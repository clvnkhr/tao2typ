// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:36:14.842021+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Cayley graphs and the geometry of groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Cayley graphs and the geometry of groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 July 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")[#text("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In most undergraduate courses, groups are first introduced as a primarily ")#emph[#text("algebraic")]#text(" concept – a set equipped with a number of algebraic operations (group multiplication, multiplicative inverse, and multiplicative identity) and obeying a number of rules of algebra (most notably the associative law). It is only somewhat later that one learns that groups are not solely an algebraic object, but can also be equipped with the structure of a manifold (giving rise to ")#emph[#text("Lie groups")]#text(") or a topological space (giving rise to ")#emph[#text("topological groups")]#text("). (See also ")#link("https://terrytao.wordpress.com/2009/10/19/grothendiecks-definition-of-a-group/")[#text("this post")]#text(" for a number of other ways to think about groups.)")

#text("Another important way to enrich the structure of a group ")#mi("{G}")#text(" is to give it some ")#emph[#text("geometry")]#text(". A fundamental way to provide such a geometric structure is to specify a list of generators ")#mi("{S}")#text(" of the group ")#mi("{G}")#text(". Let us call such a pair ")#mi("{(G,S)}")#text(" a ")#emph[#text("generated group")]#text("; in many important cases the set of generators ")#mi("{S}")#text(" is finite, leading to a ")#emph[#text("finitely generated group")]#text(". A generated group ")#mi("{(G,S)}")#text(" gives rise to the ")#emph[#text("word metric")]#text(" ")#mi("{d: G \\times G \\rightarrow {\\bf N}}")#text(" on ")#mi("{G}")#text(", defined to be the maximal metric for which ")#mi("{d(x,sx) \\leq 1}")#text(" for all ")#mi("{x \\in G}")#text(" and ")#mi("{s \\in S}")#text(" (or more explicitly, ")#mi("{d(x,y)}")#text(" is the least ")#mi("{m}")#text(" for which ")#mi("{y = s_1^{\\epsilon_1} \\ldots s_m^{\\epsilon_m} x}")#text(" for some ")#mi("{s_1,\\ldots,s_m \\in S}")#text(" and ")#mi("{\\epsilon_1,\\ldots,\\epsilon_m \\in \\{-1,+1\\}}")#text("). This metric then generates the balls ")#mi("{B_S(R) := \\{ x \\in G: d(x,\\text{id}) \\leq R \\}}")#text(". In the finitely generated case, the ")#mi("{B_S(R)}")#text(" are finite sets, and the rate at which the cardinality of these sets grow in ")#mi("{R}")#text(" is an important topic in the field of ")#link("http://en.wikipedia.org/wiki/Geometric_group_theory")[#text("geometric group theory")]#text(". The idea of studying a finitely generated group via the geometry of its metric goes back at least to the work of Dehn.")

#text("One way to visualise the geometry of a generated group is to look at the (labeled) ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley colour graph")]#text(" of the generated group ")#mi("{(G,S)}")#text(". This is a directed coloured graph, with edges coloured by the elements of ")#mi("{S}")#text(", and vertices labeled by elements of ")#mi("{G}")#text(", with a directed edge of colour ")#mi("{s}")#text(" from ")#mi("{x}")#text(" to ")#mi("{sx}")#text(" for each ")#mi("{x \\in G}")#text(" and ")#mi("{s \\in S}")#text(". The word metric then corresponds to the graph metric of the Cayley graph.")

#text("For instance, the Cayley graph of the cyclic group ")#mi("{{\\bf Z}/6{\\bf Z}}")#text(" with a single generator ")#mi("{S = \\{1\\}}")#text(" (which we draw in green) is given as")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/07/z61.png")[#image("../assets/77beb569dc973c90505b10b95bd7159cf6650f13a9287865accf55b3709e74d7-14f8cd190c3df7e4d64830fd1472a8fd582961344be17667cc5b91abbbeb20bb.png", width: 90%)]

#text("while the Cayley graph of the same group but with the generators ")#mi("{S = \\{2,3\\}}")#text(" (which we draw in blue and red respectively) is given as")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/07/z621.png")[#image("../assets/ccdc42b4a4fcfc649e7e30571cf104e498fdf1df38d32744df08e0e28c940f3f-0e765a6dc8b72f9cd138da46618250947725aeaf8fc6bf6355f6c313c703ccf7.png", width: 90%)]

#text("We can thus see that the same group can have somewhat different geometry if one changes the set of generators. For instance, in a large cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", with a single generator ")#mi("{S = \\{1\\}}")#text(" the Cayley graph “looks one-dimensional”, and balls ")#mi("{B_S(R)}")#text(" grow linearly in ")#mi("{R}")#text(" until they saturate the entire group, whereas with two generators ")#mi("{S = \\{s_1,s_2\\}}")#text(" chosen at random, the Cayley graph “looks two-dimensional”, and the balls ")#mi("{B_S(R)}")#text(" typically grow quadratically until they saturate the entire group.")

#text("Cayley graphs have three distinguishing properties:")

#list(
[#text("(Regularity) For each colour ")#mi("{s \\in S}")#text(", every vertex ")#mi("{x}")#text(" has a single ")#mi("{s}")#text("-edge leading out of ")#mi("{x}")#text(", and a single ")#mi("{s}")#text("-edge leading into ")#mi("{x}")#text(".")],
[#text("(Connectedness) The graph is connected.")],
[#text("(Homogeneity) For every pair of vertices ")#mi("{x, y}")#text(", there is a unique coloured graph isomorphism that maps ")#mi("{x}")#text(" to ")#mi("{y}")#text(".")]
)

#text("It is easy to verify that a directed coloured graph is a Cayley graph (up to relabeling) if and only if it obeys the above three properties. Indeed, given a graph ")#mi("{(V,E)}")#text(" with the above properties, one sets ")#mi("{G}")#text(" to equal the (coloured) automorphism group of the graph ")#mi("{(V,E)}")#text("; arbitrarily designating one of the vertices of ")#mi("{V}")#text(" to be the identity element ")#mi("{\\text{id}}")#text(", we can then identify all the other vertices in ")#mi("{V}")#text(" with a group element. One then identifies each colour ")#mi("{s \\in S}")#text(" with the vertex that one reaches from ")#mi("{\\text{id}}")#text(" by an ")#mi("{s}")#text("-coloured edge. Conversely, every Cayley graph of a generated group ")#mi("{(G,S)}")#text(" is clearly regular, is connected because ")#mi("{S}")#text(" generates ")#mi("{G}")#text(", and has isomorphisms given by right multiplication ")#mi("{x \\mapsto xg}")#text(" for all ")#mi("{g\\in G}")#text(". (The regularity and connectedness properties already ensure the uniqueness component of the homogeneity property.)")

#text("From the above equivalence, we see that we do not really need the vertex labels on the Cayley graph in order to describe a generated group, and so we will now drop these labels and work solely with ")#emph[#text("unlabeled")]#text(" Cayley graphs, in which the vertex set is not already identified with the group. As we saw above, one just needs to designate a marked vertex of the graph as the “identity” or “origin” in order to turn an unlabeled Cayley graph into a labeled Cayley graph; but from homogeneity we see that all vertices of an unlabeled Cayley graph “look the same” and there is no canonical preference for choosing one vertex as the identity over another. I prefer here to keep the graphs unlabeled to emphasise the homogeneous nature of the graph.")

#text("It is instructive to revisit the basic concepts of group theory using the language of (unlabeled) Cayley graphs, and to see how geometric many of these concepts are. In order to facilitate the drawing of pictures, I work here only with small finite groups (or Cayley graphs), but the discussion certainly is applicable to large or infinite groups (or Cayley graphs) also.")

#text("For instance, in this setting, the concept of ")#emph[#text("abelianness")]#text(" is analogous to that of a ")#emph[#text("flat")]#text(" (zero-curvature) geometry: given any two colours ")#mi("{s_1, s_2}")#text(", a directed path with colours ")#mi("{s_1, s_2, s_1^{-1}, s_2^{-1}}")#text(" (adopting the obvious convention that the reversal of an ")#mi("{s}")#text("-coloured directed edge is considered an ")#mi("{s^{-1}}")#text("-coloured directed edge) returns to where it started. (Note that a generated group ")#mi("{(G,S)}")#text(" is abelian if and only if the generators in ")#mi("{S}")#text(" pairwise commute with each other.) Thus, for instance, the two depictions of ")#mi("{{\\bf Z}/6{\\bf Z}}")#text(" above are abelian, whereas the group ")#mi("{S_3}")#text(", which is also the dihedral group of the triangle and thus admits the Cayley graph")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/07/s31.png")[#image("../assets/f14d8684eb3d25f24a0d40312a3915c101d31620d000d173bf41ee4d3700bfff-0d7057437698eb9eb8603a2b3b1d7eb79e86c7ec90005b7fa2e32ae0ed79fddc.png", width: 90%)]

#text("is not abelian.")

#text("A subgroup ")#mi("{(G^{\\prime},S^{\\prime})}")#text(" of a generated group ")#mi("{(G,S)}")#text(" can be easily described in Cayley graph language if the generators ")#mi("{S^{\\prime}}")#text(" of ")#mi("{G^{\\prime}}")#text(" happen to be a subset of the generators ")#mi("{S}")#text(" of ")#mi("{G}")#text(". In that case, if one begins with the Cayley graph of ")#mi("{(G,S)}")#text(" and erases all colours except for those colours in ")#mi("{S^{\\prime}}")#text(", then the graph ")#emph[#text("foliates")]#text(" into connected components, each of which is isomorphic to the Cayley graph of ")#mi("{(G^{\\prime},S^{\\prime})}")#text(". For instance, in the above Cayley graph depiction of ")#mi("{S_3}")#text(", erasing the blue colour leads to three copies of the red Cayley graph (which has ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" as its structure group), while erasing the red colour leads to two copies of the blue Cayley graph (which as ")#mi("{A_3 \\equiv {\\bf Z}/3{\\bf Z}}")#text(" as its structure group). If ")#mi("{S^{\\prime}}")#text(" is not contained in ")#mi("{S}")#text(", then one has to first “change basis” and add or remove some coloured edges to the original Cayley graph before one can obtain this formulation (thus for instance ")#mi("{S_3}")#text(" contains two more subgroups of order two that are not immediately apparent with this choice of generators). Nevertheless the geometric intuition that subgroups are analogous to ")#link("http://en.wikipedia.org/wiki/Foliation")[#text("foliations")]#text(" is still quite a good one.")

#text("We saw that a subgroup ")#mi("{(G^{\\prime},S^{\\prime})}")#text(" of a generated group ")#mi("{(G,S)}")#text(" with ")#mi("{S^{\\prime} \\subset S}")#text(" foliates the larger Cayley graph into ")#mi("{S^{\\prime}}")#text("-connected components, each of which is a copy of the smaller Cayley graph. The remaining colours in ")#mi("{S}")#text(" then join those ")#mi("{S^{\\prime}}")#text("-components to each other. In some cases, each colour ")#mi("{s \\in S\\backslash S^{\\prime}}")#text(" will connect a ")#mi("{S^{\\prime}}")#text("-component to exactly one other ")#mi("{S^{\\prime}}")#text("-component; this is the case for instance when one splits ")#mi("{S_3}")#text(" into two blue components. In other cases, a colour ")#mi("{s}")#text(" can connect a ")#mi("{S^{\\prime}}")#text("-component to multiple ")#mi("{S^{\\prime}}")#text("-components; this is the case for instance when one splits ")#mi("{S_3}")#text(" into three red components. The former case occurs precisely when the subgroup ")#mi("{G^{\\prime}}")#text(" is ")#emph[#text("normal")]#text(". (Note that a subgroup ")#mi("{G^{\\prime}}")#text(" of a generated group ")#mi("{(G,S)}")#text(" is normal if and only if left-multiplication by a generator of ")#mi("{S}")#text(" maps right-cosets of ")#mi("{G^{\\prime}}")#text(" to right-cosets of ")#mi("{G^{\\prime}}")#text(".) We can then ")#emph[#text("quotient out")]#text(" the ")#mi("{(G^{\\prime},S^{\\prime})}")#text(" Cayley graph from ")#mi("{(G,S)}")#text(", leading to a quotient Cayley graph ")#mi("{(G/G^{\\prime}, S \\backslash S^{\\prime})}")#text(" whose vertices are the ")#mi("{S^{\\prime}}")#text("-connected components of ")#mi("{(G,S)}")#text(", and the edges are projected from ")#mi("{(G,S)}")#text(" in the obvious manner. We can then view the original graph ")#mi("{(G,S)}")#text(" as a ")#emph[#text("bundle")]#text(" of ")#mi("{(G^{\\prime},S^{\\prime})}")#text("-graphs over a base ")#mi("{(G/G^{\\prime},S\\backslash S^{\\prime})}")#text("-graph (or equivalently, an ")#emph[#text("extension")]#text(" of the base graph ")#mi("{(G/G^{\\prime},S\\backslash S^{\\prime})}")#text(" by the fibre graph ")#mi("{(G^{\\prime},S^{\\prime})}")#text("); for instance ")#mi("{S_3}")#text(" can be viewed as a bundle of the blue graph ")#mi("{A_3}")#text(" over the red graph ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(", but not conversely. We thus see that the geometric analogue of the concept of a normal subgroup is that of a ")#link("http://en.wikipedia.org/wiki/Bundle_(mathematics)")[#text("bundle")]#text(". The generators in ")#mi("{S \\backslash S^{\\prime}}")#text(" can be viewed as describing a ")#link("http://en.wikipedia.org/wiki/Connection_(mathematics)")[#text("connection")]#text(" on that bundle.")

#text("Note, though, that the structure group of this connection is not simply ")#mi("{G^{\\prime}}")#text(", unless ")#mi("{G^{\\prime}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Central_subgroup")[#text("central")]#text(" subgroup; instead, it is the larger group ")#mi("{G^{\\prime} \\rtimes \\text{Aut}(G^{\\prime})}")#text(", the semi-direct product of ")#mi("{G^{\\prime}}")#text(" with its automorphism group. This is because a non-central subgroup ")#mi("{G^{\\prime}}")#text(" can be “twisted around” by operations such as conjugation ")#mi("{g^{\\prime} \\mapsto sg^{\\prime}s^{-1}}")#text(" by a generator ")#mi("{s \\in S}")#text(". So central subgroups are analogous to the geometric notion of a ")#link("http://en.wikipedia.org/wiki/Principal_bundle")[#text("principal bundle")]#text(". For instance, here is the Heisenberg group")

#mi("\\displaystyle  \\begin{pmatrix} 1 & {\\bf F}_2 & {\\bf F}_2 \\\\ 0 & 1 & {\\bf F}_2 \\\\ 0 & 0 & 1 \\end{pmatrix}")

#text("over the field ")#mi("{{\\bf F}_2}")#text(" of two elements, which one can view as a central extension of ")#mi("{{\\bf F}_2^2}")#text(" (the blue and green edges, after quotienting) by ")#mi("{{\\bf F}_2}")#text(" (the red edges):")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/07/heisen1.png")[#image("../assets/1c83aaff81e2fe85ae08c6b79f46082fc146a8ef4737a916b119ce9a278f0444-73c3638d08277987104803791acff976522ff5bc0a3ecd664160e60df71b0787.png", width: 90%)]

#text("Note how close this group is to being abelian; more generally, one can think of nilpotent groups as being a slight perturbation of abelian groups.")

#text("In the case of ")#mi("{S_3}")#text(" (viewed as a bundle of the blue graph ")#mi("{A_3}")#text(" over the red graph ")#mi("{{\\bf Z}/2{\\bf Z}}")#text("), the base graph ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" is in fact embedded (three times) into the large graph ")#mi("{S_3}")#text(". More generally, the base graph ")#mi("{(G/G^{\\prime}, S \\backslash S^{\\prime})}")#text(" can be lifted back into the extension ")#mi("{(G,S)}")#text(" if and only if the short exact sequence ")#mi("{0 \\rightarrow G^{\\prime} \\rightarrow G \\rightarrow G/G^{\\prime} \\rightarrow 0}")#text(" ")#link("http://en.wikipedia.org/wiki/Split_(mathematics)")[#text("splits")]#text(", in which case ")#mi("{G}")#text(" becomes a ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semidirect product")]#text(" ")#mi("{G \\equiv G^{\\prime} \\rtimes H}")#text(" of ")#mi("{G^{\\prime}}")#text(" and a lifted copy ")#mi("{H}")#text(" of ")#mi("{G/G^{\\prime}}")#text(". Not all bundles can be split in this fashion. For instance, consider the group ")#mi("{{\\bf Z}/9{\\bf Z}}")#text(", with the blue generator ")#mi("{1}")#text(" and the red generator ")#mi("{3}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/07/z91.png")[#image("../assets/41c79d15fd3135fd033fbe4776a45c48194b7f81f29052ba636fa8d6c60d547e-f7525c5cdf10faa9d1ef60f1e5226a6ffc94edbd29e00b79e7595f9e167e18ea.png", width: 90%)]

#text("This is a ")#mi("{{\\bf Z}/3{\\bf Z}}")#text("-bundle over ")#mi("{{\\bf Z}/3{\\bf Z}}")#text(" that does not split; the blue Cayley graph of ")#mi("{{\\bf Z}/3{\\bf Z}}")#text(" is not visible in the ")#mi("{{\\bf Z}/9{\\bf Z}}")#text(" graph directly, but only after one quotients out the red fibre subgraph. The notion of a splitting in group theory is analogous to the geometric notion of a ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("global gauge")]#text(". The existence of such a splitting or gauge, and the relationship between two such splittings or gauges, are controlled by the ")#link("http://en.wikipedia.org/wiki/Group_cohomology")[#text("group cohomology")]#text(" of the sequence ")#mi("{0 \\rightarrow G^{\\prime} \\rightarrow G \\rightarrow G/G^{\\prime} \\rightarrow 0}")#text(".")

#text("Even when one has a splitting, the bundle need not be completely trivial, because the bundle is not principal, and the connection can still twist the fibres around. For instance, ")#mi("{S_3}")#text(" when viewed as a bundle over ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" with fibres ")#mi("{A_3}")#text(" splits, but observe that if one uses the red generator of this splitting to move from one copy of the blue ")#mi("{A_3}")#text(" graph to the other, that the orientation of the graph changes. The bundle is trivialisable if and only if ")#mi("{G^{\\prime}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Direct_sum")[#text("direct summand")]#text(" of ")#mi("{G}")#text(", i.e. ")#mi("{G}")#text(" splits as a direct product ")#mi("{G = G^{\\prime} \\times H}")#text(" of a lifted copy ")#mi("{H}")#text(" of ")#mi("{G/G^{\\prime}}")#text(". Thus we see that the geometric analogue of a direct summand is that of a trivialisable bundle (and that trivial bundles are then the analogue of direct products). Note that there can be more than one way to trivialise a bundle. For instance, with the Klein four-group ")#mi("{{\\bf Z}/2{\\bf Z} \\times {\\bf Z}/2{\\bf Z}}")#text(",")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/07/klein.png")[#image("../assets/804230a547a941347aee630f8f58fce0552576d886ea9fbf3d69665145bd8e19-a66bd37179b38838960fbfffc78cb20e5a48540870951609bb527f3198409d74.png", width: 90%)]

#text("the red fibre ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" is a direct summand, but one can use either the blue lift of ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" or the green lift of ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(" as the complementary factor.")

#heading(level: 1)[#text("Comments (47)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39be2b741f5db6b9353e856dec84ec21b8b8926658595af6eb2ba1fe4034e3db-57f8a23a2d0df915fb6c6f2a6bf5621c610b963fa3459c3f36a8d34fe528f89e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew L.")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45935")[#strong[#text("Andrew L.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("First off, I LOVE these “by the way” lecture posts of yours,Professor Tao. They’re a great resource for the entire mathematical community. It’s very comforting to know there’s a top notch researcher who seems just as passionate about teaching as you are. Keep up the great work.")#linebreak()#text(" The serious study of the geometric properties of groups and thier associated graph embeddings in Euclidean spaces-which was initiated by Klein and developed by so many great mathematicians,most notably Wilhelm Magnus and his students-is a fantasticaly rich topic that isn’t incorporated into traditional courses in algebra and geometry anywhere near as fully as it should be. The classic introduction is of course, GRAPHS AND THIER GROUPS by Grossman and Magnus. A much more advanced text that covers the graph theoretic aspects-including the deeper topological properties of the Cayley graph and it’s fundamental group structure touched on in your post-can be found in GRAPHS OF GROUPS ON SURFACES by Arthur T.White,currently in it’s 3rd edition.")#linebreak()#text(" Again,thanks for the great introduction to such an important topic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4271486373661761830ae4c60dd6752067a25e8a5909b05990f9934275425518-b027e144a5572b1c4d3e6a8e924b00d87ebdd13e7c6b0e6586adbafa5cae95ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45938")[#strong[#text("Theo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("It’s a well-known fact that a connected topological group is generated by any open neighborhood of its identity element. (So it is tempting to think of a Lie group as _generated_ by its Lie algebra, after identifying the Lie algebra with an infinitesimal neighborhood of the identity. This is reasonable in models of mathematics where infinite numbers really exist. Moreover, the Baker-Campbell-Hausdorff series identifies the Lie algebra with the formal group, and over ")#mi("\\mathbb R")#text(" the BCH series converges for finite-dimensional Lie algebras in a non-trivial neighborhood of the origin, and so you really can identity a neighborhood of the Lie algebra with a neighborhood of the Lie group.) So it is tempting to take some sort of “formal neighborhood” of the identity element as my generating set ")#mi("S")#text(". Can I then think of the topology on $G$ as coming from some sort of “formal Cayley graph”? Maybe I will ask this over on MathOverflow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("Yes, one can view topological groups and Lie groups as being continuous analogues of generated groups, and indeed a significant portion of geometric group theory is devoted to viewing the former as asymptotic limits of the latter (e.g. Gromov’s original proof of Gromov’s theorem on groups of polynomial growth definitely falls into this category). The literature on Hilbert’s fifth problem (which, roughly speaking, asks whether all locally compact topological groups come from Lie groups) don’t explicitly use Cayley graphs, but it seems to be lurking beneath the surface (particularly with those solutions to that problem that use nonstandard analysis).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b869235808b2230c870170197dbf3dfc89de74b25e842f695db21a5cc7c0874-97d118c6d3647236c9ddba823fe4a743b3cd63ede25fb2c021fce205b74a9b13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jair")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45939")[#strong[#text("Jair")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("Fascinating stuff. I didn’t realize that groups were so closely connected with certain graphs. Thanks for posting this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45944")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2010")])]

#text("I like the commonsense explanation of normal groups that comes out of this presentation. By contrast, the usual definition ( g n g^{-1} \\in G) is unintuitive despite its simplicity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45954")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2010")])]

#text("So a Cayley graph is not associated with a group, but with a presented group. It’d be nice to have something that only depended on the group itself, and not the presentation. (And yes, I do know where this goes…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2010")])]

#text("To be utterly pedantic, a presented group is a slightly richer object than a generated group (which, in turn, is richer than a raw group); a presented group is a group with a distinguished set of generating elements and a distinguished set of generating relations, whereas a generated group only has the former and not the latter. (So there are forgetful functors from the category of presented groups to the category of generated groups to the category of groups.) Cayley graphs are more naturally associated with generated groups than with presented groups.")

#text("In the case of infinite finitely generated groups, changing the choice of generators only affects the word metric by a bilipschitz distortion. As such, the asymptotic (coarse) geometry of the finitely generated group does not depend on the choice of generators (e.g. the concept of a finitely generated group of polynomial growth does not depend on the choice of generators). Much of geometric group theory focuses on this asymptotic geometry and so indeed one can focus primarily on groups themselves rather than on generated groups. However, if one wants to work more quantitatively and non-asymptotically (and specifically, if one wants to talk about results that are non-trivial even for finite groups) then the choice of generators becomes more important. For instance, as discussed above, a cyclic group can look one-dimensional, two-dimensional, or many-dimensional at various scales, depending on how many generators one selects and how commensurate they are to each other.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-532683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2019")])]

#text("quasi-isometry/ the geometry of the group.")#linebreak()#text(" not dependent on the choice of generators/ the presentation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2010")])]

#text("typo in the second paragraph: $y = s_1^{\\epsilon_1} \\ldots s_m^{\\epsilon_m} y$ should be $y = s_1^{\\epsilon_1} \\ldots s_m^{\\epsilon_m} x$. Thanks for the post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2010")])]

#text("Could you elaborate on the third property (Homogeneity) of the Cayley Graph?")

#text("Is this saying that there aren’t two paths between x and y of the same color and direction along each step?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("No, this is already a consequence of the regularity hypothesis.")

#text("One way to view homogeneity is that it asserts that any graph theoretic statement that is true if one uses x as a starting vertex, is also true if one uses y as a starting vertex, so that all vertices “look the same” from a graph theoretic perspective. For instance, in the Z/9Z graph, no matter where one starts from, the operation of following three blue arrows is always equal to following one red arrow. If three blues equaled a red for one starting vertex x but not for another y, then the graph would not be homogeneous.")

#text("The formal definition of homogeneity requires the notion of a graph isomorphism,")

#link("http://en.wikipedia.org/wiki/Graph_isomorphism")[#text("http://en.wikipedia.org/wiki/Graph_isomorphism")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0256afbde4a3aae59801169ea10c1af52396c390811f26b65693dda171c0e8d9-8a69847d5b00855ac15c355b2eb2bd1d9982735da31979347fc69efdcd5fcccf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Artem")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-45989")[#strong[#text("Artem")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2010")])]

#text("«Latex path not specified» in place of several formulas. About eight hours ago everything was OK.")

#text("Thanks for interesting post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("I am pleased by this post, and I would like to understand better why the group properties discussed here are geometric?")#linebreak()#text(" Is it because they are (geo)metric? But it’s a word metric, why isn’t it algebraic?")#linebreak()#text(" The notion of ‘ball’ is not geometric either. Is ‘(polynomial) growth’ a geometric concept? you just count how many words there are of length 1,2,3,.. in your generated group.")#linebreak()#text(" That a group is abelian is visible from a multiplication table (anyway visualisation of Cayley graphs is restricted to ‘small’ groups).")#linebreak()#text(" “Nevertheless the geometric intuition that subgroups are analogous to foliations is still quite a good one.”")#linebreak()#text(" It would be interesting to know how it could help. Why is it really geometric? The notion of ‘metric’ is not engaged here. Is it geometric because it is visualised and explained by means of symbolism embedded in Euclidean plain? Yes, this method is used in geometry, but not only in geometry, in analysis, for example, too.")#linebreak()#text(" The fact that “one can view topological groups and Lie groups as being continuous analogues of generated groups” gives another view on group but does not add geometric properties, it seems to me. please, tell me if I am wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46010")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("Groups are both algebraic objects and geometric objects; it is not a dichotomy.")

#text("While ")#link("http://en.wikipedia.org/wiki/Category:Metric_geometry")[#text("metric geometry")]#text(" is certainly an important component of modern geometry, metrics are certainly not the only geometric objects of study. ")#link("http://en.wikipedia.org/wiki/Riemannian_geometry")[#text("Riemannian geometry")]#text(", for instance, is definitely very much concerned with volumes of balls, among other things. ")#link("http://en.wikipedia.org/wiki/Differential_geometry")[#text("Differential geometry")]#text(" and its relatives (e.g. ")#link("http://en.wikipedia.org/wiki/Contact_geometry")[#text("contact geometry")]#text(") is similarly quite concerned with foliations, bundles, and connections. ")#link("http://en.wikipedia.org/wiki/Kleinian_geometry")[#text("Kleinian geometry")]#text(" focuses on the notion of symmetry, which is very much a group-theoretic concept also. (The classical Euclidean geometry of points, lines, and planes can be viewed as a special case of all of the above modern types of geometry.)")

#text("Traditionally, geometry has focused mostly on continuous structures, but nowadays ")#link("http://en.wikipedia.org/wiki/Discrete_geometry")[#text("discrete geometries")]#text(" are also an important area of study, and Cayley graphs form a basic example of such.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("Is it not a dichotomy in the sense that groups have algebraic and geometric properties or in the sense, the same properties of groups can be seen as algebraic and as geometric properties? or are there properties of groups which are certainly geometric but not algebraic? Because what is ‘geometric’ at the first glance, seems to be perfectly algebraic: e.g. metric, hyperbolicity can be formulated algebraically, Cayley graphs -aren’t they algebraic objects?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("Almost every fundamental concept or object in mathematics can be interpreted in a number of different ways (algebraic, geometric, dynamical, analytical, etc.), and it is important to internalise as many of these as one can in order to truly understand these concepts. I recommend the discussion in Thurston’s article “")#link("http://arxiv.org/abs/math/9404236")[#text("On proof and progress in mathematics")]#text("” for further reading. (Section 2 is the most relevant here, but the entire article is worthwhile.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("Naive question: How do you yourself distinguish algebraic objects from geometric objects? I didn’t find the relevant wikipedia article especially helpful in this regard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/832322db8e075016debf86c466d85ca49d1c8f21dcaeb131305c4338fd2961f6-b0b6d0a72545dbcc9eeb1483614006b8c9ed504105e3acfc9a656b4f07ef0dca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xiaodong xu")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46023")[#strong[#text("xiaodong xu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2010")])]

#text("Dear Terry, you wrote")

#text("•(Connectedness) The graph is connected.")

#text("This may not be true for some Cayley graphs. For instance, Z/8Z and S={2}.")

#text("Yes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46032")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("{2} does not generate Z/8Z.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cc1343b0c29ec203f8edb625f180eb60eaeb8db0ec9993c2ff8b9a36ddd0d35-098c95a6d75883f8c7712a503d39a1271c0ddb1f83bf1777f9541bda4a9238b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of westy31")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46028")[#strong[#text("westy31")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2010")])]

#text("Dear Terrence,")

#text("I thought it would be interesting to mention the relationship between Cayley graphs and tilings. I have some pictures on thi on my web page:")

#link("http://www.xs4all.nl/~westy31/Geometry/Geometry.html#Cayley")[#text("http://www.xs4all.nl/~westy31/Geometry/Geometry.html#Cayley")]

#text("Basically, you can take any Cayley graph with 2 generators, and turn it into a tiling of a Riemann surface. Each tile corresponds to a vertex of the Cayley graph. Since any finite simple group can be generated by 2 generators, all finite simple groups are a tiling of a Riemann surface. Also, you can interpret the tiling itself as a Cayly graph, by labeling rotations around the vertices as generators.")

#text("One question that comes to mind if the genus of the surface has some group theoretic meaning.")

#text("Gerard")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cec63be731542236f25e1cb4a7d42c9e3ecf844a2bc6f14f1d6dda0602dd4f9f-c2fb5af9a52260ed0c42c0258ed193f17f05833511f60dc48be715542e63548d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46071")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2010")])]

#text("Interesting article. In the second paragraph after the picture of S_3 you mention it can be split into “two red components” and “three blue components”. I believe you mean “two blue components” and “three red components”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58dade4e86297e55b0bd61f03e045807cb9b2d4c0909597cd911b2452ebfed7b-633771b0a2026b90a61ed3e75a1014855ca406c605ad163d16451a0bb46a4d23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46089")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2010")])]

#text("You wrote:")#linebreak()#text(" “In some cases, each colour {s \\in S\\backslash S’} will connect a {S’}-component to exactly one other {S’}-component; this is the case for instance when one splits {S_3} into three red components. In other cases, a colour {s} can connect a {S’}-component to multiple {S’}-components; this is the case for instance when one splits {S_3} into two blue components. ”")

#text("which should probably (???) read:")

#text("In some cases, each colour {s \\in S\\backslash S’} will connect a {S’}-component to exactly one other {S’}-component; this is the case for instance when one splits {S_3} into two blue components. In other cases, a colour {s} can connect a {S’}-component to multiple {S’}-components; this is the case for instance when one splits {S_3} into three red components.")

#emph[#text("[Oops! I implemented a previous fix incorrectly. Thanks, it should be correct now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46196")[#strong[#text("Politopos. « US Patent Appl. 12213303: Comentarios.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2010")]

#text("[…] 3….y un post muy informativo sobre grafos de Cayley como “representación geometrica” de grupos: ")#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")[#text("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marry")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46678")[#strong[#text("marry")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("Hi,")#linebreak()#text(" I am newly interested in cayley graph. I read note on cayley graphs. may be it is very clear but I could not understand how can I draw ,i.e. how can ı draw directed edge? you gave example for 6Z and S={1}. as you say, I use from x to sx. but only one element exists in S and then edge is from 1 to 1, 2 to 2… and so on. Can I misunderstand?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("In the case of an additive group such as ")#mi("{\\bf Z}/6{\\bf Z} = ({\\bf Z}/6{\\bf Z}, +)")#text(" rather than a multiplicative group ")#mi("G = (G,\\cdot)")#text(", one would connect x to s+x, rather than x to sx.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marry")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46696")[#strong[#text("marry")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" firstly, thanks for answering my previous question.")#linebreak()#text(" I wonder that all inverse element of S is also S. Is this necessary or not?")#linebreak()#text(" in your note about cayley graphs you did not wrote but some books add this condition.")#linebreak()#text(" and you said that word metric is the maximal metric .What reason is maximal?")#linebreak()#text(" best regards,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2010")])]

#text("There are two types of Cayley graphs: directed Cayley graphs (the ones discussed here) and undirected Cayley graphs. The latter require a symmetric set of generators, and the former does not.")

#text("The word metric is maximal with respect to the pointwise order on metrics (in which one writes ")#mi("d \\leq d^{\\prime}")#text(" for two metrics d,d’ if one has ")#mi("d(x,y) \\leq d^{\\prime}(x,y)")#text(" for all x,y) subject to the constraint that ")#mi("d(x,sx) \\leq 1")#text(" for all x in G and s in S. This is a succinct way to define the word metric, but perhaps not the most enlightening, which is why I also added a more explicit description of that metric.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a6835f996fec28e917c607e2a047639e3a07573ff2ece27b9ffa20686608e18-edbb354bbe5c3e91b083ad0f6c19dd3a8e669da8758bc86d386d95b332cd2c71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Son")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-143595")[#strong[#text("Son")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2012")])]

#text("Dear prof. Tao,")#linebreak()#text(" Would ")#mi("d(x,y)\\in \\{0,1\\}")#text(" only? Only that would make sense to me because this is kind of defining a metric of orbit of ")#mi("x")#text(". What we care here is to establish the connection between ")#mi("x")#text(" and its orbits. If the action of ")#mi("s\\in S")#text(" on ")#mi("x")#text(" results in ")#mi("x")#text(", ")#mi("d(x,sx)=0")#text(". Otherwise, it is ")#mi("1")#text(".")#linebreak()#text(" If that’s the case, ")#mi("d(x,y)=d(x,s_m^{\\epsilon_m}\\dots s_1^{\\epsilon_1}x)\\le d(s_2^{\\epsilon_2}\\dots s_m^{\\epsilon_m}x,s_1^{\\epsilon_1}\\dots s_m^{\\epsilon_m}x)+\\dots+d(x,s_1^{\\epsilon_1}x)\\le m")#text(".")#linebreak()#text(" That’s how I can make sense of this. Please correct me if I’m wrong.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marry")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-46719")[#strong[#text("marry")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("Dear prof. Tao,")#linebreak()#text(" you said that a directed coloured graph is a Cayley graph (up to relabeling) if and only if it obeys the above three properties. I understand one way of the proof. conversely for showing that cayley graph satisfy property of Homogeneity ,you use right multiplication xg. Can we choose left multiplication instead of right?")#linebreak()#text(" best regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-70863")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] describes the geometry of the Cayley graph on formed by connecting to for each and . (See this previous post for more discussion of using Cayley graphs to study groups […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cayley graphs and the algebra of groups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-142504")[#strong[#text("Cayley graphs and the algebra of groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2012")])]

#text("[…] is a sequel to my previous blog post “Cayley graphs and the geometry of groups“. In that post, the concept of a Cayley graph of a group was used to place some geometry on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geometric conceptions of groups (and walks of graphs from groups); Heisenburg group | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-251606")[#strong[#text("geometric conceptions of groups (and walks of graphs from groups); Heisenburg group | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")[#text("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb1bde8f63337329827dcc0bc46fe1d78a10c14f6e867396e6425bd6ff7d8acd-2dbfa0110dc9059f5846005cab9d8cad2008f50ff516c6514c688d92870dab43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Imran")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-269590")[#strong[#text("Imran")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("I want to ask a question…that If we have a finite presentation of a group, but order of the generators are unknown, then can we draw a cayley graph of that group?? if yes, then by which mean")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e80cea39365dc7e565dc165c60e3fe922622dd0f581abde72dc1d44ac34506a-4b4d5dee2e8590fd335322da2c5eabbe0e6d547bb3df3aebb470ad641f7f9f67.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tuấn Bùi")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-402186")[#strong[#text("Tuấn Bùi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2014")])]

#text("Reblogged this on ")#link("http://tbuif84.wordpress.com/2014/08/03/cayley-graphs-and-the-geometry-of-groups/")[#text("Tuấn Bùi ")]#text(" and commented:")#linebreak()#text(" Archived!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24feeeaff40d4e1eb1ff7ccd489ac9086df5cd2b5cae4f1f4d58acd106978144-c127df886cdba2b85b2b92ca50b8a27e813d8b0d75b23bb56babcc2ac066fdc2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-430173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2014")])]

#text("Does the undirected cayley graph representation of a group always have a hamiltonian cycle for any choice of generators?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-430324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2014")])]

#text("This turns out to be a well studied problem with many partial results, though still far from completely solved: ")#link("http://www.sciencedirect.com/science/article/pii/0012365X95000725")[#text("http://www.sciencedirect.com/science/article/pii/0012365X95000725")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-452182")[#strong[#text("Groups and Group Actions: Lecture 2 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2015")]

#text("[…] in various places, for example Fields medallist Terry Tao has written about them on his blog, e.g. here (warning: this post assumes knowledge of more advanced maths than first-year undergraduates usually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-452219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2015")])]

#text("Another interesting example is the study of the subgroup of algebraic functions (of one complex variable over the Riemann sphere) generated by compositions of (all branches) of finitely many algebraic functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f38135f25795836a7b0066fdbc1fdd8e9c492bcee96463f796a5723b61ef38-ebb11570e100682fb20e5fa728f30fab74537aa64d388262d5fa8f449c342760.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Valentino")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-454971")[#strong[#text("Valentino")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("I have a (probably) easy question.")

#text("Given a generating set S for a group G, I ask if the following proposition is true or not: “G has exactly one longest element wrt S if and only if S is a minimal generating set” ???")

#text("I know that this question can also be interpreted in terms of “minimal” Cayley graphs, but I can’t realize if it’s true or not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-459534")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2015")])]

#text("Reblogged this on ")#link("https://tomcircle.wordpress.com/2015/09/21/cayley-graphs-and-the-geometry-of-groups/")[#text("Math Online Tom Circle")]#text(" and commented:")#linebreak()#text(" Terence Tao’s wrote this easy-to-understand Group Theory. It is rare for mathematicians to be also a good writer in explaining difficult math in layman’s terms. Highly recommended!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac7ed09db418de4c6ad887e881ba29799258b7016ef63768e59a39c32617bf42-9647b4ff0eb158042dae6f59dca371c486dd8c6b19cde78cd8b11a9aaa6c3a05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peterisdaugulis")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-466355")[#strong[#text("peterisdaugulis")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2016")])]

#text("Dear Terrence,")#linebreak()#text(" have induced cycles (cycles without chords) of Cayley graphs been studied as essential relations for the given generators? Are there any references?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-476786")[#strong[#text("Groups and graphs (and computation) | Bahçemizi Yetiştermeliyiz")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2017")]

#text("[…] a group G, or more specifically a finite set S of generators for G, one can form the Cayley graph by taking the vertex set to be the set of group elements, and adding an edge iff for some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-478291")[#strong[#text("Groups and Group Actions: Lecture 2 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2017")]

#text("[…] in various places, for example Fields medallist Terry Tao has written about them on his blog, eg here (warning: this post assumes knowledge of more advanced maths than first-year undergraduates usually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-488914")[#strong[#text("Graph operators on Discrete Groups – oolongteafan1")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")[#text("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-685675")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2024")])]

#text("Professor Tao: Z/6Z for primes equal to or greater than 5 modulo 6 has been studied?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-689621")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2026")])]

#text("Dear Prof. Tao,")

#text("You mentioned that group-a set equipped with algebraic operations (group multiplication, multiplicative inverse, and multiplicative identity), but why would you tend to designate a binary operation in a group as “multiplication”? Is multiplication a more fundamental binary operation than addition?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/07/10/cayley-graphs-and-the-geometry-of-groups/#comment-689623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2026")])]

#text("Generally speaking, “addition” carries connotations of both commutativity and associativity, whereas “multiplication” only carries connotations of associativity. So when working with non-abelian groups, it is preferred to use multiplicative notation. (When one does not even have associativity, it is generally preferred to use a more neutral symbol to denote such binary operations, e.g., ")#mi("\\diamond")#text(".)")
]
]
