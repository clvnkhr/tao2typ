// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/
// Converted to Typst by tao2typ: "2026-10-14T16:39:23.561734+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Third SAIR competition: inverse Galois challenge", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Third SAIR competition: inverse Galois challenge")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 June 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/")[#text("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I am happy to announce the ")#link("https://competition.sair.foundation/competitions/igp24/overview")[#text("third SAIR challenge")]#text(", which is focused on obtaining numerical data for the infamous ")#link("https://en.wikipedia.org/wiki/Inverse_Galois_problem")[#text("inverse Galois problem")]#text(". This is a collaborative project with the ")#link("https://www.lmfdb.org/")[#text("L-functions and modular forms database")]#text(" (LMFDB), and is organized by ")#link("https://hobbes.la.asu.edu/")[#text("John Jones")]#text(", ")#link("https://www.jenpaulhus.com/")[#text("Jen Paulhus")]#text(", ")#link("https://math.mit.edu/~roed/")[#text("David Roe")]#text(", ")#link("https://math.mit.edu/~drew/")[#text("Andrew Sutherland")]#text(", and myself. The challenge is somewhat similar to my own ")#link("https://github.com/teorth/equational_theories")[#text("Equational Theories Project")]#text(", in that one is trying to complete a large mathematical data set in a verified fashion, except that the target data set had an existing mathematical interest. Also, the verification will be done by ")#link("https://en.wikipedia.org/wiki/Magma_(computer_algebra_system)")[#text("MAGMA")]#text(" (as well as ")#link("https://en.wikipedia.org/wiki/PARI/GP")[#text("PARI/GP")]#text(") rather than Lean.")

#text("Let me first quickly review the inverse Galois problem. Suppose one has an irreducible polynomial ")#mi("{P(z)}")#text(" of one variable of some degree ")#mi("{n}")#text(" and integer coefficients; take for instance ")#mi("{P(z) = z^3 - 3z + 1}")#text(". Then ")#mi("{P}")#text(" will have ")#mi("{n}")#text(" distinct roots ")#mi("{\\alpha_1,\\dots,\\alpha_n}")#text("; in this case the roots happen to be")

#mi("\\displaystyle \\alpha_1 = 2 \\cos \\frac{2\\pi}{9}, \\quad \\alpha_2 = 2 \\cos \\frac{8\\pi}{9}, \\quad \\alpha_3 = 2 \\cos \\frac{14 \\pi}{9}.")#text(" The roots generate a splitting field ")#mi("{\\mathbb{Q}(\\alpha_1,\\dots,\\alpha_n)}")#text(" over the rational numbers ")#mi("{\\mathbb{Q}}")#text(". Any automorphism of this splitting field must permute the roots ")#mi("{\\alpha_1,\\dots,\\alpha_n}")#text(", and thus generates a subgroup of the permutation group ")#mi("{S_n}")#text(" (defined up to relabeling of the roots), which we call the ")#emph[#text("Galois group")]#text(" of ")#mi("{P}")#text(". This is some subgroup of ")#mi("{S_n}")#text(" that acts transitively on the ")#mi("{n}")#text(" roots (because each root generates the field). Typically, it is all of ")#mi("{S_n}")#text("; but occasionally it is smaller. For example, the particular cubic polynomial ")#mi("{P}")#text(" above has the special property that each root ")#mi("{\\alpha_1,\\alpha_2,\\alpha_3}")#text(" individually generates the entire field ")#mi("{\\mathbb{Q}(\\alpha_1,\\alpha_2,\\alpha_3)}")#text(", thanks to the identities")

#mi("\\displaystyle  \\alpha_2 = \\alpha_1^2 - 2; \\quad \\alpha_3 = \\alpha_2^2 - 2; \\quad \\alpha_1 = \\alpha_3^2 - 2.")#text(" Because of this, the Galois group of ")#mi("{P}")#text(" is the cyclic group ")#mi("{C_3}")#text(" (or equivalently, the alternating group ")#mi("{A_3}")#text("), rather than the full symmetric group ")#mi("{S_3}")#text(". (This is in contrast to, say, ")#mi("{P(z) = z^3 - 2}")#text(", whose roots ")#mi("{\\alpha_1 = 2^{1/3}}")#text(", ")#mi("{\\alpha_2 = 2^{1/3} \\omega}")#text(", ")#mi("{\\alpha_3 = 2^{1/3} \\omega^2}")#text(" cannot be expressed as rational polynomials of each other, and whose Galois group is all of ")#mi("{S_3}")#text(".) In fact, in the cubic case, it turns out that the Galois group is ")#mi("{A_3}")#text(" when the ")#link("https://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" is a perfect square, and ")#mi("{S_3}")#text(" otherwise.")

#text("More generally, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Inverse Galois Problem)")]#text(" Let ")#mi("{G}")#text(" be a transitive permutation group on ")#mi("{n}")#text(" letters. Can ")#mi("{G}")#text(" be realized as the Galois group of some degree ")#mi("{n}")#text(" irreducible polynomial ")#mi("{P(z)}")#text(" with integer coefficients (after identifying the ")#mi("{n}")#text(" roots of ")#mi("{P}")#text(" suitably with the ")#mi("{n}")#text(" letters)?")
]

#text("The answer to this problem is known to be positive for ")#mi("{n \\leq 23}")#text(", with the single possible exception of the sporadic ")#link("https://en.wikipedia.org/wiki/Mathieu_group")[#text("Mathieu group")]#text(" ")#mi("{M_{23}}")#text(": ")#link("https://www.lmfdb.org/GaloisGroup/stats")[#text("there are ")#mi("{4953}")#text(" transitive permutation groups")]#text(" on ")#mi("{n \\leq 23}")#text(" letters (cf. ")#link("https://oeis.org/A002106")[#text("OEIS A002106")]#text("), and for ")#mi("{4952}")#text(" of them, a polynomial has been located with that Galois group; see ")#link("https://galoisdb.math.upb.de/")[#text("this database")]#text(" of Klüners and Malle. The problem of locating a polynomial with Galois group ")#mi("{M_{23}}")#text(" is a notorious open problem, though this is likely to be quite a difficult problem, and ")#emph[#text("not")]#text(" the objective of the SAIR challenge.")

#text("Instead, we will focus on “breadth” rather than “depth”, in order to leverage the power of crowdsourcing and modern AI technologies. It turns out that ")#link("https://www.lmfdb.org/GaloisGroup/?n=24")[#text("there are ")#mi("{25000}")#text(" distinct transitive permutation groups on ")#mi("{n=24}")#text(" letters")]#text(", which are conventionally labeled from ")#mi("{24T1}")#text(" (the cyclic group ")#mi("{C_{24}}")#text(") to ")#mi("{24T25000}")#text(" (the permutation group ")#mi("{S_{24}}")#text("). The first stage of the challenge will be:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 2 (First stage of SAIR challenge)")]#text(" For as many of the groups ")#mi("{24Tt}")#text(", ")#mi("{t = 1,\\dots,25000}")#text(", locate an integer polynomial with that Galois group (up to isomorphism). (Also of interest is to specify the number of real roots, and to keep the discriminant low; more on this later.)")
]

#text("The verification side of this problem is essentially solved: the MAGMA computer algebra system can take any candidate polynomial and locate its Galois group within seconds. The MAGMA team has kindly granted SAIR a limited license to ")#link("https://competition.sair.foundation/competitions/igp24/api")[#text("provide an API")]#text(" for contestants to calculate a certain number of Galois groups per day without needing to purchase their own license, though of course they are free to use their other computational tools to also perform these calculations outside of the competition.")

#text("The LMFDB already has polynomials for 286 of the 25000 groups, so there is plenty of remaining polynomials to claim in the challenge.")

#text("For applications, it is of interest to track some other statistics of a polynomial besides its Galois group. One of these is the number ")#mi("{r}")#text(" of real roots, which is a number between ")#mi("{0}")#text(" and ")#mi("{n}")#text(" of the same parity as ")#mi("{n}")#text(" (and which has to be achievable as the number of fixed points of one of the permutations in the Galois group, namely the one corresponding to complex conjugation); in particular, this number must be even in the degree ")#mi("{24}")#text(" case. Combining the label ")#mi("{t}")#text(" of the Galois group with the number of roots ")#mi("{r}")#text(" turns out to generate ")#mi("{165836}")#text(" ")#mi("{(t,r)}")#text(" pairs in degree ")#mi("{24}")#text(", and the challenge is actually to attach polynomials to as many of these pairs as possible. (The LMFDB has already done so for just ")#mi("{622}")#text(" of these.)")

#text("Of course, there are infinitely many polynomials of degree ")#mi("{24}")#text(", and any Galois group that is representable by one polynomial, will be representable by infinitely many others (e.g., one could simply translate the polynomial by an arbitrary integer shift). To avoid creating an unusable database filled with uninteresting polynomials, we will prioritize polynomials whose (absolute) discriminant is as small as possible. (There are some technical details as to how this discriminant is defined and computed; see ")#link("https://competition.sair.foundation/competitions/igp24/evaluation-setup")[#text("this page")]#text(" for details). The way we have set things up, each ")#mi("{(t,r)}")#text(" pair will come with a leaderboard for the polynomials with the smallest discriminants that have been located so far by contestants, removing duplicates arising from trivial operations such as translating the polynomial. Contestant team will be awarded a score between ")#mi("{0}")#text(" and ")#mi("{1}")#text(" for each submitted polynomial based on how small their discriminant is compared to the best known discriminant, and how many other teams were also able to find a polynomial with that ")#mi("{(t,r)}")#text(" pair. Thus, pairs that are extremely easy to generate (such as those associated to the full permutation group ")#mi("{S_{24}}")#text(") will be worth only a negligible score (as every contestant will be able to submit a polynomial for that pair), while pairs which are difficult to locate a polynomial for will be worth more points.")

#text("For this competition, the unrestricted use of any sort of computational tool, including AI, to locate the polynomials, are expressly permitted; this first stage of the competition is a “black box” challenge where we are not directly interested in obtaining insights as to ")#emph[#text("how")]#text(" the polynomials are located, but the sole objective is to resolve as much of the inverse Galois challenge as possible. As such, the notorious uninterpretability of modern AI is not a concern for this stage. However, we will encourage contestants to share techniques with each other in order to cover more ground, through ")#link("https://zulip.sair.foundation/#narrow/channel/21-Inverse-Galois-Problem-.28IGP24.29/topic/Welcome.20to.20IGP24/with/2411")[#text("the Zulip channel for this challenge")]#text(".")

#text("This first stage of the competition will close on August 15. After this, we will launch a second stage (with details to be determined) to focus on some set of candidate Galois groups that could not be resolved by the first stage. Here we envisage a more collaborative, conceptual, and human-driven effort in which the role of AI tools may be more secondary, and with more of a focus on creating mathematically interesting results rather than simply trying to saturate a given benchmark. Stay tuned for more details!")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/#comment-693101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2026")])]

#text("The statement claiming that the splitting field of a polynomial of degree n is of degree n over the rationals is inaccurate, for example x⁴+2 is of degree 8")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12b13d2b75645d49f337570dabbaf8eccae0c236009f6264fc76066f0c85a493-3ee28b940cff728bf5ecc239613ffb28efea4fff8a8583145793888a9fd7d11d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse Galois challenge | Persiflage")]], [#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/#comment-693146")[#strong[#text("The inverse Galois challenge | Persiflage")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2026")])]

#text("[…] learnt a few days ago about the following AI challenge: find polynomials with Galois group (G) for each of the transitive subgroups of (S_{24}), with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bec7d73c838f5b3fa23fc134f88b1366784e10b57788f084b1ab7961cb699278-11bb865a81476800179b77f9c0c0e018db1176676b514a7f839b4b5202520a08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of galoisrepresentations")]], [#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/#comment-693147")[#strong[#text("galoisrepresentations")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2026")])]

#text("This is just a mild grumble that it would be much more natural to ask for pairs ")#mi("(G,c)")#text(" where ")#mi("G")#text(" is a conjugacy class of transitive subgroup of ")#mi("S_{24}")#text(" and where ")#mi("c")#text(" is a conjugacy class of involutions. Currently one is forgetting ")#mi("c")#text(" and just remembering ")#mi("r")#text(", the number of fixed points of ")#mi("c")#text(" in the tautological action. Choosing ")#mi("c")#text(" is much more natural and it isn’t determined by ")#mi("r")#text("; a simple example is ")#mi("G=S_4")#text(" which acts transitively on ")#tao-math("24=\\left|G\\right|", block: false)#text(" points, but ")#mi("G")#text(" has two non-trivial conjugacy classes of order ")#mi("2")#text(" elements, both of which have no fixed points. Now maybe conjugacy classes are somewhat painful to coherently and consistently name, but still…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/#comment-693152")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2026")])]

#text("A fair point. Our organizing committee had some debate as to how exactly to formulate the challenge, but in general we erred on the side of having a challenge that was easy to state, even to participants with only an undergraduate exposure to algebra and number theory, in order to maximize the participant pool for the first stage. (Also it is easier to generate some eye-candy visualizations with this two-dimensional completion grid, such as the coverage graphic at ")#link("https://competition.sair.foundation/competitions/igp24/discoveries")[#text("https://competition.sair.foundation/competitions/igp24/discoveries")]#text(" .) I would imagine though that if the competition produced enough polynomial construction methods to cover almost all of the ")#mi("(t,r)")#text(" signatures, then it they should also be adaptable to cover almost all of of the conjugacy classses as well, so I think the degree 24 (t,r) challenge serves as a reasonable proxy for the more implicit goal of developing efficient construction strategies for the inverse Galois problem.")

#text("In any event, we have the flexibility to add these sorts of finer details to later stages of the competition, or to propose a completely separate competition to build some other mathematical data set of interest. If there is a data set that you think would be interesting to acquire, and for which one could plausibly get a large portion of it filled out through a competition of this type, drop me a line and we might be able to work it into a later competition.")

#text("p.s. in your blog post you wondered as to why we had such a complex scoring function. It is designed to try to reveal precisely the question you discuss in the blog post, namely which types of signatures are hard to solve for, and to incentivize contestants to work to locate such hard signatures rather than only pick up low-hanging fruit (the point value of which will rapidly dilute as more contestants figure out how to acquire them). I agree that in general the solvable cases should be easier than the non-solvable ones, but there may be some surprises even amongst the solvable class, which we hope this stage of the competition will uncover through a sort of ‘invisible hand’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/#comment-693177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2026")])]

#text("You say it has been hard to find an irred poly with Galois Group M_23. Is it possible that there isn’t one (which would also be hard to prove)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f8b7224bf66cc6a43c55125319dcb2a6ebe87c596364e0e68c19dbdd26a5082-279c0f1f91664e6ea3255e450952ee500d1df7cd936254900a1be63360a430c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CKS")]], [#link("https://terrytao.wordpress.com/2026/06/16/third-sair-competition-inverse-galois-challenge/#comment-693213")[#strong[#text("CKS")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2026")])]

#text("Your cubic example belongs to a well known family of Shanks’s simplest cyclic cubic ")#mi("x^3-a x^2-(a+3)x-1=0")#text(" for ")#mi("a=0")#text(" except you flip with ")#mi("z=-x")#text(". It is better to view the invariance ")#mi("\\alpha^2-2")#text(" as a fractional linear transforms ")#mi("\\rho(\\alpha)=1-1/\\alpha=\\alpha^2-2")#text(" which is the Galois generator of order 3 in ")#mi("PSL(2, \\mathbb{Z})")#text(". One can verify the invariance by checking ")#mi("f(x)=x+\\rho(x)+\\rho^2(x)=\\frac{x^3-3x^3+1}{x^2-x}.")

#text("There is a similar construction for the simplest quadratic,cubic, quartic and sextic because the only finite subgroup of ")#mi("PSL(2,\\mathbb{Z})")#text(" has order 1,2,3,4,6.")
]
