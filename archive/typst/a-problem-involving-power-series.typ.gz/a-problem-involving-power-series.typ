// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/
// Converted to Typst by tao2typ: "2026-10-14T15:19:48.431862+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A problem involving power series", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A problem involving power series")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/")[#text("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("My colleague ")#link("http://www.math.ucla.edu/~tml/")[#text("Tom Liggett")]#text(" recently posed to me the following problem about power series in one real variable ")#mi("{x}")#text(". Observe that the power series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty (-1)^n\\frac{x^n}{n!}")]]

#text("has very rapidly decaying coefficients (of order ")#mi("{O(1/n!)}")#text("), leading to an infinite radius of convergence; also, as the series converges to ")#mi("{e^{-x}}")#text(", the series decays very rapidly as ")#mi("{x}")#text(" approaches ")#mi("{+\\infty}")#text(". The problem is whether this is essentially the only example of this type. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Let ")#mi("{a_0, a_1, \\dots}")#text(" be a bounded sequence of real numbers, and suppose that the power series")

#align(center)[#tao-fit-display[#mitex("f(x) := \\sum_{n=0}^\\infty a_n\\frac{x^n}{n!}")]]

#text("(which has an infinite radius of convergence) decays like ")#mi("{O(e^{-x})}")#text(" as ")#mi("{x \\rightarrow +\\infty}")#text(", in the sense that the function ")#mi("{e^x f(x)}")#text(" remains bounded as ")#mi("{x \\rightarrow +\\infty}")#text(". Must the sequence ")#mi("{a_n}")#text(" be of the form ")#mi("{a_n = C (-1)^n}")#text(" for some constant ")#mi("{C}")#text("?")
]

#text("As it turns out, the problem has a very nice solution using complex analysis methods, which by coincidence I happen to be teaching right now. I am therefore posing as a challenge to my complex analysis students and to other readers of this blog to answer the above problem by complex methods; feel free to post solutions in the comments below (and in particular, if you don’t want to be spoiled, you should probably refrain from reading the comments). In fact, the ")#emph[#text("only")]#text(" way I know how to solve this problem currently is by complex methods; I would be interested in seeing a purely real-variable solution that is not simply a thinly disguised version of a complex-variable argument.")

#text("(To be fair to my students, the complex variable argument does require one additional tool that is not directly covered in my notes. That tool can be found ")#link("https://en.wikipedia.org/wiki/Laplace_transform")[#text("here")]#text(".)")

#heading(level: 1)[#text("Comments (69)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/925f642f2c1238c3efe58f6b61c24a38f48b0ef5a630059641a7b92a50bca9e6-638d248b16f685bdacf3adbabebb322018c98988ee3be80b5c56ee5162296e71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I think the answer is of course not, just consider the sine or cosine, so some coefficients are 0s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("e^x *sin x is not bounded..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/925f642f2c1238c3efe58f6b61c24a38f48b0ef5a630059641a7b92a50bca9e6-638d248b16f685bdacf3adbabebb322018c98988ee3be80b5c56ee5162296e71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Sorry, misunderstood.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88bee9691aa68f1652268b36f1cfcc8a229c5dd0b1cb692b8b039c3ba1d937c-02ea29f10d32f4a25fc4bb15fc9ec8f5d88a9c41ccdf06aad28395fbb380da12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473423")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Could not a_n be of the form C*(-alpha)^n and still satisfy the conditions described in the problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88bee9691aa68f1652268b36f1cfcc8a229c5dd0b1cb692b8b039c3ba1d937c-02ea29f10d32f4a25fc4bb15fc9ec8f5d88a9c41ccdf06aad28395fbb380da12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473424")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Of coursem 0 < alpha <=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Then the decay as x tends to infinity won’t be fast enough, since it would give f(x)=exp(-alpha*x) with alpha in (0,1)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88bee9691aa68f1652268b36f1cfcc8a229c5dd0b1cb692b8b039c3ba1d937c-02ea29f10d32f4a25fc4bb15fc9ec8f5d88a9c41ccdf06aad28395fbb380da12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473426")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Thanks that makes sense. So we need a function that balances out (or nulls out) exp(x) but whose Taylor coefficients multplied by n! are bounded. I am not a mathematician, just like looking at Terry’s output, sort of like a visitor to an art gallery.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88bee9691aa68f1652268b36f1cfcc8a229c5dd0b1cb692b8b039c3ba1d937c-02ea29f10d32f4a25fc4bb15fc9ec8f5d88a9c41ccdf06aad28395fbb380da12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473430")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I suppose we could add any polynomial (finite degree) to the first series in the post and it would still be kosher. This is probably what Terry means by *essentially* the only example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88bee9691aa68f1652268b36f1cfcc8a229c5dd0b1cb692b8b039c3ba1d937c-02ea29f10d32f4a25fc4bb15fc9ec8f5d88a9c41ccdf06aad28395fbb380da12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473431")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Wish I could retract this. I will stop posting. Sigh.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29804d28256066e287f811d2afb22f60e845ac1e4fb54ccf43553bdb0db12e1b-8b2027e734a115febe841d794ecab85f21383098b8be212b8c413f7417e4f94b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chenyang Yu")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473427")[#strong[#text("Chenyang Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I will give an outline of my thoughts. First observe that this series expansion is very similar to that of the definition of Bernoulli numbers, and in that definition the series equals x/(e^x-1). In fact, we can assume they are equal, and try to prove that for n is odd, an = 0. Then the terms left are the even terms, which coincide with Bernoulli numbers. I have some ideas about it and I am doing detailed proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1106b299d6f910a297975a1731bbfb158ab9a1aba680c8d1fef20d04ebf59d8d-0328469d07971ad92ed92ef84d3a2b76f9faa959c35a2240956ef45db9b2204e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473428")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("what if we take ")#mi("f(x)=e^{-2x}")#text(" i.e. ")#mi("a_n= 2^{n} (-1)^{n}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473434")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Then the ")#mi("a_n")#text(" aren’t bounded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1106b299d6f910a297975a1731bbfb158ab9a1aba680c8d1fef20d04ebf59d8d-0328469d07971ad92ed92ef84d3a2b76f9faa959c35a2240956ef45db9b2204e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473436")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Oh, yes, I missed the boundedness hypothesis. Sorry, my bad. Thank you Lior.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc45c5bfbc8d677e73b8c0a8ed3f9ab3d5d4a1385cecb364f810414cb81198e8-d629d9719fcb4b28c0512cfdb61f75ea75b9f41da39859ee7335cf6b91f5bfe1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Can't Sleep... Why am I doing math to sleep!?!")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473445")[#strong[#text("Can't Sleep... Why am I doing math to sleep!?!")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("2^-x? E^-xlog2 should result in a_n = 1*(log2)^n.")#linebreak()#text(" Or does that violate the big O bound? Nope, Les mental hospital rules hold.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4300e5b550737429557ca00768faf35e98a085eb54abf4be3af73e583572fd4e-1760213c8eeabbb7fc101acc5f56cbe47e6090c4aac2bcb88962744fda3713fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473448")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("If we use complex analysis methods, it is then natural to consider complex coefficients.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473449")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Take ")#mi("a_n = \\frac{(-1)^n}{n!}")#text(". It satisfies ")#mi("f = O(e^{-x})")#text(" (compare two consecutive terms of the powers series ")#mi("e^{-x]}")#text(", with the consecutive terms in the power series of ")#mi("f(x)")#text("). This should be fine since both series are easy to show to be absolutely. The radius of converge is all the reals by the ratio test.")

#text("I don’t think this argument uses anything trickier that undergrad calc, so I’, probably wrong.")

#emph[#text("[")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n!} x^n")#text(" is alternating in sign, but the magnitudes are not monotone decreasing, so one cannot easily perform a comparison test. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473473")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("I’m sorry, I was referring to ")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n!n!}x^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473503")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Would some please explain to me why my reasoning is spurious?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("The series ")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n! n!} x^n = J_0(2 \\sqrt{x})")#text(" is not dominated by ")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n!} x^n = e^{-x}")#text(", due to the non-monotone nature of the magnitudes of the terms in the alternating series (so their consecutive differences can fluctuate in sign). See for instance ")#link("https://www.wolframalpha.com/input/?i=plot+(sum+(-1)%5En+*x%5En+%2F+(n!*n!)+from+n%3D0+to+infinity)+and+exp(-x)+from+x%3D0+to+x%3D10")[#text("this Wolfram Alpha plot")]#text(". (From the asymptotics of Bessel functions, your power series in fact decays like ")#mi("x^{-1/4}")#text(" rather than ")#mi("e^{-x}")#text(".)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473535")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("Thank you. The fools we (I) make ourselves when not considering asymptotic analysis.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473454")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Terry Tao’s hint about the Laplace transform was indeed all that was needed. :-) A “complex” solution to this nice problem can be found at ")#link("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")[#text("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")]#text(" . (Sorry, it was too hard for me to use the online latex tool.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("It seems that your proof still applies for the more general case of polynomial growth of the coefficients ")#mi("a_n")#text(" with ")#mi("n")#text(" (i.e. ")#mi("a_n = O(n^p)")#text(" for any fixed ")#mi("p > 0")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473597")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("This is a good point. Indeed, it seems easy to extend the proof to cover the more general case of polynomial growth of the ")#mi("a_n")#text("‘s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("In addition to the polynomial growth of the ")#mi("a_n")#text("‘s, it seems that the boundedness restriction of ")#mi("e^x f(x)")#text(" can be relaxed to ")#mi("o(x)")#text(" as ")#mi("x \\to +\\infty")#text(" (because in your proof it implies that ")#mi("(u+1)g(u) = o(1)")#text(" as ")#mi("u+1 \\to 0+")#text(" – which is sufficient to rule out the possibility of a pole singularity of ")#mi("g")#text(" at ")#mi("-1")#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/966c76843f5a76e1331d3a1ab5030b33a2c5ffeda1484fa6cde32f7e1b076c4c-a4f1f23950f5c2ead0012d6a697473941f04b2e23d83941de1b097ad9eb16507.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marccof")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-497113")[#strong[#text("marccof")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("Hi, do you still have your proof somewhere ? The dropbox link is dead and I would be interested in seeing the solution to this question.")#linebreak()#text(" Thanks !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d0787f36ff8adaaae2bf792d89bbd3946b1e7047e133f9a57e68c5c66436b1b-3457e7638e41a7fc17ccffbbb49839d30462270a5143f6b714c8535ead43712f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-497115")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("The Dropbox link is no longer valid. The SelectedWorks link ")#link("https://works.bepress.com/iosif-pinelis/14/")[#text("https://works.bepress.com/iosif-pinelis/14/")]#text(" should work and be of more permanent nature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/966c76843f5a76e1331d3a1ab5030b33a2c5ffeda1484fa6cde32f7e1b076c4c-a4f1f23950f5c2ead0012d6a697473941f04b2e23d83941de1b097ad9eb16507.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marccof")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-497260")[#strong[#text("marccof")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2018")])]

#text("Thanks you !")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473460")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("I have added a remark and a conjecture in the file at that link, ")#link("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")[#text("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ac4547c5a9fdd0cee13bafee92668c2f41a854f3c24cea28ce63a5b89b27f70-1f4b6421871fa588a9252289058ef44d2d865d154a591ad02d4fed4f8db86fa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("isn’t exp(-1/2*x) a counterexample to your conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ac4547c5a9fdd0cee13bafee92668c2f41a854f3c24cea28ce63a5b89b27f70-1f4b6421871fa588a9252289058ef44d2d865d154a591ad02d4fed4f8db86fa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("I mean its coefficients, a_n = (-1)^n*(1/2)^n")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473467")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#mi("\\exp(-x/2)")#text(" does not decay as fast as ")#mi("\\exp(-x)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473471")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Thank you. I have removed that conjecture.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473470")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Iosif: How do you show that the singularity at ")#mi("-1")#text(" is a pole? It’s true that the integral ")#mi("\\int_0^\\infty e^{-sx}f(x)dx")#text(" is bounded above by ")#mi("\\frac{1}{1+\\Re(s)}")#text(" in the domain ")#mi("\\Re(s)>-1")#text(" — but why is that enough to show that the singularity is a pole? Perhaps for ")#mi("s")#text(" tending to ")#mi("-1")#text(" from the other side the growth is faster?")

#text("For example, the function ")#mi("\\exp(-1/z)")#text(" has an essential singularity at zero but is nevertheless bounded on the half-plane ")#mi("\\Re(z)>0")#text(".")

#text("I’ve been stuck on this point since Terry published the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473484")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Thank you Lior for this comment. I had indeed overlooked this point. Now I have added a lemma in the file at ")#link("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")[#text("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")]#text(" that shows that $-1$ is indeed a pole of $g$. The proof of the lemma is indeed not quite trivial, and I hope I didn’t make a major error there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("It seems that your lemma shows that ")#mi("-1")#text(" is not an essential singularity of ")#mi("g")#text(". The fact that ")#mi("-1")#text(" is a removable singularity then follows from your earlier result that ")#mi("g(u) = O(1)")#text(" on the half plane ")#mi("\\Re (u) > -1")#text(" (thereby avoiding the possibility of being a pole.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473488")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Anonymous: This is mainly so, except that I only showed that ")#mi("g(u)=O(1)")#text(" for ")#mi("u>-1")#text(", but that is still enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("In fact, to exclude the possibility of a pole of ")#mi("g")#text(" at ")#mi("-1")#text(", it is sufficient to show only that ")#mi("g")#text(" is bounded on a sequence converging to ")#mi("-1")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473468")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("It’s not hard to show the Laplace transform continues to a function on the puncture place ")#mi("\\mathbb{C}\\setminus\\{-1\\}")#text(", with good enough decay to shift contours and invert the transform. If the singularity were a pole, the function would be of the form ")#mi("P(x)\\exp(-x)")#text(" where P is a polynomial, and the boundedness shows that ")#mi("P")#text(" is constant. How do you show the singularity is a pole?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("It is sufficient to show that this singularity is isolated and bounded in some neighborhood to be removable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Is it possible that this problem is a special case of a more general principle:")#linebreak()#text(" “A nontrivial entire function and its Taylor coefficients can’t both(!) decay to zero arbitrarily fast”? More precisely, let ")#mi("f(z) = \\sum_n a_n z^n")#text(" be a nontrivial entire function, and denote ")#tao-math("m_f(r) := min_{\\left|z\\right| = r} \\left|f(z)\\right|", block: false)#text(" for each ")#mi("r \\geq 0")#text(". Then if ")#tao-math("\\left|a_n\\right| \\leq b_n", block: false)#text(" where ")#mi("b_n")#text(" is a given sequence decaying to zero “sufficiently fast”, then there is a function ")#mi("g(r)")#text(" defined for ")#mi("r \\geq 0")#text(" and depending only on the sequence ")#mi("b_n")#text(" such that ")#mi("m_f(r)")#text(" is not decaying to zero faster than ")#mi("g(r)")#text(".")#linebreak()#text(" Since the Taylor coefficients of an entire function are its Fourier coefficients on the unit circle, they can be viewed (in some sense) as its “spectral coefficients” – so this principle for the case of entire functions is similar to the case of functions in ")#mi("L^1(\\mathbb R)")#text(" which can’t decay both(!) with their Fourier transform (playing the role of “spectral coefficients”) faster then Gaussian decay. So in a sense, this problem may be interpreted as a special case of some “uncertainty principle” for entire functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473494")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Let ")#mi("\\mathbf{a}")#text(" be a random variable and ")#mi("\\mathbf{x}")#text(" be Poisson distributed with mean $x$. The expectation is ")#mi("\\mathbb{E}[\\mathbf{a}] = e^{-x} \\sum a_n \\frac{x^n}{n!}")#text(". The Poisson distribution as with mean ")#mi("x")#text(" as ")#mi("x \\to \\infty")#text(" has that lump moving off to infinity. And ")#mi("\\frac{x^n}{n!}")#text(" should concentrate around ")#mi("n = x")#text(". That’s of course pretty bogus. But that’s what I’ve been thinking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1419cac6587b5d967a1035fa0fe326641b39fc19b3487d98a2998516c5ca0857-0fc7e1500e789e4e4aa283a630b51fe540f7e8c128c4cedb4c73a84c388aa373.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Av")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473502")[#strong[#text("Av")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Isn’t it just implied from Liouville’s theorem for g(x) = exp(x) * f(x) which is limited and analytical => constant")#linebreak()#text(" => 0 = g'(x) = (exp(x) * f(x))’ = exp(x) * (f(x) + f'(x))")#linebreak()#text(" => a_n + a_{n+1} = 0")#linebreak()#text(" => QED")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Unfortunately, it is only given that ")#mi("g(x)")#text(" remains bounded as ")#mi("x \\to +\\infty")#text(" (but no information given on its possible behavior as ")#mi("x\\to -\\infty")#text(" or for complex valued ")#mi("x")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a319deac826dc77af5ebfa93f1d17a55e61f1de6394218b3b59d71ce0d7324c1-ab55e8956ac0f8ef729453eee9dfb80caba86bdadcdbfc55d6a6e3cbcd9d986f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("Since |f(z)| <= M e^(|z|), where M is the guaranteed bound for the sequence a_n, it follows that |g(z)| <= |e^z M e^(-z)|= M when z is real and negative. That shows g is bounded on the real line at least.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("The example ")#mi("g(z) : = \\exp(-z^{2 n})")#text(" shows that a non-constant entire function can be bounded (with faster than exponential decay) on arbitrarily many straight lines (on which ")#mi("z^n")#text(" is real) in the complex plane.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a319deac826dc77af5ebfa93f1d17a55e61f1de6394218b3b59d71ce0d7324c1-ab55e8956ac0f8ef729453eee9dfb80caba86bdadcdbfc55d6a6e3cbcd9d986f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("That’s true, but the sequence a_n corresponding to f(z)=exp^(-z)exp(-z^(2m)) is not bounded as we are given here except for m=0.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5547dfd368db158d49cd9f5cc3b2da1fe4dcc7b4fbed19eaeedf995fa2040f1-ea00785529183c0a262acfd421dc114c68224ec490b8a44535089b2ac91f024d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Percival")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473508")[#strong[#text("Colin Percival")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("It’s almost 2AM so I’m not able to flesh out the details right now, but I have a feeling that there’s an argument based on writing f(x) as a linear combination of exp(-n x). Providing such a linear combination exists, the answer falls right out, of course.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("In order to show uniqueness of such linear combination, it seems necessary to find an orthogonal system of polynomials of ")#mi("e^{-x}")#text(" on ")#mi("[0, \\infty)")#text(" with respect to some weight function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473579")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("Colin: that’s exactly what the Laplace transform does, except that the decomposition has a continuous rather than discrete parametrization because the domain is non-compact.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17597d05713cd71a7522ed39ec67383acbfb1a88dfdace940622e3e7140f454f-6c7c0223ede099834ceefbb8dc6dfa81363abae9000d9ca435768533e975e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rsj")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473512")[#strong[#text("rsj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("It’s been 20 years since I took a complex analysis class, but IIRC if e^x*f(x) is an entire bounded analytic function on the complex plane it must be constant. e^x f(x) = C. Then f(x) = Ce^(-x)")

#text("To show that an entire bounded analytic function must be constant, look at the expression of the n’th derivative via the cauchy integral formula and show that they are all zero by taking large circular paths in the integral. The integral will have a radius term to a power in the denominator which is unbounded and the numerator will be bounded by the function bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473514")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("See the above comment of Av and its reply.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("This problem seems to be closely related to the theory of Quasi-analytic classes and the Denjoy-Carleman theorem (see e.g. Chapter 19 in Rudin’s book “Real and complex analysis”, 1987).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57fdcac65659c283ce97e98515001264d85e95e018a7eaa81af3cbbca7f43d1d-66981614b3f42f47fccedc8296e4bbf8717816503ff0f0852b0d0cf870b5ac27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elianto84")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473533")[#strong[#text("elianto84")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("Is Ramanujan master theorem (")#link("https://en.wikipedia.org/wiki/Ramanujan%27s_master_theorem")[#text("https://en.wikipedia.org/wiki/Ramanujan%27s_master_theorem")]#text(") considered a real technique? ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sergei")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473641")[#strong[#text("sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("Dear Terence Tao! Very much glad,what you draw attention on me! Big part of time expensed on translation from English into Russian and inside out,and retrieval of key-words for reflection(train of thought). In ours positions is many similarity points(fulcrums,points of intersection). Now I assured in,what not barely so,not vain be stay to have nothing to do on first floor of Erdesh tower twenty years.(1) Through Cauchy’s theorem-that through channel,connect three partitions of science: mathematic,theoretical physics,physics of elementarys particles. On another ending of through channel is such turn of Vica-place of return at zero’s of Riman dzeta- function.Confirmation-limit of Shvinger.(2) Necessary to prepare section[a,b] at four-impulse integration over widening:[a,b]=>max[xj-x(j-1)]=>[t,x,y,z] I wait reply. Sergei. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ddfcfd55b373b787f98129fce6c989d0acffb642524bfcf96152343f4e183fe-7ec33016a350048460091b541f6ab356e4f03140743956b790447f8985f853a7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473693")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Here is my rough idea: Let ")#mi("V")#text(" be the space entire functions such that the sequence ")#mi("(f^{(n)}(0) : n \\geq 0)")#text(" satisfies the given condition. Also we define")

#tao-math("\\displaystyle \\left\\| f \\right\\| = \\max\\{ \\sup_{n\\geq1} \\left|f^{(n)}(0)\\right|, \\sup_{x \\geq 0} \\left|e^x f (x)\\right| \\}.", block: false)

#text("It is not hard to check that this is indeed a norm with respect to which ")#mi("V")#text(" is a Banach space. Moreover, using the diagonalization argument, it is not hard to check that the unit ball of ")#mi("V")#text(" is compact. So ")#mi("V")#text(" is finite dimensional. Next, we consider the linear map ")#mi("I")#text(" on ")#mi("V")#text(" defined by")

#mi("\\displaystyle I(f) = x \\mapsto - \\int_{x}^{\\infty} f(t) \\, dt.")

#text("It is easy to check that ")#mi("I")#text(" is an injective linear operator on ")#mi("V")#text(". Thus ")#mi("I")#text(" is an isomorphism. The most important implication of this observation is that if ")#mi("f \\in V")#text(" then ")#mi("f^{\\prime} \\in V")#text(", since ")#mi("f = I(g)")#text(" for some and hence ")#mi("f^{\\prime} = g \\in V")#text(". Now since ")#mi("V")#text(" is finite dimensional, there exist ")#mi("n")#text(" and ")#mi("c_0, \\cdots, c_n \\in \\Bbb{R}")#text(" such that")

#mi("\\displaystyle \\sum_{k=0}^{n} c_k f^{(k)} = 0.")

#text("But we know how to solve this differential equation, and the only possible choice is ")#mi("f(x) = c e^{-x}")#text(" for some ")#mi("c \\in \\Bbb{R}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f197b3292eb953a4059121cf4c4a55b6a799486fad2d3fde8f80280ade00356-8f4d57ef0126a674002d52787b9bd546568c3214b590e86ecc6f7fd1df5d9bfb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473694")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Oops, ignore this. My claim on compactness of the unit ball was too bold.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473695")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Your idea seems interesting. (You don’t need to check that ")#mi("V")#text(" is a Banach space; that is, you don’t need to check that ")#mi("V")#text(" is complete.) However, I don’t see how you can prove the compactness by the diagonalization argument alone — this would look similar to trying to prove that the unit ball ")#mi("\\ell^1")#text(" is compact (which is of course false.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ddfcfd55b373b787f98129fce6c989d0acffb642524bfcf96152343f4e183fe-7ec33016a350048460091b541f6ab356e4f03140743956b790447f8985f853a7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473699")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Thank you for pointing out. I definitely agree with you; in fact, I realized my fault right after I posted my idea. I have a faint impression that this may be salvaged by invoking some heavy machinery in functional analysis, though I am not sure at this point. I should take some caffeine and see if there is a way this approach can be fixed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77cd0da86364a9228df54bb8479a401ab5e29bae4bccd6df39e9ccd786041138-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473702")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("It seems that in the proof of the compactness you would have to engage the boundedness of ")#tao-math("e^x\\left|f(x)\\right|", block: false)#text(". But how to do that without complex analysis? The complex analysis argument (the only one I know) is pretty involved and varied. So, I think it would be very surprising and educational if one can do here without complex analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ddfcfd55b373b787f98129fce6c989d0acffb642524bfcf96152343f4e183fe-7ec33016a350048460091b541f6ab356e4f03140743956b790447f8985f853a7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473703")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("I agree with you. Now I am now more prone to think that complex analysis is inevitable, thinking that proving ")#mi("\\dim V < \\infty")#text(" is essentially equivalent to proving that the Laplace transform ")#mi("\\mathcal{L}f(s)")#text(" has pole at ")#mi("s = -1")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/550cbecedab776be7ae0b2067f7aa3a82a25947ce03137dc87f41edd7648a6ea-c4af1a26343beab6cf6e081268dd8a0233f6fb60c7e9a4619223e7d2a613f760.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paolo Bonzini")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-473750")[#strong[#text("Paolo Bonzini")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2016")])]

#text("Functions like tanh x or 1/cosh x would satisfy the property for real x. Does that rule out a solution that doesn’t use complex analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4861aca90850daffd577a2fd72c12992d59403c89bd1627e14cd60ae7589d0dd-74710127a4b4f2f45dffabeb283d88aa99ef3a0d147ede773e6d4fc233e56789.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iker Martinez")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-513808")[#strong[#text("Iker Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2019")])]

#text("I thought a purely real variable solution.")#linebreak()#text(" We have that ")#mi("e^{x}")#text(" and ")#mi("f(x)")#text(" are both analytic, so their product ")#mi("\\phi(x)=e^{x}\\cdot f(x)")#text(" is, therefore ")#mi("\\phi(x)=\\overset{\\infty}{\\underset{n=0}{\\sum}}c_n x^n")#text(", where ")#mi("c_n= a_0\\cdot\\frac{1}{(n-1)!}+...+\\frac{a_i}{i!}\\cdot\\frac{1}{(n-i)!}+...+\\frac{a_n}{n!}")#text(".")

#text("Since ")#mi("\\underset{x\\to \\infty}{\\lim}\\phi(x)=\\underset{x\\to \\infty}{\\lim}\\dfrac{f(x)}{e^{-x}}=C")#text(", for every ")#mi("\\epsilon>0")#text(" there are ")#mi("R>0")#text(" and ")#mi("N\\in\\mathbb{N}")#text(" such that:")

#tao-math("\\displaystyle \\Bigg{\\left|\\overset{k}{\\underset{n=0}{\\sum}}c_n x^n - C \\right|}\\leq \\Bigg{\\left|\\overset{k}{\\underset{n=0}{\\sum}}c_n x^n - \\overset{\\infty}{\\underset{n=0}{\\sum}}c_n x^n \\right|}+ \\Bigg{\\left|\\overset{\\infty}{\\underset{n=0}{\\sum}}c_n x^n - C \\right|}\\leq \\dfrac{\\epsilon}{2}+\\dfrac{\\epsilon}{2}=\\epsilon.", block: false)

#text("for all ")#mi("k> N")#text(" and all ")#mi("x> R")#text(". Thus,")

#mi("\\displaystyle C- \\epsilon < \\overset{k}{\\underset{n=0}{\\sum}}c_n x^n  N, x > R")

#text("this implies that,")

#mi("\\displaystyle 0=\\underset{x\\to \\infty}{\\lim}\\dfrac{C- \\epsilon}{x^k} < c_k  N.")

#text("From this we deduce that ")#mi("\\phi(x)=\\overset{N}{\\underset{n=0}{\\sum}}c_n x^n")#text(" and because ")#mi("\\underset{x\\to \\infty}{\\lim}\\phi(x)=C")#text(", ")#mi("\\phi(x)")#text(" must be constant ")#mi("C.")#text(" Hence, ")#mi("f(x)=Ce^{-x}")#text(", where the equations ")#mi("a_n=C(-1)^n")#text(" follows.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4861aca90850daffd577a2fd72c12992d59403c89bd1627e14cd60ae7589d0dd-74710127a4b4f2f45dffabeb283d88aa99ef3a0d147ede773e6d4fc233e56789.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iker Martinez")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-513810")[#strong[#text("Iker Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2019")])]

#text("I dont know how to write math here, so I posted my solution here, ")#link("https://math.stackexchange.com/questions/3147563/a-real-variable-solution-of-a-problem-posted-on-terry-taos-blog/3147565#3147565")[#text("https://math.stackexchange.com/questions/3147563/a-real-variable-solution-of-a-problem-posted-on-terry-taos-blog/3147565#3147565")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3e0ebdd7cf627b58a2376830848bb487fb807d93eedfddcc53e7d9fc769e775-0d391ae6293e430bf6f2ac3070522cd450340c08093dbc77260b1f81ccce0272.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amsmath")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-515752")[#strong[#text("amsmath")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("There are three flaws in this “proof”. First, your coefficients seem wrong to me. Second, the limit of ")#mi("\\phi")#text(" at ")#mi("\\infty")#text(" might not exist. Third, you assume that the series converges uniformly on ")#mi("(R,\\infty)")#text(", which you cannot do.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-621072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Eugenia Malinnikova has just pointed out to me that the statement of this problem is similar to the Hardy uncertainty principle, and the solution to the problem that had been worked out in the comments is in fact very similar to Hardy’s second proof of that principle in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574130")[#text("his original paper")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-685153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("As an experiment, I have explained the solution to this problem to ChatGPT at ")#link("https://chatgpt.com/share/63c5774a-d58a-47c2-9149-362b05e268b4")[#text("this link")]#text(". Through an interactive discussion, GPT was able to expand out my sketch of a proof into a full LaTeX document, which one can ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/06/laplace.pdf")[#text("find here")]#text(". This experiment was meant to illustrate a recent comment I made in ")#link("https://www.scientificamerican.com/article/ai-will-become-mathematicians-co-pilot/")[#text("this interview")]#text(", envisioning how in the future a mathematician might produce a proof through conversation with a GPT, though ideally the GPT should also be able to provide a running formalization of the proof in a language such as Lean in order to guarantee 100% correctness of the argument (this is the main reason why I think the full workflow that I envision is still a few years away).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-685176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2024")])]

#text("If you use double dollar signs instead of single dollar signs when messaging ChatGPT, your latex will render in your own message.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-689461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2025")])]

#text("Dr Tao, I tried to solve this problem using complex variable argument, but failed. Then I checked the proof in the comment you provided, it turns out that my toolbox does not contain the tool of “Laplace Transform”. I know that not only in complex analyis but also in ODE and PDE, this tool is useful—— I would like to ask: generally speaking, what’s the strategy of using Laplace Transform?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/#comment-689467")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("You may find the answers in ")#link("https://mathoverflow.net/questions/383/motivating-the-laplace-transform-definition")[#text("https://mathoverflow.net/questions/383/motivating-the-laplace-transform-definition")]#text(" and ")#link("https://mathoverflow.net/questions/464191/motivation-and-physical-interpretation-of-the-laplace-transform")[#text("https://mathoverflow.net/questions/464191/motivation-and-physical-interpretation-of-the-laplace-transform")]#text(" to be helpful.")
]
]
