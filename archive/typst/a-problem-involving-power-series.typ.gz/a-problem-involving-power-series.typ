// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/
// Converted to Typst by tao2typ: "2026-10-18T11:28:58.434989+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A problem involving power series", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A problem involving power series")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/")[#text("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("My colleague ")#link("http://www.math.ucla.edu/~tml/")[#text("Tom Liggett")]#text(" recently posed to me the following problem about power series in one real variable ")#mi("{x}")#text(". Observe that the power series")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty (-1)^n\\frac{x^n}{n!}")]]

#text("has very rapidly decaying coefficients (of order ")#mi("{O(1/n!)}")#text("), leading to an infinite radius of convergence; also, as the series converges to ")#mi("{e^{-x}}")#text(", the series decays very rapidly as ")#mi("{x}")#text(" approaches ")#mi("{+\\infty}")#text(". The problem is whether this is essentially the only example of this type. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Let ")#mi("{a_0, a_1, \\dots}")#text(" be a bounded sequence of real numbers, and suppose that the power series")

#align(center)[#tao-fit-display[#mitex("f(x) := \\sum_{n=0}^\\infty a_n\\frac{x^n}{n!}")]]

#text("(which has an infinite radius of convergence) decays like ")#mi("{O(e^{-x})}")#text(" as ")#mi("{x \\rightarrow +\\infty}")#text(", in the sense that the function ")#mi("{e^x f(x)}")#text(" remains bounded as ")#mi("{x \\rightarrow +\\infty}")#text(". Must the sequence ")#mi("{a_n}")#text(" be of the form ")#mi("{a_n = C (-1)^n}")#text(" for some constant ")#mi("{C}")#text("?")
]

#text("As it turns out, the problem has a very nice solution using complex analysis methods, which by coincidence I happen to be teaching right now. I am therefore posing as a challenge to my complex analysis students and to other readers of this blog to answer the above problem by complex methods; feel free to post solutions in the comments below (and in particular, if you don’t want to be spoiled, you should probably refrain from reading the comments). In fact, the ")#emph[#text("only")]#text(" way I know how to solve this problem currently is by complex methods; I would be interested in seeing a purely real-variable solution that is not simply a thinly disguised version of a complex-variable argument.")

#text("(To be fair to my students, the complex variable argument does require one additional tool that is not directly covered in my notes. That tool can be found ")#link("https://en.wikipedia.org/wiki/Laplace_transform")[#text("here")]#text(".)")

#heading(level: 1)[#text("Comments (69)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a04095bf2db488789ede6d0a49ed500bc59730b933bf32e6249ee47d49eca3be-7b9996526102d4b2fc91ca5637719613b1d2c10c6cb71eba03b61113b06eeafb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473421")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I think the answer is of course not, just consider the sine or cosine, so some coefficients are 0s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473482")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("e^x *sin x is not bounded..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a04095bf2db488789ede6d0a49ed500bc59730b933bf32e6249ee47d49eca3be-7b9996526102d4b2fc91ca5637719613b1d2c10c6cb71eba03b61113b06eeafb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473422")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Sorry, misunderstood.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd0e0f9fc41bffd73efde5ffaaa30b5eb4278346c7eb210528a75c16c374c57d-dc327f100fe9591dbdc34210fff09b6f17fca81e608c90281666a9ae582efb7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473423")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Could not a_n be of the form C*(-alpha)^n and still satisfy the conditions described in the problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd0e0f9fc41bffd73efde5ffaaa30b5eb4278346c7eb210528a75c16c374c57d-dc327f100fe9591dbdc34210fff09b6f17fca81e608c90281666a9ae582efb7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473424")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Of coursem 0 < alpha <=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473425")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Then the decay as x tends to infinity won’t be fast enough, since it would give f(x)=exp(-alpha*x) with alpha in (0,1)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd0e0f9fc41bffd73efde5ffaaa30b5eb4278346c7eb210528a75c16c374c57d-dc327f100fe9591dbdc34210fff09b6f17fca81e608c90281666a9ae582efb7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473426")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Thanks that makes sense. So we need a function that balances out (or nulls out) exp(x) but whose Taylor coefficients multplied by n! are bounded. I am not a mathematician, just like looking at Terry’s output, sort of like a visitor to an art gallery.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd0e0f9fc41bffd73efde5ffaaa30b5eb4278346c7eb210528a75c16c374c57d-dc327f100fe9591dbdc34210fff09b6f17fca81e608c90281666a9ae582efb7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473430")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I suppose we could add any polynomial (finite degree) to the first series in the post and it would still be kosher. This is probably what Terry means by *essentially* the only example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd0e0f9fc41bffd73efde5ffaaa30b5eb4278346c7eb210528a75c16c374c57d-dc327f100fe9591dbdc34210fff09b6f17fca81e608c90281666a9ae582efb7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Severin")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473431")[#strong[#text("Steve Severin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Wish I could retract this. I will stop posting. Sigh.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ee72fba983cb117944922bc4c41c5a4d0a2258509c670495748aa7421030ff3-ddef2626be3d804ef39ae0cf7d226c94a4fd3bc8cd636f4c6cedea8c1dbaa6f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chenyang Yu")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473427")[#strong[#text("Chenyang Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I will give an outline of my thoughts. First observe that this series expansion is very similar to that of the definition of Bernoulli numbers, and in that definition the series equals x/(e^x-1). In fact, we can assume they are equal, and try to prove that for n is odd, an = 0. Then the terms left are the even terms, which coincide with Bernoulli numbers. I have some ideas about it and I am doing detailed proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea57123119ef36e8e67af0ef18532e19a8113b1459158a799262125d236aafa3-a494ec8b465b63edd922f22d74f443d66dc0693668abff3fadd0780dee517abd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473428")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("what if we take ")#mi("f(x)=e^{-2x}")#text(" i.e. ")#mi("a_n= 2^{n} (-1)^{n}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473434")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Then the ")#mi("a_n")#text(" aren’t bounded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea57123119ef36e8e67af0ef18532e19a8113b1459158a799262125d236aafa3-a494ec8b465b63edd922f22d74f443d66dc0693668abff3fadd0780dee517abd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473436")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Oh, yes, I missed the boundedness hypothesis. Sorry, my bad. Thank you Lior.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/047e62f3e4952c40e8cbcd987b6e7e9a87a97d9694c9b4cc43ea7078de77059a-98168158b66742f062a0c387b462f2cbd8ef886b975b251019be1dd601d66e6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Can't Sleep... Why am I doing math to sleep!?!")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473445")[#strong[#text("Can't Sleep... Why am I doing math to sleep!?!")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("2^-x? E^-xlog2 should result in a_n = 1*(log2)^n.")#linebreak()#text(" Or does that violate the big O bound? Nope, Les mental hospital rules hold.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f477e1e3a018f45c59f7b8b094a47e525b3f789d23fb67e2d6931a3d8bb21330-e1da703c99d7d16aefd15ad1b6c645eb9ba8ea55775c7f5a6250ef06e781cb74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473448")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("If we use complex analysis methods, it is then natural to consider complex coefficients.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b50c0f134d62ab008a43b371827f4265c2991683c5ce3243dd6ea4f0a2d12683-678386ef175381dbd5828e1f3cabf4bc2287987bdf3010cff379bb7c15f828ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473449")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Take ")#mi("a_n = \\frac{(-1)^n}{n!}")#text(". It satisfies ")#mi("f = O(e^{-x})")#text(" (compare two consecutive terms of the powers series ")#mi("e^{-x]}")#text(", with the consecutive terms in the power series of ")#mi("f(x)")#text("). This should be fine since both series are easy to show to be absolutely. The radius of converge is all the reals by the ratio test.")

#text("I don’t think this argument uses anything trickier that undergrad calc, so I’, probably wrong.")

#emph[#text("[")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n!} x^n")#text(" is alternating in sign, but the magnitudes are not monotone decreasing, so one cannot easily perform a comparison test. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b50c0f134d62ab008a43b371827f4265c2991683c5ce3243dd6ea4f0a2d12683-678386ef175381dbd5828e1f3cabf4bc2287987bdf3010cff379bb7c15f828ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473473")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("I’m sorry, I was referring to ")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n!n!}x^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b50c0f134d62ab008a43b371827f4265c2991683c5ce3243dd6ea4f0a2d12683-678386ef175381dbd5828e1f3cabf4bc2287987bdf3010cff379bb7c15f828ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473503")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Would some please explain to me why my reasoning is spurious?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("The series ")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n! n!} x^n = J_0(2 \\sqrt{x})")#text(" is not dominated by ")#mi("\\sum_{n=0}^\\infty \\frac{(-1)^n}{n!} x^n = e^{-x}")#text(", due to the non-monotone nature of the magnitudes of the terms in the alternating series (so their consecutive differences can fluctuate in sign). See for instance ")#link("https://www.wolframalpha.com/input/?i=plot+(sum+(-1)%5En+*x%5En+%2F+(n!*n!)+from+n%3D0+to+infinity)+and+exp(-x)+from+x%3D0+to+x%3D10")[#text("this Wolfram Alpha plot")]#text(". (From the asymptotics of Bessel functions, your power series in fact decays like ")#mi("x^{-1/4}")#text(" rather than ")#mi("e^{-x}")#text(".)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b50c0f134d62ab008a43b371827f4265c2991683c5ce3243dd6ea4f0a2d12683-678386ef175381dbd5828e1f3cabf4bc2287987bdf3010cff379bb7c15f828ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473535")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("Thank you. The fools we (I) make ourselves when not considering asymptotic analysis.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473454")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Terry Tao’s hint about the Laplace transform was indeed all that was needed. 🙂 A “complex” solution to this nice problem can be found at ")#link("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")[#text("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")]#text(" . (Sorry, it was too hard for me to use the online latex tool.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473559")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("It seems that your proof still applies for the more general case of polynomial growth of the coefficients ")#mi("a_n")#text(" with ")#mi("n")#text(" (i.e. ")#mi("a_n = O(n^p)")#text(" for any fixed ")#mi("p > 0")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473597")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("This is a good point. Indeed, it seems easy to extend the proof to cover the more general case of polynomial growth of the ")#mi("a_n")#text("‘s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473710")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("In addition to the polynomial growth of the ")#mi("a_n")#text("‘s, it seems that the boundedness restriction of ")#mi("e^x f(x)")#text(" can be relaxed to ")#mi("o(x)")#text(" as ")#mi("x \\to +\\infty")#text(" (because in your proof it implies that ")#mi("(u+1)g(u) = o(1)")#text(" as ")#mi("u+1 \\to 0+")#text(" – which is sufficient to rule out the possibility of a pole singularity of ")#mi("g")#text(" at ")#mi("-1")#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a3ce62fa1ae616f7c6829a84e94136c629c33aa0f450f9d83fb291c054e23c3-0f6c1e9eb4162d03a1a853f9b2aeb10220c94f43f287f68dfb7a142a83689d2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marccof")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-497113")[#strong[#text("marccof")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("Hi, do you still have your proof somewhere ? The dropbox link is dead and I would be interested in seeing the solution to this question.")#linebreak()#text(" Thanks !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed973a4022ded4c1be35a4fd97d159483e7a2473cb8e5568cf0c3972b3be5683-6994972e8d5ea87b196fd41c969eeba24c72534d7522db90c0cc5fbc03573b24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-497115")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("The Dropbox link is no longer valid. The SelectedWorks link ")#link("https://works.bepress.com/iosif-pinelis/14/")[#text("https://works.bepress.com/iosif-pinelis/14/")]#text(" should work and be of more permanent nature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a3ce62fa1ae616f7c6829a84e94136c629c33aa0f450f9d83fb291c054e23c3-0f6c1e9eb4162d03a1a853f9b2aeb10220c94f43f287f68dfb7a142a83689d2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marccof")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-497260")[#strong[#text("marccof")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2018")])]

#text("Thanks you !")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473460")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("I have added a remark and a conjecture in the file at that link, ")#link("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")[#text("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ebfa32d5f66543ae11225ec8287b90c47fbed94b47c98189f44fdfe6ef7b70-e5caadd33b67defe3d63aee18cd21382c3a20e007c55b3efc3159d143cba7add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473465")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("isn’t exp(-1/2*x) a counterexample to your conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ebfa32d5f66543ae11225ec8287b90c47fbed94b47c98189f44fdfe6ef7b70-e5caadd33b67defe3d63aee18cd21382c3a20e007c55b3efc3159d143cba7add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473466")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("I mean its coefficients, a_n = (-1)^n*(1/2)^n")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473467")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#mi("\\exp(-x/2)")#text(" does not decay as fast as ")#mi("\\exp(-x)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473471")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Thank you. I have removed that conjecture.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473470")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Iosif: How do you show that the singularity at ")#mi("-1")#text(" is a pole? It’s true that the integral ")#mi("\\int_0^\\infty e^{-sx}f(x)dx")#text(" is bounded above by ")#mi("\\frac{1}{1+\\Re(s)}")#text(" in the domain ")#mi("\\Re(s)>-1")#text(" — but why is that enough to show that the singularity is a pole? Perhaps for ")#mi("s")#text(" tending to ")#mi("-1")#text(" from the other side the growth is faster?")

#text("For example, the function ")#mi("\\exp(-1/z)")#text(" has an essential singularity at zero but is nevertheless bounded on the half-plane ")#mi("\\Re(z)>0")#text(".")

#text("I’ve been stuck on this point since Terry published the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473484")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Thank you Lior for this comment. I had indeed overlooked this point. Now I have added a lemma in the file at ")#link("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")[#text("https://www.dropbox.com/s/vsclr67uwx64oiy/power-series.pdf?dl=0")]#text(" that shows that $-1$ is indeed a pole of $g$. The proof of the lemma is indeed not quite trivial, and I hope I didn’t make a major error there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473486")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("It seems that your lemma shows that ")#mi("-1")#text(" is not an essential singularity of ")#mi("g")#text(". The fact that ")#mi("-1")#text(" is a removable singularity then follows from your earlier result that ")#mi("g(u) = O(1)")#text(" on the half plane ")#mi("\\Re (u) > -1")#text(" (thereby avoiding the possibility of being a pole.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473488")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Anonymous: This is mainly so, except that I only showed that ")#mi("g(u)=O(1)")#text(" for ")#mi("u>-1")#text(", but that is still enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473491")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("In fact, to exclude the possibility of a pole of ")#mi("g")#text(" at ")#mi("-1")#text(", it is sufficient to show only that ")#mi("g")#text(" is bounded on a sequence converging to ")#mi("-1")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473468")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("It’s not hard to show the Laplace transform continues to a function on the puncture place ")#mi("\\mathbb{C}\\setminus\\{-1\\}")#text(", with good enough decay to shift contours and invert the transform. If the singularity were a pole, the function would be of the form ")#mi("P(x)\\exp(-x)")#text(" where P is a polynomial, and the boundedness shows that ")#mi("P")#text(" is constant. How do you show the singularity is a pole?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473478")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("It is sufficient to show that this singularity is isolated and bounded in some neighborhood to be removable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473477")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Is it possible that this problem is a special case of a more general principle:")#linebreak()#text(" “A nontrivial entire function and its Taylor coefficients can’t both(!) decay to zero arbitrarily fast”? More precisely, let ")#mi("f(z) = \\sum_n a_n z^n")#text(" be a nontrivial entire function, and denote ")#tao-math("m_f(r) := min_{\\left|z\\right| = r} \\left|f(z)\\right|", block: false)#text(" for each ")#mi("r \\geq 0")#text(". Then if ")#tao-math("\\left|a_n\\right| \\leq b_n", block: false)#text(" where ")#mi("b_n")#text(" is a given sequence decaying to zero “sufficiently fast”, then there is a function ")#mi("g(r)")#text(" defined for ")#mi("r \\geq 0")#text(" and depending only on the sequence ")#mi("b_n")#text(" such that ")#mi("m_f(r)")#text(" is not decaying to zero faster than ")#mi("g(r)")#text(".")#linebreak()#text(" Since the Taylor coefficients of an entire function are its Fourier coefficients on the unit circle, they can be viewed (in some sense) as its “spectral coefficients” – so this principle for the case of entire functions is similar to the case of functions in ")#mi("L^1(\\mathbb R)")#text(" which can’t decay both(!) with their Fourier transform (playing the role of “spectral coefficients”) faster then Gaussian decay. So in a sense, this problem may be interpreted as a special case of some “uncertainty principle” for entire functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ccf11fb4eefa65d72aa4581c5826416b951ea2473a976ab14fa067534b1d05a0-6afd38ddf05fba05735cf13e96a4d2f0c42a3c7bc49c4326a5bb06d9c1a931f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473494")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Let ")#mi("\\mathbf{a}")#text(" be a random variable and ")#mi("\\mathbf{x}")#text(" be Poisson distributed with mean $x$. The expectation is ")#mi("\\mathbb{E}[\\mathbf{a}] = e^{-x} \\sum a_n \\frac{x^n}{n!}")#text(". The Poisson distribution as with mean ")#mi("x")#text(" as ")#mi("x \\to \\infty")#text(" has that lump moving off to infinity. And ")#mi("\\frac{x^n}{n!}")#text(" should concentrate around ")#mi("n = x")#text(". That’s of course pretty bogus. But that’s what I’ve been thinking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c67b34ca15881a8bb61dcb74df0fd157f1e7238483b7fd473509aea65961a12-5e7e322ebb8afdb87ad0ecf8a2962afd28521b64534a9cffbacf9fe4e1c272de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Av")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473502")[#strong[#text("Av")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Isn’t it just implied from Liouville’s theorem for g(x) = exp(x) * f(x) which is limited and analytical => constant")#linebreak()#text(" => 0 = g'(x) = (exp(x) * f(x))’ = exp(x) * (f(x) + f'(x))")#linebreak()#text(" => a_n + a_{n+1} = 0")#linebreak()#text(" => QED")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473506")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Unfortunately, it is only given that ")#mi("g(x)")#text(" remains bounded as ")#mi("x \\to +\\infty")#text(" (but no information given on its possible behavior as ")#mi("x\\to -\\infty")#text(" or for complex valued ")#mi("x")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d70c726c3ca566021a13fb6e0c353f88a927e1dfc4a67b344595d44fae0fbf8-d2ba6d72f3fb6964e24998cd28ee470ed219b6eb7e0373db02ff8210a2ccfe2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473527")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("Since |f(z)| <= M e^(|z|), where M is the guaranteed bound for the sequence a_n, it follows that |g(z)| <= |e^z M e^(-z)|= M when z is real and negative. That shows g is bounded on the real line at least.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473545")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("The example ")#mi("g(z) : = \\exp(-z^{2 n})")#text(" shows that a non-constant entire function can be bounded (with faster than exponential decay) on arbitrarily many straight lines (on which ")#mi("z^n")#text(" is real) in the complex plane.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d70c726c3ca566021a13fb6e0c353f88a927e1dfc4a67b344595d44fae0fbf8-d2ba6d72f3fb6964e24998cd28ee470ed219b6eb7e0373db02ff8210a2ccfe2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473552")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("That’s true, but the sequence a_n corresponding to f(z)=exp^(-z)exp(-z^(2m)) is not bounded as we are given here except for m=0.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a4a6a2638faad02f353260616e6bc2e40fec9c69c92d4b7bd41b8b6ebae1b7a-9fb8d4d05940d3b2271adc449975e38fe5850e1c482697c8eac7b452479ec413.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Percival")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473508")[#strong[#text("Colin Percival")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("It’s almost 2AM so I’m not able to flesh out the details right now, but I have a feeling that there’s an argument based on writing f(x) as a linear combination of exp(-n x). Providing such a linear combination exists, the answer falls right out, of course.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473511")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("In order to show uniqueness of such linear combination, it seems necessary to find an orthogonal system of polynomials of ")#mi("e^{-x}")#text(" on ")#mi("[0, \\infty)")#text(" with respect to some weight function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473579")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("Colin: that’s exactly what the Laplace transform does, except that the decomposition has a continuous rather than discrete parametrization because the domain is non-compact.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7371f45565337842f821048e36a0ef88b4bf5d7787335836c81c220745c72dfc-19ac831d4a2aa6c05b591c99ede41d992f2c787d675c993c15ae4aa7bfc18970.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rsj")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473512")[#strong[#text("rsj")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("It’s been 20 years since I took a complex analysis class, but IIRC if e^x*f(x) is an entire bounded analytic function on the complex plane it must be constant. e^x f(x) = C. Then f(x) = Ce^(-x)")

#text("To show that an entire bounded analytic function must be constant, look at the expression of the n’th derivative via the cauchy integral formula and show that they are all zero by taking large circular paths in the integral. The integral will have a radius term to a power in the denominator which is unbounded and the numerator will be bounded by the function bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473514")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("See the above comment of Av and its reply.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473515")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("This problem seems to be closely related to the theory of Quasi-analytic classes and the Denjoy-Carleman theorem (see e.g. Chapter 19 in Rudin’s book “Real and complex analysis”, 1987).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f2b9fbe7498e0481da39b04a41766c74fea818c04c12897761f288f0c3d2828-61f440909fc3cc1a623f3cc5e341c1216f864618a2779551ec5d3ccac71a620e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elianto84")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473533")[#strong[#text("elianto84")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("Is Ramanujan master theorem (")#link("https://en.wikipedia.org/wiki/Ramanujan%27s_master_theorem")[#text("https://en.wikipedia.org/wiki/Ramanujan%27s_master_theorem")]#text(") considered a real technique? 😉")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c15abe1c5e784d6155541e5b1383a12c89c2c6d75f32ef3384b1d3c7997d1193-e77e3ee12207e0d91ec3ebc8f935ee8c246f81193257cf83636c4a8ac8927ce0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sergei")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473641")[#strong[#text("sergei")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("Dear Terence Tao! Very much glad,what you draw attention on me! Big part of time expensed on translation from English into Russian and inside out,and retrieval of key-words for reflection(train of thought). In ours positions is many similarity points(fulcrums,points of intersection). Now I assured in,what not barely so,not vain be stay to have nothing to do on first floor of Erdesh tower twenty years.(1) Through Cauchy’s theorem-that through channel,connect three partitions of science: mathematic,theoretical physics,physics of elementarys particles. On another ending of through channel is such turn of Vica-place of return at zero’s of Riman dzeta- function.Confirmation-limit of Shvinger.(2) Necessary to prepare section[a,b] at four-impulse integration over widening:[a,b]=>max[xj-x(j-1)]=>[t,x,y,z] I wait reply. Sergei. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f0c0e51e422b2a835b000f88e8a07b11d5393f822df4fda0944cb621a5ac7b1-ffc16f89d677a2e04340db9879c52042abd75ece1c4a021d2799d080ac662337.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473693")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Here is my rough idea: Let ")#mi("V")#text(" be the space entire functions such that the sequence ")#mi("(f^{(n)}(0) : n \\geq 0)")#text(" satisfies the given condition. Also we define")

#tao-math("\\displaystyle \\left\\| f \\right\\| = \\max\\{ \\sup_{n\\geq1} \\left|f^{(n)}(0)\\right|, \\sup_{x \\geq 0} \\left|e^x f (x)\\right| \\}.", block: false)

#text("It is not hard to check that this is indeed a norm with respect to which ")#mi("V")#text(" is a Banach space. Moreover, using the diagonalization argument, it is not hard to check that the unit ball of ")#mi("V")#text(" is compact. So ")#mi("V")#text(" is finite dimensional. Next, we consider the linear map ")#mi("I")#text(" on ")#mi("V")#text(" defined by")

#mi("\\displaystyle I(f) = x \\mapsto - \\int_{x}^{\\infty} f(t) \\, dt.")

#text("It is easy to check that ")#mi("I")#text(" is an injective linear operator on ")#mi("V")#text(". Thus ")#mi("I")#text(" is an isomorphism. The most important implication of this observation is that if ")#mi("f \\in V")#text(" then ")#mi("f^{\\prime} \\in V")#text(", since ")#mi("f = I(g)")#text(" for some and hence ")#mi("f^{\\prime} = g \\in V")#text(". Now since ")#mi("V")#text(" is finite dimensional, there exist ")#mi("n")#text(" and ")#mi("c_0, \\cdots, c_n \\in \\Bbb{R}")#text(" such that")

#mi("\\displaystyle \\sum_{k=0}^{n} c_k f^{(k)} = 0.")

#text("But we know how to solve this differential equation, and the only possible choice is ")#mi("f(x) = c e^{-x}")#text(" for some ")#mi("c \\in \\Bbb{R}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbe552d2d4094fc28d309834c155b1537f9182fa15e11943fac8a3ef92685759-2c9ba36bf377749ff44c9f7e14fb3f3ecbed966b9308c4cd30e65fd4141a86e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473694")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Oops, ignore this. My claim on compactness of the unit ball was too bold.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473695")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Your idea seems interesting. (You don’t need to check that ")#mi("V")#text(" is a Banach space; that is, you don’t need to check that ")#mi("V")#text(" is complete.) However, I don’t see how you can prove the compactness by the diagonalization argument alone — this would look similar to trying to prove that the unit ball ")#mi("\\ell^1")#text(" is compact (which is of course false.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f0c0e51e422b2a835b000f88e8a07b11d5393f822df4fda0944cb621a5ac7b1-ffc16f89d677a2e04340db9879c52042abd75ece1c4a021d2799d080ac662337.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473699")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Thank you for pointing out. I definitely agree with you; in fact, I realized my fault right after I posted my idea. I have a faint impression that this may be salvaged by invoking some heavy machinery in functional analysis, though I am not sure at this point. I should take some caffeine and see if there is a way this approach can be fixed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da801c9bbf5e62ec987a086cde53ea48c900b6a77db24abc269d8bba8c059e79-ecec179ec80638e4297b086b0ace9eb0c1913cb7359bf298f9e7849ebd3a1aa1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473702")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("It seems that in the proof of the compactness you would have to engage the boundedness of ")#tao-math("e^x\\left|f(x)\\right|", block: false)#text(". But how to do that without complex analysis? The complex analysis argument (the only one I know) is pretty involved and varied. So, I think it would be very surprising and educational if one can do here without complex analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f0c0e51e422b2a835b000f88e8a07b11d5393f822df4fda0944cb621a5ac7b1-ffc16f89d677a2e04340db9879c52042abd75ece1c4a021d2799d080ac662337.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangchul Lee")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473703")[#strong[#text("Sangchul Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("I agree with you. Now I am now more prone to think that complex analysis is inevitable, thinking that proving ")#mi("\\dim V < \\infty")#text(" is essentially equivalent to proving that the Laplace transform ")#mi("\\mathcal{L}f(s)")#text(" has pole at ")#mi("s = -1")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3500c27d820f96bb2b3b8df1c869e36282cf17df5a1fe910c9c0a3b658bdb6df-3aa95419699fb7b3a5d55ee0b3577536ca5c2ece96b97edb396c6f4626473349.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paolo Bonzini")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-473750")[#strong[#text("Paolo Bonzini")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2016")])]

#text("Functions like tanh x or 1/cosh x would satisfy the property for real x. Does that rule out a solution that doesn’t use complex analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6caca35c0ca985a92dca07672fb32e97c8110df01b88be00126ab4cd2029196-aafce5d6e74d4a1bf4b2fc2f321e57847261b40f6ddb8972ce7367b8a55f69a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iker Martinez")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-513808")[#strong[#text("Iker Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2019")])]

#text("I thought a purely real variable solution.")#linebreak()#text(" We have that ")#mi("e^{x}")#text(" and ")#mi("f(x)")#text(" are both analytic, so their product ")#mi("\\phi(x)=e^{x}\\cdot f(x)")#text(" is, therefore ")#mi("\\phi(x)=\\overset{\\infty}{\\underset{n=0}{\\sum}}c_n x^n")#text(", where ")#mi("c_n= a_0\\cdot\\frac{1}{(n-1)!}+...+\\frac{a_i}{i!}\\cdot\\frac{1}{(n-i)!}+...+\\frac{a_n}{n!}")#text(".")

#text("Since ")#mi("\\underset{x\\to \\infty}{\\lim}\\phi(x)=\\underset{x\\to \\infty}{\\lim}\\dfrac{f(x)}{e^{-x}}=C")#text(", for every ")#mi("\\epsilon>0")#text(" there are ")#mi("R>0")#text(" and ")#mi("N\\in\\mathbb{N}")#text(" such that:")

#tao-math("\\displaystyle \\Bigg{\\left|\\overset{k}{\\underset{n=0}{\\sum}}c_n x^n - C \\right|}\\leq \\Bigg{\\left|\\overset{k}{\\underset{n=0}{\\sum}}c_n x^n - \\overset{\\infty}{\\underset{n=0}{\\sum}}c_n x^n \\right|}+ \\Bigg{\\left|\\overset{\\infty}{\\underset{n=0}{\\sum}}c_n x^n - C \\right|}\\leq \\dfrac{\\epsilon}{2}+\\dfrac{\\epsilon}{2}=\\epsilon.", block: false)

#text("for all ")#mi("k> N")#text(" and all ")#mi("x> R")#text(". Thus,")

#mi("\\displaystyle C- \\epsilon < \\overset{k}{\\underset{n=0}{\\sum}}c_n x^n  N, x > R")

#text("this implies that,")

#mi("\\displaystyle 0=\\underset{x\\to \\infty}{\\lim}\\dfrac{C- \\epsilon}{x^k} < c_k  N.")

#text("From this we deduce that ")#mi("\\phi(x)=\\overset{N}{\\underset{n=0}{\\sum}}c_n x^n")#text(" and because ")#mi("\\underset{x\\to \\infty}{\\lim}\\phi(x)=C")#text(", ")#mi("\\phi(x)")#text(" must be constant ")#mi("C.")#text(" Hence, ")#mi("f(x)=Ce^{-x}")#text(", where the equations ")#mi("a_n=C(-1)^n")#text(" follows.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6caca35c0ca985a92dca07672fb32e97c8110df01b88be00126ab4cd2029196-aafce5d6e74d4a1bf4b2fc2f321e57847261b40f6ddb8972ce7367b8a55f69a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iker Martinez")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-513810")[#strong[#text("Iker Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2019")])]

#text("I dont know how to write math here, so I posted my solution here, ")#link("https://math.stackexchange.com/questions/3147563/a-real-variable-solution-of-a-problem-posted-on-terry-taos-blog/3147565#3147565")[#text("https://math.stackexchange.com/questions/3147563/a-real-variable-solution-of-a-problem-posted-on-terry-taos-blog/3147565#3147565")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1930e20cc52a8c5c3ff2578860942244bd58ab30bf3230a15291aad1e37650a1-26ed7963a8c4de3cec3ff0c5444d353132cc243a4a10bf0a469d3cc8349f6dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amsmath")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-515752")[#strong[#text("amsmath")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2019")])]

#text("There are three flaws in this “proof”. First, your coefficients seem wrong to me. Second, the limit of ")#mi("\\phi")#text(" at ")#mi("\\infty")#text(" might not exist. Third, you assume that the series converges uniformly on ")#mi("(R,\\infty)")#text(", which you cannot do.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-621072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Eugenia Malinnikova has just pointed out to me that the statement of this problem is similar to the Hardy uncertainty principle, and the solution to the problem that had been worked out in the comments is in fact very similar to Hardy’s second proof of that principle in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574130")[#text("his original paper")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-685153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("As an experiment, I have explained the solution to this problem to ChatGPT at ")#link("https://chatgpt.com/share/63c5774a-d58a-47c2-9149-362b05e268b4")[#text("this link")]#text(". Through an interactive discussion, GPT was able to expand out my sketch of a proof into a full LaTeX document, which one can ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/06/laplace.pdf")[#text("find here")]#text(". This experiment was meant to illustrate a recent comment I made in ")#link("https://www.scientificamerican.com/article/ai-will-become-mathematicians-co-pilot/")[#text("this interview")]#text(", envisioning how in the future a mathematician might produce a proof through conversation with a GPT, though ideally the GPT should also be able to provide a running formalization of the proof in a language such as Lean in order to guarantee 100% correctness of the argument (this is the main reason why I think the full workflow that I envision is still a few years away).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-685176")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2024")])]

#text("If you use double dollar signs instead of single dollar signs when messaging ChatGPT, your latex will render in your own message.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-689461")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2025")])]

#text("Dr Tao, I tried to solve this problem using complex variable argument, but failed. Then I checked the proof in the comment you provided, it turns out that my toolbox does not contain the tool of “Laplace Transform”. I know that not only in complex analyis but also in ODE and PDE, this tool is useful—— I would like to ask: generally speaking, what’s the strategy of using Laplace Transform?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/a-problem-involving-power-series/comment-page-1/#comment-689467")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("You may find the answers in ")#link("https://mathoverflow.net/questions/383/motivating-the-laplace-transform-definition")[#text("https://mathoverflow.net/questions/383/motivating-the-laplace-transform-definition")]#text(" and ")#link("https://mathoverflow.net/questions/464191/motivation-and-physical-interpretation-of-the-laplace-transform")[#text("https://mathoverflow.net/questions/464191/motivation-and-physical-interpretation-of-the-laplace-transform")]#text(" to be helpful.")
]
]
