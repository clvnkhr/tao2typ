// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/11/the-walsh-model-for-m_2-carleson/
// Converted to Typst by tao2typ: "2026-10-14T16:35:06.422342+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Walsh model for M_2^* Carleson", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Walsh model for M_2^* Carleson")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/11/the-walsh-model-for-m_2-carleson/")[#text("https://terrytao.wordpress.com/2007/12/11/the-walsh-model-for-m_2-carleson/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.ucla.edu/~demeter/")[#text("Ciprian Demeter")]#text(", ")#link("http://www.math.gatech.edu/~lacey/")[#text("Michael Lacey")]#text(", ")#link("http://www.math.ucla.edu/~thiele/")[#text("Christoph Thiele")]#text(" and I have just uploaded our joint paper, “")#link("http://arxiv.org/abs/0712.1295")[#text("The Walsh model for ")#mi("M_2^*")#text(" Carleson")]#text("” to the ")#link("http://arxiv.org/")[#text("arXiv")]#text(". This paper (which was recently accepted for publication in ")#link("http://www.uam.es/departamentos/ciencias/matematicas/especifica/ibero/index.html")[#text("Revista Iberoamericana")]#text(") establishes a simplified model for the key estimate (the “")#mi("M_2^*")#text(" Carleson estimate”) in another (much longer) ")#link("http://front.math.ucdavis.edu/math.DS/0601455")[#text("paper of ours")]#text(" on the ")#link("http://www.ams.org/mathscinet-getitem?mr=939436")[#text("return times theorem")]#text(" of Bourgain, in which the Fourier transform is replaced by its ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("dyadic analogue")]#text(", the ")#link("http://en.wikipedia.org/wiki/Walsh_function")[#text("Walsh-Fourier transform")]#text(". This model estimate is established by the now-standard techniques of time-frequency analysis: one decomposes the expression to be estimated into a sum over tiles, and then uses combinatorial stopping time arguments into group the tiles into trees, and the trees into forests. One then uses (phase-space localised, and frequency-modulated) versions of classical Calderòn-Zygmund theory (or in this particular case, a certain maximal Fourier inequality of Bourgain) to control individual trees and forests, and sums up over the trees and forests using orthogonality methods (excluding an exceptional set if necessary).")

#text("Rather than discuss time-frequency analysis in detail here, I thought I would dwell instead on the return times theorem, and sketch how it is connected to the ")#mi("M_2^*")#text(" Carleson estimate; this is a more complicated version of the “")#mi("M_2")#text(" Carleson estimate”, which is an estimate which is logically equivalent to ")#link("http://www.ams.org/mathscinet-getitem?mr=199631")[#text("Carleson’s famous theorem")]#text(" (and its extension ")#link("http://www.ams.org/mathscinet-getitem?mr=238019")[#text("by Hunt")]#text(") on the ")#link("http://en.wikipedia.org/wiki/Convergence_of_Fourier_series#Convergence_almost_everywhere")[#text("almost everywhere convergence of Fourier series")]#text(".")

#metadata(none) <tao-b52e19f0f9be16d84ad2>

#heading(level: 1)[#text("— The Carleson-Hunt theorem —")]

#text("Let’s begin with the ")#emph[#text("Carleson-Hunt theorem")]#text(", which asserts that the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\lim_{N \\to \\infty} \\int_{-N}^N \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("is valid for ")#link("http://en.wikipedia.org/wiki/Almost_everywhere")[#text("almost every")]#text(" ")#mi("x \\in {\\Bbb R}")#text(", whenever f lies in an ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("L^p({\\Bbb R})")#text(" space")]#text(" for some ")#mi("1 < p < \\infty")#text(". Here, the Fourier transform is defined for sufficiently rapidly decreasing f by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\int_{-\\infty}^\\infty f(x) e^{-2\\pi i x \\xi}\\ dx")]]

#text("and then extended to ")#mi("L^p({\\Bbb R})")#text(" by density (here one can use a classical theorem of Riesz that asserts that the Dirichlet operators ")#mi("S_N f(x) := \\int_{-N}^N \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")#text(" can be continuously extended to ")#mi("L^p({\\Bbb R})")#text(" for every ")#mi("1 < p < \\infty")#text(").")

#text("The convergence theorem is easy to show if the function f is smooth and rapidly decreasing; the difficulty is to extend it to the rougher functions in ")#mi("L^p({\\Bbb R})")#text(". It turns out that the key lies in establishing the maximal inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|  \\sup_N \\left|\\int_{-N}^N \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi\\right| \\right\\|_{L^p({\\Bbb R})} \\ll_p \\left\\|f\\right\\|_{L^p({\\Bbb R})}", block: true)]]

#text("for all test functions f; once one has (1), the Carleson-Hunt theorem follows by a standard approximation argument. (Conversely, by using ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("Stein’s maximal principle")]#text(", one can show that the Carleson-Hunt theorem is in fact logically equivalent to (1), at least in the range ")#mi("1 < p < 2")#text(".)")

#text("One can recast this estimate in a slightly different manner. Define the ")#emph[#text("Carleson operator")]

#align(center)[#mi("{\\mathcal C}f(\\theta, x) = \\int_{-\\infty}^\\theta \\hat f(\\xi) e^{2\\pi i x \\xi} = p.v. \\frac{1}{\\pi} \\int_{-\\infty}^{\\infty} \\frac{f(x-y)}{y} e^{2\\pi i y \\theta}\\ dy")#text(".")]

#text("Note that this operator extends the ")#link("http://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(", which is recovered by restricting ")#mi("\\theta")#text(" to equal zero. It is then not hard to show that the estimate (1) is equivalent to the estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\left\\| {\\mathcal C} f(x,\\theta) \\right\\|_{L^\\infty_\\theta({\\Bbb R})} \\right\\|_{L^p_x({\\Bbb R})} \\ll_p \\left\\|f\\right\\|_{L^p({\\Bbb R})}.", block: true)]]

#heading(level: 1)[#text("— The return times theorem —")]

#text("Now let us leave Fourier analysis and pass to ergodic theory, which studies the long-time dynamics of ")#link("http://en.wikipedia.org/wiki/Measure-preserving_dynamical_system")[#text("measure-preserving systems")]#text(" ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(", thus ")#mi("(X,{\\mathcal X},\\mu)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(", and ")#mi("T: X \\to X")#text(" is a measure-preserving bijection. One of the fundamental theorems in ergodic theory is, of course, the ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem#Ergodic_theorem_.28Individual_or_Birkhoff.29")[#text("pointwise (or Birkhoff) ergodic theorem")]#text(", which asserts that for any function ")#mi("f \\in L^p(X)")#text(" with ")#mi("1 \\leq p \\leq \\infty")#text(", the sequence")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_{n=1}^N f( T^n x )")]]

#text("is convergent as ")#mi("N \\to \\infty")#text(" for almost every ")#mi("x \\in X")#text(" (as measured with respect to ")#mi("\\mu")#text(", of course). (If the measure-preserving system is ")#link("http://en.wikipedia.org/wiki/Ergodic")[#text("ergodic")]#text(", then the limit is equal to ")#mi("\\int_X f\\ d\\mu")#text(", but for this discussion we will not be interested in the specific value of the limit.) Just as the Carleson-Hunt theorem (which is a qualitative convergence result) is connected to (2) (which is a quantitative estimate), the pointwise ergodic theorem is connected to an estimate, namely the ")#link("http://en.wikipedia.org/wiki/Maximal_ergodic_theorem")[#text("maximal ergodic theorem")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_N \\left|  \\frac{1}{N} \\sum_{n=1}^N f( T^n x ) \\right| \\right\\|_{L^p(X)} \\ll_p \\left\\|f\\right\\|_{L^p(X)},", block: true)]]

#text("valid for all ")#mi("1 < p \\leq \\infty")#text(" and ")#mi("f \\in L^p({\\Bbb R})")#text(". (Actually, the maximal ergodic theorem is a little stronger than this, incorporating a sharp weak (1,1) inequality, but I will not discuss this improvement here.) The maximal ergodic theorem does not directly imply the pointwise ergodic theorem, although it does let deduce the ")#mi("1 < p < \\infty")#text(" case of the pointwise ergodic theorem from the ")#mi("p=\\infty")#text(" case by the density argument mentioned earlier. The maximal ergodic theorem is also closely related to the ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_inequality")[#text("Hardy-Littlewood maximal inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_k \\left|  \\frac{1}{2^{k}} \\int_{\\Bbb R} f(x+z) K(z/2^k)\\ dz \\right| \\right\\|_{L^p_x({\\Bbb R})} \\ll_p \\left\\|f\\right\\|_{L^p({\\Bbb R})},", block: true)]]

#text("where K is some approximation to the identity whose exact value is not important for this discussion. Indeed, one can deduce the former from the latter by ")#link("http://www.ams.org/mathscinet-getitem?mr=453975")[#text("Conze’s transference principle")]#text(".")

#text("The pointwise ergodic theorem immediately implies the following extension of itself, namely that for any fixed ")#mi("\\theta \\in {\\Bbb R}")#text(" and every ")#mi("f \\in L^p(X)")#text(" for some ")#mi("1 \\leq p \\leq \\infty")#text(", the sequence")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N e^{2\\pi i n \\theta x} f( T^n x )")]]

#text("converges for almost every ")#mi("x \\in X")#text(". Indeed, to see this one simply applies the pointwise ergodic theorem to the product system ")#mi("X \\times S^1")#text(" with the shift ")#mi("(x,\\omega) \\to (Tx,\\omega+\\alpha)")#text(" and to the function ")#mi("(x,\\omega) \\mapsto f(x) e^{2\\pi i \\omega}")#text(". However, note that for each individual real number ")#mi("\\theta")#text(", there is an exceptional set of x for which the sequence (3) fails to converge. Since the set of real numbers is uncountable, it could conceivably happen that there does not exist any x for which (3) converges for ")#emph[#text("all")]#text(" ")#mi("\\theta")#text(". Nevertheless, this does not happen, thanks to the ")#link("http://www.ams.org/mathscinet-getitem?mr=4098")[#text("Wiener-Wintner theorem")]#text(", which asserts that if ")#mi("f \\in L^p(X)")#text(" for some ")#mi("1 \\leq p \\leq \\infty")#text(", then for almost every x in X, the sequence (3) converges for ")#emph[#text("all")]#text(" ")#mi("\\theta")#text(". This theorem is closely linked to the maximal ergodic theorem-type estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left\\| \\sup_N \\left|  \\frac{1}{N} \\sum_{n=1}^N e^{2\\pi i n \\theta} f( T^n x ) \\right| \\right\\|_{L^\\infty_\\theta({\\Bbb R})} \\right\\|_{L^p(X)} \\ll_p \\left\\|f\\right\\|_{L^p(X)},", block: true)]]

#text("or the Hardy-Littlewood maximal type estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left\\| \\sup_k \\left|  \\frac{1}{2^{k}} \\int_{{\\Bbb R}} f(x+z) e^{2\\pi i z \\theta} K(z/2^k)\\ dz \\right|  \\right\\|_{L^\\infty_\\theta({\\Bbb R})} \\right\\|_{L^p_x({\\Bbb R})} \\ll_p \\left\\|f\\right\\|_{L^p({\\Bbb R})},", block: true)]]

#text("for ")#mi("1 < p \\leq \\infty")#text(", although in this particular case, these apparently stronger estimates follow immediately from their untwisted counterparts (in which ")#mi("\\theta=0")#text(" throughout) by the triangle inequality.")

#text("We motivated the Wiener-Wintner theorem by adjoining an arbitrary circle rotation ")#mi("\\omega \\mapsto \\omega + \\theta")#text(" to the original measure-preserving system ")#mi("x \\mapsto Tx")#text(". But one could have adjoined a more general system ")#mi("y \\mapsto Sy")#text(" to the original system, leading to the conclusion that for each ")#mi("f \\in L^p(X)")#text(", ")#mi("g \\in L^q(Y)")#text(", and any measure preserving transformations ")#mi("T: X \\to X")#text(", ")#mi("S: Y \\to Y")#text(", the sequence")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{1}{N} \\sum_{n=1}^N f( T^n x ) g(S^n y)")]]

#text("converges for almost every x,y.")

#text("Motivated by the Wiener-Wintner theorem, one can ask whether one can make the exceptional set uniform in the choice of g, S, y. This is indeed the case, and is ")#link("http://www.ams.org/mathscinet-getitem?mr=939436")[#text("Bourgain’s return times theorem")]#text(": if ")#mi("1 < p,q \\leq \\infty")#text(" and one has the duality condition ")#mi("1/p + 1/q \\leq 1")#text(", then for every ")#mi("f \\in L^p(X)")#text(" and ")#mi("T: X \\to X")#text(" it is true that for almost every x in X, the sequence (4) converges for all systems ")#mi("(Y, {\\mathcal Y},\\nu, S)")#text(", all ")#mi("g \\in L^q(Y)")#text(", and all y in Y. (In ")#link("http://front.math.ucdavis.edu/math.DS/0601455")[#text("our longer paper")]#text(", we replaced the duality condition with ")#mi("q \\geq 2")#text("; conversely, the claim fails at the double endpoint ")#mi("p=q=1")#text(", as shown ")#link("http://www.ams.org/mathscinet-getitem?mr=2145565")[#text("by Assani, Buzcolich, and Mauldin")]#text(".)")

#text("The return times theorem is related to the estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\sup_{g, Y, S: \\left\\|g\\right\\|_{L^q(Y)} \\leq 1} \\sup_N \\left| \\frac{1}{N} \\sum_{n=1}^N f( T^n x ) g(S^n y) \\right| \\right\\|_{L^p(X)} \\ll_{p,q} \\left\\|f\\right\\|_{L^p(X)},", block: true)]]

#text("in much the same way that the pointwise ergodic theorem is related to the maximal ergodic theorem. (Thus, the estimate does not quite imply the convergence result by itself – one would need a “")#link("http://en.wikipedia.org/wiki/Total_variation")[#text("variational")]#text("” or “upcrossing” version of the estimate for that – but can be used via density arguments to enlarge the range of functions in which convergence holds.)")

#text("Just as Conze’s transference principle allows one to deduce the maximal ergodic theorem from the Hardy-Littlewood maximal inequality (which can be viewed as its continuous counterpart over ")#mi("{\\Bbb R}")#text("), the estimate (5) follows from the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{g: \\left\\|g\\right\\|_{L^q({\\Bbb R})} \\leq 1} \\left\\| \\sup_k \\left| \\frac{1}{2^{k}} \\int_{\\Bbb R} f(x+z) g(y+z) K(z/2^k)\\ dz \\right|  \\right\\|_{L^q_y({\\Bbb R})} \\right\\|_{L^p_x({\\Bbb R})}", block: true)]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\ll_{p,q} \\left\\|f\\right\\|_{L^p(X)}.", block: true)]]

#text("The left-hand side here is rather fearsome looking (two norms and two suprema, one of which is over a class of functions rather than a single real number) but we can simplify it a bit by noting that the inner integral is a convolution operator in g, thus the left-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_g \\left\\| \\sup_k \\left|g * K_{k,f,x}(y)\\right| \\right\\|_{L^q_y} \\right\\|_{L^p_x}", block: true)]]

#text("where ")#mi("K_{k,f,x}")#text(" is the kernel ")#mi("K_{k,f,x}(y) := f(x-z) 2^{-k} K(-z/2^k)")#text(". The inner supremum is then a maximal ")#link("http://en.wikipedia.org/wiki/Multiplier_%28Fourier_analysis%29")[#text("Fourier multiplier")]#text(" ")#tao-math("\\sup_k \\left|m_{k,f,x}(D) g(y)\\right|", block: false)#text(", where ")#mi("m_{k,f,x} = \\widehat{K_{k,f,x}}")#text(" is the Fourier transform of ")#mi("K_{k,f,x}")#text(". Recall that Fourier multipliers m(D) have the ")#emph[#text("multiplier norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\right\\|_{M_q} := \\sup_{g: \\left\\|g\\right\\|_{L^q({\\Bbb R})} \\leq 1} \\left\\| m(D) g \\right\\|_{L^q({\\Bbb R})};", block: true)]]

#text("motivated by this, we can define the ")#emph[#text("maximal multiplier norm")]#text(" of a sequence ")#mi("m = (m_k)_{k \\in {\\Bbb Z}}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\right\\|_{M_q^*} := \\sup_{g: \\left\\|g\\right\\|_{L^q({\\Bbb R})} \\leq 1} \\left\\| \\sup_k \\left|m_k(D) g\\right| \\right\\|_{L^q({\\Bbb R})}.", block: true)]]

#text("The return times estimate is then equivalent to the assertion that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\left\\|m_{\\cdot,f,x}\\right\\|_{M_q^*} \\right\\|_{L^p_x} \\ll_{p,q} \\left\\|f\\right\\|_{L^p}.", block: true)]]

#text("It turns out that the Fourier multiplier ")#mi("m_{k,f,x}(\\theta)")#text(" is roughly a smoothed out version ")#mi("{\\mathcal C}_k f(\\theta,x)")#text(" of the Carleson operator ")#mi("{\\mathcal C} f(\\theta,x)")#text(", in which one only considers physical scales of order ")#mi("2^k")#text(" and coarser (or equivalently, frequency scales of order ")#mi("2^{-k}")#text(" and finer). This can be made precise using wave packet decompositions, which I will not discuss here. Thus the return times estimate is basically equivalent to")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\left\\|{\\mathcal C}_{\\cdot} f(\\theta,x)\\right\\|_{(M_q^*)_\\theta} \\right\\|_{L^p_x} \\ll_{p,q} \\left\\|f\\right\\|_{L^p}.", block: true)]]

#text("On the other hand, from the well-known fact (from ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel’s theorem")]#text(") that the ")#mi("M_2")#text(" norm of a multiplier m is the same as its supremum norm, the Carleson-Hunt inequality (1) is equivalent to")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\left\\|{\\mathcal C} f(\\theta,x) \\right\\|_{(M_2)_\\theta} \\right\\|_{L^p_x} \\ll_{p,q} \\left\\|f\\right\\|_{L^p}.", block: true)]]

#text("Thus we see that the return times theorem for q=2 is a maximal version of Carleson’s theorem. Indeed, we prove the return times theorem in the case ")#mi("q=2")#text(" by adapting the time-frequency proof of Carleson’s theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=1783613")[#text("due to Lacey and Thiele")]#text(".")

#text("[Update, Dec 12: A missing exponential in a Hardy-Littlewood type maximal estimate has been reinstated; thanks to Richard Oberlin for the correction.]")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48fed3d4df1fb366d7bb65f2c6e0179985fec4ac650549081505d563a5c80b9b-cd245e2dd4b6a9e59b975595a1a50b2e9fdbe1f8311a253f4701e150c75df765.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lacey")]], [#link("https://terrytao.wordpress.com/2007/12/11/the-walsh-model-for-m_2-carleson/#comment-19979")[#strong[#text("Michael Lacey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2007")])]

#text("Many years ago, in 1989, through conversations with ")#link("http://www.math.unc.edu/people_karlpetersen.html")[#text(" Karl Petersen ")]#text(" the question of the ")#link("http://arxiv.org/abs/math/0601192")[#text(" Wiener-Wintner Theorem for the Hilbert transform ")]#linebreak()#text(" was my introduction to the Carleson Theorem.")

#text("At the time, I couldn’t answer the that question, nor could I understand")#linebreak()#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=939436")[#text("Bourgain’s Return Time Theorem,")]#text(" mentioned in the post above. So I phrased to")#linebreak()#text(" myself, in 1990, the ")#link("http://arxiv.org/abs/math/9903203")[#text(" Calderon Conjecture ")]#text(" many years before Christoph Thiele and I solved it.")

#text("Not mentioned by Terry, is a far reaching extension of the Wiener-Wintner Theorem to a ")#link("http://www.ams.org/mathscinet-getitem?mr=1489899")[#text(" Multiple Wiener-Wintner Theorem")]#text(" due to")#linebreak()#text(" ")#link("http://www.math.colostate.edu/~rudolphd/")[#text(" Dan Rudolph.")]#linebreak()#text(" It would be great to extend these results to the “M_2^*” context described")#linebreak()#text(" above. But this appears to be beyond the reach of our current understanding, an observation apparently due to Bourgain.")
]
