// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/04/more-of-my-interviews-and-talks/
// Converted to Typst by tao2typ: "2026-11-12T01:31:35.489309+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More of my interviews and talks", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More of my interviews and talks")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/04/more-of-my-interviews-and-talks/")[#text("https://terrytao.wordpress.com/2026/11/04/more-of-my-interviews-and-talks/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-12 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am continuing in this current era to open up my blog to a broader range of voices on math and AI, with the majority of posts now being guest posts by other authors. My own views on these topics (which often overlap with, but are not identical to, those of the guest authors) are summarized on ")#link("https://teorth.github.io/tao-web/ai-views.html")[#text("this page")]#text(". I have also given a number of recent interviews and talks on these topics; I am listing some of these here for reference.")

#list(
[#text("“")#link("https://open.spotify.com/episode/4R4RTCjawK92g33ipS2gP6")[#text("How maths underpins almost every aspect of our lives")]#text("“, Instant Genius podcast, BBC Science Focus, October 18, 2026.")],
[#text("“")#link("https://youtu.be/TjeCcDkuyao")[#text("Terence Tao & Yu Deng: Why We Build Open Math Model")]#text("“, SAIR Foundation, October 19, 2026.")],
[#text("James Tapper, “")#link("https://observer.co.uk/news/science-technology/article/terence-tao-ai-race-turns-beautiful-mathematics-into-toxic-waste")[#text("Terence Tao: AI race turns beautiful mathematics into ‘toxic waste’")]#text("“, The Observer, October 23, 2026.")],
[#text("“")#link("https://www.nature.com/articles/d41586-026-03389-1")[#text("Can maths survive AI? Fields medallist Terence Tao calls for a ‘Maths 2.0’ world")]#text("“, World View op-ed, Nature, October 22, 2026.")],
[#text("“")#link("https://www.sciencefriday.com/segments/terence-tao-ai-math-solutions/")[#text("Terence Tao on how AI math solutions miss the point")]#text("“, interview with Flora Lichtman, Science Friday, October 28, 2026. ")#link("https://www.youtube.com/watch?v=9vetGqz4zXg")[#text("[Youtube version")]#text("]")],
[#text("“")#link("https://www.youtube.com/watch?v=EYrlyxuyFbs")[#text("Inside AI’s Brutal Race to Solve a Famous Math Problem")]#text("“, New Scientist, October 28, 2026.")],
[#text("Rivka Galchen, “")#link("https://www.newyorker.com/magazine/2026/11/09/the-year-math-changed-forever")[#text("The Year Math Changed Forever")]#text("“, The New Yorker, November 1, 2026.")]
)

#text("Disclosure: while many of these articles were solicited due to current events, some are also related to a long-planned launch of a ")#link("https://www.quantabooks.org/books/six-math-essentials/")[#text("book I wrote")]#text(", to be released Nov 10.")
