// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:37:42.882516+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Gaps between primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Gaps between primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/")[#text("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short post here to note that the ")#link("http://www.ams.org/notices/201506/rnoti-p660.pdf")[#text("cover story of this month’s Notices of the AMS")]#text(", by John Friedlander, is about the recent work on bounded gaps between primes by Zhang, Maynard, our own Polymath project, and others.")

#text("I may as well take this opportunity to upload some slides of my own talks on this subject: here are ")#link("https://terrytao.wordpress.com/wp-content/uploads/2015/07/lat.pdf")[#text("my slides on small and large gaps between the primes")]#text(" that I gave at the “")#link("http://www.ipam.ucla.edu/programs/special-events-and-conferences/latinos-in-the-mathematical-sciences-conference/")[#text("Latinos in the Mathematical Sciences")]#text("” back in April, and ")#link("https://terrytao.wordpress.com/wp-content/uploads/2015/07/polymath.pdf")[#text("here are my slides on the Polymath project")]#text(" for the ")#link("http://www.kva.se/en/Events-List/2014/The-Rolf-Schock-Prize-symposium-in-mathematics/")[#text("Schock Prize symposium")]#text(" last October. (I also gave an abridged version of the latter talk at an ")#link("https://aaas.confex.com/aaas/2015/webprogram/Session9529.html")[#text("AAAS Symposium")]#text(" in February, as well as the ")#link("https://breakthroughprize.org/Symposiums/5")[#text("Breakthrough Symposium")]#text(" from last November.)")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67c854637d9f39d895a594ce873c97eaa99800ba101acf16525f2cbbfca2f365-e3872974876f9454dcf6c892196b39f4fe7dc832022508bf10e0e7f32dc6204d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-456978")[#strong[#text("Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2015")])]

#text("Has anybody noticed the rhythm of primes has been uncovered? ")#link("http://www.pateo.nl/PDF/PrimeRhythm.pdf")[#text("http://www.pateo.nl/PDF/PrimeRhythm.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b9f41ebf2ff5afab843e332956defcd5a714b5cb604fb51505543ce0003136b-dc66fff4a00dc381669bc4abfec1529db6cfc647725d272d28ae7fbbbb6d5532.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dong hongyu")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457044")[#strong[#text("dong hongyu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("I am a chinese student.I know that mathmatic is a very beautiful subject.But unfortunately,my teacher does not have much knowledge of this beautiful subject.Can you recommend me for some book about calculus and probability theory？Thank you very much。")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulienSylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457046")[#strong[#text("sylvainjulienSylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("If you’re interested in applications of analysis and propability theory to number theory, I recommend Gérald Tenenbaum’s book “Introduction to analytic and probabilistic theory”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b9f41ebf2ff5afab843e332956defcd5a714b5cb604fb51505543ce0003136b-dc66fff4a00dc381669bc4abfec1529db6cfc647725d272d28ae7fbbbb6d5532.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dong hongyu")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457060")[#strong[#text("dong hongyu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("thank you very much.In china, it is very hard for us to know about these.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/495d55709ea257c61c2c990b9c3837a444b4a2505e2b9277aa138a4ffe2029af-32d2a8f2ffa670094ba7e4c928a10230ea802c5d6b4fedad64bc24eed898b0f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neelabh Deka")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457190")[#strong[#text("Neelabh Deka")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2015")])]

#text("Sir,my name is Neelabh Deka and I’m a 12 grader,I’ve found a nice prime related result while playing with prime numbers. Unfortunately I cant prove it,so I would like to share it.")#linebreak()#text(" Conjecture-Let P_n denote the n-th prime number.If we choose n consecutive natural numbers from the interval [2,P_n^2] such that they are divisible by P_1,P_2,…,P_n not necessarily in order, then the next set of n consecutive natural numbers would contain at least one prime number.")

#text("For example ,if n=3,then p_n=5 then we choose three consecutive natural numbers between 2 and 25,say 8,9 and 10.Here 2 divides 8,3 divides 9,5 divides 10,then next set of three consecutive natural numbers we get 11 which is a prime.")

#text("A related conjecture would be to guess that the previous set of n consecutive natural numbers before our choice would also contain at least one prime number.")

#text("If this conjecture true then we may hope to apply it to other conjectures like brocard,grimms’s conjecture.")

#link("mailto:Email-neelabhdeka1997@gmail.com")[#text("Email-neelabhdeka1997@gmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9af4e817831fe33c81b1494552289000c1850e188057ec230cc2e9c9c7be1299-4241a2cc15e4483c13693d4df4c959a33a3325766ea7bbcbcedd7bb708bd325a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of C. Ruiz-Piñate")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457760")[#strong[#text("C. Ruiz-Piñate")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2015")])]

#text("Dear Professor Tao,")

#text("I was wondering if, when you are considering the gaps between consecutive primes, you are taking into account that this phenomen is due to the overlaping of minimum two different odd number rows where roots and gaps don’t touch each other. They only become consecutive ( n and n+2) when both rows are overlaped.")

#text("One row starts at 3 and grows +4 and the other starts at 5 and grows +4.")

#text("What seems to be f.i. a prime succesion with consecutive primes of 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, is in reality comprised of overlaping the gaps resulting from the substraction of the odd and even squares ( and viceversa). You will notice that the factors resulting from odd^2 minus even^2 compared with even^2 minus odd^2 have no common numbers. Repetitions happen only within a sub-set.")

#text("So, one set of primes (gaps) resulting from substracting odd from even squares is 3, 7, 11, 19, 23, 31, 43, 47, 59, 67, 71, 79, 83, and the other even from odd squares 5, 13, 17, 29, 37, 41, 53, 61, 73, 89, 97, 101.")

#text("The Prime number theorem applies but we have to use it for minimum two different subsets. Since each row has it’s “own” primes you will notice that the approximation of x/ln x is closer to the real ammount of primes when you make 2*((x/2)/ln(x/2)).")

#text("approx of primes with x, 2* x/2 and (pi)")

#text("for 10^4, 1,085 vs 1,174 (1,229)")#linebreak()#text(" for 10^5, 8.685 vs 9.242 (9,592)")#linebreak()#text(" for 10^6, 72.382 vs 76.205 (78,498)")#linebreak()#text(" for 10^7, 620,421vs 648,300 (664,579)")

#text("One of the odd number sub-sets can be also subdivided in two groups of non touching number and gap rows which when the PNT is used yields further a much better approximation of the ammount of primes by adding (x/2)/ln(x/2) + 2((x/4)/ln(x/4))")

#text("for 10^4, 1,085 vs 1,226 (1,229)")#linebreak()#text(" for 10^5, 8.685 vs 9.559 (9,592)")#linebreak()#text(" for 10^6, 72.382 vs 78,331 (78,498)")#linebreak()#text(" for 10^7, 620,421vs 663,552 (664,579)")

#text("In addition I have found that the parables resulting in this analysis will give you in further comparisson an exact primality proof which at the same time yields the prime factors (in case of a composite number) through a discovered hyperbola function. I will be glad to discuss these lay findings in more detail should anybody in the forum consider these interesting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67c854637d9f39d895a594ce873c97eaa99800ba101acf16525f2cbbfca2f365-e3872974876f9454dcf6c892196b39f4fe7dc832022508bf10e0e7f32dc6204d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ollev Verhoeven")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457761")[#strong[#text("Ollev Verhoeven")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2015")])]

#text("dear professor Tao,")#linebreak()#text(" would you please pay attention to the link in my email? It provides a very simple explanation on the rhythm of prime numbers. The order of sequence actually has been solved in 2010 by a Dutchman.")

#link("http://www.pateo.nl/PDF/PrimeRhythm.pdf")[#text("Click to access PrimeRhythm.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f552172ae5569c21631385a64f0c4ce6c81593a09845694ac9ace7b8bdd0da6-46a6f5e193b32c8981ba06f95e36e6aa9caf70133f33afae927954723b01986c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457830")[#strong[#text("Fred")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2015")])]

#text("If the probability a number is prime is greater than 0, and the probability another number is prime is also greater than 0, then the joint probability they are both prime is greater than 0.")

#text("When we use 4 number lines representing the sequences of 1’s, 3’s, 7’s and 9’s, we can visualize how frequently these numbers with a probability of being prime greater than 0 are aligned next to each other (+2) and at every other conceivable positive spacing. Furthermore, each sequence is infinitely long, implying infinitely many twin primes and primes pairs of all even sized gaps. I have notes / visualization available here:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e17b6fe0221cba683d549d2c57de44174cd53e3d80c9dd6ce2244c7ce42ada-50a53d89ee4dd9c8ed30545e40e69c167eafa9d9c1bb818dbf8cf4414e0fccb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of April Jashmer Anting")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457852")[#strong[#text("April Jashmer Anting")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2015")])]

#text("Dear Prof Terry Tao,")

#text("May I just ask whether everyone is aware of this:")

#text("I am considering any number N=2k+1 and a function W(n)=k! (mod N).")

#text("Then, N is composite if and only if W(n)=0 otherwise N is prime.")#linebreak()#text(" Furthermore, if k is even and N is prime then there would always be a number a such that a²+1 (mod N)=0 in fact a=W(n).")#linebreak()#text(" If k is odd, N is prime then W(n)=1 or -1 .")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-457855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2015")])]

#text("This is one of the standard applications of Wilson’s theorem: see ")#link("https://en.wikipedia.org/wiki/Wilson%27s_theorem#Quadratic_residues")[#text("https://en.wikipedia.org/wiki/Wilson%27s_theorem#Quadratic_residues")]#text(" . But if you discovered it independently, congratulations :).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e17b6fe0221cba683d549d2c57de44174cd53e3d80c9dd6ce2244c7ce42ada-50a53d89ee4dd9c8ed30545e40e69c167eafa9d9c1bb818dbf8cf4414e0fccb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of April Jashmer Anting")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-458011")[#strong[#text("April Jashmer Anting")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("I am very grateful for your quick response sir. I am working to stretch out the implication of this result. Among those results are as follows (just let me know if they are interesting):")

#text("1. 2^(2^n + 2) + 1 can never be prime it is always divisible by 5.")#linebreak()#text(" 2. Fermat number greater than 5 is not always divisible by 3 nor 5")#linebreak()#text(" 3. 2^(2^n – 2) + 1 can never be prime it is always divisible by 5.")#linebreak()#text(" 4. 2^{2^(n+1) + 4} + 1 n>1 is always divisible by 17.")#linebreak()#text(" 5. Fermat number is of the form 15k+2.")

#text("There are lot of result coming in but its hard to choose a path that could lead into a more sound result. Thus, I would really appreciate your feedback.")

#text("PS: I greatly love your effort and conviction in pursuing a collaborative approach in mathematical research and using the internet (the only accessible tool that I have) to encourage people in doing math. You just open the whole mathematical ideas to the ends of the earth. May the rest follow.")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e17b6fe0221cba683d549d2c57de44174cd53e3d80c9dd6ce2244c7ce42ada-50a53d89ee4dd9c8ed30545e40e69c167eafa9d9c1bb818dbf8cf4414e0fccb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of April Jashmer Anting")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-458014")[#strong[#text("April Jashmer Anting")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("no. 5 means fermat number more than 5")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-458026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2015")])]

#text("do u really think he would bother with your trivial statements lol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9caef4b5028ca7355308de0c46c5b850ec5540b37d58342c19ada8249ad4a5d1-1d2a6405039b90a1e214593db2478ec2f5565fc5cc4075f766beb0d3547c7a46.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mallesham kummari")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-541704")[#strong[#text("mallesham kummari")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2020")])]

#text("Let p_1, p_2,…, p_n be first n primes. Let M be the smallest integer such that M and M+2 both coprime to first n primes p_1,…, p_n. Then is it true that M and M+2 both are primes???")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/07/06/gaps-between-primes/#comment-541998")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2020")])]

#text("Probably, just because it is likely that there is always a twin prime pair ")#mi("M, M+2")#text(" with ")#mi("p_n < M < p_n^2-2")#text(" once ")#mi("n")#text(" is not too tiny, but establishing this is likely to be just as hard as proving the twin prime conjecture.")
]
]
