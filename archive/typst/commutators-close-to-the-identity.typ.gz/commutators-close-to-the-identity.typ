// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/
// Converted to Typst by tao2typ: "2026-10-14T16:38:19.601064+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Commutators close to the identity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Commutators close to the identity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 April 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/")[#text("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I am recording here some notes on a nice problem that ")#link("http://www.math.ucla.edu/~popa/")[#text("Sorin Popa")]#text(" shared with me recently. To motivate the question, we begin with the basic observation that the differentiation operator ")#mi("{Df(x) := \\frac{d}{dx} f(x)}")#text(" and the position operator ")#mi("{Xf(x) := xf(x)}")#text(" in one dimension formally obey the commutator equation ")#metadata(none) <tao-555706671972bc5f74ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("[D,X] = 1")]]

#text("where ")#mi("{1}")#text(" is the identity operator and ")#mi("{[D,X] := DX-XD}")#text(" is the commutator. Among other things, this equation is fundamental in quantum mechanics, leading for instance to the Heisenberg uncertainty principle.")

#text("The operators ")#mi("{D,X}")#text(" are unbounded on spaces such as ")#mi("{L^2({\\bf R})}")#text(". One can ask whether the commutator equation ")#link(<tao-555706671972bc5f74ca>)[#text("(1)")]#text(" can be solved using bounded operators ")#mi("{D,X \\in B(H)}")#text(" on a Hilbert space ")#mi("{H}")#text(" rather than unbounded ones. In the finite dimensional case when ")#mi("{D, X}")#text(" are just ")#mi("{n \\times n}")#text(" matrices for some ")#mi("{n \\geq 1}")#text(", the answer is clearly negative, since the left-hand side of ")#link(<tao-555706671972bc5f74ca>)[#text("(1)")]#text(" has trace zero and the right-hand side does not. What about in infinite dimensions, when the trace is not available? As it turns out, the answer is still negative, as was first worked out ")#link("https://de.wikipedia.org/wiki/Satz_von_Wintner-Wielandt")[#text("by Wintner and Wielandt")]#text(". A short proof can be given as follows. Suppose for contradiction that we can find bounded operators ")#mi("{D, X}")#text(" obeying ")#link(<tao-555706671972bc5f74ca>)[#text("(1)")]#text(". From ")#link(<tao-555706671972bc5f74ca>)[#text("(1)")]#text(" and an easy induction argument, we obtain the identity ")#metadata(none) <tao-6f74b1bfc59df8e6e2a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("[D,X^n] = n X^{n-1}")]]

#text("for all natural numbers ")#mi("{n}")#text(". From the triangle inequality, this implies that")

#align(center)[#tao-fit-display[#tao-math("n \\left\\| X^{n-1} \\right\\|_{op} \\leq 2 \\left\\|D\\right\\|_{op} \\left\\| X^n \\right\\|_{op}.", block: true)]]

#text("Iterating this, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| X \\right\\|_{op} \\leq \\frac{(2 \\left\\|D\\right\\|_{op})^{n-1}}{n!} \\left\\|X^n \\right\\|_{op}", block: true)]]

#text("for any ")#mi("{n}")#text(". Bounding ")#tao-math("{\\left\\|X^n\\right\\|_{op} \\leq \\left\\|X\\right\\|_{op}^n}", block: false)#text(" and then sending ")#mi("{n \\rightarrow \\infty}")#text(", we conclude that ")#tao-math("{\\left\\|X\\right\\|_{op}=0}", block: false)#text(", which clearly contradicts ")#link(<tao-555706671972bc5f74ca>)[#text("(1)")]#text(". (Note the argument can be generalised without difficulty to the case when ")#mi("{D,X}")#text(" lie in a Banach algebra, rather than be bounded operators on a Hilbert space.)")

#text("It was observed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=685464")[#text("by Popa")]#text(" that there is a quantitative version of this result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{D, X \\in B(H)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| [D,X] - I \\right\\|_{op} \\leq \\varepsilon", block: true)]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(". Then we have ")#metadata(none) <tao-68d8aca2273362336704>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| X \\right\\|_{op} \\left\\|D \\right\\|_{op} \\geq \\frac{1}{2} \\log \\frac{1}{\\varepsilon}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By multiplying ")#mi("{D}")#text(" by a suitable constant and dividing ")#mi("{X}")#text(" by the same constant, we may normalise ")#tao-math("{\\left\\|D\\right\\|_{op}=1/2}", block: false)#text(". Write ")#mi("{DX - XD = 1 + E}")#text(" with ")#tao-math("{\\left\\|E\\right\\|_{op} \\leq \\varepsilon}", block: false)#text(". Then the same induction that established ")#link(<tao-6f74b1bfc59df8e6e2a2>)[#text("(2)")]#text(" now shows that")

#align(center)[#tao-fit-display[#mitex("[D,X^n]= n X^{n-1} + X^{n-1} E + X^{n-2} E X + \\dots + E X^{n-1}")]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("n \\left\\| X^{n-1} \\right\\|_{op} \\leq \\left\\| X^n \\right\\|_{op} + n \\varepsilon \\left\\|X\\right\\|_{op}^{n-1}.", block: true)]]

#text("We divide by ")#mi("{n!}")#text(" and sum to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=0}^\\infty \\frac{\\left\\|X^n\\right\\|_{op}}{n!} \\leq \\sum_{n=1}^\\infty \\frac{\\left\\|X^n\\right\\|_{op}}{n!} + \\varepsilon \\exp( \\left\\|X\\right\\|_{op} )", block: true)]]

#text("giving the claim.")#linebreak()#text(" ")#mi("\\Box")

#text("Again, the argument generalises easily to any Banach algebra. Popa then posed the question of whether the quantity ")#mi("{\\frac{1}{2} \\log \\frac{1}{\\varepsilon}}")#text(" can be replaced by any substantially larger function of ")#mi("{\\varepsilon}")#text(", such as a polynomial in ")#mi("{\\frac{1}{\\varepsilon}}")#text(". As far as I know, the above simple bound has not been substantially improved.")

#text("In the opposite direction, one can ask for constructions of operators ")#mi("{X,D}")#text(" that are not too large in operator norm, such that ")#mi("{[D,X]}")#text(" is close to the identity. Again, one cannot do this in finite dimensions: ")#mi("{[D,X]}")#text(" has trace zero, so at least one of its eigenvalues must outside the disk ")#tao-math("{\\{ z: \\left|z-1\\right| < 1\\}}", block: false)#text(", and therefore ")#tao-math("{\\left\\|[D,X]-1\\right\\|_{op} \\geq 1}", block: false)#text(" for any finite-dimensional ")#mi("{n \\times n}")#text(" matrices ")#mi("{X,D}")#text(".")

#text("However, it was shown in 1965 by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=178354")[#text("Brown and Pearcy")]#text(" that in infinite dimensions, one can construct operators ")#mi("{D,X}")#text(" with ")#mi("{[D,X]}")#text(" arbitrarily close to ")#mi("{1}")#text(" in operator norm (in fact one can prescribe any operator for ")#mi("{[D,X]}")#text(" as long as it is not equal to a non-zero multiple of the identity plus a compact operator). In the above paper of Popa, a quantitative version of the argument (based in part on some earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=336361")[#text("work of Apostol and Zsido")]#text(") was given as follows. The first step is to observe the following Hilbert space version of ")#link("https://en.wikipedia.org/wiki/Hilbert%27s_paradox_of_the_Grand_Hotel")[#text("Hilbert’s hotel")]#text(": in an infinite dimensional Hilbert space ")#mi("{H}")#text(", one can locate isometries ")#mi("{u, v \\in B(H)}")#text(" obeying the equation ")#metadata(none) <tao-e6184ce10e266134fdcf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("uu^* + vv^* = 1,")]]

#text("where ")#mi("{u^*}")#text(" denotes the adjoint of ")#mi("{u}")#text(". For instance, if ")#mi("{H}")#text(" has a countable orthonormal basis ")#mi("{e_1, e_2, \\dots}")#text(", one could set")

#align(center)[#tao-fit-display[#mitex("u := \\sum_{n=1}^\\infty e_{2n-1} e_n^*")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("v := \\sum_{n=1}^\\infty e_{2n} e_n^*,")]]

#text("where ")#mi("{e_n^*}")#text(" denotes the linear functional ")#mi("{x \\mapsto \\langle x, e_n \\rangle}")#text(" on ")#mi("{H}")#text(". Observe that ")#link(<tao-e6184ce10e266134fdcf>)[#text("(4)")]#text(" is again impossible to satisfy in finite dimension ")#mi("{n}")#text(", as the left-hand side must have trace ")#mi("{2n}")#text(" while the right-hand side has trace ")#mi("{n}")#text(".")

#text("As ")#mi("{u,v}")#text(" are isometries, we have ")#metadata(none) <tao-cb66cc2d9f8afab6a0bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("v^* v = u^* u = 1;")]]

#text("Multiplying ")#link(<tao-e6184ce10e266134fdcf>)[#text("(4)")]#text(" on the left by ")#mi("{v^*}")#text(" and right by ")#mi("{u}")#text(", or on the left by ")#mi("{u^*}")#text(" and right by ")#mi("{v}")#text(", then gives ")#metadata(none) <tao-1fc90bc28ec9f84706eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("v^* u = u^* v = 0.")]]

#text("From ")#link(<tao-e6184ce10e266134fdcf>)[#text("(4)")]#text(", ")#link(<tao-cb66cc2d9f8afab6a0bc>)[#text("(5)")]#text(" we see in particular that, while we cannot express ")#mi("{1}")#text(" as a commutator of bounded operators, we can at least express it as the sum of two commutators:")

#align(center)[#tao-fit-display[#mitex("[u^*, u] + [v^*, v] =1.")]]

#text("We can rewrite this somewhat strangely as")

#align(center)[#tao-fit-display[#mitex("[\\frac{1}{2} u^*, 4u+2v] + [\\frac{1}{2} u^* - v^*, -2v] = 2")]]

#text("and hence there exists a bounded operator ")#mi("{a}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("[\\frac{1}{2} u^*, 4u+2v] = 1+a; \\quad [\\frac{1}{2} u^* - v^*, -2v] = 1-a.")]]

#text("Moving now to the Banach algebra of ")#mi("{2 \\times 2}")#text(" matrices with entries in ")#mi("{B(H)}")#text(" (which can be equivalently viewed as ")#mi("{B(H \\oplus H)}")#text("), a short computation then gives the identity")

#align(center)[#tao-fit-display[#mitex("\\left[ \\begin{pmatrix} \\frac{1}{2} u^* & 0 \\\\ a & \\frac{1}{2} u^* - v^* \\end{pmatrix}, \\begin{pmatrix} 4u+2v & 1 \\\\ 0 & -2v \\end{pmatrix} \\right] = \\begin{pmatrix} 1 & v^* \\\\ b & 1 \\end{pmatrix}")]]

#text("for some bounded operator ")#mi("{b}")#text(" whose exact form will not be relevant for the argument. Now, by Neumann series (and the fact that ")#mi("{u,v}")#text(" have unit operator norm), we can find another bounded operator ")#mi("{c}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("c + \\frac{1}{2} v c u^* = b,")]]

#text("and then another brief computation shows that")

#align(center)[#tao-fit-display[#mitex("\\left[ \\begin{pmatrix} \\frac{1}{2} u^* & 0 \\\\ a & \\frac{1}{2} u^* - v^* \\end{pmatrix}, \\begin{pmatrix} 4u+2v & 1 \\\\ vc & -2v \\end{pmatrix} \\right] = \\begin{pmatrix} 1 & v^* \\\\ 0 & 1 \\end{pmatrix}.")]]

#text("Thus we can express the operator ")#mi("{\\begin{pmatrix} 1 & v^* \\\\ 0 & 1 \\end{pmatrix}}")#text(" as the commutator of two operators of norm ")#mi("{O(1)}")#text(". Conjugating by ")#mi("{\\begin{pmatrix} \\varepsilon^{1/2} & 0 \\\\ 0 & \\varepsilon^{-1/2} \\end{pmatrix}}")#text(" for any ")#mi("{0 < \\varepsilon \\leq 1}")#text(", we may then express ")#mi("{\\begin{pmatrix} 1 & \\varepsilon v^* \\\\ 0 & 1 \\end{pmatrix}}")#text(" as the commutator of two operators of norm ")#mi("{O(\\varepsilon^{-1})}")#text(". This shows that the right-hand side of ")#link(<tao-68d8aca2273362336704>)[#text("(3)")]#text(" cannot be replaced with anything that blows up faster than ")#mi("{\\varepsilon^{-2}}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(". Can one improve this bound further?")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b3fb32aa72352038486d31f049434eff196ad792f408ec156fd19e67db02c75-7a3fed1f01111808ed340118d5339c930577c5829d66445c36572e23c1944618.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Sorry this is a little off-topic but I was wondering if have you ever considered the hat problem (")#link("https://epubs.siam.org/doi/pdf/10.1137/060652774")[#text("https://epubs.siam.org/doi/pdf/10.1137/060652774")]#text(")")#linebreak()#text(" and 100-prisoners problem (")#link("https://en.wikipedia.org/wiki/100_prisoners_problem")[#text("https://en.wikipedia.org/wiki/100_prisoners_problem")]#text(").")#linebreak()#text(" What is the bigger picture idea of these decentralized control combinatorial problems?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495904")[#strong[#text("Mir Cea")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")]

#text("Maybe the following is too naive and goes nowhere, but anyway, I ask it because the answer is not clear to me. Maybe it has some clarificatory power, regarding whether in the hilbert hotel analogue you presented, it is better or worse, to e.g. move 2/3 of the people three times, rather than 1/2 of the people twice… So the question is: in what sense is it true that applying the same thing you did for two isometries u, v, for say 3 isometries u,v,w, is not going to improve the outcome bound?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495912")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("This could well be worth trying. One model problem would be to try to optimise the numerical constant is in the ")#mi("O(\\varepsilon^{-2})")#text(" example. If it turns out that using a different version of the “Hilbert’s hotel” trick gives better numerical constants, it could suggest a direction in which to improve the construction to eventually get an ")#mi("o(\\varepsilon^{-2})")#text(" bound.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495906")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Equivalently, we can phrase the problem like this: given the constraints ")#tao-math("\\left\\|X\\right\\| \\leq C", block: false)#text(" and ")#tao-math("\\left\\| D \\right\\| \\leq C", block: false)#text(", how small can ")#tao-math("\\left\\| [D,X] - I \\right\\|", block: false)#text(" be made?")

#text("Since ")#tao-math("\\left\\| X\\right\\| \\leq C", block: false)#text(" is equivalent to ")#mi("CI - X^*X \\geq 0")#text(", this is a problem of ")#link("https://www.math.auckland.ac.nz/~igorklep/Sosh_book_rev1_submitted.pdf")[#text("noncommutative polynomial optimization")]#text(", and therefore there is a convergent sequence of (larger and larger) semidefinite programs that gives us the answer for each value of ")#mi("C")#text(".")

#text("At least in principle, these semidefinite programs can not only be solved numerically, but even symbolically. I will try to work out what these semidefinite programs look like, in case that somebody wants to do some computations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495917")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("So here is the proposal in a bit more detail. This is a computer-assisted search, as has also been suggested by Will Sawin, in a systematic form. And Will, you’re right, this approach is for the operators on Hilbert space case.")

#text("Suppose we want start with ")#mi("\\epsilon > 0")#text(" and ")#mi("C>0")#text(", and to know whether there are operators ")#mi("X")#text(" and ")#mi("D")#text(" on some nonzero Hilbert space such that ")#tao-math("\\left\\|X\\right\\|, \\left\\|D\\right\\|\\leq C", block: false)#text(" and ")#tao-math("\\left\\| [D,X] - I \\right\\| \\leq \\epsilon", block: false)#text(". For the purposes of the following, it is helpful to rewrite these constraints as")#linebreak()#text(" ")#mi("C^2 I - X^* X \\geq 0, \\qquad C^2 I - D^*D \\geq 0,")#linebreak()#text(" and similarly")#linebreak()#text(" ")#mi("\\epsilon I - ([D,X] - I)^*([D,X]-I).")#linebreak()#text(" The left-hand sides of these constraints are noncommutative polynomials ")#mi("q_1,q_2,q_3 \\in \\mathbb{C}\\langle X,X^*,D,D^*\\rangle")#text(". Their particular form is not terribly relevant for the following.")

#text("I will roughly follow the exposition of ")#link("https://arxiv.org/abs/0903.4368")[#text("this paper")]#text(" in order to sketch the method. Given a vector ")#mi("\\phi")#text(" in the Hilbert spaces on which these operators act, the moment matrix ")#mi("(M_{v,w})")#text(" is an infinite matrix indexed by all monomials ")#mi("v,w\\in \\mathbb{C}\\langle X,X^*,D,D^*\\rangle")#text(", taking the form")#linebreak()#text(" ")#mi("M_{v,w} = \\langle v\\phi, w\\phi\\rangle")#linebreak()#text(" for some unit vector ")#mi("\\phi")#text(" in the Hilbert space on which these polynomials act; the particular choice of ")#mi("\\phi")#text(" is not important. As a Gram matrix, this moment matrix is positive semidefinite. Moreover, assuming satisfaction of the above constraints, also the matrix ")#mi("(\\langle v\\phi,q_i w\\phi\\rangle)_{v,w}")#text(" is positive semidefinite for each ")#mi("i")#text(". By writing ")#mi("q_i")#text(" as a sum of monomials, the entries of these new matrices are linear combinations of the entries of ")#mi("M")#text(".")

#text("So given operators ")#mi("X")#text(" and ")#mi("D")#text(" satisfying the constraints, we get an infinite positive semidefinite matrix ")#mi("M")#text(" for which a bunch of linearly transformed matrices are also positive semidefinite. The main punchline is that the converse is also true: given positive semidefinite ")#mi("M")#text(" such that the linearly transformed matrices are still positive, then there are operators ")#mi("X")#text(" and ")#mi("D")#text(" satisfying the constraints: simply introduce a scalar product on ")#mi("\\mathbb{C}\\langle X,X^*,D,D^*\\rangle")#text(", introduce the inner product given by the sesquilinear extension of ")#mi("\\langle v,w\\rangle := M_{v,w}")#text(", divide by the null space, and complete. ")#mi("X")#text(" and ")#mi("D")#text(" operate on this Hilbert space in the obvious way by left multiplication. (This is the GNS construction.)")

#text("In order to get a sequence of SDPs, one truncates ")#mi("M")#text(" by restricting to a finite subset of monomials.")

#text("In this formulation, I can only test whether given ")#mi("C")#text(" and ")#mi("\\epsilon")#text(" can be realized jointly, and this boils down to a sequence of semidefinite satisfiability problems. I guess that optimizing over one while fixing the other will be a sequence of SDP optimization problems, but I’m not yet sure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495923")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Here’s an attempt at concretely formulating one of these semidefinite relaxations, namely for the truncation corresponding to the set of monomials ")#mi("\\{1,X,D,XD,DX\\}")#text(".")

#text("One needs to find a 5×5 positive semidefinite matrix ")#mi("M")#text(" subject to ")#mi("M_{1,1} = 1")#text(", and subject to positive semidefiniteness of the following two matrices:")#linebreak()#text(" ")#mi("\\begin{pmatrix} C^2 - M_{2,2} & C^2 M_{1,3} - M_{2,4} \\\\ C^2 M_{3,1} - M_{4,2} & C^2 M_{3,3} - M_{4,4} \\end{pmatrix},")#linebreak()#text(" ")#mi("\\begin{pmatrix} C^2 - M_{3,3} & C^2 M_{1,2} - M_{3,5} \\\\ C^2 M_{2,1} - M_{5,3} & C^2 M_{2,2} - M_{5,5} \\end{pmatrix}.")#linebreak()#text(" Due to the absence of complex numbers in the constraints, it’s enough to assume ")#mi("M")#text(" to be real. Under this assumption, the objective function is to minimize ")#mi("1 + M_{5,5} + M_{4,4} - 2(M_{1,4} + M_{1,5} + M_{4,5})")#text(". The resulting optimal value should be a lower bound on ")#tao-math("\\left\\|[D,X] - I\\right\\|^2", block: false)#text(" in terms of ")#mi("C")#text(".")

#text("However, it’s possible that this truncation is so bad that the resulting lower bound may be negative. Also, it’s very likely that I have a calculation error somewhere, leading to a nonsensical result. It would be much easier if it was possible to set this up directly as a noncommutative polynomial optimization problem in ")#link("http://ncsostools.fis.unm.si/")[#text("NCSOStools")]#text(", but I’m not sure whether the problem is of a form that this toolbox can deal with. (It’s more standard to try and ")#emph[#text("maximize")]#text(" operator norms!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-496192")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("It seems that my calculations above were correct, and I have implemented this semidefinite program in the meantime. Unfortunately, my fears turned out to be justified: the resulting lower bounds on ")#tao-math("\\left\\|[D,X] - I\\right\\|^2", block: false)#text(" are negative.")

#text("Nevertheless, using NCSOStools, I am now able to probe whether there exist operators satisfying ")#tao-math("\\left\\|[D,X] - I\\right\\| \\leq \\epsilon", block: false)#text(" and ")#tao-math("\\left\\|D\\right\\|,\\left\\|X\\right\\|\\leq C", block: false)#text(" for any given pair of values ")#mi("(C,\\epsilon)")#text(". Thanks to the convergence as the SDP size goes to infinity, the program will exclude (with enough time and memory) every pair of values that cannot be realized.")

#text("The computations that I have done so far seem to suggest that ")#tao-math("\\left\\| [D,X] - I\\right\\| < 1", block: false)#text(" is impossible ")#emph[#text("at all")]#text(", no matter how large the bounds on ")#tao-math("\\left\\|D\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|X\\right\\|", block: false)#text(" are. Since this contradicts already the Brown-Pearcy result, I have very low confidence in this claim, especially as the SeDuMi solver returns a “Run into numerical problems” message. Could somebody with more experience with SDPs look into this? My Matlab script is ")#link("https://pastebin.com/eZE0fv9W")[#text("here")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495908")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("For fixed values of ")#tao-math("\\left|\\left| X\\right|\\right|_{op}", block: false)#text(", ")#tao-math("\\left|\\left|D\\right|\\right|_{op}", block: false)#text(", Popa’s quantitative bound can be truncated to a finite one with only a small loss in the bound on ")#mi("\\epsilon")#text(". Moreover I think if any tuple of values ")#tao-math("\\left|\\left|D\\right|\\right|_{op}, \\left|\\left|X\\right|\\right|_{op}, \\epsilon", block: false)#text(" is impossible for Banach algebras, there is an argument of this type with finitely many terms that disproves it: Otherwise, take the free algebra on ")#mi("X,D,E")#text(", with the obvious norm, and mod out by the closure of the two-sided ideal generated by ")#mi("[X,D]-1-E")#text(", which does not contain any element within ")#mi("1")#text(" of the identity.")

#text("So perhaps this problem, like the previous one on word norms, is amenable to computer search to find new such arguments, followed by human interpretation to consolidate gains?")

#text("The simplest form of the game would be to find identities implied by the equation ")#mi("[X,D]=1+E")#text(" of the form ")#mi("1 =")#text(" a term that, when ")#mi("X,D")#text(" are replaced with ")#mi("M")#text(" and ")#mi("E")#text(" replaced with ")#mi("\\epsilon")#text(", and all subtractions signs removed, would produce a number smaller than ")#mi("1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Will, could you elaborate on what the “obvious norm” is? I tried using the spectral radius but could not verify the additivity. In any event I do agree that the problem has a similar feel to Polymath14 and a computer assisted search for bounds may well be the way forward.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495915")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("I was thinking of the least norm on the free algebra where ")#mi("X,D")#text(" have norm ")#mi("\\leq M")#text(" and ")#mi("E")#text(" has norm ")#mi("\\leq \\epsilon")#text(". The norm of an element is then the minimum over algebraic expressions in ")#mi("X,D,\\epsilon")#text(" for that element of the “obvious” norm of that expression. It’s equivalent to view this as the ")#mi("l^1")#text(" norm where each monomial has measure the product of the norms of its elements.")

#text("My idea is very similar to Tobias Fritz’s. I think the only difference is his works for algebras of operators on Hilbert spaces, while mine should work for arbitrary Banach algebras, and his involves semidefinite programming while mine would involve linear programming.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("OK, I see what you’re saying now, thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Here is a model problem one could try to attack numerically. Let’s forget about ")#mi("E")#text(" for now and try proving a lower bound on ")#tao-math("\\left\\| D \\right\\|_{op} \\left\\| X \\right\\|_{op}", block: false)#text(" assuming ")#mi("[D,X]=1")#text(", in which one is only “allowed” to use words in ")#mi("D,X")#text(" of a fixed length ")#mi("2n")#text(" (involving ")#mi("n")#text(" copies of ")#mi("D")#text(" and ")#mi("n")#text(" copies of ")#mi("X")#text(" – note from the scaling symmetry ")#mi("D \\mapsto \\lambda D, X \\mapsto \\lambda^{-1} X")#text(" that the powers of ")#mi("X,D")#text(" have to be in balance). For instance, one can rewrite the Wintner-Wielandt argument by observing the identity")

#mi("1 = \\frac{1}{n!} [D,[D,\\dots,[D,X^n]\\dots]")

#text("assuming ")#mi("[D,X]=1")#text(", where there are ")#mi("n")#text(" iterated commutators; expanding this out into noncommutative monomials of degree ")#mi("(n,n)")#text(" in ")#mi("(D,X)")#text(", we conclude")

#tao-math("1 \\leq \\frac{1}{n!} 2^n \\left\\|D\\right\\|^n \\left\\|X\\right\\|^n", block: false)

#text("in any Banach algebra norm. But is ")#mi("\\frac{2^n}{n!}")#text(" best possible here? In other words, for given ")#mi("n")#text(", what is the minimal ")#mi("\\ell^1")#text(" norm of the coefficients of a homogeneous noncommutative polynomial ")#mi("P(X,D)")#text(" of degree ")#mi("(n,n)")#text(" that evaluates to ")#mi("1")#text(" when ")#mi("[D,X]=1")#text("? Presumably one could actually work this out numerically for small values of ")#mi("n")#text(" through linear algebra (there are ")#mi("\\binom{2n}{n}")#text(" noncommutative monomials, which after applying ")#mi("[D,X]")#text(" can be expressed in terms of the basis ")#mi("X^jD^j")#text(" for ")#mi("j=0,\\dots,n")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495980")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("This is sharp if and only if for each homogeneous noncommutative monomial of degree ")#mi("n")#text(", ")#tao-math("\\left| \\sum_{i=0}^n c_i (-1)^i 2^{-i} i! \\right| \\leq n!/2^n", block: false)#text(", where ")#mi("c_i")#text(" is the coefficient of ")#mi("X^i D^i")#text(" in the canonical form of the monomial. (If direction by linearity, only if by writing ")#mi("X^i D^i")#text(" as a linear combination of the monomials ")#mi("D^a X^n D^{n-a}")#text(" that appear in the iterated commutators expression ).")

#text("I believe I have checked this for ")#mi("n \\leq 3")#text(" but first I disproved it several times so I can’t be completely sure.")

#text("Noncommutative polynomials with equal degree in ")#mi("X")#text(" and ")#mi("D")#text(" are actually a commutative ring, generated by $XD$. To understand this function on monomials analytically it would be helpful to understand what it looks like in the basis of powers of $XD$, but I haven’t managed this yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("It looks like of all the noncommutative monomials of degree ")#mi("(n,n)")#text(", when expressed in terms of the basis ")#mi("X^i D^i")#text(" for ")#mi("i=0,\\dots,n")#text(", the coefficient of 1 never exceeds ")#mi("n!")#text(" (attained for ")#mi("D^n X^n")#text("). This suggests to me that the best inequality one could ever hope for using degree ")#mi("(n,n)")#text(" monomials for ")#mi("[D,X]=1")#text(" is ")#tao-math("1 \\leq n! \\left\\|D\\right\\|^n \\left\\| X\\right\\|^n", block: false)#text(", thus to get a bound of the form ")#tao-math("\\left\\|D\\right\\| \\left\\|X\\right\\| \\geq R", block: false)#text(" one would need to use monomials of degree ")#mi("\\gg R")#text(". Given that ")#mi("n!/2^n")#text(" is not so much smaller than ")#mi("n!")#text(", this also hints that Popa’s lower bound is perhaps sharp except for the constant.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495998")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("One thing that remains is to explain why to finish the argument in the ")#mi("\\epsilon")#text(" setting requires using the bounds for each value of ")#mi("n")#text(" simultaneously, so that a term like ")#mi("\\epsilon e^R")#text(" appears in the final bound, rather than just an individual term ")#mi("\\epsilon R^n /n!")#text(" (where we could take ")#mi("n")#text(" much larger than ")#mi("R")#text(".)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b43e70ec4656a6524c00abcf2b93c105d86f5730dc5135896d57a653373cdbf-f9f0d976fdce5387ed9916ffa53800fa3c73a79d688a51413d7ab0059bfb1dde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495918")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Thanks for this interesting post. In the proof of Theorem 1, I think you get")

#tao-math("\\displaystyle n \\left\\| X^{n-1} \\right\\|_{op} \\leq \\left\\| X^n \\right\\|_{op} + \\varepsilon n \\left\\|X\\right\\|_{op}^{n-1}", block: false)

#text("before dividing by ")#mi("n!")#text(" and summing from ")#mi("1")#text(" to ")#mi("\\infty")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495979")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("Let ")#mi("n")#text(" be a positive integer and ")#mi("R")#text(" a ring of characteristic ")#mi("n")#text(". The identity matrix of ")#mi("R^{n\\times n}")#text(" has trace ")#mi("n")#text(", but in ")#mi("R")#text(" it is equal to zero, so in principle it is possible to find matrices ")#mi("D,X\\in R^{n\\times n}")#text(" such that ")#mi("[D,X]=1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("What about operators satisfying ")#mi("[u^*,u]+[v^*,v]=1")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-495991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("More exactly, my questión is the following, are they necessarily isometries? In the negative case, what can we say about their invariant subspaces?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-496116")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("One could conceivably build a sequence of examples showing that Popa’s bound is essentially sharp through a recursive construction. For instance, if whenever one can solve ")#mi("[D,X] = 1 + E")#text(" with ")#tao-math("\\left\\| D \\right\\| \\left\\|X\\right\\| \\ll \\log \\frac{1}{\\varepsilon}", block: false)#text(" and ")#tao-math("\\left\\|E \\right\\| \\ll \\varepsilon", block: false)#text(", one can somehow create new operators ")#mi("\\tilde D, \\tilde X, \\tilde E")#text(" (possibly matrix combinations of the existing ones) with ")#mi("[\\tilde D, \\tilde X] = 1 + \\tilde E")#text(", ")#tao-math("\\left\\|\\tilde D\\right\\| \\left\\| \\tilde X\\right\\| \\leq \\left\\| D \\right\\| \\left\\|X\\right\\| + O(1)", block: false)#text(" and ")#tao-math("\\left\\|\\tilde E\\right\\| \\ll \\varepsilon^2 \\log^{O(1)} \\frac{1}{\\varepsilon}", block: false)#text(", then one can iterate (starting from an example with ")#mi("\\varepsilon")#text(" small enough) to show that Popa’s bound is sharp up to constants. Maybe a variant of the 2 x 2 matrix construction in the blog post would work for this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d395ef3574c5e73f7e28049a2f7fbfe0b874a589e1ee3d7b117cb5da3f9a658-ad5b2a8dcd9573400472d15e5b3c8fa91e7ca5aa3eb54dad65d01128662c5eb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-496142")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("There is something that confuses me in the construction sketched in the second part of the post. I have been able to verify the first commutator equation involving the 2×2-matrices, but I am unable to follow the second one. I’m getting that the relevant equation for ")#mi("c")#text(" is ")#mi("\\tfrac{1}{2}[u^*,c]-v^*c + b = 0")#text(". Is this supposed to be implied by ")#mi("c + \\tfrac{1}{2}vcu^* = b")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-496204")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Oops, there was a typo; ")#mi("c")#text(" should have been ")#mi("vc")#text(". Fixed now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Commutators close to the identity – an update | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-500428")[#strong[#text("Commutators close to the identity – an update | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("[…] of Operator Theory. This paper resulted from some progress I made on the problem discussed in this previous post. Recall in that post the following result of Popa: if are bounded operators on a Hilbert space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-500454")[#strong[#text("246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("[…] of Operator Theory. This paper resulted from some progress I made on the problem discussed in this previous post. Recall in that post the following result of Popa: if are bounded operators on a Hilbert space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e5c404e498dc3517cd92635b8e9ebcd5467739cac5683f7d6a33a364cec6768-302b33873aba5b17fbd6a447c1b8966ea527a028edf1313fc95dc91065cd41d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-503679")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2018")])]

#text("Has the following generalization of Theorem 1 been considered:")

#text("Suppose ")#mi("X, D \\in S_p(H)")#text(" for some ")#mi("p \\geq 1")#text(" where ")#mi("S_p(H)")#text(" is the Schatten space. Does there exist a real valued function ")#mi("f_p(x)")#text(" such that if ")#tao-math("\\left|\\left| [D, X] - I \\right|\\right|_p \\leq \\epsilon", block: false)#text(" then ")#tao-math("\\left|\\left|D\\right|\\right|_p, \\left|\\left|X\\right|\\right|_p \\geq f_p(\\epsilon)", block: false)#text(" where ")#mi("\\lim_{\\epsilon \\to 0+}=\\infty")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-503680")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2018")])]

#text("I’m not sure I am fully understanding your question, but if ")#mi("X,D \\in S_p(H)")#text(" for some ")#mi("p < \\infty")#text(" then ")#mi("X,D")#text(" are compact, hence ")#mi("[D,X]")#text(" will be also, and so ")#mi("[D,X]")#text(" will contain spectrum at 0. In particular ")#tao-math("\\left\\| [D,X] - I \\right\\|_p", block: false)#text(" will always be at least 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e5c404e498dc3517cd92635b8e9ebcd5467739cac5683f7d6a33a364cec6768-302b33873aba5b17fbd6a447c1b8966ea527a028edf1313fc95dc91065cd41d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/#comment-505885")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")])]

#text("Thank you for pointing this out. Can’t we view problem in the setting of a von Neumann algebra equipped with a (n.s.f) trace?")
]
]
]
