// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/22/freimans-theorem-in-finite-fields-via-extremal-set-theory/
// Converted to Typst by tao2typ: "2026-10-13T06:05:04.985564+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Freiman’s theorem in finite fields via extremal set theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set par(justify: true, leading: 0.65em, spacing: 0.9em)
#set heading(numbering: none)
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#text(size: 23pt, weight: "semibold")[#text("Freiman’s theorem in finite fields via extremal set theory")]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/22/freimans-theorem-in-finite-fields-via-extremal-set-theory/")[#text("https://terrytao.wordpress.com/2007/03/22/freimans-theorem-in-finite-fields-via-extremal-set-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" and I have just uploaded the paper “")#link("http://arxiv.org/abs/math.CO/0703668")[#text("Freiman’s theorem in finite fields via extremal set theory")]#text("” to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(", which we have submitted to ")#link("http://www.cambridge.org/journals/journal_catalogue.asp?mnemonic=cpc")[#text("Combinatorics, Probability, and Computing")]#text(". This paper is our third regarding various refinements of Freiman’s theorem; the ")#link("http://arxiv.org/abs/math.NT/0511069")[#text("first one")]#text(" concerned approximating a set of small doubling in a torsion-free group by a progression of really small rank using compressions and convex geometry, while the ")#link("http://arxiv.org/abs/math.CO/0701585")[#text("second one")]#text(" obtained an intersection version of Freiman’s theorem (and the Balog-Szemerédi-Gowers theorem) in the 2-torsion case using an induction-on-dimension argument. Here, we return to compressions to obtain particularly sharp bounds on Freiman’s theorem in the 2-torsion case, and in particular getting some partial results on the ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("polynomial Freiman-Ruzsa conjecture")]#text(". Specifically, we show that if ")#mi("A \\subset {\\Bbb F}_2^n")#text(" has doubling constant at most K, thus ")#mi("|A+A| \\leq K|A|")#text(", then A can be contained in an affine subspace of cardinality at most ")#mi("2^{2K + O(\\sqrt{K} \\log K)} |A|")#text(". Except for the O() factor, this is sharp. If in addition A is a downset, we show that A can be covered by ")#mi("O(K^{46})")#text(" translates of a coordinate subspace of cardinality at most |A|. (The constant 46 is definitely not best possible, though we show that it cannot be lowered to below 1.46.) In particular, this settles the polynomial Freiman-Ruzsa conjecture in the case when the set is a downset.")

#text("The main ideas are to use ideas from extremal set systems theory, notably the method of compressions (as used for instance by ")#link("http://www.ams.org/mathscinet-getitem?mr=1425777")[#text("Bollobás")#text(" and Leader")]#text(") and of shifts (as used for instance by ")#link("http://www.ams.org/mathscinet-getitem?mr=905277")[#text("Frankl")]#text("). Using all this machinery, things eventually reduce to understanding sumsets of a very structured class of sets – the ")#emph[#text("shift-minimal downsets")]#text(" – and their relationship with Hamming balls. This in turn ultimately rests on a certain “gamblers’ ruin” problem already considered by Frankl.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/22/freimans-theorem-in-finite-fields-via-extremal-set-theory/#comment-5157")[#strong[#text("Dyadic models « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2007")

#text("[…] and to use tools related to such flags such as the combinatorial technique of compression. See this previous blog post for some examples of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/22/freimans-theorem-in-finite-fields-via-extremal-set-theory/#comment-32785")[#strong[#text("Extremal Combinatorics IV: Shifting « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2008")

#text("[…] or “compression” (for an application to additive number theory look at this post by Terry […]")
]
