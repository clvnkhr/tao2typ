// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/
// Converted to Typst by tao2typ: "2026-10-14T15:17:37.561417+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some notes on group extensions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some notes on group extensions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/")[#text("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In mathematics, one frequently starts with some space ")#mi("{X}")#text(" and wishes to ")#emph[#text("extend")]#text(" it to a larger space ")#mi("{Y}")#text(". Generally speaking, there are two ways in which one can extend a space ")#mi("{X}")#text(":")

#list(
[#text("By ")#link("http://en.wikipedia.org/wiki/Embedding")[#text("embedding")]#text(" ")#mi("{X}")#text(" into a space ")#mi("{Y}")#text(" that has ")#mi("{X}")#text(" (or at least an isomorphic copy of ")#mi("{X}")#text(") as a ")#link("http://en.wikipedia.org/wiki/Subspace")[#text("subspace")]#text(".")],
[#text("By ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("covering")]#text(" ")#mi("{X}")#text(" by a space ")#mi("{Y}")#text(" that has ")#mi("{X}")#text(" (or an isomorphic copy thereof) as a ")#link("http://en.wikipedia.org/wiki/Quotient_space")[#text("quotient")]#text(".")]
)

#text("For many important categories of interest (such as ")#link("http://en.wikipedia.org/wiki/Abelian_category")[#text("abelian categories")]#text("), the former type of extension can be represented by the ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("exact sequence")]#text(",")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow X \\rightarrow Y")]]

#text("and the latter type of extension be represented by the exact sequence")

#align(center)[#tao-fit-display[#mitex("Y \\rightarrow X \\rightarrow 0.")]]

#text("In some cases, ")#mi("{X}")#text(" can be both embedded in, and covered by, ")#mi("{Y}")#text(", in a consistent fashion; in such cases we sometimes say that the above exact sequences ")#emph[#text("split")]#text(".")

#text("An analogy would be to that of digital images. When a computer represents an image, it is limited both by the scope of the image (what it is picturing), and by the resolution of an image (how much physical space is represented by a given pixel). To make the image “larger”, one could either ")#emph[#text("embed")]#text(" the image in an image of larger scope but equal resolution (e.g. embedding a picture of a ")#mi("{200 \\times 200}")#text(" pixel image of person’s face into a ")#mi("{800 \\times 800}")#text(" pixel image that covers a region of space that is four times larger in both dimensions, e.g. the person’s upper body) or ")#emph[#text("cover")]#text(" the image with an image of higher resolution but of equal scope (e.g. enhancing a ")#mi("{200 \\times 200}")#text(" pixel picture of a face to a ")#mi("{800 \\times 800}")#text(" pixel of the same face). In the former case, the original image is a ")#emph[#text("sub-image")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Cropping")[#text("cropped image")]#text(") of the extension, but in the latter case the original image is a ")#emph[#text("quotient")]#text(" (or a ")#link("http://en.wikipedia.org/wiki/Pixelation")[#text("pixelation")]#text(") of the extension. In the former case, each pixel in the original image can be identified with a pixel in the extension, but not every pixel in the extension is covered. In the latter case, every pixel in the original image is ")#emph[#text("covered")]#text(" by several pixels in the extension, but the pixel in the original image is not canonically identified with any particular pixel in the extension that covers it; it “loses its identity” by dispersing into higher resolution pixels.")

#text("(Note that “zooming in” the visual representation of an image by making each pixel occupy a larger region of the screen neither increases the scope or the resolution; in this language, a zoomed-in version of an image is merely an ")#emph[#text("isomorphic copy")]#text(" of the original image; it carries the same amount of information as the original image, but has been represented in a new ")#emph[#text("coordinate system")]#text(" which may make it easier to view, especially to the visually impaired.)")

#text("In the study of a given category of spaces (e.g. topological spaces, manifolds, groups, fields, etc.), embedding and coverings are both important; this is particularly true in the more topological areas of mathematics, such as manifold theory. But typically, the term ")#emph[#text("extension")]#text(" is reserved for just one of these two operations. For instance, in the category of fields, coverings are quite trivial; if one covers a field ")#mi("{k}")#text(" by a field ")#mi("{l}")#text(", the kernel of the covering map ")#mi("{\\pi: l \\rightarrow k}")#text(" is necessarily trivial and so ")#mi("{k, l}")#text(" are in fact isomorphic. So in field theory, a ")#emph[#text("field extension")]#text(" refers to an embedding of a field, rather than a covering of a field. Similarly, in the theory of metric spaces, there are no non-trivial isometric coverings of a metric space, and so the only useful notion of an extension of a metric space is the one given by embedding the original space in the extension.")

#text("On the other hand, in group theory (and in group-like theories, such as the theory of dynamical systems, which studies group actions), the term “extension” is reserved for coverings, rather than for embeddings. I think one of the main reasons for this is that coverings of groups automatically generate a special type of embedding (a ")#link("http://en.wikipedia.org/wiki/Normal_subgroup")[#text("normal")]#text(" embedding), whereas most embeddings don’t generate coverings. More precisely, given a group extension ")#mi("{G}")#text(" of a base group ")#mi("{H}")#text(",")

#align(center)[#tao-fit-display[#mitex("G \\rightarrow H \\rightarrow 0,")]]

#text("one can form the ")#link("http://en.wikipedia.org/wiki/Kernel_(mathematics)")[#text("kernel")]#text(" ")#mi("{K = \\text{ker}(\\phi)}")#text(" of the covering map ")#mi("{\\pi: G \\rightarrow H}")#text(", which is a normal subgroup of ")#mi("{G}")#text(", and we thus can extend the above sequence canonically to a ")#link("http://en.wikipedia.org/wiki/Exact_sequence")[#text("short exact sequence")]

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0.")]]

#text("On the other hand, an embedding of ")#mi("{K}")#text(" into ")#mi("{G}")#text(",")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G")]]

#text("does not similarly extend to a short exact sequence unless the the embedding is normal.")

#text("Another reason for the notion of extension varying between embeddings and coverings from subject to subject is that there are various natural ")#emph[#text("duality operations")]#text(" (and more generally, ")#link("http://en.wikipedia.org/wiki/Functor")[#text("contravariant functors")]#text(") which turn embeddings into coverings and vice versa. For instance, an embedding of one vector space ")#mi("{V}")#text(" into another ")#mi("{W}")#text(" induces a covering of the ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("dual space")]#text(" ")#mi("{V^*}")#text(" by the dual space ")#mi("{W^*}")#text(", and conversely; similarly, an embedding of a locally compact abelian group ")#mi("{H}")#text(" in another ")#mi("{G}")#text(" induces a covering of the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual")]#text(" ")#mi("{\\hat H}")#text(" by the Pontryagin dual ")#mi("{\\hat G}")#text(". In the language of images, embedding an image in an image of larger scope is largely equivalent to covering the Fourier transform of that image by a transform of higher resolution, and conversely; this is ultimately a manifestation of the basic fact that frequency is inversely proportional to wavelength.")

#text("Similarly, a common duality operation arises in many areas of mathematics by starting with a space ")#mi("{X}")#text(" and then considering a space ")#mi("{C(X)}")#text(" of functions on that space (e.g. continuous real-valued functions, if ")#mi("{X}")#text(" was a topological space, or in more algebraic settings one could consider homomorphisms from ")#mi("{X}")#text(" to some fixed space). Embedding ")#mi("{X}")#text(" into ")#mi("{Y}")#text(" then induces a covering of ")#mi("{C(X)}")#text(" by ")#mi("{C(Y)}")#text(", and conversely, a covering of ")#mi("{X}")#text(" by ")#mi("{Y}")#text(" induces an embedding of ")#mi("{C(X)}")#text(" into ")#mi("{C(Y)}")#text(". Returning again to the analogy with images, if one looks at the collection of ")#emph[#text("all")]#text(" images of a fixed scope and resolution, rather than just a single image, then increasing the available resolution causes an ")#emph[#text("embedding")]#text(" of the space of low-resolution images into the space of high-resolution images (since of course every low-resolution image is an example of a high-resolution image), whereas increasing the available scope causes a ")#emph[#text("covering")]#text(" of the space of narrow-scope images by the space of wide-scope images (since every wide-scope image can be ")#emph[#text("cropped")]#text(" into a narrow-scope image). Note in the case of images, that these extensions can be split: not only can a low-resolution image be viewed as a special case of a high-resolution image, but any high-resolution image can be ")#link("http://en.wikipedia.org/wiki/Pixelation")[#text("pixelated")]#text(" into a low-resolution one. Similarly, not only can any wide-scope image be cropped into a narrow-scope one, a narrow-scope image can be extended to a wide-scope one simply by filling in all the new areas of scope with black (or by using more advanced image processing tools to create a more visually pleasing extension). (In the category of sets, the statement that every covering can be split is precisely the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(".)")

#text("I’ve recently found myself having to deal quite a bit with group extensions in my research, so I have decided to make some notes on the basic theory of such extensions here. This is utterly elementary material for a group theorist, but I found this task useful for organising my own thoughts on this topic, and also in pinning down some of the jargon in this field.")

#metadata(none) <tao-e8a0b24dff95103d5226>

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Group extension)")]#text(" An ")#emph[#text("extension")]#text(" of a group ")#mi("{H}")#text(" is a group ")#mi("{G}")#text(", together with a surjective ")#emph[#text("projection map")]#text(" (or ")#emph[#text("covering map")]#text(") ")#mi("{\\pi: G \\rightarrow H}")#text(". If the kernel of ")#mi("{\\pi}")#text(" can be identified with (i.e. is isomorphic to) a group ")#mi("{K}")#text(", we say that ")#mi("{G}")#text(" is an ")#emph[#text("extension")]#text(" of ")#mi("{H}")#text(" by ")#mi("{K}")#text(", and we have the short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0.")]]

#text("If the group ")#mi("{K}")#text(" has some property ")#mi("{{\\mathcal P}}")#text(", we say that ")#mi("{G}")#text(" is a ")#mi("{{\\mathcal P}}")#text(" extension of ")#mi("{H}")#text(". Thus for instance, if ")#mi("{K}")#text(" is abelian, ")#mi("{G}")#text(" is an abelian extension of ")#mi("{H}")#text("; if ")#mi("{K}")#text(" is central (in ")#mi("{G}")#text("), ")#mi("{G}")#text(" is a central extension of ")#mi("{H}")#text("; and so forth. (Note that all extensions are automatically normal extensions, so we will almost never use the latter term.) We refer to ")#mi("{H}")#text(" as the ")#emph[#text("base")]#text(" of the extension, and ")#mi("{K}")#text(" as the ")#emph[#text("fibre")]#text(", and refer to ")#mi("{H}")#text(" and ")#mi("{K}")#text(" collectively as ")#emph[#text("factors")]#text(" of ")#mi("{G}")#text(".")

#text("If ")#mi("{K}")#text(" has some property ")#mi("{{\\mathcal P}}")#text(", and ")#mi("{H}")#text(" has some property ")#mi("{{\\mathcal Q}}")#text(", then we say that ")#mi("{G}")#text(" is ")#emph[#mi("{{\\mathcal P}}")#text("-by-")#mi("{{\\mathcal Q}}")]#text(". (I have no idea why the order is traditionally arranged in this way; I would have thought that extending a ")#mi("{{\\mathcal Q}}")#text(" group by a ")#mi("{{\\mathcal P}}")#text(" group would give a ")#mi("{{\\mathcal P}}")#text("-by-")#mi("{{\\mathcal Q}}")#text(" group, rather than the other way around; perhaps at one point the idea of a normal embedding was considered more important than a group extension. Nevertheless, the notation seems to be entrenched by now.) Thus, for instance, ")#mi("{G}")#text(" is abelian-by-finite if ")#mi("{K}")#text(" is abelian and ")#mi("{H}")#text(" is finite, but finite-by-abelian if ")#mi("{K}")#text(" is finite and ")#mi("{H}")#text(" is abelian.")
]

#text("One can think of a ")#mi("{K}")#text("-by-")#mi("{H}")#text(" group as a group that looks like ")#mi("{H}")#text(" “at large scales” and like ")#mi("{K}")#text(" “at small scales”; one can also view this group as a principal ")#mi("{K}")#text("-bundle over ")#mi("{H}")#text(".")

#text("There are several ways to generate a group extension ")#mi("{G \\rightarrow H \\rightarrow 0}")#text(". Firstly, given any homomorphism ")#mi("{\\pi: G \\rightarrow G^{\\prime}}")#text(" from one group ")#mi("{G}")#text(" to another, the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_on_homomorphisms")[#text("homomorphism theorem")]#text(" tells us that ")#mi("{G}")#text(" is an extension of the image ")#mi("{\\pi(G)}")#text(", with kernel ")#mi("{\\text{ker}(\\pi)}")#text(":")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow \\text{ker}(\\pi) \\rightarrow G \\rightarrow \\pi(G) \\rightarrow 0.")]]

#text("Of course, every group extension arises in this manner.")

#text("A group extension ")#mi("{\\pi: G \\rightarrow H}")#text(" ")#emph[#text("splits")]#text(" if there is a homomorphism ")#mi("{\\phi: H \\rightarrow G}")#text(" such that ")#mi("{\\pi(\\phi(h)) = h}")#text(" for all ")#mi("{h \\in H}")#text(". In this case, ")#mi("{H}")#text(" acts on the kernel ")#mi("{K}")#text(" by conjugation (after identifying ")#mi("{H}")#text(" with ")#mi("{\\phi(H)}")#text("); denoting this action by ")#mi("{\\rho}")#text(" (thus ")#mi("{\\rho(h) k := \\phi(h) k \\phi(h)^{-1}}")#text("), we can then canonically identify ")#mi("{G}")#text(" with the ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semi-direct product")]#text(" ")#mi("{K \\rtimes_\\rho H}")#text(", defined as the set of pairs ")#mi("{(k,h)}")#text(" with ")#mi("{k \\in K}")#text(", ")#mi("{h \\in H}")#text(", with the group law ")#mi("{(k,h) (k^{\\prime},h^{\\prime}) := (k \\rho(h)(k^{\\prime}), hh^{\\prime})}")#text(", by identifying ")#mi("{(k,h)}")#text(" with ")#mi("{k \\phi(h)}")#text(". Conversely, every semi-direct product ")#mi("{K \\rtimes_\\rho H}")#text(" is a group extension of ")#mi("{H}")#text(" by ")#mi("{K}")#text(" which splits. If the conjugation action ")#mi("{\\rho}")#text(" is trivial, then the semi-direct product simplifies to the ")#emph[#text("direct product")]#text(" ")#mi("{K \\times H}")#text(". In particular, any semi-direct product which is a central extension is of this form.")

#text("Note that, in general, an extension of ")#mi("{H}")#text(" by ")#mi("{K}")#text(" is a different concept from an extension of ")#mi("{K}")#text(" by ")#mi("{H}")#text(", because one can have ")#mi("{H}")#text(" as a normal subgroup but not as a quotient, or vice versa. For instance, ")#mi("{S_3}")#text(" has ")#mi("{A_3}")#text(" as a normal subgroup, but not as a quotient; ")#mi("{S_3}")#text(" is an extension of ")#mi("{{\\mathbb Z}/2{\\mathbb Z}}")#text(" by ")#mi("{A_3}")#text(", but not vice versa. To put it another way, the operator “-by-” is not commutative: ")#mi("{H}")#text("-by-")#mi("{K}")#text(" is a different concept from ")#mi("{K}")#text("-by-")#mi("{H}")#text(".")

#text("A subgroup of an ")#mi("{K}")#text("-by-")#mi("{H}")#text(" group is automatically an ")#mi("{K^{\\prime}}")#text("-by-")#mi("{H^{\\prime}}")#text(" group for some subgroups ")#mi("{H^{\\prime}, K^{\\prime}}")#text(" of ")#mi("{H, K}")#text(" respectively; this is essentially ")#link("http://en.wikipedia.org/wiki/Goursat%27s_lemma")[#text("Goursat’s lemma")]#text(". Furthermore, the index of the subgroup is the product of the index of ")#mi("{H^{\\prime}}")#text(" in ")#mi("{H}")#text(", and the index of ")#mi("{K^{\\prime}}")#text(" in ")#mi("{K}")#text(".")

#text("Some standard notions in group theory can be defined using group extensions.")

#list(
[#text("A ")#link("http://en.wikipedia.org/wiki/Metabelian_group")[#text("metabelian group")]#text(" is the same thing as an abelian-by-abelian group, i.e. an abelian extension of an abelian group.")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Metacyclic_group")[#text("metacyclic group")]#text(" is the same thing as an cyclic-by-cyclic group, i.e. a cyclic extension of a cyclic group.")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Polycyclic_group")[#text("polycyclic group")]#text(" is defined recursively by declaring the trivial group to be polycyclic of length ")#mi("{0}")#text(", and defining a polycyclic group of length ")#mi("{l}")#text(" to be an extension of a cyclic group by a polycyclic group of length ")#mi("{l-1}")#text(". Thus polycyclic groups are polycyclic-by-cyclic, where the polycyclic factor has a shorter length.")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Supersolvable_group")[#text("supersolvable group")]#text(" is defined recursively by declaring the trivial group to be supersolvable of length ")#mi("{0}")#text(", and defining a supersolvable group of length ")#mi("{l}")#text(" to be a cyclic extension supersolvable group of length ")#mi("{l-1}")#text(". Thus supersolvable groups are cyclic-by-supersolvable, where the supersolvable factor has a shorter length. In other words, supersolvable groups are towers of cyclic extensions.")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable group")]#text(" is defined recursively by declaring the trivial group to be solvable of length ")#mi("{0}")#text(", and defining a solvable group of length ")#mi("{l}")#text(" to be an extension of an abelian group by a solvable group of length ")#mi("{l-1}")#text(". Thus solvable groups are solvable-by-abelian, where the solvable factor has a shorter length. One can equivalently define solvable groups as abelian-by-solvable, where the solvable factor again has a shorter length (because the final term in the ")#link("http://en.wikipedia.org/wiki/Derived_series")[#text("derived series")]#text(" is abelian and normal). In other words, a solvable group is a tower of abelian extensions.")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent group")]#text(" is defined recursively by declaring the trivial group to be nilpotent of step ")#mi("{0}")#text(", and defining a nilpotent group of step ")#mi("{s}")#text(" to be a central extension of a nilpotent group of step ")#mi("{s-1}")#text(", thus nilpotent groups are central-by-nilpotent. In other words, a nilpotent group is a tower of central extensions.")]
)

#text("(The inclusions here are: cyclic implies abelian implies metabelian implies solvable, cyclic implies metacyclic implies supersolvable implies polycyclic implies solvable, metacyclic implies metabelian, and abelian implies nilpotent implies solvable.)")

#text("The trivial group is the identity for the “-by-” operator: trivial-by-")#mi("{{\\mathcal P}}")#text(" or ")#mi("{{\\mathcal P}}")#text("-by-trivial is the same thing as ")#mi("{{\\mathcal P}}")#text(".")

#text("Now we comment on the associativity of the “-by-” operator. If ")#mi("{N, H, K}")#text(" are groups, observe that an ")#mi("{N}")#text("-by-(")#mi("{H}")#text("-by-")#mi("{K}")#text(") group (i.e. an extension of an ")#mi("{H}")#text("-by-")#mi("{K}")#text(" group by ")#mi("{N}")#text(") is automatically an (")#mi("{N}")#text("-by-")#mi("{H}")#text(")-by-")#mi("{K}")#text(" group (i.e. an extension of ")#mi("{K}")#text(" by an ")#mi("{N}")#text("-by-")#mi("{H}")#text(" group), since if we denote ")#mi("{G}")#text(" by the ")#mi("{N}")#text("-by-(")#mi("{H}")#text("-by-")#mi("{K}")#text(") group, and ")#mi("{\\pi}")#text(" the quotient map from ")#mi("{G}")#text(" to the ")#mi("{H}")#text("-by-")#mi("{K}")#text(" group, then ")#mi("{\\pi^{-1}(H)}")#text(" is a ")#mi("{N}")#text("-by-")#mi("{H}")#text(" normal subgroup of ")#mi("{G}")#text(" whose quotient is ")#mi("{K}")#text(". Thus, for instance, every cyclic-by-metacyclic group is metacyclic-by-cyclic, and more generally every supersolvable group is polycyclic.")

#text("On the other hand, the converse is not true: not every (")#mi("{N}")#text("-by-")#mi("{H}")#text(")-by-")#mi("{K}")#text(" group is an ")#mi("{N}")#text("-by-(")#mi("{H}")#text("-by-")#mi("{K}")#text(") group. The problem is that ")#mi("{N}")#text(" is normal in the ")#mi("{N}")#text("-by-")#mi("{H}")#text(" group, but need not be normal in the (")#mi("{N}")#text("-by-")#mi("{H}")#text(")-by-")#mi("{K}")#text(" group. For instance, the semi-direct product ")#mi("{{\\mathbb Z}^2 \\rtimes SL_2({\\mathbb Z})}")#text(" is (")#mi("{{\\mathbb Z}}")#text("-by-")#mi("{{\\mathbb Z}}")#text(")-by-")#mi("{SL_2({\\mathbb Z})}")#text(" but not ")#mi("{{\\mathbb Z}}")#text("-by-(")#mi("{{\\mathbb Z}}")#text("-by-")#mi("{SL_2({\\mathbb Z})}")#text("). So the “-by-” operation is not associative in general (for instance, there are polycyclic groups that are not supersolvable). However, if ")#mi("{N}")#text(" is not just normal in the ")#mi("{N}")#text("-by-")#mi("{H}")#text(" group, but is ")#link("http://en.wikipedia.org/wiki/Characteristic_subgroup")[#text("characteristic")]#text(" in that group, then it is automatically normal in the larger (")#mi("{N}")#text("-by-")#mi("{H}")#text(")-by-")#mi("{K}")#text(" group, and then one can interpret the (")#mi("{N}")#text("-by-")#mi("{H}")#text(")-by-")#mi("{K}")#text(" group as an ")#mi("{N}")#text("-by-(")#mi("{H}")#text("-by-")#mi("{K}")#text(") group. So one recovers associativity when the first factor is characteristic. This explains why solvable groups can be recursively expressed both as abelian-by-solvable, and equivalently as solvable-by-abelian; this is ultimately because the ")#link("http://en.wikipedia.org/wiki/Commutator_subgroup")[#text("commutator subgroup")]#text(" ")#mi("{[G,G]}")#text(" is a characteristic subgroup of ")#mi("{G}")#text(". An easy but useful related observation is that solvable-by-solvable groups are again solvable (with the length of the product being bounded by the sum of the length of the factors).")

#text("Given a group property ")#mi("{{\\mathcal P}}")#text(", a group ")#mi("{G}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Virtually")[#text("virtually ")#mi("{{\\mathcal P}}")]#text(" if it has a finite index subgroup with the property ")#mi("{{\\mathcal P}}")#text("; thus for instance a virtually abelian group is one with a finite index abelian subgroup, and so forth. (With this convention, “finite” is the same as “virtually trivial”.) This concept is not directly expressible in terms of group extensions for arbitrary properties ")#mi("{{\\mathcal P}}")#text("; however, if the group property ")#mi("{{\\mathcal P}}")#text(" is ")#emph[#text("hereditary")]#text(" in the sense that subgroups of a ")#mi("{{\\mathcal P}}")#text(" group are also ")#mi("{{\\mathcal P}}")#text(", then a virtually ")#mi("{{\\mathcal P}}")#text(" group is the same concept as a ")#mi("{{\\mathcal P}}")#text("-by-finite group. This is because every finite index subgroup ")#mi("{H}")#text(" of a group ")#mi("{G}")#text(" automatically contains a finite index ")#emph[#text("normal")]#text(" subgroup of ")#mi("{G}")#text(". (Proof: ")#mi("{G}")#text(" acts on the finite quotient space ")#mi("{G/H}")#text(" by left multiplication, hence the ")#link("http://en.wikipedia.org/wiki/Stabilizer_(group_theory)#Orbits_and_stabilizers")[#text("stabiliser")]#text(" of ")#mi("{G/H}")#text(" has finite index in ")#mi("{G}")#text(". But this stabliser is also normal in ")#mi("{G}")#text(" and contained in ")#mi("{H}")#text(".)")

#text("One also observes that if ")#mi("{{\\mathcal P}}")#text(", ")#mi("{{\\mathcal Q}}")#text(" are hereditary properties, then the property of ")#mi("{{\\mathcal P}}")#text("-by-")#mi("{{\\mathcal Q}}")#text(" is hereditary also; if ")#mi("{0 \\rightarrow P \\rightarrow G \\rightarrow Q \\rightarrow 0}")#text(" is a ")#mi("{{\\mathcal P}}")#text("-by-")#mi("{{\\mathcal Q}}")#text(" group, and ")#mi("{G^{\\prime}}")#text(" is a subgroup of ")#mi("{G}")#text(", then the short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow (P \\cap G^{\\prime}) \\rightarrow G^{\\prime} \\rightarrow \\pi(G^{\\prime}) \\rightarrow 0,")]]

#text("where ")#mi("{\\pi: G \\rightarrow Q}")#text(" is a projection map, demonstrates that ")#mi("{G^{\\prime}}")#text(" is also a ")#mi("{{\\mathcal P}}")#text("-by-")#mi("{{\\mathcal Q}}")#text(" group. Thus for instance the properties of being metabelian, metacyclic, polycyclic, supersolvable, solvable, or nilpotent, are hereditary. As a consequence, virtually nilpotent is the same as nilpotent-by-finite, etc.")

#text("We saw for hereditary properties ")#mi("{{\\mathcal P}}")#text(" that “")#mi("{{\\mathcal P}}")#text("-by-finite” was the same concept as “virtually ")#mi("{{\\mathcal P}}")#text("“. It is natural to ask whether the same is true for “finite-by-")#mi("{{\\mathcal P}}")#text("“. The answer is no; for instance, one can extend the an infinite vector space ")#mi("{V}")#text(" over a finite field ")#mi("{F}")#text(" by ")#mi("{F}")#text(" (using some non-degenerate bilinear anti-symmetric form ")#mi("{\\omega: V \\times V \\rightarrow F}")#text(", and defining ")#mi("{(v,f) (w,g) = (v+w, f+g+\\omega(v,w))}")#text(" for ")#mi("{v,w \\in V}")#text(" and ")#mi("{f,g \\in F}")#text(") to create a nilpotent group which is finite-by-abelian, but not virtually abelian. Conversely, the semi-direct product ")#mi("{{\\mathbb Z} \\rtimes {\\mathbb Z}/2{\\mathbb Z}}")#text(" (where ")#mi("{{\\mathbb Z}/2{\\mathbb Z}}")#text(" acts on ")#mi("{{\\mathbb Z}}")#text(" by reflection) is virtually abelian, but not finite-by-abelian. On the other hand, for hereditary ")#mi("{{\\mathcal P}}")#text(", a finite-by-")#mi("{{\\mathcal P}}")#text(" group is virtually (central finite)-by-")#mi("{{\\mathcal P}}")#text(". This is because if ")#mi("{G}")#text(" is an extension of a ")#mi("{{\\mathcal P}}")#text(" group ")#mi("{P}")#text(" by a finite group ")#mi("{F}")#text(", then ")#mi("{G}")#text(" acts by conjugation on the finite group ")#mi("{F}")#text("; the stabiliser ")#mi("{G^{\\prime}}")#text(" of this action is then a finite index subgroup, whose intersection of ")#mi("{F}")#text(" is then central in ")#mi("{G^{\\prime}}")#text(". The projection of ")#mi("{G^{\\prime}}")#text(" onto ")#mi("{P}")#text(" is also a ")#mi("{{\\mathcal P}}")#text(" group by the hereditary nature of ")#mi("{{\\mathcal P}}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" There is a variant of the above result which is also useful. Suppose one has an ")#mi("{H}")#text("-by-")#mi("{K}")#text(" group ")#mi("{G}")#text(" in which the action of ")#mi("{K}")#text(" on ")#mi("{H}")#text(" is virtually trivial (i.e. there are only a finite number of distinct automorphisms of ")#mi("{H}")#text(" induces by ")#mi("{K}")#text(". Then ")#mi("{G}")#text(" is virtually a central ")#mi("{H^{\\prime}}")#text("-by-")#mi("{K^{\\prime}}")#text(" group for some finite index subgroups ")#mi("{H^{\\prime}, K^{\\prime}}")#text(" of ")#mi("{H, K}")#text(".")
]

#text("One can phrase various results in group theory in a succinct form using this notation. For instance, one of the results in ")#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")[#text("my earlier blog post on amenability")]#text(" now states that amenable-by-amenable groups are amenable. Another example that I have been looking at recently is ")#link("http://www.math.ethz.ch/~pink/ftp/LP5.pdf")[#text("this paper of Larsen and Pink")]#text(", the main result of which is a classification of finite linear groups over a field of characteristic ")#mi("{p}")#text(", namely that such groups are virtually (")#mi("{p}")#text("-group by abelian) by (semisimple of Lie type), where one has bounds on the index of the “virtually” and on the type of the semisimple group.")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4df46ae82110da63185b49b4f0402479484431fa9641cc7179d38623c45bba48-ed7fea971c19aa6d9cac479b5b896072dbdbd290e9114bcb26e73136a46c880d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43338")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Thanks for this review, but I’m slightly puzzled with the order of the factors in the -by- operator.")

#text("In definition 1, you say that if G is an extension of a group H with property Q by a group K with property P, it is a Q-by-P group. This sounds logical to me. But what is strange is that you seem to call G a K-by-H group (just below definition 1). Four paragraphs further, you speak about H-by-K groups. There is either a typo or a confusing change of convention. In the next paragraphs, you seem to be calling an extension of H by K a K-by-H group.")

#text("Finally in the paragraph about hereditary properties, G is an extension of Q by P, which you say is a (calligraphic) P-by-Q group. To be consistent with the definition 1, this means that P should have property Q and vice versae…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Oops, I had the definition the wrong way around; an extension of H by K is (confusingly) a K-by-H group rather than an H-by-K group. I don’t know why these conventions are the way they are, but I guess it comes from reading the exact sequence 0 -> K -> G -> H -> 0 from left to right.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant V")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43339")[#strong[#text("Prashant V")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Dear Terry,")

#text("Are there any analogues of the Isomorphism Extension Theorem for groups? Can one always extend a group isomorphism?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43343")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Well, group extensions are defined by covering rather than by embedding, so the question does not really make sense for group extensions (if G extends H, and H’ is isomorphic to H, then G automatically extends H’ also). But for embeddings (if H is embedded in G, and H is isomorphic to H’, then the isomorphism can be extended to one between G and G’ for some G’ containing H’), it seems to me that the same Zorn’s lemma argument would work here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43351")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("We can embed ")#mi("\\mathbb{Z}_2\\hookrightarrow\\mathbb{Z}_4")#text(" by ")#mi("1\\mapsto2")#text(".")

#text("We can embed ")#mi("\\mathbb{Z}_2\\hookrightarrow V_4\\cong\\mathbb{Z}_2\\times\\mathbb{Z}_2")#text(" by including into one of the factors.")

#text("But clearly ")#mi("\\mathbb{Z}_4\\ncong V_4")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Well, yes, but in that case I don’t pick ")#mi("{\\Bbb Z}_2 \\hookrightarrow V_4")#text(" as my embedding of H’ in a larger group G’. I would pick ")#mi("{\\Bbb Z}_2 \\hookrightarrow {\\Bbb Z}_4")#text(".")

#text("It does mean, though, that as currently phrased in my comment, the proposed group isomorphism extension theorem is a triviality; if H and H’ are isomorphic, and H can be embedded in G, then clearly H’ can be embedded in G also.")

#text("A slightly more interesting result is that if H is embedded in G, and H’ is isomorphic to H and embedded in G’, then one can simultaneously embed H, H’, G, G’ into a single object, the ")#emph[#text("amalgamated free product")]#text(" of G and G’ over H, in such a way that H, H’ become identified. I guess the existence of the amalgamated free product is the closest analogue to the field isomorphism extension theorem in group theory.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43353")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Oh yes, if you’re free to choose the target then it’s trivial.")

#text("I was thinking Prashant was asking for something like a rigidity theorem, where under certain circumstances the behavior of the whole structure is essentially determined by a certain substructure. Then if two structures’ particular substructures are isomorphic, then the entire structures are isomorphic.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Perhaps this post deserves an expository tag.")

#emph[#text("[Fair enough – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef9ae689f121b8209ace1aaa14384ddcd1670331e20b509148b34ac9cbef89cd-690350188b5c8da675c69d3f23431b5c055b7f51be2bff593872505090d94bac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nate")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43357")[#strong[#text("Nate")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("in definition 1 paragraph 2, there is a typo (if i understand the conventions correctly): it reads “if K is central in G, K is a central extension of H” but i think it should read “if K is central in G, G is a central extension of H”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d19d7dbe2ba89f6558b8366c8f9056027eb2c1a9a1acb896aff99804e7aa2f23-8c29882598737da53c498442e7d6c6d28a0593fb4bf6c2016f26fb4d12e9de23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-43412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2010")])]

#text("Just to clarify that there are at least two meanings of “embedding”. One is that of an injective morphism (as in the wikipedia article); another is when X is isomorphic to the image under the embedding. The two are not equivalent, although for the groups example, the two are indeed the same. For example, the identity map takes the normed sequence space l^1 into l^infty, so l^1 is “embedded” in l^infty in the first sense but not in the second. This example also illustrates that an embedding/extension (in the first sense) can also be thought of as a pixelation: the norm on l^1 is “finer” than the “hazier” one on l^infty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van Dantzig’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-53233")[#strong[#text("van Dantzig’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2011")])]

#text("[…] semidirect products as examples, but can be more general than these situations, as discussed in this previous blog post). In principle, the problem of understanding the structure of then splits into three simpler […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-90828")[#strong[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("[…] the combined group , due to the possible presence of non-trivial group cohomology. See for instance this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the classification of complex Lie algebras | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-226584")[#strong[#text("Notes on the classification of complex Lie algebras | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("[…] associative: every Lie algebra of the form is also of the form , but the converse is not true (see this previous blog post for some related discussion). As we are working in the infinitesimal world of Lie algebras (which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40dcb654fab17228181730204366b86f4d701e2b386dc7d941c7fe8e7963ba31-b69f226e0adc18def80a8e71ef1f7674c4ac84628802a24ea58664a263e98f61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Srinivas Rau")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-251633")[#strong[#text("Srinivas Rau")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("Does the fundamental group of a compact Riemann surface have a universal central extension 0—>Z—->G—>pi(X)—>0 as claimed by Atiyah -Bott (1982)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd930426b4d3c98383c55540bd23cebcd0fa10a814895a84ac3e948956dd26ce-ff740452d6fd6d1660d163b610c77ed8b87ad45eca631c229e66d88a8d516344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mudheher Al-Bayati")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-494118")[#strong[#text("Mudheher Al-Bayati")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2018")])]

#text("How we can define a extending dynamical system depending on group extension concept ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8b6a39142f9a02193a381db0cf70ae80a5441de763043bd4ebe626953bcb6d8-5881464b3f174c993b2e6aa62df512300b9a03d74221c36ea4510034afaa28ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthis")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-502080")[#strong[#text("Matthis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2018")])]

#text("Dear Terence,")

#text("at the moment I am working on my bachelor thesis with the topic group extensions. Your overview is great and an interesting result is that a subgroup of an K-by-H extension is an K’-by-H’ extension with K’ and H’ subgroups of K and H. You say the proof is essentially Goursat’s Lemma but I just can’t figure out how this should work. Perhaps it’s just missing experience and know-how in group theory…")#linebreak()#text(" Maybe you can start me off?")

#text("Thanks a lot!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-502103")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2018")])]

#text("What have you tried so far, and what did you get?")

#text("If you are more comfortable with linear algebra than with group theory, one can work with the analogous problem involving vector spaces over a fixed field (e.g. real vector spaces). If ")#mi("K, H")#text(" are vector spaces, a ")#mi("K")#text("-by-")#mi("H")#text(" vector space is a space ")#mi("G")#text(" which has a linear map onto ")#mi("H")#text(" with kernel ")#mi("K")#text(". The assertion for groups has an exact analogue in this category (replacing “subgroup” by “subspace” of course), and you may find it easier to prove from your linear algebra intuition.")

#text("Another category where the analogous result is true is that of sets, although here the claim is somewhat degenerate and perhaps ")#emph[#text("too")]#text(" easy to prove. If ")#mi("K,H")#text(" are disjoint sets, a ")#mi("K")#text("-by-")#mi("H")#text(" set would be a set ")#mi("G")#text(" that contains a subset ")#mi("K")#text(" such that the set-theoretic difference ")#mi("G \\backslash K")#text(" is equal to ")#mi("H")#text(". (This notion is rather degenerate since there is precisely one such extension, namely ")#mi("K \\cup H")#text(".) The corresponding claim is then rather trivial, but it may still give you a bit of intuition, in particular with regards to how ")#mi("K^{\\prime}")#text(" and ")#mi("H^{\\prime}")#text(" are actually related to ")#mi("G^{\\prime}")#text(", ")#mi("K")#text(", and ")#mi("H")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8b6a39142f9a02193a381db0cf70ae80a5441de763043bd4ebe626953bcb6d8-5881464b3f174c993b2e6aa62df512300b9a03d74221c36ea4510034afaa28ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthis")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-502157")[#strong[#text("Matthis")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2018")])]

#text("Thank you for your response!")#linebreak()#text(" I was desperate trying to someway connect the group extension problem with Goursat’s lemma without assuming my extension was a direct product, I did not came that far.")

#text("Thinking about the analogous problem with vector spaces helped!")#linebreak()#text(" For a K-by-H extension G I get a homomorphism f from G with Im(f)=H and Ker(f)=K. So for a subgroup G’ from G I call the intersection of K and G’ K’ and this is the kernel of f restricted to G’. For H’ I take the image of G’ under f.")#linebreak()#text(" I wrote it down and thought it through and it seems to work, assuming I did not make an embarrassing mistake.")

#text("But is it that simple? What does that have to do with Goursat’s lemma?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-502225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2018")])]

#text("This result does not directly invoke Goursat’s lemma (which derives a stronger conclusion assuming stronger hypotheses) but the two results are in the same spirit and use similar tools in the proof.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e41f573125b4888d14fb5822c3a5ec6a81f8bf941a22cb7e07f7a72bae8ac43-8e61a702ad524c90d5fcf02a2c01b0ff7344e43e7f8ba9a939419bd87d9d7bc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kit")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-514304")[#strong[#text("Kit")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2019")])]

#text("Dear Terence,")#linebreak()#text(" I am in my final year of my bachelors and I am doing my dissertation on subgroup lattices. While working through some proofs I have become stuck on results that use group extensions. In particular the book I am using often justifies a subgroup being abelian because it is “a cyclic extension of a central subgroup”.")#linebreak()#text(" I don’t really understand what this means (this post has been a big help!) or why it would lead to the subgroup being abelian.")#linebreak()#text(" Any help would be greatly appreciated, thank you for your time!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/#comment-514306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2019")])]

#text("If a group ")#mi("G")#text(" is formed by an extension of a central subgroup ")#mi("H")#text(" by a cyclic group ")#mi("K = \\langle g \\rangle")#text(" generated by some generator ")#mi("g")#text(" (so the short exact sequence ")#mi("0 \\to K \\to G \\to H \\to 0")#text(" splits, with ")#mi("H")#text(" now being a subgroup of ")#mi("G")#text(" as well as a quotient), then ")#mi("g")#text(" and ")#mi("H")#text(" both commute with ")#mi("H")#text(" (as ")#mi("H")#text(" is central), and ")#mi("g")#text(" of course commutes with itself. Since ")#mi("g")#text(" and ")#mi("H")#text(" together generate the group ")#mi("G")#text(", the entire group ")#mi("G")#text(" is then abelian.")
]
]
