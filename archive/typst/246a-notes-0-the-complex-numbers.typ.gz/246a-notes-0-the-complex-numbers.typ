// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/
// Converted to Typst by tao2typ: "2026-10-14T15:19:46.811805+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246A, Notes 0: the complex numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246A, Notes 0: the complex numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")[#text("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Next set of notes: ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(".")

#text("Kronecker is famously reported to have said, “God created the natural numbers; all else is the work of man”. The truth of this statement (literal or otherwise) is debatable; but one can certainly view the other standard number systems ")#mi("{{\\bf Z}, {\\bf Q}, {\\bf R}, {\\bf C}}")#text(" as (iterated) completions of the natural numbers ")#mi("{{\\bf N}}")#text(" in various senses. For instance:")

#list(
[#text("The integers ")#mi("{{\\bf Z}}")#text(" are the additive completion of the natural numbers ")#mi("{{\\bf N}}")#text(" (the minimal additive group that contains a copy of ")#mi("{{\\bf N}}")#text(").")],
[#text("The rationals ")#mi("{{\\bf Q}}")#text(" are the multiplicative completion of the integers ")#mi("{{\\bf Z}}")#text(" (the minimal field that contains a copy of ")#mi("{{\\bf Z}}")#text(").")],
[#text("The reals ")#mi("{{\\bf R}}")#text(" are the metric completion of the rationals ")#mi("{{\\bf Q}}")#text(" (the minimal complete metric space that contains a copy of ")#mi("{{\\bf Q}}")#text(").")],
[#text("The complex numbers ")#mi("{{\\bf C}}")#text(" are the algebraic completion of the reals ")#mi("{{\\bf R}}")#text(" (the minimal algebraically closed field that contains a copy of ")#mi("{{\\bf R}}")#text(").")]
)

#text("These descriptions of the standard number systems are elegant and conceptual, but not entirely suitable for ")#emph[#text("constructing")]#text(" the number systems in a non-circular manner from more primitive foundations. For instance, one cannot quite define the reals ")#mi("{{\\bf R}}")#text(" from scratch as the metric completion of the rationals ")#mi("{{\\bf Q}}")#text(", because the definition of a metric space itself requires the notion of the reals! (One can of course construct ")#mi("{{\\bf R}}")#text(" by other means, for instance by using ")#link("https://en.wikipedia.org/wiki/Dedekind_cut")[#text("Dedekind cuts")]#text(" or by using ")#link("https://en.wikipedia.org/wiki/Uniform_space")[#text("uniform spaces")]#text(" in place of metric spaces.) The definition of the complex numbers as the algebraic completion of the reals does not suffer from such a non-circularity issue, but a certain amount of field theory is required to work with this definition initially. For the purposes of quickly constructing the complex numbers, it is thus more traditional to first define ")#mi("{{\\bf C}}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Kummer_theory")[#text("quadratic extension")]#text(" of the reals ")#mi("{{\\bf R}}")#text(", and more precisely as the extension ")#mi("{{\\bf C} = {\\bf R}(i)}")#text(" formed by adjoining a square root ")#mi("{i}")#text(" of ")#mi("{-1}")#text(" to the reals, that is to say a solution to the equation ")#mi("{i^2+1=0}")#text(". It is not immediately obvious that this extension is in fact algebraically closed; this is the content of the famous ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(", which we will prove later in this course.")#linebreak()#text(" The two equivalent definitions of ")#mi("{{\\bf C}}")#text(" – as the algebraic closure, and as a quadratic extension, of the reals respectively – each reveal important features of the complex numbers in applications. Because ")#mi("{{\\bf C}}")#text(" is algebraically closed, all polynomials over the complex numbers split completely, which leads to a good spectral theory for both finite-dimensional matrices and infinite-dimensional operators; in particular, one expects to be able to diagonalise most matrices and operators. Applying this theory to constant coefficient ordinary differential equations leads to a unified theory of such solutions, in which real-variable ODE behaviour such as exponential growth or decay, polynomial growth, and sinusoidal oscillation all become aspects of a single object, the ")#link("https://en.wikipedia.org/wiki/Euler%27s_formula")[#text("complex exponential")]#text(" ")#mi("{z \\mapsto e^z}")#text(" (or more generally, the ")#link("https://en.wikipedia.org/wiki/Matrix_exponential")[#text("matrix exponential")]#text(" ")#mi("{A \\mapsto \\exp(A)}")#text("). Applying this theory more generally to diagonalise arbitrary translation-invariant operators over some locally compact abelian group, one arrives at ")#link("https://en.wikipedia.org/wiki/Fourier_analysis")[#text("Fourier analysis")]#text(", which is thus most naturally phrased in terms of complex-valued functions rather than real-valued ones. If one drops the assumption that the underlying group is abelian, one instead discovers the representation theory of ")#link("https://en.wikipedia.org/wiki/Unitary_representation")[#text("unitary representations")]#text(", which is simpler to study than the real-valued counterpart of orthogonal representations. For closely related reasons, the theory of complex ")#link("https://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(" is simpler than that of real Lie groups.")

#text("Meanwhile, the fact that the complex numbers are a quadratic extension of the reals lets one view the complex numbers geometrically as a two-dimensional plane over the reals (the ")#link("https://en.wikipedia.org/wiki/Complex_plane")[#text("Argand plane")]#text("). Whereas a point singularity in the real line disconnects that line, a point singularity in the Argand plane leaves the rest of the plane connected (although, importantly, the punctured plane is no longer ")#link("https://en.wikipedia.org/wiki/Simply_connected_space")[#text("simply connected")]#text("). As we shall see, this fact causes singularities in complex analytic functions to be better behaved than singularities of real analytic functions, ultimately leading to the powerful ")#link("https://en.wikipedia.org/wiki/Residue_calculus")[#text("residue calculus")]#text(" for computing complex integrals. Remarkably, this calculus, when combined with the quintessentially complex-variable technique of ")#emph[#text("contour shifting")]#text(", can also be used to compute some (though certainly not all) definite integrals of ")#emph[#text("real")]#text("-valued functions that would be much more difficult to compute by purely real-variable methods; this is a prime example of Hadamard’s famous dictum that “the shortest path between two truths in the real domain passes through the complex domain”.")

#text("Another important geometric feature of the Argand plane is the angle between two tangent vectors to a point in the plane. As it turns out, the operation of multiplication by a complex scalar preserves the magnitude and orientation of such angles; the same fact is true for any non-degenerate complex analytic mapping, as can be seen by performing a Taylor expansion to first order. This fact ties the study of complex mappings closely to that of the ")#link("https://en.wikipedia.org/wiki/Conformal_geometry")[#text("conformal geometry")]#text(" of the plane (and more generally, of two-dimensional surfaces and domains). In particular, one can use complex analytic maps to conformally transform one two-dimensional domain to another, leading among other things to the famous ")#link("https://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text(", and to the classification of ")#link("https://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surfaces")]#text(".")

#text("If one Taylor expands complex analytic maps to second order rather than first order, one discovers a further important property of these maps, namely that they are ")#link("https://en.wikipedia.org/wiki/Harmonic_function")[#text("harmonic")]#text(". This fact makes the class of complex analytic maps extremely rigid and well behaved analytically; indeed, the entire theory of elliptic PDE now comes into play, giving useful properties such as ")#link("https://en.wikipedia.org/w/index.php?title=Elliptic_regularity")[#text("elliptic regularity")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(". In fact, due to the magic of residue calculus and contour shifting, we already obtain these properties for maps that are merely complex differentiable rather than complex analytic, which leads to the striking fact that complex differentiable functions are automatically analytic (in contrast to the real-variable case, in which real differentiable functions can be very far from being analytic).")

#text("The geometric structure of the complex numbers (and more generally of complex manifolds and complex varieties), when combined with the algebraic closure of the complex numbers, leads to the beautiful subject of ")#emph[#text("complex algebraic geometry")]#text(", which motivates the much more general theory developed in modern algebraic geometry. However, we will not develop the algebraic geometry aspects of complex analysis here.")

#text("Last, but not least, because of the good behaviour of Taylor series in the complex plane, complex analysis is an excellent setting in which to manipulate various ")#link("https://en.wikipedia.org/wiki/Generating_function")[#text("generating functions")]#text(", particularly ")#link("https://en.wikipedia.org/wiki/Fourier_series")[#text("Fourier series")]#text(" ")#mi("{\\sum_n a_n e^{2\\pi i n \\theta}}")#text(" (which can be viewed as boundary values of power (or Laurent) series ")#mi("{\\sum_n a_n z^n}")#text("), as well as ")#link("https://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]#text(" ")#mi("{\\sum_n \\frac{a_n}{n^s}}")#text(". The theory of contour integration provides a very useful dictionary between the asymptotic behaviour of the sequence ")#mi("{a_n}")#text(", and the complex analytic behaviour of the Dirichlet or Fourier series, particularly with regard to its poles and other singularities. This turns out to be a particularly handy dictionary in ")#link("https://en.wikipedia.org/wiki/Analytic_number_theory")[#text("analytic number theory")]#text(", for instance relating the distribution of the primes to the ")#link("https://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(". Nowadays, many of the analytic number theory results first obtained through complex analysis (such as the ")#link("https://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(") can also be obtained by more “real-variable” methods; however the complex-analytic viewpoint is still extremely valuable and illuminating.")

#text("We will frequently touch upon many of these connections to other fields of mathematics in these lecture notes. However, these are mostly side remarks intended to provide context, and it is certainly possible to skip most of these tangents and focus purely on the complex analysis material in these notes if desired.")

#text("Note: complex analysis is a very visual subject, and one should draw plenty of pictures while learning it. I am however not planning to put too many pictures in these notes, partly as it is somewhat inconvenient to do so on this blog from a technical perspective, but also because pictures that one draws on one’s own are likely to be far more useful to you than pictures that were supplied by someone else.")

#metadata(none) <tao-72dbfc0149e3fe6b9ad6>

#heading(level: 1)[#strong[#text(" — 1. The construction and algebra of the complex numbers — ")]]

#text("Note: this section will be far more algebraic in nature than the rest of the course; we are concentrating almost all of the algebraic preliminaries in this section in order to get them out of the way and focus subsequently on the analytic aspects of the complex numbers.")

#text("Thanks to the laws of high-school algebra, we know that the real numbers ")#mi("{{\\bf R}}")#text(" are a ")#link("https://en.wikipedia.org/wiki/Field_(algebra)")[#text("field")]#text(": it is endowed with the arithmetic operations of addition, subtraction, multiplication, and division, as well as the additive identity ")#mi("{0}")#text(" and multiplicative identity ")#mi("{1}")#text(", that obey the usual laws of algebra (i.e. the ")#link("https://en.wikipedia.org/wiki/Field_(mathematics)#Definition_and_illustration")[#text("field axioms")]#text(").")

#text("The algebraic structure of the reals does have one drawback though – not all (non-trivial) polynomials have roots! Most famously, the polynomial equation ")#mi("{x^2+1=0}")#text(" has no solutions over the reals, because ")#mi("{x^2}")#text(" is always non-negative, and hence ")#mi("{x^2+1}")#text(" is always strictly positive, whenever ")#mi("{x}")#text(" is a real number.")

#text("As mentioned in the introduction, one traditional way to define the complex numbers ")#mi("{{\\bf C}}")#text(" is as the smallest possible extension of the reals ")#mi("{{\\bf R}}")#text(" that fixes this one specific problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (The complex numbers)")]#text(" ")#metadata(none) <tao-8cfa51e892bbc8308970>#text(" A ")#emph[#text("field of complex numbers")]#text(" is a field ")#mi("{{\\bf C}}")#text(" that contains the real numbers ")#mi("{{\\bf R}}")#text(" as a subfield, as well as a root ")#mi("{i}")#text(" of the equation ")#mi("{i^2+1=0}")#text(". (Thus, strictly speaking, a field of complex numbers is a pair ")#mi("{({\\bf C},i)}")#text(", but we will almost always abuse notation and use ")#mi("{{\\bf C}}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Metonym")[#text("metonym")]#text(" for the pair ")#mi("{({\\bf C},i)}")#text(".) Furthermore, ")#mi("{{\\bf C}}")#text(" is generated by ")#mi("{{\\bf R}}")#text(" and ")#mi("{i}")#text(", in the sense that there is no subfield of ")#mi("{{\\bf C}}")#text(", other than ")#mi("{{\\bf C}}")#text(" itself, that contains both ")#mi("{{\\bf R}}")#text(" and ")#mi("{i}")#text("; thus, in the language of ")#link("https://en.wikipedia.org/wiki/Field_extension")[#text("field extensions")]#text(", we have ")#mi("{{\\bf C} = {\\bf R}(i)}")#text(".")
]

#text("(We will take the existence of the real numbers ")#mi("{{\\bf R}}")#text(" as a given in this course; constructions of the real number system can of course be found in many real analysis texts, including ")#link("https://terrytao.wordpress.com/books/analysis-i/")[#text("my own")]#text(".)")

#text("Definition ")#link(<tao-8cfa51e892bbc8308970>)[#text("1")]#text(" is short, but proposing it as a definition of the complex numbers raises some immediate questions:")

#list(
[#text("(Existence) Does such a field ")#mi("{{\\bf C}}")#text(" even exist?")],
[#text("(Uniqueness) Is such a field ")#mi("{{\\bf C}}")#text(" unique (up to isomorphism)?")],
[#text("(Non-arbitrariness) Why the square root of ")#mi("{-1}")#text("? Why not adjoin instead, say, a fourth root of ")#mi("{-42}")#text(", or the solution to some other algebraic equation? Also, could one iterate the process, extending ")#mi("{{\\bf C}}")#text(" further by adding more roots of equations?")]
)

#text("The third set of questions can be answered satisfactorily once we possess the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(". For now, we focus on the first two questions.")

#text("We begin with existence. One can construct the complex numbers quite explicitly and quickly using the Argand plane construction; see Remark ")#link(<tao-57a1468eb17b7296da69>)[#text("7")]#text(" below. However, from the perspective of higher mathematics, it is more natural to view the construction of the complex numbers as a special case of the more general algebraic construction that can extend any field ")#mi("{k}")#text(" by the root ")#mi("{\\alpha}")#text(" of an irreducible nonlinear polynomial ")#mi("{P \\in k[\\mathrm{x}]}")#text(" over that field; this produces a field of complex numbers ")#mi("{{\\bf C}}")#text(" when specialising to the case where ")#mi("{k={\\bf R}}")#text(" and ")#mi("{P = \\mathrm{x}^2+1}")#text(". We will just describe this construction in that special case, leaving the general case as an exercise.")

#text("Starting with the real numbers ")#mi("{{\\bf R}}")#text(", we can form the space ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" of (formal) polynomials")

#align(center)[#tao-fit-display[#mitex("P(\\mathrm{x}) = a_d \\mathrm{x}^d + a_{d-1} \\mathrm{x}^{d-1} + \\dots + a_0 \\mathrm{x}^0")]]

#text("with real co-efficients ")#mi("{a_0,\\dots,a_d \\in {\\bf R}}")#text(" and arbitrary non-negative integer ")#mi("{d}")#text(" in one indeterminate variable ")#mi("{\\mathrm{x}}")#text(". (A small technical point: we do not view this indeterminate ")#mi("{\\mathrm{x}}")#text(" as belonging to any particular domain such as ")#mi("{{\\bf R}}")#text(", so we do not view these polynomials ")#mi("{P}")#text(" as functions but merely as formal expressions involving a placeholder symbol ")#mi("{\\mathrm{x}}")#text(" (which we have rendered in Roman type to indicate its formal character). In this particular ")#link("https://en.wikipedia.org/wiki/Characteristic_(algebra)")[#text("characteristic zero")]#text(" setting of working over the reals, it turns out to be harmless to identify each polynomial ")#mi("{P}")#text(" with the corresponding function ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" formed by interpreting the indeterminate ")#mi("{\\mathrm{x}}")#text(" as a real variable; but if one were to generalise this construction to positive characteristic fields, and particularly finite fields, then one can run into difficulties if polynomials are not treated formally, due to the fact that two distinct formal polynomials might agree on all inputs in a given finite field (e.g. the polynomials ")#mi("{x}")#text(" and ")#mi("{x^p}")#text(" agree for all ")#mi("{x}")#text(" in the finite field ")#mi("{{\\mathbf F}_p}")#text("). However, this subtlety can be ignored for the purposes of this course.) This space ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" of polynomials has a pretty good algebraic structure, in particular the usual operations of addition, subtraction, and multiplication on polynomials, together with the zero polynomial ")#mi("{0}")#text(" and the unit polynomial ")#mi("{1}")#text(", give ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" the structure of a (unital) ")#link("https://en.wikipedia.org/wiki/Commutative_ring")[#text("commutative ring")]#text(". This commutative ring also contains ")#mi("{{\\bf R}}")#text(" as a subring (identifying each real number ")#mi("{a}")#text(" with the degree zero polynomial ")#mi("{a \\mathrm{x}^0}")#text("), and so we shall henceforth omit the ")#mi("{\\mathrm{x}^0}")#text(" factor when referring to elements of ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(". The ring ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" is however not a field, because many non-zero elements of ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" do not have multiplicative inverses. (In fact, no non-constant polynomial in ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" has an inverse in ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(", because the product of two non-constant polynomials has a ")#link("https://en.wikipedia.org/wiki/Degree_of_a_polynomial")[#text("degree")]#text(" that is the sum of the degrees of the factors.)")#linebreak()#text(" If a unital commutative ring fails to be a field, then it will instead possess a number of non-trivial ")#link("https://en.wikipedia.org/wiki/Ideal_(ring_theory)")[#text("ideals")]#text(". The only ideal we will need to consider here is the ")#link("https://en.wikipedia.org/wiki/Principal_ideal")[#text("principal ideal")]

#align(center)[#tao-fit-display[#mitex("\\langle \\mathrm{x}^2+1 \\rangle := \\{ (\\mathrm{x}^2+1) P(\\mathrm{x}): P(\\mathrm{x}) \\in {\\bf R}[\\mathrm{x}] \\}.")]]

#text("This is clearly an ideal of ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" – it is closed under addition and subtraction, and the product of any element of the ideal ")#mi("{\\langle \\mathrm{x}^2 + 1 \\rangle}")#text(" with an element of the full ring ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" remains in the ideal ")#mi("{\\langle \\mathrm{x}^2 + 1 \\rangle}")#text(".")#linebreak()#text(" We now define ")#mi("{{\\bf C}}")#text(" to be the ")#link("https://en.wikipedia.org/wiki/Quotient_ring")[#text("quotient space")]

#align(center)[#tao-fit-display[#mitex("{\\bf C} := {\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2+1 \\rangle")]]

#text("of the commutative ring ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" by the ideal ")#mi("{\\langle \\mathrm{x}^2+1 \\rangle}")#text("; this is the space of cosets ")#mi("{P(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle = \\{ P(\\mathrm{x}) + Q(\\mathrm{x}): Q(\\mathrm{x}) \\in \\langle \\mathrm{x}^2+1 \\rangle \\}}")#text(" of ")#mi("{\\langle \\mathrm{x}^2+1 \\rangle}")#text(" in ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(". Because ")#mi("{\\langle \\mathrm{x}^2+1 \\rangle}")#text(" is an ideal, there is an obvious way to define addition, subtraction, and multiplication in ")#mi("{{\\bf C}}")#text(", namely by setting")

#tao-aligned(keep: true)[


#tao-math("(P(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle) + (Q(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle)  & := (P(\\mathrm{x}) + Q(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle),", block: true)



#tao-math("(P(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle) - (Q(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle)  & := (P(\\mathrm{x}) - Q(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle)", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("(P(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle) \\cdot (Q(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle) := (P(\\mathrm{x}) Q(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle)")]]

#text("for all ")#mi("{P(\\mathrm{x}), Q(\\mathrm{x}) \\in {\\bf R}[\\mathrm{x}]}")#text("; these operations, together with the additive identity ")#mi("{0 = 0_{\\bf C} := 0 + \\langle \\mathrm{x}^2+1 \\rangle}")#text(" and the multiplicative identity ")#mi("{1 = 1_{\\bf C} := 1 + \\langle \\mathrm{x}^2+1 \\rangle}")#text(", can be easily verified to give ")#mi("{{\\bf C}}")#text(" the structure of a commutative ring. Also, the real line ")#mi("{{\\bf R}}")#text(" embeds into ")#mi("{{\\bf C}}")#text(" by identifying each real number ")#mi("{a}")#text(" with the coset ")#mi("{a + \\langle \\mathrm{x}^2+1 \\rangle}")#text("; note that this identification is injective, as no real number is a multiple of the polynomial ")#mi("{\\mathrm{x}^2+1}")#text(".")#linebreak()#text(" If we define ")#mi("{i \\in {\\bf C}}")#text(" to be the coset")

#align(center)[#tao-fit-display[#mitex("i := \\mathrm{x} + \\langle \\mathrm{x}^2 + 1 \\rangle,")]]

#text("then it is clear from construction that ")#mi("{i^2+1=0}")#text(". Thus ")#mi("{{\\bf C}}")#text(" contains both ")#mi("{{\\bf R}}")#text(" and a solution of the equation ")#mi("{i^2+1=0}")#text(". Also, since every element of ")#mi("{{\\bf C}}")#text(" is of the form ")#mi("{P(\\mathrm{x}) + \\langle \\mathrm{x}^2+1 \\rangle}")#text(" for some polynomial ")#mi("{P \\in {\\bf R}[\\mathrm{x}]}")#text(", we see that every element of ")#mi("{{\\bf C}}")#text(" is a polynomial combination ")#mi("{P(i)}")#text(" of ")#mi("{i}")#text(" with real coefficients; in particular, any subring of ")#mi("{{\\bf C}}")#text(" that contains ")#mi("{{\\bf R}}")#text(" and ")#mi("{i}")#text(" will necessarily have to contain every element of ")#mi("{{\\bf C}}")#text(". Thus ")#mi("{{\\bf C}}")#text(" is generated by ")#mi("{{\\bf R}}")#text(" and ")#mi("{i}")#text(".")#linebreak()#text(" The only remaining thing to verify is that ")#mi("{{\\bf C}}")#text(" is a field and not just a commutative ring. In other words, we need to show that every non-zero element of ")#mi("{{\\bf C}}")#text(" has a multiplicative inverse. This stems from a particular property of the polynomial ")#mi("{\\mathrm{x}^2 + 1}")#text(", namely that it is ")#link("https://en.wikipedia.org/wiki/Irreducible_polynomial")[#text("irreducible")]#text(" in ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(". That is to say, we cannot factor ")#mi("{\\mathrm{x}^2+1}")#text(" into non-constant polynomials")

#align(center)[#tao-fit-display[#mitex("\\mathrm{x}^2 + 1 = P(\\mathrm{x}) Q(\\mathrm{x})")]]

#text("with ")#mi("{P(\\mathrm{x}), Q(\\mathrm{x}) \\in {\\bf R}[\\mathrm{x}]}")#text(". Indeed, as ")#mi("{\\mathrm{x}^2+1}")#text(" has degree two, the only possible way such a factorisation could occur is if ")#mi("{P(\\mathrm{x}), Q(\\mathrm{x})}")#text(" both have degree one, which would imply that the polynomial ")#mi("{x^2+1}")#text(" has a root in the reals ")#mi("{{\\bf R}}")#text(", which of course it does not.")#linebreak()#text(" Because the polynomial ")#mi("{\\mathrm{x}^2+1}")#text(" is irreducible, it is also ")#link("https://en.wikipedia.org/wiki/Prime_element")[#text("prime")]#text(": if ")#mi("{\\mathrm{x}^2+1}")#text(" divides a product ")#mi("{P(\\mathrm{x}) Q(\\mathrm{x})}")#text(" of two polynomials in ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(", then it must also divide at least one of the factors ")#mi("{P(\\mathrm{x})}")#text(", ")#mi("{Q(\\mathrm{x})}")#text(". Indeed, if ")#mi("{\\mathrm{x}^2 + 1}")#text(" does not divide ")#mi("{P(\\mathrm{x})}")#text(", then by irreducibility the greatest common divisor of ")#mi("{\\mathrm{x}^2+1}")#text(" and ")#mi("{P(\\mathrm{x})}")#text(" is ")#mi("{1}")#text(". Applying the ")#link("https://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text(" for polynomials, we then obtain a representation of ")#mi("{1}")#text(" as")

#align(center)[#tao-fit-display[#mitex("1 = R(\\mathrm{x}) (\\mathrm{x}^2+1) + S(\\mathrm{x}) P(\\mathrm{x})")]]

#text("for some polynomials ")#mi("{R(\\mathrm{x}), S(\\mathrm{x})}")#text("; multiplying both sides by ")#mi("{Q(\\mathrm{x})}")#text(", we conclude that ")#mi("{Q(\\mathrm{x})}")#text(" is a multiple of ")#mi("{\\mathrm{x}^2+1}")#text(".")#linebreak()#text(" Since ")#mi("{\\mathrm{x}^2+1}")#text(" is prime, the quotient space ")#mi("{{\\bf C} = {\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2+1 \\rangle}")#text(" is an ")#link("https://en.wikipedia.org/wiki/Integral_domain")[#text("integral domain")]#text(": there are no ")#link("https://en.wikipedia.org/wiki/Zero_divisor")[#text("zero-divisors")]#text(" in ")#mi("{{\\bf C}}")#text(" other than zero. This brings us closer to the task of showing that ")#mi("{{\\bf C}}")#text(" is a field, but we are not quite there yet; note for instance that ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" is an integral domain, but not a field. But one can finish up by using finite dimensionality. As ")#mi("{{\\bf C}}")#text(" is a ring containing the field ")#mi("{{\\bf R}}")#text(", it is certainly a vector space over ")#mi("{{\\bf R}}")#text("; as ")#mi("{{\\bf C}}")#text(" is generated by ")#mi("{{\\bf R}}")#text(" and ")#mi("{i}")#text(", and ")#mi("{i^2=-1}")#text(", we see that it is in fact a two-dimensional vector space over ")#mi("{{\\bf R}}")#text(", spanned by ")#mi("{1}")#text(" and ")#mi("{i}")#text(" (which are linearly independent, as ")#mi("{i}")#text(" clearly cannot be real). In particular, it is finite dimensional. For any non-zero ")#mi("{z \\in {\\bf C}}")#text(", the multiplication map ")#mi("{w \\mapsto zw}")#text(" is an ")#mi("{{\\bf R}}")#text("-linear map from this finite-dimensional vector space to itself. As ")#mi("{{\\bf C}}")#text(" is an integral domain, this map is injective; by finite-dimensionality, it is therefore surjective (by the ")#link("https://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text("). In particular, there exists ")#mi("{w}")#text(" such that ")#mi("{zw = 1}")#text(", and hence ")#mi("{z}")#text(" is invertible and ")#mi("{{\\bf C}}")#text(" is a field. This concludes the construction of a complex field ")#mi("{{\\bf C}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can think of the action of passing from a ring ")#mi("{R}")#text(" to a quotient ")#mi("{R/I}")#text(" by some ideal ")#mi("{I}")#text(" as the action of forcing some relations to hold between the various elements of ")#mi("{R}")#text(", by requiring all the elements of the ideal ")#mi("{I}")#text(" (or equivalently, all the generators of ")#mi("{I}")#text(") to vanish. Thus one can think of ")#mi("{{\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2 + 1 \\rangle}")#text(" as the ring formed by adjoining a new element ")#mi("{i}")#text(" to the existing ring ")#mi("{{\\bf R}}")#text(" and then demanding the constraint ")#mi("{i^2+1=0}")#text(". With this perspective, the main issues to check in order to obtain a complex field are firstly that these relations do not collapse the ring so much that two previously distinct elements of ")#mi("{{\\bf R}}")#text(" become equal, and secondly that all the non-zero elements become invertible once the relations are imposed, so that we obtain a field rather than merely a ring or integral domain.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" It is instructive to compare the complex field ")#mi("{{\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2 + 1 \\rangle}")#text(", formed by adjoining the square root of ")#mi("{-1}")#text(" to the reals, with other commutative rings such as the ")#link("https://en.wikipedia.org/wiki/Dual_number")[#text("dual numbers")]#text(" ")#mi("{{\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2 \\rangle}")#text(" (which adjoins an additional square root of ")#mi("{0}")#text(" to the reals) or the ")#link("https://en.wikipedia.org/wiki/Split-complex_number")[#text("split complex numbers")]#text(" ")#mi("{{\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2 - 1 \\rangle}")#text(" (which adjoins a new root of ")#mi("{+1}")#text(" to the reals). The latter two objects are perfectly good rings, but are not fields (they contain zero divisors, and the first ring even contains a nilpotent). This is ultimately due to the reducible nature of the polynomials ")#mi("{\\mathrm{x}^2}")#text(" and ")#mi("{\\mathrm{x}^2-1}")#text(" in ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(".")
]

#text("Uniqueness of ")#mi("{{\\bf C}}")#text(" up to isomorphism is a straightforward exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Uniqueness up to isomorphism)")]#text(" ")#metadata(none) <tao-00283b765262a9b9e48c>#text(" Suppose that one has two complex fields ")#mi("{{\\bf C} = ({\\bf C},i)}")#text(" and ")#mi("{{\\bf C}^{\\prime} = ({\\bf C}^{\\prime},i^{\\prime})}")#text(". Show that there is a unique field isomorphism ")#mi("{\\iota: {\\bf C} \\rightarrow {\\bf C}^{\\prime}}")#text(" that maps ")#mi("{i}")#text(" to ")#mi("{i^{\\prime}}")#text(" and is the identity on ")#mi("{{\\bf R}}")#text(".")
]

#text("Now that we have existence and uniqueness up to isomorphism, it is safe to designate one of the complex fields ")#mi("{{\\bf C} = ({\\bf C},i)}")#text(" as ")#emph[#text("the")]#text(" complex field; the other complex fields out there will no longer be of much importance in this course (or indeed, in most of mathematics), with one small exception that we will get to later in this section. One can, if one wishes, use the above abstract algebraic construction ")#mi("{( {\\bf R}[\\mathrm{x}] / \\langle \\mathrm{x}^2+1 \\rangle, \\mathrm{x} + \\langle \\mathrm{x}^2 + 1 \\rangle)}")#text(" as the choice for “the” complex field ")#mi("{{\\bf C}}")#text(", but one can certainly pick other choices if desired (e.g. the Argand plane construction in Remark ")#link(<tao-57a1468eb17b7296da69>)[#text("7")]#text(" below). But in view of Exercise ")#link(<tao-00283b765262a9b9e48c>)[#text("4")]#text(", the precise construction of ")#mi("{{\\bf C}}")#text(" is not terribly relevant for the purposes of actually doing complex analysis, much as the question of whether to construct the real numbers ")#mi("{{\\bf R}}")#text(" using Dedekind cuts, equivalence classes of Cauchy sequences, or some other construction is not terribly relevant for the purposes of actually doing real analysis. So, from here on out, we will no longer refer to the precise construction of ")#mi("{{\\bf C}}")#text(" used; the reader may certainly substitute his or her own favourite construction of ")#mi("{{\\bf C}}")#text(" in place of ")#mi("{{\\bf R}[\\mathbf{x}] / \\langle {\\mathbf x}^2 + 1 \\rangle}")#text(" if desired, with essentially no change to the rest of the lecture notes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{k}")#text(" be an arbitrary field, let ")#mi("{k[\\mathrm{x}]}")#text(" be the ring of polynomials with coefficients in ")#mi("{k}")#text(", and let ")#mi("{P(\\mathrm{x})}")#text(" be an irreducible polynomial in ")#mi("{k[\\mathrm{x}]}")#text(" of degree at least two. Show that ")#mi("{k[\\mathrm{x}] / \\langle P(\\mathrm{x}) \\rangle}")#text(" is a field containing an embedded copy of ")#mi("{k}")#text(", as well as a root ")#mi("{\\alpha}")#text(" of the equation ")#mi("{P(\\alpha)=0}")#text(", and that this field is generated by ")#mi("{k}")#text(" and ")#mi("{\\alpha}")#text(". Also show that all such fields are unique up to isomorphism. (This field ")#mi("{k[\\mathrm{x}] / \\langle P(\\mathrm{x}) \\rangle}")#text(" is an example of a ")#link("https://en.wikipedia.org/wiki/Field_extension")[#text("field extension")]#text(" of ")#mi("{k}")#text(", the further study of which can be found in any advanced undergraduate or early graduate text on algebra, and is the starting point in particular for the beautiful topic of ")#link("https://en.wikipedia.org/wiki/Galois_theory")[#text("Galois theory")]#text(", which we will not discuss here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{k}")#text(" be an arbitrary field. Show that every non-constant polynomial ")#mi("{P(\\mathrm{x})}")#text(" in ")#mi("{k[\\mathrm{x}]}")#text(" can be factored as the product ")#mi("{P_1(\\mathrm{x}) \\dots P_r(\\mathrm{x})}")#text(" of irreducible non-constant polynomials. Furthermore show that this factorisation is unique up to permutation of the factors ")#mi("{P_1(\\mathrm{x}),\\dots,P_r(\\mathrm{x})}")#text(", and multiplication of each of the factors by a constant (with the product of all such constants being one). In other words: the polynomial ring ")#mi("{k[\\mathrm{x}]}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Unique_factorization_domain")[#text("unique factorisation domain")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7 (Real and imaginary coordinates)")]#text(" ")#metadata(none) <tao-57a1468eb17b7296da69>#text(" As a complex field ")#mi("{{\\bf C}}")#text(" is spanned (over ")#mi("{{\\bf R}}")#text(") by the linearly independent elements ")#mi("{1}")#text(" and ")#mi("{i}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("{\\bf C} = \\{ a + b i: a,b \\in {\\bf R} \\}")]]

#text("with each element ")#mi("{z}")#text(" of ")#mi("{{\\bf C}}")#text(" having a unique representation of the form ")#mi("{a+bi}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("a+bi = c+di \\iff a=c \\text{ and } b=d")]]

#text("for real ")#mi("{a,b,c,d}")#text(". The addition, subtraction, and multiplication operations can then be written down explicitly in these coordinates as")

#tao-aligned(keep: true)[


#tao-math("(a+bi) + (c+di)  & = (a+c) + (b+d)i", block: true)



#tao-math("(a+bi) - (c+di)  & = (a-c) + (b-d)i", block: true)



#tao-math("(a+bi) (c+di)  & = (ac-bd) + (ad+bc)i", block: true)
]

#text("and with a bit more work one can compute the division operation as")

#align(center)[#tao-fit-display[#mitex("\\frac{a+bi}{c+di} = \\frac{ac+bd}{c^2+d^2} + \\frac{bc-ad}{c^2+d^2} i")]]

#text("if ")#mi("{c+di \\neq 0}")#text(". One could take these coordinate representations as the ")#emph[#text("definition")]#text(" of the complex field ")#mi("{{\\bf C}}")#text(" and its basic arithmetic operations, and this is indeed done in many texts introducing the complex numbers. In particular, one could take the ")#link("https://en.wikipedia.org/wiki/Argand_plane")[#text("Argand plane")]#text(" ")#mi("{({\\bf R}^2, (0,1))}")#text(" as the choice of complex field, where we identify each point ")#mi("{(a,b)}")#text(" in ")#mi("{{\\bf R}^2}")#text(" with ")#mi("{a+bi}")#text(" (so for instance ")#mi("{{\\bf R}^2}")#text(" becomes endowed with the multiplication operation ")#mi("{(a,b) (c,d) = (ac-bd,ad+bc)}")#text("). This is a very concrete and direct way to construct the complex numbers; the main drawback is that it is not immediately obvious that the field axioms are all satisfied. For instance, the associativity of multiplication is rather tedious to verify in the coordinates of the Argand plane. In contrast, the more abstract algebraic construction of the complex numbers given above makes it more evident what the source of the field structure on ")#mi("{{\\bf C}}")#text(" is, namely the irreducibility of the polynomial ")#mi("{\\mathrm{x}^2+1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Because of the Argand plane construction, we will sometimes refer to the space ")#mi("{{\\bf C}}")#text(" of complex numbers as the ")#emph[#text("complex plane")]#text(". We should warn, though, that in some areas of mathematics, particularly in algebraic geometry, ")#mi("{{\\bf C}}")#text(" is viewed as a one-dimensional complex vector space (or a one-dimensional complex manifold or complex variety), and so ")#mi("{{\\bf C}}")#text(" is sometimes referred to in those cases as a ")#emph[#text("complex line")]#text(". (Similarly, ")#link("https://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surfaces")]#text(", which from a real point of view are two-dimensional surfaces, can sometimes be referred to as ")#emph[#text("complex curves")]#text(" in the literature; the ")#link("https://en.wikipedia.org/wiki/Modular_curve")[#text("modular curve")]#text(" is a famous instance of this.) In this current course, though, the topological notion of dimension turns out to be more important than the algebraic notions of dimension, and as such we shall generally refer to ")#mi("{{\\bf C}}")#text(" as a plane rather than a line.")
]

#text("Elements of ")#mi("{{\\bf C}}")#text(" of the form ")#mi("{bi}")#text(" for ")#mi("{b}")#text(" real are known as ")#emph[#text("purely imaginary numbers")]#text("; the terminology is colourful, but despite the name, imaginary numbers have precisely the same first-class mathematical object status as real numbers. If ")#mi("{z=a+bi}")#text(" is a complex number, the real components ")#mi("{a,b}")#text(" of ")#mi("{z}")#text(" are known as the ")#emph[#text("real part")]#text(" ")#mi("{\\mathrm{Re}(z)}")#text(" and ")#emph[#text("imaginary part")]#text(" ")#mi("{\\mathrm{Im}(z)}")#text(" of ")#mi("{z}")#text(" respectively. Complex numbers that are not real are occasionally referred to as ")#emph[#text("strictly complex numbers")]#text(". In the complex plane, the set ")#mi("{{\\bf R}}")#text(" of real numbers forms the ")#emph[#text("real axis")]#text(", and the set ")#mi("{i{\\bf R}}")#text(" of imaginary numbers forms the ")#emph[#text("imaginary axis")]#text(". Traditionally, elements of ")#mi("{{\\bf C}}")#text(" are denoted with symbols such as ")#mi("{z}")#text(", ")#mi("{w}")#text(", or ")#mi("{\\zeta}")#text(", while symbols such as ")#mi("{a,b,c,d,x,y}")#text(" are typically intended to represent real numbers instead.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" We noted earlier that the equation ")#mi("{x^2+1=0}")#text(" had no solutions in the reals because ")#mi("{x^2+1}")#text(" was always positive. In other words, the properties of the order relation ")#mi("{<}")#text(" on ")#mi("{{\\bf R}}")#text(" prevented the existence of a root for the equation ")#mi("{x^2+1=0}")#text(". As ")#mi("{{\\bf C}}")#text(" does have a root for ")#mi("{x^2+1=0}")#text(", this means that the complex numbers ")#mi("{{\\bf C}}")#text(" cannot be ordered in the same way that the reals are ordered (that is to say, being totally ordered, with the positive numbers closed under both addition and multiplication). Indeed, one usually refrains from putting any order structure on the complex numbers, so that statements such as ")#mi("{z < w}")#text(" for complex numbers ")#mi("{z,w}")#text(" are left undefined (unless ")#mi("{z,w}")#text(" are real, in which case one can of course use the real ordering). In particular, the complex number ")#mi("{i}")#text(" is considered to be neither positive nor negative, and an assertion such as ")#mi("{z<w}")#text(" is understood to implicitly carry with it the claim that ")#mi("{z,w}")#text(" are real numbers and not just complex numbers. (Of course, if one really wants to, one can find some total orderings to place on ")#mi("{{\\bf C}}")#text(", e.g. ")#link("https://en.wikipedia.org/wiki/Lexicographical_order")[#text("lexicographical ordering")]#text(" on the real and imaginary parts. However, such orderings do not interact too well with the algebraic structure of ")#mi("{{\\bf C}}")#text(" and are rarely useful in practice.)")
]

#text("As with any other field, we can raise a complex number ")#mi("{z}")#text(" to a non-negative integer ")#mi("{n}")#text(" by declaring inductively ")#mi("{z^0 := 1}")#text(" and ")#mi("{z^{n+1} := z \\times z^n}")#text(" for ")#mi("{n \\geq 0}")#text("; in particular we adopt the usual convention that ")#mi("{0^0=1}")#text(" (when thinking of the base ")#mi("{0}")#text(" as a complex number, and the exponent ")#mi("{0}")#text(" as a non-negative integer). For negative integers ")#mi("{n = -m}")#text(", we define ")#mi("{z^n = 1/z^m}")#text(" for non-zero ")#mi("{z}")#text("; we leave ")#mi("{z^n}")#text(" undefined when ")#mi("{z}")#text(" is zero and ")#mi("{n}")#text(" is negative. At the present time we do not attempt to define ")#mi("{z^\\alpha}")#text(" for any exponent ")#mi("{\\alpha}")#text(" other than an integer; we will return to such exponentiation operations later in the course, though we will at least define the complex exponential ")#mi("{e^z}")#text(" for any complex ")#mi("{z}")#text(" later in this set of notes.")

#text("By definition, a complex field ")#mi("{({\\bf C},i)}")#text(" is a field ")#mi("{{\\bf C}}")#text(" together with a root ")#mi("{z=i}")#text(" of the equation ")#mi("{z^2+1=0}")#text(". But if ")#mi("{z=i}")#text(" is a root of the equation ")#mi("{z^2+1=0}")#text(", then so is ")#mi("{z=-i}")#text(" (indeed, from the factorisation ")#mi("{z^2+1 = (z-i) (z+i)}")#text(" we see that these are the only two roots of this quadratic equation. Thus we have another complex field ")#mi("{\\overline{{\\bf C}} := ({\\bf C},-i)}")#text(" which differs from ")#mi("{{\\bf C}}")#text(" only in the choice of root ")#mi("{i}")#text(". By Exercise ")#link(<tao-00283b765262a9b9e48c>)[#text("4")]#text(", there is a unique field isomorphism from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf C}}")#text(" that maps ")#mi("{i}")#text(" to ")#mi("{-i}")#text(" (i.e. a complex field isomorphism from ")#mi("{{\\bf C}}")#text(" to ")#mi("{\\overline{{\\bf C}}}")#text("); this operation is known as ")#link("https://en.wikipedia.org/wiki/Complex_conjugate")[#text("complex conjugation")]#text(" and is denoted ")#mi("{z \\mapsto \\overline{z}}")#text(". In coordinates, we have")

#align(center)[#tao-fit-display[#mitex("\\overline{a+bi} = a-bi.")]]

#text("Being a field isomorphism, we have in particular that")

#align(center)[#tao-fit-display[#mitex("\\overline{z+w} = \\overline{z} + \\overline{w}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\overline{zw} = \\overline{z}\\ \\overline{w}")]]

#text("for all complex numbers ")#mi("{z,w}")#text(". It is also clear that complex conjugation fixes the real numbers, and only the real numbers: ")#mi("{z = \\overline{z}}")#text(" if and only if ")#mi("{z}")#text(" is real. Geometrically, complex conjugation is the operation of reflection in the complex plane across the real axis. It is clearly an ")#link("https://en.wikipedia.org/wiki/Involution_(mathematics)")[#text("involution")]#text(" in the sense that it is its own inverse:")

#align(center)[#tao-fit-display[#mitex("\\overline{\\overline{z}} = z.")]]

#text("One can also relate the real and imaginary parts to complex conjugation via the identities ")#metadata(none) <tao-b5a170558ac2218fcd4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mathrm{Re}(z) = \\frac{z + \\overline{z}}{2}; \\quad \\mathrm{Im}(z) = \\frac{z-\\overline{z}}{2i}.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" Any field automorphism of ")#mi("{{\\bf C}}")#text(" has to map ")#mi("{i}")#text(" to a root of ")#mi("{z^2+1=0}")#text(", and so the only field automorphisms of ")#mi("{{\\bf C}}")#text(" that preserve the real line are the identity map and the conjugation map; conversely, the real line is the subfield of ")#mi("{{\\bf C}}")#text(" fixed by both of these automorphisms. In the language of ")#link("https://en.wikipedia.org/wiki/Galois_theory")[#text("Galois theory")]#text(", this means that ")#mi("{{\\bf C}}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Galois_extension")[#text("Galois extension")]#text(" of ")#mi("{{\\bf R}}")#text(", with ")#emph[#text("Galois group")]#text(" ")#mi("{\\mathrm{Gal}({\\bf C}/{\\bf R})}")#text(" consisting of two elements. There is a certain sense in which one can think of the complex numbers (or more precisely, the ")#link("https://en.wikipedia.org/wiki/Scheme_(mathematics)")[#text("scheme")]#text(" ")#mi("{{\\mathcal C}}")#text(" of complex numbers) as a double cover of the real numbers (or more precisely, the scheme ")#mi("{{\\mathcal R}}")#text(" of real numbers), analogous to how the boundary of a Möbius strip can be viewed as a double cover of the unit circle formed by shrinking the width of the strip to zero. (In this analogy, points on the unit circle correspond to specific models of the real number system ")#mi("{{\\bf R}}")#text(", and lying above each such point are two specific models ")#mi("{({\\bf C}, i)}")#text(", ")#mi("{({\\bf C},-i)}")#text(" of the complex number system; this analogy can be made precise using Grothendieck’s “functor of points” interpretation of schemes.) The operation of complex conjugation is then analogous to the operation of ")#link("https://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(" caused by looping once around the base unit circle, causing the two complex fields sitting above a real field to swap places with each other. (This analogy is not quite perfect, by the way, because the boundary of a Möbius strip is not simply connected and can in turn be finitely covered by other curves, whereas the complex numbers are algebraically complete and admit no further finite extensions; one should really replace the unit circle here by something with a two-element fundamental group, such as the projective plane ")#mi("{\\mathbf{RP}^2}")#text(" that is double covered by the sphere ")#mi("{S^2}")#text(", but this is harder to visualize.) The analogy between (")#link("https://en.wikipedia.org/wiki/Absolute_Galois_group")[#text("absolute")]#text(") Galois groups and fundamental groups suggested by this picture can be made precise in scheme theory by introducing the concept of an ")#link("https://en.wikipedia.org/wiki/%C3%89tale_fundamental_group")[#text("étale fundamental group")]#text(", which unifies the two concepts, but developing this further is well beyond the scope of this course; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2548205")[#text("this book of Szamuely")]#text(" for further discussion.")
]

#text("Observe that if we multiply a complex number ")#mi("{z}")#text(" by its complex conjugate ")#mi("{\\overline{z}}")#text(", we obtain a quantity ")#mi("{N(z) := z \\overline{z}}")#text(" which is invariant with respect to conjugation (i.e. ")#mi("{\\overline{N(z)} = N(z)}")#text(") and is therefore real. The map ")#mi("{N: {\\bf C} \\rightarrow {\\bf R}}")#text(" produced this way is known in field theory as the ")#link("https://en.wikipedia.org/wiki/Norm_form")[#text("norm form")]#text(" of ")#mi("{{\\bf C}}")#text(" over ")#mi("{{\\bf R}}")#text("; it is clearly multiplicative in the sense that ")#mi("{N(zw) = N(z) N(w)}")#text(", and is only zero when ")#mi("{z}")#text(" is zero. It can be used to link multiplicative inversion with complex conjugation, in that we clearly have ")#metadata(none) <tao-2b4e5423744ef67450b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{z} = \\frac{\\overline{z}}{N(z)}")]]

#linebreak()#text(" for any non-zero complex number ")#mi("{z}")#text(". In coordinates, we have")

#align(center)[#tao-fit-display[#mitex("N(a+bi) = (a+bi) (a-bi) = a^2+b^2")]]

#text("(thus recovering, by the way, the inversion formula ")#mi("{\\frac{1}{a+bi} = \\frac{a}{a^2+b^2} - \\frac{b}{a^2+b^2} i}")#text(" implicit in Remark ")#link(<tao-57a1468eb17b7296da69>)[#text("7")]#text("). In coordinates, the multiplicativity ")#mi("{N(zw) = N(z) N(w)}")#text(" takes the form of ")#link("https://en.wikipedia.org/wiki/Lagrange%27s_identity")[#text("Lagrange’s identity")]

#align(center)[#tao-fit-display[#mitex("(ac-bd)^2 + (ad+bc)^2 = (a^2+b^2) (c^2+d^2)")]]

#heading(level: 1)[#strong[#text(" — 2. The geometry of the complex numbers — ")]]

#text("The norm form ")#mi("{N}")#text(" of the complex numbers has the feature of being positive definite: ")#mi("{N(z)}")#text(" is always non-negative (and strictly positive when ")#mi("{z}")#text(" is non-zero). This is a feature that is somewhat special to the complex numbers; for instance, the quadratic extension ")#mi("{{\\bf Q}(\\sqrt{2})}")#text(" of the rationals ")#mi("{{\\bf Q}}")#text(" by ")#mi("{\\sqrt{2}}")#text(" has the norm form ")#mi("{N(n+m\\sqrt{2}) = (n+m\\sqrt{2}) (n-m\\sqrt{2}) = n^2-2m^2}")#text(", which is indefinite. One can view this positive definiteness of the norm form as the one remaining vestige in ")#mi("{{\\bf C}}")#text(" of the order structure ")#mi("{<}")#text(" on the reals, which as remarked previously is no longer present directly in the complex numbers. (One can also view the positive definiteness of the norm form as a consequence of the topological connectedness of the punctured complex plane ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(": the norm form is positive at ")#mi("{z=1}")#text(", and cannot change sign anywhere in ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", so is forced to be positive on the rest of this connected region.)")

#text("One consequence of positive definiteness is that the ")#link("https://en.wikipedia.org/wiki/Bilinear_form")[#text("bilinear form")]

#align(center)[#tao-fit-display[#mitex("\\langle z, w \\rangle := \\mathrm{Re}( z \\overline{w} )")]]

#text("becomes a positive definite inner product on ")#mi("{{\\bf C}}")#text(" (viewed as a vector space over ")#mi("{{\\bf R}}")#text("). In particular, this turns the complex numbers into an ")#link("https://en.wikipedia.org/wiki/Inner_product_space")[#text("inner product space")]#text(" over the reals. From the usual theory of inner product spaces, we can then construct a norm")

#align(center)[#tao-fit-display[#tao-math("\\left|z\\right| := \\langle z, z \\rangle^{1/2} = N(z)^{1/2}", block: true)]]

#text("(thus, the norm is the square root of the norm form) which obeys the triangle inequality ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|z+w\\right| \\leq \\left|z\\right| + \\left|w\\right|;", block: true)]]

#text("(which implies the usual permutations of this inequality, such as ")#tao-math("{\\left|\\left|z\\right|-\\left|w\\right|\\right| \\leq \\left|z-w\\right| \\leq \\left|z\\right| + \\left|w\\right|}", block: false)#text("), and from the multiplicativity of the norm form we also have ")#metadata(none) <tao-c0c75a8e79ad011929e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|zw\\right| = \\left|z\\right| \\left|w\\right|", block: true)]]

#text("(and hence also ")#tao-math("{\\left|z/w\\right| = \\left|z\\right|/\\left|w\\right|}", block: false)#text(" if ")#mi("{w}")#text(" is non-zero) and from the involutive nature of complex conjugation we have ")#metadata(none) <tao-f562267f2b6d890a7c0c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\overline{z}\\right| = \\left|z\\right|.", block: true)]]

#text("The norm ")#mi("{|\\cdot|}")#text(" clearly extends the ")#link("https://en.wikipedia.org/wiki/Absolute_value")[#text("absolute value operation")]#text(" ")#tao-math("{x \\mapsto \\left|x\\right|}", block: false)#text(" on the real numbers, and so we also refer to the norm ")#tao-math("{\\left|z\\right|}", block: false)#text(" of a complex number ")#mi("{z}")#text(" as its ")#emph[#text("absolute value")]#text(" or ")#emph[#text("magnitude")]#text(". In coordinates, we have ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|a+bi\\right| = \\sqrt{a^2+b^2},", block: true)]]

#text("thus for instance ")#tao-math("{\\left|i\\right|=1}", block: false)#text(", and from ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(6)")]#text(" we also immediately have the useful inequalities ")#metadata(none) <tao-ac20e97c2070ec2066ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\mathrm{Re}(z)\\right|, \\left|\\mathrm{Im}(z)\\right| \\leq \\left|z\\right| \\leq \\left|\\mathrm{Re}(z)\\right| + \\left|\\mathrm{Im}(z)\\right|.", block: true)]]

#text("As with any other ")#link("https://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector space")]#text(", the norm ")#tao-math("{z \\mapsto \\left|z\\right|}", block: false)#text(" defines a metric on the complex numbers via the definition")

#align(center)[#tao-fit-display[#tao-math("d(z,w) := \\left|z-w\\right|.", block: true)]]

#text("Note that using the Argand plane representation of ")#mi("{{\\bf C}}")#text(" as ")#mi("{{\\bf R}^2}")#text(" that this metric coincides with the usual Euclidean metric on ")#mi("{{\\bf R}^2}")#text(". This metric in turn defines a topology on ")#mi("{{\\bf C}}")#text(" (generated in the usual manner by the open disks ")#tao-math("{D(z,r) := \\{ w \\in {\\bf C}: \\left|z-w\\right| < r \\}}", block: false)#text("), which in turn generates all the usual topological notions such as the concept of an open set, closed set, compact set, connected set, and boundary of a set; the notion of a limit of a sequence ")#mi("{z_n}")#text("; the notion of a continuous map, and so forth. For instance, a sequence ")#mi("{z_n}")#text(" of complex numbers converges to a limit ")#mi("{z \\in {\\bf C}}")#text(" if ")#tao-math("{\\left|z_n -z\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and a map ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is continuous if one has ")#mi("{f(z_n) \\rightarrow f(z)}")#text(" whenever ")#mi("{z_n \\rightarrow z}")#text(", or equivalently if the inverse image of any open set is open. Again, using the Argand plane representation, these notions coincide with their counterparts on the Euclidean plane ")#mi("{{\\bf R}^2}")#text(".")#linebreak()#text(" As usual, if a sequence ")#mi("{z_n}")#text(" of complex numbers converges to a limit ")#mi("{z}")#text(", we write ")#mi("{z = \\lim_{n \\rightarrow \\infty} z_n}")#text(". From the triangle inequality ")#link(<tao-cddd67830982a78cc839>)[#text("(3)")]#text(" and the multiplicativity property ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(4)")]#text(" we see that the addition operation ")#mi("{+: {\\bf C} \\times {\\bf C} \\rightarrow {\\bf C}}")#text(", subtraction operation ")#mi("{-: {\\bf C} \\times {\\bf C} \\rightarrow {\\bf C}}")#text(", and multiplication operation ")#mi("{\\times: {\\bf C} \\times {\\bf C} \\rightarrow {\\bf C}}")#text(", thus we have the familiar limit laws")

#tao-aligned(keep: true)[


#tao-math("\\lim_{n \\rightarrow \\infty} (z_n + w_n)  & = \\lim_{n \\rightarrow \\infty} z_n + \\lim_{n \\rightarrow \\infty} w_n,", block: true)



#tao-math("\\lim_{n \\rightarrow \\infty} (z_n - w_n)  & = \\lim_{n \\rightarrow \\infty} z_n - \\lim_{n \\rightarrow \\infty} w_n", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} (z_n \\cdot w_n) = \\lim_{n \\rightarrow \\infty} z_n \\cdot \\lim_{n \\rightarrow \\infty} w_n")]]

#text("whenever the limits on the right-hand side exist. Similarly, from ")#link(<tao-f562267f2b6d890a7c0c>)[#text("(5)")]#text(" we see that complex conjugation is an isometry of the complex numbers, thus")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\overline{z_n} = \\overline{\\lim_{n \\rightarrow \\infty} z_n}")]]

#text("when the limit on the right-hand side exists. As a consequence, the norm form ")#mi("{N: {\\bf C} \\rightarrow {\\bf R}}")#text(" and the absolute value ")#mi("{|\\cdot|: {\\bf C} \\rightarrow {\\bf R}}")#text(" are also continuous, thus")

#align(center)[#tao-fit-display[#tao-math("\\lim_{n \\rightarrow \\infty} \\left|z_n\\right| = \\left|\\lim_{n \\rightarrow \\infty} z_n\\right|", block: true)]]

#text("whenever the limit on the right-hand side exists. Using the formula ")#link(<tao-2b4e5423744ef67450b8>)[#text("(2)")]#text(" for the reciprocal of a complex number, we also see that division is a continuous operation as long as the denominator is non-zero, thus")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\frac{z_n}{w_n} = \\frac{\\lim_{n \\rightarrow \\infty} z_n}{\\lim_{n \\rightarrow \\infty} w_n}")]]

#text("as long as the limits on the right-hand side exist, and the limit in the denominator is non-zero.")#linebreak()#text(" From ")#link(<tao-ac20e97c2070ec2066ed>)[#text("(7)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("z_n \\rightarrow z \\iff \\mathrm{Re}(z_n) \\rightarrow \\mathrm{Re}(z) \\text{ and } \\mathrm{Im}(z_n) \\rightarrow \\mathrm{Im}(z);")]]

#text("in particular")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mathrm{Re}(z_n) = \\mathrm{Re} \\lim_{n \\rightarrow \\infty} z_n")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} \\mathrm{Im}(z_n) = \\mathrm{Im} \\lim_{n \\rightarrow \\infty} z_n")]]

#text("whenever the limit on the right-hand side exists. One consequence of this is that ")#mi("{{\\bf C}}")#text(" is ")#link("https://en.wikipedia.org/wiki/Complete_metric_space")[#text("complete")]#text(": every sequence ")#mi("{z_n}")#text(" of complex numbers that is a Cauchy sequence (thus ")#tao-math("{\\left|z_n-z_m\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n,m \\rightarrow \\infty}")#text(") converges to a unique complex limit ")#mi("{z}")#text(". (As such, one can view the complex numbers as a (very small) example of a ")#link("https://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space")]#text(".)")#linebreak()#text(" As with the reals, we have the fundamental fact that any formal series ")#mi("{\\sum_{n=0}^\\infty z_n}")#text(" of complex numbers which is ")#link("https://en.wikipedia.org/wiki/Absolute_convergence")[#text("absolutely convergent")]#text(", in the sense that the non-negative series ")#tao-math("{\\sum_{n=0}^\\infty \\left|z_n\\right|}", block: false)#text(" is finite, is necessarily convergent to some complex number ")#mi("{S}")#text(", in the sense that the partial sums ")#mi("{\\sum_{n=0}^N z_n}")#text(" converge to ")#mi("{S}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(". This is because the triangle inequality ensures that the partial sums are a Cauchy sequence. As usual we write ")#mi("{S = \\sum_{n=0}^\\infty z_n}")#text(" to denote the assertion that ")#mi("{S}")#text(" is the limit of the partial sums ")#mi("{\\sum_{n=0}^N z_n}")#text(". We will occasionally have need to deal with series that are only conditionally convergent rather than absolutely convergent, but in most of our applications the only series we will actually evaluate are the absolutely convergent ones. Many of the limit laws imply analogues for series, thus for instance")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty \\mathrm{Re}(z_n) = \\mathrm{Re} \\sum_{n=0}^\\infty z_n")]]

#text("whenever the series on the right-hand side is absolutely convergent (or even just convergent). We will not write down an exhaustive list of such series laws here.")#linebreak()#text(" An important role in complex analysis is played by the ")#emph[#text("unit circle")]

#align(center)[#tao-fit-display[#tao-math("S^1 := \\{ z \\in {\\bf C}: \\left|z\\right|=1 \\}.", block: true)]]

#text("In coordinates, this is the set of points ")#mi("{a+bi}")#text(" for which ")#mi("{a^2+b^2=1}")#text(", and so this indeed has the geometric structure of a unit circle. Elements of the unit circle will be referred to in these notes as ")#emph[#text("phases")]#text(". Every non-zero complex number ")#mi("{z}")#text(" has a unique ")#link("https://en.wikipedia.org/wiki/Polar_decomposition")[#text("polar decomposition")]#text(" as ")#mi("{z = r \\omega}")#text(" where ")#mi("{r>0}")#text(" is a positive real and ")#mi("{\\omega}")#text(" lies on the unit circle ")#mi("{S^1}")#text(". Indeed, it is easy to see that this decomposition is given by ")#tao-math("{r = \\left|z\\right|}", block: false)#text(" and ")#tao-math("{\\omega = \\frac{z}{\\left|z\\right|}}", block: false)#text(", and that this is the only polar decomposition of ")#mi("{z}")#text(". We refer to the polar components ")#tao-math("{r=\\left|z\\right|}", block: false)#text(" and ")#tao-math("{\\omega = z/\\left|z\\right|}", block: false)#text(" of a non-zero complex number ")#mi("{z}")#text(" as the ")#emph[#text("magnitude")]#text(" and ")#emph[#text("phase")]#text(" of ")#mi("{z}")#text(" respectively.")#linebreak()#text(" From ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(4)")]#text(" we see that the unit circle ")#mi("{S^1}")#text(" is a multiplicative group; it contains the multiplicative identity ")#mi("{1}")#text(", and if ")#mi("{z, w}")#text(" lie in ")#mi("{S^1}")#text(", then so do ")#mi("{zw}")#text(" and ")#mi("{1/z}")#text(". From ")#link(<tao-2b4e5423744ef67450b8>)[#text("(2)")]#text(" we see that reciprocation and complex conjugation agree on the unit circle, thus")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{z} = \\overline{z}")]]

#text("for ")#mi("{z \\in S^1}")#text(". It is worth emphasising that this useful identity does ")#emph[#text("not")]#text(" hold as soon as one leaves the unit circle, in which case one must use the more general formula ")#link(<tao-2b4e5423744ef67450b8>)[#text("(2)")]#text(" instead! If ")#mi("{z_1,z_2}")#text(" are non-zero complex numbers ")#mi("{z_1,z_2}")#text(" with polar decompositions ")#mi("{z_1 = r_1 \\omega_1}")#text(" and ")#mi("{z_2 = r_2 \\omega_2}")#text(" respectively, then clearly the polar decompositions of ")#mi("{z_1 z_2}")#text(" and ")#mi("{z_1/z_2}")#text(" are given by ")#mi("{z_1 z_2 = (r_1 r_2) (\\omega_1 \\omega_2)}")#text(" and ")#mi("{z_1/z_2 = (r_1/r_2) (\\omega_1/\\omega_2)}")#text(" respectively. Thus polar coordinates are very convenient for performing complex multiplication, although they turn out to be atrocious for performing complex addition. (This can be contrasted with the usual Cartesian coordinates ")#mi("{z=a+bi}")#text(", which are very convenient for performing complex addition and mildly inconvenient for performing complex multiplication.) In the language of group theory, the polar decomposition splits the multiplicative complex group ")#mi("{{\\bf C}^\\times = ({\\bf C} \\backslash \\{0\\}, \\times)}")#text(" as the ")#link("https://en.wikipedia.org/wiki/Direct_product_of_groups")[#text("direct product")]#text(" of the positive reals ")#mi("{(0,+\\infty)}")#text(" and the unit circle ")#mi("{S^1}")#text(": ")#mi("{{\\bf C}^\\times \\equiv (0,+\\infty) \\times S^1}")#text(".")#linebreak()#text(" If ")#mi("{\\omega}")#text(" is an element of the unit circle ")#mi("{S^1}")#text(", then from ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(4)")]#text(" we see that the operation ")#mi("{z \\mapsto \\omega z}")#text(" of multiplication by ")#mi("{\\omega}")#text(" is an isometry of ")#mi("{{\\bf C}}")#text(", in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\omega z - \\omega w\\right| = \\left|z-w\\right|", block: true)]]

#text("for all complex numbers ")#mi("{z, w}")#text(". This isometry also preserves the origin ")#mi("{0}")#text(". As such, it is geometrically obvious (see Exercise ")#link(<tao-2c42f720d41266a5f9a5>)[#text("11")]#text(" below) that the map ")#mi("{z \\mapsto \\omega z}")#text(" must either be a rotation around the origin, or a reflection around a line. The former operation is orientation preserving, and the latter is orientation reversing. Since the map ")#mi("{z \\mapsto \\omega z}")#text(" is clearly orientation preserving when ")#mi("{\\omega = 1}")#text(", and the unit circle ")#mi("{S^1}")#text(" is connected, a continuity argument shows that ")#mi("{z \\mapsto \\omega z}")#text(" must be orientation preserving for all ")#mi("{\\omega \\in S^1}")#text(", and so must be a rotation around the origin by some angle. Of course, by trigonometry, we may write")

#align(center)[#tao-fit-display[#mitex("\\omega = \\cos \\theta + i \\sin \\theta")]]

#text("for some real number ")#mi("{\\theta}")#text(". The rotation ")#mi("{z \\mapsto \\omega z}")#text(" clearly maps the number ")#mi("{1}")#text(" to the number ")#mi("{\\cos \\theta + i \\sin \\theta}")#text(", and so the rotation must be a counter-clockwise rotation by ")#mi("{\\theta}")#text(" (adopting the usual convention of placing ")#mi("{1}")#text(" to the right of the origin and ")#mi("{i}")#text(" above it). In particular, when applying this rotation ")#mi("{z \\mapsto \\omega z}")#text(" to another point ")#mi("{\\cos \\phi + i \\sin \\phi}")#text(" on the unit circle, this point must get rotated to ")#mi("{\\cos(\\theta+\\phi) + i \\sin(\\theta+\\phi)}")#text(". We have thus given a geometric proof of the multiplication formula ")#metadata(none) <tao-3687ed048014daac3878>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(\\cos(\\theta + \\phi) + i \\sin(\\theta + \\phi)) = (\\cos \\theta + i \\sin \\theta) (\\cos \\phi + i \\sin \\phi);")]]

#text("taking real and imaginary parts, we recover the familiar ")#link("https://en.wikipedia.org/wiki/List_of_trigonometric_identities#Angle_sum_and_difference_identities")[#text("trigonometric addition formulae")]

#tao-aligned(keep: true)[


#tao-math("\\cos(\\theta+\\phi)  & = \\cos \\theta \\cos \\phi - \\sin \\theta \\sin \\phi", block: true)



#tao-math("\\sin(\\theta+\\phi)  & = \\sin \\theta \\cos \\phi + \\cos \\theta \\sin \\phi.", block: true)
]

#text("We can also iterate the multiplication formula to give ")#link("https://en.wikipedia.org/wiki/De_Moivre%27s_formula")[#text("de Moivre’s formula")]

#align(center)[#tao-fit-display[#mitex("\\cos( n \\theta ) + i \\sin(n \\theta) = (\\cos \\theta + i \\sin \\theta)^n")]]

#text("for any natural number ")#mi("{n}")#text(" (or indeed for any integer ")#mi("{n}")#text("), which can in turn be used to recover familiar identities such as the double angle formulae")

#tao-aligned(keep: true)[


#tao-math("\\cos(2\\theta)  & = \\cos^2 \\theta - \\sin^2 \\theta", block: true)



#tao-math("\\sin(2\\theta)  & = 2 \\sin \\theta \\cos \\theta", block: true)
]

#text("or triple angle formulae")

#tao-aligned(keep: true)[


#tao-math("\\cos(3\\theta)  & = \\cos^3 \\theta - 3 \\sin^2 \\theta \\cos \\theta", block: true)



#tao-math("\\sin(3\\theta)  & = 3 \\sin \\theta \\cos^2 \\theta - \\sin^3 \\theta", block: true)
]

#text("after expanding out de Moivre’s formula for ")#mi("{n=2}")#text(" or ")#mi("{n=3}")#text(" and taking real and imaginary parts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-2c42f720d41266a5f9a5>

#list(
[#text("(i) Let ")#mi("{T: {\\bf R}^2 \\rightarrow {\\bf R}^2}")#text(" be an isometry of the Euclidean plane that fixes the origin ")#mi("{(0,0)}")#text(". Show that ")#mi("{T}")#text(" is either a rotation around the origin by some angle ")#mi("{\\theta \\in {\\bf R}}")#text(", or the reflection around some line through the origin. (")#emph[#text("Hint:")]#text(" try to compose ")#mi("{T}")#text(" with rotations or reflections to achieve some normalisation of ")#mi("{T}")#text(", e.g. that ")#mi("{T}")#text(" fixes ")#mi("{(1,0)}")#text(". Then consider what ")#mi("{T}")#text(" must do to other points in the plane, such as ")#mi("{(0,1)}")#text(". Alternatively, one can use various formulae relating distances to angle, such as the ")#link("https://en.wikipedia.org/wiki/Sine_rule")[#text("sine rule")]#text(" or ")#link("https://en.wikipedia.org/wiki/Law_of_cosines")[#text("cosine rule")]#text(", or the formula ")#tao-math("{\\langle z, w \\rangle = \\left|z\\right| |w| \\cos \\theta}", block: false)#text(" for the inner product.) For this question, you may use any result you already know from Euclidean geometry or trigonometry.")],
[#text("(ii) Show that all isometries ")#mi("{T: {\\bf C} \\rightarrow {\\bf C}}")#text(" of the complex numbers take the form")

#align(center)[#tao-fit-display[#mitex("T(z) = z_0 + \\omega z")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("T(z) = z_0 + \\omega \\overline{z}")]]

#text("for some complex number ")#mi("{z_0}")#text(" and phase ")#mi("{\\omega \\in S^1}")#text(".")]
)
]

#text("Every non-zero complex number ")#mi("{z}")#text(" can now be written in polar form as ")#metadata(none) <tao-f712d322b8f5a7e4431b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("z = r (\\cos(\\theta) + i \\sin(\\theta))")]]

#linebreak()#text(" with ")#mi("{r>0}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text("; we refer to ")#mi("{\\theta}")#text(" as an ")#link("https://en.wikipedia.org/wiki/Argument_(complex_analysis)")[#text("argument")]#text(" of ")#mi("{z}")#text(", and can be interpreted as an angle of counterclockwise rotation needed to rotate the positive real axis to a position that contains ")#mi("{z}")#text(". The argument is not quite unique, due to the periodicity of sine and cosine: if ")#mi("{\\theta}")#text(" is an argument of ")#mi("{z}")#text(", then so is ")#mi("{\\theta + 2\\pi k}")#text(" for any integer ")#mi("{k}")#text(", and conversely these are all the possible arguments that ")#mi("{z}")#text(" can have. The set of all such arguments will be denoted ")#mi("{\\mathrm{arg}(z)}")#text("; it is a coset of the discrete group ")#mi("{2\\pi {\\bf Z} := \\{ 2\\pi k: k \\in {\\bf Z}\\}}")#text(", and can thus be viewed as an element of the ")#mi("{1}")#text("-torus ")#mi("{{\\bf R}/2\\pi{\\bf Z}}")#text(".")#linebreak()#text(" The operation ")#mi("{w \\mapsto zw}")#text(" of multiplying a complex number ")#mi("{w}")#text(" by a given non-zero complex number ")#mi("{z}")#text(" now has a very appealing geometric interpretation when expressing ")#mi("{z}")#text(" in polar coordinates ")#link(<tao-f712d322b8f5a7e4431b>)[#text("(9)")]#text(": this operation is the composition of the operation of dilation by ")#mi("{r}")#text(" around the origin, and counterclockwise rotation by ")#mi("{\\theta}")#text(" around the origin. For instance, multiplication by ")#mi("{i}")#text(" performs a counter-clockwise rotation by ")#mi("{\\pi/2}")#text(" around the origin, while multiplication by ")#mi("{-i}")#text(" performs instead a clockwise rotation by ")#mi("{\\pi/2}")#text(". As complex multiplication is commutative and associative, it does not matter in which order one performs the dilation and rotation operations. Similarly, using Cartesian coordinates, we see that the operation ")#mi("{w \\mapsto z+w}")#text(" of adding a complex number ")#mi("{w}")#text(" by a given complex number ")#mi("{z}")#text(" is simply a spatial ")#emph[#text("translation")]#text(" by a displacement of ")#mi("{z}")#text(". The multiplication operation need not be isometric (due to the presence of the dilation ")#mi("{r}")#text("), but observe that both the addition and multiplication operations are ")#link("https://en.wikipedia.org/wiki/Conformal_map")[#text("conformal")]#text(" (angle-preserving) and also orientation-preserving (a counterclockwise loop will transform to another counterclockwise loop, and similarly for clockwise loops). As we shall see later, these conformal and orientation-preserving properties of the addition and multiplication maps will extend to the larger class of ")#emph[#text("complex differentiable maps")]#text(" (at least outside of ")#link("https://en.wikipedia.org/wiki/Critical_point_(mathematics)")[#text("critical points")]#text(" of the map), and are an important aspect of the geometry of such maps.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" One can also interpret the operations of complex arithmetic geometrically on the Argand plane as follows. As the addition law on ")#mi("{{\\bf C}}")#text(" coincides with the vector addition law on ")#mi("{{\\bf R}^2}")#text(", addition and subtraction of complex numbers is given by the usual parallelogram rule for vector addition; thus, to add a complex number ")#mi("{z}")#text(" to another ")#mi("{w}")#text(", we can translate the complex plane until the origin ")#mi("{0}")#text(" gets mapped to ")#mi("{z}")#text(", and then ")#mi("{w}")#text(" gets mapped to ")#mi("{z+w}")#text("; conversely, subtraction by ")#mi("{z}")#text(" corresponds to translating ")#mi("{z}")#text(" back to ")#mi("{0}")#text(". Similarly, to multiply a complex number ")#mi("{z}")#text(" with another ")#mi("{w}")#text(", we can dilate and rotate the complex plane around the origin until ")#mi("{1}")#text(" gets mapped to ")#mi("{z}")#text(", and then ")#mi("{w}")#text(" will be mapped to ")#mi("{zw}")#text("; conversely, division by ")#mi("{z}")#text(" corresponds to dilating and rotating ")#mi("{z}")#text(" back to ")#mi("{1}")#text(".")
]

#text("When performing computations, it is convenient to restrict the argument ")#mi("{\\theta}")#text(" of a non-zero complex number ")#mi("{z}")#text(" to lie in a ")#link("https://en.wikipedia.org/wiki/Fundamental_domain")[#text("fundamental domain")]#text(" of the ")#mi("{1}")#text("-torus ")#mi("{{\\bf R}/2\\pi{\\bf Z}}")#text(", such as the half-open interval ")#mi("{\\{ \\theta: 0 \\leq \\theta < 2\\pi \\}}")#text(" or ")#mi("{\\{ \\theta: -\\pi < \\theta \\leq \\pi \\}}")#text(", in order to recover a unique parameterisation (at the cost of creating a ")#link("https://en.wikipedia.org/wiki/Branch_point#Branch_cuts")[#text("branch cut")]#text(" at one point of the unit circle). Traditionally, the fundamental domain that is most often used is the half-open interval ")#mi("{\\{ \\theta: -\\pi < \\theta \\leq \\pi \\}}")#text(". The unique argument of ")#mi("{z}")#text(" that lies in this interval is called the ")#emph[#text("standard argument")]#text(" of ")#mi("{z}")#text(" and is denoted ")#mi("{\\mathrm{Arg}(z)}")#text(", and ")#mi("{\\mathrm{Arg}}")#text(" is called the ")#emph[#text("standard branch")]#text(" of the argument function. Thus for instance ")#mi("{\\mathrm{Arg}(1)=0}")#text(", ")#mi("{\\mathrm{Arg}(i) = \\pi/2}")#text(", ")#mi("{\\mathrm{Arg}(-1) = \\pi}")#text(", and ")#mi("{\\mathrm{Arg}(-i) = -\\pi/2}")#text(". Observe that the standard branch of the argument has a discontinuity on the negative real axis ")#mi("{\\{ x \\in {\\bf R}: x \\leq 0\\}}")#text(", which is the ")#emph[#text("branch cut")]#text(" of this branch. Changing the fundamental domain used to define a branch of the argument can move the branch cut around, but cannot eliminate it completely, due to non-trivial ")#link("https://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(" (if one continuously loops once counterclockwise around the origin, and varies the argument continuously as one does so, the argument will increment by ")#mi("{2\\pi}")#text(", and so no branch of the argument function can be continuous at every point on the loop).")

#text("The multiplication formula ")#link(<tao-3687ed048014daac3878>)[#text("(8)")]#text(" resembles the multiplication formula ")#metadata(none) <tao-457be7edac577684f3e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\exp( x + y) = \\exp( x ) \\exp( y )")]]

#linebreak()#text(" for the ")#link("https://en.wikipedia.org/wiki/Exponential_function")[#text("real exponential function")]#text(" ")#mi("{\\exp: {\\bf R} \\rightarrow {\\bf R}}")#text(". The two formulae can be unified through the famous ")#link("https://en.wikipedia.org/wiki/Euler%27s_formula")[#text("Euler formula")]#text(" involving the complex exponential ")#mi("{\\exp: {\\bf C} \\rightarrow {\\bf C}}")#text(". There are many ways to define the complex exponential. Perhaps the most natural is through the ordinary differential equation ")#mi("{\\frac{d}{dz} \\exp(z) = \\exp(z)}")#text(" with boundary condition ")#mi("{\\exp(0)=1}")#text(". However, as we have not yet set up a theory of complex differentiation, we will proceed (at least temporarily) through the device of ")#link("https://en.wikipedia.org/wiki/Taylor_series")[#text("Taylor series")]#text(". Recalling that the real exponential function ")#mi("{\\exp: {\\bf R} \\rightarrow {\\bf R}}")#text(" has the Taylor expansion")

#tao-aligned(keep: true)[


#tao-math("\\exp(x)  & = \\sum_{n=0}^\\infty \\frac{x^n}{n!}", block: true)



#tao-math(" & = 1 + x + \\frac{x^2}{2!} + \\frac{x^3}{3!} + \\dots", block: true)
]

#text("which is absolutely convergent for any real ")#mi("{x}")#text(", one is led to define the complex exponential function ")#mi("{\\exp: {\\bf C} \\rightarrow {\\bf C}}")#text(" by the analogous expansion ")#metadata(none) <tao-f0164915cf681cc7bb1c>

#tao-aligned(keep: true)[


#tao-math("\\exp(z)  & = \\sum_{n=0}^\\infty \\frac{z^n}{n!}", block: true, numbering: n => [#text("(11)")])



#tao-math(" & = 1 + z + \\frac{z^2}{2!} + \\frac{z^3}{3!} + \\dots", block: true)
]

#text("noting from ")#link(<tao-c0c75a8e79ad011929e6>)[#text("(4)")]#text(" that the absolute convergence of the real exponential ")#mi("{\\exp(x)}")#text(" for any ")#mi("{x \\in {\\bf R}}")#text(" implies the absolute convergence of the complex exponential for any ")#mi("{z \\in {\\bf C}}")#text(". We also frequently write ")#mi("{e^z}")#text(" for ")#mi("{\\exp(z)}")#text(". The multiplication formula ")#link(<tao-457be7edac577684f3e5>)[#text("(10)")]#text(" for the real exponential extends to the complex exponential:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Use the ")#link("https://en.wikipedia.org/wiki/Binomial_theorem")[#text("binomial theorem")]#text(" and ")#link("https://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini’s theorem")]#text(" for (complex) doubly infinite series to conclude that ")#metadata(none) <tao-affa729802a1cd006b2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\exp(z+w) = \\exp(z) \\exp(w)")]]

#text("for any complex numbers ")#mi("{z,w}")#text(".")
]

#text("If one compares the Taylor series for ")#mi("{\\exp(z)}")#text(" with the familiar Taylor expansions")

#tao-aligned(keep: true)[


#tao-math("\\sin(x)  & = \\sum_{n=0}^\\infty (-1)^n \\frac{x^{2n+1}}{(2n+1)!}", block: true)



#tao-math(" & = x - \\frac{x^3}{3!} + \\frac{x^5}{5!} - \\dots", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\cos(x)  & = \\sum_{n=0}^\\infty (-1)^n \\frac{x^{2n}}{(2n)!}", block: true)



#tao-math(" & = 1 - \\frac{x^2}{2!} + \\frac{x^4}{4!} - \\dots", block: true)
]

#text("for the (real) sine and cosine functions, one obtains the ")#link("https://en.wikipedia.org/wiki/Euler%27s_formula")[#text("Euler formula")]#text(" ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("e^{i x} = \\cos x + i \\sin x")]]

#text("for any real number ")#mi("{x}")#text("; in particular we have the famous identities ")#metadata(none) <tao-73ca7e07ccc925566e81>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("e^{2\\pi i} = 1")]]

#text("and ")#metadata(none) <tao-7534883368a57c310541>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("e^{\\pi i} + 1 = 0.")]]

#text("We now see that the multiplication formula ")#link(<tao-3687ed048014daac3878>)[#text("(8)")]#text(" can be written as a special form")

#align(center)[#tao-fit-display[#mitex("e^{i(\\theta + \\phi)} = e^{i\\theta} e^{i\\phi}")]]

#text("of ")#link(<tao-affa729802a1cd006b2c>)[#text("(12)")]#text("; similarly, de Moivre’s formula takes the simple and intuitive form")

#align(center)[#tao-fit-display[#mitex("e^{i n \\theta} = (e^{i\\theta})^n.")]]

#text("From ")#link(<tao-affa729802a1cd006b2c>)[#text("(12)")]#text(" and ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(13)")]#text(" we also see that the exponential function basically transforms Cartesian coordinates to polar coordinates:")

#align(center)[#tao-fit-display[#mitex("\\exp( x+iy ) = e^x ( \\cos y + i \\sin y ).")]]

#text("Later on in the course we will study (the various branches of) the logarithm function that inverts the complex exponential, thus converting polar coordinates back to Cartesian ones.")#linebreak()#text(" From ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(13)")]#text(" and ")#link(<tao-b5a170558ac2218fcd4a>)[#text("(1)")]#text(", together with the easily verified identity")

#align(center)[#tao-fit-display[#mitex("\\overline{e^{ix}} = e^{-ix},")]]

#text("we see that we can recover the trigonometric functions ")#mi("{\\sin(x), \\cos(x)}")#text(" from the complex exponential by the formulae ")#metadata(none) <tao-9740c9dcdb4487d8cd63>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sin(x) = \\frac{e^{ix} - e^{-ix}}{2i}; \\quad \\cos(x) = \\frac{e^{ix} + e^{-ix}}{2}.")]]

#text("(Indeed, if one wished, one could take these identities as the ")#emph[#text("definition")]#text(" of the sine and cosine functions, giving a purely analytic way to construct these trigonometric functions.) From these identities one can derive all the usual trigonometric identities from the basic properties of the exponential (and in particular ")#link(<tao-affa729802a1cd006b2c>)[#text("(12)")]#text("). For instance, using a little bit of high school algebra we can prove the familiar identity")

#align(center)[#tao-fit-display[#mitex("\\sin^2(x) + \\cos^2(x) = 1")]]

#text("from ")#link(<tao-9740c9dcdb4487d8cd63>)[#text("(16)")]#text(":")

#tao-aligned(keep: true)[


#tao-math("\\sin^2(x) + \\cos^2(x)  & = \\frac{(e^{ix}-e^{-ix})^2}{(2i)^2} + \\frac{(e^{ix} + e^{-ix})^2}{2^2}", block: true)



#tao-math(" & = \\frac{e^{2ix} - 2 + e^{-2ix}}{-4} + \\frac{e^{2ix} + 2 + e^{-2ix}}{4}", block: true)



#tao-math(" & = 1.", block: true)
]

#text("Thus, in principle at least, one no longer has a need to memorize all the different trigonometric identities out there, since they can now all be unified as consequences of just a handful of basic identities for the complex exponential, such as ")#link(<tao-affa729802a1cd006b2c>)[#text("(12)")]#text(", ")#link(<tao-73ca7e07ccc925566e81>)[#text("(14)")]#text(", and ")#link(<tao-7534883368a57c310541>)[#text("(15)")]#text(".")#linebreak()#text(" In view of ")#link(<tao-9740c9dcdb4487d8cd63>)[#text("(16)")]#text(", it is now natural to introduce the complex sine and cosine functions ")#mi("{\\sin: {\\bf C} \\rightarrow {\\bf C}}")#text(" and ")#mi("{\\cos: {\\bf C} \\rightarrow {\\bf C}}")#text(" by the formula ")#metadata(none) <tao-8651347d5d501956a468>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sin(z) := \\frac{e^{iz} - e^{-iz}}{2i}; \\quad \\cos(z) := \\frac{e^{iz} + e^{-iz}}{2}.")]]

#linebreak()#text(" These complex trigonometric functions no longer have a direct trigonometric interpretation (as one cannot easily develop a theory of complex angles), but they still inherit almost all of the algebraic properties of their real-variable counterparts. For instance, one can repeat the above high school algebra computations ")#emph[#text("verbatim")]#text(" to conclude that ")#metadata(none) <tao-d4426e9c4b6ac3fb4fd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sin^2(z) + \\cos^2(z) = 1")]]

#text("for all ")#mi("{z}")#text(". (We caution however that this does ")#emph[#text("not")]#text(" imply that ")#mi("{\\sin(z)}")#text(" and ")#mi("{\\cos(z)}")#text(" are bounded in magnitude by ")#mi("{1}")#text(" – note carefully the lack of absolute value signs outside of ")#mi("{\\sin(z)}")#text(" and ")#mi("{\\cos(z)}")#text(" in the above formula! See also Exercise ")#link(<tao-5e657ff6158d3e2a6d23>)[#text("16")]#text(" below.) Similarly for all of the other trigonometric identities. (Later on in this series of lecture notes, we will develop the concept of ")#link("https://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text(", which can explain why so many real-variable algebraic identities naturally extend to their complex counterparts.) From ")#link(<tao-f0164915cf681cc7bb1c>)[#text("(11)")]#text(" we see that the complex sine and cosine functions have the same Taylor series expansion as their real-variable counterparts, namely")

#tao-aligned(keep: true)[


#tao-math("\\sin(z)  & = \\sum_{n=0}^\\infty (-1)^n \\frac{z^{2n+1}}{(2n+1)!}", block: true)



#tao-math(" & = z - \\frac{z^3}{3!} + \\frac{z^5}{5!} - \\dots", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\cos(z)  & = \\sum_{n=0}^\\infty (-1)^n \\frac{z^{2n}}{(2n)!}", block: true)



#tao-math(" & = 1 - \\frac{z^2}{2!} + \\frac{z^4}{4!} - \\dots.", block: true)
]

#text("The formulae ")#link(<tao-8651347d5d501956a468>)[#text("(17)")]#text(" for the complex sine and cosine functions greatly resemble those of the ")#link("https://en.wikipedia.org/wiki/Hyperbolic_function")[#text("hyperbolic trigonometric functions")]#text(" ")#mi("{\\sinh, \\cosh: {\\bf R} \\rightarrow {\\bf R}}")#text(", defined by the formulae")

#align(center)[#tao-fit-display[#mitex("\\sinh(x) := \\frac{e^x - e^{-x}}{2}; \\quad \\cosh(x) := \\frac{e^x + e^{-x}}{2}.")]]

#text("Indeed, if we extend these functions to the complex domain by defining ")#mi("{\\sinh, \\cosh: {\\bf C} \\rightarrow {\\bf C}}")#text(" to be the functions")

#align(center)[#tao-fit-display[#mitex("\\sinh(z) := \\frac{e^z - e^{-z}}{2}; \\quad \\cosh(z) := \\frac{e^z + e^{-z}}{2},")]]

#text("then on comparison with ")#link(<tao-8651347d5d501956a468>)[#text("(17)")]#text(" we obtain the complex identities ")#metadata(none) <tao-1b158839f8aa339e89bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sinh(z) = -i \\sin(iz); \\quad \\cosh(z) = \\cos(iz)")]]

#text("or equivalently ")#metadata(none) <tao-dae7f3a056377ab98e8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sin(z) = -i \\sinh(iz); \\quad \\cos(z) = \\cosh(iz)")]]

#text("for all complex ")#mi("{z}")#text(". Thus we see that once we adopt the perspective of working over the complex numbers, the hyperbolic trigonometric functions are “rotations by 90 degrees” of the ordinary trigonometric functions; this is a simple example of what physicists call a ")#link("https://en.wikipedia.org/wiki/Wick_rotation")[#text("Wick rotation")]#text(". In particular, we see from these identities that any trigonometric identity will have a hyperbolic counterpart, though due to the presence of various factors of ")#mi("{i}")#text(", the signs may change as one passes from trigonometric to hyperbolic functions or vice versa (a fact quantified by ")#link("http://mathworld.wolfram.com/OsbornesRule.html")[#text("Osborne’s rule")]#text("). For instance, by substituting ")#link(<tao-1b158839f8aa339e89bb>)[#text("(19)")]#text(" or ")#link(<tao-dae7f3a056377ab98e8e>)[#text("(20)")]#text(" into ")#link(<tao-d4426e9c4b6ac3fb4fd8>)[#text("(18)")]#text(" (and replacing ")#mi("{z}")#text(" by ")#mi("{iz}")#text(" or ")#mi("{-iz}")#text(" as appropriate), we end up with the analogous identity")

#align(center)[#tao-fit-display[#mitex("\\cosh^2(z) - \\sinh^2(z) = 1")]]

#text("for the hyperbolic trigonometric functions. Similarly for all other trigonometric identities. Thus we see that the complex exponential single-handedly unites the trigonometry, hyperbolic trigonometry, and the real exponential function into a single coherent theory!")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]

#list(
[#text("(i) If ")#mi("{n}")#text(" is a positive integer, show that the only complex number solutions to the equation ")#mi("{z^n = 1}")#text(" are given by the ")#mi("{n}")#text(" complex numbers ")#mi("{e^{2\\pi i k/n}}")#text(" for ")#mi("{k=0,\\dots,n-1}")#text("; these numbers are thus known as the ")#link("https://en.wikipedia.org/wiki/Roots_of_unity")[#mi("{n^{th}}")#text(" roots of unity")]#text(". Conclude the identity ")#mi("{z^n - 1 = \\prod_{k=0}^{n-1} (z - e^{2\\pi i k/n})}")#text(" for any complex number ")#mi("{z}")#text(".")],
[#text("(ii) Show that the only compact subgroups ")#mi("{G}")#text(" of the multiplicative complex numbers ")#mi("{{\\bf C}^\\times}")#text(" are the unit circle ")#mi("{S^1}")#text(" and the ")#mi("{n^{th}}")#text(" roots of unity")

#align(center)[#tao-fit-display[#mitex("C_n := \\{ e^{2\\pi i k/n}: k=0,1,\\dots,n-1\\}")]]

#text("for ")#mi("{n=1,2,\\dots}")#text(". (Hint: there are two cases, depending on whether ")#mi("{1}")#text(" is a limit point of ")#mi("{G}")#text(" or not.)")],
[#text("(iii) Give an example of a non-compact subgroup of ")#mi("{S^1}")#text(".")],
[#text("(iv) Show that the only closed subgroups of the additive group ")#mi("{{\\bf R} = ({\\bf R},+)}")#text(" are the whole group ")#mi("{{\\bf R}}")#text(", the trivial group ")#mi("{\\{0\\}}")#text(", and groups of the form ")#mi("{\\alpha {\\bf Z} = \\{ n \\alpha: n \\in {\\bf Z}\\}}")#text(" for some non-zero real ")#mi("{\\alpha}")#text(". (Hint: divide into cases, depending on whether ")#mi("{0}")#text(" is isolated or not.)")],
[#text("(v) Show that the only connected closed subgroups of ")#mi("{{\\bf C} = ({\\bf C},+)}")#text(" are the whole group ")#mi("{{\\bf C}}")#text(", the trivial group ")#mi("{\\{0\\}}")#text(", and the lines ")#mi("{\\{ tz: t \\in {\\bf R} \\}}")#text(" for some non-zero complex number ")#mi("{z}")#text(". (Hint: modify the argument of (iv), and if the subgroup contains a line, try to “quotient it out” to reduce back to a one-dimensional problem.)")],
[#text("(vi) Show that the only closed subgroups of ")#mi("{{\\bf C}}")#text(" are either ")#mi("{{\\bf C}}")#text(", discrete (every point is isolated), a line ")#mi("{\\{ tz: t \\in {\\bf R} \\}}")#text(" for some non-zero complex number ")#mi("{z}")#text(", or of the form ")#mi("{\\{ tz + n w: t \\in {\\bf R}, n \\in {\\bf Z} \\}}")#text(" where ")#mi("{z, w}")#text(" are non-zero complex numbers that are linearly independent over the reals.")],
[#text("(vii) Show that the only connected closed subgroups of ")#mi("{{\\bf C}^\\times}")#text(" are the whole group ")#mi("{{\\bf C}^\\times}")#text(", the trivial group ")#mi("{\\{1\\}}")#text(", and the one-parameter groups of the form ")#mi("{\\{ \\exp( tz ): t \\in {\\bf R} \\}}")#text(" for some non-zero complex number ")#mi("{z}")#text(". (Hint: apply (vi) to the inverse image of the group under the exponential map.)")]
)
]

#text("The next exercise gives a special case of the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(", when considering the roots of polynomials of the specific form ")#mi("{P(z) = z^n - w}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Show that if ")#mi("{w}")#text(" is a non-zero complex number and ")#mi("{n}")#text(" is a positive integer, then there are exactly ")#mi("{n}")#text(" distinct solutions to the equation ")#mi("{z^n = w}")#text(", and any two such solutions differ (multiplicatively) by an ")#mi("{n^{th}}")#text(" root of unity. In particular, a non-zero complex number ")#mi("{w}")#text(" has two square roots, each of which is the negative of the other. What happens when ")#mi("{w=0}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-5e657ff6158d3e2a6d23>#text(" Let ")#mi("{z_n}")#text(" be a sequence of complex numbers. Show that ")#mi("{\\sin(z_n)}")#text(" is ")#link("https://en.wikipedia.org/wiki/Bounded_function")[#text("bounded")]#text(" if and only if the imaginary part of ")#mi("{z_n}")#text(" is bounded, and similarly with ")#mi("{\\sin(z_n)}")#text(" replaced by ")#mi("{\\cos(z_n)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" (This question was drawn from a previous version of this course taught by Rowan Killip.) Let ")#mi("{w_1, w_2}")#text(" be distinct complex numbers, and let ")#mi("{\\lambda}")#text(" be a positive real that is not equal to ")#mi("{1}")#text(".")

#list(
[#text("(i) Show that the set ")#tao-math("{\\{ z \\in {\\bf C}: \\left|\\frac{z-w_1}{z-w_2}\\right| = \\lambda \\}}", block: false)#text(" defines a circle in the complex plane. (Ideally, you should be able to do this without breaking everything up into real and imaginary parts.)")],
[#text("(ii) Conversely, show that every circle in the complex plane arises in such a fashion (for suitable choices of ")#mi("{w_1,w_2,\\lambda}")#text(", of course).")],
[#text("(iii) What happens if ")#mi("{\\lambda=1}")#text("?")],
[#text("(iv) Let ")#mi("{\\gamma}")#text(" be a circle that does not pass through the origin. Show that the image of ")#mi("{\\gamma}")#text(" under the inversion map ")#mi("{z \\mapsto 1/z}")#text(" is a circle. What happens if ")#mi("{\\gamma}")#text(" is a line? What happens if the ")#mi("{\\gamma}")#text(" passes through the origin (and one then deletes the origin from ")#mi("{\\gamma}")#text(" before applying the inversion map)?")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" If ")#mi("{z}")#text(" is a complex number, show that ")#mi("{\\exp(z) = \\lim_{n \\rightarrow \\infty} (1 + \\frac{z}{n})^n}")#text(".")
]

#heading(level: 1)[#text("Comments (68)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/809e22dc05c377504f460ce5668561424c752de1fd5453a9a196b39bc75c9d1b-81925532da90a8263811473a0c76854977e708a4d9ab13bd766184a3f6f2eacb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scottedwards2000")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472402")[#strong[#text("scottedwards2000")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("Reblogged this on ")#link("https://orderofsql.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/")[#text("The Order of SQL")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5f94588365ef4da1a7ccb5f58ef1913ccd162300d767794dae381a3a4048390-8678a20de279572d2ab093552a9370751dfc050d754c3f2cdb4fba3e285bc65c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadiraja")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472403")[#strong[#text("Vadiraja")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("Perhaps we should add that ")#mi("1, i, -1")#text(" are the classes of ")#mi("1, x, -1")#text(". We should avoid using the symbol ")#mi("i")#text(" and identifying the field ")#mi("\\mathbb{C}")#text(" as the ring ")#mi("\\mathbb{R}[i]")#text(" modulo the relation that ")#mi("i^2+1=0")#text(".")

#text("Its the same thing, of course as your previous definition ")#mi("\\mathbb{C}=R[i]/(i^2+1)")#text(" since ")#mi("(i^2+1)")#text(" is the smallest ideal containing the relation ")#mi("i^2+1=0")#text(".")

#text("Adding this concept of a ring modulo relations, when people might be learning about quotient rings for the first time, is confusing.")

#emph[#text("[Remark about rings with relations added -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472404")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("It is interesting to observe that ")#mi("i")#text(" is defined only as a root of ")#mi("x^2 + 1 = 0")#text(", hence any identity involving ")#mi("i")#text(" (e.g. Euler formula) automatically(!) holds also for the other root (i.e. ")#mi("i")#text(" may be replaced by ")#mi("-i")#text(" in the identity).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beea4f5a60e30b13cc344e69b98d05be740ede991e336d7b3182282b26be6192-b6c6b38053354c96f650cab5f984ad4b17198cac0ca45e1483aa812e2f6dce7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("A priori, only any *algebraic* identity involving i. For instance, exp(pi/2 * -i)=/=exp(pi/2 * i).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("More precisely, if there is a proof for any(!) identity involving “i” (which needs merely to satisfy ")#mi("i^2 = -1")#text("), then the proof should apply also for “-i” (replacing “i”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a04e90eb6f2d1f27b45e0a71a50e99e533bb0834c7e5634a7d599d9c9406d28d-fb125e73d05dba29fae14f1e479c2f6f327b162e4a556587f4c4ac2afa0efaf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("I think the point could be concisely phrased as “complex conjugation is a field automorphism.”")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472405")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("For “half-open interval {\\{ \\theta: \\pi < \\theta \\leq \\pi \\}} \"")#linebreak()#text(" read \"half-open interval {\\{ \\theta: -\\pi < \\theta \\leq \\pi \\}} \"")

#text("For \"the (various branches of the) logarithm \"")#linebreak()#text(" read \"(the various branches of) the logarithm \"")

#text("WFL")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472407")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("After multiplication by ")#mi("i")#text(" is rotation by ")#mi("pi/2")#text(" counter-clockwise, multiplication by ")#mi("-i")#text(" is rotation by ")#mi("pi/2")#text(" clockwise, but the text has “rotation by i”")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf8f0ad4c256e9470eb328901035988d4aa7b41679127b204b07b6ab5abcb866-f8b46ee7bbc7d54c6b083f253beb108bcbcecfd0810f34af1069113d13dc94b6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Birdwatcher")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472411")[#strong[#text("The Birdwatcher")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("“For instance, one cannot quite define the reals {{\\bf R}} from scratch as the metric completion of the rationals {{\\bf Q}}, because the definition of a metric space itself requires the notion of the reals”")

#text("One can certainly view it as the completion as a uniform space (the two main uses of uniform spaces (that I know of) are (i) the elimination of this circularity and (ii) unifying the exposition of metric completions and module completions (the ones that allow us to talk formal power series in AG))")

#emph[#text("[Note about uniform space and Dedekind cut construction of the reals added. I had thought about mentioning that the reals can also be viewed as the order-theoretic completion of the rationals, which is what the Dedekind cut construction essentially is capturing, but since the extended reals ")#mi("[-\\infty,\\infty]")#text(" are arguably another candidate for this order-theoretic completion, I could not figure out how to insert this comment succinctly without disrupting the flow of the discussion. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c66ead9d57be1b9fb7c592d26498fb6199c971c567dc67ba8ee06bc82148674-581fe2315e6309a341cd26d11f68809d4c26c86e03c878e710d821f1ed6602fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juha-Matti Perkkiö")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472417")[#strong[#text("Juha-Matti Perkkiö")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("Indeed, and Dedekind cuts are very elementary, non-circular and not relying on any auxiliary concepts. (I was wondering about the purpose of the comment on circularity as well.)")

#text("By the way, there is one philosophical/pedagogical aspect of complex numbers which might be relevant at this level of discussion. Namely, the geometric construction (with compass and straight edge) of the product of two complex numbers is generically simpler and never more complicated than for two real numbers. Perhaps the notion of scaling by a real factor is so deceptively familiar that this curious little fact is easily overlooked.")

#emph[#text("[Remark added on the geometric interpretation of the complex arithmetic operations – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("Arguably the fastest way to construct the reals as an ordered field directly from the integers, by-passing the rationals completely, is to define them as “slopes” in the sense of Eudoxus, i.e. quasimorphisms from Z to Z up to bounded distance. It is a pity that the infinitely more clumsy definition via Dedekind cuts seems to have become the standard one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472412")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("Terry, Kronecker famously DID NOT write this. A colleague of his named Weber claimed that Kronecker made such a comment in a lecture. The lecture itself was never published and we have no way of checking the accuracy of this quote. Kronecker scholar Yvon Gauthier believes the attribution is dubious because what Kronecker specifically did write is that numbers are a product of the human mind. The implied realism about number systems just does not seem to square well with Kronecker’s views on infinity and specifically his rejection of completed infinity.")

#emph[#text("[Attribution reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4ba158f300399e05b508f00d7851bd0de231c2a3b205f884a8ad2aee8c17f63-d7b51a6cb475ac311c84f369f0554bd2c9a8386a4b0969734157773009e0af79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472414")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("Typo in the Lagrange formula at end of section 1; s/ab-cd/ac-bd/")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472416")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("In Exercise 10 (iii), did you confuse the unit circle and the complex multiplicative group?")

#emph[#text("[I don’t believe so – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("The accent in “etalé fundamental group” is on the wrong e (it should be étale)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472430")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("Elementary arithmetic notation can be somewhat simplified. Knowing addition, multiplication and exponentiation you do not need a subtraction operation or a division bar or a square root sign, because ")#mi("a-b=a+(-b)")#text(" and ")#mi("\\frac 1 a=a^{-1}")#text(" and ")#mi("\\sqrt {a}= a^{2^{-1}}")#text(". When the minus sign is no longer used for subtraction but only for change of sign, you may write ")#mi("-1 = -")#text(", and the above expressions become ")#mi("a + -b")#text(" , ")#mi("a^-")#text(", and ")#mi("a^{2^-}")#text(" . You do not need a multiplication sign because the product ")#mi("2\\times 3")#text(" can be written")#mi("2^1 3^1")#text(". Also the expression ")#mi("e^{2\\ pi i x}")#text(" is conveniently written ")#mi("-^{2x}")#text(", emphasizing the fact that it is algebraic when x is rational.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ada8be95e9fa74b18ea06cf907896c1fd5d063eafc9a505cdbf1d0b4c75fae15-d2d861c04e90b4d0b9ef75dca4686bd83a57e627d1dd27031afa469ff0f68b7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moshe Simon")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472434")[#strong[#text("Moshe Simon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")])]

#text("The residue calculus and contour integration are indeed magical, which makes them difficult to understand intuitively. Many of the results that are traditionally proved using them are topological in nature, and can be derived using other, topological, arguments that follow from the idea that a complex differentiable function is locally a rotation composed with a radial scaling, and thus does no folding locally or globally. These arguments utilize the concept of the winding number of a closed curve around any point not on the curve, which has a natural definition derived from any continuous branch of the argument of the points on the curve. Among the results that can be obtained (not necessarily in this order) are:")#linebreak()#text(" Min-Max modulus principle.")#linebreak()#text(" Algebraic closure of C.")#linebreak()#text(" Analyticity of differentiable functions.")#linebreak()#text(" The fixed point theorem for continuous functions on a disc.")#linebreak()#text(" The covering theorem.")#linebreak()#text(" Liouville’s theorem.")#linebreak()#text(" Schwartz lemma.")#linebreak()#text(" Cauchy’s inequality.")#linebreak()#text(" Open map theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("The third result can be viewed as “one half” of the equivalence between holomorphic (i.e. locally complex differentiable) functions and analytic (i.e. local representation by Taylor series) functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/745de7e1ff53e8a6f60ff88865dfef07982fe6ddb3e254e4d9cf880def122a75-9c8c9eb9ac6dcd52a1792a6a84c4ab50c979808c6123e8f910af707d9537ee9c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward C. Jones")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472453")[#strong[#text("Edward C. Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("Is there a paper or text where this approach to complex variables is worked out?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ada8be95e9fa74b18ea06cf907896c1fd5d063eafc9a505cdbf1d0b4c75fae15-d2d861c04e90b4d0b9ef75dca4686bd83a57e627d1dd27031afa469ff0f68b7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moshe Simon")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472462")[#strong[#text("Moshe Simon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("G.T. Whyburn Topological Analysis")#linebreak()#text(" A.F. Beardon Complex Analysis: The Argument Principle in Analysis and Topology")

#text("I also have course notes from lectures given by Beardon many years ago.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472437")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2016")])]

#text("Euler’s formula (13) may also be used to define (without relying on any geometric background) the trigonometric functions from the definition (11) of the exponential function. Such approach (e.g. in Rudin’s book “Real and complex analysis”) seems to be more self-contained.")

#emph[#text("[A comment to this effect has now been added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472442")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2016")])]

#text("Minor typo: the second instance of “every element” in the text reads as “every element C”. Should it be “every element of C”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cedad11c3a2defecb432984709488e333bab8a739a1bd8bf91dc3a18d1359eb-0e63631e0a9583ddb779e88295c405344f2ade16648a291f7c6a5caa8073ee14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rodrigue")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472449")[#strong[#text("Rodrigue")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("In exercise (11), shouldn’t it be ")#mi("z^n - 1 = \\prod\\limits_{k=0}^{n-1} (z - e^{\\frac{i2\\pi k}{n}})")#text(", with k ranging from 0 to ")#mi("n-1")#text(" instead of starting at 1?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("According to Wikipedia, it seems that complex numbers were first introduced and used (in the 16th century) by Cardano (who called them “fictitious”) to solve cubic equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi A. Bajaj")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472495")[#strong[#text("Ravi A. Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("I am strongly in favor of the hierarchy of numbers outlined here, with the first passage being additivity, the second being multiplicativity, the third being metricity, and the fourth being algebra. (One reason I like it is because, though I may be at risk of abusing the context of your words, in previous posts about prime numbers you alluded to “non-multiplicative” aspects of the theory so I appreciate the sense of there being a ladder toward those aspects that manifests in the construction of the numbers themselves.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c23fddc6998ce0ec65a3cf62b2ad3ab144990071004bc3a676561d1fdcf0be7-bf9ee5fb646bad1459880c423ac08ab3ac8278241dbcba3e552db49f6c44053c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("Sign error at remark 5, division formula, inside last term.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f41dcaedf162c6190422e70c828ba58ec0539b53ca5fbc247f5f5301f2240cf-aa2b63139b293e4c0698f7ea3bb95f28ff6b242726a0629e161678a7a61008b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harsh Kumar")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472505")[#strong[#text("Harsh Kumar")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("You use the term tangent vectors of the Argand plane in the introduction. Basically here:")#linebreak()#text(" “Another important geometric feature of the Argand plane is the angle between two tangent vectors to a point in the plane. ”")

#text("Could you explain what you mean by that in a little more depth. I understand from the context that you mean the angle between two complex vectors, but how are those the tangent vectors?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472527")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Formally, a ")#link("https://en.wikipedia.org/wiki/Tangent_vector")[#text("tangent vector")]#text(" to a point ")#mi("z_0")#text(" in any manifold ")#mi("M")#text(" is the derivative at ")#mi("z_0")#text(" of any differentiable curve in ")#mi("M")#text(" that passes through ")#mi("z_0")#text("; geometrically one thinks of such a vector as a little arrow based at ")#mi("z_0")#text(". In the case of a flat space such as the complex numbers ")#mi("{\\mathbf C}")#text(", the tangent space ")#mi("T_{z_0} {\\mathbf C}")#text(" of the complex plane at ")#mi("z_0")#text(" can be identified with ")#mi("{\\mathbf C}")#text(" just by translating such a vector to the origin. But from a geometric point of view, one can of course take angles from any base point ")#mi("z_0")#text(", not just the origin, so it is slightly more appropriate to think of vectors here as tangent vectors from some base point rather than just elements of ")#mi("{\\bf C}")#text(". (This also makes things easier conceptually when one considers conformal geometry of non-flat spaces, such as the ")#link("https://en.wikipedia.org/wiki/Riemann_sphere")[#text("Riemann sphere")]#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35186b0c9e03516cd6c753630993d6079968fae10524181d5d404140a024ceae-974717ca90d426a994d366d3cfad98df75a8f3478926424d98a74985bed6b80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JDM")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472571")[#strong[#text("JDM")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2016")])]

#text("“Manifolds are a bit like pornography: hard to define, but you know one when you see one.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c23fddc6998ce0ec65a3cf62b2ad3ab144990071004bc3a676561d1fdcf0be7-bf9ee5fb646bad1459880c423ac08ab3ac8278241dbcba3e552db49f6c44053c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2016")])]

#text("Still not fixed – maybe this was missed – there is a sign error at the division formula at remark 6, most right term,")#linebreak()#text(" for example it gives 1/i=+i")#linebreak()#text(" please check.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb99e33947ed36bd55fcf3ed017fea149dae2ceba98f774a46926f35a0607ce7-f5618759fcc9eb23d53e99f3bdf1cce34639fd6c1f24d651f6b44416faab75ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Backhurst")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-472712")[#strong[#text("Colin Backhurst")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2016")])]

#text("Really enjoying this series of notes")#linebreak()#text(" A few typos:")#linebreak()#text(" 1. In remark 12 the translation for subtraction should be to 0 (like it is for addition) rather than 1 (like it is for multiplication and division)")#linebreak()#text(" 2. Two lines above your (19) when extending cosh to be C->C you have cosh(x) where it should be cosh(z).")#linebreak()#text(" 3. In exercise 14 (iii)”given an example” should be “give an example”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b264be8358f3d22cecbbe54670b97a7ab507bf4cf9142aebeaaf6281ddd6936-7703577e5a1bf701fa4d45662143be4609295b04d5c811ab0d2459c15c468144.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jsevillamol")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-473049")[#strong[#text("jsevillamol")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("Wonderful notes!")

#text("One small typo: when defining exponentiation, it should be $z^0=1$ instead of $z^0 = 0$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c7e27949b4d7b690774bf9e3c61b5f81d4c1155b0858291b69c184c217e2b93-324ac95f04fef65cec94a72b5ab41498a6c2d67ec1de77125d53f6642de604ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Khang")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-473370")[#strong[#text("Khang")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("When I tried to construct the real numbers by metric completion, to avoid circularity, I used a lite version of metric topology on Q based on just rational-valued distance (concepts like delta-epsilon limits, closed sets, open sets, Cauchy sequences are still equivalent), then I defined a real as an equivalence class of Cauchy sequences in Q, a positive sequence as a sequence with a strictly positive rational lower bound (this makes the reals totally ordered) etc. Then I upgraded the metric to real-valued distance to prove the reals are complete. Is that okay or is there something I’m missing?")

#emph[#text("[Yes, that works; I adopt a similar approach for instance in my own analysis textbook. The circularity here is minor and relatively easy to circumvent, but at the cost of elegance. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13011cc7df44ba1b63d573fcc286ac99e1cb4777785374ad564309b893bcdd58-0a95d4d5facbe24475557bf7f27b2fb44faea8f34f2354de35167c5e53841cae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-475313")[#strong[#text("Jacob")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2016")])]

#text("Great notes! I really appreciate all the connections that are drawn to other parts of mathematics.")

#text("Two minor typos I noticed:")#linebreak()#text(" 1. In the line expressing the multiplicativity of complex conjugation there should be a whitespace command (e.g. “\\,”) between the symbols on the right hand side.")#linebreak()#text(" 2. One or more words are missing in the paragraph that begins “From the triangle inequality (3) and the multiplicativity (4) we see that the addition operation […]”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-477692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("Typo in")

#text("… to denote the assertion that {S} is the limit of the partial sums {\\sum_{n=0}^\\infty}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-477693")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("To avoid circular argument, what definition for the sine and cosine functions should one use in (8)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-477715")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("One can use any definition not involving the complex numbers from which one can deduce the usual laws of trigonometry. For instance, the (real) power series definition would suffice, and is perhaps the fastest rigorous route, if the least well motivated. Alternatively, one can observe that the Argand plane obeys a modern axiom system of Euclidean geometry (e.g. the ")#link("https://en.wikipedia.org/wiki/Hilbert's_axioms")[#text("Hilbert axioms")]#text("), develop notions of angle and length, and rigorously define trigonometric functions using the usual geometric definitions. One could also define the trigonometric functions by solving the harmonic oscillator ODE.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-477694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("… noting from (4) that the absolute convergence of the real exponential {\\exp(x)} for any {x \\in {\\bf R}} implies the absolute convergence of the complex exponential for any {z \\in {\\bf C}}.")

#text("Should (4) be (7)?")

#emph[#text("[No: the point is that ")#mi("z^n/n!")#text(" has a magnitude of ")#tao-math("\\left|z\\right|^n/n!", block: false)#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-481924")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] 246A, Notes 0: the complex numbers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce5595d4c0176c21269cf0d3a6e57165d1821896e0dd88e0747722d60237a562-ea14def07d7114e71c2f2a9f5d3bd5313ca929ef220897720d86ae29828b737d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Benedetto Proenca")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-492311")[#strong[#text("Nathan Benedetto Proenca")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2018")])]

#text("I am having trouble with exercise 14 (ii).")

#text("I arrived at the fact that I need the subgroup to be a subset of the unit circle,")#linebreak()#text(" and was able to prove that its $ latex C_n$ when 1 is not a limit point.")

#text("However, I am unable to conclude that it is the whole unit circle when 1 is a limit point. I was trying to show that I can have any number of the form $ latex e^{iq}$, with $ latex q \\in \\mathbb{Q}$, and then to use the fact that the subgroup is closed to finish the proof. However, I am not able to show that I have every $ latex e^{i/n}$ for $ latex n \\in \\Naturals$ from the fact that 1 is a limit point")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-492323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("You don’t need to have small rational angles to approximate an arbitrary element of the unit circle; small irrational angles will also work equally well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce5595d4c0176c21269cf0d3a6e57165d1821896e0dd88e0747722d60237a562-ea14def07d7114e71c2f2a9f5d3bd5313ca929ef220897720d86ae29828b737d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Benedetto Proenca")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-492343")[#strong[#text("Nathan Benedetto Proenca")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2018")])]

#text("Got it. Thank you very much")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a280cf3f6740eefa11e88e929212c66aac0ec53e72de7e0d930d09e7788f93a8-c9a9e7745150b48455c6cf9ce2de83275aa180ca7fd0d9ed1987d2753385cde6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Atom")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-552020")[#strong[#text("Atom")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("Prof. Terry.")

#text("I’m looking forward to studying complex analysis from these notes of yours. Can you please reassure if there are any prerequisites for these. I’ve done (more than) half of your Analysis I now, and have previously done Axler’s Linear Algebra Done Right, apart from which I’ve had no other significant exposure to abstract algebra.")

#text("Will I be losing anything what’s in your notes with only this much background?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01ff62ce861f626c24f6c069fa70ebcccb340d4e4043791730c2e94b721dccb1-e86e4ba8e793731b39dec3962315f6a804df8ad78f16050f6aa1eea8aaa91b67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of savitha muthanna")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593238")[#strong[#text("savitha muthanna")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Prof Tao,")

#text("I have a couple of questions on Notes 0,covered in the lecture on Friday(I dont have a deep background in abstract algebra) :")#linebreak()#text(" 1. ” The only ideal we will need to consider here is the")#linebreak()#text(" principal ideal: $:= {(\\rom{x}^2+1)P(\\rom{x}): P(\\rom{x}) \\in R[\\rom{x}]}}$. My question is, is the ideal, generated by $$, the ‘root’ of $(\\rom{x}^2 +1)$ commuted by the elements of $P(\\rom{x}) $ belonging to $R(\\rom{x})$? I am trying to understand the notation?")#linebreak()#text(" 2. “If we define $i \\to C$ to be the coset i:= \\rom{x}+,\\rom{x}^2+1},then it is clearfrom construction that $i^2+1=0$”")#linebreak()#text(" How is $i=x+$ ??? In fact in the lecture, you said, $P(\\rom{x} + = P(\\rom{x}+{\\rom{x}^2+1>)=P(i)$. I din’t understand that. Consequently I don’t see how $i+1$ amounts to $\\rom{x}^2+1$ or $i^2$ to $\\rom{x}^2$ either.")#linebreak()#text(" 3. I din’t completely understand how we arrived at the fact that z is invertible from finite dimensionality. I understood that C is 2 dimensional vector space. What is w in your notes? Why is this map injective? Also why is it surjective? ( I know the rank-nullity theorem).")

#text("Thank you,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Hope you don’t mind I make a few comments here.")

#text("1. In the definition,")

#mi("\\displaystyle \\langle \\mathrm{x}^2+1 \\rangle := \\{ (\\mathrm{x}^2+1) P(\\mathrm{x}): P(\\mathrm{x}) \\in {\\bf R}[\\mathrm{x}] \\}")

#text("the RHS is a “subset” of ")#mi("{\\bf R}[\\mathrm{x}]")#text(". No fancy notation/meaning here. (This subset has the structure of an ideal of ")#mi("{\\bf R}[\\mathrm{x}]")#text(" )")

#text("This the “quotient ring” approach rather than the “adjoining a new element” approach for defining ")#mi("{\\bf C}")#text(". See Remark 2.")

#text("2. ")#emph[#text("If we define ")#mi("{i \\in {\\bf C}}")#text(" to be the coset")]

#mi("\\displaystyle i := \\mathrm{x} + \\langle \\mathrm{x}^2 + 1 \\rangle")#text(",")

#text("then it is clear from construction that ")#mi("{i^2+1=0}")#text(".")

#text("One has ")#mi("i = \\mathrm{x} + \\langle \\mathrm{x}^2 + 1 \\rangle")#text(" because we are ")#emph[#text("defining")]#text(" the symbol ")#mi("i")#text(" to be so. In order to understand the logic here, one should throw away what one assumes he knows about “complex numbers”: until this point, there is no ")#mi("i")#text(" in the world and the excerpt above is what this symbol means. Whenever one sees ")#mi("i")#text(" following this definition, one should automatically replace it with the coset ")#mi("\\mathrm{x} + \\langle \\mathrm{x}^2 + 1 \\rangle")#text(".")

#text("3. ")#emph[#text("For any non-zero ")#mi("{z \\in {\\bf C}}")#text(", the multiplication map ")#mi("{w \\mapsto zw}")#text(" is an ")#mi("{{\\bf R}}")#text("-linear map from this finite-dimensional vector space to itself.")]

#text("The multiplication map is defined on ")#mi("{\\bf C}")#text(". So the variable ")#mi("w")#text(" takes values in ")#mi("{\\bf C}")#text(", which is the “domain” of the multiplication map. “Why is this map injective?” Because the kernel of this linear map is ")#mi("\\{0\\}")#text(". Now you can apply the rank-nullity theorem you know to conclude that it must be subjective as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("1) if ")#mi("i:=x+\\langle x^2 + 1\\rangle")#text(" how is ")#mi("i^2+1=0")#text("?")#linebreak()#text(" 3) For 3, why is the kernel map ")#mi("{0}")#text("? It would be zero if $w$ has a zero kernel. But that is not stated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593504")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("1): use the laws of addition and multiplication in the quotient ring ")#mi("{\\mathbb R}[x]/\\langle x^2+1 \\rangle")#text(", as laid out in the displays shortly before the definition of ")#mi("i")#text(".")

#text("3): use the fact that ")#mi("{\\mathbb R}[x]/\\langle x^2+1 \\rangle")#text(" is an integral domain.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Thank you!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593262")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Could you please edit your comment to correct the typos in it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-593644")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Terry, the following note in the CCLE course page (")#link("https://ccle.ucla.edu/mod/page/view.php?id=3173126")[#text("https://ccle.ucla.edu/mod/page/view.php?id=3173126")]#text("):")

#text("[Note for non-UCLA participants: only homework from enrolled UCLA students will be graded. Other participants are welcome to discuss the HW questions on the blog.]")

#text("is linking to your Fourier analysis blog posts.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-594225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Do you have a reference for the picture you drew in class for Remark 10?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-594247")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Szamuely’s book (cited in that remark) has some further elaboration of the analogy between etale fundamental groups and topological fundamental groups, though he may not have that precise picture. You also might find this ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/#comment-239475")[#text("comment of Will Sawin")]#text(" (in the function field setting) to be helpful, as well as the famous diagram of Mumford that is called “Mumford’s treasure map” in ")#link("http://www.neverendingbooks.org/mumfords-treasure-map")[#text("this web page")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-594236")[#strong[#text("Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Typo at: {\\times: {\\bf C} \\rightarrow {\\bf C} \\rightarrow {\\bf C}} for defining multiplication :)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-594238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("(To be clear, it’s in the limit section right before “… thus we have the familiar limit laws”)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-609919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#emph[#linebreak()#text(" … Starting with the real numbers ")#mi("{{\\bf R}}")#text(", we can form the space ")#mi("{{\\bf R}[\\mathrm{x}]}")#text(" of (formal) polynomials")]

#mi("\\displaystyle P(x) = a_d \\mathrm{x}^d + a_{d-1} \\mathrm{x}^{d-1} + \\dots + a_0")#linebreak()

#text("Typo in the font for ")#mi("x")#text(" in ")#mi("P(x)")#text(".")

#text("(A pedantic comment: the place holder ")#mi("{\\mathrm{x}^0})")#text(" is missing on the right—it is mentioned later in the notes that “… identifying each real number ")#mi("{a}")#text(" with the degree zero polynomial ")#mi("{a \\mathrm{x}^0}")#text(")”. Otherwise the identification is already done in the definition of ")#mi("P(\\mathrm{x})")#text(".)")

#text("(To be more pedantic, it is an exercise to find in the definition of the multiplicative identity ")#mi("{1_{\\bf C} := 1\\mathrm{x}^0 + \\langle \\mathrm{x}^2+1\\mathrm{x}^0 \\rangle}")#text(" that one can indeed later “identify” ")#mi("1_{\\bf C}")#text(" with ")#mi("1\\mathrm{x}^0")#text(" and thus the real number ")#mi("1")#text(". So it makes to write in the definition ")#mi("{1:= 1 + \\langle \\mathrm{x}^2+1 \\rangle}")#text(")")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-609960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("At the beginning of section 2, to view the positive definiteness of the norm form, continuity of the norm form ")#mi("N")#text(" on the connected set ")#mi("{\\bf C}\\setminus\\{0\\}")#text(" is used.")

#text("What “continuity argument” are you referring to in the following?")

#emph[#linebreak()#text(" … the unit circle ")#mi("{S^1}")#text(" is connected, a *continuity argument* shows that ")#mi("{z \\mapsto \\omega z}")#text(" must be orientation preserving for all ")#mi("{\\omega \\in S^1}")#text(",")#linebreak()#text(" ")]

#emph[#text("[One can verify that the set of ")#mi("\\omega \\in S^1")#text(" for which ")#mi("z \\mapsto \\omega z")#text(" is orientation-preserving is non-empty, open, and closed. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/320a618ef53c7c1b58cd60d2e39e12834d571c3ee06f1153970cdea61608cdc4-4ab92598afa3bd4a40d062a0dae8dc0fb8d4ef6280441e32dd192fcf0b23163b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-624876")[#strong[#text("Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2021")])]

#text("Dear Terry,")

#text("I quite like your notes for the 246ABC sequence. Are there any plans to morph these into a textbook?")

#text("Warmly,")

#text("Ryan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-625003")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2021")])]

#text("I will teach the entire sequence again next year using this set of notes, at which point I may think about converting them to a text.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-625530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("Dear Prof. Tao:")

#text("If classes continue to be online this coming fall, could you teach real analysis, or probability, or number theory other than complex analysis? Lots of students will benefit from your teaching.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 1: complex differentiation | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-634688")[#strong[#text("246A, Notes 1: complex differentiation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] set of notes: Notes 0. Next set of notes: Notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-639276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2022")])]

#text("Why is the closure of the reals (the complex numbers)is only twice as big, but the closure of other fields, i.e. closure of p-adiac field, and closure of the rationals are much bigger, both of infinite degree? What do you mean by infinite degree? Is the degree of complex numbers 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-639285")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2022")])]

#text("The key intuition lies in observing that we need only a single element ")#mi("\\sqrt{-1}")#text(" (or square root of any other negative real number) to be adjoined to ")#mi("\\mathbf{R}")#text(" for forming the complex numbers ")#mi("\\mathbf{C}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-639566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2022")])]

#text("The ")#link("https://en.wikipedia.org/wiki/Degree_of_a_field_extension")[#text("degree of a field extension")]#text(" is the dimension of the extension as a vector space over the base field.")

#text("For me, one reason why the algebraic closure of the reals is only of degree 2 is that the reals are already pretty close to being algebraically closed by virtue of the intermediate value theorem, which easily implies that any polynomial of ")#strong[#text("odd")]#text(" degree over the reals has a real root. Since the reals are already to find roots for half of the available degrees, it’s not so surprising that the algebraic completion has degree 2 as well. My intuition for the p-adics is not as good, but certainly as a bare minimum one needs to adjoin all the roots of p to the p-adics to even have a chance of being algebraically closed, which is already enough to demonstrate that the algebraic closure has infinite degree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-639296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2022")])]

#text("When we say dimension of a field, we usually mean dimension of the field as a vector space over another field, e.g ")#mi("\\dim_{\\mathbb{R}}^{\\mathbb{C}}=2")#text(", and ")#mi("\\dim_{\\mathbb{R}}^{\\mathbb{R}}=1")#text(". If the dimension as a vector space is not finite, we say it is infinite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-689452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2025")])]

#text("Dear Dr Tao,")

#text("You mentionded: “contour shifting” can also be used to compute some definite integrals of real-valued functions that would be much more difficult to compute by purely real-variable methods—— What kind of real integrals are suitable for solving with “contour shifting”?")

#text("Furthermore, for the “motivation” part, compared to real-variable methods, what structure (like geometric structure?) or behaviour of the integrand does using this method utilize to make it better to use?”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-689456")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2025")])]

#text("The short answer is holomorphicity (or at least meromorphicity) of the integrand. For the long answer… well, you will have to read through the remainder of the lecture notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-689610")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2026")])]

#text("Dear Prof. Tao,")

#text("I think the definition of complex numbers as the ")#emph[#text("quotient space ")]#text("C :=R[x]/<x^2 +1> of the commutative ring R[x] by the ideal <x^2 +1> is the most concise way. However this is not intuitive that much. Thus I would like to ask: From an algebraic perspective, what is the intuitive understanding of the ")#emph[#text("quotient space")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/18/246a-notes-0-the-complex-numbers/#comment-689612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2026")])]

#text("From an algebraic perspective, the quotient construction is a way to force algebraic identities to be true, even if they were not true in the unquotiented algebra. For instance, in ")#mi("{\\bf R}[x]")#text(", it is not true that ")#mi("x^2+1")#text(" vanishes; but after quotienting out by ")#mi("\\langle x^2 + 1 \\rangle")#text(", this expression now vanishes in the quotient ring, so if one uses ")#mi("i")#text(" to denote the representative of ")#mi("x")#text(" in this ring, then ")#mi("i^2+1=0")#text(".")
]
]
