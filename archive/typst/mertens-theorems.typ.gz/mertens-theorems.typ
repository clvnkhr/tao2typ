// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/12/11/mertens-theorems/
// Converted to Typst by tao2typ: "2026-10-14T15:18:53.188793+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mertens’ theorems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mertens’ theorems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 December 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/")[#text("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorems")]#text(" are a set of classical estimates concerning the asymptotic distribution of the prime numbers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Mertens’ theorems)")]#text(" ")#metadata(none) <tao-2215b340483e38ab9df1>#text(" In the asymptotic limit ")#mi("{x \\rightarrow \\infty}")#text(", we have ")#metadata(none) <tao-606864ec215983d8eb0d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{p\\leq x} \\frac{\\log p}{p} = \\log x + O(1),")]]

#metadata(none) <tao-fb51191447076aed4994>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{p\\leq x} \\frac{1}{p} = \\log \\log x + O(1),")]]

#text("and ")#metadata(none) <tao-49b1b2a55bf524165f12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{p\\leq x} \\log(1-\\frac{1}{p}) = -\\log \\log x - \\gamma + o(1)")]]

#text("where ")#mi("{\\gamma}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler-Mascheroni constant")]#text(", defined by requiring that ")#metadata(none) <tao-01ea9df76bc63a172589>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("1 + \\frac{1}{2} + \\ldots + \\frac{1}{n} = \\log n + \\gamma + o(1)")]]

#text("in the limit ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#text("The third theorem ")#link(<tao-49b1b2a55bf524165f12>)[#text("(3)")]#text(" is usually stated in exponentiated form")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\leq x} (1-\\frac{1}{p}) = \\frac{e^{-\\gamma}+o(1)}{\\log x},")]]

#text("but in the logarithmic form ")#link(<tao-49b1b2a55bf524165f12>)[#text("(3)")]#text(" we see that it is strictly stronger than ")#link(<tao-fb51191447076aed4994>)[#text("(2)")]#text(", in view of the asymptotic ")#mi("{\\log(1-\\frac{1}{p}) = -\\frac{1}{p} + O(\\frac{1}{p^2})}")#text(".")

#text("Remarkably, these theorems can be proven without the assistance of the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} 1 = \\frac{x}{\\log x} + o( \\frac{x}{\\log x} ),")]]

#text("which was proven about two decades after Mertens’ work. (But one can certainly use versions of the prime number theorem with good error term, together with summation by parts, to obtain good estimates on the various errors in Mertens’ theorems.) Roughly speaking, the reason for this is that Mertens’ theorems only require control on the Riemann zeta function ")#mi("{\\zeta(s) = \\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(" in the neighbourhood of the pole at ")#mi("{s=1}")#text(", whereas (as discussed in ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous post")]#text(") the prime number theorem requires control on the zeta function on (a neighbourhood of) the line ")#mi("{\\{ 1+it: t \\in {\\bf R} \\}}")#text(". Specifically, Mertens’ theorem is ultimately deduced from the ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product")]#text(" formula ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\zeta(s) = \\prod_p (1-\\frac{1}{p^s})^{-1},")]]

#text("valid in the region ")#mi("{\\text{Re}(s) > 1}")#text(" (which is ultimately a Fourier-Dirichlet transform of the fundamental theorem of arithmetic), and following crude asymptotics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Simple pole)")]#text(" ")#metadata(none) <tao-8563d0d12f13ad2504d0>#text(" For ")#mi("{s}")#text(" sufficiently close to ")#mi("{1}")#text(" with ")#mi("{\\text{Re}(s) > 1}")#text(", we have ")#metadata(none) <tao-164200a298bafec89fd3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\zeta(s) = \\frac{1}{s-1} + O(1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\zeta^{\\prime}(s) = \\frac{-1}{(s-1)^2} + O(1).")]]
]

#emph[#text("Proof:")]#text(" For ")#mi("{s}")#text(" as in the proposition, we have ")#mi("{\\frac{1}{n^s} = \\frac{1}{t^s} + O(\\frac{1}{n^2})}")#text(" for any natural number ")#mi("{n}")#text(" and ")#mi("{n \\leq t \\leq n+1}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n^s} = \\int_n^{n+1} \\frac{1}{t^s}\\ dt + O( \\frac{1}{n^2} ).")]]

#text("Summing in ")#mi("{n}")#text(" and using the identity ")#mi("{\\int_1^\\infty \\frac{1}{t^s}\\ dt = \\frac{1}{s-1}}")#text(", we obtain the first claim. Similarly, we have")

#align(center)[#tao-fit-display[#mitex("\\frac{-\\log n}{n^s} = \\int_n^{n+1} \\frac{-\\log t}{t^s}\\ dt + O( \\frac{\\log n}{n^2} ),")]]

#text("and by summing in ")#mi("{n}")#text(" and using the identity ")#mi("{\\int_1^\\infty \\frac{-\\log t}{t^s}\\ dt = \\frac{-1}{(s-1)^2}}")#text(" (the derivative of the previous identity) we obtain the claim. ")#mi("\\Box")

#text("The first two of Mertens’ theorems ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(", ")#link(<tao-fb51191447076aed4994>)[#text("(2)")]#text(" are relatively easy to prove, and imply the third theorem ")#link(<tao-49b1b2a55bf524165f12>)[#text("(3)")]#text(" except with ")#mi("{\\gamma}")#text(" replaced by an unspecified absolute constant. To get the specific constant ")#mi("{\\gamma}")#text(" requires a little bit of additional effort. From ")#link(<tao-01ea9df76bc63a172589>)[#text("(4)")]#text(", one might expect that the appearance of ")#mi("{\\gamma}")#text(" arises from the refinement ")#metadata(none) <tao-d21bb537725d603ee2db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\zeta(s) = \\frac{1}{s-1} + \\gamma + O(\\left|s-1\\right|)", block: true)]]

#text("that one can obtain to ")#link(<tao-164200a298bafec89fd3>)[#text("(6)")]#text(". However, it turns out that the connection is not so much with the zeta function, but with the Gamma function, and specifically with the identity ")#mi("{\\Gamma^{\\prime}(1) = - \\gamma}")#text(" (which is of course related to ")#link(<tao-d21bb537725d603ee2db>)[#text("(7)")]#text(" through the functional equation for zeta, but can be proven without any reference to zeta functions). More specifically, we have the following asymptotic for the ")#link("http://en.wikipedia.org/wiki/Exponential_integral")[#text("exponential integral")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Exponential integral asymptotics)")]#text(" ")#metadata(none) <tao-dd7a946de80abf417970>#text(" For sufficiently small ")#mi("{\\epsilon}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\epsilon^\\infty \\frac{e^{-t}}{t}\\ dt = \\log \\frac{1}{\\epsilon} - \\gamma + O(\\epsilon).")]]
]

#text("A routine integration by parts shows that this asymptotic is equivalent to the identity")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-t} \\log t\\ dt = -\\gamma")]]

#text("which is the identity ")#mi("{\\Gamma^{\\prime}(1)=-\\gamma}")#text(" mentioned previously.")

#emph[#text("Proof:")]#text(" We start by using the identity ")#mi("{\\frac{1}{i} = \\int_0^1 x^{i-1}\\ dx}")#text(" to express the harmonic series ")#mi("{H_n := 1+\\frac{1}{2}+\\ldots+\\frac{1}{n}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("H_n = \\int_0^1 1 + x + \\ldots + x^{n-1}\\ dx")]]

#text("or on summing the geometric series")

#align(center)[#tao-fit-display[#mitex("H_n = \\int_0^1 \\frac{1-x^n}{1-x}\\ dx.")]]

#text("Since ")#mi("{\\int_0^{1-1/n} \\frac{1}{1-x} = \\log n}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("H_n - \\log n = \\int_0^1 \\frac{1_{[1-1/n,1]}(x) - x^n}{1-x}\\ dx;")]]

#text("making the change of variables ")#mi("{x = 1-\\frac{t}{n}}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("H_n - \\log n = \\int_0^n \\frac{1_{[0,1]}(t) - (1-\\frac{t}{n})^n}{t}\\ dt.")]]

#text("As ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{\\frac{1_{[0,1]}(t) - (1-\\frac{t}{n})^n}{t}}")#text(" converges pointwise to ")#mi("{\\frac{1_{[0,1]}(t) - e^{-t}}{t}}")#text(" and is pointwise dominated by ")#mi("{O( e^{-t} )}")#text(". Taking limits as ")#mi("{n \\rightarrow \\infty}")#text(" using dominated convergence, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\gamma = \\int_0^\\infty \\frac{1_{[0,1]}(t) - e^{-t}}{t}\\ dt.")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\frac{e^{-t} - 1_{[0,\\epsilon]}(t)}{t}\\ dt = \\log \\frac{1}{\\epsilon} - \\gamma.")]]

#text("The claim then follows by bounding the ")#mi("{\\int_0^\\epsilon}")#text(" portion of the integral on the left-hand side. ")#mi("\\Box")

#text("Below the fold I would like to record how Proposition ")#link(<tao-8563d0d12f13ad2504d0>)[#text("2")]#text(" and Proposition ")#link(<tao-dd7a946de80abf417970>)[#text("3")]#text(" imply Theorem ")#link(<tao-2215b340483e38ab9df1>)[#text("1")]#text("; the computations are utterly standard, and can be found in most analytic number theory texts, but I wanted to write them down for my own benefit (I always keep forgetting, in particular, how the third of Mertens’ theorems is proven).")

#metadata(none) <tao-43757425a83931bd0edf>

#heading(level: 1)[#strong[#text(" — 1. Proof of Mertens’ theorems — ")]]

#text("Let ")#mi("{s}")#text(" be as in Proposition ")#link(<tao-8563d0d12f13ad2504d0>)[#text("2")]#text(". Taking logarithms of ")#mi("{\\zeta(s)}")#text(" using ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(5)")]#text(", we obtain the asymptotic ")#metadata(none) <tao-ebdb59143bdb3b4c2860>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_p \\log( 1 - \\frac{1}{p^s} ) = \\log(s-1) + O( \\left|s-1\\right| )", block: true)]]

#text("using the standard branch of the logarithm; if we instead compute the logarithmic derivative ")#mi("{\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}}")#text(", we obtain the closely related asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\frac{\\log p}{p^s - 1} = \\frac{1}{s-1} + O( 1 )")]]

#text("which by the approximation ")#mi("{\\frac{\\log p}{p^s - 1} = \\frac{\\log p}{p^s} + O(\\frac{\\log p}{p^2} )}")#text(" also gives ")#metadata(none) <tao-0967115f2813a3541eae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_p \\frac{\\log p}{p^s} = \\frac{1}{s-1} + O( 1 ).")]]

#text("These are already very close to Mertens’ theorems, except that the sharp cutoff ")#mi("{1_{[0,x]}(p)}")#text(" has been replaced by a smoother cutoff ")#mi("{\\frac{1}{p^{s-1}}}")#text(". To pass from the smooth cutoff to the rough, we use Fourier analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-6aab2fd5a6e93c1740c5>#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a compactly supported, Riemann integrable function independent of ")#mi("{x}")#text(". Then as ")#mi("{x \\rightarrow \\infty}")#text(", we have ")#metadata(none) <tao-a4cf5e703ea05d936c9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_p \\frac{\\log p}{p} F( \\frac{\\log p}{\\log x} ) = \\log x \\int_0^\\infty F(t)\\ dt + o(\\log x).")]]
]

#emph[#text("Proof:")]#text(" By approximating ")#mi("{F}")#text(" above and below by smooth functions, we may assume without loss of generality that ")#mi("{F}")#text(" is smooth. Applying the Fourier inversion formula to the function ")#mi("{t \\mapsto e^t F(t)}")#text(", we thus have a Fourier representation of the form ")#metadata(none) <tao-33250f5f56068761de96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("F(t) = \\int_{\\bf R} e^{-(1+iu) t} f(u)\\ du")]]

#text("for some rapidly decreasing function ")#mi("{f}")#text(". The left-hand side of ")#link(<tao-a4cf5e703ea05d936c9c>)[#text("(10)")]#text(" may then be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(u) (\\sum_p \\frac{\\log p}{p^{1 + \\frac{1+iu}{\\log x}}})\\ du.")]]

#text("The summation here may be crudely bounded in magnitude by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_p \\frac{\\log p}{p^{1 + \\frac{1+iu}{\\log x}}}\\right| \\leq \\sum_p \\frac{\\log p}{p^{1+1/\\log x}} \\ll \\log x", block: true)]]

#text("thanks to ")#link(<tao-0967115f2813a3541eae>)[#text("(9)")]#text(". From this and the rapid decrease of ")#mi("{f}")#text(", we see that the contribution of the integrand for which ")#tao-math("{\\left|u\\right| \\geq \\sqrt{\\log x}}", block: false)#text(" (say) is ")#mi("{O(1)}")#text(". In the remaining region, we may apply ")#link(<tao-0967115f2813a3541eae>)[#text("(9)")]#text(" to estimate the left-hand side of ")#link(<tao-a4cf5e703ea05d936c9c>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|u\\right| \\leq \\sqrt{\\log x}} f(u) (\\frac{\\log x}{1+iu} + O(1) )\\ du + O(1).", block: true)]]

#text("The net contribution of the ")#mi("{O(1)}")#text(" error is again ")#mi("{O(1)}")#text(", so from the rapid decrease of ")#mi("{f}")#text(" again we may rewrite this expression as")

#align(center)[#tao-fit-display[#mitex("\\log x \\int_{\\bf R} \\frac{f(u)}{1+iu}\\ du + O(1)")]]

#text("and the claim then follows by integrating ")#link(<tao-33250f5f56068761de96>)[#text("(11)")]#text(" on ")#mi("{[0,+\\infty)}")#text(". ")#mi("\\Box")

#text("Setting ")#mi("{F:= 1_{[0,1]}}")#text(" in the above proposition gives a weak version of the first Mertens’ theorem ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(", in which the ")#mi("{O(1)}")#text(" error term has worsened to ")#mi("{o(\\log x)}")#text(". To recover the full ")#mi("{O(1)}")#text(" term by this Fourier-analytic method requires a more precise accounting of error terms in the above estimates. Firstly, if one uses ")#link(<tao-d21bb537725d603ee2db>)[#text("(7)")]#text(" instead of ")#link(<tao-164200a298bafec89fd3>)[#text("(6)")]#text(", one eventually can improve ")#link(<tao-0967115f2813a3541eae>)[#text("(9)")]#text(" to ")#metadata(none) <tao-2e16b4ca8367812b8427>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_p \\frac{\\log p}{p^s} = \\frac{1}{s-1} + C + O( \\left|s-1\\right| )", block: true)]]

#text("for some absolute constant ")#mi("{C}")#text(", and for ")#mi("{s}")#text(" sufficiently close to ")#mi("{1}")#text(" with ")#mi("{\\text{Re}(s)>1}")#text(". Next, we recall the analogue of ")#link(<tao-33250f5f56068761de96>)[#text("(11)")]#text(" for the function ")#mi("{1_{(-\\infty,1]}}")#text(", namely")

#align(center)[#tao-fit-display[#mitex("1_{(-\\infty,1]}(t) = \\frac{1}{2\\pi} p.v. \\int_{\\bf R} \\frac{e^{(1+iu)(1-t)}}{1+iu}\\ du")]]

#text("which can be easily verified through contour integration. This formula is not ideal for our purposes (it would require controlling ")#mi("{\\zeta}")#text(" up and down the line ")#mi("{\\text{Re} s = 1}")#text("), so we truncate it, introducing the function")

#align(center)[#tao-fit-display[#mitex("F(t) := \\frac{1}{2\\pi} \\int_{\\bf R} \\frac{e^{(1+iu)(1-t)}}{1+iu} \\psi( \\frac{u}{\\log x} )\\ du")]]

#text("where ")#mi("{\\psi}")#text(" is a smooth cutoff to a sufficiently small interval ")#mi("{[-\\epsilon,\\epsilon]}")#text(" around the origin, that equals one on ")#mi("{[-\\epsilon/2,\\epsilon/2]}")#text(", for some small fixed ")#mi("{\\epsilon>0}")#text(". Repeating the proof of Proposition ")#link(<tao-6aab2fd5a6e93c1740c5>)[#text("4")]#text(", and using ")#link(<tao-2e16b4ca8367812b8427>)[#text("(12)")]#text(" instead of ")#link(<tao-0967115f2813a3541eae>)[#text("(9)")]#text(", we conclude (if ")#mi("{\\epsilon}")#text(" is small enough) that")

#align(center)[#tao-fit-display[#tao-math("\\sum_p \\frac{\\log p}{p} F( \\frac{\\log p}{\\log x} ) = \\frac{1}{2\\pi} \\int_{\\bf R} ( \\frac{\\log x}{1+iu} + C + O( \\frac{1+\\left|u\\right|}{\\log x} )) \\frac{\\psi(\\frac{u}{\\log x})}{1+iu}\\ du.", block: true)]]

#text("Routine calculation shows that the right-hand side is ")#mi("{\\log x + O(1)}")#text(". On the other hand, Littlewood-Paley theory can be used to show that")

#align(center)[#tao-fit-display[#tao-math("F(t) = 1_{[-\\infty,1)}(t) + O( (1 + \\left|1-t\\right| \\log x )^{-10} )", block: true)]]

#text("(say). From this we have that")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\frac{\\log p}{p} F( \\frac{\\log p}{\\log x} ) = \\sum_{p \\leq x} \\frac{\\log p}{p}")]]

#text("and ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A more elementary proof of ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(" can be obtained by starting with the identity ")#mi("{\\log n = \\sum_{d|n} \\Lambda(d)}")#text(" and summing to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\log n = \\sum_{d \\leq x} \\Lambda(d) \\lfloor \\frac{x}{d} \\rfloor.")]]

#text("On the one hand, Stirling’s formula gives ")#mi("{\\sum_{n \\leq x} \\log n = x \\log x + O(x)}")#text(". On the other hand, we have ")#mi("{\\lfloor \\frac{x}{d} \\rfloor = \\frac{x}{d}+O(1)}")#text(" and ")#mi("{\\sum_{d \\leq x} \\Lambda(d) = O(x)}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{\\Lambda(d)}{d} = \\log x + O(1),")]]

#text("from which ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(" easily follows.")
]

#text("We now skip to the third Mertens’ theorem ")#link(<tao-49b1b2a55bf524165f12>)[#text("(3)")]#text(", since as observed previously the second Mertens’ theorem ")#link(<tao-fb51191447076aed4994>)[#text("(2)")]#text(" follows as a corollary (and also follows from the first theorem through summation by parts). Let ")#mi("{0 < \\epsilon < 1}")#text(" be a fixed quantity (independent of ")#mi("{x}")#text("). From ")#link(<tao-ebdb59143bdb3b4c2860>)[#text("(8)")]#text(" with ")#mi("{s := 1+\\frac{\\epsilon}{\\log x}}")#text(" we have ")#metadata(none) <tao-05ec7ecbd2c50a1f0c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_p \\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ) = - \\log \\frac{1}{\\epsilon} - \\log \\log x + o(1)")]]

#text("where the asymptotic notation refers to the limit ")#mi("{x \\rightarrow \\infty}")#text(". Let us first consider the contribution to this sum from those ")#mi("{p}")#text(" with ")#mi("{p>x}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_{p>x} \\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ).")]]

#text("By Taylor expansion we have ")#mi("{\\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ) = -\\frac{1}{p^{1+\\epsilon/\\log x}} + O( \\frac{1}{p^2} )}")#text(", and hence the above sum is equal to")

#align(center)[#tao-fit-display[#mitex("- \\sum_{p>x} \\frac{1}{p^{1+\\epsilon/\\log x}} + o(1)")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("- \\frac{1}{\\log x} \\sum_{p>x} \\frac{\\log p}{p} F( \\frac{\\log p}{\\log x} ) + o(1)")]]

#text("where ")#mi("{F(t) := \\frac{e^{-\\epsilon t}}{t}}")#text(". From Proposition ")#link(<tao-6aab2fd5a6e93c1740c5>)[#text("4")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x} \\sum_{x \\leq p \\leq x^N} \\frac{\\log p}{p} F( \\frac{\\log p}{\\log x} ) = \\int_1^N \\frac{e^{-\\epsilon t}}{t}\\ dt + o(1)")]]

#text("for any fixed ")#mi("{N>1}")#text(". One can bound the tail error from ")#mi("{p > x^N}")#text(" from the first Mertens’ theorem ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(" and dyadic decomposition, and on taking limits as ")#mi("{N \\rightarrow \\infty}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p>x} \\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ) = - \\int_1^\\infty \\frac{e^{-\\epsilon t}}{t} \\ dt + o(1);")]]

#text("scaling ")#mi("{t}")#text(" by ")#mi("{\\epsilon}")#text(" and then using Proposition ")#link(<tao-dd7a946de80abf417970>)[#text("3")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p>x} \\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ) = - \\log \\frac{1}{\\epsilon} + \\gamma + O(\\epsilon) + o(1);")]]

#text("subtracting this from ")#link(<tao-05ec7ecbd2c50a1f0c60>)[#text("(13)")]#text(" we conclude that ")#metadata(none) <tao-736bc2d4e0945110e88f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{p \\leq x} \\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ) = - \\log\\log x - \\gamma + O(\\epsilon) + o(1).")]]

#text("From the mean value theorem we have")

#align(center)[#tao-fit-display[#mitex("\\log( 1 - \\frac{1}{p^{1+\\epsilon/\\log x}} ) = \\log(1-\\frac{1}{p}) + O( \\frac{\\epsilon \\log p}{p \\log x} )")]]

#text("so from the first Mertens’ theorem ")#link(<tao-606864ec215983d8eb0d>)[#text("(1)")]#text(", we can write the left-hand side of ")#link(<tao-736bc2d4e0945110e88f>)[#text("(14)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\log( 1 - \\frac{1}{p} ) + O( \\epsilon ).")]]

#text("Putting all this together, we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\log( 1 - \\frac{1}{p} ) = -\\log\\log x - \\gamma + O(\\epsilon) + o(1).")]]

#text("Since ")#mi("{\\epsilon}")#text(" may be chosen arbitrarily small, we obtain the third Mertens’ theorem ")#link(<tao-49b1b2a55bf524165f12>)[#text("(3)")]#text(" as required.")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The beauty of the Riemann sphere | cartesian product")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-257611")[#strong[#text("The beauty of the Riemann sphere | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("[…] Mertens’ theorems (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-259210")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2013")]

#text("So let me get this straight, Prof Tao. In order to do analysis on the primes we need a good scaling for our graph paper:")

#text("Rescale the primes as ")#mi("\\frac{\\log p}{\\log x}")

#text("Weight our function by ")#mi("\\frac{\\log p}{p \\log x}")

#text("And it is just like the Riemann integral. The closest I can find is logarithmic graph paper. ")#link("http://www.printablepaper.net/category/log")[#text("http://www.printablepaper.net/category/log")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ed4366c4acfdc577f31106b0d2504d33afb14aea32f847ce714bfb993b9550d-99b4a49893d437a8a2d40bd6d1e11fb0465f0dfaac37539a0136bac7bd85b261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mizar")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-262132")[#strong[#text("Mizar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2014")])]

#text("Dear Prof. Tao, thank you for this great post!")#linebreak()#text(" Using Proposition 4 we obtain a slightly weaker statement than that in the first Theorem, namely ")#mi("\\sum_{p\\leq x} \\frac{\\log p}{p} = \\log x (1+o(1))")#text(", right?")#linebreak()#text(" Moreover I want to point out two (negligible) typos: after you talk about dyadic decomposition, you write ")#mi("\\sum_{p>x} \\log(1 - \\frac{1}{p^{\\epsilon/\\log x}} )")#text(" twice, instead of ")#mi("\\sum_{p>x} \\log(1 - \\frac{1}{p^{1+\\epsilon/\\log x}} )")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-268541")[#strong[#text("Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("[…] from Mertens’ theorem one easily verifies […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7971a1f49892897ebf3cca49b0194d951c248364802f8c91e42b6764c11c1e2-8b645bd4fc313872b7b9bf48ef0f43f0b6a18badf33050e9f5caa0c550ee281c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jaspgus")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-365189")[#strong[#text("jaspgus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2014")])]

#text("Hello,")

#text("I have been finding some difficulty when I try to fill in some of the details in the proof of proposition 4, specifically when applying it to the smooth approximations of ")#mi("1_{[0,1]}")#text(". Namely, the implied constants I’ve been getting depend on the magnitude of the derivatives of the approximations, which becomes a problem since I think these get very large as the approximations get better.")

#text("Do you have any tips I could try? The only kind of rapid decay on the fourier transform I’ve really tried come from repeated integration by parts, perhaps there is a stronger type of decay?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-365388")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2014")])]

#text("Oops, you’re right, the argument provided only gives the weaker error term of ")#mi("o(\\log x)")#text(". I’ve now put in the details of the more complicated argument that gives the O(1) error term this way (as well as a more elementary proof of the O(1) term that avoids all Fourier analysis and zeta function estimates).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ceb1288c5c7d39318e34df83c9bc183a1635a02a81b5ad434e893340210c878-1efdc87d5a859620cb4267301a5d7a998fa466b422d12d2865f2b84c994b7fab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sdwkn__lsha")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-387143")[#strong[#text("sdwkn__lsha")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2014")])]

#text("May will be useful")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n\\le x}{\\frac{1}{{\\log  n\\ }}}=x{\\log  {\\log  x\\ }\\ }+0.5{\\log  {\\log  x\\ }\\ }-\\sum_{n\\le x}{{\\log  {\\log  n\\ }\\ }}+O(1)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Large gaps between consecutive prime numbers | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-408004")[#strong[#text("Large gaps between consecutive prime numbers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2014")])]

#text("[…] compute the sum here, we first observe from Mertens’ theorem (discussed in this previous blog post) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e58d71f0f6fed623003aa05efe0585d16ef93ffa28f35566bfb61f50623ecf-2a8a45a0582c8ce83139ff9a7a2fcc83164146aeb54123a9d43b62b9f617bd50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Metzler")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-413074")[#strong[#text("David Metzler")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2014")])]

#text("A somewhat idle question inspired by your comments here and elsewhere about asymptotics for almost primes: given an arbitrary prime signature ")#mi("\\{a_1,...,a_k\\}")#text(", is a PNT-style asymptotic result known for the set of primes with that signature? I would guess so, and I would think that it just takes a bit more work with zeta (but I’m a geometer, not a number theorist!). Or does this require sieving, and sometimes run into the parity problem? I’d also be interested in the case where the prime signature is ordered, i.e. where we separate 2^2 * 3 = 12 from 2 * 3^2 = 18, for example. Perhaps that makes it much harder?")

#text("I’m planning to get my young kids interested in a “race” between the cumulative counts of the sets of primes with various signatures (for small n). E.g. they can find out when semiprimes start to beat primes. It would be nice to know what the asymptotic story is in general for this “race”. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-413373")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2014")])]

#text("Yes, there are asymptotics for these sorts of numbers, see e.g. ")#link("http://mathoverflow.net/questions/35927/asymptotic-density-of-k-almost-primes")[#text("http://mathoverflow.net/questions/35927/asymptotic-density-of-k-almost-primes")]#text(" for some discussion of the case ")#mi("a_1=\\dots=a_k=1")#text(". As far as asymptotics are concerned, pretty much everything is known about the average prime factorisation of a ")#emph[#text("single")]#text(" large number ")#mi("n")#text(", ultimately thanks to multiplicative number theory techniques such as the theory of the Riemann zeta function. (The error term in these asymptotics is, of course, a completely different story, being very sensitive to the Riemann hypothesis and related conjectures.) Multiplicative number theory is one of the few powerful techniques we have that is not subject to the parity barrier, ultimately coming from the fundamental theorem of arithmetic that multiplicatively links the natural numbers to the primes (which leads to the Euler product factorisation of zeta, etc.). Unfortunately, multiplicative techniques fail completely once one starts looking at the primality of tuples such as ")#mi("n,n+2")#text(" rather than a single number ")#mi("n")#text("; for instance, there is no useful fundamental theorem of arithmetic that only involves twin primes. (Well, one could make one tautologically, by introducing the set of natural numbers with only twin primes in their prime factorisation, but we have no useful additional information about that set (e.g. its asymptotic density) which one could then use to say something about twin primes.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-414081")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2014")])]

#text("Is it also the case that we have no useful additional info about the set of natural numbers whose *largest* prime factor is a twin?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e58d71f0f6fed623003aa05efe0585d16ef93ffa28f35566bfb61f50623ecf-2a8a45a0582c8ce83139ff9a7a2fcc83164146aeb54123a9d43b62b9f617bd50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Metzler")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-414983")[#strong[#text("David Metzler")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2014")])]

#text("Terry—thanks very much for the response. I’ll take a look at that Math Overflow thread.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-453943")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2015")])]

#text("For a different proof of Proposition 4 and some general results see the very recent paper: Dumitru Popa, Polya-Radoux type results for some arithmetical functions, J. M.A.A, 2015, now article In Press, Accepted manuscript.")#linebreak()#text(" Dumitru Popa.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/947ba9988221bcce15ebace7273c3d676df3945ac0790b9a9e6c1f78a0253137-0ea8b577009423f7cfd0ba45ef2d0747c773f2fa58648c2c5981d17156dcf9d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Glasby")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-483612")[#strong[#text("Stephen Glasby")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2017")])]

#text("I am interested to know more about the constant in equation (1). Landau proved it lies between -2 and 2. For x up to 10^7 it lies between -2 and 0.")#linebreak()#text(" Has progress been made since Landau’s proof of Merten’s equation (1)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-483618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2017")])]

#text("The most recent result in this direction I know of is by Dusart, see Theorem 6.11 of ")#link("https://arxiv.org/abs/1002.0442")[#text("https://arxiv.org/abs/1002.0442")]#text(" .")

#text("Best,")

#text("Terry")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/947ba9988221bcce15ebace7273c3d676df3945ac0790b9a9e6c1f78a0253137-0ea8b577009423f7cfd0ba45ef2d0747c773f2fa58648c2c5981d17156dcf9d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Glasby")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-483621")[#strong[#text("Stephen Glasby")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2017")])]

#text("Many thanks Terry. Dusart’s approximation will suffice for my group theoretic application. (BTW: the only time I met you was January 1985 at the Australian Mathematics Summer School in Canberra, and even then you had an interest in number theory.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50a3bfd0b6209da396f035163567c5c9b61d4fc130ebd0dced5802e1dfde08b3-fe1216f47d92a45f49d08dbe831f438be7763f30b6e708a2ecd892fbec268240.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Dienes")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-493595")[#strong[#text("John Dienes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2018")])]

#text("Dear Professor Tao:")#linebreak()#text(" I am writing a review about fragmentation and such, making much use of statistical concepts. To illustrate the power of such ideas I show that the density of primes is given by w= 1/log n. To derive this I note that the probability that w is prime is given by (1-1/2)(1-1/3)(1-1/5)…(1-1/n). Then some more “rough and ready” math shows this is equal to 1/log n. Saying that the probability is the same as the density is not much of a stretch. To confirm this neat result I used the table on p. 3 of Edwards giving the number of primes between 2,500,000 and 3,000,000: 216,816 – 183,072= 33,744. Thus in the neighborhood of 2,750,000 the density is 0.067488, while 1/log 2,750,000 is 0.067400, which passes for pretty good confirmation in engineering.")#linebreak()#text(" But then I ran across Mertens’ third theorem in Hardy and Wright and they would have me take exp(-gamma)/log n, smaller by 0.561. Clearly there is a problem with my example, but I hate to give up on it, especially since the conclusion checks out nicely.")#linebreak()#text(" The same calculation for 10**24 and 10**25 yields 0.01761 while 1/log n = 0.01737. So why does Mertens fail me? I have read and reread your discussion on the internet, but my math is not so sophisticated, having quit in 1950. It did not help. (I do a lot of applied math, which is somewhat different.)")#linebreak()#text(" I would greatly appreciate some explanation of this awful contradiction.")#linebreak()#text(" John Dienes")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-493621")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2018")])]

#text("This is known as the ")#emph[#text("Mertens paradox")]#text(", and is discussed on my blog at ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")]#text(" . Basically, the resolution comes from the fact that the events “p divides n”, for randomly selected n between 1 and x, do not behave independently once p becomes large. For instance, if p and q are primes between sqrt(x) and x, it is not possible for p and q to both divide n simultaneously, so the events “p divides n” and “q divides n” are far from independent. As a consequence one cannot simply multiply together the probabilities 1-1/p to predict the density of primes up to x; there is a correction at large primes which ends up contributing the ")#mi("e^{-\\gamma}")#text(" factor.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-505714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2018")])]

#text("Basically, the proof of the third theorem splits one infinity log(s-1) into two infinities log(epslon) and log(log x). The first cancels with log(epslon) in the upper sum over p>x, and the second left in the final result of the lower sum over p<=x.")#linebreak()#text(" The problem is: how can the upper sum keeps providing the full Euler constant value as x going to infinity? As I think, both upper sum and lower sum provide part of the Euler constant value, and the upper sum provides decreasing portion (to 0) when x increases (to infinity).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-505717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2018")])]

#text("Or put it this way: Denote by gamma the Euler constant. Calculate the limit as x->infinity, while epsilon is fixed.")#linebreak()#text(" lim(UpperSum) = log(epsilon) + gamma +O(epsilon)")#linebreak()#text(" The limit of an empty sum must be 0. So we must have")#linebreak()#text(" 0 = log(epsilon) + gamma +O(epsilon) which is absurd.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f5e42236f84baa161d4fb1e1e9244d4cb35e302851782309faff583966b430-11002f0e725618ae2423a91c1c45314a122ea65c45e8746a0fb5a1a392084072.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan Orozco (@JuanOrozcoNT)")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-525705")[#strong[#text("Juan Orozco (@JuanOrozcoNT)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2019")])]

#text("Professor Tao, when exponentiating the log version of the third theorem, shouldn’t “+O(1)” become “times O(1)”, meaning the error is a constant factor? Thanks for this post. It has been a great resource throughout the years.")

#emph[#text("The exponential of ")#mi("-\\gamma + o(1)")#text(" is ")#mi("e^{-\\gamma} \\exp(o(1)) = e^{-\\gamma} (1 + o(1)) = e^{-\\gamma} + o(1)")#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2e59fb889fcc2f375fb27886558969770aa05e14cce9b69f933be2d28573de4-f324c2a8b545f34088669777ae6d9cfb81ccf84322831b26b966dcc7dce2935f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A.S.Roy")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-594178")[#strong[#text("A.S.Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("Sorry I am not very comfortable with Fourier analysis and this is probably a really naive question, but I had to ask it, since this is the only one which I could not resolve (despite my best attempts) in the proof of Proposition 4: on applying the Fourier inversion formula on the function ")#mi("G(t):= e^tF(t)")#text(", I am getting something like")

#mi("\\displaystyle F(t) = \\int_{\\mathbb R} e^{-t(1+iu)} f(u) \\, du")

#text("where the function ")#mi("f")#text(" is given by the following integral:")

#mi("f(u) =  -\\frac1{2\\pi} \\int_{\\mathbb R} e^{y(1+iu)} F(y) \\, dy")

#text("It is not clear to me why $f$ decreases rapidly: I tried using integration by parts (taking into account the smoothness of ")#mi("F")#text(") to obtain")

#tao-math("\\left|f(u)\\right| = \\left| \\frac{A}{1+iu}(e^{c(1+iu)} - e^{-c(1+iu)}) - \\frac1{1+iu} \\int_{-c}^c F^{\\prime}(y) e^{y(1+iu)} \\, dy \\right|,", block: false)

#text("where ")#mi("\\text{supp }F \\subset [-c,c]")#text(" and ")#mi("A = \\int_{-c}^c F(t)\\ dt")#text(" for some ")#mi("c>0")#text(" since ")#mi("F")#text(" has compact support. While the integral occurring in the previous expression is ")#mi("O(1/u^2)")#text(" the first term seems to be ")#mi("\\asymp 1/u")#text(", so all I keep getting is ")#mi("f(u) = O(1/u)")#text(". Could you kindly let me know what I am doing wrong? I would be really obliged for the same.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-594250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("The boundary terms involve ")#mi("F(c)=0")#text(" and ")#mi("F(-c)=0")#text(" rather than ")#mi("A")#text(", and hence vanish.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-629845")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2021")])]

#text("Dear Prof. Tao,")

#text("you use a simple sentence to claim that ")#mi("1/n^s = 1/t^s + O(1/n^2)")#text(" in the proof of Prop. 2, but one does have to use the real derivative of the absolute value, or am I mistaken? I failed to immediately find an algebraic manipulation making that clear.")

#emph[#text("[Yes, this is easiest to see using an estimation of the derivative of ")#mi("1/t^s")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-629846")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2021")])]

#text("And Stirling’s formula may be replaced by a simple summation by parts in Remark 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3efc0e23cd336faac3153fd4e36c856631881d75382e25cd59d787353789488-44597670dda04adcb3567bc1e3f3922d20b40ff8c00d9c5bc93a77040dae7907.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Petrow")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-639369")[#strong[#text("Ian Petrow")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2022")])]

#text("Apologies for the pedantry, but: Shouldn’t it either be “Mertens Theorem” or “Mertens’s Theorem”, since “Mertens'” is not the proper way to make a possessive out of Mertens. And yet, it seems to be common to write “Mertens'” in the literature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-639377")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2022")])]

#text("Idiot. Mertens is the last name of the mathematician “Franz Mertens”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-639387")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2022")])]

#text("Yes that is why Mertens’s could have made sense.")#linebreak()#text(" But in any case the applicability of the result would remain the same, its power and nature would also not change if we call it by some other name.")

#text("Afterall, what’s in a name? What people call rose would still smell sweet if called by some other name. -a reworded quote of Shakespeare.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-639386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2022")])]

#text("Mertens’ is the correct possessive form of Mertens. When a word ends with a ‘s’, such as “Mertens”, just need to add an ‘ to get its possessive form. This is basic English grammar.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/#comment-639389")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2022")])]

#text("If I recall correctly, then Mertens’ theorem is also useful in a step to establish Chebyshev bounds which is the starting point of almost any proof of the prime number theorem.")

#text("Also if I recall correctly, then I read on the internet a trustworthy article on how Euler knew/ foresighted this result almost a century before Franz Mertens actually published this paper.")
]
