// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/16/proofs-prompts-and-posts/
// Converted to Typst by tao2typ: "2026-10-14T11:19:36.119755+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Proofs, Prompts and Posts", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Proofs, Prompts and Posts")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/16/proofs-prompts-and-posts/")[#text("https://terrytao.wordpress.com/2026/09/16/proofs-prompts-and-posts/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the editors of the communal blog ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("In the mathematical community, AI became a central conversation topic months before we started our communal blog, called ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(". Some of us were already experimenting with it, whereas some of us were skeptically watching from the sidelines. Inevitably, we all had our moment of realisation: be it Navier–Stokes, the 10 open problems, the unit distance conjecture, or successfully counting how many Rs are in strawberry (apparently it’s 3).")

#text("It was evident that everyone had thoughts about AI in mathematics, and many were not afraid of voicing strong opinions. We felt these conversations remained limited in their reach, though, as most mathematicians do not have a natural platform. We remember reading many established mathematicians lamenting the fate of PhD students at the beginning of August, but we were barely able to find a PhD student speaking out anywhere.")

#metadata(none) <tao-6dbfa740b108e7ea4672>

#text("For that reason, we decided to start a collaborative blog called Proofs and Prompts. Back in spring, we felt no particular urgency to launch this project. AI progress was fast, but we could enjoy our summers. On ")#link("https://openai.com/index/ten-advances-in-mathematics/")[#text("the 1st of August")]#text(", we realised we had to get started.")

#text("Now, about a month later (and a ton of introductory emails to get started), engagement from the community on the website is still growing, and our inboxes are full of many insightful contributions. We have enough momentum to keep going for quite some time; and we hope you’ll be a part of it with us.")

#text("Our goal with Proofs and Prompts is to hear from everyone. We believe that this endeavour has been, to some extent, successful. We have heard from ")#link("https://proofsandprompts.com/2026/08/09/the-ai-dissenter-viewpoint/")[#text("PhD students")]#text(", ")#link("https://proofsandprompts.com/2026/08/13/keeping-the-learner-in-the-loop/")[#text("undergrads")]#text(", ")#link("https://proofsandprompts.com/2026/08/07/writing-mathematics-in-the-age-of-ai/")[#text("Fields medallists")]#text(", and ")#link("https://proofsandprompts.com/2026/08/13/on-the-brutal-mathematics-of-slop/")[#text("hobbyists")]#text(". We have had posts proposing ")#link("https://proofsandprompts.com/2026/08/09/the-ai-dissenter-viewpoint/")[#text("a general moratorium on AI")]#text(", ")#link("https://proofsandprompts.com/2026/09/11/we-need-a-stockfish-for-math/")[#text("posts suggesting that AI is not playing enough of a role in mathematics")]#text(", ")#link("https://proofsandprompts.com/2026/09/08/whats-not-new/")[#text("posts claiming we have seen similar changes before")]#text(", and ")#link("https://proofsandprompts.com/2026/08/17/how-dare-you/")[#text("posts bringing in the climate crisis")]#text(". The discussion on Proofs and Prompts about the Caltech Mathathon featured both a critical ")#link("https://proofsandprompts.com/2026/09/10/open-letter-about-the-mathathon/")[#text("open letter")]#text(" and ")#link("https://proofsandprompts.com/2026/09/10/a-response-from-mathathon/")[#text("a response")]#text(" from the organisers, at the same time.")

#text("And yet, much more is still to be said, by more people. We believe we have considerable room to improve on the diversity of the authors, their experiences, and their relevant background. Few posts were written by people with experience developing or evaluating LLMs; contributors have been overwhelmingly from Western Europe and North America; only a handful of posts have been written by women, out of the forty-or-so already published. All these factors limit the range of perspectives shared and we’d like to hear in detail about more specific problems from people with first-hand knowledge. This includes questions around inequalities of access, practical aspects of LLMs and their limitations, open-source models, the response of journal editors, new initiatives, and so on.")

#text("So this is a plea to anyone reading this. We think that we can achieve a lot in this space if everyone gets their turn to speak and fruitful debates ensue. Our ambition is for Proofs and Prompts to be a place where people find one another and organise around shared concerns and visions. So please send us your contributions and suggestions ")#link("https://proofsandprompts.com/submit/")[#text("here")]#text(", and come join ")#link("https://proofsandprompts.com/")[#text("the conversation")]#text(".")

#text("We hope to see you there!")
