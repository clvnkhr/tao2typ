// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/
// Converted to Typst by tao2typ: "2026-10-14T15:21:20.975444+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A CERN for AI-assisted science?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A CERN for AI-assisted science?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/")[#text("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://dms.umontreal.ca/~koukoulo/")[#text("Dimitris Koukoulopoulos")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("At the 2026 World Cup semifinal, England led Argentina 1-0 with less than twenty minutes left. And then the momentum completely changed: England switched to a much more defensive formation, withdrawing attacking players and retreating deeper. The Argentinians started attacking in waves. They equalized in the 85th minute and scored the winner in stoppage time.")

#text("England’s defeat offers a valuable lesson: when trying to avoid the worst outcome, fear and passivity are not your friends.")

#metadata(none) <tao-07ff291bf11952e6245d>

#text("The recent ")#link("https://openai.com/index/navier-stokes-solution/")[#text("announcement by OpenAI of a solution to the Navier–Stokes Millennium Prize problem")]#text(", and the ")#link("https://mathandai.org/")[#text("controversy surrounding the way it was obtained and released")]#text(", should be a wake-up call for the scientific community. We need to come together quickly and develop an institutional response to this new reality. Complacency and defeatism are not an appropriate response, or else we risk turning the worst scenarios of AI disruption to science and society into self-fulfilling prophecies.")

#text("One thing seems clear: AI is here to stay. These tools already have spectacular and potentially transformative capabilities, and we need to learn how to incorporate them fully into scientific research. But if we want to do so in a way that is truly beneficial to science and society, I think we urgently need publicly funded frontier AI systems for academic research. These should include simple conversational and agentic interfaces with substantial public compute behind them. Researchers would have free baseline access to them, while projects requiring more substantial resources would apply for access to multi-agent systems and large-scale compute.")

#text("There are several problems with allowing access to frontier AI to remain concentrated in a handful of private companies.")

#text("First, scientific research can involve sensitive, proprietary or even classified data. Researchers need environments with strong confidentiality protections and clear accountability in the event of data breaches.")

#text("Second, unpublished research itself is sensitive. Prompts, uploaded documents and interactions with AI agents can contain new ideas and partial results. Researchers need strong guarantees that this material cannot become available to systems that might subsequently reproduce or build upon it. The recent controversies surrounding Navier–Stokes and ")#link("https://terrytao.wordpress.com/2026/09/11/on-the-existence-of-non-sofic-groups/")[#text("non-sofic groups")]#text(" illustrate how even the possibility of such reuse can seriously undermine researchers’ trust in these systems.")

#text("Third, the incentives of private companies are not the incentives of the scientific community. Competition encourages rapid demonstrations of new capabilities and spectacular results. Speed is valuable in science, but so are proper verification and attribution, careful exposition and, crucially, human understanding. For example, in mathematics, which is my field of research, a theorem is most useful to the community not simply when it has been proved, but when its ideas have been digested and incorporated into our collective knowledge. Speed can also be harmful, particularly for young scientists who are just establishing themselves. The recent experience of ")#link("https://www.sciencenews.org/article/human-math-record-twin-primes-openai")[#text("Julia Stadlmann")]#text(" is instructive: she worked for two years to produce the first improvement in more than a decade in the record on bounded gaps between primes, and then her result was surpassed by AI-assisted efforts within days. The point is not that stronger results should be withheld. It is that we risk moving to a system where years of early-career work can be eclipsed almost instantaneously by organizations with much greater resources. Young researchers are the future of science; it is our duty as a society to nurture them. Public access to frontier AI would reduce the enormous asymmetry in the research tools available to scientists, particularly to early-career researchers.")

#text("This brings me to my fourth objection: access to the strongest AI systems is currently highly unequal. The Navier–Stokes result, for example, was produced by an internal OpenAI model that the company describes as significantly more capable than its publicly available frontier model. ")#link("https://openai.com/index/ten-advances-in-mathematics/")[#text("Several other recent mathematical advances")]#text(" were likewise obtained using unreleased models. This risks creating a two-tier scientific system: a small group of researchers selected by, collaborating with, or employed by AI companies may have access to research capabilities unavailable to everyone else, regardless of what subscription they are willing to pay for. Public AI cannot prevent private companies from pursuing scientific results. But it can ensure that the scientific community has an independent, powerful alternative.")

#text("To address these issues, ")#strong[#text("we need to build a CERN for AI-assisted science.")]#text(" This analogy is not new: ")#link("https://digital-strategy.ec.europa.eu/en/news/eu-launches-investai-initiative-mobilise-eu200-billion-investment-artificial-intelligence")[#text("the European Commission has itself used it")]#text(" in describing its AI infrastructure plans. What I am proposing is a more specific version of that idea, centred on AI as public infrastructure for scientific research.")

#text("The timing may be unusually favourable. The EU and Canada are rapidly deepening their strategic relationship. As I write this, European Commission President Ursula von der Leyen has proposed that Canada become the EU’s ")#link("https://www.reuters.com/world/eu-opens-door-canada-become-first-associate-member-eu-commission-president-says-2026-09-16/")[#text("first-ever “associate member”")]#text(", while ")#link("https://www.pm.gc.ca/en/news/news-releases/2026/09/12/prime-minister-carney-strengthen-canadas-ties-european-partners-visit")[#text("Mark Carney is in Strasbourg")]#text(" to address the European Parliament. This constitutes a remarkable step toward what Carney has called a ")#link("https://www.reuters.com/world/americas/carney-pushes-idea-making-canada-associate-member-eu-wsj-reports-2026-09-13/")[#text("“unique alliance”")]#text(" between Canada and the EU. In addition, both sides are making major public investments in AI and computing infrastructure. Indeed, Canada has committed ")#strong[#text("C$2 billion over five years")]#text(" to ")#link("https://ised-isde.canada.ca/site/ised/en/canadian-sovereign-ai-compute-strategy")[#text("sovereign AI compute")]#text(", including up to ")#strong[#text("C$1 billion for public supercomputing infrastructure")]#text(". The EU is developing ")#link("https://research-and-innovation.ec.europa.eu/strategy/strategy-research-and-innovation/our-digital-future/european-ai-science-strategy/raise-resource-ai-science-europe_en")[#text("RAISE")]#text(" and a network of ")#link("https://digital-strategy.ec.europa.eu/en/policies/ai-factories")[#text("AI Factories")]#text(" to support AI research and innovation. It has also launched ")#link("https://digital-strategy.ec.europa.eu/en/news/eu-launches-ai-gigafactories-call-boost-europes-computing-capacity-and-unlock-more-eu30-billion")[#text("a call for up to seven AI Gigafactories")]#text(", backed by up to ")#strong[#text("€10 billion")]#text(" in public funding, and expected to unlock at least ")#strong[#text("€20 billion")]#text(" in additional private investment. Even more importantly, ")#link("https://www.canada.ca/en/innovation-science-economic-development/news/2025/12/joint-statement-of-the-first-meeting-of-the-canada-european-union-digital-partnership-council.html")[#text("Canada and the EU have explicitly agreed")]#text(" to explore cooperation on fundamental AI research, agentic systems for scientific discovery, access to advanced AI infrastructure, and the co-development of advanced AI models for the public good.")

#text("Such an initiative should be open to other research partners willing to contribute resources and subscribe to common standards of scientific governance, confidentiality, access and accountability.")

#text("A CERN for AI-assisted science cannot be merely another supercomputer centre. The user-facing layer is essential. Every researcher should have access to a simple chatbox to directly access frontier AI models without having to become an expert in model deployment, cloud infrastructure or GPU computing.")

#text("Such a system would be a sophisticated research assistant, helping academics explore hypotheses and conjectures, test their research strategies, perform bibliographic searches, and many other important tasks. More ambitious projects could decompose a difficult research programme into many interacting subproblems and use coordinated AI agents to explore them semi-autonomously, with researchers directing the overall strategy and interpreting the results.")

#text("Behind this simple interface would sit the expensive infrastructure: publicly controlled frontier models, large-scale compute and storage, and the teams needed to maintain and continually improve the system.")

#text("In short, let’s give every researcher free baseline access to a world-class conversational and agentic AI research environment backed by public frontier AI and compute. Ordinary use should be effortless. Projects requiring exceptional resources could apply competitively for large compute allocations and sophisticated multi-agent systems, just as researchers apply for access to other major scientific facilities. Canada already has experience with this kind of mechanism: the ")#link("https://www.alliancecan.ca/en")[#text("Digital Research Alliance of Canada")]#text(" allocates advanced computing resources through a peer-reviewed Resource Allocation Competition.")

#text("My motivation is not primarily to save academics the cost of AI subscriptions. I am much more concerned about the long-term independence of research. With AI becoming central to science, the fundamental research tools should not be controlled almost entirely by a handful of private companies whose objectives will not necessarily remain aligned with those of the scientific community.")

#text("There are obviously many questions to consider: whether publicly funded models could realistically remain near the frontier; whether we should train models from scratch or combine public infrastructure with commercial and open-weight models; how such an institution should be governed; what scale of funding would be required; how access to very large compute resources should be allocated; and how to prevent the public infrastructure itself from becoming bureaucratic, technologically stagnant or captured by particular national or commercial interests.")

#text("We need to engage in a public debate among scientists, governments and funding agencies about the feasibility of this project. The choice is not between using AI and rejecting it: AI is already becoming part of scientific practice. The question is whether the infrastructure on which future research depends will be treated as a public good, or whether we will allow science to become structurally dependent on a small number of private companies. That is not a choice we should make by default or through inaction. Just ask ")#link("https://koukoulopoulos.gr/apaitoyme-na-leitoyrgisoyn-ptolem-v-ag-dimitrios/")[#text("the English fans")]#text(".")

#emph[#text("Acknowledgements: I would like to thank Patrick Allen, Eyal Goren, Andrew Granville, Paris Koukoulopoulos, Matilde Lalín, Daniel Litt, James Maynard, Carlo Pagano and Oscar Alberto Quijano Xacur for their helpful comments while preparing this text. I used chatGPT to sharpen the writing and perform literature research.")]

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Hear, hear!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695551")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Keep in mind that the World Cup was won by Spain :), who defeated Argentina the very next game, because the basics and professionalism of the Spanish team were superior.")

#text("The idea of a CERN for AI-assisted science is worth supporting. But may I suggest something far more basic ")#emph[#text("to start with")]#text(": transparency of all AI-assisted mathematical results. Let’s suggest there be an ethical rule throughout the mathematical community worldwide, that all AI-assisted data, claims, results, etc obtained by whomever, on whatever platforms, should – as an ethical rule – be published in one and only open access “journal” or “arxiv”, a sort of huge database/website. ")#strong[#text("For transparency, for ease of reference and attribution")]#text(", ")#strong[#text("for verification/replication ")]#text("etc. (I might be old-fashioned, but I think of AI claims as equivalent to physics experiments. I definitively don’t dismiss them, but I prefer independent replication of any calculation/claim.)")

#text("In a traditional journal, every word should be written and undersigned by a human, who certainly would be free to refer and cite many DOIs from the AI-assisted “journal”/”arxiv”, including stuff published simultaneously with the human text.")

#text("If that means the number of research papers published in classical, “human” journals drops by 20%, that’s ok.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Maybe I do not understand the idea in this comment clearly. In my understanding, this AI-only journal idea does not seem to be sustainable. What about the follow-up papers written by a human, citing those AI-generated results, even very heavily?")

#text("I do not see it as a way to separate those AI truths/understanding from genuine truths/understanding. Even whether we can really separate them. There can be other way to adapt to this new era.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-696508")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("One of the issues that I see is how to be able to always distinguish claims/theorems that were verified by humans from the ones claimed by AI, especially when they would be used in future proofs. Maybe the word “journal” is not the right word. But I was thinking that somebody could then independently repeat a given AI run to obtain the same claims and proofs, like they do with experiments in physics. So it would be nice if there were a good recording of the “experimental settings”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("What do you mean by “AI assisted results”?")

#text("What if I have the entire paper written, on my own, except one technical lemma and AI helps me fill in the proof? I transcribe the proof and believe it is correct and stand behind it.")

#text("Should my paper be relegated to an AI assisted journal? You’re ridiculous.")

#text("You aren’t accepting the reality of the situation. AI is here. Choose to use it or not. You will be left behind.")

#text("I also object to a detailed “AI disclosure” itemizing how it is used. If I used Sage to experiment, I wouldn’t write a disclaimer in my paper saying that I am guilty of using Sage. Rather, I would write an acknowledgment like “Sage software provided useful insights during the project”. I propose something similar with AI use, e.g.")

#text("”Acknowledgments: Sage software and ChatGPT were useful during preparation of this manuscript. We thank John and Jane Doe for helpful conversations”")

#text("End of story.")

#text("-Tenured pure mathematician at R1 university")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I find the attempt to anonymously argue by authority pretty funny.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-696509")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("Sorry, it’s a misunderstanding. Here is a stupid example, but relevant. Suppose someone uses Sage or AI to multiply 2 polynomials of degree 1 million each, and the result is relevant/important for the other results in the paper. There is no way you have checked by hand that multiplication.")

#text("If you checked a fact by hand, it’s yours. How you got inspiration (Sage, AI, Holy Spirit) is irrelevant. If you multiplied two polynomials of degree 100 each, I do believe you checked that by hand.")

#text("It does not matter if AI helped you achieve the statement and the proof. I am only addressing the issue of you as a human checking that AI assisted proof. Once you have checked it – it’s yours. We assume good faith. We just want to avoid potential situations where a proof that no one has verified for 50 years has been used elsewhere.")

#text("The “journal” (sorry, “journal” is the wrong word) would be to “publish” long AI proofs that have NOT been thoroughly checked by humans, yet. As time progresses, there would be MANY such. It’s ok to rely on them, too, as long as we keep track of what gaps still exist.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Brilliant proposal. We urgently need this to advance science on a trustworthy basis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695554")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("$2B over 5 years. So less than 1/1000 of what the US is spending.")

#text("Yeah, that oughta do it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Google alone is spending half a billion a day, and that is without paying the NVIDIA tax lol.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I strongly agree with the idea of public AI system to support scientific community!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Watching mathematicians debate the risks of AI for their field feels like watching a species on the brink of extinction organizing a symposium on how to negotiate with evolution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695566")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Assuming the Beast’s coming is imminent and unstoppable, it seems like there are two big questions around:")

#text("(1) Where is the Beast going to live: in private or public hands?")

#text("(2) How should you deal with the Beast?")

#text("The enthusiasm that a public beast is obviously better tamable than a private one strikes me as somewhat naive. Both ways would most likely lead to hell. Also, as a non-mathematician following this blog sequence out of curiosity, I find it remarkable to what extent you guys discuss your stuff assuming mathematics were the only area affected. It is a kind of univariate / ceteris-paribus analysis that is quite misaligned with the reality which is most obviously multivariate and encompasses almost all areas of human activity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a1a244575ad691416644e72c1bfbde56c0a3ad905f9c32caa396b36f3170df2-0555ba0cd58d8260e2e1d743f491567434f226c9fd610ad9e395f7a9b85b2420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominique Manchon")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695579")[#strong[#text("Dominique Manchon")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Good point! A specificity of us mathematicians in this story is that the Beast considers us as its useful idiots. Most of our internal discussions by now turns around whether we should agree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8afd437da1e36ab156fcdc0ff4e6d28e8e48582473c360ab6e4aac8a8a94880e-11086e67d63e97b981d0240d596254a1217fc1a92c53dccae70ac8508b5737eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Camargo")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695571")[#strong[#text("André Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Certainly it would be nice to have free AI tools for Science (in the same spirit of free software), but it seems that even the future of AI is uncertain. At the same time we recently witness some oustanding achievements in math with AI, and some specialists talks about super intelligence, another group of Scientists states that this scenario is not long-term sustainable. Some people are even talking about an AI buble with billions of dolars invested, with no expected return so far. The most sceptical ones claims that the AI companies are actually desperate with the situation. Under this perspective, maybe this hyperfocus on math problems of AI companies are just an attempt to track the attention of potential investors, showing them how powerful are they tools.")

#text("Even in the best scenario: when there is no AI buble, we, as human beigs, and specially in the condition of Scientists, must not support the massive use of AI, even if it is a version for scientists, at least not if it is conceived under the current state of art. In fact, according to the google AI agent: “AI data centers ")#text("cause significant pollution and environmental strain through massive energy consumption, air emissions from backup power sources, high water usage, and noise")#text("“.")

#text("In summary, with the worst case scenario in mind, we also should support slowing down AI development immediately is for our own health.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695578")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("“Canada has committed ")#strong[#text("C$2 billion over five years")]#text("” wow that is hilarious I was not aware of this, cue the “Is this AI capex for ants?”. But in all seriousness this is obviously a great idea in theory, but you explain why this simply cannot happen yourself. “Whether publicly funded models could realistically remain near the frontier?” The answer: no. “What scale of funding would be required?” Too much for governments to stomach if you want to be at all competitive. “How to prevent the public infrastructure itself from becoming bureaucratic?” Famously Europe is great at this. “How to ensure against technological stagnation or capture by particular national or commercial interests?” Already happening, see Cohere or Mistral.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The answer: no. “What scale of funding would be required?” Too much for governments to stomach if you want to be at all competitive.")
]

#text("there are already several well-known counterexamples to this. GLM, Kimi and other models, considered frontier, shiw that public or primarily state-backed LLM competitive development is possible. A sign that this is to be taken seriously is that Trump is trying to block such models being used in the USA, because you understand, the viability of nonultracapitalist LLM technology is absolutely unacceptable …")

#text("What Kokoulopoulos describes here is possible and *must* be fought for, by all of us!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb886bd384f1356ff4adfda7f2674ae2e482e4c46eaff1ca2a4a2c6aed6470bc-2922574d6094b15932e26cb1f35e75531f12b92b612b3cf693129b593c5ae647.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-697593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Chinese models are not frontier. No one describes them as frontier, except for perhaps cybersecurity, where classifiers on true frontier models prevent them from doing cybersecurity work. Frontier AI requires investment on the scale of trillions. Even Chinese labs have spent hundreds of billions, by this point. This essay and your comment is a useless fever dream.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I don’t think that’s enough money to achieve frontier AI. Meta paid one researcher $250m, and offered another $1.5B. That’s just to hire two people.")

#text("A more realistic plan would be to figure out how to fund mathematicians enough to purchase AI for themselves and for their students. It isn’t the end of the world to have a field of research be expensive and require purchases from large companies. Look at biology or astrophysics. But it does require a lot more grant-writing.")

#text("Either way, more funding is required, and I think more funding will come, but pure mathematicians will have to make the case for “why pure mathematics matters” to an audience of people who are not pure mathematicians. And perhaps move slightly more in the direction of “applied mathematics”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e957bbe9594eeb5a0d31e3ddf3d131767fa8e0aaab74b6faaa76349d9b3e5aca-8e4f66a80855e3ff212d26f6c004d1209d56442d5fafdf116596a67cb9dbb962.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of candid23b7be9464")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695585")[#strong[#text("candid23b7be9464")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I have been thinking about this discussion from a slightly different perspective. Mathematicians themselves build on a vast body of existing mathematics, but those who work deeply on a particular problem also spend years adding something new to it: failed attempts, new questions, useful methods, intuitions about promising directions, and sometimes the missing conditions that allow a new path to emerge. AI inherits much of this accumulated intellectual landscape and can now search, recombine and test it with extraordinary computational power. That is a genuine contribution from AI, but it does not make the problem-specific contributions of mathematicians disappear into the general category of “human knowledge.”")

#text("A simple thought experiment might be useful: if we gave the same AI exactly the same computational resources, but limited its mathematical knowledge to what was available 100 years ago, would it still reach the same result as easily? And if mathematicians stopped contributing new ideas, questions, failed attempts and new paths from today onward, how long could AI continue advancing by working with what had already accumulated?")

#text("This also makes me wonder whether, at this early stage of AI-assisted science, we should avoid deciding too quickly what an ideal AI research assistant should look like. We are currently witnessing scientists and AI learning how to work together, and perhaps this process itself is valuable research data. If researchers could document, in a reasonably structured way, when AI entered the research process, what researchers contributed, what AI contributed, which suggestions failed or were rejected, where new directions emerged, and how final judgements were made, we could gradually build an empirical record of human–AI scientific collaboration.")

#text("Such records could serve two purposes at once. They could help researchers study which forms of human–AI interaction genuinely support inquiry, reasoning and discovery, providing evidence for the future design of better AI research assistants. At the same time, they could make attribution more transparent by showing how both human and AI contributions actually developed throughout the research process.")

#text("Perhaps the question is therefore not simply whether humans or AI “solved” a problem, but how the different contributions that made a solution possible can remain visible. AI deserves credit for what it actually discovers or completes, while researchers who spent years creating the intellectual paths that made such exploration possible should not be diluted into an anonymous “humanity.” If we can make this early period of learning how to work with AI visible rather than allowing it to disappear, it may become part of the evidence from which better forms of human–AI scientific collaboration can be designed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("“AI deserves credit for what it actually discovers or completes”. Never. There is no such thing as “credit” that has to be given to “AI”. The claim that “AI deserves credit” is a blatant form of idolatry. LLMs are just channeling human thought throughnot persons endowed with responsibility. That is in particular why they are not considered as authors of a paper. Moreover, the mathematics community has never felt the need to demand that works with several human authors also detail what contribution each author made. It seems unjustified to demand now that an author who has used an LLM should go into such detail, rather than just disclosing that they used an LLM and giving at most an outline of how extensive this use was.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e957bbe9594eeb5a0d31e3ddf3d131767fa8e0aaab74b6faaa76349d9b3e5aca-8e4f66a80855e3ff212d26f6c004d1209d56442d5fafdf116596a67cb9dbb962.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Starry Yu Zhang")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695911")[#strong[#text("Starry Yu Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Thanks — I think I may not have expressed this distinction clearly enough. By “credit”, I was not suggesting that AI should be treated as an author, nor that every mathematician’s individual contribution needs to be documented in detail.")

#text("What I am interested in preserving are the ")#strong[#text("key reasoning nodes")]#text(" through which an understanding develops: for example, what problem or limitation was perceived, what was tried, where an approach failed or produced a contradiction, what condition appeared to be missing, what new idea or direction entered the process, and how that changed what was explored next. If AI introduces something at one of these points, I think it is useful for that intervention to remain traceable, just as part of the history of how the reasoning developed.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Imagine this scenario: Three leading mathematicians are working independently on a difficult mathematical problem. They save their manuscript on an online platform that has an AI-powered grammar-checking feature, which is enabled by default. The mathematicians do not need or use this feature, and they are unaware that it is enabled. As a result, their manuscript becomes accessible to the AI system, and their draft is subsequently used as part of model training. Meanwhile, somewhere else in the world, another person uses the same AI system and asks it to solve the mathematical problem. Because the model was trained on the mathematicians’ manuscript, it is able to generate a proof based on their work. The person then publishes the proof, without knowing that the underlying ideas came from the mathematicians’ unpublished manuscript. This raises an important question: Who owns the intellectual contribution, and is it acceptable for an AI system to use unpublished work for training when the authors did not knowingly consent to it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("An alternative plan with journals might be what proposed in the comments here ")#link("https://galoisrepresentations.org/2026/09/17/ways-to-improve-mathematics-an-introduction/#comments")[#text("https://galoisrepresentations.org/2026/09/17/ways-to-improve-mathematics-an-introduction/#comments")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa002588eb919903595723d9e02e3f1f3b6c646eade892889004068f051dcdbe-32f671f518131d1d111903c930e781a514719fd62c2c596ef64a3b15c02da6a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695614")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Dear author, can you be more concrete about how LLM helped to “sharpen the writing”? I’m extremely wary of any LLM influence on writing beyond basic grammar and spelling checks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Athe EU is committing 10B in AI datacenters. This is roughly what the US and China put in in a DAY. Whatever you are proposing, you’re more than two orders of magnitude wrong with the funding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e957bbe9594eeb5a0d31e3ddf3d131767fa8e0aaab74b6faaa76349d9b3e5aca-8e4f66a80855e3ff212d26f6c004d1209d56442d5fafdf116596a67cb9dbb962.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Starry Yu Zhang")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695680")[#strong[#text("Starry Yu Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("One further point is that contribution transparency should work in both directions. When AI assists research, it should not be enough to say that the model merely performed “trial and error”, “search”, or “brute force”. If its suggestions, failed attempts, methods, or intermediate results provided continuous intellectual guidance toward the final result, those contributions should be documented as part of the research path.")

#text("At the same time, the ideas and methods brought into that process by AI may themselves have human histories. A person’s years of research should not simply dissolve into an anonymous pool of “human data” once it enters a model. Where identifiable and relevant, the provenance and developmental continuity of those contributions should be preserved.")

#text("Ideally, we should be able to reconstruct both paths: ")#strong[#text("what AI contributed to the researcher, and what human intellectual contributions made those AI contributions possible.")]#text(" This would allow attribution to be based on a traceable history of contribution rather than only on who produced the final answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7da70b88347d80417b42545415998a12c95865ad3a10c42570aa222eaed7c410-de7e73f2066c5afeb3e82274e8fd147c49c84ff189284702258b748372f930ac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nguyễn Xuân Bách")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-695795")[#strong[#text("Nguyễn Xuân Bách")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Establishing such a CERN-like facility for mathematics would be a remarkable development. However, speaking from my perspective as a chess player, the recent trend of seamlessly blending human and machine contributions in mathematical research could prove disastrous—a risk many mathematicians may not fully appreciate.")

#text("Consider a chess analogy: a novice equipped with a smartphone could defeat Magnus Carlsen simply by observing an engine’s evaluation bar, without even seeing the suggested moves. The ability to intuitively evaluate a position is a fundamental skill. A player who truly possesses this deep understanding can author a profound chess book, whereas a computer-assisted novice cannot.")

#text("In mathematics, the situation is even more complex. When AI is heavily integrated into the creative process, the boundary between human intuition and machine output blurs, making intellectual attribution nearly impossible. In chess, players improve by playing independently and using the engine only for post-game review. A similar boundary is necessary in math.")

#text("A better approach would be to structure this CERN-like entity as a centralized resource. Mathematicians collaborating on a shared problem could submit a formal, detailed proposal (e.g., a 5-to-10-page outline) to be reviewed by a panel of experts. If approved, the AI could then generate a comprehensive, 50-page manuscript. Later, human mathematicians working in a strictly traditional manner could treat these AI-generated papers as distinct entities to be studied and cited.")

#text("This framework would utilize AI as an optimization tool, preventing unfair competition and ensuring equitable access to computational resources. Furthermore, similar to strict anti-cheating rules in chess, any university or institute granted access to this centralized AI should be required to enforce a strict ban on the uncredited mixing of human and AI work within their own faculties and associated journals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-696676")[#strong[#text("Artificial intelligence and the mathematical community – Yiannis Sakellaridis' nascent blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")]

#text("[…] land-grab stage to monetization, will financially strangle our scientific institutions. Only an enormous publicly-funded investment can spare us that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42930a64f79286272eebe309f362215a6ffb9e27a1f03a7e8d9f2f1f98c03a4-65ebb05db218b727fdfcb38ea4eacba9416a1f925f16b3b6c55669d04d6bfcdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-697509")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("There is also a tremendous opportunity. Research often concentrates around a few established directions, partly through historical accident and the accumulation of resources and influence. Equally capable researchers may lack the means to seriously explore alternatives. Powerful AI could change this by making many more research directions feasible. But if access to the strongest AI systems is concentrated, the opposite could happen. Will AI broaden scientific exploration beyond the established research agendas, or reinforce their dominance?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-697623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("“First, scientific research can involve sensitive, proprietary or even classified data. Researchers need environments with strong confidentiality protections and clear accountability in the event of data breaches.”")

#text("Use Amazon Bedrock. If it’s good enough for the DoD (or DoW) then it’s probably good enough for science.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/#comment-697624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Amazon Bedrock already solves all of your privacy concerns. The design is that AWS, not the model maker, runs the model. It’s how the DoD/DoW runs their AI models on classified materials and issues of national defense, without being concerned about Anthropic seeing the data or training on it.")
]
