// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/
// Converted to Typst by tao2typ: "2026-10-14T16:36:06.958843+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Littlewood-Offord problem in high dimensions and a conjecture of Frankl and Füredi", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Littlewood-Offord problem in high dimensions and a conjecture of Frankl and Füredi")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/")[#text("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Van Vu and I have just uploaded to the arXiv our joint paper “")#link("http://arxiv.org/abs/1002.5028")[#text("The Littlewood-Offord problem in high dimensions and a conjecture of Frankl and Füredi")]#text("“. In this short paper we give a different proof of a high-dimensional Littlewood-Offord result ")#link("http://www.ams.org/mathscinet-getitem?mr=960947")[#text("of Frankl and Füredi")]#text(", and in the process also affirmatively answer one of their open problems.")

#text("Let ")#mi("{v_1,\\ldots,v_n}")#text(" be ")#mi("{n}")#text(" vectors in ")#mi("{{\\mathbb R}^d}")#text(", which we normalise to all have length at least ")#mi("{1}")#text(". For any given radius ")#mi("{\\Delta > 0}")#text(", we consider the ")#emph[#text("small ball probability")]

#align(center)[#tao-fit-display[#mitex("p(v_1,\\ldots,v_n,\\Delta) := \\sup_B {\\bf P}( \\eta_1 v_1 + \\ldots + \\eta_n v_n \\in B )")]]

#text("where ")#mi("{\\eta_1,\\ldots,\\eta_n}")#text(" are iid Bernoulli signs (i.e. they take values ")#mi("{+1}")#text(" or ")#mi("{-1}")#text(" independently with a probability of ")#mi("{1/2}")#text(" of each), and ")#mi("{B}")#text(" ranges over all (closed) balls of radius ")#mi("{\\Delta}")#text(". The ")#emph[#text("Littlewood-Offord problem")]#text(" is to compute the quantity")

#align(center)[#tao-fit-display[#mitex("p_d(n,\\Delta) := \\sup_{v_1,\\ldots,v_n} p(v_1,\\ldots,v_n,\\Delta)")]]

#text("where ")#mi("{v_1,\\ldots,v_n}")#text(" range over all vectors in ")#mi("{{\\mathbb R}^d}")#text(" of length at least one. Informally, this number measures the extent to which a random walk of length ")#mi("{n}")#text(" (with all steps of size at least one) can concentrate into a ball of radius ")#mi("{\\Delta}")#text(".")

#text("The one-dimensional case of this problem was answered ")#link("http://www.ams.org/mathscinet-getitem?mr=14608")[#text("by Erdös")]#text(". First, one observes that one can normalise all the ")#mi("{v_i}")#text(" to be at least ")#mi("{+1}")#text(" (as opposed to being at most ")#mi("{-1}")#text("). In the model case when ")#mi("{\\Delta < 1}")#text(", he made the following simple observation: if a random sum ")#mi("{\\eta_1 v_1 + \\ldots + \\eta_n v_n}")#text(" fell into a ball of radius ")#mi("{\\Delta}")#text(" (which in the one-dimensional case, is an interval of length less than ")#mi("{2}")#text("), and one then changed one or more of the signs ")#mi("{\\eta_i}")#text(" from ")#mi("{-1}")#text(" to ")#mi("{+1}")#text(", then the new sum must necessarily lie outside of the ball. In other words, for any ball ")#mi("{B}")#text(" of radius ")#mi("{\\Delta}")#text(", the set of signs ")#mi("{(\\eta_1,\\ldots,\\eta_n) \\in \\{-1,+1\\}^n}")#text(" for which ")#mi("{\\eta_1 v_1 + \\ldots + \\eta_n v_n \\in B}")#text(" forms an ")#link("http://en.wikipedia.org/wiki/Antichain")[#text("antichain")]#text(". Applying ")#link("http://en.wikipedia.org/wiki/Sperner's_theorem")[#text("Sperner’s theorem")]#text(", the maximal size of this antichain is ")#mi("{\\binom{n}{\\lfloor n/2\\rfloor}}")#text(", and this soon leads to the exact value")

#align(center)[#tao-fit-display[#mitex("p_1(n,\\Delta) = \\binom{n}{\\lfloor n/2\\rfloor}/2^n = \\frac{\\sqrt{\\frac{2}{\\pi}}+o(1)}{\\sqrt{n}}")]]

#text("when ")#mi("{0 \\leq \\Delta < 1}")#text(" (the bound is attained in the extreme case ")#mi("{v_1=\\ldots=v_n=1}")#text(").")

#text("A similar argument works for higher values of ")#mi("{\\Delta}")#text(", using ")#link("http://en.wikipedia.org/wiki/Dilworth%27s_theorem")[#text("Dilworth’s theorem")]#text(" instead of Sperner’s theorem, and gives the exact value")

#align(center)[#tao-fit-display[#mitex("p_1(n,\\Delta) = \\sum_{j=1}^s \\binom{n}{m_j}/2^n = \\frac{s\\sqrt{\\frac{2}{\\pi}}+o(1)}{\\sqrt{n}}")]]

#text("whenever ")#mi("{n \\geq s}")#text(" and ")#mi("{s-1 \\leq \\Delta < s}")#text(" for some natural number ")#mi("{s}")#text(", where ")#mi("{\\binom{n}{m_1},\\ldots,\\binom{n}{m_s}}")#text(" are the ")#mi("{s}")#text(" largest binomial coefficients of ")#mi("{\\binom{n}{1}, \\ldots, \\binom{n}{n}}")#text(".")

#text("Now consider the higher-dimensional problem. One has the obvious bound")

#align(center)[#tao-fit-display[#mitex("p_d(n,\\Delta) \\geq p_1(n,\\Delta),")]]

#text("but it is not obvious whether this inequality is strict. In other words, is there some way to exploit the additional freedom given by higher dimensions to make random walks concentrate more than in the one-dimensional case?")

#text("For some values of ")#mi("{\\Delta}")#text(", it turns out that the answer is no, as was first ")#link("http://www.ams.org/mathscinet-getitem?mr=265923")[#text("observed by Kleitman")]#text(" (and discussed further ")#link("http://www.ams.org/mathscinet-getitem?mr=960947")[#text("by Frankl and Füredi")]#text("). Suppose for instance that")

#align(center)[#tao-fit-display[#mitex("\\sqrt{(s-1)^2+1} \\leq \\Delta < s")]]

#text("for some ")#mi("{s \\geq 2}")#text(". Then one can consider the example in which ")#mi("{v_1=\\ldots=v_{n-1}=e_1}")#text(" is one unit vector, and ")#mi("{v_n=e_2}")#text(" is another unit vector orthogonal to ")#mi("{e_1}")#text(". The small ball probability in this case can be computed to equal ")#mi("{p_1(n-1,s-1)}")#text(" rather than ")#mi("{p_1(n,s-1)}")#text(", which is slightly larger.")

#text("In the positive direction, Frankl and Füredi established the asymptotic ")#metadata(none) <tao-ced2eea28f29d92e3d4f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("p_d(n,\\Delta) = (1 + o(1)) p_1(n,\\Delta)")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" (holding ")#mi("{d}")#text(" and ")#mi("{\\Delta}")#text(" fixed). Furthermore, if ")#mi("{\\Delta}")#text(" was close to an integer, and more precisely if")

#align(center)[#tao-fit-display[#mitex("s-1 \\leq \\Delta < s-1 + \\frac{1}{10s^2}")]]

#text("(so that the above counterexample can be avoided) they showed that ")#mi("{p_d(n,\\Delta) = p_1(n,\\Delta)}")#text(" for sufficiently large ")#mi("{n}")#text(" (depending on ")#mi("{s,\\Delta}")#text(").")

#text("The factor ")#mi("{\\frac{1}{10s^2}}")#text(" was an artefact of their method, and they conjectured in fact that one should have ")#mi("{p_d(n,\\Delta) = p_1(n,\\Delta)}")#text(" for sufficiently large ")#mi("{n}")#text(" whenever ")#metadata(none) <tao-d2a1dea1982544b06050>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("s-1 \\leq \\Delta < \\sqrt{(s-1)^2+1}")]]

#text("thus matching the counterexample exactly. This conjecture was verified for ")#mi("{s = 1}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=265923")[#text("by Kleitman")]#text(" and for ")#mi("{s=2,3}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=960947")[#text("by Frankl and Füredi")]#text(".")

#text("In this paper we verify the conjecture of Frankl and Füredi (and give a new proof of their asymptotic ")#link(<tao-ced2eea28f29d92e3d4f>)[#text("(1)")]#text("). Our main tool is the following high-dimensional Littlewood-Offord inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Suppose that ")#mi("{v_1,\\ldots,v_n \\in {\\mathbb R}^d}")#text(" which is genuinely ")#mi("{d}")#text("-dimensional in the sense that for any hyperplane ")#mi("{H}")#text(" going through the origin, one has ")#mi("{\\text{dist}(v_i,H) \\geq 1}")#text(" for at least ")#mi("{k}")#text(" values of ")#mi("{i}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("p(v_1,\\ldots,v_n,\\Delta) \\ll_{d,\\Delta} k^{-d/2}.")]]
]

#text("Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" can be viewed as a high-dimensional variant of Erdös’s inequality (but without the sharp upper bound). It is proven by the Fourier-analytic method ")#link("http://www.ams.org/mathscinet-getitem?mr=494478")[#text("of Halász")]#text(". (This theorem was announced in my book with Van Vu several years ago, but we did not get around to publishing it until now.)")

#text("Using Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", one can verify the conjecture of Frankl and Füredi fairly quickly (the deduction takes a little over a page). The main point is that if there is excessive concentration, then Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" quickly places almost all of the vectors ")#mi("{v_1,\\ldots,v_n}")#text(" to lie very close to a line. If ")#emph[#text("all")]#text(" the vectors are close to a line, then we can project onto this line and rescale, which causes ")#mi("{\\Delta}")#text(" to worsen a little bit in this reduction to the one-dimensional case, but it turns out that the bounds ")#link(<tao-d2a1dea1982544b06050>)[#text("(2)")]#text(" allow us to tolerate this degradation of ")#mi("{\\Delta}")#text(" once ")#mi("{s>3}")#text(" (so it is fortunate that the cases ")#mi("{s \\leq 3}")#text(" were already done for us!). If instead we have a vector far from the line (as is the case in the key counterexample), then we manually eliminate that vector using the ")#link("http://en.wikipedia.org/wiki/Parallelogram_law")[#text("parallelogram law")]#text(", which effectively drops ")#mi("{\\Delta}")#text(" below ")#mi("{s-1}")#text(" (half of the time, at least) if ")#mi("{\\Delta}")#text(" was initially less than ")#mi("{\\sqrt{(s-1)^2+1}}")#text(", which gives enough of a saving to conclude the argument.")

#text("One moral that one can draw from this argument is that one can use a quasi-sharp estimate (such as Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("), which ostensibly loses constant factors, to then deduce a sharp estimate (such as the Frankl-Furëdi conjecture) that loses no constant factors, as long as one is in an asymptotic regime (in this case, ")#mi("{s \\geq 3}")#text(" and ")#mi("{n}")#text(" large depending on ")#mi("{d,\\Delta}")#text("). The key is to exploit the fine structure in the main term (in this case, the piecewise constant nature of ")#mi("{p_1(n,\\Delta)}")#text(" when ")#mi("{\\Delta}")#text(" passes over integers) to extract gains that can absorb the losses coming from the quasi-sharp estimate).")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-43762")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2010")])]

#text("Did you mean ")#mi("p_d(n,\\Delta):=\\sup_{v_1,\\dots,v_n}p_d(v_1,\\dots,v_n,\\Delta)")#text("?")

#emph[#text("[Corrected, thanks.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2be7063d30cc0fed6cc2d0e7de64272e793922643132ecec511f1a42d3c3fb8-4d12764af0ebffc13264c6e0143fa071fee6eeac8e9e5f72d89fea1d73a0bf1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SteveM")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-43771")[#strong[#text("SteveM")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2010")])]

#text("I’m interested in random walks and diffusions but have never encountered")#linebreak()#text(" this interesting problem before. But if the random terms in the partial sum are iid Bernoulli {-1,+1} with probabilities p(1)=q(-1)=1/2, then won’t the strong law of large numbers guarantee that the small ball probability converges almost surely to unity as n tends to infinity, at least for some dimensions? Also, how is the problem changed if the iid Bernoulli random variables in the problem have probability p(1)>q(-1)? Generated by a biased coin for example. I’m thinking of discrete random walks that are either transient or recurrent with Brownian motion being the limit of a random walk where the step sizes get smaller and smaller. In three dimensions or higher Brownian motion is transient and should leave a ball, however large, around any point never to return. Whereas in one and two dimensions, Brownian motion is recurrent and should return to a neighbourhood however small, of any point, infinitely often. I’m just curious as to whether these points are relevent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-43774")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2010")])]

#text("The random walks here are not normalised by n (or by sqrt(n)), so the law of large numbers (or the central limit theorem) is not directly relevant, although the central limit theorem is certainly consistent with the concentration probability being of order 1/sqrt(n).")

#text("The Littlewood-Offord inequality (Theorem 1) is valid for more general random walks (we remark on this in the paper), but for the problem of computing quantities such as p_d(n,Delta) precisely, one needs to have the Bernoulli distribution on the nose (otherwise the combinatorial tools such as Sperner’s theorem and Dilworth’s theorem will not apply).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d596d8e96326c7bcc6d16d8703871df5a501dbe1ab8ee2206e1d040cf4d5311c-dbe7776b50e03b500e85537d1ac0cb4e2e06acd75663b5263f4a7fe164de21ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sunkhiroes")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-43775")[#strong[#text("sunkhiroes")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2010")])]

#text("I ck Arixv, and liked the Bernoulli use and shrinking k=dl (masterful) .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-48134")[#strong[#text("The Determinant of Random Bernoulli Matrices « Tsourolampis Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2010")]

#text("[…] [7] Littlewood-Offord ")#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conj")[#text("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conj")]#text("… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32f73724ad023696969c1cf6a5205365e507038acc7b86e4355512f20306398b-bb070d1df0224457ca972cf45f433b230b08ce2f60c7496db86620fdea248419.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rakshith")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-457062")[#strong[#text("Rakshith")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("Is the Littlewood-offord theorem valid if the random variables are not iid?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-457074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2015")])]

#text("Well, certainly ")#emph[#text("some")]#text(" discorrelation between the signs is required; if all the signs are constrained to be equal, for instance, then there is an enormous amount of concentration regardless of the presence or absence of arithmetic structure. But the iid hypothesis is probably way too strong, and one should have analogous results in the presence of weak correlation, although most of the methods used so far are not able to handle such correlation. (There is beginning to be a little work in this direction for the Littlewood-Offord problems arising from random regular graphs.)")

#text("On the other hand, the current techniques to prove Littlewood-Offord theorems should extend without much difficulty to the case of independent but not identically distributed variables (and there are probably results of this form in the literature already); identical distribution is largely a technical convenience rather than an essential hypothesis (as long as all the distributions of individual variables obey their hypotheses with a suitable level of uniformity).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32f73724ad023696969c1cf6a5205365e507038acc7b86e4355512f20306398b-bb070d1df0224457ca972cf45f433b230b08ce2f60c7496db86620fdea248419.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rakshith")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-457086")[#strong[#text("Rakshith")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2015")])]

#text("Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30dd8475d82af1c9d75fb0f3f9abbc7c3757c9582b8e9687f8b64c031378d155-958528b82618dbc450bcbebd4d90c76b32abc804848a82b1400154a37141c9c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zifan")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-468711")[#strong[#text("Zifan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("Professor Tao, where can I find a proof on \\displaystyle p_1(n,\\Delta) = \\sum_{j=1}^s \\binom{n}{m_j}/2^n = \\frac{s\\sqrt{\\frac{2}{\\pi}}+o(1)}{\\sqrt{n}}")#linebreak()#text(" this statement? I am not familiar with the Dilworth theorem so I don’t quite see how it can be used to calculate the sum of the largest binomial coefficients. Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-468712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("This is done in the ")#link("http://www.ams.org/journals/bull/1945-51-12/S0002-9904-1945-08454-7/home.html")[#text("original paper of Erdos")]#text(" linked to above. (Dilworth’s theorem is not mentioned by name in that paper, but it is essentially proven there.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30dd8475d82af1c9d75fb0f3f9abbc7c3757c9582b8e9687f8b64c031378d155-958528b82618dbc450bcbebd4d90c76b32abc804848a82b1400154a37141c9c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zifan")]], [#link("https://terrytao.wordpress.com/2010/03/01/the-littlewood-offord-problem-in-high-dimensions-and-a-conjecture-of-frankl-and-furedi/#comment-468714")[#strong[#text("Zifan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("Thanks for the quick reply! I see. Theorem 2 is what I want. But I am a little bit confused by $c_1$ in that theorem. Is $c_1$ a universal constant. If not, what does $c_1$ depends on?")
]
]
]
