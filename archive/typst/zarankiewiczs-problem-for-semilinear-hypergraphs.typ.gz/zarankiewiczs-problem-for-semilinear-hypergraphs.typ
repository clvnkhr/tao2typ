// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/
// Converted to Typst by tao2typ: "2026-10-14T16:38:50.572632+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Zarankiewicz’s problem for semilinear hypergraphs", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Zarankiewicz’s problem for semilinear hypergraphs")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 September 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/")[#text("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://sites.google.com/view/abasit")[#text("Abdul Basit")]#text(", ")#link("https://www.math.ucla.edu/~chernikov/")[#text("Artem Chernikov")]#text(", ")#link("https://math.nd.edu/people/faculty/sergei-starchenko/")[#text("Sergei Starchenko")]#text(", ")#link("https://faculty.math.illinois.edu/~mctran2/")[#text("Chiu-Minh Tran")]#text(" and I have uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2009.02922")[#text("Zarankiewicz’s problem for semilinear hypergraphs")]#text(". This paper is in the spirit of a number of results in extremal graph theory in which the bounds for various graph-theoretic problems or results can be greatly improved if one makes some additional hypotheses regarding the structure of the graph, for instance by requiring that the graph be “definable” with respect to some theory with good model-theoretic properties.")

#text("A basic motivating example is the question of counting the number of incidences between points and lines (or between points and other geometric objects). Suppose one has ")#mi("{n}")#text(" points and ")#mi("{n}")#text(" lines in a space. How many incidences can there be between these points and lines? The utterly trivial bound is ")#mi("{n^2}")#text(", but by using the basic fact that two points determine a line (or two lines intersect in at most one point), a simple application of Cauchy-Schwarz improves this bound to ")#mi("{n^{3/2}}")#text(". In graph theoretic terms, the point is that the bipartite incidence graph between points and lines does not contain a copy of ")#mi("{K_{2,2}}")#text(" (there does not exist two points and two lines that are all incident to each other). Without any other further hypotheses, this bound is basically sharp: consider for instance the collection of ")#mi("{p^2}")#text(" points and ")#mi("{p^2+p}")#text(" lines in a finite plane ")#mi("{{\\bf F}_p^2}")#text(", that has ")#mi("{p^3+p^2}")#text(" incidences (one can make the situation more symmetric by working with a projective plane rather than an affine plane). If however one considers lines in the real plane ")#mi("{{\\bf R}^2}")#text(", the famous ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(" improves the incidence bound further from ")#mi("{n^{3/2}}")#text(" to ")#mi("{O(n^{4/3})}")#text(". Thus the incidence graph between real points and lines contains more structure than merely the absence of ")#mi("{K_{2,2}}")#text(".")

#text("More generally, bounding on the size of bipartite graphs (or multipartite hypergraphs) not containing a copy of some complete bipartite subgraph ")#mi("{K_{k,k}}")#text(" (or ")#mi("{K_{k,\\dots,k}}")#text(" in the hypergraph case) is known as ")#emph[#text("Zarankiewicz’s problem")]#text(". We have results for all ")#mi("{k}")#text(" and all orders of hypergraph, but for sake of this post I will focus on the bipartite ")#mi("{k=2}")#text(" case.")

#text("In our paper we improve the ")#mi("{n^{3/2}}")#text(" bound to a near-linear bound in the case that the incidence graph is “semilinear”. A model case occurs when one considers incidences between points and axis-parallel rectangles in the plane. Now the ")#mi("{K_{2,2}}")#text(" condition is not automatic (it is of course possible for two distinct points to both lie in two distinct rectangles), so we impose this condition by ")#emph[#text("fiat")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Suppose one has ")#mi("{n}")#text(" points and ")#mi("{n}")#text(" axis-parallel rectangles in the plane, whose incidence graph contains no ")#mi("{K_{2,2}}")#text("‘s, for some large ")#mi("{n}")#text(".")

#list(
[#text("(i) The total number of incidences is ")#mi("{O(n \\log^4 n)}")#text(".")],
[#text("(ii) If all the rectangles are dyadic, the bound can be improved to ")#mi("{O( n \\frac{\\log n}{\\log\\log n} )}")#text(".")],
[#text("(iii) The bound in (ii) is best possible (up to the choice of implied constant).")]
)
]

#text("We don’t know whether the bound in (i) is similarly tight for non-dyadic boxes; the usual tricks for reducing the non-dyadic case to the dyadic case strangely fail to apply here. One can generalise to higher dimensions, replacing rectangles by polytopes with faces in some fixed finite set of orientations, at the cost of adding several more logarithmic factors; also, one can replace the reals by other ordered division rings, and replace polytopes by other sets of bounded “semilinear descriptive complexity”, e.g., unions of boundedly many polytopes, or which are cut out by boundedly many functions that enjoy coordinatewise monotonicity properties. For certain specific graphs we can remove the logarithmic factors entirely. We refer to the preprint for precise details.")

#text("The proof techniques are combinatorial. The proof of (i) relies primarily on the order structure of ")#mi("{{\\bf R}}")#text(" to implement a “divide and conquer” strategy in which one can efficiently control incidences between ")#mi("{n}")#text(" points and rectangles by incidences between approximately ")#mi("{n/2}")#text(" points and boxes. For (ii) there is additional order-theoretic structure one can work with: first there is an easy pruning device to reduce to the case when no rectangle is completely contained inside another, and then one can impose the “tile partial order” in which one dyadic rectangle ")#mi("{I \\times J}")#text(" is less than another ")#mi("{I^{\\prime} \\times J^{\\prime}}")#text(" if ")#mi("{I \\subset I^{\\prime}}")#text(" and ")#mi("{J^{\\prime} \\subset J}")#text(". The point is that this order is “locally linear” in the sense that for any two dyadic rectangles ")#mi("{R_-, R_+}")#text(", the set ")#mi("{[R_-,R_+] := \\{ R: R_- \\leq R \\leq R_+\\}}")#text(" is linearly ordered, and this can be exploited by elementary double counting arguments to obtain a bound which eventually becomes ")#mi("{O( n \\frac{\\log n}{\\log\\log n})}")#text(" after optimising certain parameters in the argument. The proof also suggests how to construct the counterexample in (iii), which is achieved by an elementary iterative construction.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/124f2317c08c4d35f23785e647ba4da7ea5b54e91cc0b97f90495f7b029a8950-52e8d46162151a102d40dcda946c298a4443f49577a98fe9dd24447fc7395ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeraoulia Rafik")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-588407")[#strong[#text("zeraoulia Rafik")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2020")])]

#text("@Dear prof Tao , You have claimed in paragraph or section 2 that the famous Szemerédi-Trotter theorem improve the incidence bounds further n^(3/2) to O(n^{4/3}) but in wikipedia for Szemerédi-Trotter theorem the incidence bound can’t be improved , except in terms of the implicit constants, I want to explain me how this ? or probably you mean the exception case namely implicit constant which it is not clear to me , Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-588911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2020")])]

#text("Just a short update: Tomon and Zakharov have ")#link("https://arxiv.org/abs/2009.04380")[#text("now used")]#text(" the counterexample construction in Theorem 1(iii) to disprove a recent conjecture ")#link("https://arxiv.org/abs/1407.5075")[#text("of Alon, Basavaraju, Chandran, Mathew, and Rajendraprasad")]#text(" regarding the maximal possible number of edges in a graph of a given separation dimension and number of vertices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-588984")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2020")])]

#text("What does it mean for an incidence graph to be “semilinear”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-588997")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("It means that the incidence relation can be defined using a finite number of linear inequalities (over some suitable ordered ring). (Here the “semi-” prefix is in the same sense as “")#link("https://en.wikipedia.org/wiki/Semialgebraic_set")[#text("semi-algebraic set")]#text("“.) For instance, to describe the incidences between a set ")#mi("P")#text(" of points in the plane and a set ")#mi("R")#text(" of rectangles, one can view ")#mi("P")#text(" as a collection of pairs ")#mi("(x,y)")#text(" in ")#mi("{\\bf R}^2")#text(", and ")#mi("R")#text(" as a collection of quadruples ")#mi("(x_1,y_1,x_2,y_2)")#text(" in ")#mi("{\\bf R}^4")#text(", and the incidence relation is then given by the linear inequalities ")#mi("x_1 \\leq x \\leq x_2")#text(" and ")#mi("y_1 \\leq y \\leq y_2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-589010")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2020")])]

#text("Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-589412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2020")])]

#text("Noice")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3badc63d6617ba0093ad18857c42bb76d17be0bd6fb70d029a0bd2420db1aa40-3f9a34b3724e6447fcaf6a5a8bf4b6484b902263f42f0478e55e1ce74498f48a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-595308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("why the prop2.8 need condition ‘finite’? where the condition is applied in the proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-595393")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("Ah, right, this condition is in fact never used, it can be safely deleted.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d256d00d40685b83fabdfdc71d99615ee527a87bb77fd51a40b75cc2b9db819-e280e5e17c4552ac316f5a5b367c124aa6a71ef3a5e59c126a475b8ea983ce18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HongJun Ge")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-602485")[#strong[#text("HongJun Ge")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2020")])]

#text("Dear prof Tao, in remark4.7 how can you prove that the probability is larger than 10^(-10)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-602764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2020")])]

#text("Ah, this claim turns out to be not quite true as stated; one needs to use a non-isotropic dilation in which the x and y coordinates are multiplied by different dilation factors, rather than the isotropic dilation currently written, in order to have a positive probability of the rectangle being approximately dyadic. Basically a horizontal dilation will make (with positive probability) the horizontal side length close to a power of two (say between $1.001$ and $1.002$ times a power of two), a vertical dilation will achieve a similar effect for the vertical side length, and then a random translation will then place the rectangle very close to a dyadic rectangle with positive probability.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4aea057bf66c179d58134110da65c694d505feeb3cd55479bc5344c14aa9422-38f2eaf667f5cf8c27473c75fc1a9836563f81f3d1d116cb8a19580e2ca10fb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arslanahmedphm")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-603696")[#strong[#text("arslanahmedphm")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("@Dear Prof Tao , Suppose we have a point p(a,b) a and b are given and let L be a line s.t p(a,b) belong to L")#linebreak()#text(" By this information can we know the equation of L in terms of P(a.b) ?can it gives as more information about L?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d256d00d40685b83fabdfdc71d99615ee527a87bb77fd51a40b75cc2b9db819-e280e5e17c4552ac316f5a5b367c124aa6a71ef3a5e59c126a475b8ea983ce18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HongJun Ge")]], [#link("https://terrytao.wordpress.com/2020/09/08/zarankiewiczs-problem-for-semilinear-hypergraphs/#comment-622741")[#strong[#text("HongJun Ge")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2021")])]

#text("Dear prof Tao. In section 5 we define a_cB means dim(a/BC)=dim(a/C). What’s the meaning of BC?")

#emph[#text("[This is notation (common in model theory) for the union of $B$ and $C$. -T]")]
]
