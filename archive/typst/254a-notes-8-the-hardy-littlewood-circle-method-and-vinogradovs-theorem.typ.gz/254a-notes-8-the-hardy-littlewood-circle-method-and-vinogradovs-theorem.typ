// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:37:40.661139+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 March 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We have seen in previous notes that the operation of forming a Dirichlet series")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(n) := \\sum_n \\frac{f(n)}{n^s}")]]

#text("or twisted Dirichlet series")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} \\chi f(n) := \\sum_n \\frac{f(n) \\chi(n)}{n^s}")]]

#text("is an incredibly useful tool for questions in multiplicative number theory. Such series can be viewed as a multiplicative Fourier transform, since the functions ")#mi("{n \\mapsto \\frac{1}{n^s}}")#text(" and ")#mi("{n \\mapsto \\frac{\\chi(n)}{n^s}}")#text(" are multiplicative characters.")#linebreak()#text(" Similarly, it turns out that the operation of forming an ")#emph[#text("additive")]#text(" Fourier series")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\theta) := \\sum_n f(n) e(-n \\theta),")]]

#text("where ")#mi("{\\theta}")#text(" lies on the (additive) unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" and ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(" is the standard additive character, is an incredibly useful tool for ")#emph[#text("additive")]#text(" number theory, particularly when studying additive problems involving three or more variables taking values in sets such as the primes; the deployment of this tool is generally known as the ")#emph[#text("Hardy-Littlewood circle method")]#text(". (In the analytic number theory literature, the minus sign in the phase ")#mi("{e(-n\\theta)}")#text(" is traditionally omitted, and what is denoted by ")#mi("{\\hat f(\\theta)}")#text(" here would be referred to instead by ")#mi("{S_f(-\\theta)}")#text(", ")#mi("{S(f;-\\theta)}")#text(" or just ")#mi("{S(-\\theta)}")#text(".) We list some of the most classical problems in this area:")

#list(
[#text("(")#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("Even Goldbach conjecture")]#text(") Is it true that every even natural number ")#mi("{N}")#text(" greater than two can be expressed as the sum ")#mi("{p_1+p_2}")#text(" of two primes?")],
[#text("(")#link("http://en.wikipedia.org/wiki/Goldbach%27s_weak_conjecture")[#text("Odd Goldbach conjecture")]#text(") Is it true that every odd natural number ")#mi("{N}")#text(" greater than five can be expressed as the sum ")#mi("{p_1+p_2+p_3}")#text(" of three primes?")],
[#text("(")#link("http://en.wikipedia.org/wiki/Waring%27s_problem")[#text("Waring problem")]#text(") For each natural number ")#mi("{k}")#text(", what is the least natural number ")#mi("{g(k)}")#text(" such that every natural number ")#mi("{N}")#text(" can be expressed as the sum of ")#mi("{g(k)}")#text(" or fewer ")#mi("{k^{th}}")#text(" powers?")],
[#text("(Asymptotic Waring problem) For each natural number ")#mi("{k}")#text(", what is the least natural number ")#mi("{G(k)}")#text(" such that every ")#emph[#text("sufficiently large")]#text(" natural number ")#mi("{N}")#text(" can be expressed as the sum of ")#mi("{G(k)}")#text(" or fewer ")#mi("{k^{th}}")#text(" powers?")],
[#text("(Partition function problem) For any natural number ")#mi("{N}")#text(", let ")#mi("{p(N)}")#text(" denote the number of representations of ")#mi("{N}")#text(" of the form ")#mi("{N = n_1 + \\dots + n_k}")#text(" where ")#mi("{k}")#text(" and ")#mi("{n_1 \\geq \\dots \\geq n_k}")#text(" are natural numbers. What is the asymptotic behaviour of ")#mi("{p(N)}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text("?")]
)

#text("The Waring problem and its asymptotic version will not be discussed further here, save to note that the Vinogradov mean value theorem (Theorem 13 from ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(") and its variants are particularly useful for getting good bounds on ")#mi("{G(k)}")#text("; see for instance the ")#link("http://arxiv.org/abs/1404.3508")[#text("ICM article of Wooley")]#text(" for recent progress on these problems. Similarly, the partition function problem was the original motivation of Hardy and Littlewood in introducing the circle method, but we will not discuss it further here; see e.g. Chapter 20 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for a treatment.")

#text("Instead, we will focus our attention on the odd Goldbach conjecture as our model problem. (The even Goldbach conjecture, which involves only two variables instead of three, is unfortunately not amenable to a circle method approach for a variety of reasons, unless the statement is replaced with something weaker, such as an averaged statement; see ")#link("https://terrytao.wordpress.com/2012/05/20/heuristic-limitations-of-the-circle-method/")[#text("this previous blog post")]#text(" for further discussion. On the other hand, the methods here can obtain weaker versions of the even Goldbach conjecture, such as showing that “almost all” even numbers are the sum of two primes; see Exercise ")#link(<tao-e083ce0f89f964ebf351>)[#text("34")]#text(" below.) In particular, we will establish the following celebrated ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("theorem of Vinogradov")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Vinogradov’s theorem)")]#text(" ")#metadata(none) <tao-28d46654d81889701f71>#text(" Every sufficiently large odd number ")#mi("{N}")#text(" is expressible as the sum of three primes.")
]

#text("Recently, the restriction that ")#mi("{n}")#text(" be sufficiently large was replaced ")#link("http://arxiv.org/abs/1501.05438")[#text("by Helfgott")]#text(" with ")#mi("{N > 5}")#text(", thus establishing the odd Goldbach conjecture in full. This argument followed the same basic approach as Vinogradov (based on the circle method), but with various estimates replaced by “log-free” versions (analogous to the log-free zero-density theorems in ")#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/")[#text("Notes 7")]#text("), combined with careful numerical optimisation of constants and also some numerical work on the even Goldbach problem and on the generalised Riemann hypothesis. We refer the reader to ")#link("http://arxiv.org/abs/1501.05438")[#text("Helfgott’s text")]#text(" for details.")

#text("We will in fact show the more precise statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Quantitative Vinogradov theorem)")]#text(" ")#metadata(none) <tao-82183b7fca9b98f39584>#text(" Let ")#mi("{N \\geq 2}")#text(" be an natural number. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c: a+b+c=N} \\Lambda(a) \\Lambda(b) \\Lambda(c) = G_3(N) \\frac{N^2}{2} + O_A( N^2 \\log^{-A} N )")]]

#text("for any ")#mi("{A>0}")#text(", where ")#metadata(none) <tao-952eb25e6903e35b2b7d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("G_3(N) = \\prod_{p|N} (1-\\frac{1}{(p-1)^2}) \\times \\prod_{p \\not | N} (1 + \\frac{1}{(p-1)^3}).")]]

#text("The implied constants are ineffective.")
]

#text("We dropped the hypothesis that ")#mi("{N}")#text(" is odd in Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(", but note that ")#mi("{G_3(N)}")#text(" vanishes when ")#mi("{N}")#text(" is even. For odd ")#mi("{N}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("1 \\ll G_3(N) \\ll 1.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(" implies Theorem ")#link(<tao-28d46654d81889701f71>)[#text("1")]#text(".")
]

#text("Unfortunately, due to the ineffectivity of the constants in Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(" (a consequence of the reliance on the Siegel-Walfisz theorem in the proof of that theorem), one cannot quantify explicitly what “sufficiently large” means in Theorem ")#link(<tao-28d46654d81889701f71>)[#text("1")]#text(" directly from Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(". However, there is a modification of this theorem which gives effective bounds; see Exercise ")#link(<tao-46e0876178516073c5ae>)[#text("32")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Obtain a heuristic derivation of the main term ")#mi("{G_3(N) \\frac{N^2}{2}}")#text(" using the modified Cramér model (Section 1 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(").")
]

#text("To prove Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(", we consider the more general problem of estimating sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} f(a) g(b) h(c)")]]

#text("for various integers ")#mi("{N}")#text(" and functions ")#mi("{f,g,h: {\\bf Z} \\rightarrow {\\bf C}}")#text(", which we will take to be finitely supported to avoid issues of convergence.")#linebreak()#text(" Suppose that ")#mi("{f,g,h}")#text(" are supported on ")#mi("{\\{1,\\dots,N\\}}")#text("; for simplicity, let us first assume the pointwise bound ")#tao-math("{\\left|f(n)\\right|, \\left|g(n)\\right|, \\left|h(n)\\right| \\ll 1}", block: false)#text(" for all ")#mi("{n}")#text(". (This simple case will not cover the case in Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(", when ")#mi("{f,g,h}")#text(" are truncated versions of the von Mangoldt function ")#mi("{\\Lambda}")#text(", but will serve as a warmup to that case.) Then we have the trivial upper bound ")#metadata(none) <tao-36e0fd847d927d68475f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} f(a) g(b) h(c) \\ll N^2.")]]

#linebreak()#text(" ")#text(" A basic observation is that this upper bound is attainable if ")#mi("{f,g,h}")#text(" all “pretend” to behave like the same additive character ")#mi("{n \\mapsto e(\\theta n)}")#text(" for some ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(". For instance, if ")#mi("{f(n)=g(n)=h(n) = e(\\theta n) 1_{n \\leq N}}")#text(", then we have ")#mi("{f(a)g(b)h(c) = e(\\theta N)}")#text(" when ")#mi("{a+b+c=N}")#text(", and then it is not difficult to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} f(a) g(b) h(c) = (\\frac{1}{2}+o(1)) e(\\theta N) N^2")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(".")#linebreak()#text(" The key to the success of the circle method lies in the converse of the above statement: the ")#emph[#text("only")]#text(" way that the trivial upper bound ")#link(<tao-36e0fd847d927d68475f>)[#text("(2)")]#text(" comes close to being sharp is when ")#mi("{f,g,h}")#text(" all correlate with the same character ")#mi("{n \\mapsto e(\\theta n)}")#text(", or in other words ")#mi("{\\hat f(\\theta), \\hat g(\\theta), \\hat h(\\theta)}")#text(" are simultaneously large. This converse is largely captured by the following two identities:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-8a39178d327e72a92d3b>#text(" Let ")#mi("{f,g,h: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be finitely supported functions. Then for any natural number ")#mi("{N}")#text(", show that ")#metadata(none) <tao-c2242e2c12190babaf9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{a,b,c: a+b+c=N} f(a) g(b) h(c) = \\int_{{\\bf R}/{\\bf Z}} \\hat f(\\theta) \\hat g(\\theta) \\hat h(\\theta) e(\\theta N)\\ d\\theta")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|f(n)\\right|^2 = \\int_{{\\bf R}/{\\bf Z}} \\left|\\hat f(\\theta)\\right|^2\\ d\\theta.", block: true)]]
]

#text("The traditional approach to using the circle method to compute sums such as ")#mi("{\\sum_{a,b,c: a+b+c=N} f(a) g(b) h(c)}")#text(" proceeds by invoking ")#link(<tao-c2242e2c12190babaf9f>)[#text("(3)")]#text(" to express this sum as an integral over the unit circle, then dividing the unit circle into “major arcs” where ")#mi("{\\hat f(\\theta), \\hat g(\\theta),\\hat h(\\theta)}")#text(" are large but computable with high precision, and “minor arcs” where one has estimates to ensure that ")#mi("{\\hat f(\\theta), \\hat g(\\theta),\\hat h(\\theta)}")#text(" are small in both ")#mi("{L^\\infty}")#text(" and ")#mi("{L^2}")#text(" senses. For functions ")#mi("{f,g,h}")#text(" of number-theoretic significance, such as truncated von Mangoldt functions, the “major arcs” typically consist of those ")#mi("{\\theta}")#text(" that are close to a rational number ")#mi("{\\frac{a}{q}}")#text(" with ")#mi("{q}")#text(" not too large, and the “minor arcs” consist of the remaining portions of the circle. One then obtains lower bounds on the contributions of the major arcs, and upper bounds on the contribution of the minor arcs, in order to get good lower bounds on ")#mi("{\\sum_{a,b,c: a+b+c=N} f(a) g(b) h(c)}")#text(".")

#text("This traditional approach is covered in many places, such as ")#link("http://www.ams.org/mathscinet-getitem?mr=628618")[#text("this text of Vaughan")]#text(". We will emphasise in this set of notes a slightly different perspective on the circle method, coming from recent developments in additive combinatorics; this approach does not quite give the sharpest quantitative estimates, but it allows for easier generalisation to more combinatorial contexts, for instance when replacing the primes by dense subsets of the primes, or replacing the equation ")#mi("{a+b+c=N}")#text(" with some other equation or system of equations.")

#text("From Exercise ")#link(<tao-8a39178d327e72a92d3b>)[#text("5")]#text(" and Hölder’s inequality, we immediately obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-a3510d75a8d801b1ae57>#text(" Let ")#mi("{f,g,h: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be finitely supported functions. Then for any natural number ")#mi("{N}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{a,b,c: a+b+c=N} f(a) g(b) h(c)\\right| \\leq (\\sum_n \\left|f(n)\\right|^2)^{1/2} (\\sum_n \\left|g(n)\\right|^2)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\times \\sup_\\theta \\left|\\sum_n h(n) e(n\\theta)\\right|.", block: true)]]

#text("Similarly for permutations of the ")#mi("{f,g,h}")#text(".")
]

#text("In the case when ")#mi("{f,g,h}")#text(" are supported on ")#mi("{[1,N]}")#text(" and bounded by ")#mi("{O(1)}")#text(", this corollary tells us that we have ")#mi("{\\sum_{a,b,c: a+b+c=N} f(a) g(b) h(c)}")#text(" is ")#mi("{o(N^2)}")#text(" whenever one has ")#mi("{\\sum_n h(n) e(n\\theta) = o(N)}")#text(" uniformly in ")#mi("{\\theta}")#text(", and similarly for permutations of ")#mi("{f,g,h}")#text(". From this and the triangle inequality, we obtain the following conclusion: if ")#mi("{f}")#text(" is supported on ")#mi("{[1,N]}")#text(" and bounded by ")#mi("{O(1)}")#text(", and ")#mi("{f}")#text(" is ")#emph[#text("Fourier-approximated")]#text(" by another function ")#mi("{g}")#text(" supported on ")#mi("{[1,N]}")#text(" and bounded by ")#mi("{O(1)}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) e(n\\theta) = \\sum_n g(n) e(n\\theta) + o(N)")]]

#text("uniformly in ")#mi("{\\theta}")#text(", then we have ")#metadata(none) <tao-ab88ea80fdee69b28b0f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{a,b,c: a+b+c=N} f(a) f(b) f(c) = \\sum_{a,b,c: a+b+c=N} g(a) g(b) g(c) + o(N^2).")]]

#text("Thus, one possible strategy for estimating the sum ")#mi("{\\sum_{a,b,c: a+b+c=N} f(a) f(b) f(c)}")#text(" is, one can effectively replace (or “model”) ")#mi("{f}")#text(" by a simpler function ")#mi("{g}")#text(" which Fourier-approximates ")#mi("{g}")#text(" in the sense that the exponential sums ")#mi("{\\sum_n f(n) e(n\\theta), \\sum_n g(n) e(n\\theta)}")#text(" agree up to error ")#mi("{o(N)}")#text(". For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{N}")#text(" be a natural number, and let ")#mi("{A}")#text(" be a random subset of ")#mi("{\\{1,\\dots,N\\}}")#text(", chosen so that each ")#mi("{n \\in \\{1,\\dots,N\\}}")#text(" has an independent probability of ")#mi("{1/2}")#text(" of lying in ")#mi("{A}")#text(".")

#list(
[#text("(i) If ")#mi("{f := 1_A}")#text(" and ")#mi("{g := \\frac{1}{2} 1_{[1,N]}}")#text(", show that with probability ")#mi("{1-o(1)}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", one has ")#mi("{\\sum_n f(n) e(n\\theta) = \\sum_n g(n) e(n\\theta) + o(N)}")#text(" uniformly in ")#mi("{\\theta}")#text(". (")#emph[#text("Hint:")]#text(" for any fixed ")#mi("{\\theta}")#text(", this can be accomplished with quite a good probability (e.g. ")#mi("{1-o(N^{-2})}")#text(") using a concentration of measure inequality, such as ")#link("http://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding’s inequality")]#text(". To obtain the uniformity in ")#mi("{\\theta}")#text(", round ")#mi("{\\theta}")#text(" to the nearest multiple of (say) ")#mi("{1/N^2}")#text(" and apply the union bound).")],
[#text("(ii) Show that with probability ")#mi("{1-o(1)}")#text(", one has ")#mi("{(\\frac{1}{16}+o(1))N^2}")#text(" representations of the form ")#mi("{N=a+b+c}")#text(" with ")#mi("{a,b,c \\in A}")#text(" (with ")#mi("{(a,b,c)}")#text(" treated as an ordered triple, rather than an unordered one).")]
)
]

#text("In the case when ")#mi("{f}")#text(" is something like the truncated von Mangoldt function ")#mi("{\\Lambda(n) 1_{n \\leq N}}")#text(", the quantity ")#tao-math("{\\sum_n \\left|f(n)\\right|^2}", block: false)#text(" is of size ")#mi("{O( N \\log N)}")#text(" rather than ")#mi("{O( N )}")#text(". This costs us a logarithmic factor in the above analysis, however we can still conclude that we have the approximation ")#link(<tao-ab88ea80fdee69b28b0f>)[#text("(4)")]#text(" whenever ")#mi("{g}")#text(" is another sequence with ")#tao-math("{\\sum_n \\left|g(n)\\right|^2 \\ll N \\log N}", block: false)#text(" such that one has the improved Fourier approximation ")#metadata(none) <tao-a4c5f89e3fe8c459f5d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_n f(n) e(n\\theta) = \\sum_n g(n) e(n\\theta) + o(\\frac{N}{\\log N})")]]

#linebreak()#text(" ")#text(" uniformly in ")#mi("{\\theta}")#text(". (Later on we will obtain a “log-free” version of this implication in which one does not need to gain a factor of ")#mi("{\\frac{1}{\\log N}}")#text(" in the error term.)")#linebreak()#text(" This suggests a strategy for proving Vinogradov’s theorem: find an approximant ")#mi("{g}")#text(" to some suitable truncation ")#mi("{f}")#text(" of the von Mangoldt function (e.g. ")#mi("{f(n) = \\Lambda(n) 1_{n \\leq N}}")#text(" or ")#mi("{f(n) = \\Lambda(n) \\eta(n/N)}")#text(") which obeys the Fourier approximation property ")#link(<tao-a4c5f89e3fe8c459f5d2>)[#text("(5)")]#text(", and such that the expression ")#mi("{\\sum_{a+b+c=N} g(a) g(b) g(c)}")#text(" is easily computable. It turns out that there are a number of good options for such an approximant ")#mi("{g}")#text(". One of the quickest ways to obtain such an approximation (which is used in Chapter 19 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(") is to start with the standard identity ")#mi("{\\Lambda = -\\mu L * 1}")#text(", that is to say")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) = - \\sum_{d|n} \\mu(d) \\log d,")]]

#text("and obtain an approximation by truncating ")#mi("{d}")#text(" to be less than some threshold ")#mi("{R}")#text(" (which, in practice, would be a small power of ")#mi("{N}")#text("): ")#metadata(none) <tao-f0d35077d78a95f0b9bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\Lambda(n) \\approx - \\sum_{d \\leq R: d|n} \\mu(d) \\log d.")]]

#text("Thus, for instance, if ")#mi("{f(n) = \\Lambda(n) 1_{n \\leq N}}")#text(", the approximant ")#mi("{g}")#text(" would be taken to be")

#align(center)[#tao-fit-display[#mitex("g(n) := - \\sum_{d \\leq R: d|n} \\mu(d) \\log d 1_{n \\leq N}.")]]

#text("One could also use the slightly smoother approximation ")#metadata(none) <tao-81fd67d02f679b818a4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\Lambda(n) \\approx \\sum_{d \\leq R: d|n} \\mu(d) \\log \\frac{R}{d}")]]

#text("in which case we would take")

#align(center)[#tao-fit-display[#mitex("g(n) := \\sum_{d \\leq R: d|n} \\mu(d) \\log \\frac{R}{d} 1_{n \\leq N}.")]]

#text("The function ")#mi("{g}")#text(" is somewhat similar to the continuous Selberg sieve weights studied in ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(", with the main difference being that we did not square the divisor sum as we will not need to take ")#mi("{g}")#text(" to be non-negative. As long as ")#mi("{z}")#text(" is not too large, one can use some sieve-like computations to compute expressions like ")#mi("{\\sum_{a+b+c=N} g(a)g(b)g(c)}")#text(" quite accurately. The approximation ")#link(<tao-a4c5f89e3fe8c459f5d2>)[#text("(5)")]#text(" can be justified by using a nice estimate of Davenport that exemplifies the Mobius pseudorandomness heuristic from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Davenport’s estimate)")]#text(" ")#metadata(none) <tao-88ba1c4700c3e4b3c697>#text(" For any ")#mi("{A>0}")#text(" and ")#mi("{x \\geq 2}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) e(\\theta n) \\ll_A x \\log^{-A} x")]]

#text("uniformly for all ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(". The implied constants are ineffective.")
]

#text("This estimate will be proven by splitting into two cases. In the “major arc” case when ")#mi("{\\theta}")#text(" is close to a rational ")#mi("{a/q}")#text(" with ")#mi("{q}")#text(" small (of size ")#mi("{O(\\log^{O(1)} x)}")#text(" or so), this estimate will be a consequence of the Siegel-Walfisz theorem ( from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("); it is the application of this theorem that is responsible for the ineffective constants. In the remaining “minor arc” case, one proceeds by using a combinatorial identity (such as Vaughan’s identity) to express the sum ")#mi("{\\sum_{n \\leq x} \\mu(n) e(\\theta n)}")#text(" in terms of bilinear sums of the form ")#mi("{\\sum_n \\sum_m a_n b_m e(\\theta nm)}")#text(", and use the Cauchy-Schwarz inequality and the minor arc nature of ")#mi("{\\theta}")#text(" to obtain a gain in this case. This will all be done below the fold. We will also use (a rigorous version of) the approximation ")#link(<tao-f0d35077d78a95f0b9bd>)[#text("(6)")]#text(" (or ")#link(<tao-81fd67d02f679b818a4d>)[#text("(7)")]#text(") to establish Vinogradov’s theorem.")

#text("A somewhat different looking approximation for the von Mangoldt function that also turns out to be quite useful is ")#metadata(none) <tao-92829e91fb11026ba175>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\Lambda(n) \\approx \\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\frac{\\mu(q)}{\\phi(q)} e( \\frac{an}{q} )")]]

#linebreak()#text(" ")#text(" for some ")#mi("{Q}")#text(" that is not too large compared to ")#mi("{N}")#text(". The methods used to establish Theorem ")#link(<tao-88ba1c4700c3e4b3c697>)[#text("8")]#text(" can also establish a Fourier approximation that makes ")#link(<tao-92829e91fb11026ba175>)[#text("(8)")]#text(" precise, and which can yield an alternate proof of Vinogradov’s theorem; this will be done below the fold.")#linebreak()#text(" The approximation ")#link(<tao-92829e91fb11026ba175>)[#text("(8)")]#text(" can be written in a way that makes it more similar to ")#link(<tao-81fd67d02f679b818a4d>)[#text("(7)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that the right-hand side of ")#link(<tao-92829e91fb11026ba175>)[#text("(8)")]#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq Q: d|n} \\mu(d) \\rho_d")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\rho_d := \\frac{d}{\\phi(d)} \\sum_{m \\leq Q/d: (m,d)=1} \\frac{\\mu^2(m)}{\\phi(m)}.")]]

#text("Then, show the inequalities")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq Q/d} \\frac{\\mu^2(m)}{\\phi(m)} \\leq \\rho_d \\leq \\sum_{m \\leq Q} \\frac{\\mu^2(m)}{\\phi(m)}")]]

#text("and conclude that")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{Q}{d} - O(1) \\leq \\rho_d \\leq \\log Q + O(1).")]]

#text("(")#emph[#text("Hint:")]#text(" for the latter estimate, use Theorem 27 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".)")
]

#text("The coefficients ")#mi("{\\rho_d}")#text(" in the above exercise are quite similar to optimised Selberg sieve coefficients (see Section 2 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(").")

#text("Another approximation to ")#mi("{\\Lambda}")#text(", related to the modified Cramér random model (see Model 10 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") is ")#metadata(none) <tao-a5831008ce901d5c7b8b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\Lambda(n) \\approx \\frac{W}{\\phi(W)} 1_{(n,W)=1}")]]

#linebreak()#text(" ")#text(" where ")#mi("{W := \\prod_{p \\leq w} p}")#text(" and ")#mi("{w}")#text(" is a slowly growing function of ")#mi("{N}")#text(" (e.g. ")#mi("{w = \\log\\log N}")#text("); a closely related approximation is ")#metadata(none) <tao-95832737f103784e2576>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{\\phi(W)}{W} \\Lambda(Wn+b) \\approx 1")]]

#text("for ")#mi("{W,w}")#text(" as above and ")#mi("{1 \\leq b \\leq W}")#text(" coprime to ")#mi("{W}")#text(". These approximations (closely related to a device known as the “")#mi("{W}")#text("-trick”) are not as quantitatively accurate as the previous approximations, but can still suffice to establish Vinogradov’s theorem, and also to count many other linear patterns in the primes or subsets of the primes (particularly if one injects some additional tools from additive combinatorics, and specifically the inverse conjecture for the Gowers uniformity norms); see ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("this paper of Ben Green and myself")]#text(" for more discussion (and this ")#link("http://www.ams.org/mathscinet-getitem?mr=3165421")[#text("more recent paper of Shao")]#text(" for an analysis of this approach in the context of Vinogradov-type theorems). The following exercise expresses the approximation ")#link(<tao-a5831008ce901d5c7b8b>)[#text("(9)")]#text(" in a form similar to the previous approximation ")#link(<tao-92829e91fb11026ba175>)[#text("(8)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" With ")#mi("{W}")#text(" as above, show that")

#align(center)[#tao-fit-display[#mitex("\\frac{W}{\\phi(W)} 1_{(n,W)=1} = \\sum_{q|W} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\frac{\\mu(q)}{\\phi(q)} e( \\frac{an}{q} )")]]

#text("for all natural numbers ")#mi("{n}")#text(".")
]

#metadata(none) <tao-469bed43e9a7413e9e59>

#heading(level: 1)[#strong[#text(" — 1. Exponential sums over primes: the minor arc case — ")]]

#text("We begin by developing some simple rigorous instances of the following general heuristic principle (cf. Section 3 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Principle 11 (Equidistribution principle)")]#text(" ")#metadata(none) <tao-0551ffc77d5f3a5d68f2>#text(" An exponential sum (such as a linear sum ")#mi("{\\sum_n e(f(n))}")#text(" or a bilinear sum ")#mi("{\\sum_n \\sum_m a_n b_m e(f(n,m))}")#text(" involving a “structured” phase function ")#mi("{f}")#text(" should exhibit some non-trivial cancellation, unless there is an “obvious” algebraic reason why such cancellation may not occur (e.g. ")#mi("{f}")#text(" is approximately periodic with small period, or ")#mi("{f(n,m)}")#text(" approximately decouples into a sum ")#mi("{g(n)+h(m)}")#text(").")
]

#text("There are some quite sophisticated versions of this principle in the literature, such as ")#link("http://en.wikipedia.org/wiki/Ratner%27s_theorems")[#text("Ratner’s theorems")]#text(" on equidistribution of unipotent flows, discussed in ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("this previous blog post")]#text(". There are yet further precise instances of this principle which are conjectured to be true, but for which this remains unproven (e.g. regarding incomplete Weil sums in finite fields). Here, though, we will focus only on the simplest manifestations of this principle, in which ")#mi("{f}")#text(" is a linear or bilinear phase. Rigorous versions of this special case of the above principle will be very useful in estimating exponential sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) e(\\theta n)")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) e(\\theta n)")]]

#text("in “minor arc” situations in which ")#mi("{\\theta}")#text(" is not too close to a rational number ")#mi("{a/q}")#text(" of small denominator. The remaining “major arc” case when ")#mi("{\\theta}")#text(" is close to such a rational number ")#mi("{a/q}")#text(" has to be handled by the complementary methods of multiplicative number theory, which we turn to later in this section.")#linebreak()#text(" For pedagogical reasons we shall develop versions of this principle that are in contrapositive form, starting with a hypothesis that a significant bias in an exponential sum is present, and deducing algebraic structure as a consequence. This leads to estimates that are not fully optimal from a quantitative viewpoint, but I believe they give a good qualitative illustration of the phenomena being exploited here.")

#text("We begin with the simplest instance of Principle ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("11")]#text(", namely regarding unweighted linear sums of linear phases:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12")]#text(" ")#metadata(none) <tao-525eca1d5089dbdcbb67>#text(" Let ")#mi("{I \\subset {\\bf Z}}")#text(" be an interval of length at most ")#mi("{N}")#text(" for some ")#mi("{N \\geq 1}")#text(", let ")#mi("{\\theta \\in{\\bf R}/{\\bf Z}}")#text(", and let ")#mi("{\\delta > 0}")#text(".")

#list(
[#text("(i) If")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in I} e(\\theta n)\\right| \\geq \\delta N,", block: true)]]

#text("Then ")#tao-math("{\\left\\|\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta N}}", block: false)#text(", where ")#tao-math("{\\left\\|\\theta\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" denotes the distance from (any representative of) ")#mi("{\\theta}")#text(" to the nearest integer.")],
[#text("(ii) More generally, if")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in I} f(n) e(\\theta n)\\right| > \\delta N \\sup_{n \\in I} \\left|f(n)\\right|", block: true)]]

#text("for some monotone function ")#mi("{f: I \\rightarrow {\\bf R}}")#text(", then ")#tao-math("{\\left\\|\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta N}}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" From the geometric series formula we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in I} e(\\theta n)\\right| \\leq \\frac{2}{\\left|e(\\theta)-1\\right|} \\ll \\frac{1}{\\left\\|\\theta\\right\\|_{{\\bf R}/{\\bf Z}}}", block: true)]]

#text("and the claim (i) follows. To prove (ii), we write ")#mi("{I = \\{a,\\dots,b\\}}")#text(" and observe from summation by parts that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} f(n) e(\\theta n) = f(a) \\sum_{n \\in I} e(\\theta n) + \\sum_{m = a+1}^b (f(m)-f(m-1)) \\sum_{n=m}^b e(\\theta n)")]]

#text("while from monotonicity we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f(a)\\right|+ \\sum_{m = a+1}^b \\left|f(m)-f(m-1)\\right| \\leq 2 \\sup_{n \\in I} \\left|f(n)\\right|", block: true)]]

#text("and the claim then follows from (i) and the pigeonhole principle. ")#mi("\\Box")#linebreak()#text(" Now we move to bilinear sums. We first need an elementary lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13 (Vinogradov lemma)")]#text(" ")#metadata(none) <tao-f734ad4e842854d4f5c1>#text(" Let ")#mi("{I \\subset {\\bf Z}}")#text(" be an interval of length at most ")#mi("{N}")#text(" for some ")#mi("{N \\geq 1}")#text(", and let ")#mi("{\\theta \\in{\\bf R}/{\\bf Z}}")#text(" be such that ")#tao-math("{\\left\\|n\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" for at least ")#mi("{\\delta N}")#text(" values of ")#mi("{n \\in I}")#text(", for some ")#mi("{0 < \\varepsilon, \\delta < 1}")#text(". Then either")

#align(center)[#tao-fit-display[#mitex("N < \\frac{2}{\\delta}")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\varepsilon > 10^{-2} \\delta")]]

#text("or else there is a natural number ")#mi("{q \\leq 2/\\delta}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\varepsilon}{\\delta N}.", block: true)]]
]

#text("One can obtain somewhat sharper estimates here by using the classical theory of continued fractions and Bohr sets, as in ")#link("https://terrytao.wordpress.com/2012/01/03/continued-fractions-bohr-sets-and-the-littlewood-conjecture/")[#text("this previous blog post")]#text(", but we will not need these refinements here.")

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{N \\geq \\frac{2}{\\delta}}")#text(" and ")#mi("{\\varepsilon \\leq 10^{-2} \\delta}")#text(", since we are done otherwise. Then there are at least two ")#mi("{n \\in I}")#text(" with ")#tao-math("{\\left\\|n \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(", and by the pigeonhole principle we can find ")#mi("{n_1 < n_2}")#text(" in ")#mi("{I}")#text(" with ")#tao-math("{\\left\\|n_1 \\theta \\right\\|_{{\\bf R}/{\\bf Z}}, \\left\\|n_2 \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" and ")#mi("{n_2-n_1 \\leq \\frac{2}{\\delta}}")#text(". By the triangle inequality, we conclude that there exists at least one natural number ")#mi("{q \\leq \\frac{2}{\\delta}}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq 2\\varepsilon.", block: true)]]

#text("We take ")#mi("{q}")#text(" to be minimal amongst all such natural numbers, then we see that there exists ")#mi("{a}")#text(" coprime to ")#mi("{q}")#text(" and ")#tao-math("{\\left|\\kappa\\right| \\leq 2\\varepsilon}", block: false)#text(" such that ")#metadata(none) <tao-8ed3f6ad685b959ead70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\theta = \\frac{a}{q} + \\frac{\\kappa}{q}.")]]

#linebreak()#text(" If ")#mi("{\\kappa=0}")#text(" then we are done, so suppose that ")#mi("{\\kappa \\neq 0}")#text(". Suppose that ")#mi("{n < m}")#text(" are elements of ")#mi("{I}")#text(" such that ")#tao-math("{\\left\\|n\\theta \\right\\|_{{\\bf R}/{\\bf Z}}, \\left\\|m\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" and ")#mi("{m-n \\leq \\frac{1}{10 \\kappa}}")#text(". Writing ")#mi("{m-n = qk + r}")#text(" for some ")#mi("{0 \\leq r < q}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (m-n) \\theta \\right\\|_{{\\bf R}/{\\bf Z}} = \\left\\| \\frac{ra}{q} + (m-n) \\frac{\\kappa}{q} \\right\\|_{{\\bf R}/{\\bf Z}} \\leq 2\\varepsilon.", block: true)]]

#text("By hypothesis, ")#mi("{(m-n) \\frac{\\kappa}{q} \\leq \\frac{1}{10 q}}")#text("; note that as ")#mi("{q \\leq 2/\\delta}")#text(" and ")#mi("{\\varepsilon \\leq 10^{-2} \\delta}")#text(" we also have ")#mi("{\\varepsilon \\leq \\frac{1}{10q}}")#text(". This implies that ")#tao-math("{\\left\\| \\frac{ra}{q} \\right\\|_{{\\bf R}/{\\bf Z}} < \\frac{1}{q}}", block: false)#text(" and thus ")#mi("{r=0}")#text(". We then have")

#align(center)[#tao-fit-display[#tao-math("\\left|k \\kappa\\right| \\leq 2 \\varepsilon.", block: true)]]

#text("We conclude that for fixed ")#mi("{n \\in I}")#text(" with ")#tao-math("{\\left\\|n\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(", there are at most ")#tao-math("{\\frac{2\\varepsilon}{\\left|\\kappa\\right|}}", block: false)#text(" elements ")#mi("{m}")#text(" of ")#tao-math("{[n, n + \\frac{1}{10 \\left|\\kappa\\right|}]}", block: false)#text(" such that ")#tao-math("{\\left\\|m\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(". Iterating this with a greedy algorithm, we see that the number of ")#mi("{n \\in I}")#text(" with ")#tao-math("{\\left\\|n\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon}", block: false)#text(" is at most ")#tao-math("{(\\frac{N}{1/10\\left|\\kappa\\right|} + 1) 2\\varepsilon/\\left|\\kappa\\right|}", block: false)#text("; since ")#mi("{\\varepsilon < 10^{-2} \\delta}")#text(", this implies that")

#align(center)[#tao-fit-display[#mitex("\\delta N \\ll 2 \\varepsilon / \\kappa")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now we can control bilinear sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\alpha*\\beta(n) e(\\theta n) = \\sum_{m,n: mn\\in I} \\alpha(m) \\beta(n) e(\\theta nm).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Bilinear sum estimate)")]#text(" ")#metadata(none) <tao-623210167553939c87ed>#text(" Let ")#mi("{M, N \\geq 1}")#text(", let ")#mi("{I \\subset {\\bf Z}}")#text(" be an interval, and let ")#mi("{a: {\\bf N} \\rightarrow {\\bf C}}")#text(", ")#mi("{\\beta: {\\bf N} \\rightarrow {\\bf C}}")#text(" be sequences supported on ")#mi("{[1,M]}")#text(" and ")#mi("{[1,N]}")#text(" respectively. Let ")#mi("{\\delta > 0}")#text(" and ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(".")

#list(
[#text("(i) (Type I estimate) If ")#mi("{\\beta}")#text(" is real-valued and monotone and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m,n: mn \\in I} \\alpha(m) \\beta(n) e( \\theta nm )\\right| > \\delta MN \\sup_m \\left|\\alpha(m)\\right| \\sup_n \\left|\\beta(n)\\right|", block: true)]]

#text("then either ")#mi("{N \\ll \\delta^{-2}}")#text(", or there exists ")#mi("{q \\ll 1/\\delta}")#text(" such that ")#tao-math("{\\left\\|q\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta^2 NM}}", block: false)#text(".")],
[#text("(ii) (Type II estimate) If")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m,n: mn \\in I} \\alpha(m) \\beta(n) e( \\theta nm )\\right| > \\delta (MN)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\times (\\sum_m \\left|\\alpha(m)\\right|^2)^{1/2} (\\sum_n \\left|\\beta(n)\\right|^2)^{1/2}", block: true)]]

#text("then either ")#mi("{\\min(M,N) \\ll \\delta^{-4}}")#text(", or there exists ")#mi("{q \\ll 1/\\delta^2}")#text(" such that ")#tao-math("{\\left\\|q\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta^4 NM}}", block: false)#text(".")]
)
]

#text("The hypotheses of (i) and (ii) should be compared with the trivial bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m,n: mn \\in I} \\alpha(m) \\beta(n) e( \\theta nm )\\right| \\leq MN \\sup_m \\left|\\alpha(m)\\right| \\sup_n \\left|\\beta(n)\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m,n: mn \\in I} \\alpha(m) \\beta(n) e( \\theta nm )\\right| \\leq (MN)^{1/2} (\\sum_m \\left|\\alpha(m)\\right|^2)^{1/2} (\\sum_n \\left|\\beta(n)\\right|^2)^{1/2}", block: true)]]

#text("arising from the triangle inequality and the Cauchy-Schwarz inequality.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We begin with (i). By the triangle inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m \\leq M} \\left|\\sum_{n: mn \\in I} \\beta(n) e( \\theta nm )\\right| > \\delta MN \\sup_n \\left|\\beta(n)\\right|.", block: true)]]

#text("The summand in ")#mi("{m}")#text(" is bounded by ")#tao-math("{N \\sup_n \\left|\\beta(n)\\right|}", block: false)#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n: mn \\in I} \\beta(n) e( \\theta nm )\\right| > \\frac{\\delta}{2} N \\sup_n \\left|\\beta(n)\\right|", block: true)]]

#text("for at least ")#mi("{\\frac{\\delta}{2} M}")#text(" choices of ")#mi("{m \\leq M}")#text(" (this is easiest to see by arguing by contradiction). Applying Lemma ")#link(<tao-525eca1d5089dbdcbb67>)[#text("12")]#text("(ii), we conclude that ")#metadata(none) <tao-16edd4b84c3ada6a373c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| \\theta m \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta N}", block: true)]]

#text("for at least ")#mi("{\\frac{\\delta}{2} M}")#text(" choices of ")#mi("{m \\leq M}")#text(". Applying Lemma ")#link(<tao-f734ad4e842854d4f5c1>)[#text("13")]#text(", we conclude that one of ")#mi("{M \\ll 1/\\delta}")#text(", ")#mi("{\\frac{1}{\\delta N} \\gg \\delta}")#text(", or there exists a natural number ")#mi("{q \\ll 1/\\delta}")#text(" such that ")#tao-math("{\\left\\|q\\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta^2 NM}}", block: false)#text(". This gives (i) except when ")#mi("{M \\ll 1/\\delta}")#text(". In this case, we return to ")#link(<tao-16edd4b84c3ada6a373c>)[#text("(12)")]#text(", which holds for at least one natural number ")#mi("{m \\leq M \\ll 1/\\delta}")#text(", and set ")#mi("{q := m}")#text(".")#linebreak()#text(" Now we prove (ii). By the triangle inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_m \\left|\\alpha(m)\\right| \\left|\\sum_{n: mn \\in I} \\beta(n) e( \\theta nm )\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("> \\delta (MN)^{1/2} (\\sum_m \\left|\\alpha(m)\\right|^2)^{1/2} (\\sum_n \\left|\\beta(n)\\right|^2)^{1/2}", block: true)]]

#text("and hence by the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m\\leq M} \\left|\\sum_{n: mn \\in I} \\beta(n) e( \\theta nm )\\right|^2 > \\delta^2 MN \\sum_n \\left|\\beta(n)\\right|^2.", block: true)]]

#text("The left-hand side expands as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n,n^{\\prime} \\leq N} \\beta(n) \\overline{\\beta(n^{\\prime})} \\sum_{m \\leq M: mn, mn^{\\prime} \\in I} e(\\theta(n-n^{\\prime}) m);")]]

#text("from the triangle inequality, the estimate ")#tao-math("{\\beta(n) \\overline{\\beta(n^{\\prime})} \\ll \\left|\\beta(n)\\right|^2 + \\left|\\beta(n^{\\prime})\\right|^2}", block: false)#text(" and symmetry we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq N} \\left|\\sum_{m \\leq M: mn, mn^{\\prime} \\in I} e(\\theta(n-n^{\\prime}) m)\\right| \\gg \\delta^2 M N", block: true)]]

#text("for at least one choice of ")#mi("{n^{\\prime} \\leq N}")#text(". Fix this ")#mi("{n^{\\prime}}")#text(". Since ")#tao-math("{\\left|\\sum_{m \\leq M: mn, mn^{\\prime} \\in I} e(\\theta(n-n^{\\prime}) m)\\right| \\leq M}", block: false)#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m \\leq M: mn, mn^{\\prime} \\in I} e(\\theta(n-n^{\\prime}) m)\\right| \\gg \\delta^2 M", block: true)]]

#text("for ")#mi("{\\gg \\delta^2 N}")#text(" choices of ")#mi("{n \\leq N}")#text(". Applying Lemma ")#link(<tao-525eca1d5089dbdcbb67>)[#text("12")]#text("(i), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\theta(n-n^{\\prime}) \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{1}{\\delta^2 M }", block: true)]]

#text("for ")#mi("{\\gg \\delta^2 N}")#text(" choices of ")#mi("{n \\leq N}")#text(". Applying Lemma ")#link(<tao-f734ad4e842854d4f5c1>)[#text("13")]#text(", we obtain the claim. ")#mi("\\Box")#linebreak()#text(" The following exercise demonstrates the sharpness of the above theorem, at least with regards to the bound on ")#mi("{q}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{\\frac{a}{q}}")#text(" be a rational number with ")#mi("{(a,q)=1}")#text(", let ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(", and let ")#mi("{M, N}")#text(" be multiples of ")#mi("{q}")#text(".")

#list(
[#text("(i) If ")#tao-math("{\\left\\|\\theta - \\frac{a}{q}\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{c}{qNM}}", block: false)#text(" for a sufficiently small absolute constant ")#mi("{c>0}")#text(", show that ")#tao-math("{\\left|\\sum_{n \\leq N} \\sum_{m \\leq M} e( \\theta nm ) \\right| \\gg \\frac{1}{q} NM}", block: false)#text(".")],
[#text("(ii) If ")#mi("{a}")#text(" is even, and ")#tao-math("{\\left\\|\\theta - \\frac{a}{q}\\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\frac{c}{\\sqrt{q}NM}}", block: false)#text(" for a sufficiently small absolute constant ")#mi("{c>0}")#text(", show that ")#tao-math("{\\left|\\sum_{n \\leq N} \\sum_{m \\leq M} e( a n^2/2q) e(-a m^2/2q) e( \\theta nm ) \\right| \\gg \\frac{1}{\\sqrt{q}} NM}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Quantitative Weyl exponential sum estimates)")]#text(" ")#metadata(none) <tao-4968d0cf3b24d26d1d37>#text(" Let ")#mi("{P(n) = \\alpha_d n^d + \\dots + \\alpha_1 n + \\alpha_0}")#text(" be a polynomial with coefficients ")#mi("{\\alpha_0,\\dots,\\alpha_d \\in {\\bf R}/{\\bf Z}}")#text(" for some ")#mi("{d \\geq 1}")#text(", let ")#mi("{N \\geq 1}")#text(", and let ")#mi("{\\delta > 0}")#text(".")

#list(
[#text("(i) Suppose that ")#tao-math("{\\left|\\sum_{n \\in I} e(P(n))\\right| \\geq \\delta N}", block: false)#text(" for some interval ")#mi("{I}")#text(" of length at most ")#mi("{N}")#text(". Show that there exists a natural number ")#mi("{q \\ll_d \\delta^{-O_d(1)}}")#text(" such that ")#tao-math("{\\left\\| q\\alpha_d \\right\\|_{{\\bf R}/{\\bf Z}} \\ll_d \\delta^{-O_d(1)} / N^d}", block: false)#text(". (")#emph[#text("Hint:")]#text(" induct on ")#mi("{d}")#text(" and use the van der Corput inequality (Proposition 7 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(").")],
[#text("(ii) Suppose that ")#tao-math("{\\left|\\sum_{n \\in I} e(P(n))\\right| \\geq \\delta N}", block: false)#text(" for some interval ")#mi("{I}")#text(" contained in ")#mi("{[1,N]}")#text(". Show that there exists a natural number ")#mi("{q \\ll_d \\delta^{-O_d(1)}}")#text(" such that ")#tao-math("{\\left\\| q\\alpha_j \\right\\|_{{\\bf R}/{\\bf Z}} \\ll_d \\delta^{-O_d(1)} / N^j}", block: false)#text(" for all ")#mi("{0 \\leq j \\leq d}")#text(" (note this claim is trivial for ")#mi("{j=0}")#text("). (")#emph[#text("Hint:")]#text(" use downwards induction on ")#mi("{j}")#text(", adjusting ")#mi("{q}")#text(" as one goes along, and split up ")#mi("{I}")#text(" into somewhat short arithmetic progressions of various spacings ")#mi("{q}")#text(" in order to turn the top degree components of ")#mi("{P(n)}")#text(" into essentially constant phases.)")],
[#text("(iii) Use these bounds to give an alternate proof of Exercise 8 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(".")]
)
]

#text("We remark that sharper versions of the above exercise are available if one uses the Vinogradov mean value theorem from ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text("; see Theorem 1.6 of ")#link("http://www.maths.bris.ac.uk/~matdw/ecvin20110711.pdf")[#text("this paper of Wooley")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Quantitative multidimensional Weyl exponential sum estimates)")]#text(" Let ")#mi("{P(n_1,\\dots,n_k) = \\sum_{i_1+\\dots+i_k \\leq d} \\alpha_{i_1,\\dots,i_k} n_1^{i_1} \\dots n_k^{i_k}}")#text(" be a polynomial in ")#mi("{k}")#text(" variables with coefficients ")#mi("{\\alpha_{i_1,\\dots,i_k} \\in {\\bf R}/{\\bf Z}}")#text(" for some ")#mi("{d \\geq 1}")#text(". Let ")#mi("{N_1,\\dots,N_k \\geq 1}")#text(" and ")#mi("{\\delta > 0}")#text(". Suppose that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n_1 \\leq N_1} \\dots \\sum_{n_k \\leq N_k} e( P(n_1,\\dots,n_k) )\\right| \\geq \\delta N_1 \\dots N_k.", block: true)]]

#text("Show that either one has ")#mi("{N_j \\ll_{d,k} \\delta^{-O_{d,k}(1)}}")#text(" for some ")#mi("{j=1,\\dots,k}")#text(", or else there exists a natural number ")#mi("{q \\ll_{d,k} \\delta^{-O_{d,k}(1)}}")#text(" such that ")#tao-math("{\\left\\|q \\alpha_{i_1,\\dots,i_k} \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\frac{\\delta^{-O_{d,k}(1)}}{N_1^{i_1} \\dots N_k^{i_k}}}", block: false)#text(" for all ")#mi("{i_1,\\dots,i_k}")#text(". (Note: this is a rather tricky exercise, and is only recommended for students who have mastered the arguments needed to solve the one-dimensional version of this exercise from Exercise ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("16")]#text(". A solution is given in ")#link("https://terrytao.wordpress.com/2015/08/06/equidistribution-for-multidimensional-polynomial-phases/")[#text("this blog post")]#text(".)")
]

#text("Recall that in the proof of the Bombieri-Vinogradov theorem (see ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text("), sums such as ")#mi("{\\sum_n \\Lambda(n) \\chi(n)}")#text(" or ")#mi("{\\sum_n \\mu(n) \\chi(n)}")#text(" were handled by using combinatorial identities such as Vaughan’s identity to split ")#mi("{\\Lambda}")#text(" or ")#mi("{\\mu}")#text(" into combinations of Type I or Type II convolutions. The same strategy can be applied here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 18 (Minor arc exponential sums are small)")]#text(" ")#metadata(none) <tao-cabd786ac52d8cfc81b0>#text(" Let ")#mi("{x \\geq 2}")#text(", ")#mi("{\\delta > 0}")#text(", and ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(", and let ")#mi("{I}")#text(" be an interval in ")#mi("{[1,x]}")#text(". Suppose that either ")#metadata(none) <tao-d1a4f9d25f0725d131dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|\\sum_{n\\in I} \\Lambda(n) e(\\theta n)\\right| \\geq \\delta x", block: true)]]

#text("or ")#metadata(none) <tao-5468b428a6b190fd0eb8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left|\\sum_{n\\in I} \\mu(n) e(\\theta n)\\right| \\geq \\delta x.", block: true)]]

#text("Then either ")#mi("{x \\ll \\delta^{-O(1)}}")#text(", or there exists a natural number ")#mi("{q \\ll \\delta^{-2} \\log^{O(1)} x}")#text(" such that ")#tao-math("{\\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-5} \\frac{\\log^{O(1)} x}{x}}", block: false)#text(".")
]

#text("The exponent in the bound ")#mi("{x \\ll \\delta^{-O(1)}}")#text(" can be made explicit (and fairly small) if desired, but this exponent is not of critical importance in applications. The losses of ")#mi("{\\log x}")#text(" in this proposition are undesirable (though affordable, for the purposes of proving results such as Vinogradov’s theorem); these losses have been reduced over the years, and finally eliminated entirely in the ")#link("http://arxiv.org/abs/1501.05438")[#text("recent work of Helfgott")]#text(".")

#emph[#text("Proof:")]#text(" We will prove this under the hypothesis ")#link(<tao-d1a4f9d25f0725d131dc>)[#text("(13)")]#text("; the argument for ")#link(<tao-5468b428a6b190fd0eb8>)[#text("(14)")]#text(" is similar and is left as an exercise. By removing the portion of ")#mi("{I}")#text(" in ")#mi("{[0, \\delta x/2]}")#text(", and shrinking ")#mi("{\\delta}")#text(" slightly, we may assume without loss of generality that ")#mi("{I \\subset [\\delta x, x]}")#text(".")

#text("We recall the Vaughan identity")

#align(center)[#tao-fit-display[#mitex("\\Lambda = \\Lambda_{\\leq V} + \\mu_{\\leq U} * L - \\mu_{\\leq U} * \\Lambda_{\\leq V} * 1 + \\mu_{>U} * \\Lambda_{>V} * 1")]]

#text("valid for any ")#mi("{U,V > 1}")#text("; see Lemma 18 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(". We select ")#mi("{U=V=x^{1/3}}")#text(". By the triangle inequality, one of the assertions ")#metadata(none) <tao-fefe4204ef3fa37d9477>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\sum_{n\\in I} \\Lambda_{\\leq V}(n) e(\\theta n)\\right| \\gg \\delta x", block: true)]]

#metadata(none) <tao-4986db3f9c72acdeb622>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\sum_{n\\in I} \\mu_{\\leq U} * L(n) e(\\theta n)\\right| \\gg \\delta x", block: true)]]

#metadata(none) <tao-6d0ca4af9f86967771bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|\\sum_{n\\in I} \\mu_{\\leq U} * \\Lambda_{\\leq V} * 1(n) e(\\theta n)\\right| \\gg \\delta x", block: true)]]

#metadata(none) <tao-a35a3980a28234682ccf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left|\\sum_{n\\in I} \\mu_{>U} * \\Lambda_{>V} * 1(n) e(\\theta n)\\right| \\gg \\delta x", block: true)]]

#text("must hold. If ")#link(<tao-fefe4204ef3fa37d9477>)[#text("(15)")]#text(" holds, then ")#mi("{V \\gg \\delta x}")#text(", from which we easily conclude that ")#mi("{x \\ll \\delta^{-O(1)}}")#text(". Now suppose that ")#link(<tao-4986db3f9c72acdeb622>)[#text("(16)")]#text(" holds. By dyadic decomposition, we then have ")#metadata(none) <tao-6860bc89219d80f8140f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left|\\sum_{n\\in I} \\alpha * \\beta(n) e(\\theta n)\\right| \\gg \\frac{\\delta x}{\\log^{O(1)} x}", block: true)]]

#text("where ")#mi("{\\alpha, \\beta}")#text(" are restrictions of ")#mi("{\\mu_{\\leq U}}")#text(", ")#mi("{L}")#text(" to dyadic intervals ")#mi("{[M,2M]}")#text(", ")#mi("{[N,2N]}")#text(" respectively. Note that the location of ")#mi("{I}")#text(" then forces ")#mi("{\\delta x \\ll MN \\ll x}")#text(", and the support of ")#mi("{\\mu_{\\leq U}}")#text(" forces ")#mi("{M \\ll U}")#text(", so that ")#mi("{N \\gg x/U = x^{2/3}}")#text(". Applying Theorem ")#link(<tao-623210167553939c87ed>)[#text("14")]#text("(i), we conclude that either ")#mi("{N \\ll \\delta^{-2} \\log^{O(1)} x}")#text(" (and hence ")#mi("{x \\ll \\delta^{-O(1)}}")#text("), or else there is ")#mi("{q \\ll \\delta^{-2} \\log^{O(1)} x}")#text(" such that ")#tao-math("{\\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-3} \\frac{\\log^{O(1)} x}{x}}", block: false)#text(", and we are done.")#linebreak()#text(" Similarly, if ")#link(<tao-6d0ca4af9f86967771bb>)[#text("(17)")]#text(" holds, we again apply dyadic decomposition to arrive at ")#link(<tao-6860bc89219d80f8140f>)[#text("(19)")]#text(", where ")#mi("{\\alpha,\\beta}")#text(" are now restrictions of ")#mi("{\\mu_{\\leq U} * \\Lambda_{\\leq V}}")#text(" and ")#mi("{1}")#text(" to ")#mi("{[M,2M]}")#text(" and ")#mi("{[N,2N]}")#text(". As before, we have ")#mi("{\\delta x \\ll MN \\ll x}")#text(", and now ")#mi("{M \\ll UV}")#text(" and so ")#mi("{N \\gg x^{1/3}}")#text(". Note from the identity ")#mi("{\\sum_{d|n} \\Lambda(d)=\\log n}")#text(" that ")#mi("{\\alpha}")#text(" is bounded pointwise by ")#mi("{\\log x}")#text(". Repeating the previous argument then gives one of the required conclusions.")

#text("Finally, we consider the “Type II” scenario in which ")#link(<tao-a35a3980a28234682ccf>)[#text("(18)")]#text(" holds. We again dyadically decompose and arrive at ")#link(<tao-6860bc89219d80f8140f>)[#text("(19)")]#text(", where ")#mi("{\\alpha}")#text(" and ")#mi("{\\beta}")#text(" are now the restrictions of ")#mi("{\\mu_{>U}}")#text(" and ")#mi("{\\Lambda_{>V}*1}")#text(" (say) to ")#mi("{[M,2M]}")#text(" and ")#mi("{[N,2N]}")#text(", so that ")#mi("{\\delta x \\ll MN \\ll x}")#text(", ")#mi("{M \\gg U}")#text(", and ")#mi("{N \\gg V}")#text(". As before we can bound ")#mi("{\\beta}")#text(" pointwise by ")#mi("{\\log x}")#text(". Applying Theorem ")#link(<tao-623210167553939c87ed>)[#text("14")]#text("(ii), we conclude that either ")#mi("{\\min(M,N) \\ll \\delta^{-4} \\log^{O(1)} x}")#text(", or else there exists ")#mi("{q \\ll \\delta^{-2} \\log^{O(1)} x}")#text(" such that ")#tao-math("{\\left\\|q\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\ll \\delta^{-5} \\frac{\\log^{O(1)} x}{x}}", block: false)#text(", and we again obtain one of the desired conclusions. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Finish the proof of Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" by treating the case when ")#link(<tao-5468b428a6b190fd0eb8>)[#text("(14)")]#text(" occurs.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Establish a version of Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" in which ")#link(<tao-d1a4f9d25f0725d131dc>)[#text("(13)")]#text(" or ")#link(<tao-5468b428a6b190fd0eb8>)[#text("(14)")]#text(" are replaced with")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{p \\leq x} e( \\theta p )\\right| \\gg \\delta \\frac{x}{\\log x}.", block: true)]]
]

#heading(level: 1)[#strong[#text(" — 2. Exponential sums over primes: the major arc case — ")]]

#text("Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" provides guarantees that exponential sums such as ")#mi("{\\sum_{n \\leq x} \\Lambda(n) e(\\theta n)}")#text(" are much smaller than ")#mi("{x}")#text(", unless ")#mi("{x}")#text(" is itself small, or if ")#mi("{\\theta}")#text(" is close to a rational number ")#mi("{a/q}")#text(" of small denominator. We now analyse this latter case. In contrast with the minor arc analysis, the implied constants will usually be ineffective.")

#text("The situation is simplest in the case of the Möbius function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 21")]#text(" ")#metadata(none) <tao-192fcbbcd023e8417a21>#text(" Let ")#mi("{I}")#text(" be an interval in ")#mi("{[1,x]}")#text(" for some ")#mi("{x \\geq 2}")#text(", and let ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(". Then for any ")#mi("{A>0}")#text(" and natural number ")#mi("{q}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\mu(n) e(\\theta n) \\ll_A (q + x \\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}}) x \\log^{-A} x.", block: true)]]

#text("The implied constants are ineffective.")
]

#emph[#text("Proof:")]#text(" By splitting into residue classes modulo ")#mi("{q}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I: n = a\\ (q)} \\mu(n) e(\\theta n) \\ll_A (1 + \\frac{x}{q} \\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}}) x \\log^{-A} x", block: true)]]

#text("for all ")#mi("{a = 0,\\dots,q-1}")#text(". Writing ")#mi("{n = qm+a}")#text(", and removing a factor of ")#mi("{e(a\\theta)}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m \\in {\\bf Z}: qm+a \\in I} \\mu(qm+a) e(\\xi m) \\ll_A (1 + \\frac{x}{q} \\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}}) x \\log^{-A} x", block: true)]]

#text("where ")#mi("{\\xi \\in {\\bf R}}")#text(" is the representative of ")#mi("{q\\theta}")#text(" that is closest to the origin, so that ")#tao-math("{\\left|\\xi\\right| = \\left\\|q\\theta\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(".")#linebreak()#text(" For all ")#mi("{m}")#text(" in the above sum, one has ")#mi("{0 \\leq m \\leq x/q}")#text(". From the fundamental theorem of calculus, one has ")#metadata(none) <tao-dfc1a1888f01d9476764>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("e(\\xi m) = 1 + 2\\pi i \\xi \\int_0^{x/q} e(\\xi t) 1_{m \\geq t}\\ dt")]]

#linebreak()#text(" ")#text(" and so by the triangle inequality it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\bf Z}: qm+a \\in I; m \\geq t} \\mu(qm+a) \\ll_A x \\log^{-A} x")]]

#text("for all ")#mi("{0 \\leq t \\leq x/q}")#text(". But this follows from the Siegel-Walfisz theorem for the Möbius function (Exercise 66 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("). ")#mi("\\Box")#linebreak()#text(" Arguing as in the proof of Lemma ")#link(<tao-525eca1d5089dbdcbb67>)[#text("12")]#text("(ii), we also obtain the corollary ")#metadata(none) <tao-d7de34b17b4691aa77ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{n \\in I} \\mu(n) e(\\theta n) f(n) \\ll_A (q + x \\left\\| q \\theta \\right\\|_{{\\bf R}/{\\bf Z}}) x \\log^{-A} x \\sup_{n \\in I} \\left|f(n)\\right|", block: true)]]

#linebreak()#text(" ")#text(" for any monotone function ")#mi("{f: I \\rightarrow {\\bf R}}")#text(", with ineffective constants.")#linebreak()#text(" Davenport’s theorem (Theorem ")#link(<tao-88ba1c4700c3e4b3c697>)[#text("8")]#text(") is now immediate from applying Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" with ")#mi("{\\delta := \\log^{-A} x}")#text(", followed by Proposition ")#link(<tao-192fcbbcd023e8417a21>)[#text("21")]#text(" (with ")#mi("{A}")#text(" replaced by a larger constant) to deal with the major arc case.")

#text("Now we turn to the analogous situation for the von Mangoldt function ")#mi("{\\Lambda}")#text(". Here we expect to have a non-trivial main term in the major arc case: for instance, the prime number theorem tells us that ")#mi("{\\sum_{n \\leq I} \\Lambda(n) e(\\theta n)}")#text(" should be approximately the length of ")#mi("{I}")#text(" when ")#mi("{\\theta=0}")#text(". There are several ways to describe the behaviour of ")#mi("{\\Lambda}")#text(". One way is to use the approximation")

#align(center)[#tao-fit-display[#mitex("\\Lambda^\\sharp_R(n) := - \\sum_{d \\leq R: d|n} \\mu(d) \\log d")]]

#text("discussed in the introduction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 22")]#text(" ")#metadata(none) <tao-e90dfa8b1e73941e209c>#text(" Let ")#mi("{x \\geq 2}")#text(" and let ")#mi("{R}")#text(" be such that ")#mi("{R \\geq x^\\varepsilon}")#text(". Then for any interval ")#mi("{I}")#text(" in ")#mi("{[1,x]}")#text(" and any ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(", one has ")#metadata(none) <tao-7d445240c97cb8b39b22>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) - \\sum_{n \\in I} \\Lambda^\\sharp_R(n) e(\\theta n) \\ll_{A,\\varepsilon} x \\log^{-A} x")]]

#text("for all ")#mi("{A>0}")#text(". The implied constants are ineffective.")
]

#emph[#text("Proof:")]#text(" As discussed in the introduction, we have")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) - \\Lambda^\\sharp_R(n) = - \\sum_{d>R: d|n} \\mu(d) \\log d")]]

#text("so the left-hand side of ")#link(<tao-7d445240c97cb8b39b22>)[#text("(22)")]#text(" can be rearranged as")

#align(center)[#tao-fit-display[#mitex("- \\sum_m \\sum_{d>R: dm \\in I} \\mu(d) \\log d e( m \\theta d).")]]

#text("Since ")#mi("{I \\subset [1,x]}")#text(", the inner sum vanishes unless ")#mi("{m \\leq x/R}")#text(". From Theorem ")#link(<tao-88ba1c4700c3e4b3c697>)[#text("8")]#text(" and summation by parts (or ")#link(<tao-d7de34b17b4691aa77ab>)[#text("(21)")]#text(" and Proposition ")#link(<tao-192fcbbcd023e8417a21>)[#text("21")]#text("), we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d>R: dm \\in I} \\mu(d) \\log d e( m \\theta d) \\ll_A \\frac{x}{m} \\log^{-A}(x/m) \\times \\log x;")]]

#text("since ")#mi("{m \\leq x/R}")#text(", we have ")#mi("{\\log^{-A}(x/m) \\ll_{A,\\varepsilon} \\log^{-A} x}")#text(", and the claim now follows from summing in ")#mi("{m}")#text(" (and increasing ")#mi("{A}")#text(" appropriately). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-1570eb5695612a47b307>#text(" Show that Proposition ")#link(<tao-e90dfa8b1e73941e209c>)[#text("22")]#text(" continues to hold if ")#mi("{\\Lambda^\\sharp_R}")#text(" is replaced by the function")

#align(center)[#tao-fit-display[#mitex("\\Lambda_R(n) := \\sum_{d \\leq R: d|n} \\mu(d) \\log \\frac{R}{d}")]]

#text("or more generally by")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{R,\\eta}(n) := \\log R \\sum_{d \\leq R: d|n} \\mu(d) \\eta( \\frac{\\log d}{\\log R} )")]]

#text("where ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a bounded function such that ")#mi("{\\eta(t) = 1-t}")#text(" for ")#mi("{0 \\leq t \\leq 1/2}")#text(" and ")#mi("{\\eta(t)=0}")#text(" for ")#mi("{t>1}")#text(". (")#emph[#text("Hint:")]#text(" use a suitable linear combination of the identities ")#mi("{\\Lambda = - \\mu L * 1}")#text(" and ")#mi("{\\Lambda = \\mu * L}")#text(".)")
]

#text("Alternatively, we can try to replicate the proof of Proposition ")#link(<tao-192fcbbcd023e8417a21>)[#text("21")]#text(" directly, keeping track of the main terms that are now present in the Siegel-Walfisz theorem. This gives a quite explicit approximation for ")#mi("{\\sum_{n \\in I} \\Lambda(n) e(\\theta n)}")#text(" in major arc cases:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24")]#text(" ")#metadata(none) <tao-c7dac63a93ebc854d4ee>#text(" Let ")#mi("{I}")#text(" be an interval in ")#mi("{[1,x]}")#text(" for some ")#mi("{x \\geq 2}")#text(", and let ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(" be of the form ")#mi("{\\theta = \\frac{a}{q} + \\frac{\\xi}{q}}")#text(", where ")#mi("{q \\geq 1}")#text(" is a natural number, ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(", and ")#mi("{\\xi \\in {\\bf R}}")#text(". Then for any ")#mi("{A>0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) - \\frac{\\mu(q)}{\\phi(q)} \\int_I e(\\frac{\\xi t}{q})\\ dt \\ll_A (q + x \\left|\\xi\\right|) x \\log^{-A} x.", block: true)]]

#text("The implied constants are ineffective.")
]

#emph[#text("Proof:")]#text(" We may assume that ")#tao-math("{\\left|\\xi\\right| \\leq \\frac{\\log^{A} x}{x}}", block: false)#text(" and ")#mi("{q \\leq \\log^A x}")#text(", as the claim follows from the triangle inequality and the prime number theorem otherwise. For similar reasons we can also assume that ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{A}")#text(".")

#text("As in the proof of Proposition ")#link(<tao-192fcbbcd023e8417a21>)[#text("21")]#text(", we decompose into residue classes mod ")#mi("{q}")#text(" to write")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) = \\sum_{b \\in {\\bf Z}/q{\\bf Z}} \\sum_{n \\in I: n = b\\ (q)} \\Lambda(n) e(\\theta n).")]]

#text("If ")#mi("{b}")#text(" is not coprime to ")#mi("{q}")#text(", then one easily verifies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I: n = b\\ (q)} \\Lambda(n) e(\\theta n) \\ll \\log^2 x")]]

#text("and the contribution of these cases is thus acceptable. Thus, up to negligible errors, we may restrict ")#mi("{b}")#text(" to be coprime to ")#mi("{q}")#text(". Writing ")#mi("{n = qm+b}")#text(", we thus may replace ")#mi("{\\sum_{n \\in I} \\Lambda(n) e(\\theta n)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{b \\in ({\\bf Z}/q{\\bf Z})^\\times} e(\\theta b) \\sum_{m: qm+b \\in I} \\Lambda(qm+b) e(\\xi m).")]]

#text("Applying ")#link(<tao-dfc1a1888f01d9476764>)[#text("(20)")]#text(", we can write")

#tao-aligned(keep: true)[


#tao-math("\\sum_{m: qm+b \\in I} \\Lambda(qm+b) e(\\xi m)  & = \\sum_{m: qm+b \\in I} \\Lambda(qm+b)", block: true)



#tao-math(" & + 2\\pi i \\xi \\int_0^{x/q} e(\\xi t) \\sum_{m: qm+b \\in I; m \\geq t} \\Lambda(qm+b)\\ dt.", block: true)
]

#text("Applying the Siegel-Walfisz theorem (Exercise 64 of Notes 2), we can replace ")#mi("{\\Lambda}")#text(" here by ")#mi("{\\frac{q}{\\phi(q)}}")#text(", up to an acceptable error. Applying ")#link(<tao-dfc1a1888f01d9476764>)[#text("(20)")]#text(" again, we have now replaced ")#mi("{\\sum_{n \\in I} \\Lambda(n) e(\\theta n)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{q}{\\phi(q)} \\sum_{b \\in ({\\bf Z}/q{\\bf Z})^\\times} e(\\theta b) \\sum_{m: qm+b \\in I} e(\\xi m),")]]

#text("which we can rewrite as")

#align(center)[#tao-fit-display[#mitex("\\frac{q}{\\phi(q)} \\sum_{n \\in I: (n,q)=1} e(\\theta n).")]]

#text("From Möbius inversion one has")

#align(center)[#tao-fit-display[#mitex("1_{(n,q)=1} = \\sum_{d|q} \\mu(d) 1_{d|n},")]]

#text("so we can rewrite the previous expression as")

#align(center)[#tao-fit-display[#mitex("\\frac{q}{\\phi(q)} \\sum_{d|q} \\mu(d) \\sum_{m: dm \\in I} e(d\\theta m).")]]

#text("For ")#mi("{d|q}")#text(" with ")#mi("{d < q}")#text(", we see from the hypotheses that ")#tao-math("{\\left\\|d\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\gg 1/q}", block: false)#text(", and so ")#mi("{\\sum_{m: dm \\in I} e(d\\theta m) \\ll q}")#text(" by Lemma ")#link(<tao-525eca1d5089dbdcbb67>)[#text("12")]#text("(i). The contribution of all ")#mi("{d<q}")#text(" is then ")#mi("{\\ll \\frac{q}{\\phi(q)} \\tau(q) q}")#text(", which is acceptable since ")#mi("{q \\leq \\log^A x}")#text(". So, up to acceptable errors, we may replace ")#mi("{\\sum_{n \\in I} \\Lambda(n) e(\\theta n)}")#text(" by ")#mi("{\\frac{q}{\\phi(q)} \\mu(q) \\sum_{m: qm \\in I} e(q\\theta m)}")#text(". We can write ")#mi("{e(q\\theta m)=e(\\xi m)}")#text(", and the claim now follows from Exercise 11 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" and a change of variables. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Assuming the generalised Riemann hypothesis, obtain the significantly stronger estimate")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) - \\frac{\\mu(q)}{\\phi(q)} \\int_I e(\\frac{\\xi t}{q})\\ dt \\ll (q + x \\left|\\xi\\right|)^{O(1)} x^{1/2} \\log^2 x", block: true)]]

#text("with effective constants. (")#emph[#text("Hint:")]#text(" use Exercise 48 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", and adjust the arguments used to prove Proposition ")#link(<tao-c7dac63a93ebc854d4ee>)[#text("24")]#text(" accordingly.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" ")#metadata(none) <tao-246c9177dcfa5e11a7fa>#text(" If ")#mi("{q \\leq \\log^A x}")#text(" and there is a real primitive Dirichlet character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" whose ")#mi("{L}")#text("-function ")#mi("{L(\\cdot,\\chi)}")#text(" has an exceptional zero ")#mi("{\\beta}")#text(" with ")#mi("{1 - \\frac{c}{\\log q} \\leq \\beta < 1}")#text(" for a sufficiently small ")#mi("{c}")#text(", establish the variant")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) - \\frac{\\mu(q)}{\\phi(q)} \\int_I e(\\frac{\\xi t}{q})\\ dt + \\chi(a) \\frac{\\tau(\\chi)}{\\phi(q)} \\int_I t^{\\beta-1} e(\\frac{\\xi t}{q})\\ dt")]]

#align(center)[#tao-fit-display[#tao-math("\\ll_A (q + x \\left|\\xi\\right|) x \\log^{-A} x", block: true)]]

#text("of Proposition ")#link(<tao-c7dac63a93ebc854d4ee>)[#text("24")]#text(", with the implied constants now effective and with the Gauss sum ")#mi("{\\tau(\\chi)}")#text(" defined in equation (11) of Supplement 2. If there is no such primitive Dirichlet character, show that the above estimate continues to hold with the exceptional term ")#mi("{\\overline{\\chi(a)} \\frac{\\tau(\\chi)}{\\phi(q)} \\int_I t^{\\beta-1} e(\\frac{\\xi t}{q})\\ dt}")#text(" deleted.")
]

#text("Informally, the above exercise suggests that one should add an additional correction term ")#mi("{- \\frac{q}{\\phi(q)} \\chi(n) n^{\\beta-1}}")#text(" to the model for ")#mi("{\\Lambda}")#text(" when there is an exceptional zero.")

#text("We can now formalise the approximation ")#link(<tao-92829e91fb11026ba175>)[#text("(8)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-cc5d5c2e07829c1aea03>#text(" Let ")#mi("{A > 0}")#text(", and suppose that ")#mi("{B}")#text(" is sufficiently large depending on ")#mi("{A}")#text(". Let ")#mi("{x \\geq 2}")#text(", and let ")#mi("{Q}")#text(" be a quantity with ")#mi("{\\log^B x \\leq Q \\leq x^{1/2} \\log^{-B} x}")#text(". Let ")#mi("{\\nu_Q: {\\bf N} \\rightarrow {\\bf R}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("\\nu_Q(n) := \\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\frac{\\mu(q)}{\\phi(q)} e( \\frac{an}{q} ).")]]

#text("Show that for any interval ")#mi("{I \\subset [1,x]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) - \\sum_{n \\in I} \\nu_Q(n) e(\\theta n) \\ll_A x \\log^{-A} x")]]

#text("for all ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(", with ineffective constants.")
]

#text("We also can formalise the approximations ")#link(<tao-a5831008ce901d5c7b8b>)[#text("(9)")]#text(", ")#link(<tao-95832737f103784e2576>)[#text("(10)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{x \\geq 2}")#text(", and let ")#mi("{w > 1}")#text(" be such that ")#mi("{w \\leq \\frac{1}{4} \\log x}")#text(". Write ")#mi("{W := \\prod_{p \\leq w} p}")#text(".")

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\Lambda(n) e(\\theta n) - \\sum_{n \\in I} \\frac{W}{\\phi(W)} 1_{(n,W)=1} e(\\theta n) \\ll \\frac{1}{w}")]]

#text("for all ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(" and ")#mi("{I \\subset [1,x]}")#text(", with an ineffective constant.")],
[#text("(ii) Suppose now that ")#mi("{x \\geq 100}")#text(" and ")#mi("{w = O(\\log\\log x)}")#text(". Let ")#mi("{1 \\leq b \\leq W}")#text(" be coprime to ")#mi("{W}")#text(", and let ")#mi("{\\Lambda_{b,W} := \\frac{\\phi(W)}{W} \\Lambda(Wn+b)}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\Lambda_b(n) e(\\theta n) - \\sum_{n \\in I} e(\\theta n) \\ll \\frac{1}{w}")]]

#text("for all ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(" and ")#mi("{I \\subset [1,x]}")#text(".")]
)
]

#text("Proposition ")#link(<tao-c7dac63a93ebc854d4ee>)[#text("24")]#text(" suggests that the exponential sum ")#mi("{\\sum_{n \\in I} \\Lambda(n) e(\\theta n)}")#text(" should be of size about ")#mi("{x / \\phi(q)}")#text(" when ")#mi("{\\theta}")#text(" is close to ")#mi("{a/q}")#text(" and ")#mi("{q}")#text(" is fairly small, and ")#mi("{x}")#text(" is large. However, the arguments in Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" only give an upper bound of ")#mi("{O( x / \\sqrt{q} )}")#text(" instead (ignoring logarithmic factors). There is a good reason for this discrepancy, though. The proof of Proposition ")#link(<tao-c7dac63a93ebc854d4ee>)[#text("24")]#text(" relied on the Siegel-Walfisz theorem, which in turn relied on Siegel’s theorem. As discussed in Notes 2, the bounds arising from this theorem are ")#emph[#text("ineffective")]#text(" – we do not have any control on how the implied constant in the estimate in Proposition ")#link(<tao-c7dac63a93ebc854d4ee>)[#text("24")]#text(" depends on ")#mi("{A}")#text(". In contrast, the upper bounds in Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" are completely effective. Furthermore, these bounds are close to sharp in the hypothetical scenario of a Landau-Siegel zero:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Let ")#mi("{c}")#text(" be a sufficiently small (effective) absolute constant. Suppose there is a non-principal character ")#mi("{\\chi}")#text(" of conductor ")#mi("{q}")#text(" with an exceptional zero ")#mi("{\\beta \\geq 1 - \\frac{c}{\\log q}}")#text(". Let ")#mi("{x \\geq 2}")#text(" be such that ")#mi("{q \\leq \\exp(c \\sqrt{\\log x} )}")#text(" and ")#mi("{\\beta \\geq 1 - \\frac{c}{\\log x}}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq x} \\Lambda(n) e( \\frac{a}{q} n )\\right| \\gg \\frac{x \\sqrt{q}}{\\phi(q)} \\geq \\frac{x}{\\sqrt{q}}", block: true)]]

#text("for every ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(".")
]

#text("This exercise indicates that apart from the factors of ")#mi("{\\log x}")#text(", any substantial improvements to Proposition ")#link(<tao-cabd786ac52d8cfc81b0>)[#text("18")]#text(" will first require some progress on the notorious Landau-Siegel zero problem. It also indicates that if a Landau-Siegel zero is present, then one way to proceed is to simply incorporate the effect of that zero into the estimates (so that the computations for major arc exponential sums would acquire an additional main term coming from the exceptional zero), and try to establish results like Vinogradov’s theorem separately in this case (similar to how things were handled for Linnik’s theorem, see ")#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/")[#text("Notes 7")]#text("), by using something like Exercise ")#link(<tao-246c9177dcfa5e11a7fa>)[#text("26")]#text(" in place of Proposition ")#link(<tao-c7dac63a93ebc854d4ee>)[#text("24")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Vinogradov’s theorem — ")]]

#text("We now have a number of routes to establishing Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(". Let ")#mi("{N}")#text(" be a large number. We wish to compute the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf N}: a+b+c=N} \\Lambda(a) \\Lambda(b) \\Lambda(c)")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} f(a) f(b) f(c)")]]

#text("where ")#mi("{f(n) := \\Lambda(n) 1_{1 \\leq n \\leq N}}")#text(".")#linebreak()#text(" Now we replace ")#mi("{f}")#text(" by a more tractable approximation ")#mi("{g}")#text(". There are a number of choices for ")#mi("{g}")#text(" that were presented in the previous section. For sake of illustration, let us select the choice ")#metadata(none) <tao-5c566addabaffd8f2e3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("g(n) := \\log R \\sum_{d \\leq R: d|n} \\mu(d) \\eta( \\frac{\\log d}{\\log R} ) 1_{1 \\leq n\\leq N}")]]

#linebreak()#text(" ")#text(" where ")#mi("{R := N^{1/10}}")#text(" (say) and where ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a fixed smooth function supported on ")#mi("{[-1,1]}")#text(" such that ")#mi("{\\eta(t) = 1-t}")#text(" for ")#mi("{0 \\leq t \\leq 1/2}")#text(". From Exercise ")#link(<tao-1570eb5695612a47b307>)[#text("23")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\theta \\in {\\bf R}/{\\bf Z}} \\left| \\sum_n (f(n)-g(n)) e(n \\theta) \\right| \\ll_{A,\\eta} N \\log^{-A} N", block: true)]]

#text("(with ineffective constants) for any ")#mi("{A>0}")#text(". Also, by bounding ")#mi("{g}")#text(" by the divisor function on ")#mi("{[1,N]}")#text(" we have the bounds")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|f(n)\\right|^2, \\sum_n \\left|g(n)\\right|^2 \\ll N \\log^{O(1)} N", block: true)]]

#text("so from several applications of Corollary ")#link(<tao-a3510d75a8d801b1ae57>)[#text("6")]#text(" (splitting ")#mi("{f}")#text(" as the sum of ")#mi("{f-g}")#text(" and ")#mi("{g}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} f(a) f(b) f(c) =")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} g(a) g(b) g(c) + O_A( N^2 \\log^{-A} N )")]]

#text("for any ")#mi("{A>0}")#text(" (again with ineffective constants).")#linebreak()#text(" Now we compute ")#mi("{\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} g(a) g(b) g(c)}")#text(". Using ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(23)")]#text(", we may rearrange this expression as")

#align(center)[#tao-fit-display[#mitex("\\log^3 R \\sum_{d_1,d_2,d_3} (\\prod_{i=1}^3 \\mu(d_i) \\eta(\\frac{\\log d_i}{\\log R})) \\sum_{a,b,c \\in {\\bf N}: d_1|a, d_2|b, d_3|c, a+b+c=N} 1.")]]

#text("The inner sum can be estimated by covering the ")#mi("{(a,b)}")#text(" parameter space by squares of sidelength ")#mi("{[d_1, d_2, d_3]}")#text(" (the least common multiple of ")#mi("{d_1,d_2,d_3}")#text(") as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf N}: d_1|a, d_2|b, d_3|c, a+b+c=N} 1 = \\rho(d_1,d_2,d_3) \\frac{N^2}{2} + O( N d_1 d_2 d_3 )")]]

#text("where ")#mi("{\\rho(d_1,d_2,d_3)}")#text(" is the proportion of residue classes in the plane ")#mi("{\\{ (a,b,c) \\in ({\\bf Z}/[d_1,d_2,d_3]): a+b+c=N\\ ([d_1,d_2,d_3])\\}}")#text(" with ")#mi("{d_1|a, d_2|b, d_3|c}")#text(". Since ")#mi("{d_1,d_2,d_3 \\leq R = N^{1/10}}")#text(", the contribution of the error term is certainly acceptable, so")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c \\in {\\bf Z}: a+b+c=N} f(a) f(b) f(c)")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{N^2}{2} \\log^3 R \\sum_{d_1,d_2,d_3} (\\prod_{i=1}^3 \\mu(d_i) \\eta(\\frac{\\log d_i}{\\log R})) \\rho(d_1,d_2,d_3) + O_A( N^2 \\log^{-A} N).")]]

#text("Thus to prove Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(", it suffices to establish the asymptotic ")#metadata(none) <tao-8e6a0ab2937027144d3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\log^3 R \\sum_{d_1,d_2,d_3} (\\prod_{i=1}^3 \\mu(d_i) \\eta(\\frac{\\log d_i}{\\log R})) \\rho(d_1,d_2,d_3) = G_3(N) + O_A( \\log^{-A} N ).")]]

#text("From the Chinese remainder theorem we see that ")#mi("{\\rho}")#text(" is multiplicative in the sense that ")#mi("{\\rho(d_1 d^{\\prime}_1,d_2 d^{\\prime}_2, d_3 d^{\\prime}_3) = \\rho(d_1,d_2,d_3) \\rho(d^{\\prime}_1,d^{\\prime}_2,d^{\\prime}_3)}")#text(" when ")#mi("{d_1d_2d_3}")#text(" is coprime to ")#mi("{d^{\\prime}_1d^{\\prime}_2d^{\\prime}_3}")#text(", so to evaluate this quantity for squarefree ")#mi("{d_1,d_2,d_3}")#text(" it suffices to do so when ")#mi("{d_1,d_2,d_3 \\in \\{1,p\\}}")#text(" for a single prime ")#mi("{p}")#text(". This is easily done:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" ")#metadata(none) <tao-fdd33982464b25638709>#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\rho(d_1,d_2,d_3) = \\frac{1}{d_1 d_2 d_3}")]]

#text("except when ")#mi("{d_1=d_2=d_3=p}")#text(", in which case one has")

#align(center)[#tao-fit-display[#mitex("\\rho(p,p,p) = \\frac{1_{p|N}}{p^2}.")]]
]

#text("The left-hand side of ")#link(<tao-8e6a0ab2937027144d3c>)[#text("(24)")]#text(" is an expression similar to that studied in Section 2 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(", and can be estimated in a similar fashion. Namely, we can perform a Fourier expansion ")#metadata(none) <tao-a5861679d0724be2eecc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("e^u \\eta( u ) = \\int_{\\bf R} F(t) e^{-itu}\\ dt")]]

#linebreak()#text(" ")#text(" for some smooth, rapidly decreasing ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(". This lets us write the left-hand side of ")#link(<tao-8e6a0ab2937027144d3c>)[#text("(24)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\log^3 R \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} \\sum_{d_1,d_2,d_3} \\frac{\\mu(d_1) \\mu(d_2) \\mu(d_3) \\rho(d_1,d_2,d_3)}{d_1^{(1+it_1)/\\log R} d_2^{(1+it_2)/\\log R} d_3^{(1+it_3)/\\log R}}")]]

#align(center)[#tao-fit-display[#mitex("F(t_1) F(t_2) F(t_3)\\ dt_1 dt_2 dt_3.")]]

#text("We can factor this as ")#metadata(none) <tao-8ff4b663f0a504b2ad93>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\log^3 R \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} \\prod_p E_p(\\frac{1+it_1}{\\log R},\\frac{1+it_2}{\\log R},\\frac{1+it_3}{\\log R})")]]

#align(center)[#tao-fit-display[#mitex("F(t_1) F(t_2) F(t_3)\\ dt_1 dt_2 dt_3")]]

#text("where (by Exercise ")#link(<tao-fdd33982464b25638709>)[#text("30")]#text(")")

#tao-aligned(keep: true)[


#tao-math("E_p(s_1,s_2,s_3)  & = 1 - \\frac{1}{p^{1+s_1}} - \\frac{1}{p^{1+s_2}} - \\frac{1}{p^{1+s_3}}", block: true)



#tao-math(" & + \\frac{1}{p^{2+s_1+s_2}} + \\frac{1}{p^{2+s_1+s_3}} + \\frac{1}{p^{2+s_2+s_3}}", block: true)



#tao-math(" & - \\frac{1_{p|N}}{p^{2+s_1+s_2+s_3}}.", block: true)
]

#text("From Mertens’ theorem we see that")

#tao-aligned(keep: true)[


#tao-math("\\prod_p E_p(\\frac{1+it_1}{\\log R},\\frac{1+it_2}{\\log R},\\frac{1+it_3}{\\log R})  & \\ll \\prod_p (1 + O(\\frac{1}{p^{1+1/\\log R}}) )", block: true)



#tao-math(" & \\ll \\log^{O(1)} R", block: true)
]

#text("so from the rapid decrease of ")#mi("{F}")#text(" we may restrict ")#mi("{t_1,t_2,t_3}")#text(" to be bounded in magnitude by ")#mi("{\\sqrt{\\log R}}")#text(" accepting a negligible error of ")#mi("{O_A(\\log^{-A} R)}")#text(". Using")

#align(center)[#tao-fit-display[#mitex("\\prod_p 1 - \\frac{1}{p^s} = \\frac{1}{\\zeta(s)}")]]

#text("for ")#mi("{\\text{Re}(s)=1}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(s_1,s_2,s_3) = \\frac{1}{\\zeta(1+s_1) \\zeta(1+s_2) \\zeta(1+s_3)}")]]

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(s_1,s_2,s_3) \\prod_{j=1}^3 (1 - \\frac{1}{p^{1+s_j}})^{-1}.")]]

#text("By Taylor expansion, we have")

#align(center)[#tao-fit-display[#mitex("E_p(s_1,s_2,s_3) \\prod_{j=1}^3 (1 - \\frac{1}{p^{1+s_j}})^{-1} = 1 + O( \\frac{1}{p^{3/2}} )")]]

#text("(say) uniformly for ")#tao-math("{\\left|s_1\\right|, \\left|s_2\\right|, \\left|s_3\\right| \\leq 1/10}", block: false)#text(", and so the logarithm of the product ")#mi("{\\prod_p E_p(s_1,s_2,s_3) \\prod_{j=1}^3 (1 - \\frac{1}{p^{1+s_j}})^{-1}}")#text(" is a bounded holomorphic function in this region. From Taylor expansion we thus have")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(s_1,s_2,s_3) \\prod_{j=1}^3 (1 - \\frac{1}{p^{1+s_j}})^{-1} = (1+P(s_1,s_2,s_3)+O_A(\\log^{-A} R))")]]

#align(center)[#tao-fit-display[#mitex("\\times \\prod_p E_p(0,0,0) / (1 - \\frac{1}{p})^3")]]

#text("when ")#mi("{s_1,s_2,s_3 = O( 1/\\sqrt{\\log R} )}")#text(", where ")#mi("{P}")#text(" is some polynomial (depending on ")#mi("{A}")#text(") with vanishing constant term. From ")#link(<tao-952eb25e6903e35b2b7d>)[#text("(1)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(0,0,0) / (1 - \\frac{1}{p})^3 = G_3(N).")]]

#text("Similarly we have")

#align(center)[#tao-fit-display[#mitex("\\zeta(1+s) = \\frac{1 + Q(s) + O_A( \\log^{-A} R)}{s}")]]

#text("for ")#mi("{s = O(1/\\sqrt{\\log R})}")#text(", where ")#mi("{Q}")#text(" is another polynomial depending on ")#mi("{A}")#text(" with vanishing constant term. We can thus write ")#link(<tao-8ff4b663f0a504b2ad93>)[#text("(26)")]#text(" (up to errors of ")#mi("{O_A(\\log^{-A} R)}")#text(") as")

#align(center)[#tao-fit-display[#tao-math("G_3(N) \\int_{\\left|t_1\\right|, \\left|t_2\\right|, \\left|t_3\\right| \\leq \\sqrt{\\log R}} (1+S(\\frac{1+it_1}{\\log R},\\frac{1+it_2}{\\log R},\\frac{1+it_3}{\\log R}))", block: true)]]

#align(center)[#tao-fit-display[#mitex("(1+it_1) (1+it_2) (1+it_3) F(t_1) F(t_2) F(t_3)\\ dt_1 dt_2 dt_3")]]

#text("where ")#mi("{S}")#text(" is a polynomial depending on ")#mi("{A}")#text(" with vanishing constant term. By the rapid decrease of ")#mi("{F}")#text(" we may then remove the constraints on ")#mi("{t_1,t_2,t_3}")#text(", and reduce ")#link(<tao-8e6a0ab2937027144d3c>)[#text("(24)")]#text(" to showing that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} (1+S(\\frac{1+it_1}{\\log R},\\frac{1+it_2}{\\log R},\\frac{1+it_3}{\\log R}))")]]

#align(center)[#tao-fit-display[#mitex("(1+it_1) (1+it_2) (1+it_3) F(t_1) F(t_2) F(t_3)\\ dt_1 dt_2 dt_3 = 1")]]

#text("which on expanding ")#mi("{S}")#text(" and Fubini’s theorem reduces to showing that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (1+it)^k F(t)\\ dt = 1_{k=1}")]]

#text("for ")#mi("{k=1,2,\\dots}")#text(". But from multiplying ")#link(<tao-a5861679d0724be2eecc>)[#text("(25)")]#text(" by ")#mi("{e^{-u}}")#text(" and then differentiating ")#mi("{k}")#text(" times at ")#mi("{u=0}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\eta^{(k)}(0) = (-1)^k \\int_{\\bf R} (1+it)^k F(t)\\ dt,")]]

#text("and the claim follows since ")#mi("{\\eta(u) = 1-u}")#text(" for ")#mi("{0 \\leq u \\leq 1/2}")#text(". This proves Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(" and hence Theorem ")#link(<tao-28d46654d81889701f71>)[#text("1")]#text(".")#linebreak()#text(" One can of course use other approximations to ")#mi("{\\Lambda}")#text(" to establish Vinogradov’s theorem. The following exercise gives one such route:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Use Exercise ")#link(<tao-cc5d5c2e07829c1aea03>)[#text("27")]#text(" to obtain the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c: a+b+c=N} \\Lambda(a) \\Lambda(b) \\Lambda(c)")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{N^2}{2} \\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\frac{\\mu(q)}{\\phi(q)^3} e( aN/q) + O_A( N^2 \\log^{-A} N )")]]

#text("for any ")#mi("{A>0}")#text(" with ineffective constants. Then show that")

#align(center)[#tao-fit-display[#mitex("\\sum_q \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\frac{\\mu(q)}{\\phi(q)^3} e( aN/q) = G_3(N)")]]

#text("and give an alternate derivation of Theorem ")#link(<tao-82183b7fca9b98f39584>)[#text("2")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" ")#metadata(none) <tao-46e0876178516073c5ae>#text(" By using Exercise ")#link(<tao-246c9177dcfa5e11a7fa>)[#text("26")]#text(" in place of Exercise ")#link(<tao-cc5d5c2e07829c1aea03>)[#text("27")]#text(", obtain the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b,c: a+b+c=N} \\Lambda(a) \\Lambda(b) \\Lambda(c)")]]

#align(center)[#tao-fit-display[#mitex("= (G_3(N) + O( \\frac{q^2}{\\phi(q)^3}) ) \\frac{N^2}{2} + O_A( N^2 \\log^{-A} N )")]]

#text("for any ")#mi("{A>0}")#text(" with ")#emph[#text("effective")]#text(" constants if there is a real primitive Dirichlet character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" and modulus ")#mi("{q \\leq \\log^B x}")#text(" and an exceptional ")#mi("{\\beta}")#text(" with ")#mi("{1 - \\frac{c}{\\log q} \\leq \\beta < 1}")#text(" for some sufficiently small ")#mi("{c}")#text(" and for some sufficiently large ")#mi("{B}")#text(" depending on ")#mi("{A}")#text(", with the ")#mi("{\\chi(N) \\frac{\\tau(\\chi)^4}{\\phi(q)^3}}")#text(" term being deleted if no such exceptional character exists. Use this to establish Theorem ")#link(<tao-28d46654d81889701f71>)[#text("1")]#text(" with an ")#emph[#text("effective")]#text(" bound on how sufficiently large ")#mi("{N}")#text(" has to be.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{N \\geq 2}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,r: a+2r \\leq N} \\Lambda(a) \\Lambda(a+r) \\Lambda(a+2r) = {\\mathfrak S} \\frac{N^2}{4} + O_A( N^2 \\log^{-A} N )")]]

#text("for any ")#mi("{A > 0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} := \\frac{3}{2} \\prod_{p>3} (1-\\frac{2}{p}) (1-\\frac{1}{p})^{-2}.")]]

#text("Conclude that the number of length three arithmetic progressions ")#mi("{a,a+r,a+2r}")#text(" contained in the primes up to ")#mi("{N}")#text(" is ")#mi("{{\\mathfrak S} \\frac{N^2}{4\\log^3 N} + O_A( N^2 \\log^{-A} N )}")#text(" for any ")#mi("{A > 0}")#text(". (This result is ")#link("http://www.ams.org/mathscinet-getitem?mr=1513216")[#text("due to van der Corput")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Even Goldbach conjecture for most ")#mi("{N}")#text(")")]#text(" ")#metadata(none) <tao-e083ce0f89f964ebf351>#text(" Let ")#mi("{N \\geq 2}")#text(", and let ")#mi("{g}")#text(" be as in ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(23)")]#text(".")

#list(
[#text("(i) Show that ")#mi("{\\Lambda(f,f,h) = \\Lambda(g,g,h) + O_A( N^2 \\log^{-A} N )}")#text(" for any ")#mi("{A > 0}")#text(" and any function ")#mi("{h: \\{1,\\dots,N\\} \\rightarrow {\\bf R}}")#text(" bounded in magnitude by ")#mi("{1}")#text(".")],
[#text("(ii) For any ")#mi("{M \\leq N}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b: a+b=M} g(a) g(b) = G_2(M) M + O_A( N \\log^{-A} N )")]]

#text("for any ")#mi("{A > 0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("G_2(M) := \\prod_{p|M} \\frac{p^2-p}{(p-1)^2} \\times \\prod_{p \\not | M} \\frac{p^2-2p}{(p-1)^2}.")]]],
[#text("(iii) Show that for any ")#mi("{A > 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b: a+b=M} f(a) f(b) = G_2(M) M + O_A( N \\log^{-A} N )")]]

#text("for all but at most ")#mi("{O_A( N \\log^{-A} N )}")#text(" of the numbers ")#mi("{M \\in \\{1,\\dots,N\\}}")#text(".")],
[#text("(iv) Show that all but at most ")#mi("{O_A( N \\log^{-A} N )}")#text(" of the even numbers in ")#mi("{\\{1,\\dots,N\\}}")#text(" are expressible as the sum of two primes.")]
)
]

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453612")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("Partition function problem (about 20 lines before Thm 1) N and p(N)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("In exercise 7, it is not clear which probability ")#mi("p_n")#text(" is assigned to each ")#mi("n \\leq N")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("Let ")#mi("S")#text(" be a subset of the primes. What is the strongest known condition on the distribution of ")#mi("S")#text(" such that (at least probabilistically) its sumset ")#mi("S+S")#text(" contains almost any even number.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("Of course, “strongest” above should be “weakest”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453633")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("I’m not sure what you mean by “probabilistically” here, but it is possible to find sets S of primes of relative density arbitrarily close to 1 for which S+S does not contain almost every even number. For instance, if W is the product of all the primes less than or equal to w, let S be the set of primes p larger than w such that ")#mi("(p-2,W) > 1")#text(". Then S+S avoids the residue class ")#mi("2 \\text{ mod } W")#text(" but has density ")#mi("1 - \\prod_{2 < p \\leq w} (1 - \\frac{1}{p-1})")#text(", which goes to one as w goes to infinity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("“probabilistically” was meant to be “under appropriate probabilistic model”. In your example It is clear that ")#mi("S+S")#text(" avoids the residue class ")#mi("2 \\mod W")#text(" but it is still not sufficiently clear how the last expression for the density of ")#mi("S+S")#text(" was derived.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2015")])]

#text("The complement of S consists of the primes lying in ")#mi("\\prod_{2 < p \\leq w} (p-2)")#text(" primitive residue classes modulo W, and the density claim then follows from the prime number theorem in arithmetic progressions.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2015")])]

#text("Thanks for the explanation! (I misunderstood your previous explanation “but has density …” as referring to the density of ")#mi("S+S")#text(" – instead of the relative density of ")#mi("S")#text(").")#linebreak()#text(" In the case where ")#mi("S")#text(" is the set of twin primes, is it still possible (according to the current knowledge) that ")#mi("S+S")#text(" contains almost every even positive integer?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2015")])]

#text("The set ")#mi("S")#text(" of twin primes (primes ")#mi("p")#text(" such that ")#mi("p+2")#text(" is also prime) consists almost entirely of primes that are ")#mi("2 \\text{ mod } 3")#text(", so ")#mi("S+S")#text(" consists almost entirely of even numbers that are ")#mi("1 \\text{ mod } 3")#text(". Cramer model or Hardy-Littlewood prime tuple models predict though that this is basically the only obstruction, indeed ")#mi("S+S")#text(" should contain all but finitely many numbers that are ")#mi("4 \\text{ mod} 6")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/948644588034e9888b7fb8a11c9e9f8616f1e1a4b4dcf11fb208fd4568da4b79-c9c108b4f2b2e8c7a6e7154e54f6246888a88cabfd3729eba5e444947851b439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of murugan ramar")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453628")[#strong[#text("murugan ramar")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("i have new analysis operators and functional spaces")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453634")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("As a beginner I’m a puzzled by 7(ii). If the independent probability were 1 instead of ½, and order didn’t matter, wouldn’t the coefficient be 1/12? So why isn’t the coefficient in the problem either 1/(8*12) (if order doesn’t matter) or 6/(8*12) (if it does)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453668")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2015")])]

#text("Interesting post. An alternative formula for the function Mangoldt:")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{d|n} \\Lambda (d)= \\sum_{d|n} \\Lambda \\left ( \\frac{n}{d} \\right ) = \\sum_{d\\leq \\sqrt{n}:d|n} \\Lambda \\left ( \\frac{n}{d} \\right ) + \\sum_{d\\leq \\sqrt{n}:d|n} \\left ( \\frac{n}{d} - \\left \\lfloor \\frac{n}{d+1} \\right \\rfloor \\right )\\Lambda (d)")#linebreak()#text(" Using the Mobius inversion:")#linebreak()#text(" ")#mi("\\displaystyle \\Lambda (n) = \\sum_{d|n} \\mu (d) \\sum_{f\\leq \\sqrt{\\frac{n}{d}}:f|\\frac{n}{d}} \\Lambda (\\frac{n}{df}) + \\sum_{d|n} \\mu (d) \\sum_{f\\leq \\sqrt{\\frac{n}{d}}:f|\\frac{n}{d}} \\left ( \\frac{n}{df}-\\left \\lfloor \\frac{n}{d(f+1)} \\right \\rfloor \\right )\\Lambda (f)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a7f7ea5e8c1e2ae94d73c80133f113244da3402d20374ab42e89f28a0007d8-69af76fda1ecb5b019dd09a9852822ac1e6a80afba05383fdf5c4bae2a5ddce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conic3bundle1surfaces4")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453768")[#strong[#text("conic3bundle1surfaces4")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2015")])]

#text("“see ??? below” should perhaps be “see Exercise 34 below” ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23dbd5d320ae32d419a14bff5e2ced56aa5e0b6a97d0dbf5662cfb1e08913ac9-5e09baddeafa5d2f29208dbd1a3188031f2b0900a3bba88fb1933f1aa4169919.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of edwinjose")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-453810")[#strong[#text("edwinjose")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("Out of topic question: Are there people studying numbers with 3 or more factors? What is the status of the twin 3-factor number conjecture? Perhaps the twin 2-factor number conjecture is just a special case of twin n-factor numbers. I want to know what is the latest in n-factor number research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-454422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2015")])]

#text("Can you clarify what the symbol $\\||$ means?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-454430")[#strong[#text("Vinogradov’s theorem, Part 1 | Intelligible Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2015")]

#text("[…] am trying to read the blog post by Terence Tao on the Hardy-Littlewood circle method and Vinogradov’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69ff871958d3a04e9874cd669d30e6f2991c74905d49eaece8c2f9b9a5a6d687-95967d17c61bb9708910f8fa63ef68c95b737784855218fcc25fbec3df899684.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asier Calbet Rípodas")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-456247")[#strong[#text("Asier Calbet Rípodas")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2015")])]

#text("I was reading your initial comments on the distinction between multiplicative and additive number theory, which are almost always kept separate. However, it occurs to me that studying the Dirichlet Divisor Problem, for example, can be seen as a problem in both additive and multiplicative number theory – indeed, the divisor function can be recovered from the square of the riemann zeta function, but the generating function of the divisor function can also be used via the circle method. Any further thoughts on this? Is the divisor function “special” in this sense, or are there other “overlaps” between additive number theory via the circle method and multiplicative number theory via the riemann zeta function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-456248")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2015")])]

#text("A few problems are lucky enough to have both exploitable additive and multiplicative structure (the counting of primes in arithmetic progressions is another example). I don’t view the two methods as being completely exclusive, and sometimes one needs a combination of the two methods (as well as possibly some other inputs as well) to solve a given analytic number theory problem. And of course there are no shortage of problems for which there is neither exploitable additive structure or exploitable multiplicative structure…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equidistribution for multidimensional polynomial phases | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-457998")[#strong[#text("Equidistribution for multidimensional polynomial phases | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("[…] second lemma (which we recycle from this previous blog post) is a variant of the equidistribution […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A conjectural local Fourier-uniformity of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-462897")[#strong[#text("A conjectural local Fourier-uniformity of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("[…] Since is significantly larger than , standard Vinogradov-type manipulations (see e.g. Lemma 13 of these previous notes) show that this bad case occurs for many only when is “major arc”, which is the case […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic computation of correlations of the divisor function | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-472022")[#strong[#text("Heuristic computation of correlations of the divisor function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("[…] at the current level of technology, is to apply the Hardy-Littlewood circle method (discussed in this previous post) to express (2) in terms of exponential sums for various frequencies . The contribution of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-521319")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("[…] The circle method […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-532957")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] into major and minor arcs in the circle method applied to additive number theory problems; see Notes 8. The Möbius and Liouville functions are model examples of non-pretentious functions; see […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-643962")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2022")])]

#text("Dear prof Tao,")#linebreak()#text(" “As in Proposition 24” should have been 21?")

#emph[#text("[Corrected, thanks – T.]")]

#text("Also, in exercise 31, set ")#mi("Q = \\log^B x")#text(" and use Exercise 9 and properties of ")#mi("\\rho (d_1, d_2, d_3)")#text(", I obtain:")

#mi("\\displaystyle \\sum_{m+n+p=N} \\nu_Q(m) \\nu_Q(n) \\nu_Q(p) = \\frac{N^2}{2} \\bigl( \\sum_{d \\leq Q, d | n} \\frac{\\mu (d)}{d^2}\\rho^3_d")#linebreak()#text(" ")#mi("\\displaystyle +\\sum_{d_1, d_2, d_3 \\leq Q} \\prod_i \\frac{\\mu(d_i)}{d_i} \\rho_{d_i}  \\bigr) + \\mathcal{O}_A \\left(N^2\\log^{-A} N \\right)")

#text("where the second sum over ")#mi("d_1,d_2,d_3")#text(" not all equal and which seems closely related but hopeless to get to the final sum:")#linebreak()#text(" ")#mi("\\frac{N^2}{2} \\sum_{q\\leq Q} \\frac{\\mu (q)}{\\phi^3(q)} c_q(N)=\\sum_{d\\leq Q, d|n} \\frac{d \\mu(d)}{\\phi^3(d)} \\sum_{k\\leq \\frac{Q}{d}, (k,d)=1} \\frac{\\mu^2(k)}{\\phi^3(k)}")#linebreak()#text(" Any hint would be highly appreciated. Thank you for your time.")

#emph[#text("[Don’t try to use Exercise 9; instead evaluate the exponential sums directly via familiar Fourier-analytic manipulations. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/#comment-657168")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2022")])]

#text("Dear prof Tao,")#linebreak()#text(" Maybe this is not a good question but how can one factor the product into ")#mi("E_p(s_1, s_2, s_3)")#text(" as in section 3? How can one know which terms are there in ")#mi("E_p(s_1, s_2, s_3)")#text(" ? Thank you for your time.")

#emph[#text("[Any (absolutely convergent) sum of a multiplicative function in one or more variables can be factored into an Euler product. For instance ")#mi("\\sum_{n=1}^\\infty g(n) = \\prod_p (\\sum_{j=0}^\\infty g(p^j))")#text(" for multiplicative ")#mi("g")#text(", and similarly for sums in multiple varables. -T]")]
]
