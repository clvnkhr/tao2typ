// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/12/21/an-epsilon-of-room-vol-i-now-published/
// Converted to Typst by tao2typ: "2026-10-14T16:36:24.022128+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“An epsilon of room”, Vol. I, now published", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“An epsilon of room”, Vol. I, now published")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 December 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/12/21/an-epsilon-of-room-vol-i-now-published/")[#text("https://terrytao.wordpress.com/2010/12/21/an-epsilon-of-room-vol-i-now-published/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The first volume of my 2009 blog book, “")#link("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")[#text("An epsilon of room")]#text("“, ")#link("http://www.ams.org/bookstore-getitem/item=gsm-117")[#text("has now been publishe")]#text("d by the AMS, as part of the ")#link("http://www.ams.org/cgi-bin/bookstore/bookpromo/gsmseries")[#text("Graduate Studies in Mathematics")]#text(" series. (So I finally have a book whose cover is at least partially in yellow, which for some reason seems to be the traditional colour for mathematics texts.) This volume contains the material from my 245B and 245C classes, and can thus be viewed as a second text in graduate real analysis. (I plan to have one volume of the 2010 blog book to be devoted to the material for the 245A class I just taught, and would thus serve as a first text in graduate real analysis to complement this volume.)")

#text("The second volume, which covers a wide range of other topics, should also be published in the near future.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/736bba1b985db7c1ccd0a1410f4777177146b44a2c61c684ef3696518ad889e6-f5b166b25a3cc2dca515961e6a5ccc66ff667f67bbd25a7dfa449bb55aff601d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Honglang Wang")]], [#link("https://terrytao.wordpress.com/2010/12/21/an-epsilon-of-room-vol-i-now-published/#comment-49083")[#strong[#text("Honglang Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2010")])]

#text("Now I have updated my profile pic, then I want to congratulate again, hehe. By the way, I really appriciate you have such great blog for others to share. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34f1ad8aae5b23c87d106772e9794795eaccb5c20b0094e7a5656f1f5af35bb4-6ebb92334d46e72fc7764804f4382440349a9192ff382dddb2cd23246f1b9160.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ioan")]], [#link("https://terrytao.wordpress.com/2010/12/21/an-epsilon-of-room-vol-i-now-published/#comment-49324")[#strong[#text("Ioan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2011")])]

#text("What about an DVD with recorded lectures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/21/an-epsilon-of-room-vol-i-now-published/#comment-49356")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2011")]

#strong[#text("Do you know anyone who has created a book from a blog?…")]

#text("Terence Tao has one of the best mathematical blogs on the Internet and has been publishing it in book form for a few years now. The blog has included full lecture notes for several graduate courses, which are now available in book form. See, for exampl…")
]
