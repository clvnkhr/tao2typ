// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/
// Converted to Typst by tao2typ: "2026-10-18T11:29:27.131734+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Why I didn’t sign the Fields medallists’ letter", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Why I didn’t sign the Fields medallists’ letter")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/")[#text("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-18 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://gowers.wordpress.com/")[#text("Timothy Gowers")]#text(", crossposted from ")#link("https://gowers.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/")[#text("his blog")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("When I was around 11 I heard for the first time about Fermat’s Last Theorem. I was immediately captivated by the problem statement, as well as by the accompanying story, and made a fairly serious attempt to prove it. And while, unsurprisingly, I failed, I learned a lot from the attempt. Blissfully ignorant of the fact that the ")#mi("{n=3}")#text(" case had been proved by Euler over 200 years earlier, I decided that that would be a good place to start: once I had sorted that out, I was optimistic that I would be ready to tackle the general case.")

#text("Since I still couldn’t really see where to start, I decided to simplify the problem further and concentrate on successive differences of cubes, with a view to showing that such a difference could not itself be a cube. At the time I did not know how to express what I was doing in algebraic language, so I did not explicitly try to prove that the Diophantine equation ")#mi("{3n^2+3n+1=m^3}")#text(" had no solution. Rather, I just worked out some successive differences and stared at them, trying to get some idea of why none of them was a perfect cube. (I should be clear that this story is a reconstruction of what I think probably happened given the few memory traces that remain half a century later rather than a completely reliable account.) At some point, I had the idea of taking the difference sequence of the difference sequence, and discovered that it formed an arithmetic progression. That felt like progress, so I investigated difference sequences a bit more and discovered, purely empirically, the rule that if you start with ")#mi("{n}")#text("th powers and keep taking successive differences, then eventually you get to the constant sequence ")#mi("{n!, n!, n!, \\dots}")#text(".")

#text("Somehow I never managed to turn this observation into a proof of Fermat’s Last Theorem, and later on my dream of solving it got replaced by other mathematical dreams. However, when I reached the point in my mathematical education where I was taught about taking difference sequences and about what happened to polynomials, I understood those topics much better than I would have if I had not discovered difference sequences for myself and spent happy hours playing around with them. I mention this story just as an illustration of the phenomenon that was strongly emphasized in ")#link("https://mathandai.org/")[#text("this letter signed by 25 Fields medallists")]#text(", that one learns a lot from thinking about a problem, regardless of whether one solves it.")

#text("In the end, however, I felt that I could not sign the letter, despite agreeing with much of what it said. Instead, it seemed better to do what I did with the Leiden Declaration and set out my own position in a blog post. But it should be understood that by doing that I am not setting myself up as a member of some opposing camp: indeed one of my worries at the moment is that the mathematical community might become bitterly divided, something I would very much like to avoid. Also, I agree on the fundamental point that we are facing a crisis: I just want to offer a slightly different analysis of what that crisis is. I don’t claim full originality for this analysis, as I know that several other mathematicians have already put forward thoughts that are similar to the ones I have, though (for what it’s worth) I have largely come to these conclusions independently.")

#text("On the subject of independence, it will perhaps help if I clarify that while I have contacts in the mathematics group at OpenAI, and have also been given early access to some of their models (typically only a few days before they have been released), and have been given free access to their Pro models once released, I have never been paid by OpenAI. I mention this in the hope, perhaps naive, that what I write will not be dismissed for ad hominem reasons. Another potential reason for my being regarded as “pro-AI” is that, as I have stated publicly several times, I have a group in Cambridge devoted to automatic theorem proving. However, that is actually more of a reason to be anti-AI, since our group has been trying to attack the problem of getting computers to prove interesting theorems by understanding as well as possible how humans prove interesting theorems, so now that LLMs can clearly do it without the help of such insights as we have had, one of the main motivations for our work has disappeared. To put it another way, we have had to swallow the ")#link("http://www.incompleteideas.net/IncIdeas/BitterLesson.html")[#text("bitter lesson")]#text(" (which of course we were always aware was a distinct possibility, even if the speed at which it happened has taken us by surprise). I do in fact think that it is still a very interesting and valuable intellectual exercise to try to gain this understanding, even if we can use LLMs as black boxes, but that’s a topic for another blog post.")

#text("So why didn’t I sign the letter? Let me extract a couple of sentences from it that express what I see as the principal argument being put forward.")

#emph[#text("But solving problems is only a tool and proxy for achieving the primary goal of conceptual understanding and insight. Forgetting this in the world of AI may turn the tool against the primary goal. Indeed, the mass production at faster and faster pace of “true/false” statements could destroy fertile ground instead of breathing life into new ideas.")]

#text("Perhaps the main reason I didn’t sign is that I don’t fully subscribe to this view. Instead, I have a more complicated view, which I actually expressed in my essay The Two Cultures of Mathematics a quarter of a century ago, and which can be summarized by saying that there is a spectrum of attitudes in mathematics to the relationship between problem-solving and conceptual understanding. At one end of the spectrum you have mathematicians who are primarily motivated by the wish to solve problems, who see conceptual understanding as a very important means to that end. At the other you have mathematicians who are primarily motivated by the wish to attain conceptual understanding, who see problem-solving as a very important means to ")#emph[#text("that")]#text(" end. I worry that the severe-misalignment letter could be seen as saying that the “right” attitude is to focus on conceptual understanding as the main priority — indeed, the above sentences say that more or less directly. But I think that there are mathematicians all across the spectrum, and that that is a good thing (or perhaps I should say that it has been a good thing up to now — the future is much less certain), and I don’t want to suggest to a large fraction of mathematicians, including myself, that their mathematical temperament is somehow “wrong”.")

#text("My own particular mathematical attitude is very similar to one that was beautifully articulated in ")#link("https://x.com/Jacob_Tsimerman/status/2051116022585770170?s=20")[#text("a Twitter post by Jacob Tsimerman")]#text(" (another non-signatory of the letter), which, now that I look at it, says a lot of what I will be saying here. And that post in turn is a response to Daniel Litt, who is in my opinion one of the wisest commentators on mathematics and AI. His views are expressed ")#link("https://www.daniellitt.com/blog/2026/9/13/a-beginning-for-mathematics/")[#text("in a later post here")]#text(", which I deliberately didn’t read until finishing this one, and then found, as I expected, that there was significant overlap. I would also like to take this opportunity to recommend an excellent post by Noah Smith entitled ")#link("https://www.noahpinion.blog/p/the-end-of-the-age-of-heroes")[#text("The End of the Age of Heroes")]#text(", in case you haven’t read it.")

#text("I have been talking so far about individual mathematical understanding, but I suspect that what concerns most of the signatories is less that than the collective understanding that results at least in part from the human activity of problem solving. My guess is that they would argue, completely coherently, that even if collective understanding is the primary goal, if many individuals are primarily motivated by the wish to solve problems, that’s absolutely fine and contributes to that collective understanding.")

#text("With that interpretation, the issue becomes slightly different: is it more important that the collective understanding of the mathematical community should be as advanced as possible or that there should be answers to as many problems as possible? Or are those two aims valuable in different ways, so that there is no point in declaring one of them more important? Or are they so inextricably linked that it makes no sense to argue that one is more important than the other? And when we say “important”, for whom are we saying it is important: for mathematicians, or for society as a whole?")

#text("I find these hard questions, so I don’t want just to declare an answer to them. (Do you see what I did there?) Instead, I’d like to try to offer at least some argument for any conclusions I come to, even if they are tentative. So let’s compare two scenarios. In the first, which I think is the more likely actually to happen, models become publicly available that are better at solving problems than virtually all mathematicians. If there are a few residual mathematicians who can do things the models can’t, even they work far faster if they make heavy use of the models. Thanks to this, in a short time we get answers to many questions that we have deeply cared about, but the rate at which we receive these answers far exceeds the rate at which the mathematical community can absorb them. In particular, most of the answers are obtained with zero effort from human mathematicians — just prompts such as “Thank you — please continue”.")

#text("In the second scenario, there has been an international agreement, for entirely other reasons, to block the public release of models significantly more powerful than the ones we currently have, and the mathematicians within the tech companies agree to hold off from getting their internal models to solve major problems. Instead, they take guidance from the mathematical community, solving problems only when asked to do so by some suitably representative body that decides that the benefit of receiving a solution of a certain problem outweighs the benefits of humans struggling to solve it over a much longer timescale.")

#text("I’d like to consider what the difference would be between these two scenarios both for individual and collective understanding. I’ll begin with individual understanding.")

#text("One might argue that for individual understanding, not too much would change if we are suddenly flooded with large numbers of big new results. There is already far more mathematics out there than I have any hope of understanding (for example, despite being fascinated when Fermat’s Last Theorem was proved, I have made no attempt to understand the proof), and even among the parts that I do understand, the parts that I understand because I myself discovered them form a very small fraction, though a fraction that I understand more deeply than anything else (at least temporarily — after a while I forget things and lose quite a lot of the understanding I built up). However, one change, which seems positive, from the perspective of the building up of individual understanding, would be that we would have a much bigger choice of results that we could choose to study. Also, if we found ourselves stuck on some point, AI would be able to help us. The main likely negative change is that we would probably cease to exercise that part of our brains that we use when spending months or years struggling with a difficult research problem, which can be hugely helpful in developing understanding.")

#text("I say “likely” because in principle there would be nothing to stop us thinking about very hard problems without consulting LLMs, but in practice it seems unlikely that people would put in the same level of effort that they do now. The situation might a bit like what happened with satnavs, where one could always decide not to use them, to keep the part of the brain active that can look at a map, learn a route, and follow it, but in practice most people succumb to the temptation to use a satnav. (In fact, I myself do try to keep that part of my brain active, and was rather proud of finding my way somewhere recently when I had briefly looked up the route on my phone but then forgotten to bring the phone with me when I actually went there.) But even if all we were doing was reading AI output, I think that the problem-solving muscles in the brain wouldn’t atrophy completely. When students are reading maths papers, I strongly advise them (and I think this is pretty standard advice) to read “actively” rather than “passively”, doing things like trying to prove the result for yourself, looking at the paper only when you feel stuck and need a hint, and even then just trying to get the hint and as little extra as possible. If one reads a paper that way, then one is constantly solving problems, some just exercises and some quite a bit harder. It seems likely that an LLM could get to know what our mathematical background is and feed us with just the right hints to allow us to work our way through a mathematics paper in this active way. Yes, we would lose the particularly deep level of understanding and ownership that comes with having solved a hard problem oneself, but it isn’t clear to me that progress in mathematics would suffer as a result. I would be very interested to hear counterarguments to precisely this point. That is, I would be interested to know what use that level of deep involvement with a proof might have in a world where AI is much better than we are at finding proofs.")

#text("How about collective understanding? Let me quote a bit more of the letter.")

#emph[#text("Indeed, the mass production at faster and faster pace of “true/false” statements could destroy fertile ground instead of breathing life into new ideas.")]

#emph[#text("Often these solutions are announced in a rush, leaving no time for a proper writeup, the isolation of new methods and ideas, and citing relevant previous work of others. As in all creative professions, this raises severe attribution and plagiarism questions. Moreover, without the willing mathematicians who must take care of their development and integration into the mathematical canon, AI-conceived ideas would never become fully alive and the crucial human transmission chain between mathematicians would be lost.")]

#text("I’ll come back to questions about proper citation and focus on what I take as the core worry here: that if results are proved too quickly, then the digestion process will become impossible. I am definitely worried that results will not be properly digested, but for different reasons.")

#text("A first remark is that what AI is producing is not just true/false statements: we now know not just that the Navier-Stokes equation with smooth forcing admits finite-time blow-up, but we have a proof of that, which builds on a great deal of wonderful work done by human mathematicians. Many people used to express the worry that AI would solve our favourite problems with utterly opaque proofs, but that has not turned out to be the case, even if their write-ups often leave plenty to be desired. (Incidentally, I see these inadequate write-ups as almost certainly a temporary annoyance and therefore not as a fundamental threat to mathematical practice or future mathematical understanding.)")

#text("Secondly, even if the volume of new results is large, mathematics is a highly specialized discipline, so mathematicians can work in parallel. If, for example, we had to digest 1000 important results in a year that were roughly uniformly distributed across mathematics, then most sub-communities of mathematicians would probably want to understand around 30 of them, and for each individual problem there might well be only a small handful of specialists who would be obvious people to take the lead in reaching this understanding, with that handful varying from problem to problem. So it would be a big task, but not necessarily an impossible one.")

#text("In this context, it is worth thinking about the huge volume of output of human mathematicians, which seems to have been increasing recently, even before AI. While I have sometimes heard complaints about this, I have certainly not heard suggestions that human mathematicians should slow down the rate at which they prove interesting theorems. That may be partly because the authors of those theorems take the trouble to write their papers well and give good talks. But what about the large quantity of papers, including important ones, that are not written well and whose authors give incomprehensible talks? That can be annoying, but it is a familiar annoyance and not one that we think of as a crisis.")

#text("A third point is that even if the volume of AI output is too big for us to be able to digest it properly, that is not necessarily a bad thing. To draw an imperfect analogy, there is now more content available on streaming services than anyone could possibly watch, with the result that there is almost certainly some very good content out there that is hardly watched at all. But that isn’t obviously a worse situation than if there were far less content and all of it received the attention it deserved. Returning to mathematics, if there were too much AI-generated content for us to be able to digest it, then we could choose which parts of it we wanted to digest.")

#text("For that we would need to have some idea what was there (a situation a little similar to how human mathematicians typically learn quite a lot about what results are known in their area even when they do not understand their proofs in any detail). One way one could try to achieve that would be to create a well-designed database, probably with AI help. But perhaps that would be unnecessary, and instead one could simply talk to an LLM and ask it to give a bird’s-eye view of whatever area of mathematics one wanted to understand in that knowing-what’s-there way.")

#text("The fear seems to be that some very interesting and important parts of mathematics will be discovered by AI and then overlooked, when had they been discovered by human mathematicians they would not have been overlooked. And that may even be the case, but what matters is whether the amount of interesting and important mathematics discovered by AI that is not overlooked will exceed the amount of interesting and important mathematics that would have been discovered and properly digested by humans with AI having played a more modest role.")

#text("In short, it seems to me that while a flood of “big” AI results would be likely to increase the amount of important mathematics that was not properly digested, it would also be likely to increase the amount that ")#emph[#text("was")]#text(" properly digested, which seems like a pretty good bargain.")

#text("Let me quickly discuss the problem of AI not properly crediting human mathematicians. I agree that this is a serious problem right now, but it is another problem that I see as temporary. Very soon, the whole “credit system” will surely collapse, since finding an amazing proof will be no more of an intellectual achievement than when a citizen scientist spots through their telescope an object that turns out to be a new comet. Until that happens, it is important to give humans the credit they deserve, since careers can depend on it, but that will soon cease to be the case as well. I have to say that I’m puzzled that this problem exists, since I would have thought that if you asked an LLM to look at a proof and tell you which ideas in it are close to ideas that are in the literature already, it would be extremely good at that task. I hope the answer to this conundrum is not that people have been in such a hurry that they have simply not taken the trouble to do this, but I fear that it might be, at least in some cases. If so, then those who have been careless deserve to be criticized, but it is a minor matter compared with the survival of mathematics, especially if the lack of citations is swiftly put right.")

#text("Does all this mean that I am optimistic that mathematicians will end up digesting at least as much mathematics in a post-AI world as it would have if AI had not been able to prove major theorems? Not exactly. But my worry is not that we would be unable to do it, but rather that the social structures that currently support this digestion process will be destroyed and not adequately replaced.")

#text("One way that might happen is that AI disrupts society so much, or even kills vast numbers of us, that the preservation of something like the current mathematical tradition ceases to be of any concern: all that will matter is the survival of the human race. But that again is a topic for a different blog post (which in fact I am in the middle of writing).")

#text("Let’s assume instead that we get lucky and that AI remains more or less under control. My worry then is that we do not manage to transmit what we know to a new generation of mathematicians. Speaking for myself, my main motivation for becoming a mathematician was the dream that I would solve unsolved problems — the more famous the better. I have also always greatly preferred directly thinking about a problem to reading books and papers and generally learning the mathematics of other people. (I’m not saying that’s good, but just stating a fact about myself.) If the dream of solving a famous problem had not existed, I’m not sure whether I would have become a mathematician. I don’t completely rule it out: maybe what really motivated me was that I had an aptitude for the subject and that solving problems was a way of getting respect from a small group of peers. And maybe I could have tried to gain that respect in a different way, such as thinking very hard about an area of mathematics until I was able to demonstrate to others just how well I understood it. But I’m not sure how motivating that would have been for me. I very much hope that there is a pool of young people for whom it ")#emph[#text("will")]#text(" be a powerful motivation, because I think the survival of a human mathematical tradition may well depend on it.")

#text("Thus, the primary risk, as I see it, is that a lot of people who would have done a PhD in mathematics and gone on to become custodians of the mathematical tradition will no longer wish to do so. Those of us who have PhD students, including me, need to try as hard as we can to come up with imaginative ways for them to use their time productively (in consultation with the students themselves, obviously). Whether or not we do a good job with that could make a huge difference to the future of mathematics. A related risk is that the perception among policy-makers will be that mathematicians are no longer needed and that funding will become much harder to come by: we urgently need to come up with good ways of explaining the value of having a large pool of human mathematical experts, even if it is no longer part of their role to find new proofs of theorems.")

#text("A final reason that I didn’t sign the letter is that I wasn’t really sure what it was demanding that isn’t happening already. It seems likely that in a matter of not very many months LLMs will be released that are able to solve major mathematical problems, and they will presumably have no trouble at all with more run-of-the-mill problems. However much we might regret that, there is no chance that the impact of such models on mathematics will persuade AI companies to stop their release, though perhaps concerns about safety will lead to some delay and give us a bit more time to work out how to adapt. Assuming that they are released, there will be a flood of new results, whether we like it or not, and it will no longer be the AI companies producing them, though perhaps the pattern will continue that the AI companies will have access to more powerful models and so will obtain more than their fair share of headline results. So I felt that there was nothing to be gained from criticizing AI companies for generating too many solutions too quickly. In fact, it may well be that all that does is bring forward by a couple of months what was going to happen anyway, and perhaps it will even allow the results to be released in a more controlled way than they would have been if they had been discovered by random people once the models were publicly available. Under the circumstances, I think the best we can do is recognise the changes that are coming and try to work out the least unsatisfactory way of dealing with them.")

#heading(level: 1)[#text("Comments (43)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695500")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I also believe in an abundance of proofs. Abundance is almost never a bad thing; we can always choose wisely among what we have.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695532")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("it could be very overwhelming")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1624e80f140871e0de29b816ec325f971c3b219842344d92191056378b3f20b-91979e7dd76a572fb04c2002428ba78e3338b52fc20e29402e109c8c2778f10c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observant12e86d8d4f")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695501")[#strong[#text("observant12e86d8d4f")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I think ironically your position might be the Navier Stokes blowup. Will AI advance mathematics exponentially or will it dissolve it?")

#text("There is a danger that the LLM results are superficially correct, obscure the real insights of the result, contain subtle errors and we only discover the blowup when its too late and we don’t know quite where to look because we didn’t absorb the argument sufficiently to get to the failure point and go “ah! that must be xyz”")

#text("We see this problem in vibe coding – or even “professional SWEng with LLM’s” – the code appears to do what you asked – but contains N^3 lines of code vs N the ideal. N^3 lines of code contains m^3 bugs.")

#text("That doesn’t mean LLM’s are bad – they just have to be treated as synthetic library books that can be utilized to help us get to a result and dissect it – and not all seeing Oracles that take away our human agency.")

#text("I think Douglas Adams summed it all up with Deep Thought’s answer : 42")

#text("Be careful what you wish for.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695678")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("That’s why Open AI released a Lean formalization of the proof. As long as the problem statement was formalized correctly in Lean (a much easier job to verify than checking the proof itself) and the Lean file builds correctly, we can be sure that the proof is correct and is free from all the errors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695503")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#emph[#text("‘Those of us who have PhD students, including me, need to try as hard as we can to come up with imaginative ways for them to use their time productively…. Whether or not we do a good job with that could make a huge difference to the future of mathematics.’")]

#text("Indeed. I do not yet fully understand how to help students incorporate LLMS into their training without adversely impacting whatever cognitive training they need to develop to be able to understand mathematics. We instinctively know having a toddler use LLMS to learn counting may be a bad idea, and keep them away from such tools. We also recognize gifted mathematicians are rendered more productive, and many indeed use the tools extensively. It’s the students in arguably the most vulnerable stages of their development – moving from solving textbook-style problems to doing research – that I worry about the most right now.")

#text("In strictly pragmatic terms: this is the ‘season’ when we begin to review graduate and postdoctoral applications. I am grappling with questions like: how many graduate students (if any) is it fair for us to admit? What attributes should they possess, if problem-solving is to be devalued and understanding prioritized (or the other way around, or something else)? What careers would they be trained for? Clarity in exposition opens some paths. Skills in quantitative problem-solving open other paths [are these still available to young aspirants?].")

#text("What kinds of projects would be suitable – is anything the student and I conceive of in Summer 2027 still going to be of community-appreciated value by the time they graduate? What value, and how is it to be assessed? Do I tell them ‘go digest this proof, and explain it’, or do I tell them ‘go read these papers and build a framework’, or do I point them at some Millenium problem, knowing it could be solved by next Monday? The method of suggesting reasonably-hard problems of increasing difficulty no longer works, I think.")

#text("At present ‘originality’ is a core value we assess in a PhD. Have we agreed to remove this requirement, and replace it by ‘understanding’? In a shallow sense, assessing ‘originality’ is much easier – one simply looks at who go there first. Do we have a shared understanding of how to evaluate mathematical understanding?")

#text("More tongue-in-cheek: it’s prize nomination season, and many an award recognizes outstanding mathematical achievement in some form or another. We’ve not always had consensus, but we did possess some notion of what was meant. Do we have new shared norms for what we consider ‘outstanding mathematical achievement in mathematics’ for this season? Will the Joseph L. Doob prize (finally!) receive its due recognition, eventually superseding the Fields medals in importance in our world?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695556")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I have an idea. Upload the student’s thesis to AI, prompt it to generate exam questions based on it, and have students do a closed-book exam. Alternatively, if thesis is not required because all research is done by AI, just let student take AI-generated exam on “recent advances” of student-self-selected topics. This is in addition to the oral exam.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695787")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I’m not in mathematics, and I hadn’t thought about how uncertain math PhD students programs must be right now. I’m a freelance journalist covering math — would you be willing to tell me more about this uncertainty?")

#text("signal: amw.93")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695879")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Happy to reach out. In the meanwhile, though, there are beautifully-written essays by students in such programs, which are somewhat bravely recording their uncertainties.")

#link("https://kirwinhampshire.substack.com/p/the-dark-night-of-mathematics")[#text("https://kirwinhampshire.substack.com/p/the-dark-night-of-mathematics")]

#link("https://marcelgoh.ca/2026/07/05/ai-vegetarian.html")[#text("https://marcelgoh.ca/2026/07/05/ai-vegetarian.html")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695506")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("A perpetual frustration I have with discussion like this is found in the statement “I mention this in the hope, perhaps naive, that what I write will not be dismissed for ad hominem reasons.” This is not applicable to this post as, by the very title, it is a personal statement and not an academic argument. The truth is, a lot of the people who write posts like this also got very close to AI companies, and received grants, and gave named talks about AI. They were able to do so because of accomplishments under the system they seem so ready to dismantle. And, I think, the concerns of the tenured, award laden mathematician who was posting about the novelty of AI a few weeks ago should be viewed skeptically. (Especially bc AI companies have clearly appropriated those credentials for marketing reasons, an inevitable outcome that should have been seen by those involved).")

#text("The “soft” reasons why people do math are important, undeniably, but they are overindexed by those who have gone beyond the practical concerns of the profession, I believe. And mathematics is a profession. A profession that is under existential attack. The question a lot of younger people have is not why we do math or even how, but if we will be in a position to do it in an economically sustainable way. Humans will find joy in math no matter what form it takes, so long as they are able to do it.")

#text("People have lamented the fall of the Theorem Economy. In a similarly glib manner, I believe we are in an era of Discussion Inflation. It used to be that discussion was scarce, mathematicians did it rarely if it all, but now, post N-S, we are drowning in poetic waxing (check the monthly posts here, for relevant data). I am skeptical these are being properly digested by the community, and what it seems we need are some concrete polices to change, especially to protect younger mathematicians and ensure their proper development, but the same people who had no issue leading us down this track seem conspicuously hesitant to plant their flag on what needs to be done. Frustrating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695542")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Re: “Discussion Inflation.” As you say, until a few months ago, mathematicians rarely engaged in any self-reflection, especially if they weren’t also cross-appointed in Philosophy or a similar discipline.")

#text("I understand the reasons for this, but it was gross professional negligence, and it’s largely responsible for the situation we’re in now. The proliferation of recent commentary seems to me to be a healthy immune response which is long overdue.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea35c0e26f50780a6a05e98ec9cbabf2b8620fe7f567e046187852ad89a9742f-1454fe79f8a4c823773a15468b0783e6873a5ca4fab94c2ce671a9c49fd2fe25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695507")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("What about transparency? Can we come up with a system that records (for everyone to see) what AI model, run by what humans, has produced what claim? Maybe some kind of open online ”journal” for all AI-generated ”results”. Yes, it would be huge, but it would be in one place for everyone to see, to scrutiny, to digest, to reference, to referee, to discuss, to understand, to reformulate, to write up, and eventually to motivate the future development of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695510")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I disagree that the Fields medalist’s letter suggests the primacy of ‘conceptual understanding’ over ‘problem solving’. ")#linebreak()#text("I think the arguments above have isolated what is likely a non-issue in the letter, and are using it as an excuse for extended fence-sitting and advocating a sense of inevitability while denouncing the agency of mathematicians.")

#text("For example one can push the argument presented at the end of this essay as saying ‘why have any agency in life, when at somepoint you will die’")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695518")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("What a great post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695520")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Your argument assumes a pipeline like this:")

#text("AI finds a proof → proof is basically correct → humans eventually understand and organize it → mathematics benefits.")

#text("What about this “AI slop” pipeline?")

#text("AI generates something that looks like a proof → mathematician publishes it without understanding it → nobody can readily verify or explain it → the literature fills with results whose mathematical content is uncertain or inaccessible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75466c58a1d44368f62680173e0db2daac71b4602786cab257de2d23ab498b37-88faf38c0286a8da84d461505a72f2f41337b413cb821b50265c4232d0ec2961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695547")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("This is why they are pushing for LEAN certificates. You can have an incomprehensible, machine generated proof and still accept the result if it works in LEAN. In some ways, the Navier-Stokes proof makes it easier. I know the logic is likely correct given their premise. Which means I should focus on attacking their premise first.")

#text("For instance,the Navier-Stokes proof has time running in reverse but keeps the idea of time moving forward from an initial condition to a final condition. The Millennium problem requires the initial velocity to be well-defined, smooth, and divergence-free. By reversing time, the singularity matches the final condition instead of the initial condition, and this is also forbidden if time is reversed. They do this by defining a countdown to a singularity with tau = 1-t and dtau=-dt.")

#text("Garbage in garbage out is a lot like Gauss’ law for the incompressible equation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695574")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Why should anyone care about a proof if it is not understandable by reasonable human mathematicians? Tired of hearing about Lean")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695591")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I guess lean is the next compulsory course for all mathematicians")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-696169")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("There are many “end-users” of mathematics: engineers and scientists, for whom the important thing is the theorem statement and the fact that it’s true. They don’t wanna waste time on delving into and understanding what a proof is doing.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695573")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("This is what journal editors and referees are for")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695529")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Thank you very much, Tim, for your insightful essay! I think you articulated many points clearly. I have a small comment:")

#text("You wrote ”…Thus, the primary risk, as I see it, is that a lot of people who would have done a PhD in mathematics and gone on to become custodians of the mathematical tradition will no longer wish to do so”, putting solving difficult/famous problems as a very important motivation for young people to enter the subject.")

#text("I agree with it. We will lose such motivation given the current situation. But, other subjects, for example, literature, did not have that type of motivation at all. As I see it, many scientific areas do not have such famous-problem-solving culture, though they have certain important goals they want to achieve. Mathematics has many other, possibly more important, aspects than famous-problem-solving, which I think the Fields medalist’s letter tried to emphasize. In the end, we will have a new culture, and that will draw younger generation to our field, though it would possibly be a different type of people we usually had. ")#strong[#text("Depending on what we do from now on")]#text(", we may make mathematics even more interesting to more people, as it becomes much easier to navigate in the mathematical world: It is like having a landscape of mountains, lakes, bushes, streams, deserts, etc, and we can explore it not only with our feet, but, also with helicopters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd633dc1b21affe92b72ecf80a1eec690e6e9b4760e8729677c018d948c8f0b5-0597a20a0480a46e5b0ff4bd7057b40ef5fe926242c992e6825862051ff2c80a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominique Manchon")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695538")[#strong[#text("Dominique Manchon")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("“")#emph[#text("Returning to mathematics, if there were too much AI-generated content for us to be able to digest it, then we could choose which parts of it we wanted to digest.")]#text("”")

#text("I strongly disagree with this vision of mathematicians compelled to digest AI-generated proofs rather than developing their own research. ")#emph[#text("Who")]#text(" will undertake the dauting task to understand from A to Z the recent inhumane proof of the 67%-of-Riemann-zeros result? It comforts the worst fears among us: the very few companies driving AI consider human mathematicians (if not humans in general) doomed to be at their service.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695549")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Strictly speaking the 67% is a bad example: the task was undertook by Youness Lamzouri and resulted in a very readable proof within a short time frame ")#link("https://arxiv.org/abs/2609.02882")[#text("https://arxiv.org/abs/2609.02882")]#text(" . Navier-Stokes on the other hand…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd633dc1b21affe92b72ecf80a1eec690e6e9b4760e8729677c018d948c8f0b5-0597a20a0480a46e5b0ff4bd7057b40ef5fe926242c992e6825862051ff2c80a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dominique Manchon")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695584")[#strong[#text("Dominique Manchon")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Wow… I am not a number theorist, but this original well-written masterpiece is manifestly far beyond digestion. Félicitations Youness !")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75466c58a1d44368f62680173e0db2daac71b4602786cab257de2d23ab498b37-88faf38c0286a8da84d461505a72f2f41337b413cb821b50265c4232d0ec2961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695557")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Moore’s law has run out. The only way to add capacity is by building more data centers. AI is chewing up that compute capacity. Historically, SWAP-C (space, weight, power, and cost) improved automatically. AI will go where it makes the most profit. The economy will keep growing and compounding between 2% and 4% per year. AI was scaling ‘linearly,’ but now they have added agents at an enormous computing cost. I am not sure how many tricks they have left. But even if AI had enough compute to replace everyone, the amount of work needed in the economy will soon outgrow its compute. AI will then have to compete with mass unemployment and rock bottom labor rates. How is AI going to compete with offshoring manufacturing and outsourcing?")

#text("There will be an equilibrium and AI companies are not profitable except for NVIDIA, open-source models have eroded their moat. But open-source models still need hardware that lasts one to three years.")

#text("People tend to overestimate AI when it is applied to a domain outside their expertise. I suspect you are able to drive a car. Did your AI drive your car today? If it did, would you trust it with total control? Self-driving was predicted to replace all drivers by now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695558")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I disagree with the premise that a lot of people are only motivated to study mathematics because of the fame of open problems. I was always just curious about certain topics, and their connections to them. Perhaps there will be less “top mathematicians” of the calibre of the current generation of fields medallists – but I never aspired to be anything more than average to begin with. The bulk of average mathematicians will remain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695592")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Not pushing a frontier that is available to us just seems like something humanity will never do.")

#text("Maybe I’m blinded or something but I simply don’t think there’s a world where ai is not unleashed with all its strength on open math problems.")

#text("I suppose I still feel that AI has not blazed an entirely new trail, and that stretching our current approaches more than we could, because a human couldn’t synthesize a mass amount of other human generated content but ai can is different from inventing a field and that I actually still have some skepticism as to whether or not this capability of humans has been significantly broached at all. Of course such a quality is also rare of humans")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695596")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("we urgently need to come up with good ways of explaining the value of having a large pool of human mathematical experts")
]

#text("But what it that’s impossible? If no matter how you look at it, we can’t make the mathematical community financially and materially (let alone “philosophically”) sustainable in this new realm? If “humans will still be needed to steer/teach/canonize what the AIs do” were just copes that we will need to give up as AIs overtake every aspect of the profession? Do we resign ourselves to seeing the mathematical tradition disappear under the pretext of “inevitability”, or do we decide that nothing about human action is evitable, as long as we are able to unite ourselves on this matter?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695604")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("This managed to piss me off a lot more than I thought it would, just brushing off completely the NS plagarism controversy and blindly celebrating OpenAIs claims when at least the Connes rigidity conjecture claim was already debunked? The position appears to be just rolling over when this is most definitely is not a humans need not apply moment? I guess I’ll spare my concerns about llm obfuscation and conartistry for one that is far more important:")

#text("Perhaps it’s my age but I just hate this whole attitude of “this is how the world is now what can you do progress is progress”, I think we perhaps are starting to see the tension really fiercely emerge that this is a privileged vantage point not shared by younger people deeply existentially concerned about sustainability. The million dollar problem being solved hardly feels like an accomplishment to celebrate when the cost of how is truly considered, rather I see a tradegy of hubris and a signpost on our way to a global easter island.")

#text("I think there is also sadly a lot of extreme naivete about why so much capital has really been thrown at this technology, and so much willful denial even when the powers that be themselves have gotten pretty brazen about the “national security” label for it. Such warnings are the plot of much 80s sci fi, the development of communications technology has always not been far removed from such immediate applications and yet here we still just totally ignoring geospatial intelligence data being used to identify people’s social networks affilations and decided whether or not they are a “terrorist” and how much already that has killed innocent people, because “hello there the jacobian conjecture is false thanx” “omg wow when RH”…")

#text("I guess I shouldn’t worry because sometime in the future the models will be good enough to solve climate change and world hunger, cure cancer and make sure every child in Africa has clean drinking water. These companies totally aren’t openly talking about bombing China… yay AGI is here I may not have clean drinking water anymore but I gusss I can ask it about that too")

#text("I’m not afraid of the computer, I’m afraid of the human stupidity ignoring Icarus’ fate. The extreme picture I paint is the bleak reality we actually face, I wish I could entertain more joyful conversation about happy medium utilizations of new tools, but we can’t keep ignoring who controls them and what they are actually up to. The salespitch that this stuff can replace human decision making has already resulted in a global energy crisis, do mathematicians think they live under rocks and are immune from this all?")

#text("A certain hermit from the pyrenees tried to warn us didn’t he…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695622")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I agree with almost all of this, but the “debunking” I have seen of the Connes rigidity paper is itself LLM slop and is by an author who seems to have a poor grasp on reality, so I think this does not strengthen your argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695648")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("You appear to be correct, the author of that also claims a proof of RH… that the human work can’t be so blindly trusted also, and how much faith we often are putting into the author of most of what we read in a textbook is still a huge part of the issue with LLM mathematics, but I will take the egg on my face and wish I could edit that out now.")

#text("This covers that the OpenAI claims are nevertheless plagiarized as well ")#link("https://www.scientificamerican.com/article/openais-latest-math-breakthroughs-commit-research-misconduct-experts-say/")[#text("https://www.scientificamerican.com/article/openais-latest-math-breakthroughs-commit-research-misconduct-experts-say/")]

#text("I admit I was too quick to look for a gotcha, I’ll also blame Nalini Joshi for sharing that on her mastodon and making the same mistake as I it seems and this the fallacy of appealing to authority in action")

#text("Theo Baker the kid who got Stanford’s president fired when he uncovered research fraud was pretty quick to dismiss the suggestion of a link between Washington politics and academic misconduct but I think that’s very mistaken (I also thing he had enough of a scare with Theranos lawyers already and doesn’t have a death wish). How easy it is to say something that can be latched onto to discredit your entire argument about very complex matters like these I think says a lot about how society spiraled so out of control to have such dereliction of duty so widespread in leadership positions and sort of feels metaphysical, obviously Grothendieck is no model for how to change society and we are blessed ro be able to learn from the mistakes of those who came before us.")

#text("The most brilliant mathematicians I personally know went not into research but primary education, I am talking out of my ass while they do the real heroic work for society")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695666")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("“hello there the jacobian conjecture is false thanx”")#linebreak()#text("yes that tweet still annoys me very deeply. the performative carefreeness of it is extremely cringe")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695606")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("“We are doomed anyway, what is the point of saying anything? What is the point of doing anything, for that matter?”")

#text("Great.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of guillaume")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695611")[#strong[#text("guillaume")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("It is true that the letter mentions “problem solving” as a tool, and not as a goal in itself (and I tend to disagree also with this). This is a difference indeed, but this was not the main point of the letter, which was to oppose the fact that the machines solve the problems, depriving the humans from the possibility of solving the problems by themselves.")

#text("This is a textbook case of political inaction: Political action requires you to get united with people who share some important ideas with you, but of course not all. It sometimes requires you to sign some collective texts, that do not have the same level of precision than what you would write as a single author (and you could use a blog post to clarify why you sign, despite some disagreements).")

#text("There are only two choices: political action, which has to be collective, or political inaction. Political inaction is a form of action in favor of the sociopath billionaires who hold the AI switches.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c7a74ee5acbe7fad5d1e16d38c3422d522ecb6f5521b69fde429223b51e7c5c-08db972442e60c06913e6f718271267f22badfc2f14a501b377c117970c27d05.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jörg Neunhäuserer")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695632")[#strong[#text("Jörg Neunhäuserer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("The essence of mathematical research is not proving mathematical theorems. The mathematical community has been wrong about this for a long time. Hunting down proofs is a tedious, boring, and nerve-racking business that we can safely leave to artificial intelligence. What is dishonorable, however, is claiming authorship of a proof that was found by an AI. A few dozen clever prompts to an AI are certainly not enough to justify such a claim.")

#text("In mathematical research, as I understand it, the goal is the discovery of abstract reality. Our rational intuition gives us access to abstract objects, and we describe them in the language of mathematics. These definitions are the first essence of mathematical research.")

#text("Furthermore, we are able to formulate conjectures about the properties of the abstract objects that we discover. These conjectures are the second essence of mathematical research. Since our conjectures can be wrong, proofs—as the logical and analytical methodology of mathematics—are indeed of some relevance. But in the end, it is entirely irrelevant who or what finds a proof. The mathematician’s real task is to understand a proof and to present it in a compelling way so that other mathematicians can understand it as well.")

#text("When I look at some of the mathematicians who gained fame, power, and money by finding horrendously complicated proofs, I cannot shake the impression that they often lack genuine understanding—or at least the ability to communicate understanding. If such people are replaced by machines, isn’t that simply progress?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695633")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Although doing math is certainly fun, I think most math will always be out of reach for humans or AI. Im not an expert in complexity but It seems in my experience that math Is done through brute force, and the topology of the state space one Is trying to take theorems out of can be arbitrarily convoluted.")

#text("One can always create a more complex idea out of creating some “holes” of a previous simpler one. (And It easy to imagine simplicity as continuity or analythicity)")

#text("Also, this may mean that some theorems can only be “solved by brute force” which means that there may not be a higher principle or point of view that could simplify either memory or steps in computation.")

#text("This makes math more an economical enterprise than an aesthetic one. One can of course dedícate his life to puré math for its own sake, but again, why preferring a problem in group theory over an arbitrary 1000000 real life piece puzzle? One can find aesthetics in both, and the invested love and work one puts in the 1000000 piece puzzle makes one love It even more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a32f136fc144ff270f8416c2063ecc96f9f8b0a133f7b17509a8db62a4291816-be7d069f7d5b6258b20f1a2779f7d53047043bb94a51baef2a19d70f80edebfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsotirov")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695639")[#strong[#text("alexsotirov")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Prof Gowers, this is beautifully written and I agree with almost all points in your essay, many of which I feel are essentially self evident. And my agreement with you is even if I am actually the type who prefers “leisurly reading and understanding” rather than passionate “problem solving”, which seems to be at least somewhat the opposite of your preferences. If there is anything to add it would be that even though the future of mathematics and the world seems highly uncertain at this point one possibility is that mathematics could become very clearly separated from more materialistic concerns such as having a “job” as a mathematician or anything like that and it would become a pure intelectual pursuit for those who are interested in it. Not unlike chess for example or even sport though I would more liken it to the things related to our attraction to truth and beauty so perhaps art or even religion (I am myself not religious in any traditional sense). Also AI makes advanced mathematics readily accessible to many interested people outside of tight academic circles to an extent that could not have been imagined before — this surely helps overall mathematical understanding in the world! Hopefully the contribution of AI to mathematics, which to me seems to be decidedly positive, will not be negated by AI’s overall impact on humanity which certainly has the potential to be apocalyptic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695651")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("This will be like the way Fermat practiced it. Everyone have other day jobs and spend 3 hours after dinner everyday to do math with the help of AI. The overall productivity might even increase if we have 2x hobbyists than current professionals and AI increases productivity by 2x.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695660")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("something I struggle with as a PhD student in math entering research is whether or not using ai to learn results from unfamiliar fields of math more quickly, impacts my own cognitive potential")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aa31fa006c857bb4663dcbf39edeb1630646d4b7ba011a38d2d6240bd61c330-c121414f4ab8d2b49f1ee3efb75e18d071982ee19ceb51790c3e0ada14c02c3a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695667")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I would like to provide some counter-arguments to your specific points. Specifically about an AI providing hints to aid us individually in understanding. I think others have touched on what I am about to say, but perhaps I can present my argument in a new way, that kind of goes at the heart of the start of this post about the ‘two cultures of mathematics’ and your fear about the ‘division’ between these two cultures. Because, indeed, I think this division is only being made bigger by AI.")

#text("I very much think that we should begin to more formally use various tools developed by philosophers to begin to address these meta questions. One of the thinkers who I think is most relevant to the discussion of mathematics is Immanuel Kant.")

#text("I know mathematicians sometimes do not like philosophy, but if you bare with philosophy for a single paragraph, we will get to the pragmatic stuff after. Kant introduced this distinction between a ")#link("https://en.wikipedia.org/wiki/Thing-in-itself")[#text("“thing-in-itself” and “things-for-us”")]#text(". Roughly, a thing-in-itself is an object intrinsically existing, independently of phenomenal experience, whereas a thing-for-us is an object viewed essentially as a set of properties about phenomenal experience. He argued that we are fundamentally unable to have any certainty about the existence of “things-in-themselves”: instead we can only have knowledge about “things-for-us”. However, he thought that “things-in-themselves” are essentially inevitable parts of our psychology, and that denying that it is an inevitable part of our psychology leads us to (in my words) overcomplicate things, or otherwise, means we lose all sense of direction. And specifically, “things-in-themselves” are an imagined ‘completion’ of something that is inherently incomplete, so that they are in some sense a fiction (either an epistomological fiction, or metaphysical one, or both)")

#text("I think this view is extremely helpful for understanding mathematics. A specific example is the concept of infinity. Kant would say that we cannot know if infinite cardinals have any intrinsic existence independently of experience, but that they appear to as aspects of experience (when we think about infinite objects, we have some phenomenal experience in the form of thoughts, or maybe some picture in our mind like the number line, or e.g. a tree diagram in the case of surreal numbers etc). Nevertheless, even if infinite objects are a fiction, they are far more useful than not, and being dogmatic about their lack of existence can sometimes “overcomplicate” things. Infinity also fits into his idea of these metaphysical truths as ‘completions’ of a process that is incomplete (like counting).")

#text("Suffice it to say, that in the 21st century, I think many mathematicians successfully bounce between thinking in mathematical objects “things-for-us” (essentially analytic fictions/aspects of our mind or experience) and “things-in-themselves” (intrinsically existent objects) all the time, even if individual mathematicians may disagree about which one or the other is actually real, we use each view as tools to do mathematics.")

#text("What does this have to do with the two cultures of mathematics and this AI discussion? Well, I think before the 19th/20th century crisis in mathematics: before the discovery that Euclids first 4 axioms had other models, and before Gödel’s incompleteness theorems and Tarski’s undefinability theorem, there was a unifying force that dissolved the two cultures of mathematics entirely, that is, ")#emph[#text("mathematics was about finding mathematical truths")]#text(". Traditionally, at least, gaining mathematical truths is in some sense what understanding is all about, and its also, I think, what ‘problem-solving’ is about. In this way, truth unifies the two cultures.")

#text("The issue, of course, is that because of the Formalist movement, we no longer have this elegant solution to the problem of “what is the goal of mathematics”. And that, as a result, we view mathematical ‘truth’ as superfluous.")

#text("This is what creates a separation between the two cultures of mathematics, because we have to find some other criterion for ‘the goal of mathematics’. Some will say it is this other thing “understanding”. Some will say its “problem solving”, and these are seen as separate, and perhaps diametrically opposed, because, well, what are they leading to? Understanding to what end? Problem solving to what end? As we understand more and more, and solve more and more problems, when does it end? Where are we going?")

#text("Tarski’s undefinability theorem, together with the formalist movement, essentially banished Truth itself as a mathematical subject, and it seems like it is mostly only studied by those who identify as philosophers today (although sometimes mathematical truth is studied by philosophers of mathematics).")

#text("However, what I want to propose is that this is only a result of viewing truth as a “thing-in-itself” instead of a “thing-for-us”. We banish it, and think of it as actually not existing, instead of accepting that it is an inevitable part of our psychology. And as a result we overcomplicate things and lose our sense of direction. In other words, much like infinity, I think perhaps it is possible to re-introduce truth into mathematics as a guide for what mathematics is really about. As an answer to the questions “Understanding to what end?” and “Problem solving to what end?”. I think the simple statement that “mathematics is about finding mathematical truths” is an extremely elegant solution to the problems we face, that in some sense unifies both cultures of mathematics, and also makes clear much of the trepidation about AI in mathematics (which I will try to explain below, but I think others have explained some of this in this thread, although perhaps rather angrily).")

#text("I think we can, with some work and discussion from the mathematical community, come to some agreement on some properties of what we mean by ‘mathematical truth’. ")#emph[#text("Without ")]#text("making metaphysical commitments about it. Because I think this can be viewed as a ‘convenient fiction’ even by those who dont believe in such a thing as ‘mathematical truths’, in much the same way that infinity is still used by finitists because it is useful to help us solve problems. And in the same way that mathematicians bounce between thinking in terms of “things-in-themselves” and “things-for-us”")

#text("Indeed, I think mathematical truth helps us solve a different kind of problem even if you dont believe in it: the problem of alignment within the mathematical community.")

#text("But can we align an AI towards mathematical truth?")

#text("Well, to me, I think even without pinning down a specific sense of what ‘truth’ is, all signs point to ‘no’. We cannot align AI towards truth. This, I think, has essentially been proven, by considering Tarski’s undefinability theorem, combined with its ")#link("https://iep.utm.edu/liar-paradox/#SH1a")[#text("strengthened versions")]#text(". Any AI is definable in any first order theory, and in set theory at least, the limit of any computable sequence of AI states is also definable. In other words, an AI cannot computably approach truth. For this argument, we do not even have to assume that set theory is ‘sound’, only that it is consistent. AFAIK, all of ")#link("https://iep.utm.edu/liar-paradox/#H3")[#text("the common ways to resolve the paradox")]#text(" either deflate truth entirely (which does not help us in this crisis), are prone to the strengthened liars paradox, or introduce notions of truth that we cannot computably handle. Indeed, I am fairly sure this argument is pretty robust even if we assume the sequence of AI states is not definable, if we move outside of a formalist paradigm.")

#text("So, what is the problem with AI ‘hints’ in terms of aiding understanding? Well, ‘understanding’ is, as we have talked about it here, about obtaining mathematical truths. However, an AI is unlikely to be aligned towards truth. Instead, it can at best be aligned towards making us think it is aligned towards truth.")

#text("In general, this is also the issue with AI aiding in collective understanding. If we adopt this convenient fiction of mathematical truth, even if we assume that there are no bugs in the formal proof assistant that AI uses, we do not have any agreement as a community about whether or not the axioms we are using and the deduction rules of the proof assistant actually prove true statements. Some people think that a truly sound formal system needs to be higher order, others think that we need axioms that allow for non-well founded semantics (even though we can say we can prove the isomorphic sentences in a theory without non-well founded semantics, this doesnt mean these sentences represent the same propositions) Moreover, we do not know if the definitions or abstractions an AI makes are defining truly existent objects or are being interpreted by the AI in a truthful way. And again, we cannot ‘align’ the AI towards truth, so we do not know if its choice of problems or its manor of solving problems are actually meant to aid in attaining truth (either us attaining truth, or it) or for some other goal.")

#text("This does not mean that AI cannot be helpful, but it does mean that we need to reignite these discussions about what mathematical truth ")#emph[#text("is")]#text(" to us. We need to actually engage with the discussion instead of just saying “everything will be fine”.")

#text("I think this would help us align with ourselves, and get everyone on the same page. Even if we do not agree that “mathematical truth” is a “thing-in-itself”, we can actually prove a lot of objective facts about “mathematical truth” and have a productive discussion about it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-695818")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Yes, we would lose the particularly deep level of understanding and ownership that comes with having solved a hard problem oneself, but it isn’t clear to me that progress in mathematics would suffer as a result. I would be very interested to hear counterarguments to precisely this point.")
]

#text("There seems to be a fundamental misunderstanding, highlighted by this request. The concern in the letter from the field metallists is not that “progress in mathematics would suffer”. The concern is that humans will be left behind, not knowing what’s going on in the field at all. Sure, AI likely can continue to add to the corpus of mathematics without major human input. But the whole point of the letter is that “progress in mathematics” is not the goal; human understanding of mathematics is the goal.")

#text("It’s not unlike the problem in literature; sure, AI can write stories now. But producing stories was never the goal of literature; sharing of human experience is the goal. Similarly, in mathematics, finding proofs is not the goal, human understanding of those proofs and the surrounding mathematics is the goal.")

#text("One might well respond to this with this notion that there’s a spectrum of mathematicians and a large portion of them do indeed spend all of their time on proofs. I would point out, in turn, that most novelists do spend their time on writing stories, but, again, that doesn’t make producing stories the goal. I would ask somebody who thinks that their goal has nothing to do with human understanding… then why are you looking for a proof at all? What’s the point of this endeavor, if not human understanding?")

#text("As an extra note, I would also point out that even if we take the “mathematicians are a spectrum” thing at face value… that this post still leaves those mathematicians on the other end of the spectrum hung out to dry, as though they and their goal of human understanding don’t matter because that’s just not the writer’s personal thing. That seems a bit shallow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca23fec2cf08eeff39c712b5bdaf18359b87261f72fa6c3780c853438066f02a-892acf2d83449fa1403ad43ea0593c408df8c1af5044c37959904ab3bb4cd616.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-696152")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Thank you for this thorough review. I think that the way forward, for mathematicians and all society, goes through tackling generally the pending superiority of AI in (almost) all mental tasks. Humanity has for centuries adapted to new technology without a systematic method: many activities once carried out by humans have disappeared as such. Humans responded in an ad hoc way, whether individually or collectively: prominently, we humans have gradually had more leisure time, and developed activities to occupy ourselves. We also have had less professional physical activity, and developed leisure sports. As a consequence games take up more of our times than in centuries past. In physical games like football there’s a chance that humans/animals remain forever dominant over more rigid (lower entropy and less modular) machines; machines will usually be stronger, but probably always with less endurance; all this for physical reasons. But this is really not so important: from a motivational and philosophical perspective humans “feel” chess or (other) video games, where machine dominates, pretty much like they view physical sports")

#text("When i speak of tackling replacement by AI generally, i have in mind extending such an attitude to all domains: humans should gamify/competify all activities, regardless of whether they are (still) better than machines at them or whether they are still necessary for economic activity in the sense of producing goods and services for direct subsistence and comfort. In other words i propose that we humans generally begin to view all our activities as unnecessary, conducted “pour l’honneur de l’esprit human” – ironically Jacobi likely didnt imagine that humans would worry so much about becoming economically useless as mathematicians. And that we should still compete among humans in all domains. In particular in mathematics; which way is not clear though, and it may be harder than to find good ways to compete in mathematics than in other human activities")

#text("Single-day problem solving competition have been thoroughly explored, and they’re very useful. The more difficult part is months- and lifelong research, where motivation and research is complex, mixed with all aspects of life, where judging result is also complex, and where even the selection of problems is complex. One avenue to explore, mentioned by others, is that of understanding and structuring mathematical knowledge: it takes effort even knowing technical results to produce good pedagogy, in various forms and at various levels. Another would be to develop trust and/or complex ways of verifying that a given mathematician has produced some results without resorting to AI: technically this is not difficult if one can trace competitors’ access to AI, but that would breach privacy – though if monitoring is done by AI, as opposed to other humans, it may be acceptable")

#text("But AI would be accessed to some extent at least, if only for routine web searches, so the monitoring will probably not be binary, nor even qualitative. Conceivably we could judge how much a given researcher/competitor has used AI assistance, even without monitoring his/her computer access: the presentation of his/her results could yield sufficient insight, perhaps accompanied by personal recollections of the process, a sort of diary. Thinking about it the idea of a research diary could make verification to very high confidence possible, even without intrusive monitoring. AIs could even judge such research reports better than humans, who are already quite good at judging each other in such matters, and detecting intellectual fraud")

#text("The organization of mathematics, as a social process, would evolve, with a division of labors into old and some new categories: single-day competitions would remain, but there would be longer and open-problem competitions, there would also be organization and pedagogy of AI-generated knowledge. Possibly other tasks too creating their own category")

#text("As of today, i think the general issue of AI replacing humans is manageable without immense efforts or collective pain – though many individuals will suffer -, in particular along the lines sketched above for mathematics, and other scientific fields. But it will necessitate collective action, if only that of discussing those issues and finding informal consensuses on them")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d274b808ebe358f7f3118b8207767730d199df192d8d0c8a21298a966573bd25-854a57d6be8ef3f5947a86360bc0812670a05ff78c5e48fa3ff463617dabc19c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dayanidhan")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-696221")[#strong[#text("dayanidhan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Whilst I agree with the post for the most part, I do believe the comment on accreditation is too brashly claimed. Specifically:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Very soon, the whole “credit system” will surely collapse, since finding an amazing proof will be no more of an intellectual achievement than when a citizen scientist spots through their telescope an object that turns out to be a new comet.")
]

#text("It is not that I claim the counterfactual (I am rather unqualified and unsure whether this will turn out to be the case), but that you seem to claim that mathematics can be an intellectually stimulating career path in the future.")

#text("I ")#emph[#text("think")]#text(" most mathematicians can agree that intellectual stimulation is a necessary condition for them to pursue the field, and as such, convincing PhD students that it is worthy pursuit would be impossible without it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/17/why-i-didnt-sign-the-fields-medallists-letter/comment-page-1/#comment-697309")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("What do Fields Medal winners actually write about? They champion an ideal that hasn’t existed for a long time—universities have become social institutions that reward their members, in some cases, with lavish and secure salaries. It’s no exaggeration to say that around 90% of publications are bul***it—they have only one goal: to help the authors graduate. Now that a system is delivering real results—people are complaining—and worse still: they’re accusing the obviously superior party of having ulterior motives—and suddenly they’re turning into socialists.")
]
