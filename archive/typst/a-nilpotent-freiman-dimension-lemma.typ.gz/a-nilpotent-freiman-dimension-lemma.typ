// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/21/a-nilpotent-freiman-dimension-lemma/
// Converted to Typst by tao2typ: "2026-10-14T16:36:45.511096+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A nilpotent Freiman dimension lemma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A nilpotent Freiman dimension lemma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/21/a-nilpotent-freiman-dimension-lemma/")[#text("https://terrytao.wordpress.com/2011/12/21/a-nilpotent-freiman-dimension-lemma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Emmanuel Breuillard, Ben Green and I have just uploaded to the arXiv the short paper “")#link("http://arxiv.org/abs/1112.4174")[#text("A nilpotent Freiman dimension lemma")]#text("“, submitted to the special volume of the ")#link("http://www.journals.elsevier.com/european-journal-of-combinatorics/")[#text("European Journal of Combinatorics")]#text(" in honour of Yahya Ould Hamidoune. This paper is a nonabelian (or more precisely, nilpotent) variant of the following additive combinatorics lemma of Freiman:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Freiman’s lemma. ")]#text("Let A be a finite subset of a Euclidean space with ")#tao-math("\\left|A+A\\right| \\leq K\\left|A\\right|", block: false)#text(". Then A is contained in an affine subspace of dimension at most ")#mi("{}\\lfloor K-1 \\rfloor")#text(".")
]

#text("This can be viewed as a “cheap” version of the more well known theorem of Freiman that places sets of small doubling in a torsion-free abelian group inside a generalised arithmetic progression. The advantage here is that the bound on the dimension is extremely explicit.")

#text("Our main result is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" Let A be a finite subset of a simply-connected nilpotent Lie group G which is a K-approximate group (i.e. A is symmetric, contains the identity, and ")#mi("A \\cdot A")#text(" can be covered by up to K left translates of A. Then A can be covered by at most ")#mi("K^{2+29K^9}")#text(" left-translates of a closed connected Lie subgroup of dimension at most ")#mi("K^9")#text(".")
]

#text("We remark that ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("our previous paper")]#text(" established a similar result, in which the dimension bound was improved to ")#mi("6\\log_2 K")#text(", but at the cost of worsening the covering number to ")#mi("O_K(1)")#text(", and with a much more complicated proof (91 pages instead of 8). Furthermore, the bound on ")#mi("O_K(1)")#text(" is ineffective, due to the use of ultraproducts in the argument (though it is likely that some extremely lousy explicit bound could eventually be squeezed out of the argument by finitising everything). Note that the step of the ambient nilpotent group G does not influence the final bounds in the theorem, although we do of course need this step to be finite. A simple quotienting argument allows one to deduce a corollary of the above theorem in which the ambient group is assumed to be residually torsion-free nilpotent instead of being a simply connected nilpotent Lie group, but we omit the statement of this corollary here.")

#text("To motivate the proof of this theorem, let us first show a simple case of an ")#link("http://www.ams.org/mathscinet-getitem?mr=43102")[#text("argument of Gleason")]#text(", which is very much in the spirit of Freiman’s lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Gleason Lemma (special case).")]#text(" Let ")#mi("A")#text(" be a finite symmetric subset of a Euclidean space, and let ")#mi("0 = H_0 \\subset H_1 \\subset \\ldots \\subset H_k")#text(" be a sequence of subspaces in this space, such that the sets ")#mi("2A \\cap H_i")#text(" are strictly increasing in i for ")#mi("i=0,\\ldots,k")#text(". Then ")#tao-math("\\left|5A\\right| \\geq k\\left|A\\right|", block: false)#text(", where ")#mi("5A = A+A+A+A+A")#text(".")
]

#strong[#text("Proof.")]#text(" By hypothesis, for each ")#mi("i=1,\\ldots,k")#text(", the projection ")#mi("B_i")#text(" of ")#mi("2A \\cap H_i")#text(" to ")#mi("H_i / H_{i-1}")#text(" is non-trivial, finite, and symmetric. In particular, since the vector space ")#mi("H_i/H_{i-1}")#text(" is torsion-free, ")#mi("B_i+B_i")#text(" is strictly larger than ")#mi("B_i")#text(". Equivalently, one can find ")#mi("a_i")#text(" in ")#mi("(2A \\cap H_i) + (2A \\cap H_i)")#text(" that does not lie in ")#mi("(2A \\cap H_i) + H_{i-1}")#text("; in particular, ")#mi("a_i \\in 4A \\cap H_i")#text(" and ")#mi("a_i+A")#text(" is disjoint from ")#mi("H_{i-1}+A")#text(". As a consequence, the ")#mi("a_i+A")#text(" are disjoint and lie in 5A, whence the claim. ")#mi("\\Box")

#text("Note that by combining the contrapositive of this lemma with a greedy algorithm, one can show that any K-approximate group in a Euclidean space is contained in a subspace of dimension at most ")#mi("K^4")#text(", which is a weak version of Freiman’s lemma.")

#text("To extend the argument to the nilpotent setting we use the following idea. Observe that any non-trivial genuine subgroup H of a nilpotent group G will contain at least one non-trivial central element; indeed, by intersecting H with the lower central series ")#mi("G = G_1 \\geq G_2 \\geq G_3 \\geq \\ldots")#text(" of G, and considering the last intersection ")#mi("H \\cap G_k")#text(" which is non-trivial, one obtains the claim. It turns out that one can adapt this argument to approximate groups, so that any sufficiently large K-approximate subgroup A of G will contain a non-trivial element that centralises a large fraction of A. Passing to this large fraction and quotienting out the central element, we obtain a new approximate group. If, after a bounded number of steps, this procedure gives an approximate group of bounded size, we are basically done. If, however, the process continues, then by using some Lie group theory, one can find a long sequence ")#mi("H_0 \\leq H_1 \\leq \\ldots \\leq H_k")#text(" of connected Lie subgroups of G, such that the sets ")#mi("A^2 \\cap H_i")#text(" are strictly increasing in i. Using some Lie group theory and the hypotheses on G, one can deduce that the group ")#mi("\\langle A^2 \\cap H_{i+1}\\rangle")#text(" generated by ")#mi("A^2 \\cap H_{i+1}")#text(" is much larger than ")#mi("\\langle A^2 \\cap H_i \\rangle")#text(", in the sense that the latter group has infinite index in the former. It then turns out that the Gleason argument mentioned above can be adapted to this setting.")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/21/a-nilpotent-freiman-dimension-lemma/#comment-117808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2011")])]

#text("Missing paper tag?")

#emph[#text("[Added, thanks – T.]")]
]
