// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/
// Converted to Typst by tao2typ: "2026-10-14T15:20:20.546873+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quantitative bounds for critically bounded solutions to the Navier-Stokes equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quantitative bounds for critically bounded solutions to the Navier-Stokes equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 August 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/")[#text("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1908.04958")[#text("Quantitative bounds for critically bounded solutions to the Navier-Stokes equations")]#text("“, submitted to the proceedings of the ")#link("http://pma.caltech.edu/linde-hall-inaugural-math-symposium")[#text("Linde Hall Inaugural Math Symposium")]#text(". (I unfortunately had to cancel my physical attendance at this symposium for personal reasons, but was still able to contribute to the proceedings.) In recent years I have been interested in working towards establishing the existence of classical solutions for the Navier-Stokes equations")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = \\Delta u - \\nabla p", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("that blow up in finite time, but this time for a change I took a look at the other side of the theory, namely the conditional regularity results for this equation. There are several such results that assert that if a certain norm of the solution stays bounded (or grows at a controlled rate), then the solution stays regular; taken in the contrapositive, they assert that if a solution blows up at a certain finite time ")#mi("{T_*}")#text(", then certain norms of the solution must also go to infinity. Here are some examples (not an exhaustive list) of such blowup criteria:")

#list(
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1555394")[#text("Leray")]#text(" blowup criterion, 1934) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", and ")#mi("{3 < p \\leq \\infty}")#text(", then ")#tao-math("{\\liminf_{t \\rightarrow T_*} (T_* - t)^{\\frac{1}{2}-\\frac{3}{2p}} \\left\\| u(t) \\right\\|_{L^p_x({\\bf R}^3)} \\geq c}", block: false)#text(" for an absolute constant ")#mi("{c>0}")#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=126088")[#text("Prodi")]#text("–")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=136885")[#text("Serrin")]#text("–")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=236541")[#text("Ladyzhenskaya")]#text(" blowup criterion, 1959-1967) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", and ")#mi("{3 < p \\leq \\infty}")#text(", then ")#tao-math("{\\left\\| u \\right\\|_{L^q_t L^p_x([0,T_*) \\times {\\bf R}^3)} =+\\infty}", block: false)#text(", where ")#mi("{\\frac{1}{q} := \\frac{1}{2} - \\frac{3}{2p}}")#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=763762")[#text("Beale-Kato-Majda")]#text(" blowup criterion, 1984) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\left\\| \\omega \\right\\|_{L^1_t L^\\infty_x([0,T_*) \\times {\\bf R}^3)} = +\\infty}", block: false)#text(", where ")#mi("{\\omega := \\nabla \\times u}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Vorticity")[#text("vorticity")]#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=760047")[#text("Kato")]#text(" blowup criterion, 1984) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\liminf_{t \\rightarrow T_*} \\left\\|u(t) \\right\\|_{L^3_x({\\bf R}^3)} \\geq c}", block: false)#text(" for some absolute constant ")#mi("{c>0}")#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1992563")[#text("Escauriaza-Seregin-Sverak")]#text(" blowup criterion, 2003) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\limsup_{t \\rightarrow T_*} \\left\\|u(t) \\right\\|_{L^3_x({\\bf R}^3)} = +\\infty}", block: false)#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1992563")[#text("Seregin")]#text(" blowup criterion, 2012) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\lim_{t \\rightarrow T_*} \\left\\|u(t) \\right\\|_{L^3_x({\\bf R}^3)} = +\\infty}", block: false)#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3412277")[#text("Phuc")]#text(" blowup criterion, 2015) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\limsup_{t \\rightarrow T_*} \\left\\|u(t) \\right\\|_{L^{3,q}_x({\\bf R}^3)} = +\\infty}", block: false)#text(" for any ")#mi("{q < \\infty}")#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3475661")[#text("Gallagher-Koch-Planchon")]#text(" blowup criterion, 2016) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\limsup_{t \\rightarrow T_*} \\left\\|u(t) \\right\\|_{\\dot B_{p,q}^{-1+3/p}({\\bf R}^3)} = +\\infty}", block: false)#text(" for any ")#mi("{3 < p, q < \\infty}")#text(".")],
[#text("(")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3803715")[#text("Albritton")]#text(" blowup criterion, 2016) If ")#mi("{u}")#text(" blows up at a finite time ")#mi("{T_*}")#text(", then ")#tao-math("{\\lim_{t \\rightarrow T_*} \\left\\|u(t) \\right\\|_{\\dot B_{p,q}^{-1+3/p}({\\bf R}^3)} = +\\infty}", block: false)#text(" for any ")#mi("{3 < p, q < \\infty}")#text(".")]
)

#text("My current paper is most closely related to the Escauriaza-Seregin-Sverak blowup criterion, which was the first to show a critical (i.e., scale-invariant, or dimensionless) spatial norm, namely ")#mi("{L^3_x({\\bf R}^3)}")#text(", had to become large. This result now has many proofs; for instance, many of the subsequent blowup criterion results imply the Escauriaza-Seregin-Sverak one as a special case, and there are also additional proofs by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3037023")[#text("Gallagher-Koch-Planchon")]#text(" (building on ideas ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2784068")[#text("of Kenig-Koch")]#text("), and by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2551795")[#text("Dong-Du")]#text(". However, all of these proofs rely on some form of a compactness argument: given a finite time blowup, one extracts some suitable family of rescaled solutions that converges in some weak sense to a limiting solution that has some additional good properties (such as almost periodicity modulo symmetries), which one can then rule out using additional qualitative tools, such as unique continuation and backwards uniqueness theorems for parabolic heat equations. In particular, all known proofs use some version of the backwards uniqueness ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2005639")[#text("theorem of Escauriaza, Seregin, and Sverak")]#text(". Because of this reliance on compactness, the existing proofs of the Escauriaza-Seregin-Sverak blowup criterion are qualitative, in that they do not provide any quantitative information on how fast the ")#tao-math("{\\left\\|u(t)\\right\\|_{L^3_x({\\bf R}^3)}}", block: false)#text(" norm will go to infinity (along a subsequence of times).")

#text("On the other hand, it is a general principle that qualitative arguments established using compactness methods ought to have quantitative analogues that replace the use of compactness by more complicated substitutes that give effective bounds; see for instance ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("previous")]#text(" blog posts for more discussion. I therefore was interested in trying to obtain a quantitative version of this blowup criterion that gave reasonably good effective bounds (in particular, my objective was to avoid truly enormous bounds such as tower-exponential or Ackermann function bounds, which often arise if one “naively” tries to make a compactness argument effective). In particular, I obtained the following triple-exponential quantitative regularity bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" If ")#mi("{u}")#text(" is a classical solution to Navier-Stokes on ")#mi("{[0,T) \\times {\\bf R}^3}")#text(" with ")#metadata(none) <tao-844bc172f032bdd2d0ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| u \\right\\|_{L^\\infty_t L^3_x([0,T) \\times {\\bf R}^3)} \\leq A", block: true)]]



#text(" for some ")#mi("{A \\geq 2}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left| \\nabla^j u(t,x)\\right| \\leq \\exp\\exp\\exp(A^{O(1)}) t^{-\\frac{j+1}{2}}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left| \\nabla^j \\omega(t,x)\\right| \\leq \\exp\\exp\\exp(A^{O(1)}) t^{-\\frac{j+2}{2}}", block: true)]]

#text("for ")#mi("{(t,x) \\in [0,T) \\times {\\bf R}^3}")#text(" and ")#mi("{j=0,1}")#text(".")
]

#text("As a corollary, one can now improve the Escauriaza-Seregin-Sverak blowup criterion to")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{t \\rightarrow T_*} \\frac{\\left\\|u(t) \\right\\|_{L^3_x({\\bf R}^3)}}{(\\log\\log\\log \\frac{1}{T_*-t})^c} = +\\infty", block: true)]]

#text("for some absolute constant ")#mi("{c>0}")#text(", which to my knowledge is the first (")#emph[#text("very")]#text(" slightly) supercritical blowup criterion for Navier-Stokes in the literature.")

#text("The proof uses many of the same quantitative inputs as previous arguments, most notably the Carleman inequalities used to establish unique continuation and backwards uniqueness theorems for backwards heat equations, but also some additional techniques that make the quantitative bounds more efficient. The proof focuses initially on points of concentration of the solution, which we define as points ")#mi("{(t_0,x_0)}")#text(" where there is a frequency ")#mi("{N_0}")#text(" for which one has the bound ")#metadata(none) <tao-fd85bea45364587289dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|N_0^{-1} P_{N_0} u(t_0,x_0)\\right| \\geq A^{-C_0}", block: true)]]



#text(" for a large absolute constant ")#mi("{C_0}")#text(", where ")#mi("{P_{N_0}}")#text(" is a Littlewood-Paley projection to frequencies ")#mi("{\\sim N_0}")#text(". (This can be compared with the upper bound of ")#mi("{O(A)}")#text(" for the quantity on the left-hand side that follows from ")#link(<tao-844bc172f032bdd2d0ba>)[#text("(1)")]#text(".) The factor of ")#mi("{N_0^{-1}}")#text(" normalises the left-hand side of ")#link(<tao-fd85bea45364587289dd>)[#text("(2)")]#text(" to be dimensionless (i.e., critical). The main task is to show that the dimensionless quantity ")#mi("{t_0 N_0^2}")#text(" cannot get too large; in particular, we end up establishing a bound of the form")

#align(center)[#tao-fit-display[#mitex("t_0 N_0^2 \\lesssim \\exp\\exp\\exp A^{O(C_0^6)}")]]

#text("from which the above theorem ends up following from a routine adaptation of the local well-posedness and regularity theory for Navier-Stokes.")

#text("The strategy is to show that any concentration such as ")#link(<tao-fd85bea45364587289dd>)[#text("(2)")]#text(" when ")#mi("{t_0 N_0^2}")#text(" is large must force a significant component of the ")#mi("{L^3_x}")#text(" norm of ")#mi("{u(t_0)}")#text(" to also show up at many other locations than ")#mi("{x_0}")#text(", which eventually contradicts ")#link(<tao-844bc172f032bdd2d0ba>)[#text("(1)")]#text(" if one can produce enough such regions of non-trivial ")#mi("{L^3_x}")#text(" norm. (This can be viewed as a quantitative variant of the “rigidity” theorems in some of the previous proofs of the Escauriaza-Seregin-Sverak theorem that rule out solutions that exhibit too much “compactness” or “almost periodicity” in the ")#mi("{L^3_x}")#text(" topology.) The chain of causality that leads from a concentration ")#link(<tao-fd85bea45364587289dd>)[#text("(2)")]#text(" at ")#mi("{(t_0,x_0)}")#text(" to significant ")#mi("{L^3_x}")#text(" norm at other regions of the time slice ")#mi("{t_0 \\times {\\bf R}^3}")#text(" is somewhat involved (though simpler than the much more convoluted schemes I initially envisaged for this argument):")

#enum(start: 1, 
[#text("Firstly, by using Duhamel’s formula, one can show that a concentration ")#link(<tao-fd85bea45364587289dd>)[#text("(2)")]#text(" can only occur (with ")#mi("{t_0 N_0^2}")#text(" large) if there was also a preceding concentration ")#metadata(none) <tao-19a5203713d686f475c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|N_1^{-1} P_{N_1} u(t_1,x_1)\\right| \\geq A^{-C_0}", block: true)]]

#text("at some slightly previous point ")#mi("{(t_1,x_1)}")#text(" in spacetime, with ")#mi("{N_1}")#text(" also close to ")#mi("{N_0}")#text(" (more precisely, we have ")#mi("{t_1 = t_0 - A^{-O(C_0^3)} N_0^{-2}}")#text(", ")#mi("{N_1 = A^{O(C_0^2)} N_0}")#text(", and ")#mi("{x_1 = x_0 + O( A^{O(C_0^4)} N_0^{-1})}")#text("). This can be viewed as a sort of contrapositive of a “local regularity theorem”, such as the ones established by Caffarelli, Kohn, and Nirenberg. A key point here is that the lower bound ")#mi("{A^{-C_0}}")#text(" in the conclusion ")#link(<tao-19a5203713d686f475c5>)[#text("(3)")]#text(" is precisely the same as the lower bound in ")#link(<tao-fd85bea45364587289dd>)[#text("(2)")]#text(", so that this backwards propagation of concentration can be iterated.")],
[#text("Iterating the previous step, one can find a sequence of concentration points ")#metadata(none) <tao-3fe3cde54dc9f3f924c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|N_n^{-1} P_{N_n} u(t_n,x_n)\\right| \\geq A^{-C_0}", block: true)]]

#text("with the ")#mi("{(t_n,x_n)}")#text(" propagating backwards in time; by using estimates ultimately resulting from the dissipative term in the energy identity, one can extract such a sequence in which the ")#mi("{t_0-t_n}")#text(" increase geometrically with time, the ")#mi("{N_n}")#text(" are comparable (up to polynomial factors in ")#mi("{A}")#text(") to the natural frequency scale ")#mi("{(t_0-t_n)^{-1/2}}")#text(", and one has ")#tao-math("{x_n = x_0 + O( \\left|t_0-t_n\\right|^{1/2} )}", block: false)#text(". Using the “epochs of regularity” theory that ultimately dates back to Leray, and tweaking the ")#mi("{t_n}")#text(" slightly, one can also place the times ")#mi("{t_n}")#text(" in intervals ")#mi("{I_n}")#text(" (of length comparable to a small multiple of ")#tao-math("{\\left|t_0-t_n\\right|}", block: false)#text(") in which the solution is quite regular (in particular, ")#mi("{u, \\nabla u, \\omega, \\nabla \\omega}")#text(" enjoy good ")#mi("{L^\\infty_t L^\\infty_x}")#text(" bounds on ")#mi("{I_n \\times {\\bf R}^3}")#text(").")],
[#text("The concentration ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(4)")]#text(" can be used to establish a lower bound for the ")#mi("{L^2_t L^2_x}")#text(" norm of the vorticity ")#mi("{\\omega}")#text(" near ")#mi("{(t_n,x_n)}")#text(". As is well known, the vorticity obeys the ")#link("https://en.wikipedia.org/wiki/Vorticity_equation")[#text("vorticity equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega = \\Delta \\omega - (u \\cdot \\nabla) \\omega + (\\omega \\cdot \\nabla) u.")]]

#text("In the epoch of regularity ")#mi("{I_n \\times {\\bf R}^3}")#text(", the coefficients ")#mi("{u, \\nabla u}")#text(" of this equation obey good ")#mi("{L^\\infty_x}")#text(" bounds, allowing the machinery of Carleman estimates to come into play. Using a Carleman estimate that is used to establish unique continuation results for backwards heat equations, one can propagate this lower bound to also give lower ")#mi("{L^2}")#text(" bounds on the vorticity (and its first derivative) in annuli of the form ")#tao-math("{\\{ (t,x) \\in I_n \\times {\\bf R}^3: R \\leq \\left|x-x_n\\right| \\leq R^{\\prime} \\}}", block: false)#text(" for various radii ")#mi("{R,R^{\\prime}}")#text(", although the lower bounds decay at a gaussian rate with ")#mi("{R}")#text(".")],
[#text("Meanwhile, using an energy pigeonholing argument ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1626257")[#text("of Bourgain")]#text(" (which, in this Navier-Stokes context, is actually an ")#link("https://en.wikipedia.org/wiki/Enstrophy")[#text("enstrophy")]#text(" pigeonholing argument), one can locate some annuli ")#tao-math("{\\{ x \\in {\\bf R}^3: R \\leq \\left|x-x_n\\right| \\leq R^{\\prime}\\}}", block: false)#text(" where (a slightly normalised form of) the entrosphy is small at time ")#mi("{t=t_n}")#text("; using a version of the localised enstrophy estimates from ")#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")[#text("a previous paper of mine")]#text(", one can then propagate this sort of control forward in time, obtaining an “annulus of regularity” of the form ")#tao-math("{\\{ (t,x) \\in [t_n,t_0] \\times {\\bf R}^3: R_n \\leq \\left|x-x_n\\right| \\leq R^{\\prime}_n\\}}", block: false)#text(" in which one has good estimates; in particular, one has ")#mi("{L^\\infty_x}")#text(" type bounds on ")#mi("{u, \\nabla u, \\omega, \\nabla \\omega}")#text(" in this cylindrical annulus.")],
[#text("By intersecting the previous epoch of regularity ")#mi("{I_n \\times {\\bf R}^3}")#text(" with the above annulus of regularity, we have some lower bounds on the ")#mi("{L^2}")#text(" norm of the vorticity (and its first derivative) in the annulus of regularity. Using a Carleman estimate first introduced by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2005639")[#text("Escauriaza, Seregin, and Sverak")]#text(", as well as a second application of the Carleman estimate used previously, one can then propagate this lower bound back up to time ")#mi("{t=t_0}")#text(", establishing a lower bound for the vorticity on the spatial annulus ")#tao-math("{\\{ (t_0,x): R_n \\leq \\left|x-x_n\\right| \\leq R^{\\prime}_n \\}}", block: false)#text(". By some basic Littlewood-Paley theory one can parlay this lower bound to a lower bound on the ")#mi("{L^3}")#text(" norm of the velocity ")#mi("{u}")#text("; crucially, this lower bound is uniform in ")#mi("{n}")#text(".")],
[#text("If ")#mi("{t_0 N_0^2}")#text(" is very large (triple exponential in ")#mi("{A}")#text("!), one can then find enough scales ")#mi("{n}")#text(" with disjoint ")#tao-math("{\\{ (t_0,x): R_n \\leq \\left|x-x_n\\right| \\leq R^{\\prime}_n \\}}", block: false)#text(" annuli that the total lower bound on the ")#mi("{L^3_x}")#text(" norm of ")#mi("{u(t_0)}")#text(" provided by the above arguments is inconsistent with ")#link(<tao-844bc172f032bdd2d0ba>)[#text("(1)")]#text(", thus establishing the claim.")]
)

#text("The chain of causality is summarised in the following image:")

#image("../assets/01c8e7dbab917be4cd0d4b4ddce542aabae605fba46ff5486fd2b609d5692ecd-06c404bc8b0bdc6a9840e8d9044205d439e3879c74fc0a9af676104da1cf1ab5.png", width: 90%, alt: "scheme")

#text("It seems natural to conjecture that similar triply logarithmic improvements can be made to several of the other blowup criteria listed above, but I have not attempted to pursue this question. It seems difficult to improve the triple logarithmic factor using only the techniques here; the Bourgain pigeonholing argument inevitably costs one exponential, the Carleman inequalities cost a second, and the stacking of scales at the end to contradict the ")#mi("{L^3}")#text(" upper bound costs the third.")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686de7c56e01b9812b7dab89e546012de642bacbe076abbb729dc42f7ff8089a-e85a696188abca866bc724d3304752748cfcf62e5c8c2de35fe8a6be3c205525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omarleoblog")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519679")[#strong[#text("omarleoblog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("Wow sir you are an amazing person. Only a genious undestands")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("In the section describing the attempt “Exploiting blowup criteria” of implementing “strategy 3” in “Why global regularity for Navier-Stokes is hard” you say that “However, all such blowup criteria are subcritical or critical in nature, and thus, barring a breakthrough in Strategy 2, the known globally controlled quantities cannot be used to reach a contradiction.” Now that you have a supercritical blowup criterion, how would you say this affects the analysis of the hardness of global regularity of Navier-Stokes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519681")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("This result would fall in the category of “Positive approach 4” in ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("the blog post")]#text(" you mention. Roughly speaking, the results here assert that in order to ensure regularity, one does not need to uniformly bound the critical norm ")#mi("L^3_x")#text("; it would suffice to bound a slightly supercritical norm such as ")#mi("L^3 (\\log\\log\\log L)^{-c}_x")#text(" (actually I don’t quite prove this statement in the paper, but I would expect it would follow from a variant of the methods used there). This is technically a little bit closer to what one would need to positively resolve the global regularity problem, namely to be able to deduce regularity from a uniform bound on just the ")#mi("L^2_x")#text(" norm, but the gap between what implies global regularity and one what can actually control is still absolutely enormous. Note that in the case of dyadic models of Navier-Stokes, it is known that slightly supercritical levels of dissipation can still establish global regularity, but significantly supercritical levels of dissipation, such as those seen in the actual 3D Navier-Stokes equations, cause blowup. So I would not view slightly supercritical results as being significant evidence towards being able to control strongly supercritical situations; instead I view them primarily as optimisations of the critical theory, which can penetrate a little bit, but not too far, into the supercritical regime.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2019")])]

#text("Dear Pro.Tao")#linebreak()#text(" I am very amusing to see your paper. You keep up your paper. A top secret from 2006 to 2019: around 13 years. So far I have wanted to tell a story that related to Pro.Tao and Perelmann. After Dr.Perelmann solved Poincare conjecture in 2006, I started to go to China in 2010 , a long journey was very hard. My aim to China is to meet the best man in the world(not mathematics).He is a wizard. He is a reclusive man not be on media, magazine.Firstly , I was very hard to meet him, but with my patient, I finally met him. Initially , I took 2 portraits of Dr.Tao and Perelmann. Obviously, he did not know who they were. I asked him that how Sir valued both of them.He answered they were the best heroes in the world. Next , I asked who was better(Obviously, he did not know Perelmann is Russian, Terence Tao is Australian). An amazing result: his finger on Terence Tao. Imediately , I had argument against him and I said Sir was wrong, Perelmann was better. I said that Perelmann solved the most difficult problem in 7 ones in the world. Now , there are only 6 ones. Terence Tao not yet. He did not wait me to say more. Sir quickly threw his pen pierce through out the picture. This made my heart thump. Sir opened big eyes and announced that Terence Tao solved 4 out of 6. For my viewpoint , I cannot affirm Sir was right or not, but to examine his talent , I asked Sir which football team would be champion in the world in 2014.Wow, Sir is a truly wizard ,the best man in the world. I got a sum of big money from betting .Thanks Sir a lot")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2019")])]

#text("“I was very hard to meet him” haha")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("Dear Tao,")#linebreak()#text(" After I read your last sentence at the end of your blog. I want to offer you an advice. I can’t give you money, diamond. I give you an uncountable thing, that is spirit. You never give up. Although I am not a mathematician, I know that you have gone 85% on the way of Navier Stokes problem. You trust me! You certainly succeed. In 2019, you will have a great surprising fun. I will give you two wings in order to make you fly higher in the sky.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("What is the precise definition of blowup at finite time ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("There are several equivalent definitions, but one would be “inability to extend the solution as a classical solution beyond that time”. (This in turn requires one to specify what a classical solution is; one definition for instance would be a solution where the velocity and pressure fields ")#mi("u,p")#text(" are smooth, and all derivatives of those fields are square-integrable in space, locally uniformly in time.) One can specify other notions of what it means to be a classical solution, but generally speaking as long as the notion involves some subcritical regularity control, they end up being essentially equivalent to each other. Once one accepts any of the blowup criteria listed in the blog post, one can then take one of those criteria to be an alternate equivalent definition for finite time blowup if one wishes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2019")])]

#text("Is there any conjecture on the magnitude of the best possible bound in theorem 1 ? (i.e. how much the triple exponential bound may be improved)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2019")])]

#text("I don’t think there is much data on this to make a good conjecture yet. Certainly the bound is at least linear, since this is what happens for the linear heat equation; it should be possible to get some sort of superlinear bound by adapting some of the illposedness theory for supercritical equations. A polynomial bound would come close to settling the global regularity conjecture in the positive (if the exponent was low enough), but is unlikely to be true. There is a small chance that one can lower the triple exponential bound to a double exponential one by somehow avoiding the use of Bourgain’s energy pigeonholing argument, but I think this would require one to use more Carleman estimates than the “off the shelf” ones that I simply took from the Escauriaza-Seregin-Sverak paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("Is it possible for the best possible bound to be sub-exponential in ")#mi("A")#text(" (e.g. ")#mi("\\exp(A^{1/2})")#text(") ?")

#emph[#text("[See my previous response – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b43f7e1ac2b10c49b744e95b8c6800e436f0b0d0b58b24c0f5b75ee323ff92bb-095e74d7ec4a62d29f1a97ad5390f6b71ea69230dce0bb8cb145ac6824ab20c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous coward")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519906")[#strong[#text("Anonymous coward")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2019")])]

#text("There’s something I just don’t understand, why bother with all this crap? There are much easier ways to earn 1 million than go for a millennium problem. What is the point of math at all? This world is all about shallowness, money, status, only a naive person who never grew out of that innocent teen mentality would waste his life on these useless and intractable problems. You publish some result that takes years in the making, only to have less than 50 people in the world who can understand it, you “live for the grudging appreciation of your few colleagues” (some famous mathematician said this can’t remember name). While savvy cunning manipulative people live in heaven on earth. I slowly saw the world for what it is, I was severely outcasted by certain people I really wanted to get to know because of my “career decisions”, and out grew that naive teen mentality, quitted this nightmare years ago. People like you Terry and my supervisors… Will never understand you people.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3f20c74bab8e9d6a83262761333ad2d848e1dff2cc6b1a338ae201de88316f1-4593ae86a5bad9440eaee17f13464586d5031e6d3c022725c6ed3d6653c00f7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Eve")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519916")[#strong[#text("Michel Eve")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("What a stupid comment ! If you wonder about the usefulness of doing research in Math then why do you bother reading this blog ? You are very lucky that your inapropriate comment has not been removed…especially coming from an anonymous coward.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("You are extremely wrong. Pro.Tao do not need money. Conquering the best problems in the world is from his love of math when he was childhood. If he needs money(Maybe Pro.Tao has gotten Abel prize( nearly $ 1 million) in recent years,but he is humble, he yields to other man. You should not ask me why reason I know. With his famous name in the world, he makes money very easily")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49b34b13fca1197d61a5091a36e9227664c33e414a2a779648d56739b6d16e78-1424087395bf800b7cb4833ae9085fb47a60ab8a11139d049fb6e89ae6be224d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ari")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-522345")[#strong[#text("Ari")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("I don’t know if you are trolling but I will respond.")

#text("1. He is not in it for the money, duh. This may be hard for “normal” people to understand but some people just love math just like some people love baseball.")

#text("2. He is doing less selfish thing than making millions and you are blaming him for what? I don’t think he is savvy-cunning, if he was, he’d making millions in finance or something. In fact he is the complete opposite. Savvy-cunning-manipulative people don’t spend decades working on math problems that don’t pay returns.")

#text("3. I do agree that people need to but cut out from any naive teen mentality, that eg. doing hard math work will make you happy. People who want to do serious research might end up unhappy, depressed or even on the street. But this message should be to the young guys not to Tao.")

#text("4. Be happy that there are people working on these hard problems. Even though a lot of math will have relatively less value, almost all it increases in utility some way. For example solving Navier-Stokes-Eq. might make for better and safer turbines for airplanes, or even help model blood flow in human veins etc. Without Fourier and other transforms we wouldn’t have MRI or digital imaging etc.")

#text("p.s. Stop contaminating his fine blog with these bad comments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a0e6502bda5598edff524bd4ad024b5204d3f42f6114419f3106b80634cc77-e22283622784c05b612c2da8aefe7319e0cd8dcc8195b77461ee1c48fe2a9ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m.r.s")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519945")[#strong[#text("m.r.s")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("Hi pro. tao")#linebreak()#text(" Please write a complete book on the Navier-Stokes equation. that book should have:")

#text("1.A book that deals with the details and prerequisites of this equation!")#linebreak()#text(" 2. The book is simple and detailed!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a0e6502bda5598edff524bd4ad024b5204d3f42f6114419f3106b80634cc77-e22283622784c05b612c2da8aefe7319e0cd8dcc8195b77461ee1c48fe2a9ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m.r.s")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519946")[#strong[#text("m.r.s")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("Many books have been written about Navier Stokes equations. But they are not perfect at all. Not for beginners.")#linebreak()#text(" Please write a book for beginners on Navier Stokes equations.")#linebreak()#text(" For example with this title : “Navier Stokes equations for beginners”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a0e6502bda5598edff524bd4ad024b5204d3f42f6114419f3106b80634cc77-e22283622784c05b612c2da8aefe7319e0cd8dcc8195b77461ee1c48fe2a9ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m.r.s")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519947")[#strong[#text("m.r.s")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2019")])]

#text("Such a book will surely be very bulky. Maybe 1000 pages!!!!!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("Thanks for the Note.")#linebreak()#text(" Can you express or refer us to rigorous definitions and distinctions between")

#text("a) Blow-up")#linebreak()#text(" b) Singularity")#linebreak()#text(" c) Uniqueness")#linebreak()#text(" d) Well-posed")#linebreak()#text(" e) Regularity")

#text("I can see these terms have been used interchangeably sometimes. And please let us know what have not been proven yet.")

#text("If the initial condition for 3D NS is small (in some norms), seems that the solution remains bounded. If yes, what is left to be proven in existence and uniqueness.")

#text("Thanks again,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("I forgot to mention that, it has been proved that the weak solution for Navier Stokes is not unique. Is there any consequence on convergence to the strong solution.")#linebreak()#text(" Thanks,")#linebreak()#text(" Mahdi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519985")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("The short answer is “it’s complicated”.")

#text("A technical discussion of some of the basic results and concepts can be found for instance in ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("my recent")]#text(" ")#link("https://terrytao.wordpress.com/category/teaching/254a-incompressible-fluid-equations/")[#text("lecture notes")]#text(" on this topic. But for the abridged version: first one has to select a solution concept, which can range all the way from classical solutions (smooth and decaying in space) to weak solutions (only solving the solution in a distributional sense), with a number of intermediate notions of solution that have been studied (e.g. Leray-Hopf weak solution, suitable weak solution, Fujita-Kato mild solution, etc.). One also as to select am matching class of initial data (e.g., smooth data, finite energy data, etc.). Once one has chosen a solution concept and an initial data class, then")

#enum(start: 1, 
[#text("Existence means that for a given choice of initial data in the given class, there is at least one solution of the required type with this initial data. This can either be local existence (on some finite time interval) or global existence (on the time half-line ")#mi("[0,+\\infty)")#text(").")],
[#text("Uniqueness means that for a given choice of initial data, there is at most one solution of the required type on a given time interval. One can make a distinction between local uniqueness and global uniqueness, but in most circumstances the two are logically equivalent.")],
[#text("Well-posedness means that solutions exist, are unique, and also depend continuously on the initial data (with respect to some specified topology). It also comes in local and global flavours (in the local case there are some finer subtleties regarding how the time of existence is required to depend on the initial data, which I will gloss over here). By upgrading the notion of continuity to uniform continuity, ")#mi("C^1")#text(" differentiability, etc., one can talk about uniform well-posedness, ")#mi("C^1")#text("-wellposedness, etc..")],
[#text("Regularity means that if the initial data is regular, then the solution is also. (there is some flexibility in what one chooses “regular” to mean; one could for instance take it to mean “smooth”, or other times one uses some other concept of regularity, such as Holder space regularity).")],
[#text("Blowup means that the solution exits the solution concept at the final time of existence (which could be either finite or infinite) in a specified way, most typically by a certain space or spacetime norm becoming infinite. It implies lack of existence (within this solution concept) beyond the final time, but gives a more precise description of exactly why existence breaks down. (In some other equations, such as general relativity, one can occasionally come across the phenomenon of a solution being unable to be continued beyond a certain point while still remaining smooth, so that one can have lack of existence without blowup; the “strong cosmic censorship hypothesis” asserts that this does not happen generically for this equation, but it is known that it can happen for very special solutions.)")],
[#text("Singularities are locations in space or spacetime where the solution (or some completion of the solution to the final time of existence) fails to be regular.")]
)

#text("As it turns out for Navier-Stokes, solution concepts basically divide into two types, “strong solutions” and “weak solutions”. For strong solutions, one typically has local existence, uniqueness, well-posedness and regularity but global existence or regularity is not known unless one is in a perturbative regime the initial data is very close to zero (or very close to some other well understood initial state); if the solution is not global, then there are various blowup criteria, such as the ones listed in the blog post, which then demonstrate various types of blowup and singularity formation at the final time of existence. For weak solutions, uniqueness, well-posedness and regularity are either false or not known unconditionally (it depends on the precise weak solution concept), but there are conditional results such as “weak-strong uniqueness” results. Also, for weak solutions one typically has global existence (so in particular weak solutions usually do not “blow up” so badly that they exit the category of weak solutions), and some partial information is known about the singularities (e.g., control on the Hausdorff dimension of the singular set).")

#text("Weak solutions typically arise as weak limits of strong solutions with high frequency forcing terms. A non-uniqueness result for weak solutions then indicates that some sequences of strong solutions with high frequency forcing terms and initial data converging weakly to some limiting initial data, need not converge weakly. This may either indicate some limitations to the strong well-posedness theory, or be primarily resulting from the low-frequency consequences of adding a high frequency forcing term. In my opinion many of the currently known non-uniqueness results for weak solutions are of the second category.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("Thanks a lot for prompt and comprehensive response.")#linebreak()#text(" Wish you all the best,")#linebreak()#text(" Mahdi")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("It seems that the viscosity coefficient is missing in the NS equation above.")

#emph[#text("[In this paper the viscosity is normalised to be 1 for simplicity. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2019")])]

#text("The viscosity normalization to 1 may be viewed as a gauge transformation.")#linebreak()#text(" It seems that such normalization is possible (in certain cases) even for dimensionless parameters.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a0e6502bda5598edff524bd4ad024b5204d3f42f6114419f3106b80634cc77-e22283622784c05b612c2da8aefe7319e0cd8dcc8195b77461ee1c48fe2a9ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m.r.s")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519997")[#strong[#text("m.r.s")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("What does “cj” notation on page 8 mean?")#linebreak()#text(" Nowhere has the paper been used")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a0e6502bda5598edff524bd4ad024b5204d3f42f6114419f3106b80634cc77-e22283622784c05b612c2da8aefe7319e0cd8dcc8195b77461ee1c48fe2a9ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m.r.s")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-519998")[#strong[#text("m.r.s")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#text("notation cj in this equation:")#linebreak()#text(" Aj=c0j")#linebreak()#text(" in page 8 your paper!!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2019")])]

#mi("C_0^j")#text(" is ")#mi("C_0")#text(" raised to the power ")#mi("j")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520334")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2019")])]

#text("Dear Sir Tao,")#linebreak()#text(" I ‘d like to contribute a little merit:")#linebreak()#text(" To disscuss Navier Stokes, I am allowed to tell a 100 year- story. ” 100 year ago, the inventist Edison met an old woman , she complained that she was tired and she wished there was somewhat means to help her go home”. Immediately, Edison thought about the first electric car in the world. An great invention from a little idea of an old woman.”Sometime the great heroes in the world must respect a little idea from a normal person” .Like also Navier Stokes , why all hundreds of mathematicians in the world keep their heads into solving “ghost” Navier Stokes equation.Like also coming aross the other bank of river , instead of building a bridge that costs of much money , material , men. We only use a boat to destination. Sir Tao , why don’t you invent another formular to describle fluid flows replacing “ghost” Navier Stokes equation. After then , Sir compares two equations toghether.")#linebreak()#text(" Best wishes")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matemático joven")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520094")[#strong[#text("matemático joven")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("Dear Prof. Tao,")

#text("this might be a really dumb suggestion, but did you try an evolutionary algorithm for building your water computer?")

#text("Perhaps those criteria could restrict your search space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa0c17e2b4b0d7e85abd0c1e57315267c0558044638038551e1e81ddff968ba9-bfa1cbe943716636b50972a7ba3ae667343c976b10302c9e7a7432ac67d2cbb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rjgoodin")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520105")[#strong[#text("rjgoodin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("Hi Prof. Tao,")#linebreak()#text(" I’m sorry to see all the bizarre comments that come up any time you mention the phrase “Navier-Stokes”, but I’m impressed by your graciousness.")#linebreak()#text(" For my part, as an interested layperson, I interested to see all of these qualitative results for the blow-up, but really surprised that there were no quantitative results so far. It’s fascinating to see all of these open problems, regardless of how far they get us on the Big Ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matemático joven")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520153")[#strong[#text("matemático joven")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2019")])]

#text("I think the lack of quantitative results was with respect to the Escauriaza-Seregin-Sverak-type estimates. But you’d have to look it up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stupid&lame")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-520358")[#strong[#text("Stupid&lame")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("This blog is stupid and lame")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-528767")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text("I have posted a comment on my blog")

#link("https://claesjohnson.blogspot.com/2019/11/solving-clay-navier-stokes-problem-with.html")[#text("https://claesjohnson.blogspot.com/2019/11/solving-clay-navier-stokes-problem-with.html")]

#text("Would very much appreciate your view on the meaningfulness of a triple exponential bound on gradients and the relation between smoothness and turbulence. Can turbulent solutions be smooth solutions? If so, what is the meaning of a turbulent solution?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-528811")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2019")])]

#text("I have found an exact family of solutions to the Euler equations before that appear very turbulent and they are smooth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-534236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("In the paper when you get (5.17) from the previous line, why is it not a triple exponential of A6? t0 is lower bounded by an exponential of R’, which is itself bounded by an exponential of A6.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-534259")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("Thanks for pointing this out. The radius ")#mi("r")#text(" for Proposition 4.3 here was selected to be too large just after (5.15). If one sets ")#mi("r")#text(" to equal to ")#mi("C_0^{1/4} R^{\\prime} (t_0/T_2)^{1/2}")#text(" instead of ")#tao-math("\\left|x_*\\right|/2", block: false)#text(" (and also sets ")#mi("T")#text(" to equal ")#mi("1000t_0")#text(" rather than ")#mi("T_2")#text(") then I believe the argument goes through as before and now there is only a double exponential loss rather than a triple exponential one. This will be corrected in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-534261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("I see, thanks! I’m glad it doesn’t have to be exp exp exp exp.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb41629b900a04bf9debac4d5eac088c522fb410dada341099521f7f9faeb264-a753dd309490ffe7a3fccee4f133ec9c1bea4ce7d7e270786ca05bf0f89638af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daoguo Zhou")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-534333")[#strong[#text("Daoguo Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2019")])]

#text("Are there more references in PDE about turning quanlitative results by compactness method into quantitative analogues?")

#text("The method in your paper does not appear often.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-534365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2019")])]

#text("There are some very general “proof mining” techniques (see e.g., ")#link("https://www.brics.dk/RS/02/31/BRICS-RS-02-31.pdf")[#text("https://www.brics.dk/RS/02/31/BRICS-RS-02-31.pdf")]#text(" ) that allow one to start with a qualitative result obtained by a compactness method and converting it into a quantitative result, but these methods often give extremely poor bounds (tower exponential type bounds are common). In high dimensional geometry there is some literature on replacing results based on compact embeddings of Banach spaces with more quantitative estimates on metric entropy numbers, though I don’t know if such results have been applied very much to PDE settings. In the reverse direction, to attack critical PDE Bourgain introduced a quantitative “induction on energy” method which was later simplified by Kenig and Merle to a qualitative “non-existence of minimal-energy blowup solution” argument.")

#text("In an old paper of mine ")#link("http://front.math.ucdavis.edu/math.AP/0402130")[#text("http://front.math.ucdavis.edu/math.AP/0402130")]#text(" I obtained quantitative bounds for the global regularity of spherically symmetric NLS which had previously been obtained by arguments that were either qualitative or used the induction on energy method that provided only tower exponentially poor bounds. Much of the literature on global regularity for slightly supercritical equations (starting with my paper ")#link("https://arxiv.org/abs/math/0606145")[#text("https://arxiv.org/abs/math/0606145")]#text(" ) also implicitly requires a very quantitative understanding of the critical theory; roughly speaking, the extent to which one can penetrate into the supercritical regime tends to be inversely proportional to the strength of the quantitative bounds one gets in the critical regime.")

#text("Certainly I think it is a productive exercise to look at other qualitative results in PDE (or in analysis in general) and try to make them more quantitative, with bounds as strong as possible; this exercise tends to force one to really understand the underlying mechanics of the argument and also allows one to quantitative compare the strength of various techniques to attack the problem in a way that might not be visible at the purely qualitative level.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-535674")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#link("https://link.springer.com/chapter/10.1007/978-3-642-32589-2_51")[#text("https://link.springer.com/chapter/10.1007/978-3-642-32589-2_51")]#linebreak()#text(" smoothness really help or it’s just hiding the goal.")#linebreak()#text(" if i want to collapse in a little hole who represent the best gradient but i can’t define the hole.")#linebreak()#text(" Or inverse smoothness doesn’t change complexity so i’m working with the same entity. Therefore we always collapse the optimal way by applying it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zaker")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-593195")[#strong[#text("zaker")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Hello professor.")#linebreak()#text(" I want to ask you a few questions about the Navier-Stokes equation of incompressible fluid flow.")#linebreak()#text(" Question 1- Can the Navier-Stokes equation be explained like Euler’s equation by Arnold’s theory of geodesics?")#linebreak()#text(" Question 2 – Suppose we have written the Navier-Stokes equation on a Riemannian manifold. How is the “Millennium Prize Problem” expressed now? That is, how is the above problem written for Riemani Manifeld?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3912a0ff6907093731533dc4f04c048f4e8daa2f6dd9edca5cd908d59b423e94-57560863e700facb33811eab329319e473a74b266c784b917cde3d91af93330f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-600587")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("Would research like this 1) help you or 2) motivate you to work on deep learning or 3) suggest that deep learning might be an arsenal for you some day in your work on pdes or may be other (ir)relevant areas ")#link("https://www.technologyreview.com/2020/10/30/1011435/ai-fourier-neural-network-cracks-navier-stokes-and-partial-differential-equations/")[#text("https://www.technologyreview.com/2020/10/30/1011435/ai-fourier-neural-network-cracks-navier-stokes-and-partial-differential-equations/")]#text("?")

#text("If so or if not why or why not respectively?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-680171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2023")])]

#text("Is it possible that any initial data which cause a blowup is not (effectively) constructible (so any proof of the existence of such initial data is not constructive)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-680779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("This scenario is not ruled out by our current understanding of the situation; we have no finite time certificate for blowup. On the other hand, if a given explicit (smooth) choice of initial data has a global solution (say on a periodic domain for simplicity), then this global solvability can be verified by a finite time computation, by performing rigorous numerical simulation of the solution to a sufficiently high accuracy that rigorous perturbation theory can then convert the numerical solution to an exact global solution. (This is an unpublished observation of Bourgain, which I reproduced in Section 4 of ")#link("https://arxiv.org/abs/0710.1604")[#text("this paper")]#text(".) See also ")#link("https://mathoverflow.net/questions/108433/for-which-millennium-problems-does-undecidable-true")[#text("this MathOverflow question")]#text(" for some related discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claes Johnson")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-680199")[#strong[#text("Claes Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2023")])]

#text("I have put up a new post on the unfortunate formulation of the Navier-Stokes Millennium Problem missing the physics of turbulent solutions as key aspect:")

#link("https://claesjohnson.blogspot.com/2023/07/terence-tao-on-navier-stokes-millennium.html")[#text("https://claesjohnson.blogspot.com/2023/07/terence-tao-on-navier-stokes-millennium.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-680203")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2023")])]

#text("This is going to blow your small mind: one can simply undo the rescaling that normalizes ")#mi("nu = 1")#text(", and the ")#mi("L^3")#text(" norm is proportional to the viscosity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-680430")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2023")])]

#text("There are exact families of “turbulent-like” solutions to the 3D Euler equations at least. For example there are solutions that have a velocity component such as")#linebreak()#text(" cos(2tkcos(k(x+y-z+t))+k(x+y+z-t))+1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e83045ee1784bf91fa9a10805f1a09bdafc4ac7f1a2743390ede8176c2d38fe-191cf52af127f77cd932fc2fccbb2837fcd12d24c40d08604fec95a4ed47c6e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Zhao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-684475")[#strong[#text("Jason Zhao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2024")])]

#text("It’s remarked in Escauriaza-Seregin-Sverak that backwards uniqueness could be applied to other equations at critical regularity, such as NLS and NLW, though there is a gap in that there is (so far) no local regularity theory for these equations.")

#text("Is there any hope of proving a partial regularity result for dispersive equations, e.g. an epsilon-regularity theorem in the spirit of Caffarelli-Kohn-Nirenberg? Or is parabolic/elliptic regularity necessary for such a result to hold?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/08/15/quantitative-bounds-for-critically-bounded-solutions-to-the-navier-stokes-equations/#comment-684573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("For nonlinear wave equations, one can obtain a local regularity theory from a global regularity theory from finite speed of propagation (though there are some minor technical issues sometimes regarding how to truncate a solution in a way that keeps e.g., the energy small). But for nonlinear Schrodinger equations, where there is genuinely infinite speed of propagation (far more dramatic than the parabolic diffusion experienced by say Navier-Stokes), I don’t think there is enough advantage gained by spatial localization to try to seek a good local regularity theory. Generally speaking, it is more fruitful to try localizing in the frequency variable (e.g., by using Littlewood-Paley projections) when analysing NLS.")
]
]
