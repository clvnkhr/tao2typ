// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/
// Converted to Typst by tao2typ: "2026-10-14T15:19:09.879784+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Narrow progressions in the primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Narrow progressions in the primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 September 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/")[#text("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.ma.huji.ac.il/~tamarz/")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1409.1327")[#text("Narrow progressions in the primes")]#text("“, submitted to the special issue “Analytic Number Theory” in honor of the 60th birthday of ")#link("http://en.wikipedia.org/wiki/Helmut_Maier")[#text("Helmut Maier")]#text(". The results here are vaguely reminiscent of the recent progress on bounded gaps in the primes, but use different methods.")

#text("About a decade ago, ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("Ben Green and I showed")]#text(" that the primes contained arbitrarily long arithmetic progressions: given any ")#mi("{k}")#text(", one could find a progression ")#mi("{n, n+r, \\dots, n+(k-1)r}")#text(" with ")#mi("{r>0}")#text(" consisting entirely of primes. In fact we showed the same statement was true if the primes were replaced by any subset of the primes of positive relative density.")

#text("A little while later, ")#link("http://www.ams.org/mathscinet-getitem?mr=2461509")[#text("Tamar Ziegler and I obtained")]#text(" the following generalisation: given any ")#mi("{k}")#text(" and any polynomials ")#mi("{P_1,\\dots,P_k: {\\bf Z} \\rightarrow {\\bf Z}}")#text(" with ")#mi("{P_1(0)=\\dots=P_k(0)}")#text(", one could find a “polynomial progression” ")#mi("{n+P_1(r),\\dots,n+P_k(r)}")#text(" with ")#mi("{r>0}")#text(" consisting entirely of primes. Furthermore, we could make this progression somewhat “narrow” by taking ")#mi("{r = n^{o(1)}}")#text(" (where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{n}")#text(" goes to infinity). Again, the same statement also applies if the primes were replaced by a subset of positive relative density. My previous result with Ben corresponds to the linear case ")#mi("{P_i(r) = (i-1)r}")#text(".")

#text("In this paper we were able to make the progressions a bit narrower still: given any ")#mi("{k}")#text(" and any polynomials ")#mi("{P_1,\\dots,P_k: {\\bf Z} \\rightarrow {\\bf Z}}")#text(" with ")#mi("{P_1(0)=\\dots=P_k(0)}")#text(", one could find a “polynomial progression” ")#mi("{n+P_1(r),\\dots,n+P_k(r)}")#text(" with ")#mi("{r>0}")#text(" consisting entirely of primes, and such that ")#mi("{r \\leq \\log^L n}")#text(", where ")#mi("{L}")#text(" depends only on ")#mi("{k}")#text(" and ")#mi("{P_1,\\dots,P_k}")#text(" (in fact it depends only on ")#mi("{k}")#text(" and the degrees of ")#mi("{P_1,\\dots,P_k}")#text("). The result is still true if the primes are replaced by a subset of positive density ")#mi("{\\delta}")#text(", but unfortunately in our arguments we must then let ")#mi("{L}")#text(" depend on ")#mi("{\\delta}")#text(". However, in the linear case ")#mi("{P_i(r) = (i-1)r}")#text(", we were able to make ")#mi("{L}")#text(" independent of ")#mi("{\\delta}")#text(" (although it is still somewhat large, of the order of ")#mi("{k 2^k}")#text(").")

#text("The polylogarithmic factor is somewhat necessary: using an upper bound sieve, one can easily construct a subset of the primes of density, say, ")#mi("{90\\%}")#text(", whose arithmetic progressions ")#mi("{n,n+r,\\dots,n+(k-1)r}")#text(" of length ")#mi("{k}")#text(" all obey the lower bound ")#mi("{r \\gg \\log^{k-1} n}")#text(". On the other hand, the prime tuples conjecture predicts that if one works with the actual primes rather than dense subsets of the primes, then one should have infinitely many length ")#mi("{k}")#text(" arithmetic progressions of bounded width for any fixed ")#mi("{k}")#text(". The ")#mi("{k=2}")#text(" case of this is precisely the celebrated theorem of ")#link("http://en.wikipedia.org/wiki/Yitang_Zhang")[#text("Yitang Zhang")]#text(" that was the focus of the recently concluded Polymath8 project here. The higher ")#mi("{k}")#text(" case is conjecturally true, but appears to be out of reach of known methods. (Using the multidimensional Selberg sieve of Maynard, one can get ")#mi("{m}")#text(" primes inside an interval of length ")#mi("{O( \\exp(O(m)) )}")#text(", but this is such a sparse set of primes that one would not expect to find even a progression of length three within such an interval.)")

#text("The argument in the previous paper was unable to obtain a polylogarithmic bound on the width of the progressions, due to the reliance on a certain technical “correlation condition” on a certain Selberg sieve weight ")#mi("{\\nu}")#text(". This correlation condition required one to control arbitrarily long correlations of ")#mi("{\\nu}")#text(", which was not compatible with a bounded value of ")#mi("{L}")#text(" (particularly if one wanted to keep ")#mi("{L}")#text(" independent of ")#mi("{\\delta}")#text(").")

#text("However, thanks to recent advances in this area ")#link("http://www.ams.org/mathscinet-getitem?mr=3177293")[#text("by Conlon, Fox, and Zhao")]#text(" (who introduced a very nice “densification” technique), it is now possible (in principle, at least) to delete this correlation condition from the arguments. Conlon-Fox-Zhao did this for my original theorem with Ben; and in the current paper we apply the densification method to our previous argument to similarly remove the correlation condition. This method does not fully eliminate the need to control arbitrarily long correlations, but allows most of the factors in such a long correlation to be ")#emph[#text("bounded")]#text(", rather than merely controlled by an unbounded weight such as ")#mi("{\\nu}")#text(". This turns out to be significantly easier to control, although in the non-linear case we still unfortunately had to make ")#mi("{L}")#text(" large compared to ")#mi("{\\delta}")#text(" due to a certain “clearing denominators” step arising from the complicated nature of the Gowers-type uniformity norms that we were using to control polynomial averages. We believe though that this an artefact of our method, and one should be able to prove our theorem with an ")#mi("{L}")#text(" that is uniform in ")#mi("{\\delta}")#text(".")

#text("Here is a simple instance of the densification trick in action. Suppose that one wishes to establish an estimate of the form ")#metadata(none) <tao-6341788aa8f0dd68ce77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf E}_n {\\bf E}_r f(n) g(n+r) h(n+r^2) = o(1)")]]

#text("for some real-valued functions ")#mi("{f,g,h}")#text(" which are bounded in magnitude by a weight function ")#mi("{\\nu}")#text(", but which are not expected to be bounded; this average will naturally arise when trying to locate the pattern ")#mi("{(n,n+r,n+r^2)}")#text(" in a set such as the primes. Here I will be vague as to exactly what range the parameters ")#mi("{n,r}")#text(" are being averaged over. Suppose that the factor ")#mi("{g}")#text(" (say) has enough uniformity that one can already show a smallness bound ")#metadata(none) <tao-d6a98598212ed729f5b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\bf E}_n {\\bf E}_r F(n) g(n+r) H(n+r^2) = o(1)")]]

#text("whenever ")#mi("{F, H}")#text(" are bounded functions. (One should think of ")#mi("{F,H}")#text(" as being like the indicator functions of “dense” sets, in contrast to ")#mi("{f,h}")#text(" which are like the normalised indicator functions of “sparse” sets). The bound ")#link(<tao-d6a98598212ed729f5b9>)[#text("(2)")]#text(" cannot be directly applied to control ")#link(<tao-6341788aa8f0dd68ce77>)[#text("(1)")]#text(" because of the unbounded (or “sparse”) nature of ")#mi("{f}")#text(" and ")#mi("{h}")#text(". However one can “densify” ")#mi("{f}")#text(" and ")#mi("{h}")#text(" as follows. Since ")#mi("{f}")#text(" is bounded in magnitude by ")#mi("{\\nu}")#text(", we can bound the left-hand side of ")#link(<tao-6341788aa8f0dd68ce77>)[#text("(1)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n \\nu(n) | {\\bf E}_r g(n+r) h(n+r^2) |.")]]

#text("The weight function ")#mi("{\\nu}")#text(" will be normalised so that ")#mi("{{\\bf E}_n \\nu(n) = O(1)}")#text(", so by the Cauchy-Schwarz inequality it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_n \\nu(n) \\left| {\\bf E}_r g(n+r) h(n+r^2) \\right|^2 = o(1).", block: true)]]

#text("The left-hand side expands as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n {\\bf E}_r {\\bf E}_s \\nu(n) g(n+r) h(n+r^2) g(n+s) h(n+s^2).")]]

#text("Now, it turns out that after an enormous (but finite) number of applications of the Cauchy-Schwarz inequality to steadily eliminate the ")#mi("{g,h}")#text(" factors, as well as a certain “polynomial forms condition” hypothesis on ")#mi("{\\nu}")#text(", one can show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n {\\bf E}_r {\\bf E}_s (\\nu-1)(n) g(n+r) h(n+r^2) g(n+s) h(n+s^2) = o(1).")]]

#text("(Because of the polynomial shifts, this requires a method known as “PET induction”, but let me skip over this point here.) In view of this estimate, we now just need to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n {\\bf E}_r {\\bf E}_s g(n+r) h(n+r^2) g(n+s) h(n+s^2) = o(1).")]]

#text("Now we can reverse the previous steps. First, we collapse back to")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_n \\left| {\\bf E}_r g(n+r) h(n+r^2) \\right|^2 = o(1).", block: true)]]

#text("One can bound ")#tao-math("{\\left|{\\bf E}_r g(n+r) h(n+r^2)\\right|}", block: false)#text(" by ")#mi("{{\\bf E}_r \\nu(n+r) \\nu(n+r^2)}")#text(", which can be shown to be “bounded on average” in a suitable sense (e.g. bounded ")#mi("{L^4}")#text(" norm) via the aforementioned polynomial forms condition. Because of this and the Hölder inequality, the above estimate is equivalent to")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_n \\left| {\\bf E}_r g(n+r) h(n+r^2) \\right| = o(1).", block: true)]]

#text("By setting ")#mi("{F}")#text(" to be the signum of ")#mi("{{\\bf E}_r g(n+r) h(n+r^2)}")#text(", this is equivalent to")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_n {\\bf E}_r F(n) g(n+r) h(n+r^2) = o(1).")]]

#text("This is halfway between ")#link(<tao-6341788aa8f0dd68ce77>)[#text("(1)")]#text(" and ")#link(<tao-d6a98598212ed729f5b9>)[#text("(2)")]#text("; the sparsely supported function ")#mi("{f}")#text(" has been replaced by its “densification” ")#mi("{F}")#text(", but we have not yet densified ")#mi("{h}")#text(" to ")#mi("{H}")#text(". However, one can shift ")#mi("{n}")#text(" by ")#mi("{r^2}")#text(" and repeat the above arguments to achieve a similar densificiation of ")#mi("{h}")#text(", at which point one has reduced ")#link(<tao-6341788aa8f0dd68ce77>)[#text("(1)")]#text(" to ")#link(<tao-d6a98598212ed729f5b9>)[#text("(2)")]#text(".")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e20c14d87bab7ee957eb9fe4fa29a6207ceb605b3cae849d010cfb1568c10b6-a679dd53b7f12cc85f139ec37509171f47fead8c7540fb8309acf55f4ae31683.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wolf")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-412851")[#strong[#text("wolf")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2014")])]

#text("Can somebody please clarify this statement for me?")#linebreak()#text(" “given any k, one could find a progression n, n+r, … , n+(k-1)r with r>0 consisting entirely of primes”.")#linebreak()#text(" If r=1 then n and n+1 cannot both be primes for the trivial reason that one must be even if the other is odd.")#linebreak()#text(" What am I missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-412858")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2014")])]

#text("I think the claim is not that such a progression exists for *all* r>0 , but that it exists for *at least one* r>0 (else the statement would have begun “given any k and any r>0…”).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-412859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2014")])]

#text("The assertion is that one could find an “r” for which that statement is true, not that the statement is true for every r.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c356feedd92ebfabcde022b781f7a91de37975bce70dd7bf8c42811a2c19c3a-1da4b0c1530936e9e346447f18b77701725425a58c51b7041502657096e726e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pybienvenu")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-417308")[#strong[#text("pybienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2014")])]

#text("In what sense it is the same densification trick as in Fox-Conlon-Zhao ? In their paper, they replaced g(x,y) by g'(x,y)=Eg(x,z)g(y,z) and here you also replace a function by an expectation, but is there more analogy ? Moreover, in your article, what you call the densification of f is not related to f as far as I understand; it depends on f and g actually. Thank you for any clarification !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-419390")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("Beginner Q: In the discussion following (1), does “[g is] not expected to be bounded” mean that g’s expected value is not bounded, or simply that g is not bounded? (I initially guessed the former, but this seems to conflict w/ the later supposition that (2) is true whenever F, H are bounded functions, because the choice F=H=1 would then imply EnEr(g(n+r)) = o(1))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-419644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("We do not expect ")#mi("g")#text(" to be bounded in general.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c356feedd92ebfabcde022b781f7a91de37975bce70dd7bf8c42811a2c19c3a-1da4b0c1530936e9e346447f18b77701725425a58c51b7041502657096e726e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pybienvenu")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-442921")[#strong[#text("pybienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2014")])]

#text("Hello, why do you actually take the signum and not the expectation itself, just like FCZ do ? You would introduce ")#mi("f^{\\prime}(n)=\\mathbb{E}g(n+d)g(n+d^2)")#text(", and then ")#mi("F(n)=f^{\\prime}(n)\\wedge 1")#text(" and notice that the expression is now ")#mi("\\mathbb{E}_n f^{\\prime}(n)^2=\\mathbb{E}_n f^{\\prime}(n)(f^{\\prime}-F(n))+\\mathbb{E} f^{\\prime}F")#text(" and you could find that both are negligible.")

#emph[#text("[Yes, this should work also; there are multiple ways to conclude this portion of the argument. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c356feedd92ebfabcde022b781f7a91de37975bce70dd7bf8c42811a2c19c3a-1da4b0c1530936e9e346447f18b77701725425a58c51b7041502657096e726e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pybienvenu")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-442927")[#strong[#text("pybienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2014")])]

#text("Sorry, I mean that the last expectation is now of the form ")#mi("\\mathbb{E} F(n)g(n)g(n+d^2)")#text(" while the first is dominated by ")#mi("\\mathbb{E} \\nu^{\\prime}(n)\\mid \\nu^{\\prime}(n)-1\\mid=\\mathbb{E} (\\nu^{\\prime}-1)^2+\\mathbb{E}\\mid \\nu^{\\prime}-1\\mid")#text(" where ")#mi("\\nu^{\\prime}")#text(" is the averaged ")#mi("\\nu")#text(" just like in “the Green-Tao theorem : an exposition”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c356feedd92ebfabcde022b781f7a91de37975bce70dd7bf8c42811a2c19c3a-1da4b0c1530936e9e346447f18b77701725425a58c51b7041502657096e726e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pybienvenu")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-444372")[#strong[#text("pybienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2014")])]

#text("Hello, I just wanted to mention two little problems in the paper I can see currently on the arxiv. First in the second page, the singular series is not correct (k instead of -k). Secondly, there’s a problem in the 6th page in how you define your W-tricked set (because you placed your original set in [N’,2N’]). Best regards.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c356feedd92ebfabcde022b781f7a91de37975bce70dd7bf8c42811a2c19c3a-1da4b0c1530936e9e346447f18b77701725425a58c51b7041502657096e726e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pybienvenu")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-444590")[#strong[#text("pybienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2014")])]

#text("Moreover, in the inequality (17), the Gowers-Cauchy-Schwarz inequality, there’s an extra 2^d exponent I’m afraid.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/#comment-467305")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] using the recent “densification” technique of Conlon, Fox, and Zhao, discussed in this previous post), we are able in particular to establish the following […]")
]
