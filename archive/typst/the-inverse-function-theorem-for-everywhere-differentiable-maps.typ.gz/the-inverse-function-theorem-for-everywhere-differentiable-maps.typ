// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/
// Converted to Typst by tao2typ: "2026-10-14T15:18:12.946872+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The inverse function theorem for everywhere differentiable maps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The inverse function theorem for everywhere differentiable maps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/")[#text("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The classical ")#link("http://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(" reads as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (")#mi("{C^1}")#text(" inverse function theorem)")]#text(" Let ")#mi("{\\Omega \\subset {\\bf R}^n}")#text(" be an open set, and let ")#mi("{f: \\Omega \\rightarrow {\\bf R}^n}")#text(" be an continuously differentiable function, such that for every ")#mi("{x_0 \\in \\Omega}")#text(", the derivative map ")#mi("{Df(x_0): {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" is invertible. Then ")#mi("{f}")#text(" is a local homeomorphism; thus, for every ")#mi("{x_0 \\in \\Omega}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of ")#mi("{x_0}")#text(" and an open neighbourhood ")#mi("{V}")#text(" of ")#mi("{f(x_0)}")#text(" such that ")#mi("{f}")#text(" is a homeomorphism from ")#mi("{U}")#text(" to ")#mi("{V}")#text(".")
]

#text("It is also not difficult to show by inverting the Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("f(x) = f(x_0) + Df(x_0)(x-x_0) + o(\\left\\|x-x_0\\right\\|)", block: true)]]

#text("that at each ")#mi("{x_0}")#text(", the local inverses ")#mi("{f^{-1}: V \\rightarrow U}")#text(" are also differentiable at ")#mi("{f(x_0)}")#text(" with derivative ")#metadata(none) <tao-905301bf736f9b791431>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("Df^{-1}(f(x_0)) = Df(x_0)^{-1}.")]]

#text("The textbook proof of the inverse function theorem proceeds by an application of the ")#link("http://en.wikipedia.org/wiki/Contraction_mapping_theorem")[#text("contraction mapping theorem")]#text(". Indeed, one may normalise ")#mi("{x_0=f(x_0)=0}")#text(" and ")#mi("{Df(0)}")#text(" to be the identity map; continuity of ")#mi("{Df}")#text(" then shows that ")#mi("{Df(x)}")#text(" is close to the identity for small ")#mi("{x}")#text(", which may be used (in conjunction with the fundamental theorem of calculus) to make ")#mi("{x \\mapsto x-f(x)+y}")#text(" a contraction on a small ball around the origin for small ")#mi("{y}")#text(", at which point the contraction mapping theorem readily finishes off the problem.")

#text("I recently learned (after I asked ")#link("http://mathoverflow.net/questions/75049/does-the-inverse-function-theorem-hold-for-everywhere-differentiable-maps")[#text("this question on Math Overflow")]#text(") that the hypothesis of continuous differentiability may be relaxed to just everywhere differentiability:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Everywhere differentiable inverse function theorem)")]#text(" Let ")#mi("{\\Omega \\subset {\\bf R}^n}")#text(" be an open set, and let ")#mi("{f: \\Omega \\rightarrow {\\bf R}^n}")#text(" be an everywhere differentiable function, such that for every ")#mi("{x_0 \\in \\Omega}")#text(", the derivative map ")#mi("{Df(x_0): {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" is invertible. Then ")#mi("{f}")#text(" is a local homeomorphism; thus, for every ")#mi("{x_0 \\in \\Omega}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of ")#mi("{x_0}")#text(" and an open neighbourhood ")#mi("{V}")#text(" of ")#mi("{f(x_0)}")#text(" such that ")#mi("{f}")#text(" is a homeomorphism from ")#mi("{U}")#text(" to ")#mi("{V}")#text(".")
]

#text("As before, one can recover the differentiability of the local inverses, with the derivative of the inverse given by the usual formula ")#link(<tao-905301bf736f9b791431>)[#text("(1)")]#text(".")

#text("This result implicitly follows from the more general ")#link("http://www.ams.org/mathscinet-getitem?mr=172256")[#text("results of Cernavskii")]#text(" about the structure of finite-to-one open and closed maps, however the arguments there are somewhat complicated (and subsequent proofs of those results, such as the one ")#link("http://www.ams.org/mathscinet-getitem?mr=200928")[#text("by Vaisala")]#text(", use some powerful tools from algebraic geometry, such as ")#link("http://en.wikipedia.org/wiki/Dimension_theory")[#text("dimension theory")]#text("). There is however a ")#link("http://www.ams.org/mathscinet-getitem?mr=2059050")[#text("more elementary proof of Saint Raymond")]#text(" that was pointed out to me by Julien Melleray. It only uses basic point-set topology (for instance, the concept of a connected component) and the basic topological and geometric structure of Euclidean space (in particular relying primarily on local compactness, local connectedness, and local convexity). I decided to present (an arrangement of) Saint Raymond’s proof here.")

#text("To obtain a local homeomorphism near ")#mi("{x_0}")#text(", there are basically two things to show: local surjectivity near ")#mi("{x_0}")#text(" (thus, for ")#mi("{y}")#text(" near ")#mi("{f(x_0)}")#text(", one can solve ")#mi("{f(x)=y}")#text(" for some ")#mi("{x}")#text(" near ")#mi("{x_0}")#text(") and local injectivity near ")#mi("{x_0}")#text(" (thus, for distinct ")#mi("{x_1, x_2}")#text(" near ")#mi("{f(x_0)}")#text(", ")#mi("{f(x_1)}")#text(" is not equal to ")#mi("{f(x_2)}")#text("). Local surjectivity is relatively easy; basically, the standard proof of the inverse function theorem works here, after replacing the contraction mapping theorem (which is no longer available due to the possibly discontinuous nature of ")#mi("{Df}")#text(") with the ")#link("http://en.wikipedia.org/wiki/Brouwer_fixed_point_theorem")[#text("Brouwer fixed point theorem instead")]#text(" (or one could also use ")#link("http://en.wikipedia.org/wiki/Topological_degree_theory")[#text("degree theory")]#text(", which is more or less an equivalent approach). The difficulty is local injectivity – one needs to preclude the existence of nearby points ")#mi("{x_1, x_2}")#text(" with ")#mi("{f(x_1) = f(x_2) = y}")#text("; note that in contrast to the contraction mapping theorem that provides both existence and uniqueness of fixed points, the Brouwer fixed point theorem only gives existence and not uniqueness.")

#text("In one dimension ")#mi("{n=1}")#text(" one can proceed by using ")#link("http://en.wikipedia.org/wiki/Rolle%27s_theorem")[#text("Rolle’s theorem")]#text(". Indeed, as one traverses the interval from ")#mi("{x_1}")#text(" to ")#mi("{x_2}")#text(", one must encounter some intermediate point ")#mi("{x_*}")#text(" which maximises the quantity ")#tao-math("{\\left|f(x_*)-y\\right|}", block: false)#text(", and which is thus instantaneously non-increasing both to the left and to the right of ")#mi("{x_*}")#text(". But, by hypothesis, ")#mi("{f^{\\prime}(x_*)}")#text(" is non-zero, and this easily leads to a contradiction.")

#text("Saint Raymond’s argument for the higher dimensional case proceeds in a broadly similar way. Starting with two nearby points ")#mi("{x_1, x_2}")#text(" with ")#mi("{f(x_1)=f(x_2)=y}")#text(", one finds a point ")#mi("{x_*}")#text(" which “locally extremises” ")#tao-math("{\\left\\|f(x_*)-y\\right\\|}", block: false)#text(" in the following sense: ")#tao-math("{\\left\\|f(x_*)-y\\right\\|}", block: false)#text(" is equal to some ")#mi("{r_*>0}")#text(", but ")#mi("{x_*}")#text(" is adherent to at least two distinct connected components ")#mi("{U_1, U_2}")#text(" of the set ")#tao-math("{U = \\{ x: \\left\\|f(x)-y\\right\\| < r_* \\}}", block: false)#text(". (This is an oversimplification, as one has to restrict the available points ")#mi("{x}")#text(" in ")#mi("{U}")#text(" to a suitably small compact set, but let us ignore this technicality for now.) Note from the non-degenerate nature of ")#mi("{Df(x_*)}")#text(" that ")#mi("{x_*}")#text(" was already adherent to ")#mi("{U}")#text("; the point is that ")#mi("{x_*}")#text(" “disconnects” ")#mi("{U}")#text(" in some sense. Very roughly speaking, the way such a critical point ")#mi("{x_*}")#text(" is found is to look at the sets ")#tao-math("{\\{ x: \\left\\|f(x)-y\\right\\| \\leq r \\}}", block: false)#text(" as ")#mi("{r}")#text(" shrinks from a large initial value down to zero, and one finds the first value of ")#mi("{r_*}")#text(" below which this set disconnects ")#mi("{x_1}")#text(" from ")#mi("{x_2}")#text(". (Morally, one is performing some sort of ")#link("http://en.wikipedia.org/wiki/Morse_theory")[#text("Morse theory")]#text(" here on the function ")#tao-math("{x \\mapsto \\left\\|f(x)-y\\right\\|}", block: false)#text(", though this function does not have anywhere near enough regularity for classical Morse theory to apply.)")

#text("The point ")#mi("{x_*}")#text(" is mapped to a point ")#mi("{f(x_*)}")#text(" on the boundary ")#mi("{\\partial B(y,r_*)}")#text(" of the ball ")#mi("{B(y,r_*)}")#text(", while the components ")#mi("{U_1, U_2}")#text(" are mapped to the interior of this ball. By using a continuity argument, one can show (again very roughly speaking) that ")#mi("{f(U_1)}")#text(" must contain a “hemispherical” neighbourhood ")#tao-math("{\\{ z \\in B(y,r_*): \\left\\|z-f(x_*)\\right\\| < \\kappa \\}}", block: false)#text(" of ")#mi("{f(x_*)}")#text(" inside ")#mi("{B(y,r_*)}")#text(", and similarly for ")#mi("{f(U_2)}")#text(". But then from differentiability of ")#mi("{f}")#text(" at ")#mi("{x_*}")#text(", one can then show that ")#mi("{U_1}")#text(" and ")#mi("{U_2}")#text(" overlap near ")#mi("{x_*}")#text(", giving a contradiction.")

#text("The rigorous details of the proof are provided below the fold.")

#metadata(none) <tao-21f3c74f8a988260361d>

#heading(level: 1)[#strong[#text(" — 1. Proof — ")]]

#text("Fix ")#mi("{x_0 \\in \\Omega}")#text(". By a translation, we may assume ")#mi("{x_0=f(x_0)=0}")#text("; by a further linear change of variables, we may also assume ")#mi("{Df(0)}")#text(" (which by hypothesis is non-singular) to be the identity map. By differentiability, we have")

#align(center)[#tao-fit-display[#tao-math("f(x) = x + o(\\left\\|x\\right\\|)", block: true)]]

#text("as ")#mi("{x \\rightarrow 0}")#text(". In particular, there exists a ball ")#mi("{B(0,r_0)}")#text(" in ")#mi("{\\Omega}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f(x)-x\\right\\| < \\frac{1}{2} \\left\\|x\\right\\|", block: true)]]

#text("for all ")#mi("{x\\in B(0,r_0)}")#text("; by rescaling we may take ")#mi("{r_0=1}")#text(", thus ")#metadata(none) <tao-5e1cf42878df58fea7bf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| f(x)-x\\right\\| < \\frac{1}{2} \\|x\\| \\text{ whenever } \\left\\|x\\right\\| \\leq 1.", block: true)]]

#text("Among other things, this gives a uniform lower bound ")#metadata(none) <tao-7790e5f9966886cf30a0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| f(x) \\right\\| > \\frac{1}{2}", block: true)]]

#text("for all ")#mi("{x \\in \\partial B(0, 1)}")#text(", and a uniform upper bound ")#metadata(none) <tao-466575b016103a6ea57f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| f(x) \\right\\| < \\frac{1}{10}", block: true)]]

#text("for all ")#mi("{x \\in B(0, \\frac{1}{20})}")#text("; thus ")#mi("{f}")#text(" maps ")#mi("{B(0,\\frac{1}{20})}")#text(" to ")#mi("{B(0,\\frac{1}{10} )}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Local surjectivity)")]#text(" ")#metadata(none) <tao-79766dfa75c6592f9e0f>#text(" For any ")#mi("{0 < r < 1}")#text(", ")#mi("{f(B(0,r))}")#text(" contains ")#mi("{B(0,r/2)}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{y \\in B(0,r/2)}")#text(". From ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(2)")]#text(", we see that the map ")#mi("{f: \\partial B(0,r) \\rightarrow f(\\partial B(0,r))}")#text(" avoids ")#mi("{y}")#text(", and has ")#link("http://en.wikipedia.org/wiki/Degree_of_a_continuous_mapping")[#text("degree")]#text(" ")#mi("{1}")#text(" around ")#mi("{y}")#text("; contracting ")#mi("{\\partial B(0,r)}")#text(" to a point, we conclude that ")#mi("{f(x)=y}")#text(" for some ")#mi("{x \\in B(0,r)}")#text(", yielding the claim.")

#text("Alternatively, one may proceed by invoking the ")#link("http://en.wikipedia.org/wiki/Brouwer_fixed_point_theorem")[#text("Brouwer fixed point theorem")]#text(", noting that the map ")#mi("{x \\mapsto x - f(x) + y}")#text(" is continuous and maps the closed ball ")#mi("{\\overline{B(0,r)}}")#text(" to the open ball ")#mi("{B(0,r)}")#text(" by ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(2)")]#text(", and has a fixed point precisely when ")#mi("{f(x)=y}")#text(".")

#text("A third argument (avoiding the use of degree theory or the Brouwer fixed point theorem, but requiring one to replace ")#mi("{B(0,r/2)}")#text(" with the slightly smaller ball ")#mi("{B(0,r/3)}")#text(") is as follows: let ")#mi("{x \\in \\overline{B(0,r)}}")#text(" minimise ")#tao-math("{\\left\\|f(x)-y\\right\\|}", block: false)#text(". From ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(2)")]#text(" and the hypothesis ")#mi("{y \\in B(0,r/3)}")#text(" we see that ")#mi("{x}")#text(" lies in the interior ")#mi("{B(0,r)}")#text(". If the minimum is zero, then we have found a solution to ")#mi("{f(x)=y}")#text(" as required; if not, then we have a stationary point of ")#tao-math("{x \\mapsto \\left\\|f(x)-y\\right\\|}", block: false)#text(", which implies that ")#mi("{Df(x)}")#text(" is degenerate, a contradiction. (One can recover the full ball ")#mi("{B(0,r/2)}")#text(" by tweaking the expression ")#tao-math("{\\left\\|f(x)-y\\right\\|}", block: false)#text(" to be minimised in a suitable fashion; we leave this as an exercise for the interested reader.) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-2348f998744212575d85>#text(" ")#mi("{f}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Open_map")[#text("open map")]#text(": the image of any open set is open.")
]

#emph[#text("Proof:")]#text(" It suffices to show that for every ")#mi("{x \\in \\Omega}")#text(", the image of any open neighbourhood of ")#mi("{x}")#text(" is an open neighbourhood of ")#mi("{f(x)}")#text(". Proposition ")#link(<tao-79766dfa75c6592f9e0f>)[#text("3")]#text(" handles the case ")#mi("{x=0}")#text("; the general case follows by renormalising. ")#mi("\\Box")

#text("Suppose we could show that ")#mi("{f}")#text(" is injective on ")#mi("{B(0,\\frac{1}{20})}")#text(". By Corollary ")#link(<tao-2348f998744212575d85>)[#text("4")]#text(", the inverse map ")#mi("{f^{-1}: f(B(0,\\frac{1}{20})) \\rightarrow B(0,\\frac{1}{20})}")#text(" is also continuous. Thus ")#mi("{f}")#text(" is a homeomorphism from ")#mi("{B(0,\\frac{1}{20})}")#text(" to ")#mi("{f(B(0,\\frac{1}{20}))}")#text(", which are both neighbourhoods of ")#mi("{0}")#text(" by Proposition ")#link(<tao-79766dfa75c6592f9e0f>)[#text("3")]#text("; giving the claim.")

#text("It remains to establish injectivity. Suppose for sake of contradiction that this was not the case. Then there exists ")#mi("{x_1, x_2 \\in B(0,\\frac{1}{20} )}")#text(" and ")#mi("{y \\in B(0,\\frac{1}{10} )}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("y = f(x_1) = f(x_2).")]]

#text("For every radius ")#mi("{r \\geq 0}")#text(", the set")

#align(center)[#tao-fit-display[#tao-math("K_r := \\{ x \\in \\Omega: \\left\\| f(x)-y\\right\\| \\leq r \\}", block: true)]]

#text("is closed and contains both ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(". Let ")#mi("{K_r^1}")#text(" denote the connected component of ")#mi("{K_r}")#text(" that contains ")#mi("{x_1}")#text(". Since ")#mi("{K_r}")#text(" is non-decreasing in ")#mi("{r}")#text(", ")#mi("{K_r^1}")#text(" is non-decreasing also.")

#text("Now let us study the behaviour of ")#mi("{K_r^1}")#text(" as ")#mi("{r}")#text(" ranges from ")#mi("{0}")#text(" to ")#mi("{\\frac{4}{10} }")#text(". The two extreme cases are easy to analyse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-83b81769140c2b838f31>#text(" ")#mi("{K_0^1 = \\{x_1\\}}")#text(".")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{Df(x_1)}")#text(" is non-singular, we see from differentiability that ")#mi("{f(x) \\neq f(x_1)}")#text(" for all ")#mi("{x \\neq x_1}")#text(" sufficiently close to ")#mi("{x_1}")#text(". Thus ")#mi("{x_1}")#text(" is an isolated point of ")#mi("{K_0}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" We have ")#mi("{B(0,\\frac{1}{20} ) \\subset K_r^1 \\subset B(0,1)}")#text(" for all ")#mi("{\\frac{2}{10} \\leq r \\leq \\frac{4}{10}}")#text(". In particular, ")#mi("{K_r^1}")#text(" is compact for all ")#mi("{0 \\leq r \\leq \\frac{4}{10} }")#text(", and contains ")#mi("{x_2}")#text(" for ")#mi("{\\frac{2}{10} \\leq r \\leq \\frac{4}{10} }")#text(".")
]

#emph[#text("Proof:")]#text(" Since ")#mi("{f(B(0,\\frac{1}{20} )) \\subset B(f(0),\\frac{1}{10} ) \\subset \\overline{B(y,r)}}")#text(", we see that ")#mi("{B(0,\\frac{1}{20} ) \\subset K_r}")#text("; since ")#mi("{B(0,\\frac{1}{20} )}")#text(" is connected and contains ")#mi("{x_1}")#text(", we conclude that ")#mi("{B(0,\\frac{1}{20} ) \\subset K^1_r}")#text(".")

#text("Next, if ")#mi("{x \\in \\partial B(0,1)}")#text(", then by ")#link(<tao-7790e5f9966886cf30a0>)[#text("(3)")]#text(" we have ")#mi("{f(x) \\not \\in B(0,\\frac{1}{2})}")#text(", and hence ")#mi("{f(x) \\not \\in \\overline{B(y, r)}}")#text(". Thus ")#mi("{K_r}")#text(" is disjoint from the sphere ")#mi("{\\partial B(0,1)}")#text(". Since ")#mi("{x_1}")#text(" lies in the interior of this sphere we thus have ")#mi("{K_r^1 \\subset B(0,1)}")#text(" as required. ")#mi("\\Box")

#text("Next, we show that the ")#mi("{K_r^1}")#text(" increase continuously in ")#mi("{r}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-0cc1c74193b578d2351e>#text(" If ")#mi("{0 \\leq r < \\frac{1}{20}}")#text(" and ")#mi("{\\epsilon > 0}")#text(", then for ")#mi("{r < r^{\\prime} < \\frac{1}{20}}")#text(" sufficiently close to ")#mi("{r}")#text(", ")#mi("{K_{r^{\\prime}}^1}")#text(" is contained in an ")#mi("{\\epsilon}")#text("-neighbourhood of ")#mi("{K_r^1}")#text(".")
]

#emph[#text("Proof:")]#text(" By the finite intersection property, it suffices to show that ")#mi("{\\bigcap_{r^{\\prime}>r} K_{r^{\\prime}}^1 = K_r^1}")#text(". Suppose for contradiction that there is a point ")#mi("{x}")#text(" outside of ")#mi("{K_r^1}")#text(" that lies in ")#mi("{K_{r^{\\prime}}^1}")#text(" for all ")#mi("{r^{\\prime}>r}")#text(". Then ")#mi("{x}")#text(" lies in ")#mi("{K_{r^{\\prime}}}")#text(" for all ")#mi("{r^{\\prime}>r}")#text(", and hence lies in ")#mi("{K_r \\cap B(0,1)}")#text(". As ")#mi("{x}")#text(" and ")#mi("{x_1}")#text(" lie in different connected components of the compact set ")#mi("{K_r \\cap \\overline{B(0,1)}}")#text(" (recall that ")#mi("{K_r}")#text(" is disjoint from ")#mi("{\\partial B(0,1)}")#text("), there must be a partition of ")#mi("{K_r \\cap \\overline{B(0,1)}}")#text(" into two disjoint closed sets ")#mi("{F, G}")#text(" that separate ")#mi("{x}")#text(" from ")#mi("{x_1}")#text(" (for otherwise the only clopen sets in ")#mi("{K_r \\cap \\overline{B(0,1)}}")#text(" that contain ")#mi("{x_1}")#text(" would also contain ")#mi("{x}")#text(", and their intersection would then be a connected subset of ")#mi("{K_r \\cap \\overline{B(0,1)}}")#text(" that contains both ")#mi("{x_1}")#text(" and ")#mi("{x}")#text(", contradicting the fact that ")#mi("{x}")#text(" lies outside ")#mi("{K_r^1}")#text("). By normality, we may find open neighbourhoods ")#mi("{U, V}")#text(" of ")#mi("{F, G}")#text(" that are disjoint. For all ")#mi("{x}")#text(" on the boundary ")#mi("{\\partial U}")#text(", one has ")#tao-math("{\\left\\| f(x)-y\\right\\| > r}", block: false)#text(" for all ")#mi("{x \\in \\partial U}")#text(". As ")#mi("{\\partial U}")#text(" is compact and ")#mi("{f}")#text(" is continuous, we thus have ")#tao-math("{\\left\\| f(x)-y\\right\\| > r^{\\prime}}", block: false)#text(" for all ")#mi("{x \\in \\partial U}")#text(" if ")#mi("{r^{\\prime}}")#text(" is sufficiently close to ")#mi("{r}")#text(". This makes ")#mi("{U \\cap K_{r^{\\prime}}}")#text(" clopen in ")#mi("{K_{r^{\\prime}}}")#text(", and so ")#mi("{x}")#text(" cannot lie in ")#mi("{K_{r^{\\prime}}^1}")#text(", giving the desired contradiction. ")#mi("\\Box")

#text("Observe that ")#mi("{K_r^1}")#text(" contains ")#mi("{x_2}")#text(" for ")#mi("{r \\geq \\frac{2}{10} }")#text(", but does not contain ")#mi("{x_2}")#text(" for ")#mi("{r=0}")#text(". By the monotonicity of the ")#mi("{K_r^1}")#text(" and least upper bound principle, there must therefore exist a critical ")#mi("{0 \\leq r_* \\leq \\frac{2}{10} }")#text(" such that ")#mi("{K_r^1}")#text(" contains ")#mi("{x_2}")#text(" for all ")#mi("{r > r_*}")#text(", but does not contain ")#mi("{x_2}")#text(" for ")#mi("{r < r_*}")#text(". From Lemma ")#link(<tao-0cc1c74193b578d2351e>)[#text("7")]#text(" we see that ")#mi("{K_{r_*}^1}")#text(" must also contain ")#mi("{x_2}")#text(". In particular, by Lemma ")#link(<tao-83b81769140c2b838f31>)[#text("5")]#text(", ")#mi("{r_* > 0}")#text(".")

#text("We now analyse the critical set ")#mi("{K_{r_*}^1}")#text(". By construction, this set is connected, compact, contains both ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(", contained in ")#mi("{B(0,1)}")#text(", and one has ")#tao-math("{\\left\\|f(x)-y\\right\\| \\leq r_*}", block: false)#text(" for all ")#mi("{x \\in K_{r_*}^1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" ")#metadata(none) <tao-71b4f3a3748cd6843c01>#text(" The set ")#tao-math("{U := \\{ x \\in K_{r_*}^1: \\left\\|f(x)-y\\right\\| < r_* \\}}", block: false)#text(" is open and disconnected.")
]

#emph[#text("Proof:")]#text(" The openness is clear from the continuity of ")#mi("{f}")#text(" (and the local connectedness of ")#mi("{{\\bf R}^n}")#text("). Now we show disconnectedness. Being an open subset of ")#mi("{{\\bf R}^n}")#text(", connectedness is equivalent to path connectedness, and ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(" both lie in ")#mi("{U}")#text(", so it suffices to show that ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(" cannot be joined by a path ")#mi("{\\gamma}")#text(" in ")#mi("{U}")#text(". But if such a path ")#mi("{\\gamma}")#text(" existed, then by compactness of ")#mi("{\\gamma}")#text(" and continuity of ")#mi("{f}")#text(", one would have ")#mi("{\\gamma \\subset K_r}")#text(" for some ")#mi("{r < r_*}")#text(". This would imply that ")#mi("{x_2 \\in K_r^1}")#text(", contradicting the minimal nature of ")#mi("{r_*}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" ")#metadata(none) <tao-3b950c6c79b9eaa08e54>#text(" ")#mi("{U}")#text(" has at most finitely many connected components.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{U_1}")#text(" be a connected component of ")#mi("{U}")#text("; then ")#mi("{f(U_1)}")#text(" is non-empty and contained in ")#mi("{B(y,r_*)}")#text(". As ")#mi("{U}")#text(" is open, ")#mi("{U_1}")#text(" is also open, and thus by Corollary ")#link(<tao-2348f998744212575d85>)[#text("4")]#text(", ")#mi("{f(U_1)}")#text(" is open also.")

#text("We claim that ")#mi("{f(U_1)}")#text(" is in fact all of ")#mi("{B(y,r_*)}")#text(". Suppose this were not the case. As ")#mi("{B(y,r_*)}")#text(" is connected, this would imply that ")#mi("{f(U_1)}")#text(" is not closed in ")#mi("{B(y,r_*)}")#text("; thus there is an element ")#mi("{z}")#text(" of ")#mi("{B(y,r_*)}")#text(" which is adherent to ")#mi("{f(U_1)}")#text(", but does not lie in ")#mi("{f(U_1)}")#text(". Thus one may find a sequence ")#mi("{x_n}")#text(" in ")#mi("{U_1}")#text(" with ")#mi("{f(x_n)}")#text(" converging to ")#mi("{z}")#text(". By compactness of ")#mi("{K_{r_*}^1}")#text(" (which contains ")#mi("{U_1}")#text("), we may pass to a subsequence and assume that ")#mi("{x_n}")#text(" converges to a limit ")#mi("{x}")#text(" in ")#mi("{K_{r_*}^1}")#text("; then ")#mi("{f(x)=z}")#text(". By continuity, there is thus a ball ")#mi("{B}")#text(" centred at ")#mi("{x}")#text(" that is mapped to ")#mi("{B(y,r)}")#text(" for some ")#mi("{r < r_*}")#text("; this implies that ")#mi("{B}")#text(" lies in ")#mi("{K_{r_*}}")#text(" and hence in ")#mi("{K_{r_*}^1}")#text(" (since ")#mi("{x \\in K_{r_*}^1}")#text(") and thence in ")#mi("{U}")#text(" (since ")#mi("{r}")#text(" is strictly less than ")#mi("{r_*}")#text("). As ")#mi("{x}")#text(" is adherent to ")#mi("{U_1}")#text(" and ")#mi("{B}")#text(" is connected, we conclude that ")#mi("{B}")#text(" lies in ")#mi("{U_1}")#text(". In particular ")#mi("{x}")#text(" lies in ")#mi("{U_1}")#text(" and so ")#mi("{z=f(x)}")#text(" lies in ")#mi("{f(U_1)}")#text(", a contradiction.")

#text("As ")#mi("{f(U_1)}")#text(" is equal to ")#mi("{B(y,r_*)}")#text(", we thus see that ")#mi("{U_1}")#text(" contains an element of ")#mi("{f^{-1}(\\{y\\})}")#text(". However, each element ")#mi("{x}")#text(" of ")#mi("{f^{-1}(\\{y\\})}")#text(" must be isolated since ")#mi("{Df(x)}")#text(" is non-singular. By compactness of ")#mi("{K_{r_*}^1}")#text(", the set ")#mi("{K_{r_*}^1}")#text(" (and hence ")#mi("{U}")#text(") thus contains at most finitely many elements of ")#mi("{f^{-1}(\\{y\\})}")#text(", and so there are finitely many components as claimed. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-b1b1bdb480c61d075300>#text(" Every point in ")#mi("{K_{r_*}^1}")#text(" is adherent to ")#mi("{U}")#text(" (i.e. ")#mi("{\\overline{U} = K_{r_*}^1}")#text(").")
]

#emph[#text("Proof:")]#text(" If ")#mi("{x \\in K_{r_*}^1}")#text(", then ")#tao-math("{\\left\\|f(x)-y\\right\\| \\leq r_*}", block: false)#text(". If ")#tao-math("{\\left\\|f(x)-y\\right\\|<r_*}", block: false)#text(" then ")#mi("{x \\in U}")#text(" and we are done, so we may assume ")#tao-math("{\\left\\|f(x)-y\\right\\| = r_*}", block: false)#text(". By differentiability, one has")

#align(center)[#tao-fit-display[#tao-math("f(x^{\\prime}) = f(x) + Df(x) (x^{\\prime}-x) + o(\\left\\|x^{\\prime}-x\\right\\|)", block: true)]]

#text("for all ")#mi("{x^{\\prime}}")#text(" sufficiently close to ")#mi("{x}")#text(". If we choose ")#mi("{x^{\\prime}}")#text(" to lie on a ray emenating from ")#mi("{x}")#text(" such that ")#mi("{Df(x)(x^{\\prime}-x)}")#text(" lies on a ray pointing towards ")#mi("{y}")#text(" from ")#mi("{f(x)}")#text(" (this is possible as ")#mi("{Df(x)}")#text(" is non-singular), we conclude that for all ")#mi("{x^{\\prime}}")#text(" sufficiently close to ")#mi("{x}")#text(" on this ray, ")#tao-math("{\\left\\|f(x^{\\prime})-y\\right\\| < r_*}", block: false)#text(". Thus all such points ")#mi("{x^{\\prime}}")#text(" lie in ")#mi("{K_{r_*}}")#text("; since ")#mi("{x}")#text(" lies in ")#mi("{K_{r_*}^1}")#text(" and the ray is locally connected, we see that all such points ")#mi("{x^{\\prime}}")#text(" in fact lie in ")#mi("{K_{r_*}^1}")#text(" and thence in ")#mi("{U}")#text(". The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11")]#text(" ")#metadata(none) <tao-c5ee1a1f0bc21d1422f9>#text(" There exists a point ")#mi("{x_* \\in K_{r_*}^1}")#text(" with ")#tao-math("{\\left\\|f(x_*)-y\\right\\| = r_*}", block: false)#text(" (i.e. ")#mi("{x_*}")#text(" lies outside ")#mi("{U}")#text(") which is adherent to at least two connected components of ")#mi("{U}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose this were not the case, then the closures of all the connected components of ")#mi("{U}")#text(" would be disjoint. (Note that an element of one connected component of ")#mi("{U}")#text(" cannot lie in the closure of another component.) By Lemma ")#link(<tao-b1b1bdb480c61d075300>)[#text("10")]#text(", these closures would form a partition of ")#mi("{K_{r_*}^1}")#text(" by closed sets. By Lemma ")#link(<tao-71b4f3a3748cd6843c01>)[#text("8")]#text(", there are at least two such closed sets, each of which is non-empty; by Lemma ")#link(<tao-3b950c6c79b9eaa08e54>)[#text("9")]#text(", the number of such closed sets is finite. But this contradicts the connectedness of ")#mi("{K_{r_*}^1}")#text(". ")#mi("\\Box")

#text("Next, we prove")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" ")#metadata(none) <tao-56469d6119aa005479af>#text(" Let ")#mi("{x_* \\in K_{r_*}^1}")#text(" be such that ")#tao-math("{\\left\\|f(x_*)-y\\right\\|=r_*}", block: false)#text(", and suppose that ")#mi("{x}")#text(" is adherent to a connected component ")#mi("{U_1}")#text(" of ")#mi("{U}")#text(". Let ")#mi("{\\omega}")#text(" be the vector such that ")#metadata(none) <tao-328c5022ccc950d0bc9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("Df(x_*) \\omega = y - f(x_*)")]]

#text("(this vector exists and is non-zero since ")#mi("{Df(x_*)}")#text(" is non-singular). Then ")#mi("{U_1}")#text(" contains an open ray of the form ")#mi("{\\{ x_* + t \\omega: 0 < t < \\epsilon \\}}")#text(" for some ")#mi("{\\epsilon > 0}")#text(".")
]

#text("This together with Corollary ")#link(<tao-c5ee1a1f0bc21d1422f9>)[#text("11")]#text(" gives the desired contradiction, since one cannot have two distinct components ")#mi("{U_1, U_2}")#text(" both contain a ray from ")#mi("{x_*}")#text(" in the direction ")#mi("{\\omega}")#text(".")

#emph[#text("Proof:")]#text(" As ")#mi("{f}")#text(" is differentiable at ")#mi("{x_*}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("f(x_* + t\\omega) = f(x_*) + Df(x_*) t \\omega + o(\\left|t\\right|)", block: true)]]

#text("for all sufficiently small ")#mi("{t}")#text("; we rearrange this using ")#link(<tao-328c5022ccc950d0bc9c>)[#text("(5)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("f(x_* + t \\omega) - y = (1-t) (f(x_*) - y) + o(\\left|t\\right|).", block: true)]]

#text("In particular, ")#mi("{f(x_*+t\\omega) \\in B(y,r_*)}")#text(" for all sufficiently small positive ")#mi("{t}")#text(". This shows that all sufficiently small open rays ")#mi("{\\{ x_* + t \\omega: 0 < t < \\epsilon \\}}")#text(" lie in ")#mi("{K_{r_*}}")#text(", hence in ")#mi("{K_{r_*}^1}")#text(" (since ")#mi("{x_* \\in K_{r_*}^1}")#text("), and hence in ")#mi("{U}")#text(". In fact, the same argument shows that there is a cone ")#metadata(none) <tao-cff179e7721e503c090c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\{ x_* + t \\omega^{\\prime}: 0 < t < \\epsilon; \\left\\|\\omega^{\\prime} - \\omega\\right\\| \\leq \\epsilon \\}", block: true)]]

#text("that will lie in ")#mi("{U}")#text(" if ")#mi("{\\epsilon}")#text(" is small enough. As this cone is connected, it thus suffices to show that ")#mi("{U_1}")#text(" intersects this cone.")

#text("Let ")#mi("{\\delta > 0}")#text(" be a small radius to be chosen later. As ")#mi("{Df(x_*)}")#text(" is non-singular, we see if ")#mi("{\\delta}")#text(" is small enough that ")#mi("{f(x) \\neq f(x_*)}")#text(" whenever ")#tao-math("{\\left\\|x-x_*\\right\\| = \\delta}", block: false)#text(". By continuity, we may thus find ")#mi("{\\kappa > 0}")#text(" such that ")#tao-math("{\\left\\|f(x)-f(x_*)\\right\\| > \\kappa}", block: false)#text(" whenever ")#tao-math("{\\left\\|x-x_*\\right\\| = \\delta}", block: false)#text(".")

#text("Consider the set")

#align(center)[#tao-fit-display[#tao-math("U^{\\prime} := \\{ x \\in U_1: \\left\\|x-x_*\\right\\| \\leq \\delta; \\left\\|f(x)-f(x_*)\\right\\| < \\kappa \\}.", block: true)]]

#text("As ")#mi("{x_*}")#text(" is adherent to ")#mi("{U_1}")#text(", ")#mi("{U^{\\prime}}")#text(" is non-empty. By construction of ")#mi("{\\kappa}")#text(", we see that we also have")

#align(center)[#tao-fit-display[#tao-math("U^{\\prime} := \\{ x \\in U_1: \\left\\|x-x_*\\right\\| < \\delta; \\left\\|f(x)-f(x_*)\\right\\| < \\kappa \\}", block: true)]]

#text("and so ")#mi("{U^{\\prime}}")#text(" is open. By Corollary ")#link(<tao-2348f998744212575d85>)[#text("4")]#text(", ")#mi("{f(U^{\\prime})}")#text(" is then also non-empty and open. By construction, ")#mi("{f(U^{\\prime})}")#text(" also lies in the set")

#align(center)[#tao-fit-display[#tao-math("D := \\{ z \\in B(y,r_*): \\left\\|z-f(x_*)\\right\\| < \\kappa \\}.", block: true)]]

#text("We claim that ")#mi("{f(U^{\\prime})}")#text(" is in fact all of ")#mi("{D}")#text(". The proof will be a variant of the proof of Lemma ")#link(<tao-3b950c6c79b9eaa08e54>)[#text("9")]#text(". Suppose this were not the case. As ")#mi("{D}")#text(" is connected, this implies that there is an element ")#mi("{z}")#text(" of ")#mi("{D}")#text(" which is adherent to ")#mi("{f(U^{\\prime})}")#text(", but does not lie in ")#mi("{f(U^{\\prime})}")#text(". Thus one may find a sequence ")#mi("{x_n}")#text(" in ")#mi("{U^{\\prime}}")#text(" with ")#mi("{f(x_n)}")#text(" converging to ")#mi("{z}")#text(". By compactness of ")#mi("{K_{r_*}^1}")#text(" (which contains ")#mi("{U^{\\prime}}")#text("), we may pass to a subsequence and assume that ")#mi("{x_n}")#text(" converges to a limit ")#mi("{x}")#text(" in ")#mi("{K_{r_*}^1}")#text("; then ")#mi("{f(x)=z}")#text(". By continuity, there is thus a ball ")#mi("{B}")#text(" centred at ")#mi("{x}")#text(" contained in ")#mi("{B(x_*,\\delta)}")#text(" that is mapped to ")#mi("{B(y,r) \\cap D}")#text(" for some ")#mi("{r < r_*}")#text("; this implies that ")#mi("{B}")#text(" lies in ")#mi("{K_{r_*}}")#text(" and hence in ")#mi("{K_{r_*}^1}")#text(" (since ")#mi("{x \\in K_{r_*}^1}")#text(") and thence in ")#mi("{U}")#text(" (since ")#mi("{r}")#text(" is strictly less than ")#mi("{r_*}")#text("). As ")#mi("{x}")#text(" is adherent to ")#mi("{U_1}")#text(" and ")#mi("{B}")#text(" is connected, we conclude that ")#mi("{B}")#text(" lies in ")#mi("{U_1}")#text(" and thence in ")#mi("{U^{\\prime}}")#text(". In particular ")#mi("{x}")#text(" lies in ")#mi("{U^{\\prime}}")#text(" and so ")#mi("{z=f(x)}")#text(" lies in ")#mi("{f(U^{\\prime})}")#text(", a contradiction.")

#text("As ")#mi("{f(U^{\\prime}) = D}")#text(", we may thus find a sequence ")#mi("{t_n > 0}")#text(" converging to zero, and a sequence ")#mi("{x_n \\in U^{\\prime}}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("f(x_n) = f(x_*) + t_n (y - f(x_*)).")]]

#text("However, if ")#mi("{\\delta}")#text(" is small enough, we have ")#tao-math("{\\left\\|f(x_n)-f(x_*)\\right\\|}", block: false)#text(" comparable to ")#tao-math("{\\left\\|x_n-x_*\\right\\|}", block: false)#text(" (cf. ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(2)")]#text("), and so ")#mi("{x_n}")#text(" converges to ")#mi("{x_*}")#text(". By Taylor expansion, we then have")

#align(center)[#tao-fit-display[#tao-math("f(x_n) = f(x_*) + Df(x_*) (x_n-x_*) + o(\\left\\|x_n-x_*\\right\\|)", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("(Df(x_*)+o(1)) (x_n-x_*) = t_n Df(x_*) \\omega")]]

#text("for some matrix-valued error ")#mi("{o(1)}")#text(". Since ")#mi("{Df(x_*)}")#text(" is invertible, this implies that")

#align(center)[#tao-fit-display[#mitex("x_n-x_* = t_n (1+o(1)) \\omega = t_n \\omega + o(t_n).")]]

#text("In particular, ")#mi("{x_n}")#text(" lies in the cone ")#link(<tao-cff179e7721e503c090c>)[#text("(6)")]#text(" for ")#mi("{n}")#text(" large enough, and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (40)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/949494182c5c9a1c632f04630468ebef1a228a8c633c5fc60773cfa696cd01aa-0d59957573aa391c62aebcac013482a0721b6f88457ef2151c12bf7774a5c683.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leandro Cioletti")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-78154")[#strong[#text("Leandro Cioletti")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2011")])]

#text("Thanks for sharing this. I read the mathoverflow question and I liked very much this result, but we don’t have in our local library a copy of the papers cited there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23c686e415e220c5557688edacf37a60daed1e6668dd2e2191b2365deab7eebd-78529f7ecb7aeb31c02f57edd7cede70d26fc30d0241204ee074122d60626baf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-78177")[#strong[#text("Philippe")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2011")])]

#text("Small correction: the person that pointed this proof to you is Julien Melleray (not Malleray).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3f2c03f49b750c1b431f41d4280e47d76fe3022158db915889845990324caed-072ddf18b1d867aab7daf6df10bcdb8f19c3a1f7f188f7a2da65328f450817ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vineel567")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-78244")[#strong[#text("vineel567")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2011")])]

#text("what tools do you use to write such a wonderful technical articles with all the special characters and mathematical style preserved.??? Thanks in advance")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-79372")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2011")])]

#text("Take a look at this page: ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" especially after the “Some technical remarks” fold.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ed3650baba38b454478973f06693caab97c9e266d4cea92d13d134fed974cbd-d7962b9421990fcee2cc9f8b9a1b000bdc04a7513fd4dadd13eff49058a0238b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-79198")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2011")])]

#text("Sorry I mean everywhere invertibility. Is it necessary? If so why is the local invertibility not sufficient?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-79373")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2011")])]

#text("The statement does only require local invertibility, no? It only requires invertibility at every point in the open neighborhood ")#mi("\\Omega")#text(". Or are you asking whether invertibility at a single point is sufficient?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-79430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2011")])]

#text("This result seems counter-intuitive. In the 1D case, if f'(x)<0 for x0 for x>x_0 then it doesn’t seem possible for the function f to be invertible at x_0. Also, the derivative is invertible in a neighborhood of x_0 so it seems to satisfy the conditions of the theorem.")

#emph[#text("[You will need to use &lt; and &gt; instead of < and > to avoid your comments being mangled by the HTML parser. In any event, in one dimension the result is precisely the contrapositive of Rolle’s theorem. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-79434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2011")])]

#text("It should be f'(x)0 for x > x0.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/485a62618ed0bd11efcb8fe09860fcaf34bf8907bab047ab50932365ce20810f-69b8acde7b7404ec8fd00e387d781415da1f583dcaed0026b45f2338bd1092dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Swanson")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-80773")[#strong[#text("Josh Swanson")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2011")])]

#text("Thank you for typing this up! Reading through it was a nice review of basic real analysis and topology.")

#text("The Brouwer fixed point theorem is false with open balls, so the map you mention in the proof of Proposition 3 should be between closed balls. Even so, the fixed point isn’t on the boundary (from (3) scaled by the magnitude of x) so the result still follows easily.")

#text("In the same proposition, I wasn’t able to follow the reasoning in your third argument which gives |x| < r (i.e. |x| is not r) without taking |y| < r/3 rather than |y| < r/2. This doesn’t seem to affect anything adversely, though. I really like that argument since it makes the overall proof much more elementary.")

#text("I wasn’t able to follow the reasoning in the last few lines–in particular replacing o(||x_n – x_*||) with o(t_n). I was able to show the result anyway, though I had to pass to a further subsequence and use the invertibility of the derivative to do so.")

#text("Minor typos/issues:")#linebreak()#text(" “point set” -> “point-set”")#linebreak()#text(" “A third argument (…) as follows” -> “A third argument (…) is as follows”")#linebreak()#text(" “image of any open neighborhood” -> “the image of any open neighborhood”")#linebreak()#text(" In the proof of Lemma 6, strictly speaking the B(y, r) should be closed in each case")#linebreak()#text(" In Lemma 7, dividing delta by 2 doesn’t seem to serve a purpose")#linebreak()#text(" “then f(U_1) is non-empty contained in” -> “then f(U_1) is non-empty and contained in”")#linebreak()#text(" “conpactness” -> “compactness”")#linebreak()#text(" “This together with Corollary 11 with” -> “This together with Corollary 11”")#linebreak()#text(" In defining U’ (and in the restatement right after), there’s a missing vertical bar")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-81777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2011")])]

#text("What about the following proof? Is it related to Cernavskii’s or Vaisala’s?")

#text("As above, let’s prove that ")#mi("f")#text(" is a local homeomorphism at a point ")#mi("x_0\\in\\Omega")#text(". We may assume ")#mi("f(x_0)=x_0=0")#text(" and ")#tao-math("\\left|f(x)-x\\right|<\\frac{1}{2}\\left|x\\right|", block: false)#text(" for ")#mi("x\\in B(0,1)")#text(".")

#text("Due to Proposition 3 above, for each ")#mi("y\\in \\overline{B(0,\\frac{1}{3})}")#text(", there is a point in ")#mi("x\\in \\overline{B(0,\\frac{2}{3})}")#text(" such that ")#mi("f(x)=y")#text(". Moreover, ")#mi("f^{-1}(y)")#text(" is compact. Take, in ")#mi("f^{-1}(y)")#text(", the point with maximum first coordinate. If there is more than one such point, take the that with maximum second coordinate, and so forth. Let the chosen point equal ")#mi("g(y)")#text(".")

#text("The function ")#mi("g")#text(" is continuous, since")

#text("i) Because ")#mi("f")#text(" is open, for every point near ")#mi("y")#text(" there is a pre-image near ")#mi("f(y)")#text(".")#linebreak()#text(" ii) If there is a sequence ")#mi("y_n\\to y")#text(" such that, say, ")#mi("g(y_n)")#text(" has first coordinate bigger than the first coordinate of ")#mi("g(y)")#text(" with a non-vanishing difference, we can take a subsequence ")#mi("y_{n_k}")#text(" which converges to a point ")#mi("y^{\\prime}")#text(" whose first coordinate is bigger than that of ")#mi("y")#text(", a contradiction.")

#mi("g")#text(" is obviously injective, and it is defined in a compact set. Thus, ")#mi("g")#text(" is a homeomorphism.")

#text("This function is also a left inverse of ")#mi("f")#text(" (that is, ")#mi("g\\circ f=id")#text(" in the image of ")#mi("g")#text("). The claim then follows from the fact that injective continuous functions from ")#mi("n")#text("-dimensional sets to ")#mi("n")#text("-dimensional sets are open.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-81798")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2011")])]

#text("I don’t think the proof of the continuity of g is complete, even in the one-dimensional case. For instance, what prevents ")#mi("g(y_n)")#text(" from being significantly below ")#mi("g(y)")#text(" in one dimension?")

#text("Note that there are plenty of continuous proper maps without continuous left-inverses, e.g. ")#mi("f(x) := x^3 - x")#text(" in one dimension. (Note in this case that the function g as defined above is discontinuous.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-81848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2011")])]

#text("Errata: above, the line “which converges to a point ")#mi("y^{\\prime}")#text(" whose first coordinate is bigger than that of ")#mi("y")#text(", a contradiction” is wrong. Instead of it, define ")#mi("x=g(y)")#text(" and read “such that ")#mi("g(y_{n_k})")#text(" converges to a point ")#mi("x^{\\prime}")#text(" whose first coordinate is bigger than that of ")#mi("x")#text(", a contradiction”.")

#text("Dear Tao,")

#text("indeed that “proof” is wrong. I still think the case ")#mi("n=1")#text(" is ok:")

#text("Take any neighborhood ")#mi("N")#text(" of ")#mi("x")#text(". If ")#mi("m")#text(" is sufficiently large, ")#mi("y_m\\in f(N)")#text(", so we have a candidate ")#mi("z_m")#text(" for ")#mi("g(y_m)")#text(" in ")#mi("N")#text(". We may suppose ")#mi("z_m\\to x")#text(" (e.g., by choosing ")#mi("z_m")#text(" as close to ")#mi("x")#text(" as possible).")

#text("In one dimension, by definition, ")#mi("x_m")#text(" is the biggest element of ")#mi("f^{-1}(y_m)")#text(", so that its lim inf is at least ")#mi("\\lim_{m\\to\\infty}z_m=x")#text(". Then, as above, if ")#mi("y_m")#text(" does not go to ")#mi("x")#text(", we achieve a contradiction.")

#text("However, in more dimensions, I have overlooked something: the coordinates of the ")#mi("y_m")#text("‘s don’t behave in the same way.")

#text("For the sake of clarity, given any ")#mi("a,b\\in\\mathbb R^n")#text(", let’s say ")#mi("a> b")#text(" if and only if ")#mi("a=b")#text(" or one of the following conditions holds.")

#mi("a_1> b_1")#text(".")#linebreak()#text(" ")#mi("a_1=b_1")#text(" and ")#mi("a_2> b_2")#text(".")#linebreak()#text(" ")#mi("a_1=b_1")#text(", ")#mi("a_2=b_2")#text(" and ")#mi("a_3> b_3")#text(".")#linebreak()#text(" Etc.")

#text("The failure of the proof is related to the instability of the relation above: if ")#mi("p")#text(" and ")#mi("q")#text(" are sequences such that ")#mi("p_m > q_m")#text(", ")#mi("\\lim_{m\\to\\infty} p_m=p")#text(" and ")#mi("\\lim_{m\\to\\infty} q_m=q")#text(", it is not necessarily true that ")#mi("p\\geq q")#text(".")

#text("I will try to fix the argument, even though I think success is not probable.")

#text("Question: if ")#mi("g")#text(" were continous, doesn’t the conclusion follow? For it is known that injective continuous maps (in this case, ")#mi("g")#text(") are local homeomorphisms. So ")#mi("g")#text(" would a homeomorphism between two neighborhoods of ")#mi("0")#text(", and ")#mi("f")#text(" should be its inverse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-82429")[#strong[#text("Twelth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")]

#text("[…] Tao: The inverse function theorem for everywhere differentiable maps, The Brunn-Minkowski inequality for nilpotent […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8fca51d51d67bd4c7358d7c54247d28b01d50483b99c9482447316889ad6c0-0c29a534082f19a6a4a98b0f84ca03874df6f107bce899f1ae2d287f3bb301e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-82959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2011")])]

#text("Dear Prof. Tao,")

#text("in the proof of lemma 7 you ask the reader to “note that ")#mi("K_{r} \\setminus K_{r}^{1}")#text(" is closed”. Can you give me a hint on how to see this? Components are closed in general (which gives the compactness of ")#mi("K_{r}^{1}")#text("), but I do not see, why ")#mi("K_{r}^{1}")#text(" is also open (relative to ")#mi("K_{r}")#text(").")

#text("Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-83183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2011")])]

#text("Oops, the argument is not quite correct as stated; I’ve rewritten it. The key point is that in a compact set, any two points that don’t lie in the same connected component can be separated from each other by clopen sets (but the connected components themselves need not be clopen).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-90804")[#strong[#text("Implicit function theorem | Mathitself")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")]

#text("[…] deep result is that it’s enough that is everywhere differentiable (see Tao’s post), which remains one an other deep result called invariance of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8aab725368e54fcd10014623a211c088537e6dc79bbf273f54be8ff259a1117-4cb95400a9c42c3a04279611d6ebd457bf90cbcda00283e62fee31bf996d5bd0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of francescodifusco")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-132485")[#strong[#text("francescodifusco")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2012")])]

#text("Reblogged this on ")#link("http://francescodifusco.wordpress.com/2012/03/10/4732/")[#text("FRANCESCO DI FUSCO")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ee9affc630aec9b08b964c45dbf522332f7164015d9655a3db2744e18f633e2-5eb51005278a6ff78775489dbacce6215bd3c268fa210235d1e71d6b65d76752.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Macdonald")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-133963")[#strong[#text("Alan Macdonald")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2012")])]

#text("The paper “A Strong Inverse Function Theorem” by William J. Knight")#linebreak()#text(" (The American Mathematical Monthly, Vol. 95, No. 7, pp. 648-651) gives an improvement of the standard result in a different direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4425e3cf260714fa623bb5a2a7f0a079b062e9e5548e361a0d79e443a587ee49-9e9191223b9f1860a0b8223ab7e80e3b2186f8bd6f93b984f91177690a6b4c4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olaf Zurth")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-168300")[#strong[#text("Olaf Zurth")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2012")])]

#text("A Question: Is there in the first line of Lemma 6 a typo?")#linebreak()#text(" ")#mi("{0,\\frac{2}{10} \\leq r \\leq \\frac{4}{10}}")#text(" should read as ")#mi("{\\frac{2}{10} \\leq r \\leq \\frac{4}{10}}")#text(" or did I misunderstood something?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e82518f5070ee72b6ad09d1c548a8f43ed968acce75ee378bc532fc8834d05-7f65f588638da8ed85a67f283ba5e99f67cda8543d2712b6005fa6e43d19e3db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of blindman")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-190755")[#strong[#text("blindman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2012")])]

#text("Dear Professor Tao,")

#text("the local inverses ")#mi("f^{-1}:V\\rightarrow U")#text(" are also differentiable at ")#mi("x_0")

#text("should be replaced by")

#text("the local inverses ")#mi("f^{-1}:V\\rightarrow U")#text(" are also differentiable at ")#mi("f(x_0)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e82518f5070ee72b6ad09d1c548a8f43ed968acce75ee378bc532fc8834d05-7f65f588638da8ed85a67f283ba5e99f67cda8543d2712b6005fa6e43d19e3db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of blindman")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-190761")[#strong[#text("blindman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2012")])]

#text("Dear Professor Terence Tao,")

#text("In the book “Mathematical Analysis on Manifold” of Michael Spivak, the author gave a counterexample of Theorem 1 (Exercise 2.39, page 52) if the assumption on the continuity of the derivate ")#mi("f^{\\prime}")#text(" is violated.")#linebreak()#text(" They consider the function ")#mi("f::\\mathbb{R}\\rightarrow\\mathbb{R}")#text(" given by")

#text("+ ")#mi("f(x)=\\frac{x}{2}+x^2\\sin\\frac{1}{x}")#text(" if ")#mi("x\\ne 0")#text(";")

#text("+ ")#mi("f(x)=0")#text(" if ")#mi("x=0")

#text("I would to ask your comments about this situation.")

#text("Thank your for your helping.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-190764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2012")])]

#text("This function has non-zero derivative at 0, but has vanishing derivative at many other points (as can be seen for instance from ")#link("http://www.wolframalpha.com/input/?i=plot+x%2F2+%2B+x%5E2+sin%281%2Fx%29+from+x%3D0+to+x%3D.2")[#text("a plot of the function")]#linebreak()#text(" ), and so does not contradict Theorem 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e82518f5070ee72b6ad09d1c548a8f43ed968acce75ee378bc532fc8834d05-7f65f588638da8ed85a67f283ba5e99f67cda8543d2712b6005fa6e43d19e3db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of blindman")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-190899")[#strong[#text("blindman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2012")])]

#text("Dear Sir. Thank you for your comments and helping.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad9aec3dc9ac04234eb5ea2a227b7745b5e3f826c6116cf5928e632313c48fa9-d1f26c9a4f9dc1af82529a1522c095ce853e37aa1ab0f7de55ac8f7d5a2eb046.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pera")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-204936")[#strong[#text("pera")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2012")])]

#text("And what would be counterexample?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef1d24718837cfb1d018799972475ce115a04549d6412d912a54cd648f2ec189-c641aa3beb1aaa0bc45a163f330301879d881ff5034e46be28dc4c4eab8ed124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-280109")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("Why not just to use the Mean value theorem on a segment $[x_1,x_2]$ to obtain injectivity immidiately instead of all these lemmas?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef1d24718837cfb1d018799972475ce115a04549d6412d912a54cd648f2ec189-c641aa3beb1aaa0bc45a163f330301879d881ff5034e46be28dc4c4eab8ed124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-280807")[#strong[#text("Alexander")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2014")])]

#text("Ok, I see: because there’s no such a theorem… sorry!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-463670")[#strong[#text("The inverse function theorem | Negro's notes")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2015")]

#text("[…] differentiable conditions on a mapping which ensure that it is a local diffeomorphism. (But see Terry Tao’s blog for a differentiable, non-smooth inverse function theorem). The main point of such theorems is the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/586da1dacbbc1c82e1cc1e625dbe5274959090524877b6c46e57ef40d864383c-a99da5f0f19e3863139836030ae50da6f1a5821ddd619d990571a1762de8e62f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mladen Đalto")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-474581")[#strong[#text("Mladen Đalto")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2016")])]

#text("Is there a pseudoinverse version of this theorem for $ f: \\mathbb{R}^n \\rightarrow \\mathbb{R}^m$ where $n$ is not equal $m$ ?")#linebreak()#text(" If not, what method of proof/research would you recommend ?")#linebreak()#text(" I require it for machine learning research so any pointers would be appreciated.")#linebreak()#text(" Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-479873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2017")])]

#text("In Spivak’s Calculus on manifolds, there is an exercise that the function ")#mi("f:\\mathbb{R}\\to\\mathbb{R}")#text(" defined by")

#mi("\\displaystyle f(x)=\\frac{x}{2}+x^2\\sin\\frac{1}{x},\\quad x\\neq 0")

#text("and ")#mi("f(0)=0")#text(" shows that continuity of the derivative cannot be eliminated from the hypothesis of the inverse function theorem. Why does this not contradict Theorem 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-479889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2017")])]

#text("This map ")#mi("f")#text(" has an infinite number of critical points near the origin, so the hypotheses of Theorem 2 are not satisfied. (Perhaps the formulation of the inverse function theorem in Spivak is slightly different, in that one only demands invertibility of the derivative at a single point, rather than on an entire domain.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-479905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2017")])]

#text("I’m very much curious about motivation of considering the map ")#mi("{x \\mapsto x-f(x)+y}")#text(", which is the key step to recover the proof of Theorem 1. Other than just memorizing it, I have never seen in any textbook an explanation for a possible motivation (algebra? geometry? or something else) for this map.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-479907")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2017")])]

#text("If ")#mi("f(0)=0")#text(" and ")#mi("Df(0)")#text(" is the identity, then Taylor expansion suggests the approximation ")#mi("f(x) \\approx x")#text(" for small ")#mi("x")#text(". If this approximation were exact – ")#mi("f(x) = x")#text(" – then one could easily solve the equation ")#mi("f(x)=y")#text(" by writing it as ")#mi("x=y")#text(". But the approximation is inexact; the best one can do with regards to transforming ")#mi("f(x)=y")#text(" to an equation that looks like ")#mi("x=y")#text(" is to add ")#mi("x-f(x)")#text(" to both sides to obtain ")#mi("x = x - f(x) + y")#text(". The error here ")#mi("x-f(x)")#text(" is not zero, but it is “small”, and in particular (for small ")#mi("x")#text(" and continuously differentiable ")#mi("f")#text(") the map ")#mi("x \\mapsto x - f(x)+y")#text(" still behaves somewhat like a constant, in that it is a contraction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbc3671ad8ec28f22aae48971fbf53a2e7370e157ddd6b1cb6a881ab149f723c-1036ddbc0d965b1609fb001766b5d65c718175f12fae1817bc72f7ea118c89be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Higgins")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-494843")[#strong[#text("Joe Higgins")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2018")])]

#text("Can you give a hint about the statement ‘one can recover the differentiability of the local inverses’ please? Much appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-494863")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2018")])]

#text("Let’s say ")#mi("y_0 = f(x_0)")#text(". If ")#mi("y_n")#text(" approaches ")#mi("y_0")#text(", then by the homeomorphism property we have local inverses ")#mi("x_n = f^{-1}(y_n)")#text(" that approach ")#mi("x_0")#text(". On the other hand, we have the Newton approximation ")#tao-math("f(x_n) = f(x_0) + Df(x_0)(x_n-x_0) + o(\\left|x_n-x_0\\right|)", block: false)#text(". One can put these facts together to obtain the usual formula for the derivative of ")#mi("f^{-1}")#text(" at ")#mi("y_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-682637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2023")])]

#text("I’m a little confused about this, following the hint I obtain $f^{-1}(y) = f^{-1}(y_0) + (Df(x_0))^{-1}(y-y_0) + o(|f^{-1}(y)-f^{-1}(y_0)|$, so I have to prove that $o(|f^{-1}(y)-f^{-1}(y_0)|$ is also $o(|y-y_0|)$, but I can’t find a way without supposing continuity of $Df$ at the point $x_0$. Thank you in advance.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f195b10d79bb2e0b1f360d0c053cc93c3cf1396b3e9f28514669a4455d88b628-c89f9d167423df289729e1eaea7abccd6492843724b9aa74cc797c7a0b509695.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaikrishnan Janardhanan")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-573492")[#strong[#text("Jaikrishnan Janardhanan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2020")])]

#text("There seems to be a new and elementary proof of the inverse function theorem for just everywhere differentiable maps:")#linebreak()#text(" ")#link("https://www.jstor.org/stable/10.14321/realanalexch.43.2.0429")[#text("https://www.jstor.org/stable/10.14321/realanalexch.43.2.0429")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b93dcf4545e60d0e25dffb8a5108ff9ef36318fd2a3e508d184b68fa566da28-ce292b95913cab01735ffd7b6de5bd5caf5c4229d7e98eac5e3bb36a4f51b0d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eduardo Ramos")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-671947")[#strong[#text("Eduardo Ramos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2023")])]

#text("Hello Terence Tao. Are you still interested in such question? I think I solved the infinite dimension case, where I proved the same is true in Bannach Spaces as long as F is “locally proper” in some sense, which includes for instance functions of the form I+K, K being compact. Additionally I think the proof is actually simpler, and generates interesting results in more general spaces. Could you read my proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b93dcf4545e60d0e25dffb8a5108ff9ef36318fd2a3e508d184b68fa566da28-ce292b95913cab01735ffd7b6de5bd5caf5c4229d7e98eac5e3bb36a4f51b0d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eduardo Ramos")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-671949")[#strong[#text("Eduardo Ramos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2023")])]

#text("Specifically, I proved that for Banach spaces ")#mi("X")#text(" and ")#mi("Y")#text(", if ")#mi("F: U\\subset X\\to Y")#text(" is Fréchet differentiable and ")#mi("DF(x):X\\to Y")#text(" invertible for all ")#mi("x\\in U")#text(", then ")#mi("F")#text(" will be a local homeomorphism if and only if ")#mi("F")#text(" is ‘locally proper’.")

#text("Here ")#mi("F")#text(" being locally proper means that for each ")#mi("x_0\\in U")#text(" there exists a closed neighborhood ")#mi("V\\subset U")#text(" of ")#mi("x_0")#text(" such that if ")#mi("(x_n)")#text(" is a sequence in ")#mi("V")#text(" with ")#mi("F(x_n)\\to c\\in Y")#text(", then ")#mi("(x_n)")#text(" has a convergent subsequence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b93dcf4545e60d0e25dffb8a5108ff9ef36318fd2a3e508d184b68fa566da28-ce292b95913cab01735ffd7b6de5bd5caf5c4229d7e98eac5e3bb36a4f51b0d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eduardo Ramos")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-672369")[#strong[#text("Eduardo Ramos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2023")])]

#text("Well, after checking each detail of my proof I found an error. Actually with the above conditions I can only prove that ")#mi("F")#text(" is an open map. Under the above hypothesis I also found a similar argument for the infinite dimensional case that can follow all steps of your arguments up to Proposition 12, where it sadly fails. Soon I will publish the open mapping result, and will keep working on the local injectivity problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b62b1a0302d2cb2103e1e31011efe13d7c706d9c6b68cb10e6456b5399ebf28-024f67cd39f8f68a418ee65007ce40dff3e60c3490520bd1c24b52d9995c3d93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A A")]], [#link("https://terrytao.wordpress.com/2011/09/12/the-inverse-function-theorem-for-everywhere-differentiable-maps/#comment-688461")[#strong[#text("A A")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("… uniform upper bound ")#tao-math("\\left\\| f(x) \\right\\| < \\frac{1}{10}", block: false)#text(" for all ")#mi("x\\in \\partial B(0, \\frac{1}{20})")#text("; …")
]

#text("Dear Professor Tao — very minor and feel free to ignore, but think here you probably meant ")#mi("x\\in B(0, \\frac{1}{20})")#text(" (i.e the whole closed ball, not just its boundary).")

#emph[#text("[Corrected, thanks – T.]")]
]
