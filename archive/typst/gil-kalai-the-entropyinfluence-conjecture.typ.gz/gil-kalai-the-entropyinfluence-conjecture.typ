// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:16:27.731713+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Gil Kalai) The entropy/influence conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Gil Kalai) The entropy/influence conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/")[#text("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[")#emph[#text("This post is authored by ")#link("http://www.ma.huji.ac.il/~kalai/")[#text("Gil Kalai")]#text(", who has kindly “guest blogged” this week’s “open problem of the week”.")]#text(" – T.]")

#text("The ")#emph[#text("entropy-influence conjecture")]#text(" seeks to relate two somewhat different measures as to how a boolean function has concentrated Fourier coefficients, namely the total influence and the entropy.")

#text("We begin by defining the total influence. Let ")#mi("\\{-1,+1\\}^n")#text(" be the discrete cube, i.e. the set of ")#mi("\\pm 1")#text(" vectors ")#mi("(x_1,\\ldots,x_n)")#text(" of length n. A ")#emph[#text("boolean function")]#text(" is any function ")#mi("f: \\{-1,+1\\}^n \\to \\{-1,+1\\}")#text(" from the discrete cube to {-1,+1}. One can think of such functions as “voting methods”, which take the preferences of n voters (+1 for yes, -1 for no) as input and return a yes/no verdict as output. For instance, if n is odd, the “majority vote” function ")#mi("\\text{sgn}(x_1+\\ldots+x_n)")#text(" returns +1 if there are more +1 variables than -1, or -1 otherwise, whereas if ")#mi("1 \\leq k \\leq n")#text(", the “")#mi("k^{th}")#text(" dictator” function returns the value ")#mi("x_k")#text(" of the ")#mi("k^{th}")#text(" variable.")

#text("We give the cube ")#mi("\\{-1,+1\\}^n")#text(" the uniform probability measure ")#mi("\\mu")#text(" (thus we assume that the n voters vote randomly and independently). Given any boolean function f and any variable ")#mi("1 \\leq k \\leq n")#text(", define the ")#emph[#text("influence")]#text(" ")#mi("I_k(f)")#text(" of the ")#mi("k^{th}")#text(" variable to be the quantity")

#align(center)[#tao-fit-display[#mitex("I_k(f) := \\mu \\{ x \\in \\{-1,+1\\}^n: f(\\sigma_k(x)) \\neq f(x) \\}")]]

#text("where ")#mi("\\sigma_k(x)")#text(" is the element of the cube formed by flipping the sign of the ")#mi("k^{th}")#text(" variable. Informally, ")#mi("I_k(f)")#text(" measures the probability that the ")#mi("k^{th}")#text(" voter could actually determine the outcome of an election; it is sometimes referred to as the ")#link("http://www.cs.unc.edu/~livingst/Banzhaf/")[#text("Banzhaf power index")]#text(". The ")#emph[#text("total influence")]#text(" I(f) of f (also known as the ")#emph[#text("average sensitivity")]#text(" and the ")#emph[#text("edge-boundary density")]#text(") is then defined as")

#align(center)[#tao-fit-display[#mitex("I(f) := \\sum_{k=1}^n I_k(f).")]]

#text("Thus for instance a dictator function has total influence 1, whereas majority vote has total influence comparable to ")#mi("\\sqrt{n}")#text(". The influence can range between 0 (for constant functions +1, -1) and n (for the parity function ")#mi("x_1 \\ldots x_k")#text(" or its negation). If f has mean zero (i.e. it is equal to +1 half of the time), then the ")#emph[#text("edge-isoperimetric inequality")]#text(" asserts that ")#mi("I(f) \\geq 1")#text(" (with equality if and only if there is a dictatorship), whilst the ")#link("http://www.ams.org/mathscinet-getitem?mr=1194785")[#text("Kahn-Kalai-Linial")]#text(" (KKL) theorem asserts that ")#mi("I_k(f) \\gg \\frac{\\log n}{n}")#text(" for some k. There is a ")#link("http://www.ams.org/mathscinet-getitem?mr=1645642")[#text("result of Friedgut")]#text(" that if ")#mi("I(f)")#text(" is bounded by A (say) and ")#mi("\\varepsilon > 0")#text(", then f is within a distance ")#mi("\\varepsilon")#text(" (in ")#mi("L^1")#text(" norm) of another boolean function g which only depends on ")#mi("O_{A,\\varepsilon}(1)")#text(" of the variables (such functions are known as ")#link("http://en.wikipedia.org/wiki/Military_dictatorship")[#text("juntas")]#text(").")

#metadata(none) <tao-db36519dec4d8f0544c3>

#text("Now we define the entropy. For this we recall the ")#emph[#text("Fourier-Walsh expansion")]

#align(center)[#tao-fit-display[#mitex("f=\\sum_{S \\subset \\{-1,+1\\}^n}  \\hat f (S)U_S")]]

#text("of any real-valued function ")#mi("f: \\{-1,+1\\}^n \\to {\\Bbb R}")#text(", where ")#mi("U_S: \\{-1,+1\\}^n \\to \\{-1,+1\\}")#text(" is the monomial boolean function")

#align(center)[#tao-fit-display[#mitex("U_S(x_1,\\ldots,x_n) = \\prod \\{x_i: i\\in S\\}")]]

#text("and ")#mi("\\hat f(S)")#text(" is the Fourier-Walsh coefficient")

#align(center)[#tao-fit-display[#mitex("\\hat f(S) := \\int_{\\{-1,+1\\}^n} f(x) U_S(x)\\ d\\mu(x).")]]

#text("Algebraically, the Fourier-Walsh expansion regards f as a polynomial combination of multilinear (square-free) monomials. It is of course a special case of the more general concept of a Fourier transform on an abelian group.")

#text("From ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{S \\subset \\{-1,+1\\}^n} \\hat f(S)^2 = 1.")]]

#text("The influence can be written similarly:")

#align(center)[#tao-math("I(f) = \\sum_{S \\subset \\{-1,+1\\}^n} \\hat f(S)^2 \\left|S\\right|", block: false)#text(".")]

#text("Note that this (together with Plancherel’s theorem) already implies the edge-isoperimetric inequality. The influence thus measures the average “height” of the spectrum, with each set S being viewed as having height |S|.")

#text("The ")#emph[#text("spectral entropy")]#text(" E(f) of a boolean function f is defined as")

#align(center)[#tao-fit-display[#mitex("E(f) = \\sum_{S \\subset \\{-1,+1\\}^n} \\hat f(S)^2 \\log_2 \\frac{1}{\\hat f(S)^2}")]]

#text("Roughly speaking, it measures the logarithm of the “width” of the Fourier transform of f; it is larger when the spectrum of f is “smeared out”. From ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(", the entropy is at least zero (with equality attained if and only if f is a monomial ")#mi("U_S")#text(" for some S), and can be as large as n or so (this is the case for random functions, for instance).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Entropy/influence conjecture")]#text(" (")#link("http://www.ams.org/mathscinet-getitem?mr=1371123")[#text("Friedgut-Kalai, 1996")]#text(") : We have ")#mi("E(f) \\ll I(f)")#text(" (i.e. ")#mi("E(f) \\leq C I(f)")#text(" for some absolute constant C.)")
]

#text("Comparing the Fourier-analytic formulae for the entropy and influence, we thus see that this conjecture asserts in some sense that if the Fourier coefficients are “smeared” then the Fourier coefficients are (on average) “high”. One strange feature of this conjecture is worth noting: the spectral entropy is invariant under arbitrary ")#mi("{\\Bbb Z}/2{\\Bbb Z}")#text(" linear transformations, whereas the influence depends on a specific basis. Thus, the conjecture also implies that if Fourier coefficients are smeared, then they are high with respect to arbitrary bases.")

#text("On the other hand, both the entropy and influence are additive with respect to tensor products: if ")#mi("f: \\{-1,1\\}^n \\to \\{-1,1\\}")#text(" and ")#mi("g: \\{-1,1\\}^m \\to \\{-1,1\\}")#text(" are boolean functions, then the ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("f \\otimes g: \\{-1,1\\}^{n+m} \\to \\{-1,1\\}")#text(" is such that ")#mi("E(f \\otimes g) = E(f) + E(g)")#text(" and")#mi("I(f \\otimes g) = I(f) + I(g)")#text(". This fact is of course consistent with the conjecture.")

#text("The entropy/influence conjecture, if true, has several consequences:")

#enum(start: 1, 
[#strong[#text("Influences under symmetry")]#text(". The motivation for the entropy/influence conjecture was to understand influences (and the related threshold behavior) under symmetry. Here is a simple case: suppose that f is symmetric under some ")#link("http://en.wikipedia.org/wiki/Transitive")[#text("transitive")]#text(" group of permutations acting on the variables. Suppose also that f is odd (i.e. ")#mi("f(-x)=-f(x)")#text("). In terms of voting methods, this means that the two candidates +1, -1 are treated equally, and that every ")#emph[#text("individual")]#text(" voter is treated equally, though because we do not assume that the permutation group is 2-transitive, it is not necessarily the case that every ")#emph[#text("pair")]#text(" of voters is treated equally.The entropy/influence conjecture then implies a lower bound of ")#mi("I(f) \\gg \\log n")#text(". An unconditional proof of this latter claim was obtained by ")#link("http://www.ams.org/mathscinet-getitem?mr=1371123")[#text("Friedgut and Kalai")]#text(" using the KKL theorem mentioned earlier.For certain specific types of permutation groups, the entropy/influence conjecture predicts a precise improvement of this logarithmic lower bound. Slightly weaker versions of these improved bounds were established by ")#link("http://www.ams.org/mathscinet-getitem?mr=1466334")[#text("Bourgain and Kalai")]#text(", and")#linebreak()#text(" interesting to see if the techniques extend to give some weaker form of the conjecture without symmetry.")#linebreak()#text(" Results about influence under symmetry give some hope")#linebreak()#text(" for similar results on influences under some sort of “spectral continuity” hypothesis. Roughly speaking, one expects assertions of the form “When the variables have geometric meaning and the Fourier coefficients respect the geometry and are “continuous”, then the influence must be high.”")],
[#strong[#text("Mansour’s conjecture")]#text(". Consider a Boolean function f described by a formula in ")#link("http://en.wikipedia.org/wiki/Conjunctive_normal_form")[#text("conjunctive normal form")]#text(" of polynomial size in n. ")#link("http://www.ams.org/mathscinet-getitem?mr=1339562")[#text("Yishay Mansour conjectured")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=1370363")[#text("this paper")]#text(") that most of the Fourier coefficients are concentrated only on")#linebreak()#text(" polynomial number of coefficients! This conjecture is still open. Using a ")#link("http://www.ams.org/mathscinet-getitem?mr=1475339")[#text("theorem of Hastad and Boppana")]#text(" one can show ")#mi("I(f) \\ll  \\log n")#text("; thus Mansour’s conjecture will follow from the entropy/influence conjecture. Mansour’s motivation was to show that such Boolean functions can be statistically learned (for uniform random input) in polynomial time. This was proved ")#link("http://www.ams.org/mathscinet-getitem?mr=1607822")[#text("by Jackson")]#text(" using a different method.")]
)

#text("There are some variants and strengthenings of this conjecture:")

#enum(start: 1, 
[#strong[#text("Other probability distributions")]#text(". The notions considered here and the entropy/influence-conjecture extend if we replace the unbiased Boolean variables with other product probability spaces, such as independent biased Boolean variables or Gaussian variables. It is also of interest to consider non-product spaces as well.")],
[#strong[#text("Noise sensitivity versions")]#text(". The entropy/influence conjecture shows that the mean height of the spectrum is ")#mi("\\gg E(f)")#text(". Can one guarantee a more robust conclusion, namely that the median height (or other percentiles) are also ")#mi("\\gg E(f)")#text("? (This is called “noise sensitivity” but I will not explain why.) This claim is not true for the majority vote function, but some version of this may persist if one somehow rules out majority vote-like examples – for instance by considering boolean functions which are monotone, invariant under a transitive permutation group, with influence ")#mi("O(n^{1/3})")#text(" (say).")],
[#strong[#text("Pivotals distribution versions")]#text(". If f is a boolean function and ")#mi("x \\in \\{-1,+1\\}^n")#text(", define ")#mi("\\text{piv}(x) := \\{ 1 \\leq k \\leq n: f(\\sigma_k(x)) \\neq f(x) \\}")#text(". If x is selected randomly, then ")#mi("\\text{piv}(x)")#text(" is a random subset of ")#mi("\\{1,\\ldots,n\\}")#text("; the distribution of this random variable is called the ")#emph[#text("pivotals distribution")]#text(". Note that the expected value of this distribution is precisely I(f), so the pivotals distribution is somewhat analogous to the spectral distribution. We can ask if some version of the influence/entropy inequality applies also here. (A direct translation fails for the majority function, so we will need a weaker form.) Existence of such connection gives interesting prediction for pivotal sets for certain interesting examples.")],
[#strong[#text("Matrix function versions")]#text(". The following related conjecture is based on discussions together with Itai Benjamini, Gadi Kozma, Elchanan Mossell, and Ofer Zeitouni.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture")]#text(". There is an absolute constant ")#mi("\\beta>0")#text(" with the following property. Let ")#mi("f: \\mathfrak{so}(n) \\to {\\Bbb R}")#text(" be an odd function on the space ")#mi("\\mathfrak{so}(n)")#text(" of antisymmetric real ")#mi("n \\times n")#text(" matrices, which is invariant under similarity of matrices. Then we have ")#tao-math("I(f) \\geq n^\\beta \\left\\|f\\right\\|_2", block: false)#text(", where the influence and ")#mi("L^2")#text(" norm are measured using the Gaussian probability distribution on ")#mi("\\mathfrak {so}(n)")#text(". [To define the influence of non-boolean functions, one considers the average variance of these functions in each of the coordinates in turn, keeping all the other coordinates frozen.]")
]

#link("http://www.ams.org/mathscinet-getitem?mr=2208732")[#text("Kalai and Safra have a survey")]#text(" on issues related to these conjectures.")

#text("[")#emph[#text("Update")]#text(", Aug 17: Maths typo corrected. – T.]")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of otto")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7047")[#strong[#text("otto")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("Gil,")

#text("A small correction: At some point near the middle of your post, you start summing over S a subset of the cube, whereas it should be S a subset of {1,2, …, n}.")

#text("The same question can be asked for real-valued functions on the discrete cube, or perhaps for functions taking values in [-1,+1]. Is it essential that the range be discrete?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7064")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("Hi, Dr. Kalai. What I can see looks interesting, but the vast majority of your LaTeX formulas do not parse. I’m digging through the HTML source I see on this end, but I can’t see what’s going wrong. Do you see them rendered properly at your end?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7069")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("Otto, the range being {-1,1} is essential. Consider ")#mi("f(x_1,\\ldots,x_n) := (x_1 + ... + x_n)/n")#text(", which has range [-1,1]. Then I(f) = 1/n, but ")#mi("E(f) = (2\\log n)/n")#text(".")

#text("Mysteriously, if you define Ent(f) to be the same as E(f) except you don’t put in the “hats” (i.e., you take the entropy of f’s squared values, rather than f’s Fourier coefficients’ squared values), then it holds that ")#mi("\\text{Ent}(f) \\leq 2 I(f)")#text(". This is the Logarithmic-Sobolev Inequality for {-1,1}^n.")

#text("Gil might also have mentioned the application of this conjecture (and related ideas) to the theory of metric space embeddings; see, e.g., Cor. 3.9 in:")

#link("http://www.cims.nyu.edu/~naor/homepage%20files/nonembed-final-new.pdf")[#text("Click to access nonembed-final-new.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("Otto: Thanks for the typo correction! (For technical reasons, I am the one responsible for these sorts of formatting issues, though Gil is of course responsible for the content.)")

#text("John: I see the LaTeX displaying just fine; perhaps there was some temporary wordpress glitch.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of otto")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7094")[#strong[#text("otto")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("Is there an entropic uncertainty principle saying that one of Ent(f) or Ent(\\hat f) has to be large? (assuming |f| = 1)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7098")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("Dear Otto,")

#text("There is indeed such a principle; in fact ")#mi("\\text{Ent}(f) + \\text{Ent}(\\hat f)")#text(" is minimised precisely when f is a sharp example for the discrete uncertainty principle ")#tao-math("\\left|\\text{supp}(f)\\right| \\left|\\text{supp}(\\hat f)\\right| \\geq \\left|G\\right|", block: false)#text(" (in this context |G| would be 2^n), or in other words when f (and hence ")#mi("\\hat f")#text(") is a scalar multiple of a translated and modulated indicator function of a subgroup. Indeed it is not hard to see (from Jensen’s inequality) that the entropy uncertainty principle implies the discrete uncertainty principle.")

#text("One particularly slick proof of the entropy uncertainty principle is to take the sharp Hausdorff-Young inequality, which with the right normalisations reads ")#tao-math("\\left\\|f\\right\\|_{p^{\\prime}} \\leq \\left\\|f\\right\\|_p", block: false)#text(" for ")#mi("1 \\leq p \\leq 2")#text(", and differentiate (!) this inequality at ")#mi("p=2")#text(" (noting from Plancherel’s identity that we have identity at the endpoint ")#mi("p=2")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7102")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")]

#text("[…] (Gil Kalai) The entropy/influence conjecture [This post is authored by Gil Kalai, who has kindly “guest blogged” this week’s “open problem of the week”. – […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of otto")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7109")[#strong[#text("otto")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2007")])]

#text("What about the following question (which seems morally close).")

#text("Consider ")#mi("f : \\{-1,1\\}^n \\to S^{n-1}")#text(". Do we have")

#tao-math("\\sum_{S \\subseteq [n]} \\left\\|\\hat f(S)\\right\\|_2^2 \\log \\frac{1}{\\left\\|\\hat f(S)\\right\\|_2^2} \\leq C \\left\\|f\\right\\|_{\\text{Lip}}", block: false)#text("?")

#text("Even more ambitiously, if ")#mi("f : \\{-1,1\\}^n \\to R^n")#text(", is one of")#linebreak()#text(" Ent(f) or Ent(\\hat f) always bounded by ")#tao-math("C \\left\\|f\\right\\|_{\\text{Lip}}", block: false)#text("?")#linebreak()#text(" (Either concentrate of measure or concentration of spectral measure?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7272")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2007")])]

#text("Dear all, Greetings from Jerusalem. Thanks everybody for the interesting comments, suggestions and corrections, and thanks Terry for hosting me so helpfully.")

#text("I think that Otto’s idea to find a version of the E/I-conjecture for real functions on the discrete cube is a good idea but I do not know how to do it. (As Ryan pointed out we need to modify the formulation.) Let me mention a formula by Michel Talagrand (formula (1.2) in the paper: On Russo’s approximate zero-one law, Ann. of Prob. 22 (1994) 1576-1578,) which extends the KKL Theorem (in a sharp form) to arbitrary real functions on the discrete cube.")

#text("(I did not understand Otto’s suggestion from remark 8 regarding functions from the discrete ")#mi("n")#text("-dimensional cube to ")#mi("S^{n-1}")#text(" and ")#mi("R^n")#text(". Is it important that the ")#mi("n")#text(" on both sides is the same? Also please remind me what is the LIP norm.)")

#text("The connection to metric embeddings that Ryan mentioned is indeed a very nice recent application of Fourier analysis of Boolean functions (along with a lot of other stuff). Subash Khot and Nisheeth Vishnoi made the breakthrough proving that there is a finite metric space of size ")#mi("n")#text(" in ")#mi("\\ell_2^2")#text(" which requires a distortion of ")#mi("(\\log \\log)^{1/6}")#text(" for ")#mi("\\ell_1")#text("-embedding. (46th Annual IEEE Symposium on Foundations of Computer Science (FOCS’05) pp. 53-62.) Their result answered negatively a fundamental problem posed by Goemans and Linial. Along with Muli Safra we spent a lot of efforts to understand their beautiful paper. And we even have some hopes that the E/I conjecture or some relative may be relevant for possible improvements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aeebf36a0977046d41e2ade7b0d4dd9571dfa57761df8625087fed7f7829cc61-03dc283c03143bd950a9164a699b573482c142ab39f72d825eb2c1ca9c782b58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamed Hatami")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-7337")[#strong[#text("Hamed Hatami")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2007")])]

#text("Let me mention a problem due to Ryan O’Donnell which is related to")#linebreak()#text(" the entropy/influence conjecture. The following statement follows")#linebreak()#text(" immediately from the conjecture, but a valid proof that does not use")#linebreak()#text(" the conjecture is unknown.")

#text("There exists a positive constant ")#mi("C")#text(" such that the following")#linebreak()#text(" holds. If ")#mi("f:\\{-1,1\\}^n \\rightarrow \\{-1,1\\}")#text(", then")

#tao-math("\\max_{S \\neq \\emptyset} \\left|\\widehat{f}(S)\\right| \\ge C^{-I(f)/{\\rm Var}(f)}", block: false)#text(".")

#text("When ")#mi("f")#text(" is monotone, the statement follows from the KKL")#linebreak()#text(" theorem as in that case ")#mi("\\widehat{f}(\\{k\\})=I_k(f)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-27242")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2008")])]

#text("I realized a typo in my presentation. In the four displaced formulas where the sums are over ")#mi("S \\subset \\{-1,1\\}^n")#text(", it should be, of course, over ")#mi("S \\subset \\{1,2,\\dots,n\\}")#text(".Sorry!")

#text("Here is another remark: Item 3 in the “variants” considers the distribution of the sets of pivotals, and asks if the influence is bounded below by a constant times the entropy of this pivotal distribution.")

#text("I claimed that this does not work for the balanced majority function, but it does. In this case with probability ")#mi("1-c\\sqrt {n}")#text(" we have the empty sets as the set of pivotals and otherwise the set of pivotals is a random set of size ")#mi("{}[n/2]")#text(" or ")#mi("{}[n/2]+1")#text(". So it looks that both the influence and entropy of the pivotals distribution is ")#mi("c \\sqrt {n}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-29752")[#strong[#text("Combinatorics, mathematics, academics, polemics, … « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2008")]

#text("[…] and the other was about the entropy/influence conjecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-30148")[#strong[#text("Nati’s Influence « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2008")]

#text("[…] post: The Entropy Influence Conjecture. (Terry Tao’s blog) Possibly related posts: (automatically generated)Smart Mobs, Dumb […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-35359")[#strong[#text("Quantum boolean functions « Tobias J. Osborne’s research notes")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")]

#text("[…] than review the theory of fourier analysis for boolean functions I’ll just refer you to the post by Gil Kalai on the entropy influence conjecture which contains a very readable account. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-41861")[#strong[#text("Analysis and Probability of Boolean Functions — Gil Kalai at the UCLA-IPAM Colloquium « Not just coffee time")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2009")]

#text("[…] on Analysis and Probability of Boolean Functions. Parts of this talk have been featured in a guest blog entry over at Terence Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-43714")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("Mansour’s conjecture for random DNF formulas was proved by Adam Klivans, Homin Lee, Andrew Wan ")#link("http://eccc.hpi-web.de/report/2010/023/")[#text("http://eccc.hpi-web.de/report/2010/023/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-51190")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("There is a new paper on the conjecture entitled ")#emph[#text(" The Fourier Entropy-Infuence Conjecture")#linebreak()#text(" for certain classes of Boolean functions")]#text(", by")#linebreak()#text(" Ryan O’Donnell, John Wright, and Yuan Zhou, that can be found here")

#link("http://www.cs.cmu.edu/~odonnell/papers/fei.pdf")[#text("Click to access fei.pdf")]

#text("The paper contains a proof of the conjecture for symmetric Boolean functions and in various other cases. For symmetric functions a noise sensitivity statement for the discrete directional derivatives of the function")#linebreak()#text(" which implies the conjecture is proved.")

#text("Let me also mention that Gady Kozma asked if the conjecture remains true for functions to the unit circle in the complex plane.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-610112")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2020")])]

#text("Gideon Schechtman used analogs of the Rudin-Shapiro pairs of functions to find a counter example to the entropy/influence statement for functions to the unit complex circle. ")#link("https://arxiv.org/abs/2009.12753")[#text("https://arxiv.org/abs/2009.12753")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-53889")[#strong[#text("Tentative Plans and Belated Updates II | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2011")]

#text("[…] theorem in terms of families of fans. (We asked about it here.) There is a new paper on the Entropy-Influence conjecture entitled The Fourier Entropy-Infuence Conjecture for certain classes of Boolean […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-249658")[#strong[#text("NatiFest is Coming | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")]

#text("[…] post: The Entropy Influence Conjecture. (Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-543575")[#strong[#text("A new PolyTCS blog! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2020")]

#text("[…] is a 2014 post on GLL on the problem of Project 2, and here is my 2007 post on WN on the problem of Project […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-543578")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2020")])]

#text("Let me mention a substantial progress and a proof of a weaker form of the conjecture in ")#link("https://arxiv.org/abs/1911.10579")[#text("https://arxiv.org/abs/1911.10579")]#text(" by Esty Kelman, Guy Kindler, Noam Lifshitz, Dor Minzer, and Muli Safra.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-547423")[#strong[#text("Kelman, Kindler, Lifshitz, Minzer, and Safra: Towards the Entropy-Influence Conjecture | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")]

#text("[…] Let me briefly report on a remarkable new paper by Esty Kelman, Guy Kindler, Noam Lifshitz, Dor Minzer, and Muli Safra, Revisiting Bourgain-Kalai and Fourier Entropies. The paper describes substantial progress towards the Entropy-Influence conjecture, posed by Ehud Friedgut and me in 1996. (See this blog post from 2007.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-621559")[#strong[#text("Possible future Polymath projects (2009, 2021) | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2021")]

#text("[…] are so far three very interesting proposals there, and the first proposal is the Friedgut-Kalai Entropy/Influence conjecture. For various proposals, see also the polymath blog administered by Tim Gowers, Michael Nielsen, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#comment-634672")[#strong[#text("Everyday entropy: what is a map? – bonefactory")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")]

#text("[…] ")#link("https://www.quantamagazine.org/gil-kalais-argument-against-quantum–computers-20180207/ ")[#text("https://www.quantamagazine.org/gil-kalais-argument-against-quantum–computers-20180207/ ")]#text(" I think that the effort required to obtain a low enough error level for any implementation of universal quantum circuits increases exponentially with the number of qubits, and thus, quantum computers are not possible. I am pretty certain, while a little nervous to be proven wrong. Our results state that noise will corrupt the computation, and that the noisy outcomes will be very easy to simulate on a classical computer. This prediction can already be tested; you don’t even need 50 qubits for that, I believe that 10 to 20 qubits will suffice. For quantum computers of the kind Google and IBM are building, when you run, as they plan to do, certain computational processes, they expect robust outcomes that are increasingly hard to simulate on a classical computer. Well, I expect very different outcomes. So I don’t need to be certain, I can simply wait and see. https://terrytao.wordpress.com/2007/08/16/gil-kalai-the-entropyinfluence-conjecture/#more-41 […]")
]
