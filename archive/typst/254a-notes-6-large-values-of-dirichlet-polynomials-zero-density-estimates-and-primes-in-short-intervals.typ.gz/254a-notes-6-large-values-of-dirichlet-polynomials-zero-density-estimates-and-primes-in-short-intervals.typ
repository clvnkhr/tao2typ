// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/
// Converted to Typst by tao2typ: "2026-10-14T10:23:47.992319+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("previous set of notes")]#text(", we studied upper bounds on sums such as ")#tao-math("{\\left|\\sum_{N \\leq n \\leq N+M} n^{-it}\\right|}", block: false)#text(" for ")#mi("{1 \\leq M \\leq N}")#text(" that were valid for all ")#mi("{t}")#text(" in a given range, such as ")#mi("{[T,2T]}")#text("; this led in turn to upper bounds on the Riemann zeta ")#mi("{\\zeta(\\sigma+it)}")#text(" for ")#mi("{t}")#text(" in the same range, and for various choices of ")#mi("{\\sigma}")#text(". While some improvement over the trivial bound of ")#mi("{O(N)}")#text(" was obtained by these methods, we did not get close to the conjectural bound of ")#mi("{O( N^{1/2+o(1)})}")#text(" that one expects from pseudorandomness heuristics (assuming that ")#mi("{T}")#text(" is not too large compared with ")#mi("{N}")#text(", e.g. ")#mi("{T = O(N^{O(1)})}")#text(".")

#text("However, it turns out that one can get much better bounds if one settles for estimating sums such as ")#tao-math("{\\left|\\sum_{N \\leq n \\leq N+M} n^{-it}\\right|}", block: false)#text(", or more generally finite Dirichlet series (also known as ")#emph[#text("Dirichlet polynomials")]#text(") such as ")#tao-math("{\\left|\\sum_n a_n n^{-it}\\right|}", block: false)#text(", for ")#emph[#text("most")]#text(" values of ")#mi("{t}")#text(" in a given range such as ")#mi("{[T,2T]}")#text(". Equivalently, we will be able to get some control on the ")#emph[#text("large values")]#text(" of such Dirichlet polynomials, in the sense that we can control the set of ")#mi("{t}")#text(" for which ")#tao-math("{\\left|\\sum_n a_n n^{-it}\\right|}", block: false)#text(" exceeds a certain threshold, even if we cannot show that this set is empty. These large value theorems are often closely tied with estimates for ")#emph[#text("mean values")]#text(" such as ")#tao-math("{\\frac{1}{T}\\int_T^{2T} \\left|\\sum_n a_n n^{-it}\\right|^{2k}\\ dt}", block: false)#text(" of a Dirichlet series; these latter estimates are thus known as ")#emph[#text("mean value theorems")]#text(" for Dirichlet series. Our approach to these theorems will follow the same sort of methods used in ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(", in particular relying on the generalised Bessel inequality from those notes.")

#text("Our main application of the large value theorems for Dirichlet polynomials will be to control the number of zeroes of the Riemann zeta function ")#mi("{\\zeta(s)}")#text(" (or the Dirichlet ")#mi("{L}")#text("-functions ")#mi("{L(s,\\chi)}")#text(") in various rectangles of the form ")#tao-math("{\\{ \\sigma+it: \\sigma \\geq \\alpha, \\left|t\\right| \\leq T \\}}", block: false)#text(" for various ")#mi("{T > 1}")#text(" and ")#mi("{1/2 < \\alpha < 1}")#text(". These rectangles will be larger than the zero-free regions for which we can exclude zeroes completely, but we will often be able to limit the number of zeroes in such rectangles to be quite small. For instance, we will be able to show the following weak form of the Riemann hypothesis: as ")#mi("{T \\rightarrow \\infty}")#text(", a proportion ")#mi("{1-o(1)}")#text(" of zeroes of the Riemann zeta function in the critical strip with ")#tao-math("{\\left|\\text{Im}(s)\\right| \\leq T}", block: false)#text(" will have real part ")#mi("{1/2+o(1)}")#text(". Related to this, the number of zeroes with ")#tao-math("{\\left|\\text{Im}(s)\\right| \\leq T}", block: false)#text(" and ")#tao-math("{\\left|\\text{Re}(s)\\right| \\geq \\alpha}", block: false)#text(" can be shown to be bounded by ")#mi("{O( T^{O(1-\\alpha)+o(1)} )}")#text(" as ")#mi("{T \\rightarrow \\infty}")#text(" for any ")#mi("{1/2 < \\alpha < 1}")#text(".")

#text("In the next set of notes we will use refined versions of these theorems to establish ")#link("http://en.wikipedia.org/wiki/Linnik%27s_theorem")[#text("Linnik’s theorem")]#text(" on the least prime in an arithmetic progression.")

#text("Our presentation here is broadly based on Chapters 9 and 10 in ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(", who give a number of more sophisticated large value theorems than the ones discussed here.")

#metadata(none) <tao-5ac751464e2e40df311d>

#heading(level: 1)[#strong[#text(" — 1. Large values of Dirichlet polynomials — ")]]

#text("Our basic estimate on large values is the following ")#mi("{L^2}")#text(" estimate, due to ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("Montgomery and Vaughan")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (")#mi("{L^2}")#text(" estimate on large values)")]#text(" ")#metadata(none) <tao-e2dd5fc22bd03997921e>#text(" Let ")#mi("{N \\geq 1}")#text(" and ")#mi("{T > 0}")#text(", and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers. Let ")#mi("{t_1,\\dots,t_J}")#text(" be a ")#mi("{1}")#text("-separated set of real numbers in an interval of length at most ")#mi("{T}")#text(", thus ")#tao-math("{\\left|t_j - t_{j^{\\prime}}\\right| \\geq 1}", block: false)#text(" for all ")#mi("{1 \\leq j < j^{\\prime} \\leq J}")#text(". Let ")#mi("{\\sigma_1,\\dots,\\sigma_J = O(1)}")#text(" be real numbers. Then ")#metadata(none) <tao-b5fd4da6901078530ad0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{j=1}^J \\left|N^{\\sigma_j} \\sum_{N/2 \\leq n \\leq N} a_n n^{-\\sigma_j-it_j}\\right|^2 \\ll (T + N) \\sum_{N/2 \\leq n \\leq N} \\left|a_n\\right|^2.", block: true)]]
]

#text("This estimate is closely analogous to the analytic large sieve inequality (Proposition 6 from ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text("). The factor ")#mi("{N^{\\sigma_j} n^{-\\sigma_j}}")#text(" is needed for technical reasons, but should be ignored at a first reading since it is comparable to one on the range ")#mi("{N/2 \\leq n \\leq N}")#text(". The bound ")#link(<tao-b5fd4da6901078530ad0>)[#text("(1)")]#text(" can be compared against the Cauchy-Schwarz bound")

#align(center)[#tao-fit-display[#tao-math("\\left|N^{\\sigma_j} \\sum_{N/2 \\leq n \\leq N} a_n n^{-\\sigma_j-it_j}\\right|^2 \\ll N \\sum_{N/2 \\leq n \\leq N} \\left|a_n\\right|^2", block: true)]]

#text("and against the pseudorandomness heuristic that ")#tao-math("{\\left|\\sum_{N/2 \\leq n \\leq N} a_n n^{-it_j}\\right|^2}", block: false)#text(" should be roughly of size ")#tao-math("{\\sum_{N/2 \\leq n \\leq N} \\left|a_n\\right|^2}", block: false)#text(" for “typical” ")#mi("{t_j}")#text(".")

#emph[#text("Proof:")]#text(" We first observe that to prove the theorem, it suffices to do so in the case ")#mi("{T = N/100}")#text(". Indeed, if ")#mi("{T < N/100}")#text(", one can simply increase ")#mi("{T}")#text(" until it reaches ")#mi("{N/100}")#text(", which does not significantly affect the factor ")#mi("{T+N}")#text("; conversely, if ")#mi("{T > N/100}")#text(", one can partition ")#mi("{t_1,\\dots,t_J}")#text(" into ")#mi("{O( T/N )}")#text(" subsets, each of diameter at most ")#mi("{N/100}")#text(", and the claim then follows from the triangle inequality.")

#text("Without loss of generality we may assume the ")#mi("{t_j}")#text(" are in increasing order, so in particular ")#tao-math("{\\left|t_j - t_{j^{\\prime}}\\right| \\geq \\left|j-j^{\\prime}\\right|}", block: false)#text(" for any ")#mi("{j,j^{\\prime}}")#text(".")

#text("Next, we apply the generalised Bessel inequality (Proposition 2 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text("), using the weight ")#mi("{\\nu(n)}")#text(" defined as ")#mi("{\\nu(n) := \\psi(n/N)}")#text(", where ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a smooth function supported on ")#mi("{[1/4,4]}")#text(" which equals one on ")#mi("{[1/2,1]}")#text(". This lets us bound the left-hand side of ")#link(<tao-b5fd4da6901078530ad0>)[#text("(1)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{N/2 \\leq n \\leq N} \\frac{\\left|a_n\\right|^2}{\\nu(n)}) (\\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J c_j \\overline{c_{j^{\\prime}}} \\sum_n \\nu(n) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})})", block: true)]]

#text("for some coefficients ")#mi("{c_1,\\dots,c_J}")#text(" with ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2 = 1}", block: false)#text(".")

#text("By choice of ")#mi("{\\nu}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{N/2 \\leq n \\leq N} \\frac{\\left|a_n\\right|^2}{\\nu(n)} = \\sum_{N/2 \\leq n \\leq N} \\left|a_n\\right|^2,", block: true)]]

#text("so it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J c_j \\overline{c_{j^{\\prime}}} \\sum_n \\nu(n) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})} \\ll N.")]]

#text("We now focus on the expression ")#metadata(none) <tao-2492c2a18ce9f3ca5b0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_n \\nu(n) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})})")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_n \\psi(n/N) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log n ).")]]

#text("When ")#mi("{j=j^{\\prime}}")#text(", we can bound this by ")#mi("{O(N)}")#text(", which gives an acceptable contribution; now we consider the case ")#mi("{j \\neq j^{\\prime}}")#text(". One could estimate ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("(2)")]#text(" in this case using Proposition 6 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(" and summation by parts to get a bound of ")#tao-math("{O( \\frac{1}{\\left|t_j-t_{j^{\\prime}}\\right|} ) = O( \\frac{1}{\\left|j-j^{\\prime}\\right|})}", block: false)#text(" here, but one can do better (saving a logarithmic factor) by exploiting the smooth nature of ")#mi("{\\psi}")#text(". Namely, by using the Poisson summation formula (Theorem 34 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("), we can rewrite ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("(2)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\int_{\\bf R} \\psi( x/N) (x/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log x - m x )\\ dx")]]

#text("which we rescale as")

#align(center)[#tao-fit-display[#mitex("N e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log N) \\sum_m \\int_{\\bf R} \\frac{\\psi(x)}{x^{\\sigma_j+\\sigma_{j^{\\prime}}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log x - m N x )\\ dx.")]]

#text("Since ")#tao-math("{\\left|t_j - t_{j^{\\prime}}\\right| \\leq T = \\frac{N}{100}}", block: false)#text(", one can check that the derivative of the phase ")#mi("{x \\mapsto \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log x - m N x}")#text(" is ")#tao-math("{\\gg \\left|t_j-t_{j^{\\prime}}\\right|}", block: false)#text(" on the support of ")#mi("{\\psi}")#text(" when ")#mi("{m=0}")#text(", and ")#tao-math("{\\gg \\left|m\\right|N}", block: false)#text(" when ")#mi("{m}")#text(" is non-zero, while the second derivative is ")#tao-math("{O( \\left|t_j-t_{j^{\\prime}}\\right| )}", block: false)#text(". Meanwhile, the function ")#mi("{\\frac{\\psi(x)}{x^{\\sigma_j+\\sigma_{j^{\\prime}}}}}")#text(" is compactly supported and has the first two derivatives bounded by ")#mi("{O(1)}")#text(". From this and two integrations by parts we obtain the bounds")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\frac{\\psi(x)}{x^{\\sigma_j+\\sigma_{j^{\\prime}}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log x - m N x )\\ dx \\ll \\frac{1}{\\left|t_j-t_{j^{\\prime}}\\right|^2}", block: true)]]

#text("when ")#mi("{m=0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{\\psi(x)}{x^{\\sigma_j+\\sigma_{j^{\\prime}}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log x - m N x )\\ dx \\ll \\frac{1}{m^2 N^2}")]]

#text("when ")#mi("{m \\neq 0}")#text(", thus on summing")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\nu(n) n^{i(t_j-t_{j^{\\prime}})} \\ll \\frac{N}{\\left|t_j-t_{j^{\\prime}}\\right|^2} \\ll \\frac{N}{\\left|j-j^{\\prime}\\right|^2}.", block: true)]]

#text("We thus need to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq j,j^{\\prime} \\leq J: j \\neq j^{\\prime}} \\frac{c_j \\overline{c_{j^{\\prime}}}}{\\left|j-j^{\\prime}\\right|^2} \\ll 1.", block: true)]]

#text("But if one bounds ")#tao-math("{c_j \\overline{c_{j^{\\prime}}} \\ll \\left|c_j\\right|^2 + \\left|c_{j^{\\prime}}\\right|^2}", block: false)#text(" we obtain the claim. ")#mi("\\Box")

#text("There is an integral variant of this large values estimate, although we will not use it much here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (")#mi("{L^2}")#text(" mean value theorem)")]#text(" Let ")#mi("{N \\geq 1}")#text(" and let ")#mi("{(a_n)_{1 \\leq n \\leq N}}")#text(" be a sequence of complex numbers.")

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{T \\rightarrow \\infty} \\frac{1}{T} \\int_0^T \\left|\\sum_{1 \\leq n \\leq N} a_n n^{-it}\\right|^2\\ dt = \\sum_{1 \\leq n \\leq N} \\left|a_n\\right|^2.", block: true)]]],
[#text("(ii) Show the more precise estimate")

#metadata(none) <tao-7dd04b0145ffa5646536>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\int_{T_0}^{T_0+T} \\left|\\sum_{1 \\leq n \\leq N} a_n n^{-it}\\right|^2\\ dt = (T + O(N)) \\sum_{1 \\leq n \\leq N} \\left|a_n\\right|^2.", block: true)]]

#text("for any ")#mi("{T > 0}")#text(" and ")#mi("{T_0 \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" Reduce to the case when ")#mi("{T_0=0}")#text(". An adaptation of Theorem ")#link(<tao-e2dd5fc22bd03997921e>)[#text("1")]#text(" gives an upper bound of roughly the right order of magnitude; to get the asymptotic, apply Plancherel’s theorem to an expression of the form ")#tao-math("{\\int_{\\bf R} \\eta(t) \\left|\\sum_{1 \\leq n \\leq N} a_n n^{-it}\\right|^2}", block: false)#text(" where ")#mi("{\\eta(t)}")#text(" is the indicator function ")#mi("{1_{[0,T]}}")#text(" convolved by some rapidly decreasing function whose Fourier transform is supported on (say) ")#mi("{[-1/10N, 1/10N]}")#text(", and use the previous upper bound to control the error.)")]
)
]

#text("We will use the large values estimate in the following way:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" ")#metadata(none) <tao-19f4c684a3ff4f2dfa73>#text(" Let ")#mi("{N, T \\geq 2}")#text(", and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers obeying a bound of the form ")#mi("{a_n \\ll \\tau(n)^{O(1)} \\log^{O(1)} n }")#text(" for all ")#mi("{1 \\leq n \\leq N}")#text(". Let ")#mi("{0 \\leq \\beta \\leq 1}")#text(". Then, after deleting at most ")#mi("{O( T^\\beta \\log^{O(1)}(N) )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\leq N^{1/2-\\sigma} \\max(N, T)^{1/2} T^{-\\beta/2}", block: true)]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[0,T]}")#text(".")
]

#text("One can view this corollary as improving upon the trivial bound ")#metadata(none) <tao-9f0a3fdddc621d9b5e11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\leq N^{1/2-\\sigma} N^{1/2} \\log^{O(1)} N", block: true)]]

#text("coming from mean value theorems on multiplicative functions (see Proposition 21 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("), if one is allowed to delete some unit intervals from the range ")#mi("{[0,T]}")#text(" of ")#mi("{t}")#text(", with the bound improving as one deletes more and more intervals.")

#emph[#text("Proof:")]#text(" Let ")#mi("{S \\subset [0,T]}")#text(" be the set of all ")#mi("{t \\in [0,T]}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| > N^{1/2-\\sigma} \\max(N, T)^{1/2} T^{-\\beta/2}", block: true)]]

#text("for at least one choice of ")#mi("{\\sigma \\in [-1,2]}")#text(". By the greedy algorithm, we can cover ")#mi("{S}")#text(" by the union of ")#mi("{J}")#text(" intervals of the form ")#mi("{[t_j-1, t_j+1]}")#text(", where ")#mi("{t_1,\\dots,t_J}")#text(" are ")#mi("{1}")#text("-separated points in ")#mi("{[0,T]}")#text(". By hypothesis, we can find ")#mi("{\\sigma_1,\\dots,\\sigma_J \\in [-1,2]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma_j+it_j}}\\right| > N^{1/2-\\sigma_j} \\max(N, T)^{1/2} T^{-\\beta/2}", block: true)]]

#text("for all ")#mi("{j=1,\\dots,J}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|N^{\\sigma_j} \\sum_{N/2 \\leq n \\leq N} a_n n^{-\\sigma_j-it_j}\\right|^2 \\geq J N \\max(N,T) T^{-\\beta}.", block: true)]]

#text("On the other hand, from mean value theorems on multiplicative functions (see Proposition 21 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{N/2 \\leq n\\leq N} \\left|a_n\\right|^2 \\ll N \\log^{O(1)} N", block: true)]]

#text("and thus by Theorem ")#link(<tao-e2dd5fc22bd03997921e>)[#text("1")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|N^{\\sigma_j} \\sum_{N/2 \\leq n \\leq N} a_n n^{-\\sigma_j-it_j}\\right|^2 \\ll (T+N) N \\log^{O(1)} N.", block: true)]]

#text("Comparing the two bounds we see that ")#mi("{J = O( T^\\beta \\log^{O(1)} N)}")#text(", and the claim follows. ")#mi("\\Box")

#text("The above estimate turns out to be rather inefficient if ")#mi("{N}")#text(" is very small compared with ")#mi("{T}")#text(", because the ")#mi("{\\max(N,T)}")#text(" factor becomes large compared with ")#mi("{N}")#text(" and so it is not even clear that one improves upon the trivial bound ")#link(<tao-9f0a3fdddc621d9b5e11>)[#text("(4)")]#text(". However, by multiplying Dirichlet polynomials together one can get a good bound in this regime:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" ")#metadata(none) <tao-08c4242b5f585628bb8c>#text(" Let ")#mi("{N, T \\geq 2}")#text(", and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers obeying a bound of the form ")#mi("{a_n \\ll \\tau(n)^{O(1)} \\log^{O(1)} n }")#text(" for all ")#mi("{1 \\leq n \\leq N}")#text(". Let ")#mi("{0 \\leq \\beta \\leq 1}")#text(", and let ")#mi("{k \\geq 1}")#text(" be a natural number. Then, after deleting at most ")#mi("{O_k( T^\\beta \\log^{O_k(1)}(N) )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(", we have ")#metadata(none) <tao-fab66aa01347d3f11a16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_k N^{1/2-\\sigma} \\max(N, T^{1/k})^{1/2} T^{-\\frac{\\beta}{2k}}", block: true)]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[0,T]}")#text(".")
]

#emph[#text("Proof:")]#text(" We raise the original Dirichlet polynomial ")#mi("{\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}}")#text(" to the ")#mi("{k^{th}}")#text(" power to obtain ")#metadata(none) <tao-ffeafcc7e00140c8cb94>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}})^k = \\sum_{N^k/2^k \\leq n \\leq N^k} \\frac{b_n}{n^{\\sigma+it}}")]]

#text("where ")#mi("{b_n}")#text(" is the Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("b_n := \\sum_{N/2 \\leq n_1,\\dots,n_k \\leq N: n = n_1 \\dots n_k} a_{n_1} \\dots a_{n_k}.")]]

#text("From the bounds on ")#mi("{a_n}")#text(" we have ")#mi("{b_n\\ll_k \\tau(n)^{O_k(1)} \\log^{O_k(1)} n}")#text(". Subdividing ")#mi("{[N^k/2^k,N^k]}")#text(" into ")#mi("{k}")#text(" dyadic intervals and applying Corollary ")#link(<tao-19f4c684a3ff4f2dfa73>)[#text("3")]#text(" (with ")#mi("{N}")#text(" replaced by ")#mi("{N^k}")#text(") and the triangle inequality, we conclude that upon deleting ")#mi("{O_k( T^\\beta \\log^{O_k(1)}(N) )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N^k/2^k \\leq n \\leq N^k} \\frac{b_n}{n^{\\sigma+it}}\\right| \\ll_k (N^k)^{1/2-\\sigma} \\max(N^k, T)^{1/2} T^{-\\beta/2}", block: true)]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{t \\in [0,T]}")#text(" outside these intervals. Applying ")#link(<tao-ffeafcc7e00140c8cb94>)[#text("(6)")]#text(" and taking ")#mi("{k^{th}}")#text(" roots, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that if ")#mi("{T \\geq 2}")#text(" and ")#mi("{0 \\leq \\beta \\leq 1}")#text(", then after deleting at most ")#mi("{O( T^\\beta \\log^{O(1)} T )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(", one has ")#mi("{\\zeta(\\frac{1}{2}+it) \\ll T^{\\frac{1-\\beta}{4}}}")#text(" for all ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[0,T]}")#text(". Conclude the fourth moment bound")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\left|\\zeta(\\frac{1}{2}+it)\\right|^4\\ dt \\ll T \\log^{O(1)} T.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use the approximate functional equation, Exercise 39 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" In 1926, Ingham showed the more precise asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\left|\\zeta(\\frac{1}{2}+it)\\right|^4\\ dt = \\frac{1+o(1)}{2\\pi^2} T \\log^4 T", block: true)]]

#text("as ")#mi("{T \\rightarrow \\infty}")#text(". The higher moments ")#tao-math("{\\int_0^T \\left|\\zeta(\\frac{1}{2}+it)\\right|^{2k}\\ dt}", block: false)#text(" for ")#mi("{k=3,4,\\dots}")#text(" have been intensively studied, and are conjectured ")#link("http://www.ams.org/mathscinet-getitem?mr=1828303")[#text("by Conrey and Gonek")]#text(" (using the random matrix model, see Section 4 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") to be asymptotic to ")#mi("{C_k T \\log^{k^2} T}")#text(" for certain explicit constants ")#mi("{C_k}")#text(", but this remains unproven. It can be shown that the Lindelof hypothesis is equivalent to the assertion that ")#tao-math("{\\int_0^T \\left|\\zeta(\\frac{1}{2}+it)\\right|^{2k}\\ dt \\ll_{k,\\varepsilon} T^{1+\\varepsilon}}", block: false)#text(" for all ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(". In a recent paper ")#link("http://arxiv.org/abs/1305.4618")[#text("of Harper")]#text(", it was shown assuming the Riemann hypothesis that ")#tao-math("{\\int_0^T \\left|\\zeta(\\frac{1}{2}+it)\\right|^{2k}\\ dt \\ll_k T \\log^{k^2} T}", block: false)#text(" for all ")#mi("{k \\geq 1}")#text(" and ")#mi("{T \\geq 2}")#text(".")
]

#text("It is ")#link("http://www.ams.org/mathscinet-getitem?mr=337847")[#text("conjectured by Montgomery")]#text(" that Corollary ")#link(<tao-08c4242b5f585628bb8c>)[#text("4")]#text(" also holds for real ")#mi("{k \\geq 1}")#text(", after replacing the ")#mi("{O_k(\\log^{O_k(1)}(N))}")#text(" factor by ")#mi("{O_{k,\\varepsilon}(N^\\varepsilon)}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1122620")[#text("this paper of Bourgain")]#text(" for a counterexample showing that such a factor is necessary. (Amusingly, this counterexample relies on the existence of ")#link("http://en.wikipedia.org/wiki/Kakeya_set")[#text("Besicovitch sets")]#text(" of measure zero!) If one had this, then one could optimise ")#link(<tao-fab66aa01347d3f11a16>)[#text("(5)")]#text(" in the range ")#mi("{T^\\varepsilon \\ll N \\ll T}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(" by choosing ")#mi("{k}")#text(" so that ")#mi("{N = T^{1/k}}")#text(", arriving (morally, at least) at a bound of the form ")#metadata(none) <tao-06f8382071a4109d1a10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1-\\sigma-\\frac{\\beta}{2}},", block: true)]]

#text("thus beating the trivial bound by about ")#mi("{N^{\\beta/2}}")#text(". This bound would have many consequences, most notably the ")#emph[#text("density hypothesis")]#text(" discussed below. Unfortunately, Montgomery’s conjecture remains open. Nevertheless, one can obtain a weaker version of this bound by choosing natural numbers ")#mi("{k}")#text(" so that ")#mi("{T^{1/k}}")#text(" is ")#emph[#text("close")]#text(" to ")#mi("{N}")#text(", rather than exactly equal to ")#mi("{N}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7")]#text(" ")#metadata(none) <tao-9d9417124d12a14a0f39>#text(" Let ")#mi("{N, T \\geq 2}")#text(" be such that ")#mi("{T^\\varepsilon \\ll N \\ll T}")#text(" for some ")#mi("{\\varepsilon>0}")#text(", and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers obeying a bound of the form ")#mi("{a_n \\ll \\tau(n)^{O(1)} \\log^{O(1)} n }")#text(" for all ")#mi("{1 \\leq n \\leq N}")#text(". Let ")#mi("{0 \\leq \\beta \\leq 1}")#text(". Then, after deleting at most ")#mi("{O_\\varepsilon( T^\\beta \\log^{O_\\varepsilon(1)}(N) )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(", we have ")#metadata(none) <tao-661d9715f3987bc2b156>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1-\\sigma-\\max(\\frac{\\beta}{4},\\beta-\\frac{1}{2})}", block: true)]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[0,T]}")#text(".")
]

#text("Note that the bound ")#link(<tao-661d9715f3987bc2b156>)[#text("(8)")]#text(" is not too much worse than ")#link(<tao-06f8382071a4109d1a10>)[#text("(7)")]#text(" in the important regimes when ")#mi("{\\beta}")#text(" is close to ")#mi("{0}")#text(" and when ")#mi("{\\beta}")#text(" is close to ")#mi("{1}")#text(".")

#emph[#text("Proof:")]#text(" We can choose a natural number ")#mi("{k = O_\\varepsilon(1)}")#text(" such that ")#mi("{T^{1/2} \\ll N^k \\ll T}")#text(", so that ")#mi("{T^{1/2k} \\ll N}")#text(". Applying Corollary ")#link(<tao-08c4242b5f585628bb8c>)[#text("4")]#text(" with ")#mi("{k}")#text(" replaced by ")#mi("{2k}")#text(", we conclude (after deleting at most ")#mi("{O_\\varepsilon( T^\\beta \\log^{O_\\varepsilon(1)}(N) )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1/2-\\sigma} N^{1/2} T^{-\\frac{\\beta}{4k}};", block: true)]]

#text("since ")#mi("{T^{-\\frac{\\beta}{4k}} \\ll N^{-\\frac{\\beta}{4}}}")#text(", one obtains ")#link(<tao-661d9715f3987bc2b156>)[#text("(8)")]#text(" with ")#mi("{\\frac{\\beta}{4}}")#text(" in place of ")#mi("{\\max(\\frac{\\beta}{4},\\beta-\\frac{1}{2})}")#text(". If instead one uses Corollary ")#link(<tao-08c4242b5f585628bb8c>)[#text("4")]#text(" with ")#mi("{k}")#text(" rather than ")#mi("{2k}")#text(", one obtains (after deleting a similar number of unit intervals) that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1/2-\\sigma} T^{\\frac{1-\\beta}{2k}};", block: true)]]

#text("since ")#mi("{T^{\\frac{1-\\beta}{2k}} \\ll N^{1-\\beta}}")#text(", one obtains the remaining case of ")#link(<tao-661d9715f3987bc2b156>)[#text("(8)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-677f84fb42642c956c48>#text(" If one has the additional hypothesis ")#mi("{N \\ll T^{2\\varepsilon}}")#text(", show that one can replace the ")#mi("{\\max(\\frac{\\beta}{4},\\beta-\\frac{1}{2})}")#text(" factor in ")#link(<tao-661d9715f3987bc2b156>)[#text("(8)")]#text(" by ")#mi("{(1-O(\\varepsilon)) \\frac{\\beta}{2}}")#text(". Thus we can approach the conjectured estimate ")#link(<tao-06f8382071a4109d1a10>)[#text("(7)")]#text(" in the regime where ")#mi("{N}")#text(" is very small compared with ")#mi("{T}")#text(".")
]

#text("In the regime when ")#mi("{\\beta}")#text(" is small, one can obtain better bounds by exploiting further estimates on exponential sums such as ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("(2)")]#text(". We will give just one example (due ")#link("http://www.ams.org/mathscinet-getitem?mr=268130")[#text("to Montgomery")]#text(") of such an improvement, referring the reader to Chapter 9 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" or Chapter 7 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1297543")[#text("Montgomery")]#text(" for further examples.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Let ")#mi("{N, T \\geq 2}")#text(", and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers obeying a bound of the form ")#mi("{a_n \\ll \\tau(n)^{O(1)} \\log^{O(1)} n }")#text(" for all ")#mi("{1 \\leq n \\leq N}")#text(". Let ")#mi("{0 \\leq \\beta \\leq 1}")#text(". Then, after deleting at most ")#mi("{O( T^\\beta )}")#text(" unit intervals from ")#mi("{[0,T]}")#text(", we have ")#metadata(none) <tao-76b0ad4af34733ccdb0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll N^{1-\\sigma} (T^{-\\beta/2} + T^{1/4} N^{-1/2}) \\log^{O(1)}(NT)", block: true)]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[0,T]}")#text(".")
]

#text("Note that this bound can in fact be superior to ")#link(<tao-06f8382071a4109d1a10>)[#text("(7)")]#text(" if ")#mi("{N}")#text(" is a little bit less than ")#mi("{T}")#text(" and ")#mi("{\\beta}")#text(" is less than ")#mi("{1/2}")#text(".")

#emph[#text("Proof:")]#text(" Let ")#mi("{S \\subset [0,T]}")#text(" be the set of all ")#mi("{t \\in [0,T]}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| > N^{1-\\sigma} (T^{-\\beta/2} + T^{1/4} N^{-1/2}) \\log^C(NT)", block: true)]]

#text("for at least one choice of ")#mi("{\\sigma \\in [-1,2]}")#text(", where ")#mi("{C}")#text(" is a large constant be chosen later. By the greedy algorithm as before, we can cover ")#mi("{S}")#text(" by the union of ")#mi("{J}")#text(" intervals of the form ")#mi("{[t_j-1, t_j+1]}")#text(", where ")#mi("{t_1,\\dots,t_J}")#text(" are ")#mi("{1}")#text("-separated points in ")#mi("{[0,T]}")#text("; we arrange the ")#mi("{t_j}")#text(" in increasing order, so that ")#tao-math("{\\left|t_j - t_{j^{\\prime}}\\right| \\geq \\left|j-j^{\\prime}\\right|}", block: false)#text(". By hypothesis, we can find ")#mi("{\\sigma_1,\\dots,\\sigma_J \\in [-1,2]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma_j+it_j}}\\right| > N^{1-\\sigma} (T^{-\\beta/2} + T^{1/4} N^{-1/2}) \\log^C(NT)", block: true)]]

#text("for all ")#mi("{j=1,\\dots,J}")#text(", and hence ")#metadata(none) <tao-9c20ed1b0b9f30568439>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{j=1}^J \\left|N^{\\sigma_j} \\sum_{N/2 \\leq n \\leq N} a_n n^{-\\sigma_j-it_j}\\right|^2 \\gg J (N^2 T^{-\\beta} + N T^{1/2}) \\log^{2C}(NT).", block: true)]]

#text("As before, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{N/2 \\leq n\\leq N} \\left|a_n\\right|^2 \\ll N \\log^{O(1)} N", block: true)]]

#text("and so by the generalised Bessel inequality (with ")#mi("{\\nu := 1_{[N/2,N]}}")#text(") we may bound the left-hand side of ")#link(<tao-9c20ed1b0b9f30568439>)[#text("(10)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\ll N \\log^{O(1)} N \\sum_{1 \\leq j,j^{\\prime} \\leq J} \\left|c_j\\right| \\left|c_{j^{\\prime}}\\right| \\left|\\sum_{N/2 \\leq n \\leq N} (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})}\\right|", block: true)]]

#text("for some ")#mi("{c_1,\\dots,c_J}")#text(" with ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2 = 1}", block: false)#text(". The diagonal contribution ")#mi("{j=j^{\\prime}}")#text(" is ")#mi("{O( N^2 \\log^{O(1)} N )}")#text(". For the off-diagonal contributions, we see from Propositions 6, 9 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(" (dealing with the cases ")#tao-math("{\\left|t_j-t_{j^{\\prime}}\\right| \\leq N/100}", block: false)#text(" and ")#tao-math("{\\left|t_j-t_{j^{\\prime}}\\right| > N/100}", block: false)#text(" respectively) and summation by parts that")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})}\\right|  & \\ll \\frac{N}{\\left|t_j-t_{j^{\\prime}}\\right|} + \\left|t_j-t_{j^{\\prime}}\\right|^{1/2} \\log T", block: true)



#tao-math(" & \\ll \\frac{N}{\\left|j-j^{\\prime}\\right|} + T^{1/2} \\log T,", block: true)
]

#text("and so from the bound ")#tao-math("{\\left|c_j\\right| \\left|c_{j^{\\prime}}\\right| \\ll \\left|c_j\\right|^2 + \\left|c_{j^{\\prime}}\\right|^2}", block: false)#text(" we can bound the left-hand side of ")#link(<tao-9c20ed1b0b9f30568439>)[#text("(10)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll N \\log^{O(1)}(NTJ) ( N + J T^{1/2} ).")]]

#text("Since ")#mi("{J \\leq T}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("J (N^2 T^{-\\beta} + N T^{1/2}) \\log^{2C}(NT) \\ll N \\log^{O(1)}(NT) ( N + J T^{1/2} ).")]]

#text("The second term on the right-hand side may be absorbed into the left-hand side if ")#mi("{C}")#text(" is large enough, and we conclude that")

#align(center)[#tao-fit-display[#mitex("J (N^2 T^{-\\beta} + N T^{1/2}) \\log^{2C}(NT) \\ll N \\log^{O(1)}(NT) N")]]

#text("which gives ")#mi("{J \\ll T^{2\\beta}}")#text(", and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Zero density estimates — ")]]

#text("We now use the large value theorems for Dirichlet polynomials to control zeroes ")#mi("{\\sigma+it}")#text(" of the Riemann zeta function ")#mi("{\\zeta}")#text(" with large real part ")#mi("{\\sigma}")#text(". The key connection is that if ")#mi("{\\sigma+it}")#text(" is a zero of ")#mi("{\\zeta}")#text(", then this will force some Dirichlet polynomial ")#mi("{\\sum_n \\frac{a_n}{n^{\\sigma+it}}}")#text(" to be unusually large at that zero, which can be ruled out by the theorems of the previous section (after excluding some unit intervals from the range of ")#mi("{t}")#text("). Dirichlet polynomials with this sort of property are sometimes known as ")#emph[#text("zero-detecting polynomials")]#text(", for this reason.")

#text("Naively, one might expect, in view of the identities ")#mi("{\\sum_{n=1}^\\infty \\frac{\\mu(n)}{n^s} = \\frac{1}{\\zeta(s)}}")#text(" and ")#mi("{\\sum_{n=1}^\\infty \\frac{\\Lambda(n)}{n^s} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}}")#text(" for ")#mi("{\\text{Re}(s) < 1}")#text(", that Dirichlet polynomials such as ")#mi("{\\sum_{1 \\leq n \\leq N} \\frac{\\mu(n)}{n^s}}")#text(" or ")#mi("{\\sum_{1 \\leq n \\leq N} \\frac{\\Lambda(n)}{n^s}}")#text(" might serve as zero-detecting polynomials. Unfortunately, in the regime ")#mi("{\\text{Re}(s) > 1}")#text(", it is difficult to control the tail behaviour of these series. A more efficient choice comes from the following observation. Suppose that ")#mi("{\\zeta(\\sigma+it)=0}")#text(" for some ")#mi("{0 < \\sigma < 1}")#text(" and ")#mi("{t \\in [T,2T]}")#text(", where ")#mi("{T \\geq 2}")#text(" is large. From Exercise 33 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\sigma+it) = \\sum_n \\frac{\\eta(\\log n - \\log x)}{n^{\\sigma+it}} + O_A( T^{-A} )")]]

#text("for any ")#mi("{A>0}")#text(", where ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a smooth function equaling ")#mi("{1}")#text(" on ")#mi("{(-\\infty,-1)}")#text(" and zero on ")#mi("{(1,+\\infty)}")#text(", and ")#mi("{x}")#text(" is a sufficiently large multiple of ")#mi("{T}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\eta(\\log n - \\log x)}{n^{\\sigma+it}} = O_A( T^{-A} ).")]]

#text("To eliminate the terms coming from small ")#mi("{n}")#text(", we multiply both sides by the Dirichlet polynomial ")#mi("{\\sum_{n \\leq T^\\varepsilon} \\frac{\\mu(n)}{n^{\\sigma+it}}}")#text(" for some fixed ")#mi("{0 < \\varepsilon < 1}")#text(". This series can be very crudely bounded by ")#mi("{O(T^\\varepsilon)}")#text(", so that (after adjusting ")#mi("{A}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("(\\sum_{n \\leq T^\\varepsilon} \\frac{\\mu(n)}{n^{\\sigma+it}}) (\\sum_n \\frac{\\eta(\\log n - \\log x)}{n^{\\sigma+it}}) = O_A( T^{-A} ).")]]

#text("In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{a_n}{n^{\\sigma+it}} = -1 + O_A( T^{-A} )")]]

#text("where ")#mi("{a_n}")#text(" is the sequence")

#align(center)[#tao-fit-display[#mitex("a_n := \\sum_{d|n: d \\leq T^\\varepsilon} \\mu(d) \\eta( \\log \\frac{n}{d} - \\log x ) - 1_{n=1}.")]]

#text("In particular, for large ")#mi("{T}")#text(" we have ")#metadata(none) <tao-22917db8acdcd33e43dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|\\sum_n \\frac{a_n}{n^{\\sigma+it}}\\right| > \\frac{1}{2}", block: true)]]

#text("and so ")#mi("{\\sum_n \\frac{a_n}{n^{\\sigma+it}}}")#text(" serves as a zero-detecting polynomial.")

#text("From Möbius inversion, we see that ")#mi("{a_n}")#text(" is supported on the range ")#mi("{T^\\varepsilon \\ll n \\ll T^{1+\\varepsilon}}")#text(", and is bounded by ")#mi("{O( \\tau(n) )}")#text(". We can thus decompose the Dirichlet polynomial ")#mi("{\\sum_n \\frac{a_n}{n^{\\sigma+it}}}")#text(" as the sum of ")#mi("{O(\\log T)}")#text(" expressions of the form ")#mi("{\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}}")#text(" for ")#mi("{T^\\varepsilon \\ll N \\ll T^{1+\\varepsilon}}")#text(". Applying Corollary ")#link(<tao-9d9417124d12a14a0f39>)[#text("7")]#text(" (or Corollary ")#link(<tao-19f4c684a3ff4f2dfa73>)[#text("3")]#text(" to deal with the cases when ")#mi("{N \\gg T}")#text("), we see that for any ")#mi("{0 < \\beta < 1}")#text(", and after deleting at most ")#mi("{O_\\varepsilon( T^{\\beta} \\log^{O_\\varepsilon(1)} T )}")#text(" unit intervals from ")#mi("{[T,2T]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1-\\sigma-\\beta/4}", block: true)]]

#text("for all ")#mi("{O(\\log T)}")#text(" choices of ")#mi("{T^\\varepsilon \\ll N \\ll T^{1+\\varepsilon}}")#text(" and for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[T,2T]}")#text(". Adding a large multiple of ")#mi("{\\frac{\\log\\log T}{\\log T}}")#text(" to ")#mi("{\\beta}")#text(" (which does not significantly affect the error ")#mi("{O_\\varepsilon( T^{\\beta} \\log^{O_\\varepsilon(1)} T )}")#text(", we can improve this to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1-\\sigma-\\beta/4} \\frac{1}{\\log^2 N}", block: true)]]

#text("(say). Summing this in ")#mi("{N}")#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\frac{a_n}{n^{\\sigma+it}}\\right| < \\frac{1}{2}", block: true)]]

#text("if")

#align(center)[#tao-fit-display[#mitex("\\sigma \\geq 1 - \\beta/4")]]

#text("and ")#mi("{T}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Comparing this with ")#link(<tao-22917db8acdcd33e43dc>)[#text("(11)")]#text(", we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" Let ")#mi("{0 < \\beta < 1}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", and let ")#mi("{T}")#text(" be sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Then, after deleting at most ")#mi("{O_\\varepsilon( T^{\\beta} \\log^{O_\\varepsilon(1)} )}")#text(" unit intervals from ")#mi("{[T,2T]}")#text(", there are no zeroes of ")#mi("{\\zeta}")#text(" of the form ")#mi("{\\sigma+it}")#text(" with ")#mi("{\\sigma \\geq 1-\\beta/4}")#text(" and ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[T,2T]}")#text(".")
]

#text("For any ")#mi("{\\alpha > 0}")#text(" and ")#mi("{T > 0}")#text(", let ")#mi("{N(\\alpha,T)}")#text(" denote the number of zeroes ")#mi("{\\sigma+it}")#text(" of the Riemann zeta function (counting multiplicity) with ")#mi("{\\alpha \\leq \\sigma \\leq 1}")#text(" and ")#mi("{0 \\leq t \\leq T}")#text(". Recall from Proposition 16 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" that there are at most ")#mi("{O(\\log T)}")#text(" zeroes in any rectangle of the form ")#mi("{\\{ \\sigma+it: \\sigma \\geq 1/2; t_0 \\leq t \\leq t_0+1 \\}}")#text(" with ")#mi("{t_0 = O(T)}")#text(". Combining this with the previous proposition, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11 (Zero-density estimate)")]#text(" ")#metadata(none) <tao-d52b78b0b0630151485e>#text(" Let ")#mi("{3/4 < \\alpha < 1}")#text(" and ")#mi("{T \\geq 2}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("N(\\alpha,T) \\ll T^{4(1-\\alpha)} \\log^{O(1)} T.")]]
]

#emph[#text("Proof:")]#text(" By dyadic decomposition (and reflection symmetry) we may replace the constraint ")#mi("{0 \\leq t < T}")#text(" in the definition of ")#mi("{N(\\alpha,T)}")#text(" by ")#mi("{T \\leq t \\leq 2T}")#text(". The claim then follows from the previous proposition with ")#mi("{\\beta := 4(1-\\alpha)}")#text(" and a suitably small choice of ")#mi("{\\varepsilon}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Weak Riemann hypothesis)")]#text(" For any ")#mi("{1/2 < \\alpha < 1}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("N(\\alpha,T) \\ll_\\varepsilon T^{3/2-\\alpha+\\varepsilon}")]]

#text("for all ")#mi("{T > 2}")#text(". Conclude in particular that for any ")#mi("{\\varepsilon > 0}")#text(", only ")#mi("{o(T)}")#text(" of the zeroes of the Riemann zeta function in the rectangle ")#mi("{\\{\\sigma+it: 0 < \\sigma < 1; 0 \\leq t \\leq T \\}}")#text(" have real part greater than ")#mi("{1/2+\\varepsilon}")#text(" or less than ")#mi("{1/2-\\varepsilon}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" The sharpest result known in the direction of the weak Riemann hypothesis is ")#link("http://www.ams.org/mathscinet-getitem?mr=10712")[#text("by Selberg")]#text(", who showed that ")#mi("{N(\\alpha,T) \\ll \\frac{T}{\\alpha-1/2}}")#text(" for any ")#mi("{1/2 < \\alpha \\leq 1}")#text(" and ")#mi("{T \\geq 1}")#text(". Thus, “most” zeroes ")#mi("{\\sigma+it}")#text(" with ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" lie within ")#mi("{O(1/\\log T)}")#text(" of the critical line. Improving upon this result seems to be closely related to making progress on the pair correlation conjecture (see Section 4 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(").")
]

#text("Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(" is far from the sharpest bound on ")#mi("{N(\\alpha,T)}")#text(" known, but it will suffice for our applications; see Chapter 10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(" for various stronger bounds on ")#mi("{N(\\alpha,T)}")#text(", formed by using more advanced large values estimates as well as more complicated zero detecting polynomials. The ")#emph[#text("density hypothesis")]#text(" asserts that ")#metadata(none) <tao-d919a100ce6b45524d41>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("N(\\alpha,T) \\ll_\\varepsilon T^{2(1-\\alpha)+\\varepsilon}")]]

#text("for any ")#mi("{1/2 \\leq \\alpha \\leq 1}")#text(", ")#mi("{T > 1}")#text(", and ")#mi("{\\varepsilon > 0}")#text(", thus replacing the exponent ")#mi("{4}")#text(" in Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(" with ")#mi("{2}")#text(". This hypothesis is known to hold for ")#mi("{\\alpha > \\frac{5}{6}}")#text(" (a result of Huxley, in fact his estimates are even stronger than what the density hypothesis predicts), but is open in general; it is known that the exponent ")#mi("{4}")#text(" in Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(" can be replaced by ")#mi("{12/5}")#text(" (by the work ")#link("http://www.ams.org/mathscinet-getitem?mr=3649")[#text("of Ingham")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=330067")[#text("of Huxley")]#text("), but at the critical value ")#mi("{\\alpha=3/4}")#text(" no further improvement is currently known. Of course, the Riemann hypothesis is equivalent to the assertion that ")#mi("{N(\\alpha,T)=0}")#text(" for all ")#mi("{1/2 < \\alpha \\leq 1}")#text(", which is far stronger than the density hypothesis; in Exercise ")#link(<tao-23678e9300f19e9350bc>)[#text("15")]#text(" below we will see that even the ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelof hypothesis")]#text(" is sufficient to imply the density hypothesis. However, the density hypothesis can be a reasonable substitute for the Riemann hypothesis in some settings (e.g. in establishing prime number theorems in short intervals, as discussed below), and looks more amenable to a purely analytic attack (e.g. through resolution of the exponent pair conjecture, discussed briefly in ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(") than the Riemann hypothesis.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that ")#link(<tao-06f8382071a4109d1a10>)[#text("(7)")]#text(" implies ")#link(<tao-d919a100ce6b45524d41>)[#text("(12)")]#text(".")
]

#text("In Exercise 32 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", it was observed that if there were no zeroes of the Riemann zeta function with real part larger than ")#mi("{\\alpha}")#text(", then one had the upper bound ")#mi("{\\zeta(\\sigma+it) = O(t^{o(1)})}")#text(" as ")#tao-math("{\\left|t\\right| \\rightarrow \\infty}", block: false)#text(" for fixed ")#mi("{\\sigma >\\alpha}")#text(". The following exercise gives a sort of converse to this claim, “modulo the density hypothesis”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Riemann zero usually implies large value of ")#mi("{\\zeta}")#text(")")]#text(" ")#metadata(none) <tao-23678e9300f19e9350bc>#text(" Let ")#mi("{1/2 < \\alpha < 1}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", and let ")#mi("{T > 2}")#text(". Show that after deleting at most ")#mi("{O_\\varepsilon( T^{2(1-\\alpha)+O(\\varepsilon)} )}")#text(" unit intervals from ")#mi("{[T,2T]}")#text(", the following holds: whenever ")#mi("{\\sigma+it}")#text(" is a zero of the Riemann zeta function with ")#mi("{\\alpha \\leq \\sigma \\leq 1}")#text(" and ")#mi("{t}")#text(" in the remaining portion of ")#mi("{[T,2T]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\zeta( \\sigma^{\\prime} + it^{\\prime} )\\right| \\geq T^{\\varepsilon^2}", block: true)]]

#text("for some ")#mi("{\\sigma^{\\prime},t^{\\prime}}")#text(" with ")#tao-math("{\\left|t^{\\prime}-t\\right| \\leq T^\\varepsilon}", block: false)#text(" and ")#mi("{\\sigma^{\\prime} = \\sigma + O(\\varepsilon)}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-677f84fb42642c956c48>)[#text("8")]#text(" to dispose of the portion of the zero-detecting polynomial ")#mi("{\\sum_n \\frac{a_n}{n^{\\sigma+it}}}")#text(" with ")#mi("{n = O(T^{O(\\varepsilon)})}")#text(". Then divide out by ")#mi("{\\sum_{n \\leq T^\\varepsilon} \\frac{\\mu(n)}{n^{\\sigma+it}}}")#text(" and conclude that a sum such as ")#mi("{\\sum_n \\frac{\\eta(\\log n - \\log N)}{n^{\\sigma+it}}}")#text(" is large for some ")#mi("{T^\\varepsilon \\ll N \\ll T}")#text(". Then use Lemma 34 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".) Conclude in particular that the Lindelof hypothesis implies the density hypothesis.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" One can refine the above arguments to show that the density hypothesis is equivalent to the assertion that for any ")#mi("{1/2 < \\alpha < 1}")#text(", one has the Lindelof-type bounds ")#mi("{\\zeta(\\sigma+it) = O( T^{o(1)} )}")#text(" for all ")#mi("{\\alpha \\leq \\sigma \\leq 1}")#text(" and all ")#mi("{t}")#text(" in the set ")#mi("{[0,T]}")#text(" with at most ")#mi("{O( T^{2(1-\\alpha)+o(1)} )}")#text(" unit intervals removed, as ")#mi("{T \\rightarrow \\infty}")#text(". An application of Jensen’s formula shows that this claim is equivalent in turn to the assertion that for any ")#mi("{1/2 < \\alpha < 1}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", the set ")#tao-math("{\\{ \\sigma+it: \\sigma > \\alpha+\\varepsilon; \\left|t-t_0\\right| \\leq 1\\}}", block: false)#text(" contains ")#mi("{o( \\log T )}")#text(" zeroes of ")#mi("{\\zeta}")#text(" for all ")#mi("{t \\in [0,T]}")#text(" with at most ")#mi("{O( T^{2(1-\\alpha)+o(1)} )}")#text(" involved. Informally, what this means is that the density hypothesis fails not just through the existence of a sufficient number of “exceptional” zeroes ")#mi("{\\sigma+it}")#text(" with ")#mi("{\\sigma > \\alpha}")#text(", but in fact through a sufficient number of ")#emph[#text("clumps")]#text(" of exceptional zeroes – ")#mi("{\\gg \\log T}")#text(" such zeroes within a unit distance of each other.")
]

#heading(level: 1)[#strong[#text(" — 3. Primes in short intervals — ")]]

#text("As an application of the zero density estimates we obtain a prime number theorem in short intervals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Prime number theorem in short intervals)")]#text(" ")#metadata(none) <tao-fdb650157acc18ef4a3a>#text(" For any fixed ")#mi("{\\varepsilon > 0}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n < x+y} \\Lambda(n) = y + o(y)")]]

#text("whenever ")#mi("{x \\rightarrow \\infty}")#text(" and ")#mi("{x^{3/4+\\varepsilon} \\leq y \\leq x}")#text(". In particular, there exists a prime between ")#mi("{x}")#text(" and ")#mi("{x+x^{3/4+\\varepsilon}}")#text(" whenever ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(".")
]

#text("Theorems of this type were first obtained by Hohiesel in 1930. If the ")#mi("{3/4}")#text(" exponent could be lowered to be below ")#mi("{1/2}")#text(", this would establish ")#link("http://en.wikipedia.org/wiki/Legendre%27s_conjecture")[#text("Legendre’s conjecture")]#text(" that there always exists a prime between consecutive squares ")#mi("{n^2, (n+1)^2}")#text(", at least when ")#mi("{n}")#text(" is sufficiently large. Unfortunately, we do not know how to do this, even under the assumption of the Riemann hypothesis; the best unconditional result is ")#link("http://www.ams.org/mathscinet-getitem?mr=1851081")[#text("by Baker, Harman, and Pintz")]#text(", who established the existence of a prime between ")#mi("{x}")#text(" and ")#mi("{x+x^{0.525}}")#text(" for every sufficiently large ")#mi("{x}")#text(". Among other things, this establishes the existence of a prime between adjacent cubes ")#mi("{n^3, (n+1)^3}")#text(" if ")#mi("{n}")#text(" is large enough.")

#emph[#text("Proof:")]#text(" From the truncated explicit formula (Theorem 21 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n < x} \\Lambda(n) = x - \\sum_{\\rho: \\text{Re}(\\rho) > 3/4 + \\varepsilon/2, \\left|\\text{Im}(\\rho)\\right| \\leq x^{1/4-\\varepsilon/2}} \\frac{x^\\rho}{\\rho} + o(y)", block: true)]]

#text("and similarly with ")#mi("{x}")#text(" replaced by ")#mi("{x+y}")#text(". Subtracting, we conclude that ")#metadata(none) <tao-5400d6b19f4371145577>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\sum_{x \\leq n < x+y} \\Lambda(n) = y - \\sum_{\\rho: \\text{Re}(\\rho) > 3/4 + \\varepsilon/2, \\left|\\text{Im}(\\rho)\\right| \\leq x^{1/4-\\varepsilon/2}} \\frac{(x+y)^\\rho - x^\\rho}{\\rho} + o(y).", block: true)]]

#text("From the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#tao-math("(x+y)^\\rho - x^\\rho \\ll \\left|\\rho\\right| y x^{\\text{Re}(\\rho) - 1}", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\leq n < x+y} \\Lambda(n) = y + y \\sum_{\\rho: \\text{Re}(\\rho) > 3/4 + \\varepsilon/2, \\left|\\text{Im}(\\rho)\\right| \\leq x^{1/4-\\varepsilon/2}} O(x^{\\text{Re}(\\rho) - 1}) + o(y).", block: true)]]

#text("By symmetry of the zeroes, it thus suffices to show that ")#metadata(none) <tao-3c77f261a156a5308fee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{\\rho: \\text{Re}(\\rho) > 3/4 + \\varepsilon/2, 0 \\leq \\text{Im}(\\rho) \\leq x^{1/4-\\varepsilon/2}} x^{\\text{Re}(\\rho) - 1} = o(1).")]]

#text("Writing")

#align(center)[#tao-fit-display[#mitex("x^{\\text{Re}(\\rho) - 1} \\ll_\\varepsilon \\log x \\int_{3/4+\\varepsilon/4}^1 1_{\\sigma < \\text{Re}(\\rho)} x^{\\sigma-1}\\ d\\sigma,")]]

#text("we can bound the left-hand side of ")#link(<tao-3c77f261a156a5308fee>)[#text("(14)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll_\\varepsilon \\log x \\int_{3/4+\\varepsilon/4}^1 N( \\sigma, x^{1/4-\\varepsilon/2} ) x^{\\sigma-1}\\ d\\sigma.")]]

#text("From the Vinogradov-Korobov zero-free region (Exercise 5 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text("), we see that the integrand vanishes when ")#mi("{\\sigma \\geq 1 - A \\frac{\\log\\log x}{\\log x}}")#text(" for any ")#mi("{A>0}")#text(", if ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{A}")#text(". (Indeed, the Vinogradov-Korobov region gives more vanishing than this, but this is all that we shall need.) Using this and Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(", we may bound the left-hand side of ")#link(<tao-3c77f261a156a5308fee>)[#text("(14)")]#text(" by")

#tao-aligned(keep: true)[


#tao-math(" & \\ll_\\varepsilon \\log^{O(1)} x \\int_{3/4+\\varepsilon/4}^{1 - A \\log \\log x/ \\log x} x^{-2\\varepsilon(1-\\sigma)}\\ d\\sigma", block: true)



#tao-math(" & \\ll_\\varepsilon \\log^{O(1) - 2 \\varepsilon A} x", block: true)
]

#text("and the claim follows by choosing ")#mi("{A}")#text(" large enough depending on ")#mi("{\\varepsilon}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Assuming the density hypothesis, show that the exponent ")#mi("{3/4}")#text(" in Theorem ")#link(<tao-fdb650157acc18ef4a3a>)[#text("17")]#text(" can be replaced by ")#mi("{1/2}")#text("; thus the density hypothesis, though weaker than the Riemann or Lindelof hypotheses, is still strong enough to get a near-miss to the Legendre conjecture.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Using the Littlewood zero-free region (see Exercise 4 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(" and subsequent remarks) in place of the Vinogradov-Korobov zero-free region, obtain Theorem ")#link(<tao-fdb650157acc18ef4a3a>)[#text("17")]#text(" with ")#mi("{3/4}")#text(" replaced by some absolute constant ")#mi("{c<1}")#text(". (This is close to the original argument of Hohiesel.)")
]

#text("As we have seen several times in previous notes, one can obtain better results on prime number theorems in short intervals if one works ")#emph[#text("on average")]#text(" in ")#mi("{x}")#text(", rather than demanding a result which is true for all ")#mi("{x}")#text(". For instance, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 20 (Prime number theorem on the average)")]#text(" ")#metadata(none) <tao-4645f5141f13d441f35d>#text(" For any fixed ")#mi("{\\varepsilon > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{2X} \\left| \\sum_{x \\leq n < x+y} \\Lambda(n) - y\\right|^2\\ dx = o( y^2 X )", block: true)]]

#text("whenever ")#mi("{X \\rightarrow \\infty}")#text(" and ")#mi("{x^{1/2+\\varepsilon} \\leq y \\leq x}")#text(". In particular, there is a prime between ")#mi("{x}")#text(" and ")#mi("{x+x^{1/2+\\varepsilon}}")#text(" for ")#emph[#text("almost all")]#text(" ")#mi("{x}")#text(" in ")#mi("{[X,2X]}")#text(", in the sense that the set of exceptions has measure ")#mi("{o(X)}")#text(".")
]

#emph[#text("Proof:")]#text(" By arguing as in ")#link(<tao-5400d6b19f4371145577>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n < x+y} \\Lambda(n) - y = - \\sum_{\\rho: \\text{Re}(\\rho) > 1/2 + \\varepsilon/2, \\text{Im}(\\rho)| \\leq T} \\frac{(x+y)^\\rho - x^\\rho}{\\rho} + o(y)")]]

#text("where ")#mi("{T := x^{1/2-\\varepsilon/2}}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{2X} \\left| \\sum_{\\rho} \\frac{(x+y)^\\rho - x^\\rho}{\\rho} \\right|^2\\ dx = o( y^2 X )", block: true)]]

#text("where the sum is understood to be over zeroes ")#mi("{\\rho}")#text(" if the zeta function with ")#mi("{\\text{Re}(\\rho) > 1/2 + \\varepsilon/2, \\text{Im}(\\rho)| \\leq T}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\frac{(x+y)^\\rho - x^\\rho}{\\rho} = y\\int_0^1 (x+\\theta y)^{\\rho-1}\\ d\\theta")]]

#text("it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{2X} \\left| \\sum_{\\rho} (x+\\theta y)^{\\rho-1} \\right|^2\\ dx = o( X )", block: true)]]

#text("for each ")#mi("{0 < \\theta < 1}")#text("; shifting ")#mi("{x}")#text(" by ")#mi("{\\theta y}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{3X} \\left| \\sum_{\\rho} x^{\\rho-1} \\right|^2\\ dx = o( y^2 X ).", block: true)]]

#text("The left-hand side can be expanded as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\rho, \\rho^{\\prime}} \\int_X^{3X} x^{\\rho+\\overline{\\rho^{\\prime}}-2}\\ dx.")]]

#text("By symmetry we may bound this by")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\rho, \\rho^{\\prime}: \\text{Re}(\\rho) \\geq \\text{Re}(\\rho^{\\prime})} |\\int_X^{3X} x^{\\rho+\\overline{\\rho^{\\prime}}-2}\\ dx|.")]]

#text("For ")#mi("{\\rho^{\\prime} = \\rho+O(1)}")#text(", we may bound")

#align(center)[#tao-fit-display[#mitex("\\int_X^{3X} x^{\\rho+\\overline{\\rho^{\\prime}}-2}\\ dx \\ll X^{2 \\text{Re}(\\rho) - 1}")]]

#text("while for ")#tao-math("{\\left|\\rho^{\\prime}-\\rho\\right| > 1}", block: false)#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{3X} x^{\\rho+\\overline{\\rho^{\\prime}}-2}\\ dx \\ll \\frac{X^{2 \\text{Re}(\\rho) - 1}}{\\left|\\rho-\\rho^{\\prime}\\right|}", block: true)]]

#text("so on summing using Proposition 16 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\rho^{\\prime}: \\text{Re}(\\rho) \\geq \\text{Re}(\\rho^{\\prime})} \\left|\\int_X^{3X} x^{\\rho+\\overline{\\rho^{\\prime}}-2}\\ dx\\right| \\ll X^{2 \\text{Re}(\\rho) - 1} \\log^2 X", block: true)]]

#text("and so it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_\\rho X^{2 \\text{Re}(\\rho) - 2} = o( \\frac{1}{\\log^2 X} ).")]]

#text("But this can be done by a repetition of the arguments used to establish ")#link(<tao-3c77f261a156a5308fee>)[#text("(14)")]#text("; indeed, the left-hand side is")

#align(center)[#tao-fit-display[#mitex("\\ll_\\varepsilon \\int_{1/2+\\varepsilon/4}^1 N( \\sigma, x^{1/2-\\varepsilon/2} ) x^{2(\\sigma-1)}\\ d\\sigma")]]

#text("and by using the Vinogradov-Korobov zero-free region and Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(" as before, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]

#list(
[#text("(i) Assuming without proof that the exponent in Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(" can be lowered from ")#mi("{4}")#text(" to ")#mi("{12/5}")#text(", show that the exponent ")#mi("{1/2}")#text(" in Theorem ")#link(<tao-4645f5141f13d441f35d>)[#text("20")]#text(" may be lowered from ")#mi("{1/2}")#text(" to ")#mi("{1/6}")#text("; this implies in particular that Legendre’s conjecture is true for “almost all” ")#mi("{n}")#text(".")],
[#text("(ii) Assuming the density hypothesis, show that the exponent ")#mi("{1/2}")#text(" in Theorem ")#link(<tao-4645f5141f13d441f35d>)[#text("20")]#text(" can be lowered all the way to zero.")]
)
]

#heading(level: 1)[#strong[#text(" — 4. ")#mi("{L}")#text("-function variants — ")]]

#text("We have already seen in previous notes that many results about the Riemann zeta function ")#mi("{\\zeta(\\sigma+it)}")#text(" extend to ")#mi("{L}")#text("-functions ")#mi("{L(\\sigma+it,\\chi)}")#text(", with the variable ")#mi("{\\chi}")#text(" playing a role closely analogous to that of the imaginary ordinate ")#mi("{t}")#text(". Certainly, for instance, one can prove zero-density estimates for a single ")#mi("{L}")#text("-function ")#mi("{L(\\cdot,\\chi)}")#text(" for a single Dirichlet character of modulus ")#mi("{q}")#text(" by much the same methods as given previously, after the usual modification of replacing logarithmic factors such as ")#mi("{\\log(2+T)}")#text(" with ")#mi("{\\log(q(2+T))}")#text(" instead.")

#text("However, one can also prove “grand density theorems” in which one counts zeroes not just of a single ")#mi("{L}")#text("-function ")#mi("{\\sigma+it \\mapsto L(\\sigma+it,\\chi)}")#text(", but of a whole ")#emph[#text("family")]#text(" of ")#mi("{L}")#text("-functions ")#mi("{(\\sigma+it,\\chi) \\mapsto L(\\sigma+it,\\chi)}")#text(", in which ")#mi("{\\chi}")#text(" ranges in some given family (e.g. ")#emph[#text("all")]#text(" Dirichlet characters of a given modulus ")#mi("{q}")#text("). Such theorems are particularly useful when trying to control primes in an arithmetic progression ")#mi("{a\\ (q)}")#text(", since Fourier expansion then requires one to consider all characters of modulus ")#mi("{q}")#text(" simultaneously. (It is also of interest to obtain grand density theorems for all Dirichlet characters of modulus ")#emph[#text("up to")]#text(" some threshold ")#mi("{Q}")#text(", but we will not need to discuss this variant here.) In order to get good results in this regard, one needs a version of the large values theorems in which one averages over characters ")#mi("{\\chi}")#text(" as well as imaginary ordinates ")#mi("{t}")#text(". Here is a typical such result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (")#mi("{L^2}")#text(" estimate on large values with characters)")]#text(" ")#metadata(none) <tao-cc24a39580761b6348c4>#text(" Let ")#mi("{N \\geq 1}")#text(" and ")#mi("{T > 1}")#text(", let ")#mi("{q}")#text(" be a natural number, and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers. Let ")#mi("{t_1,\\dots,t_J}")#text(" be real numbers in an interval of length ")#mi("{T}")#text(", and let ")#mi("{\\chi_1,\\dots,\\chi_J}")#text(" be Dirichlet characters of modulus ")#mi("{q}")#text(" (possibly non-primitive or principal). Assume the following separation condition on the pairs ")#mi("{(\\chi_j,t_j)}")#text(" for ")#mi("{j=1,\\dots,J}")#text(": ")#metadata(none) <tao-451e2b719061fdaed685>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|t_j-t_{j^{\\prime}}\\right| \\geq 1 \\text{ whenever } 1 \\leq j < j^{\\prime} \\leq J \\text{ and } \\chi_j = \\chi_{j^{\\prime}}.", block: true)]]

#text("Then for any ")#mi("{\\sigma_1,\\dots,\\sigma_J \\in [-1,2]}")#text(", we have ")#metadata(none) <tao-23de467214ce1bae62f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sum_{j=1}^J \\left|N^{\\sigma_j} \\sum_{N/2 \\leq n \\leq N} a_n \\chi_j(n) n^{-\\sigma_j-it_j}\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll (qT + N) \\sum_{N/2 \\leq n \\leq N} \\left|a_n\\right|^2.", block: true)]]
]

#text("Note that this generalises Theorem ")#link(<tao-e2dd5fc22bd03997921e>)[#text("1")]#text(", which is the ")#mi("{q=1}")#text(" case of Theorem ")#link(<tao-cc24a39580761b6348c4>)[#text("22")]#text(".")

#emph[#text("Proof:")]#text(" We mimic the proof of Theorem ")#link(<tao-cc24a39580761b6348c4>)[#text("22")]#text(". By increasing ")#mi("{N}")#text(", we may reduce without loss of generality to the case ")#mi("{qT \\leq N/100}")#text(". As before, we apply the generalised Bessel inequality with the same weight ")#mi("{\\nu(n) := \\psi(n/N)}")#text(" used in Theorem ")#link(<tao-cc24a39580761b6348c4>)[#text("22")]#text(", to reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J c_j \\overline{c_{j^{\\prime}}} \\sum_n \\nu(n) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})} \\overline{\\chi_j} \\chi_{j^{\\prime}}(n) \\ll N.")]]

#text("Bounding ")#tao-math("{c_j \\overline{c_{j^{\\prime}}} \\ll \\left|c_j\\right|^2 + \\left|c_{j^{\\prime}}\\right|^2}", block: false)#text(" and using symmetry, it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j^{\\prime}=1}^J \\left|\\sum_n \\nu(n) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})} \\overline{\\chi_j} \\chi_{j^{\\prime}}(n)\\right| \\ll N", block: true)]]

#text("for each ")#mi("{j}")#text(".")

#text("We now focus on the expression ")#metadata(none) <tao-77041537222ecc0649b5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_n \\nu(n) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} n^{i(t_j-t_{j^{\\prime}})}) \\overline{\\chi_j} \\chi_{j^{\\prime}}(n)")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_n \\psi(n/N) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log n ) \\overline{\\chi_j} \\chi_{j^{\\prime}}(n).")]]

#text("As before, this expression is bounded by ")#mi("{O(N)}")#text(" in the diagonal case ")#mi("{j=j^{\\prime}}")#text(", which gives an acceptable contribution, so we turn to the case ")#mi("{j \\neq j^{\\prime}}")#text(". We split into two subcases, depending on whether ")#mi("{\\chi_j = \\chi_{j^{\\prime}}}")#text(" or not.")

#text("First suppose that ")#mi("{\\chi_j=\\chi_{j^{\\prime}}}")#text(". We then split the sum in ")#link(<tao-77041537222ecc0649b5>)[#text("(17)")]#text(" into ")#mi("{\\phi(q)}")#text(" sums, each arising from a primitive residue class ")#mi("{a\\ (q)}")#text(", on which ")#mi("{\\overline{\\chi_j} \\chi_{j^{\\prime}}(n) = 1}")#text(". Applying a change of variables ")#mi("{n = m q + a}")#text(" and then using Poisson summation as in the proof of Theorem ")#link(<tao-cc24a39580761b6348c4>)[#text("22")]#text(", one can show that each individual sum is ")#tao-math("{O( \\frac{N}{q \\left|t_j-t_{j^{\\prime}}\\right|^2} )}", block: false)#text(", so the total sum ")#link(<tao-77041537222ecc0649b5>)[#text("(17)")]#text(" is ")#tao-math("{O( \\frac{N}{\\left|t_j-t_{j^{\\prime}}\\right|^2} )}", block: false)#text(". Summing over all the ")#mi("{j^{\\prime}}")#text(" with ")#mi("{\\chi_{j^{\\prime}} = \\chi_j}")#text(", the ")#mi("{t_{j^{\\prime}}}")#text(" are ")#mi("{1}")#text("-separated by hypothesis, and so we obtain an acceptable contribution in this case.")

#text("Now suppose that ")#mi("{\\chi_j \\neq \\chi_{j^{\\prime}}}")#text(". Again, we can split the sum in ")#link(<tao-77041537222ecc0649b5>)[#text("(17)")]#text(" into ")#mi("{\\phi(q)}")#text(" sums, each of which is equal to ")#mi("{\\overline{\\chi_j} \\chi_{j^{\\prime}}(a)}")#text(" times")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = a\\ (q)} \\psi(n/N) (n/N)^{-\\sigma_j-\\sigma_{j^{\\prime}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log n )")]]

#text("for a primitive residue class ")#mi("{a\\ (q)}")#text(". Repeating the analysis of Theorem ")#link(<tao-cc24a39580761b6348c4>)[#text("22")]#text(", but now noting that ")#mi("{t_j-t_{j^{\\prime}}}")#text(" is not required to be bounded below, we can write this latter sum as")

#align(center)[#tao-fit-display[#mitex("\\frac{N}{q} (\\int_{\\bf R} \\frac{\\psi(x)}{x^{\\sigma_j+\\sigma_{j^{\\prime}}}} e( \\frac{t_j - t_{j^{\\prime}}}{2\\pi} \\log x )\\ dx + O( \\frac{1}{(N/q)^2} )).")]]

#text("Summing in ")#mi("{a}")#text(", and noting that ")#mi("{\\overline{\\chi_j} \\chi_{j^{\\prime}}}")#text(" has mean zero, we see that the main term here cancels out, and we can bound ")#link(<tao-77041537222ecc0649b5>)[#text("(17)")]#text(" by ")#mi("{O( \\frac{q}{N} )}")#text(". The total number of possible ")#mi("{j^{\\prime}}")#text(" can be bounded by ")#mi("{qT = O(N)}")#text(", and so the contribution of this case is acceptable (with a bit of room to spare). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" If one is willing to lose a factor of ")#mi("{\\log N}")#text(", the above proof can be simplified slightly by performing only one integration by parts rather than two in the integrals arising from Poisson summation.")
]

#text("We can now obtain a large values theorem in which the role of the interval ")#mi("{[0,T]}")#text(" is now replaced by the set ")#mi("{\\{ (\\chi,t): \\chi\\ (q), t \\in [0,T] \\}}")#text(" of pairs ")#mi("{(\\chi,t)}")#text(", with ")#mi("{\\chi}")#text(" a Dirichlet character of modulus ")#mi("{q}")#text(", and ")#mi("{t}")#text(" an element of ")#mi("{[0,T]}")#text(". Inside this set, we consider unit intervals of the form ")#mi("{\\{ (\\chi, t): t \\in [t_0,t_0+1] \\}}")#text(" for some Dirichlet character ")#mi("{\\chi}")#text(" and ")#mi("{t_0 \\in {\\bf R}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-25f3f839083673f183be>#text(" Let ")#mi("{N, T \\geq 2}")#text(", let ")#mi("{q}")#text(" be a natural number, and let ")#mi("{(a_n)_{N/2 \\leq n \\leq N}}")#text(" be a sequence of complex numbers obeying a bound of the form ")#mi("{a_n \\ll \\tau(n)^{O(1)} \\log^{O(1)} n }")#text(" for all ")#mi("{1 \\leq n \\leq N}")#text(". Let ")#mi("{0 \\leq \\beta \\leq 1}")#text(".")

#list(
[#text("(i) If ")#mi("{k}")#text(" is a natural number, show that after deleting at most ")#mi("{O_k( (qT)^\\beta \\log^{O_k(1)}(N) )}")#text(" unit intervals from ")#mi("{\\{ (\\chi,t): \\chi\\ (q), t \\in [0,T] \\}}")#text(", one has")

#metadata(none) <tao-90afb20389004a67fae9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n \\chi(n)}{n^{\\sigma+it}}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_k N^{1/2-\\sigma} \\max(N, (qT)^{1/k})^{1/2} (qT)^{-\\frac{\\beta}{2k}}")]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{(\\chi,t)}")#text(" in the remaining portion of ")#mi("{\\{ (\\chi,t): \\chi\\ (q), t \\in [0,T] \\}}")#text(".")],
[#text("(ii) If ")#mi("{N \\geq (qT)^\\varepsilon}")#text(" for some ")#mi("{\\varepsilon>0}")#text(", show that after deleting at most ")#mi("{O_\\varepsilon( T^\\beta \\log^{O_\\varepsilon(1)}(N) )}")#text(" unit intervals from ")#mi("{\\{ (\\chi,t): \\chi\\ (q), t \\in [0,T] \\}}")#text(", we have")

#metadata(none) <tao-c3129b819754e4356066>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\left|\\sum_{N/2 \\leq n \\leq N} \\frac{a_n}{n^{\\sigma+it}}\\right| \\ll_\\varepsilon N^{1-\\sigma-\\max(\\frac{\\beta}{4},\\beta-\\frac{1}{2})}", block: true)]]

#text("for all ")#mi("{-1 \\leq \\sigma \\leq 2}")#text(" and all ")#mi("{(\\chi,t)}")#text(" in the remaining portion of ")#mi("{\\{ (\\chi,t): \\chi\\ (q), t \\in [0,T] \\}}")#text(".")]
)
]

#text("For any ")#mi("{0 \\leq \\alpha \\leq 1}")#text(", ")#mi("{T \\geq 1}")#text(", and natural number ")#mi("{q}")#text(", let ")#mi("{N(\\alpha,q,T)}")#text(" denote the combined number of zeroes ")#mi("{\\sigma+it}")#text(" of all of the ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(" with ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(", ")#mi("{\\alpha \\leq \\sigma \\leq 1}")#text(" and ")#mi("{0 \\leq t \\leq T}")#text(", counting multiplicity of course. We can then repeat the proof of Corollary ")#link(<tao-d52b78b0b0630151485e>)[#text("11")]#text(" to give")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Grand zero-density estimate)")]#text(" ")#metadata(none) <tao-a3e969cef6a745d05453>#text(" Let ")#mi("{3/4 < \\alpha < 1}")#text(", ")#mi("{T \\geq 2}")#text(", and let ")#mi("{q}")#text(" be a natural number. Show that")

#align(center)[#tao-fit-display[#mitex("N(\\alpha,q,T) \\ll (qT)^{4(1-\\alpha)} \\log^{O(1)}(qT).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" For any ")#mi("{0 \\leq \\alpha \\leq 1}")#text(" and ")#mi("{Q,T \\geq 1}")#text(", let ")#mi("{\\tilde N(\\alpha,Q,T)}")#text(" denote the combined number of zeroes ")#mi("{\\sigma+it}")#text(" of all of the ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(" with ")#mi("{\\chi}")#text(" ")#emph[#text("primitive")]#text(" and of conductor at most ")#mi("{Q}")#text(", ")#mi("{\\alpha \\leq \\sigma \\leq 1}")#text(" and ")#mi("{0 \\leq t \\leq T}")#text(", counting multiplicity of course. Show that for any ")#mi("{3/4 < \\alpha < 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\tilde N(\\alpha,Q,T) \\ll (Q^2T)^{4(1-\\alpha)} \\log^{O(1)}(Q^2T).")]]

#text("(")#emph[#text("Hint:")]#text(" one will have to develop an analogue of Theorem ")#link(<tao-cc24a39580761b6348c4>)[#text("22")]#text(" and Exercise ")#link(<tao-25f3f839083673f183be>)[#text("24")]#text(" in which one works with primitive characters of conductor at most ")#mi("{Q}")#text(", rather than all characters of a fixed modulus ")#mi("{q}")#text(", and with all references to ")#mi("{QT}")#text(" replaced by ")#mi("{Q^2 T}")#text(".)")
]

#text("As with the density theorems for the zeta function, the exponents here may be improved somewhat, with the ")#mi("{4}")#text(" conjecturally being reducible to ")#mi("{2}")#text(" for any ")#mi("{1/2 < \\alpha < 1}")#text("; see Chapter 10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(". (Of course, the generalised Riemann hypothesis asserts that ")#mi("{N(\\alpha,q,T)}")#text(" in fact vanishes whenever ")#mi("{\\alpha > 1/2}")#text(".)")

#text("Given that the density estimates for the Riemann zeta function yield prime number theorems in short intervals, one expects the grand density estimates to yield prime number theorems in sparse (and short) arithmetic progressions. However, there are two technical issues with this. The first is that the analogue of the Vinogradov-Korobov zero-free region is not necessarily wide enough (in some ranges of parameters) for the argument to work. The second is that one may encounter an exceptional (Landau-Siegel) zero. These difficulties can be overcome, leading to Linnik’s theorem (as well as the quantitative refinement of this theorem by Gallagher); this will be the focus of the next set of notes.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452024")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2015")])]

#text("It seems that in the line below remark 13 (and more places) “corollary 25” should be “corollary 11”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f1a372e829463793aeb0a623311ea4ace0743754c878093a82082ffe3cd7d03-abe1f067d8cef1b256503dd90f7848db75a2186d27ca83029456caf89a091fd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of akshay")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452071")[#strong[#text("akshay")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("Dear Prof Tao,")

#text("If one proves simialr results about cancellations in short intervals for mobius instead of primes, do you think we can use that information to detect primes in short intervals? I have seen some recent work where they get cancellation in most intervals of size x^delta for Mobius. They use the algebraic structure of mobius ; build a bilinear structure by factoring out primes and then using standard estimates on dirichlet polynomials.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("Unfortunately one needs error terms of ")#mi("o( 1/\\log x)")#text(" or better in the Mobius function estimates before they become sensitive enough to detect primes (which have density ")#mi("O( 1/\\log x)")#text(", by the prime number theorem). The arguments of Matomaki and Radziwill (which I assume is what you are referring to) have worse error terms than this, indeed their first step is to throw away the contribution of the primes (as well as some other numbers without enough small prime factors) and to get the cancellation purely from small prime divisors. I think the way one should view their results (and similar results on bounded multiplicative functions) is that questions about the Mobius function and relatives (e.g. Liouville function) are in fact somewhat easier than those about prime numbers (or von Mangoldt function), at least if one is content with error terms that are worse than ")#mi("1/\\log x")#text(" times the main term.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452093")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("Hi Terry,")

#text("I’ve thought a bit about this issue in the past and I’ve never come to a clear understanding. It’s clear to me why the standard approach requires an ")#mi("o(1/\\log(x))")#text(" error term to convert from estimates involving Mobius to primes, but it isn’t clear to me how to reconcile this with the fact that ")#mi("\\sum_{n\\leq x} \\mu(n) = o(x)")#text(" is sufficient to imply the the PNT. Do you have any insight into this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452107")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("Dear Mark,")

#text("Landau’s observation that ")#mi("\\sum_{n \\leq x} \\mu(n) = o(x)")#text(" implies the prime number theorem relies on a multiplicative identity concerning the Mobius function, namely ")#mi("\\sum_{n \\leq x} \\mu(n) \\lfloor \\frac{x}{n} \\rfloor = 1")#text(", which allows one to upgrade the estimate ")#mi("\\sum_{n \\leq x} \\mu(n) = o(x)")#text(" to the stronger estimate ")#mi("\\sum_{n \\leq x} \\frac{\\mu(n)}{n} = o(1)")#text(", and now the error term is stronger than the trivial bound by a little bit more than a factor of a logarithm and so this bound is (in principle, at least) strong enough to discern primes. (It still takes a bit of extra manipulation to see this though, see e.g. Theorem 58 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".) Basically, because of the aforementioned identity, there already ")#emph[#text("is")]#text(" an estimate involving the Mobius function in the interval ")#mi("[1,x]")#text(" with an extremely good error term (in this case, the identity is exact and the error term is zero). No identity or estimate with such a good error term currently exists for the Mobius function in short intervals ")#mi("[x,x+y]")#text(" if ")#mi("y")#text(" is very small (e.g. less than ")#mi("x^{1/6}")#text(").")

#text("(The basic problem is that whilst ")#mi("[1,x]")#text(" has some limited closure properties with respect to multiplication, which allows one to exploit the multiplicative structure of the Mobius or von Mangoldt functions on this interval by direct elementary manipulations, the interval ")#mi("[x,x+y]")#text(" has no multiplicative closure properties whatsoever, and we only know how to exploit the multiplicative structure via complex analytic/Fourier analytic methods, i.e. through the zeta function. If one averages in x, one recovers a little bit of multiplicative closure that can be used, this is for instance how the method of Katai or Bourgain-Sarnak-Ziegler on establishing a little bit of cancellation in Mobius sums works. But if one restricts to the primes then one again loses all multiplicative closure properties.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nodes")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452077")[#strong[#text("Nodes")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("I don’t see any theorem here. At least some weak conjectures…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452108")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("In the sixth line below (1), it seems that “")#mi("N_ j^{\\sigma}")#text("” (in the LHS) should be “")#mi("N^{\\sigma _j}")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452280")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] the previous set of notes, we saw how zero-density theorems for the Riemann zeta function, when combined with the zero-free […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452431")[#strong[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2015")])]

#text("[…] to this paper, such estimates were only known (using arguments similar to those in Section 3 of Notes 6) for unconditionally, or for for some sufficiently large if one assumed the Riemann hypothesis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-452619")[#strong[#text("254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2015")])]

#text("[…] thanks to the existence of several mean value theorems for the zeta function, as discussed in Notes 6; we discuss this below the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-462854")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("There is a more precise estimate of Exercise 2 (ii), and can in the future to hope for a better result? (Without improving the large sieve, if necessary.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A conjectural local Fourier-uniformity of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-462893")[#strong[#text("A conjectural local Fourier-uniformity of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("[…] if for some fixed ; I believe this result is due to Ramachandra (see also Exercise 21 of this previous blog post), and in fact one could obtain a better error term on the right-hand side that for instance gained […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da87e6971d472723c5320e567915782b17a0a6f3a7b77d257bf00bc0df3d93a7-2d9ebf36b3b42665bb549f067b7e88557c0cb0b1ecbc1c8609a55b4f000307f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claudeh5")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-479370")[#strong[#text("Claudeh5")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Hello professor Tao,")

#text("In the proof of theorem 17, the formulas with Im(rho) have at the right a | but there is not | at the left.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-521318")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("[…] Zero density theorems […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-532952")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] grows much slower than this. By using the techniques based on zero density estimates discussed in Notes 6, it was shown by Motohashi that one can also establish (4) as long as (strictly speaking Motohashi […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computation-outsourced discussion of zero density theorems for the Riemann zeta function | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-685294")[#strong[#text("A computation-outsourced discussion of zero density theorems for the Riemann zeta function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2024")])]

#text("[…] and some coefficients of size ; see Section 10.2 of Iwaniec-Kowalski or these lecture notes of mine, or Appendix 3 of this recent paper of Maynard and Platt for more details. It is also possible to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/#comment-687729")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2025")])]

#text("I still feel n^2+1 is very difficult to solve.")
]
