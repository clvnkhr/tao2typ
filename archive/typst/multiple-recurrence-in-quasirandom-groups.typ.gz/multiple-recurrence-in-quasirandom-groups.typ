// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/
// Converted to Typst by tao2typ: "2026-10-14T16:36:56.799714+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Multiple recurrence in quasirandom groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Multiple recurrence in quasirandom groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 November 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/")[#text("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my joint paper with ")#link("http://www.math.osu.edu/~bergelson.1/")[#text("Vitaly Bergelson")]#text(", “")#link("http://arxiv.org/abs/1211.6372")[#text("Multiple recurrence in quasirandom groups")]#text("“, which is submitted to ")#link("http://www.springer.com/birkhauser/mathematics/journal/39")[#text("Geom. Func. Anal.")]#text(". This paper builds upon a ")#link("http://www.ams.org/mathscinet-getitem?mr=2410393")[#text("paper of Gowers")]#text(" in which he introduced the concept of a ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("quasirandom group")]#text(", and established some mixing (or recurrence) properties of such groups. A ")#mi("{D}")#text("-quasirandom group is a finite group with no non-trivial unitary representations of dimension at most ")#mi("{D}")#text(". We will informally refer to a “quasirandom group” as a ")#mi("{D}")#text("-quasirandom group with the quasirandomness parameter ")#mi("{D}")#text(" large (more formally, one can work with a ")#emph[#text("sequence")]#text(" of ")#mi("{D_n}")#text("-quasirandom groups with ")#mi("{D_n}")#text(" going to infinity). A typical example of a quasirandom group is ")#mi("{SL_2(F_p)}")#text(" where ")#mi("{p}")#text(" is a large prime. Quasirandom groups are discussed in depth in ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("this blog post")]#text(". One of the key properties of quasirandom groups established in Gowers’ paper is the following “weak mixing” property: if ")#mi("{A, B}")#text(" are subsets of ")#mi("{G}")#text(", then for “almost all” ")#mi("{g \\in G}")#text(", one has ")#metadata(none) <tao-2661a27c5e5afb754354>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu( A \\cap gB ) \\approx \\mu(A) \\mu(B)")]]

#text("where ")#tao-math("{\\mu(A) := \\left|A\\right|/\\left|G\\right|}", block: false)#text(" denotes the density of ")#mi("{A}")#text(" in ")#mi("{G}")#text(". Here, we use ")#mi("{x \\approx y}")#text(" to informally represent an estimate of the form ")#mi("{x=y+o(1)}")#text(" (where ")#mi("{o(1)}")#text(" is a quantity that goes to zero when the quasirandomness parameter ")#mi("{D}")#text(" goes to infinity), and “almost all ")#mi("{g \\in G}")#text("” denotes “for all ")#mi("{g}")#text(" in a subset of ")#mi("{G}")#text(" of density ")#mi("{1-o(1)}")#text("“. As a corollary, if ")#mi("{A,B,C}")#text(" have positive density in ")#mi("{G}")#text(" (by which we mean that ")#mi("{\\mu(A)}")#text(" is bounded away from zero, uniformly in the quasirandomness parameter ")#mi("{D}")#text(", and similarly for ")#mi("{B,C}")#text("), then (if the quasirandomness parameter ")#mi("{D}")#text(" is sufficiently large) we can find elements ")#mi("{g, x \\in G}")#text(" such that ")#mi("{g \\in A}")#text(", ")#mi("{x \\in B}")#text(", ")#mi("{gx \\in C}")#text(". In fact we can find approximately ")#tao-math("{\\mu(A)\\mu(B)\\mu(C) \\left|G\\right|^2}", block: false)#text(" such pairs ")#mi("{(g,x)}")#text(". To put it another way: if we choose ")#mi("{g,x}")#text(" uniformly and independently at random from ")#mi("{G}")#text(", then the events ")#mi("{g \\in A}")#text(", ")#mi("{x \\in B}")#text(", ")#mi("{gx \\in C}")#text(" are approximately independent (thus the random variable ")#mi("{(g,x,gx) \\in G^3}")#text(" resembles a uniformly distributed random variable on ")#mi("{G^3}")#text(" in some weak sense). One can also express this mixing property in integral form as")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f_1(g) f_2(x) f_3(gx)\\ d\\mu(g) d\\mu(x) \\approx (\\int_G f_1\\ d\\mu) (\\int_G f_2\\ d\\mu) (\\int_G f_3\\ d\\mu)")]]

#text("for any bounded functions ")#mi("{f_1,f_2,f_3: G \\rightarrow {\\bf R}}")#text(". (Of course, with ")#mi("{G}")#text(" being finite, one could replace the integrals here by finite averages if desired.) Or in probabilistic language, we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f_1(g) f_2(x) f_3(gx) \\approx \\mathop{\\bf E} f_1(x_1) f_2(x_2) f_3(x_3)")]]

#text("where ")#mi("{g, x, x_1, x_2, x_3}")#text(" are drawn uniformly and independently at random from ")#mi("{G}")#text(".")

#text("As observed in Gowers’ paper, one can iterate this observation to find “parallelopipeds” of any given dimension in dense subsets of ")#mi("{G}")#text(". For instance, applying ")#link(<tao-2661a27c5e5afb754354>)[#text("(1)")]#text(" with ")#mi("{A,B,C}")#text(" replaced by ")#mi("{A \\cap hB}")#text(", ")#mi("{C \\cap hD}")#text(", and ")#mi("{E \\cap hF}")#text(" one can assert (after some relabeling) that for ")#mi("{g,h,x}")#text(" chosen uniformly and independently at random from ")#mi("{G}")#text(", the events ")#mi("{g \\in A}")#text(", ")#mi("{h \\in B}")#text(", ")#mi("{gh \\in C}")#text(", ")#mi("{x \\in D}")#text(", ")#mi("{gx \\in E}")#text(", ")#mi("{hx \\in F}")#text(", ")#mi("{ghx \\in H}")#text(" are approximately independent whenever ")#mi("{A,B,C,D,E,F,H}")#text(" are dense subsets of ")#mi("{G}")#text("; thus the tuple ")#mi("{(g,h,gh,x,gh,hx,ghx)}")#text(" resebles a uniformly distributed random variable in ")#mi("{G^7}")#text(" in some weak sense.")

#text("However, there are other tuples for which the above iteration argument does not seem to apply. One of the simplest tuples in this vein is the tuple ")#mi("{(g, x, xg, gx)}")#text(" in ")#mi("{G^4}")#text(", when ")#mi("{g, x}")#text(" are drawn uniformly at random from a quasirandom group ")#mi("{G}")#text(". Here, one does ")#emph[#text("not")]#text(" expect the tuple to behave as if it were uniformly distributed in ")#mi("{G^4}")#text(", because there is an obvious constraint connecting the last two components ")#mi("{gx, xg}")#text(" of this tuple: they must lie in the same conjugacy class! In particular, if ")#mi("{A}")#text(" is a subset of ")#mi("{G}")#text(" that is the union of conjugacy classes, then the events ")#mi("{gx \\in A}")#text(", ")#mi("{xg \\in A}")#text(" are perfectly correlated, so that ")#mi("{\\mu( gx \\in A, xg \\in A)}")#text(" is equal to ")#mi("{\\mu(A)}")#text(" rather than ")#mi("{\\mu(A)^2}")#text(". Our main result, though, is that in a quasirandom group, this is (approximately) the ")#emph[#text("only")]#text(" constraint on the tuple. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0e09e7fe25a4a36cc090>#text(" Let ")#mi("{G}")#text(" be a ")#mi("{D}")#text("-quasirandom group, and let ")#mi("{g, x}")#text(" be drawn uniformly at random from ")#mi("{G}")#text(". Then for any ")#mi("{f_1,f_2,f_3,f_4: G \\rightarrow [-1,1]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f_1(g) f_2(x) f_3(gx) f_4(xg) = \\mathop{\\bf E} f_1(x_1) f_2(x_2) f_3(x_3) f_4(x_4) + o(1)")]]

#text("where ")#mi("{o(1)}")#text(" goes to zero as ")#mi("{D \\rightarrow \\infty}")#text(", ")#mi("{x_1,x_2,x_3}")#text(" are drawn uniformly and independently at random from ")#mi("{G}")#text(", and ")#mi("{x_4}")#text(" is drawn uniformly at random from the conjugates of ")#mi("{x_3}")#text(" for each fixed choice of ")#mi("{x_1,x_2,x_3}")#text(".")
]

#text("This is the probabilistic formulation of the above theorem; one can also phrase the theorem in other formulations (such as an integral formulation), and this is detailed in the paper. This theorem leads to a number of recurrence results; for instance, as a corollary of this result, we have")

#align(center)[#tao-fit-display[#mitex("\\mu(A) \\mu(B)^2 - o(1) \\leq \\mu( A \\cap gB \\cap Bg ) \\leq \\mu(A) \\mu(B) + o(1)")]]

#text("for almost all ")#mi("{g \\in G}")#text(", and any dense subsets ")#mi("{A, B}")#text(" of ")#mi("{G}")#text("; the lower and upper bounds are sharp, with the lower bound being attained when ")#mi("{B}")#text(" is randomly distributed, and the upper bound when ")#mi("{B}")#text(" is conjugation-invariant.")

#text("To me, the more interesting thing here is not the result itself, but how it is proven. Vitaly and I were not able to find a purely finitary way to establish this mixing theorem. Instead, we had to first use the machinery of ultraproducts (as discussed in ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("this previous post")]#text(") to convert the finitary statement about a quasirandom group to an infinitary statement about a type of infinite group which we call an ")#emph[#text("ultra quasirandom group")]#text(" (basically, an ultraproduct of increasingly quasirandom finite groups). This is analogous to how the Furstenberg correspondence principle is used to convert a finitary combinatorial problem into an infinitary ergodic theory problem.")

#text("Ultra quasirandom groups come equipped with a finite, countably additive measure known as ")#emph[#text("Loeb measure")]#text(" ")#mi("{\\mu_G}")#text(", which is very analogous to the Haar measure of a compact group, except that in the case of ultra quasirandom groups one does not quite have a topological structure that would give compactness. Instead, one has a slightly weaker structure known as a ")#emph[#mi("{\\sigma}")#text("-topology")]#text(", which is like a topology except that open sets are only closed under countable unions rather than arbitrary ones. There are some interesting measure-theoretic and topological issues regarding the distinction between topologies and ")#mi("{\\sigma}")#text("-topologies (and between Haar measure and Loeb measure), but for this post it is perhaps best to gloss over these issues and pretend that ultra quasirandom groups ")#mi("{G}")#text(" come with a Haar measure. One can then recast Theorem ")#link(<tao-0e09e7fe25a4a36cc090>)[#text("1")]#text(" as a mixing theorem for the left and right actions of the ultra approximate group ")#mi("{G}")#text(" on itself, which roughly speaking is the assertion that ")#metadata(none) <tao-ed7b9fa7fd6302be4b96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_G f_1(x) L_g f_2(x) L_g R_g f_3(x)\\ d\\mu_G(x) \\approx 0")]]

#text("for “almost all” ")#mi("{g \\in G}")#text(", if ")#mi("{f_1, f_2, f_3}")#text(" are bounded measurable functions on ")#mi("{G}")#text(", with ")#mi("{f_3}")#text(" having zero mean on all conjugacy classes of ")#mi("{G}")#text(", where ")#mi("{L_g, R_g}")#text(" are the left and right translation operators")

#align(center)[#tao-fit-display[#mitex("L_g f(x) := f(g^{-1} x); \\quad R_g f(x) := f(xg).")]]

#text("To establish this mixing theorem, we use the machinery of ")#emph[#text("idempotent ultrafilters")]#text(", which is a particularly useful tool for understanding the ergodic theory of actions of countable groups ")#mi("{G}")#text(" that need not be amenable; in the non-amenable setting the classical ergodic averages do not make much sense, but ultrafilter-based averages are still available. To oversimplify substantially, the idempotent ultrafilter arguments let one establish mixing estimates of the form ")#link(<tao-ed7b9fa7fd6302be4b96>)[#text("(2)")]#text(" for “many” elements ")#mi("{g}")#text(" of an infinite-dimensional parallelopiped known as an ")#emph[#text("IP system")]#text(" (provided that the actions ")#mi("{L_g,R_g}")#text(" of this IP system obey some technical mixing hypotheses, but let’s ignore that for sake of this discussion). The claim then follows by using the quasirandomness hypothesis to show that if the estimate ")#link(<tao-ed7b9fa7fd6302be4b96>)[#text("(2)")]#text(" failed for a large set of ")#mi("{g \\in G}")#text(", then this large set would then contain an IP system, contradicting the previous claim.")

#text("Idempotent ultrafilters are an extremely infinitary type of mathematical object (one has to use Zorn’s lemma no fewer than ")#emph[#text("three")]#text(" times just to construct one of these objects!). So it is quite remarkable that they can be used to establish a finitary theorem such as Theorem ")#link(<tao-0e09e7fe25a4a36cc090>)[#text("1")]#text(", though as is often the case with such infinitary arguments, one gets absolutely no quantitative control whatsoever on the error terms ")#mi("{o(1)}")#text(" appearing in that theorem. (It is also mildly amusing to note that our arguments involve the use of ultrafilters in two completely different ways: firstly in order to set up the ultraproduct that converts the finitary mixing problem to an infinitary one, and secondly to solve the infinitary mixing problem. Despite some superficial similarities, there appear to be no substantial commonalities between these two usages of ultrafilters.) There is already a fair amount of literature on using idempotent ultrafilter methods in infinitary ergodic theory, and perhaps by further development of ultraproduct correspondence principles, one can use such methods to obtain further finitary consequences (although the state of the art for idempotent ultrafilter ergodic theory has not advanced much beyond the analysis of two commuting shifts ")#mi("{L_g, R_g}")#text(" currently, which is the main reason why our arguments only handle the pattern ")#mi("{(g,x,xg,gx)}")#text(" and not more sophisticated patterns).")

#text("We also have some miscellaneous other results in the paper. It turns out that by using the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Triangle_removal_lemma")[#text("triangle removal lemma")]#text(" from graph theory, one can obtain a recurrence result that asserts that whenever ")#mi("{A}")#text(" is a dense subset of a finite group ")#mi("{G}")#text(" (not necessarily quasirandom), then there are ")#tao-math("{\\gg \\left|G\\right|^2}", block: false)#text(" pairs ")#mi("{(x,g)}")#text(" such that ")#mi("{x, gx, xg}")#text(" all lie in ")#mi("{A}")#text(". Using a hypergraph generalisation of the triangle removal lemma known as the ")#emph[#text("hypergraph removal lemma")]#text(", one can obtain more complicated versions of this statement; for instance, if ")#mi("{A}")#text(" is a dense subset of ")#mi("{G^2}")#text(", then one can find ")#tao-math("{\\gg \\left|G\\right|^2}", block: false)#text(" triples ")#mi("{(x,y,g)}")#text(" such that ")#mi("{(x,y), (gx, y), (gx, gy), (gxg^{-1}, gyg^{-1})}")#text(" all lie in ")#mi("{A}")#text(". But the method is tailored to the specific types of patterns given here, and we do not have a general method for obtaining recurrence or mixing properties for arbitrary patterns of words in some finite alphabet such as ")#mi("{g,x,y}")#text(".")

#text("We also give some properties of a model example of an ultra quasirandom group, namely the ultraproduct ")#mi("{SL_2(F)}")#text(" of ")#mi("{SL_2(F_{p_n})}")#text(" where ")#mi("{p_n}")#text(" is a sequence of primes going off to infinity. Thanks to the substantial recent progress (by Helfgott, Bourgain, Gamburd, Breuillard, and others) on understanding the expansion properties of the finite groups ")#mi("{SL_2(F_{p_n})}")#text(", we have a fair amount of knowledge on the ultraproduct ")#mi("{SL_2(F)}")#text(" as well; for instance any two elements of ")#mi("{SL_2(F)}")#text(" will almost surely generate a spectral gap. We don’t have any direct application of this particular ultra quasirandom group, but it might be interesting to study it further.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence in quasirandom groups « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/#comment-197407")[#strong[#text("Multiple recurrence in quasirandom groups « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("[…] Multiple recurrence in quasirandom groups. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mixing for progressions in non-abelian groups « What’s new")]], [#link("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/#comment-203696")[#strong[#text("Mixing for progressions in non-abelian groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("[…] paper is loosely related in subject topic to my two previous papers on polynomial expansion and on recurrence in quasirandom groups (with Vitaly Bergelson), although the methods here are rather different from those in those two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/#comment-255860")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] possible to use both types of ultrafilters in separate places for a single application; see this paper of Bergelson and myself for an […]")
]
