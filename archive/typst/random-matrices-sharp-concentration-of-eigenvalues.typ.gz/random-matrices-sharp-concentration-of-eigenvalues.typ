// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/
// Converted to Typst by tao2typ: "2026-10-14T16:36:46.757944+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: Sharp concentration of eigenvalues", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: Sharp concentration of eigenvalues")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 January 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/")[#text("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Van Vu and I have just uploaded to the arXiv our paper ")#link("http://arxiv.org/abs/1201.4789")[#text("Random matrices: Sharp concentration of eigenvalues")]#text(", submitted to the ")#link("http://ejp.ejpecp.org/")[#text("Electronic Journal of Probability")]#text(". As with many of our previous papers, this paper is concerned with the distribution of the eigenvalues ")#mi("{\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)}")#text(" of a random Wigner matrix ")#mi("{M_n}")#text(" (such as a matrix drawn from the ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Unitary Ensemble")]#text(" (GUE) or ")#link("http://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("Gaussian Orthogonal Ensemble")]#text(" (GOE)). To simplify the discussion we shall mostly restrict attention to the ")#emph[#text("bulk")]#text(" of the spectrum, i.e. to eigenvalues ")#mi("{\\lambda_i(M_n)}")#text(" with ")#mi("{\\delta n \\leq i \\leq (1-\\delta) i n}")#text(" for some fixed ")#mi("{\\delta>0}")#text(", although analogues of most of the results below have also been obtained at the edge of the spectrum.")

#text("If we normalise the entries of the matrix ")#mi("{M_n}")#text(" to have mean zero and variance ")#mi("{1/n}")#text(", then in the asymptotic limit ")#mi("{n \\rightarrow \\infty}")#text(", we have the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircle law")]#text(", which asserts that the eigenvalues are asymptotically distributed according to the semicircular distribution ")#mi("{\\rho_{sc}(x)\\ dx}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\rho_{sc}(x) := \\frac{1}{2\\pi} (4-x^2)_+^{1/2}.")]]

#text("An essentially equivalent way of saying this is that for large ")#mi("{n}")#text(", we expect the ")#mi("{i^{th}}")#text(" eigenvalue ")#mi("{\\lambda_i(M_n)}")#text(" of ")#mi("{M_n}")#text(" to stay close to the ")#emph[#text("classical location")]#text(" ")#mi("{\\gamma_i \\in [-2,2]}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{-2}^{\\gamma_i} \\rho_{sc}(x)\\ dx = \\frac{i}{n}.")]]

#text("In particular, from the Wigner semicircle law it can be shown that asymptotically almost surely, one has ")#metadata(none) <tao-94ffce1c041262a59ad3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lambda_i(M_n) = \\gamma_i + o(1)")]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(".")

#text("In the modern study of the spectrum of Wigner matrices (and in particular as a key tool in establishing universality results), it has become of interest to improve the error term in ")#link(<tao-94ffce1c041262a59ad3>)[#text("(1)")]#text(" as much as possible. A typical early result in this direction was ")#link("http://www.ams.org/mathscinet-getitem?mr=1217559")[#text("by Bai")]#text(", who used the ")#link("http://en.wikipedia.org/wiki/Stieltjes_transformation")[#text("Stieltjes transform")]#text(" method to obtain polynomial convergence rates of the shape ")#mi("{O(n^{-c})}")#text(" for some absolute constant ")#mi("{c>0}")#text("; see also the subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=1942311")[#text("papers of Alon-Krivelevich-Vu")]#text(" and of ")#link("http://www.ams.org/mathscinet-getitem?mr=2057479")[#text("of Meckes")]#text(", who were able to obtain such convergence rates (with exponentially high probability) by using concentration of measure tools, such as Talagrand’s inequality. On the other hand, in the case of the GUE ensemble it is known (by ")#link("http://www.ams.org/mathscinet-getitem?mr=2124079")[#text("this paper of Gustavsson")]#text(") that ")#mi("{\\lambda_i(M_n)}")#text(" has variance comparable to ")#mi("{\\frac{\\log n}{n^2}}")#text(" in the bulk, so that the optimal error term in ")#link(<tao-94ffce1c041262a59ad3>)[#text("(1)")]#text(" should be about ")#mi("{O(\\log^{1/2} n/n)}")#text(". (One may think that if one wanted bounds on ")#link(<tao-94ffce1c041262a59ad3>)[#text("(1)")]#text(" that were uniform in ")#mi("{i}")#text(", one would need to enlarge the error term further, but this does not appear to be the case, due to strong correlations between the ")#mi("{\\lambda_i}")#text("; note for instance this recent result of Ben Arous and Bourgarde that the largest gap between eigenvalues in the bulk is typically of order ")#mi("{O(\\log^{1/2} n/n)}")#text(".)")

#text("A significant advance in this direction was achieved by Erdos, Schlein, and Yau in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2481753")[#text("series")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2537522")[#text("of")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2587574")[#text("papers")]#text(" where they used a combination of Stieltjes transform and concentration of measure methods to obtain ")#emph[#text("local semicircle laws")]#text(" which showed, among other things, that one had asymptotics of the form")

#align(center)[#tao-fit-display[#mitex("N(I) = (1+o(1)) \\int_I \\rho_{sc}(x)\\ dx")]]

#text("with exponentially high probability for intervals ")#mi("{I}")#text(" in the bulk that were as short as ")#mi("{n^{-1+\\epsilon}}")#text(" for some ")#mi("{\\epsilon>0}")#text(", where ")#mi("{N(I)}")#text(" is the number of eigenvalues. These asymptotics are consistent with a good error term in ")#link(<tao-94ffce1c041262a59ad3>)[#text("(1)")]#text(", and are already sufficient for many applications, but do not quite imply a strong concentration result for individual eigenvalues ")#mi("{\\lambda_i}")#text(" (basically because they do not preclude long-range or “secular” shifts in the spectrum that involve large blocks of eigenvalues at mesoscopic scales). Nevertheless, this was rectified in a subsequent paper of ")#link("http://arxiv.org/abs/1007.4652")[#text("Erdos, Yau, and Yin")]#text(", which roughly speaking obtained a bound of the form")

#align(center)[#tao-fit-display[#mitex("\\lambda_i(M_n) = \\gamma_i + O( \\frac{\\log^{O(\\log\\log n)} n}{n} )")]]

#text("in the bulk with exponentially high probability, for Wigner matrices obeying some exponential decay conditions on the entries. This was achieved by a rather delicate high moment calculation, in which the contribution of the diagonal entries of the resolvent (whose average forms the Stieltjes transform) was shown to mostly cancel each other out.")

#text("As the GUE computations show, this concentration result is sharp up to the quasilogarithmic factor ")#mi("{\\log^{O(\\log\\log n)} n}")#text(". The main result of this paper is to improve the concentration result to one more in line with the GUE case, namely")

#align(center)[#tao-fit-display[#mitex("\\lambda_i(M_n) = \\gamma_i + O( \\frac{\\log^{O(1)} n}{n} )")]]

#text("with exponentially high probability (see ")#link("http://arxiv.org/abs/1201.4789")[#text("the paper")]#text(" for a more precise statement of results). The one catch is that an additional hypothesis is required, namely that the entries of the Wigner matrix have vanishing third moment. We also obtain similar results for the edge of the spectrum (but with a different scaling).")

#text("Our arguments are rather different from those of Erdos, Yau, and Yin, and thus provide an alternate approach to establishing eigenvalue concentration. The main tool is the Lindeberg exchange strategy, which is also used to prove the Four Moment Theorem (although we do not directly invoke the Four Moment Theorem in our analysis). The main novelty is that this exchange strategy is now used to establish large deviation estimates (i.e. exponentially small tail probabilities) rather than universality of the limiting distribution. Roughly speaking, the basic point is as follows. The Lindeberg exchange strategy seeks to compare a function ")#mi("{F(X_1,\\ldots,X_n)}")#text(" of many independent random variables ")#mi("{X_1,\\ldots,X_n}")#text(" with the same function ")#mi("{F(Y_1,\\ldots,Y_n)}")#text(" of a different set of random variables (which match moments with the original set of variables to some order, such as to second or fourth order) by exchanging the random variables one at a time. Typically, one tries to upper bound expressions such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\phi(F(X_1,\\ldots,X_n)) - \\phi(F(X_1,\\ldots,X_{n-1},Y_n))")]]

#text("for various smooth test functions ")#mi("{\\phi}")#text(", by performing a Taylor expansion in the variable being swapped and taking advantage of the matching moment hypotheses. In previous implementations of this strategy, ")#mi("{\\phi}")#text(" was a bounded test function, which allowed one to get control of the bulk of the distribution of ")#mi("{F(X_1,\\ldots,X_n)}")#text(", and in particular in controlling probabilities such as")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( a \\leq F(X_1,\\ldots,X_n) \\leq b )")]]

#text("for various thresholds ")#mi("{a}")#text(" and ")#mi("{b}")#text(", but did not give good control on the tail as the error terms tended to be polynomially decaying in ")#mi("{n}")#text(" rather than exponentially decaying. However, it turns out that one can modify the exchange strategy to deal with moments such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (1 + F(X_1,\\ldots,X_n)^2)^k")]]

#text("for various moderately large ")#mi("{k}")#text(" (e.g. of size comparable to ")#mi("{\\log n}")#text("), obtaining results such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} (1 + F(Y_1,\\ldots,Y_n)^2)^k = (1+o(1)) {\\bf E} (1 + F(X_1,\\ldots,X_n)^2)^k")]]

#text("after performing all the relevant exchanges. As such, one can then use large deviation estimates on ")#mi("{F(X_1,\\ldots,X_n)}")#text(" to deduce large deviation estimates on ")#mi("{F(Y_1,\\ldots,Y_n)}")#text(".")

#text("In this paper we also take advantage of a simplification, first ")#link("http://arxiv.org/abs/1001.3453")[#text("noted by Erdos, Yau, and Yin")]#text(", that Four Moment Theorems become somewhat easier to prove if one works with resolvents ")#mi("{(M_n-z)^{-1}}")#text(" (and the closely related Stieltjes transform ")#mi("{s(z) := \\frac{1}{n} \\text{tr}( (M_n-z)^{-1} )}")#text(") rather than with individual eigenvalues, as the Taylor expansion of resolvents are very simple (essentially being a ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]#text("). The relationship between the Stieltjes transform and the location of individual eigenvalues can be seen by taking advantage of the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{\\pi}{2} - \\frac{\\pi}{n} N((-\\infty,E)) = \\int_0^\\infty \\text{Re} s(E + i \\eta)\\ d\\eta")]]

#text("for any energy level ")#mi("{E \\in {\\bf R}}")#text(", which can be verified from elementary calculus. (In practice, we would truncate ")#mi("{\\eta}")#text(" near zero and near infinity to avoid some divergences, but this is a minor technicality.) As such, a concentration result for the Stieltjes transform can be used to establish an analogous concentration result for the eigenvalue counting functions ")#mi("{N((-\\infty,E))}")#text(", which in turn can be used to deduce concentration results for individual eigenvalues ")#mi("{\\lambda_i(M_n)}")#text(" by some basic combinatorial manipulations.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3441e661621d027ac010b4a07698f93b491d10b2eba91fe9068eba754803a679-1567982201c0e509c91885fb037990f88d277fc451d1f20e78db30e2af8a7bdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Janjigian")]], [#link("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/#comment-129465")[#strong[#text("Chris Janjigian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2012")])]

#text("I think there is a small formatting error in the sixth paragraph. The hyperlink to the third Erdos, Schlein, and Yau paper is not rendering correctly.")

#text("-Chris")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/#comment-132068")[#strong[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("[…] one can improve the error term here from to for any (see this previous recent paper of Van and myself for more discussion of these sorts of estimates, sometimes known as eigenvalue rigidity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of local spectral statistics of non-Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/#comment-146839")[#strong[#text("Random matrices: Universality of local spectral statistics of non-Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2012")])]

#text("[…] a task that is analogous to the task of obtaining concentration for Wigner matrices (as we did in this recent paper), as well as central limit theorems for log-determinants of Wigner matrices (as we did in this […]")
]
