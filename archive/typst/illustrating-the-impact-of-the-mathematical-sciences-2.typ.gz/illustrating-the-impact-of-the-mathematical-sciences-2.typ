// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/
// Converted to Typst by tao2typ: "2026-10-14T15:20:51.007690+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Illustrating the Impact of the Mathematical Sciences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Illustrating the Impact of the Mathematical Sciences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 January 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/")[#text("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Over the last few years, I have served on a committee of the ")#link("https://www.nasonline.org/")[#text("National Academy of Sciences")]#text(" to produce some posters and other related media to showcase twenty-first century and its applications in the real world, suitable for display in classrooms or math departments. Our posters (together with some associated commentary, webinars on related topics, and even a whimsical “")#link("https://nap.nationalacademies.org/resource/other/deps/illustrating-math/interactive/pdf/Math-hero.pdf")[#text("comic")]#text("“) are now available for download ")#link("https://nap.nationalacademies.org/resource/other/deps/illustrating-math/interactive/")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03086459cf864bfee73edb57758a8ab0b8067980c9d8c9de5c9ae28f75def3a6-2e47eb508ac01766d436057764bc964b46dca50108829a872f3420cec27aaae9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuchao Li")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-671977")[#strong[#text("Yuchao Li")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#text("The link for the computed commutes post seems not correct.")

#emph[#text("[Thanks, we’ll get this fixed – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80d22a5f8bd193f6a38491e0fa4cd3232fd32f8852036189ae60fd38f8bccb5c-134f2b76171fe0370e27ee62d7b3d4e513a459a0f8a23842d9f484853612287a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sally Keely")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672055")[#strong[#text("Sally Keely")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2023")])]

#text("Neither are some of the other poster links to “download” directing correctly. Look forward to seeing them fixed. Super work on the graphics and variety of applications.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2119dfe0cb3c4024a9db51fc268c1343e352ca4d59fe421dec13b77a2c2bdb3d-d22dafb3c0484c26eb914803d0661dd0da21fba1205edfd7b3ff2488c739a817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bredrindeacon")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672086")[#strong[#text("bredrindeacon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2023")])]

#text("Thanks a lot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2023")])]

#text("Dear Prof. Tao, The “Mathematics and Statistics of Weather Forecasting” section has a paragraph on “Automated Manufacturing” which I’m not sure is intentional.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672106")[#strong[#text("Mathematics, illustrated – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2023")]

#text("[…] Today’s mathematical research, both pure and applied, is paving the way for major scientific, engineering, and technological breakthroughs. Cutting-edge work in the mathematical sciences is responsible for advances in artificial intelligence, manufacturing, precision medicine, cybersecurity, and more. Find out how the mathematical sciences are helping to improve our everyday lives by checking out the stories and infographics below. … (NAP via Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/761742a06e570d151c97eda7e9fd6a3116c453db4564133ab44442a1841cb919-cef7280eedd0576db73291bf4d12d4e0dde9f18aa56535b1cbb056d86a84ebf9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sid67")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672287")[#strong[#text("Sid67")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2023")])]

#text("Very cool illustrations… Thank you !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a2efeb2b7f4cf3e31bfd6b23b86eacd3a9083431b39e2ed8a591aa698dae7e7-7f40345c9d16a200fbb4ad0988f17672fdf2eabcfce6186275d68819b4f24582.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S. Evans")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672328")[#strong[#text("S. Evans")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2023")])]

#text("If two mathematicians are emailing each other about their results in some theorems or conjectures, or some other math stuff, do they just send a pdf file or also include tex file out of courtesy? How it usually looks like?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a921ca72d07ce877625397f525fa2aae8235754ea0af2d4759b0767c4d75dc8-dde6bd68ccaae80337e8384a0842680cdc4083b6e086970fc9a8f61a0d320050.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Enderton")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672346")[#strong[#text("Enderton")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2023")])]

#text("Thanks a lot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7b3164c1a2d30f707f831f0a0d84e0bed5ecc9652e4edfe31d5df09b3037c34-2e34b065e4c30ae7bae583ac701810d30f971a2d0a12ae6c2bc2695c17e6a6ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fing")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-672518")[#strong[#text("fing")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("Tremendous!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/01/12/illustrating-the-impact-of-the-mathematical-sciences-2/#comment-677007")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2023")])]

#text("If k a ≡ k b (mod n) and a ≡ b (mod n), then")#linebreak()#text(" k is coprime with n???")
]
