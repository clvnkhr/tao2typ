// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/
// Converted to Typst by tao2typ: "2026-10-14T07:14:38.604344+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The power of convex relaxation: near-optimal matrix completion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The power of convex relaxation: near-optimal matrix completion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/")[#text("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.acm.caltech.edu/~emmanuel/")[#text("Emmanuel Candés")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/0903.1476")[#text("The power of convex relaxation: near-optimal matrix completion")]#text("“, submitted to ")#link("http://pareja.itsoc.org/initial_submission/")[#text("IEEE Inf. Theory")]#text(". In this paper we study the ")#emph[#text("matrix completion problem")]#text(", which one can view as a sort of “non-commutative” analogue of the ")#emph[#text("sparse recovery problem")]#text(" studied in the field of ")#link("http://en.wikipedia.org/wiki/Compressed_sensing")[#text("compressed sensing")]#text(", although there are also some other significant differences between the two problems. The sparse recovery problem seeks to recover a sparse vector ")#mi("x \\in {\\Bbb R}^n")#text(" from some linear measurements ")#mi("Ax = b \\in {\\Bbb R}^m")#text(", where A is a known ")#mi("m \\times n")#text(" matrix. For general x, classical linear algebra tells us that if m < n, then the problem here is underdetermined and has multiple solutions; but under the additional assumption that x is ")#emph[#text("sparse")]#text(" (most of the entries are zero), it turns out (under various hypotheses on the measurement matrix A, and in particular if A contains a sufficient amount of “randomness” or “incoherence”) that exact recovery becomes possible in the underdetermined case. Furthermore, recovery is not only theoretically possible, but is also computationally practical in many cases; in particular, under some assumptions on A, one can recover x by minimising the convex norm ")#tao-math("\\left\\| x \\right\\|_{\\ell^1}", block: false)#text(" over all solutions to Ax=b.")

#text("Now we turn to the matrix completion problem. Instead of an unknown vector ")#mi("x \\in {\\Bbb R}^n")#text(", we now have an unknown matrix ")#mi("M = (m_{ij})_{i \\in [n_1], j \\in [n_2]} \\in {\\Bbb R}^{n_1 \\times n_2}")#text(" (we use the shorthand ")#mi("[n] := \\{1,\\ldots,n\\}")#text(" here). We will take a specific type of underdetermined linear measurement of M, namely we pick a random subset ")#mi("\\Omega \\subset [n_1] \\times [n_2]")#text(" of the matrix array ")#mi("[n_1] \\times [n_2]")#text(" of some cardinality ")#mi("1 \\leq m \\leq n_1 n_2")#text(", and form the random sample ")#mi("P_\\Omega(M) := (m_{ij})_{(i,j) \\in \\Omega} \\in {\\Bbb R}^{\\Omega}")#text(" of M.")

#text("Of course, with no further information on M, it is impossible to complete the matrix M from the partial information ")#mi("P_\\Omega(M)")#text(" – we only have ")#mi("m")#text(" pieces of information and need ")#mi("n_1 n_2")#text(". But suppose we also know that M is ")#emph[#text("low-rank")]#text(", e.g. has rank less than r; this is an analogue of sparsity, but for matrices rather than vectors. Then, in principle, we have reduced the number of degrees of freedom for M from ")#mi("n_1 n_2")#text(" to something more like ")#mi("O( r \\max(n_1,n_2) )")#text(", and so (in analogy with compressed sensing) one may now hope to perform matrix completion with a much smaller fraction of samples, and in particular with m close to ")#mi("r \\max(n_1,n_2)")#text(".")

#text("This type of problem comes up in several real-world applications, most famously in the ")#link("http://en.wikipedia.org/wiki/Netflix_Prize")[#text("Netflix prize")]#text(". The Netflix prize problem is to be able to predict a very large ratings matrix M, whose rows are the customers, whose columns are the movies, and the entries are the rating that each customer would hypothetically assign to each movie. Of course, not every customer has rented every movie from Netflix, and so only a small fraction ")#mi("P_\\Omega(M)")#text(" of this matrix is actually known. However, if one makes the assumption that most customers’ rating preference is determined by only a small number of characteristics of the movie (e.g. genre, lead actor/actresses, director, year, etc.), then the matrix should be (approximately) low rank, and so the above type of analysis should be useful (though of course it is not going to be the ")#emph[#text("only")]#text(" tool of use in this messy, real-world problem).")

#text("Actually, one expects to need to oversample the matrix by a logarithm or two in order to have a good chance of exact recovery, if one is sampling randomly. This can be seen even in the rank one case r=1, in which ")#mi("M=uv^*")#text(" is the product of a column vector and a row vector; let’s consider square matrices ")#mi("n_1=n_2=n")#text(" for simplicity. Observe that if the sampled coordinates ")#mi("\\Omega")#text(" completely miss one of the rows of the matrix, then the corresponding element of u has gone completely unmeasured, and one cannot hope to complete this row of the matrix. Thus one needs to sample every row (and also every column) of the ")#mi("n \\times n")#text(" matrix. The solution to the ")#link("http://en.wikipedia.org/wiki/Coupon_collector%27s_problem")[#text("coupon collector’s problem")]#text(" then tells us that one needs about ")#mi("O(n \\log n)")#text(" samples to achieve this goal. In fact, the theory of ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93R%C3%A9nyi_model")[#text("Erdős-Rényi random graphs")]#text(" tells us that the bipartite graph induced by ")#mi("\\Omega")#text(" becomes almost surely connected beyond this threshold, which turns out to be exactly what is needed to perform matrix completion for rank 1 matrices.")

#text("On the other hand, one cannot hope to complete the matrix if some of the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition#Singular_values.2C_singular_vectors.2C_and_their_relation_to_the_SVD")[#text("singular vectors")]#text(" of the matrix are extremely sparse. For instance, in the Netflix problem, a singularly idiosyncratic customer (or dually, a singularly unclassifiable movie) may give rise to a row or column of M that has no relation to the rest of the matrix, occupying its own separate component of the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(" of M; such a row or column is then impossible to complete exactly without sampling the entirety of that row or column. Thus, to get exact matrix completion from a small fraction of entries, one needs some sort of ")#emph[#text("incoherence")]#text(" assumption on the singular vectors, which spreads them out across all coordinates in a roughly even manner, as opposed to being concentrated on just a few values.")

#text("In a recent paper, ")#link("http://arxiv.org/abs/0805.4471")[#text("Candés and Recht")]#text(" proposed solving the matrix completion problem by minimising the ")#emph[#text("nuclear norm")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Trace_class")[#text("trace norm")]#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\|M\\right\\|_* = \\sum_{i=1}^{\\min(n_1,n_2)} \\sigma_i(M) = \\text{tr}( M M^*)^{1/2}", block: true)]]

#text("amongst all matrices consistent with the observed data ")#mi("P_\\Omega(M)")#text(". This nuclear norm is the non-commutative counterpart to the ")#mi("\\ell^1")#text(" norm for vectors, and so this algorithm is analogous to the ")#mi("\\ell^1")#text(" minimisation (or ")#emph[#text("basis pursuit")]#text(") algorithm which is effective for compressed sensing (though not the only such algorithm for this task). They showed, roughly speaking, that exact matrix completion (for, say, square matrices ")#mi("n_1=n_2=n")#text(" for simplicity) is ensured with high probability so long as the singular vectors obey a certain incoherence property (basically, their ")#mi("\\ell^\\infty")#text(" norm should be close to the minimal possible value, namely ")#mi("O(1/\\sqrt{n})")#text("), so long as one had the condition")

#align(center)[#mi("m \\gg n^{1.2} r \\log n")#text(".")]

#text("This differs from the presumably optimal threshold of ")#mi("nr \\log n")#text(" by a factor of about ")#mi("n^{0.2}")#text(".")

#text("The main result of our paper is to mostly eliminate this gap, at the cost of a stronger hypothesis on the matrix being measured:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Main theorem.")]#text(" (Informal statement) Suppose the ")#mi("n_1 \\times n_2")#text(" matrix M has rank r and obeys a certain “strong incoherence property”. Then with high probability, nuclear norm minimisation will recover M from a random sample ")#mi("P_\\Omega(M)")#text(" provided that ")#mi("m \\gg n r \\log^{O(1)} n")#text(", where ")#mi("n := \\max(n_1,n_2)")#text(".")
]

#text("A result of a broadly similar nature, but with a rather different recovery algorithm and with a somewhat different range of applicability, was recently established ")#link("http://arxiv.org/abs/0901.3150")[#text("by Keshavan, Oh, and Montanari")]#text(". The strong incoherence property is somewhat technical, but is related to the Candés-Recht incoherence property and is satisfied by a number of reasonable random matrix models. The exponent O(1) here is reasonably civilised (ranging between 2 and 9, depending on the specific model and parameters being used).")

#metadata(none) <tao-1bdb76758756e047cdf0>#text("The general strategy of proof is broadly similar to that in my ")#link("http://front.math.ucdavis.edu/math.CA/0409186")[#text("first compressed sensing paper with Candés and Romberg")]#text(", and also with the more recent paper of ")#link("http://arxiv.org/abs/0805.4471")[#text("Candés and Recht")]#text(". (The later papers, based around the restricted isometry property (RIP), are not directly applicable, as the possibility of concentrated singular values defeats the naive non-commutative analogue of the RIP. However, if one changes the measurement model by taking random Gaussian linear measurements of M (viewed as an ")#mi("n_1 n_2")#text("-dimensional vector) rather than randomly sampling the entries, then one can recover an RIP-like property, together with most of the compressed sensing theory; see ")#link("http://faculty.washington.edu/mfazel/lowrank.html")[#text("this paper of Recht, Fazel, and Parrilo")]#text(".)")

#text("To begin the proof, one uses a duality argument (essentially just the ")#link("http://en.wikipedia.org/wiki/Hahn%E2%80%93Banach_theorem")[#text("Hahn-Banach theorem")]#text(", combined with a standard computation of the (")#link("http://en.wikipedia.org/wiki/Subgradient")[#text("sub")]#text("-)gradient of the nuclear norm) to equate the success of the nuclear norm minimisation with that of establishing the existence of a certain “dual certificate” matrix Y with certain technical properties relating to the sampling operator ")#mi("P_\\Omega")#text(", to the orthogonal projections ")#mi("P_U, P_V")#text(" to the spaces U, V generated by the left- and right- singular vectors ")#mi("u_1,\\ldots,u_r, v_1,\\ldots,v_r")#text(" appearing in the singular value decomposition ")#mi("M = \\sum_{i=1}^r \\sigma_i u_i v_i^*")#text(" of M, and also on the “sign pattern” ")#mi("E := \\sum_{i=1}^r u_i v_i^*")#text(" of M. The strong incoherence property alluded to earlier is a condition on the matrix coefficients of ")#mi("P_U, P_V, E")#text(", basically saying that they behave in magnitude as if the singular vectors were distributed randomly.")

#text("In order to locate this certificate, we perform a least-squares minimisation, which requires inverting and then estimating a certain operator arising from ")#mi("P_\\Omega, P_U, P_V")#text(". Inversion can be accomplished by using a useful ")#link("http://www.ams.org/mathscinet-getitem?mr=1694526")[#text("selection lemma of Rudelson")]#text(", but to obtain good estimates on the resulting certificate, we need to expand in Neumann series and estimate the spectral norm of a certain complicated combination of ")#mi("P_\\Omega, P_U, P_V")#text(". The first few terms of this series were already controlled by ")#link("http://arxiv.org/abs/0805.4471")[#text("Candés and Recht")]#text(", using tools from high-dimensional geometry such as the non-commutative Khintchine inequality. However, these techniques do not seem to be able to fully exploit all the (increasingly non-commutative) cancellations present in these products of matrix operators after the fourth or fifth iterate or so, which is ultimately what causes the loss of ")#mi("n^{0.2}")#text(" in their result. To deal with this, we instead rely on the classical moment method, raising the operators involved to high powers and computing traces. As usual, this reduces us to considering certain sums over paths, which in this case are paths of horizontal, vertical, and “non-rook” moves in the grid ")#mi("[n_1] \\times [n_2]")#text(". But the paths here end up being rather combinatorially complicated, resembling a “spider” with a compact body but many legs. Furthermore, there are some subtle cancellations in the coefficients (ultimately arising from identities such as ")#mi("P_U P_U = P_U")#text(", ")#mi("P_U E = E")#text(", ")#mi("E^* E = P_V")#text(", etc.) which need to be exploited in order to obtain near-optimal results, although in the bounded rank case r=O(1) it turns out that a relatively “low-tech” approach suffices (taking absolute values and using fairly crude estimates everywhere).")

#text("The basic difficulty is that this spider can self-intersect in a large number of ways. Furthermore, it is not enough to track how often each vertex is traversed by this spider; one must also keep track of the various transitions the spider makes from one row to another, or from one column to another In some cases, the matrix coefficients arising from two of these transitions can “collapse” to a single matrix coefficient (due to identities such as ")#mi("P_U P_U = P_U")#text("), replacing the combinatorial configuration of the spider with a “simpler” configuration. The strategy is then to exploit these identities to collapse the spider whenever possible, until no further cancellations remain, and it becomes safe to estimate everything by absolute values. This collapsing procedure is the most delicate portion of the paper, and is highly combinatorial in nature.")

#text("In a forthcoming paper of Candés and Plan, the exact recovery results here for noiseless measurement models will be extended to provide approximate recovery results in the presence of noise.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidspeyer")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36562")[#strong[#text("davidspeyer")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Typo in the first paragraph: “most of the entries are non-zero” should read “most of the entries are zero.” ")#emph[#text("[Corrected, thanks – T.]")]

#text("Sounds like interesting work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36572")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Matrix completion problems often come with an extra requirement that the solutions must be symmetric positive semi-definite. Then it is a particular kind of ")#link("http://en.wikipedia.org/wiki/Semidefinite_programming")[#text("semidefinite programming")]#text(", which is a generalisation of linear programming.")#linebreak()#text(" I wonder if you ever looked into extensing your condenced sensing technique to the semidefinite programming.")#linebreak()#text(" This would be wonderful news if something like this works there, too…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22414dfb3ed0b891bf6edefc4c7a9bdb29a6f2fb647a805b52972f6fa1872d2c-c02d7b162e9810c7997c6c4166ed3afda617aa03c264d2d01c1ec48766afdd1b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FhnuZoag")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36584")[#strong[#text("FhnuZoag")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("So, Prof Tao, are you actually working on the Netflix prize?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36589")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("Dear Dima,")

#text("Nuclear norm minimisation is already a convex optimisation program and so I would imagine that one could simply impose the semidefinite and symmetric conditions as an additional constraint and still get a computationally practical problem. It is not hard to show that if the original convex program recovered the correct solution, then the program with the additional ")#emph[#text("a priori")]#text(" information on the solution added as a constraint would also recover the correct solution (providing, of course, that this a priori information is accurate). In fact any information of a convex nature can be incorporated easily. It may even be possible to improve the theoretical guarantees for recovery with this additional information, although this would require a complicated reworking of our random matrix calculations as one would be inserting additional projections into the dual certificate to try to “improve” it.")

#text("I believe there has been some experimentation to use SDPs instead of linear programs to improve the reach of compressed sensing, but I think the results so far are still rather partial and tentative.")

#text("Dear FhnuZoag: I am not directly working on this prize, but I understand that nuclear norm minimisation is already one of the techniques being incorporated into some of the competition efforts. Of course, being a messy real-world problem, one does not rely just on one tool, but on a wide variety of other methods as well, combined together in some empirically optimised fashion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john mangual")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36595")[#strong[#text("john mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("I don’t think there’s a single place in industry that isn’t trying to solve an underdetermined system of equations. I like the idea that a unique solution can exist if we impose other conditions on our solution (e.g. sparseness).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cc1a16a1fa0d35ea9dfdb939b72dcfb988ded386908eac766e440d02d50767b-9d8bffb733f3342d0f6ab1a990da4d92c172c55b5f0b5d2b3977a53f27bad5a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrea Montanari")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36603")[#strong[#text("Andrea Montanari")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("One interesting question is the following:")

#text("Assume that the graph induced by ")#mi("\\Omega")#text(" is uniformly random conditional on")#linebreak()#text(" a minimum degree ")#mi("Const.*r")#text(". Is then completion possible? For rank one this is")#linebreak()#text(" true (but not so interesting).")

#text("If the answer is positive, then the logarithmic factor in the uniform model are just")#linebreak()#text(" due to those columns/rows with less than ")#mi("Const*r")#text(" revealed entries.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36608")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2009")])]

#text("Dear Andrea,")

#text("I believe in the rank 1 case ")#mi("M = uv^*")#text(" one also needs the graph induced by ")#mi("\\Omega")#text(" to be connected, otherwise one can multiply u on one connected component by a scalar and divide v on the same connected component by the same scalar and get a lack of uniqueness. But once one is connected and hits every row and column, one does get unique recovery in the rank 1 case. (But I guess connectedness becomes extremely likely once the mindegree is conditioned to be at least 3.)")

#text("Similarly, in the rank r case one needs to not be able to disconnect the graph by removing r-1 edges. But I guess that if the min-degree is at least 3r (say) then this is also highly unlikely.")

#text("It may be that these are the only conditions for information-theoretic recovery of the data in the general rank case; it is an interesting question, and possibly a tractable one (one basically has to understand the tangent space of the space of rank r matrices, and in particular how the zero entries of a matrix in that tangent space can be distributed).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36833")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("Dear Terry,")

#text("The upcoming paper by Candes and Plan is now located at:")

#link("http://www.acm.caltech.edu/~emmanuel/papers/NoisyCompletion.pdf")[#text("Click to access NoisyCompletion.pdf")]

#text("Cheers,")

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cc1a16a1fa0d35ea9dfdb939b72dcfb988ded386908eac766e440d02d50767b-9d8bffb733f3342d0f6ab1a990da4d92c172c55b5f0b5d2b3977a53f27bad5a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrea Montanari")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36953")[#strong[#text("Andrea Montanari")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("Dear Terence,")

#text("we submitted a long version of our paper:")

#link("http://www.stanford.edu/~montanar/PAPERS/FILEPAP/spectral16.pdf")[#text("Click to access spectral16.pdf")]

#text("Any feedback is welcome.")

#text("Andrea")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36960")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("The papers describe this matrix completion problem and algorithm as analogous to compressed sensing. But could compressed sensing be interpreted as a special case of matrix completion, namely for circulant matrices? (Or maybe generalized circulant, for some other abelian or even non-abelian group.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36980")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("Greg: I may be missing something obvious here, since I have only a vague passing familiarity with compressed sensing, but what is the connection with circulant matrices?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-36986")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("The point is that first, a circulant matrix is an expanded form of its first row, which is an arbitrary vector; and second, that you obtain the singular values of the circulant matrix by taking the Fourier transform of that vector. I don’t know enough details of compressed sensing to say this for sure, but this construction leads me to ask whether matrix completion is not just analogous to compressed sensing, but rather a generalization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-37008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("Dear Greg,")

#text("Hmm, that’s a good observation. The compressed sensing problem of recovering a function with few Fourier coefficients from a sparse sample is indeed formally equivalent to recovering a circulant matrix with low rank from a sparse sample, and the recovery algorithm used in the former (L^1 minimisation of the Fourier transform) is a special case of the recovery algorithm used in the latter (minimisation of nuclear norm).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-37035")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("There are many special cases of the matrix completion problem that could be called compressed sensing. As I said more briefly in the parentheses,")#linebreak()#text(" suppose that the rows and columns of a matrix are indexed by elements of a group, and suppose that the entry M_{ab} only depends on a^{-1}b. Then this is a generalized kind of circulant matrix, particularly if the group is non-commutative, and the recovery algorithm is another kind of compressed sensing.")

#text("For this reason, matrix completion could just as well be called non-commutative compressed sensing. This is surely a useful viewpoint. Also this phrase “nuclear norm” makes this slightly less clear, since that norm is of course just the spectral ell^1 norm.")

#text("The next question of course is what theorems about compressed sensing are subsumed by the matrix completion version. If a result has been subsumed, that’s interesting for one reason; and if it hasn’t been, it’s also interesting because you can ask why not.")

#text("—-")

#text("Taking things in a different direction, when I just skim the moment estimates in the matrix completion paper, it reminds me of the moment version of the non-commutative central limit theorem. (I don’t mean the free probability version, although that one is also a moment story, but rather the standard quantum probability version.) This is known as the Giri-von-Waldenfels theorem. I think that it’s an interesting problem to work out non-moment versions of this result, i.e., versions that more resemble convergence in distribution. A key problem is to define what convergence in distribution should mean in the quantum case. (Again, in the case of free probability it’s easier, because the limiting distribution is bounded and thus determined by its moments.) In my arXiv paper “A tracial quantum central limit theorem”, I obtained a partial result in this direction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-37269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Dear Greg,")

#text("The noncommutative circulant matrices are interesting, although they begin to fall outside of the scope of matrix completion as it becomes quite hard for such matrices to be low rank (the noncommutative Fourier transform, in addition to being sparse, has to avoid all the high-dimensional irreducible representations). The proofs of the matrix completion results mimic in many places the compressed sensing results (and now I have a better understanding as to why, thanks to your observation), but they are more complicated and give worse bounds. (For instance, applying the result of this paper directly to the problem of measuring a function with only r Fourier coefficients using as few samples as possible, we need nr log^6 n or so random samples, whereas our original result in that case gave r log n. (The factor of n discrepancy is due to the fact that in the circulant case, measuring one matrix entry automatically gives you another n-1 matrix entries for free, so that should be ignored.)")

#text("At an early stage in the project with Emmanuel we tried using various non-commutative tools, notably the non-commutative Khintchine inequality, but the high moment expressions we ended up facing were just too entangled together in a non-commutative way for such tools to simplify the expressions we were facing. It seems that the moment method is actually one of the more robust methods for doing things like controlling operator norms of products of random matrices, though the combinatorial tasks needed to execute the method can be really quite sizeable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-37285")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Yeah I sort of figured that the log factors would be worse. Of course it raises the question of what’s better about circulant matrices, actual convergence/completion or merely the methods for obtaining bounds.")

#text("As for non-commutative circulant matrices, it is true that there is a relevant negative result concerning the structure of finite groups. Namely, if all irreps have dimension at most k, then the group G has an abelian subgroup of index at most f(k). However, I think that f may grow quickly enough that there is a middle ground, where the rank is not all that much larger than sparseness and yet G is not all that close to abelian.")

#text("Then too, when you have a non-commutative circulant matrix M, or indeed in any circumstance when M a priori commutes with some group action of a group G, then the spectrum of M is colored by the irreps of G. So in this case you have many natural variations of the nuclear norm obtained by assigning different weights to the irreps. Should each irrep be weighted by its dimension, as you will obtain by direct restriction of the ordinary nuclear norm? Or should it be weighted by 1, or by something in between? Well, maybe it’s as simple as that the sparseness promise is described with a weighting, and the convex relaxation should simply be chosen with the same weighting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cacb39b6277ed54f516eb3f55d9fe00bf40edc1379e8cc355ecc34b0cf81cbb3-83212c721fa10bf5229088b5ae49c4a87400f3b47eb0f64e7ed542043e09636a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-37441")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2009")])]

#text("Hello Professor Tao,")

#text("Have you seen this paper on a related method? Thought you might like to check this out:")

#link("http://arxiv.org/abs/0901.1898")[#text("http://arxiv.org/abs/0901.1898")]

#text("– Adam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0c3b4b8b699561081aab9c4f63bbf39fb411af8f9ec1741172a22020ea6b7b2-f0e21db4f4aa9e48ce36be33f1d4d4652e06b7c9b7a8f7ae6a110d19365cc7e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Smith")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-42308")[#strong[#text("Joe Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("As I understand these papers (which is not well) the random sample from the matrix is drawn as though you had a single bin containing one ball for each element in the n1 x n2 matrix M and drew out balls randomly.")

#text("Would a more restricted and realistic sampling method allow tighter proofs?")

#text("Suppose:")

#text("1.) You have a bin (the “row” bin) containing n2 balls for each of the values 1 … n1. (IE there are n1 * n2 balls altogether in the row bin)")#linebreak()#text(" 2.) You have n1 bins (the “column” bins), labelled 1 .. n1, each containing n2 balls marked consecutively 1 … n2")

#text("You draw a ball from the row bin (which gives you a row number) and then draw a ball from the “columns” bin corresponding to the row number you have just drawn. The combination of the two balls now identifies an entry.")

#text("Identifying entries in this way would be more realistic and should result in a subset which is less likely to grossly over or under represent some rows or columns and hence should allow slightly tighter bounds.")

#text("Just a thought.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/772d7fb5e0c696c0d50b1fd8b15f1aaee4662621fb652e70aa9f7e685fe72bd3-6c9631313e10e331dc2b97e62b2cd821e406643db6b04c6fb45a399de6de5dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jagannathan Arjun S")]], [#link("https://terrytao.wordpress.com/2009/03/10/the-power-of-convex-relaxation-near-optimal-matrix-completion/#comment-44065")[#strong[#text("Jagannathan Arjun S")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2010")])]

#text("Dr.Tao,")

#text("I apologize for my ignorance in advance and am thankful for the time taken in reading what i have put down.")#linebreak()#text(" I did read a few papers on matrix completion, in particular :")#linebreak()#text(" a. Candes and Recht :Exact matrix completion via convex optimization")#linebreak()#text(" b. Zhisu Zu et al: Fast and near-optimal matrix completion via randomized basis pursuit")#linebreak()#text(" To what i can interpret in the crudest sense is that:")#linebreak()#text(" 1: first the linearly independent columns of a matrix A or rank r are selected by some suitable algorithm")#linebreak()#text(" 2. Then the other columns are expressed as a linear combination of these columns.")#linebreak()#text(" Hence the entire purpose of this matrix completion algorithm is that using these basis vectors we fill in the entries of other rows.")#linebreak()#text(" I am an undergraduate working on data compression using compressive projection principal component analysis by J Fowler.")#linebreak()#text(" There we multiply a given data matrix with a random orthonormal matrix reducing the dimension and multiply.")#linebreak()#text(" then using the the transpose of the same random orthonormal matrix and use rayleigh ritz theory to approximate the real eigenvectors with the ritz vectors. Then we reconstruct using PCA.")#linebreak()#text(" This really works well for hyperspectral data but fails for normal images as the normalized ritz vectors are unaligned to the real eigen vectors significantly")#linebreak()#text(" The covariance varies significantly from that of the input images data. I wonder can this matrix completion be used for data compression by making just randomly selecting the basis vectors of the input image.")#linebreak()#text(" sorry for the trouble")
]
