// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/
// Converted to Typst by tao2typ: "2026-10-14T15:19:08.284171+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Avila, Bhargava, Hairer, Mirzakhani", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Avila, Bhargava, Hairer, Mirzakhani")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 August 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/")[#text("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The 2014 Fields medallists have ")#link("http://www.mathunion.org/general/prizes/2014/prize-citations/")[#text("just been announced")]#text(" as (in alphabetical order of surname) ")#link("http://en.wikipedia.org/wiki/Artur_Avila")[#text("Artur Avila")]#text(", ")#link("http://en.wikipedia.org/wiki/Manjul_Bhargava")[#text("Manjul Bhargava")]#text(", ")#link("http://en.wikipedia.org/wiki/Martin_Hairer")[#text("Martin Hairer")]#text(", and ")#link("http://en.wikipedia.org/wiki/Maryam_Mirzakhani")[#text("Maryam Mirzakhani")]#text(" (see also these nice ")#link("http://www.simonsfoundation.org/quanta/20140812-a-brazilian-wunderkind-who-calms-chaos/")[#text("video profiles for the winners")]#text(", which is a new initiative of the IMU and the Simons foundation). This time four years ago, I wrote ")#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/")[#text("a blog post")]#text(" discussing one result from each of the 2010 medallists; I thought I would try to repeat the exercise here, although the work of the medallists this time around is a little bit further away from my own direct area of expertise than last time, and so my discussion will unfortunately be a bit superficial (and possibly not completely accurate) in places. As before, I am picking these results based on my own idiosyncratic tastes, and they should not be viewed as necessarily being the “best” work of these medallists. (See also the press releases for ")#link("http://www.mathunion.org/fileadmin/IMU/Prizes/2014/news_release_avila.pdf")[#text("Avila")]#text(", ")#link("http://www.mathunion.org/fileadmin/IMU/Prizes/2014/news_release_bhargava.pdf")[#text("Bhargava")]#text(", ")#link("http://www.mathunion.org/fileadmin/IMU/Prizes/2014/news_release_hairer.pdf")[#text("Hairer")]#text(", and ")#link("http://www.mathunion.org/fileadmin/IMU/Prizes/2014/news_release_mirzakhani.pdf")[#text("Mirzakhani")]#text(".)")

#text("Artur Avila works in dynamical systems and in the study of Schrödinger operators. The work of Avila that I am most familiar with is ")#link("http://www.ams.org/mathscinet-getitem?mr=2521117")[#text("his solution")]#text(" with ")#link("http://www.math.uci.edu/~szhitomi/")[#text("Svetlana Jitormiskaya")]#text(" of the ")#emph[#text("ten martini problem")]#text(" of Kac, the solution to which (according to Barry Simon) he offered ten martinis for, hence the name. (The problem had also been previously posed in the work ")#link("http://www.jetp.ac.ru/cgi-bin/e/index/e/19/3/p634?a=list")[#text("of Azbel")]#text(" and ")#link("http://adsabs.harvard.edu/abs/1975PhDT........43H")[#text("of Hofstadter")]#text(".) The problem involves perhaps the simplest example of a Schrödinger operator with non-trivial spectral properties, namely the ")#link("http://en.wikipedia.org/wiki/Almost_Mathieu_operator")[#text("almost Mathieu operator")]#text(" ")#mi("{H^{\\lambda,\\alpha}_\\omega: \\ell^2({\\bf Z}) \\rightarrow \\ell^2({\\bf Z})}")#text(" defined for parameters ")#mi("{\\alpha,\\omega \\in {\\bf R}/{\\bf Z}}")#text(" and ")#mi("{\\lambda>0}")#text(" by a discrete one-dimensional Schrödinger operator with cosine potential:")

#align(center)[#tao-fit-display[#mitex("(H^{\\lambda,\\alpha}_\\omega u)_n := u_{n+1} + u_{n-1} + 2\\lambda (\\cos 2\\pi(\\theta+n\\alpha)) u_n.")]]

#text("This is a bounded self-adjoint operator and thus has a spectrum ")#mi("{\\sigma( H^{\\lambda,\\alpha}_\\omega )}")#text(" that is a compact subset of the real line; it arises in a number of physical contexts, most notably in the theory of the ")#link("http://en.wikipedia.org/wiki/Quantum_Hall_effect#Integer_quantum_Hall_effect_.E2.80.93_Landau_levels")[#text("integer quantum Hall effect")]#text(", though I will not discuss these applications here. Remarkably, the structure of this spectrum depends crucially on the Diophantine properties of the frequency ")#mi("{\\alpha}")#text(". For instance, if ")#mi("{\\alpha = p/q}")#text(" is a rational number, then the operator is periodic with period ")#mi("{q}")#text(", and then basic (discrete) ")#link("http://en.wikipedia.org/wiki/Floquet_theory")[#text("Floquet theory")]#text(" tells us that the spectrum is simply the union of ")#mi("{q}")#text(" (possibly touching) intervals. But for irrational ")#mi("{\\alpha}")#text(" (in which case the spectrum is independent of the phase ")#mi("{\\theta}")#text("), the situation is much more fractal in nature, for instance in the critical case ")#mi("{\\lambda=1}")#text(" the spectrum (as a function of ")#mi("{\\alpha}")#text(") gives rise to the ")#link("http://en.wikipedia.org/wiki/Hofstadter%27s_butterfly")[#text("Hofstadter butterfly")]#text(". The “ten martini problem” asserts that for ")#emph[#text("every")]#text(" irrational ")#mi("{\\alpha}")#text(" and every choice of coupling constant ")#mi("{\\lambda > 0}")#text(", the spectrum is homeomorphic to a Cantor set. Prior to the work of Avila and Jitormiskaya, there were a number of partial results on this problem, notably ")#link("http://www.ams.org/mathscinet-getitem?mr=2031032")[#text("the result of Puig")]#text(" establishing Cantor spectrum for a full measure set of parameters ")#mi("{(\\lambda,\\alpha)}")#text(", as well as results requiring a perturbative hypothesis, such as ")#mi("{\\lambda}")#text(" being very small or very large. The result was also already known for ")#mi("{\\alpha}")#text(" being either very close to rational (i.e. a Liouville number) or very far from rational (a Diophantine number), although the analyses for these two cases failed to meet in the middle, leaving some cases untreated. The argument uses a wide variety of existing techniques, both perturbative and non-perturbative, to attack this problem, as well as an amusing argument by contradiction: they assume (in certain regimes) that the spectrum ")#emph[#text("fails")]#text(" to be a Cantor set, and use this hypothesis to obtain additional Lipschitz control on the spectrum (as a function of the frequency ")#mi("{\\alpha}")#text("), which they can then use (after much effort) to improve existing arguments and conclude that the spectrum was in fact Cantor after all!")

#text("Manjul Bhargava produces amazingly beautiful mathematics, though most of it is outside of my own area of expertise. One part of his work that touches on an area of my own interest (namely, random matrix theory) is his ongoing work with many co-authors on modeling (both conjecturally and rigorously) the statistics of various key number-theoretic features of elliptic curves (such as their rank, their ")#link("http://en.wikipedia.org/wiki/Selmer_group")[#text("Selmer group")]#text(", or their ")#link("http://en.wikipedia.org/wiki/Tate%E2%80%93Shafarevich_group")[#text("Tate-Shafarevich groups")]#text("). For instance, ")#link("http://arxiv.org/abs/1304.3971")[#text("with Kane, Lenstra, Poonen, and Rains")]#text(", Manjul has proposed a very general random matrix model that predicts all of these statistics (for instance, predicting that the ")#mi("{p}")#text("-component of the Tate-Shafarevich group is distributed like the cokernel of a certain random ")#mi("{p}")#text("-adic matrix, very much in the spirit of the Cohen-Lenstra heuristics discussed in ")#link("https://terrytao.wordpress.com/2009/10/02/at-the-austms-conference/")[#text("this previous post")]#text("). But what is even more impressive is that Manjul and his coauthors have been able to ")#emph[#text("verify")]#text(" several non-trivial fragments of this model (e.g. showing that certain moments have the predicted asymptotics), giving for the first time non-trivial upper and lower bounds for various statistics, for instance obtaining lower bounds on how often an elliptic curve has rank ")#mi("{0}")#text(" or rank ")#mi("{1}")#text(", leading most recently (in combination with existing work ")#link("http://www.ams.org/mathscinet-getitem?mr=833192")[#text("of Gross-Zagier")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1106906")[#text("of Kolyvagin")]#text(", among others) to his ")#link("http://arxiv.org/abs/1407.1826")[#text("amazing result with Skinner and Zhang")]#text(" that at least ")#mi("{66\\%}")#text(" of all elliptic curves over ")#mi("{{\\bf Q}}")#text(" (ordered by height) obey the ")#link("http://en.wikipedia.org/wiki/Birch_and_Swinnerton-Dyer_conjecture")[#text("Birch and Swinnerton-Dyer conjecture")]#text(". Previously it was not even known that a positive proportion of curves obeyed the conjecture. This is still a fair ways from resolving the conjecture fully (in particular, the situation with the presumably small number of curves of rank ")#mi("{2}")#text(" and higher is still very poorly understood, and the theory of Gross-Zagier and Kolyvagin that this work relies on, which was initially only available for ")#mi("{{\\bf Q}}")#text(", has only been extended to totally real number fields thus far, by the ")#link("http://www.ams.org/mathscinet-getitem?mr=1826411")[#text("work of Zhang")]#text("), but it certainly does provide hope that the conjecture could be within reach in a statistical sense at least.")

#text("Martin Hairer works in at the interface between probability and partial differential equations, and in particular in the theory of stochastic differential equations (SDEs). The result of his that is closest to my own interests is his remarkable demonstration with ")#link("http://fds.duke.edu/db/aas/math/faculty/jonm/")[#text("Jonathan Mattingly")]#text(" of unique invariant measure for the two-dimensional stochastically forced Navier-Stokes equation")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla u)  & = \\nu \\Delta u - \\nabla p + \\xi", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("on the two-torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(", where ")#mi("{\\xi}")#text(" is a Gaussian field that forces a fixed set of frequencies. It is expected that for any reasonable choice of initial data, the solution to this equation should asymptotically be distributed according to Kolmogorov’s power law, as discussed ")#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/")[#text("in this previous post")]#text(". This is still far from established rigorously (although there are some results in this direction for dyadic models, see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=3050291")[#text("this paper of Cheskidov, Shvydkoy, and Friedlander")]#text("). However, Hairer and Mattingly were able to show that there was a unique probability distribution to almost every initial data would converge to asymptotically; by the ergodic theorem, this is equivalent to demonstrating the existence and uniqueness of an invariant measure for the flow. Existence can be established using standard methods, but uniqueness is much more difficult. One of the standard routes to uniqueness is to establish a “strong Feller property” that enforces some continuity on the transition operators; among other things, this would mean that two ergodic probability measures with intersecting supports would in fact have a non-trivial common component, contradicting the ergodic theorem (which forces different ergodic measures to be mutually singular). Since all ergodic measures for Navier-Stokes can be seen to contain the origin in their support, this would give uniqueness. Unfortunately, the strong Feller property is unlikely to hold in the infinite-dimensional phase space for Navier-Stokes; but Hairer and Mattingly develop a clean abstract substitute for this property, which they call the ")#emph[#text("asymptotic strong Feller")]#text(" property, which is again a regularity property on the transition operator; this in turn is then demonstrated by a careful application of Malliavin calculus.")

#text("Maryam Mirzakhani has mostly focused on the geometry and dynamics of ")#link("http://en.wikipedia.org/wiki/Teichm%C3%BCller_space")[#text("Teichmuller")]#text("-type moduli spaces, such as the moduli space of Riemann surfaces with a fixed genus and a fixed number of cusps (or with a fixed number of boundaries that are geodesics of a prescribed length). These spaces have an incredibly rich structure, ranging from geometric structure (such as the Kahler geometry given by the ")#link("http://en.wikipedia.org/wiki/Weil%E2%80%93Petersson_metric")[#text("Weil-Petersson metric")]#text("), to dynamical structure (through the action of the ")#link("http://en.wikipedia.org/wiki/Mapping_class_group")[#text("mapping class group")]#text(" on this and related spaces), to algebraic structure (viewing these spaces as algebraic varieties), and are thus connected to many other objects of interest in geometry and dynamics. For instance, by ")#link("http://www.ams.org/mathscinet-getitem?mr=2264808")[#text("developing a new recursive formula")]#text(" for the Weil-Petersson volume of this space, Mirzakhani was ")#link("http://www.ams.org/mathscinet-getitem?mr=2415399")[#text("able to")]#text(" asymptotically count the number of ")#emph[#text("simple")]#text(" prime geodesics of length up to some threshold ")#mi("{L}")#text(" in a hyperbolic surface (or more precisely, she obtained asymptotics for the number of such geodesics in a given orbit of the mapping class group); the answer turns out to be polynomial in ")#mi("{L}")#text(", in contrast to the much larger class of ")#emph[#text("non-simple")]#text(" prime geodesics, whose asymptotics are exponential in ")#mi("{L}")#text(" (the “prime number theorem for geodesics”, developed in a classic series of works by Delsart, Huber, Selberg, and Margulis); she also used this formula to establish a new proof of a ")#link("http://www.ams.org/mathscinet-getitem?mr=1144529")[#text("conjecture of Witten")]#text(" on intersection numbers that was first ")#link("http://www.ams.org/mathscinet-getitem?mr=1171758")[#text("proven by Kontsevich")]#text(". More recently, in two lengthy papers ")#link("http://arxiv.org/abs/1302.3320")[#text("with Eskin")]#text(" and ")#link("http://arxiv.org/abs/1305.3015")[#text("with Eskin-Mohammadi")]#text(", Mirzakhani established rigidity theorems for the action of ")#mi("{SL_2({\\bf R})}")#text(" on such moduli spaces that are close analogues of Ratner’s celebrated rigidity theorems for unipotently generated groups (discussed in ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("this previous blog post")]#text("). Ratner’s theorems are already notoriously difficult to prove, and rely very much on the polynomial stability properties of unipotent flows; in this even more complicated setting, the unipotent flows are no longer tractable, and Mirzakhani instead uses a recent “exponential drift” method of ")#link("http://www.ams.org/mathscinet-getitem?mr=2831114")[#text("Benoist and Quint")]#text(" as a substitute. Ratner’s theorems are incredibly useful for all sorts of problems connected to homogeneous dynamics, and the analogous theorems established by Mirzakhani, Eskin, and Mohammadi have a similarly broad range of applications, for instance in counting periodic billiard trajectories in rational polygons.")

#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c856f898b656f06931c63b14624d0c963cd5c1e8a1321eba6c3d545c5788509-d0f669246554889b8dd2a2eeca5d6f9aa1a79191e28b9d5c3ab341cab9ebc6f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of johngg")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-404947")[#strong[#text("johngg")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("You wrote about the medalists 4 years ago not last year.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be2af8833324863183e543625d6a9b6998ae7008e76ca10cd948348fb9953896-e264b72abced211c5147c522add4690016dbdb930def2b404d11fe0e31ab07b2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zr9558")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-404974")[#strong[#text("zr9558")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Reblogged this on ")#link("http://zr9558.com/2014/08/13/avila-bhargava-hairer-mirzakhani/")[#text("ZHANG RONG")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-404978")[#strong[#text("Media Item from “Haaretz” Today: “For the first time ever…” | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")]

#text("[…] The ICM 2014 started today in Seoul. The International congress taking place once every four years is an exciting event, celebrated by thousands of mathematicians in Seoul and many others all over the world. The opening ceremonies came with the announcement of Artur Avila, Manjul Bhargava, Martin Hairer, and Maryam Mirzakhani as 2014 Fields medalist, Subhash Khot won the Nevanlinna prize, Stanley Osher won the Gauss prize and Phillip Griffiths is the Chern medalist, and Adrián Paenza won the Leelavati Prize. Heartly congratulations to Artur, Manjul, Martin, Maryam, Subhash, Stanley, Phillip, and Adrián! This is also the first for Brazil and Iran! More on the Fields medalists works can be found on Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1a454862b828d38f91fa20af79797f30d7b1cf1c79c282187831a734e0044c-93b3fb1b52ebafc1caf3989f29aa38b888f8b8063d34a60054ebd2cce1e4dff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-404998")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Impressive that 3 of the 4 winners represent important milestones:")

#text("First women + Iranian + Middle Eastern winner.")#linebreak()#text(" First Brazilian + Latin American winner.")#linebreak()#text(" First ethnic Indian winner.")

#text("Hairer is also the first Austrian winner, to my knowledge. :)")

#text("Hopefully an auspicious sign of things to come.")

#text("In addition, 2 of the 4 winners this year were former IMO medalists, giving another boost to the IMO’s prestige. It’ll be interesting to see which standout IMO participants from recent years follow in their footsteps. Lisa Sauermann? Teodor von Burg? Raúl Arturo Chávez Sarmiento? Jeck Lim?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb4d0ea6f05b229eba5add9a6dd2f401bbfe0f2e3ed01b5f54cbe257e2e745db-d451b2bb624951388d98dce4b51ae5e935ecde473f2430f63b53d8f8fbc88865.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of william e emba")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405418")[#strong[#text("william e emba")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("Lindenstrauss was the first Middle Eastern winner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-464672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2016")])]

#text("Indian -Canadian/American, best of both worlds. But still brought up through the American system")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8fd8846f9567d43dab0ad5ad4b10411ca7222931c828202eb19fd3d9e3a2406-f32568bfbc3a888c728823972e16d49aec3b04959de515500e538ddc4141bcbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szilard")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405013")[#strong[#text("Szilard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("“First women + Iranian + Middle Eastern winner.")#linebreak()#text(" First Brazilian + Latin American winner.")#linebreak()#text(" First ethnic Indian winner. ”")

#text("I really hope that they have achieved something extraordinary that’s why they gor the award.")

#text("Giving an award based on gender and location is a very bad thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3acbc51d3a05fbc18248ec7ae40badc8a2e02ab9f389cfa50f7945b8ba5a0e26-08827152807835222b88e3e2d15d6d1700b746e1a9bbf1b201c3d2033cc69084.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scons Dut")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405037")[#strong[#text("Scons Dut")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("You have seen by yourself that they did, indeed, achieve extraordinary things. There is nothing worrying in enjoying the mentionned facts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1a454862b828d38f91fa20af79797f30d7b1cf1c79c282187831a734e0044c-93b3fb1b52ebafc1caf3989f29aa38b888f8b8063d34a60054ebd2cce1e4dff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405201")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Please don’t make ignorant comments like this. All four of the 2014 medalists have been favorites among experts for years and have sterling research records. All of them have previously received many laurels for their contributions; Mirzakhani has won the AMS prize and Clay Award; Avila has won the EMS prize, and so on.")

#text("The Fields Medal selection process is about as meritocratic as such an award can be, and probably less clouded by political considerations than the Nobels for the hard sciences. I’ve yet to meet any reputable mathematician who thinks this year’s winners are undeserving.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/302be603ef4405f78a729c67e5ba4faa50e4c842cb64ea616599c6104aeba3f0-742513852daecb5286c675d7eae72aceab73f0a1e3b302e202db704ada6fb79f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mo Beans")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-431321")[#strong[#text("Mo Beans")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2014")])]

#text("Not sure if Tao’s already linked to these, but here are good lay-friendly press releases of the Fields winners along with their research if you’re still interested in knowing whether “they’ve achieved something extraordinary”:")

#text("Artur Avila (")#link("http://www.quantamagazine.org/20140812-a-brazilian-wunderkind-who-calms-chaos/")[#text("http://www.quantamagazine.org/20140812-a-brazilian-wunderkind-who-calms-chaos/")]#text(")")#linebreak()#text(" Manjul Bhargava (")#link("http://www.quantamagazine.org/20140812-the-musical-magical-number-theorist/")[#text("http://www.quantamagazine.org/20140812-the-musical-magical-number-theorist/")]#text(")")#linebreak()#text(" Martin Hairer (")#link("http://www.quantamagazine.org/20140812-in-mathematical-noise-one-who-heard-music/")[#text("http://www.quantamagazine.org/20140812-in-mathematical-noise-one-who-heard-music/")]#text(")")#linebreak()#text(" Maryam Mirzakhani (")#link("http://www.quantamagazine.org/20140812-a-tenacious-explorer-of-abstract-surfaces/")[#text("http://www.quantamagazine.org/20140812-a-tenacious-explorer-of-abstract-surfaces/")]#text(")")

#text("They detail what the winners accomplished aside from what Tao covered above in his post (leaving out of course the mathematical details – broad conceptual brushstrokes are unavoidable if you’re writing for a nontechnical audience), so they should be interesting. Make no mistake, the quality of these winners’ publications are of the highest order. That they happen to be of X nationality and Y gender seems to me almost incidental, and rather irrelevant to the prize committee’s decision to award them the Fields.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Why not Ben Green? Jacob Lurie (at least he got $3 mil)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405946")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")])]

#text("Giving Fields to Ben Green is like giving the second medal to Terry Tao. It is indeed slightly disappointing that Jacob Lurie has been passed over, since his insights and achievements certainly do not pale in the view of those of the current medalists.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Dear Terry, in your (nice!) description of Artur Ávila’s work, you use both ")#mi("\\theta")#text(" and ")#mi("\\omega")#text(" for the phase in the potential for the almost Mathieu operator, it seems. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405069")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("In dynamics of billiard balls on polygonal tables, Mirzakhani, Eskin, and Mohammadi apply their theorems to counting periodic billiard trajectories if the polygon is rational ; what part or parts of their hypotheses or theorems don’t go through for non-rational polygons?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("I’m not an expert on these things, but on looking through the relevant papers it appears that one needs the polygons to have angles commensurate with ")#mi("\\pi")#text(" in order to associate such a polygon to a “flat surface” – a Riemann surface with a holomorphic 1-form whose zeroes have some integer multiplicity. (It looks like this construction goes back to a ")#link("http://www.personal.psu.edu/axk29/pub/AK-Zemlyakov1974.pdf")[#text("1974 paper of Zemlyatov and Katok")]#text(", and seems to basically arise from “unfolding” the polygon under reflections.) If one tries the same construction when one does not have angles commensurate with ")#mi("\\pi")#text(", it looks like one gets some nasty space instead that is somewhat worse than an orbifold, and I don’t know to what extent the methods in these papers carry over to such a setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405114")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("One can think of the unfolding construction as adding a copy of the table for each of the directions that a billiard ball could be traveling after bouncing off some number of sides. In other words, you want a copy ")#mi("T_g")#text(" of the table for each element ")#mi("g")#text(" in the group ")#mi("G")#text(" generated by the linear parts (aka derivatives) of reflections through the sides of the table. You then glue side ")#mi("s")#text(" of ")#mi("T_g")#text(" to side ")#mi("s")#text(" of ")#mi("T_{gh}")#text(" if ")#mi("h\\in G")#text(" corresponds to reflection through side ")#mi("s")#text(". In this way one obtains a surface. The group ")#mi("G")#text(" is finite exactly when the angles are all rational multiplies of ")#mi("\\pi")#text(". So in these cases, the unfolding construction gives a nice compact surface. When ")#mi("G")#text(" is infinite, the surface will not be compact, which is harder to work with, and so the construction is much less useful. The rational angle condition is not really so natural if you’re interested in general billiards. There are, however, a few results for general tables that can be proved by approximating by rational tables, for which the unfolding construction is fruitful.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ca77ac7b66908460d97a063baf0e54b195c834b2959aa27df5cdf2281100a1a-508c60d0d5dcaef2c75254b23fa842073f004dc77eac2bb5e18269f081a740b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2014 Fields Medal and Nevanlinna Prize Winners Announced")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405103")[#strong[#text("2014 Fields Medal and Nevanlinna Prize Winners Announced")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("[…] Terry Tao (previous Fields Medal Winner): Avila, Bhargava, Hairer, Mirzakhani […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405125")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("The list of tags on this post made me notice the utterly meaningless coincidence that this year’s medalists’ names are in the same order whether you alphabetize by first names or by last names.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/910fc9e3c34f9da22bc81802a9f77361e629db396933b0eac18ba33eb3cbf32e-e64d190148faa2fd924927540682692db0349cb7a8a0206fdc914d1be1161f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405140")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("Nontrivial observation considering all the Ma*s.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Khot, Osher, Griffiths | What's new")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405178")[#strong[#text("Khot, Osher, Griffiths | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("[…] addition to the Fields medallists mentioned in the previous post, the IMU also awarded the Nevanlinna prize to Subhash Khot, the Gauss prize to Stan Osher (my […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1a454862b828d38f91fa20af79797f30d7b1cf1c79c282187831a734e0044c-93b3fb1b52ebafc1caf3989f29aa38b888f8b8063d34a60054ebd2cce1e4dff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405194")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("I forgot to mention that Artur Avila is also the first Fields Medalist to receive his doctorate outside of the U.S. or Europe. He was educated from beginning to end in his native Brazil. What a coup for Brazil’s IMPA.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405324")[#strong[#text("Gergely")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("There are counterexamples to what you say: Kodaira (Tokyo), Mori (Kyoto), Zelmanov (Novisibirsk), Lindenstrauss (Jerusalem).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a53c447048057bf268c9deace8e288f45312f64e5f8b18f44b7838e71bdc954-6583498d239d12da3a83e4f08c749075dd0b69254ef3850d9975357557748149.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405544")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")])]

#text("The guy was also a prodigy. He won an gold medal at the IMO and got his Phd. from the best pure and applied math institution in Brazil at 21.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405435")[#strong[#text("Fields Medals 2014 | physics4me")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2014")]

#text("[…] also: Avila, Bhargava, Hairer, Mirzakhani by Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405654")[#strong[#text("Terrance Tao discusses the Fields Medal winners. | BUMPS")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")]

#text("[…] addition to the Fields medallists mentioned in the previous post, the IMU also awarded the Nevanlinna prize to Subhash Khot, the Gauss prize to Stan Osher (my […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405792")[#strong[#text("Medallas Fields 2014, IMO 1995 y software para Mac | Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")]

#text("[…] de descubrir, en esta entrada de Tao, unos vídeos sobre los medallistas Fields del […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405819")[#strong[#text("Día importante para las Matemáticas: Maryam Mirzakhani (Irán) gana una Medalla Fields | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")]

#text("[…] leer a Terence Tao, “Avila, Bhargava, Hairer, Mirzakhani,” What’s New, 12 Aug 2014, y “Khot, Osher, Griffiths,” What’s New, 12 Aug 2014. Tim Gowers, “ICM2014 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-405951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2014")])]

#text("Bhargava’s 66% BSD contribution to our understanding of the BSD conjecture seems to be a red herring: Bhargava’s result does not prove BSD for a single elliptic curve for which it was not known already by much deeper work of other authors (Gross-Zagier, Kolyvagin, Wei Zhang)! Bhargava simply puts known results together under an appealingly-looking average statement, which in practice is of rather limited use.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e06c3561cb6e0a9762febc02fa0d01522dcce211d002e71410d390293704a4e8-77a5967811fde62c63b07534d30b595862b9527624594ece078c95a39e8b31f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cynicism")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-406181")[#strong[#text("Cynicism")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")])]

#text("This is ridiculous. Before Bhargava’s work we knew basically nothing about the average rank of elliptic curves unconditionally. If you want to say that Bhargava’s work doesn’t tell us much about BSD for any single elliptic curve then both he and I would probably agree with you. But to say there’s limited use for knowing the average behavior of difficult-to-know quantities is unthinkable for any mathematician or math enthusiast.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-406191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")])]

#text("I think you misunderstood my comment. I agree that the average rank information that he provides is very much of interest. The thing that I do not agree with is that this is any substantial progress towards BSD (the description of his work in the text calls the 66% aspect “one of the best results we have on BSD”). In particular, I think that the 66% aspect (which is Bhargava’s contribution) is of no practical use for BSD. Bhargava’s average rank work is surely substantial progress towards another problem in the arithmetic of elliptic curves (of completely different flavor), namely, the Katz-Sarnak 50-50 conjecture. But to me it doesn’t seem appropriate to use the 66% BSD as a selling point of Bhargava’s results, because the 66% is just repackaging of deeper results of others. Unfortunately, this was done even in the laudatio (although quite mildly).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-406673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2014")])]

#text("I admit I made a poor choice of words with “best result we have”; I was thinking in the technical sense used by analytic number theorists, in which “best” means “largest lower bound available” or “smallest upper bound available”, and not in the colloquial sense. (This problem of a scientific term being mistaken for a public meaning is ")#link("http://blogs.agu.org/mountainbeltway/2011/10/17/words-matter/")[#text("pervasive in science")]#text(", and I guess it caught me out too this time. I vaguely remember thinking while initially writing this post that I would use “one of the best” rather than “best” to indicate that I was only interpreting “best” in a narrow sense, but that clearly didn’t work out as intended.) I’ve reworded the post to remove this confusion (and also incorporated some other corrections sent to me by email).")

#text("(Added later) I agree that statistical results on BSD do not provide any obvious way forward to resolve the full BSD conjecture, but such statistical results may still be eventually useful in some analytic number theory applications as a partial substitute for the full BSD conjecture, in analogy to how the Bombieri-Vinogradov theorem (“GRH on the average”) is a useful substitute for actual GRH, or the density hypothesis (“RH is true for most zeroes of zeta”) is a useful substitute for actual RH. Presumably one needs to make further advances on the analytic rank side of BSD as well as the algebraic rank side of BSD to get to this point, though.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-406205")[#strong[#text("2014 Fields Medals | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")]

#text("[…] For two very different sorts of blog posts about the Fields Medal, see Terry Tao and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0eb3ef55e16a6591a23b640ed636bfbbcc87ad561a9626dfff42bbae2b2ad8-da325e57c74af2c7493e12cc25e6335feb9b4aa21b68c2a2a6e4dcf97cd16f4e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fields Medals 2014 | babis' blog")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-406355")[#strong[#text("Fields Medals 2014 | babis' blog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")])]

#text("[…] summarizes some of their scientific contributions. Terence Tao wrote a more technical article-post about this year’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-406514")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2014")])]

#text("Looking at some of the semi-popular-press stuff about the medalists’ work, Hairer seems to have done some new formalization of stochastic PDE that allowed mathematically rigorous treatment of stuff that previously was done only hand-wavingly by physicists. Can anyone describe what that was about and what difficulty was overcome? I thought this stuff went back to Wiener’s explanation of Brownian motion in the 1930’s. Is there a generally accessible introduction to the subject? It does sound interesting. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-407064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2014")])]

#text("The basic idea is that solutions to many physical SPDEs cannot have sufficient regularity to be classical, because the white noise which forces the system is not a function. If the SPDE is either linear or close to linear, this can be overcome by using some version of the theory of distributions or other classical techniques. Hairer’s work allows one to tackle SPDEs that are highly non-linear, such as the KPZ equation. One of the terms in this equation is the square of a gradient: since solutions typically only exist in the distributional sense it is not clear how one should make sense of this term. Hairer developed a framework called “Regularity structures” which one can think of as a generalization of Taylor approximations that allows one to prove well-posedness of equations of this type.")

#text("The most generally accessible introduction to this field (which is extremely new) currently available is probably this: ")#link("http://arxiv.org/pdf/1401.3014v2.pdf")[#text("http://arxiv.org/pdf/1401.3014v2.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/178150cf24703784861aeafc534155d8aeed3513faf8f3ef9f691a2d65a5d3ac-0a1127d1404348d2aa3ae3c1179db6f8836a6dcbf3e92365b792d4ca488b7919.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olivier")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-411831")[#strong[#text("Olivier")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2014")])]

#text("“and the theory of Gross-Zagier and Kolyvagin that this work relies on is not available for other number fields than {{\\bf Q}}”")

#text("In fact, it is valid over all totally real fields (albeit with complications).")

#emph[#text("[Thanks for the correction! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-412465")[#strong[#text("Maryam Mirzakhani and Dynamics on Moduli Space | A Hitchhiker's Guide to the Ivory Tower")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2014")]

#text("[…] by Terence Tao and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FIELDS MEDAL 2018")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-482651")[#strong[#text("FIELDS MEDAL 2018")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2017")])]

#text("Who do you think will win the Fields Medal in 2018? Vote here (choose four names): ")#link("https://poll.pollcode.com/44839318")[#text("https://poll.pollcode.com/44839318")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82135c727c688a6d4157faf95a03acd571d6c795504b282f984fea3d181293c7-067c906a985e2d64ac92c3cf8facdc536decdfb8f0cb6bd5fab6c59e5375f8c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FIELDS MEDAL 2018")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-483108")[#strong[#text("FIELDS MEDAL 2018")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2017")])]

#text("Besides Peter Scholze, who do you think will win the Fields Medal in 2018 (choose up to three names)? Vote here: ")#link("https://vote.pollcode.com/31229277")[#text("https://vote.pollcode.com/31229277")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FIELDS MEDAL 2018")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-483469")[#strong[#text("FIELDS MEDAL 2018")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("The final round of voting for the Fields Medal 2018: ")#link("https://vote.pollcode.com/73641394")[#text("https://vote.pollcode.com/73641394")]

#text("First round results: ")#link("https://poll.pollcode.com/44839318_result")[#text("https://poll.pollcode.com/44839318_result")]

#text("Second round results: ")#link("https://poll.pollcode.com/31229277_result")[#text("https://poll.pollcode.com/31229277_result")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maryam Mirzakhani | What's new")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-483779")[#strong[#text("Maryam Mirzakhani | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("[…] she won the Fields medal in 2014 (as I posted about previously on this blog), we corresponded for a while. The Fields medal is of course one of the highest honours one can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-483784")[#strong[#text("The unprecedented Best Seller! | My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] she won the Fields medal in 2014 (as I posted about previously on this blog), we corresponded for a while. The Fields medal is of course one of the highest honours one can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b2b28875c52616a95179ed6acf3b066b28cf5fe3cdfc656bd3779f1d5f448e6-756da77589c6db146ada5bb279405a435ef0bdfe95567c28b02a65cb8fdb9164.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jemas Kumar")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-483792")[#strong[#text("Jemas Kumar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")])]

#text("Reblogged this on ")#link("https://beginner007.wordpress.com/2017/07/15/avila-bhargava-hairer-mirzakhani/")[#text("Jemas Kumar")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-483986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2017")])]

#text("typo: In the last paragraph the word “with” should be removed from the sentence ending “…Benoist and Quint with as a substitute.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-484109")[#strong[#text("some published posts about Maryam Mirzakhani | Mathpresso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2017")]

#text("[…] she won the Fields medal in 2014 (as I posted about previously on this blog), we corresponded for a while. The Fields medal is of course one of the highest honours one can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-497778")[#strong[#text("some published posts about Maryam Mirzakhani – Pangan 7")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")]

#text("[…] she won the Fields medal in 2014 (as I posted about previously on this blog), we corresponded for a while. The Fields medal is of course one of the highest honours one can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Birkar, Figalli, Scholze, Venkatesh | What's new")]], [#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-503570")[#strong[#text("Birkar, Figalli, Scholze, Venkatesh | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("[…] the two previous congresses in 2010 and 2014, I wrote blog posts describing some of the work of each of the winners. This time, though, I happened to be a member […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/#comment-575097")[#strong[#text("Some published posts about Maryam Mirzakhani | Diranlou")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2020")]

#text("[…] she won the Fields medal in 2014 (as I posted about previously on this blog), we corresponded for a while. The Fields medal is of course one of the highest honours one can […]")
]
