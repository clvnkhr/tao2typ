// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/
// Converted to Typst by tao2typ: "2026-10-14T16:37:36.548341+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 5: The linear sieve and Chen’s theorem (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 5: The linear sieve and Chen’s theorem (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 January 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/")[#text("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We continue the discussion of sieve theory from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(", but now specialise to the case of the ")#emph[#text("linear sieve")]#text(" in which the sieve dimension ")#mi("{\\kappa}")#text(" is equal to ")#mi("{1}")#text(", which is one of the best understood sieving situations, and one of the rare cases in which the precise limits of the sieve method are known. A bit more specifically, let ")#mi("{z, D \\geq 1}")#text(" be quantities with ")#mi("{z = D^{1/s}}")#text(" for some fixed ")#mi("{s>1}")#text(", and let ")#mi("{g}")#text(" be a multiplicative function with ")#metadata(none) <tao-711430f6164e93803d93>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("g(p) = \\frac{1}{p} + O(\\frac{1}{p^2})")]]

#text("and ")#metadata(none) <tao-4d2f4b668cfc48e6059d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("0 \\leq g(p) \\leq 1-c")]]

#text("for all primes ")#mi("{p}")#text(" and some fixed ")#mi("{c>0}")#text(" (we allow all constants below to depend on ")#mi("{c}")#text("). Let ")#mi("{P(z) := \\prod_{p<z} p}")#text(", and for each prime ")#mi("{p < z}")#text(", let ")#mi("{E_p}")#text(" be a set of integers, with ")#mi("{E_d := \\bigcap_{p|d} E_p}")#text(" for ")#mi("{d|P(z)}")#text(". We consider finitely supported sequences ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" of non-negative reals for which we have bounds of the form ")#metadata(none) <tao-c2bc07610fb18d0eb3a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\in E_d} a_n = g(d) X + r_d.")]]

#text("for all square-free ")#mi("{d \\leq D}")#text(" and some ")#mi("{X>0}")#text(", and some remainder terms ")#mi("{r_d}")#text(". One is then interested in upper and lower bounds on the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n\\not \\in\\bigcup_{p <z} E_p} a_n.")]]

#text("The fundamental lemma of sieve theory (Corollary 19 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(") gives us the bound ")#metadata(none) <tao-af892a23b70d9bcf7d25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\sum_{n\\not \\in\\bigcup_{p <z} E_p} a_n = (1 + O(e^{-s})) X V(z) + O( \\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| )", block: true)]]

#text("where ")#mi("{V(z)}")#text(" is the quantity ")#metadata(none) <tao-4704a5ca34624537d035>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("V(z) := \\prod_{p<z} (1-g(p)).")]]

#text("This bound is strong when ")#mi("{s}")#text(" is large, but is not as useful for smaller values of ")#mi("{s}")#text(". We now give a sharp bound in this regime. We introduce the functions ")#mi("{F, f: (0,+\\infty) \\rightarrow {\\bf R}^+}")#text(" by ")#metadata(none) <tao-407eca442505ec8c70f4>

#tao-aligned(keep: true)[


#tao-math("F(s)  & := 2e^\\gamma ( \\frac{1_{s>1}}{s}", block: true, numbering: n => [#text("(6)")])



#tao-math(" & + \\sum_{j \\geq 3, \\text{ odd}} \\frac{1}{j!} \\int_{[1,+\\infty)^{j-1}} 1_{t_1+\\dots+t_{j-1}\\leq s-1} \\frac{dt_1 \\dots dt_{j-1}}{t_1 \\dots t_j} )", block: true)
]

#text("and ")#metadata(none) <tao-45dfab8555f501c25ea6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("f(s) := 2e^\\gamma \\sum_{j \\geq 2, \\text{ even}} \\frac{1}{j!} \\int_{[1,+\\infty)^{j-1}} 1_{t_1+\\dots+t_{j-1}\\leq s-1} \\frac{dt_1 \\dots dt_{j-1}}{t_1 \\dots t_j}")]]

#text("where we adopt the convention ")#mi("{t_j := s - t_1 - \\dots - t_{j-1}}")#text(". Note that for each ")#mi("{s}")#text(" one has only finitely many non-zero summands in ")#link(<tao-407eca442505ec8c70f4>)[#text("(6)")]#text(", ")#link(<tao-45dfab8555f501c25ea6>)[#text("(7)")]#text(". These functions are closely related to the Buchstab function ")#mi("{\\omega}")#text(" from Exercise 28 of Supplement 4; indeed from comparing the definitions one has")

#align(center)[#tao-fit-display[#mitex("F(s) + f(s) = 2 e^\\gamma \\omega(s)")]]

#text("for all ")#mi("{s>0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Alternate definition of ")#mi("{F, f}")#text(")")]#text(" ")#metadata(none) <tao-95c3204ad3a3ce06826f>#text(" Show that ")#mi("{F(s)}")#text(" is continuously differentiable except at ")#mi("{s=1}")#text(", and ")#mi("{f(s)}")#text(" is continuously differentiable except at ")#mi("{s=2}")#text(" where it is continuous, obeying the delay-differential equations ")#metadata(none) <tao-44f86611d4de6dafdf13>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{d}{ds}( s F(s) ) = f(s-1)")]]

#text("for ")#mi("{s > 1}")#text(" and ")#metadata(none) <tao-9845695daed1b729f6a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{d}{ds}( s f(s) ) = F(s-1)")]]

#text("for ")#mi("{s>2}")#text(", with the initial conditions")

#align(center)[#tao-fit-display[#mitex("F(s) = \\frac{2e^\\gamma}{s} 1_{s>1}")]]

#text("for ")#mi("{s \\leq 3}")#text(" and")

#align(center)[#tao-fit-display[#mitex("f(s) = 0")]]

#text("for ")#mi("{s \\leq 2}")#text(". Show that these properties of ")#mi("{F, f}")#text(" determine ")#mi("{F, f}")#text(" completely.")
]

#text("For future reference, we record the following explicit values of ")#mi("{F, f}")#text(": ")#metadata(none) <tao-371b7a3dc076cf3dbe34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("F(s) = \\frac{2e^\\gamma}{s}")]]

#text("for ")#mi("{1 < s \\leq 3}")#text(", and ")#metadata(none) <tao-08464fbf1e7812d1f137>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("f(s) = \\frac{2e^\\gamma}{s} \\log(s-1)")]]

#text("for ")#mi("{2 \\leq s \\leq 4}")#text(".")

#text("We will show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Linear sieve)")]#text(" ")#metadata(none) <tao-7f2fe580edb35154041f>#text(" Let the notation and hypotheses be as above, with ")#mi("{s > 1}")#text(". Then, for any ")#mi("{\\varepsilon > 0}")#text(", one has the upper bound ")#metadata(none) <tao-5e567455a23979b8d027>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{n\\not \\in\\bigcup_{p <z} E_p} a_n \\leq (F(s) + O(\\varepsilon)) X V(z) + O( \\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| )", block: true)]]

#text("and the lower bound ")#metadata(none) <tao-acac074bd95e75d6d32b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\sum_{n\\not \\in\\bigcup_{p <z} E_p} a_n \\geq (f(s) - O(\\varepsilon)) X V(z) + O( \\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| )", block: true)]]

#text("if ")#mi("{D}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon, s, c}")#text(". Furthermore, this claim is sharp in the sense that the quantity ")#mi("{F(s)}")#text(" cannot be replaced by any smaller quantity, and similarly ")#mi("{f(s)}")#text(" cannot be replaced by any larger quantity.")
]

#text("Comparing the linear sieve with the fundamental lemma (and also testing using the sequence ")#mi("{a_n = 1_{1 \\leq n \\leq N}}")#text(" for some extremely large ")#mi("{N}")#text("), we conclude that we necessarily have the asymptotics")

#align(center)[#tao-fit-display[#mitex("1 - O(e^{-s}) \\leq f(s) \\leq 1 \\leq F(s) \\leq 1 + O( e^{-s} )")]]

#text("for all ")#mi("{s \\geq 1}")#text("; this can also be proven directly from the definitions of ")#mi("{F, f}")#text(", or from Exercise ")#link(<tao-95c3204ad3a3ce06826f>)[#text("1")]#text(", but is somewhat challenging to do so; see e.g. Chapter 11 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(" for details.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Establish the integral identities")

#align(center)[#tao-fit-display[#mitex("F(s) = 1 + \\frac{1}{s} \\int_s^\\infty (1 - f(t-1))\\ dt")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f(s) = 1 + \\frac{1}{s} \\int_s^\\infty (1 - F(t-1))\\ dt")]]

#text("for ")#mi("{s \\geq 2}")#text(". Argue heuristically that these identities are consistent with the bounds in Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(" and the Buchstab identity (Equation (16) from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Use the Selberg sieve (Theorem 30 from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(") to obtain a slightly weaker version of ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(" in the range ")#mi("{1 < s < 3}")#text(" in which the error term ")#tao-math("{\\left|r_d\\right|}", block: false)#text(" is worsened to ")#tao-math("{\\tau_3(d) \\left|r_d\\right|}", block: false)#text(", but the main term is unchanged.")
]

#text("We will prove Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(" below the fold. The optimality of ")#mi("{F, f}")#text(" is closely related to the parity problem obstruction discussed in Section 5 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text("; a naive application of the parity arguments there only give the weak bounds ")#mi("{F(s) \\geq \\frac{2 e^\\gamma}{s}}")#text(" and ")#mi("{f(s)=0}")#text(" for ")#mi("{s \\leq 2}")#text(", but this can be sharpened by a more careful counting of various sums involving the Liouville function ")#mi("{\\lambda}")#text(".")

#text("As an application of the linear sieve (specialised to the ranges in ")#link(<tao-371b7a3dc076cf3dbe34>)[#text("(10)")]#text(", ")#link(<tao-08464fbf1e7812d1f137>)[#text("(11)")]#text("), we will establish a famous ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("theorem of Chen")]#text(", giving (in some sense) the closest approach to the twin prime conjecture that one can hope to achieve by sieve-theoretic methods:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Chen’s theorem)")]#text(" There are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is the product of at most two primes.")
]

#text("The same argument gives the version of Chen’s theorem for the even Goldbach conjecture, namely that for all sufficiently large even ")#mi("{N}")#text(", there exists a prime ")#mi("{p}")#text(" between ")#mi("{2}")#text(" and ")#mi("{N}")#text(" such that ")#mi("{N-p}")#text(" is the product of at most two primes.")

#text("The discussion in these notes loosely follows that of ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(" (who study sieving problems in more general dimension than ")#mi("{\\kappa=1}")#text(").")

#metadata(none) <tao-fe33e85a6d221e06f1e8>

#heading(level: 1)[#strong[#text(" — 1. Optimality — ")]]

#text("We first establish that the quantities ")#mi("{F(s), f(s)}")#text(" appearing in Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(" cannot be improved. We use the parity argument ")#link("http://www.ams.org/mathscinet-getitem?mr=53147")[#text("of Selberg")]#text(", based on weight sequences ")#mi("{a_n}")#text(" related to the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(".")

#text("We argue for the optimality of ")#mi("{F(s)}")#text("; the argument for ")#mi("{f(s)}")#text(" is similar and is left as an exercise. Suppose that there is ")#mi("{s \\geq 1}")#text(" for which the claim in Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(" is not optimal, thus there exists ")#mi("{\\delta>0}")#text(" such that ")#metadata(none) <tao-f572f1c90f8bbb1ef0ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{n\\not \\in\\bigcup_{p <z} E_p} a_n \\leq (F(s) - \\delta) X V(z) + O( \\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| )", block: true)]]

#text("for ")#mi("{z, D, g, E_p, a_n, X, V(z), r_d}")#text(" as in that theorem, with ")#mi("{z}")#text(" sufficiently large.")

#text("We will contradict this claim by specialising to a special case. Let ")#mi("{z}")#text(" be a large parameter going to infinity, and set ")#mi("{D := z^s}")#text(". We set ")#mi("{g(d) := 1/d}")#text(", then by Mertens’ theorem we have ")#mi("{V(z) = \\frac{e^{-\\gamma}+o(1)}{\\log z}}")#text(". We set ")#mi("{E_p}")#text(" to be the residue class ")#mi("{0\\ (p)}")#text(", thus ")#link(<tao-c2bc07610fb18d0eb3a7>)[#text("(3)")]#text(" becomes ")#metadata(none) <tao-02d5d0522a76608d64a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\sum_{n: d|n} a_n = g(d) X + r_d")]]

#text("and ")#link(<tao-f572f1c90f8bbb1ef0ac>)[#text("(14)")]#text(" becomes ")#metadata(none) <tao-4ecde249d747d51d869a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sum_{n: (n,P(z)) = 1} a_n \\leq \\frac{F(s) - \\delta + o(1)}{e^\\gamma} \\frac{X}{\\log z} + O( \\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| )", block: true)]]

#text("where ")#mi("{P(z) := \\prod_{p<z} p}")#text(".")

#text("Now let ")#mi("{\\varepsilon > 0}")#text(" be a small fixed quantity to be chosen later, set ")#mi("{X := D^{1+\\varepsilon}}")#text(", and let ")#mi("{a_n}")#text(" be the sequence")

#align(center)[#tao-fit-display[#mitex("a_n := (1 - \\lambda(n)) 1_{1 \\leq n \\leq X}.")]]

#text("This is clearly finitely supported and non-negative. For any ")#mi("{d}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: d|n} a_n = \\sum_{n \\leq X/d} 1 - \\lambda(d) \\sum_{n \\leq X/d} \\lambda(n)")]]

#text("from the multiplicativity of ")#mi("{\\lambda}")#text(". If ")#mi("{d \\leq D}")#text(", then ")#mi("{X/d \\geq D^\\varepsilon}")#text(", and then by the prime number theorem for the Liouville function (Exercise 41 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", combined with Exercise 18 from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x/d} \\lambda(n) \\ll_\\varepsilon \\frac{X}{d} \\log^{-10} D")]]

#text("(say), annd hence the remainder term ")#mi("{r_d}")#text(" in ")#link(<tao-02d5d0522a76608d64a5>)[#text("(15)")]#text(" is of size ")#metadata(none) <tao-9a07c3e252c1088eaa34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|r_d\\right| \\ll_\\varepsilon \\frac{X}{d} \\log^{-10} D.", block: true)]]

#text("As such, the error term ")#tao-math("{O( \\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| )}", block: false)#text(" in ")#link(<tao-4ecde249d747d51d869a>)[#text("(16)")]#text(" may be absorbed into the ")#mi("{o(1)}")#text(" term, and so ")#metadata(none) <tao-6690d4f8d99759c53874>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{n \\leq X: (n,P(z))=1} (1-\\lambda(n)) \\leq \\frac{F(s) - \\delta + o(1)}{e^\\gamma} \\frac{X}{\\log z}.")]]

#text("Now we count the left-hand side. Observe that ")#mi("{1-\\lambda(n)}")#text(" is supported on those numbers ")#mi("{n = p_1 \\dots p_r}")#text(" that are the product of an odd number of primes ")#mi("{p_1 \\geq \\dots \\geq p_r}")#text(" (possibly with repetition), in which case ")#mi("{1-\\lambda(n)=2}")#text(". To be coprime to ")#mi("{P(z)}")#text(", all these primes must be at least ")#mi("{z}")#text("; since we are restricting ")#mi("{n \\leq X = z^{(1+\\varepsilon)s}}")#text(", we thus must have ")#mi("{r \\leq (1+\\varepsilon) s}")#text(". The left-hand side of ")#link(<tao-6690d4f8d99759c53874>)[#text("(18)")]#text(" may thus be written as ")#metadata(none) <tao-492da4c5ee086ab4070b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("2 \\sum_{r \\leq (1+\\varepsilon) s, \\text{ odd}} \\sum_{p_1 \\geq \\dots \\geq p_r \\geq z: p_1 \\dots p_r \\leq X} 1.")]]

#text("This expression may be computed using the prime number theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-280f3568fa9691086e4f>#text(" Show that the expression ")#link(<tao-492da4c5ee086ab4070b>)[#text("(19)")]#text(" is equal to ")#mi("{\\frac{F( s(1+\\varepsilon))+o(1)}{e^\\gamma} \\frac{X}{\\log z}}")#text(".")
]

#text("Since ")#mi("{F}")#text(" is continuous for ")#mi("{s>1}")#text(", we obtain a contradiction if ")#mi("{\\varepsilon}")#text(" is sufficiently small.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Verify the optimality of ")#mi("{f(s)}")#text(" in Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(". (")#emph[#text("Hint:")]#text(" replace ")#mi("{1-\\lambda(n)}")#text(" by ")#mi("{1+\\lambda(n)}")#text(" in the above arguments.)")
]

#heading(level: 1)[#strong[#text(" — 2. The linear sieve — ")]]

#text("We now prove the forward direction of Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(". Again, we focus on the upper bound ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(", as the lower bound case is similar.")

#text("Fix ")#mi("{s>1}")#text(". Morally speaking, the most natural sieve to use here is the (upper bound) ")#emph[#text("beta sieve")]#text(" from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(", with the optimal value of ")#mi("{\\beta}")#text(", which for the linear sieve turns out to be ")#mi("{\\beta=2}")#text(". Recall that this sieve is defined as the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{E_d}")]]

#text("where ")#mi("{{\\mathcal D}_+}")#text(" is the set of divisors ")#mi("{d = p_1 \\dots p_m}")#text(" of ")#mi("{P(z)}")#text(" with ")#mi("{z > p_1 > \\dots > p_m}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_{r-1} p_r^3 \\leq D")]]

#text("for all odd ")#mi("{1 \\leq r \\leq m}")#text(". From Proposition 14 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(" this is indeed an upper bound sieve; indeed we have ")#metadata(none) <tao-9691cf90923cba9d50a5>

#tao-aligned(keep: true)[


#tao-math("\\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{E_d}(n)  & = 1_{n \\not \\in \\bigcup_{p < z} E_p}", block: true, numbering: n => [#text("(20)")])



#tao-math(" & + \\sum_{r \\text{ odd}} \\sum_{d \\in {\\mathcal E}_r} 1_{n \\in E_d} 1_{n \\not \\in \\bigcup_{p < p_*(d)} E_p}", block: true)
]

#text("where ")#mi("{{\\mathcal E}_r}")#text(" is the set of divisors ")#mi("{d = p_1 \\dots p_r}")#text(" of ")#mi("{P(z)}")#text(" with ")#mi("{z > p_1 > \\dots > p_r = p_*(d)}")#text(", such that ")#metadata(none) <tao-6a6f02676afa294c96c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("p_1 \\dots p_{r-1} p_r^3 > D")]]

#text("and ")#metadata(none) <tao-78f17de5dc9d58fb792f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("p_1 \\dots p_{r^{\\prime}-1} p_{r^{\\prime}}^3 \\leq D")]]

#text("for all odd ")#mi("{1 \\leq r^{\\prime} < r}")#text(". Now for the key heuristic point: if ")#mi("{n \\approx D}")#text(" lies in the support of ")#mi("{1-\\lambda}")#text(", then the sum in ")#link(<tao-9691cf90923cba9d50a5>)[#text("(20)")]#text(" mostly vanishes. Indeed, if ")#mi("{n \\leq D}")#text(" is such that ")#mi("{n \\in E_d}")#text(" and ")#mi("{n \\not \\in \\bigcup_{p < p_*(d)} E_p}")#text(" for some ")#mi("{d = p_1 \\dots p_r \\in {\\mathcal E}_r}")#text(" and odd ")#mi("{r}")#text(", then one has ")#mi("{n = p_1 \\dots p_r q}")#text(" for some ")#mi("{q}")#text(" that is not divisible by any prime less than ")#mi("{p_r}")#text(". On the other hand, from ")#link(<tao-6a6f02676afa294c96c7>)[#text("(21)")]#text(", ")#link(<tao-78f17de5dc9d58fb792f>)[#text("(22)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("q \\approx \\frac{D}{p_1 \\dots p_r} < p_r^2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("q \\approx \\frac{D}{p_1 \\dots p_r} \\geq 1")]]

#text("which (morally) implies from the sieve of Erathosthenes that ")#mi("{q}")#text(" is prime, thus ")#mi("{\\lambda(n) = (-1)^{r+1} = +1}")#text(" and so ")#mi("{n}")#text(" is not in the support of ")#mi("{1-\\lambda}")#text(". As such, we expect the upper bound sieve ")#mi("{ \\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{E_d}}")#text(" to be extremely efficient on the support of ")#mi("{1-\\lambda}")#text(", which when combined with the analysis of the previous section suggests that this sieve should produce the desired upper bound ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(".")

#text("One can indeed use this sieve to establish the required bound ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text("; see Chapter 11 of Friedlander-Iwaniec for details. However, for various technical reasons it will be convenient to modify this sieve slightly, by increasing the ")#mi("{\\beta}")#text(" parameter to be slightly greater than ")#mi("{2}")#text(", and also by using the fundamental lemma to perform a preliminary sifting on the small primes.")

#text("We turn to the details. To prove ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(" we may of course assume that ")#mi("{\\varepsilon>0}")#text(" is suitably small. It will be convenient to worsen the error ")#mi("{O(\\varepsilon)}")#text(" in ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(" a little to ")#mi("{O( \\varepsilon \\log \\frac{1}{\\varepsilon} )}")#text(", since one can of course remove the logarithm by reducing ")#mi("{\\varepsilon}")#text(" appropriately.")

#text("Set ")#mi("{D_0 := z^{\\varepsilon^2}}")#text(" and ")#mi("{z_0 := z^{\\varepsilon^3}}")#text(". By the fundamental lemma of sieve theory (Lemma 17 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text("), one can find combinatorial upper and lower bound sieve coefficients ")#mi("{(\\lambda^{\\pm,0}_d)_{d \\leq D_0}}")#text(" at sifting level ")#mi("{z_0}")#text(" supported on divisors of ")#mi("{P(z_0)}")#text(", such that ")#metadata(none) <tao-5fb6a47e368e12e5d8b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{d \\leq D_0: d|P(z_0)} \\lambda^{\\pm,0}_d g(d) = V( z_0 ) ( 1 + O( e^{-1/\\varepsilon} ) ).")]]

#text("Thus we have ")#mi("{\\lambda^{\\pm,0}_d \\in \\{-1,0,1\\}}")#text(" and ")#metadata(none) <tao-f5774877e0057713a809>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sum_{d \\leq D_0: d|P(z_0)} \\lambda^{-,0}_d 1_{E_d}(n) \\leq 1_{n \\not \\in \\bigcup_{p<z_0} E_p} \\leq \\sum_{d \\leq D_0: d|P(z_0)} \\lambda^{+,0}_d 1_{E_d}(n)")]]

#text("for all ")#mi("{n}")#text(".")

#text("We will use the upper bound sieve ")#mi("{\\sum_{d \\leq D_0:d|P(z_0)} \\lambda^{+,0}_d 1_{E_d}(n)}")#text(" as a preliminary sieve to remove the ")#mi("{E_p}")#text(" for ")#mi("{p<z_0}")#text("; the lower bound sieve ")#mi("{\\lambda^{-,0}_d}")#text(" plays only a minor supporting role, mainly to control the difference between the upper bound sieve ")#mi("{1_{n \\not \\in \\bigcup_{p<z_0} E_p}}")#text(".")

#text("Next, we set ")#mi("{P(z_0,z) := P(z)/P(z_0) = \\prod_{z_0 \\leq p < z} p}")#text(", and let ")#mi("{\\lambda^+_d}")#text(" be the upper bound beta sieve with parameter ")#mi("{\\beta = 2+\\varepsilon}")#text(" on the primes dividing ")#mi("{P(z_0,z)}")#text(" up to level of distribution ")#mi("{D / D_0^2}")#text(". In other words, ")#mi("{{\\mathcal D}_+}")#text(" consists of those divisors ")#mi("{d = p_1 \\dots p_r}")#text(" of ")#mi("{P(z_0,z)}")#text(" with ")#mi("{p_1 > \\dots > p_r}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("p_1 \\dots p_{m-1} p_m^{3+\\varepsilon} \\leq D / D_0^2")]]

#text("for all odd ")#mi("{1 \\leq m \\leq r}")#text("; in particular, ")#mi("{d \\leq D/D_0^2}")#text(" for all ")#mi("{d \\in {\\mathcal D}_+}")#text(". By Proposition 14 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(", this is indeed an upper bound sieve for the primes dividing ")#mi("{P(z_0,z)}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{E_d} \\geq 1_{n \\not \\in \\bigcup_{z_0 \\leq p < z} E_p}.")]]

#text("Multiplying this with the second inequality in ")#link(<tao-f5774877e0057713a809>)[#text("(24)")]#text(" (this is the method of ")#emph[#text("composition of sieves")]#text("), we obtain an upper bound sieve for the primes up to ")#mi("{z}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\sum_{d \\in {\\mathcal D}_+} \\lambda^{+,0}_{d_0} \\mu(d) 1_{E_{d_0d}}(n) \\geq 1_{n \\not \\in \\bigcup_{p < z} E_p}.")]]

#text("Multiplying this by ")#mi("{a_n}")#text(" and summing in ")#mi("{n}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\not \\in \\bigcup_{p<z} E_p} a_n \\leq \\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\sum_{d \\in {\\mathcal D}_+} \\lambda^{+,0}_{d_0} \\mu(d) \\sum_{n \\in E_{d_0 d}} a_n.")]]

#text("Note that each product ")#mi("{d_0 d}")#text(" appears at most once in the above sum, and all such products are squarefree and at most ")#mi("{D}")#text(". Applying ")#link(<tao-c2bc07610fb18d0eb3a7>)[#text("(3)")]#text(", we thus have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\not \\in \\bigcup_{p<z} E_p} a_n  & \\leq \\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\sum_{d \\in {\\mathcal D}_+} \\lambda^{+,0}_{d_0} \\mu(d) g(d_0) g(d) X", block: true)



#tao-math(" & + \\sum_{d \\leq D: \\mu^2(d)=1} |r_d|.", block: true)
]

#text("Thus to prove ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\sum_{d \\in {\\mathcal D}_+} \\lambda^{+,0}_{d_0} \\mu(d) g(d_0) g(d) = (F(s) + O(\\varepsilon\\log \\frac{1}{\\varepsilon})) V(z)")]]

#text("for ")#mi("{z}")#text(" sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Factoring out the ")#mi("{d_0}")#text(" summation using ")#link(<tao-5fb6a47e368e12e5d8b1>)[#text("(23)")]#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal D}_+} \\mu(d) g(d) = (F(s) + O(\\varepsilon\\log \\frac{1}{\\varepsilon})) V(z) / V(z_0).")]]

#text("Now we eliminate the role of ")#mi("{g}")#text(". From ")#link(<tao-711430f6164e93803d93>)[#text("(1)")]#text(", ")#link(<tao-4704a5ca34624537d035>)[#text("(5)")]#text(" and Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("V(z) / V(z_0) = (1 + O(\\varepsilon)) \\frac{\\log z_0}{\\log z}")]]

#text("for ")#mi("{z}")#text(" large enough. Also, if ")#mi("{d \\in {\\mathcal D}_+}")#text(", then ")#mi("{d \\leq D/D_0^2}")#text(" and all prime factors of ")#mi("{d}")#text(" are at least ")#mi("{z_0 = D^{\\varepsilon^3/s}}")#text(". Thus ")#mi("{d}")#text(" has at most ")#mi("{O_{s,\\varepsilon}(1)}")#text(" prime factors, each of which are at least ")#mi("{z_0}")#text(". From ")#link(<tao-711430f6164e93803d93>)[#text("(1)")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("g(d) = \\frac{1}{d} + O_{s,\\varepsilon}( \\frac{1}{z_0} \\frac{1}{d} ).")]]

#text("The contribution of the error term ")#mi("{O_{s,\\varepsilon}( \\frac{1}{z_0} \\frac{1}{d} )}")#text(" is then easily seen to be ")#mi("{O( \\varepsilon \\frac{\\log z_0}{\\log z} )}")#text(" for ")#mi("{z}")#text(" large enough, and so we reduce to showing that ")#metadata(none) <tao-970b1897af0abab6127d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{d \\in {\\mathcal D}_+} \\frac{\\mu(d)}{d} = (F(s) + O(\\varepsilon\\log \\frac{1}{\\varepsilon})) \\frac{\\log z_0}{\\log z}.")]]

#text("One can proceed here by evaluating the left-hand side directly. However, we will proceed instead by using the weight function ")#mi("{1-\\lambda}")#text(" from the previous section. More precisely, we will evaluate the expression ")#metadata(none) <tao-5c566addabaffd8f2e3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{n \\leq D} (1-\\lambda(n)) \\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\sum_{d \\in {\\mathcal D}_+} \\lambda^{+,0}_{d_0} \\mu(d) 1_{d_0d|n}")]]

#text("in two different ways, where ")#mi("{\\lambda^{+,0}_{d_0}}")#text(" is as before (but with the role of ")#mi("{g(d)}")#text(" now replaced by the function ")#mi("{1/d}")#text("). Firstly, since ")#mi("{d_0 d \\leq D/D_0}")#text(", we see from the argument used to establish ")#link(<tao-9a07c3e252c1088eaa34>)[#text("(17)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq D: d_0 d|n} 1-\\lambda(n) = \\frac{D}{d_0 d} + O( \\frac{D}{d_0 d} \\log^{-10} D )")]]

#text("(say). Since each ")#mi("{d_0 d}")#text(" appears at least once, we can thus write ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\sum_{d \\in {\\mathcal D}_+} \\lambda^{+,0}_{d_0} \\mu(d) \\frac{D}{d_0 d} + O( D \\log^{-9} D )")]]

#text("which upon factoring the ")#mi("{d_0}")#text(" sum using ")#link(<tao-5fb6a47e368e12e5d8b1>)[#text("(23)")]#text(" and Mertens’ theorem")

#align(center)[#tao-fit-display[#mitex("(1 + O(\\varepsilon)) \\frac{D}{e^\\gamma \\log z_0} \\sum_{d \\in {\\mathcal D}_+} \\frac{\\mu(d)}{d} + O( D \\log^{-9} D ).")]]

#text("Thus to verify ")#link(<tao-970b1897af0abab6127d>)[#text("(25)")]#text(", it will suffice to show that ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(26)")]#text(" is of the form")

#align(center)[#tao-fit-display[#mitex("(F(s) + O(\\varepsilon \\log \\frac{1}{\\varepsilon})) \\frac{D}{e^\\gamma \\log z}")]]

#text("for ")#mi("{z}")#text(" sufficiently large.")

#text("To do this, we abbreviate ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(26)")]#text(" as ")#metadata(none) <tao-736bc2d4e0945110e88f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sum_{n \\leq D} (1-\\lambda(n)) \\nu^{+,0}(n) \\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{d|n}")]]

#text("where ")#mi("{\\nu^{\\pm,0}}")#text(" are the sieves")

#align(center)[#tao-fit-display[#mitex("\\nu^{\\pm,0}(n) := \\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\lambda^{\\pm,0}_{d_0} 1_{d_0|n}.")]]

#text("By Proposition 14 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(", we can expand ")#mi("{\\sum_{d \\in {\\mathcal D}_+} \\mu(d) 1_{d|n}}")#text(" as ")#metadata(none) <tao-3b13bdde41d4aca7897b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("1_{(n,P(z_0,z))=1} + \\sum_{r \\text{ odd}} \\sum_{d \\in {\\mathcal E}_r} 1_{d|n} 1_{(n,P(z_0,p_*(d)))=1}")]]

#text("where for any ")#mi("{r \\geq 1}")#text(", ")#mi("{{\\mathcal E}_r}")#text(" is the collection of all divisors ")#mi("{d = p_1 \\dots p_r}")#text(" of ")#mi("{P(z_0,z)}")#text(" with ")#mi("{p_1 > \\dots > p_r = p_*(d)}")#text(" such that ")#metadata(none) <tao-1ebdebf404899ebd341a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("p_1 \\dots p_{r-1} p_r^{3+\\varepsilon} > D/D_0^2")]]

#text("but ")#metadata(none) <tao-796e80c7e5bf8a48cb60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("p_1 \\dots p_{r^{\\prime}-1} p_{r^{\\prime}}^{3+\\varepsilon} \\leq D/D_0^2")]]

#text("for all ")#mi("{1 \\leq r^{\\prime} < r}")#text(" with the same parity as ")#mi("{r}")#text(". For technical reasons, we will also impose the additional inequality ")#metadata(none) <tao-3ea6bc47a6277afef178>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("p_1 \\dots p_{r^{\\prime}-1} p_{r^{\\prime}}^{2+\\varepsilon} \\leq D/D_0^2")]]

#text("for all ")#mi("{1 \\leq r^{\\prime} < r}")#text(" with the opposite parity as ")#mi("{r}")#text("; this follows from ")#link(<tao-796e80c7e5bf8a48cb60>)[#text("(30)")]#text(" when ")#mi("{r^{\\prime} > 1}")#text(", but is an additional constraint when ")#mi("{r^{\\prime}=1}")#text(" and ")#mi("{r}")#text(" is even, but in the above identity ")#mi("{r}")#text(" is odd, so this additional constraint is harmless. For similar reasons we impose the inequality ")#metadata(none) <tao-50281f1fba4985733222>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("p_1 \\dots p_r^{1+\\varepsilon} \\leq D/D_0^2")]]

#text("which follows from ")#link(<tao-796e80c7e5bf8a48cb60>)[#text("(30)")]#text(" or ")#link(<tao-3ea6bc47a6277afef178>)[#text("(31)")]#text(" except when ")#mi("{r=1}")#text(", but then this inequality is automatic from our hypothesis ")#mi("{s>1}")#text(", which implies ")#mi("{z^{1+\\varepsilon} \\leq D/D_0^2}")#text(" if ")#mi("{\\varepsilon}")#text(" is chosen small enough.")

#text("Inserting the identity ")#link(<tao-3b13bdde41d4aca7897b>)[#text("(28)")]#text(", we can write ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("A + \\sum_{r \\text{ odd}} B_r")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("A :=\\sum_{n \\leq D} (1-\\lambda(n)) \\nu^{+,0}(n) 1_{(n,P(z_0,z))=1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B_r := \\sum_{d \\in {\\mathcal E}_r} \\sum_{n \\leq D} (1-\\lambda(n)) \\nu^{+,0}(n) 1_{d|n} 1_{(n,P(z_0,p_*(d))=1}.")]]

#text("We first estimate ")#mi("{A}")#text(". By")#link(<tao-f5774877e0057713a809>)[#text("(24)")]#text(", we can write ")#mi("{A}")#text(" as the sum of ")#metadata(none) <tao-c199c96fe76d78bc000e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\sum_{n \\leq D} (1-\\lambda(n)) 1_{(n,P(z))=1}")]]

#text("plus an error of size at most")

#align(center)[#tao-fit-display[#tao-math("O( \\left|\\sum_{n \\leq D} (\\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\lambda^{+,0}_{d_0} 1_{d_0|n} - \\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\lambda^{-,0}_{d_0} 1_{d_0|n} )\\right| )", block: true)]]

#text("(where we bound ")#mi("{(1-\\lambda(n)) 1_{(n,P(z_0,z))=1}}")#text(" by ")#mi("{O(1)}")#text("). The error may be rearranged as")

#align(center)[#tao-fit-display[#tao-math("O( \\left|\\sum_{d_0 \\leq D_0: d_0|P(z_0)} (\\lambda^{+,0}_{d_0} - \\lambda^{-,0}_{d_0}) (\\frac{D}{d_0}+O(1))\\right| ),", block: true)]]

#text("which by ")#link(<tao-5fb6a47e368e12e5d8b1>)[#text("(23)")]#text(" is of size ")#mi("{O( e^{-1/\\varepsilon} \\frac{D}{\\log z_0} ) = O( \\varepsilon \\frac{D}{\\log z} )}")#text(" for ")#mi("{\\varepsilon}")#text(" small enough. As for the main term ")#link(<tao-c199c96fe76d78bc000e>)[#text("(33)")]#text(", we see from Exercise ")#link(<tao-280f3568fa9691086e4f>)[#text("6")]#text(" (and the arguments preceding that exercise) that this term is equal to ")#mi("{\\frac{F(s)+O(\\varepsilon)}{e^\\gamma} \\frac{D}{\\log z}}")#text(" for ")#mi("{z}")#text(" sufficiently large. Thus, to obtain the desired approximation for ")#link(<tao-5c566addabaffd8f2e3a>)[#text("(26)")]#text(", it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{r \\text{ odd}} B_r \\ll \\varepsilon \\log \\frac{1}{\\varepsilon} \\frac{D}{\\log z}.")]]

#text("Next, we establish an exponential decay estimate on the ")#mi("{B_r}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" For ")#mi("{z}")#text(" sufficiently large depending on ")#mi("{\\varepsilon}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("B_r \\ll \\varepsilon^{-O(1)} \\alpha^r e^{-s} \\frac{D}{\\log z}")]]

#text("for all ")#mi("{r \\geq 1}")#text(" and some absolute constant ")#mi("{0 < \\alpha < 1}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) Note that if ")#mi("{d = p_1 \\dots p_r}")#text(" is in ")#mi("{{\\mathcal E}_r}")#text(", then ")#mi("{d \\leq D/D_0^2}")#text(" and all prime factors are at least ")#mi("{z_0 = D^{\\varepsilon^3}}")#text(", thus we may assume without loss of generality that ")#mi("{r \\leq 1/\\varepsilon^3}")#text(".")

#text("We bound")

#align(center)[#tao-fit-display[#mitex("B_r \\ll \\sum_{d \\in {\\mathcal E}_r} \\sum_{n \\leq D/d} \\nu^{+,0}(n) 1_{(n,P(z_0,p_*(d)))=1}.")]]

#text("Note that if ")#mi("{d = p_1 \\dots p_r}")#text(" lies in ")#mi("{{\\mathcal E}_r}")#text(", then")

#align(center)[#tao-fit-display[#mitex("D_0^2 p_r^\\varepsilon \\leq \\frac{D}{d} < D_0^2 p_r^{2+\\varepsilon}")]]

#text("thanks to ")#link(<tao-1ebdebf404899ebd341a>)[#text("(29)")]#text(", ")#link(<tao-50281f1fba4985733222>)[#text("(32)")]#text(". From this and the fundamental lemma of sieve theory we see (Exercise!) that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq D/d} \\nu^{+,0}(n) 1_{(n,P(z_0,p_r))=1} \\ll \\varepsilon^{-O(1)} \\frac{D}{d \\log p_*(d)}")]]

#text("and so it will suffice to show that ")#metadata(none) <tao-9834876dcfb05cb167a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\sum_{d \\in {\\mathcal E}_r} \\frac{1}{d} \\frac{\\log z}{\\log p_*(d)} \\ll \\alpha^r e^{-s}.")]]

#text("By the prime number theorem, the left-hand side is bounded (Exercise!) by ")#mi("{f_r(s-2\\varepsilon^2) + o(1)}")#text(" as ")#mi("{z \\rightarrow \\infty}")#text(", where")

#align(center)[#tao-fit-display[#mitex("f_r(s) := \\int_{J_r(s)} \\frac{dt_1 \\dots dt_r}{t_1 \\dots t_{r-1} t_r^2}")]]

#text("and ")#mi("{J_r(s) \\subset (0,+\\infty)^r}")#text(" is the set of points ")#mi("{(t_1,\\dots,t_r)}")#text(" with ")#mi("{1 \\geq t_1 \\geq \\dots \\geq t_r > 0}")#text(",")

#align(center)[#tao-fit-display[#mitex("t_1 + \\dots + t_{r-1} + (3+\\varepsilon) t_r \\geq s,")]]

#text("and such that")

#align(center)[#tao-fit-display[#mitex("t_1 + \\dots + t_{r^{\\prime}-1} + (3+\\varepsilon)t_{r^{\\prime}} \\leq s")]]

#text("for all ")#mi("{1 \\leq r^{\\prime} < r}")#text(" with the same parity as ")#mi("{r}")#text(", and")

#align(center)[#tao-fit-display[#mitex("t_1 + \\dots + t_{r^{\\prime}-1} + (2+\\varepsilon)t_{r^{\\prime}} \\leq s")]]

#text("for all ")#mi("{1 \\leq r^{\\prime} \\leq r}")#text(". It thus suffices to prove the bound ")#metadata(none) <tao-3388452318b2e7225fe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("f_r(s) \\leq C \\alpha^r e^{-s}")]]

#text("for all ")#mi("{s>1}")#text(" and some absolute constant ")#mi("{C>0}")#text(".")

#text("We use an argument from the ")#link("http://www.ams.org/mathscinet-getitem?mr=2331072")[#text("book of Harman")]#text(". Observe that ")#mi("{f_r(s)}")#text(" vanishes for ")#mi("{s > r+2}")#text(", which makes the claim ")#link(<tao-3388452318b2e7225fe9>)[#text("(35)")]#text(" routine for ")#mi("{r=1}")#text(" (Exercise!) for ")#mi("{C}")#text(" sufficiently large. We will now inductively prove ")#link(<tao-3388452318b2e7225fe9>)[#text("(35)")]#text(" for all odd ")#mi("{r}")#text(". From the change of variables ")#mi("{u = \\frac{s}{t_1}}")#text(", we obtain the identity ")#metadata(none) <tao-28a5e8d55f7e2cc5ba5d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("f_r(s) = \\frac{1}{s} \\int_{\\max(s, b_r)}^\\infty f_{r-1}(t-1)\\ dt")]]

#text("where ")#mi("{b_r := 3+\\varepsilon}")#text(" when ")#mi("{r}")#text(" is odd and ")#mi("{b_r := 2+\\varepsilon}")#text(" when ")#mi("{r}")#text(" is even (Exercise!). In particular, if ")#mi("{r \\geq 3}")#text(" is odd and ")#link(<tao-3388452318b2e7225fe9>)[#text("(35)")]#text(" was already proven for ")#mi("{r-2}")#text(", then")

#tao-aligned(keep: true)[


#tao-math("f_r(s)  & = \\frac{1}{s} \\int_{\\max(s,3+\\varepsilon)}^\\infty \\frac{1}{t-1} \\int_{t-1}^\\infty f_{r-2}(u-1)\\ du dt", block: true)



#tao-math(" & \\leq \\frac{1}{s} \\int_{\\max(s,3+\\varepsilon)}^\\infty \\frac{1}{t-1} \\int_{t-1}^\\infty C \\alpha^{r-2} e^{1-u}\\ du dt", block: true)



#tao-math(" & \\leq C \\alpha^{r} e^{-s} \\times \\alpha^{-2} \\times \\frac{e^{s+2}}{s} \\int_{\\max(s,3+\\varepsilon)}^\\infty \\frac{e^{-t}}{t-1}\\ dt.", block: true)
]

#text("One can check (Exercise!) that the quantity ")#mi("{\\frac{e^{s+2}}{s} \\int_{\\max(s,3+\\varepsilon)}^\\infty \\frac{e^{-t}}{t-1}\\ dt}")#text(" is maximised at ")#mi("{s=3+\\varepsilon}")#text(", where its value is less than ")#mi("{1}")#text(" (in fact it is ")#mi("{0.94\\dots}")#text(") if ")#mi("{\\varepsilon}")#text(" is small enough. As such, we obtain ")#link(<tao-3388452318b2e7225fe9>)[#text("(35)")]#text(" if ")#mi("{\\alpha}")#text(" is sufficiently close to ")#mi("{1}")#text(".")

#text("Finally, ")#link(<tao-3388452318b2e7225fe9>)[#text("(35)")]#text(" for even ")#mi("{r}")#text(" follows from the odd ")#mi("{r}")#text(" case (with a slightly larger choice of ")#mi("{C}")#text(") by one final application of ")#link(<tao-28a5e8d55f7e2cc5ba5d>)[#text("(36)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Fill in the steps marked (Exercise!) in the above proof.")
]

#text("In view of this lemma, the total contribution of ")#mi("{B_r}")#text(" with ")#mi("{r > C \\log \\frac{1}{\\varepsilon}}")#text(" for some sufficiently large ")#mi("{C}")#text(" is acceptable. Thus it suffices to show that")

#align(center)[#tao-fit-display[#mitex("B_r \\ll \\varepsilon \\frac{D}{\\log z}")]]

#text("whenever ")#mi("{r = O( \\log\\frac{1}{\\varepsilon} )}")#text(" is odd.")

#text("By ")#link(<tao-f5774877e0057713a809>)[#text("(24)")]#text(", we can write ")#mi("{B_r}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal E}_r} \\sum_{n \\leq D} (1-\\lambda(n)) 1_{d|n} 1_{(n,P(p_*(d)))=1}")]]

#text("plus an error of size")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{d \\in {\\mathcal E}_r} \\sum_{n \\leq D} (\\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\lambda^{+,0}_{d_0} 1_{dd_0|n} - \\sum_{d_0 \\leq D_0: d_0|P(z_0)} \\lambda^{-,0}_{d_0} 1_{dd_0|n} ) ).")]]

#text("Arguing as in the treatment of the ")#mi("{A}")#text(" term, we see from ")#link(<tao-5fb6a47e368e12e5d8b1>)[#text("(23)")]#text(" that the error term is bounded by")

#tao-aligned(keep: true)[


#tao-math(" & \\ll O( \\sum_{d \\in {\\mathcal E}_r} \\sum_{d_0 \\leq D_0: d_0|P(z_0)} (\\lambda^{+,0}_{d_0} - \\lambda^{-,0}_{d_0}) \\frac{D}{dd_0} ) + \\sum_{d \\in {\\mathcal E}_r} \\sum_{d_0 \\leq D_0: d_0|P(z_0)} 1", block: true)



#tao-math(" & \\ll \\sum_{d \\in {\\mathcal E}_r} e^{-1/\\varepsilon} \\frac{D}{d \\log z_0} + \\frac{D}{D_0^2} D_0", block: true)



#tao-math(" & \\ll e^{-1/\\varepsilon} \\frac{D}{\\log z_0} (\\sum_{z_0 \\leq p \\leq z} \\frac{1}{p})^r + \\frac{D}{D_0}", block: true)



#tao-math(" & \\ll e^{-1/\\varepsilon} \\frac{D}{\\log z_0} O( \\log \\frac{\\log z}{\\log z_0} )^r + \\frac{D}{D_0}", block: true)



#tao-math(" & \\ll \\varepsilon \\frac{D}{\\log z}", block: true)
]

#text("as desired for ")#mi("{z}")#text(" large enough, since ")#mi("{r = O(\\log \\frac{1}{\\varepsilon})}")#text(" and ")#mi("{\\frac{\\log z}{\\log z_0} = O( \\varepsilon^{-3} )}")#text(". Thus it suffices to show that ")#metadata(none) <tao-5d9c970dcd517291d13e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\sum_{d \\in {\\mathcal E}_r} \\sum_{n \\leq D} (1-\\lambda(n)) 1_{d|n} 1_{(n,P(p_*(d)))=1} \\ll \\varepsilon \\frac{D}{\\log z}.")]]

#text("If ")#mi("{d = p_1 \\dots p_r}")#text(" and ")#mi("{n}")#text(" appear in the above sum, then we have ")#mi("{n = p_1 \\dots p_r q}")#text(" where ")#mi("{q \\leq \\frac{D}{d}}")#text(" has no prime factor less than ")#mi("{p_r}")#text(", has an even number of prime factors, and obeys the bounds")

#align(center)[#tao-fit-display[#mitex("q \\leq D_0^2 p_r^{2+\\varepsilon}")]]

#text("thanks to ")#link(<tao-1ebdebf404899ebd341a>)[#text("(29)")]#text(". Note that ")#link(<tao-1ebdebf404899ebd341a>)[#text("(29)")]#text(" also gives ")#mi("{p_r \\geq (D/D_0^2)^{1/(r+2)}}")#text(", and thus (since ")#mi("{r = O( \\log \\frac{1}{\\varepsilon} )}")#text(" and ")#mi("{D_0 = z^{\\varepsilon^3}}")#text(") we see that ")#mi("{q < p_r^3}")#text(" if ")#mi("{\\varepsilon}")#text(" is small enough and ")#mi("{z}")#text(" is large enough. This forces ")#mi("{q}")#text(" to either equal ")#mi("{1}")#text(", or be the product of two primes between ")#mi("{p_r}")#text(" and ")#mi("{D_0^2 p_r^{1+\\varepsilon}}")#text(". The contribution of the ")#mi("{q=1}")#text(" case is bounded by ")#tao-math("{\\left|{\\mathcal E}_r\\right| \\leq D/D_0^2}", block: false)#text(", which is acceptable. As for the contribution of those ")#mi("{q}")#text(" that are the product of two primes, the prime number theorem shows that there are at most")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_r \\leq p \\leq D_0^2 p_r^{1+\\varepsilon}} O( \\frac{D}{d p \\log p_r} ) = O( \\varepsilon \\frac{D}{d \\log p_r} )")]]

#text("values of ")#mi("{q}")#text(" that can contribute to the sum, and so this contribution to ")#mi("{B_r}")#text(" is at most")

#align(center)[#tao-fit-display[#mitex("O( \\varepsilon \\frac{D}{\\log z} \\sum_{d \\in {\\mathcal E}_r} \\frac{1}{d} \\frac{\\log z}{\\log p_*(d)} ),")]]

#text("but by ")#link(<tao-9834876dcfb05cb167a5>)[#text("(34)")]#text(" the sum here is ")#mi("{O(1)}")#text(" for ")#mi("{z}")#text(" large enough, and the claim follows. This completes the proof of ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Establish the lower bound ")#link(<tao-acac074bd95e75d6d32b>)[#text("(13)")]#text(" in Theorem ")#link(<tao-7f2fe580edb35154041f>)[#text("2")]#text(". (Note that one can assume without loss of generality that ")#mi("{s>2}")#text(", which will now be needed to ensure ")#link(<tao-3ea6bc47a6277afef178>)[#text("(31)")]#text(" when ")#mi("{r^{\\prime}=1}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 3. Chen’s theorem — ")]]

#text("We now prove Chen’s theorem for twin primes, loosely following the treatment in Chapter 25 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(". We will in fact show the slightly stronger statement that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x/2 \\leq n \\leq x-2} \\Lambda(n) 1_{{\\mathcal P}_2}(n+2) 1_{(n+2,P(z))=1} \\gg \\frac{x}{\\log x}")]]

#text("for sufficiently large ")#mi("{x}")#text(", where ")#mi("{{\\mathcal P}_2}")#text(" is the set of all numbers that are products of at most two primes, and ")#mi("{z := x^{1/8}}")#text(". Indeed, after removing the (negligible) contribution of those ")#mi("{n}")#text(" that are powers of primes, this estimate would imply that there are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is the product of at most two primes, each of which is at least ")#mi("{p^{1/8}}")#text(".")

#text("Chen’s argument begins with the following simple lower bound sieve for ")#mi("{1_{{\\mathcal P}_2}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" If ")#mi("{x^{2/3} < n \\leq x}")#text(", then")

#align(center)[#tao-fit-display[#mitex("1_{{\\mathcal P}_2}(n) \\geq 1 - \\frac{1}{2} \\sum_{p \\leq x^{1/3}} 1_{p|n} - \\frac{1}{2} \\sum_{p_1 \\leq x^{1/3} < p_2 \\leq p_3} 1_{n=p_1p_2p_3} - \\frac{1}{2} \\sum_{p \\leq x^{1/3}} 1_{p^2|n}.")]]
]

#emph[#text("Proof:")]#text(" If ")#mi("{n}")#text(" has no prime factors less than or equal to ")#mi("{x^{1/3}}")#text(", then ")#mi("{n \\in {\\mathcal P}_2}")#text(" and the claim follows. If ")#mi("{n}")#text(" has two or more factors less than or equal to ")#mi("{x^{1/3}}")#text(", then ")#mi("{1 - \\frac{1}{2} \\sum_{p \\leq x^{1/3}} 1_{p|n} \\leq 0}")#text(" and the claim follows. Finally, if ")#mi("{n}")#text(" has exactly one factor less than or equal to ")#mi("{x^{1/3}}")#text(", then (as ")#mi("{n > x^{2/3}}")#text(") it must be of the form ")#mi("{n=p_1p_2p_3}")#text(" for some ")#mi("{p_1 \\leq x^{1/3} < p_2 \\leq p_3}")#text(", or it is divisible by ")#mi("{p^2}")#text(" for some ")#mi("{p \\leq x^{1/3}}")#text(", and the claim again follows. ")#mi("\\Box")

#text("In view of this sieve (trivially managing the contribution of ")#mi("{n \\leq x^{2/3}}")#text(" or of the case where ")#mi("{p^2|n}")#text(", and using the restriction of ")#mi("{n+2}")#text(" to be coprime to ")#mi("{P(z)}")#text("), it suffices to show that ")#metadata(none) <tao-525eca1d5089dbdcbb67>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("A_1 - \\frac{1}{2} \\sum_{z \\leq p \\leq x^{1/3}} A_{2,p} - \\frac{1}{2} A_3 \\gg \\frac{x}{\\log x}")]]

#text("for sufficiently large ")#mi("{x}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("A_1  & := \\sum_{x/2 \\leq n \\leq x-2} \\Lambda(n) 1_{(n+2,P(z))=1},", block: true)



#tao-math("A_{2,p}  & := \\sum_{x/2 \\leq n \\leq x-2: p|n+2} \\Lambda(n) 1_{(n+2,P(z))=1},", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("A_3 := \\sum_{x/2 \\leq n \\leq x-2} \\Lambda(n) \\sum_{z \\leq p_1 \\leq x^{1/3} < p_2 \\leq p_3} 1_{n+2=p_1p_2p_3}.")]]

#text("We thus seek sufficiently good lower bounds on ")#mi("{A_1}")#text(" and sufficiently good upper bounds on ")#mi("{A_{2,p}}")#text(" and ")#mi("{A_3}")#text(". As it turns out, the linear sieve, combined with the Bombieri-Vinogradov theorem, will give bounds on ")#mi("{A_1, A_{2,p}, A_3}")#text(" with numerical constants that are sufficient for this purpose.")

#text("We begin with ")#mi("{A_1}")#text(". We use the lower bound linear sieve, with ")#mi("{E_p}")#text(" equal to the residue class ")#mi("{-2\\ (p)}")#text(" for all ")#mi("{p < z}")#text(", so that ")#mi("{E_d}")#text(" is the residue class ")#mi("{-2\\ (d)}")#text(". We approximate")

#align(center)[#tao-fit-display[#mitex("\\sum_{x/2 \\leq n \\leq x-2: n \\in E_d} \\Lambda(n) = g(d) \\frac{x}{2} + r_d")]]

#text("where ")#mi("{g}")#text(" is the multiplicative function with ")#mi("{g(2) :=0}")#text(" and ")#mi("{g(p) := \\frac{1}{p-1}}")#text(" for ")#mi("{p>2}")#text(". From the Bombieri-Vinogradov theorem (Theorem 17 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(") we have ")#metadata(none) <tao-a789758dd8557bd22c16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("\\sum_{d \\leq D} \\left|r_d\\right| \\ll x \\log^{-10} x", block: true)]]

#text("(say) if ")#mi("{D := x^{1/2 - \\varepsilon} = z^{4-8\\varepsilon}}")#text(" for some small fixed ")#mi("{\\varepsilon > 0}")#text(". Applying the lower bound linear sieve ")#link(<tao-acac074bd95e75d6d32b>)[#text("(13)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("A_1 \\geq (f(4-8\\varepsilon) - O(\\varepsilon)) \\frac{x}{2} V(z) + O( x \\log^{-10} x )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("V(z) = \\prod_{p < z} (1-g(p)).")]]

#text("We can compute an asymptotic for ")#mi("{V}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-9685c81b76accc506949>#text(" Show that")

#align(center)[#tao-fit-display[#mitex("V(z) = (2 \\Pi_2 + o(1)) \\frac{1}{e^\\gamma \\log z}")]]

#text("as ")#mi("{z \\rightarrow \\infty}")#text(", where ")#mi("{\\Pi_2 = \\prod_{p>2} (1-\\frac{1}{(p-1)^2})}")#text(" is the twin prime constant.")
]

#text("From ")#link(<tao-08464fbf1e7812d1f137>)[#text("(11)")]#text(" we have ")#mi("{f(4) = \\frac{e^\\gamma}{2} \\log 3}")#text(". Sending ")#mi("{\\varepsilon}")#text(" slowly to zero, we conclude that ")#metadata(none) <tao-f55ff16f66f43360266b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("A_1 \\geq (\\log 3-o(1)) \\Pi_2 \\frac{x}{2\\log z}.")]]

#text("Now we turn to ")#mi("{A_{2,p}}")#text(". Here we use the upper bound linear sieve. Let ")#mi("{E_d}")#text(" be as before. For any ")#mi("{d}")#text(" dividing ")#mi("{P(z)}")#text(" and ")#mi("{z \\leq p < x^{1/3}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x/2 \\leq n \\leq x-2: n \\in E_d} \\Lambda(n) 1_{p|n+2} = g(d) g(p) \\frac{x}{2} + r_{pd}")]]

#text("where ")#mi("{g}")#text(" and ")#mi("{r_d}")#text(" are as previously. We apply the upper bound linear sieve ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(" with level of distribution ")#mi("{D/p}")#text(", to conclude that")

#tao-aligned(keep: true)[


#tao-math("A_{2,p}  & \\leq (F( \\frac{\\log D/p}{\\log z} ) + O(\\varepsilon)) g(p) \\frac{x}{2} V(z)", block: true)



#tao-math(" & + O( \\sum_{d \\leq D/p} \\left|r_{pd}\\right| ).", block: true)
]

#text("We sum over ")#mi("{p}")#text(". Since ")#mi("{pd}")#text(" is at most ")#mi("{D}")#text(", and each number less than or equal to ")#mi("{D}")#text(" has at most ")#mi("{O( \\log x )}")#text(" prime factors, we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{z \\leq p < x^{1/3}} A_{2,p}  & \\leq \\sum_{z \\leq p< x^{1/3}} (F( \\frac{\\log D/p}{\\log z} )", block: true)



#tao-math(" & + O(\\varepsilon)) g(p) \\frac{x}{2} V(z) + O( \\log x \\sum_{d \\leq D} \\left|r_d\\right| ).", block: true)
]

#text("The error term is ")#mi("{O( x \\log^{-9} x )}")#text(" thanks to ")#link(<tao-a789758dd8557bd22c16>)[#text("(39)")]#text(". Since ")#mi("{g(p) = \\frac{1+o(1)}{p}}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{z \\leq p < x^{1/3}} A_{2,p} \\leq (\\sum_{z \\leq p< x^{1/3}} \\frac{F( \\frac{\\log D/p}{\\log z} )}{p} + O(\\varepsilon)) \\frac{\\Pi_2 x}{e^\\gamma \\log z}")]]

#text("for sufficiently large ")#mi("{x}")#text(", thanks to Exercise ")#link(<tao-9685c81b76accc506949>)[#text("12")]#text(". We can compute the sum using Exercise 37 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", to obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{z \\leq p< x^{1/3}} \\frac{F( \\frac{\\log D/p}{\\log z} )}{p} = \\int_1^{8/3} F( 4-8\\varepsilon-t ) \\frac{dt}{t} + o(1),")]]

#text("which by ")#link(<tao-371b7a3dc076cf3dbe34>)[#text("(10)")]#text(" and sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" slowly gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{z \\leq p < x^{1/3}} A_{2,p} \\leq (\\int_1^{8/3} \\frac{1}{4-t} \\frac{dt}{t} + o(1)) \\frac{2 \\Pi_2 x}{\\log z}.")]]

#text("A routine computation shows that")

#align(center)[#tao-fit-display[#mitex("\\int_1^{8/3} \\frac{1}{4-t} \\frac{dt}{t} = \\frac{\\log 6}{4}")]]

#text("and so ")#metadata(none) <tao-2c3a4249d77070058649>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\sum_{z \\leq p < x^{1/3}} A_{2,p} \\leq (\\log 6+o(1)) \\Pi_2 \\frac{x}{2\\log z}.")]]

#text("Finally, we consider ")#mi("{A_3}")#text(", which is estimated by “switching” the sieve to sift out small divisors of ")#mi("{n}")#text(", rather than small divisors of ")#mi("{n+2}")#text(". Removing those ")#mi("{n}")#text(" with ")#mi("{n \\leq \\sqrt{x}}")#text(", as well as those ")#mi("{n}")#text(" that are powers of primes, and then shifting ")#mi("{n}")#text(" by ")#mi("{2}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("A_3 \\leq \\log x \\sum_{n} 1_{(n-2,P(\\sqrt{x}))=1} a_n + O_\\varepsilon( x^{1/2+\\varepsilon} )")]]

#text("where ")#mi("{a_n}")#text(" is the finitely supported non-negative sequence ")#metadata(none) <tao-e5e0b754700cd0f3e278>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("a_n := 1_{x/2+2 \\leq n \\leq x} \\sum_{z \\leq p_1 \\leq x^{1/3} < p_2 \\leq p_3} 1_{n=p_1p_2p_3}.")]]

#text("Here we are sifting out the residue classes ")#mi("{E^{\\prime}_p := 2\\ (p)}")#text(", so that ")#mi("{E^{\\prime}_d := 2\\ (d)}")#text(".")

#text("The sequence ")#mi("{a_n}")#text(" has good distribution up to level ")#mi("{D}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]#text(" One has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E^{\\prime}_d} a_n = g(d) \\sum_n a_n + r_d")]]

#text("where ")#mi("{g(d)}")#text(" is as before, and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d\\right| \\ll x \\log^{-10} x", block: true)]]

#text("(say), with ")#mi("{D}")#text(" as before.")
]

#emph[#text("Proof:")]#text(" Observe that the quantity ")#mi("{p_3}")#text(" in ")#link(<tao-e5e0b754700cd0f3e278>)[#text("(42)")]#text(" is bounded above by ")#mi("{x^{2/3}}")#text(" if the summand is to be non-zero. We now use a finer-than-dyadic decomposition trick similar to that used in the proof of the Bombieri-Vinogradov theorem in ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(" to approximate ")#mi("{a_n}")#text(" as a combination of Dirichlet convolutions. Namely, we set ")#mi("{\\lambda := 1 + \\log^{-20} x}")#text(", and partition ")#mi("{[x^{1/3},x^{2/3}]}")#text(" (plus possibly a little portion to the right of ")#mi("{x^{2/3}}")#text(") into ")#mi("{A=O( \\log^{21} x )}")#text(" consecutive intervals ")#mi("{I_1,\\dots,I_A}")#text(" each of the form ")#mi("{[N, \\lambda N]}")#text(" for some ")#mi("{x^{1/3} \\leq N \\leq x^{2/3}}")#text(". We similarly split ")#mi("{[z,x^{1/3}]}")#text(" (plus possibly a tiny portion of ")#mi("{[z/2,z]}")#text(") into ")#mi("{B=O( \\log^{21} x)}")#text(" intervals ")#mi("{J_1,\\dots, J_B}")#text(" each of the form ")#mi("{[M, \\lambda M]}")#text(" for some ")#mi("{1 \\ll M \\leq x^{1/3}}")#text(". We can thus split ")#mi("{a_n}")#text(" as")

#align(center)[#tao-fit-display[#mitex("a_n = \\sum_{1 \\leq b \\leq B} \\sum_{1 \\leq a \\leq a^{\\prime} \\leq A} \\sum_{z \\leq p_1 \\leq x^{1/3} < p_2 \\leq p_3: p_1 \\in J_b, p_2 \\in I_a, p_3 \\in I_{a^{\\prime}}} 1_{n=p_1p_2p_3}1_{x/2+2 \\leq n \\leq x} .")]]

#text("Observe that for each ")#mi("{a,a^{\\prime}}")#text(" there are only ")#mi("{O(1)}")#text(" choices of ")#mi("{b}")#text(" for which the summand can be non-zero. As such, the contribution of the diagonal case ")#mi("{a=a^{\\prime}}")#text(" can be easily seen to be absorbed into the ")#mi("{r_d}")#text(" error, as can those cases where the product set ")#mi("{\\{ uvw: u \\in J_b, v \\in I_a, r \\in I_{a^{\\prime}} \\}}")#text(" is not contained completely in ")#mi("{[x/2+2,x]}")#text(". If we let ")#mi("{\\Omega}")#text(" be the set of triplets ")#mi("{(b,a,a^{\\prime})}")#text(" obeying these properties, we can thus approximate ")#mi("{a_n}")#text(" by ")#mi("{\\sum_{(b,a,a^{\\prime}) \\not \\in \\Omega} a_n^{(b,a,a^{\\prime})}}")#text(", where ")#mi("{a_n^{(b,a,a^{\\prime})}}")#text(" is the Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("a_n^{(b,a,a^{\\prime})} := 1_{{\\mathcal P} \\cap J_b} * 1_{{\\mathcal P} \\cap I_a} * 1_{{\\mathcal P} \\cap I_{a^{\\prime}}}.")]]

#text("From the general Bombieri-Vinogradov theorem (Theorem 16 of ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(") and the Siegel-Walfisz theorem (Exercise 64 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in E_d} a_n^{(b,a,a^{\\prime})} = g(d) X^{(b,a,a^{\\prime})} + r_d^{(b,a,a^{\\prime})}")]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq D: \\mu^2(d)=1} \\left|r_d^{(b,a,a^{\\prime})}\\right| \\ll x \\log^{-10} x", block: true)]]

#text("(say) and")

#align(center)[#tao-fit-display[#mitex("X^{(b,a,a^{\\prime})} = \\sum_n a_n^{(b,a,a^{\\prime})}.")]]

#text("This gives the claim with ")#mi("{\\sum_n a_n}")#text(" replaced by the quantity ")#mi("{\\sum_{(b,a,a^{\\prime}) \\not \\in \\Omega} X^{(b,a,a^{\\prime})}}")#text("; but by undoing the previous decomposition we see that this quantity is equal to ")#mi("{\\sum_n a_n}")#text(" up to an error of ")#mi("{O( x \\log^{-11} x)}")#text(" (say), and the claim follows.")

#text("Applying the upper bound sieve ")#link(<tao-5e567455a23979b8d027>)[#text("(12)")]#text(" (with sifting level ")#mi("{D^{1/(1+\\varepsilon)}}")#text("), we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n} 1_{(n-2,P(\\sqrt{x}))=1} a_n \\leq (F(1+\\varepsilon)+O(\\varepsilon)) V( D^{1/(1+\\varepsilon)} ) \\sum_n a_n + O( x \\log^{-10} x )")]]

#text("and hence by ")#link(<tao-371b7a3dc076cf3dbe34>)[#text("(10)")]#text(" and Exercise ")#link(<tao-9685c81b76accc506949>)[#text("12")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n} 1_{(n-2,P(\\sqrt{x}))=1} a_n \\leq (4+O(\\varepsilon)) \\frac{2\\Pi_2}{\\log x} \\sum_n a_n + O( x \\log^{-10} x )")]]

#text("for ")#mi("{x}")#text(" sufficiently large.")

#text("Note that")

#align(center)[#tao-fit-display[#mitex("\\sum_n a_n = \\sum_{z \\leq p_1 \\leq x^{1/3} < p_2 < \\frac{x}{p_1 p_2}} \\sum_{\\max( p_2, \\frac{x/2+2}{p_1 p_2} ) < p_3 < \\frac{x}{p_1 p_2}} 1.")]]

#text("From the prime number theorem and Exercise 37 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_n a_n \\leq (1+o(1)) \\frac{x}{2\\log x} \\int_{1/8 \\leq t_1 \\leq 1/3 < t_2 < 1-t_1-t_2} \\frac{dt_1 dt_2}{t_1 t_2 (1-t_1-t_2)}.")]]

#text("(In fact one also has a matching lower bound, but we will not need it here.) We thus conclude that")

#align(center)[#tao-fit-display[#mitex("A_3 \\leq (C+o(1)) \\Pi_2 \\frac{x}{2\\log z}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("C  & := \\int_{1/8 \\leq t_1 \\leq 1/3 < t_2 < 1-t_1-t_2} \\frac{dt_1 dt_2}{t_1 t_2 (1-t_1-t_2)}", block: true)



#tao-math(" & = 0.363 \\dots", block: true)
]

#text("The left-hand side of ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(38)")]#text(" is then at least")

#align(center)[#tao-fit-display[#mitex("(2 \\log 3 - \\log 6 - C) \\Pi_2 \\frac{x}{4 \\log z}.")]]

#text("One can calculate that ")#mi("{2 \\log 3 - \\log 6 - C > 0}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Establish Chen’s theorem for the even Goldbach conjecture.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" If one is willing to use stronger distributional claims on the primes than is provided by the Bombieri-Vinogradov theorem, then one can use a simpler sieve than Chen’s sieve to establish Chen’s theorem, but then the required distributional theorem will then either be conjectural or more difficult to establish than the Bombieri-Vinogradov theorem. See Chapter 25 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(" for further discussion.")
]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-451202")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("It seems that in the RHS of (6)-(7), “")#mi("u")#text("” (in the integrands) should be “")#mi("s")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-451205")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("Also in the line below (7).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-451211")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("In the last two integrals preceding Exercise 9, the upper integration limit is misplaced.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-451212")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("3 lines up from (37): we see from (23) *that the error*(?) is bounded by")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-451316")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2015")])]

#text("In the proof of Chen’s Theorem, in the paragraph “We begin with ")#mi("A_1")#text("“, ")#mi("E_d")#text(" is said to be the class of -2 mod ")#mi("p")#text(" rather than mod ")#mi("d")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-453639")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("Just after the fragment “and the Siegel-Walfisz theorem (Exercise 64 of Notes 2) we see that [Formula] where” it should probably be log^{-10}x instead of log^{-100x}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-453645")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2015")])]

#text("Right now it’s log^{-10x} instead of log^{-10}x.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-454010")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("Chen’s theorem section: shouldn’t it be ")#mi("x/2 \\leq n \\leq x-2 : p|n+2")#text(" under the big sigma in the definition of ")#mi("A_{2,p}")#text(" ? The same thing reappears a few lines later.")

#text("Just after “Now we turn to ")#mi("A_{2,p}")#text("“, what happens if p divides d?")

#emph[#text("[I was not able to locate this issue – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-454015")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2015")])]

#text("In the same fragment it probably should be ")#mi("z \\leq p \\leq x^{1/3}")#text(" instead of ")#mi("z^{1/3} \\leq p \\leq z")#text(", shouldn’t it? That would also explain my last question.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-454024")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2015")])]

#text("The ")#mi("A_{2,p}")#text(" issue wasn’t there anymore while I was writting about it. I think you had repaired it a few days before and I forgot to refresh the website. Sorry for the confusion.")

#text("By the way, thank you for writing posts about sieve theory. Some details and ideas are much easier for me to follow right now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-454093")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2015")])]

#text("The formula under “Applying the upper bound sieve” fragment: it should be ")#mi("O( \\varepsilon )")#text(" instead of ")#mi("\\varepsilon")#text(" in one place.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-463751")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")])]

#text("I have a little confusion: before the equation (40) we send {\\varepsilon} to 0 slowly but in Theorem 2 we have “if {D} is sufficiently large depending on {\\varepsilon, s, c}.” How should I understand this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-463757")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")])]

#text("It seems to me like we are using two different epsilons there. By the way, is it possible to relax conditions in Theorem 2 and let ")#mi("\\varepsilon")#text(" depend on z?")

#text("Theorem 2 also reminds me the Jurkat-Richert theorem, although we do not have any restriction on the sieve dimension. How do these two theorems are related to each other?")

#text("Sorry for doubling the post and using LaTeX wrongly in the previous one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-463762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")])]

#text("For any fixed choice of ")#mi("\\varepsilon")#text(", the largeness condition on ")#mi("D")#text(" required for Theorem 2 will apply if ")#mi("x")#text(" is large enough, thus")

#mi("A_1 \\geq (f(4-8\\varepsilon) - O(\\varepsilon)) \\Pi_2 \\frac{x}{\\log z}")

#text("whenever ")#mi("x")#text(" is sufficiently large depending on ")#mi("\\varepsilon")#text(" (this allows for the o(1) errors to be absorbed into the ")#mi("O(\\varepsilon)")#text(" error). In particular, for any ")#mi("\\delta > 0")#text(", one has")

#mi("A_1 \\geq (f(4)-\\delta) \\Pi_2 \\frac{x}{\\log z}")

#text("whenever ")#mi("x")#text(" is sufficiently large depending on ")#mi("\\delta")#text(" (by choosing ")#mi("\\varepsilon")#text(" appropriately depending on ")#mi("\\delta")#text("). This implies that")

#mi("A_1 \\geq (f(4) - o(1)) \\Pi_2 \\frac{x}{\\log z}")

#text("as ")#mi("x \\to \\infty")#text(".")

#text("Another way to think about it as follows: if one has a bound of the form")

#mi("f(x) = O(\\varepsilon) + o(1) \\quad (1)")

#text("as ")#mi("x \\to \\infty")#text(" for any fixed choice of ")#mi("\\varepsilon")#text(", then one automatically has the improvement")

#mi("f(x) = o(1)")

#text("as ")#mi("x \\to \\infty")#text(", by setting ")#mi("\\varepsilon")#text(" equal to a function of ")#mi("x")#text(" that goes to zero sufficiently slowly (slow enough so that the ")#mi("o(1)")#text(" error in (1) still goes to zero even though ")#mi("\\varepsilon")#text(" is now varying).")

#text("The Jurkat-Richert theorem has a slightly better error term replacing ")#mi("O(\\varepsilon)")#text(", and a slightly worse error term for the ")#tao-math("\\left|r_d\\right|", block: false)#text(" errors, but can easily be used as a substitute for Theorem 2 for the purpose of proving Chen’s theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-464570")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2015")])]

#text("I have one problem with Lemma 11. How do we rule out the numbers of the form ")#mi("p^2q")#text(", where ")#mi("p,q \\in \\mathcal{P}")#text(" and ")#mi("p \\leq x^{1/3}-1")#text(" and ")#mi("q \\geq x^{1/3}")#text("?")

#text("I saw an another proof of Chen’s theorem in which the author (Nathanson, I guess) used the sum ")#mi("\\sum_{z< q \\leq x^{1/3}} k 1_{q^k \\| n}")#text(" instead of ")#mi("\\sum_{p \\leq x^{1/3}} 1_{p|n}")#text(". By this trick we can easily avoid thinking about numbers which are not square-free.")

#text("Are these two approaches equivalent in some easy way which I cannot see right now?")

#text("I would also like to thank you for your last answer.")

#emph[#text("[Oops, this case does need to be inserted, but it is easily dealt with (with ")#mi("z = x^{1/8}")#text(", it contributes ")#mi("x^{7/8+o(1)}")#text(" from trivial estimates). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52000100297aa059cf8695d2afb051f80aadde62358d8caf7d875546fa0fdb8f-9be2a6fd7c60deac0767ca3686f23b815185ad09e98dae8431cda417a358505f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-518340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2019")])]

#text("Why is of ")#mi("z:=x^{\\frac{1}{8}}")#text(" in Chen’s Theorem? Is it not the case that the closer ")#mi("z")#text(" is to ")#mi("z:=x^{\\frac{1}{3}}")#text(" the better? I believe that using the same arguments and with same error term, one could set ")#mi("z:=x^{\\frac{1}{k}}")#text(", where ")#mi("k")#text(" is the root of ")#mi("\\log\\frac{k-2}{4} - \\int_{\\frac{1}{k}}^{\\frac{1}{3}} \\frac{\\log(2-3x)}{x(1-x)} dx")#text(", i.e, ")#mi("k =7.585...")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-518344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2019")])]

#text("In this post I am not attempting to optimise the exponents in order to keep the exposition as clean as possible. I believe the text of Friedlander-Iwaniec contains further improvements to the exponent for ")#mi("z")#text(", but I do not have the reference handy right now, and there may be further slight improvements in the literature.")

#text("UPDATE: Section 25.6 of Friedlander-Iwaniec allows ")#mi("z")#text(" to be as large as ")#mi("x^{3/11}")#text(". It may be that further improvements are still possible beyond this exponent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-542095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("Hi Prof Tao,")#linebreak()#text(" Just a quick question: why do we need eq. (31)? We seem to never use it in the proof. Apologies if I missed a clear usage of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-542222")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("(31) is needed to establish some cases of (32), which is then used in the proof of Lemma 8. (One could cut out the middle man and just impose (32), but this formalism is closer to the general beta-sieve formalism one sees for instance in the text of Iwaniec-Kowalski or Friedlander-Iwaniec.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2dbf42492d14667c0ec2a31803a7738aef1a5985ce77ec2acedc8c9bc190ad3-bca8de91b86d65bd04e9c96a3f419066b76e5388773231a0e67bb74252f47e17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michelangelo Mecozzi")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-547685")[#strong[#text("Michelangelo Mecozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("A tiny detail: when we define ")#mi("D_0")#text(" and ")#mi("z_0")#text(" should the values be swapped? With the current values we have ")#mi("s_0 = \\log D_0/\\log z_0 = 1/\\varepsilon")#text(" and I assume we want ")#mi("s_0 = \\varepsilon")#text(" as in the proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2dbf42492d14667c0ec2a31803a7738aef1a5985ce77ec2acedc8c9bc190ad3-bca8de91b86d65bd04e9c96a3f419066b76e5388773231a0e67bb74252f47e17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michelangelo Mecozzi")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-547687")[#strong[#text("Michelangelo Mecozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("My bad, actually we want that and it wouldn’t make sense to swap! I was working on the Exercise trying to show that the LHS of (34) is bounded by ")#mi("f(s-2\\varepsilon^3)+o(1)")#text(", this should be be ")#mi("f(s-2\\varepsilon^2)+o(1)")#text(" or I’m mistaken again? Doesn’t make any difference in the calculations…")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-548489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Is it possible to get the following clarification: when you say (towards the end of the proof of the linear sieve) “Note that (29) also gives ")#mi("p_r \\geq (D/D_0^2)^{1/(r+2)}")#text("” how can we deduce that?")

#emph[#text("[You are right, this is not the correct way to get a lower bound on ")#mi("p_r")#text(" at this step. I will have to look at Friedlander-Iwaniec for the correct argument, but unfortunately due to the lockdown I will not be able to do so for a while. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-550356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("I was finally able to retrieve my copy of Friedlander-Iwaniec. Theorem 2 is proven (in a stronger and more general form) as Theorem 11.12 from that paper. However the arguments are quite intricate, in particular the upper bounds on ")#mi("B_r")#text(" are proven recursively. I now vaguely remember finding an alternate approach (based on using the Selberg counterexample weights) to write the notes here, but as you pointed out the lower bounding of ")#mi("p_r")#text(" is incorrect. If one does compute what (29), (30) do give for lower bounds, they are more of the form ")#mi("p_r \\geq D^{1/C^r}")#text(", thus the exponent degrades exponentially in ")#mi("r")#text(" rather than linearly. This still gives satisfactory control on the ")#mi("B_r")#text(" when ")#mi("r = o(\\log \\frac{1}{\\varepsilon})")#text(" but now there is an intermediate region ")#mi("r \\sim \\log \\frac{1}{\\varepsilon}")#text(" which is not currently covered by the above arguments. The issue is probably fixable, for instance by importing some of the recursive arguments from Friedlander-Iwaniec, but currently I will not have the time to address them and for now one should simply refer to Theorem 11.12 of Friedlander-Iwaniec for a proof of Theorem 2 in this post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/29/254a-supplement-5-the-linear-sieve-and-chens-theorem-optional/#comment-685599")[#strong[#text("Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("[…] related to this, if one only sieves up to for some , the linear sieve (see e.g., Theorem 2 of this previous blog post) shows that one must have at least survivors, where can be given explicitly in the regime by the […]")
]
