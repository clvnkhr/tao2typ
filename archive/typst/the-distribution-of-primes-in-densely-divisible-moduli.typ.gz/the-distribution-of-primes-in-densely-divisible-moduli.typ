// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/
// Converted to Typst by tao2typ: "2026-10-14T16:37:08.412531+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The distribution of primes in densely divisible moduli", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The distribution of primes in densely divisible moduli")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As in previous posts, we use the following asymptotic notation: ")#mi("{x}")#text(" is a parameter going off to infinity, and all quantities may depend on ")#mi("{x}")#text(" unless explicitly declared to be “fixed”. The asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" is then defined relative to this parameter. A quantity ")#mi("{q}")#text(" is said to be ")#emph[#text("of polynomial size")]#text(" if one has ")#mi("{q = O(x^{O(1)})}")#text(", and ")#emph[#text("bounded")]#text(" if ")#mi("{q=O(1)}")#text(". We also write ")#mi("{X \\lessapprox Y}")#text(" for ")#mi("{X \\ll x^{o(1)} Y}")#text(", and ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\ll Y \\ll X}")#text(".")

#text("The purpose of this post is to collect together all the various refinements to the second half of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text(" that have been obtained as part of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text(" and present them as a coherent argument (though not fully self-contained, as we will need some lemmas from previous posts).")

#text("In order to state the main result, we need to recall some definitions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Singleton congruence class system)")]#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(", and let ")#mi("{{\\mathcal S}_I}")#text(" denote the square-free numbers whose prime factors lie in ")#mi("{I}")#text(". A ")#emph[#text("singleton congruence class system")]#text(" on ")#mi("{I}")#text(" is a collection ")#mi("{{\\mathcal C} = (\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" of primitive residue classes ")#mi("{a_q \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(" for each ")#mi("{q \\in {\\mathcal S}_I}")#text(", obeying the Chinese remainder theorem property ")#metadata(none) <tao-793ff64f83b41b5d467a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("a_{qr}\\ (qr) = (a_q\\ (q)) \\cap (a_r\\ (r))")]]

#text("whenever ")#mi("{q,r \\in {\\mathcal S}_I}")#text(" are coprime. We say that such a system ")#mi("{{\\mathcal C}}")#text(" has ")#emph[#text("controlled multiplicity")]#text(" if the")

#align(center)[#tao-fit-display[#tao-math("\\tau_{\\mathcal C}(n) := \\left|\\{ q \\in {\\mathcal S}_I: n = a_q\\ (q) \\}\\right|", block: true)]]

#text("obeys the estimate ")#metadata(none) <tao-cbf38e496835a79fe9ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{C^{-1} x \\leq n \\leq Cx: n = a\\ (r)} \\tau_{\\mathcal C}(n)^2 \\ll \\frac{x}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{o(1)}.")]]

#text("for any fixed ")#mi("{C>1}")#text(" and any congruence class ")#mi("{a\\ (r)}")#text(" with ")#mi("{r \\in {\\mathcal S}_I}")#text(". Here ")#mi("{\\tau}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(".")
]

#text("Next we need a relaxation of the concept of ")#mi("{y}")#text("-smoothness.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Dense divisibility)")]#text(" Let ")#mi("{y \\geq 1}")#text(". A positive integer ")#mi("{q}")#text(" is said to be ")#emph[#mi("{y}")#text("-densely divisible")]#text(" if, for every ")#mi("{1 \\leq R \\leq q}")#text(", there exists a factor of ")#mi("{q}")#text(" in the interval ")#mi("{[y^{-1} R, R]}")#text(". We let ")#mi("{{\\mathcal D}_y}")#text(" denote the set of ")#mi("{y}")#text("-densely divisible positive integers.")
]

#text("Now we present a strengthened version ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" of the Motohashi-Pintz-Zhang conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(", which depends on parameters ")#mi("{0 < \\varpi < 1/4}")#text(" and ")#mi("{0 < \\delta < 1/4}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3")]#text(" (")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(") Let ")#mi("{I \\subset {\\bf R}}")#text(", and let ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" be a congruence class system with controlled multiplicity. Then ")#metadata(none) <tao-6d7e04068fa604f0ea60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a_q)\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(".")
]

#text("The difference between this conjecture and the weaker conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is that the modulus ")#mi("{q}")#text(" is constrained to be ")#mi("{x^\\delta}")#text("-densely divisible rather than ")#mi("{x^\\delta}")#text("-smooth (note that ")#mi("{I}")#text(" is no longer constrained to lie in ")#mi("{[1,x^\\delta]}")#text("). This relaxation of the smoothness condition improves the Goldston-Pintz-Yildirim type sieving needed to deduce ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text("; see ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("this previous post")]#text(".")

#text("The main result we will establish is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(" holds for any ")#mi("{\\varpi,\\delta>0}")#text(" with ")#metadata(none) <tao-ec2e990b934dde55cb87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("148\\varpi+33\\delta < 1.")]]
]

#text("This improves upon previous constraints of ")#mi("{87\\varpi + 17 \\delta < \\frac{1}{4}}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234670")[#text("this blog comment")]#text(") and ")#mi("{207 \\varpi + 43 \\delta < \\frac{1}{4}}")#text(" (see Theorem 13 of ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps")[#text("this previous post")]#text("), which were also only established for ")#mi("{MPZ[\\varpi,\\delta]}")#text(" instead of ")#mi("{MPZ^{\\prime}[\\varpi,\\delta]}")#text(". Inserting Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("4")]#text(" into the Pintz sieve from ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("this previous post")]#text(" gives ")#mi("{DHL[k_0,2]}")#text(" for ")#mi("{k_0 = 1467}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235559")[#text("this blog comment")]#text("), which when inserted in turn into ")#link("http://www.opertech.com/primes/webdata/")[#text("newly set up tables")]#text(" of narrow prime tuples gives infinitely many prime gaps of separation at most ")#mi("{H = 12,012}")#text(".")

#metadata(none) <tao-ab33058508403ce7f280>

#heading(level: 1)[#strong[#text(" — 1. Reduction to Type I/II and Type III estimates — ")]]

#text("Following Zhang, we can perform a combinatorial reduction to reduce Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("4")]#text(" to two sub-estimates. To state this properly we need some more notation. We need a large fixed constant ")#mi("{A_0>0}")#text(" (that determines how finely we slice up the scales).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Coefficient sequences)")]#text(" A ")#emph[#text("coefficient sequence")]#text(" is a finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf R}}")#text(" that obeys the bounds ")#metadata(none) <tao-afd7bf72960f2f867380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\alpha(n)\\right| \\ll \\tau^{O(1)}(n) \\log^{O(1)}(x)", block: true)]]

#text("for all ")#mi("{n}")#text(".")

#list(
[#text("(i) If ")#mi("{\\alpha}")#text(" is a coefficient sequence and ")#mi("{a\\ (q) = a \\text{ mod } q}")#text(" is a primitive residue class, the (signed) ")#emph[#text("discrepancy")]#text(" ")#mi("{\\Delta(\\alpha; a\\ (q))}")#text(" of ")#mi("{\\alpha}")#text(" in the sequence is defined to be the quantity")

#metadata(none) <tao-6cd4c9c389b460a1f603>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\Delta(\\alpha; a \\ (q)) := \\sum_{n: n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} \\alpha(n).")]]],
[#text("(ii) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("at scale ")#mi("{N}")]#text(" for some ")#mi("{N \\geq 1}")#text(" if it is supported on an interval of the form ")#mi("{[(1-O(\\log^{-A_0} x)) N, (1+O(\\log^{-A_0} x)) N]}")#text(".")],
[#text("(iii) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to ")#emph[#text("obey the Siegel-Walfisz theorem")]#text(" if one has")

#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left| \\Delta(\\alpha 1_{(\\cdot,q)=1}; a\\ (r)) \\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q,r \\geq 1}")#text(", any fixed ")#mi("{A}")#text(", and any primitive residue class ")#mi("{a\\ (r)}")#text(".")],
[#text("(iv) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to be ")#emph[#text("smooth")]#text(" if it takes the form ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(" for some smooth function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[1-O(\\log^{-A_0} x), 1+O(\\log^{-A_0} x)]}")#text(" obeying the derivative bounds")

#metadata(none) <tao-ab1e6be2000a7c9c3d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\psi^{(j)}(t) = O( \\log^{j A_0} x )")]]

#text("for all fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant in the ")#mi("{O()}")#text(" notation may depend on ")#mi("{j}")#text(").")]
)
]

#text("We can now state the two subestimates needed. The first controls sums of Type I or Type II:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Type I/II estimate)")]#text(" ")#metadata(none) <tao-840c81157f3688e42875>#text(" Let ")#mi("{\\varpi, \\delta, \\sigma > 0}")#text(" be fixed quantities such that ")#metadata(none) <tao-4057a7096a1a6ceed39b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("17 \\varpi + 4\\delta + \\sigma < \\frac{1}{4}")]]

#text("and ")#metadata(none) <tao-b693131ffb745f7da6cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("20 \\varpi + 6\\delta + 3\\sigma < \\frac{1}{2}")]]

#text("and ")#metadata(none) <tao-c427572853b46c66c9e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("32 \\varpi + 9\\delta + \\sigma < \\frac{1}{2}")]]

#text("and ")#metadata(none) <tao-5b1b85d956c07f3e4d5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("48\\varpi + 7 \\delta < \\frac{1}{2}")]]

#text("and let ")#mi("{\\alpha,\\beta}")#text(" be coefficient sequences at scales ")#mi("{M,N}")#text(" respectively with ")#metadata(none) <tao-2f48b881ea7073f1c6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("MN \\sim x")]]

#text("and ")#metadata(none) <tao-cd58add90c5a1937a32b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("x^{\\frac{1}{2}-\\sigma} \\ll N \\ll M \\ll x^{\\frac{1}{2}+\\sigma}")]]

#text("with ")#mi("{\\beta}")#text(" obeying a Siegel-Walfisz theorem. Then for any ")#mi("{I \\subset {\\bf R}}")#text(" and any singleton congruence class system ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" with controlled multiplicity we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\beta; a_q)\\right| \\ll x \\log^{-A} x.", block: true)]]
]

#text("This improves upon Theorem 16 in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps")[#text("this previous post")]#text(", in which the modulus was required to be ")#mi("{x^\\delta}")#text("-smooth, and the constraints ")#link(<tao-4057a7096a1a6ceed39b>)[#text("(9)")]#text(", ")#link(<tao-b693131ffb745f7da6cf>)[#text("(10)")]#text(", ")#link(<tao-c427572853b46c66c9e0>)[#text("(11)")]#text(" were replaced by the stronger constraint ")#mi("{ 11 \\varpi + 3\\delta + 2 \\sigma < \\frac{1}{4}}")#text(", and ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(12)")]#text(" was similarly replaced by a stronger constraint ")#mi("{39 \\varpi + 5\\delta < \\frac{1}{4}}")#text(". Of the three constraints ")#link(<tao-4057a7096a1a6ceed39b>)[#text("(9)")]#text(", ")#link(<tao-b693131ffb745f7da6cf>)[#text("(10)")]#text(", ")#link(<tao-c427572853b46c66c9e0>)[#text("(11)")]#text(", the second constraint ")#link(<tao-b693131ffb745f7da6cf>)[#text("(10)")]#text(" is more stringent in practice, while the constraint ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(12)")]#text(" is dominated by other constraints (such as ")#link(<tao-ec2e990b934dde55cb87>)[#text("(4)")]#text(").")

#text("The second subestimate controls sums of Type III:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Type III estimate)")]#text(" ")#metadata(none) <tao-9ce19620746a8f953f54>#text(" Let ")#mi("{\\varpi, \\delta > 0}")#text(" be fixed quantities. Let ")#mi("{N_1,N_2,N_3, M > 1}")#text(" be scales obeying the relations")

#align(center)[#tao-fit-display[#mitex("N_1 \\gg N_2,N_3")]]

#metadata(none) <tao-620090ec13bea1af7472>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("M N_1^4 N_2^4 N_3^5 > x^{4+16\\varpi + \\delta+\\epsilon}")]]

#metadata(none) <tao-4eff9a56e3f01b24ef14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("N_1^3 N_2^3 N_3^4 > x^{3+12\\varpi + \\delta+\\epsilon}")]]

#text("and ")#metadata(none) <tao-dedcfe5dabd7a56fba00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("N_1 N_2 \\gtrapprox x^{1/2+6\\varpi+\\epsilon}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("MN_1 N_2 N_3 \\sim x")]]

#text("for some fixed ")#mi("{\\epsilon>0}")#text(". Let ")#mi("{\\alpha,\\psi_1,\\psi_2,\\psi_3}")#text(" be coefficient sequences at scales ")#mi("{M,N_1,N_2,N_3}")#text(" respectively, with ")#mi("{\\psi_1,\\psi_2,\\psi_3}")#text(" smooth. Then for any ")#mi("{I \\subset {\\bf R}}")#text(", and any singleton congruence class system ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\psi_1 \\ast \\psi_2 \\ast \\psi_3; a_q)\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(".")
]

#text("This improves upon Theorem 17 in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps")[#text("this previous post")]#text(", in which the modulus was required to be ")#mi("{x^\\delta}")#text("-smooth, and the constraints ")#link(<tao-620090ec13bea1af7472>)[#text("(15)")]#text(", ")#link(<tao-4eff9a56e3f01b24ef14>)[#text("(16)")]#text(" were replaced by the stronger constraint ")#mi("{N_1^4 N_2^4 N_3^5 > x^{4+16\\varpi + \\delta+\\epsilon}}")#text(". Of the two constraints ")#link(<tao-620090ec13bea1af7472>)[#text("(15)")]#text(", ")#link(<tao-4eff9a56e3f01b24ef14>)[#text("(16)")]#text(", the first constraint ")#link(<tao-620090ec13bea1af7472>)[#text("(15)")]#text(" is more stringent in practice.")

#text("Let us now recall the combinatorial argument (from ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps")[#text("this previous post")]#text(") that allows one to deduce Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("4")]#text(" from Theorems ")#link(<tao-840c81157f3688e42875>)[#text("6")]#text(" and ")#link(<tao-9ce19620746a8f953f54>)[#text("7")]#text(". As in Section 3 of ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps")[#text("this previous post")]#text(", we let ")#mi("{K \\geq 1}")#text(" be a fixed integer (")#mi("{K=10}")#text(" will suffice). Using the Heath-Brown identity as discussed in that section, we reduce to establishing the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha_1 \\ast \\ldots \\ast \\alpha_{2J}; a_q)\\right| \\ll x \\log^{-A} x", block: true)]]

#text("where ")#mi("{1 \\leq J \\leq K}")#text(", ")#mi("{1 \\ll N_1,\\ldots,N_{2J} \\ll x}")#text(" are quantities with the following properties:")

#list(
[#text("(i) Each ")#mi("{\\alpha_i}")#text(" is a coefficient sequence at scale ")#mi("{N_i}")#text(". More generally the convolution ")#mi("{\\alpha_S}")#text(" of the ")#mi("{\\alpha_i}")#text(" for ")#mi("{i \\in S}")#text(" is a coefficient sequence at scale ")#mi("{\\prod_{i \\in S} N_i}")#text(".")],
[#text("(ii) If ")#mi("{N_i \\gg x^{1/K+\\epsilon}}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(", then ")#mi("{\\alpha_i}")#text(" is smooth.")],
[#text("(iii) If ")#mi("{N_i \\gg x^\\epsilon}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(", then ")#mi("{\\alpha_i}")#text(" obeys a Siegel-Walfisz theorem. More generally, ")#mi("{\\alpha_S}")#text(" obeys a Siegel-Walfisz theorem if ")#mi("{\\prod_{i \\in S} N_i \\gg x^\\epsilon}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(".")],
[#text("(iv) ")#mi("{N_1 \\ldots N_{2J} \\sim x}")#text(".")]
)

#text("We can write ")#mi("{N_i \\sim x^{t_i}}")#text(" for ")#mi("{i=1,\\ldots,2J}")#text(", where the ")#mi("{t_i}")#text(" are non-negative reals that sum to ")#mi("{1}")#text(". We apply Lemma 6 from ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(" with some parameter ")#metadata(none) <tao-0b4ddb68a3e3633020d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("1/10 < \\sigma < 1/2")]]

#text("to be chosen later and conclude one of the following:")

#list(
[#text("(Type 0) There is a ")#mi("{t_i}")#text(" with ")#mi("{t_i \\geq 1/2 + \\sigma}")#text(".")],
[#text("(Type I/II) There is a partition ")#mi("{\\{1,\\ldots,2J\\} = S \\cup T}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} - \\sigma < \\sum_{i \\in S} t_i \\leq \\sum_{i \\in T} t_i < \\frac{1}{2} + \\sigma.")]]],
[#text("(Type III) There exist distinct ")#mi("{i,j,k}")#text(" with ")#mi("{2\\sigma \\leq t_i \\leq t_j \\leq t_k \\leq 1/2-\\sigma}")#text(" and ")#mi("{t_i+t_j,t_i+t_k,t_j+t_k \\geq 1/2 + \\sigma}")#text(".")]
)

#text("In the Type 0 case, we can write ")#mi("{\\alpha_1 \\ast \\ldots \\ast \\alpha_{2j}}")#text(" in a form in which Theorem 15 from ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(" applies. Similarly, in the Type I/II case we can write ")#mi("{\\alpha_1 \\ast \\ldots \\ast \\alpha_{2j}}")#text(" in a form in which Theorem ")#link(<tao-840c81157f3688e42875>)[#text("6")]#text(" applies, provided that the conditions ")#link(<tao-4057a7096a1a6ceed39b>)[#text("(9)")]#text(", ")#link(<tao-b693131ffb745f7da6cf>)[#text("(10)")]#text(", ")#link(<tao-c427572853b46c66c9e0>)[#text("(11)")]#text(" are obeyed (the condition ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(12)")]#text(" is implied by ")#link(<tao-ec2e990b934dde55cb87>)[#text("(4)")]#text("). Now suppose we are in the Type III case. For ")#mi("{K}")#text(" large enough (e.g. ")#mi("{K=10}")#text("), we see that ")#mi("{t_i,t_j,t_k \\geq \\frac{1}{K}+\\epsilon}")#text(" for some fixed ")#mi("{\\epsilon}")#text(". Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("7")]#text(" will then apply with")

#tao-aligned(keep: true)[


#tao-math("N_1  & \\sim x^{t_k}", block: true)



#tao-math("N_2  & \\sim x^{t_j}", block: true)



#tao-math("N_3  & \\sim x^{t_i}", block: true)



#tao-math("M  & \\sim x^{1-t_i-t_j-t_k}", block: true)
]

#text("provided that we can verify the hypotheses ")#link(<tao-620090ec13bea1af7472>)[#text("(15)")]#text(", ")#link(<tao-4eff9a56e3f01b24ef14>)[#text("(16)")]#text(", ")#link(<tao-dedcfe5dabd7a56fba00>)[#text("(17)")]#text(", which will follow if we have")

#align(center)[#tao-fit-display[#mitex("(1-t_i-t_j-t_k) + 4t_k + 4t_j + 5t_i > 4 + 16 \\varpi + \\delta")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("3t_k + 3 t_j + 4 t_i > 3 + 12 \\varpi + \\delta")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("t_k + t_j > \\frac{1}{2} + 6 \\varpi.")]]

#text("Since ")#mi("{t_i+t_j,t_i+t_k,t_j+t_k \\geq 1/2+\\sigma}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("(1-t_i-t_j-t_k) + 4t_k + 4t_j + 5t_i > 1 + 5 (\\frac{1}{2}+\\sigma)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("3t_k + 3t_j + 4t_i > 5 (\\frac{1}{2}+\\sigma)")]]

#text("so we will be done if we can find ")#mi("{\\sigma}")#text(" obeying the constraints ")#link(<tao-0b4ddb68a3e3633020d4>)[#text("(18)")]#text(", ")#link(<tao-4057a7096a1a6ceed39b>)[#text("(9)")]#text(", ")#link(<tao-b693131ffb745f7da6cf>)[#text("(10)")]#text(", ")#link(<tao-c427572853b46c66c9e0>)[#text("(11)")]#text(" as well as the constraints ")#metadata(none) <tao-7f9f29a4c20e3f2370b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("1 + 5 (\\frac{1}{2}+\\sigma) > 4 + 16 \\varpi + \\delta")]]

#text("and ")#metadata(none) <tao-d383b25abdd3fc5f319a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("5 (\\frac{1}{2}+\\sigma) > 3 + 12 \\varpi + \\delta")]]

#text("and ")#metadata(none) <tao-c483479a35ef72d6c725>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sigma > 6 \\varpi.")]]

#text("The condition ")#link(<tao-d383b25abdd3fc5f319a>)[#text("(20)")]#text(" is a consequence of ")#link(<tao-7f9f29a4c20e3f2370b9>)[#text("(19)")]#text(" and can thus be omitted.")

#text("We rewrite all of the constraints in terms of upper and lower bounds on ")#mi("{\\sigma}")#text(". The upper bounds take the form ")#metadata(none) <tao-bb82030dbc2bcaba32a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sigma < 1/2")]]

#metadata(none) <tao-6ca202c88e549dff68c0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sigma < \\frac{1}{4} - 17 \\varpi - 4 \\delta")]]

#metadata(none) <tao-011e39efe22590f4a339>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sigma < \\frac{1}{6} - \\frac{20}{3} \\varpi - 2 \\delta")]]

#metadata(none) <tao-e9c981a479986215bab0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sigma < \\frac{1}{2} - 32 \\varpi - 9\\delta")]]

#text("while the lower bounds take the form ")#metadata(none) <tao-2804bad6fe94a55f18b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sigma > \\frac{1}{10}")]]

#metadata(none) <tao-8a1cee436cbac1489a18>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sigma > \\frac{1}{10} + \\frac{16}{5} \\varpi + \\frac{1}{5} \\delta.")]]

#metadata(none) <tao-be18b85f77fc024db379>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\sigma > 6\\varpi")]]

#text("Clearly ")#link(<tao-bb82030dbc2bcaba32a9>)[#text("(22)")]#text(" is implied by ")#link(<tao-6ca202c88e549dff68c0>)[#text("(23)")]#text(", and ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(26)")]#text(" is implied by ")#link(<tao-8a1cee436cbac1489a18>)[#text("(27)")]#text("; restricting to the case ")#mi("{\\varpi < 1/60}")#text(" (which follows from ")#link(<tao-ec2e990b934dde55cb87>)[#text("(4)")]#text("), ")#link(<tao-be18b85f77fc024db379>)[#text("(28)")]#text(" is also implied by ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(26)")]#text(". Assuming ")#link(<tao-ec2e990b934dde55cb87>)[#text("(4)")]#text(", we also see that ")#link(<tao-6ca202c88e549dff68c0>)[#text("(23)")]#text(", ")#link(<tao-e9c981a479986215bab0>)[#text("(25)")]#text(" are implied by ")#link(<tao-011e39efe22590f4a339>)[#text("(24)")]#text(", so we reduce to establishing that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{10} + \\frac{16}{5} \\varpi + \\frac{1}{5} \\delta < \\frac{1}{6} - \\frac{20}{3} \\varpi - 2 \\delta")]]

#text("but this rearranges to ")#link(<tao-ec2e990b934dde55cb87>)[#text("(4)")]#text(".")

#text("It remains to establish Theorem ")#link(<tao-840c81157f3688e42875>)[#text("6")]#text(" and Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("7")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Type I/II analysis — ")]]

#text("We begin the proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("6")]#text(", closely following the arguments from Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(". We can restrict ")#mi("{q}")#text(" to the range")

#align(center)[#tao-fit-display[#mitex("q \\gtrapprox x^{1/2}")]]

#text("for some sufficiently slowly decaying ")#mi("{o(1)}")#text(", since otherwise we may use the Bombieri-Vinogradov theorem (Theorem 4 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("). Thus, by dyadic decomposition, we need to show that ")#metadata(none) <tao-4b3d4a0dd732f791ca89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\sum_{d \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}: D \\leq d < 2D} \\left|\\Delta(\\alpha \\ast \\beta; a_d)\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any ")#mi("{D}")#text(" in the range")

#align(center)[#tao-fit-display[#mitex("x^{1/2} \\lessapprox D \\lessapprox x^{1/2+2\\varpi}.")]]

#text("Let ")#metadata(none) <tao-352b5b6699d83cdc4efd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\mu > 0")]]

#text("be an exponent to be optimised later (in the Type I case, it will be infinitesimally close to zero, while in the Type II case, it will be infinitesimally larger than ")#mi("{2\\varpi}")#text(").")

#text("By Lemma 11 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", we know that for all ")#mi("{d}")#text(" in ")#mi("{[D,2D]}")#text(" outside of a small number of exceptions, we have ")#metadata(none) <tao-3afbd5577a879d3382d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\prod_{p|d: p \\leq D_0} p \\lessapprox 1")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("D_0 := \\exp(\\log^{1/3} x).")]]

#text("Specifically, the number of exceptions in the interval ")#mi("{[D,2D]}")#text(" is ")#mi("{O(D \\log^{-A} x)}")#text(" for any fixed ")#mi("{A>0}")#text(". The contribution of the exceptional ")#mi("{d}")#text(" can be shown to be acceptable by Cauchy-Schwarz and trivial estimates (see Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("), so we restrict attention to those ")#mi("{d}")#text(" for which ")#link(<tao-3afbd5577a879d3382d9>)[#text("(31)")]#text(" holds. In particular, as ")#mi("{d}")#text(" is restricted to be ")#mi("{x^\\delta}")#text("-densely divisible we may factor")

#align(center)[#tao-fit-display[#mitex("d=qr")]]

#text("with ")#mi("{q,r}")#text(" coprime and square-free, with ")#mi("{q \\in {\\mathcal S}_{I^{\\prime}}}")#text(" with ")#mi("{I^{\\prime} := [D_0,\\infty) \\cap I}")#text(", and")

#align(center)[#tao-fit-display[#mitex("x^{-\\mu-\\delta} N \\lessapprox r \\lessapprox x^{-\\mu} N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{1/2} \\lessapprox qr \\lessapprox x^{1/2+2\\varpi}.")]]

#text("By dyadic decomposition, it thus sufices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_{I^{\\prime}}: q \\sim Q} \\sum_{r \\in {\\mathcal S}_I: r \\sim R; (q,r)=1} \\left|\\Delta(\\alpha \\ast \\beta; a_{qr})\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{Q, R \\geq 1}")#text(" obey the size conditions ")#metadata(none) <tao-375676bd26868505668f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("x^{-\\mu-\\delta} N \\lessapprox R \\lessapprox x^{-\\mu} N")]]

#text("and ")#metadata(none) <tao-2617708489831f17c7b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("x^{1/2} \\lessapprox QR \\lessapprox x^{1/2 + 2\\varpi}.")]]

#text("Fix ")#mi("{Q,R}")#text(". We abbreviate ")#mi("{\\sum_{q \\in {\\mathcal S}_{I^{\\prime}}: q \\sim Q}}")#text(" and ")#mi("{\\sum_{r \\in {\\mathcal S}_I: r \\sim R}}")#text(" by ")#mi("{\\sum_q}")#text(" and ")#mi("{\\sum_r}")#text(" respectively, thus our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_q \\sum_{r: (q,r)=1} \\left|\\Delta(\\alpha \\ast \\beta; a_{qr})\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("We now split the discrepancy")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha \\ast \\beta; a_{qr}) = \\sum_{n = a_{qr}\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)")]]

#text("as the sum of the subdiscrepancies")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = a_{qr}\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n).")]]

#text("In Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", it was established that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)\\right| \\ll", block: true)]]

#align(center)[#tao-fit-display[#mitex("NM \\log^{-A} x")]]

#text("so it suffices to show that ")#metadata(none) <tao-c75de8c1b7c3ae525209>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\sum_{n: n = a_{qr}\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM \\log^{-A} x.")]]

#text("As in the previous notes, we will not take advantage of the ")#mi("{r}")#text(" summation, and use crude estimates to reduce to showing that ")#metadata(none) <tao-e9fa0453869469e08db9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\sum_{q; (q,r)=1} \\left|\\sum_{n: n = a_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for each individual ")#mi("{r \\in {\\mathcal S}_I}")#text(" with ")#mi("{r \\sim R}")#text(", which we now fix. Repeating the previous arguments, it sufices to show that ")#metadata(none) <tao-73cce42f1f0e9099688b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("\\sum_{q; (q,r)=1} \\left|\\sum_{n: n = b_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\sum_{n: n = b^{\\prime}_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("whenever ")#mi("{(b_q)_{q \\in {\\mathcal S}_{I^{\\prime}}}, (b^{\\prime}_q)_{q \\in {\\mathcal S}_{I^{\\prime}}}}")#text(" are good singleton congruence class systems.")

#text("By duality and Cauchy-Schwarz exactly as in Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("the previous post")]#text(", it suffices to show that ")#metadata(none) <tao-8dd42f9fc74cd334c8dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("\\sum_{m} \\psi_M(m) \\left|\\sum_{q,n: mn = a_r\\ (r); (q,r)=1} c_{q} \\beta(n) (1_{mn = b_{q}\\ (q)} - 1_{mn = b^{\\prime}_{q}\\ (q)})\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{\\psi_M}")#text(" is a smooth coefficient sequence at scale ")#mi("{M}")#text(". Expanding out the square, it suffices to show that ")#metadata(none) <tao-70848ccfe56d24288a89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a_r\\ (r); (q_1,r)=(q_2,r)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{mn_1 = b_{q_1}\\ (q_1)} 1_{mn_2 = b^{\\prime}_{q_2}\\ (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x )")]]

#text("where ")#mi("{q_1,q_2}")#text(" is subject to the same constraints as ")#mi("{q}")#text(" (thus ")#mi("{q_i \\in {\\mathcal S}_{I^{\\prime}}}")#text(" and ")#mi("{Q \\ll q_i \\ll Q}")#text(" for ")#mi("{i=1,2}")#text("), and ")#mi("{X}")#text(" is some quantity that is independent of the choice of congruence classes ")#mi("{(b_q)_{q \\in {\\mathcal S}_I}}")#text(", ")#mi("{(b^{\\prime}_q)_{q \\in {\\mathcal S}_I}}")#text(".")

#text("As in the ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums")[#text("previous notes")]#text(", we can dispose of the case when ")#mi("{q_1,q_2}")#text(" share a common factor by using the controlled multiplicity hypothesis, provided we have the hypothesis ")#metadata(none) <tao-f45610b06fe1da76ca5b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("x^\\mu \\geq x^{-1/2+2\\varpi+c} N")]]

#text("which we file away for later. (There was also the condition ")#mi("{R \\ll x^{-c+o(1)} M}")#text(" from equation (33) of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sum")[#text("previous notes")]#text(", but this condition is implied by ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(30)")]#text(" for ")#mi("{c}")#text(" small enough since ")#mi("{N \\ll M}")#text(".) This reduces us to establishing ")#metadata(none) <tao-c7d459bba7d890eb2690>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("\\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a_r\\ (r); (q_1,r)=(q_2,r)=(q_1,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{mn_1 = b_{q_1}\\ (q_1)} 1_{mn_2 = b^{\\prime}_{q_2}\\ (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-2} \\log^{-A} x ).")]]

#text("It remains to verify ")#link(<tao-c7d459bba7d890eb2690>)[#text("(40)")]#text(". Observe that ")#mi("{n_1}")#text(" must be coprime to ")#mi("{q_1r}")#text(" and ")#mi("{n_2}")#text(" coprime to ")#mi("{q_2r}")#text(", with ")#mi("{n_1 = n_2\\ (r)}")#text(", to have a non-zero contribution to the sum. We then rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q_1,q_2: (q_1,r)=(q_2,r)=(q_1,q_2)=1} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: n_1=n_2\\ (r); (n_1,q_1r)=(n_2,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{m = a_r/n_1\\ (r); m = b_{q_1}/n_1\\ (q_1); m = b^{\\prime}_{q_2}/n_2 (q_2)};")]]

#text("note that these inverses in the various rings ")#mi("{{\\bf Z}/r{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_1{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_2{\\bf Z}}")#text(" are well-defined thanks to the coprimality hypotheses.")

#text("We may write ")#mi("{n_2 = n_1+kr}")#text(" for some ")#mi("{k = O(N/R)}")#text(". By the triangle inequality, and relabeling ")#mi("{n_1}")#text(" as ")#mi("{n}")#text(", it thus suffices to show that for any particular ")#metadata(none) <tao-996e1ebb1203243399dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("k = O(N/R),")]]

#text("one has ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("\\sum_{q_1,q_2: (q_1,r)=(q_2,r)=(q_1,q_2)=1} \\sum_{m} \\psi_M(m) \\sum_{n; (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n) \\beta(n+kr) 1_{m = a_r/n\\ (r); m = b_{q_1}/n\\ (q_1); m = b^{\\prime}_{q_2}/(n+kr) (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X_k + O( N M R^{-1} \\log^{-A} x )")]]

#text("for some ")#mi("{X_k}")#text(" independent of the ")#mi("{b_q}")#text(" and ")#mi("{b^{\\prime}_q}")#text(".")

#text("Applying completion of sums (Section 2 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("the previous post")]#text("), we reduce to showing that ")#metadata(none) <tao-a7a8572a4aabf25aac4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("\\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} |\\sum_{n} \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n)| \\lessapprox x^{-\\epsilon} Q^2 N")]]

#text("for a sufficiently small fixed ")#mi("{\\epsilon>0}")#text(", where ")#metadata(none) <tao-a81ffb258bff4eddc451>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("H := x^\\epsilon Q^2 R/M")]]

#text("and ")#mi("{\\Phi = \\Phi_{k,r}}")#text(" is the phase ")#metadata(none) <tao-e46fd696bb4d24c149d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("\\Phi(h,q_1,q_2;n) := 1_{(q_1,r)=(q_2,r)=(q_1,q_2)=(n,r)=(n,q_1)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("e_r( \\frac{a_r h}{nq_1 q_2} ) e_{q_1}( \\frac{b_{q_1}h}{n r q_2} ) e_{q_2}( \\frac{b^{\\prime}_{q_2} h}{(n+kr) r q_1} ),")]]

#text("and we have dropped all hypotheses on ")#mi("{q_1,q_2}")#text(" other than magnitude, and we abbreviate ")#mi("{\\sum_{1 \\leq h \\leq H}}")#text(" as ")#mi("{\\sum_h}")#text(".")

#text("We now split into two cases, one which works when ")#mi("{M, N}")#text(" are not too close to ")#mi("{x^{1/2}}")#text(", and one which works when ")#mi("{M, N}")#text(" are close to ")#mi("{x^{1/2}}")#text(". Here is the Type I estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Type I case)")]#text(" ")#metadata(none) <tao-b5e509d769c77bd1fecf>#text(" If the inequalities ")#metadata(none) <tao-7c25b82c0ab03b1bca18>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("17\\varpi + \\sigma + 4\\mu + 4\\delta < \\frac{1}{4}")]]

#text("and ")#metadata(none) <tao-9a370ebd95136e8b2036>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#mitex("20\\varpi + 3\\sigma + 6\\mu + 6\\delta < \\frac{1}{2}")]]

#text("and ")#metadata(none) <tao-22b1f82e804e2c285b47>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#mitex("32 \\varpi + \\sigma + 9 \\mu + 9\\delta < \\frac{1}{2}.")]]

#text("and ")#metadata(none) <tao-628b49d96dcde97a430d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#mitex("M \\gtrapprox x^{1/2+2\\varpi+c^{\\prime}}")]]

#text("hold for some fixed ")#mi("{c^{\\prime}>0}")#text(", then ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(43)")]#text(" holds for a sufficiently small fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("The hypotheses ")#link(<tao-7c25b82c0ab03b1bca18>)[#text("(46)")]#text(", ")#link(<tao-9a370ebd95136e8b2036>)[#text("(47)")]#text(", ")#link(<tao-22b1f82e804e2c285b47>)[#text("(48)")]#text(" improve upon Theorem 13 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", which had instead the more strict condition")

#align(center)[#tao-fit-display[#mitex("11\\varpi + 3\\mu + 3\\delta + 2 \\sigma < \\frac{1}{4}.")]]

#text("In practice the condition ")#link(<tao-9a370ebd95136e8b2036>)[#text("(47)")]#text(" is dominant.")

#text("Now we give the Type II estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Type II case)")]#text(" ")#metadata(none) <tao-39f88196b45a1d7fb36b>#text(" If the inequality ")#metadata(none) <tao-ab830477ec5ce7877333>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#mitex("24\\varpi + 7 \\mu + 7 \\delta + 5 \\sigma < \\frac{1}{2}")]]

#text("holds, then ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(43)")]#text(" holds for a sufficiently small fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("This result improves upon Theorem 14 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(" which had the stronger condition")

#align(center)[#tao-fit-display[#mitex("24\\varpi + 10 \\mu + 10 \\delta + 7 \\sigma < \\frac{1}{2}.")]]

#text("In practice, ")#link(<tao-ab830477ec5ce7877333>)[#text("(50)")]#text(" will not hold with the original value of ")#mi("{\\sigma}")#text(" in Theorem ")#link(<tao-840c81157f3688e42875>)[#text("6")]#text("; instead, we only use Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("9")]#text(" the case ")#mi("{M \\lessapprox x^{1/2+2\\varpi+c^{\\prime}}}")#text(" excluded by Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("8")]#text(", in which case we will be able to lower ")#mi("{\\sigma}")#text(" down to be ")#mi("{2\\varpi+c^{\\prime}}")#text(" and verify ")#link(<tao-ab830477ec5ce7877333>)[#text("(50)")]#text(" in that case.")

#text("Assuming these theorems, let us now conclude the proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("6")]#text(". First suppose we are in the “Type I” regime when ")#link(<tao-628b49d96dcde97a430d>)[#text("(49)")]#text(" holds for some fixed ")#mi("{c^{\\prime}>0}")#text(". Then by ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("N \\ll x^{1/2-2\\varpi-c^{\\prime}}")]]

#text("which means that the condition ")#link(<tao-f45610b06fe1da76ca5b>)[#text("(39)")]#text(" is now weaker than ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(30)")]#text(" (for ")#mi("{c}")#text(" small enough) and may be omitted. By ")#link(<tao-4057a7096a1a6ceed39b>)[#text("(9)")]#text(", ")#link(<tao-b693131ffb745f7da6cf>)[#text("(10)")]#text(", ")#link(<tao-c427572853b46c66c9e0>)[#text("(11)")]#text(", we can simultaneously obey ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(30)")]#text(", ")#link(<tao-7c25b82c0ab03b1bca18>)[#text("(46)")]#text(", ")#link(<tao-9a370ebd95136e8b2036>)[#text("(47)")]#text(", ")#link(<tao-22b1f82e804e2c285b47>)[#text("(48)")]#text(" by setting ")#mi("{\\mu}")#text(" sufficiently close to zero, and the claim now follows from Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("8")]#text(".")

#text("Now suppose instead that we are in the “Type II” regime where ")#link(<tao-628b49d96dcde97a430d>)[#text("(49)")]#text(" fails for some small ")#mi("{c^{\\prime}>0}")#text(", so that by ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("x^{1/2-2\\varpi-c^{\\prime}} \\ll N \\ll M \\ll x^{1/2+2\\varpi+c^{\\prime}}.")]]

#text("From this we see that we may replace ")#mi("{\\sigma}")#text(" by ")#mi("{2\\varpi+c^{\\prime}}")#text(" in ")#link(<tao-cd58add90c5a1937a32b>)[#text("(14)")]#text(" and in all of the above analysis. If we set ")#mi("{\\mu := 2\\varpi + c^{\\prime}}")#text(" then the conditions ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(30)")]#text(", ")#link(<tao-f45610b06fe1da76ca5b>)[#text("(39)")]#text(" are obeyed (again taking ")#mi("{c}")#text(" small enough). Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("9")]#text(" will then give us what we want provided that")

#align(center)[#tao-fit-display[#mitex("24\\varpi + 7 (2\\varpi+c^{\\prime}) + 7 \\delta + 5 (2\\varpi+c^{\\prime}) < \\frac{1}{2}")]]

#text("which is satisfied for ")#mi("{c^{\\prime}}")#text(" small enough thanks to ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(12)")]#text(".")

#text("In the next two sections we establish Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("8")]#text(" and Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("9")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. The Type I sum — ")]]

#text("We now prove Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("8")]#text(". It suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_h \\sum_{q_1,q_2 \\sim Q} c_{h,q_1,q_2} \\sum_{n} \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n)\\right| \\lessapprox x^{-\\epsilon} Q^2 N", block: true)]]

#text("for any bounded real coefficients ")#mi("{c_{h,q_1,q_2} = O(1)}")#text(". Performing the manipulations from Section 6 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", we reduce to showing that ")#metadata(none) <tao-5c255f4c58718acd41ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#mitex("\\sum_{h,h^{\\prime}} \\sum_{q_2,q^{\\prime}_2 \\sim Q} |\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}| \\lessapprox x^{-2\\epsilon} Q^2 N")]]

#text("for any ")#mi("{q_1 \\sim Q}")#text(".")

#text("To prove ")#link(<tao-5c255f4c58718acd41ac>)[#text("(51)")]#text(", we isolate the ")#emph[#text("diagonal case")]#text(" ")#mi("{h^{\\prime}q_2 = hq^{\\prime}_2}")#text(" and the ")#emph[#text("non-diagonal case")]#text(" ")#mi("{h^{\\prime}q_2 \\neq h q^{\\prime}_2}")#text(". For the diagonal case, we argue as in Section 6 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("the previous post")]#text(" and reduce to verifying that")

#align(center)[#tao-fit-display[#mitex("QR \\lessapprox x^{-3\\varepsilon} M")]]

#text("but this follows from ")#link(<tao-2617708489831f17c7b6>)[#text("(33)")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("(49)")]#text(" for ")#mi("{\\epsilon}")#text(" small enough.")

#text("Now we treat the non-diagonal case ")#mi("{h^{\\prime}q_2 \\neq hq^{\\prime}_2}")#text(". The key estimate here is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" ")#metadata(none) <tao-5a19de5f6c425600990f>#text(" In the non-diagonal case ")#mi("{h^{\\prime}q_2 \\neq hq^{\\prime}_2}")#text(", we have ")#metadata(none) <tao-4a0ba3b5a21b0257fa9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox N^{1/2} Q^{1/4} R^{1/4} + N^{1/2} Q + R^{-1/4} N (hq^{\\prime}_2-h^{\\prime}q_2,r)^{1/4}.")]]
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(45)")]#text(" we may of course assume that")

#align(center)[#tao-fit-display[#mitex("(q_1,r) = (q_2,r) = (q_1,q_2) = (q^{\\prime}_2,r) = (q_1,q^{\\prime}_2) = 1.")]]

#text("Arguing as in Section 6 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", we may write the left-hand side of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(52)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{n} \\psi_N(n) 1_{(n,d_1) = (n+kr,d_2)=1} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+kr} )\\right|", block: true)]]

#text("where ")#mi("{d_1 := q_1 r}")#text(", ")#mi("{d_2 := [q_2, q^{\\prime}_2]}")#text(", and ")#mi("{c_1,c_2}")#text(" are integers with ")#metadata(none) <tao-21876c22edad493502a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(53)")])
#mitex("(c_1, r) = (hq^{\\prime}_2-h^{\\prime}q_2, r).")]]

#text("Now for the new input that was not present in the previous Type I analysis. Applying Proposition 5(iii) from ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("this previous post")]#text(", and noting that ")#mi("{D_1,d_2}")#text(" are coprime, we can bound the left-hand side of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(52)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\lessapprox N^{1/2} d_1^{1/4} +N^{1/2} d_2^{1/2} + \\frac{(c_1,d_1)^{1/4}}{d_1^{1/4}} N.")]]

#text("Since ")#mi("{d_1 \\ll QR}")#text(", ")#mi("{d_2 \\ll Q^2}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\frac{(c_1,d_1)^{1/4}}{d_1^{1/4}} \\leq \\frac{(c_1,r)^{1/4}}{r^{1/4}} = \\frac{(hq^{\\prime}_2-h^{\\prime}q_2,r)^{1/4}}{r^{1/4}}")]]

#text("the claim follows. ")#mi("\\Box")

#text("Note from the divisor bound that for each choice of ")#mi("{h,q^{\\prime}_2}")#text(" and ")#mi("{a = O(HQ)}")#text(", there are ")#mi("{\\lessapprox 1}")#text(" choices of ")#mi("{h^{\\prime}, q_2}")#text(" such that ")#mi("{hq^{\\prime}_2 - h^{\\prime}q_2 = a}")#text(". From this and Lemma 5 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{h,h^{\\prime}} \\sum_{q_2,q^{\\prime}_2 \\sim Q} (hq^{\\prime}_2-h^{\\prime}q_2,r) 1_{hq^{\\prime}_2 \\neq h^{\\prime}q_2} \\lessapprox H^2 Q^2")]]

#text("and thus also if ")#mi("{(hq^{\\prime}_2-h^{\\prime}q_2,r)}")#text(" is replaced by ")#mi("{(hq^{\\prime}_2-h^{\\prime}q_2,r)^{1/4}}")#text(". From this and Lemma ")#link(<tao-5a19de5f6c425600990f>)[#text("10")]#text(" we see that the non-diagonal contribution to ")#link(<tao-5c255f4c58718acd41ac>)[#text("(51)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^2 Q^2 ( N^{1/2} Q^{1/4} R^{1/4} + N^{1/2} Q + R^{-1/4} N )")]]

#text("so to conclude ")#link(<tao-5c255f4c58718acd41ac>)[#text("(51)")]#text(" we need to show that")

#align(center)[#tao-fit-display[#mitex("H^2 Q^{9/4} R^{1/4} N^{1/2} \\lessapprox x^{-2\\epsilon} Q^2 N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H^2 Q^3 N^{1/2} \\lessapprox x^{-2\\epsilon} Q^2 N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H^2 Q^2 R^{-1/4} N \\lessapprox x^{-2\\epsilon} Q^2 N")]]

#text("Using ")#link(<tao-a81ffb258bff4eddc451>)[#text("(44)")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(13)")]#text(" we can rewrite these criteria as")

#align(center)[#tao-fit-display[#mitex("(QR)^{17/4} \\lessapprox x^{2-4\\epsilon} N^{1/2} (R/N)^2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(QR)^5 \\lessapprox x^{2-4\\epsilon} N^{3/2} (R/N)^3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(QR)^4 \\lessapprox x^{2-4\\epsilon} N^{1/4} (R/N)^{9/4}")]]

#text("respectively. Applying ")#link(<tao-2617708489831f17c7b6>)[#text("(33)")]#text(", ")#link(<tao-375676bd26868505668f>)[#text("(32)")]#text(", it suffices to verify that")

#align(center)[#tao-fit-display[#mitex("\\frac{17}{4} (\\frac{1}{2} + 2 \\varpi) < 2 + \\frac{1}{2} ( \\frac{1}{2}-\\sigma ) - 2 (\\mu + \\delta)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("5 (\\frac{1}{2} + 2 \\varpi) < 2 + \\frac{3}{2} ( \\frac{1}{2}-\\sigma ) - 3 (\\mu + \\delta)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("4 (\\frac{1}{2} + 2 \\varpi) < 2 + \\frac{1}{4} ( \\frac{1}{2}-\\sigma ) - \\frac{9}{4} (\\mu + \\delta).")]]

#text("respectively. These rearrange to ")#link(<tao-7c25b82c0ab03b1bca18>)[#text("(46)")]#text(", ")#link(<tao-9a370ebd95136e8b2036>)[#text("(47)")]#text(", ")#link(<tao-22b1f82e804e2c285b47>)[#text("(48)")]#text(" respectively, and the claim follows.")

#heading(level: 1)[#strong[#text(" — 4. The Type II sum — ")]]

#text("We now prove Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("9")]#text(". Arguing as in Section 7 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", it suffices to show that ")#metadata(none) <tao-f700da657a0e05cabc98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#tao-math("\\sum_{h,h^{\\prime}} \\sum_{q_1, q^{\\prime}_1, q_2,q^{\\prime}_2 \\sim Q} \\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q^{\\prime}_1,q^{\\prime}_2;n)}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^{-2\\epsilon} Q^4 N.")]]

#text("As in ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("the previous post")]#text(", the diagonal case ")#mi("{h^{\\prime}q_1 q_2 = h q^{\\prime}_1 q^{\\prime}_2}")#text(" is acceptable provided that")

#align(center)[#tao-fit-display[#mitex("R \\ll x^{-3\\epsilon+o(1)} M,")]]

#text("but this is automatic from ")#link(<tao-375676bd26868505668f>)[#text("(32)")]#text(" and ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(30)")]#text(" if ")#mi("{\\epsilon}")#text(" is small enough.")

#text("We have the following analogue of Lemma ")#link(<tao-5a19de5f6c425600990f>)[#text("10")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" In the off-diagonal case ")#mi("{h^{\\prime}q_1q_2 \\neq h q^{\\prime}_1 q^{\\prime}_2}")#text(", we have ")#metadata(none) <tao-a5a678fbc88d625d311d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(55)")])
#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q^{\\prime}_1,q^{\\prime}_2;n)}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^{2} R^{1/2} + R^{-1} N (hq^{\\prime}_1q^{\\prime}_2-h^{\\prime}q_1q_2,r)")]]
]

#text("This is an improved version of the estimate (48) from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(" in which several inefficiencies in the second term on the right-hand side have been removed.")

#emph[#text("Proof:")]#text(" From ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(45)")]#text(" we may assume")

#align(center)[#tao-fit-display[#mitex("(q_1,r) = (q^{\\prime}_1,r) = (q_2,r) = (q^{\\prime}_2,r) = (q_1,q_2) = (q^{\\prime}_1,q^{\\prime}_2) = 1")]]

#text("and by the arguments from the previous post we may rewrite the left-hand side of ")#link(<tao-a5a678fbc88d625d311d>)[#text("(55)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{n} \\psi_N(n) 1_{(n,d_1) = (n+kr,d_2)=1} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+kr} ) \\right|", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("d_1 := [q_1,q^{\\prime}_1]r; \\quad d_2 := [q_2,q^{\\prime}_2]")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(c_1, r) = (hq^{\\prime}_1q^{\\prime}_2-h^{\\prime}q_1q_2, r).")]]

#text("By Proposition 5(ii) of ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("this previous post")]#text(", we may the bound this quantity by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox [d_1,d_2]^{1/2} + \\frac{N}{d_1 d_2} (d_1,d_2)^2 (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2)")]]

#text("where ")#mi("{d^{\\prime}_1:= d_1/(d_1,d_2)}")#text(", ")#mi("{d^{\\prime}_2 := d_2/(d_1,d_2)}")#text(". We may bound")

#align(center)[#tao-fit-display[#mitex("\\frac{N}{d_1 d_2} (d_1,d_2)^2 (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2) \\leq N \\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\leq N \\frac{(c_1,r)}{r}")]]

#text("since ")#mi("{r}")#text(" divides ")#mi("{d_1}")#text(" but is coprime to ")#mi("{d_2}")#text(", and the claim follows. ")#mi("\\Box")

#text("Arguing as in the previous section we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{h,h^{\\prime}} \\sum_{q_1, q^{\\prime}_1, q_2,q^{\\prime}_2 \\sim Q} 1_{hq^{\\prime}_1q^{\\prime}_2 \\neq h^{\\prime}q_1q_2} (hq^{\\prime}_1q^{\\prime}_2-h^{\\prime}q_1q_2,r) \\lessapprox H^2 Q^4")]]

#text("and so the off-diagonal contribution to ")#link(<tao-f700da657a0e05cabc98>)[#text("(54)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^2 Q^6 R^{1/2} + H^2 Q^4 R^{-1} N.")]]

#text("To conclude ")#link(<tao-f700da657a0e05cabc98>)[#text("(54)")]#text(" we thus need to show that")

#align(center)[#tao-fit-display[#mitex("H^2 Q^6 R^{1/2} \\lessapprox x^{-2\\epsilon} Q^4 N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H^2 Q^4 R^{-1} N \\lessapprox x^{-2\\epsilon} Q^4 N.")]]

#text("Using ")#link(<tao-a81ffb258bff4eddc451>)[#text("(44)")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(13)")]#text(" we can rewrite these criteria as")

#align(center)[#tao-fit-display[#mitex("(QR)^6 \\lessapprox x^{2-4\\epsilon} N^{5/2} (R/N)^{7/2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(QR)^4 \\lessapprox x^{2-4\\epsilon} N (R/N)^3")]]

#text("respectively. Applying ")#link(<tao-2617708489831f17c7b6>)[#text("(33)")]#text(", ")#link(<tao-375676bd26868505668f>)[#text("(32)")]#text(", it suffices to verify that")

#align(center)[#tao-fit-display[#mitex("6 (\\frac{1}{2} + 2 \\varpi) < 2 + \\frac{5}{2} ( \\frac{1}{2}-\\sigma ) - \\frac{7}{2} (\\mu + \\delta)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("4 (\\frac{1}{2} + 2 \\varpi) < 2 + ( \\frac{1}{2}-\\sigma ) - 3 (\\mu + \\delta)")]]

#text("which can be rearranged as")

#align(center)[#tao-fit-display[#mitex("24 \\varpi + 7 \\mu + 7 \\delta + 5 \\sigma < 1/2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("8 \\varpi + 3 \\mu + 3 \\delta + \\sigma <1/2")]]

#text("respectively, and thus both follow from ")#link(<tao-ab830477ec5ce7877333>)[#text("(50)")]#text(".")

#heading(level: 1)[#strong[#text(" — 5. The Type III estimate — ")]]

#text("Now we prove Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("7")]#text(". Our arguments will closely track those of Section 2 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(", except that we will carry the ")#mi("{\\alpha}")#text(" averaging with us for significantly longer in the argument.")

#text("Let ")#mi("{\\varpi,\\delta,N_1,N_2,N_3,M,\\alpha,\\psi_1,\\psi_2,\\psi_3}")#text(" obey the hypotheses of the theorem. It will suffice to establish the bound ")#metadata(none) <tao-256b93a925d9f71f4db0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(56)")])
#tao-math("\\left|\\Delta(\\alpha \\ast \\psi_1 \\ast \\psi_2 \\ast \\psi_3; a)\\right| \\lessapprox x^{-\\epsilon} \\frac{x}{d}", block: true)]]

#text("for all ")#mi("{d \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}}")#text(" with ")#mi("{d < x^{1/2+2\\varpi}}")#text(" and all ")#mi("{a \\in ({\\bf Z}/d{\\bf Z})^\\times}")#text(", and some sufficiently fixed ")#mi("{\\epsilon>0}")#text(".")

#text("Fix ")#mi("{d}")#text(". It suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = a\\ (d)} \\psi_1 \\ast \\psi_2 \\ast \\alpha \\ast \\psi_3(n) = X + O( x^{-\\epsilon+o(1)} \\frac{x}{d} )")]]

#text("for some ")#mi("{X}")#text(" that does not depend on ")#mi("{a}")#text(". Applying completion of sums, we can express the left-hand side as the main term")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{d} (\\sum_{n_1} \\psi_1(n_1)) (\\sum_{n: (n,d)=1} \\psi_2 \\ast \\alpha \\ast \\psi_3(n))")]]

#text("plus the error terms")

#align(center)[#tao-fit-display[#tao-math("O( (\\log^{O(1)} x) \\frac{N_1}{d} \\sum_{1 \\leq h \\le H} \\left|\\sum_{n: (n,d)=1} \\psi_2 \\ast \\alpha \\ast \\psi_3(n) e_d( \\frac{ah}{n} )\\right| )", block: true)]]

#text("and a tiny error")

#align(center)[#tao-fit-display[#mitex("O( x^{-A+ O(1)} )")]]

#text("for any fixed ")#mi("{A>0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("H := x^\\epsilon \\frac{d}{N_1}.")]]

#text("It thus suffices to show that ")#metadata(none) <tao-2e75a349e53c2d190fc6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(57)")])
#mitex("\\sum_{1 \\leq h \\le H} |\\sum_{n: (n,d)=1} \\psi_2 \\ast \\alpha \\ast \\psi_3(n) e_d( \\frac{ah}{n} ) | \\lessapprox x^{-\\epsilon} M N_2 N_3.")]]

#text("it will suffice to prove the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" ")#metadata(none) <tao-6446d58d6dfafd58586d>#text(" Let ")#mi("{\\delta>0}")#text(" be fixed, and let ")#metadata(none) <tao-2b59b6a04f3b9ba1d7b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(58)")])
#mitex("H, N_2, N_3, d, B \\gg 1")]]

#text("be such that ")#mi("{d}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible and ")#metadata(none) <tao-60c2d799bb894ebfab8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(59)")])
#mitex("H \\lessapprox x^{\\epsilon} \\frac{d}{N_2}")]]

#text("and ")#metadata(none) <tao-b5587bfd231a74fd2aa1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(60)")])
#mitex("M N_2^4 N_3^5 \\gtrapprox B^{-6} d^4 H^4 x^{\\delta+c}")]]

#text("and ")#metadata(none) <tao-3b0cfb1c3107678644bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(61)")])
#mitex("N_2^3 N_3^4 \\gtrapprox B^{-4} d^3 H^3 x^{\\delta+c}")]]

#text("and ")#metadata(none) <tao-e5589804b070def4acb5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(62)")])
#mitex("N_2 \\gtrapprox H x^c")]]

#metadata(none) <tao-99a2fcae60933394aa75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(63)")])
#mitex("M N_2^2 N_3 \\gtrapprox B^{-2} d H^2 x^c")]]

#text("for some fixed ")#mi("{c>0}")#text(", and let ")#mi("{\\psi_2,\\psi_3}")#text(" be smooth coefficient sequences at scale ")#mi("{N_2,N_3}")#text(" respectively. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h \\le H: (h,d)=1} |\\sum_{n: (n,d)=1} \\psi_2 \\ast \\alpha \\ast \\psi_3(n) e_d( \\frac{ah}{n} ) | \\lessapprox x^{-\\epsilon} B M N_2 N_3")]]

#text("if ")#mi("{\\epsilon}")#text(" is sufficiently small.")
]

#text("Let us now see why the above proposition implies ")#link(<tao-2e75a349e53c2d190fc6>)[#text("(57)")]#text(". To prove ")#link(<tao-2e75a349e53c2d190fc6>)[#text("(57)")]#text(", we may of course assume ")#mi("{H \\geq 1}")#text(" as the claim is trivial otherwise. We can split")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h \\leq H} F(h) = \\sum_{d = d_1 d_2} \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h^{\\prime},d_1)=1} F( d_2 h^{\\prime} )")]]

#text("for any function ")#mi("{F(h)}")#text(" of ")#mi("{h}")#text(", so that ")#link(<tao-2e75a349e53c2d190fc6>)[#text("(57)")]#text(" can be written as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d = d_1 d_2} \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h^{\\prime},d_1)=1} \\left|\\sum_{n: (n,d_1 d_2)=1} \\psi_2 \\ast \\alpha \\ast \\psi_3(n) e_{d_1}( \\frac{ah^{\\prime}}{n} )\\right|", block: true)]]

#text("which we expand as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d = d_1 d_2} \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h^{\\prime},d_1)=1} |\\sum_{m: (m,d_1 d_2)=1} \\alpha(m) \\sum_{n_2: (n_2,d_1 d_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d_1d_2)=1} \\psi_2(n_2) \\psi_3(n_3) e_{d_1}( \\frac{ah^{\\prime}}{mn_2 n_3} )|")]]

#text("In order to apply Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("12")]#text(" we need to modify the ")#mi("{(n_2,d_1d_2)=1}")#text(", ")#mi("{(n_3,d_1d_2)=1}")#text(" constraints. By Möbius inversion one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_2: (n_2,d_1d_2)=1} F(n_2) = \\sum_{b_2|d_2} \\mu(b_2) \\sum_{n_2: (n_2,d_1)=1} F(b_2 n_2)")]]

#text("for any function ")#mi("{F}")#text(", and similarly for ")#mi("{n_3}")#text(", so by the triangle inequality we may bound the previous expression by ")#metadata(none) <tao-34707c3f40dfa20c3902>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(64)")])
#mitex("\\sum_{d = d_1 d_2} \\sum_{b_2|d_2} \\sum_{b_3|d_2} F( d_1, d_2, b_1, b_2 )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(d_1,d_2,b_1,b_2) := \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h^{\\prime},d_1)=1}")]]

#align(center)[#tao-fit-display[#mitex("|\\sum_{m: (m,d_1d_2)=1} \\alpha(m) \\sum_{n_2: (n_2,d_1)=1} \\sum_{n_3: (n_3,d_1)=1} \\psi_2(b_2n_2) \\psi_3(b_3n_3)")]]

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{ah^{\\prime}}{mb_2b_3 n_2 n_3} )|")]]

#text("We may discard those values of ")#mi("{d_2}")#text(" for which ")#mi("{H^{\\prime} := H/d_2}")#text(" is less than one, as the summation is vacuous in that case. We then apply Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("(12)")]#text(" with ")#mi("{d,N_2,N_3,H}")#text(" replaced by ")#mi("{d_1,N_2/b_2,N_3/b_3,H^{\\prime}}")#text(" respectively (but with ")#mi("{M}")#text(" unchanged), ")#mi("{\\alpha}")#text(" replaced with its restriction to values coprime to ")#mi("{d_1,d_2}")#text(", and ")#mi("{B}")#text(" set equal to ")#mi("{b_2 b_3}")#text(", ")#mi("{x^\\delta}")#text(" replaced by ")#mi("{d_2 x^\\delta}")#text(", and ")#mi("{\\psi_2,\\psi_3}")#text(" replaced by ")#mi("{\\psi_2(b_2\\cdot)}")#text(" and ")#mi("{\\psi_3(b_3\\cdot)}")#text(". One can check that all the hypotheses of Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("12")]#text(" are obeyed (with ")#link(<tao-b5587bfd231a74fd2aa1>)[#text("(60)")]#text(" coming from ")#link(<tao-620090ec13bea1af7472>)[#text("(15)")]#text(", ")#link(<tao-3b0cfb1c3107678644bd>)[#text("(61)")]#text(" coming from ")#link(<tao-4eff9a56e3f01b24ef14>)[#text("(16)")]#text(", and ")#link(<tao-e5589804b070def4acb5>)[#text("(62)")]#text(", ")#link(<tao-99a2fcae60933394aa75>)[#text("(63)")]#text(" coming from ")#link(<tao-dedcfe5dabd7a56fba00>)[#text("(17)")]#text("), so we may bound ")#link(<tao-34707c3f40dfa20c3902>)[#text("(64)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^{-\\epsilon} M N_2 N_3 \\sum_{d = d_1 d_2} \\sum_{b_2|d_2} \\sum_{b_3|d_2} 1")]]

#text("which by the divisor bound is ")#mi("{\\lessapprox x^{-\\epsilon} M N_2 N_3}")#text(", which is acceptable.")

#text("It remains to prove Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("12")]#text(". Note from ")#link(<tao-2b59b6a04f3b9ba1d7b9>)[#text("(58)")]#text(", ")#link(<tao-60c2d799bb894ebfab8c>)[#text("(59)")]#text(" one has ")#metadata(none) <tao-f998fe06afa0cfbe73e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(65)")])
#mitex("d \\gg x^{-\\epsilon} N_2.")]]

#text("Expanding out the ")#mi("{\\psi_2 \\ast \\psi_3}")#text(" convolution, our task is to show that ")#metadata(none) <tao-07d715edb696fb5f628f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(66)")])
#tao-math("\\sum_{1 \\leq h \\le H: (h,d)=1} \\left|\\sum_{n_2: (n_2,d)=1} \\sum_{n_3: (n_3,d)=1} \\psi_2(n_2) (\\alpha \\ast \\psi_3)(n_3) e_d( \\frac{ah}{n_2n_3} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{-\\epsilon} B MN_2 N_3.")]]

#text("The next step is Weyl differencing. We will need a step size ")#mi("{r \\geq 1}")#text(" which we will optimise in later. We set ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(67)")])
#mitex("K := \\lfloor x^{-\\epsilon} N_2 r^{-1} H^{-1}\\rfloor;")]]

#text("we will make the hypothesis that ")#metadata(none) <tao-3e11b6c3eef5d583d7be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(68)")])
#mitex("K \\geq 1")]]

#text("and save this condition to be verified later.")

#text("By shifting ")#mi("{n_2}")#text(" by ")#mi("{khr}")#text(" for ")#mi("{1 \\leq k \\leq K}")#text(" and then averaging, we may write the left-hand side of ")#link(<tao-07d715edb696fb5f628f>)[#text("(66)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h \\le H: (h,d)=1} |\\frac{1}{K} \\sum_{1 \\leq k \\leq K} \\sum_{n_2: (n_2,d)=1} \\sum_{n_3: (n_3,d)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\psi_2(n_2+hkr) (\\alpha \\ast \\psi_3)(n_3) e_d( \\frac{ah}{(n_2+hkr)n_3} )|.")]]

#text("By the triangle inequality, it thus suffices to show that ")#metadata(none) <tao-65cc63a4e10ee8f05be4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(69)")])
#mitex("\\sum_{1 \\leq h \\leq H: (h,d)=1} \\sum_{n_2: (n_2,d)=1} |\\sum_{1 \\leq k \\leq K} \\psi_2(n_2+hkr)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d)=1} (\\alpha \\ast \\psi_3)(n_3) e_d( \\frac{ah}{(n_2+hkr)n_3} )| \\ll x^{-\\epsilon} B K M N_2 N_3.")]]

#text("Next, we combine the ")#mi("{h}")#text(" and ")#mi("{n_2}")#text(" summations into a single summation over ")#mi("{{\\bf Z}/d{\\bf Z}}")#text(". We first use a Taylor expansion and ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(67)")]#text(" to write")

#align(center)[#tao-fit-display[#mitex("\\psi_2(n_2+hkr) = \\sum_{j=0}^J \\frac{1}{j!} (h/H)^j N_2^{j} \\psi_2^{(j)}(n_2) (Hkr/N_2)^j + O( x^{-J\\epsilon+o(1)})")]]

#text("for any fixed ")#mi("{J}")#text(". If ")#mi("{J}")#text(" is large enough, then the error term will be acceptable, so it suffices to establish ")#link(<tao-65cc63a4e10ee8f05be4>)[#text("(69)")]#text(" with ")#mi("{\\psi_2(n_2+hkr)}")#text(" replaced by ")#mi("{(h/H)^j N_2^j \\psi_2^{(j)}(n_2) (hkr/N_2)^j}")#text(" for any fixed ")#mi("{j \\geq 0}")#text(". We can rewrite")

#align(center)[#tao-fit-display[#mitex("e_d( \\frac{ah}{(n_2+hkr)n_3} ) = e_d( \\frac{a}{(l+kr) n_3} )")]]

#text("where ")#mi("{l \\in {\\bf Z}/d{\\bf Z}}")#text(" is such that ")#mi("{(l+kr,d)=1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("l = \\frac{n_2}{h}\\ (d).")]]

#text("Thus we can estimate the left-hand side of ")#link(<tao-65cc63a4e10ee8f05be4>)[#text("(69)")]#text(" by ")#metadata(none) <tao-305f2522484988d66f36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(70)")])
#mitex("\\sum_{l \\in {\\bf Z}/d{\\bf Z}} \\nu(l) |\\sum_{1 \\leq k \\leq K: (l+kr,d)=1} (Hkr/N_2)^j")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d)=1} (\\alpha \\ast \\psi_3)(n_3) e_d( \\frac{a}{(l+kr) n_3})|")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\nu(l) := \\sum_{1 \\leq h \\leq H: (h,d)=1} \\sum_{n_2} 1_{l = \\frac{n_2}{h}\\ (d)} N_2^j |\\psi_2^{(j)}(n_2)|.")]]

#text("Here we have bounded ")#mi("{(h/H)^j}")#text(" by ")#mi("{O(1)}")#text(".")

#text("We will eliminate the ")#mi("{\\nu}")#text(" expression via Cauchy-Schwarz. Observe from the smoothness of ")#mi("{\\psi_2}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\nu(l) \\ll x^{o(1)} \\left|\\{ (h,n_2): 1 \\leq h \\leq H; 1 \\ll n_2 \\ll N_2; (h,d)=1; l = \\frac{n_2}{h}\\ (d) \\}\\right|", block: true)]]

#text("and thus")

#tao-aligned(keep: true)[


#tao-math("\\sum_l \\nu(l)^2  & \\ll x^{o(1)} |\\{ (h,h^{\\prime},n_2,n^{\\prime}_2): 1 \\leq h,h^{\\prime} \\leq H; 1\\ll n_2,n^{\\prime}_2 \\ll N_2;", block: true)



#tao-math("(h,d) & =(h^{\\prime},d) = 1; \\frac{n_2}{h} = \\frac{n^{\\prime}_2}{h^{\\prime}}\\ (d) \\}|.", block: true)
]

#text("Note that ")#mi("{\\frac{n_2}{h} = \\frac{n^{\\prime}_2}{h^{\\prime}}\\ (d)}")#text(" implies ")#mi("{n_2 h^{\\prime} = n^{\\prime}_2 h\\ (d)}")#text(". But from ")#link(<tao-60c2d799bb894ebfab8c>)[#text("(59)")]#text(" we have ")#mi("{1 \\leq n_2 h^{\\prime}, n^{\\prime}_2 h \\ll x^\\epsilon d}")#text(", so in fact we have ")#mi("{n_2 h^{\\prime} = n^{\\prime}_2 h + k d}")#text(" for some ")#mi("{k = O(x^\\epsilon)}")#text(". Thus")

#tao-aligned(keep: true)[


#tao-math("\\sum_l \\nu(l)^2  & \\ll x^{\\epsilon+o(1)} |\\{ (h,h^{\\prime},n_2,n^{\\prime}_2): 1 \\leq h^{\\prime} \\leq H; 1\\ll n_2 \\ll N_2;", block: true)



#tao-math("n_2 h^{\\prime}  & = n^{\\prime}_2 h + k d \\text{ for some } k = O(x^\\epsilon)\\}|.", block: true)
]

#text("From the divisor bound, we see that for each fixed ")#mi("{n_2, h^{\\prime}}")#text(" there are ")#mi("{O(x^{\\epsilon+o(1)})}")#text(" choices for ")#mi("{n^{\\prime}_2,h}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_l \\nu(l)^2 \\lessapprox x^{\\epsilon} N_2 H.")]]

#text("From this, ")#link(<tao-305f2522484988d66f36>)[#text("(70)")]#text(", and Cauchy-Schwarz, we see that to prove ")#link(<tao-65cc63a4e10ee8f05be4>)[#text("(69)")]#text(" it will suffice to show that ")#metadata(none) <tao-0fb532081657b0142eaa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(71)")])
#mitex("\\sum_{l \\in {\\bf Z}/d{\\bf Z}} |\\sum_{1 \\leq k \\leq K: (l+kr,d)=1} (Hkr/N_2)^j")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d)=1} (\\alpha \\ast \\psi_3)(n_3) e_d( \\frac{a}{(l+kr) n_3})|^2")]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{-3\\epsilon} B^{2} K^2 M^2 N_2 N_3^2 H^{-1}.")]]

#text("We square out ")#link(<tao-0fb532081657b0142eaa>)[#text("(71)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq k,k^{\\prime} \\leq K}\\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l+kr,d)=(l+k^{\\prime}r,d)=1} (Hkr/N_2)^j (Hk^{\\prime}r/N_2)^j")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m,m^{\\prime}: (mm^{\\prime},d)=1} \\alpha(m) \\overline{\\alpha(m^{\\prime})}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3,n^{\\prime}_3: (n_3,d)=(n^{\\prime}_3,d)=1} \\psi_3(n_3) \\overline{\\psi_3}(n^{\\prime}_3) e_d( \\frac{a}{(l+kr)mn_3)} - \\frac{a}{(l+k^{\\prime}r)m^{\\prime}n^{\\prime}_3} ).")]]

#text("If we shift ")#mi("{l}")#text(" by ")#mi("{kr}")#text(", then relabel ")#mi("{k^{\\prime}-k}")#text(" by ")#mi("{k}")#text(", and use the fact that ")#mi("{Hkr/N_2, Hk^{\\prime}r/N_2 = O(1)}")#text(", we can reduce this to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K}", block: true)]]

#align(center)[#tao-fit-display[#mitex("|\\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+kr,d)=1} \\sum_{n_3,n^{\\prime}_3: (n_3,d)=(n^{\\prime}_3,d)=1} \\sum_{m,m^{\\prime}: (mm^{\\prime},d)=1} \\alpha(m) \\overline{\\alpha(m^{\\prime})}")]]

#align(center)[#tao-fit-display[#mitex("\\psi_3(n_3) \\overline{\\psi_3}(n^{\\prime}_3) e_d( \\frac{a}{lmn_3} - \\frac{a}{(l+kr)m^{\\prime} n^{\\prime}_3} )|")]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{-3\\epsilon} M^2 B^{2} K N_2 N_3^2 H^{-1}.")]]

#text("Next we perform another completion of sums, this time in the ")#mi("{n_3,n^{\\prime}_3}")#text(" variables, to bound")

#align(center)[#tao-fit-display[#mitex("|\\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+kr,d)=1} \\sum_{n_3,n^{\\prime}_3: (n_3,d)=(n^{\\prime}_3,d)=1} \\sum_{m,m^{\\prime}: (mm^{\\prime},d)=1} \\alpha(m) \\overline{\\alpha(m^{\\prime})}")]]

#align(center)[#tao-fit-display[#mitex("\\psi_3(n_3) \\overline{\\psi_3}(n^{\\prime}_3) e_d( \\frac{a}{lmn_3} - \\frac{a}{(l+kr)m^{\\prime}n^{\\prime}_3} )|")]]

#text("by")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\ll M: (mm^{\\prime},d)=1} \\sum_{\\left|t\\right|, \\left|t^{\\prime}\\right| \\leq M^{\\prime}} (\\frac{N_3}{d})^2 \\left| U(k; t,t^{\\prime}; m,m^{\\prime}; d)\\right|+ x^{-A}", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#metadata(none) <tao-b1f629a0f2f7f9718531>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(72)")])
#mitex("M^{\\prime} := x^{\\epsilon} \\frac{d}{N_3}")]]

#text("(the prime is there to distinguish this quantity from ")#mi("{M}")#text(") and")

#align(center)[#tao-fit-display[#mitex("U(k;t,t^{\\prime};m,m^{\\prime};d) := \\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+kr,d)=1} \\sum_{n_3,n^{\\prime}_3 \\in ({\\bf Z}/d{\\bf Z})^\\times}")]]

#align(center)[#tao-fit-display[#mitex("e_d( \\frac{a}{lmn_3} - \\frac{a}{(l+kr)m^{\\prime}n^{\\prime}_3} + tn_3 - t^{\\prime} n^{\\prime}_3).")]]

#text("Making the change of variables ")#mi("{u := \\frac{a}{mn_3}\\ (d)}")#text(" and ")#mi("{u^{\\prime} := \\frac{a}{m^{\\prime}n^{\\prime}_3}\\ (d)}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("U(k;t,t^{\\prime};m,m^{\\prime};d) = T( kr; at/m, at^{\\prime}/m^{\\prime}; d)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("T(k; m,m^{\\prime}; q) := \\sum_{l \\in {\\bf Z}/q{\\bf Z}: (l,q)=(l+k,q)=1} \\sum_{u \\in ({\\bf Z}/q{\\bf Z})^\\times} \\sum_{u^{\\prime} \\in ({\\bf Z}/q{\\bf Z})^\\times}")]]

#align(center)[#tao-fit-display[#mitex("e_q( \\frac{u}{l} - \\frac{u^{\\prime}}{l+k} + \\frac{m}{u} - \\frac{m^{\\prime}}{u^{\\prime}} ).")]]

#text("Applying the Bombieri-Birch bound (Theorem 4 from this ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("previous post")]#text("), and recalling that ")#mi("{a \\in ({\\bf Z}/d{\\bf Z})^\\times}")#text(", we reduce to showing that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\leq M: (mm^{\\prime},d)=1} \\sum_{\\left|t\\right|, \\left|t^{\\prime}\\right| \\leq M^{\\prime}} \\frac{(kr,t/m-t^{\\prime}/m^{\\prime},d)}{(kr,d)^{1/2}} (\\frac{N_3}{d})^2 d^{3/2}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^{-4\\epsilon} B^{2} K M^2 N_2 N_3^2 H^{-1}.")]]

#text("We may cross multiply and write")

#align(center)[#tao-fit-display[#mitex("(kr,t/m-t^{\\prime}/m^{\\prime},d) = (kr,tm^{\\prime}-t^{\\prime}m,d).")]]

#text("By the divisor bound, for each choice of ")#mi("{t,m^{\\prime}}")#text(" and ")#mi("{tm^{\\prime}-t^{\\prime}m}")#text(" there is ")#mi("{\\lessapprox 1}")#text(" choices for ")#mi("{t^{\\prime}}")#text(" and ")#mi("{m}")#text(". Thus it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("MM^{\\prime} \\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|b\\right| \\ll MM^{\\prime}} \\frac{(kr,b,d)}{(kr,d)^{1/2}} (\\frac{N_3}{d})^2 d^{3/2} \\lessapprox x^{-4\\epsilon} B^{2} K M^2 N_2 N_3^2 H^{-1}.", block: true)]]

#text("We now choose ")#mi("{r}")#text(" to be a factor of ")#mi("{d}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("d = qr")]]

#text("for some ")#mi("{q}")#text(" coprime to ")#mi("{r}")#text(". We compute the sum on the left-hand side:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13")]#text(" If ")#mi("{r|d}")#text(", then we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|b\\right| \\ll MM^{\\prime}} \\frac{(kr,b,d)}{(kr,d)^{1/2}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox ( r^{1/2} K + d^{1/2} + MM^{\\prime} K r^{-1/2} ).")]]
]

#emph[#text("Proof:")]#text(" We first consider the contribution of the diagonal case ")#mi("{b=0}")#text(". This term may be estimated by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\sum_{\\left|k\\right| \\leq K} (kr,d)^{1/2} = r^{1/2} \\sum_{\\left|k\\right| \\leq K} (k,q)^{1/2}.", block: true)]]

#text("The ")#mi("{k=0}")#text(" term gives ")#mi("{d^{1/2}}")#text(", while the contribution of the non-zero ")#mi("{k}")#text(" are also acceptable by Lemma 5 from ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(".")

#text("For the non-diagonal case ")#mi("{b \\neq 0}")#text(", we see from Lemma 5 from ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|b\\right| \\ll M M^{\\prime}: b \\neq 0} (kr,b,d) \\lessapprox MM^{\\prime};", block: true)]]

#text("since ")#mi("{(kr,d) \\geq r}")#text(", we obtain a bound of ")#mi("{\\lessapprox MM^{\\prime} K r^{-1/2}}")#text(" from this case as required. ")#mi("\\Box")

#text("From this lemma, we see that we are done if we can find ")#mi("{r}")#text(" obeying ")#metadata(none) <tao-59548661e252a6f235e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(73)")])
#mitex("MM^{\\prime} (r^{1/2} K + d^{1/2} + MM^{\\prime} K r^{-1/2} ) (\\frac{N_3}{d})^2 d^{3/2} \\ll x^{-5\\epsilon} B^{2} K M^2 N_2 N_3^2 H^{-1}.")]]

#text("as well as the previously recorded condition ")#link(<tao-3e11b6c3eef5d583d7be>)[#text("(68)")]#text(". We can split the condition ")#link(<tao-59548661e252a6f235e5>)[#text("(73)")]#text(" into three subconditions:")

#tao-aligned(keep: true)[


#tao-math("M^{\\prime} r^{1/2} d^{-1/2}  & \\ll x^{-5\\epsilon} B^{2} M N_2 H^{-1}", block: true)



#tao-math("M^{\\prime} K^{-1}  & \\ll x^{-5\\epsilon} B^{2} M N_2 H^{-1}", block: true)



#tao-math("(M^{\\prime})^2 r^{-1/2} d^{-1/2}  & \\ll x^{-5\\epsilon} B^{2} N_2 H^{-1}.", block: true)
]

#text("Substituting the definitions ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(67)")]#text(", ")#link(<tao-b1f629a0f2f7f9718531>)[#text("(72)")]#text(" of ")#mi("{K, M^{\\prime}}")#text(", we can rewrite all of these conditions as lower and upper bounds on ")#mi("{r}")#text(". Indeed, ")#link(<tao-3e11b6c3eef5d583d7be>)[#text("(68)")]#text(" follows from (say) ")#metadata(none) <tao-dd191696e15e2ee29341>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(74)")])
#mitex("r \\ll x^{-2\\epsilon} N_2 H^{-1}")]]

#text("while the other three conditions rearrange to ")#metadata(none) <tao-7ef9ec0cf2c4facafddd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(75)")])
#mitex("r \\ll x^{-12\\epsilon} B^{4} M^2 N_2^2 N_3^2 H^{-2} d^{-1}")]]

#metadata(none) <tao-95b70fd9f1baf96ea89b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(76)")])
#mitex("r \\ll x^{-7\\epsilon} B^{2} M N_2^2 N_3 H^{-2} d^{-1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("r \\gg x^{14\\epsilon} B^{-4} N_2^{-2} N_3^{-4} H^2 d^{3}.")]]

#text("We can replace the first two constraints by the stronger constraint ")#metadata(none) <tao-9bf308ca455411a898dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(77)")])
#mitex("r \\ll x^{-12\\epsilon} B^{2} M N_2^2 N_3 H^{-2} d^{-1}")]]

#text("We combine these constraints as")

#align(center)[#tao-fit-display[#mitex("R_1 \\ll r \\ll R_2, R_3")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("R_1  & := x^{14\\epsilon} B^{-4} N_2^{-2} N_3^{-4} H^2 d^{3}", block: true)



#tao-math("R_2  & := x^{-2\\epsilon} N_2 H^{-1}", block: true)



#tao-math("R_3  & := x^{-12\\epsilon} B^{2} M N_2^2 N_3 H^{-2} d^{-1}.", block: true)
]

#text("From ")#link(<tao-b5587bfd231a74fd2aa1>)[#text("(60)")]#text(", ")#link(<tao-3b0cfb1c3107678644bd>)[#text("(61)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("R_2,R_3 \\gtrapprox x^{\\delta+c} R_1;")]]

#text("and from ")#link(<tao-e5589804b070def4acb5>)[#text("(62)")]#text(", ")#link(<tao-99a2fcae60933394aa75>)[#text("(63)")]#text(" we have ")#mi("{R_2,R_3 \\gg 1}")#text(". Since ")#mi("{d}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible, we will be done as soon as we verify that")

#align(center)[#tao-fit-display[#mitex("R_1 \\ll d,")]]

#text("since ")#mi("{d}")#text(" will then have a factor in ")#mi("{[x^{-\\delta} R, R]}")#text(" where ")#mi("{R := \\max(\\min(R_2,R_3,d),1)}")#text(", which works if ")#mi("{R_1 \\ll x^{-\\delta} d}")#text(" (and if ")#mi("{R_1 \\gg x^{-\\delta} d}")#text(" we can just take ")#mi("{d}")#text(" as the factor).")

#text("It remains to establish ")#mi("{R_1 \\ll d}")#text(". But this bound can be rewritten as")

#align(center)[#tao-fit-display[#mitex("x^{20\\epsilon} B^{-6} d^3 H^3 \\ll N_2^3 N_3^6")]]

#text("and the claim follows from ")#link(<tao-3b0cfb1c3107678644bd>)[#text("(61)")]#text(", ")#link(<tao-2b59b6a04f3b9ba1d7b9>)[#text("(58)")]#text(".")

#heading(level: 1)[#text("Comments (86)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-235947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Once again recording the latest critical numerology. If we ignore ")#mi("\\delta")#text(" and infinitesimals, then we have")

#mi("\\varpi = 1/148, \\quad \\delta = 0")

#text("and the critical term in the Heath-Brown identity is now of the form")

#mi("\\alpha_0 \\ast \\psi_1 \\ast \\psi_2 \\ast \\psi_3")

#text("where ")#mi("\\psi_1, \\psi_2, \\psi_3")#text(" are smooth and at scale ")#mi("x^{(1/2+\\sigma)/2}")#text(" and ")#mi("\\alpha_0")#text(" is at scale ")#mi("x^{1 - 3 (1/2+\\sigma)/2}")#text(" with")

#mi("\\sigma = 9/74 \\approx 0.1216,")

#text("thus ")#mi("\\psi_1,\\psi_2,\\psi_3")#text(" are at scale ")#mi("x^{23/74} \\approx x^{0.3108}")#text(" , and ")#mi("\\alpha")#text(" is at scale ")#mi("x^{5/74} \\approx x^{0.0676}")#text(". We are still a little bit above the combinatorial constraint ")#mi("\\sigma > 1/10")#text(" but we will be bumping against that pretty soonish.")

#text("This critical case is on the Type I / Type III border; both arguments apply to this case, and improving either of them at this choice of parameters should lead to an improvement in the final value of ")#mi("\\varpi")#text(". (On the other hand, the Type II analysis is not critical here, and we do not urgently need to improve that analysis further for the time being). With the Type I analysis, we may group ")#mi("\\psi_1 \\ast \\psi_2")#text(" and ")#mi("\\alpha_0 \\ast \\psi_3")#text(" as ")#mi("\\alpha")#text(" and ")#mi("\\beta")#text(" respectively, and the parameter scales are")

#mi("N = x^{1/2 - \\sigma} = x^{14/37} \\approx x^{0.3784}")

#mi("M = x^{1/2+\\sigma} = x^{23/37} \\approx x^{0.6216}")

#mi("d,  D \\approx x^{1/2 + 2 \\varpi} = x^{19/37} \\approx x^{0.5135}")

#mi("r, R \\approx N = x^{14/37} \\approx x^{0.3784}")

#mi("q, q_1, q_2, q^{\\prime}_2 \\approx Q \\approx D/N = x^{5/37} \\approx x^{0.1351}")

#mi("k \\approx N/R \\approx 1")

#mi("h, h^{\\prime}, H \\approx Q^2 R/M \\approx x^{1/37} \\approx x^{0.0270}")#text(".")

#text("In Lemma 10, it is the middle term ")#mi("N^{1/2} Q")#text(" which dominates slightly, suggesting that there is a little bit of gain to be had by refactoring to reduce ")#mi("d_2")#text(" and increase ")#mi("d_1")#text(".")

#text("Meanwhile, in the Type III analysis, the numerology is")

#mi("M = x^{5/74} \\approx x^{0.0676}; \\quad N_1=N_2=N_3 = x^{23/74} \\approx x^{0.3108}")

#mi("d \\approx x^{1/2+2\\varpi} = x^{19/37} \\approx x^{0.5135}")

#mi("h,H \\approx d/N_2 \\approx x^{15/74} \\approx x^{0.2027}")

#mi("B \\approx 1")

#mi("M^{\\prime} \\approx d/N_3 \\approx x^{15/74} \\approx x^{0.2027}")

#mi("r,R_1,R_3 \\approx x^{3/37} \\approx x^{0.0811}")

#mi("R_2 \\approx x^{7/74} \\approx x^{0.0946}")

#mi("k,K \\approx N_2/rH \\approx x^{1/37} \\approx x^{0.0270}")

#text("In Lemma 13 the last two terms on the RHS are equal and dominant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236945")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("I am confused, in (49) you give a constraint for Type II that has ")#mi("5\\sigma\\le 1/2")#text(" (in particular), but then you take ")#mi("\\sigma\\approx 0.1216")#text("? Is ")#mi("\\mu")#text(" allowed to be negative?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236946")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("OK, I guess you explain it right below (49), that “")#mi("\\sigma")#text("” is really not such, but a different thing that is really only ")#mi("2\\omega")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-235956")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("I think reshufffling the divisors to reduce ")#mi("\\sqrt {N}Q")#text(" slightly, would make ")#mi("101\\omega+21\\delta\\le 3/4")#text(" dominant, maybe with such extra ")#mi("\\delta")#text("‘s from this shuffling. The theoretical limit from ")#mi("\\omega=3/404")#text(" is then ")#mi("k_0=1267")#text(", and I can achieve ")#mi("k_0=1268")#text(" rather easily.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-235962")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#mi("k_0 = 1267")#text(" gives us ")#mi("H = 10 182")#text(" and ")#mi("k_0 = 1268")#text(" gives us ")#mi("H = 10 206")#text(".")

#text("To get ")#mi("H")#text(" below 10 000 using current admissible tuples we need ")#mi("k_0 = 1246")#text(".")

#text("(commenting mostly to get updates, but this will save others searching though the files for records)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Hmm, I get slightly different numerology, though there are a number of details and lower order terms to check. As ")#mi("q_1 r")#text(", ")#mi("q_2 r")#text(", ")#mi("q^{\\prime}_2 r")#text(" are already ")#mi("x^\\delta")#text("-densely divisible by construction, one should be able to reshuffle to improve the bound in (51) to")

#mi("\\lessapprox x^{\\delta/6} N^{1/2} (Q^3 R)^{1/6} + N R^{-1/4} (hq^{\\prime}_2 -h^{\\prime}q_2,r)^{1/4}")

#text("(I think), which leads to a primary constraint of")

#mi("x^{\\delta/6} H^2 Q^2 N^{1/2} (Q^3 R)^{1/6} \\ll Q^2 N")

#text("(ignoring epsilons) for Theorem 8, which after some algebra is giving me the constraint")

#mi("\\frac{\\delta}{6} + \\frac{9}{2} (\\frac{1}{2}+2\\varpi) < 2 + \\frac{5}{6} (\\frac{1}{2} - \\delta) - \\frac{7}{3}(\\mu+\\delta)")

#text("which simplifies to")

#mi("54 \\varpi + 5 \\sigma + 15 \\delta < 1")

#text("which when rebalanced against ")#mi("\\sigma > \\frac{1}{10} + \\frac{16}{5} \\varpi + \\frac{1}{5} \\delta")#text(" which is the best Type III constraint we currently have, seems to give")

#mi("140 \\varpi + 32 \\delta < 1")

#text("which is a little more strict than your condition, though still an improvement over ")#mi("148 \\varpi + 33 \\delta < 1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236097")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("I think ")#mi("140 \\varpi + 32 \\delta < 1")#text(" leads to ")#mi("k_0=1345")#text(" by choosing ")#mi("A=625")#text(", ")#mi("\\delta^{\\prime}=0.0547")#text(" and ")#mi("\\varpi=1/140 - 0.55 \\cdot 10^{-10}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236100")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("I retract that. Error from too low numerical precision.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236123")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("I think this is more correct.")#linebreak()#text(" For ")#mi("k_0=1346")#text(" choose:")#linebreak()#text(" ")#mi("A=560, \\delta^{\\prime}=0.00715, \\varpi=\\frac{1}{140}-\\frac{0.3672}{10^5}")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Confirmed by maple…")

#linebreak()#text(" varpi := 1/140 - 0.3672 / 10^5;")#linebreak()#text(" k0 := 1346;")#linebreak()#text(" deltap := 0.00715;")#linebreak()#text(" A := 560;")

#text("delta := (1 - 140 * varpi) / 32;")#linebreak()#text(" theta := deltap / (1/4 + varpi);")

#text("# Gergely's improved value for thetat")#linebreak()#text(" thetat := ((deltap - delta)/2 + varpi) / (1/4 + varpi);")#linebreak()#text(" deltat := delta / (1/4 + varpi);")

#text("j := BesselJZeros(k0-2,1);")

#text("eps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));")

#text("kappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);")#linebreak()#text(" kappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);")

#text("# using Gergely and Eytan's improved kappa_3")

#text("alpha := j^2 / (4 * (k0-1));")#linebreak()#text(" e := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );")

#text("# using Gergely's exact expression for denominator")#linebreak()#text(" gd := (j^2/2) * BesselJ(k0-3,j)^2;")

#text("# using Eytan's exact expression for numerator")#linebreak()#text(" tn := sqrt(thetat)*j;")#linebreak()#text(" gn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));")

#text("kappa3 := (gn/gd) * e;")

#text("eps2 := 2*(kappa1+kappa2+kappa3);")

#text("# we win if eps2 < eps")#linebreak()
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-235999")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("I am a bit confused when you say (several times) that ")#mi("MPZ[\\varpi,\\delta]")#text(" is stronger than ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(". I think it is the other way, since ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(" bounds a sum with more summands. In fact in the post ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]#text(" you said “we can prove a stronger result than ")#mi("MPZ[\\varpi,\\delta]")#text(" in this regime in a couple ways”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("Gah, you’re right, I do have it the wrong way around, I will fix this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236054")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("In (2), the ")#mi("n")#text(" on the RHS should be ")#mi("x")#text(".")

#text("In the statement of Theorem 9, you may wish to include the assumption ")#mi("M \\ll x^{1/2+2\\varpi +c}")#text(".")

#text("In the statement of Lemma 13, you may wish to include the assumption that ")#mi("r | d")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236109")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2013")])]

#text("A few more minor corrections.")

#text("1. In the second bullet point (for type I/II) I believe the ")#mi("n")#text(" should be ")#mi("2j")#text(", which gets confusing since in the next line there is a second meaning for ")#mi("j")#text(".")

#text("2. In the line after those bullets “Type O” should be “Type 0”.")

#text("3. A few lines later when it says “the condition (9), (10) are obeyed” I believe you also want to include (11).")

#text("4. Earlier in the sentence containing equation (30), the ")#mi("q")#text(" should be ")#mi("d")#text(".")

#text("5. In the offset equation before (31), did you want to write ")#mi("r \\sim R")#text(" instead of ")#mi("R \\ll r \\ll R")#text(" (and similarly for ")#mi("q,Q")#text(")?")

#text("6. In the second line of (37), there is an extra right parenthesis.")

#text("7. In the second offset equation after Lemma 10, there is a missing right absolute value bar.")

#text("8. In the statement of Proposition 12, it ends with “for some fixed ")#mi("\\epsilon > 0")#text(".” However, ")#mi("\\epsilon")#text(" occurs earlier in (58). Furthermore, in the type III analysis done at the beginning of the post, I believe you take ")#mi("\\epsilon")#text(" arbitrarily small. (I believe you meant, in Proposition 12, for ")#mi("\\epsilon")#text(" to be a fixed, but arbitrarily small, constant [defined before (58)].)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236237")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Emmanuel Kowalski has just posted on his blog at")

#link("http://blogs.ethz.ch/kowalski/2013/06/25/a-ternary-divisor-variation")[#text("http://blogs.ethz.ch/kowalski/2013/06/25/a-ternary-divisor-variation")]

#text("a sketch of his new Type III estimate with Fouvry, Michel, and Nelson. I will reproduce their argument in the notation of the blog post above. The objective is to obtain an estimate of the form")

#mi("\\sum_{q \\sim Q} |\\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a_q\\ (q))| \\lessapprox x^{-\\varepsilon} M N_1 N_2 N_3")

#text("for ")#mi("Q")#text(" as large as possible (in particular, as large as ")#mi("x^{1/2+2\\varpi}")#text("), but restricted to be square-free and ")#mi("x^\\delta")#text("-densely divisible. By the dense divisibility, it will suffice to show that")

#mi("\\sum_{r \\sim R} \\sum_{s \\sim S: (r,s)=1} |\\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a_{rs}\\ (rs))| \\lessapprox x^{-\\varepsilon} M N")

#text("for ")#mi("RS=Q")#text(" that we can specify to accuracy ")#mi("x^\\delta")#text(", thus we may place ")#mi("R")#text(" in ")#mi("[x^{-\\delta} R_0, R_0]")#text(" for some ")#mi("R_0")#text(" to be chosen later, and ")#mi("N = N_1 N_2 N_3")#text(".")

#text("FKMN do not exploit any averaging in ")#mi("\\alpha")#text(" or ")#mi("s")#text("; one can probably exploit the former to improve upon their results but we will not do so here. Removing those averages, we are now looking at")

#mi("\\sum_{r \\sim R: (r,s)=1} |\\Delta(\\psi_1 * \\psi_2 * \\psi_3; a_{rs}\\ (rs))| \\lessapprox x^{-\\varepsilon} N / S.")

#text("This may be rewritten as")

#mi("\\sum_r c_r \\sum_{n_1,n_2,n_3} \\psi_1(n_1) \\psi_2(n_2) \\psi_3(n_3) 1_{n_1n_2n_3 = a_{rs}\\ (rs)}")

#mi("= X + O( x^{o(1)} N / S )")

#text("where ")#mi("X")#text(" does not depend on the residues ")#mi("a_{rs}")#text(", and the ")#mi("c_r")#text(" are bounded and only supported on those ")#mi("r \\sim R")#text(" coprime to ")#mi("s")#text(". Performing completion of sums in the ")#mi("n_1,n_2,n_3")#text(" variables, the left-hand side can be expressed as")

#mi("\\frac{1}{H} \\sum_{h_1=O(H_1), h_2 = O(H_2), h_3 = O(H_3); h_1h_2h_3 \\neq 0} | \\sum_r c_r")

#mi("\\sum_{x,y,z \\in {\\bf Z}/rs{\\bf Z}: xyz = a_{rs}\\ (rs)} e_{rs}(h_1 x + h_2 y + h_3 z)")#text(" (*)")

#text("plus terms which do not depend on ")#mi("a_{rs}")#text(" (coming from the cases when at least one of the ")#mi("h_i")#text(" vanish), where ")#mi("H_i = Q/N_i")#text(" and ")#mi("H = H_1 H_2 H_3 = Q^3/N")#text(". The inner sum may be rescaled as")

#mi("rs K_3( a_{rs} h_1 h_2 h_3; rs )")

#text("where ")#mi("K_3")#text(" is the hyper-Kloosterman sum")

#mi("K_3(a;q) = \\frac{1}{q} \\sum_{x,y,z \\in {\\bf Z}/q{\\bf Z}: xyz=a} e_q(x+y+z)")#text(".")

#text("The ")#mi("h_1,h_2,h_3")#text(" now only appear through their product, and so we may gather terms and write the expression (*) as")

#mi("\\frac{Q}{H} \\sum_{h = O(H): h \\neq 0} \\tilde d_3(h) \\sum_r c^{\\prime}_r K_3( a_{rs} h; rs )")

#text("where ")#mi("\\tilde d_3(h)")#text(" is the number of representations ")#mi("h=h_1h_2h_3")#text(" with ")#mi("h_i=O(H_i)")#text(" and ")#mi("H = H_1 H_2 H_3 = Q^3 / N")#text(", and ")#mi("c^{\\prime}_r = rs c_r / Q")#text(" is another bounded sequence. The objective is now to show")

#mi("\\sum_{h = O(H): h \\neq 0} \\tilde d_3(h) |\\sum_r c^{\\prime}_r K_3( a_{rs} h; rs )| \\lessapprox x^{-\\varepsilon} N H / S Q.")

#text("Note that ")#mi("NH/SQ = Q R")#text(". Deligne tells us that ")#mi("K_3 \\lessapprox 1")#text(", which bounds the LHS by ")#mi("H R")#text(", but this only works in the Bombieri-Vinogradov regime ")#mi("Q \\ll N^{1/2}")#text(". To do better we apply Cauchy-Schwarz to eliminate the ")#mi("\\tilde d_3")#text(" term and gain another unweighted index ")#mi("h")#text(" to sum over. From the divisor bound one has")

#mi("\\sum_{h = O(H): h \\neq 0} \\tilde d_3(h)^2 \\lessapprox H")

#text("so it suffices to show that")

#tao-math("\\sum_{h = O(H)} \\left|\\sum_r c^{\\prime}_r K_3( a_{rs} h; rs )\\right|^2 \\lessapprox x^{-2\\varepsilon} Q^2 R^2 / H.", block: false)#text(" (**)")

#text("We can rearrange the LHS as")

#mi("\\sum_{r_1, r_2} c^{\\prime}_{r_1} \\overline{c^{\\prime}_{r_2}}")

#mi("\\sum_{h = O(H)} K_3(a_{r_1s} h; r_1s) \\overline{K_3(a_{r_2s} h; r_2s)}")#text(".")

#text("The summand is periodic in h with period ")#mi("[r_1,r_2] s")#linebreak()#text(" One then performs completion of sums in ")#mi("h")#text(", using the Chinese remainder theorem and Deligne’s estimates to estimate the completed sums, and eventually ends up with a bound on the inner sum of the form")

#mi("\\lessapprox (\\frac{H}{[r_1,r_2] s} + 1)")#linebreak()#text(" ")#mi("d (s/d)^{1/2} r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}")

#text("where ")#mi("r_0 := (r_1,r_2)")#text(" and ")#mi("d := (r_1^3-r_2^3, s)")#text(". So now one has to sum")

#mi("\\sum_{r_1,r_2 \\sim R: (r_1r_2, s) = 1}")#linebreak()#text(" ")#mi("(\\frac{H r_0}{r_1 r_2 s} + 1) d (s/d)^{1/2} r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}.")

#text("A computation shows that for each choice of ")#mi("r_0 = O(R)")#text(" and ")#mi("d|s")#text(", the number of pairs ")#mi("r_1,r_2")#text(" with ")#mi("r_0=(r_1,r_2)")#text(" and ")#mi("d = (r_1^3-r_2^3,s)")#text(" is ")#mi("\\lessapprox \\frac{R^2}{r_0^2 d} + \\frac{R}{r_0}")#text(". So now one is summing")

#mi("\\sum_{d|s} \\sum_{r_0=O(R)} (\\frac{R^2}{r_0^2 d} + \\frac{R}{r_0})")

#mi("(\\frac{H r_0}{r_1 r_2 s} + 1) d (s/d)^{1/2} r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}")#text(".")

#text("One can perform the ")#mi("d")#text(" summation without difficulty and end up with")

#mi("\\lessapprox \\sum_{r_0=O(R)} (\\frac{R^2 s^{1/2}}{r_0^2} + \\frac{R s}{r_0})")

#mi("(\\frac{H r_0}{r_1 r_2 s} + 1) r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}")#text(",")

#text("and then performing the ")#mi("r_0")#text(" summation this becomes")

#mi("\\lessapprox H R S^{-1/2} + R^3 S^{1/2} + HR + S R^2")#text(".")

#text("The first term is bounded by the third and can be dropped. We also crudely bound the secondary term ")#mi("SR^2")#text(" by ")#mi("S^{3/2}R^2")#text(".")#linebreak()#text(" To make this less than ")#mi("x^{-2\\varepsilon} Q^2 R^2 / H")#text(", this is equivalent to requiring (ignoring epsilons)")

#mi("H^2/Q^2, H^{2/3}/Q^{1/3} \\lessapprox R \\lessapprox Q^3 / H^2")#text(".")

#text("The expression ")#mi("H^{2/3}/Q^{1/3}")#text(" is a geometric average ")#mi("(H^2/Q^2)^{2/3} (Q^3/H^2)^{1/3}")#text(" of the other two and so the ")#mi("H^2/Q^2")#text(" term may be dropped. This already forces ")#mi("H \\lessapprox Q^{5/4}")#text(". As we may specify ")#mi("R")#text(" to accuracy ")#mi("x^\\delta")#text(", we win as soon as")

#mi("x^\\delta H^{2/3} / Q^{1/3} \\lessapprox Q^3 / H^2")

#text("which rearranges to")

#mi("H \\lessapprox x^{-3\\delta/8} Q^{5/4}")

#text("or equivalently")

#mi("N \\gtrapprox x^{3\\delta/8} Q^{7/4}")

#text("thus")

#mi("N_1 N_2 N_3 \\gtrapprox x^{\\frac{7}{4}(\\frac{1}{2}+2\\varpi) + \\frac{3}{8} \\delta}")#text(".")

#text("In terms of ")#mi("\\sigma")#text(", this gives a constraint")

#mi("\\frac{3}{2} (\\frac{1}{2} + \\sigma) > \\frac{7}{4} (\\frac{1}{2} + 2 \\varpi) + \\frac{3}{8} \\delta")

#text("which can be rearranged as")

#mi("\\sigma > \\frac{1}{12} + \\frac{7}{3} \\varpi + \\frac{1}{4} \\delta")#text(". (1)")

#text("We also have")

#mi("\\sigma > 1/10")#text(". (2)")

#text("If we play this against the Type I constraints")

#mi("17 \\varpi + 4 \\delta + \\sigma < \\frac{1}{4}")#text(" (3)")

#mi("20 \\varpi + 6\\delta + 3\\sigma < \\frac{1}{2}")#text(" (4)")

#mi("32 \\varpi + 9 \\delta + \\sigma < \\frac{1}{2}")#text(" (5)")

#mi("48\\varpi + 7 \\delta < \\frac{1}{2}")#text(" (6)")

#text("in the main post, one ends up with")

#mi("116 \\varpi + \\frac{51}{2} \\delta < 1")#text(" (1+3)")

#mi("108 \\varpi + 25 \\delta < 1")#text(" (1+4)")

#mi("412 \\varpi + 111 \\delta < 5")#text(" (1+5)")

#mi("280 \\varpi + 80 \\delta < 3")#text(" (2+3)")

#mi("100 \\varpi + 30 \\delta < 1")#text(" (2+4)")

#mi("160 \\varpi + 45 \\delta < 2")#text(" (2+5)")

#mi("96 \\varpi + 14 \\delta < 1")#text(" (6)")

#text("leaving one with the final constraint")

#mi("116 \\varpi + 30 \\delta < 1")

#text("coming from merging the (1+3) and (2+4) estimates (this is not quite optimal, but will do for now).")

#text("This should be improvable once we flesh out the improved Type I estimates currently being discussed at ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")]#text(" . But the fact that all the different combinations (1+3), …, (6) are beginning to surface means that we will have to start fighting on a lot of fronts to get more improvement from here on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236242")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#mi("k_0=1007, A=396, \\delta^{\\prime}=0.0085, \\varpi=1/116 - 0.62/10^5")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236244")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("And if confirmed, a prime gap bound of 7860.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("confirmed by maple, going on the wiki :)")

#linebreak()#text(" varpi := 1/116 - 0.62 / 10^5;")#linebreak()#text(" k0 := 1007;")#linebreak()#text(" deltap := 0.0085;")#linebreak()#text(" A := 396;")

#text("delta := (1 - 116 * varpi) / 30;")#linebreak()#text(" theta := deltap / (1/4 + varpi);")

#text("# Gergely's improved value for thetat")#linebreak()#text(" thetat := ((deltap - delta)/2 + varpi) / (1/4 + varpi);")#linebreak()#text(" deltat := delta / (1/4 + varpi);")

#text("j := BesselJZeros(k0-2,1);")

#text("eps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));")

#text("kappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);")#linebreak()#text(" kappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);")

#text("# using Gergely and Eytan's improved kappa_3")

#text("alpha := j^2 / (4 * (k0-1));")#linebreak()#text(" e := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );")

#text("# using Gergely's exact expression for denominator")#linebreak()#text(" gd := (j^2/2) * BesselJ(k0-3,j)^2;")

#text("# using Eytan's exact expression for numerator")#linebreak()#text(" tn := sqrt(thetat)*j;")#linebreak()#text(" gn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));")

#text("kappa3 := (gn/gd) * e;")

#text("eps2 := 2*(kappa1+kappa2+kappa3);")

#text("# we win if eps2 < eps")#linebreak()
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236279")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Asking Maple for more digits (Digits := …) will cause this script to fail. However, I believe it will work after correcting the typo in the expression for delta. :-)")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236345")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Actually the treatment of the degenerate ")#mi("h_1,h_2,h_3")#text(" terms is a bit more difficult than I claimed, because the rescaling identity")

#mi("\\sum_{x,y,z \\in {\\bf Z}/rs{\\bf Z}: xyz = a_{rs}\\ (rs)} e_{rs}(h_1 x + h_2 y + h_3 z)")

#mi("= \\sum_{x,y,z \\in {\\bf Z}/rs{\\bf Z}: xyz = a_{rs} h_1 h_2 h_3\\ (rs)} e_{rs}(x + y + z)")

#text("is only true when ")#mi("h_1,h_2,h_3")#text(" are coprime to ")#mi("rs")#text(". One should be able to eliminate the non-coprime cases by introducing some “B” parameters as in the blog post treatment of the Type III case but it will get a bit messy. In principle it should work because whenever one or two of the ")#mi("h_i")#text(" share a common prime ")#mi("p")#text(" with ")#mi("rs")#text(", one picks up two or one Ramanujan sums in the ")#mi("p")#text(" modulus which should safely counteract all the losses coming elsewhere from having to enforce such divisibility conditions. One also has to deal with the case when all of the ")#mi("h_1,h_2,h_3")#text(" have a common factor; this should be handled by factoring out these common factors from ")#mi("h_1,h_2,h_3,r,s")#text(" and inserting “B” terms to measure the losses and gains. In past experience there were always many powers of B to spare, so I don’t think this is a major issue, but it does need to be addressed at some point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("OK, the treatment of the non-coprime case ends up being slightly tricky, one has to force coprimality ")#mi("(h,q)=1")#text(" before performing the factoring ")#mi("q=rs")#text(" because one needs to optimise the factoring with respect to the common factor in order to get a convergent series.")

#text("Here are some details. The key estimate is")

#strong[#text("Proposition")]#text(" Let ")#mi("H, Q")#text(" be of polynomial size. If ")#mi("c_q")#text(" are bounded and supported on ")#mi("y")#text("-densely divisible squarefree ")#mi("q \\sim Q")#text(", then")

#mi("\\sum_{h = O(H)} | \\sum_{q: (h,q)=1} c_q K_3( a_q h; q)| \\lessapprox y^{3/16} H^{1/2} Q^{11/4} + y^{1/8} H Q^{3/4}")#text(".")

#strong[#text("Proof")]#text(" By pigeonholing and dense divisbility we may factor ")#mi("q=rs")#text(" with ")#mi("r \\sim R")#text(", ")#mi("s \\sim S")#text(" with")

#mi("y^{-1/4} Q^{1/2} \\ll R \\ll y^{3/4} Q^{1/2}")

#text("and")

#mi("y^{-3/4} Q^{1/2} \\ll S \\ll y^{1/4} Q^{1/2}")#text(".")

#text("It then suffices to show that")

#mi("\\sum_{h = O(H)} | \\sum_{r: (h,r)=1} \\sum_{s: (h,s)=(h,r)=1} c_{r,s} K_3( a_{rs} h; {rs})| \\lessapprox x^{3\\delta/16} H Q^{7/4} + x^{\\delta/4} H^2 Q^{1/2}")#text(" (*)")

#text("for some bounded ")#mi("c_{r,s}")#text(" that is supported on coprime ")#mi("r \\sim R")#text(" and ")#mi("s \\sim s")#text(".")

#text("We pull the s summation out and then Cauchy-Schwarz in h to bound this by")

#tao-math("\\lessapprox H^{1/2} \\sum_s (\\sum_{h: (h,s)=1} \\left|\\sum_{r: (h,r)=1} c_{r,s} K_3( a_{rs} h; {rs})\\right|^2)^{1/2}", block: false)#text(".")

#text("The sum inside the parentheses can be estimated using the previous arguments as")

#mi("\\lessapprox R^3 S^{1/2} + HR + S^{3/2} R^2")

#text("so the LHS of (*) is")

#mi("\\lessapprox H^{1/2} S (R^3 S^{1/2} + HR + S^{3/2} R^2 )^{1/2}")

#text("which we can rewrite as")

#mi("\\lessapprox H^{1/2} Q^{5/4} R^{1/4} + H Q^{1/2} S^{1/2} + H^{1/2} Q S^{3/4}")

#text("and the claim then follows from the upper bounds on R,S. ")#mi("\\Box")

#text("Now back to the Type III estimates. We wish to show")

#mi("\\sum_q c_q \\sum_{n_1,n_2,n_3} \\psi_1(n_1) \\psi_2(n_2) \\psi_3(n_3) 1_{n_1 n_2 n_3 = a_q\\ (q)} = X + O(x^{-\\varepsilon} N)")

#text("where ")#mi("X")#text(" does not depend on the ")#mi("a_q")#text(". After completion of sums and removing the degenerate frequencies, this becomes")

#mi("\\sum_{h_1=O(H_1),h_2=O(H_2),h_3=O(H_3): h_1h_2h_3 \\neq 0} |\\sum_q c^{\\prime}_q F(h_1,h_2,h_3,a_q;q)|  \\lessapprox x^{-\\varepsilon} Q^2")

#text("where")

#mi("F(h_1,h_2,h_3,a_q;q) := \\frac{1}{q} \\sum_{x,y,z \\in {\\bf Z}/q{\\bf Z}: xyz=a_q\\ (q)} e_q( h_1 x + h_2 y + h_3 z)")

#text("would morally be the hyper-Kloosterman sum ")#mi("K_3(h_1h_2h_3a_q;q)")#text(" except that we do not yet have that ")#mi("h_1,h_2,h_3")#text(" are coprime to ")#mi("q")#text(".")

#text("Suppose that ")#mi("(h_i,q) = b_i")#text(". Writing ")#mi("h_i= b_i h^{\\prime}_i")#text(", ")#mi("b := [b_1,b_2,b_3]")#text(" and ")#mi("q = b q^{\\prime}")#text(", we can use the Chinese remainder theorem and Ramanujan sum bounds to factor ")#mi("F(h_1,h_2,h_3,a_q;q)")#text(" as ")#mi("K_3( h^{\\prime}_1 h^{\\prime}_2 h^{\\prime}_3 a_{q^{\\prime}} / b^3; q^{\\prime} )")#text(" times a factor independent of ")#mi("q^{\\prime}")#text(" of magnitude ")#mi("\\frac{b_1 b_2 b_3}{b^2}")#text(" (we skip this computation, it boils down to checking a bunch of cases when ")#mi("q")#text(" consists of a single prime ")#mi("p")#text("). For each fixed ")#mi("b_1,b_2,b_3")#text(", we apply the Proposition with H replaced by ")#mi("H/b_1b_2b_3")#text(" and ")#mi("Q")#text(" replaced by ")#mi("Q/b")#text(", noting that the modulus ")#mi("q^{\\prime}")#text(" is now only ")#mi("b x^\\delta")#text("-densely divisible instead of ")#mi("x^\\delta")#text("-densely divisible, and one ends up with a total bound of")

#mi("\\lessapprox \\sum_{b_1,b_2,b_3} (b x^\\delta)^{3/16} (\\frac{H}{b_1b_2b_3})^{1/2} (Q/b)^{11/4}")

#mi("+ (bx^\\delta)^{1/8} \\frac{H}{b_1b_2b_3} (Q/b)^{3/4}.")

#text("Fortunately, the net power of b here in the denominator is greater than 1, and the b summation converges (as can be seen by taking Euler products) to get a bound of")

#mi("\\lessapprox x^{3\\delta/16} H^{1/2} Q^{11/4} + x^{\\delta/8} H Q^{3/4}")

#text("which is ")#mi("\\lessapprox x^{-\\varepsilon} Q^2")#text(" as required if")

#mi("H \\lessapprox x^{-3\\delta/8 - 2\\varepsilon} Q^{5/4}")

#text("and we are back to the same numerology as before. So the coprimality thing is a moderate pain to deal with, but fortunately doesn’t seem to ultimately impact the final estimates.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236346")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Plugging in the constraints (1+3), (1+4), (1+5), (2+3), (2+4), (2+5), and (6) into Mathematica’s “Reduce” function (which I love by the way) yields the final constraints (if I copied everything correctly):")

#mi("100\\varpi +30\\delta < 1")#text(" when ")#mi("\\varpi\\leq 3/620")

#text("or")

#mi("116\\varpi + 25.5\\delta < 1")#text(" when ")#mi("3/620 < \\varpi\\leq 233/18460")

#text("or")

#mi("82.4\\varpi + 2.2\\delta < 1")#text(" when ")#mi("233/18460 < \\varpi")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Thanks! There is also the trivial constraint ")#mi("\\delta > 0")#text(" which presumably kills off the third case here, so for the regime of ")#mi("\\varpi")#text(" we are currently shooting for, the ")#mi("116 \\varpi + 25.5 \\delta < 1")#text(" condition is dominant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-237169")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("In the Wiki page (")#link("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")[#text("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")]#text(") the condition ")#mi("116 \\varpi + 25.5 \\delta < 1")#text(" has been misprinted as ")#mi("116 \\varpi + 22.5 \\delta < 1")#text(".")

#emph[#text("[Fixed, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236363")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Can you share your code? Sounds like a nice function of Mathematica indeed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236368")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("The code is actually quite simple which is why I like the function so much. If I had been thinking straight, I would have added the extra conditions ")#mi("0 < \\varpi < 1/4")#text(", etc. The downside is that it is all automated, and so (in the final write-up) we may need to rederive the necessary inequalities. (But that shouldn't be too hard, given that we would know what to look for.)")

#text("All I typed was: Reduce[116p + (51/2)d<1 && 108p+25d<1 && … ]")

#text("This should be able to deal with any sort of polytope issues (at least for a small number of variables).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236369")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("An alternative is to just draw the lines… This is maple code:")#linebreak()#text(" ")#raw("\nwith(plots):")

#text("eq := [116*varpi + 51/2*delta = 1,")#linebreak()#text(" 108*varpi + 25*delta = 1,")#linebreak()#text(" 412*varpi + 111*delta = 5,")#linebreak()#text(" 280*varpi + 80*delta = 3,")#linebreak()#text(" 100*varpi + 30*delta = 1,")#linebreak()#text(" 160*varpi + 45*delta = 2,")#linebreak()#text(" 96*varpi + 14*delta = 1]:")

#text("max_v := min(seq( eval(solve(e, varpi), delta=0), e in eq ));")#linebreak()#text(" max_d := min(seq( eval(solve(e, delta), varpi=0), e in eq ));")

#text("implicitplot(eq, varpi=0..max_v, delta=0..max_d, color=[blue,black,black,black,red,black,black]);")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236370")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Thank you guys, such tricks save time!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("I found some Maple code (LinearMultivariateSystem) that does something similar, and allows me to plug in the Type I, Type II, and Type III constraints directly without having to manually play off the inequalities against each other. The (varpi,delta,sigma) polytope ends up being a bit messy but it does confirm that the main constraint is ")#mi("116 \\varpi + 25.5 \\delta < 1")#text(" when ")#mi("1/124 \\leq \\varpi < 1/116")#text(".")

#raw("\nwith(SolveTools[Inequality]);")

#text("base := [ sigma > 1/10, sigma < 1/2, varpi > 0, varpi < 1/4, delta > 0, delta < 1/4+varpi ];")

#text("typeI_1 := [ 11 * varpi + 3 * delta + 2 * sigma < 1/4 ];")

#text("typeI_2 := [ 17 * varpi + 4 * delta + sigma < 1/4, 20 * varpi + 6 * delta + 3 * sigma < 1/2, 32 * varpi + 9 * delta + sigma < 1/2 ];")

#text("typeII_1 := [ 58 * varpi + 10 * delta < 1/2 ];")

#text("typeII_1a := [48 * varpi + 7 * delta < 1/2 ];")

#text("typeIII_1 := [ (13/2) * (1/2 + sigma) > 8 * (1/2 + 2*varpi) + delta ];")

#text("typeIII_2 := [ 1 + 5 * (1/2 + sigma) > 8 * (1/2 + 2*varpi) + delta ];")

#text("typeIII_3 := [ 3/2 * (1/2 + sigma) > (7/4) * (1/2 + 2*varpi) + (3/8) * delta ];")

#text("constraints := [ op(base), op(typeI_2), op(typeII_1a), op(typeIII_3) ];")

#text("LinearMultivariateSystem(constraints, [varpi,delta,sigma]);")#linebreak()
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236247")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("This comment is an attempt to summarise the many different advances we have (whether worked out in full, or only partially sketched so far) on the problem of getting ")#mi("\\varpi,\\delta")#text(" as large as possible. To simplify this overview I will not make a distinction between ")#mi("MPZ[\\varpi,\\delta]")#text(" or ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(" (so I will not distinguish between smoothness, dense divisibility, or “double dense divisibility”).")

#text("These estimates are obtained by a combination of three types of estimates: Type I estimates, Type II estimates, and Type III estimates. We have various levels of technological advance on each of these estimates, with a question mark indicating that this technology has not yet been fully fleshed out:")

#text("Type I-1: Zhang’s original argument bounding Type I estimates. Uses the bound on incomplete Kloosterman sums coming from completion of sums.")

#text("Type I-2: A refinement to Type I-1 coming from using q-van der Corput in the d_2 direction to improve the bounds on incomplete Kloosterman sums.")

#text("Type I-3?: A refinement to Type I-2 coming from refactoring the modulus d=d_1 d_2 to optimise the direction in which to apply q-van der Corput.")

#text("Type I-4?: A further refinement coming from iterating the q-van der Corput method.")

#text("Type I-5??: A yet further refinement taking advantage of additional averaging to reduce the contribution of diagonal terms.")

#text("Type II-1, Type II-2?, Type II-3?, Type II-4?, Type II-5??: Analogues of Type I-1 to Type I-5?? for the Type II sums.")

#text("Type III-1: Zhang’s original argument bounding Type III modulus, using Weyl differencing and not taking advantage of the alpha averaging.")

#text("Type III-2: Refinement of Type III-1 taking advantage of the alpha averaging to reduce the contribution of diagonal terms.")

#text("Type III-3: The new Fouvry-Kowalski-Michel argument avoiding Weyl differencing. Does not take advantage of the alpha averaging.")

#text("Type III-4?: Combining Fouvry-Kowalski-Michel with the alpha averaging.")

#text("Now a quick summary of progress so far:")

#text("* Zhang’s original argument uses Type I-1 + Type II-1 + Type III-1. This was optimised to give the constraint ")#mi("207\\varpi + 43\\delta < 1/4")#text(".")

#text("* By upgrading Type III-1 to Type III-2, we computed the numerology for Type I-1 + Type II-1 + Type III-2 and got ")#mi("87\\varpi + 17 \\delta < 1/4")#text(".")

#text("* By upgrading Type I-1 to Type I-2, we computed the numerology for Type I-2 + Type II-1 + Type III-2 and got ")#mi("148 \\varpi + 33 \\delta < 1")#text(", as described in the post above. (I had earlier computed Type I-2 + Type II-1 + Type III-1 to get the inferior constraint ")#mi("178\\varpi + 52 \\delta < 1")#text(".)")

#text("* By upgrading Type I-2 to Type I-3?, and using Type I-3? + Type II-1 + Type III-2, we have tentatively computed either ")#mi("101\\varpi + 21\\delta < 3/4")#text(" or ")#mi("140 \\varpi + 32\\delta < 1")#text(" (this discrepancy is not yet resolved).")

#text("* A very sketchy projection of Type I-4? + Type II-1 + Type III-2 suggests that ")#mi("\\varpi")#text(" could get as large as 1/74 (or 1/88 if we only use Type III-1 instead of Type III-2), except that the Type II-1 estimates start failing at 1/96. However this can presumably be overcome by upgrading Type II-1 to something better, such as Type II-2? or Type II-3?; we have not yet bothered to do anything to the Type II sums but we should probably do so soon.")

#text("* In the comments above, I have worked out the numerology for Type I-2 + Type II-1 + Type III-3 and obtained ")#mi("116 \\varpi + 30 \\delta < 1")#text(".")

#text("Clearly there is a lot more progress to be made. Ideally we can work out the details of all the different estimates above and arrive at Type I-5 + Type II-5 + Type III-4 which should give significantly better values of ")#mi("\\varpi,\\delta")#text(" than we currently have.")

#text("One can view each of these estimates as working on some polytope in ")#mi("(\\varpi,\\delta,\\sigma)")#text(" parameter space, with ")#mi("MPZ[\\varpi,\\delta]")#text(" (or some variant thereof) holding if one can find a ")#mi("1/10 < \\sigma < 1/2")#text(" such that ")#mi("(\\varpi,\\delta,\\sigma)")#text(" simultaneously lies in a Type I-polytope, a Type II-polytope, and a Type III-polytope.")

#text("I think I will write up a wiki page to organise all this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236265")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("The wiki page is now up:")

#link("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")[#text("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")]

#text("In the next day or two I’ll start on systematically working out the various levels of Type I, Type II, and Type III estimates that we currently have, which should lead to a sequence of improvements to ")#mi("\\varpi, \\delta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aviwlevy")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236271")[#strong[#text("aviwlevy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("There seems to be a missing comment hyperlink under Type I, Level 4 on the new wiki page.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236269")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("I hope it is explicit enough in what I wrote on my blogs that we worked with Paul Nelson on this…")

#emph[#text("[Sorry about that! I’ve updated the attributions accordingly. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236270")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Thanks; the summary page of the Wiki also has one mistake, and also the summary two comments above (Type III-3, Type III-4?)…")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("The purpose of this comment is to record the details of the “Level 3” Type I estimate, which optimises the direction in which the q-van der Corput A-process (aka Weyl differencing) is applied, in the context of densely divisible moduli. This was sketched already in ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli")]#text(" but is done here a little more carefully (in particular, a secondary constraint on ")#mi("\\varpi,\\delta,\\sigma")#text(" can now be shown to be dropped).")

#text("First, a convenient fact: if ")#mi("a, b")#text(" are both ")#mi("y")#text("-densely divisible, then ")#mi("[a,b]")#text(" is also ")#mi("y")#text("-densely divisible. This is because at least one of ")#mi("a,b")#text(" must be as large as ")#mi("[a,b]^{1/2}")#text("; if say ")#mi("a")#text(" is this large then one can use the factors of ")#mi("a")#text(", together with the factors of ")#mi("a")#text(" times ")#mi("[a,b]/a")#text(", to demonstrate the dense divisibility of ")#mi("[a,b]")#text(".")

#text("In particular, in the context of Lemma 10 above, the quantity ")#mi("q_1 r [q_2,q^{\\prime}_2]")#text(" is ")#mi("x^\\delta")#text("-densely divisible, because ")#mi("q_1 r, q_2 r, q^{\\prime}_2 r")#text(" are ")#mi("x^\\delta")#text("-densely divisible by construction.")

#text("Next, a Kloosterman sum bound: if")

#mi("S := \\sum_n \\psi_N(n) e_{d_1}(\\frac{c_1}{n}) e_{d_2}(\\frac{c_2}{n+l})")

#text("with ")#mi("d_1,d_2")#text(" squarefree and coprime with ")#mi("d_1 d_2")#text(" ")#mi("x^\\delta")#text("-densely divisible, then for any other factorisation ")#mi("d = s_1 s_2")#text(" of ")#mi("d")#text(", we may use the k=1 van der Corput bound from ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236228")[#text("this comment")]#text(" and bound")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} (s^{\\prime}_1)^{1/2} + N^{1/2} (s^{\\prime}_2)^{1/4}", block: false)

#text("if ")#mi("N < d^{\\prime}")#text(", where ")#mi("d^{\\prime} := d / (c_1,d_1) (c_2,d_2)")#text(", ")#mi("s^{\\prime}_1 = (s_1,d^{\\prime})")#text(", and ")#mi("s^{\\prime}_2 := (s_2,d^{\\prime})")#text(". If we choose a factorisation ")#mi("d_1 d_2 = s_1 s_2")#text(" with ")#mi("x^{-2\\delta/3} (d_1d_2)^{1/3} \\leq s_1 \\leq x^{\\delta/3} (d_1 d_2)^{1/3}")#text(" in this case, we end up with")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} x^{\\delta/6} (d_1 d_2)^{1/6}", block: false)#text(".")

#text("In the opposite case when ")#mi("N > d^{\\prime}")#text(", we basically have from completion of sums that")

#tao-math("\\left|S\\right| \\lessapprox \\frac{N}{d^{\\prime}} \\left|\\sum_{n \\in {\\bf Z}/d^{\\prime}{\\bf Z}} e_{d_1}(\\frac{c_1}{n}) e_{d_2}(\\frac{c_2}{n+l})\\right|", block: false)

#text("(strictly speaking we need to improve ")#mi("N > d^{\\prime}")#text(" to ")#mi("N > x^\\varepsilon d^{\\prime}")#text(" to get something like this, but let’s ignore this detail) and by computing the degenerate completed Kloosterman sum we obtain a bound of ")#mi("\\lessapprox N/d^{\\prime} = \\frac{(c_1,d_1)}{d_1} \\frac{(c_2,d_2)}{d_2}N")#text(" here. So the net bound on ")#mi("S")#text(" is")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} x^{\\delta/6} (d_1 d_2)^{1/6} + \\frac{(c_1,d_1)}{d_1} \\frac{(c_2,d_2)}{d_2}N.", block: false)

#text("Using this bound, we can improve the RHS in Lemma 10 of this post to")

#mi("N^{1/2} x^{\\delta/6} (Q^3 R)^{1/6}+ (hq^{\\prime}_2-h^{\\prime}q_2,r) R^{-1} N")#text(".")

#text("(one can get further improvements to the second term in the RHS by also studying the other components of ")#mi("(c_1,d_1)")#text(" and ")#mi("(c_2,d_2)")#text(", but I don’t think we need these improvements yet.) The non-diagonal contribution to (50) is then")

#mi("\\lessapprox H^2 Q^2 ( N^{1/2} x^{\\delta/6} (Q^3 R)^{1/6}+ R^{-1} N)")

#text("which needs to be ")#mi("\\lessapprox x^{-\\varepsilon} Q^2 N")

#text("leading to the conditions")

#mi("H^2 (Q^3 R)^{1/6} \\lessapprox x^{-\\delta/6 - \\varepsilon} N^{1/2}")

#text("and")

#mi("H^2 R^{-1} \\lessapprox x^{-\\varepsilon}")#text(".")

#text("As ")#mi("H = x^\\varepsilon Q^2 R / M")#text(" and ")#mi("NM \\sim x")#text(", this becomes")

#mi("(QR)^{9/2} \\lessapprox x^{2-\\delta/6 - 3\\varepsilon} (R/N)^{7/3} N^{5/6}")

#mi("(QR)^4 \\lessapprox x^{2-3\\varepsilon} (R/N)^3 N")

#text("which since ")#mi("QR \\lessapprox x^{1/2+2\\varpi}")#text(", ")#mi("N \\gtrapprox x^{1/2-\\sigma}")#text(", and ")#mi("x^{-\\delta-\\mu} N \\lessapprox R \\lessapprox x^{-\\mu} N")#text(" for an infinitesimal ")#mi("\\mu")#text(", leads to the constraints")

#mi("\\frac{9}{2} (\\frac{1}{2} + 2 \\varpi) < 2 - \\frac{5}{2} \\delta + \\frac{5}{6} (\\frac{1}{2} - \\sigma)")

#text("and")

#mi("4 (\\frac{1}{2} + 2 \\varpi) < 2 - 3 \\delta + \\frac{1}{2} - \\sigma")

#text("which may be rearranged as")

#mi("54 \\varpi + 15 \\delta + 5 \\sigma < 1")

#text("and")

#mi("8 \\varpi + 3 \\delta + \\sigma < \\frac{1}{2}")#text(".")

#text("The second constraint is clearly dominated by the first and so may be dropped. We conclude the “Level 3” bound that the Type I estimates hold for ")#mi("54 \\varpi + 15 \\delta +5 \\sigma < 1")#text(". Combining the Level 3 Type I estimates with the current best Type II estimate (which I’ve called Level 1a on the wiki) and the best Type III estimate (Level 3), Maple gives the slightly messy constraint")

#mi("788 \\varpi + 195 \\delta < 7")

#text("for ")#mi("1/140 < \\varpi < 7/788")

#text("which is a little bit better than the previous bound of ")#mi("118 \\varpi + 25.5 \\delta < 1")#text(".")

#raw("\nwith(SolveTools[Inequality]);\nbase := [ sigma > 1/10, sigma < 1/2, varpi > 0, varpi < 1/4, delta > 0, delta < 1/4+varpi ];\ntypeI_1 := [ 11 * varpi + 3 * delta + 2 * sigma < 1/4 ];\ntypeI_2 := [ 17 * varpi + 4 * delta + sigma < 1/4, 20 * varpi + 6 * delta + 3 * sigma < 1/2, 32 * varpi + 9 * delta + sigma < 1/2 ];\ntypeI_3 := [ 54 * varpi + 15 * delta + 5 * sigma < 1 ];\ntypeII_1 := [ 58 * varpi + 10 * delta < 1/2 ];\ntypeII_1a := [48 * varpi + 7 * delta < 1/2 ];\ntypeIII_1 := [ (13/2) * (1/2 + sigma) > 8 * (1/2 + 2*varpi) + delta ];\ntypeIII_2 := [ 1 + 5 * (1/2 + sigma) > 8 * (1/2 + 2*varpi) + delta ];\ntypeIII_3 := [ 3/2 * (1/2 + sigma) > (7/4) * (1/2 + 2*varpi) + (3/8) * delta ];\nconstraints := [ op(base), op(typeI_3), op(typeII_1a), op(typeIII_3) ];\nLinearMultivariateSystem(constraints, [varpi,delta,sigma]);\n")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236406")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("I think ")#mi("k_0 = 962, A = 388, \\delta^{\\prime} = 0.0069, \\varpi = 7/788 - 0.5932/10^5")#text(" works.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("Maple confirms, as usual… it gives H = 7470. Thanks!")

#raw("\nk0 := 962;\nvarpi := 7/788 - 0.5932/10^5;\ndelta := (7 - 788*varpi) / 195;\ndeltap := 0.0069;\nA := 388;\ntheta := deltap / (1/4 + varpi);\nthetat := ((deltap - delta)/2 + varpi) / (1/4 + varpi);\ndeltat := delta / (1/4 + varpi);\nj := BesselJZeros(k0-2,1);\neps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));\nkappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);\nkappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);\nalpha := j^2 / (4 * (k0-1));\ne := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );\ngd := (j^2/2) * BesselJ(k0-3,j)^2;\ntn := sqrt(thetat)*j;\ngn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));\nkappa3 := (gn/gd) * e;\neps2 := 2*(kappa1+kappa2+kappa3);\n# we win if eps2 < eps\n")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("There is a typo in the last line of the code, it should be constraints.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236423")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2013")])]

#text("I’ve been looking at the Type II estimates. My plan was to mimic the “Level 2” and “Level 3” improvements for the Type I estimates to obtain analogous gains in Type II, but I found an interesting phenomenon, in that the critical numerology for the Type II estimates actually fall outside of the range in which the van der Corput type lemmas gain over the completion of sums bound, so the Level 2 and Level 3 estimates are actually ")#emph[#text("worse")]#text(" than the Level 1 estimates. However, I was able to extract a different gain by observing that the parameter R, which currently in the Type II case is constrained to the interval")

#mi("[x^{-2\\varpi-\\delta-\\varepsilon} N, x^{-2\\varpi-\\varepsilon} N]")

#text("could instead be constrained to")

#mi("[x^{1/2-2\\varpi-\\delta-\\varepsilon}, x^{1/2-2\\varpi-\\varepsilon}]")

#text("(which, in retrospect, is closer to what Zhang did originally, though he used ")#mi("-3\\varpi")#text(" instead of ")#mi("-2\\varpi-\\varepsilon")#text(") and this gives slightly better numerology, improving the old constraint of ")#mi("48\\varpi + 7 \\delta < 1/2")#text(" to ")#mi("38 \\varpi + 7 \\delta < 1/2")#text(". In a bit more detail, the two constraints coming out of the Type II analysis are")

#mi("(QR)^6 \\lessapprox x^{2-4\\varepsilon} N^{-1} R^{7/2}")

#text("and")

#mi("(QR)^4 \\lessapprox x^{2-4\\varepsilon} N^{-2} R^{3}")

#text("and if one inserts the bounds ")#mi("QR \\lessapprox x^{1/2+2\\varpi}")#text(", ")#mi("N \\lessapprox x^{1/2}")#text(", and ")#mi("R \\gtrapprox x^{1/2-2\\varpi-\\delta-\\varepsilon}")#text(" one obtains the constraints")

#mi("19 \\varpi + \\frac{7}{2} \\delta < \\frac{1}{4}")

#text("and")

#mi("14 \\varpi + 3 \\delta < \\frac{1}{2}")

#text("which lead to the stated constraint ")#mi("38 \\varpi + 7 \\delta < \\frac{1}{2}")#text(".")

#text("Setting ")#mi("\\delta=0")#text(", the critical numerology for Type 2 is then ")#mi("\\varpi = 1/76")#text(", ")#mi("N=M=x^{1/2}")#text(", ")#mi("R = x^{1/2-2\\varpi}")#text(", ")#mi("Q = x^{2\\varpi}")#text(", ")#mi("H = x^{6\\varpi}")#text(". In Lemma 11, the modulus ")#mi("d := r[q_1,q^{\\prime}_1,q_2,q^{\\prime}_2]")#text(" should be of size ")#mi("Q^4 R \\approx x^{1/2+14\\varpi}")#text(", while ")#mi("N")#text(" is of size ")#mi("x^{1/2}")#text(", so ")#mi("N \\sim d^{19/26} \\approx d^{0.731}")#text(", which is too large for a single van der Corput estimate to be useful (but potentially a combination of the A and B process might barely squeeze a slight gain in this regime).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236455")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Perhaps the parameters (")#mi("(1/2, -2, -1) and (1/2, -2, 0)")#text(") defining the range of ")#mi("R")#text(" are still not the optimal ones? (if so, they may be optimized.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236481")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("A good question!")

#text("The constraints on R arise in the following ways. Generally, one would like R to be as large as possible, as most of the bounds we need are of the form ")#mi("X \\lessapprox Y R^\\alpha")#text(" for various positive exponents ")#mi("\\alpha")#text(", and various quantities ")#mi("X,Y")#text(" that do not depend on R. (Ultimately, this is because R represents the portion of the modulus that we do not perform Cauchy-Schwarz on (when moving from (35) to (36) in the main post.) On the other hand, due to the ")#mi("x^\\delta")#text("-densely divisible hypothesis, we can only localise R to an interval of the form ")#mi("[x^{-\\delta} R_0, R_0]")#text(", where we are free to choose ")#mi("R_0")#text(". So we would generally like ")#mi("R_0")#text(" to be large as possible as well.")

#text("However, there is a “diagonal” contribution coming from the case when ")#mi("q_1,q_2")#text(" have a common factor which needs to also be addressed; this is only briefly mentioned in this post (near (38)), but is done in more detail in the treatment of (32) in ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text(" . The treatment of this case is complicated, but produces three upper bounds required on R, namely")

#mi("R \\lessapprox x^{-c} N")

#mi("R \\lessapprox x^{-c} M")

#mi("QR \\times R \\lessapprox x^{-c} NM")#text(" (*)")

#text("Note that these quantities also necessarily obey the conditions ")#mi("NM \\sim x")#text(" and ")#mi("QR \\lessapprox x^{1/2+2\\varpi}")#text(".")

#text("In the Type I case (when ")#mi("N \\lessapprox x^{1/2-2\\varpi}")#text(") it is the first constraint that dominates, so that one sets ")#mi("R_0 := x^{-c} N")#text(" for some small c. But in the Type II case (when ")#mi("x^{1/2-2\\varpi} \\lessapprox N \\lessapprox x^{1/2}")#text(") it is the last case that dominates, so the largest ")#mi("R_0")#text(" can be here is ")#mi("x^{1/2-2\\varpi-c}")#text(".")

#text("However, it is possible that one could treat (32) a bit more efficiently. It seems unlikely that R could usefully ever be larger than N (otherwise it becomes pointless to try to Cauchy-Schwarz on the residue class ")#mi("n \\text{ mod } r")#text(") but I don’t immediately have a good explanation as to why the condition (*) is so necessary. One might indeed be able to save a few more factors of ")#mi("\\varpi")#text(" this way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236482")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Actually, now that I look at it I think that (*) can indeed be removed, although it requires some technical modifications to the argument. Specifically, the controlled multiplicity hypothesis")

#mi("\\sum_{C^{-1} x \\leq n \\leq Cx: n = a\\ (r)} \\tau_{{\\mathcal C}}(n)^2 \\ll \\frac{n}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{O(1)}")

#text("(which should have been stated in this post, but was omitted accidentally) needs to be strengthened slightly to")

#mi("\\sum_{C^{-1} x \\leq n \\leq Cx: n = a\\ (r)} \\tau_{{\\mathcal C}}(n)^2 \\tau(n)^C \\ll \\frac{n}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{O(1)}")#text(" (**)")

#text("but in the applications we need, this strengthening is available.")

#text("Henceforth all equation references are referring to ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text(" .")

#text("We redo the estimation of the non-coprime contribution (32). Repeating the arguments in the previous post, we arrive at the task of bounding")

#mi("\\sum_{q_0>1: (q_0,r)=1} \\sum_m \\psi_M(m) \\sum_{n_1,n_2: n_1 = n_2\\ (r); b^{\\prime}_{q_0} n_1 = b_{q_0} n_2\\ (q_0); mn_1 = a_r\\ (r); mn_1 = b_{q_0}\\ (q_0)}")

#tao-math("\\left|\\beta(n_1)\\right| |\\beta(n_2)| \\tau_b(mn_1)^2", block: false)

#text("by ")#mi("\\ll N^2 M R^{-2} \\log^{-A} x")#text(" (plus a symmetric term that is treated similarly). As before, we crucially have that ")#mi("q_0")#text(" has no prime factors smaller than ")#mi("D_0")#text(".")

#text("We now deviate from the previous post (which performed the m summation at this point) by introducing the new variable ")#mi("s := mn_1")#text(", which is comparable to x, and rearranging the above expression as")

#mi("\\sum_{q_0>1: (q_0,r)=1} \\sum_{s \\sim x: s = a_r\\ (r); s = b_{q_0}\\ (r)} \\tau_b(s)^2")

#tao-math("\\sum_{s = m n_1} \\psi_M(m) |\\beta(n_1)| \\sum_{n_2: n_2=n_1\\ (r); b_{q_0} n_2 = b^{\\prime}_{q_0} n_2\\ (q_0)} \\left|\\beta(n_2)\\right|", block: false)#text(".")

#text("The ")#mi("n_2")#text(" sum is ")#mi("\\ll \\frac{N}{q_0 R} \\tau(rq_0)^{O(1)} \\log^{O(1)} x + x^{o(1)}")#text(" by crude estimates. By the divisor bound, the ")#mi("\\sum_{s=mn_1}")#text(" sum is then ")#mi("\\ll \\frac{N}{q_0 R} \\tau(s)^{O(1)} \\tau(rq_0)^{O(1)} \\log^{O(1)} x + x^{o(1)}")#text(" by crude bounds. By using the improved controlled multiplicity hypothesis (**), the ")#mi("x")#text(" sum is then")

#mi("\\ll \\frac{x}{q_0R} \\frac{N}{q_0 R} \\tau(rq_0)^{O(1)} \\log^{O(1)} x + \\frac{x}{q_0 R} x^{o(1)}.")

#text("(noting that ")#mi("q_0 R \\leq QR \\ll x^{1/2+2\\varpi} \\ll x")#text("), and then finally the ")#mi("q_0")#text(" sum is")

#mi("D_0^{-1} \\frac{xN}{R^2} \\tau(r)^{O(1)} \\log^{O(1)} x + \\frac{x^{1+o(1)}}{R}")

#text("and this is acceptable given the single condition")

#mi("R \\lessapprox x^{-\\varepsilon} N")

#text("for some fixed ")#mi("\\varepsilon > 0")#text(". So we can set ")#mi("R_0 := x^{-\\varepsilon} N")#text(" in both the Type I and Type II cases. Returning to the Type II analysis from my comment above, the constraints")

#mi("(QR)^6 \\lessapprox x^{2-4\\varepsilon} N^{-1} R^{7/2}")

#text("and")

#mi("(QR)^4 \\lessapprox x^{2-4\\varepsilon} N^{-2} R^{3}")

#text("should now be rearranged as")

#mi("(QR)^6 \\lessapprox x^{2-4\\varepsilon} (R/N)^{7/2} N^{5/2}")

#text("and")

#mi("(QR)^4 \\lessapprox x^{2-4\\varepsilon} (R/N)^3 N")

#text("and using the bounds ")#mi("R/N \\gg x^{-\\delta} R_0/N \\gg x^{-\\delta-\\varepsilon}")#text(", ")#mi("QR \\ll x^{1/2+2\\varpi}")#text(" and ")#mi("N \\gg x^{1/2-2\\varpi-c}")#text(", we are left with the constraints")

#mi("6(\\frac{1}{2} + 2 \\varpi) < 2 - \\frac{7}{2} \\delta + \\frac{5}{2} (\\frac{1}{2} - 2\\varpi)")

#text("and")

#mi("4(\\frac{1}{2} + 2 \\varpi) < 2 - 3 \\delta + (\\frac{1}{2} - 2\\varpi)")

#text("which rearrange to")

#mi("34 \\varpi +  7 \\delta < \\frac{1}{2}")

#text("and")

#mi("10 \\varpi + 3 \\delta < \\frac{1}{2}")#text(".")

#text("The second condition is redundant, leaving us with a \"Level 1c\" Type II constraint of ")#mi("34 \\varpi + 7 \\delta < \\frac{1}{2}")#text(", improving upon the previous constraint ")#mi("38 \\varpi + 7 \\delta < \\frac{1}{2}")#text(". Since even the most optimistic projections we have so far do not foresee ")#mi("\\varpi")#text(" going below 1/74, it now looks like the Type II estimates are good enough for the near-term that they will not cause any further difficulty.")

#text("Thanks for raising the question!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236489")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("I’m glad to see such fast improvement! (my last suggestion to optimize the parameters at the end of the project was sent before I read your response!)")#linebreak()#text(" Anyway, perhaps at the end of the project, it may be possible to optimize similar parameters when all the necessary limitations on them will become clear from the detailed proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236484")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Perhaps such optimization (if possible) should be tried at the end of the project (when all the needed restrictions on the parameters will be known from the detailed proof.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236494")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("I’ve been trying to figure out how the combinatorial lemma has influenced the creation of types 0,I,II,III; and conversely, how some natural cut-offs in estimating certain sums has influenced the creation of the combinatorial lemma. Further, I wanted to know if there was some sort of combinatorial improvement that could be made. In that spirit, let me describe how I now view things. This likely won’t be earthshattering for the experts, but may be helpful to those “occasional number-theorists” like myself.")

#text("For record keeping, let ")#mi("\\varphi_1,\\ldots,\\varphi_m")#text(" be coefficient sequences at scales ")#mi("M_1,\\ldots, M_m")#text(", and let ")#mi("\\psi_1,\\ldots,\\psi_n")#text(" be smooth coefficient sequences at scales ")#mi("N_1, \\ldots, N_n")#text(". We take positive real numbers ")#mi("s_1,\\ldots, s_m, t_1,\\ldots, t_n")#text(" such that ")#mi("x^{s_i} \\ll M_i \\ll x^{s_i}")#text(" and ")#mi("x^{t_j} \\ll N_j \\ll x^{t_j}")#text(". We also assume ")#mi("x \\ll M_1 \\cdots M_m N_1 \\cdots N_n \\ll x")#text(", and so ")#mi("\\sum_{i}s_i+\\sum_{j}t_j=1")#text(". (Note: These real numbers are not fixed, but can change with ")#mi("x")#text(". However, I’m postulating (from the answer to Avi Levy’s recent question), we can assume some sort of law of excluded middle, which I will use implicitly throughout this comment.) For simplicity, we assume ")#mi("s_1\\geq \\ldots \\geq s_m")#text(" and ")#mi("t_1\\geq \\ldots \\geq t_n")#text(". Furthermore, we may assume ")#mi("t_n\\geq s_1")#text(" from how the coefficient sequences are created; the non-smooth sequences are (basically) convolutions of even smaller smooth sequences. (This assumption isn’t essential, but often helps simplify things.)")

#text("We want to estimate quantities (with possible future modifications to “doubly dense divisibility”) of the form")

#tao-math("\\sum_{q\\in \\mathcal{S}_I \\cap \\mathcal{D}_{x^{\\delta}}:q<x^{1/2+2\\varpi}}\\left|\\Delta(\\varphi_1\\ast\\cdots \\ast \\varphi_m\\ast \\psi_1\\ast\\cdots\\ast \\psi_n;a_q)\\right|", block: false)#text(".")

#text("Intuitively speaking, we want more ")#mi("\\psi")#text("'s than ")#mi("\\varphi")#text("'s, since smoothness helps us. It is also my impression that we don't want too many terms in the Dirichlet convolution, or the sums is difficult to bound well. (But this is not always the case. For instance, the case ")#mi("m=1,n=0")#text(" is not always better than the Type I/II case where ")#mi("m=2,n=0")#text(".) We often will combine some of the convolutions into a single term, but at the cost of sometimes losing smoothness. We say that the sum above is of signature ")#mi("(m;n)")#text(".")

#text("Now come the combinatorics. I want to address two specific cases. First consider when ")#mi("\\sigma=1/4")#text(". This is on the cups of what is not allowed using (the current) Type I-4 bounds. I believe that this will turn out to be a natural barrier, otherwise (as we'll see shortly) one could reprove Zhang's result without any Type III analysis.")

#text("Consider what happens when ")#mi("t_1")#text(" is large. Indeed, if ")#mi("t_1 \\geq 1/2+2\\varpi +\\epsilon")#text(" then we are in the Type 0 case. What happens if ")#mi("t_1")#text(" is not quite so large? In the range ")#mi("1/2-2\\varpi -\\epsilon \\leq t_1 \\leq 1/2+2\\varpi+\\epsilon")#text(" we can reduce to the Type II regime, by combining all coefficient sequences except ")#mi("\\psi_1")#text(" into a single term. Note that we have an added bonus; one of the two convolved functions is smooth! In the range ")#mi("1/2-\\sigma \\leq t_1 \\leq 1/2-2\\varpi-\\epsilon")#text(" we can similarly reduce to Type I, again with the bonus that the smaller of the two coefficient sequences is smooth.")

#text("Now, let's consider the other end of the spectrum, where ")#mi("t_1")#text(" is small. If ")#mi("t_1 < 1/4")#text(" then ")#mi("s_i,t_j<1/4")#text(" for all ")#mi("i,j")#text(". Thus, recombining the sequences we can reduce to signature ")#mi("(2;0)")#text(" where ")#mi("1/4 < s_1,s_2< 3/4")#text(". This is again Type I/II (but without the added bonus of at least one sequence being smooth). Further, when ")#mi("\\sigma=1/4")#text(", this covers all possible cases.")

#text("Finally, we will look at the case when ")#mi("\\sigma=1/12")#text(", which is outside the current combinatorial bounds. The cases when ")#mi("t_1")#text(" is large are dealt with in exactly the same way as above. Similarly, if ")#mi("t_1 < 2\\sigma=1/6")#text(", we can reduce to the Type I/II analysis as above. So, we reduce to the case when ")#mi("1/6\\leq t_1 \\leq 5/12")#text(".")

#text("Zhang's combinatorial method here seems to consist of counting how many other ")#mi("t")#text("'s can possibly belong to this same interval, while (without loss of generality) restricting ")#mi("s_i<1/6")#text(", and further thinking of any ")#mi("t<1/6")#text(" as an ")#mi("s")#text(" (i.e. forgetting about the smoothness of such sequences).")

#text("(A) Suppose ")#mi("t_1")#text(" is the only ")#mi("t")#text(" in the given interval. Then ")#mi("\\sum_i s_i\\geq 7/12")#text(", and taking just enough of the ")#mi("\\varphi")#text("'s and attaching them to ")#mi("\\psi")#text(", we reduce to Type I/II.")

#text("(B) Suppose ")#mi("t_1, t_2")#text(" are the only ")#mi("t")#text("'s in the given interval. Attaching all of the ")#mi("\\varphi")#text("'s to ")#mi("\\psi_2")#text(" would give a sequence of size ")#mi("1-t_1\\geq 7/12")#text(", and so there is some subcollection of the ")#mi("\\varphi")#text("'s which when attached to ")#mi("\\psi_2")#text(" given a sequence of size between ")#mi("5/12,7/12")#text(". Attaching the remainder of the ")#mi("\\varphi")#text("'s to ")#mi("\\psi_1")#text(" reduces to Type I/II.")

#text("(C) If there are more than six ")#mi("t")#text("'s in the interval, then we reach a contradiction since in that case ")#mi("\\sum_{j}t_j \\geq 7(1/6)")#text(".")

#text("(D) If there are exactly six ")#mi("t")#text("'s in the interval, then we have ")#mi("t_1=t_2=\\cdots=t_6=1/6")#text(". We reduce to type II by combining ")#mi("\\psi_1,\\psi_2,\\psi_3")#text(", and then combining the remaining sequences.")

#text("(E) If there are exactly five ")#mi("t")#text("'s in the interval, then we have a new situation that wasn't covered by the combinatorial lemma. (This is one of the reasons for the cutoff at ")#mi("\\sigma=1/10")#text(".) This can happen, for instance if ")#mi("t_1=t_2=\\cdots=t_5=1/5")#text(". There are a few ways to deal with this new situation; depending on which of the signatures ")#mi("(1,5),(1,4),(2,4),(1,3),\\ldots")#text(" is most manageable.")

#text("(F) Suppose ")#mi("t_1,t_2,t_3,t_4")#text(" are the only ")#mi("t")#text("'s in the interval (and so ")#mi("n=4")#text("). If ")#mi("5/12\\leq t_i+t_j\\leq 7/12")#text(" for some pair ")#mi("i\\neq j")#text(", then we reduce to Type I/II. If ")#mi("t_i+t_j<5/12")#text(" for every distinct pair, then ")#mi("\\sum_i s_i=1-\\sum_j t_j \\geq 1-5/12-5/12=1/6")#text(". Thus, combining/convolving the sequences ")#mi("\\psi_1,\\psi_2")#text(" and all ")#mi("\\varphi")#text("'s, we have size ")#mi("\\geq 1/6+1/6+1/6=1/2")#text(". As in case (B), we reduce to Type I/II.")

#text("Thus, we reduce to when ")#mi("7/12 <  t_1+t_2")#text(". If ")#mi("7/12 <t_2+t_3")#text(" then we are in Type III (combining ")#mi("\\psi_4")#text(" with all the ")#mi("\\varphi")#text("'s). So, we may also assume ")#mi("t_2+t_3< 5/12")#text(". Thus, we have")

#mi("7/24 < t_1 < 10/24, 4/24< t_3,t_4<5/24")

#text("But ")#mi("5/12<7/24+4/24=11/24")#text(" and so ")#mi("7/12<t_1+t_4")#text(". Thus ")#mi("9/24= 7/12-5/24<7/12-t_4<t_1")#text(". This situation is possible, for example when we have (approximately)")

#mi("t_1, t_2,t_3=5/24,\\ t_4=9/24")#text(".")

#text("(G) Finally, consider the case when ")#mi("n=3")#text(". As before, we may assume we *cannot* recombine and reduce to types I/II/III. If ")#mi("t_1+t_2<5/12")#text(" then we easily obtain ")#mi("t_3\\leq t_2< 5/24")#text(" and so ")#mi("\\sum_i s_i \\geq 9/24")#text(". This easily reduces to Type I/II. So ")#mi("7/12<t_1+t_2")#text(", and as we are not in Type III we have ")#mi("t_2+t_3 < 5/12")#text(". As in (F), we can reduce to the case where")

#mi("9/24 < t_1 < 10/24, 4/24 < t_3 < 5/24")

#text("and so we also obtain, ")#mi("t_2< 6/24")#text(". This leaves ")#mi("\\sum_i s_i \\geq 1/6")#text(". Thus, we can combine some of the ")#mi("\\varphi")#text("'s with ")#mi("\\psi_1")#text(", and reduce to Type I/II again. So there are no extra cases here.")

#text("Observations:———-")

#text("Can we improve on this? There are at least two ways to proceed; whether they improve things remains to be seen. Instead of counting the number of indices in the interval ")#mi("2\\sigma\\leq t_i\\leq 1/2-\\sigma")#text(", we could continue with the (possibly more natural) process of considering signatures in order. So, for example, we might consider what happens for the signature ")#mi("(1,2)")#text(" (with the two smooth sequences having fairly \"large\" scales), and ply this against the Type III analysis. Indeed, this is somewhat suggested by the current form that the Type III computations take. Those estimate gives ")#mi("3t_1 + 3t_2 + 4t_3\\approx 3+12\\varpi +\\delta+\\epsilon")#text(" (where here we can take ")#mi("t_2<t_3")#text(" if we like, which we do). So, we want ")#mi("t_3")#text(" as large as possible (and hence we want ")#mi("t_3=t_1")#text("). Thus, we are naturally led to consider the case when there are two, nearly equal, large scales.")

#text("Another (possibly less helpful) option would be to consider signatures of the form ")#mi("(3,0)")#text(". If we could do a Type III analysis without the smoothness hypothesis, this would remove the combinatorial constraint ")#mi("1/10<\\sigma")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Thanks for this analysis!")

#text("It’s a nice observation that the Type I/II case could stretch to cover all cases if ")#mi("\\sigma")#text(" could be raised to 1/4. This might lead to a simpler proof of Zhang’s theorem (in particular, not relying on Deligne’s version of the Weil conjectures, only Weil’s original results which nowadays can also be proven by elementary means) for sufficiently small ")#mi("\\varpi")#text(" by eliminating the Type III analysis. But for the task of getting ")#mi("\\varpi")#text(" as big as possible we presumably need an “all hands on deck” approach in which we throw all the estimates we have at the problem.")

#text("Actually, now that I think about it, ")#mi("\\sigma=1/6")#text(" might already be big enough for this purpose, as this is the meeting point between ")#mi("2\\sigma")#text(" and ")#mi("1/2-\\sigma")#text(". So the Level 3 or Level 4 Type I estimates (combined with Type II) might already give a proof of Zhang’s theorem!")

#text("In the other direction, with regards to trying to push ")#mi("\\sigma")#text(" below 1/10, I think the two new critical cases to consider will be a “Type IV” sum in which n=4 and ")#mi("(t_1,t_2,t_3,t_4)")#text(" is close to ")#mi("(1/5,1/5,1/5,2/5)")#text(" and a “Type V” sum in which n=5 and ")#mi("(t_1,t_2,t_3,t_4,t_5)")#text(" is close to ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" (I have not figured out exactly what “close to” means though). This basically corresponds to distribution results (for smooth or densely divisible moduli) for the higher order divisor functions ")#mi("d_4")#text(" and ")#mi("d_5")#text(". I am unsure if there are any fancy arguments in the literature (beyond the Zhang-based ones) that beat Bombieri-Vinogradov in this context; it seems that ")#mi("d_3")#text(" is pretty much state of the art. But this is certainly a good direction to focus attention on, though perhaps not by Polymath8; new ways to control ")#mi("d_4")#text(" and ")#mi("d_5")#text(" would be very interesting beyond just the ability to squeeze a few more improvements to ")#mi("\\varpi")#text(", ")#mi("k_0")#text(", and ")#mi("H")#text(". (I could imagine that Polymath8 eventually gets to the point where the ")#mi("\\sigma > 1/10")#text(" constraint is the dominant obstruction, and then calls it a day, leaving it to others in the field to start attacking ")#mi("d_4")#text(" and ")#mi("d_5")#text(" and get some improvements to ")#mi("\\varpi")#text(" etc. as a bonus.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236513")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Yes, I believe that you are right that ")#mi("\\sigma=1/6")#text(" is already good enough (if you can deal with the “endpoint” case of ")#mi("t_1=t_2=t_3=1/3")#text("). It would be neat to see that lead to a simpler proof of Zhang’s theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236514")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("I see from your new Level 4 Type III analysis, that some of my observations may have been unwarranted. However, it still may be the case that those sums of signature ")#mi("(1;2)")#text(" naturally fit “inbetween” the Type I/II sums (whose signature is ")#mi("(2;0)")#text(") and the Type III sums (whose signature is ")#mi("(1;3)")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236527")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("If we can get to the point where ")#mi("\\sigma > 1/10")#text(" is the main obstruction, where does that leave us with ")#mi("\\varpi")#text(", taking all optimistic projections into account? And what about ")#mi("k_0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236539")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Actually, with the Level 4 Type III estimates, we’ve just reached this point – so ")#mi("\\varpi")#text(" is basically stuck at 1/108 right now until we improve the Type I estimates again beyond Level 3. We do have an in principle improvement here (“Level 4”) by using an iterated van der Corput, but it is not yet implemented. In principle, this estimate give something like ")#mi("40\\varpi + 4 \\sigma < 1")#text(" (ignoring deltas), so if we play that against ")#mi("\\sigma > 1/10")#text(" that should give ")#mi("\\varpi < 3/200")#text(", though 3/200 ~ 1/67 is large enough that the Type II and Type III estimates will have to be improved again before we can actually reach this point.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236596")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("If ")#mi("40\\varpi + 4 \\delta < 1")#text(", it is easily to obtain ")#mi("k_0 = 300")#text(" (e.g., for ")#mi("\\varpi=1/40-1.9582/10^5, \\delta^{\\prime}=0.0079, A=86")#text(", based on a rough search using a simple nonlinear optimizer calling with the maple script), if the calculation is correct. This will totally fall into the region of Engelsma's exact bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69328ca38020bfdb13e572a59ca53eaf4bd575cc30bf6a9da7fcbe218b11e62b-35ac0fb53b4d8dfdaafdeca5cc6d4320e35ac400b23bc0818982f7d91f3d6ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("Unfortunately Xfxie the inequality in Tao’s comment is in “sigma” not “delta” the inequality above comes from the type 1 inequality and still needs to be confronted with type 3’s to eliminate sigma and get the final inequality. There is no delta in the inequality because he just wants a rough idea of the result (and because that factor wasn’t calculated yet).")#linebreak()#text(" Can you share the optimizer you are using I guess it could save some time here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236605")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("@Anonymous: I have to reply here because cannot find the reply button under your thread.")

#text("The optimizer code is currently located on my home machine. I will try to post the code tonight or soon.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("In this comment I will upgrade another estimate, specifically to upgrade the “Level 3” Type III estimate of Fouvry, Kowalski, Michel, and Nelson to a “Level 4” estimate that exploits averaging in the alpha parameter to reduce the contribution of the diagonal terms (this idea was used in the “Level 2” estimates and was also suggested by FKMN). We will be largely repeating the arguments from the previous comment ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236237")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236237")]#text(" .")

#text("As in that comment, the objective is to show that")

#mi("\\sum_{r \\sim R} \\sum_{s \\sim S: (r,s)=1} |\\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a_{rs}\\ (rs))| \\lessapprox x^{-\\varepsilon} M N")

#text("for ")#mi("RS=Q")#text(" that we can specify to accuracy ")#mi("x^\\delta")#text(", thus we may place ")#mi("R")#text(" in ")#mi("[x^{-\\delta} R_0, R_0]")#text(" for some ")#mi("R_0")#text(" to be chosen later, and ")#mi("N = N_1 N_2 N_3")#text(".")

#text("FKMN discard the averaging in ")#mi("\\alpha")#text(" or ")#mi("s")#text(". For Level 4 estimates, we still discard the s averaging (there isn’t really any plausible way we know of to exploit it thus far) but keep the alpha average. We are now looking at")

#mi("\\sum_{r \\sim R: (r,s)=1} |\\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a_{rs}\\ (rs))| \\lessapprox x^{-\\varepsilon} M N / S.")

#text("This may be rewritten as")

#mi("\\sum_r c_r \\sum_m \\alpha(m) \\sum_{n_1,n_2,n_3} \\psi_1(n_1) \\psi_2(n_2) \\psi_3(n_3) 1_{m n_1n_2n_3 = a_{rs}\\ (rs)}")

#mi("= X + O( x^{o(1)} M N / S )")

#text("where ")#mi("X")#text(" does not depend on the residues ")#mi("a_{rs}")#text(", and the ")#mi("c_r")#text(" are bounded and only supported on those ")#mi("r \\sim R")#text(" coprime to ")#mi("s")#text(". We can similarly restrict ")#mi("\\alpha")#text(" to those ")#mi("m")#text(" that are coprime to ")#mi("s")#text(".")#linebreak()#text(" Performing completion of sums in the ")#mi("n_1,n_2,n_3")#text(" variables, the left-hand side can be expressed as")

#mi("\\frac{1}{H} \\sum_{h_1=O(H_1), h_2 = O(H_2), h_3 = O(H_3); h_1h_2h_3 \\neq 0} | \\sum_r c_r \\sum_{m: (m,r)=1} \\alpha(m)")

#mi("\\sum_{x,y,z \\in {\\bf Z}/rs{\\bf Z}: mxyz = a_{rs}\\ (rs)} e_{rs}(h_1 x + h_2 y + h_3 z)|")#text(" (*)")

#text("plus terms which do not depend on ")#mi("a_{rs}")#text(" (coming from the cases when at least one of the ")#mi("h_i")#text(" vanish), where ")#mi("H_i = Q/N_i")#text(" and ")#mi("H = H_1 H_2 H_3 = Q^3/N")#text(". Ignoring for this discussion the coprimality problem mentioned in a previous comment, the inner sum may be rescaled as")

#mi("rs K_3( a_{rs} h_1 h_2 h_3 / m; rs )")

#text("as before, so we may gather terms and write the expression (*) as")

#mi("\\frac{Q}{H} \\sum_{h = O(H): h \\neq 0} \\tilde d_3(h) \\sum_r c^{\\prime}_r \\sum_{m: (m,r)=1} \\alpha(m) K_3( a_{rs} h / m; rs )")

#text("as before. The objective is now to show")

#mi("\\sum_{h = O(H): h \\neq 0} \\tilde d_3(h) |\\sum_r c^{\\prime}_r \\sum_{m: (m,r)=1} \\alpha(m) K_3( a_{rs} h / m; rs )| \\lessapprox x^{-\\varepsilon} QRM.")

#text("By Cauchy-Schwarz as in the previous comment it suffices to show that")

#tao-math("\\sum_{h = O(H)} \\left|\\sum_r c^{\\prime}_r \\sum_{m: (m,r)=1} \\alpha(m) K_3( a_{rs} h / m; rs )\\right|^2 \\lessapprox x^{-2\\varepsilon} Q^2 R^2 / H.", block: false)#text(" (**)")

#text("We can rearrange the LHS as")

#mi("\\sum_{r_1, r_2} c^{\\prime}_{r_1} \\overline{c^{\\prime}_{r_2}} \\sum_{m_1,m_2: (m_1,r_1)=(m_2,r_2)=1} \\alpha(m_1) \\overline{\\alpha(m_2)}")

#mi("\\sum_{h = O(H)} K_3(a_{r_1s} h / m_1; r_1s) \\overline{K_3(a_{r_2s} h / m_2; r_2s)}")#text(".")

#text("The summand is periodic in h with period ")#mi("[r_1,r_2] s")#linebreak()#text(" One then performs completion of sums in ")#mi("h")#text(", using the Chinese remainder theorem and Deligne’s estimates to estimate the completed sums, and eventually ends up with a bound on the inner sum of the form")

#mi("\\lessapprox (\\frac{H}{[r_1,r_2] s} + 1)")#linebreak()#text(" ")#mi("d (s/d)^{1/2} r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}")

#text("where ")#mi("r_0 := (r_1,r_2,m_2-m_1)")#text(" and ")#mi("d := (m_2r_1^3-m_1 r_2^3, s)")#text("; the insertion of the m factors is the key new improvement here. So now one has to sum")

#mi("\\sum_{r_1,r_2 \\sim R: (r_1r_2, s) = 1} \\sum_{m_1,m_2 \\sim M: (m_1,r_1s)=(m_2,r_2s)=1}")#linebreak()#text(" ")#mi("(\\frac{H r_0}{r_1 r_2 s} + 1) d (s/d)^{1/2} r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}.")

#text("The diagonal case ")#mi("m_1=m_2")#text(" contributes a term of")

#mi("\\lessapprox M( R^3 S^{1/2} + HR + R^2 S  )")

#text("by repeating the arguments from the previous comment. Now we turn to the off-diagonal contributions ")#mi("m_1 \\neq m_2")#text(". Among other things this forces ")#mi("r_0")#text(" to divide ")#mi("m_1-m_2")#text(", which already gives a noticeable gain (and forces ")#mi("r_0")#text(" to be only as large as ")#mi("O(M)")#text(").")

#text("Fix ")#mi("m_1,m_2")#text(". The same computation as the previous comment shows that for each choice of ")#mi("r_0 | m_1-m_2")#text(" and ")#mi("d|s")#text(", the number of pairs ")#mi("r_1,r_2")#text(" with ")#mi("r_0=(r_1,r_2,m_1-m_2)")#text(" and ")#mi("d = (m_2r_1^3-m_1r_2^3,s)")#text(" is ")#mi("\\lessapprox \\frac{R^2}{r_0^2 d} + \\frac{R}{r_0}")#text(". (There are ")#mi("O(R/r_0)")#text(" choices for ")#mi("r_1")#text(", and for fixed ")#mi("r_1")#text(" there are ")#mi("O( R_0/r_0d + 1)")#text(" choices for ")#mi("r_2")#text(".)")

#text("So now one is summing")

#mi("\\sum_{m_1 \\neq m_2} \\sum_{d|s} \\sum_{r_0|m_1-m_2} (\\frac{R^2}{r_0^2 d} + \\frac{R}{r_0})")

#mi("(\\frac{H r_0}{r_1 r_2 s} + 1) d (s/d)^{1/2} r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}")#text(".")

#text("One can perform the ")#mi("d")#text(" summation without difficulty and end up with")

#mi("\\lessapprox \\sum_{m_1 \\neq m_2} \\sum_{r_0|m_1-m_2} (\\frac{R^2 s^{1/2}}{r_0^2} + \\frac{R s}{r_0})")

#mi("(\\frac{H r_0}{r_1 r_2 s} + 1) r_0 (r_1/r_0)^{1/2} (r_2/r_0)^{1/2}")#text(",")

#text("and then performing the ")#mi("r_0")#text(" summation (which is now improved due to the constraint ")#mi("r_0|m_1-m_2")#text(") this becomes")

#mi("\\lessapprox M^2( H R S^{-1/2} + R^3 S^{1/2} + H + S R^2 )")#text(".")

#text("Collecting terms, it is now")

#mi("M^2 ( H R S^{-1/2} + R^3 S^{1/2} + H + S R^2  ) + M HR")

#text("that we wish to be ")#mi("\\lessapprox x^{-2\\varepsilon} M^2 Q^2 R^2 / H")#text(".")#linebreak()#text(" Ignoring epsilons, this gives rise to upper and lower bounds on R:")

#mi("R \\gtrapprox H^{4/3}/Q^{5/3}")

#mi("R \\lessapprox Q^3 / H^2")

#mi("R \\gtrapprox H/Q")

#mi("R \\gtrapprox H/Q")

#mi("R \\gtrapprox H^2 / (Q^2 M)")#text(".")

#text("So we now have")

#mi("H^2/Q^2M, H/Q, H^{4/3}/Q^{5/3} \\lessapprox R \\lessapprox Q^3 / H^2")#text(".")

#text("Since ")#mi("R")#text(" has to be at least 1, we need ")#mi("H \\lessapprox Q^{3/2}")#text(", which also makes all the lower bounds on ")#mi("R")#text(" at most ")#mi("Q")#text(". We then win if")

#mi("H^2/Q^2M, H/Q, H^{4/3}/Q^{5/3} \\lessapprox x^{-\\delta} Q^3 / H^2")

#text("which rearranges to")

#mi("H \\lessapprox x^{-\\delta/4} Q^{5/4} M^{1/4}, x^{-\\delta/3} Q^{4/3}, x^{-3\\delta/10} Q^{7/5}")#text(".")

#text("These are stronger than the previous constraint ")#mi("H \\lessapprox Q^{3/2}")#text(" which may now be discarded. Also the last constraint ")#mi("H \\lessapprox x^{-3\\delta/10} Q^{7/5}")#text(" is weaker than ")#mi("H \\lessapprox x^{-\\delta/3} Q^{4/3}")#text(" and may also be dropped. As ")#mi("H = Q^3/N")#text(", the constraints may be rewritten as")

#mi("N \\gtrapprox x^{\\delta/4} Q^{7/4} M^{-1/4}, x^{\\delta/3} Q^{5/3}")

#text("thus")

#mi("N_1 N_2 N_3 \\gtrapprox x^{\\frac{7}{4}(\\frac{1}{2}+2\\varpi) + \\frac{1}{4} \\delta} M^{-1/4}")

#text("and")

#mi("N_1 N_2 N_3 \\gtrapprox x^{\\frac{5}{3}(\\frac{1}{2}+2\\varpi) + \\frac{1}{3} \\delta}")

#text("In terms of ")#mi("\\sigma")#text(", this gives a constraint")

#mi("\\frac{1}{4} + \\frac{3}{4} \\frac{3}{2} (\\frac{1}{2} + \\sigma) > \\frac{7}{4} (\\frac{1}{2} + 2 \\varpi) + \\frac{1}{4} \\delta")

#mi("\\frac{3}{2} (\\frac{1}{2} + \\sigma) > \\frac{5}{3} (\\frac{1}{2} + 2 \\varpi) + \\frac{1}{3} \\delta")

#text("which can be rearranged as")

#mi("\\sigma > \\frac{1}{18} + \\frac{28}{9} \\varpi + \\frac{2}{9} \\delta")

#text("and")

#mi("\\sigma > \\frac{1}{18} + \\frac{20}{9} \\varpi + \\frac{2}{9} \\delta")#text(".")

#text("the first condition dominates, so it looks like the Level 4 Type III constraint is")

#mi("\\sigma > \\frac{1}{18} + \\frac{28}{9} \\varpi + \\frac{2}{9} \\delta")#text(".")

#text("which when combined with the latest Type I and Type II estimates (Level 3 and Level 1c respectively) seems to give the final constraint")

#mi("18 \\varpi + 5 \\delta < \\frac{1}{6}")

#text("which is basically formed by the collision of the ")#mi("\\sigma > 1/10")#text(" constraint and the Level 3 Type I constraint of ")#mi("54 \\varpi + 15 \\delta + 5\\sigma < 1")#text(". Thus the Level 4 Type III estimates are so strong that they are no longer providing the dominant contribution, it is now the clash between Type I and the combinatorial constraint ")#mi("\\sigma > 1/10")#text(" which is the bottleneck; Type III won’t become relevant again until ")#mi("\\varpi")#text(" hits 1/70. (This also means that the above analysis will be fairly robust to numerical errors.)")

#raw("\n with(SolveTools[Inequality]);\n base := [ sigma > 1/10, sigma  0, varpi  0, delta < 1/4+varpi ];\n typeI_1 := [ 11 * varpi + 3 * delta + 2 * sigma < 1/4 ];\n typeI_2 := [ 17 * varpi + 4 * delta + sigma < 1/4, 20 * varpi + 6 * delta + 3 * sigma < 1/2, 32 * varpi + 9 * delta + sigma < 1/2 ];\n typeI_3 := [ 54 * varpi + 15 * delta + 5 * sigma < 1 ];\n typeII_1 := [ 58 * varpi + 10 * delta < 1/2 ];\n typeII_1a := [48 * varpi + 7 * delta < 1/2 ];\n typeII_1b := [38 * varpi + 7 * delta < 1/2 ];\n typeII_1c := [34 * varpi + 7 * delta  8 * (1/2 + 2*varpi) + delta ];\n typeIII_2 := [ 1 + 5 * (1/2 + sigma) > 8 * (1/2 + 2*varpi) + delta ];\n typeIII_3 := [ 3/2 * (1/2 + sigma) > (7/4) * (1/2 + 2*varpi) + (3/8) * delta ];\n typeIII_4 := [ 3/2 * (1/2 + sigma) > (5/3) * (1/2 + 2*varpi) + (1/3) * delta ];\n constraints := [ op(base), op(typeI_3), op(typeII_1c), op(typeIII_4) ];\n LinearMultivariateSystem(constraints, [varpi,delta,sigma]);\n")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236507")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Here I think one can choose ")#mi("k_0 = 902, A = 360, \\delta^{\\prime} = 0.0069, \\varpi = 1/(6\\cdot 18) - 0.735/10^5")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236517")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("Maple okays it :) Thanks to the shiny new ")#link("http://math.mit.edu/~primegaps/")[#text("narrow admissible tuples page")]#text(" (now accepting submissions!), this gives H = 6,966. (Four orders of magnitude improvement!)")

#raw("\nk0 := 902;\nvarpi := 1/(6*18) - 0.735/10^5;\ndelta := (1/6 - 18*varpi)/5;\ndeltap := 0.0069;\nA := 360;\ntheta := deltap / (1/4 + varpi);\nthetat := ((deltap - delta)/2 + varpi) / (1/4 + varpi);\ndeltat := delta / (1/4 + varpi);\nj := BesselJZeros(k0-2,1);\neps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));\nkappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);\nkappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);\nalpha := j^2 / (4 * (k0-1));\ne := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );\ngd := (j^2/2) * BesselJ(k0-3,j)^2;\ntn := sqrt(thetat)*j;\ngn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));\nkappa3 := (gn/gd) * e;\neps2 := 2*(kappa1+kappa2+kappa3);\n# we win if eps2 < eps\n")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236536")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("This script looks strange. Copy-error?")

#emph[#text("[Oops, the first three lines were missing; should be there now. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236614")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("Using this Level 4 Type III analysis, I have an idea [*very* sketchy at the moment] that has the potential to remove any reference to ")#mi("\\sigma")#text(" (thus removing Type I computations), unify Type 0 and Type III into a single result, and trivialize Type II computations.")

#text("Let us begin as above, but with the new objective to obtain the bound")

#mi("\\sum_{r\\sim R}\\sum_{s\\in S:(r,s)=1}|\\Delta(\\alpha\\ast \\psi_1\\ast\\cdots\\ast\\psi_{n};a_{rs}\\ (rs))|\\lessapprox x^{-\\epsilon}MN")

#text("Proceeding as in the comment, the main term of interest in the LHS is")

#mi("\\frac{1}{H}\\sum_{h_1=O(H_1),\\ldots, h_n=O(H_n); h_1\\cdots h_n\\neq 0}|\\sum_r c_r\\sum_{m:(m,r)=1}\\alpha(m)")

#mi("\\sum_{x_1,\\ldots, x_n\\in {\\bf Z}/rs{\\bf Z}: mx_1\\cdots x_n=a_{rs}\\ (rs)} e_{rs}(h_1x_1+\\cdots +h_n x_n)|")#text(" (*)")

#text("Setting ")#mi("h=h_1\\cdots h_n")#text(", and proceeding as before, the changes are twofold. First, replace ")#mi("\\tilde d_3")#text(" by ")#mi("\\tilde d_n")#text(". I believe that this causes no trouble, and can still be handled by the divisor bound. Second, we replace ")#mi("K_3")#text(" by ")#mi("K_n")#text(". Here is where my idea becomes especially sketchy. We need to find a bound on")

#mi("\\sum_{h=O(H)}K_n(a_{r_1s}h;r_1 s)\\overline{K_n(a_{r_2 s}h;r_2 s)}")

#text("of some manageable order. To continue, supposing we get something similar to")

#mi("(\\frac{H}{[r_1,r_2]s}+1) d(s/d)^{1/2}r_0(r_1/r_0)^{1/2}(r_2/r_0)^{1/2}")

#text("(which is what was obtained above in the ")#mi("n=3")#text(" case, possibly here with ")#mi("d")#text(" involving ")#mi("n")#text("th powers), then the rest of the post seems to follow along similar lines. We still end with something *close* to the two conditions")

#mi("N \\gtrapprox x^{\\frac{7}{4}(\\frac{1}{2}+2\\varpi)+\\frac{1}{4}\\delta}M^{-1/4}")

#text("and")

#mi("N \\gtrapprox x^{\\frac{5}{3}(\\frac{1}{2}+2\\varpi)+\\frac{1}{3}\\delta}")#text(".")

#text("These equations (when precisely stated) may now rely on ")#mi("n")#text(", but for simplicity I’ll ignore that. Fix ")#mi("\\epsilon > 0")#text(" and restrict to the case ")#mi("M\\lessapprox x^{\\epsilon}")#text(". Considering all ")#mi("n")#text(" up to a large (but fixed) size, the only combinatorial case not covered is when all scales are smaller than ")#mi("x^{\\epsilon}")#text(". If ")#mi("\\epsilon")#text(" is fine enough we can cover that final case with a Type II analysis (in a significantly shorter interval).")

#text("At any rate, it might be interesting to work out what happens when ")#mi("n=4,5")#text(", as that will partially address the current ")#mi("\\sigma=1/10")#text(" obstruction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ph.M")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236618")[#strong[#text("Ph.M")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("I don’t know for the validity of the argument yet, but the Deligne type estimates for the K_n sums and product thereof possibly with an extra additive character (because polya-vinogradov) are valid exactly as for n=3 and are consequences of ")#link("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.dmj/1077229697")[#text("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.dmj/1077229697")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("It is worth checking out the numerology for, say, n=4, ")#mi("M = 1")#text(", ")#mi("N_1=N_2=N_3=N_4 = x^{1/4}")#text(" (even though this particular case can also be handled by Type II methods) and ")#mi("RS = x^{1/2+\\varepsilon}")#text(", ")#mi("\\varpi,\\delta \\approx 0")#text(" to see if we can just beat Bombieri-Vinogradov for ")#mi("d_4")#text(" in the most favorable case by this method. I think the numerology may become a less favorable though (the normalisation of ")#mi("K_4(a, q)")#text(" for instance, should have a factor of ")#mi("\\frac{1}{q^{3/2}}")#text(" in front rather than ")#mi("\\frac{1}{q}")#text(" to reflect the expected square root cancellation). There is also the additional issue that a certain amount of algebraic geometry (ell-adic sheaf cohomology, this sort of thing) is needed to actually justify the expected square root cancellation for sums such as ")#mi("\\sum_h K_4(a_{r_1} h; rs) \\overline{K_4(a_{r_2} h; rs)} e_{rs}(ch)")#text(" but we can cross that bridge when we come to it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ph.M")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236620")[#strong[#text("Ph.M")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("As said above algebraic geometry is not at all a problem here; my greatest worry as you said is that ")#mi("H=Q^n/N_1\\cdots N_n")#text(" will get huge if ")#mi("n")#text(" is large so that an important term in Polya-Vinogradov will be the zero frequency: for these one need a weight dropping phenomenon (more than square-root cancellation) for the complete sums, ")#mi("n=4")#text(" say,")

#mi("\\displaystyle \\sum_{h(p)}K_n(h;p)")

#text("and")

#mi("\\displaystyle \\sum_{h(p), (h,p)=1}\\overline{K_n(h;p)}K_n(ah;p)")

#text("where ")#mi("(a,p)=1")#text(": these sums can probably be evaluated in an elementary way and then their size may determine whether this has a chance for ")#mi("n\\geq 4")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236639")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("Thanks for the pointers. It looks like this idea won’t work out, but it gives me good motivation to understand the arguments better.")

#text("If it does turn out that ")#mi("n=4")#text(" gives a natural barrier, there is yet another way to beat the combinatorial restriction. If we are not in type 0,I,II, then we can still reduce to the case where there exist at least three real numbers in the range ")#mi("2\\sigma \\leq t_i\\leq 1/2-\\sigma")#text(". In general, we no longer have that ")#mi("t_1+t_2+t_3 \\geq \\frac{3}{2}(\\frac{1}{2}+\\sigma)")#text(", but we can use the poorer lower bound ")#mi("t_1+t_2+t_3\\geq 6\\sigma")#text(". Unfortunately, with the current Level 4 Type III bounds, this gives")

#mi("\\sigma \\geq \\frac{5}{36} +\\frac{7}{9}\\varpi+ \\frac{1}{18}\\delta \\geq 1/10")

#text("so it doesn’t help us (yet).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236652")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("After a nice discussion over lunch with Philippe Michel (who happens to be in LA currently), I now have a clearer idea of why the Type III argument of FKMN beats Bombieri-Vinogradov for n=3 but just barely fails to do so for n=4.")

#text("Let’s start with n=3, taking ")#mi("N_1=N_2=N_3 = x^{1/3}")#text(" and ")#mi("Q = x^{1/2}")#text(" for simplicity (so we are just at the border of Bombieri-Vinogradov. Philippe pointed out that it is convenient to write things in terms of powers of Q, thus ")#mi("N_1,N_2,N_3 \\sim Q^{2/3}")#text(" here. We want to understand the expression")

#mi("\\sum_{n_1,n_2,n_3 \\sim Q^{2/3}: n_1 n_2 n_3 = a\\ (q)} 1")

#text("on the average for typical (smooth) ")#mi("q \\sim Q")#text(" (I will suppress the dependence of ")#mi("a")#text(" on ")#mi("q")#text(" here for simplicity). The trivial bound here is ")#mi("O( \\frac{Q^{2/3} Q^{2/3} Q^{2/3}}{q} ) = O( Q )")#text(", so we want to control this sum with accuracy ")#mi("o(Q)")#text(" or better. Using completion of sums, we can rewrite the above expression (morally) as")

#mi("\\frac{1}{(Q^{1/3})^3} \\sum_{h_1,h_2,h_3 = O(Q^{1/3})} \\sum_{n_1,n_2,n_3 \\in {\\bf Z}/q{\\bf Z}: n_1n_2 n_3 = a\\ (q)}")

#mi("e_q( h_1 n_1 + h_2 n_2 + h_3 n_3 )")

#text("which (if we discard the cases where ")#mi("h_1h_2h_3")#text(" vanishes or otherwise has a common factor with ")#mi("q")#text(") is basically")

#mi("\\sum_{h_1,h_2,h_3 = O(Q^{1/3})} K_3( a h_1 h_2 h_3; q )")

#text("(the ")#mi("\\frac{1}{(Q^{1/3})^3}")#text(" out the front is absorbed into the normalisation of ")#mi("K_3")#text(". Deligne (for the surface ")#mi("\\{xyz = a\\}")#text(") tells us that ")#tao-math("\\left|K_3(ah_1h_2h_3;q)\\right| \\lessapprox 1", block: false)#text(", giving us back ")#mi("O(Q)")#text(". So a direct application of Deligne only recovers the trivial bound; but once we do even a little bit of Cauchy-Schwarz and take advantage of the averaging in q we can do better (again using Deligne, but now for a hyper-Kloosterman correlation rather than for a single hyper-Kloosterman sum). Eventually it turns out that we can get ")#mi("N_1N_2N_3")#text(" as low as ")#mi("Q^{7/4}")#text(" (down from the current level of ")#mi("Q^2")#text("), which corresponds to a 4/7 level of distribution.")

#text("Now we take n=4, in the model case when ")#mi("Q = x^{1/2}")#text(" and ")#mi("N_1 =N_2 = N_3 =N_4 = x^{1/4} = Q^{1/2}")#text(". We are now staring at")

#mi("\\sum_{n_1,n_2,n_3,n_4 \\sim Q^{1/2}: n_1 n_2 n_3 n_4 = a\\ (q)} 1")

#text("(before averaging in q). The trivial bound is ")#mi("O( \\frac{(Q^{1/2})^4}{q} ) = O( Q )")#text(" as before. After completion of sums we get")

#mi("\\frac{1}{(Q^{1/2})^4} \\sum_{h_1,h_2,h_3,h_4 = O(Q^{1/2})} \\sum_{n_1,n_2,n_3,n_4 \\in {\\bf Z}/q{\\bf Z}: n_1n_2 n_3 n_4 = a\\ (q)}")

#mi("e_q( h_1 n_1 + h_2 n_2 + h_3 n_3 + h_4 n_4)")

#text("(note here that completion of sums did not shorten the length ")#mi("O(Q^{1/2})")#text(" of incomplete summation, in contrast to the n=3 case when it reduced a sum of length ")#mi("O(Q^{2/3})")#text(" to the dual length of ")#mi("O( Q^{1/3})")#text(". With the normalisation of ")#mi("K_4")#text(" (which now has a ")#mi("q^{-3/2}")#text(" in front instead of ")#mi("q^{-1}")#text("), this morally becomes")

#mi("Q^{-1/2} \\sum_{h_1,h_2,h_3,h_4 = O(Q^{1/2})} K_4( a h_1 h_2 h_3 h_4; q ).")

#text("Deligne still tells us that ")#tao-math("\\left|K_4(a h_1 h_2 h_3 h_4; q)\\right| \\lessapprox 1", block: false)#text(", but this now gives a net bound of ")#mi("O( Q^{3/2} )")#text(", so we fall short by ")#mi("Q^{1/2}")#text(" of even recovering Bombieri-Vinogradov here. We can _barely_ recover this by averaging in q as per FKMN. Namely, we are now trying to prove something like")

#tao-math("\\left|\\sum_{q \\sim Q} c_q \\sum_{h = O(Q^2)} \\tilde \\tau_4(h) K_4(ah; q)\\right| \\lessapprox Q^{5/2}", block: false)

#text("for some bounded ")#mi("c_q")#text(" and some divisor-like function ")#mi("\\tilde \\tau_4")#text(". Performing Cauchy-Schwarz in h, this becomes")

#tao-math("\\left|\\sum_{q,q^{\\prime} \\sim Q} c_q \\overline{c_{q^{\\prime}}} \\sum_{h = O(Q^2)} K_4(ah;q) \\overline{K_4(ah;q^{\\prime})}\\right| \\lessapprox Q^3", block: false)#text(".")

#text("The diagonal term ")#mi("q=q^{\\prime}")#text(" is barely acceptable, and the off-diagonal terms are also barely accceptable using hyper-Kloosterman correlation (if we replace ")#mi("h=O(Q^2)")#text(" with ")#mi("h \\in {\\bf Z}/qq^{\\prime}{\\bf Z}")#text("). So we can barely recover Bombieri-Vinogradov with basically no room to maneuver. So it looks like we would have to come up with a new trick in order to use this sort of argument to get something non-trivial in the n=4 case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236660")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("Is it ")#mi("e( h_1 n_1 + h_2 n_2 + h_3 n_3 )")#text(" or ")#mi("e_q( h_1 n_1 + h_2 n_2 + h_3 n_3 )")#text(" in the completed sum?")

#emph[#text("[It’s ")#mi("e_q")#text("; I’ve corrected the text. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ph.M")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236661")[#strong[#text("Ph.M")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("What about doing this analysis with Cauchy in (h,r) (instead of h alone) with q=rs with r very small but >1 and s close to Q ?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("Dear Philippe,")

#text("If we try to Cauchy-Schwarz in more variables, the off-diagonal terms ")#mi("s \\neq s^{\\prime}")#text(" become better, but the diagonal terms ")#mi("s=s^{\\prime}")#text(" become worse; since both the diagonal and off-diagonal terms barely make it to Bombieri-Vinogradov, I don’t see a way to rebalance the Cauchy-Schwarz to do better. A little more precisely, we now write the Bombieri-Vinogradov type estimate to be proven as")

#tao-math("\\left|\\sum_{h = O(Q^2)} \\sum_{r \\sim R} \\sum_{s \\sim S} c_{rs} \\tilde \\tau_4(h) K_4(ah;rs)\\right| \\lessapprox Q^{5/2}", block: false)

#text("with ")#mi("Q = RS")#text(". If we Cauchy-Schwarz in h,r as you suggest we end up with")

#tao-math("\\left|\\sum_{h = O(Q^2)} \\sum_{r \\sim R} \\sum_{s,s^{\\prime} \\sim S} c_{rs} \\overline{c_{rs^{\\prime}}} K_4(ah;rs) \\overline{K_4(ah,rs^{\\prime})} \\right|", block: false)

#mi("\\lessapprox Q^3 / R")

#text("The diagonal contribution ")#mi("s=s^{\\prime}")#text(" now has size ")#mi("O( Q^2 R S ) = O(Q^3 )")#text(" which is now a little bit too big to even get back Bombieri-Vinogradov.")

#text("Having said this, though, I think this rebalancing trick may work for the Type I and Type II sums to get a further gain from what we already have (or plan to have). In both the Type I and Type II sums, one is eventually looking at a sum of the form")

#mi("\\sum_h \\sum_{q_1,q_2 \\sim Q} c_{h,q_1,q_2} \\sum_n \\beta(n) \\beta(n+kr) \\Phi( h, q_1, q_2; n )")

#text("where ")#mi("\\Phi")#text(" is a certain explicit phase and the coefficients ")#mi("c_{h,q_1,q_2}, \\beta")#text(" are essentially bounded (and never mind what k and r are, it’s not important for this discussion); see equation (39) of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text(" . In the Type I sum, Zhang performs Cauchy-Schwarz in the ")#mi("n,q_1")#text(" variables and finds that the diagonal terms ")#mi("h^{\\prime}q_2 = hq^{\\prime}_2")#text(" are OK (as long as ")#mi("M \\gg x^{1/2+2\\varpi+c}")#text(" or equivalently ")#mi("N \\ll x^{1/2-2\\varpi-c}")#text(" for some small fixed ")#mi("c>0")#text(") and then works hard to control the off-diagonal terms ")#mi("h^{\\prime}q_2 \\neq hq^{\\prime}_2")#text(". In the Type II sum, the diagonal terms ")#mi("h^{\\prime}q_2=hq^{\\prime}_2")#text(" coming from Cauchy-Schwarz in ")#mi("n,q_1")#text(" are no longer OK and so Zhang uses Cauchy-Schwarz in just ")#mi("h")#text(" in order to make the diagonal terms ")#mi("h^{\\prime}q_1q_2=hq^{\\prime}_1q^{\\prime}_2")#text(" better, at the cost of making the off-diagonal terms ")#mi("h^{\\prime}q_1q_2 \\neq hq^{\\prime}_1q^{\\prime}_2")#text(" worse (but because in Type II, ")#mi("M")#text(" and ")#mi("N")#text(" are much closer to ")#mi("x^{1/2}")#text(" than in Type I, one still can get reasonable estimates here.")

#text("But in light of your suggestion, I see that there are other Cauchy-Schwarz’s available: in particular,in Type I we can factor ")#mi("q_2 = r_2 s_2")#text(" and Cauchy-Schwarz in ")#mi("n,q_1,r_2")#text(" rather than just ")#mi("n,q_1")#text(" in order to make the diagonal terms do a bit more of the work and the off-diagonal terms do a bit less of the work. Similar optimisations are available in the Type II case (indeed one could imagine that one could now treat Type I and Type II in a unified fashion with a continuum of Cauchy-Schwarz options).")

#text("I’ll add this idea to the queue of possible Type I/Type II improvements (I’ll dub it “Level 6”). There are still two earlier potential Type I/Type II improvements (which I’ve called “Level 4” and “Level 5”) that should be worked out too; I think I can get a preliminary version of Level 4 worked out soon and will post it here. (It’s sort of a strange situation to have more ideas for progress than time available to work the ideas out properly; it’s almost always the other way around :-).)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236532")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2013")])]

#text("As someone who is following the discussion here with some interest, can I suggest that the constraints in current form would be easier to follow and compare when reading posts and tables (eg on the wiki page) if they were normalised to ")#mi("a\\varpi + b\\delta < 1")#text(" (ie clear fractions)")

#emph[#text("[Fair enough – I’ve edited the wiki accordingly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236682")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("In this comment I am recording a preliminary “Level 4” estimate for Type I. However I am punting on the issue of exactly how to define “double dense divisibility” (which should roughly capture the notion that a modulus ")#mi("q")#text(" can be factored as ")#mi("q = d_1 d_2 d_3")#text(" with ")#mi("d_1,d_2,d_3")#text(" placed more or less wherever one wants) and revert to the older notion of ")#mi("x^\\delta")#text("-smoothness. This will worsen the numerology when converting from ")#mi("\\varpi,\\delta")#text(" to ")#mi("k_0")#text(" (basically, this forces one to take ")#mi("\\tilde \\delta = \\delta")#text(", so that ")#mi("\\kappa_3")#text(" vanishes and ")#mi("A")#text(" is irrelevant) but I think the gain from improving ")#mi("\\varpi,\\delta")#text(" will still be greater than the loss from having to revert to a more primitive sieve. (This is presumably a temporary issue, that can be resolved once we work out what double dense divisibility should be.) Unfortunately I have bad news – due to arithmetic errors in my previous projection at ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236039")[#text("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236039")]#text(" , this argument ends up being a lot worse than anticipated, and in fact is inferior to the Level 3 estimate.")

#text("Anyway, to the details. As with this previous comment ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")]#text(" , the starting point is a bound for the incomplete Kloosterman sum")

#mi("S := \\sum_n \\psi_N(n) e_{d_1}(\\frac{c_1}{n}) e_{d_2}(\\frac{c_2}{n+l})")

#text("with ")#mi("d_1,d_2")#text(" squarefree and coprime with ")#mi("d_1 d_2")#text(" ")#mi("x^\\delta")#text("-smoooth, then for any other factorisation ")#mi("d = s_1 s_2 s_3")#text(" of ")#mi("d")#text(", we may use the k=2 van der Corput bound from ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236228")[#text("this comment")]#text(" and bound")

#tao-math("\\left|S\\right| \\lessapprox N^{1/2} (s^{\\prime}_1)^{1/2} + N^{3/4} (s^{\\prime}_2)^{1/4} + N^{3/4} (s^{\\prime}_3)^{1/8}", block: false)

#text("if ")#mi("N \\lessapprox d^{\\prime}")#text(", where ")#mi("d^{\\prime} := d / (c_1,d_1) (c_2,d_2)")#text(", ")#mi("s^{\\prime}_1 = (s_1,d^{\\prime})")#text(", ")#mi("s^{\\prime}_2 := (s_2,d^{\\prime})")#text(", and ")#mi("s^{\\prime}_3 := (s_3,d^{\\prime})")#text(". As ")#mi("d")#text(" is ")#mi("x^\\delta")#text("-smooth, we may choose a factorisation ")#mi("d_1 d_2 = s_1 s_2 s_3")#text(" with")

#mi("x^{-5\\delta/7} N^{3/7} d^{1/7} \\leq s_1 \\leq x^{2\\delta/7} N^{3/7} d^{1/7}")

#text("and")

#mi("x^{-3\\delta/7} N^{-1/7} d^{2/7} \\leq s_2 \\leq x^{4\\delta/7} N^{-1/7} d^{2/7}")

#text("(note that ")#mi("d \\geq r \\sim R \\sim x^{-\\varepsilon} N")#text(", so ")#mi("N^{-1/7} d^{2/7} \\geq 1")#text(") so that")

#mi("s_3 \\leq x^{8\\delta/7} N^{-2/7} d^{4/7}")

#text("and thus")

#tao-math("\\left|S\\right| \\lessapprox x^{\\delta/7} N^{5/7} (d_1 d_2)^{1/14}", block: false)#text(".")

#text("Using completion of sums to handle the opposite case ")#mi("N \\gtrapprox x^\\varepsilon d^{\\prime}")#text(" as in the previous comment, we conclude that")

#tao-math("\\left|S\\right| \\lessapprox N^{5/7} x^{\\delta/7} (d_1 d_2)^{1/14} + \\frac{(c_1,d_1)}{d_1} \\frac{(c_2,d_2)}{d_2}N.", block: false)

#text("Using this bound, we can improve the RHS in Lemma 10 of this post to")

#mi("N^{5/7} x^{\\delta/7} (Q^3 R)^{1/14}+ (hq^{\\prime}_2-h^{\\prime}q_2,r) R^{-1} N")#text(".")

#text("The non-diagonal contribution to (50) is then")

#mi("\\lessapprox H^2 Q^2 ( N^{5/7} x^{\\delta/7} (Q^3 R)^{1/14}+ R^{-1} N)")

#text("which needs to be ")#mi("\\lessapprox x^{-\\varepsilon} Q^2 N")

#text("leading to the conditions")

#mi("H^2 (Q^3 R)^{1/14} \\lessapprox x^{-\\delta/7 - \\varepsilon} N^{2/7}")

#text("and")

#mi("H^2 R^{-1} \\lessapprox x^{-\\varepsilon}")#text(".")

#text("As ")#mi("H = x^\\varepsilon Q^2 R / M")#text(" and ")#mi("NM \\sim x")#text(", this becomes")

#mi("(QR)^{59/14} \\lessapprox x^{2-\\delta/7 - 3\\varepsilon} (R/N)^{15/7} N^{3/7}")

#mi("(QR)^4 \\lessapprox x^{2-3\\varepsilon} (R/N)^3 N")

#text("which since ")#mi("QR \\lessapprox x^{1/2+2\\varpi}")#text(", ")#mi("N \\gtrapprox x^{1/2-\\sigma}")#text(", and ")#mi("x^{-\\delta-\\mu} N \\lessapprox R \\lessapprox x^{-\\mu} N")#text(" for an infinitesimal ")#mi("\\mu")#text(", leads to the constraints")

#mi("\\frac{59}{14} (\\frac{1}{2} + 2 \\varpi) < 2 - \\frac{16}{7} \\delta + \\frac{3}{7} (\\frac{1}{2} - \\sigma)")

#text("and")

#mi("4 (\\frac{1}{2} + 2 \\varpi) < 2 - 3 \\delta + \\frac{1}{2} - \\sigma")

#text("which may be rearranged as")

#mi("\\frac{236}{3} \\varpi + \\frac{64}{3} \\delta + 4 \\sigma < 1")

#text("and")

#mi("8 \\varpi + 3 \\delta + \\sigma < \\frac{1}{2}")#text(".")

#text("The second constraint is clearly dominated by the first and so may be dropped. We conclude the “Level 4” bound that the Type I estimates hold for ")#mi("\\frac{236}{3} \\varpi + \\frac{64}{3} \\delta + 4 \\sigma < 1")#text(". This is significantly worse than the previous claim of ")#mi("40 \\varpi + C \\delta + 4 \\sigma < 1")#text(" coming from ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236039")[#text("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/#comment-236039")]#text(" ; there were two arithmetic errors in the previous analysis, namely that a factor of ")#mi("x^{4\\varpi}")#text(" actually should have been ")#mi("x^{8\\varpi}")#text(", and also an expression ")#mi("\\frac{1}{2} + 2\\sigma +4 \\varpi")#text(" should have been ")#mi("\\frac{1}{2} + 2 \\sigma + 6 \\varpi")#text(". Playing this estimate off against the combinatorial constraint ")#mi("\\sigma > 1/10")#text(" gives ")#mi("\\varpi < 9/1180 \\approx 1/131")#text(", which is a little worse than what we currently have. The moral here seems to be that the small gain coming from the second van der Corput is not quite strong enough to compensate for the large number of additional factors of ")#mi("\\varpi")#text(" one loses when trying to use that estimate.")

#text("On the plus side, it means that we don't have to think about double dense divisibility immediately…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236718")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("In the page “distribution of primes in smooth moduli” the coefficient of")#linebreak()#text(" ")#mi("\\varpi")#text(" should be ")#mi("236/3")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236727")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("A comment and a typo:")

#text("1. Besides (38), we also need the hypothesis ")#mi("R \\lessapprox x^{-c} M")#text(", which is (33) from the earlier thread (")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text("). This is automatic from (31) when ")#mi("M, N")#text(" are not too close to ")#mi("x^{1/2}")#text(", e.g. under (48), but it requires ")#mi("\\mu\\geq c")#text(" in general. If (48) fails, then we choose ")#mi("\\mu := 2\\varpi + c")#text(", which is admissible.")

#text("2. “(45), (46), (49)” should be “(45), (46), (47)”: 3 occurrences.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236761")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("I thought we had to be a bit more careful about ")#mi("c")#text(". Clearly, ")#mi("R \\ll x^{-c+o(1)} M")#text(" holds for ")#mi("c")#text(" small enough, but “small enough” really means “depending on ")#mi("\\mu")#text("“. On the other hand, in deriving Theorem 6 from Theorems 8 and 9, we make a choice of ")#mi("\\mu")#text(" depending on ")#mi("c")#text(". So without further comment, ")#mi("\\mu")#text(" and ")#mi("c")#text(" depend mutually on each other and the two dependencies might be contradictory. So I thought we had to make sure that for the choice of ")#mi("\\mu")#text(" we make, ")#mi("c")#text(" is sufficiently small relative to it so that ")#mi("R \\ll x^{-c+o(1)} M")#text(" holds. This is why I said that assuming (48) any ")#mi("\\mu>0")#text(" is good, while not assuming (48) any ")#mi("\\mu\\geq c")#text(" is good. Sorry if I am missing something. I wish you a good trip!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("Ah, I see what you are saying now. What’s happening is that I’m using c for two independent small quantities; I’ll change the second c to c’ to avoid circular dependenices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236766")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("Thank you, it is clear now!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("I am beginning to suspect that the Type I/II analysis could be simplified by removing the somewhat intricate arguments Zhang uses to enforce that ")#mi("q_1,q_2")#text(" are coprime. (This would also remove the “controlled multiplicity” hypothesis from the congruence classes, and also remove most of the upper bound constraints on ")#mi("R")#text(", potentially leading to some improvement in the numerology.) I have to check the details, but I think one of the main reasons Zhang needed coprimality (other than to make certain formulae look nicer) is that his exponential sum estimate on incomplete Kloosterman sums (Lemma 11 from Zhang’s paper) was a bit inefficient in the non-coprime case (his factors of ")#mi("(c_1,d_1) (c_2,d_2)")#text(" in that Lemma should really be ")#mi("(c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2)")#text(" where ")#mi("d^{\\prime}_i = d_i/(d_1,d_2)")#text("). Otherwise, having common factors between the q’s actually _helps_ the analysis by making the overall modulus ")#mi("r[q_1,q_2,q^{\\prime}_2]")#text(" smaller. Again, I have to check the details…")

#text("p.s. I’m leaving for Budapest today, probably will be out of action here for a day or so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("OK, I now see where coprimality is really used. If one skips the reduction to the coprime case ")#mi("(q_1,q_2)=1")#text(" in the Type I/II analysis, one eventually has a little difficulty with the “main term” ")#mi("X_k")#text(" in the analysis (the display after (36) in ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text(" ), which becomes")

#mi("\\sum_{q_1,q_2: (q_1,r)=(q_2,r)=1: (q_1,q_2)|k} \\sum_{n: (n,q_1r) = (n+kr,q_2)=1}")#linebreak()#text(" ")#mi("\\frac{c_{q_1} c_{q_2} \\beta(n) \\beta(n+kr)}{r[q_1,q_2]} 1_{b_{q_1} = b^{\\prime}_{q_2}\\ (q_1,q_2)} \\sum_m \\psi_M(m).")

#text("The problem comes from the new factor ")#mi("1_{b_{q_1} = b^{\\prime}_{q_2}\\ (q_1,q_2)}")#text(", which in the non-coprime case depends on the choice of ")#mi("b_{q_1}, b^{\\prime}_{q_2}")#text(" and so cannot actually be dumped into the main term ")#mi("X_k")#text(" in the non-coprime case. However in that case one can estimate this expression crudely, using ")#mi("q_0 = (q_1,q_2)")#text(", as")

#mi("\\frac{MN \\log^{O(1)} x}{R} \\sum_{q_0 > 1: q_0 | k} \\frac{1}{q_0}")

#text("and on averaging in k we and using the lower bound ")#mi("q_0 \\geq D_0")#text(" we can show that this expression is (barely) acceptable as an error term rather than a main term. So we can’t get rid of the reduction that makes ")#mi("q")#text(" free of tiny primes. On the other hand, by reworking the argument in the above way we can avoid the need to assume controlled multiplicity altogether in Zhang’s theorem, thus strengthening it slightly.")

#text("I also now see that the condition ")#mi("R \\lessapprox x^{-\\varepsilon} N")#text(" is necessary for the dispersion method to work, otherwise the condition ")#mi("mn = a_r\\ (r)")#text(" basically determines ")#mi("n")#text(" from ")#mi("m, r")#text(" and there is nothing to disperse!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounded gaps between primes (Polymath8) – a progress report | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236883")[#strong[#text("Bounded gaps between primes (Polymath8) – a progress report | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("[…] sketch of Zhang’s argument for establishing Type I estimates (details may be found at these two posts). It is based on previous arguments of Bombieri, Friedlander, and Iwaniec, relying on various […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Rolling over to a new thread at ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")[#text("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")]#text(" (we traditionally do this every 100 comments or so, but the comments in this thread are particularly lengthy and technical and so I thought it would be good to recap with a fresh thread).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236902")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("I think that Theorem 8 can be improved in that (47) can be omitted. We observe first that (52) can be supplemented by")

#mi("(c_1, q_1) = (hq^{\\prime}_2-h^{\\prime}q_2, q_1)")#text(",")

#text("as follows from the explicit formula")

#mi("c_1 := (hq^{\\prime}_2 - h^{\\prime}q_2) (a_r \\bar{q_1} \\bar{q_2} \\bar{q^{\\prime}_2} q_1 + b_{q_1} \\bar{r} \\bar{q_2} \\bar{q^{\\prime}_2} r)\\ (d_1).")

#text("Using also ")#mi("d_1=q_1r\\sim QR")#text(", the last term in (51) can be improved to")

#mi("(QR)^{-1/4} N (hq^{\\prime}_2-h^{\\prime}q_2,q_1r)^{1/4}")#text(".")

#text("The improvement is really by a factor of ")#mi("Q^{-1/4}(hq^{\\prime}_2-h^{\\prime}q_2,q_1)^{1/4}")#text(", since ")#mi("(q_1,r)=1")#text(". By going back to earlier parts of the argument, we see that we need to average this over ")#mi("q_1\\sim Q")#text(", and then sum over ")#mi("h,h^{\\prime},q_2,q_2^{\\prime}")#text(" with ")#mi("hq_2^{\\prime}\\neq h^{\\prime}q_2")#text(". This way we gain a factor of ")#mi("\\lessapprox Q^{-1/4}")#text(" over the original contribution of the last term in (51). Therefore, instead of")

#mi("H^2 Q^2 R^{-1/4} N \\lessapprox x^{-2\\epsilon} Q^2 N")#text(",")

#text("we only need to ensure")

#mi("H^2 Q^2 (QR)^{-1/4} N \\lessapprox x^{-2\\epsilon} Q^2 N")#text(",")

#text("that is,")

#mi("(QR)^{15/4} \\lessapprox x^{2-4\\epsilon} (R/N)^2")#text(".")

#text("In short, the last display of Section 3 can be replaced by")

#mi("\\frac{15}{4}(\\frac{1}{2} + 2 \\varpi) < 2-2(\\mu + \\delta)")#text(",")

#text("which rearranges to")

#mi("15\\varpi+4\\mu+4\\delta<\\frac{1}{4}")#text(".")

#text("So this would replace (47), but it follows from (45), hence can be omitted.")

#text("I hope I did not make a mistake. I also report two typos:")

#text("1. In the line before (52), ")#mi("d_2:=[q_1,q_2]")#text(" should be ")#mi("d_2:=[q_2,q_2^{\\prime}]")#text(".")

#text("2. In the fifth display of Section 6 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]#text(", ")#mi("c_{h^{\\prime},q_1,q^{\\prime}_2}")#text(" should be ")#mi("\\overline{c_{h^{\\prime},q_1,q^{\\prime}_2}}")#text(".")

#emph[#text("[Corrected, thanks. It looks like this improvement does not make the dominant inequalities any better, at least currently, but it may become useful at some later stage. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-237495")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")])]

#text("Just a minor comment. In the last line in the proof of Lemma 11, “since ")#mi("r")#text(" divides ")#mi("d_1")#text(" but not ")#mi("d_2")#text("” should be “since ")#mi("r")#text(" divides ")#mi("d_1")#text(" but is coprime to ")#mi("d_2")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in doubly densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-237790")[#strong[#text("The distribution of primes in doubly densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("[…] improves upon the previous constraint of (see this previous post), although that latter statement was stronger in that it only required single dense divisibility […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-237903")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Just a typo: in (36), ")#mi("n = a_r\\ (r)")#text(" should be ")#mi("mn = a_r\\ (r)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-238206")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("A question and some typos:")

#text("1. In the third display below Proposition 12, we have the constraint ")#mi("(m,d_1)=1")#text(". Why is it not ")#mi("(m,d_1d_2)=1")#text(" as dictated by ")#mi("(n,d_1d_2)=1")#text(" from the previous display?")

#text("2. In the first display below Proposition 12, ")#mi("F(d_2 h)")#text(" should be ")#mi("F(d_2 h^{\\prime})")#text(".")

#text("3. In the second and third display below Proposition 12, ")#mi("(h,d_1)")#text(" should be ")#mi("(h^{\\prime},d_1)")#text(".")

#text("4. In the display following (63), ")#mi("(h,d_1)")#text(" should be ")#mi("(h^{\\prime},d_1)")#text(".")

#emph[#text("[Corrected, thanks. The additional constraint ")#mi("(m,d_2)=1")#text(" does indeed need to be placed on ")#mi("m")#text(" but this is harmless as one simply applies Proposition 12 with a suitably truncated version of ")#mi("\\alpha")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-238256")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Another question and two typos:")

#text("1. In the discussion below Proposition 12, you say that (62) with the appropriate parameters follows from (17). My calculation tells me that instead of (17) we need the slightly stronger bound ")#mi("N_1 N_2 \\gtrapprox x^{1/2+6\\varpi+\\epsilon}")#text(". More precisely, we want")

#mi("M (\\frac{N_2}{b_2})^2 (\\frac{N_3}{b_3}) \\gtrapprox (b_2 b_3)^{-2} d_1 (x^\\epsilon \\frac{d_1}{N_1})^2 x^c")#text(",")

#mi("M N_1^2 N_2^2 N_3 \\gtrapprox b_3^{-1} d_1^3 x^{2\\epsilon+c}")#text(",")

#mi("x N_1 N_2 \\gtrapprox (x^{1/2+2\\varpi})^3 x^{2\\epsilon+c}")#text(",")

#mi("N_1 N_2 \\gtrapprox x^{1/2+6\\varpi+2\\epsilon+c}")#text(".")

#text("Am I missing something?")

#text("2. “values coprime to ")#mi("d_1")#text("” should be “values coprime to ")#mi("d_1d_2")#text("“.")

#text("3. In (63) and in the display before (64), ")#mi("b_3|d_3")#text(" should be ")#mi("b_3|d_2")#text(".")

#emph[#text("[Corrected, thanks. Increasing ")#mi("3\\varpi")#text(" to ")#mi("6\\varpi")#text(" causes some changes in the final calculations, but fortunately only for non-dominant inequalities, and the final constraint on ")#mi("\\varpi,\\delta")#text(" remains unchanged. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-238328")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("A few suggestions and typos:")

#text("1. In (66) and subsequent displays, I would put ")#mi("\\alpha \\ast \\psi_3(n_3)")#text(" into parentheses.")

#text("2. In the proof of Proposition 12 you remark that (59) implies ")#mi("1 \\leq n_2 h^{\\prime}, n^{\\prime}_2 h \\leq d")#text(". I think (59) only implies ")#mi("1 \\leq n_2 h^{\\prime}, n^{\\prime}_2 h \\lessapprox x^{\\epsilon} d")#text(", so the subsequent bound for ")#mi("\\sum_l \\nu(l)^2")#text(" needs an extra factor of ")#mi("x^{\\epsilon}")#text(".")

#text("3. In the three display following (71), the condition ")#mi("(m,d)=(m^{\\prime},d)=1")#text(" is missing, and ")#mi("\\overline{\\psi_3}(n_3)")#text(" should be ")#mi("\\overline{\\psi_3}(n_3^{\\prime})")#text(".")

#text("4. In the second display below (71), a factor ")#mi("M^2")#text(" is missing on the right hand side.")

#text("5. In the third display below (72), the term ")#mi("e_q( \\frac{t}{l} - \\frac{t^{\\prime}}{l+k} + \\frac{m}{t} - \\frac{m^{\\prime}}{t^{\\prime}} )")#text(" is missing. Also, for the sake of the reader, it would be better to use the variables ")#mi("u,u^{\\prime}")#text(" instead of ")#mi("t,t^{\\prime}")#text(" in this definition.")

#text("6. In the fourth display below (72), the condition ")#mi("(m^{\\prime},d)=1")#text(" is missing.")

#text("7. In (74) and in the third display below (77), ")#mi("n^{-2\\epsilon}")#text(" should be ")#mi("x^{-2\\epsilon}")#text(".")

#text("8. For the sake of the reader I would add more detail regarding the choice of ")#mi("r|d")#text(" below (77). There is a constant ")#mi("C>0")#text(" such that ")#mi("R:=C\\min(R_2,R_3)")#text(" exceeds ")#mi("1")#text(". If ")#mi("R\\leq d")#text(", then there is a divisor ")#mi("r|d")#text(" such that ")#mi("Rx^{-\\delta}\\leq r\\leq R")#text(", and any such divisor is admissible by ")#mi("Rx^{-\\delta}\\gg R_1")#text(". Otherwise ")#mi("R>d")#text(", hence ")#mi("r:=d")#text(" is admissible by ")#mi("R_1\\ll d")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-238414")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2013")])]

#text("Dear Terry, sorry for the trouble or if I am wrong, but:")

#text("1. We also need to change ")#mi("n_2 h^{\\prime} = n^{\\prime}_2 h")#text(" to ")#tao-math("\\left|n_2 h^{\\prime} - n^{\\prime}_2 h\\right|/d\\in\\mathbb{Z}\\cap[0,O(x^\\epsilon)]", block: false)#text(" in the second display before (71) and the line that precedes it.")

#text("2. In the fourth display below (72), the condition ")#mi("(m,d)=1")#text(" should be ")#mi("(mm^{\\prime},d)=1")#text(".")

#text("3. In the third display below (77), ")#mi("n^{-2\\epsilon}")#text(" should be ")#mi("x^{-2\\epsilon}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-238422")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2013")])]

#text("Somehow these last corrections have not appeared, perhaps due to an upload problem?")

#emph[#text("[Oops, sorry about that – it should be OK now – T]")]
]
]
]
