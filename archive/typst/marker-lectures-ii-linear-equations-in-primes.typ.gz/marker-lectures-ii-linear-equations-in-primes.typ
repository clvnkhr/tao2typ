// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:35:27.697852+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Marker lectures II, “Linear equations in primes”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Marker lectures II, “Linear equations in primes”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/")[#text("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I am at ")#link("http://www.math.psu.edu/")[#text("Penn State University")]#text(", giving this ")#link("http://www.math.psu.edu/seminars/marker2008.php")[#text("year’s Marker lectures")]#text(". My chosen theme for my four lectures here is “recent developments in additive prime number theory”. My first lecture, “Long arithmetic progressions in primes”, is similar to my ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("AMS lecture on the same topic")]#text(" and so I am not reposting it here. The second lecture, the notes for which begin after the fold, is on “Linear equations in primes”. These two lectures focus primarily on work of myself and Ben Green. The third and fourth lectures, entitled “Small gaps between primes” and “Sieving for almost primes and expander graphs”, will instead be focused on the work of Goldston-Yildirim-Pintz and Bourgain-Gamburd-Sarnak respectively.")#linebreak()#text(" ")#metadata(none) <tao-69efbf4a48db2966aa1e>#text("In my previous lecture (or the ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("AMS lecture")]#text("), I focused on finding a specific type of pattern inside the prime numbers, namely that of an arithmetic progression ")#mi("n, n+r, \\ldots, n+(k-1)r")#text(". The main reason why the analysis there is specific to progressions is because of its reliance on ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(", which shows that arithmetic progressions are necessarily abundant in sufficiently “large” sets of integers. There are several other variants and generalisations of this theorem known to a few other types of patterns (e.g. polynomial progressions ")#mi("n+P_1(r), \\ldots, n+P_k(r)")#text(", where ")#mi("P_1,\\ldots,P_k")#text(" are polynomials from the integers to the integers with ")#mi("P_1(0) = \\ldots = P_k(0)=0")#text(" and ")#mi("r \\neq 0")#text("), and in some cases the analogous results about primes are known (e.g. ")#link("http://arxiv.org/abs/math.NT/0610050")[#text("Tamar Ziegler and myself showed")]#text(" that for any given ")#mi("P_1,\\ldots,P_k")#text(" as above, there are infinitely many polynomial progressions of primes).")

#text("However, for most patterns, there is no analogue of Szemerédi’s theorem, and the strategy used in the previous lecture or ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("AMS lecture")]#text(" cannot be directly applied. For instance, it is certainly not true that any subset of integers with positive upper density contains any twins ")#mi("n,n+2")#text("; the multiples of three, for instance, form a counterexample, among many others. (In fact, there are so many counterexamples here, that it looks unlikely that the ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(" can be attacked by this method without a significant new idea.)")

#text("Furthermore, even in the cases when these methods do work, for instance in demonstrating for each k that there are infinitely many progressions of length k inside the primes, they do not settle the more quantitative problem of how many progressions of length k there are asymptotically in any given finite range of primes, e.g. the primes less than a number N in the asymptotic limit ")#mi("N \\to \\infty")#text(". This is because Szemerédi’s theorem provides a lower bound for the number of progressions in a large finite set, but not a matching upper bound. (For instance, given a subset A of ")#mi("\\{1,\\ldots,N\\}")#text(" of density 1/2, the number of progressions of length 3 in A can be as large as ")#mi("(1/4 + o(1)) N^2")#text(" (if ")#mi("A")#text(" consists of the even integers from 1 to N, for instance) and as small as ")#mi("(1/8 + o(1)) N^2")#text(" (if ")#mi("A")#text(" is a randomly chosen set of density 1/2), and can even be a little bit smaller by perturbing this example slightly.)")

#text("On the other hand, as discussed in the previous lecture or ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("AMS lecture")]#text(", one can use standard random models for the primes to predict what the correct asymptotic for these questions should be. For instance, the number of arithmetic progressions ")#mi("n, n+r, \\ldots, n+(k-1)r")#text(" of a fixed length k consisting of primes less than N should be asymptotically")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(\\frac{1}{2(k-1)} (\\prod_p \\beta_p) + o(1)) \\frac{N^2}{\\log^k N}")]]

#text("where the product is over all primes p, and the quantity ")#mi("\\beta_p")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("\\beta_p := \\frac{1}{p} (\\frac{p}{p-1})^{k-1}")]]

#text("for ")#mi("p \\leq k")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\beta_p := (1-\\frac{k-1}{p}) (\\frac{p}{p-1})^{k-1}")]]

#text("for ")#mi("p \\geq k")#text(".")

#text("The various terms in this complicated-looking formula can be explained as follows. The “Archimedean” factors ")#mi("\\frac{1}{2(k-1)}")#text(" and ")#mi("N^2")#text(" come from the fact that the number of arithmetic progressions ")#mi("n, n+r, \\ldots,n+(k-1)r")#text(" of ")#emph[#text("natural numbers")]#text(" less than N is ")#mi("(\\frac{1}{2(k-1)} +o(1)) N^2")#text(". The “density” factor ")#mi("\\frac{1}{\\log^k N}")#text(" comes from the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which roughly speaking asserts that each of the k elements ")#mi("n, n+r, \\ldots,n+(k-1)r")#text(" in a typical arithmetic progression has a ")#mi("(1+o(1)) \\frac{1}{\\log N}")#text(" “probability” of being prime. The “local” factors ")#mi("\\beta_p")#text(" measures how much bias arithmetic progressions with respect to being coprime to a fixed prime p, which is relevant for progressions of primes, since primes of course tend to be coprime to p. More precisely, ")#mi("\\beta_p")#text(" can be defined as the probability that a random arithmetic progression of length k has all entries coprime to p, divided by the probability that a random collection of k independent numbers are all coprime to p. It is not difficult to show that the product ")#mi("\\prod_p \\beta_p")#text(" converges to some finite non-zero number for each k.")

#text("Similar heuristic asymptotic formulae exist for the number of many other patterns of primes; for instance, the number of representations ")#mi("N=p_1+p_2")#text(" of a large integer N as the sum of two primes should be equal to ")#mi("(\\prod_p \\beta_{p,N} + o(1)) N")#text(", where ")#mi("\\beta_{p,N}")#text(" is the probability that two randomly chosen numbers ")#link("http://en.wikipedia.org/wiki/Conditional_probability")[#text("conditioned")]#text(" to be coprime to p sum to N modulo p, divided by the probability that two randomly chosen numbers sum to N modulo p. (In particular, ")#mi("\\beta_{2,N}=0")#text(" for odd N, reflecting the fact that it is very difficult for an odd number to be representable as the sum of two primes. More generally, one can compute that ")#mi("\\beta_{p,N} = 1 + \\frac{1}{p-1}")#text(" when p divides N, and ")#mi("\\beta_{p,N} = 1 - \\frac{1}{(p-1)^2}")#text(" otherwise.) A more general prediction for counting linear patterns inside primes exists, and is essentially the ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy-Littlewood prime tuples conjecture")]#text(". This conjecture, which is widely believed to be true, would imply many other conjectures in the subject, such as the twin primes conjecture and the ")#link("http://en.wikipedia.org/wiki/Goldbach_conjecture")[#text("Goldbach conjecture")]#text(" (for sufficiently large even numbers). Unfortunately, the cases of the prime tuples conjecture which would have these consequences remain out of reach of current technology.")

#text("Using some elementary linear algebra, one can recast the prime tuples conjecture not as a question of finding linear patterns inside primes, but rather that of solving linear equations in which all the unknowns are required to be prime, subject to some additional linear inequalities. For instance, finding progressions of length k consisting entirely of primes less than N is essentially the same as asking for solutions to the system of equations")

#align(center)[#tao-fit-display[#mitex("p_2 - p_1 = p_3 - p_2 = \\ldots = p_k - p_{k-1}")]]

#text("and inequalities")

#align(center)[#tao-fit-display[#mitex("0 \\leq p_1,\\ldots,p_k \\leq N")]]

#text("where the unknowns ")#mi("p_1,\\ldots,p_k")#text(" are required to be primes. More generally, one could imagine the question of asking the number of k-tuples ")#mi("(p_1,\\ldots,p_k)")#text(" consisting entirely of primes which is contained in some convex set B in ")#mi("{\\Bbb R}^k")#text(" of some intermediate dimension ")#mi("1 \\leq d \\leq k")#text(", which is contained in a ball of radius O(N) around the origin. For instance, in the above example B is the 2-dimensional set")

#align(center)[#mi("\\{ (x_1,\\ldots,x_k) \\in {\\Bbb R}^k: x_2-x_1 = \\ldots = x_k-x_{k-1}; 0 \\leq x_1,\\ldots,x_k \\leq N \\}")#text(".")]

#text("(We make the technical assumption that the linear coefficients of the equations defining the d-dimensional subspace that B lives in are independent of N; k and d are of course also assumed to be independent of N. The constant coefficients, however, are allowed to vary with N; this is the situation that comes up for instance in the Goldbach conjectures.) One can think of the problem of finding points in B as that of solving k-d equations in k unknowns. One can also generalise this problem slightly by enforcing some residue constraints ")#mi("x_j = a_j \\mod q_j")#text(" on the unknowns, but we will ignore this minor extension to simplify the discussion.")

#text("The prime tuples conjecture for this problem can roughly speaking be phrased as follows. Suppose that the number if k-tuples ")#mi("(n_1,\\ldots,n_k)")#text(" in B consisting of ")#emph[#text("natural numbers")]#text(" is known to be")

#align(center)[#tao-fit-display[#mitex("(\\beta_\\infty + o(1)) N^d")]]

#text("for some constant ")#mi("\\beta_\\infty")#text(" independent of N (one can think of this constant as the normalised volume of B). Suppose also that for any fixed prime p, the number of k-tuples in B consisting of natural numbers coprime to p is known to be")

#align(center)[#tao-fit-display[#mitex("(\\beta_\\infty \\beta_p + o(1)) (1 - \\frac{1}{p})^k N^d")]]

#text("for some constant $latex\\ beta_p$ independent of n. (The factor ")#mi("(1 - \\frac{1}{p})^k")#text(" is natural, as it represents the proportion of tuples of k natural numbers in which all the entries are coprime to p.) Then the prime tuples conjecture asserts that the number of k-tuples in B consisting of primes should be")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(\\beta_\\infty \\prod_p \\beta_p + o(1)) \\frac{N^d}{\\log^k N}.")]]

#text("In particular, this can be shown to imply that if ")#mi("\\beta_\\infty > 0")#text(" (thus there are no obstructions to solving the system of equations at infinity) and if ")#mi("\\beta_p > 0")#text(" for all p (thus there are no obstructions to solvability mod p for any p) then there will exist many solutions to the system of equations in primes when N is large enough.")

#text("As mentioned earlier, this conjecture remains open in several important cases, most particularly in the one-dimensional case d=1. For instance, the twin prime conjecture would follow from the case ")#mi("B := \\{ (x_1,x_2): x_2 -x_1 = 2, 0 \\leq x_1,x_2 \\leq N \\}")#text(", but this case remains open. However, there has now been significant progress in the higher dimensional cases ")#mi("d \\geq 2")#text(", especially when the ")#emph[#text("codimension")]#text(" ")#mi("k-d")#text(" (representing the number of equations in the system) is low. Firstly, the prime number theorem settles the zero codimension case ")#mi("d=k")#text(" (and is pretty much the only situation in which we can handle a $d=1$ case). The Hardy-Littlewood circle method, based on Fourier analysis, settles all “non-degenerate” cases when ")#mi("d \\geq \\max(k-1, 2)")#text(", where “non-degenerate” roughly speaking means that the problem does not secretly contain a ")#mi("d=1")#text(" problem inside it as a lower-dimensional projection (e.g. ")#mi("B := \\{ (x_1,x_2,x_3): x_2-x_1=2, 0 \\leq x_1,x_2,x_3 \\leq N \\}")#text(" would be degenerate; more generally, B is non-degenerate if it is not contained in any hyperplane that can be defined using at most two of the unknowns). It can also handle some cases in which the codimension k-d exceeds 1 (e.g. one could take the Cartesian product of some codimension 1 examples); the precise description of what problems are within reach of this method is a little technical to state and will not be given here.")

#text("The main result of ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("this paper")]#text(" of Ben Green and myself (combined with results from ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("these")]#text(" ")#link("http://arxiv.org/abs/math.NT/0606087")[#text("other")]#text(" ")#link("http://arxiv.org/abs/0807.1736")[#text("papers")]#text(" of ours) is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" The prime tuples conjecture is true in all non-degenerate situations in which ")#mi("d \\geq \\max(k-2, 2)")#text(". If the ")#emph[#text("inverse conjecture for the Gowers norms over the integers")]#text(" is true, then the prime tuples conjecture is true in all non-degenerate situations in which ")#mi("d \\geq 2")#text(".")
]

#text("I will say a little bit more about what the inverse conjecture for the Gowers norms is later. This theorem unfortunately does not touch the most interesting case ")#mi("d=1")#text(" (when the patterns one is seeking only have one degree of freedom), but it does largely settle all the other cases. For instance, this theorem implies the asymptotic (1) for prime progressions of length k for ")#mi("k \\leq 4")#text(" (the cases ")#mi("k \\leq 3")#text(" were established earlier by van der Corput using the circle method), and the case of higher k would also follow from the theorem once the inverse conjecture is proven. As with the circle method, we can also unconditionally handle some cases in which d is less than ")#mi("\\max(k-2,2)")#text(", but the precise statement here is technical and will be omitted. (Details and further examples can of course be found in ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("our paper")]#text(".)")

#text("Now I would like to turn to the proof of this theorem. At first glance, the result looks like it is going to be quite complicated, due to the presence of all the different factors in the asymptotic (2) that one is trying to prove. However, most of the factors can be dealt with by various standard tricks. The Archimedean factor ")#mi("\\beta_\\infty")#text(" can be eliminated from the problem by working locally (with respect to the infinite ")#link("http://en.wikipedia.org/wiki/Place_(mathematics)")[#text("place")]#text("), covering B by cubes of sidelength o(N). For similar reasons, the local factors ")#mi("\\beta_p")#text(" can be eliminated by working locally mod p (i.e. restricting to a single residue class mod p for various small p). The factors ")#mi("\\frac{1}{\\log^k N}")#text(", which come from the density ")#mi("\\frac{1}{\\log N}")#text(" of primes in the region of interest (i.e. from the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text("), can largely be compensated for (with some effort) from the transference principle technology developed in our earlier paper on long progressions in the primes, which was discussed in the previous lecture (or at the ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("AMS lecture")]#text("). After all this, the problem basically boils down to the following. We have a certain subset A of the integers ")#mi("\\{1,\\ldots,N\\}")#text(" with some density ")#mi("0 < \\delta < 1")#text(" (one should think of A as being a “model” for the primes, after all the distorting structure coming from local obstructions has been stripped out; in actuality, one has to replace the set A by a weight function ")#mi("f: \\{1,\\ldots,N\\} \\to [0,1]")#text(" of mean value ")#mi("\\delta")#text(", but let us ignore this technicality to simplify the discussion). We pick a random instance of some linear pattern inside ")#mi("\\{1,\\ldots,N\\}")#text(" (for sake of concreteness, let us pick a random arithmetic progression ")#mi("n, n+r, \\ldots,n+(k-1) r")#text(") and ask what is the probability that all the elements of this pattern lie in A. Since A has density ")#mi("\\delta")#text(", we expect each element ")#mi("n+jr")#text(" of our random progression to have a probability ")#mi("\\delta+o(1)")#text(" to lie in A. (This is not quite the case if A is biased to lie on one side of ")#mi("\\{1,\\ldots,N\\}")#text(" than on the other, but it turns out that one can ignore this possibility.) Since our pattern consists of k elements, we thus expect")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\Bbb P}( n, n+r, \\ldots, n+(k-1)r \\in A ) = \\delta^k + o(1).")]]

#text("Roughly speaking, the key issue in proving the theorem is to work out some “easily checkable” conditions on A that would guarantee that the heuristic (3) is in fact valid. One then verifies that these “easily checkable” conditions do indeed hold for the set A of interest (which is a proxy for the set of primes).")

#text("As stated before, we expect ")#mi("{\\Bbb P}(n+jr \\in A) = \\delta+o(1)")#text(" for each ")#mi("0 \\leq j < k")#text(". Thus (3) is asserting in some sense that the events ")#mi("n+jr \\in A")#text(" are “approximately independent”. This would be a reasonable assertion if A was ")#emph[#text("pseudorandom")]#text(" (i.e. it behaved like a random subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of the given density ")#mi("\\delta")#text("), and is consistent with the general heuristic from number theory that we expect the prime numbers to behave randomly once all the “obvious” irregularities in distribution (in particular, irregularity modulo p for small p) has been dealt with. But if A exhibits certain types of ")#emph[#text("structure")]#text(" (or at least some bias towards structure), then (3) can fail. For instance, suppose that A consists entirely of odd numbers. Then, if the first two elements n, n+r of an arithmetic progression lie in A, they are necessarily odd, which then forces the rest of the elements of this progression to be odd. As A is concentrated entirely in these odd numbers, these elements of the progression are thus expected to have an elevated probability of lying in A, and so the left-hand side of (3) would be expected to significantly exceed the former once ")#mi("k \\geq 3")#text(". (The asymptotic (3) becomes trivially true for ")#mi("k<3")#text(".) A similar distorting effect occurs if A is not entirely contained in the odd numbers, but is merely ")#emph[#text("biased")]#text(" towards them, in that odd numbers are more likely to lie in A than even numbers. In this example, the bias in A caused the number of progressions to go up from the expected number predicted by (3); it is also possible (but more tricky) to concoct examples in which bias in A forces the number of progressions to go down somewhat, though Szemerédi’s theorem does prevent one from extinguishing these progressions completely when N is large.")

#text("Bias towards odd or even numbers is equivalent to a correlation between A and the ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("linear character")]#text(" ")#mi("\\chi(n) := (-1)^n")#text("; the algebraic constraints between the ")#mi("\\chi(n+jr)")#text(", and in particular the relationship")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\chi(n+2r) \\chi(n+r)^{-2} \\chi(n)=1")]]

#text("can be viewed as the underlying source of the distorting effect that can prevent (3) from holding for ")#mi("k \\geq 3")#text(". The same algebraic constraint holds for any other linear character, e.g. the Fourier character ")#mi("\\chi(n) := e(\\xi n)")#text(" (where ")#mi("e(x) := e^{2\\pi i x}")#text(") for some fixed frequency ")#mi("\\xi \\in {\\Bbb R}")#text(", for much the same reason that two points on a line determine the rest of the line (it is also closely related to the fact that the second derivative of a linear function vanishes). Because of this, we expect (3) to be distorted when A ")#emph[#text("correlates")]#text(" with such a character (which means that the Fourier coefficient ")#mi("\\sum_{n \\in A} \\chi(n)")#text(" is unexpectedly large in magnitude).")

#text("It turns out that in the case k=3 of progressions of length three, correlation with a linear character is the ")#emph[#text("only")]#text(" source of distortion in the count (3). A sign of this can be seen from the identity")

#align(center)[#tao-fit-display[#mitex("\\# \\{ (n,r): n,n+r,n+2r \\in A \\} = \\int_0^1 (\\sum_{n_1 \\in A} e(\\xi n_1) (\\sum_{n_2 \\in A} e(-2\\xi n_2)) (\\sum_{n_3 \\in A} e(\\xi n_3))\\ d\\xi")]]

#text("which can be viewed as a “Fourier transform” of the algebraic identity (4). One can formalise this using (a slight variant of) the above identity and some other Fourier-analytic tools (in particular, the ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel identity")]#text(") to conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Inverse theorem for length three progressions. ")]#text("(Informal statement) Let k=3. Suppose that A is a subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" for which (3) fails. Then A correlates with a non-trivial linear character ")#mi("\\chi(n) = e(\\xi n)")#text(". (“Non-trivial” basically means that ")#mi("\\chi")#text(" oscillates at least once on the interval ")#mi("\\{1,\\ldots,N\\}")#text(".)")
]

#text("Applying this theorem in the contrapositive, we conclude that we can justify the asymptotic (3) in the k=3 case as long as we can show that A does not correlate with a linear character. In the case when A is a proxy for the primes, this task essentially boils down to that of establishing non-trivial estimates for exponential sums over primes, such as")

#align(center)[#mi("\\sum_{p < N} e(\\xi p)")#text(";")]

#text("for technical reasons it is more convenient to deal with slight variants of this sum such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n=1}^N \\Lambda(n) e(\\xi n)")]]

#text("where ")#mi("\\Lambda")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", or")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n=1}^N \\mu(n) e(\\xi n)")]]

#text("where ")#mi("\\mu")#text(" is the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(". (There are various elementary identities, such as summation by parts, that allow one to express one of these sums in terms of the others. One has a lot of flexibility in here as long as one retains a factor in the sum which is somehow sensitive to the prime factorisation of n.) The reason for using these functions instead is that they enjoy a number of very useful identities, such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n=1}^\\infty \\frac{\\Lambda(n) \\chi(n)}{n^s} = -\\frac{L^{\\prime}(s,\\chi)}{L(s,\\chi)}")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{n=1}^\\infty \\frac{\\mu(n) \\chi(n)}{n^s} = \\frac{1}{L(s,\\chi)}")]]

#text("for any ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" ")#mi("\\chi")#text(" (where ")#mi("L(s,\\chi)")#text(" is the ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet L-function")]#text("), and also multiplicative identities such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log \\frac{n}{d}")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\mu(n) = \\sum_{n=abc} \\mu(a) \\mu(b)")]]

#text("To cut a long story very short, identities such as (7), (8) are useful for estimating (5), (6) respectively in the ")#emph[#text("major arc")]#text(" case when ")#mi("\\xi")#text(" is rational or close to rational (with small denominator), while (variants of) identities such as (9) or (10) (in particular, certain truncated versions of (9) and (10) such as ")#link("http://en.wikipedia.org/wiki/Vaughan%27s_identity")[#text("Vaughan’s identity")]#text(") are useful for estimating (5), (6) respectively in the ")#emph[#text("minor arc")]#text(" case when ")#mi("\\xi")#text(" is far from a rational with small denominator (or close to a rational with large denominator). This theory was pioneered by Vinogradov (and also Hardy and Littlewood), and refined and simplified over the years with many contributions by Vaughan, Davenport, Heath-Brown, and others, with the upshot being that we now have a fairly good understanding of sums such as (5) and (6), and in particular that the sum (6) exhibits a strong cancellation (by a factor of ")#mi("O_A(\\log^{-A} N)")#text(" for any fixed A) uniformly in ")#mi("\\xi")#text(" (i.e. we can handle both major and minor arcs with a uniform estimate). Combining this with the inverse theorem and the previous reductions, one can eventually establish the asymptotic (1) in the k=3 case. (This is not exactly how the original proof of (1) by van der Corput in this case proceeded, but both proofs use the same general ingredients and method, i.e. the Hardy-Littlewood circle method and the Vinogradov method for estimating exponential sums.)")

#text("Now we turn to progressions of longer length, such as the case k=4. Here, linear characters ")#mi("\\chi(n) = e(\\xi n)")#text(" continue to cause bias that distorts the expected asymptotic (3), and so it is still necessary to control sums such as (5) or (6) to prevent such bias from occuring. However, a major new difficulty arises that new sources of bias also arise. For instance, if one takes a quadratic character ")#mi("\\chi(n) := e(\\xi n^2)")#text(" for some ")#mi("\\xi")#text(", then one easily verifies the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\chi(n) \\chi(n+r)^{-3} \\chi(n+2r)^3 \\chi(n+3r)^{-1} = 1")]]

#text("which reflects the fact that the third derivative of a quadratic function (such as ")#mi("n \\mapsto \\xi n^2")#text(") is zero (it also reflects the fact that three points on the graph of a quadratic (i.e. a parabola) determine the entire parabola). One consequence of this is that if ")#mi("\\chi(n), \\chi(n+r), \\chi(n+2r)")#text(" are all close to 1 (say), then ")#mi("\\chi(n+3r)")#text(" will be also. This constraint between the four values of ")#mi("\\chi")#text(" along an arithmetic progression suggests that if A exhibits significant correlation with ")#mi("\\chi")#text(", then the event that n+3r lies in A will be influenced in some non-trivial manner by whether n, n+r, and n+2r already lie in A, which will lead to some distortion in (3). Thus one will need to update the inverse theorem by taking quadratic characters into account. (Easy examples show that it is possible for a set to correlate with a quadratic character without exhibiting any correlation with linear characters, by choosing a quadratic character with irrational coefficients.) The most optimistic conjecture in this regard would be")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposed inverse theorem for length four progressions. ")]#text("(Informal statement) Let k=4. Suppose that A is a subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" for which (3) fails. Then A correlates with a non-trivial quadratic character ")#mi("\\chi(n) = e( \\xi_2 n^2 + \\xi_1 n)")#text(".")
]

#text("Unfortunately, this conjecture fails. The easiest way to see this is to consider a ")#emph[#text("bracket quadratic character")]#text(", such as ")#mi("\\chi(n) = e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n )")#text(", where ")#mi("\\lfloor \\rfloor")#text(" is the ")#link("http://en.wikipedia.org/wiki/Floor_and_ceiling_functions")[#text("greatest integer function")]#text(". This is not quite a quadratic character, because ")#mi("\\lfloor \\rfloor")#text(" is not quite a linear function. However, this function is linear “a positive fraction of the time”; if one picks x and y to be some generic real numbers, one expects ")#mi("\\lfloor x+y \\rfloor")#text(" to equal ")#mi("\\lfloor x \\rfloor + \\lfloor y \\rfloor")#text(" about half of the time. Because of this, we see that while the identity (11) certainly doesn’t hold all the time for ")#mi("\\chi(n)")#text(", it does hold a positive fraction of the time, and this is enough to still cause significant bias to disrupt (3) if A correlates with this object. It is furthermore possible to concoct examples of sets A that correlate with bracket quadratic characters such as ")#mi("e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n )")#text(" but not any linear or quadratic characters. (The same phenomenon is not visible at the linear level; a bracket linear phase such as ")#mi("e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} )")#text(" can be rewritten as ")#mi("e( \\sqrt{6} n ) e( -\\sqrt{3} \\{ \\sqrt{2} n \\} )")#text(", which by Fourier series can be expressed as a linear combination of linear characters ")#mi("e( (\\sqrt{6} + k \\sqrt{2}) n)")#text(" for integer k. Note that the same trick does not work for ")#mi("e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n)")#text(".) Once one throws in these bracket quadratics, it turns out that these do in fact constitute all the possible obstructions to (3) holding in the k=4 case, as shown ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("by Ben Green and myself")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Inverse theorem for length four progressions. ")]#text("(Informal statement) Let k=4. Suppose that A is a subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" for which (3) fails. Then A correlates with a non-trivial bracket quadratic character ")#mi("\\chi(n) = e( \\sum_{j=1}^J \\lfloor \\alpha_j n \\rfloor \\beta_n j + \\xi_2 n^2 + \\xi_1 n)")#text(" for some real numbers ")#mi("\\alpha_j, \\beta_j, \\xi_1, \\xi_2")#text(" and bounded J.")
]

#text("The proof of this result involves both Fourier analysis and additive combinatorics, relying heavily on ideas from a ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("paper of Gowers")]#text(" on Szemerédi’s theorem for progressions of length 4. It will not be discussed here.")

#text("In view of the inverse theorem, the problem of establishing the asymptotic (1) for length 4 progressions then reduces (by suitable generalisations of the various methods discussed previously) to that of estimating exponential sums of which")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\mu(n) e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n )")]]

#text("is a typical example. One can begin to apply the methods of Vinogradov and Vaughan to control this type of expression. But one is soon faced with the problem of understanding the distribution of quadratic phases such as ")#mi("\\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n")#text(", and in particular to estimate exponential sums such as")

#align(center)[#mi("\\sum_{n=1}^N e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n )")#text(".")]

#text("This turns out to be somewhat unpleasant; the standard technology of Weyl differencing and the ")#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/")[#text("van der Corput lemma")]#text(" eventually works (see ")#link("http://arxiv.org/abs/math.NT/0606087")[#text("this paper of Ben Green and myself")]#text("), but does not scale well to bracket polynomials of higher degree such as ")#mi("e( \\lfloor \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n \\rfloor \\sqrt{5} n )")#text(", which would be necessary if one were to extend (1) to k beyond 4.")

#text("To resolve this, and inspired by the work in ergodic theory by ")#link("http://www.ams.org/mathscinet-getitem?mr=1412607")[#text("Furstenberg-Weiss")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2318563")[#text("Bergelson-Leibman")]#text(", and others, we re-interpreted bracket polynomials from a more dynamical systems perspective. To motivate this, observe that the linear character ")#mi("\\chi(n) = e(\\alpha n)")#text(" is closely tied to the circle rotation ")#mi("T: x \\mapsto x+\\alpha")#text(" on the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(", in that the character ")#mi("\\chi")#text(" can be described as a function ")#mi("\\chi(n) = F(T^n x_0)")#text(" of an orbit ")#mi("(T^n x_0)_{n \\in {\\Bbb Z}}")#text(" on this system, where ")#mi("x_0=0")#text(" is the origin and ")#mi("F(x) := e(x)")#text(" is the exponential function. In a similar spirit, a quadratic character such as ")#mi("\\chi(n) = e(\\alpha \\frac{n(n-1)}{2})")#text(" can be expressed in terms of the ")#emph[#text("skew shift system")]#text(" ")#mi("(x,y) \\mapsto (x+\\alpha,y+x)")#text(" on the torus ")#mi("({\\Bbb R}/{\\Bbb Z})^2")#text(", being of the form ")#mi("\\chi(n) = F(T^n x_0)")#text(" where ")#mi("x_0 := (0,0)")#text(" and ")#mi("F(x,y) := e(y)")#text(". More generally, one can also express bracket quadratic polynomials such as ")#mi("e( \\rfloor \\sqrt{2} n \\rfloor \\sqrt{3} n)")#text(" in the form ")#mi("\\chi(n) = F(T^n x_0)")#text(", where T is now the action of a group element ")#mi("x \\mapsto gx")#text(" on a 2-step nilmanifold ")#mi("G/\\Gamma")#text(", and F is some reasonable (e.g. piecewise smooth) function on this nilmanifold. (See my ")#link("https://terrytao.wordpress.com/2008/03/09/254a-lecture-16-a-ratner-type-theorem-for-nilmanifolds/")[#text("lecture notes")]#text(", this ")#link("http://www.ams.org/mathscinet-getitem?mr=2318563")[#text("paper of Bergelson and Leibman")]#text(", or ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("this paper of Ben and myself")]#text(" for details.) The relevance of 2-step nilpotent groups and nilmanifolds to length 4 progressions can be glimpsed in the identity")

#align(center)[#tao-fit-display[#mitex("(g^n x) (g^{n+r} x)^{-3} (g^{n+3r} x)^{-1} (g^{n+2r} x)^3 = 1")]]

#text("which is valid for all g, x in a 2-step nilpotent group G (compare this with (11)); it is an instructive exercise to prove this identity and to see how the 2-step nilpotency is used. (To make the connection more precise, one needs a variant of this constraint in which x lies in ")#mi("G/\\Gamma")#text(" rather than G, which is harder to state; see ")#link("http://www.technion.ac.il/~tamarzr/Thesis1.dvi")[#text("Ziegler’s thesis")]#text(", or this paper of ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("Ben and myself")]#text(", for details.) Indeed, one can reformulate the inverse theorem for length 4 progressions in an equivalent form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Inverse theorem for length four progressions, again. ")]#text("(Informal statement) Let k=4. Suppose that A is a subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" for which (3) fails. Then A correlates with a non-trivial ")#emph[#text("2-step nilsequence")]#text(" ")#mi("\\chi(n) = F(T^n x_0)")#text(" for some 2-step nilmanifold ")#mi("G/\\Gamma")#text(" (of bounded “complexity”), some group rotation ")#mi("T: x \\mapsto gx")#text(", some starting point ")#mi("x \\in G/\\Gamma")#text(", and some function ")#mi("F: G/\\Gamma \\to {\\Bbb C}")#text(" (also of “bounded complexity”; e.g. bounded Lipschitz norm will do).")
]

#text("The precise formulation of the theorem is a little technical; see this ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("paper of Ben and myself")]#text(" for details. Using this theorem and all the standard machinery, the task of establishing asymptotics such as (1) in the k=4 case now reduces to that of understanding sums such as")

#align(center)[#mi("\\sum_{n=1}^N F(T^n x_0)")#text(".")]

#text("At this point, one can start using the existing theory of equidistribution of orbits on homogeneous spaces ")#mi("G/\\Gamma")#text(" (of which nilmanifolds are an important example). It turns out that the existing theory is not quite quantitative enough for our purposes, and we had to develop a quantitative analogue of this theory; see ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("blog")]#text(" posts for more discussion. Anyway, it all works, and gives asymptotics for progressions of length 4 in the primes, as well as other linear patterns of similar “complexity” (e.g. any non-degenerate system of two equations in four prime unknowns is OK). To handle higher patterns, what we need is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Inverse conjecture for arithmetic progressions. ")]#text("(Informal statement) Let ")#mi("k \\geq 3")#text(". Suppose that A is a subset of ")#mi("\\{1,\\ldots,N\\}")#text(" of density ")#mi("\\delta")#text(" for which (3) fails. Then A correlates with a non-trivial ")#emph[#mi("k-2")#text("-step nilsequence")]#text(" ")#mi("\\chi(n) = F(T^n x_0)")#text(" for some (k-2)-step nilmanifold ")#mi("G/\\Gamma")#text(" (of bounded “complexity”), some group rotation ")#mi("T: x \\mapsto gx")#text(", some starting point ")#mi("x \\in G/\\Gamma")#text(", and some function ")#mi("F: G/\\Gamma \\to {\\Bbb C}")#text(" (also of “bounded complexity”).")
]

#text("This is a consequence of (and very closely related to) the inverse conjecture for the Gowers norm. It is already known for k=3 and k=4, and hopefully the higher k cases will be resolved in the near future, presumably using a mix of techniques from Fourier analysis, additive combinatorics, and ergodic theory. At this time of writing, this is the only remaining obstacle before we can understand the asymptotics of linear patterns in primes which genuinely involve two or more free parameters (as mentioned earlier, one-parameter problems such as the twin prime conjecture seem well out of reach of these methods for a number of reasons, one of which is that there is definitely no analogue of the inverse conjecture for such one-parameter patterns).")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Candela")]], [#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/#comment-45789")[#strong[#text("Pablo Candela")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2010")])]

#text("Professor Tao,")

#text("There might be a typo in the identity")

#mi("g^n x (g^{n+r}x)^{-3} (g^{n+2r}x)^3 (g^{n+3r}x)^{-1}=1")#text(".")

#text("Taking the case n=0, r=1, a short computation gives me that the LHS equals ")#mi("[g,x]^3")#text(", so this identity would imply that in a 2-step nilpotent group every commutator has order 3.")

#text("However I do get that ")#mi("x (g x)^{-3} (g^3 x)^{-1} (g^2 x)^3=1")#text(" in general, which indeed gives a constraint ")#mi("x=F(gx,g^2x,g^3x)")#text(" on any 2-step nilpotent group.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9836c79001f97cc7e713f381d8e8162999ea6b5efb2f54828fa27c2594ab7da-bf819d92dfdb7bf63ab190bbda3aa858596d14500c4531d69632d1dc96730c94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlos Paris")]], [#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/#comment-46663")[#strong[#text("Carlos Paris")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("Hi Terence,")

#text("I’m an amateur starting my journey into primes. I would like to know what book is good out there for beginners such as myself to learn the mathematics of number theory.")

#text("I have a blog / website dedicated to prime numbers, and I’ve started to drift into some probabilistic formulas for primes and twin primes, but I think it’s time for me to focus all that I’ve learned by using existing literature. The only help I’ve had is the internet and it’s really difficult to find good information, I discovered your website today for example…")

#text("You may like my website, let me know what you think…")

#text("Thanks and regards,")

#text("Carlos Paris")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]], [#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/#comment-232397")[#strong[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("[…] conjecture is known to be true if one introduces some additional averaging in ; see for instance this previous post. From the methods of sieve theory, one can obtain an upper bound of for the number of with all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20df117091648d108c66ae016d148c0a2c9c4672bd1e000f0dcb3c410db4e57f-231943f7f8266c4207635d563e3cc9c9246b1af97eab59eabc188a92cfae8c1a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan Grechuk")]], [#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/#comment-496124")[#strong[#text("Bogdan Grechuk")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("Dear Professor Tao,")

#text("You write: If $\\beta_\\infty > 0$ (thus there are no obstructions to solving the system of equations at infinity) and if $\\beta_p > 0$ for all p (thus there are no obstructions to solvability mod p for any p) then there will exist many solutions to the system of equations in primes when N is large enough.")

#text("I would like to extract a statement, as simple as possible, about just existence of infinitely many solutions. Is it true and follows from your results that:")

#text("If k linear forms are simultaneously POSITIVE integers infinitely often, and if for every p they are simultaneously not a multiple of p infinitely often, and no form is an affine transformation of another one (finite complexity condition), then they are all simultaneously prime infinitely often.")

#text("Condition “simultaneously POSITIVE integers infinitely often” corresponds to ” no obstructions to solving the system of equations at infinity”, but it seems to be a weaker than $\\beta_\\infty > 0$. Similarly, condition ” for every p they are simultaneously not a multiple of p infinitely often” seems to be weaker than $\\beta_p > 0$ for all p. Does the weaker conclusion “they are all simultaneously prime infinitely often” follows from these weaker conditions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/#comment-496137")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("The condition at ")#mi("p")#text(" is not an issue: if ")#mi("\\beta_p=0")#text(", then one cannot make the linear forms all coprime to p for any choice of integers, let alone for an infinite family of such. But at infinity the condition you propose is too weak to make use of the finite complexity condition. Consider for instance the affine forms ")#mi("3+5n_1, 3+5n_2, 3-5n_1-5n_2, n_3, n_3+n_1+2")#text(". This has finite complexity, and one can check that there are no obstructions mod p; also, one can make all the forms positive infinitely often by setting ")#mi("n_1=n_2=0")#text(" and ")#mi("n_3 > 0")#text(". But making all these forms simultaneously prime is equivalent to the twin prime conjecture (the positivity of the first three forms forces ")#mi("n_1=n_2=0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20df117091648d108c66ae016d148c0a2c9c4672bd1e000f0dcb3c410db4e57f-231943f7f8266c4207635d563e3cc9c9246b1af97eab59eabc188a92cfae8c1a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan Grechuk")]], [#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/#comment-496357")[#strong[#text("Bogdan Grechuk")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2018")])]

#text("Thank you. So, I need to say something like:")

#text("Let ")#mi("\\Psi")#text(" be a sequence of k affine linear forms in d variables ")#mi("x=(x_1, \\dots, x_d)")#text(". Let ")#mi("f_\\Psi(N)")#text(" and ")#mi("g_\\Psi(N)")#text(" be the number of ")#mi("x \\in [-N,N]^d")#text(" such that all ")#mi("\\psi_i(x)")#text(" are positive and primes, respectively. Assume that (i) ")#mi("\\lim\\limits_{N\\to\\infty}\\frac{f_\\Psi(N)}{N^d} > 0")#text(", (ii) for every p there exists ")#mi("x \\in Z^d")#text(" such that all ")#mi("\\psi_i(x)")#text(" are not multiples of $p$, and (iii) no form ")#mi("\\psi_i(.)")#text(" is an affine transformation of another form ")#mi("\\psi_j(.)")#text(". Then ")#mi("\\lim\\limits_{N\\to\\infty}\\frac{g_\\Psi(N)\\cdot (\\log N)^t}{N^d} > 0")#text(". In particular, all $\\psi_i(x)$ are simultaneously prime for infinitely many ")#mi("x \\in Z^d")#text(".")

#text("Not as simple formulation as I hoped, but a bit simpler than in the paper because I do not define ")#mi("\\beta_p")#text(". I hope this is correct now?")
]
]
]
