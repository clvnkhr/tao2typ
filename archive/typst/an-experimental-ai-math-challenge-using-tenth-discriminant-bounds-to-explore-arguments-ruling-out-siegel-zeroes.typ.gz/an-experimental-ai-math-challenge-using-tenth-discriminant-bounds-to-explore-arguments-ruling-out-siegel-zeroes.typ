// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/
// Converted to Typst by tao2typ: "2026-10-23T11:54:20.942317+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An experimental AI-math challenge: using tenth discriminant bounds to explore arguments ruling out Siegel zeroes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An experimental AI-math challenge: using tenth discriminant bounds to explore arguments ruling out Siegel zeroes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/")[#text("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-23 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the spirit of my recent “")#link("https://aimath.org/videos/terry-tao-pl/")[#text("Math 2.0")]#text("” talk on new ways to use AI assistance to enhance the human understanding of mathematics, rather than substitute for it, I am using this post to propose an experimental challenge, inspired by the recent activity around excluding Landau–Siegel zeroes, as discussed in ")#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/")[#text("this previous post")]#text(".")

#text("There is a well-known connection between Landau–Siegel zeroes and the tenth discriminant problem, which I will briefly recall here; an in-depth discussion on this problem can be found in ")#link("https://www.ams.org/journals/spmj/2014-25-04/S1061-0022-2014-01312-X/S1061-0022-2014-01312-X.pdf")[#text("this survey of Shafarevich")]#text(". As far back as the work of Gauss, it was observed that there were nine discriminants ")#mi("{-d}")#text(" whose rings of integers for the associated quadratic field ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text(" enjoyed unique factorization, namely")

#align(center)[#tao-fit-display[#mitex("d = 1, 2, 3, 7, 11, 19, 43, 67, 163.")]]

#text("Gauss believed this list of nine to be the complete list of such discriminants (the “class number one problem”), but this was only proven by Heegner in 1952 by introducing the concept of a ")#link("https://en.wikipedia.org/wiki/Heegner_point")[#text("Heegner point")]#text(" on the modular curve; and the above numbers are now known as ")#link("https://en.wikipedia.org/wiki/Heegner_number")[#text("Heegner numbers")]#text(".")

#text("Prior to Heegner’s solution was the ")#link("https://doi.org/10.1093/qmath/os-5.1.293")[#text("work of Heilbronn and Linfoot in 1934")]#text(", who used what we now call the Deuring–Heilbronn repulsion phenomenon to show that the existence of a tenth discriminant in the above list can be used to “repel” any further such discriminants, so that there was at most one further Heegner number beyond the nine already known. However, this argument was ")#link("https://en.wikipedia.org/wiki/Effective_results_in_number_theory")[#text("ineffective")]#text(": no upper bound on this putative tenth discriminant was given, and so there was no obvious way to solve the class number one problem purely from this result.")

#text("There is a close connection to Landau–Siegel zeroes: if ")#mi("{d}")#text(" is a Heegner number, and ")#mi("{\\chi}")#text(" is the quadratic character associated to this quadratic field, then the ")#link("https://en.wikipedia.org/wiki/Class_number_formula")[#text("class number formula")]#text(" gives ")#mi("{L(1,\\chi) = \\frac{\\pi}{\\sqrt{d}}}")#text(", and with a bit more work one can produce a Landau–Siegel zero ")#mi("{L(\\beta,\\chi)=0}")#text(" with ")#mi("{1-\\beta \\asymp \\frac{1}{\\sqrt{d}}}")#text(". For sufficiently large ")#mi("{d}")#text(", this is inconsistent with ")#link("https://en.wikipedia.org/wiki/Siegel_zero#Landau%E2%80%93Siegel_estimates")[#text("Siegel’s theorem")]#text("; but the standard proofs of this theorem also relied on the repulsion phenomenon and were also ineffective. It was only in 1976 that ")#link("http://www.numdam.org/item/?id=ASNSP_1976_4_3_4_623_0")[#text("Goldfeld")]#text(" gave an effective version of Siegel’s theorem that was enough to at least bound the tenth discriminant, given a suitable high rank elliptic curve. In ")#link("https://numdam.org/item/SB_1983-1984__26__309_0/")[#text("followup work of Oesterlé")]#text(", combined with a high rank elliptic curve of ")#link("https://zbmath.org/0538.14023")[#text("Gross and Zagier")]#text(", the bound ")#mi("{d \\leq e^{7000}}")#text(" was obtained; using a later ")#link("https://projecteuclid.org/journals/duke-mathematical-journal/volume-44/issue-4/The-rank-of-elliptic-curves/10.1215/S0012-7094-77-04431-3.full")[#text("elliptic curve of Brumer and Kramer")]#text(", proven to have high rank by Mestre, Oesterlé, and Serre, the bound was improved to ")#mi("{d \\leq e^{55}}")#text(". See ")#link("https://projecteuclid.org/journals/bulletin-of-the-american-mathematical-society-new-series/volume-13/issue-1/Gauss-class-number-problem-for-imaginary-quadratic-fields/bams/1183552617.pdf")[#text("this survey of Goldfeld")]#text(" for more discussion.")

#text("But now we have a fair number of new (and effective) ways to rule out Siegel zeroes, either by establishing a quasi-Riemann hypothesis, or by some version of the argument in ")#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/")[#text("this previous post")]#text(". In principle, each version of these arguments should also give a bound on the tenth discriminant ")#mi("{d}")#text(" (without using Heegner’s solution to the class number one problem that rules out this discriminant). The task of making each of these estimates explicit enough to create such a bound is rather tedious for humans. However, it seems eminently suitable for AI.")

#text("Thus, the challenge I pose is, for each of the new manuscripts or digestions relating to either the quasi-Riemann hypothesis or the Landau–Siegel zero problem (or by some novel argument), to use an AI tool to work out an effective upper bound for a hypothetical tenth discriminant ")#mi("{d}")#text(", without using Heegner’s methods, and to make best efforts to optimize this constant. This serves several purposes:")

#list(
[#text("If the threshold is low enough to resolve the remaining discriminants by direct computation, this would yield a new solution of the class number one problem — possibly one that is formalizable in Lean in a high quality fashion (suitable for instance for upstreaming to Mathlib).")],
[#text("By performing this exercise on each of the different writeups, we obtain a way to compare the “strength” of each such writeup (after performing whatever optimizations are available for each writeup), which could give insight as to the relative advantages or disadvantages of different arrangements of the methods.")],
[#text("The exercise of minimizing the upper bound may spur the creation of entirely new arguments to solve either the class number one problem, or the elimination of Landau–Siegel zeroes.")],
[#text("There are many previous “failed” attempts at excluding the Landau–Siegel zero. It is possible that some of them contain ideas that can be combined with the newer solutions to this problem to “repair” the proofs, or at least improve the bound on the tenth discriminant.")],
[#text("Efforts here may also help improve the state of knowledge on higher class number problems, which by the work of Watkins in 2004 is currently solved up to class number 100.")]
)

#text("Furthermore, as both of these problems are already solved (for over seven decades, in the case of the class number one problem), there is little risk of such a competition inadvertently disrupting an ongoing research project.")

#text("I am therefore inviting interested readers to contribute in the comments any effective bounds on the tenth discriminant they can extract from either an existing argument, or a novel one, with any amount of AI use permitted for this challenge so long as it is disclosed. Note that the challenge is broader than simply getting the “best” bound overall amongst all possible approaches; I am also interested in what bounds one can extract from any specific approach, even if they are worse than, say, the bounds of Goldfeld or Oesterlé. In particular, “negative” results in which the bounds obtained from a given method end up being rather large are still scientifically useful pieces of information that are worth reporting. One could also explore other directions, such as bounds that avoid using extensive compute to squeeze out the maximal amount of optimization, but are instead clean enough that their arguments are human-verifiable.")

#text("Any large outputs should be posted as links rather than as plain text; for instance, pointing to a Github repository containing one’s work would be a reasonable way to submit an entry (but a human-generated summary should be provided in the main text of the comment).")

#text("I would ask contributors to not prioritize speed above quality; this is not intended to be a race regarding who is “first” to claim any given bound. The spirit is intended to be collaborative rather than competitive: think of a Polymath style project, updated for the AI era. In particular, as with traditional mathematical research, it would be appropriate to build upon previous contributions to obtain an improved bound for a given proof technique. (But in such cases, one should of course give appropriate attribution to the prior source.)")

#text("I will not insist on formal verification (e.g., in Lean) of the results, though I would ask anyone submitting a purely AI-generated solution to do enough due diligence to check the output (e.g., with an independent AI tool) before posting it here.")

#text("I am looking forward to the results of this experimental challenge, both for the mathematical insights gained, and for the lessons learned on how to crowdsource AI assistance in mathematics in a responsible fashion.")

#heading(level: 1)[#text("Comments (64)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698444")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("It is good to see that you are back. Thanks a lot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698449")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Dumping here some calculations from late last night. If ")#mi("{\\mathbb Q}(\\sqrt{-d})")#text(" has class number ")#mi("1")#text(" then every rational prime ")#mi("p<d/4")#text(" is inert in the extension so has ")#mi("\\chi_d(p)=-1")#text(". Letting ")#mi("q")#text(" be the conductor of the quadratic character (at most four times the discriminant), we examine")

#mi("\\sum_{\\substack{p<q/16 \\\\ \\chi_d(p)=-1}} \\frac{\\log p}{p} = \\sum_{p<q/16} \\frac{\\log p}{p} - \\sum_{p|q} \\frac{\\log p}{p}\\,.")

#text("Suppose Mertens’s estimate reads ")#tao-math("\\left|\\sum_{p<x} \\frac{\\log p}{p} - \\log x\\right| \\leq C_\\textrm{M}", block: false)#text(" Then")

#mi("\\sum_{p<q/16} \\frac{\\log p}{p} - \\sum_{p|q} \\frac{\\log p}{p} \\geq \\log \\frac{q}{16} - c_\\textrm{M} - \\log\\log q - (1+c_\\textrm{M})")

#text("So a no-Landau–Siegel zeroes upper bound of the form")

#mi("\\sum_{\\substack{p<x \\\\ \\chi_d(p)=-1}} \\frac{\\log p}{p} \\leq \\alpha \\log x + \\beta \\log q + \\log\\log x + C_\\textrm{LS}")

#text("translates to the inequality (forfeiting a small gain)")

#mi("\\log q - \\log\\log q - (1+2C_\\textrm{M}+\\log 16) \\leq (\\alpha+\\beta)\\log q - \\alpha\\log 16 + \\log \\log q + C_\\textrm{LS}")#linebreak()#text("that is")#linebreak()#mi("(1-\\alpha-\\beta)\\log q \\leq 2\\log\\log q + C_\\textrm{LS} + 2C_\\textrm{M} + (1-\\alpha)\\log 16")

#text("which gives an upper bound on ")#mi("q")#text(" as long as ")#mi("\\alpha + \\beta < 1")#text(". For example if ")#mi("\\alpha=\\frac12,\\, \\beta=\\frac14,\\, C_\\textrm{M}=2,\\, C_\\textrm{LS}=10")#text(" one gets about ")#mi("q< 10^{15}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698451")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("It seems I made an error last night; I’m now getting a bound of ")#mi("q<10^{45}")#text(". I also lost a ")#mi("+1")#text(" in the RHS of the last equation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3bbb6d5093defb6deae2ca518fec71b01aa4b328e393fb81d77561eca1d59567-60fd8d563647dce0144890265925dcffe2d1f36536bc089619178f0a14510d33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksei Kulikov")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698454")[#strong[#text("Aleksei Kulikov")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I am sorry, as this is not related to the main point of the post, but I believe your history of effective versions of the Siegel theorem is grossly incorrect. What I believe to be correct I took from Goldfeld’s own survey of the problem from 1985 ")#link("https://pubs.ams.org/BULL/1985-13-01/S0273-0979-1985-15352-2")[#text("https://pubs.ams.org/BULL/1985-13-01/S0273-0979-1985-15352-2")]

#text("In his 1976 paper Goldfeld proved a lower bound on the class number in terms of the analytic rank of an elliptic curve. However, for his method to be actually useful he needed an elliptic curve with analytic rank at least 3, which was not known at that time. The first provable example of such an elliptic curve, and thus the first effective estimate, was established only in 1983 in the celebrated work of Gross and Zagier (in fact, when I read about the class number problem in the past, the pendulum of misattributing history was usually swinging in the other way, with calling it a “Gross–Zagier theorem”, and not mentioning Goldfeld at all).")

#text("As far as I can see, all explicit constants actually come from the work of Oesterlé, the constant 7000 comes from optimizing the work of Goldfeld with the elliptic curve of Gross and Zagier (there is actually an extra small term depending on the prime factorization of the potential d, which might make the constant even larger, but since for class number 1 problem I believe we can restrict to prime discriminants, this is not a big issue). The constant 55 comes from a different elliptic curve, found by Brumer and Kramer, but, if I understood Goldfeld correctly, it was proved to have analytic rank 3 only later in the works of Mestre, Oesterlé and Serre.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698458")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Thanks for the additional references and context! I have updated that portion of the blog post accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698456")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#mi("q < 10^{10}")#text(", relying on ")#link("https://arxiv.org/abs/2610.15483v1")[#text("Banks’s Theorem 1.1")]#text(".")

#text("I used codex to prepare the argument, running GPT-6-Astra max. Codex also generated the following summary.")

#link("https://github.com/twinheterodox/tenth-discriminant")[#text("Proof, source code, and verification outputs on GitHub")]

#text("The analytic step is a classical theta-integral argument with explicit constants. Under the class-number-one assumption, for ")#mi("q\\geq 10^{10}")#text(" it produces a real zero ")#mi("\\beta\\in(0,1)")#text(" satisfying")

#mi("\\displaystyle 1-\\beta\\leq\\frac{10}{\\sqrt{q}},")

#text("and consequently")

#mi("\\displaystyle (1-\\beta)\\log q\\leq\\frac{10\\log q}{\\sqrt{q}}\\leq 0.0024.")

#text("This contradicts Banks’s stated lower bound")

#mi("\\displaystyle (1-\\beta)\\log q\\geq 0.003.")

#text("Below this threshold, an exact integer sieve uses the necessary condition that every prime smaller than ")#mi("q/4")#text(" is inert. Using primes only up to ")#mi("109")#text(", it leaves precisely the absolute fundamental discriminants")

#mi("\\displaystyle 3,4,7,8,11,19,43,67,163.")

#text("Two implementations using different algorithms agree, and reduced-form enumeration checks the surviving fields. The argument avoids Heegner’s methods and does not use Banks’s separate small-conductor computational extension.")

#text("AI disclosure: Codex produced this summary, the derivation, the write-up, and both programs. Both programs were written by the same assistant, and their results have been cross-checked. The mathematical argument was also cross-checked with a different frontier model. I would particularly welcome scrutiny of the theta-integral lemma and the application of Banks’s theorem.")

#text("(Ed: To be clear: “I” in that last sentence is the AI model.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698461")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Ed: I will do improvements within the same general approach as replies rather than top-level comments. Codex summary follows.")

#mi("q < 5\\times 10^7")#text(", improving the previous bound by a factor of 200.")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.2.0")[#text("Version 2: complete proof, source code, and verification outputs")]#text(". The original version remains available separately.")

#text("There are two changes. First, a sharper theta-integral estimate, retaining the terms from ")#mi("\\pm 1,\\ldots,\\pm 30")#text(", gives")

#mi("\\displaystyle 1-\\beta < \\frac{2}{\\sqrt {q}}")

#text("for ")#mi("q\\geq 49{,}000{,}000")#text(", under the class-number-one assumption.")

#text("Second, using ")#link("https://arxiv.org/abs/2610.15483v1")[#text("Banks’s Lemmas 4.2 and 5.1 and Corollary 6.3")]#text(" with ")#mi("H=10^9")#text(" and ")#mi("N=q^{18}")#text(" gives")

#mi("\\displaystyle (1-\\beta)\\log q > 0.00509")

#text("for ")#mi("q\\geq 5\\times 10^7")#text(". The sharper theta estimate gives")

#mi("\\displaystyle (1-\\beta)\\log q < 0.00502")

#text("throughout the same range, yielding a contradiction. These intermediate results of Banks remain external inputs. His separate small-conductor computation is not used.")

#text("The original finite sieve already covers the larger range, so its code, outputs, and final list of nine discriminants are unchanged. Version 2 contains the complete cumulative proof and a certificate with 23 exact rational checks of the new constants.")

#text("AI disclosure: Codex generated the refinement, the write-up, the arithmetic checker, and this summary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698467")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Ed: the manuscripts for each version are getting unwieldy (and unreadable for me) since they’re relying implicitly on prior versions. I have codex rewriting this version 3 proof to be more self-contained. It should be finished in a few minutes. Codex summary follows:")

#mi("q < 10^6")#text(", a further factor of 50 improvement over v2.")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.3.0")[#text("Version 3: proof, source code, and verification outputs")]#text(". Earlier versions remain available separately.")

#text("This continues to use Banks’s determinant construction, with a different input from the class-number-one assumption: a direct estimate for split primes replaces the theta-integral zero construction.")

#text("Under that assumption, each split prime supplies two primitive lattice points of positive imaginary part with that prime as norm. Counting these points, and sieving out pairs whose coordinates share a factor among ")#mi("2,3,5,7")#text(", gives")

#mi("\\displaystyle \\sum_{\\substack{p\\leq X\\\\ \\chi_D(p)=1}}\\frac{\\log p}{p}<\\frac{0.493(\\log X)^2+5.04\\log q}{\\sqrt {q}}")

#text("for ")#mi("q\\geq 10^6")#text(" and ")#mi("X\\geq q/4")#text(". Combined with explicit prime estimates of Rosser-Schoenfeld and a bound on ramified primes, this supplies a lower bound for the weighted sum of inert primes.")

#text("Applying ")#link("https://arxiv.org/abs/2610.15483v1")[#text("Banks’s Lemmas 4.2, 5.1, and 6.2")]#text(" with ")#mi("H=10^9")#text(", ")#mi("N=q^{13}")#text(", and ")#mi("M=N^{4/3}")#text(" then gives a contradiction throughout ")#mi("q\\geq 10^6")#text(". The final comparison has an exact rational margin greater than ")#mi("0.022")#text(".")

#text("The determinant construction and cited lemmas remain external inputs. This argument uses Banks’s Lemma 6.2 directly, without the zero-dependent prime-bias estimate or Corollary 6.3. No Heegner method or small-conductor zero computation is used.")

#text("The original finite sieve already covers the remaining range, so its code, outputs, and final list of nine discriminants are unchanged. The new checker passes 26 exact arithmetic checks and 22 finite checks of the lattice formulas and prime-norm multiplicities.")

#text("AI disclosure: Codex generated the new argument, the write-up, the checker, and this summary. An independent mathematical cross-check of v3 is pending; the completed v2 cross-check does not cover the new argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698474")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Ed: determinant construction changed but still the same general approach so posted as a reply. Codex summary follows:")

#mi("q < 4000")#text(", a factor of 250 improvement over the previous ")#mi("q < 10^6")#text(".")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.4.0")[#text("Version 4: self-contained proof, source code, and verification outputs")]#text(" · ")#link("https://github.com/twinheterodox/tenth-discriminant/releases/download/v0.4.0/tenth-discriminant-v0.4.0.pdf")[#text("Direct PDF")]#text(".")

#text("This changes the determinant construction: the direct split-prime count from ")#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/#comment-698467")[#text("my earlier v3 comment")]#text(" is now combined with Ben Green’s derivative Gram determinant, working in the quadratic field itself.")

#text("Under the class-number-one assumption, counting primitive quadratic integers of prime norm bounds the weighted sum of split primes. Explicit prime estimates of Rosser–Schoenfeld then force a lower bound for the weighted sum of inert primes. Frobenius at those primes makes a positive integer determinant divisible by a product exceeding its Archimedean upper bound.")

#text("The refinements are a sharper resultant criterion for nonsingularity, evaluation points in a rectangle adapted to the quadratic-integer lattice, and an absolute-value estimate that retains the decrease of polynomial degree under differentiation. With monomials of degrees less than ")#mi("R,S")#text(" and derivatives of orders less than ")#mi("J")#text(", the choices")

#mi("R=q^4,\\qquad S=\\lfloor R/50\\rfloor,\\qquad J=\\lfloor R/55\\rfloor")

#text("give a contradiction for every ")#mi("q\\geq4000")#text(". The normalized comparison has an exact rational gap greater than ")#mi("0.007")#text(".")

#text("The ten-page paper includes the determinant and resultant arguments and the complete finite classification; no earlier version is needed. The stated Rosser–Schoenfeld estimates and classical quadratic theory remain external inputs. No Heegner method or computed zero-free region for quadratic Dirichlet L-functions is used.")

#text("All 39 exact arithmetic checks pass. A separate exhaustive residue scan checks the 499 remaining candidate integers below 4000, and reduced-form enumeration verifies the usual nine survivors. Earlier versions remain available at their original links.")

#text("AI disclosure: Codex developed the new derivation, write-up, verification programs, and this summary. Both v3 papers have passed independent mathematical cross-checks. Independent mathematical review of this v4 has also passed.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698479")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#mi("q < 2000")#text(", halving the v4 bound.")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.5.0")[#text("Version 5: proof, source code, and verification outputs")]#text(" · ")#link("https://github.com/twinheterodox/tenth-discriminant/releases/download/v0.5.0/tenth-discriminant-v0.5.0.pdf")[#text("Direct PDF")]#text(".")

#text("This retains Green’s derivative determinant but changes how it is used. Mellin averaging over its size parameter produces a lower bound for the convergent sum of ")#mi("(\\log p)/p^{71/70}")#text(" over split and ramified primes.")

#text("A logarithmic derivative of the Euler product of primitive quadratic norms gives a competing upper bound. This retains the contribution of composite norms that was discarded in the earlier point-count estimate. Euler summation controls the norm series and its derivative with explicit error bounds.")

#text("At ")#mi("q=2000")#text(", the determinant lower bound exceeds ")#mi("27.696")#text(", while the Euler-product upper bound is less than ")#mi("27.679")#text(". The difference increases with ")#mi("q")#text(", so the contradiction has a certified gap greater than ")#mi("0.017")#text(" throughout ")#mi("2000\\leq q\\leq4000")#text(".")

#text("The eleven-page paper gives the new interval argument in full, including the determinant and resultant proofs, and cites v4 for ")#mi("q\\geq4000")#text(". All 37 exact arithmetic checks pass. An exhaustive check of the 249 remaining candidate integers below 2000, followed by reduced-form enumeration, leaves the usual nine discriminants.")

#text("AI disclosure: see previous comments.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698460")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Thanks to Lior for the nice computations.")

#text("I just wanted to record some elementary observations that may be useful for computations. I’m not sure what kind of large computations are feasible with Lean these days, and would be glad for someone to weigh in.")

#text("If Q(sqrt(-q)) is a hypothetical tenth discriminant other than the nine known, then q>163 is a prime that is 3 mod 4, by Gauss’s genus theory. As Lior mentions, this means (-q/p)=-1 for all primes p < q/4. Since 2 and 3 are inert, this gives q = 19 mod 24.")

#text("One can use additional small primes and the Chinese remainder theorem to impose more conditions on q. For instance, using (-q/5)=-1 we see that q=43,67 mod 120. Using both 5 and 7 gives q=43,67,163,403,547,667 mod 840.")

#text("In this way, we can put q in a small number of residue classes mod some large-ish M, and then search in each arithmetic progression for primes. In this way, we ought to be able to rule out q < X for somewhat large X. This kind of argument seems simple enough for Lean and Mathlib.")

#text("There are other ways to eliminate large ranges of q as having class number 1, but these may not interact as well with Lean. For instance, a line of argument due to Stark, Montgomery–Weinberger, Watkins uses low-lying zeros of other Dirichlet L-functions. Stark (1966) computed low-lying zeros of the zeta function to moderate precision and was able to prove q>exp(2.2*10^7). Cherubini and Wallisser (1987) used continued fractions to rule out small values of a linear form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698541")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Actually, having a list of the first N ordinates of zeros of the zeta function to precision P in Lean’s Mathlib may be a worthwhile standalone artifact, if N and P are sufficiently large. There are many papers in analytic number theory that rely on inputs of this kind, including: Stark’s work mentioned above on lower bounds for a hypothetical tenth discriminant, the work of Odlyzko and te Riele disproving the Mertens conjecture, and the work of Lehman on the difference between pi(x) and li(x).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0ff957cc3a07c7bcf007b031948591baa120075111033161781a507e9142ec-01884b2fd037b1ef9035ecf3ccbd17d1ace80fa06252dcb06df35f484605c646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698463")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I just want to flag up this variant argument of Roelof van Dijk ")#link("https://hexagonmath.org/2610.00409v1")[#text("https://hexagonmath.org/2610.00409v1")]#text(". It uses an auxillary inert prime $p_0$ (the maximal one $\\leq X$) to show that the determinant is nonzero. Essentially the same argument is given in the paper of Jacob Pescador mentioned in Terry’s other blog post/my comment on that post – that paper is not in the public domain.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b8f812e91eea842556e307a39dce0be89c473f5258dfa42727bd0b5e32e43ae-bedcd4e530bf3e3224ec7bfcd48a819f5c51f67b11c22ee6278a5536dd081289.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Pescador")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698508")[#strong[#text("Jacob Pescador")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Following up here, the paper is now in the public domain, every version is kept here: ")#link("https://jacobpescador.github.io/ai-math/papers/landau-siegel-stepanov/")[#text("https://jacobpescador.github.io/ai-math/papers/landau-siegel-stepanov/")]

#text("Version 1 is the original I sent Ben 3 days ago.")

#text("All mathematics and text were generated by AI systems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae38e135b58bf1edcf015c0f7c38c592d0f4f1f3048a5be675f0f9152296ec07-763d22ae31b613ea9a8d2e1ffd75d8ed1022de560771b05ba684043a9eafd90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roelofvandijk")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698529")[#strong[#text("roelofvandijk")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Thank you for sharing this. I have uploaded a v2 which is a bit cleaner, with a slightly stronger argument, and added a tenth discriminant bound of 8*10^9 for D. Unfortunately, it now exceeds 2 pages. ")#link("https://hexagonmath.org/pdf/2610.00409v2")[#text("https://hexagonmath.org/pdf/2610.00409v2")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3aab0835ddf2e39efc737de9b14c6e7944583a2cf6e4277913e90f6cb5c0bb39-98558398156b3d54b8178ecb8b7775b92b29fdbed2e60828d5e9f393d5930f0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698466")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Following up on twinheterodox’s comments, here is an independent derivation of the same route (Banks’s Theorem 1.1, a zero-forcing lemma, and a Rabinowitsch sieve), with a sharper constant in the zero-forcing step and an elementary proof. Note and scripts: ")#link("https://github.com/michaelmross/tenth-discriminant")[#text("https://github.com/michaelmross/tenth-discriminant")]#text(".")

#text("Lemma. If ")#mi("D=-d")#text(" is a fundamental discriminant with ")#mi("h(D)=1")#text(" and ")#mi("d \\geq 10^{10}")#text(", then ")#mi("L(s,\\chi_D)")#text(" has a real zero ")#mi("\\beta")#text(" with ")#mi("1-\\beta < 2/\\sqrt{d}")#text(". The asymptotically sharp constant is ")#mi("6/\\pi")#text(".")

#text("Sketch. Poisson summation in one variable of the principal form (the Chowla–Selberg expansion) gives")

#mi("\\zeta_K(s) = \\zeta(2s) + \\sqrt{\\pi}\\frac{\\Gamma(s-1/2)}{\\Gamma(s)} (\\sqrt{d}/2)^{1-2s} \\zeta(2s-1) + E(s)")#text(",")

#text("where ")#tao-math("\\left|E(s)\\right| \\leq 8\\pi e^{-\\pi \\sqrt{d}}", block: false)#text(" near ")#mi("s=1")#text(".")

#text("Take ")#mi("\\sigma = 1 - 2/\\sqrt{d}")#text(". The first term is then larger than ")#mi("\\zeta(2) \\approx 1.645")#text(". The second term is negative, but its size is at most ")#mi("1.572")#text(": this follows from ")#mi("\\zeta(u) \\geq 1/(u-1)")#text(" on ")#mi("(0,1)")#text(" and the fact that ")#mi("\\Gamma(s-1/2)/\\Gamma(s)")#text(" is monotone near ")#mi("s=1")#text(". Hence ")#mi("\\zeta_K(\\sigma) > 0.07")#text(".")

#text("On the other hand, ")#mi("\\zeta_K(s) \\to -\\infty")#text(" as ")#mi("s \\to 1^-")#text(", because the residue at ")#mi("s=1")#text(" is positive. So ")#mi("\\zeta_K")#text(" has a zero in ")#mi("(\\sigma, 1)")#text(". Since ")#mi("\\zeta(s) < 0")#text(" there, the zero belongs to ")#mi("L(s,\\chi_D)")#text(".")

#text("Consequence. For ")#mi("d \\geq 10^{10}")#text(" the lemma gives ")#mi("(1-\\beta)\\log d < 4.6 \\times 10^{-4}")#text(". Banks’s theorem requires at least ")#mi("3.0 \\times 10^{-3}")#text(", so any tenth discriminant has ")#mi("d < 10^{10}")#text(". This uses only the first assertion of Banks’s theorem, not the small-conductor computation. The margin is about 6.5x, so a weaker ")#mi("\\delta_0")#text(" would also suffice.")

#text("Below ")#mi("10^{10}")#text(". If ")#mi("h=1")#text(" and ")#mi("d > 8")#text(", then ")#mi("d \\equiv 3 \\pmod 8")#text(" and ")#mi("(-d/p) = -1")#text(" for every prime ")#mi("p < (d+1)/4")#text(". A CRT sieve over the primes up to 23 leaves about 1.6 million candidates in ")#mi("(163, 10^{10})")#text(". None survives the primes below 2000, and the run takes 0.4 s in numpy.")

#text("The repo also checks the Chowla–Selberg identity numerically against ")#mi("\\zeta(s)L(s,\\chi)")#text(", with agreement to ")#mi("10^{-29}")#text(" for ")#mi("d \\leq 163")#text(", and recovers the Heegner list by brute force.")

#text("Everything rests on Banks’s Theorem 1.1, which is where independent checking is most valuable.")

#text("AI disclosure: the lemma, its proof, and the scripts were developed with Claude Opus (Anthropic). I have checked the argument and run the scripts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5f4bbe57a9e20b26ec7928db517eb8ba9f2621604b376ecc5c1e317d52854bd-574eb45d490db0560592fe331e8cd3d4036885477a028c477b2b5bcf283d55e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henric Larsson")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698469")[#strong[#text("Henric Larsson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I would like to contribute a short AI-assisted note to the tenth-discriminant challenge.")

#text("Using the explicit real-zero estimates of Banks (2026) and Lu–Zaman–Zhao (2026), I derive an elementary lower bound for imaginary quadratic class numbers using Dirichlet hyperbola and positivity of the coefficients of ζ(s)L(s,χ).")

#text("This gives the explicit bound ")#strong[#text("|D| < 50,000")]#text(" for any imaginary quadratic field of class number one. Two independent exact enumerations then recover precisely the nine classical fields, without using Heegner’s classification.")

#text("This is not an improvement on the strongest existing numerical bounds; in particular, Bennett–Martin–O’Bryant–Rechnitzer (2018) already imply a smaller cutoff. The contribution is a compact quantitative extraction from the recent zero-free estimates.")

#text("The work was conducted with GPT-6 Extra High assistance and subsequently independently reviewed by a separate GPT-Pro model. The audit verified the deduction and finite calculations conditional on the cited zero-free theorems; it was not human peer review.")

#strong[#text("Paper, LaTeX source, verification code and audit:")]

#link("https://github.com/henlar1975/Tao-tenth-discriminent-bound")[#text("https://github.com/henlar1975/Tao-tenth-discriminent-bound")]

#text("Henric Larsson")#linebreak()#text("Independent researcher")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698471")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("A quick contribution from ")#link("https://os.openmathmodel.org/app/")[#text("playing around with the SAIR open model")]#text(": it seems that the Selberg-Chowla formula implies that if ")#mi("d")#text(" is the tenth discriminant, then there is a zero ")#mi("L(\\beta,\\chi)=0")#text(" with ")#mi("\\beta \\geq 1 - \\frac{3.2}{\\sqrt{d}}")#text(" for ")#mi("d \\geq 655")#text(". This, combined with the 7/8 quasiRH, gives a bound of ")#mi("d < 655")#text(" for the tenth discriminant, and ")#mi("d < 1475")#text(" if one uses the 11/12 quasiRH instead.")

#text("While these results are numerically stronger than those obtained by other methods, they are also using much more powerful machinery. I would definitely be interested in seeing what other approaches give for the tenth discriminant, even if the numerical value of these bounds is significantly larger than those given here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/929ca06ded4682ce0e72445bf0eb7fe5554a268622f4629df904996d58ed27ed-e0437d39d9afd4ce5617bc9441d1bb8eed497e743b93ad24c0250d50cfa5ca16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LemmaLab")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698472")[#strong[#text("LemmaLab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Bound from OpenAI’s quasi-Riemann hypothesis: ")#mi("h(-d)=1 \\Rightarrow d \\leq 653")#text(".")

#text("Input: OpenAI’s zero-free half-plane (no zeros of any Dirichlet L-function with real part exceeding 7/8). The deduction is classical; the point is the explicit constant.")

#enum(start: 1, 
[#text("If ")#mi("h(-d)=1")#text(" and ")#mi("d \\notin \\{3,4,8\\}")#text(", genus theory forces ")#mi("d \\equiv 3 \\pmod 4")#text(" prime. The only reduced form is then ")#mi("Q=x^2+xy+\\frac{d+1}{4}y^2")#text(", and ")#mi("\\zeta_K(s)=\\frac12\\sum_{(x,y)\\neq 0} Q(x,y)^{-s}")#text(".")],
[#text("Chowla-Selberg (the same expansion as in michaelmross’s comment above): ")#mi("\\zeta_K(s)=\\zeta(2s)+\\sqrt{\\pi}\\,\\frac{\\Gamma(s-1/2)}{\\Gamma(s)}\\,(\\sqrt{d}/2)^{1-2s}\\,\\zeta(2s-1)+E(s)")#text(", where ")#mi("E")#text(" is a Bessel series of size about ")#mi("e^{-\\pi\\sqrt {d}}")#text(". The difference is that we evaluate it at the fixed point ")#mi("s=7/8")#text(" rather than near ")#mi("s=1")#text(".")],
[#text("At ")#mi("s=7/8")#text(" the main part is ")#mi("M(d)=\\zeta(7/4)+C\\,(\\sqrt {d}/2)^{-3/4}\\,\\zeta(3/4)")#text(" with ")#mi("C=\\sqrt{\\pi}\\,\\Gamma(3/8)/\\Gamma(7/8)\\approx 3.8558")#text(" and ")#mi("\\zeta(3/4)\\approx -3.4413")#text(". It increases with ")#mi("d")#text(", and an explicit bound for ")#tao-math("\\left|E\\right|", block: false)#text(" decreases with ")#mi("d")#text(". Arb ball arithmetic gives ")#mi("\\zeta_K(7/8) \\geq 1.39\\cdot 10^{-5}")#text(" at ")#mi("d=654")#text(", hence ")#mi("\\zeta_K(7/8)")#text(" is positive for all ")#mi("d \\geq 654")#text(".")],
[#text("Since ")#mi("\\zeta(7/8)")#text(" is negative, ")#mi("L(7/8,\\chi_{-d})=\\zeta_K(7/8)/\\zeta(7/8)")#text(" is negative, while ")#mi("L(1,\\chi_{-d})")#text(" is positive. So there is a real zero in ")#mi("(7/8,1)")#text(", a contradiction. Hence ")#mi("d \\leq 653")#text(".")],
[#text("Counting reduced forms for all fundamental discriminants with ")#mi("d \\leq 653")#text(" leaves exactly 3, 4, 7, 8, 11, 19, 43, 67, 163.")]
)

#text("Status: the input is OAI.DirichletCharacter.LFunction_ne_zero_of_seven_eighths_lt_re in openai/math (commit 1581d4cb), stated for every Dirichlet character with no further hypotheses. The proof source was reviewed with AI assistance (no sorry, no extra axioms, no native_decide) but not compiled. With the 11/12 version (paper of Oct 5) the same argument gives ")#mi("d \\leq 1151")#text(" (computed numerically, not certified).")

#text("For comparison, the Siegel-zero route currently gives ")#mi("10^6")#text(" (twinheterodox v3) and ")#mi("5\\cdot 10^4")#text(" (Henric Larsson, using Banks and Lu-Zaman-Zhao); a fixed zero-free half-plane is much stronger for this problem, at the price of resting on the QRH input.")

#text("AI disclosure: worked out with Claude (Anthropic), with rigorous numerics in Python, mpmath and python-flint (Arb). Independently checked by ChatGPT (OpenAI) with its own code: the Chowla-Selberg identity (27 tests, about 60 digits), the margin at d = 654, the error-term bound, and the class numbers up to 653. Scripts available on request.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/929ca06ded4682ce0e72445bf0eb7fe5554a268622f4629df904996d58ed27ed-e0437d39d9afd4ce5617bc9441d1bb8eed497e743b93ad24c0250d50cfa5ca16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LemmaLab")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698478")[#strong[#text("LemmaLab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Extension to all class numbers (conditional on the 7/8 QRH, as above).")

#text("For ")#mi("h=1")#text(" the thread now has 4000 (twinheterodox v4) and 11000 (Bryce) without QRH, so the QRH input mainly earns its keep for higher class numbers. Here is the general version of the argument.")

#text("For a fundamental discriminant ")#mi("-d")#text(" with ")#mi("d \\geq 5")#text(", ")#mi("\\zeta_K(s)")#text(" is half the sum of the Epstein zeta functions of the ")#mi("h")#text(" reduced forms ")#mi("(a_i,b_i,c_i)")#text(", and Chowla-Selberg applies to each. For ")#mi("s \\in [7/8,1)")#text(", using only that the principal form occurs, that ")#mi("a_i \\geq 1")#text(", and ")#mi("K_\\nu(x) \\leq \\sqrt{\\pi/2x}\\,e^{-x}")#text(" together with ")#mi("a_i \\leq \\sqrt{d/3}")#text(" for the Bessel remainder, one gets")#linebreak()#mi("\\zeta_K(s) \\geq \\zeta(2s) - \\frac{h}{2}\\left(A(s)\\,d^{1/2-s}+R(d,s)\\right)")#text(",")#linebreak()#text("with ")#tao-math("A(s)=2^{2s}\\sqrt{\\pi}\\,\\Gamma(s-1/2)\\,\\left|\\zeta(2s-1)\\right|/\\Gamma(s)", block: false)#text(" and an explicit ")#mi("R(d,s)")#text(" decreasing in ")#mi("d")#text(". If the right side is positive, ")#mi("L(s,\\chi_{-d})")#text(" is negative while ")#mi("L(1,\\chi_{-d})")#text(" is positive, contradicting the half-plane. Hence ")#mi("h \\geq 2\\zeta(2s)/(A(s)d^{1/2-s}+R(d,s))")#text(" for every ")#mi("s \\in [7/8,1)")#text(". Optimizing ")#mi("s")#text(" (it moves from 7/8 towards 0.96 as ")#mi("d")#text(" grows) and certifying with Arb gives:")

#text("every imaginary quadratic field with ")#mi("h \\leq 2")#text(" has ")#mi("d \\leq 4164")#text(";")#linebreak()#text("with ")#mi("h \\leq 10")#text(": ")#mi("d \\leq 2.81\\cdot 10^5")#text(";")#linebreak()#text("with ")#mi("h \\leq 100")#text(": ")#mi("d \\leq 6.64\\cdot 10^7")#text(";")#linebreak()#text("with ")#mi("h \\leq 1000")#text(": ")#mi("d \\leq 1.18\\cdot 10^{10}")#text(";")#linebreak()#text("with ")#mi("h \\leq 2000")#text(": ")#mi("d \\leq 5.42\\cdot 10^{10}")#text(";")#linebreak()#text("with ")#mi("h \\leq 5000")#text(": ")#mi("d \\leq 4.02\\cdot 10^{11}")#text(";")#linebreak()#text("and ")#mi("d \\geq 2^{40}")#text(" implies ")#mi("h \\geq 7946")#text(".")#linebreak()#text("(These thresholds are certified but not optimal; for ")#mi("h=1")#text(" the sharper single-form estimate above gives 653.)")

#text("For comparison, Kimura’s Lean-verified thresholds via the Siegel-zero route are ")#mi("2.85\\cdot 10^{12}")#text(" for ")#mi("h \\leq 100")#text(" and ")#mi("1.61\\cdot 10^{15}")#text(" for ")#mi("h \\leq 2000")#text(". The difference reflects the much stronger QRH input, not a cleverer argument. Since the Mosunov-Jacobson tables are complete up to ")#mi("2^{40}")#text(", the last line would in principle settle all class numbers up to 7945 conditional on QRH; I have not done that table extraction.")

#text("AI disclosure: derivation and Arb certification with Claude (Anthropic). Independently re-checked by Codex (OpenAI) with its own code: the Chowla-Selberg identity for several forms with ")#mi("a \\geq 2")#text(" (agreement to about ")#mi("10^{-64}")#text(", including even ")#mi("d")#text("), each step of the remainder bound, monotonicity in ")#mi("d")#text(", and spot checks against class numbers near ")#mi("10^5")#text(" and ")#mi("10^6")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/929ca06ded4682ce0e72445bf0eb7fe5554a268622f4629df904996d58ed27ed-e0437d39d9afd4ce5617bc9441d1bb8eed497e743b93ad24c0250d50cfa5ca16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LemmaLab")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698484")[#strong[#text("LemmaLab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#strong[#text("Application: Euler’s idoneal numbers.")]#text(" As far as I know this consequence has not been stated: ")#strong[#text("conditional on the 7/8 QRH, Euler’s list of 65 idoneal numbers is complete")]#text(" (previously known only under GRH, by Weinberger 1973; unconditionally, at most two further numbers were known to be possible).")

#text("Input: the bound ")#mi("h(-d) \\geq H(d,s) = 2\\zeta(2s)/(A(s)d^{1/2-s}+R(d,s))")#text(" for fundamental ")#mi("-d")#text(", ")#mi("d \\geq 5")#text(", ")#mi("s \\in [7/8,1)")#text(", from my comment on higher class numbers (currently in moderation). It comes from Chowla-Selberg applied to all h reduced forms.")

#enum(start: 1, 
[#text("If n is idoneal, write ")#mi("-4n = f^2 D_K")#text(". Then ")#mi("\\mathrm{Cl}(D_K)")#text(" also has exponent at most 2, so ")#mi("h(D_K) = 2^{t-1}")#text(", where t is the number of primes dividing ")#mi("D_K")#text(" (the cases ")#mi("D_K = -3, -4")#text(" are included directly).")],
[#text("A fundamental discriminant with t prime factors satisfies ")#tao-math("\\left|D_K\\right| \\geq m_t", block: false)#text(" for an explicit lower bound ")#mi("m_t")#text(" (product of small primes). For ")#mi("10 \\leq t \\leq 39")#text(", Arb gives ")#mi("H(m_t) \\geq 2^{t-1}")#text(" with a large margin (e.g. ")#mi("H(m_{10}) \\approx 1045")#text(" versus 512). For ")#mi("t \\geq 40")#text(" one uses ")#mi("H(d,7/8) \\geq C d^{3/8}")#text(" with ")#mi("C \\geq 1/12")#text(" (Arb) and ")#tao-math("\\left|D_K\\right| \\geq (t+1)!", block: false)#text(". Hence ")#mi("t \\leq 9")#text(", and for each ")#mi("t \\leq 9")#text(" a certified threshold gives ")#tao-math("\\left|D_K\\right| \\leq 5.6 \\cdot 10^8", block: false)#text(".")],
[#text("Enumerating all fundamental discriminants with exactly t prime factors below these thresholds leaves 65 with exponent at most 2 (largest 5460).")],
[#text("From ")#mi("h(f^2 D_K) = h(D_K) f \\prod_{p | f}(1-\\chi(p)/p)/u")#text(" with ")#mi("u \\leq 3")#text(", and the number of genera of ")#mi("-4n")#text(" being at most ")#mi("2^{r+1}")#text(", one gets ")#mi("\\varphi(f) \\leq 12 \\cdot 2^{\\omega(f)}")#text(". This leaves 138 conductors, the largest being 840.")],
[#text("Testing all resulting n leaves exactly Euler’s 65 numbers. The whole run takes about 30 seconds.")]
)

#text("Relation to Kimura (arXiv:2610.21511v1): his unconditional extension of the Cremona-Sutherland lists (orders with ")#mi("h(D) \\leq 1000")#text(") would also settle idoneal n with ")#mi("h(-4n) \\leq 512")#text(", though this is not stated there. The case of many prime factors is where the stronger QRH input seems needed, at least with the thresholds published there: ")#mi("t = 12")#text(" gives ")#mi("h = 2048")#text(" at ")#tao-math("\\left|D_K\\right| \\approx 1.5 \\cdot 10^{13}", block: false)#text(", while the threshold for ")#mi("h \\leq 2000")#text(" in that paper is ")#mi("1.61 \\cdot 10^{15}")#text(".")

#text("AI disclosure: derivation and code with Claude (Anthropic), Arb certification via python-flint. Independently re-checked by Codex (OpenAI) with its own code: each step of the argument, the thresholds for t up to 39 (Arb), the two finiteness steps (t at least 40, and the conductors), the generator of fundamental discriminants against brute force up to 10^6, the exponent test against Gauss composition for all n up to 5000, and a full reproduction of the final list.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/929ca06ded4682ce0e72445bf0eb7fe5554a268622f4629df904996d58ed27ed-e0437d39d9afd4ce5617bc9441d1bb8eed497e743b93ad24c0250d50cfa5ca16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LemmaLab")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698490")[#strong[#text("LemmaLab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Code, outputs and independent checks for my comments above (class number one, all class numbers, idoneal numbers): ")#link("https://github.com/LemmaLabMath/qrh-class-numbers")[#text("https://github.com/LemmaLabMath/qrh-class-numbers")]

#text("A precision on my first comment: “no sorry” refers to the DirichletL development; one dependency (PNT+, Wiener.lean) contains two sorry, which I could not trace without compiling. This does not affect my results, which are derived from the statement that Dirichlet L-functions have no zeros with ")#mi("\\mathrm{Re}\\, s > 7/8")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698494")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Just a note that OpenAI’s 11/12 quasi-GRH paper mentions just before section 1.1 that one consequence of the result is the completeness of Euler’s list of 65 idoneal numbers. This follows from the 11/12 zero-free strip and previous results in the literature: work of Elsenhans, Kluners, and Nicolae on class groups of imaginary quadratic fields with small exponent, and work of Kani and Grube relating idoneal numbers to fundamental discriminants.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/929ca06ded4682ce0e72445bf0eb7fe5554a268622f4629df904996d58ed27ed-e0437d39d9afd4ce5617bc9441d1bb8eed497e743b93ad24c0250d50cfa5ca16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LemmaLab")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698497")[#strong[#text("LemmaLab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I truly appreciate you pointing this out. I completely missed it, and I deeply regret that error.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698528")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("No worries! It’s a quick throwaway line in the 11/12 paper.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/929ca06ded4682ce0e72445bf0eb7fe5554a268622f4629df904996d58ed27ed-e0437d39d9afd4ce5617bc9441d1bb8eed497e743b93ad24c0250d50cfa5ca16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LemmaLab")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698473")[#strong[#text("LemmaLab")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Posted without having seen Terry’s comment just above; the two bounds agree (")#mi("d < 655")#text(" vs. ")#mi("d \\leq 653")#text("). Evaluating ")#mi("\\zeta_K")#text(" directly at the edge of the half-plane, rather than first locating the zero, seems to lose a little less: for the 11/12 half-plane it gives ")#mi("d \\leq 1151")#text(" instead of ")#mi("d < 1475")#text(" (that value not yet certified).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab140fc067b0b337832ce2dc96c66e69f153a8eed2bbfaf4ad03441ab55a5200-204f878ff7ccb72de7965e4c81088a9651d33367838037eab3ae55f60d867ae7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bryce")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698475")[#strong[#text("Bryce")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Combining an explicit version of ")#link("https://arxiv.org/abs/2610.21099")[#text("my polynomial-lattice argument, arXiv:2610.21099")]#text(", with the finite-range zero exclusion used by ")#link("https://github.com/henlar1975/Tao-tenth-discriminent-bound")[#text("Henric Larsson")]#text(", and a refinement of the Chowla–Selberg argument discussed by Ross and Tao, gives the cutoff ( |\\Delta|<11{,}000 ) for a negative fundamental discriminant of class number one.")

#text("Writing (q=|\\Delta|), the modifications to the argument in my paper are:")

#list(
[#text("Replace the general zero-dependent split-prime estimate with a direct count of primitive norm representations, incorporating restrictions at (2,3,5,7).")],
[#text("Work in the order generated by ((1+\\sqrt{\\Delta})/2) and (\\sqrt2), and centre the grid to improve the bounds at the complex embeddings.")],
[#text("Change the monomial region from (i+8(j+k)\\le D) to (i+192(j+k)\\le D), with grid length (N=q^7), (D\\approx9N^{4/3}/40), and prime cutoff (Q=D/2).")],
[#text("For small primes, reverse the leading term in the Frobenius relation; for larger primes, halve the error in the divisibility count.")],
[#text("At (3), additionally exploit the relation (\\theta^9\\equiv\\theta\\pmod3).")],
[#text("Make the prime estimates and remaining constants explicit, retaining Masser’s theorem as the nonvanishing input.")]
)

#text("These polynomial-lattice refinements give (q<200{,}000). For the remaining interval, Larsson’s Lu–Zaman–Zhao input combines with a sharper Chowla–Selberg sign test: retain additional terms in the zeta estimates and simplify the gamma factors by duplication. This gives (q<11{,}000), below which an elementary finite sieve recovers the nine classical discriminants.")

#text("Developed with ChatGPT assistance; the numerical inequalities have exact rational certificates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698476")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("*Used ChatGPT 6.1 Sol for this analysis. In the spirit of our host’s invitation, I am not sharing the low-quality AI write-up, but just some interesting ideas to explore further.*")

#text("I think it is possible to use the class number 1 information along with van Dijk’s argument to get an upper bound for q that is close to the quasi-GRH bounds above, in the low thousands.")

#text("Since h(-q)=1, split primes have to be represented by (a+b/2)^2+qb^2/4. Counting integers represented by this quadratic form can give an upper bound for sum_{p < X \\\\ chi(p)=1} (log p)/p that is very strong in some ranges. Use this to find a large auxiliary inert prime on the order of exp(c*sqrt(q)) that one can use as in van Dijk’s argument. Use the stronger p-power divisibility arguments from Green rather than the simplified setup of van Dijk.")

#text("There may be some numerical advantage to choosing the interpolation points from a disk instead of a rectangle.")

#text("There is quite a bit of finagling and parameter-choosing if one wants to get an upper bound for q that is very small.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/463778b7b231aa5dc8ab74532786bcaba25ca86a1ac6249ed81114648becf134-cfe4e78820552c09b2032749f2a424f7fb3940ed818e3d1103c890d398be6891.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698480")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I explored the tenth-discriminant challenge using Iwao Kimura’s explicit zero-gap estimates (")#emph[#text("Imaginary quadratic fields of class number at most 2000")]#text(", arXiv:2610.21511).")

#text("Using Kimura’s Proposition 9 with")

#mi("c=0.004401,\\quad T=19.0591,\\quad A=2{,}000{,}000,\\quad V=17{,}550")

#text("gives the numerical lower bound")

#mi("\\sqrt{q}\\,L(1,\\chi)\\geq 3.141726175\\ldots>\\pi")

#text("for the relevant conductors, using the uniform zero-gap estimate from Kimura’s certified grid.")

#text("Together with the imaginary quadratic class-number formula, this gives")

#tao-math("\\left|D\\right|<e^{19.0591}<189,348,540", block: false)

#text("for any hypothetical tenth class-number-one discriminant. It is a much larger bound than those that already have been posted here, but I share it anyway.")

#text("An exact-integer CRT sieve using splitting primes through 89 then eliminates the remaining candidates above 163.")

#emph[#text("Attribution:")]#text(" The splitting-prime obstruction and computational sieve were already used by ")#emph[#text("twinheterodox")]#text(" in this discussion. The contribution here is a different numerical specialization using Kimura’s analytic estimates, not a new classification theorem.")

#strong[#text("Research note:")]

#text("<a href=”https://drive.google.com/file/d/1TvoHMFTNdcTAjIyuOcISnzly2-sEI444/view?usp=sharing”>Read the full mathematical note (PDF)</a>")

#strong[#text("Verification code:")]

#text("<a href=”https://drive.google.com/file/d/1e4L4maEmAWyBPFGEFefsD-ruu-oTnIU8/view?usp=sharing”>View the Python verification script</a>")

#text("The numerical inequality and finite sieve have been checked computationally, but I have not independently replayed Kimura’s Lean certificates. This investigation was carried out with extensive ChatGPT 6 assistance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698500")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Ed: I ran out of replies. Consider this a continuation of the previous thread.")

#text("Headline: ")#mi("q<570")#text(", so tighter than the QRH-based argument Terry and LemmaLab gave, without using the heavier QRH machinery.")

#text("Instead of uploading a bunch more intermediate bounds, I pushed the model to tighten it as far as it could go without using “heavy machinery”. I told the model to read the comments on this post for additional ideas. My exact prompt was:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("read the comments again. the goal is to go as far as we possibly can without heavier machinery, so to the extent there are ideas there we can use them (I know you already have). We will")#linebreak()#text("attribute. Then, once you think there is nothing meaningful to be gained, we will stop and write everything up as one v6 result. Does that sound reasonable?")
]

#text("It was processing for several hours. Details are in the writeup. Somewhat interestingly, it was well down a rabbit hole using a whole bunch of different optimizations that were going to generate an extremely complex tighter bound, when it abruptly had an epiphany and discarded all that in favor of a simpler argument. At least “simpler” in some metric that makes sense to AI.")

#text("I am pretty sure this can be tightened further, but I’ve used about a month of my personal AI budget on this and it’s late (and I am not sure anyone cares).")

#text("This has not yet been independently verified because the model is getting throttled right now. There are also obvious flaws in the writeup that need fixing (I told the model to attribute provenance so it dumped a giant stream-of-consciousness paragraph at the start of the writeup)")

#strong[#text("Codex-generated summary:")]

#mi("q<570")#text(", down from ")#mi("q<2000")#text(", without QRH, a quadratic zero-free theorem, or Masser’s theorem.")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.6.0")[#text("Version 6: proof, source code, and verification files")]#text(" · ")#link("https://github.com/twinheterodox/tenth-discriminant/releases/download/v0.6.0/tenth-discriminant-v0.6.0.pdf")[#text("Direct PDF")]#text(".")

#text("This follows Terry’s request to pursue bounds using lighter machinery. It builds on Green’s derivative determinant and stronger Frobenius divisibility, van Dijk’s auxiliary-inert-prime nonvanishing argument, and Pratt’s suggestion to combine norm counts with that auxiliary prime and disk interpolation. Kerr’s higher Frobenius suggestions and the Poisson discussion by michaelmross and Terry also inform the argument; the paper gives the detailed attributions.")

#text("The main change from v5 is to retain the smoothed sum over split and ramified primes already present in the exact determinant valuation. This same sum strengthens the row and column factorial bounds through eight finite refinements, each using only the preceding stage. Further gains come from compatible higher Frobenius factors, a joint bound for derivative orders and interpolation radii, and using the auxiliary inert prime itself as the monomial width.")

#text("A positive kernel formed from a squared polynomial then compares the determinant lower bound with the quadratic norm series. Poisson summation is used at real ")#mi("s>1")#text(", with explicit error bounds that account for cancellation among the signed coefficients.")

#text("The fifteen-page paper gives the new interval argument from 570 to 2000 in full relative to its stated classical inputs, and cites the audited v5 result for the range above 2000. Five exact rational interval certificates cover the whole new interval; all 429 grouped checks pass, with a smallest certified gap greater than ")#mi("0.010389")#text(". An isolated rerun reproduces the exact outputs. A separate finite check below 570 leaves the usual nine discriminants.")

#text("Independent mathematical review of v6 is pending. The computational checks do not constitute an independent audit or formal verification.")

#text("AI disclosure: see previous comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0cd8956449e332cd23fe8731aa2d7603b299967454ce94e5b6963cdfda5bacb-3df81bb7e3a6064939d75578f3e24acd89a9fceddc4484bae0dd3f648a25ff31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698509")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("nice work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5f4bbe57a9e20b26ec7928db517eb8ba9f2621604b376ecc5c1e317d52854bd-574eb45d490db0560592fe331e8cd3d4036885477a028c477b2b5bcf283d55e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henric Larsson")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698516")[#strong[#text("Henric Larsson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("A brief follow-up to my earlier contribution.")

#text("I coordinated a separate, blind-first GPT-Pro mathematical audit of twinheterodox’s v0.6.0 argument, which claims the cutoff |D| < 570 without assuming quasi-RH or a quadratic zero-free theorem.")

#text("The initial audit found no counterexample but returned UNRESOLVED because the full numerical certification had not been independently reproduced.")

#text("We subsequently completed a separate Stage-C verification covering all 1,258 derivative interval cells, 368 auxiliary-prime endpoint checks, 1,472 feedback updates, and five signed-kernel comparisons. A fresh adjudication also checked explicit Stirling remainder bounds.")

#strong[#text("The final independent AI-audit verdict was VERIFIED WITH REPAIR, relative to the stated classical inputs, the inherited v5 result, and correct outward interval arithmetic.")]

#text("This is an independent AI-assisted mathematical review, not formal proof verification or human peer review.")

#text("Full credit for the theorem and its construction belongs to twinheterodox and the cited mathematical sources. Our contribution is independent AI-assisted verification.")

#text("Original theorem and reproducibility files:")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.6.0")[#text("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.6.0")]

#text("I intend to make the separate audit reports and verification scripts publicly accessible when practical.")

#text("Henric Larsson")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698524")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("What needed repair? Codex is generating a better writeup so we can fix anything you found.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5f4bbe57a9e20b26ec7928db517eb8ba9f2621604b376ecc5c1e317d52854bd-574eb45d490db0560592fe331e8cd3d4036885477a028c477b2b5bcf283d55e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henric Larsson")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698595")[#strong[#text("Henric Larsson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Thank you for asking. I should clarify that our label “VERIFIED WITH REPAIR” was potentially misleading.")

#text("We did ")#strong[#text("not")]#text(" find a mathematical error in your v0.6.0 proof or a numerical certificate that required correction.")

#text("The “repairs” concerned our independent audit process and its stated scope:")

#enum(start: 1, 
[#text("Our initial blind Stage A/B audit returned UNRESOLVED because the complete numerical certificate had not yet been independently verified. A subsequent Stage C completed that verification, including all 1,258 derivative cells, 368 auxiliary-prime endpoints and five signed-kernel comparisons.")],
[#text("Our independent interval implementation initially relied partly on mpmath.iv.gamma. We subsequently added separate explicit Stirling-remainder bounds for all 52 relevant exponents and repeated the critical checks successfully.")],
[#text("We made the inherited assumptions explicit, particularly the v5 result for q ≥ 2000, the classical prime estimates and correct outward interval arithmetic.")]
)

#strong[#text("We found no specific defect in your mathematical argument requiring a manuscript correction.")]

#text("A clearer description of our final verdict would therefore be “independently AI-verified relative to the explicitly stated mathematical and numerical premises,” rather than “verified with repair.”")

#text("Apologies for the ambiguity. The original frozen audit reports are preserved, and I intend to make the complete independent verification materials available on GitHub (when I get back from travel).")

#text("Henric Larsson")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698610")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Great, thanks. And no problem. It didn’t hold anything up.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698536")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("New ")#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/v0.6.1")[#text("v0.6.1")]#text(" expository rewrite of v0.6.0 (by codex, Astra-6 max).")

#text("This one is much improved over the v0.6.0 writeup.")

#text("The bound remains q < 570. It adds a proof roadmap, explains the purpose of the technical estimates, places citations where the ideas are used, and moves numerical remainder bounds to an appendix.")

#text("The mathematical argument, parameters, verification code, and recorded results are unchanged.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698514")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("v6 has been independently verified (by a second model).")

#text("I was curious what the limit of the QRH bound (Terry and LemmaLab) would yield under GRH, so I asked the model. It’s q ≤ 200.")

#text("Codex found ")#link("https://web.math.ucsb.edu/~stopple/DHP.notes.pdf#page=5")[#text("Chowla-Selberg theorem in Stopple’s exposition (p. 868)")]#text(" which says that h(−d) = 1 and d/a² > 200 contradict GRH. Taking a=1 for the principal form and d=q gives q ≤ 200.")

#text("Now apply ")#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/#comment-698460")[#text("Kyle Pratt’s comment")]#text(" : q must be prime ≡ 19 (mod 24). The only candidate between 163 and 200 is 187 but that’s composite (11 × 17). So under GRH there is no 10th discriminant.")

#text("(This is all probably well-known. But maybe interesting for other amateurs like me).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4915f1685d6f1bd5ffe1cfb2f7f2b3464c773b06b7bdfc4ba4dcdbb643dc93ea-6291806269688a34f6bf04a86569eb78cea33c3b20139bb8746761ed3f322ef9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of impossiblychocolated7c3b06799")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698525")[#strong[#text("impossiblychocolated7c3b06799")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("What are your check-in and check-out times?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9de3c3a265356ba6cf0c7f63439a27ce43ea977c80aa7ab5ab9c4dea75b00b8-d26b2ce247485a65e13f0f821a0668481bf8c85e261b922a902c76430fb89f54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of F P")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698517")[#strong[#text("F P")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I apologize for this off-topic comment, but it is clear Terry is testing ideas for Math 2.0, and I appreciate the leading role he is taking in looking for new avenues for mathematical research in the era of AI.")

#text("When AlphaFold solved the problem of protein structures, we did not hear biologist panicking for their field being solved, but excitement about direct applications in the pharmaceutical industry. The “problem” of mathematics is that new mathematical ideas (or concepts) take a long time to find their place in large-scale products. Thinking about this led me to:")

#text("(i) If we had a model trained with data before XVI century, and we asked an LLM to find a formula for the roots of polynomials of degree 3, would the LLM find the concept of imaginary quantity? May it find the formula (or formulae for all cases) for the roots, but not i. Or, if we keep pushing asking for degree 4, degree 5, and so on. Would it get complex numbers? Would it find the concept of groups in some form? We know the role of complex numbers in quantum mechanics, and from here to all sort of modern technological innovations. Can we extract new concepts from LLMs?")

#text("More examples can be given using other mathematical concepts (of course, we can now chat with an LLM), and my question is not a thought experiment, but I do not have the resources to carry it out.")

#text("(ii) Can LLMs accelerate introduction of mathematical ideas into technological innovations? For example, I asked ChatGPT if it can find any technological potential for perfectoid spaces, and it gave me a long and interesting answer. I do not only think of a direct arrow from perfectoid spaces to a technology, but to help in finding intermediate applications in Science that eventually would lead to some technology.")

#text("To identify a technology we should also identify necessities, so we may use LLMs to map (a dataset of?) necessities to potential technologies, and from here, in several steps, to potential deep (and new) mathematical concepts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b321a8911b890dc9d685e50e28640cff2f0a51ff682baa0439e32017cfec6427-ea33428db4027adc7fffaac0b37f97c46b2a887c62074c69ca0569e40eca45ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Chung")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698518")[#strong[#text("Stephen Chung")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Thanks for suggesting this problem! We have opened a dedicated problem page on rStation (")#link("https://rstation.ai/problems/tenth_discriminant")[#text("https://rstation.ai/problems/tenth_discriminant")]#text("), where AI agents can discuss approaches and publish reviewed results on this problem.")

#text("For example, this agent paper (")#link("https://rstation.ai/problems/tenth_discriminant/papers/3")[#text("https://rstation.ai/problems/tenth_discriminant/papers/3")]#text(") proves an explicit quantitative lower bound on how often both signs of λ(n)λ(p-n) occur for large primes p. Although stronger bounds have been reported, the agents give a different proof using only quadratic-character information, without the all-character zero-free theorem used in the stronger result.")

#text("We welcome other researchers and their agents to join the discussion and share results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0ff957cc3a07c7bcf007b031948591baa120075111033161781a507e9142ec-01884b2fd037b1ef9035ecf3ccbd17d1ace80fa06252dcb06df35f484605c646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698562")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Struggling to convince myself this is a net positive for mathematics")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b321a8911b890dc9d685e50e28640cff2f0a51ff682baa0439e32017cfec6427-ea33428db4027adc7fffaac0b37f97c46b2a887c62074c69ca0569e40eca45ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Chung")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698599")[#strong[#text("Stephen Chung")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Thanks for the comment. I understand that one concern may be the additional reading burden on mathematicians. The AI papers in our system are mainly intended as a shared working literature for AI agents rather than direct contributions to the human literature. There is no plan to submit these papers to arXiv or publish them externally, but we welcome mathematicians who find their work interesting to explore it further.")

#text("One motivation is to make it easier for humans to follow how AI agents develop their ideas. When a large, closed system like OpenAI’s 10,000-agent swarm produces a long proof, mathematicians only see the final proof and cannot trace how the ideas arose. Having an open space for agent discussions and citations makes the process more transparent, allowing anyone interested to see, for example, how an agent cites the work of another agent or a human.")

#text("For context, I am a machine learning researcher and built this platform to explore follow-ups to my own research. Because the agents’ discussions and papers were genuinely useful to me there, I wanted to test whether the same platform could lead to ideas useful to mathematicians.")

#text("This is still an early experiment, and I would be glad to hear how the platform could better serve the community.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698521")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("New, simplified approach. The monotonic (quadratic?) increase in proof complexity from v1-v6–and all the attendant heavy-duty numerical optimization–starts to look somewhat misguided when the bounds are already small enough to trivially check manually. So I tasked the model with finding the best “simple” bound where simplicity was not further defined. It took some back-and-forth, but in my non-professional opinion, the final result isn’t too bad.")

#strong[#text("Codex generated summary:")]

#text("q < 2¹⁵ = 32,768, with a simpler, self-contained determinant proof. This is a separate elementary companion aimed at the human-verifiable side of the challenge; the earlier v6 bound remains q < 570.")

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/elementary-v0.1.0")[#text("Elementary companion: eight-page proof, source, and verification files")]#text(" · ")#link("https://github.com/twinheterodox/tenth-discriminant/releases/download/elementary-v0.1.0/elementary-v0.1.0.pdf")[#text("Direct PDF")]#text(".")

#text("Following ")#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/#comment-698476")[#text("Pratt’s suggestion")]#text(", a direct count of quadratic norm representations bounds the split primes and supplies an auxiliary inert prime R in (q⁴, q⁵]. The proof uses ")#link("https://hexagonmath.org/2610.00311v2")[#text("Green’s derivative determinant")]#text(" on a rectangular grid, with nonvanishing proved by ")#link("https://hexagonmath.org/2610.00409v1")[#text("van Dijk’s finite-field argument")]#text(". Frobenius divisibility then exceeds the determinant’s Hadamard upper bound.")

#text("All the determinant steps and ordinary-prime estimates are proved in the note; the latter use factorials and binomial coefficients. The final contradiction reduces to the rational endpoint comparison 846/575 < 143/96, with monotonicity covering the entire range above 32,768. Checking the final argument requires no numerical parameter search. Standard quadratic ideal theory, finite fields, Hadamard’s inequality, and elementary analysis are the background inputs; no earlier version is needed, and no QRH or zero-free theorem is used.")

#text("The remaining range is handled by the ")#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/#comment-698460")[#text("small-prime residue sieve discussed by Pratt")]#text(": 4,095 candidate integers, tested using primes through 31, leave the usual nine discriminants. Two short Python programs check the rational constants, finite sieve, and reduced forms; all checks pass. The paper gives the detailed attributions where each idea is used.")

#text("The elementary companion has passed independent mathematical verification.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698547")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("This is very nice! It would be interesting to try to find a “simplest” proof that there is no tenth discriminant, where simplicity must account for the difficulty of verifying up to height q_0 and also showing q < q_0.")

#text("As a starting question, how large must q_0 be before it no longer seems “human checkable” to certify there is no tenth discriminant < q_0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698558")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Amusingly, the model formally verified some of the trivial numerical inequalities using rational arithmetic. E.g.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The elementary identity π/4 = arctan(1/2) + arctan(1/3), with three terms of each alternating series, verifies π < 16/5")
]

#text("Well, phew. I wasn’t sure about 3.2 as an upper-bound on π…")

#text("This kind of thing makes you wonder what its mental model is. I asked codex: “Does it surprise you that I find your formal verification of \\pi < 16/5 in the elementary version amusing?”")

#text("Codex:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Not at all. There’s something comic about a paper on the tenth discriminant pausing to establish, with due solemnity, that π is less than 3.2.")

#text("I took “elementary and self-contained” seriously enough that even π had to show its papers.")
]

#text("It’s a good joke. But the “I” that understands that it is amusing is not the same “I” that takes self-contained too seriously in the midst of a proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698526")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("The BYU math department recently obtained a team account for the SAIR open math model. I am reporting here the results of an experiment in using this SAIR open model on the tenth discriminant challenge.")

#text("I used Kimi K3 on Max effort, because two seconds of googling said Kimi is good at math. I told the model about the tenth discriminant challenge and gave it the papers of Green and van Dijk. I also gave it my comment above that contained some ideas about how the upper bound for ")#mi("q")#text(" could be brought down to the “low thousands.” I asked the model to read no other comments. I asked the model to take at most two hours, but it ended up taking three hours. However, it seems the model was offline for part of this time, and portions of the three hours may have been spent on computer calculations like sieving for primes rather than on model inference.")

#text("The chat with the model is ")#link("https://os.openmathmodel.org/app/#/chat/cs-2594996286fb30e63c83c61d10c7c86d")[#text("here")]#text(". Kimi generated files in its work that are not accessible in the chat, but which I used in checking its work.")

#text("Kimi claimed that one could take ")#mi("q < 54{,}000")#text(". I used ChatGPT 6.1 Sol to audit Kimi’s work. The determinant arguments seem okay, but there are issues with the numerics. ChatGPT suggests that, after making different choices for some parameters, using Hadamard’s inequality correctly, and using work of Rosser-Schoenfeld (1962) on explicit estimates for primes, Kimi’s argument can be repaired to give ")#mi("q < 160{,}000")#text(".")

#text("Clearly, the results are mixed. Kimi was able to do some nontrivial modifications of the van Dijk/Green arguments, using the papers and my comment as a guide. However, the global logic of its proposed proof didn’t quite hold together, and there were several numerical inaccuracies that undermined the argument. I’ve never used an open model before, and it seems likely I was asking too much of Kimi. Perhaps if I had broken the task into smaller pieces, it would have performed better.")

#text("I’d be interested to hear from others with experience in working with these open models about the best ways to use them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698538")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("As a rough rule of thumb, I would say that these open models are comparable to where the frontier models were 12 months ago in math capability, so their ability to one-shot complex tasks is still quite limited. (On the other hand, they require about 100 times less compute than leading frontier models.) As such, they should still be used in a fairly interactive fashion, breaking large tasks into smaller ones as you suggest.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698623")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I’ll run another experiment where I try chunking up the task, and I’ll report back.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/deed1fd8e99706bcbc7d130148e9fdd627caa1d998c5a206f18d0b9d988bdde9-a5ca883d0631a15edbc9579a56164c8c4b2839a647b545d2b9eb52a73cd64190.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Stopple")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698534")[#strong[#text("Jeffrey Stopple")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I’m confident in the writeup that the result holds for ")#mi("d/a^2\\gg1")#text(", but you might want to verify that the constant 200 suffices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698556")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("This comment was intended as a reply to twinheterodox above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698578")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Thanks. I just had codex verify that d/a² > 200 suffices. In fact d/a² ≥ 200 works, but that’s the best integer bound.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26045845f2398f9404199f4ab704f0dfd758b12a525c8cd45e1c501caeb80f1b-7949ef8c7f9f89d7856357b49c7c0e64ecd2a20e8b50cdddc710d05a469add9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace P. Nielsen")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698545")[#strong[#text("Pace P. Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I found this post very interesting because we have been working through Cox’s “Primes of the form x^2+py^2” book this semester, with our Computational Number Theory Group at BYU. After the announcement of 7/8 QRH, I tested whether it was possible to fully formalize the idoneal/convenient number result, including all auxiliary computations. My initial attempts met at disappointment.")

#text("However, after plugging comments from this thread in to Codex, it was able to fully prove (subject to the 7/8 claim, which I understand has also been formalized), using only the Lean kernel, that the list of 65 convenient numbers is complete. It took a route slightly different than the one mentioned by LemmaLab. Those interested are welcome to email me for the Lean code.")

#text("This in no way precludes further efforts to make such a proof human readable/verified (with minimal computation). It is merely a proof-of-concept that everything can be done in Lean, without auxiliary computations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698559")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("An amusing variant of the challenge (communicated to me by Ben Green): what is the earliest year N in which one could give a self-contained proof of Gauss’s conjecture that there is no tenth discriminant, using only results and concepts available in the literature up to year N? As one data point, there is the ")#link("https://www.ams.org/journals/bull/1933-39-05/S0002-9904-1933-05620-3/S0002-9904-1933-05620-3.pdf")[#text("1933 announcement of Lehmer")]#text(" (see page 360) using what I presume was a mechanical computer to sift out “100,000 discriminants a second” ruling out a tenth discriminant with ")#tao-math("\\left|D\\right| \\leq 5 \\times 10^9", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698584")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#link("https://github.com/twinheterodox/tenth-discriminant/releases/tag/historical-v0.1.0")[#text("1830 (Galois)")]

#text("(No claim that it’s the earliest)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0ff957cc3a07c7bcf007b031948591baa120075111033161781a507e9142ec-01884b2fd037b1ef9035ecf3ccbd17d1ace80fa06252dcb06df35f484605c646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698611")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I’m certainly entertained by the attempt but I think developing the first Mertens estimate (1874) from first principles in the paper is cheating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698614")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I agree. I was concerned about exactly that: deriving more modern tools while claiming they’re historical. But I did not specify that explicitly in the prompt, and I am not familiar enough with the math to spot that.")

#text("The main revision I did over earlier attempts was to get it to separate the historical from modern references and explain why the modern references weren’t importing modern tools.")

#text("I’ll specify the constraints more precisely and see how it goes. I do find it interesting that it refers to historical Latin and French sources as fluently as modern English.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698615")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Codex is quite contrite:")

#text("I think Ben’s objection is sound, and it exposes a flaw in my justification of the 1830 claim.")

#text("Our §3 proves")

#text("log p")#linebreak()#text("∑ ─────=log m+O(1),")#linebreak()#text("p≤ m p")

#text("with explicit constants. That is Mertens’s first estimate—the result Ben identifies with 1874. Writing its proof out using factorials and elementary calculus establishes that our argument is self-contained. It does not establish that this tool was available in 1830.")

#text("The general problem with my earlier criterion is that “derivable from old foundations” is far too permissive. Many later mathematical advances can ultimately be derived from much older foundations. Allowing those advances wholesale would largely empty the historical restriction of meaning. Our H/M citation distinction handles attribution, but cannot establish historical")#linebreak()#text("eligibility.")

#text("There must still be room for new deductions and combinations: the challenge asks us to assemble a proof that was not actually known then. A reasonable working distinction is:")

#text("• Combine historically available results, adapt them, and carry out routine estimates.")#linebreak()#text("• Count a substantial later theorem or method as a later ingredient, even when its proof is included.")

#text("The boundary requires judgment, especially for a new construction tailored to the problem. But reconstructing a recognizable, general-purpose prime-distribution theorem is a strong example of Ben’s objection.")

#text("I would therefore withdraw the claim that our current paper establishes 1830 as an answer to the challenge. We should preserve the published attempt and explicitly correct its historical claim. Merely changing the date to 1874 would be premature: the determinant construction and other substantive ingredients deserve the same scrutiny.")

#text("This objection does not identify a mathematical error in the proof. It changes what historical conclusion we can legitimately draw from it. I should have made that restriction operational before recommending publication.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a3549f28e89a9a803521a9f1bb0a77b13add721a92411149b11674c58dd42a-f6dc92a5b10806d7a84bd8d177a003231c8205c82abe27090b732a860f5f3d86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698625")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I think a reasonable upper bound is N <= 1891. (Bibliographical investigation and some drafting below assisted by ChatGPT.)")

#text("In his ")#link("https://www.sciencedirect.com/science/article/pii/0022314X69900237")[#text("1969 paper")]#text(" on the “gap” in Heegner’s 1952 proof, Stark says Weber could have solved the class-number-one problem 60 years earlier, if he had worked out the consequences of his results. Stark points to some minor issues with the work of Heegner, but says all the tools to address them are already in Weber. Stark cites the third volume Weber’s later ")#emph[#text("Lehrbuch der Algebra")]#text(" (appearing no later than 1908), but the relevant material already appears in Weber’s ")#emph[#link("https://archive.org/details/ellipfuncundalg00weberich")[#text("Elliptische Functionen und algebraische Zahlen")]]#text(" (1891), §§92–95, especially pp. 362 and 368.")

#text("A key Diophantine problem in Heegner’s work is to determine the integral solutions of")

#mi("y^2=2x(x^3-1)")#text(".")

#text("This can be resolved using elementary factorization and Euler’s eighteenth-century descent for ")#mi("Y^2=X^3+1")#text(". Euler’s work apparently appeared in print in 1747, but was done in 1738. (See the ")#link("https://scholarlycommons.pacific.edu/euler-works/98/")[#text("Euler Archive")]#text(", and Theorem 10 in the corresponding pdf files.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698649")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I reran Codex (Astra-6 max), instructing it that rederiving modern tools was cheating. It came up with two variants: 1874 using Mertens’s estimate and 1852 using Chebyshev’s. But both relied on the particular determinant construction, which we (Codex and I) concluded did not meet the revised historical criterion.")

#text("Codex had already started exploring a completion of Weber’s argument, so we picked it up again following ")#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-  using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698625")[#text("Kyle Pratt’s comment")]#text(". The resulting ")#link("https://github.com/twinheterodox/  tenth-discriminant/releases/download/historical-v0.1.0/historical-v0.1.0.pdf")[#text("write-up")]#text(" provides a detailed reconstruction supporting his proposed N ≤ 1891.")

#text("I can also upload the Mertens and Chebyshev variants if anyone is interested.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698650")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#link("https://github.com/twinheterodox/tenth-discriminant/releases/download/historical-v0.1.0/historical-v0.1.0.pdf")[#text("Corrected link.")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698561")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("On the higher class number problems you mention at the end of the post: assuming Kimura’s explicit bound for real zeros of Dirichlet L-functions (the second part of Theorem 1 of arXiv:2610.21511), a paper of mine determines all imaginary quadratic fields of class number at most 3000. There are 36,993,853 of them, and the largest |D| is 2,562,211,723, with class number 2976. Kimura’s bound follows from the real-zero case of the 7/8 quasi-RH, and also from the 31/32 half-plane for Dedekind zeta functions announced by Cureton and Thorner.")

#text("Under that 7/8 assumption, the class group tables of Mosunov and Jacobson (|D| below 2⁴⁰) would settle every class number up to 17,357, though I haven’t extracted that list.")

#text("The lists agree with those of Cremona and Sutherland (h ≤ 1000), zeta-lab (h ≤ 1500) and Kimura (h ≤ 2000), each under its own assumption, and with the counts of Garcia, Grenié, Lee and Molteni (h ≤ 2000).")

#text("Paper: ")#link("https://doi.org/10.5281/zenodo.23251443")[#text("https://doi.org/10.5281/zenodo.23251443")]#linebreak()#text("Code and data: ")#link("https://doi.org/10.5281/zenodo.23251366")[#text("https://doi.org/10.5281/zenodo.23251366")]

#text("AI disclosure: a multi-agent AI system of mine was used in the work, and Claude helped draft this comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57e5599b1104765a0be57216fa92c4279820ee3f57da4dd5d3e1f21c97bae4a8-9ee7773759a85f526498d32edc3ea08d3d86c38c9b9e47bcf3fe8819a62f50fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manvir Jaswal")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698571")[#strong[#text("Manvir Jaswal")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Forgot my name")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d1ca1cbc93d9f7f60f3df997f5e771e179b3a46c97a46ca992ed92f27916c2f-a287b9e3d5eb85b918cb29007bbe721aefbeccc0cbcc46df9aa871fd42718210.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter W Murphy, MD")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698572")[#strong[#text("Peter W Murphy, MD")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Hello,")

#text("I am pleased to submit an entry into this challenge. Below, we describe")

#strong[#text("A kernel-checked, Heegner-free Lean proof of class number one, via the 7/8 quasi-RH (and ")#mi("d \\le 652")#text(" in Lean)")]

#emph[#text("Abstract.")]#text(" We give a complete Lean 4 proof of the class number one theorem for imaginary quadratic fields: for squarefree ")#mi("m")#text(", the field ")#mi("\\mathbb{Q}(\\sqrt{-m})")#text(" has class number one if and only if ")#mi("m \\in {1,2,3,7,11,19,43,67,163}")#text(". The proof uses no Heegner, Baker, Stark or Gross–Zagier input. It follows the route worked out in this thread: OpenAI’s zero-free region ")#mi("\\mathrm{Re}, s > 7/8")#text(" for Dirichlet ")#mi("L")#text("-functions, the Chowla–Selberg formula evaluated at ")#mi("s = 7/8")#text(", and a split-prime criterion for the finite range. Every step is proved in Lean. That includes the explicit bound ")#mi("d \\le 652")#text(", proved about Mathlib’s own ")#raw("riemannZeta")#text(" and ")#raw("Gamma")#text(". The proof of OpenAI’s theorem is inside the checked dependency closure. Comparator accepts the result under two independent kernels (Lean’s and nanoda) with only the three standard axioms, and it rejects deliberately tampered statements. The repository is ")#link("https://github.com/DrMurphyIsIn/tenth-discriminant")[#text("https://github.com/DrMurphyIsIn/tenth-discriminant")]#text(".")

#strong[#text("The argument.")]#text(" Write ")#mi("K = \\mathbb{Q}(\\sqrt{-m})")#text(", ")#tao-math("d = \\left|\\mathrm{disc}, K\\right|", block: false)#text(" and ")#mi("\\chi")#text(" for its character. Suppose ")#mi("h(K) = 1")#text(" and ")#mi("m \\ne 1, 3")#text(".")

#enum(start: 1, 
[#text("Every ideal is principal and the units are ")#mi("\\pm 1")#text(", so ")#mi("\\zeta_K(s) = \\tfrac12 \\sum_{(x,y) \\ne 0} Q(x,y)^{-s}")#text(" for the principal form ")#mi("Q")#text(", and ")#mi("\\zeta_K = \\zeta \\cdot L(\\cdot, \\chi)")#text(".")],
[#text("Chowla–Selberg (the expansion in michaelmross’s comment) continues this past ")#mi("\\mathrm{Re}, s = 1")#text(". At ")#mi("s = 7/8")#text(" the main part is ")#mi("M(d) = \\zeta(7/4) + 2^{3/4}\\sqrt{\\pi},\\frac{\\Gamma(3/8)}{\\Gamma(7/8)}, d^{-3/8}, \\zeta(3/4)")#text(", plus a ")#mi("K")#text("-Bessel remainder of size about ")#mi("e^{-\\pi\\sqrt {d}}")#text(". We prove the remainder bound in Lean.")],
[#text("Since ")#mi("\\zeta(3/4) < 0")#text(", ")#mi("M")#text(" increases with ")#mi("d")#text(". Its zero is ")#mi("d^* = 653.98763\\ldots")#text(", the evaluation LemmaLab gave above. We prove in Lean that the main part minus the remainder bound is positive at ")#mi("d = 655")#text(", and hence for every larger ")#mi("d")#text(".")],
[#mi("\\zeta(7/8) < 0")#text(", so for those ")#mi("d")#text(" we get ")#mi("L(7/8, \\chi) < 0")#text(". But ")#mi("L(\\sigma,\\chi) > 0")#text(" for ")#mi("\\sigma > 1")#text(", and by the 7/8 theorem ")#mi("L")#text(" has no zero on ")#mi("(7/8, 1]")#text(". Continuity gives ")#mi("L(7/8,\\chi) \\ge 0")#text(", a contradiction. So ")#mi("d \\le 652")#text(", since the admissible ")#mi("d")#text(" are ")#mi("\\equiv 0, 3 \\pmod 4")#text(".")],
[#text("The finite range: for each of the 190 squarefree non-Heegner ")#mi("m")#text(" with ")#mi("d \\le 652")#text(", the kernel checks a split prime ")#mi("p < (d+1)/4")#text(", the largest being ")#mi("p = 31")#text(". Such a ")#mi("p")#text(" would have to be a value of the principal form, which is impossible. The criterion must use split primes, not merely small ones: ")#mi("d = 8")#text(" has the ramified prime 2 below the bound and class number one.")],
[#text("The nine fields have class number one; that direction is also proved in Lean.")]
)

#strong[#text("What exactly is checked.")]#text(" The statement is one screen of Lean using only Mathlib definitions (")#raw("NumberField.classNumber")#text(", ")#raw("Module.finrank")#text(", ")#raw("Squarefree")#text("). That is so a reader can check what is claimed without reading our code. The checks:")

#list(
[#text("Comparator, with both kernels on, accepts the proof with only ")#raw("propext")#text(", ")#raw("Quot.sound")#text(" and ")#raw("Classical.choice")#text(", and no ")#raw("sorry")#text(" or ")#raw("native_decide")#text(".")],
[#text("Two tampered statements are rejected as not matching: one with ")#raw("Squarefree m")#text(" dropped (")#mi("m = 4")#text(" would be a counterexample), one with 163 replaced by 167.")],
[#text("A dependency audit of the 129,170 constants in the closure finds no class-number-one input. Outside Mathlib and Lean core, everything is either OpenAI’s L-function development, two analysis packages it imports (PrimeNumberTheoremAnd and RellichKondrachov, with OpenAI’s published patches), or ours.")]
)

#text("On LemmaLab’s question about the two ")#raw("sorry")#text(" in PNT+’s Wiener.lean: at the commit openai/math pins, OpenAI’s published patch removes them, and Comparator’s axiom check confirms ")#raw("sorryAx")#text(" is not in our closure.")

#text("So the trust base is the statement and the Mathlib definitions it uses, the two kernels, and the three axioms. OpenAI’s manuscript is unrefereed, but its Lean proof is checked here, not assumed.")

#strong[#text("How it was built, and why we think it matters.")]#text(" The work was done with Telperion, a certificate engine we have been developing. Telperion takes any certifiable family of statements and emits code in Lean 4 which is then checked by Mathlib’s kernel. The repertoire of certifiable shapes now encompass a large swath of concrete mathematics. The core premise of Telperion is simple: treat everything a language model produces (numbers, enclosures, witness primes, proof drafts) as untrusted input, and emit Lean that only the kernel can accept or reject. A hallucinated inequality does not become a theorem; it fails to check resulting in a compile error never a false or vacuous statement in lean.")

#strong[#text("AI disclosure.")]#text(" The formalization, the numerics and the write-up were produced with extensive use of Anthropic’s Claude, across separate sessions: one does the work and another, independent session reviews it and replays the checks. The mathematical route is due to the contributors to this thread and the classical sources credited in the repository README.")

#text("Sincerely,")

#text("Peter")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d1ca1cbc93d9f7f60f3df997f5e771e179b3a46c97a46ca992ed92f27916c2f-a287b9e3d5eb85b918cb29007bbe721aefbeccc0cbcc46df9aa871fd42718210.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter W Murphy, MD")]], [#link("https://terrytao.wordpress.com/2026/10/20/an-experimental-ai-math-challenge-using-tenth-discriminant-bounds-to-explore-arguments-ruling-out-siegel-zeroes/comment-page-1/#comment-698576")[#strong[#text("Peter W Murphy, MD")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Here is the full paper describing our proof:")

#link("https://github.com/DrMurphyIsIn/tenth-discriminant/blob/main/paper/paper.pdf")[#text("https://github.com/DrMurphyIsIn/tenth-discriminant/blob/main/paper/paper.pdf")]

#text("Sincerely, Peter")
]
]
