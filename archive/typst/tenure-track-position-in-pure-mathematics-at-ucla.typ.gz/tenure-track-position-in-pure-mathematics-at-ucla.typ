// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/
// Converted to Typst by tao2typ: "2026-11-24T17:59:55.897221+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Tenure-track position in pure and applied mathematics at UCLA", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Tenure-track position in pure and applied mathematics at UCLA")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/")[#text("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-24 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The Department of Mathematics at the University of California, Los Angeles, ")#link("https://recruit.apo.ucla.edu/JPF11458")[#text("invites applications")]#text(" for a tenure-track faculty position as an Assistant Professor in mathematics. A competitive candidate should have a transformative research program and show excellence in undergraduate teaching and educational innovation. We give preference to applicants in areas of pure and applied mathematics. Applicants from all fields of pure and applied mathematics will be considered. Candidates must have a Ph.D (or equivalent degree) in hand by June 2027. (The exact number of positions is to be determined, but is at least one.)")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-699882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("I am an undergraduate student and I don’t want to become a mathematician. I want to know one thing… The distinction between pure and applied math is very strange to me. Could please someone explain it in a few words? For example, is the Pythagorean theorem pure or applied math (or maybe simply mathematics)? Is there “impure” or “contaminated” math? If someone finds application someday for some obscure theorem of Grothendieck, it becomes applied? or, maybe, “hybrid”? I don’t know much, but to me, math is math and applications of math are applications of math, it’s very strange to say a theorem belongs to one or another, even a problem. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-699914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("A famous mathematician once said, and quoted by another famous mathematician, “There is no applied math, only applications of math.” You’re in excellent company.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-699968")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("It’s in the motivation, not the math itself.")

#text("Applied math is motivated by applications. Pure math is motivated by math.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea7fe065205b2120c9d4f46ba71cb03d44ff60922c92b237f6039150e65e7acf-a893e0f35ad6c4f03399068bdd6e044fc7c7a539813fbc0785a9af3bfcc65d44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-699928")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2026")])]

#text("To make the definition time-invariant, we can’t use whether application exists as the determinant, because like you said we can find applications later. Instead, we should use whether the math question is motivated by other fields (physics, engineering, computation, economics, and biology). Using this definition, we’d say:")#linebreak()#text("Riemann, BSD = pure math, N-S, PvsNP, Y-M = applied math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-699991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("A lot of number theory today is motivated by practical application in places like cryptography and computer science. It’s why one of the consequences of the Riemann hypothesis is that a whole bunch of algorithms become polynomial time like the deterministic Miller over the probabilistic Rabin-Miller. So Riemann today should be categorized as applied mathematics by your standards.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14ac0ae7fd696758a9c386bf25d6f755a15b3ba9f6e91e2bad88627dc33b5220-0d542ae24deb3e921bbaf2dcafc24588f536c35e46e558dd7e594c07af00a649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-699985")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2026")])]

#text("Pure mathematics is a formal science: ")#link("https://en.wikipedia.org/wiki/Formal_science")[#text("https://en.wikipedia.org/wiki/Formal_science")]

#text("Applied mathematics is sometimes only a formal science, but with _concrete_ motivation from and typically something to say about an application. Very often, applied mathematics is _both_ a formal science and a natural science, such as in much of physical applied mathematics (e.g., the British applied-math tradition in fluid dynamics).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/11/22/tenure-track-position-in-pure-mathematics-at-ucla/#comment-700037")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Grothendieck’s 1972 talk at cern has aged remarkably, it’s almost as if he was addressing our community now and not 54 years ago")

#link("https://github.com/Lapin0t/grothendieck-cern")[#text("https://github.com/Lapin0t/grothendieck-cern")]
]
