// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/19/powells-endorsement/
// Converted to Typst by tao2typ: "2026-10-14T15:16:54.132439+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Powell’s endorsement", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Powell’s endorsement")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/")[#text("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The level and quality of discourse in this U.S. presidential campaign has not been particularly high, especially in recent weeks. So I found former Gen. Powell’s recent analysis of the current state of affairs, as part of his widely publicised endorsement of Sen. Obama, to be a welcome and refreshing improvement in this regard:")

#text("It’s a shame that much of the rhetoric and commentary surrounding this campaign – from all sides – was not more like this. [In keeping with this, I would like to remind commenters to keep the discussion constructive, polite, and on-topic.]")

#text("[")#emph[#text("Update")]#text(", Oct 22: Unfortunately, some of the more recent comments have not been as constructive, polite, and on-topic as I would have hoped. I am therefore closing this post to further comments, though anyone who wishes to discuss these issues on their own blog is welcome to leave a pingback to this post here.]")

#heading(level: 1)[#text("Comments (71)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33196")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I appreciate what Colin Powell, Terry Tao, John Sidles, and Todd Trimble have said.")

#text("I also strongly endorse Cardster’s: “Anyone academically inclined who loves intellectual discourse should support Obama; the ‘dumbing down’ of education over the last 28 or so years is obvious. We who love mathematics must make our voices heard by supporting those who love intellectual rigor in public policy.”")

#text("My father and his father were extremely political Wall Street Conservative Republicans. Yet my father refused to vote for George W. Bush. Colin Powell is right: his party has discredited its own axioms.")

#text("As someone who has been quite politically involved himself, an elected Town Councilman in communities in two states, and who wrote speeches for a presidential candidate, I agree that academics are humans, too. I take especially seriously the ‘dumbing down’ of education, as someone who has taught on and off since 1973 in middle schools, high schools, college, and university. Until you are on the front lines of the battle against ignorance, you have no idea how horrendously anti-intellectual much of America is (or has become, the derivative is hard to evaluate).")

#text("Did Nancy Reagan’s astrologer — the one she consulted to schedule international trips for Ronald — warn her about falling and breaking her pelvis? Can someone really see Russia from Wasilla, Alaska? Why did more Mathematicians not object to George W. Bush’s usage of “fuzzy math” for plain arithmetic? Has there ever been a more anti-science administration than the one collapsing right now, shockingly in the face of Thomas Jefferson, Herbert Hoover, and Jimmy Carter (who used Laplace transforms)?")

#text("My wife was a volunteer poll worker in Australia when she was doing her post-doc at UNSW. I suspect that Terry Tao has the deeply democratic egalitarian decency characteristic of Australia, PLUS the best of America (whose best education is paradoxically unsurpassed globally, though the mean and median USA education has become 3rd World).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33197")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("John Sidles: I appreciate the references very much. Even if you say some of the thinkers/architects involved have been carefully apolitical up until now, political observers would probably do well to pay heed. Thanks again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Ben, go and put your propaganda in your own blog instead of polluting Terry’s blog with your ridiculous comments. You definitely have the right to disagree with Terry’s political views; but you should remember that he writes whatever he wants in his blog. Therefore, reporting your disappointment is simply foolish!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33203")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Question to the first poster and everybody else: is “right between the eyes” an allusion to Night of the Living Dead, or were you and George A. Romero quoting a common source?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33204")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Wal-")

#text("Thank you for your clarification (20 October 2:45pm) regarding your comments 20 October 11:26am. It relieves me that you do not view Germany as a place where people with extreme views concerning “demographic transformation” ought to move.")

#text("(Note that I was not the only one with this mistaken impression of what you intended: see anonymous 4:14pm. Perhaps a bit more precision regarding language was in order.)")

#text("While I agree with your sentiment that bigoted opinions should be confronted, I am not convinced that “Taking offense is a sign of a closed mind.” Rather, I consider refusing to participate in dialogue to be a sign of a closed mind. If one finds certain remarks offensive, this should be noted in order to resolve, or at least clarify, the issue at hand. Too often I find that potentially-useful political dialogue is cut off as soon as someone is offended.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33206")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("No offense but whenever great minds “mature” they find much comfort in politics and/or political affairs.")

#text("Dr Tao is certainly keen to see what and how people react regarding this post; while it is certainly healthy to have an interest and an opinion in current world affairs it somewhat dilutes the atmosphere of this otherwise very interesting mathematics blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33210")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("According to GallUp WorldPoll, the world (70 countries, to be precise) certainly prefers ")#link("http://www.gallup.com/poll/111253/World-Citizens-Prefer-Obama-McCain-Nearly-4to1.aspx")[#text("Obama to McCain by nearly 4-to-1. ")]

#text("I am pretty sure that McCain’s campaign, if given a chance, would use the above poll numbers to argue that the whole world is conspiring against America (since they support Obama) and hence Obama should not be elected president!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7ade609df7d789d794604da195b15ec9eb956bbf62a92f4223cdf11f9229930-2d6a3ac62ef9daabf090f4f5c0e60e22a081fe2ad754add39664a57a9fdbda09.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of びっくり")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33212")[#strong[#text("びっくり")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("It is a shame that Powell isn’t running.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0104a39c8899d222b2bbc57859b2386a900992da4cc938e4b647724423f85ff-5065b977e4b432e2b42e11f47f3d52df2324adde2ada6b2b39090c7b5b4cd87a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Bacon")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33214")[#strong[#text("Michael Bacon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("Terry,")

#text("This is what happens when you jump into the political fray. While I agree completely with the sentiments you expressed, I’m sorry that you’re skewered by some for merely requesting a bit of civility in political discourse. Anyway, like someone above said, it’s your blog and you can say what you want :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33215")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("An interesting post. I enjoy it very much.")#linebreak()#text(" I would offer my encouragements rather than discouragments.")#linebreak()#text(" Great job!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03b53a002eea833fe3472c4249f3b5f5fe08b31e2a32a961b7294fc4e831c377-b326c9673cc1de08eb12fdd55c49d2fc684037fd414cfe1acd646519d4967645.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hany")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33218")[#strong[#text("Hany")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("Roger says: “You are joking, right? Those guys never did anything worthwhile again after polluting their minds with politics. Please don’t encourage Terry to go down that path”.")#linebreak()#text(" What about Laurent Schwartz (who was politically engaged all his life and mathematically productive for a good part of it)?")#linebreak()#text(" I agree that it’s easier for a mathematician to work in isolation from struggles; political or other, but sometimes this is just impossible.")#linebreak()#text(" Concerning the subject matter of Prof. Tao’s post, I do not agree that the level of discussion in the campaign was particularly low compared to US standards. Actually I always feel that US political discourse has ALWAYS been very poor and that most political figures are keen on looking more stupid and more vulgar than they actually are.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed917a937215e80fd74b61dd2b67344d38be49715c7be6d0ee86e1df3f6f44dc-d285ee37e016ebe971aefb8a605f92a7ceb6faac86159005b2623af07051a044.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Big Eclipse")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33221")[#strong[#text("Big Eclipse")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("No matter what side you are for, you have to admit that when McCain announced that Palin was his choice for a running mate, it took the winds out of the sails for that party. It was inevitable, following the initial excitement, that it was going to be seen for what it is — a poor choice; both in strategy and judgement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thuris")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33222")[#strong[#text("Thuris")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("Powell gives a measured and reasoned explanation of how he came to a conclusion. His style of speech is considered, his weighing of factors is humane. He speaks about the importance of intellectual curiosity. His discussion of the Muslim American serviceman provides a counterexample to some assumptions of the uninformed. I believe that reasons such as these are why Prof. Tao chose to post this video.")

#text("Is there any doubt that we need to move towards our better selves? The power that mathematics will give us in the coming decades (through AI, pattern recognition, biocomputation and so on) will project changes in our moral character or habits of thought onto the world around us with ever more force and immediacy. More and more vividly we will see thoughts made material, so it would be helpful to have some presentable thoughts scattered here and there among the appetitive and territorial ones.")

#text("I am not voting for either of the two candidates mentioned in the interview, so I do not have a stake in Powell’s endorsement. But I think we all stand to benefit from hearing examples of responsible speech, and I thank Prof. Tao for sharing something that speaks to his person ideals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A C")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33224")[#strong[#text("A C")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("From a foreign policy point of view,I don’t think either candidate is going to be bad for America, they share a lot of common positions.")#linebreak()#text(" 1. Both candidates are strongly committed to the defense of Israel, which is excellent.")#linebreak()#text(" 2. Both candidates are equally committed in ensuring a Iran does not obtain WMDs.")#linebreak()#text(" 3. Barack is clearly not a pacifist, his foreign policy views have been shaped by Zbigniew Brzezinski, and irrespective of the election results we are going to see an US administration which is not hesitant to defend US interests vigorously anywhere in the world.")#linebreak()#text(" 4. Both candidates understand the threat emanating from states like Pakistan, and both of them will do their best to ensure a victory in Afghanistan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4d7ad465e7a4815be9bac585761f3342c6f83aabc679f7215eae882d0e0a7b2-b160a51fb585119b340da0e206c8176792be9c300467aec5c7d3f785b08aa1a6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of One year old « The Accidental Mathematician")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33226")[#strong[#text("One year old « The Accidental Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("[…] I write this, I’m thinking of the discussion on Terry Tao’s blog provoked by a recent very mild post about politics. I’m not going to comment on Terry’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336e8a57337ea1071a8f94ee875dac3a6e7e482e0b7547623f349678744ba1d4-10b839183bdd939ad7627d1990e0ce5221a544b077c5acd99f9904757c6a5f29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33229")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("We have two despicable characters running for president who recently pledged their allegiance to the State of Israel at a AIPAC conference in NYC. Both McCain and Barack Obama pledged their allegiance to a nation that attacked a US naval ship-USS Liberty- in neutral waters that resulted in the death of over forty American teenagers-all non-Jewish of course.")

#text("If the US phantom fighting jets had got their in time, they would have blown the Israel aircraft out of the air. The US special relationship with Isarel would ave ended in 1967.")

#text("Israel has 200-400 nuclear weapons. Iran has none. However, if Iran had a few nuclear weapons the probability of an attack by the US on behalf of the state of Israel woud be very close to 0.")

#text("Have a look at Vincent Bugliosi’s new book where he makes a very tight legal that George W Bush should beindicted for mass murder. Colin Powell was the point man for the Bush adminstration at the UN. He was the one who told all the big lies of the Bush adminstration before the whole world.")

#text("Sarah Palin is an Evangelical Christian Zionist who blieves in the rapture. She has a flag of Israel in her office and wears a little Israel flag on her lapel. American politicians should give allegiance to America not to the State of Israel.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33230")[#strong[#text("The Unitarian Jihad « The Unapologetic Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")]

#text("[…] Unitarian Jihad I ran into this manifesto somewhere, and it reminded me of Terry Tao’s call for reasoned discussion, as well as Susan’s atheism post. Greetings to the Imprisoned Citizens of the United States. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Davy N.")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33231")[#strong[#text("Davy N.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("“…to a nation that attacked a US naval ship-USS Liberty-”")

#text("This occurred 41 years ago, and was caused most probably by a tragic mistake. So this is completely irrelevant to the current situation.")#linebreak()#text(" Do you support also cutting off ties with Japan, Germany and Italy as well, they also attacked Americans in the past (and not by mistake)?")

#text("From Wikipedia:")#linebreak()#text(" Both the Israeli and American governments conducted inquiries into the incident, and issued reports concluding that the attack was a tragic mistake, caused by confusion about the identity of the USS Liberty. On December 17, 1987, the issue was officially closed by the two governments through an exchange of diplomatic notes. Israel eventually paid nearly US$13 million in humanitarian reparations to the United States and in compensation to the families of the victims.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336e8a57337ea1071a8f94ee875dac3a6e7e482e0b7547623f349678744ba1d4-10b839183bdd939ad7627d1990e0ce5221a544b077c5acd99f9904757c6a5f29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33232")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("Davy N")

#text("The Israeli attack on the US liberty was a premeditated and deliberate attack on the USS Liberty. The suriviors of the USS liberty have set up their own web site refuting the lies of the Israeli goverment. Statements by both goverments don’t count for anything. In other words, what the Israeli’s did was premeditated murder. If any other nation had done this, they would have been attacked and invaded by the US. Can you imagine what would hae happned if China or Russianhad atacked the US liberty. It would have beeen seen as a declaration of war by the US and you and I wouldn’t be having this conversation right now.")

#text("In late 2008, If Iran attacked a US naval ship killing dozens of sailors-you can take this to the bank-the US would nuke Iran.")

#text("How far do you want to go with the WW11 analogy? The US would have been jusitifed in going to war with Israel back in 1967. If the Navy phantom jets had just gotten to the USS Liberty a few minutes earlier, they would have blown the Israeli attack helicopters and fighter jets-all paid for by the US tax payer, how ironic-and who knows what would have happened. One thing you can be sure of, the special relatinship with Israel would have ended. This would have taken the steam out the Evangelical Christian Zionist movement whose memebers include wierdos such as Sarah Palin.")

#text("A Barack Obama foriegn policy will include a lot of “humanaitarian” interventions. Clinton commited his very serious war crimes in Serbia. Humanitarian intervention was the excuse. There were several of these “humanitarian” interventions under Clinton. I should point out that Clintons invasion of the Balkans had the very real potetnial to start WW3. Thank God both the Chinese and Russians used restraint.")

#text("The Barack Obama worshipping I see going on is quite sickening. He is being made into a Christ-Like figure. His worshippers will cut him enormous slack to pursue an agressive criminal foreign policy.")

#text("In reality, Barack Obama is a man who lusts for power. This is recognized as one of the worst traits in a human being.")

#text("On the home front, Barack Obama will scale up the hated H1-B and L-1 B scab labor programs. He will also accelerate the ongoing Mexican invasion of America.")

#text("Barck Obama is nothing but the front man for several rackets which include:the State of Israel, the military industrial complex,Wall Street and corporations in general.")

#text("Colin Powell would be the perfect Secretary of State for Barack Obama.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous2")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33233")[#strong[#text("Anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")])]

#text("> Mrs.[!] Raoul Berger")

#text("Dear Anonymous,")

#text("Sorry for the OT squared, but since you seem to be surprised that a woman bears a male first name, let me give you an explanation.")

#text("Actually, it was quite customary in some countries for married women to adopt not only their husband’s family name, but also his first name. So when Miss Jeanne Dupont married Mr. Pierre Lefèbvre, today’s habit would be to call her Mrs. Jeanne Lefèbvre (née Dupont) (*), but in the past it would not have been uncommon to call her Mrs. Pierre Lefèbvre (née Jeanne Dupont).")

#text("So if you find it strange that a woman bears a male first name, it may be simply because it’s not *her* first name at all!")

#text("(*) Of course, in some countries, many married women now go one step further and keep her own (so-called “maiden”) name altogether (a welcome development in my view).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-2/#comment-33240")[#strong[#text("Two Math Riddles « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2008")]

#text("[…] math riddles here. But these days, when mathematical blogs break new ground and enter uncharted territories, let me make an exception and tell you two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33125")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2008")])]

#text("Thanks for posting this video. I had only heard a few sound bites on the news, and I found his entire presentation impressive in thoughtfulness and intelligence. He was too smart and morale for the Bush administration, and for that they desperately wanted to dump him.")

#text("Yesterday I got a mailing from the Republican party. Why, I don’t know, because I don’t belong. On the front it has a close-up picture of a man’s face with dark skin and showing mostly only the eyes. Printed over the picture is text that reads “America must look evil in the eye and never flinch”. So, who is that person in the picture? An arab terrorist? Obama? It’s impossible to tell from the picture, so subliminal message #1 was that they are one and the same. Subliminal message #2: “right between the eyes.” I was absolutely horrified by this inflammatory and dangerous junk.")

#text("Right in the middle of serious crises like we haven’t seen in a long time, we have Palin sowing her own inflammatory and dangerous divisiveness. If you follow her messages over time, it’s clear that to her, Joe Six Packs (read: white working class males) are the real Americans, and everyone else — especially intellectuals — are not. She seems to consciously incite violent expression at her rallies. Her husband belonged to the Alaskan Independence Party (AIP) which hated this country, had ties with militias, and a previous leader who was killed attempting to buy plastic explosives. In my opinion, these two people have hidden motives and are dangerous.")

#text("And, I might add, the general disdain by McCain and Palin of the intellect and rational thought would do nothing but hasten the decline of interest in mathematics and science in this country, which has been primarily a cultural problem. We’ve already had eight years of Bush who snidely dismissed Kerry’s “fuzzy math” during a debate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33126")[#strong[#text("Roger")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2008")])]

#text("Powell mostly endorsed Obama mostly for reasons of style and symbolism, not policy. Powell’s chief expertise is in military and foreign policy. It would have been better if he had compared the candidates in those areas where he is an expert.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33127")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("There is a serious and urgent need for the US to overhaul its foreign policy. If John McCain is elected president, it is almost impossible to imagine how his policies can engage the rest of the world in a constructive manner to come up with ")#emph[#text("long-term")]#text(" and ")#emph[#text("peaceful")]#text(" solutions to “conflicts” (which I use in the most general sense) around the world. One certainly does not expect Obama, if he is elected president, to “transform” the landscape, but at least his administration can blunt the neo-conservative rhetoric (that one abundantly hears) surrounding present-day US foreign policy. Actually, to Bush’s credit, North Korea is no longer a part of the ‘Axis of Evil’ (phew!) and Iraq had long ago ceased to exist as a member of the same Axis! Hopefully, we will get to see a lot more constructive diplomacy being initiated over the nuclear issue with Iran.")

#text("By the way, via ")#link("http://feministphilosophers.wordpress.com/2008/10/15/counting-the-candidates-words/")[#text("Feminist Philosophers")]#text(", I found this interesting ")#link("http://wordwatchers.wordpress.com/2008/10/15/debate-3-mccain-and-obama-word-usage/")[#text("blog post")]#text(" that dissects the language patterns produced by McCain and Obama in the recent third debate. The conclusions noted in the second paragraph is particularly interesting:")

#emph[#text("As discussed in a previous blog, we have also found evidence to suggest that McCain and Obama have different thinking styles. Whereas McCain tends to be more categorical in his thinking, Obama is more fluid or contextual in the ways he approaches problems. Categorical thinking involves the use of concrete nouns and their associated articles (a, an, the) and suggests that the person is approaching a problem by breaking it down into its component parts and attempting to put it in meaningful categories. Fluid or contextual thinking involves a higher rate of verbs and associated parts of speech (such as gerunds and adverbs).")]

#text("My understanding is that McCain tends to think in black and white, whereas Obama, among other things, is much more nuanced in his approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33129")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("First, I’m disappointed that T. Tao has decided to break his good habit not to deal with political/personal/social issues outside the world of mathematics in his (very nice) blog.")

#text("That said, I must note that I agree with comment #2, while I completely disagree with commenter #1.")

#text("It is also quite frustrating to see that foreign affair issues of capital importance are being disregarded, rather haphazardly, by many of Obama’s supporter. Obama’s views regarding world terrorism, Mideast and the Russian crisis are, politely put, embarrassingly naive. For instance, his “program” for solving radical Islamic oriented terrorism is by “sitting and discussing with everyone”. He even supports “having talks” with Ahmadinejad (president of Iran).")#linebreak()#text(" The problem is that “talking with everyone” sounds nice. But to claim this is the program itself (!) shows plain ignorance of the subject matters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33130")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Vishal: “Hopefully, we will get to see a lot more constructive diplomacy being initiated over the nuclear issue with Iran.”")

#text("If you really think that diplomacy alone can “solve the nuclear issue with Iran”, you apparently lack the very basic understanding (in fact knowledge) of current Iran’s strategy and ideology.")#linebreak()#text(" They are not going to pull off their nuclear plan without a violent struggle; and if they’ll do achieve nuclear capabilities they will most probably use it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1204e4e9425fce3c2ccf696c7c53200646effcc47b1fdbaca361e131b3ab07b-36d0a495293de026dd19d188adf902783f235bafed15815347c24d5e0750ed83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Struwwelpeter")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33131")[#strong[#text("Struwwelpeter")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Dear Terence,")#linebreak()#text(" despite my admiration for your mathematics")#linebreak()#text(" I am disappointed that you should stoop to those political comments.")#linebreak()#text(" Some, like you, may find Mr.Powell’s comments “welcome” and “refreshing” others may consider him a traitor to his party and evoke the metaphor of rats leaving a sinking ship.")#linebreak()#text(" Since this is a blog read essentially by academics, I am certain that the former will be in a colossal majority among your readers but,")#linebreak()#text(" paradoxically, this will not be a cause for celebration to the perfect gentleman that you are (key words: underdog, not kicking fallen enemies, following packs).")

#text("I am perfectly aware that this is your blog and that you are entitled to your political views, but I find that reading the news is rather depressing, so every day I turn to your blog for a breath of oxygen and, selfishly, would like not to be reminded of what I have just left on Google News.")

#text("Although it is logically irrelevant, I’d like to state that I am not a Republican, have no preference between Obama and Mc Cain and will not vote in the next election.")

#text("Looking forward to reading more of your wonderful mathematical surveys, insights, comments,…")#linebreak()#text(" Struwwelpeter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33132")[#strong[#text("tomate :: :: October :: 2008")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")]

#text("[…] campagna presidenziale americana, inducendo ad un inaspettato sbilanciamento perfino Terence Tao [qui], giovanissimo matematico vincitore della medaglia Fields, una delle menti più brillanti al […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9527221cf63bd4a5ac1f0e76087c731571e5acbde5ea461aa6d3471ce0f082bf-b9942300c0dfbea1968210e9c7f2791a4549089efbe07d6ae798d63b07ee5fc8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vishal Lama")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33133")[#strong[#text("Vishal Lama")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#emph[#text("If you really think that diplomacy ")#strong[#text("alone")]#text(" [emphasis mine] can “solve the nuclear issue with Iran”, you apparently lack the very basic understanding (in fact knowledge) of current Iran’s strategy and ideology.")]

#text("Ben:")

#text("I never used the word “")#emph[#text("alone")]#text("“; I used the phrase “")#emph[#text("more constructive diplomacy")]#text("“, which is something that the Bush administration (with perhaps some cue from Obama) is now finally engaged in, if you have been following the news closely. Hmmm… also, I wonder how North Korea managed to get off the US terror list under Bush Jr’s watch!")

#text("In regard to “Iran’s strategy and ideology” which you brought up, maybe it would be good to remember that there is only one country, so far, that has ")#emph[#text("actually used")]#text(" a couple of nuclear bombs in the twentieth century against its enemy. The reason for doing so may not have been ideological, or in fact, it may have been entirely benign in some twisted way but that’s beside the point. Given such a history, I am not very surprised at your apparent paranoia about Iran using a nuclear bomb against its adversary.")

#text("And, thanks for pointing out my lack of basic understanding of geopolitical affairs!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33137")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Interesting.")#linebreak()#text(" Another first choice mathematician who could not refrain from getting involved in politics.")#linebreak()#text(" It’s sad to dilute this blog with political statements of any kind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c619a24c5ca3846879239c84019efb2bcd9f63ee8b44e796cc91c569c893cd6c-cd6cbad0650eab0ee92775904bc904747b06949486252679b46f3fe9131bd3c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cardster")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33138")[#strong[#text("Cardster")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("A great post. Anyone academicallyinclined who loves intellectual discourse should support Obama; the “dumbing down” of education over the last 28 or so years is obvious. We who love mathematics must make our voices heard by supporting those who love intellectual rigor in public policy. The “trickle down economics theory” is a sham that has robbed most of a generation the ability to engage in intellectual discussion that challenges ideas rather that indulges in calumnies and slander of those who have a different views.")

#text("As an Australian who has has a 45 year interest in US Presidential history (thanks to a good teacher) who is interested in mathematics I congratulate my fellow Australian on a post from the heart.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f00881f3f89fe20b302d50108dc9d3ee550cd96d498b279ad76c1a0c04871a7-f397ac711ae58a2b7884e3a800b6004630a56a8b3151b71c39a4f3b45c545793.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wal")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33139")[#strong[#text("Wal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Why shouldn’t a mathematician take a political position? Some of the most distinguished mathematicians have taken political positions: Albert Einstein, Bertrand Russell, Alexander Grothendieck to name three twentieth century examples.")

#text("In fact there is a good case that distinguished intellectuals, in positions of privilege, who are protected by tenure and free to make virtually any statement they please without consequences for their family or employement have a duty to speak out on behalf of others without the same social protections. This is true particularly at the moment, after eight years of the most radical US administration in history which has destroyed the western economy, enriched a narrow elite, done nothing about the environmental catastrophe, is regularly murdering innocent Iraqis, Afghans, Pakistanis and Somalis and has provoked quite unnecessary and extremely dangerous confrontations with Iran and Russia.")

#text("I enjoy Terry’s maths posts but I’m also interested to read what distinguished mathematicians think about politics. Politics is not as amenable to abstract analysis as manifolds or integers but intelligent people can draw interesting conclusions. Historically, the most interesting and original political analysis has come academics who were not trained in political science. Whatever one thinks of Bertrand Russell’s politics it can’t be denied that much of what he said in 30s, which was regarded as wicked and immoral at the time, is now regarded as nothing more than civilized commonsense in western Europe and much of north America.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33140")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("It’s very telling that those who claim to be disappointed with Dr. Tao’s choice to make a (rare) political post are also those who disagree with the position he chose to endorse. I wonder what they’re really disappointed in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33142")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Vishal: “In regard to “Iran’s strategy and ideology” which you brought up, maybe it would be good to remember that there is only one country, so far, that has actually used a couple of nuclear bombs … Given such a history, I am not very surprised at your apparent paranoia about Iran using a nuclear bomb against its adversary.”")

#text("Irrelevant to the point, and once more, shows a disturbing misunderstanding of the political ideology behinds current Iran’s regime.")

#text("The Iranian president has already spent tens of millions of dollars as the mayor of Tehran in order to build grand avenues to prepare for the arrival of the Mahdi (")#link("http://www.danielpipes.org/article/3258")[#text("http://www.danielpipes.org/article/3258")]#text("; ")#link("http://www.meforum.org/article/1985")[#text("http://www.meforum.org/article/1985")]#text("). The Mahdi is an Islamic notion which stands for the leader who will come before “the end of the world”. This proves that he would be willing to take concrete actions, and pay the price for them, in order to bring about this apocalyptic “end of the world”.")

#text("Based on this, and other empirical evidences, any serious consideration on the topic should take as a working assumption that when Iran will get nuclear capabilities it will most certainly use it.")#linebreak()#text(" To ignore the threats of a regime which is deliberately, loudly and clearly stepping toward a clash with western civilization is irrational.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33143")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("“It’s very telling that those who claim to be disappointed with Dr. Tao’s choice to make a (rare) political post are also those who disagree with the position he chose to endorse. I wonder what they’re really disappointed in.”")

#text("Well, it also works the other way around, isn’t it, John?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7a02dd96c0673202d80e990fb74248e2f1862a40b963d8580769a2334640cba-67f547e9d9a2bb288065f9da8fecc8e428b54dcf13c3e46c41b5673b25a4681a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Davis")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33144")[#strong[#text("Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Seems to me like the only position taken in this post was for sensible rhetoric, which doesn’t seem like a very controversial opinion. That this call for reasonableness evoked comments like “some consider him a traitor to his party and evoke the metaphor of rats leaving a sinking ship” and “when Iran will get nuclear capabilities it will most certainly use it” only makes the point stronger.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33145")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("To those who are denouncing this post as somehow sullying Terence Tao’s otherwise wonderful blog: first, this is not quite the first time that Dr. Tao has spoken out on things important to him that have a political dimension (recall his posts on what is happening at the University of Southern Queensland, which met with near universal approval). And why shouldn’t he? He’s not just a mathematician, he’s a man with a conscience; he’s not writing just to please crowds (or you in particular), but on things which matter to him. Give him a break!")

#text("Second, given what Terence actually wrote, let’s not overreact. It’s not as if he said, “Vote Obama!” He said, in a way which could hardly be milder, that the level of political discourse in this campaign has been pretty low (not much to disagree with there, is there?), so isn’t it refreshing to see a bit of change in this regard. In my opinion, not much to disagree with there, either. Listening to the video, I get the sense that Powell’s decision to back Obama was something that came only after a lot of reflection, and probably also a lot of struggle within himself (as he is breaking ranks with his party); his tenor and phrasing suggest that very strongly. What he did yesterday took guts. To suggest otherwise, that he is a “traitor” or a rat or is only running with the crowd, seems far too cynical to me.")

#text("(Powell probably experiences anguish every day over what happened on February 5, 2003. Is party loyalty always the greatest virtue?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33147")[#strong[#text("Roger")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Wal: “Some of the most distinguished mathematicians have taken political positions: Albert Einstein, Bertrand Russell, Alexander Grothendieck to name three twentieth century examples.”")

#text("You are joking, right? Those guys never did anything worthwhile again after polluting their minds with politics. Please don’t encourage Terry to go down that path.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33148")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Oh, no, not that old trope.")

#text("I’m sorry, but mathematicians and academics ")#emph[#text("are real human beings")]#text(" just like you, Roger. We live and breathe in the same world. We raise families and pay taxes just like you. We have just as much right to concern over the policies that shape our worlds as anyone else.")

#text("I know it will come as a shock to many in the adoring throng, but even a Fields medalist like Dr. Tao has concerns other than mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f00881f3f89fe20b302d50108dc9d3ee550cd96d498b279ad76c1a0c04871a7-f397ac711ae58a2b7884e3a800b6004630a56a8b3151b71c39a4f3b45c545793.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wal")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33149")[#strong[#text("Wal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("@Roger")

#text("Politics is vital for our future. We made a pretty mess of the 20th century we need intelligent analysis if humanity is to progress in the 21st. Bertrand Russell won the Nobel Prize for a book he wrote when he was over 70. He played a major part in civilizing social attitudes in the West after the second world war, arguing for equality of women and homosexual law reform. In his 80s he was campaigning against nuclear weapons with Albert Einstein (who, admittedly, was more interested in research). When he was in his 90s he was organising resistance to the Vietnam war. If that’s not worthwhile I don’t know what is.")

#text("Many intellectuals manage to combine political activity with research very effectively – Paul Krugman, Noam Chomsky, Edward Said.")

#text("Anyway, this is a bit silly – after all we are just talking about a link to a YouTube video, hardly a major drain on Prof Tao’s resources.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33151")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("As a quantum system engineer, I spend a fair amount of time talking with mathematicians. As the parents of a Marine son who has just returned from his third tour of Anbar Province in Iraq, my wife and I have a special motivation to understand the war. And as a professor of medicine, specializing in regenerative healing, having inclinations toward Spinozism, there are (obviously) plenty of tough contradictions to reconcile.")

#text("For those interested in the nexus of logic, engineering, patriotism, humanitarianism, medicine, history, and politics, I wish to commend two works. The first work is the Army’s new “FM 3-07: Stability Operations The Road Map from Conflict to Peace”, in particular the sections on “Conflict Transformation and Legitimacy” (the 2008 edition, paragraphs I-23 through I-43).")

#text("The second work is Jonathan Israel’s recent “Enlightenment Contested: Philosophy, Modernity, and the Emancipation of Man, 1670-1752”.")

#text("Neither of these works is particularly easy, but the diligent reader will discern a very substantial overlap between them. This is no accident … over the last few years the ideals and methods of the Enlightenment have begun to diffuse quite deeply into military and strategic thought (partly because the officers who write the manuals typically have PdDs in history and/or anthropology, and partly because of the harsh lessons in the practical difficulties of nation-building and peace-marking that are still being learned in Iraq and Afghanistan, and indeed, everywhere in the world).")

#text("Much more could be written on these topics … which amount to an ongoing and simultaneous revolution in our conception of the Enlightenment and a revolution in our conception of military strategy … and these revolutions are (of course) all the more reason to read and think for yourself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Here is the content of a letter displayed at the storefront of a pharmacy at Heim-Platz, in Zurich, near ETH. I find it illustrative of how Einstein would think about his personal role in society and when he should express public opinions. There is no commentary displayed with the letter (only the envelope and a picture of Albert), but it’s obviously in response to a previous letter from Raoul Berger asking Einstein for some form of support. [I am typing it up for readers of this thread but also so its content shows up in search engines].")

#text("November 19, 1945")

#text("Mrs.[!] Raoul Berger")#linebreak()#text(" 5121 Edgemoor Lane")#linebreak()#text(" Bethesda 14, Md.")

#text("Dear Mrs. Berger,")#linebreak()#text(" I was deeply moved by your letter which shows me how your family is threatened by this awful disease. May I tell you, incidentally, that my mother and my mother’s mother both have died of the same disease. As far as the Neely bill is concerned I do not believe that it would be helpful if I would sign a petition in favor of it, for it is well known that I am only a layman. It would even impair my influence in such matters where I am competent to express an opinion publicly. For this reason I am very sorry not to be able to comply with your wish.")#linebreak()#text(" I greet you and your dear parents heartily,")#linebreak()#text(" yours cordially,")#linebreak()#text(" Albert Einstein.")

#text("I hope people find this relevant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33153")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Todd Trimble says: ")#emph[#text("I get the sense that Powell’s decision to back Obama was something that came only after a lot of reflection, and probably also a lot of struggle within himself (as he is breaking ranks with his party); his tenor and phrasing suggest that very strongly.")]

#text("Just to confirm your impression … and extend it … a similarly careful reflection, tenor, and phrasing is evident in the recent writings and speeches of (e.g.) Robert Gates, David Petraeus, and James Mattis. These people have crafted a coherent system of strategic and political thought that does not as yet have a name (although in my opinion historians will someday supply one).")

#text("By endorsing a partisan candidate, Gen. Powell has to some extent broken ranks with the other thinkers, who up to the present time have been carefully apolitical.")

#text("It is pretty clear that “who gets elected” is only part of the political issues that are in-play … quite likely, not even the most important part.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33157")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I’m very happy to find this video on Prof. Tao’s blog. I believe everyone should be involved in politics because if we were not and leave important decision making to unqualified, ill-intent people then we have to live with despicable things like the invasion of Iraq.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33159")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I’d like to echo what, surprisingly, only one person (Todd Trimble) has hinted at so far: this post is not an explicit endorsement for Obama. While of course we can all make a pretty good guess at Dr. Tao’s personal preference in this election, the actual text of the post is completely focused on the tone and level of recent political discourse; there is no discussion of what Tao thinks of either candidate, and certainly no admonishment to the reader to vote either way. I’m surprised that nearly all the responses to this post, both negative and positive, approach it from a partisan standpoint. Terry isn’t “involving himself in politics” here; he’s simply pointing out a good example of the kind of measured, civil, and (relatively) analytical approach to campaign politics that many of us wish we’d seen more in recent months. As someone who is tired both of watching the phrase “hockey moms” become part of the political lexicon and of encountering a disturbing number of college-educated students who prefer the phrase “Barack Your World” to any actual discussion of policy, I have to agree with the sentiment of Terry’s post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("To Roger who wrote: “You are joking, right? Those guys never did anything worthwhile again after polluting their minds with politics. Please don’t encourage Terry to go down that path.”")

#text("Well, first of all, Einstein did important research while being involved in humanitarian effort. His discovery of quantum entanglement is the basis for quantum algorithms. Second, even if he did not produce anything comparable to his theory of relativity, it’s not clear that the reason was that his mind was polluted with politics. It could have been that a Unifying Theory was too hard; there were and are lots of researchers who don’t seem to be involved in politics, why haven’t they come up with the correct Theory? Third, even if politics did take him away from important discovery, one should be thankful for all he did before. What Einstein, Grothendieck and Terry Tao accomplished in their youth is more than most people could in all their life. So please don’t throw careless words such as “never did anything worthwhile again” and “polluting their minds with politics” around. That’s offensive!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f1af213b05a7d7283f5d232279fb4e51dc52e19a50edfa02a7cd10b555b10e0-0b736b9924f0d28bb6b5764a07bb754bba65a2261011273bcb50865d183f15c6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hustleandfloe")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33161")[#strong[#text("hustleandfloe")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I am a bit amazed at the responses as the owner of this blog has been much less partisan in this posting than in the comments that follow. It would seem that folks who bend toward science, inquiry, even thoughtful debate could take this at face value when offered not an Obama endorsement but, simply, “The level and quality of discourse in this U.S. presidential campaign has not been particularly high, especially in recent weeks. ” and It’s a shame that much of the rhetoric and commentary surrounding this campaign – from all sides – was not more like this.")

#text("I would challenge any thoughtful person to disagree with those premises in light of the evidence. We should want for two strong and thoughtful challengers to produce productive debate.")

#text("Even if he were to delve into the politics, I would applaud it if it were done as Feynman or Umberto Eco for beautiful examples here. (e.g. Feynman’s The Meaning of It All: Thoughts of A Citizen Scientist). He was not intimidated by the application of scientfic thought to political, even religious topics, finding not conflict or dichotomy but rather revealing ways to reason through this stuff. He was aware, and mentioned it, that scientists usually fear this ground.")

#text("Still, I appreciate the role of priests, be they mathematicians or generals, among the Levites. I want them to guard their station and be free to think.")

#text("That’s my hesitancy in seeing the military leaving its ivory tower over the past decade, having brought generals a bit too close to the level of everyday political discourse (w/endorsments and the like) vs. keeping to pure military science and strategy. There IS a way and a time for them to come talk to the regular ol’ folks, though.")

#text("I think Powell and Feynman achieve this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33162")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("John Sidles: possibly it moves off-topic, but it might be helpful to provide links to the writings and speeches you’re referring to.")

#text("“By endorsing a partisan candidate, Gen. Powell has to some extent broken ranks with the other thinkers, who up to the present time have been carefully apolitical.”")

#text("It might be interesting (but again possibly off-topic) to examine this statement carefully, but it goes without saying that had Powell endorsed McCain, it would have been for a partisan candidate as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33163")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("If scientists and mathematicians do not become involved in politics, is politics to be left only to the creationists?")

#text("Politics is a matter that should be of importance to all, with or without endorsement.")

#text("Colin Powell appears to have put country before party.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d081e4864c1ea1ad211231071763258b8f6d63f1819378c3409f507740e672b7-02fba8cd4a6b875fb23bc5943d5b20c2d007d805995f327835a562cf0bb30127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33164")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I think this post falls under the “discussion of open problems” section :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33166")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I am very, very happy to see Professor Terece Tao care about politics: because politics is important to everyone’s career and academic future. If a president with arrogrant attitude for science and technology is elected, he could possibly do everything he can to turn this country into a “dumb” country.")

#text("To Ben: America has lost a big deal in the past 8 years: economic is turning downward, millions of jobs shipped overseas, trade and budget deficits soaring, now the financial and economic crisis. You will see those things worsen in the next 4 years. In 20 years, america will no longer be No.1 super power, I am very very sure about this.")

#text("By the way, leave Iran alone. U.S. does not have any power left to deal with Iran at this time. Why are you just “brave” enough to bomb such a small country? why not “Russia”? because U.S. does not even have the guts!")

#text("To Roger: I do not know who you are exactly. What “worthwhile” thing have you done? Come on, tell me……")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336e8a57337ea1071a8f94ee875dac3a6e7e482e0b7547623f349678744ba1d4-10b839183bdd939ad7627d1990e0ce5221a544b077c5acd99f9904757c6a5f29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33167")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Dear Professor Tao")

#text("After George W Bush leaves office, he, along with Donald Rumsfeld,Dick Chenney,Condalezza Rice and Colin Powell are very likely to have war crime chargs filed against them in the Hague. Donald Rumsfeld can no longer travel to Europe. Last time he went to Europe he was nearly picked up on war crime charges.")

#text("Colin Powell lied on behalf of the Bush adminstration when he made the administration’s case for going to war against Iraq. Powell is a toady and a war criminal.")

#text("Barck Obama recieved the endorsement of a war criminal. This tells us a lot about the Barack Obama adminstration. Barack Obama has not ruled out attacking Iraq. And he has also not ruled out using nuclear weapons against Iraq.")

#text("I mentioned that Colin Powell is a toady. During the Vietnam war, Captain Colin Powell played a signficantly role in the cover up of the Mai Lai massacre of Vietnamese civilians. For this, he was rewarded with many promotions.")

#text("I beleive that Colin Powell supports Barack Obama for a very specific reason. The US is going through a major demographic transformation because of post 1965 immigration policy. Powell uses language such as Obama being transformational and a new generation taking center stage. This is support based upon racial solidarity-pure and simple.")

#text("One last thing, there are millions of Americans who are opposed to their country being demographically transformed by post-1965 immigration policy. They never voted for it. Powell, Barck Obama and John McCain are all enthusisastic supporters of the ongoing demographic transformation.")

#text("I have no horse in this race. But I want to point out that the Democratic would be a politically marginal party if it wasn’t able to import its voters from overseas.")

#text("The demographic transformation of America by post-1965 immigration policy is the key to understanding the current presidential race and future presendntial races. Demographics is destiny.")

#text("I just remembered something. If you have any doubts that Colin Powell is war criminal,have a look at Vincent Bugliosi’s new book making the legal case that George W Bush has commited mass murder. Bugliosi was the prosecutor in the manson case. His book was on the best sellers list for a while")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f00881f3f89fe20b302d50108dc9d3ee550cd96d498b279ad76c1a0c04871a7-f397ac711ae58a2b7884e3a800b6004630a56a8b3151b71c39a4f3b45c545793.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wal")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33168")[#strong[#text("Wal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("@ Joshua")

#text("Millions of Americans were opposed to the demographic transformation of 1620 – none of them ever voted for it. Nor did the Africans opposed to the demographic transformation in the 18th century. I guess you are Anglo-Saxon – perhaps you should consider going to live in Germany.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33170")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Todd Trimble asks: ")#emph[#text("“John Sidles: possibly it moves off-topic, but it might be helpful to provide links to the writings and speeches you’re referring to.”")]

#text("Gosh Todd … as with any other branch of the modern literature, there are hundreds of relevant documents … many more documents than any person (including me) could reasonably digest.")

#text("Among the most widely read and discussed recent works are the two new Army/Marine field manuals ")#emph[#text("FM 3-24 Counterinsurgency")]#text(" (2006) and its companion ")#emph[#text("FM 3-07 Stability Operations: the Road Map from Conflict to Peace")]#text(" (2008).")

#text("SecDef Robert Gates’ article in the recent ")#emph[#text("Military Review> (June 2008) titled ")]#emph[#text("Beyond Guns and Steel: Reviving the Nonmilitary Instruments of American Power")]#text(" can be read as effort to define and align political support for these two field manuals … it is for this reason a rather lightweight article (as these things go).")

#text("All of the above can be found on-line (with the caveat that pre-2006 editions of these field manuals should be ignored, as the new ones are radically different).")

#text("For me, it is hugely interesting to read (on alternate nights) Jonathan Israel’s history of the Enlightenment, in alternating juxtaposition with these modern Army/Marine manuals.")

#text("The way I read all of these texts, they are concerned with the practical realities of war-fighting, nation-building, and peace-making.")

#text("In Prof. Israel’s works, we know how the story comes out … in the sense that we know (with hindsight) how our modern world looked in the years 1700, 1800, 1900, and 2000. Still, the historical context and detail that Prof. Israel provides is truly wonderful.")

#text("The Army/Marine field manuals are broadly concerned to foresee what the coming several decades might look like … needless to say, this is an immensely more difficult task.")

#text("Caveat: none of the above reading is light or happy … hence this work is seldom or never discussed by politicians … the idea that the future might be as complicated as the past is regarded as too stressful for voters to contemplate. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("The Myth of Consistent Skepticism")#linebreak()#text(" The Cautionary Case of Albert Einstein")#linebreak()#text(" ")#link("http://www.csicop.org/si/2007-03/einstein.html")[#text("http://www.csicop.org/si/2007-03/einstein.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c659e1f43fc40ba6ebc66908d68c46420036c1ac179a0b342f3d6741bff8ec57-49d3dc7897efafea037173b60cee096fd268f5da749a0b456bed7fc15efb4485.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33175")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I agree with those that enjoy hearing what a great mathematician thinks about things other than his day job. I certainly don’t think politics could get nearly as nasty as choosing to discuss religion. I’m sure that that’s why Professor Tao didn’t want to discuss Bayesian statistics :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25d4c06aac0d65c52bfc68d5de30d952ae1fc5974a07bdf471ae7d5825b656d6-4c6e96d0b7328a837d4ffbbcd2643a52959f7c716f93e9a1f7bb778420ad53a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33177")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Thanks for the post. It’s an unfortunate state of affairs when thoughtful mathematical pieces on this blog are commented on by the few, while a short entry on Powell’s political endorsement, though worded mildly by Prof. Tao, still draws so many condesending and spiteful comments.")

#text("We’re drawn to divisive politics like flies being drawn to faeces. If only we’re equally passionate about math and science and social justices than just on divisive politics.")

#text("—> Budding Harmonic Analyst (Still digesting the amplification-trick post)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336e8a57337ea1071a8f94ee875dac3a6e7e482e0b7547623f349678744ba1d4-10b839183bdd939ad7627d1990e0ce5221a544b077c5acd99f9904757c6a5f29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33178")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Is there is a dimes worth of difference on fundamental policies between Barck Obama and John McCain? There are great doubts about this.")

#text("Both support an aggressive foreign policy. Barck Obama would like to take war on terrorism right up to the Pakistani border. There is a developing consensus among elite military types that the war in Afghanistan is unwinable. Barack Obama has already let the Chavez goverment know that the destabilization of the the Venezuelan goverment will contiune apace. Think of the millions that will be wasted.")

#text("Both McCaiin and Barck Obama are on the same page on the oursourcing of th US manfacturing base to Asia.")

#text("Both McCain and Barack Obama are on the same page on the shipping of US jobs overseas-both blue collar and skilled white collar jobs.")

#text("Both McCain and Barack Obama are on the same page on the H1-B and L-1 visa program. This is high tech scab labor subsidy to multibillionaires Bill Gates and Larry Ellison.")

#text("Both John McCaain and Barck Obama are on the same page when it comes to the importation of unskilled low wage sab labor from Mexico and Latin America. For blue-collar American workers, this gives new meaning to the expression “wage -slave”. In other words, both McCain and Barack Obama are hell-bent on creating a permanent low wage economy.")

#text("The environment:Both John McCain and Barack Obama advocate both an amensty and increase in legal immigration. This would very likley push the US population to close to a billion in 25 years. This makes them both enemies of endangered species and ecosystem conservation. The American West is in its worst drought in five hundred years. Without Colorado’s water, Southern California would be a desert. This is the height of irresponsibility. Southern California has the largest number of edemic endangered species in the nation. Despite this, we have two candidates who would like to see California’s population increase upward and upward")

#text("On fundamental policy issues-the kinds of issues which can wreck a nation,-both candidates are disasters. They are also both commiting treason by advocating what is essentially an open borders immigration policy.")

#text("They also both commited treason when they gave their allegiance to the State of Israel at the APAIC conference in NYC. So does Sarah Palin when she goes around wearing a flag of Isarel on her lapel.")

#text("John Sidels, you mentioned that you are involved in neuroregeneration. This is a life and death issue in my family(Lou Gehrigs disease). Some of the one trillion dollars that has been used to invade and occupy a nation that posed no threat to the US could have been spent on curing ALS-through neuroregeneration.")

#text("By the way, Barack Obama voted to spend 400 million dollars to destabilize the Iranian goverment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f00881f3f89fe20b302d50108dc9d3ee550cd96d498b279ad76c1a0c04871a7-f397ac711ae58a2b7884e3a800b6004630a56a8b3151b71c39a4f3b45c545793.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wal")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33179")[#strong[#text("Wal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("@Daniel")

#text("What’s divisive about a political argument? If we can’t have political arguments we are in a sorry state. Although I agree that passion for maths and science are important, politics (which surely includes social justice) is more important still. Without healthy and vigorous political debate and a general population who have a general interest and education in politics and political ideas there is a risk society will stagnate.")

#text("So here’s to more vigorous political arguments and political posts from Prof Tao!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25d4c06aac0d65c52bfc68d5de30d952ae1fc5974a07bdf471ae7d5825b656d6-4c6e96d0b7328a837d4ffbbcd2643a52959f7c716f93e9a1f7bb778420ad53a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33180")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Political argument is vital to a healthy culture. What I was pointing to was a specific type of political argument (or shouting match): comments that derided Prof. Tao’s choice of entry (Powell’s endorsement) and people’s views that did not agree with their own. I agree that we would be in a sorry state if no political arguments exist, yet it is the sorry state of political arguments that I lament.")

#text("I strongly believe in the importance of meaningful exchanges of ideas. But when we label each other’s views as “dangerously naive” or accuse one to “stoop to those political comments”, then the whole exercise becomes a futile exchange best left for the uneducated. This blog provides the best environment for the highest level of exchange, due to the author and the people who read it. And yet it quickly degraded unpleasantries. This quick decay is what I was reflecting on.")#linebreak()#text(" (Of course, many comments above are even-handed and extremely informative.)")#linebreak()#text(" So in conclusion, I agree with your comments, support the choice of entry by Prof Tao (how can I not? It’s his blog), find this forum extremely informative and enlightening, and wish political disagreements do not immediately decay into hostile political divisiveness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33181")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Quoting Wal: “I guess you are Anglo-Saxon – perhaps you should consider going to live in Germany.”")

#text("As a mathematician currently working in Germany (but not from Germany), I find this remark to be particularly offensive. It not only displays the stereotype-driven ignorance of the author but, in light of the content of Dr. Tao’s post (“…keep the discussion constructive, polite…”), more than a tad bit ironic.")

#text("Perhaps you, Wal, should come visit Germany; you could learn something about confronting and overcoming racism-laced politics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f00881f3f89fe20b302d50108dc9d3ee550cd96d498b279ad76c1a0c04871a7-f397ac711ae58a2b7884e3a800b6004630a56a8b3151b71c39a4f3b45c545793.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wal")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33185")[#strong[#text("Wal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("@Paul")

#text("I was not stereotyping the Germans, I’ve been to Germany many times and like the country very much.")

#text("I was simply pointing out to Joshua that his views on immigration might be a tad inconsistent with US history. Perhaps I chose my example hastily and naively given the history of Germany but I can assure you I did not mean to imply that Germans are intrinsically any more or less racist than anyone else – in my experience they are not. I was simply pushing Joshua’s argument to it’s logical (absurd) conclusion. I could have chosen Africa (whence the human race came) but chose not to – ironically because I was concerned that it might be be misconstrued as racist. I should have stuck with “Europe” I suppose.")

#text("So – don’t be offended – generally there’s no need. If a person has a bigoted opinion it is better to argue with them and try to enlighten them. If they are an unwavering you might as well ignore them. On the other hand you might have made a mistake! Taking offense is a sign of a closed mind.")

#text("Wal")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336e8a57337ea1071a8f94ee875dac3a6e7e482e0b7547623f349678744ba1d4-10b839183bdd939ad7627d1990e0ce5221a544b077c5acd99f9904757c6a5f29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33186")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Barack Obama also voted to allow the big telecommincation companies to spy on ordinary Americans on behalf of the Bush-Cheney police state. I find the rock star adulation of Barack Obama extremely scary. It deactivates the human critcal faculty. I’m not accusing Professor Tao of this.")

#text("I have spoken to several Black Americans and quizzed them on the specifics of Obama’s economic,trade,foreign and immigration policies. None of them had a clue about Barack Obama’s policies. I suspect very strongly that this observation can be generalized to the larger Black American population and the White American college age population. Without a doubt, they are voting for Barack Obama for two reasons:1)because he is black and 2)he is for affirmative action.The critical faculty of these two populations has been deactivated. The same can be said for the White American supporters of McCain and Sarah Palin.")

#text("One last point about Colin Powell, he has quite literally gotten away with mass murder. The human race has gotten to the point where this is no longer acceptable. He is very likely to be indicted sometime after January 2009. I don’t know how long afterwards. It may be sooner than you think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33187")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("@ Joshua Chamberlain,")

#text("How many American voters understand comprehensively what Bush would do if he was elected in 2000 and 2004? Not many. If they did, they will not be in such a mess as today. as always, people cast their votes psendorandomly based on passion or whatever.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336e8a57337ea1071a8f94ee875dac3a6e7e482e0b7547623f349678744ba1d4-10b839183bdd939ad7627d1990e0ce5221a544b077c5acd99f9904757c6a5f29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33188")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Wal")

#text("I wasn’t really making any argumnt at all. I was just stating my demographic preference. You see, in America, if you are of European ancestry you are not suppose to express a demographic preference even though the post-1965 non-European population is encouraged to do this. In fact, they express their demographic preferences publicly and enthusiastically. I am not even-handed in my attitude towards US immigration policy because,honestly, no other group is. There are no absurd conclusions to be drawn. Colin Powells’s enthusiastic support for Barack Obama should be seen in this context.")

#text("Don’t romanticize the Ameridians. There were centuries of conquests and genocides within that racial group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33189")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")]

#text("[…] Powell’s endorsement The level and quality of discourse in this U.S. presidential campaign has not been particularly high, especially in […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33190")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("@ Joshua Chamberlain,")#linebreak()#text(" I totally disagree with your absurd comments. you should really go away back to Germany. If you like Europeans, go back to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25d4c06aac0d65c52bfc68d5de30d952ae1fc5974a07bdf471ae7d5825b656d6-4c6e96d0b7328a837d4ffbbcd2643a52959f7c716f93e9a1f7bb778420ad53a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33191")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Just realized my analogy of flies earlier is not the best way to convey my views. I think I just exhibited the temperament I was just speaking out against. My apologies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33192")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("Indeed Powell’s endorsement of Obama was classy, thoughtful and probably quite effective. Also the appreciation and comradeship feelings he expressed towards Macain seem genuine.")

#text("Being a regular observer of the US elections, my primary feeling, just like the feeling I have in elections back home, is a feeling of a celebration. Of course, the level of discussion and commentary is not always high, and sometimes we see uncalled-for harsh sentiments and inappropriate attitudes. The election is shaded by many genuine difficult problems involving many unknowns factors. But overall it is a celebration of democracy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33194")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I think that Einstein is a poor example to consider here. Instead, consider two contrasting examples of well known mathematicians widely separated in time. Galois was heavily involved in politics to the point of much distraction from his mathematical work, finally coming to a tragic end. Steven Smale and a few other mathematicians at Berkeley were heavily involved in the free speech and anti-war movements, and their work and careers did not seem to suffer much in the end.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Sogge")]], [#link("https://terrytao.wordpress.com/2008/10/19/powells-endorsement/comment-page-1/#comment-33195")[#strong[#text("Chris Sogge")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("I don’t want to get “political”, but whoever wins, it will be historical.")
]
