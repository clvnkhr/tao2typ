// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/
// Converted to Typst by tao2typ: "2026-10-14T15:19:53.017255+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quantitative continuity estimates", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quantitative continuity estimates")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 May 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/")[#text("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose ")#mi("{F: X \\rightarrow Y}")#text(" is a continuous (but nonlinear) map from one normed vector space ")#mi("{X}")#text(" to another ")#mi("{Y}")#text(". The continuity means, roughly speaking, that if ")#mi("{x_0, x \\in X}")#text(" are such that ")#tao-math("{\\left\\|x-x_0\\right\\|_X}", block: false)#text(" is small, then ")#tao-math("{\\left\\|F(x)-F(x_0)\\right\\|_Y}", block: false)#text(" is also small (though the precise notion of “smallness” may depend on ")#mi("{x}")#text(" or ")#mi("{x_0}")#text(", particularly if ")#mi("{F}")#text(" is not known to be ")#link("https://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniformly continuous")]#text("). If ")#mi("{F}")#text(" is known to be differentiable (in, say, the ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_derivative")[#text("Fréchet sense")]#text("), then we in fact have a linear bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F(x)-F(x_0)\\right\\|_Y \\leq C(x_0) \\left\\|x-x_0\\right\\|_X", block: true)]]

#text("for some ")#mi("{C(x_0)}")#text(" depending on ")#mi("{x_0}")#text(", if ")#tao-math("{\\left\\|x-x_0\\right\\|_X}", block: false)#text(" is small enough; one can of course make ")#mi("{C(x_0)}")#text(" independent of ")#mi("{x_0}")#text(" (and drop the smallness condition) if ")#mi("{F}")#text(" is known instead to be ")#link("https://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz continuous")]#text(".")

#text("In many applications in analysis, one would like more explicit and quantitative bounds that estimate quantities like ")#tao-math("{\\left\\|F(x)-F(x_0)\\right\\|_Y}", block: false)#text(" in terms of quantities like ")#tao-math("{\\left\\|x-x_0\\right\\|_X}", block: false)#text(". There are a number of ways to do this. First of all, there is of course the trivial estimate arising from the triangle inequality: ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|F(x)-F(x_0)\\right\\|_Y \\leq \\left\\|F(x)\\right\\|_Y + \\left\\|F(x_0)\\right\\|_Y.", block: true)]]

#text("This estimate is usually not very good when ")#mi("{x}")#text(" and ")#mi("{x_0}")#text(" are close together. However, when ")#mi("{x}")#text(" and ")#mi("{x_0}")#text(" are far apart, this estimate can be more or less sharp. For instance, if the magnitude of ")#mi("{F}")#text(" varies so much from ")#mi("{x_0}")#text(" to ")#mi("{x}")#text(" that ")#tao-math("{\\left\\|F(x)\\right\\|_Y}", block: false)#text(" is more than (say) twice that of ")#tao-math("{\\left\\|F(x_0)\\right\\|_Y}", block: false)#text(", or vice versa, then ")#link(<tao-cddd67830982a78cc839>)[#text("(1)")]#text(" is sharp up to a multiplicative constant. Also, if ")#mi("{F}")#text(" is oscillatory in nature, and the distance between ")#mi("{x}")#text(" and ")#mi("{x_0}")#text(" exceeds the “wavelength” of the oscillation of ")#mi("{F}")#text(" at ")#mi("{x_0}")#text(" (or at ")#mi("{x}")#text("), then one also typically expects ")#link(<tao-cddd67830982a78cc839>)[#text("(1)")]#text(" to be close to sharp. Conversely, if ")#mi("{F}")#text(" does not vary much in magnitude from ")#mi("{x_0}")#text(" to ")#mi("{x}")#text(", and the distance between ")#mi("{x}")#text(" and ")#mi("{x_0}")#text(" is less than the wavelength of any oscillation present in ")#mi("{F}")#text(", one expects to be able to improve upon ")#link(<tao-cddd67830982a78cc839>)[#text("(1)")]#text(".")

#text("When ")#mi("{F}")#text(" is relatively simple in form, one can sometimes proceed simply by substituting ")#mi("{x = x_0 + h}")#text(". For instance, if ")#mi("{F: R \\rightarrow R}")#text(" is the squaring function ")#mi("{F(x) = x^2}")#text(" in a commutative ring ")#mi("{R}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("F(x_0+h) = (x_0+h)^2 = x_0^2 + 2x_0 h+ h^2")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("F(x_0+h) - F(x_0) = 2x_0 h + h^2")]]

#text("or in terms of the original variables ")#mi("{x, x_0}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("F(x) - F(x_0) = 2 x_0 (x-x_0) + (x-x_0)^2.")]]

#text("If the ring ")#mi("{R}")#text(" is not commutative, one has to modify this to")

#align(center)[#tao-fit-display[#mitex("F(x) - F(x_0) = x_0 (x-x_0) + (x-x_0) x_0 + (x-x_0)^2.")]]

#text("Thus, for instance, if ")#mi("{A, B}")#text(" are ")#mi("{n \\times n}")#text(" matrices and ")#mi("{\\| \\|_{op}}")#text(" denotes the operator norm, one sees from the triangle inequality and the sub-multiplicativity ")#tao-math("{\\left\\| AB\\right\\|_{op} \\leq \\left\\| A \\right\\|_{op} \\left\\|B\\right\\|_{op}}", block: false)#text(" of operator norm that ")#metadata(none) <tao-1fbe8e4f4059ee0e7e8a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| A^2 - B^2 \\right\\|_{op} \\leq \\left\\| A - B \\right\\|_{op} ( 2 \\left\\|B\\right\\|_{op} + \\left\\|A - B \\right\\|_{op} ).", block: true)]]

#text("If ")#mi("{F(x)}")#text(" involves ")#mi("{x}")#text(" (or various components of ")#mi("{x}")#text(") in several places, one can sometimes get a good estimate by “swapping” ")#mi("{x}")#text(" with ")#mi("{x_0}")#text(" at each of the places in turn, using a telescoping series. For instance, if we again use the squaring function ")#mi("{F(x) = x^2 = x x}")#text(" in a non-commutative ring, we have")

#tao-aligned(keep: true)[


#tao-math("F(x) - F(x_0)  & = x x - x_0 x_0", block: true)



#tao-math(" & = (x x - x_0 x) + (x_0 x - x_0 x_0)", block: true)



#tao-math(" & = (x-x_0) x + x_0 (x-x_0)", block: true)
]

#text("which for instance leads to a slight improvement of ")#link(<tao-1fbe8e4f4059ee0e7e8a>)[#text("(2)")]#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A^2 - B^2 \\right\\|_{op} \\leq \\left\\| A - B \\right\\|_{op} ( \\left\\| A\\right\\|_{op} + \\left\\|B\\right\\|_{op} ).", block: true)]]

#text("More generally, for any natural number ")#mi("{n}")#text(", one has the identity ")#metadata(none) <tao-b4f606c2353eeac323eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("x^n - x_0^n = (x-x_0) (x^{n-1} + x^{n-2} x_0 + \\dots + x x_0^{n-2} + x_0^{n-1})")]]

#text("in a commutative ring, while in a non-commutative ring one must modify this to")

#align(center)[#tao-fit-display[#mitex("x^n - x_0^n = \\sum_{i=0}^{n-1} x_0^i (x-x_0) x^{n-1-i},")]]

#text("and for matrices one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A^n - B^n \\right\\|_{op} \\leq \\left\\| A-B\\right\\|_{op} ( \\left\\|A\\right\\|_{op}^{n-1} + \\left\\| A\\right\\|_{op}^{n-2} \\left\\| B\\right\\|_{op} + \\dots + \\left\\|B\\right\\|_{op}^{n-1} ).", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" If ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are unitary ")#mi("{n \\times n}")#text(" matrices, show that the commutator ")#mi("{[U,V] := U V U^{-1} V^{-1}}")#text(" obeys the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| [U,V] - I \\right\\|_{op} \\leq 2 \\left\\| U - I \\right\\|_{op} \\left\\| V - I \\right\\|_{op}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" first control ")#tao-math("{\\left\\| UV - VU \\right\\|_{op}}", block: false)#text(".)")
]

#text("Now suppose (for simplicity) that ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}^{d^{\\prime}}}")#text(" is a map between Euclidean spaces. If ")#mi("{F}")#text(" is continuously differentiable, then one can use the fundamental theorem of calculus to write")

#align(center)[#tao-fit-display[#mitex("F(x) - F(x_0) = \\int_0^1 \\frac{d}{dt} F( \\gamma(t) )\\ dt")]]

#text("where ")#mi("{\\gamma: [0,1] \\rightarrow Y}")#text(" is any continuously differentiable path from ")#mi("{x_0}")#text(" to ")#mi("{x}")#text(". For instance, if one uses the straight line path ")#mi("{\\gamma(t) := (1-t) x_0 + tx}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("F(x) - F(x_0) = \\int_0^1 ((x-x_0) \\cdot \\nabla F)( (1-t) x_0 + t x )\\ dt.")]]

#text("In the one-dimensional case ")#mi("{d=1}")#text(", this simplifies to ")#metadata(none) <tao-9f0c710ce3e5bb37de41>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("F(x) - F(x_0) = (x-x_0) \\int_0^1 F^{\\prime}( (1-t) x_0 + t x )\\ dt.")]]

#text("Among other things, this immediately implies the ")#link("https://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" for ")#mi("{C^k}")#text(" functions: if ")#mi("{F}")#text(" is a ")#mi("{C^k({\\bf R})}")#text(" function for some ")#mi("{k \\geq 1}")#text(" that vanishes at some point ")#mi("{x_0}")#text(", then ")#mi("{F(x)}")#text(" factors as the product of ")#mi("{x-x_0}")#text(" and some ")#mi("{C^{k-1}}")#text(" function ")#mi("{G}")#text(". Another basic consequence is that if ")#mi("{\\nabla F}")#text(" is uniformly bounded in magnitude by some constant ")#mi("{C}")#text(", then ")#mi("{F}")#text(" is Lipschitz continuous with the same constant ")#mi("{C}")#text(".")

#text("Applying ")#link(<tao-9f0c710ce3e5bb37de41>)[#text("(4)")]#text(" to the power function ")#mi("{x \\mapsto x^n}")#text(", we obtain the identity ")#metadata(none) <tao-2885480d52765a014de2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("x^n - x_0^n = n (x-x_0) \\int_0^1 ((1-t) x_0 + t x)^{n-1}\\ dt")]]

#text("which can be compared with ")#link(<tao-b4f606c2353eeac323eb>)[#text("(3)")]#text(". Indeed, for ")#mi("{x_0}")#text(" and ")#mi("{x}")#text(" close to ")#mi("{1}")#text(", one can use logarithms and Taylor expansion to arrive at the approximation ")#mi("{((1-t) x_0 + t x)^{n-1} \\approx x_0^{(1-t) (n-1)} x^{t(n-1)}}")#text(", so ")#link(<tao-b4f606c2353eeac323eb>)[#text("(3)")]#text(" behaves a little like a Riemann sum approximation to ")#link(<tao-2885480d52765a014de2>)[#text("(5)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" For each ")#mi("{i=1,\\dots,n}")#text(", let ")#mi("{X^{(1)}_i}")#text(" and ")#mi("{X^{(0)}_i}")#text(" be random variables taking values in a measurable space ")#mi("{R_i}")#text(", and let ")#mi("{F: R_1 \\times \\dots \\times R_n \\rightarrow {\\bf R}^m}")#text(" be a bounded measurable function.")

#list(
[#text("(i) (Lindeberg exchange identity) Show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} F(X^{(1)}_1,\\dots,X^{(1)}_n) - \\mathop{\\bf E} F(X^{(0)}_1,\\dots,X^{(0)}_n)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\sum_{i=1}^n \\mathop{\\bf E} F( X^{(1)}_1,\\dots, X^{(1)}_{i-1}, X^{(1)}_i, X^{(0)}_{i+1}, \\dots, X^{(0)}_n)", block: true)



#tao-math(" & - \\mathop{\\bf E} F( X^{(1)}_1,\\dots, X^{(1)}_{i-1}, X^{(0)}_i, X^{(0)}_{i+1}, \\dots, X^{(0)}_n).", block: true)
]],
[#text("(ii) (Knowles-Yin exchange identity) Show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} F(X^{(1)}_1,\\dots,X^{(1)}_n) - \\mathop{\\bf E} F(X^{(0)}_1,\\dots,X^{(0)}_n)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\int_0^1 \\sum_{i=1}^n \\mathop{\\bf E} F( X^{(t)}_1,\\dots, X^{(t)}_{i-1}, X^{(1)}_i, X^{(t)}_{i+1}, \\dots, X^{(t)}_n)", block: true)



#tao-math(" & - \\mathop{\\bf E} F( X^{(t)}_1,\\dots, X^{(t)}_{i-1}, X^{(0)}_i, X^{(t)}_{i+1}, \\dots, X^{(t)}_n)\\ dt,", block: true)
]

#text("where ")#mi("{X^{(t)}_i = 1_{I_i \\leq t} X^{(0)}_i + 1_{I_i > t} X^{(1)}_i}")#text(" is a mixture of ")#mi("{X^{(0)}_i}")#text(" and ")#mi("{X^{(1)}_i}")#text(", with ")#mi("{I_1,\\dots,I_n}")#text(" uniformly drawn from ")#mi("{[0,1]}")#text(" independently of each other and of the ")#mi("{X^{(0)}_1,\\dots,X^{(0)}_n, X^{(1)}_0,\\dots,X^{(1)}_n}")#text(".")],
[#text("(iii) Discuss the relationship between the identities in parts (i), (ii) with the identities ")#link(<tao-b4f606c2353eeac323eb>)[#text("(3)")]#text(", ")#link(<tao-2885480d52765a014de2>)[#text("(5)")]#text(".")]
)

#text("(The identity in (i) is the starting point for the ")#emph[#text("Lindeberg exchange method")]#text(" in probability theory, discussed for instance in ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("this previous post")]#text(". The identity in (ii) can also be used in the Lindeberg exchange method; the terms in the right-hand side are slightly more symmetric in the indices ")#mi("{1,\\dots,n}")#text(", which can be a technical advantage in some applications; see ")#link("https://arxiv.org/abs/1410.3516")[#text("this paper of Knowles and Yin")]#text(" for an instance of this.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" If ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}^{d^{\\prime}}}")#text(" is continuously ")#mi("{k}")#text(" times differentiable, establish Taylor’s theorem with remainder")

#tao-aligned(keep: true)[


#tao-math("F(x)  & = \\sum_{j=0}^{k-1} \\frac{1}{j!} (((x-x_0) \\cdot \\nabla)^j F)( x_0 )", block: true)



#tao-math(" & + \\int_0^1 \\frac{(1-t)^{k-1}}{(k-1)!} (((x-x_0) \\cdot \\nabla)^k F)((1-t) x_0 + t x)\\ dt.", block: true)
]

#text("If ")#mi("{\\nabla^k F}")#text(" is bounded, conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|F(x) - \\sum_{j=0}^{k-1} \\frac{1}{j!} (((x-x_0) \\cdot \\nabla)^j F)( x_0 )\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\frac{\\left|x-x_0\\right|^k}{k!} \\sup_{y \\in {\\bf R}^d} \\left|\\nabla^k F(y)\\right|.", block: true)]]
]

#text("For real scalar functions ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", the average value of the continuous real-valued function ")#mi("{(x - x_0) \\cdot \\nabla F((1-t) x_0 + t x)}")#text(" must be attained at some point ")#mi("{t}")#text(" in the interval ")#mi("{[0,1]}")#text(". We thus conclude the ")#link("https://en.wikipedia.org/wiki/Mean_value_theorem")[#text("mean-value theorem")]

#align(center)[#tao-fit-display[#mitex("F(x) - F(x_0) = ((x - x_0) \\cdot \\nabla F)((1-t) x_0 + t x)")]]

#text("for some ")#mi("{t \\in [0,1]}")#text(" (that can depend on ")#mi("{x}")#text(", ")#mi("{x_0}")#text(", and ")#mi("{F}")#text("). This can for instance give a second proof of fact that continuously differentiable functions ")#mi("{F}")#text(" with bounded derivative are Lipschitz continuous. However it is worth stressing that the mean-value theorem is only available for ")#emph[#text("real scalar")]#text(" functions; it is false for instance for complex scalar functions. A basic counterexample is given by the function ")#mi("{e(x) := e^{2\\pi i x}}")#text("; there is no ")#mi("{t \\in [0,1]}")#text(" for which ")#mi("{e(1) - e(0) = e^{\\prime}(t)}")#text(". On the other hand, as ")#mi("{e^{\\prime}}")#text(" has magnitude ")#mi("{2\\pi}")#text(", we still know from ")#link(<tao-9f0c710ce3e5bb37de41>)[#text("(4)")]#text(" that ")#mi("{e}")#text(" is Lipschitz of constant ")#mi("{2\\pi}")#text(", and when combined with ")#link(<tao-cddd67830982a78cc839>)[#text("(1)")]#text(" we obtain the basic bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|e(x) - e(y)\\right| \\leq \\min( 2, 2\\pi \\left|x-y\\right| )", block: true)]]

#text("which are already very useful for many applications.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{H_0, V}")#text(" be ")#mi("{n \\times n}")#text(" matrices, and let ")#mi("{t}")#text(" be a non-negative real.")

#list(
[#text("(i) Establish the ")#link("https://en.wikipedia.org/wiki/Duhamel%27s_principle")[#text("Duhamel formula")]

#tao-aligned(keep: true)[


#tao-math("e^{t(H_0+V)}  & = e^{tH_0} + \\int_0^t e^{(t-s) H_0} V e^{s (H_0+V)}\\ ds", block: true)



#tao-math(" & = e^{tH_0} + \\int_0^t e^{(t-s) (H_0+V)} V e^{s H_0}\\ ds", block: true)
]

#text("where ")#mi("{e^A}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Matrix_exponential")[#text("matrix exponential")]#text(" of ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" Differentiate ")#mi("{e^{(t-s) H_0} e^{s (H_0+V)}}")#text(" or ")#mi("{e^{(t-s) (H_0+V)} e^{s H_0}}")#text(" in ")#mi("{s}")#text(".)")],
[#text("(ii) Establish the ")#emph[#text("iterated Duhamel formula")]

#align(center)[#tao-fit-display[#mitex("e^{t(H_0+V)} = e^{tH_0} + \\sum_{j=1}^k \\int_{0 \\leq t_1 \\leq \\dots \\leq t_j \\leq t}")]]

#align(center)[#tao-fit-display[#mitex("e^{(t-t_j) H_0} V e^{(t_j-t_{j-1}) H_0} V \\dots e^{(t_2-t_1) H_0} V e^{t_1 H_0}\\ dt_1 \\dots dt_j")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{0 \\leq t_1 \\leq \\dots \\leq t_{k+1} \\leq t}")]]

#align(center)[#tao-fit-display[#mitex("e^{(t-t_{k+1}) (H_0+V)} V e^{(t_{k+1}-t_k) H_0} V \\dots e^{(t_2-t_1) H_0} V e^{t_1 H_0}\\ dt_1 \\dots dt_{k+1}")]]

#text("for any ")#mi("{k \\geq 0}")#text(".")],
[#text("(iii) Establish the infinitely iterated Duhamel formula")

#align(center)[#tao-fit-display[#mitex("e^{t(H_0+V)} = e^{tH_0} + \\sum_{j=1}^\\infty \\int_{0 \\leq t_1 \\leq \\dots \\leq t_j \\leq t}")]]

#align(center)[#tao-fit-display[#mitex("e^{(t-t_j) H_0} V e^{(t_j-t_{j-1}) H_0} V \\dots e^{(t_2-t_1) H_0} V e^{t_1 H_0}\\ dt_1 \\dots dt_j.")]]],
[#text("(iv) If ")#mi("{H(t)}")#text(" is an ")#mi("{n \\times n}")#text(" matrix depending in a continuously differentiable fashion on ")#mi("{t}")#text(", establish the variation formula")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} e^{H(t)} = (F(\\mathrm{ad}(H(t))) H^{\\prime}(t)) e^{H(t)}")]]

#text("where ")#mi("{\\mathrm{ad}(H)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Sylvester_equation")[#text("adjoint representation")]#text(" ")#mi("{\\mathrm{ad}(H)(V) = HV - VH}")#text(" applied to ")#mi("{H}")#text(", and ")#mi("{F}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("F(z) := \\int_0^1 e^{sz}\\ ds")]]

#text("(thus ")#mi("{F(z) = \\frac{e^z-1}{z}}")#text(" for non-zero ")#mi("{z}")#text("), with ")#mi("{F(\\mathrm{ad}(H(t)))}")#text(" defined using ")#link("https://en.wikipedia.org/wiki/Functional_calculus")[#text("functional calculus")]#text(".")]
)
]

#text("We remark that further manipulation of (iv) of the above exercise using the fundamental theorem of calculus eventually leads to the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff-Dynkin formula")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("this previous blog post")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-73f177b7ff1237edfb41>#text(" Let ")#mi("{A, B}")#text(" be positive definite ")#mi("{n \\times n}")#text(" matrices, and let ")#mi("{Y}")#text(" be an ")#mi("{n \\times n}")#text(" matrix. Show that there is a unique solution ")#mi("{X}")#text(" to the ")#link("https://en.wikipedia.org/wiki/Sylvester_equation")[#text("Sylvester equation")]

#align(center)[#tao-fit-display[#mitex("AX + X B = Y")]]

#text("which is given by the formula")

#align(center)[#tao-fit-display[#mitex("X = \\int_0^\\infty e^{-tA} Y e^{-tB}\\ dt.")]]
]

#text("In the above examples we had applied the fundamental theorem of calculus along linear curves ")#mi("{\\gamma(t) = (1-t) x_0 + t x}")#text(". However, it is sometimes better to use other curves. For instance, the circular arc ")#mi("{\\gamma(t) = \\cos(\\pi t/2) x_0 + \\sin(\\pi t/2) x}")#text(" can be useful, particularly if ")#mi("{x_0}")#text(" and ")#mi("{x}")#text(" are “orthogonal” or “independent” in some sense; a good example of this is the proof by Maurey and Pisier of the gaussian concentration inequality, given in Theorem 8 of ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("this previous blog post")]#text(". In a similar vein, if one wishes to compare a scalar random variable ")#mi("{X}")#text(" of mean zero and variance one with a Gaussian random variable ")#mi("{G}")#text(" of mean zero and variance one, it can be useful to introduce the intermediate random variables ")#mi("{\\gamma(t) := (1-t)^{1/2} X + t^{1/2} G}")#text(" (where ")#mi("{X}")#text(" and ")#mi("{G}")#text(" are independent); note that these variables have mean zero and variance one, and after coupling them together appropriately they evolve by the ")#link("https://en.wikipedia.org/wiki/Ornstein%E2%80%93Uhlenbeck_process")[#text("Ornstein-Uhlenbeck process")]#text(", which has many useful properties. For instance, one can use these ideas to establish monotonicity formulae for entropy; see e.g. ")#link("https://people.eecs.berkeley.edu/~courtade/pdfs/monotonicityOfEntropy.pdf")[#text("this paper of Courtade")]#text(" for an example of this and further references. More generally, one can exploit curves ")#mi("{\\gamma}")#text(" that flow according to some geometrically natural ODE or PDE; several examples of this occur famously in Perelman’s proof of the Poincaré conjecture via Ricci flow, discussed for instance in ")#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("this previous set of lecture notes")]#text(".")

#text("In some cases, it is difficult to compute ")#mi("{F(x)-F(x_0)}")#text(" or the derivative ")#mi("{\\nabla F}")#text(" directly, but one can instead proceed by implicit differentiation, or some variant thereof. Consider for instance the matrix inversion map ")#mi("{F(A) := A^{-1}}")#text(" (defined on the open dense subset of ")#mi("{n \\times n}")#text(" matrices consisting of invertible matrices). If one wants to compute ")#mi("{F(B)-F(A)}")#text(" for ")#mi("{B}")#text(" close to ")#mi("{A}")#text(", one can write temporarily write ")#mi("{F(B) - F(A) = E}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("B^{-1} - A^{-1} = E.")]]

#text("Multiplying both sides on the left by ")#mi("{B}")#text(" to eliminate the ")#mi("{B^{-1}}")#text(" term, and on the right by ")#mi("{A}")#text(" to eliminate the ")#mi("{A^{-1}}")#text(" term, one obtains")

#align(center)[#tao-fit-display[#mitex("A - B = B E A")]]

#text("and thus on reversing these steps we arrive at the basic identity ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("B^{-1} - A^{-1} = B^{-1} (A - B) A^{-1}.")]]

#text("For instance, if ")#mi("{H_0, V}")#text(" are ")#mi("{n \\times n}")#text(" matrices, and we consider the ")#link("https://en.wikipedia.org/wiki/Resolvent_formalism")[#text("resolvents")]

#align(center)[#tao-fit-display[#mitex("R_0(z) := (H_0 - z I)^{-1}; \\quad R_V(z) := (H_0 + V - zI)^{-1}")]]

#text("then we have the ")#emph[#text("resolvent identity")]#text(" ")#metadata(none) <tao-21cd7e3e49cdad5ddde1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("R_V(z) - R_0(z) = - R_V(z) V R_0(z)")]]

#text("as long as ")#mi("{z}")#text(" does not lie in the spectrum of ")#mi("{H_0}")#text(" or ")#mi("{H_0+V}")#text(" (for instance, if ")#mi("{H_0}")#text(", ")#mi("{V}")#text(" are self-adjoint then one can take ")#mi("{z}")#text(" to be any strictly complex number). One can iterate this identity to obtain")

#align(center)[#tao-fit-display[#mitex("R_V(z) = \\sum_{j=0}^k (-R_0(z) V)^j R_0(z) + (-R_V(z) V) (-R_0(z) V)^k R_0(z)")]]

#text("for any natural number ")#mi("{k}")#text("; in particular, if ")#mi("{R_0(z) V}")#text(" has operator norm less than one, one has the ")#link("https://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]

#align(center)[#tao-fit-display[#mitex("R_V(z) = \\sum_{j=0}^\\infty (-R_0(z) V)^j R_0(z).")]]

#text("Similarly, if ")#mi("{A(t)}")#text(" is a family of invertible matrices that depends in a continuously differentiable fashion on a time variable ")#mi("{t}")#text(", then by implicitly differentiating the identity")

#align(center)[#tao-fit-display[#mitex("A(t) A(t)^{-1} = I")]]

#text("in ")#mi("{t}")#text(" using the product rule, we obtain")

#align(center)[#tao-fit-display[#mitex("(\\frac{d}{dt} A(t)) A(t)^{-1} + A(t) \\frac{d}{dt} A(t)^{-1} = 0")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} A(t)^{-1} = - A(t)^{-1} (\\frac{d}{dt} A(t)) A(t)^{-1}")]]

#text("(this identity may also be easily derived from ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("(6)")]#text("). One can then use the fundamental theorem of calculus to obtain variants of ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("(6)")]#text(", for instance by using the curve ")#mi("{\\gamma(t) = (1-t) A + tB}")#text(" we arrive at")

#align(center)[#tao-fit-display[#mitex("B^{-1} - A^{-1} = \\int_0^1 ((1-t)A + tB)^{-1} (A-B) ((1-t)A + tB)^{-1}\\ dt")]]

#text("assuming that the curve stays entirely within the set of invertible matrices. While this identity may seem more complicated than ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("(6)")]#text(", it is more symmetric, which conveys some advantages. For instance, using this identity it is easy to see that if ")#mi("{A, B}")#text(" are positive definite with ")#mi("{A>B}")#text(" in the sense of positive definite matrices (that is, ")#mi("{A-B}")#text(" is positive definite), then ")#mi("{B^{-1} > A^{-1}}")#text(". (Try to prove this using ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("(6)")]#text(" instead!)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" If ")#mi("{A}")#text(" is an invertible ")#mi("{n \\times n}")#text(" matrix and ")#mi("{u, v}")#text(" are ")#mi("{n \\times 1}")#text(" vectors, establish the ")#link("https://en.wikipedia.org/wiki/Sherman%E2%80%93Morrison_formula")[#text("Sherman-Morrison formula")]

#align(center)[#tao-fit-display[#mitex("(A + t uv^T)^{-1} = A^{-1} - \\frac{t}{1 + t v^T A^{-1} u} A^{-1} uv^T A^{-1}")]]

#text("whenever ")#mi("{t}")#text(" is a scalar such that ")#mi("{1 + t v^T A^{-1} u}")#text(" is non-zero. (See also ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous blog post")]#text(" for more discussion of these sorts of identities.)")
]

#text("One can use the Cauchy integral formula to extend these identities to other functions of matrices. For instance, if ")#mi("{F: {\\bf C} \\rightarrow {\\bf C}}")#text(" is an entire function, and ")#mi("{\\gamma}")#text(" is a counterclockwise contour that goes around the spectrum of both ")#mi("{H_0}")#text(" and ")#mi("{H_0+V}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("F(H_0+V) = \\frac{-1}{2\\pi i} \\int_\\gamma F(z) R_V(z)\\ dz")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("F(H_0) = \\frac{-1}{2\\pi i} \\int_\\gamma F(z) R_0(z)\\ dz")]]

#text("and hence by ")#link(<tao-21cd7e3e49cdad5ddde1>)[#text("(7)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("F(H_0+V) - F(H_0) = \\frac{1}{2\\pi i} \\int_\\gamma F(z) R_V(z) V F_0(z)\\ dz;")]]

#text("similarly, if ")#mi("{H(t)}")#text(" depends on ")#mi("{t}")#text(" in a continuously differentiable fashion, then")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} F(H(t)) = \\frac{1}{2\\pi i} \\int_\\gamma F(z) (H(t) - zI)^{-1} H^{\\prime}(t) (z) (H(t)-zI)^{-1}\\ dz")]]

#text("as long as ")#mi("{\\gamma}")#text(" goes around the spectrum of ")#mi("{H(t)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" If ")#mi("{H(t)}")#text(" is an ")#mi("{n \\times n}")#text(" matrix depending continuously differentiably on ")#mi("{t}")#text(", and ")#mi("{F: {\\bf C} \\rightarrow {\\bf C}}")#text(" is an entire function, establish the tracial chain rule")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\text{tr} F(H(t)) = \\text{tr}(F^{\\prime}(H(t)) H^{\\prime}(t)).")]]
]

#text("In a similar vein, given that the logarithm function is the antiderivative of the reciprocal, one can express the matrix logarithm ")#mi("{\\log A}")#text(" of a positive definite matrix by the fundamental theorem of calculus identity")

#align(center)[#tao-fit-display[#mitex("\\log A = \\int_0^\\infty (I + sI)^{-1} - (A + sI)^{-1}\\ ds")]]

#text("(with the constant term ")#mi("{(I+tI)^{-1}}")#text(" needed to prevent a logarithmic divergence in the integral). Differentiating, we see that if ")#mi("{A(t)}")#text(" is a family of positive definite matrices depending continuously on ")#mi("{t}")#text(", that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\log A(t) = \\int_0^\\infty (A(t) + sI)^{-1} A^{\\prime}(t) (A(t)+sI)^{-1}\\ dt.")]]

#text("This can be used for instance to show that ")#mi("{\\log}")#text(" is a monotone increasing function, in the sense that ")#mi("{\\log A> \\log B}")#text(" whenever ")#mi("{A > B > 0}")#text(" in the sense of positive definite matrices. One can of course integrate this formula to obtain some formulae for the difference ")#mi("{\\log A - \\log B}")#text(" of the logarithm of two positive definite matrices ")#mi("{A,B}")#text(".")

#text("To compare the square root ")#mi("{A^{1/2} - B^{1/2}}")#text(" of two positive definite matrices ")#mi("{A,B}")#text(" is trickier; there are multiple ways to proceed. One approach is to use contour integration as before (but one has to take some care to avoid branch cuts of the square root). Another to express the square root in terms of exponentials via the formula")

#align(center)[#tao-fit-display[#mitex("A^{1/2} = \\frac{1}{\\Gamma(-1/2)} \\int_0^\\infty (e^{-tA} - I) t^{-1/2} \\frac{dt}{t}")]]

#text("where ")#mi("{\\Gamma}")#text(" is the gamma function; this formula can be verified by first diagonalising ")#mi("{A}")#text(" to reduce to the scalar case and using the definition of the Gamma function. Then one has")

#align(center)[#tao-fit-display[#mitex("A^{1/2} - B^{1/2} = \\frac{1}{\\Gamma(-1/2)} \\int_0^\\infty (e^{-tA} - e^{-tB}) t^{-1/2} \\frac{dt}{t}")]]

#text("and one can use some of the previous identities to control ")#mi("{e^{-tA} - e^{-tB}}")#text(". This is pretty messy though. A third way to proceed is via implicit differentiation. If for instance ")#mi("{A(t)}")#text(" is a family of positive definite matrices depending continuously differentiably on ")#mi("{t}")#text(", we can differentiate the identity")

#align(center)[#tao-fit-display[#mitex("A(t)^{1/2} A(t)^{1/2} = A(t)")]]

#text("to obtain")

#align(center)[#tao-fit-display[#mitex("A(t)^{1/2} \\frac{d}{dt} A(t)^{1/2} + (\\frac{d}{dt} A(t)^{1/2}) A(t)^{1/2} = \\frac{d}{dt} A(t).")]]

#text("This can for instance be solved using Exercise ")#link(<tao-73f177b7ff1237edfb41>)[#text("5")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} A(t)^{1/2} = \\int_0^\\infty e^{-sA(t)^{1/2}} A^{\\prime}(t) e^{-sA(t)^{1/2}}\\ ds")]]

#text("and this can in turn be integrated to obtain a formula for ")#mi("{A^{1/2} - B^{1/2}}")#text(". This is again a rather messy formula, but it does at least demonstrate that the square root is a monotone increasing function on positive definite matrices: ")#mi("{A > B > 0}")#text(" implies ")#mi("{A^{1/2} > B^{1/2} > 0}")#text(".")

#text("Several of the above identities for matrices can be (carefully) extended to operators on Hilbert spaces provided that they are sufficiently well behaved (in particular, if they have a good functional calculus, and if various spectral hypotheses are obeyed). We will not attempt to do so here, however.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/073a8681d14dd9f42abc41efcade31f980ac704d2c4d315b82bd4c4d1db6f3e6-526ad05fd3a6eeb35594caac71c41663fceecfa4641b3570c1f796bf8c792056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Rayner")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481109")[#strong[#text("Jonathan Rayner")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")])]

#text("Friendly heads up: there’s a typo in part (i) of Ex 4: e^{t H_0} dropped after the second equality")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2017")])]

#text("Let ")#mi("A, B")#text(" be complex-valued, square matrices of the same dimension. Suppose that ")#mi("\\lambda_0")#text(" is a simple eigenvalue of ")#mi("A")#text(" with corresponding (unit) eigenvector ")#mi("v_0")#text(". It follows that the matrix ")#mi("A + t B")#text(" (where ")#mi("t")#text(" is a sufficiently small complex scalar parameter) has a unique eigenvalue ")#mi("\\lambda (t)")#text(" which is an (algebraic and) analytic function of ")#mi("t")#text(" such that ")#mi("\\lambda (0) = \\lambda_0")#text(". Similarly, ")#mi("A + t B")#text(" has a unique corresponding (unit) eigenvector ")#mi("v(t)")#text(" such that ")#mi("v(0) = v_0")#text(" whose components are (algebraic and) analytic functions of ")#mi("t")#text(".")#linebreak()#text(" Is it possible by the above methods to find explicit expressions for the Taylor coefficients of ")#mi("\\lambda (t)")#text(" and the components of ")#mi("v(t)")#text(" ?")

#emph[#text("[See the previous post ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481173")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("A number of political comments have been removed from this blog post as being off topic (see ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" ). Political comments may be left on the posts at ")#link("https://terrytao.wordpress.com/tag/politics/")[#text("https://terrytao.wordpress.com/tag/politics/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("Is there any real-valued function ")#mi("f")#text(" defined and monotonically increasing over some real interval ")#mi("I")#text("such that (unlike the examples above) it is not monotonically increasing over the set of Hermitian matrices with eigenvalues in ")#mi("I")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-482146")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("A counterexample is given in ")#link("https://math.stackexchange.com/questions/158315/how-do-i-determine-whether-a-function-is-operator-monotone-on-a-given-interval")[#text("https://math.stackexchange.com/questions/158315/how-do-i-determine-whether-a-function-is-operator-monotone-on-a-given-interval")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/419533eb9f6afef8b3d6666211611fb194ad2f82c5276569146371c8bb0a126d-b9f757769cedc335c07e2732cbd69df4b44234dd839b8a27a741428aa8e65993.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JJ")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481204")[#strong[#text("JJ")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("great post")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481216")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("In the second displayed formula below exercise 7, it seems that ")#mi("d t")#text(" should be ")#mi("d s")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Groul")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481297")[#strong[#text("Groul")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2017")])]

#text("Dear Mr. Tao,")

#text("What you think of the paper on Riemann H. by Bender et al. Can it be a promising approach?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481437")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2017")])]

#text("You might be interested in ")#link("https://arxiv.org/abs/1704.02644")[#text("https://arxiv.org/abs/1704.02644")]#text(" and ")#link("https://math.stackexchange.com/questions/2211278/riemann-hypothesis-is-bender-brody-m%c3%bcller-hamiltonian-a-new-line-of-attack")[#text("https://math.stackexchange.com/questions/2211278/riemann-hypothesis-is-bender-brody-m%c3%bcller-hamiltonian-a-new-line-of-attack")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-481788")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2017")])]

#text("Dear Terence Tao! Greatly impression your last article on r3(N), r4(N). Come new moment of ours mutual relations, because they in the making(start) mutually dependents(interconnect). If you propose collaboration, then how(what) you that yourself present? I think, what living intercourse perhaps to give more efficacious result, than electron correspondence. Thus, r3(N), r4(N), r5(N) no independents, and interrelations be tied up(with). If that interrelation classify on three categories of time, what receive: r3(N)- remote past history, r4(N)- history, present time, future tense, r5(N)- remote future tense. In result r4(N)- at the most perspective direction. With calculation of time absorbability factor, that five years(minimum) of laborious everyday work. In exercise 5 is mention Perelman’s proof of the Poincare conjecture via Ricci flow. That lighthouse of Perelman, which I disclose(I see) in level r3(N). Some prompting(voice of intuition): [smallness-uniformly continuous-smoothness of surface-ocean of smooth variety(s) or diversity(s)]. Welcome to ground floor tower of Erdesh r4(N) divisor=0,9998 I be able to give my address, if you resolve. Thanks! Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbd810e60b282bfb2775bd592c1180627ec342ab4fc7bca02052cf8331a94576-93235870fc8d3ed4c41b02b8454d5d2237e65cc1615ee5aa9a27cc4b14561d14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Czerno")]], [#link("https://terrytao.wordpress.com/2017/05/22/quantitative-continuity-estimates/#comment-482604")[#strong[#text("Czerno")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2017")])]

#text("Respectfully, typo / spelling note : it’s Fréchet (not Frechét).")

#emph[#text("[Corrected, thanks – T.]")]
]
