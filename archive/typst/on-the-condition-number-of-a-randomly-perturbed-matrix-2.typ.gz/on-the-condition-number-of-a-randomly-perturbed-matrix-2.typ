// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/
// Converted to Typst by tao2typ: "2026-10-14T11:22:33.487569+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the condition number of a randomly perturbed matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the condition number of a randomly perturbed matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/")[#text("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve ")#link("http://www.arxiv.org/")[#text("arXived ")]#text("the paper “")#link("http://arxiv.org/abs/math.PR/0703307")[#text("On the condition number of a randomly perturbed matrix")]#text("”, authored with ")#link("http://www.math.ucsd.edu/%7Evanvu/")[#text("Van Vu")]#text(", which will appear at ")#link("http://research.microsoft.com/research/theory/feige/homepagefiles/stoc07.htm")[#text("STOC 2007")]#text(". (This paper was actually finished and submitted several months ago, but for some reason I neglected to upload it to the arXiv until now.) Here we show that given an arbitrary ")#mi("n \\times n")#text(" matrix M with polynomially bounded entries (in particular, M could be highly singular), a random discrete perturbation M+N, where N is (say) a random Bernoulli ")#mi("\\pm 1")#text(" matrix, will have polynomially bounded ")#link("http://en.wikipedia.org/wiki/Condition_number")[#text("condition number")]#text(" with high probability (specifically, given any A there exists a B such that the condition number is ")#mi("O(n^B)")#text(" with probability ")#mi("1-O(n^{-A})")#text("). This is the discrete analogue of an analogous result by ")#link("http://www.ams.org/mathscinet-getitem?mr=1989210")[#text("Spielman and Teng")]#text(" for continuous random perturbations. The proof uses the inverse ")#link("http://en.wikipedia.org/wiki/Littlewood-Offord_problem")[#text("Littlewood-Offord")]#text(" technology as well as a discretisation lemma for generalized arithmetic progressions, both from ")#link("http://arxiv.org/abs/math.PR/0511215")[#text("our previous paper")]#text(" (which essentially addressed the M=0 case). It turns out that the effect of M is essentially just to add a few deterministic rows to a random matrix which one needs to obtain lower bounds for the least singular value.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MK")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-105")[#strong[#text("MK")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2007")])]

#text("There is an interesting (to some) random matrix problem that when scaled by sqrt{n} the empirical distribution of an n times n matrix A with i.i.d. complex valued entries with mean zero and unit variance, converges to uniform distribution on the unit disk (“Girko’s circular law” – the non-Hermitian analogue of Wigner’s semicircle law).")#linebreak()#text(" Bai has shown that the essential problem is to get a bound on the probability that (zI-A) has a small singular value(which has been done only under certain conditions on the distribution of the entries). A much weaker bound than the type that you have in this paper is needed. I wonder if your results don’t actually settle this problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-109")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2007")])]

#text("Dear MK, Thank you for the interesting suggestion, which we will look into! My co-author Van pointed out to me that there is some precedent for this type of connection: a ")#link("http://www.math.uni-bielefeld.de/sfb701/preprints/sfb07016.pdf")[#text("recent paper by Gotze and Tikhomirov")]#text(" uses (modifications of) some ")#link("http://www.math.missouri.edu/~rudelson/papers/square-matrix.pdf")[#text("earlier work of Rudelson")]#text(" on bounding the least singular value of random matrices to justify a circular law in certain cases. Our work does share many features in common with Rudelson’s work, including the treatment of various exceptional directions and the use of inverse Littlewood-Offord technology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54dd1583026134dc4e104ba0a453a466b557c4c7910304ce680dedcd5027035c-b656500dbdcb3cec3e0b384418f76cc54ffd06373cccba7cb58b7cd18cb7c075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van vu")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-110")[#strong[#text("van vu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2007")])]

#text("Dear MK,")

#text("Thanks for pointing it out. I have a quick look at a recent paper of Gotze and Tikhomirov and it seemed that our result can be applied directly to zI-A, and so one can skip")#linebreak()#text(" lots of calculations there.")

#text("There was another paper of Girko that we could not comprehend, about central limit theorem for the determinant of a random matrix (where the entries can have very general distributions, not just gaussians). Have you seen that ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-112")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2007")])]

#text("Dear all, There are many nice open problems around the random 0-1 matrices and connections to Sperner’s theorem and Littlewood-Offord. Here is one problem which might be the most bizarre:")

#text("let ")#mi("p_n(k)")#text(" be the probability that a random n by n 0-1 matrix has determinant equal to k. So ")#mi("p_n(0)")#text(" is exponentially small and ")#mi("p_n(k)")#text(" is probably even smaller when k is not zero. (maybe ")#mi("n^{-Kn}")#text(", this is interesting but not yet bizarre)")

#text("The question is if ")#mi("p_n(2)=o(p_n(1)).")

#text("Here are two heuristics in favor and against it.")

#text("Heuristic 1: the determinant as a sum of n! signed random product clearly behave smoothly. OK, ")#mi("p_n(0)")#text(" is sort of a singular value, but you can expect that ")#mi("p_n(i)")#text(" will be similar to ")#mi("p_n(j)")#text(" when ")#mi("i")#text(" and ")#mi("j")#text(" are small (in absolute value) (even just ")#mi("n^{o(n)}")#text(".) Certainly ")#mi("p_1(n)")#text(" and ")#mi("p_2(n)")#text(" are very close.")

#text("Apropos this. Jeff Kahn challenged to prove that for ")#mi("\\pm 1")#text(" n by n matrices the permanent is zero with probability o(1). There you can also expect smoothness of the probabilities (beside that obvious parity condition.)")

#text("Heuristic 2: what is the probability that det = 0 (mod p) for a prime p? Well, 0-1 matrices should behave like random matrix mod p with entries 0,1,,…,p-1. But there the answer (denote it ")#mi("s_p")#text("} is known:")#linebreak()#text(" it is this familiar infinite product. (Not too far from 1/p.)")

#text("The probability ")#mi("r_p")#text(" that a random such matrix has determinant 1 (mod p) is ")#mi("(1-s_k)/(p-1)")#text(".")

#text("Next we can assume that the behavior is independent for different primes. So you get the prediction that the probability for 0-1 matrices that det = 1 differ by a constant from the probability that det = a power of 2.")

#text("And the probability that ")#mi("\\det = 2^k")#text(" should perhaps be similar for different ")#mi("k = o(n\\log n)")#text(".")

#text("All in all ")#mi("p_n(2)")#text(" is smaller than ")#mi("p_n(1)")#text(" by a factor of n or ")#mi("n\\log n")#text(" or so.")

#text("And by this strange heuristic if |j| is not too large, ")#mi("p_n(j)")#text(" depends on how many prime factors ")#mi("j")#text(" has.")

#text("Heuristic 2 is rather dubious but perhaps enough to shed some doubts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54dd1583026134dc4e104ba0a453a466b557c4c7910304ce680dedcd5027035c-b656500dbdcb3cec3e0b384418f76cc54ffd06373cccba7cb58b7cd18cb7c075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vanvu")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-113")[#strong[#text("vanvu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")])]

#text("Dear Gil,")

#text("To me, Heuristic 2 looks like the situation with sieves in number theory. For very small")#linebreak()#text(" p, the independence look OK. But for relatively large p, it is quite wrong. If we do sieve the trivial way (before Brunn), the estimate was quite miserable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aac5b4c99d24c63255526cb280d7492ce1812851e6e640096596171322482d8-a985a96d968915a706745f0906bc6947adfc3f4a5c65e6601b41d87aeec1a839.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MK")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-117")[#strong[#text("MK")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")])]

#text("Dear Vu and Tao, Gotze and Tikhomirov apparently need Gaussian tails for the entries, so one point of interest would be to remove all such assumptions (Bai has a Lindeberg type condition to reduce the circular law problem to one of estimating smallest singular values and perhaps there should be no more assumptions on the entries at all?).")#linebreak()#text(" I do not know which paper of Girko you refer to, but his claimed proofs of circular law are incomplete as he skips over this issue of small singular values of ZI-A. There are also some other nonHermitian random matrix problems which were held up by this issue so far and should be accessible now (assuming there is no catch in extending your result to complex matrices).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb3ecdff714503271026e0b788f5d9f0b35183404929d38dc5c98c28bd3ea1a0-3844e5e2796c13322d5df07501a83d5f79a96168c262f95a485f2b8e6122ee95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vanvu")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-118")[#strong[#text("vanvu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")])]

#text("Dear MK,")

#text("If I understand well, there is a standard machinery to reduce the CL to the problem of estimating the smallest singular value. If it is true, then what would be the most general assumption for which this machinery works ? (Then we just have to check whether our result still hold under that assumption; it is certainly hold for complex entries.)")

#text("Btw, can we know your full name ? (You can send private email to us if not want to disclose it here).")

#text("Thanks, Van Vu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aac5b4c99d24c63255526cb280d7492ce1812851e6e640096596171322482d8-a985a96d968915a706745f0906bc6947adfc3f4a5c65e6601b41d87aeec1a839.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjunath Krishnapur")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-122")[#strong[#text("Manjunath Krishnapur")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2007")])]

#text("The machinery for reducing CL to estimating small singular values is in Bai’s 1997 paper “Circular law” (Ann. Probab.) The recent book of Bai and Silverstein seems to say that the weakest known condition is (A is the ")#mi("n \\times n")#text(" random matrix)")

#tao-math("n^{-2}  \\sum_{i,j} E[ \\left|A_{ij}\\right|^{2+s} ; \\left|A_{ij}\\right|>n^t ]  \\to 0", block: false)

#text("for any t>0 and some s>0. (page 326, “Spectral analysis of large dimensional random matrices”).")#linebreak()#text(" And thanks for confirming that your theorems remain valid for complex matrices!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-123")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2007")])]

#text("Dear all. Thanks for your comment, Van. Sure, if Heuristic 2 can be improved a la Brunn this is even better. I suppose my question is whether the probability that an n by n matrix with entries 0/1 (or plus or minus one,) has determinant equal to k, depends in a strong way on the arithmetic of k. Heuristic 2 suggests that this IS the case and this is an appealing conjecture simply because it will be more interesting.")

#text("For matrices with entries plus or minus one I would expect the probability for the permanent to be equal to 2k behave very smoothly for k, like the probability of a length n! random walk from the origin landing in location 2k. But for determinants the heuristic will suggest a very different and nicer picture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of STOC talk: The condition number of a randomly perturbed matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2007/03/12/on-the-condition-number-of-a-randomly-perturbed-matrix-2/#comment-2106")[#strong[#text("STOC talk: The condition number of a randomly perturbed matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2007")])]

#text("[…] with Van Vu on the condition number of randomly perturbed matrices, which was the subject of an earlier post on this blog. For this short talk (20 minutes), Van and I prepared some slides; of course, in such a short time […]")
]
