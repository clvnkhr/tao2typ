// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/
// Converted to Typst by tao2typ: "2026-10-14T15:16:23.290901+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: boundedness of the trilinear Hilbert transform", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: boundedness of the trilinear Hilbert transform")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/")[#text("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a well-known problem in multilinear harmonic analysis; it is fascinating to me because it lies barely beyond the reach of the best technology we have for these problems (namely, multiscale time-frequency analysis), and because the most recent developments in quadratic Fourier analysis seem likely to shed some light on this problem.")

#text("Recall that the ")#link("http://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(" is defined on test functions ")#mi("f \\in {\\mathcal S}({\\Bbb R})")#text(" (up to irrelevant constants) as")

#align(center)[#tao-fit-display[#mitex("Hf(x) := p.v. \\int_{\\Bbb R} f(x+t) \\frac{dt}{t},")]]

#text("where the integral is evaluated in the principal value sense (removing the region ")#tao-math("\\left|t\\right| < \\epsilon", block: false)#text(" to ensure integrability, and then taking the limit as ")#mi("\\epsilon \\to 0")#text(".)")

#metadata(none) <tao-681a96af623ecb701dac>#text("One of the basic results in (linear) harmonic analysis is that the Hilbert transform is bounded on ")#mi("L^p({\\Bbb R)}")#text(" for every ")#mi("1 < p < \\infty")#text(", thus for each such p there exists a finite constant ")#mi("C_p")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Hf \\right\\|_{L^p({\\Bbb R})} \\leq C_p \\left\\|f\\right\\|_{L^p({\\Bbb R})}.", block: true)]]

#text("One can view boundedness result (which is of importance in complex analysis and one-dimensional Fourier analysis, while also providing a model case of the more general ")#text("Calderón")#text("-Zygmund theory of singular integral operators) as an assertion that the Hilbert transform is “not much larger than” the identity operator. And indeed the two operators are very similar; both are invariant under translations and dilations, and on the Fourier side, the Hilbert transform barely changes the magnitude of the Fourier transform at all:")

#align(center)[#tao-fit-display[#mitex("\\hat{Hf}(\\xi) = \\pi i \\text{sgn}(\\xi) \\hat f(\\xi).")]]

#text("In fact, one can show the only reasonable (e.g. ")#mi("L^2")#text("-bounded) operators which are invariant under translations and dilations are just the linear combinations of the Hilbert transform and the identity operator. (A useful heuristic in this area is to view the singular kernel ")#mi("p.v. 1/t")#text(" as being of similar “strength” to the ")#link("http://en.wikipedia.org/wiki/Dirac_delta_function")[#text("Dirac delta function")]#text(" ")#mi("\\delta(t)")#text(" – for instance, they have same scale-invariance properties.)")

#text("Note that the Hilbert transform is formally a convolution of f with the kernel ")#mi("1/t")#text(". This kernel is almost, but not quite, absolutely integrable – the integral of ")#tao-math("1/\\left|t\\right|", block: false)#text(" diverges logarithmically both at zero and at infinity. If the kernel was absolutely integrable, then the above ")#mi("L^p")#text(" boundedness result would be a simple consequence of ")#link("http://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s inequality")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Minkowski_inequality")[#text("Minkowski’s inequality")]#text("); the difficulty is thus “just” one of avoiding a logarithmic divergence. To put it another way, if one dyadically decomposes the Hilbert transform into pieces localised at different scales (e.g. restricting to an “annulus” ")#tao-math("\\left|t\\right| \\sim 2^n", block: false)#text("), then it is a triviality to establish boundedness of each component; the difficulty is ensuring that there is enough cancellation or orthogonality that one can sum over the (logarithmically infinite number of) scales and still recover boundedness.")

#text("There are a number of ways to establish boundedness of the Hilbert transform. One way is to decompose all functions involved into ")#link("http://en.wikipedia.org/wiki/Wavelet")[#text("wavelets")]#text(" – functions which are localised in space and scale, and whose frequencies stay at a fixed distance from the origin (relative to the scale). By using standard estimates concerning how a function can be decomposed into wavelets, how the Hilbert transform acts on wavelets, and how wavelets can be used to reconstitute functions, one can establish the desired boundedness. The use of wavelets to mediate the action of the Hilbert transform fits well with the two symmetries of the Hilbert transform (translation and scaling), because the collection of wavelets also obeys (discrete versions of) these symmetries. One can view the theory of such wavelets as a dyadic framework for ")#text("Calderón")#text("-Zygmund theory.")

#text("Just as the Hilbert transform behaves like the identity, it was conjectured by ")#text("Calderón (motivated by the study of the Cauchy integral on Lipschitz curves)")#strong[#text(" ")]#text("that the ")#emph[#text("bilinear Hilbert transform")]

#align(center)[#tao-fit-display[#mitex("B(f,g)(x) := p.v. \\int_{\\Bbb R} f(x+t) g(x+2t) \\frac{dt}{t}")]]

#text("would behave like the pointwise product operator ")#mi("f, g \\mapsto fg")#text(" (exhibiting again the analogy between ")#mi("p.v. 1/t")#text(" and ")#mi("\\delta(t)")#text("), in particular one should have the ")#link("http://en.wikipedia.org/wiki/Holder%27s_inequality")[#text("Hölder")]#text("-type inequality")

#align(center)[#tao-math("\\left\\| B(f,g) \\right\\|_{L^r({\\Bbb R})} \\leq C_{p,q} \\left\\|f\\right\\|_{L^p({\\Bbb R})} \\left\\|g\\right\\|_{L^q({\\Bbb R})}", block: false)#text(" (*)")]

#text("whenever ")#mi("1 < p,q < \\infty")#text(" and ")#mi("\\frac{1}{r} = \\frac{1}{p} + \\frac{1}{q}")#text(". (There is nothing special about the “2” in the definition of the bilinear Hilbert transform; one can replace this constant by any other constant except for 0, 1, or infinity, though it is a delicate issue to maintain good control on the constant ")#mi("C_{p,q}")#text(" in that case. Note that by setting g=1 and looking at the limiting case ")#mi("q=\\infty")#text(" we recover the linear Hilbert transform theory from the bilinear one, thus we expect the bilinear theory to be harder.) Again, this claim is trivial when localising to a single scale ")#tao-math("\\left|t\\right| \\sim 2^n", block: false)#text(", as it can then be quickly deduced from Hölder’s inequality. The difficulty is then to combine all the scales together.")

#text("It took some time to realise that ")#text("Calderón")#text("-Zygmund theory, despite being incredibly effective in the linear setting, was not the right tool for the bilinear problem. One way to see the problem is to observe that the bilinear Hilbert transform B (or more precisely, the estimate (*)) enjoys one additional symmetry beyond the scaling and translation symmetries that the Hilbert transform H obeyed. Namely, one has the")#emph[#text(" modulation invariance")]

#align(center)[#tao-fit-display[#mitex("B( e_{-2\\xi} f, e_\\xi g ) = e_{-\\xi} B(f,g)")]]

#text("for any frequency ")#mi("\\xi")#text(", where ")#mi("e_{\\xi}(x)   := e^{2\\pi i \\xi x}")#text(" is the linear plane wave of frequency ")#mi("\\xi")#text(", which leads to a modulation symmetry for the estimate (*). This symmetry – which has no non-trivial analogue in the linear Hilbert transform – is a consequence of the algebraic identity")

#align(center)[#tao-fit-display[#mitex("\\xi x - 2\\xi (x+t) + \\xi (x+2t) = 0")]]

#text("which can in turn be viewed as an assertion that linear functions have a vanishing second derivative.")

#text("It is a general principle that if one wants to establish a delicate estimate which is invariant under some non-compact group of symmetries, then the ")#emph[#text("proof ")]#text("of that estimate should also be largely invariant under that symmetry (or, if it does eventually decide to break the symmetry (e.g. by performing a normalisation), it should do so in a way that will yield some tangible profit). ")#text("Calderón")#text("-Zygmund theory gives the frequency origin ")#mi("\\xi = 0")#text(" a preferred role (for instance, all wavelets have mean zero, i.e. their Fourier transforms vanish at the frequency origin), and so is not the appropriate tool for any modulation-invariant problem.")

#text("The conjecture of ")#text("Calderón")#text(" was finally verified in a breakthrough ")#link("http://www.ams.org/mathscinet-getitem?mr=1491450")[#text("pair")]#text(" of ")#link("http://www.ams.org/mathscinet-getitem?mr=1689336")[#text("papers")]#text(" by Lacey and Thiele, first in the “easy” region ")#mi("2 < p,q,r^{\\prime} < \\infty")#text(" (in which all functions are locally in ")#mi("L^2")#text(" and so local Fourier analytic methods are particularly tractable) and then in the significantly larger region where ")#mi("r > 2/3")#text(". (Extending the latter result to ")#mi("r=2/3")#text(" or beyond remains open, and can be viewed as a toy version of the trilinear Hilbert transform question discussed below.) The key idea (dating back to Fefferman) was to replace the wavelet decomposition by a more general ")#emph[#text("wave packet ")]#text("decomposition – wave packets being functions which are well localised in position, scale, and frequency, but are more general than wavelets in that their frequencies do not need to hover near the origin; in particular, the wave packet framework enjoys the same symmetries as the estimate that one is seeking to prove. (As such, wave packets are a highly overdetermined basis, in contrast to the exact bases that wavelets offers, but this turns out to not be a problem, provided that one focuses more on decomposing the ")#emph[#text("operator ")]#text("B rather than the individual functions f,g.) Once the wave packets are used to mediate the action of the bilinear Hilbert transform B, Lacey and Thiele then used a carefully chosen combinatorial algorithm to organise these packets into “trees” concentrated in mostly disjoint regions of phase space, applying (modulated) ")#text("Calderón")#text("-Zygmund theory to each tree, and then using orthogonality methods to sum the contributions of the trees together. (The same method ")#link("http://www.ams.org/mathscinet-getitem?mr=1783613")[#text("also leads to")]#text(" the simplest proof known of ")#link("http://www.ams.org/mathscinet-getitem?mr=199631")[#text("Carleson’s celebrated theorem")]#text(" on convergence of Fourier series.)")

#text("Since the Lacey-Thiele breakthrough, there has been a flurry of other papers (including some that I was involved in) extending the time-frequency method to many other types of operators; all of these had the characteristic that these operators were invariant (or “morally” invariant) under translation, dilation, and some sort of modulation; this includes a number of operators of interest to ergodic theory and to nonlinear scattering theory. However, in this post I want to instead discuss an operator which does not lie in this class, namely the ")#emph[#text("trilinear Hilbert transform")]

#align(center)[#tao-fit-display[#mitex("T(f,g,h)(x) := p.v. \\int_{\\Bbb R} f(x+t) g(x+2t) h(x+3t) \\frac{dt}{t}.")]]

#text("Again, since we expect ")#mi("p.v. 1/t")#text(" to behave like ")#mi("\\delta(t)")#text(", we expect the trilinear Hilbert transform to obey a Hölder-type inequality")

#align(center)[#tao-math("\\left\\| T(f,g,h) \\right\\|_{L^s({\\Bbb R})} \\leq C_{p,q,r} \\left\\|f\\right\\|_{L^p({\\Bbb R})} \\left\\|g\\right\\|_{L^q({\\Bbb R})} \\left\\|h\\right\\|_{L^r({\\Bbb R})}", block: false)#text(" (**)")]

#text("whenever ")#mi("1 < p,q,r < \\infty")#text(" and ")#mi("\\frac{1}{s} = \\frac{1}{p} + \\frac{1}{q} + \\frac{1}{r}")#text(". This conjecture is currently unknown for any exponents p,q,r – even the case p=q=r=4, which is the “easiest” case by symmetry, duality and interpolation arguments. The main new difficulty is that in addition to the three existing invariances of translation, scaling, and modulation (actually, modulation is now a two-parameter invariance), one now also has a ")#emph[#text("quadratic modulation invariance")]

#align(center)[#tao-fit-display[#mitex("T( q_{-3\\xi} f, q_{3\\xi} g, q_{-\\xi} h ) = q_{-\\xi} T(f,g,h)")]]

#text("for any “quadratic frequency” ")#mi("\\xi")#text(", where ")#mi("q_{\\xi}(x)  := e^{2\\pi i \\xi x^2}")#text(" is the quadratic plane wave of frequency ")#mi("\\xi")#text(", which leads to a quadratic modulation symmetry for the estimate (**). This symmetry is a consequence of the algebraic identity")

#align(center)[#tao-fit-display[#mitex("\\xi x^2 - 3\\xi (x+t)^2 + 3\\xi (x+2t) ^2 - \\xi (x+3t)^2= 0")]]

#text("which can in turn be viewed as an assertion that quadratic functions have a vanishing third derivative.")

#text("It is because of this symmetry that time-frequency methods based on Fefferman-Lacey-Thiele style wave packets seem to be ineffective (though the failure is very slight; one can control entire “forests” of trees of wave packets, but when summing up all the relevant forests in the problem one unfortunately encounters a logarithmic divergence; also, it is known that if one ignores the sign of the wave packet coefficients and only concentrates on the magnitude – which one can get away with for the bilinear Hilbert transform – then the associated trilinear expression is in fact divergent). Indeed, wave packets are certainly not invariant under quadratic modulations. One can then hope to work with the next obvious generalisation of wave packets, namely the “chirps” – quadratically modulated wave packets – but the combinatorics of organising these chirps into anything resembling trees or forests seems to be very difficult. Also, recent work in the additive combinatorial approach to Szemerédi’s theorem (as well as in the ergodic theory approaches) suggests that these quadratic modulations might not be the only obstruction, that other “2-step nilpotent” modulations may also need to be somehow catered for. Indeed I suspect that some of the modern theory of Szemerédi’s theorem for progressions of length 4 will have to be invoked in order to solve the trilinear problem. (Again based on analogy with the literature on Szemerédi’s theorem, the problem of quartilinear and higher Hilbert transforms is likely to be significantly more difficult still, and thus not worth studying at this stage.)")

#text("This problem may be too difficult to attack directly, and one might look at some easier model problems first. One that was already briefly mentioned above was to return to the bilinear Hilbert transform and try to establish an endpoint result at r=2/3. At this point there is again a logarithmic failure of the time-frequency method, and so one is forced to hunt for a different approach. Another is to look at the bilinear maximal operator")

#align(center)[#tao-fit-display[#mitex("M(f,g)(x) := sup_{r > 0} \\frac{1}{2r} \\int_{-r}^r f(x+t) g(x+2t) dt")]]

#text("which is a bilinear variant of the Hardy-Littlewood maximal operator, in much the same way that the bilinear Hilbert transform is a variant of the linear Hilbert transform. It was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=1745019")[#text("by Lacey")]#text(" that this operator obeys most of the bounds that the bilinear Hilbert transform does, but the argument is rather complicated, combining the time-frequency analysis with some Fourier-analytic maximal inequalities ")#link("http://www.ams.org/mathscinet-getitem?mr=1037434")[#text("of Bourgain")]#text(". In particular, despite the “positive” (non-oscillatory) nature of the maximal operator, the only known proof of the boundedness of this operator is oscillatory. It is thus natural to seek a “positive” proof that does not require as much use of oscillatory tools such as the Fourier transform, in particular it is tempting to try an additive combinatorial approach. Such an approach has had some success with a slightly easier operator in a similar spirit, in an unpublished paper ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/maximal.dvi")[#text("of Demeter, Thiele, and myself")]#text(". There is also a ")#link("http://www.ams.org/mathscinet-getitem?mr=1825259")[#text("paper of Christ")]#text(" in which a different type of additive combinatorics (coming, in fact, from ")#link("http://www.ams.org/mathscinet-getitem?mr=1739220")[#text("work on the Kakeya problem")]#text(") was used to establish a non-trivial estimate for single-scale model of various multilinear Hilbert transform or maximal operators. If these operators are understood better, then perhaps additive combinatorics can be used to attack the trilinear maximal operator, and thence to the trilinear Hilbert transform. (This trilinear maximal operator, incidentally, has some applications to pointwise convergence of multiple averages in ergodic theory.)")

#text("Another, rather different, approach would be to work in the “finite field model” in which the underlying field ")#mi("{\\Bbb R}")#text(" is replaced by a Cantor ring ")#mi("\\overline{F(t)}")#text(" of formal Laurent series over a finite field F; in such “dyadic models” the analysis is known to be somewhat simpler (in large part because in this non-Archimedean setting it now becomes possible to create wave packets which are localised in both space and frequency). Nazarov has an unpublished proof of the boundedness of the bilinear Hilbert transform in characteristic 3 settings based on a Bellman function approach; it may be that one could achieve something similar over the field of 4 elements for (a suitably defined version of) the trilinear Hilbert transform. This would at least give supporting evidence for the analogous conjecture in ")#mi("{\\Bbb R}")#text(", although it looks unlikely that a positive result in the dyadic setting would have a ")#emph[#text("direct")]#text(" impact on the continuous one.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-1045")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2007")])]

#text("While quite far from my own research I find this problem and posting very interesting for the following reasons. First, shortly after the Calderon conjecture was proved I heard a talk about it by Chris Thiele at the HU colloquium which (to my surprise) I could follow and enjoy. (And even find there was some combinatorics.) Second, at a later time Rafi Coifman gave me the Lacey-Thiele theorem as an example how concepts and ideas from applied mathematics interlace and influence the study of classical pure math problem. (This aspect of the (even wider) story is something I will be happy to learn more about.) Third, I always wondered if Carleson’s theorem could ever be “industrialized”. (This is a fancy way to the ask if we can hope for a proof that can (really) be presented at class.) I do not know if the Lacey-Thiele proof quite get there but it is certainly in this direction. And, the analogy with Szemeredi theorem is intruiging.")

#text("Is there a quick reference/link for an easy proof for the boundedness of Hilbert transform, especially the proof using wavelets?")

#text("Regarding the analogy with Szemeredi’s theorem. Are wavelets or something similar useful there? Is there a way to think about the Roth case (or its improved versions) as related to a large spanning class of functions like wavelets?")

#text("I remember that various people (e.g. Eli Shamir) raised the idea that appropriate notion of wavelets can be useful to improve known results and find further results in places were Fourier analysis applies to combinatorics, (mainly Fourier analysis over the discrete cube, or products of fixed graphs); but I am not aware of some nice definitions/applications. In particular, I do not know what wavelets are in these contexts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-1046")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2007")])]

#text("Dear Gil,")#linebreak()#text(" Good questions! I may need several responses to answer all of them.")#linebreak()#text(" Coifman actually has a nice principle connecting pure and applied analysis: given any operator T, there is a positive correlation between T being tractable to estimate in pure analysis, and T having an efficiently computable representation for applied analysis purposes. The point is that the representations which allow T to be computed quickly, tend to also be the representations which allow one to analyse T efficiently, and vice versa.")#linebreak()#text(" For instance, suppose one wanted to compute the discrete Hilbert transform Hf of a function f on an N point set (e.g. the cyclic group Z/NZ). A naive computation of Hf would take O(N^2) computations, but by using either the Fourier representation or the wavelet representation (and using the FFT or FWT) one cuts this down to O(N log N).")#linebreak()#text(" For the bilinear Hilbert transform B, discretised to Z/NZ, I don’t know of a way to compute B(f,g) for given f,g which is any faster than O(N^2) steps. However, given f, g, h, one can compute the inner product ")#mi("\\int B(f,g) h")#text(" in something like O( N log N ) steps by using wave packets; roughly speaking, there is a representation of the form")#linebreak()#text(" ")#tao-math("\\int B(f,g) h = \\sum_P \\left|I_P\\right|^{1/2} \\langle f, \\phi_{1,P} \\rangle \\langle g, \\phi_{2,P} \\rangle \\langle h, \\phi_{3,P} \\rangle", block: false)#linebreak()#text(" where P ranges over all Heisenberg tiles (dyadic rectangles in phase space with area ")#tao-math("\\left|I_P\\right| \\left|\\omega_P\\right| = 1", block: false)#text("), ")#tao-math("\\left|I_P\\right|", block: false)#text(" is the spatial width of P, and ")#mi("\\phi_{1,P}, \\phi_{2,P}, \\phi_{3,P}")#text(" are (")#mi("L^2")#text("-normalised) wave packets which are essentially localised in phase space to P. There are about O(N log N) of these tiles, and the above inner products can all be computed by an FFT-like algorithm in O(N log N) time. (The FFT performs O(N log N) computations but only retains N of the numbers computed as the Fourier transform. If instead one saves all of the O(N log N) numbers that one computes, one essentially obtains the wave packet transform.) In accordance with Coifman’s principle, the above representation is precisely what Lacey and Thiele need to control the bilinear Hilbert transform properly.")#linebreak()#text(" No such efficient representation (better than O(N^2)) is known for the trilinear Hilbert transform; finding a fast representation here may be the key to this problem.")#linebreak()#text(" There is a “finite field”, “single scale” model which might be more tractable for this latter problem. Let G be a finite group (whose order is coprime to 2 and 3). If one is given three functions ")#mi("f,g,h: G \\to {\\Bbb C}")#text(" and one wants to compute (exactly) the expression")#linebreak()#text(" ")#mi("\\sum_{x,r \\in G} f(x) g(x+r) h(x+2r)")#linebreak()#text(" then by using the FFT one can achieve this in O( |G| log |G| ) computations. But what if one is given four functions ")#mi("f,g,h,k: G \\to {\\Bbb C}")#text(" and wants to compute")#linebreak()#text(" ")#mi("\\sum_{x,r \\in G} f(x) g(x+r) h(x+2r) k(x+3r)")#text("?")#linebreak()#text(" I know of no way to compute this in fewer than ")#tao-math("O( \\left|G\\right|^2 )", block: false)#text(" computations, even for nice groups G such as ")#mi("G = {\\Bbb F}_5^n")#text(". A faster algorithm to compute this expression exactly may be very useful to the trilinear Hilbert transform problem, by suggesting the “correct” way to represent that transform.")#linebreak()#text(" There is an analogous problem for the Gowers norms; the FFT allows one to compute the ")#mi("U^2(G)")#text(" norm of f in O( |G| log |G| ) steps, but the fastest I can compute the ")#mi("U^3(G)")#text(" norm in is ")#tao-math("O( \\left|G\\right|^2 \\log \\left|G\\right| )", block: false)#text(" steps (by using the recursive formula connecting each Gowers norm to its predecessor). Is there a faster way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-1047")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2007")])]

#text("The Lacey-Thiele proof Carleson’s theorem can be presented in a graduate harmonic analysis class in a handful of lectures. It is “simple” modulo knowing all the modern machinery of harmonic analysis (Calderon-Zygmund theory, Littlewood-Paley theory, interpolation theory, and the uncertainty principle). Things are a little simpler in a “finite field” model, in which the real line is replaced by the Walsh-Cantor group ")#mi("{\\Bbb W}_2 := \\overline{{\\Bbb F}_2(t)}")#text(". See for instance ")#link("http://www.math.ucla.edu/%7Etao/254a.1.01w/")[#text("my lecture notes on these topics")]#text(".")

#text("Wavelets appear in harmonic analysis due to the role of ")#emph[#text("scale")]#text(", which is largely absent in additive combinatorics, and in particular in Szemeredi’s theorem. In Szemeredi’s theorem there is essentially no distinction made between an arithmetic progression of small step and an arithmetic progression of large step, thus there is no need to treat these two scales separately (and indeed, since there are so many more large steps than small steps, the net contribution of the small steps is negligible compared to the large). But in things like the Hilbert transforms, the presence of the 1/t factor in the integral causes the small scales to be elevated to be of “equal strength” to the large scales, and so they have to be treated separately. Wavelets are a good way to separate the fine-scale and coarse-scale behaviours from each other. Wave packets are generalisations of wavelets which also capture frequency information, indeed the (overdetermined) wave packet basis contains both the wavelet basis and the Fourier basis as subsets.")

#text("So, in summary, I would only expect wavelet-type tools to be useful in “multiscale” situations in which one needs to treat fine-scale and coarse-scale oscillations separately.")

#text("As to the “easy” proof of the boundedness of the Hilbert transform using wavelets, this is a little trickier to answer; again, this result is easy only modulo a certain amount of standard wavelet theory. Roughly speaking, the main tool is the Littlewood-Paley inequality for wavelets")

#tao-math("\\left\\|f\\right\\|_{L^p} \\sim_p \\left\\| (\\sum_{j,k} \\left|\\langle f, \\psi_{j,k} \\rangle \\psi_{j,k}\\right|^2)^{1/2} \\right\\|_{L^p}", block: false)

#text("which asserts in particular that the ")#mi("L^p")#text(" norm of a function f is controlled by the magnitude of the wavelet coefficients ")#mi("\\langle f, \\psi_{j,k} \\rangle")#text(", but is insensitive to the phase. In the wavelet basis, the Hilbert transform is almost a diagonal operator; it alters the phase of the wavelet coefficients, and also mixes some nearby wavelet coefficients together, but does not significantly affect the magnitude of these coefficients. Making this precise, one can easily deduce the boundedness of the Hilbert transform (and many other operators) from the above inequality (plus some other useful tools, such as the Fefferman-Stein maximal inequality). The proof of the Littlewood-Paley inequality is not too difficult, but is basically a fancy version of the standard arguments used to establish boundedness of the Hilbert transform. Thus if boundedness of the Hilbert transform was your only goal, this would not be the most efficient way to establish it; but if one was interested in treating systematically a large class of operators by a single theory, this is a good approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-1061")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2007")])]

#text("Thanks, Terry")

#text("You wrote: “In Szemeredi’s theorem there is essentially no distinction made between an arithmetic progression of small step and an arithmetic progression of large step, thus there is no need to treat these two scales separately (and indeed, since there are so many more large steps than small steps, the net contribution of the small steps is negligible compared to the large).”")

#text("Is what you wrote a characteristic of Szemeredi’s theorem or rather of its proofs? (We can talk just about Roth’s theorem or the analogous problem for bounds for cap sets.) We will be happy to find a 3-term AP of any step; For the analysis in the present proofs AP with small steps are negligebale. Couldn’t it give an advantage to consider kernels which introduce delicate multi scale situations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-1068")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2007")])]

#text("Dear Gil,")#linebreak()#text(" This is possible, but I think it is unlikely (at least if one uses “naive” notions of scale) because it doesn’t seem to be compatible with the symmetries of the problem. For instance, in Z/pZ, the statement of Szemeredi’s theorem is invariant under any dilation by an invertible element of the field Z/pZ. Thus, there is no reason to give small steps (i.e. steps r in an interval such as {1,…,R}) any more privileged role than steps in a dilated interval such as ")#mi("\\{ \\lambda, 2\\lambda, \\ldots, R\\lambda \\}")#text(". This observation was used by Varnavides to show that once Szemeredi’s theorem is proven for a small interval, it automatically holds for a large interval as well, and furthermore provides a positive density family of arithmetic progressions in that larger interval.")#linebreak()#text(" That said, though, there is certainly a lot of scope for utilising ")#emph[#text("adaptive")]#text(" notions of scale, tailored to the set or function that one is seeking arithmetic progressions inside. Indeed, the known proofs of Roth and Szemeredi all do this in one way or another. For instance, to find arithmetic progressions of length 3 inside a set A in Z/pZ, one can first look for a large Fourier coefficient ")#mi("\\hat 1_A(\\xi)")#text(". If there is no such large Fourier coefficient, then we “win”; if instead we find a frequency ")#mi("\\xi")#text(" where things are large, we can use that frequency to determine a “scale” (we can give each element x in Z/pZ a “norm”, defined as the distance of ")#mi("x\\xi/p")#text(" to the nearest integer). We can then pass to a smaller scale (i.e. to a Bohr set generated by ")#mi("\\xi")#text("), and this is the heart of the original “density-incremented” proof of Roth’s theorem. Or we can then go and hunt for more types of scales to capture as much of the global structure of A as one can, until we have so much control that it becomes “obvious” that there are lots of progressions; this brings us closer to the more “ergodic” or “energy-incremented” proofs of Roth’s theorem, or to the hybrid energy+density increment proofs of Heath-Brown and Szemeredi.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/720aed7977eabb513bcfa8d2f168f738626f5329177dedf87e20c0d34ca9e0fd-d3dfabca8ec9873e8ccfe696341cc3090c1419f47e4101dd83a183d830836989.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cowgonemad")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-5033")[#strong[#text("cowgonemad")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2007")])]

#text("Dear Terry,")

#text("I am wondering. Is there some analog of the bilinear Hilbert transform on the unit circle? I know that the theory of the linear Hilbert transform works just fine there … If one would take a function on the unit circle as a periodic one on ")#mi("\\mathbb{R}")#text(", one would have that these are no longer in any ")#mi("L^p, p < \\infty")#text(", which is also kind of bad.")

#text("Best,")#linebreak()#text(" Helge")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-5036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2007")])]

#text("Dear Helge,")

#text("There is a general transference principle of Marcinkeiwicz and Zygmund which allows one to equate estimates on the real line which enjoy certain scale invariance and translation invariance properties, with their counterparts on the unit circle. For instance, there is a natural analogue of the estimates the bilinear Hilbert transform on the unit circle (basically, replace ")#mi("{\\Bbb R}")#text(" by ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" throughout, identifying the torus with ")#mi("(-1/2,1/2]")#text(" for the purposes of defining what ")#mi("1/t")#text(" means). A simple scaling argument shows that if such an estimate is true on the unit circle, then it is also true on the circle of length L (with appropriate normalisations). Letting L go to infinity, we can recover the estimate on the real line from the estimate on the circle.")

#text("In the converse direction, to obtain the circle estimate from the real line estimate, we take a function on the unit circle and extend it periodically. As you observe, the extended function is no longer in any finite ")#mi("L^p")#text(" class; however, we can truncate this function to a large finite interval ")#mi("[-R,R]")#text(" (either using a sharp truncation or a smooth one) and see what the estimate for the real line tells us about the corresponding situation on the circle. There will be an error term arising from the boundary of the interval ")#mi("[-R,R]")#text("; but one can arrange matters so that this error becomes acceptable in the limit as R goes to infinity.")

#text("There is a general principle in harmonic analysis that the unit circle is very much like the real line, except that all the coarse scales (with wavelength greater than 1) have been removed and one only has the fine scales. (Conversely, with the integers the fine scales have been removed and one only has the coarse scales.) It may seem like removing half the scales is an improvement, but the scale invariance shows that in fact you don’t actually gain very much at all; half of infinity is still infinity. In fact it turns out to be more convenient to work in the context of the real line, as then one has an exact scale-invariance symmetry which is often worth exploiting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-33400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2008")])]

#text("I know it might be a bit late to be asking questions, but this discusion leaves me with the following nature question:")

#text("Is there an example known of a multilinear operator (given, say, by convolution with a distribution) which we’ll call M(f_1,…f_n), where say M(C,f_2,..,f_n) is known to be a bounded (n-1)-linear operator (on some appropriate spaces), but the “anticipated” multilinear bounds fail for M?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9683b8cf575b1cc48d5f9d25ce3ef13d8ad28ab76840c4db3b5171d58bfbf654-6a743755ae4badd8102c0ccb504df65d19534faad9e5b88d0e755f29a327f1f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Håkan Hedenmalm")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-43711")[#strong[#text("Håkan Hedenmalm")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("I guess the results of Lacey and Thiele have analogs in more general settings. For instance, what if we consider pv \\int_\\reals f(R(x,t)) g(S(x,t)) dt/t where R(x,t) and S(x,t) are two Lipschitzian functions satisfying certain nontriviality assumption (like to avoid repetition of x+t and again x+t)?")#linebreak()#text(" To push in the same direction, think of the Lacey-Thiele theorem as the statement that")#linebreak()#text(" the integral kernel g(x+t)/(x-t) maps a Lebesgue space L^r to another Lebesgue space")#linebreak()#text(" L^s , provided g belongs to a given Lebesgue space L^q (the values of r,s,q are related as described by the theorem). What is special about the form g(x+t) here? What would we need to know about a function g(x,t) to say the same thing about the integral kernel g(x,t)/(x-t)??")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-43712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2010")])]

#text("There is some recent work in this direction, for instance see this paper of Xiaochun Li:")

#link("http://arxiv.org/abs/0805.0107")[#text("http://arxiv.org/abs/0805.0107")]

#text("but I think it is fair to say that more work needs to be done before one has a good picture here. Typically what happens in this business is that nonlinear averages behave like their linear counterparts at small scales, but can in fact be smoother than their linear counterparts at large scales due to curvature effects. As a consequence, sometimes one can deduce the nonlinear case relatively cheaply from the linear one. But in other situations the genuinely nonlinear portion presents completely new difficulties that need to be tackled by different arguments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-193643")[#strong[#text("A Few Mathematical Snapshots from India (ICM2010) | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2012")]

#text("[…] Carleson’s famous theorem asserts that the Fourier expansion of a function in converges to the function almost everywhere. High dimensional analogs of the question itself or of some basic ingredients in the argument are very important and very hard. See here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/610c6c09de86478d1331b3769ec40a48ee658464b3f0b4dce03a84b989f6ae2d-5147ec476d371a8e46dfc83ecc0c2b09b7ccf32ad96cc3062bc690b1d2044f48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of francescodiplinio")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-279470")[#strong[#text("francescodiplinio")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("Beforehand, I apologize for bumping up such an old topic, but I thought it might be worthwhile to mention some recent progress on the bilinear Hilbert transform at the endpoint ")#mi("L^{2/3}")#text(", which, as pointed out by Terence in the main post, could be looked at as a model for the harder trilinear operator. Again, as mentioned above, the technical connection stems from the “logarithmic failure” of the known time-frequency synthesis (i.e summing up the contributions of the forests) techniques for both problems.")

#text("Christoph Thiele and I have recently posted on ArXiv a joint paper ")#link("http://arxiv.org/abs/1403.5978")[#text("http://arxiv.org/abs/1403.5978")]#text(", addressing several endpoint questions for the bilinear Hilbert transform. Perhaps the most relevant result is that the restricted weak type estimate ")#mi("L^{4/3} \\times L^{4/3} \\to  L^{2/3,\\infty}")#text(" is true up to a doubly logarithmic correction, improving on the single logarithmic one which follows by the previously known methods (and which was observed by D. Bilyk and L. Grafakos, ")#link("http://www.ams.org/mathscinet-getitem?mr=2271944")[#text("http://www.ams.org/mathscinet-getitem?mr=2271944")]#text("). Same holds for any Holder tuple on the open segment ")#mi("(p_1,p_2,q)")#text(" with ")#mi("q=2/3")#text(" and ")#mi("1<p_1,p_2<2")#text(".")

#text("In order to keep using the strength of the ")#mi("L^2")#text(" methods as much as possible, on this segment, we lift the subindicator restriction for the first argument ")#mi("f_1")#text(" say, which lies in ")#mi("L^p")#text(" with ")#mi("p")#text(" between ")#mi("1")#text(" and ")#mi("2")#text(", and we seek a Calder\\'on-Zygmund decomposition of")#linebreak()#text(" the function ")#mi("f_1")#text(", into a good ")#mi("L^2")#text(" portion")#linebreak()#text(" and a bad ")#mi("L^1")#text(" portion enjoying additional localization. Due to the modulation invariance properties of BHT, the Calderon-Zygmund")#linebreak()#text(" decomposition has to respect a number of frequencies, as does the multi-frequency Calderon-Zygmund decomposition")#linebreak()#text(" (MFCZ) developed by Nazarov, Oberlin and Thiele in ")#link("http://arxiv.org/abs/0912.3010")[#text("http://arxiv.org/abs/0912.3010")]#text(".")

#text("The bad portion of the MFCZ is the sum of functions ")#mi("b_I")#text(" localized to intervals ")#mi("I")#text(" and having mean zero with respect to a number ")#mi("N")#text(" of bad frequencies relevant on the interval ")#mi("I")#text(". The main issue lies with estimating the interaction of this bad function ")#mi("b_I")#text(" with wave packets which are frequency localized in a compact interval near a bad frequency, and which are spatially localized away from but not too far away from ")#mi("I")#text(". To make this interaction sufficiently small for our needs we work on the one hand")#linebreak()#text(" with wave packets which have better than mere Schwartz function decay. We use an optimal almost exponential decay following a construction by Ingham: this seems to have no precedent in the context of time-frequency analysis. To utilize this decay we have to prepare the bad function ")#mi("b_I")#text(" of the MFCZ to have mean zero not only against the dominant bad frequency, but also against approximately ")#mi("\\log(N)")#text(" many equidistant frequencies in the vicinity of the dominating one. The price of all this is the appearance of the doubly logarithmic correction in our main restricted weak type estimate (and of some other corrective terms in the other estimates). These corrections are less and less costful as the exponent ")#mi("p")#text(" gets closer to ")#mi("p=2")#text(".")#linebreak()#text(" To discern whether these corrections are structural or simply a byproduct of our techniques, it might be telling to mention that no corrections are necessary for the Walsh model of the bilinear Hilbert transform, the so-called quartile operator, which in a previous article of mine joint with Ciprian Demeter ")#link("http://arxiv.org/abs/1206.3798")[#text("http://arxiv.org/abs/1206.3798")]#text(" is shown to obey the restricted weak type estimate above without any correction term. In fact, one of the ")#mi("L^{4/3}")#text(" functions can even be taken to be unrestricted.")#linebreak()#text(" The catch therein is that the MFCZ decomposition is obtained via a straightforward projection argument, exploiting perfect localization of the Walsh wave packets to obtain a \"bad part\" whose contribution to the operator is identically zero.")

#text("A brief comment on the relevance of our techniques in relation with THT. A direct application to THT seems unlikely to succeed: again, it is telling that our methods are robust enough (or not refined enough) to work regardless of the insertion of bounded coefficients, which, as mentioned in the main post, would make THT unbounded. On the other hand, one could check, for instance, whether a similar CZ idea would lead to improvement in the range of boundedness for Christ's single scale THT in the rational case, see article mentioned in the main post.")

#text("I apologize for the quite lengthy comment and thank very much Terence for hosting,")

#text("Francesco Di Plinio")#linebreak()#text(" ")#link("https://www.researchgate.net/profile/Francesco_Di_Plinio/?ev=hdr_xprf")[#text("https://www.researchgate.net/profile/Francesco_Di_Plinio/?ev=hdr_xprf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cancellation for the multilinear Hilbert transform | What's new")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-456097")[#strong[#text("Cancellation for the multilinear Hilbert transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2015")])]

#text("[…] open problem of obtaining bounds for the trilinear and higher Hilbert transforms (as discussed in this previous blog post). For instance, the trilinear Hilbert […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-490802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("It is said in your lecture notes (")#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes4.pdf")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/notes4.pdf")]#text(") that")#linebreak()#text(" ")#tao-math("\\displaystyle \\lim_{\\left|x\\right|\\to\\infty}xHf(x)=\\int_{\\bf R}f(x)\\quad\\quad(*)", block: false)#linebreak()#text(" for ")#mi("f\\in\\mathcal{S}({\\bf R})")#text(". You mentioned this in the very beginning of notes 4. Can one prove this without using the result that ")#mi("H")#text(" maps the Schwartz class to ")#mi("L^2({\\bf R})")#text("? It seems that (*) is equivalent to")#linebreak()#text(" ")#tao-math("\\displaystyle \\lim_{\\left|x\\right|\\to\\infty}Hf(x)=0", block: false)#linebreak()#text(" for ")#mi("f\\in\\mathcal{S}({\\bf R})")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-490803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")])]

#text("Also, why does (*) imply that ")#mi("H")#text(" is not bounded on ")#mi("L^1")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-490839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("By writing ")#tao-math("Hf(x) = \\int_{\\left|y-x\\right| > 1} \\frac{f(y)}{x-y}\\ dy + \\int_{\\left|y-x\\right| \\leq 1} \\frac{f(y)-f(x)}{x-y}\\ dy", block: false)#text(" and using the triangle inequality one can easily verify the asymptotic limits for ")#mi("Hf(x)")#text(" and ")#mi("x Hf(x)")#text(". If ")#tao-math("\\lim_{\\left|x\\right| \\to \\infty} x Hf(x)", block: false)#text(" is non-zero, then ")#tao-math("\\left|Hf(x)\\right|", block: false)#text(" is bounded from below by ")#tao-math("c/\\left|x\\right|", block: false)#text(" for some ")#mi("c>0")#text(" and all sufficiently large ")#mi("x")#text(", which implies that ")#mi("Hf")#text(" is not absolutely integrable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-490852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("In this post, ")#mi("f(x+t)")#text(" instead of ")#mi("f(x-t)")#text(" is used in the definition of the Hilbert transform. Are the two versions the same?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-490896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2017")])]

#text("Up to irrelevant constants, yes.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-491420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2018")])]

#text("In the definition of Hilbert transform of Schwartz functions, do you have a quick example that the integral is not absolutely convergent if it is not evaluated in the principal value sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-491423")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2018")])]

#text("If for instance ")#mi("f(t)=1")#text(" for ")#mi("-1 \\leq t \\leq 1")#text(" then the integral ")#mi("\\int \\frac{f(t)}{t}\\ dt")#text(" that would formally be used to define ")#mi("Hf(0)")#text(" will not be absolutely convergent regardless of what ")#mi("f")#text(" is doing outside of the interval ")#mi("-1 \\leq t \\leq 1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-491459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("Are you assuming that ")#mi("f")#text(" is nonnegative outside the interval ")#mi("[-1,1]")#text("? Is it possible that one has some cancellation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-491466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("No. For the purposes of absolute integrability, one is only integrating non-negative functions (the magnitude of the integrand) and so there is no possibility of cancellation.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-694110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("Has this been solved?")

#text("What are the applications of your class 247a/b (may not be related to this?)")
]
