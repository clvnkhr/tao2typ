// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/
// Converted to Typst by tao2typ: "2026-11-02T16:20:27.065071+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A sketch of the proof of non-existence of Siegel zeroes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A sketch of the proof of non-existence of Siegel zeroes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/")[#text("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-02 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("For a given prime ")#mi("{p}")#text(", the ")#link("https://en.wikipedia.org/wiki/Legendre_symbol")[#text("Legendre symbol")]#text(" ")#mi("{\\left(\\frac{D}{p}\\right)}")#text(" is defined as follows: if ")#mi("{D}")#text(" is a quadratic residue modulo ")#mi("{p}")#text(", then ")#mi("{\\left(\\frac{D}{p}\\right) = 1}")#text("; if ")#mi("{D}")#text(" is a quadratic non-residue modulo ")#mi("{p}")#text(", then ")#mi("{\\left(\\frac{D}{p}\\right) = -1}")#text("; and if ")#mi("{p}")#text(" divides ")#mi("{D}")#text(", then ")#mi("{\\left(\\frac{D}{p}\\right) = 0}")#text(".")

#text("Let ")#mi("{D}")#text(" be an integer that is not a perfect square. (One could require ")#mi("{D}")#text(" to be a ")#link("https://en.wikipedia.org/wiki/Discriminant#Fundamental_discriminants")[#text("fundamental discriminant")]#text(" if desired, although it turns out to be immaterial for the arguments here.) By combining ")#link("https://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("quadratic reciprocity")]#text(" with ")#link("https://en.wikipedia.org/wiki/Prime_number_theorem#Prime_number_theorem_for_arithmetic_progressions")[#text("the prime number theorem in arithmetic progressions")]#text(", one can show that the Legendre symbol is asymptotically balanced between ")#mi("{+1}")#text(" and ")#mi("{-1}")#text(". For instance, one can show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\left(\\frac{D}{p}\\right) \\frac{\\log p}{p} = o\\left(\\log x\\right)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where the sum is over primes ")#mi("{p}")#text("; equivalently (by Mertens’ theorem),")

#metadata(none) <tao-6ee2cc105a67743140cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{p \\leq x : \\left(\\frac{D}{p}\\right) = -1} \\frac{\\log p}{p} = \\frac{1}{2} \\log x + o\\left(\\log x \\right).")]]

#text("However, most of the known proofs of this asymptotic are ")#emph[#text("ineffective")]#text(" with regards to the decay of the ")#mi("{o()}")#text(" error. This is due to the infamous ")#link("https://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero problem")]#text(", arising from Dirichlet ")#mi("{L}")#text("-functions associated to ")#mi("{D}")#text(" with a zero very close to ")#mi("{s=1}")#text(". A well known example comes when ")#mi("{D = -163}")#text(", which is a non-residue for all primes ")#mi("{p < 41}")#text("; this is closely tied to Euler’s famous observation that ")#mi("{n^2 + n + 41}")#text(" is prime for all integers ")#mi("{n}")#text(" with ")#mi("{0 \\leq n < 40}")#text(", as well as the fact that the ring of integers ")#mi("{{\\bf Z}[\\frac{1+\\sqrt{-163}}{2}]}")#text(" has unique factorization. For further discussion of these topics, see ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("this previous set of lecture notes")]#text(".")

#text("Recently, the Siegel zero problem has been solved in a number of ways. In fact, a stronger “quasi-Riemann hypothesis”, showing that the zeroes of all Dirichlet ")#mi("{L}")#text("-functions have real part strictly bounded away from ")#mi("{1}")#text(", has been established (with two separate papers giving a ")#link("https://github.com/openai/math/blob/main/preprints/The-Quasi-Riemann-Hypothesis-October-5-2026/paper2.pdf")[#text("bound of ")#mi("{11/12}")]#text(" ")#link("https://github.com/openai/math/blob/main/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/paper.pdf")[#text("and ")#mi("{7/8}")]#text(" respectively) as part of a recent release by OpenAI. (In particular, the ")#mi("{o(\\log x)}")#text(" error term in ")#link(<tao-6ee2cc105a67743140cf>)[#text("(1)")]#text(" can now be improved to a power saving ")#tao-math("{O( \\left|D\\right|^{O(1)} x^{-1/8+o(1)})}", block: false)#text(".) These arguments are analytic in nature, using identities relating the Möbius function to the Fourier coefficients of certain automorphic forms; they are still in the process of being fully digested, and I will not be discussing them further here. However, there was a ")#link("https://github.com/openai/math/blob/main/preprints/Uniform-exclusion-of-Landau-Siegel-zeros-October-1-2026/paper.pdf")[#text("third paper in the same release")]#text(" that did not establish the quasi-Riemann hypothesis, but instead excluded Siegel zeroes directly. This paper was significantly shorter (nine pages) and proceeded almost entirely via algebraic number theory and the geometry of numbers.")

#text("Recently, various digestions and simplifications of the argument have been produced ")#link("https://arxiv.org/abs/2610.15483")[#text("by Banks")]#text(", ")#link("https://arxiv.org/abs/2610.21099")[#text("by Kerr")]#text(", and ")#link("https://hexagonmath.org/2610.00311v2")[#text("by Green")]#text(". I would like here to present a sketch of Green’s formulation (with some small notational changes), which I find particularly elegant. The key bound he establishes is ")#metadata(none) <tao-21a0fce74081247c4f83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{\\varepsilon^{-2} \\leq p \\leq \\varepsilon R : \\left(\\frac{D}{p}\\right) = -1} \\frac{\\log p}{p} \\leq \\left(1 + O(\\varepsilon)\\right) \\log N")]]

#text(" ")#text(" whenever ")#mi("{\\varepsilon > 0}")#text(" is a small quantity, ")#tao-math("{N \\geq \\left|D\\right|^{1/\\varepsilon}}", block: false)#text(" is a suitably large scale, and ")#mi("{R := \\lfloor N^{2 - \\varepsilon}\\rfloor}")#text(" is a larger scale that is nearly quadratic in ")#mi("{N}")#text(". For ")#mi("{\\varepsilon}")#text(" small enough, this improves by a factor of about ")#mi("{\\frac{1}{2}}")#text(" upon the trivial bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\varepsilon^{-2} \\leq p \\leq \\varepsilon R : \\left(\\frac{D}{p}\\right) = -1} \\frac{\\log p}{p} \\leq \\log R + O(1)")]]

#text("coming from Mertens’ theorem; thus ")#link(<tao-21a0fce74081247c4f83>)[#text("(2)")]#text(" is a non-trivial bound on the number of primes ")#mi("{p}")#text(" at scales up to ")#mi("{\\varepsilon R}")#text(" for which ")#mi("{D}")#text(" is a quadratic non-residue. By optimizing in ")#mi("{\\varepsilon}")#text(", this gives the upper bound for ")#link(<tao-6ee2cc105a67743140cf>)[#text("(1)")]#text("; in fact with more care one concludes that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq x : \\left(\\frac{D}{p}\\right) = -1} \\frac{\\log p}{p} \\leq \\frac{1}{2} \\log x + O(\\log \\left|D\\right|) + O(\\log\\log x).", block: true)]]

#text("(In fact, some extremely recent preprints of Jacob Pescador and Kevin Barretto have sharpened this bound further, with an upper bound of ")#tao-math("{\\frac{1}{2} \\log x + \\frac{1}{4} \\log \\left|D\\right| + \\log\\log x + O(1)}", block: false)#text(".)")

#text("One can obtain the full strength of ")#link(<tao-6ee2cc105a67743140cf>)[#text("(1)")]#text(" using standard analytic number theory methods (omitted here, but see for instance ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("these previous notes")]#text(") to rule out Siegel zeroes, which can then in turn be used to upgrade the error term in ")#link(<tao-6ee2cc105a67743140cf>)[#text("(1)")]#text(" to a classical shape ")#mi("{\\exp(- c \\sqrt{\\log x})}")#text(" for some absolute constant ")#mi("{c>0}")#text(", assuming ")#tao-math("{\\left|D\\right| \\leq \\exp(c \\sqrt{\\log x})}", block: false)#text(". Besides this, though, none of the classical analytic number theory methods are utilized in this proof. In retrospect this makes sense, as the infamous “")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("parity problem")]#text("” blocks such methods from getting results such as ")#link(<tao-21a0fce74081247c4f83>)[#text("(2)")]#text(" without some parity-breaking input: in this case, said input comes from the polynomial method, whereas in the QRH papers, it appears to be some (still poorly understood) automorphic miracle that is breaking the parity barrier.")

#text("AI disclosure: a ")#link("https://os.openmathmodel.org/app/#/chat/cs-d0648cb637c11eaa611d04a42a0bba23")[#text("chat session with the new SAIR open math model")]#text(" was used to help understand the preprints. I also benefited from conversations with Ben Green, Alex Pascadi, Lior Silberman, Valentin Blomer, Gergely Harcos, Farrell Brumley, William Banks, and Edgar Assing.")

#heading(level: 1)[#strong[#text(" — 1. High-level description of proof — ")]]

#text("I will make some minor assumptions and “cheats” to simplify the exposition. Firstly I will restrict to the case when ")#mi("{D}")#text(" is negative; this makes ")#mi("{{\\bf Z}[\\sqrt{D}]}")#text(" have one complex embedding rather than two real embeddings, which allows for a very small simplification to the notation. For extremely minor notational reasons I will also exclude ")#mi("{D=-1}")#text(", so that ")#tao-math("{\\left|D\\right| \\geq 2}", block: false)#text(". I will also pretend at a later point that an arbitrarily chosen high-degree polynomial ")#mi("{P(z_1,z_2)}")#text(" is irreducible, which is of course not always the case, but allows one to simplify a certain algebraic calculation, the general case of which is handled in Green’s writeup.")

#text("The overall strategy is that of the “adelic polynomial method”, which appears in various guises (though usually not with this name) throughout the literature, for instance in ")#link("https://eudml.org/doc/143033")[#text("the Bombieri–Vaaler paper on Siegel’s lemma")]#text(" (I would be interested in further historical information on the development of the method). We will not actually use any of the machinery of the ")#link("https://en.wikipedia.org/wiki/Adele_ring")[#text("adeles")]#text(" in this post, though experts will readily see them lying just beneath the surface.")

#text("The first observation is just the fundamental theorem of arithmetic, which gives the factorization")

#align(center)[#tao-fit-display[#tao-math("\\left|M\\right| = \\prod_p p^{v_p(M)}", block: true)]]

#text("for any non-zero integer ")#mi("{M}")#text(", where ")#mi("{v_p(M)}")#text(" is the number of times ")#mi("{p}")#text(" divides ")#mi("{M}")#text(". Taking logarithms, we obtain")

#metadata(none) <tao-1a325e9af1de76dc4925>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_p v_p(M) \\log p = \\log \\left|M\\right|.", block: true)]]

#text("So, if one wanted to obtain a bound such as ")#link(<tao-21a0fce74081247c4f83>)[#text("(2)")]#text(", one could try to construct some non-zero integer ")#mi("{M}")#text(" for which one had some upper bound on the “Archimedean magnitude” of ")#mi("{M}")#text(", while also having lower bounds on the valuations ")#mi("{v_p(M)}")#text(" for primes ")#mi("{p}")#text(" in the range of ")#link(<tao-21a0fce74081247c4f83>)[#text("(2)")]#text(" for which ")#mi("{D}")#text(" is a quadratic nonresidue. That is to say, one wants to find an ")#mi("{M}")#text(" which is not too large, while also being divisible by many powers of such primes ")#mi("{p}")#text(", and also non-vanishing.")

#text("This quantity ")#mi("{M}")#text(" will be constructed geometrically, being essentially the covolume of a certain lattice (actually the square of that covolume, to make it an integer). Let ")#mi("{S := \\lfloor \\varepsilon R \\rfloor}")#text(" be a small multiple of ")#mi("{R}")#text(". First let ")#mi("{\\Lambda}")#text(" be the set of polynomials ")#mi("{P(z_1,z_2)}")#text(" with integer coefficients that are of degree less than ")#mi("{(R,S)}")#text(" in the two variables ")#mi("{z_1,z_2}")#text(", by which we mean that they are of degree less than ")#mi("{R}")#text(" in the ")#mi("{z_1}")#text(" variable, and less than ")#mi("{S}")#text(" in the ")#mi("{z_2}")#text(" variable. The behavior in ")#mi("{z_1}")#text(" will be more important for us than that in ")#mi("{z_2}")#text(", and this is reflected in the disparity in sizes between the two degrees ")#mi("{R,S}")#text(".")

#text("Clearly ")#mi("{\\Lambda}")#text(" is a lattice of rank ")#mi("{RS}")#text(". We will evaluate this lattice on the ")#mi("{N \\times N}")#text(" grid")

#align(center)[#tao-fit-display[#mitex("E := \\{ (m + n\\sqrt{D}, m - n\\sqrt{D}): m,n \\in {\\bf Z}, 0 \\leq m, n < N \\}.")]]

#text("The idea of evaluating a lattice or vector space of polynomials on various carefully selected sets such as ")#mi("{E}")#text(" lies at the heart of the polynomial method, with a focus often being made on the extent to which such polynomials can vanish on ")#mi("{E}")#text(". In many variants of the polynomial method, one also analyzes the extent to which such polynomials can vanish ")#emph[#text("with multiplicity")]#text(" on ")#mi("{E}")#text("; Stepanov’s method (discussed for instance ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("in this previous post")]#text(") is one well-known example. One of the innovations in Green’s treatment is to also take advantage of multiplicity to achieve the non-trivial bound ")#link(<tao-21a0fce74081247c4f83>)[#text("(2)")]#text("; previous treatments did not do this, and had to work with a (somewhat artificial) extension of ")#mi("{{\\bf Z}[\\sqrt{D}]}")#text(", such as ")#mi("{{\\bf Z}[\\sqrt{D}, \\sqrt{2}]}")#text(", in order to get comparably non-trivial bounds.")

#text("Specifically, for each polynomial ")#mi("{P}")#text(" in ")#mi("{\\Lambda}")#text(", we consider the evaluations")

#align(center)[#tao-fit-display[#mitex("TP := \\left( \\partial_{z_1}^j P(z_1, z_2) \\right)_{0 \\leq j < J; (z_1,z_2) \\in E}")]]

#text("of the first ")#mi("{J}")#text(" horizontal derivatives of ")#mi("{P}")#text(" at each point of ")#mi("{E}")#text(", where the optimal choice of ")#mi("{J}")#text(" turns out to be ")#mi("{J=S}")#text(", though as these two quantities play conceptually different roles we will continue to denote them by different symbols.")

#text("The tuple ")#mi("{TP}")#text(" is an element of ")#mi("{{\\bf Z}[\\sqrt{D}]^{J \\times N^2}}")#text(", and so ")#mi("{T\\Lambda}")#text(" is some additive subgroup of ")#mi("{{\\bf Z}[\\sqrt{D}]^{J \\times N^2}}")#text(". A key fact is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Injectivity)")]#text(" ")#metadata(none) <tao-e6f2ad814692e3f553d6>#text(" ")#mi("{T}")#text(" is injective on ")#mi("{\\Lambda}")#text(". In other words, if ")#mi("{P}")#text(" is a non-zero element of ")#mi("{\\Lambda}")#text(", then ")#mi("{P}")#text(" cannot vanish to (horizontal) order ")#mi("{J}")#text(" at every point of ")#mi("{E}")#text(".")
]

#text("We will prove this later using the theory of resultants.")

#text("Thus ")#mi("{T\\Lambda}")#text(" is a lattice of rank ")#mi("{RS}")#text(". To this lattice, we can prescribe a (squared) covolume ")#mi("{M}")#text(" as follows. Let ")#mi("{v_1,\\dots,v_{RS}}")#text(" be some basis for this lattice, then form the ")#mi("{RS \\times RS}")#text(" Gram matrix")

#align(center)[#tao-fit-display[#mitex("\\left( \\langle v_i, v_j \\rangle \\right)_{1 \\leq i,j \\leq RS}")]]

#text("where we embed ")#mi("{{\\bf Z}[\\sqrt{D}]^{N \\times N^2}}")#text(" into ")#mi("{{\\bf C}^{N \\times N^2} \\equiv {\\bf R}^{2 \\times N \\times N^2}}")#text(" in the usual fashion with the Euclidean inner product for the purpose of defining the (real) inner product. This Gram matrix depends on the choice of basis, but the determinant does not; we then take ")#mi("{M}")#text(" to be this determinant. Geometrically, one can think of ")#mi("{M}")#text(" as the square of the volume of a fundamental domain of ")#mi("{T\\Lambda}")#text(".")

#text("Some basic facts about ")#mi("{M}")#text(". Firstly, the injectivity in Lemma ")#link(<tao-e6f2ad814692e3f553d6>)[#text("1")]#text(" shows that ")#mi("{M}")#text(" is non-zero. As all the coefficients of the basis vectors ")#mi("{v_i}")#text(" lie in the ring ")#mi("{{\\bf Z}[\\sqrt{D}]}")#text(", the inner products ")#mi("{\\langle v_i, v_j \\rangle}")#text(" are all integer, and so ")#mi("{M}")#text(" is also. Hence ")#mi("{M}")#text(" is a non-zero integer. (It is also positive, although this is irrelevant for us.) In particular, the fundamental theorem of arithmetic gives ")#link(<tao-1a325e9af1de76dc4925>)[#text("(3)")]#text(".")

#text("It is easy to bound the Archimedean size of ")#mi("{M}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Archimedean bound)")]#text(" ")#metadata(none) <tao-890cabe271136403326f>#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|M\\right| \\leq (1 + O(\\varepsilon) ) R^2 S \\log N.", block: true)]]
]

#text("This will be a straightforward application of ")#link("https://en.wikipedia.org/wiki/Hadamard%27s_inequality")[#text("Hadamard’s inequality")]#text(", using the obvious monomial basis, we prove this later in the post.")

#text("Now for the arithmetic input. Suppose that ")#mi("{p}")#text(" is an (odd) prime for which ")#mi("{\\left(\\frac{D}{p}\\right) = -1}")#text(". From Fermat’s little theorem we have")

#align(center)[#tao-fit-display[#mitex("D^{\\frac{p-1}{2}} = -1 \\text{ mod } p")]]

#text("and therefore")

#align(center)[#tao-fit-display[#mitex("\\sqrt{D}^p = - \\sqrt{D} \\text{ mod } p {\\bf Z}[\\sqrt{D}].")]]

#text("From further application of Fermat’s little theorem (and the Frobenius automorphism), this implies that")

#align(center)[#tao-fit-display[#mitex("(m + n \\sqrt{D})^p = m - n \\sqrt{D} \\text{ mod } p {\\bf Z}[\\sqrt{D}]")]]

#text("for any integers ")#mi("{m,n}")#text(". In particular, from a ")#mi("{p}")#text("-adic point of view, the grid ")#mi("{E}")#text(" lies close to the curve")

#align(center)[#tao-fit-display[#mitex("\\{ (z_1,z_2): z_1^p - z_2 = 0 \\}.")]]

#text("If the grid ")#mi("{E}")#text(" happened to lie exactly on this curve, then the lattice ")#mi("{T\\Lambda}")#text(" would degenerate (contradicting Lemma ")#link(<tao-e6f2ad814692e3f553d6>)[#text("1")]#text(") and ")#mi("{M}")#text(" would now vanish. This of course does not happen; but the fact that ")#mi("{E}")#text(" is ")#mi("{p}")#text("-adically close to the curve will force ")#mi("{M}")#text(" to be ")#mi("{p}")#text("-adically close to zero, or equivalently give a useful lower bound on ")#mi("{v_p(M)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Non-Archimedean bound)")]#text(" ")#metadata(none) <tao-b7acfaa62a52ec37fafe>#text(" If ")#mi("{\\varepsilon^{-2} \\leq p \\leq \\varepsilon R}")#text(" and ")#mi("{\\left(\\frac{D}{p}\\right) = -1}")#text(", then")

#align(center)[#tao-fit-display[#mitex("v_p(M) \\geq (1-O(\\varepsilon)) \\frac{R^2 S }{p}.")]]
]

#text("We prove this bound later in the post. Inserting Lemma ")#link(<tao-890cabe271136403326f>)[#text("2")]#text(" and Lemma ")#link(<tao-b7acfaa62a52ec37fafe>)[#text("3")]#text(" into ")#link(<tao-1a325e9af1de76dc4925>)[#text("(3)")]#text(" and cancelling the common factor of ")#mi("{R^2 S}")#text(", we obtain ")#link(<tao-21a0fce74081247c4f83>)[#text("(2)")]#text(" as required.")

#heading(level: 1)[#strong[#text(" — 2. Injectivity — ")]]

#text("Now we establish Lemma ")#link(<tao-e6f2ad814692e3f553d6>)[#text("1")]#text(". From my understanding, these sorts of non-vanishing theorems go back to the ")#link("https://link.springer.com/article/10.1007/BF01389194")[#text("work of Masser")]#text(" (and the Kerr preprint explicitly uses Masser’s bounds to obtain an analogue of this lemma), which initially used a fair amount of ring theory, but a more elementary alternate approach based on the interpolating polynomial method was ")#link("https://www.numdam.org/book-part/AST_1991__198-199-200__209_0/")[#text("introduced by Laurent")]#text(", an adaptation of which is used in the OpenAI release. Green’s approach is simpler still, based largely on the theory of resultants to project the (high-order) vanishing of a two-variable polynomial to a (high-order) vanishing of a one-variable polynomial.")

#text("As ")#mi("{E}")#text(" is an ")#mi("{N \\times N}")#text(" grid, a direct application of the ")#link("https://en.wikipedia.org/wiki/Schwartz%E2%80%93Zippel_lemma")[#text("Schwartz–Zippel lemma")]#text(" tells us that a non-zero degree ")#mi("{d}")#text(" polynomial can only vanish on at most ")#mi("{dN}")#text(" of the points of ")#mi("{E}")#text(". This is not directly useful for us because the degree of ")#mi("{P}")#text(" can be as large as ")#mi("{R+S \\asymp N^{2 - O(\\varepsilon)}}")#text(", and so this does not prevent ")#mi("{P}")#text(" from vanishing on all of ")#mi("{E}")#text(". And indeed, if we replaced ")#mi("{E}")#text(" by the standard ")#mi("{N \\times N}")#text(" grid")

#align(center)[#tao-fit-display[#mitex("E^{\\prime} := \\{ (m, n): 0 \\leq m,n < N \\}")]]

#text("then the degree ")#mi("{N}")#text(" polynomial ")#mi("{\\prod_{0 \\leq n < N} (z_2-n)}")#text(" already vanishes on ")#mi("{E^{\\prime}}")#text(", as does all of the horizontal derivatives of this polynomial. So to proceed here we have to somehow use the fact that the grid ")#mi("{E}")#text(" is “skew”; in particular we will take advantage of the fact that the ")#mi("{N^2}")#text(" second coordinates ")#mi("{m - n \\sqrt{D}}")#text(" of this grid are all distinct, in contrast to the situation with ")#mi("{E^{\\prime}}")#text(".")

#text("Let ")#mi("{P(z_1,z_2)}")#text(" be a non-zero polynomial of degree less than ")#mi("{(R,S)}")#text(". To avoid technicalities we will assume that ")#mi("{P}")#text(" is irreducible, and not solely a function of ")#mi("{z_2}")#text(", so that ")#mi("{\\partial_{z_1} P}")#text(" is not identically zero; the general case is treated in ")#link("https://hexagonmath.org/2610.00311v2")[#text("Ben Green’s note")]#text(".")

#text("Suppose that ")#mi("{P}")#text(" vanishes horizontally to order at least ")#mi("{J}")#text(" at a point ")#mi("{(z_1^0, z_2^0)}")#text(", then by performing a Taylor expansion around that point we can factor ")#mi("{P}")#text(" as")

#align(center)[#tao-fit-display[#mitex("P(z_1,z_2) = (z_1 - z_1^0)^J Q(z_1,z_2) + (z_2 - z_2^0) U(z_1,z_2)")]]

#text("for some polynomials ")#mi("{Q,U}")#text(" of degree less than ")#mi("{(R-J,S)}")#text(" and ")#mi("{(R,S-1)}")#text(" respectively. If we take one derivative in the ")#mi("{z_1}")#text(" direction, then ")#mi("{\\partial_{z_1} P(z_1,z_2)}")#text(" vanishes to order at least ")#mi("{J-1}")#text(" at the same point, thus")

#align(center)[#tao-fit-display[#mitex("\\partial_{z_1} P(z_1,z_2) = (z_1 - z_1^0)^{J-1} \\tilde Q(z_1,z_2) + (z_2 - z_2^0) \\tilde U(z_1,z_2)")]]

#text("for some polynomials ")#mi("{\\tilde Q,\\tilde U}")#text(" of degree less than ")#mi("{(R-J-1,S)}")#text(" and ")#mi("{(R-1,S-1)}")#text(" respectively.")

#text("Since ")#mi("{P}")#text(" and ")#mi("{\\partial_{z_1} P}")#text(" both vanish to high order at ")#mi("{(z_1^0, z_2^0)}")#text(", it is natural to look at the ")#link("https://en.wikipedia.org/wiki/Resultant")[#text("horizontal resultant")]#text(" ")#mi("{\\mathrm{Res}_{z_1}(P, \\partial_{z_1} P) \\in {\\bf Z}[z_2]}")#text(" of these two polynomials (which we now view as ")#mi("{{\\bf Z}[z_2]}")#text("-valued polynomials of ")#mi("{z_1}")#text("), defined as the determinant of the ")#mi("{(R-1) + (R-2)}")#text(" polynomials")

#align(center)[#tao-fit-display[#mitex("P, z_1 P, \\dots, z_1^{R-2} P, \\partial_{z_1} P, z_1 \\partial_{z_1} P, \\dots, z_1^{R-3} \\partial_{z_1} P")]]

#text("each of which we view as vectors of ")#mi("{(R-1) + (R-2)}")#text(" coefficients in ")#mi("{{\\bf Z}[z_2]}")#text(". Note that all the polynomials in this list take the form")

#align(center)[#tao-fit-display[#mitex("(z_1 - z_1^0)^{J-1} Q^{\\prime}(z_1,z_2) + (z_2 - z_2^0) U^{\\prime}(z_1,z_2)")]]

#text("for some polynomials ")#mi("{Q^{\\prime}, U^{\\prime}}")#text(" of degree less than ")#mi("{(2R-J, S)}")#text(" and ")#mi("{(2R, S)}")#text(" respectively (here we drop some irrelevant lower order terms). By multilinearity of the determinant, the resultant now splits into a linear combination of various determinants involving ")#mi("{k}")#text(" expressions of the form ")#mi("{(z_1 - z_1^0)^{J-1} Q^{\\prime}(z_1,z_2)}")#text(" and ")#mi("{(R-1)+(R-2)-k}")#text(" expressions of the form ")#mi("{(z_2 - z_2^0) U^{\\prime}(z_1,z_2)}")#text(". As ")#mi("{Q^{\\prime}}")#text(" is of degree less than ")#mi("{2R-J}")#text(" in the ")#mi("{z_1}")#text(" variable, any contribution with ")#mi("{k > 2R-J}")#text(" must vanish, and so we need to have at least ")#mi("{J-O(1)}")#text(" factors of the form ")#mi("{(z_2 - z_2^0) U^{\\prime}(z_1,z_2)}")#text(". We conclude that the resultant ")#mi("{\\mathrm{Res}_{z_1}(P, \\partial_{z_1} P)}")#text(" is divisible by ")#mi("{(z_2 - z_2^0)^{J - O(1)}}")#text(".")

#text("On the other hand, a straightforward degree count shows that this resultant is a polynomial of ")#mi("{z_2}")#text(" of degree ")#mi("{O(RS)}")#text(". The hypothesis that ")#mi("{P}")#text(" is irreducible and ")#mi("{\\partial_{z_1} \\not \\equiv 0}")#text(" implies that the resultant is non-zero. So if ")#mi("{P}")#text(" vanished to order at least ")#mi("{N}")#text(" at each of the ")#mi("{N^2}")#text(" points ")#mi("{(z_1^0, z_2^0)}")#text(" of ")#mi("{E}")#text(", then the resultant would have to be divisible by ")#mi("{N^2}")#text(" different factors of ")#mi("{(z_2 - z_2^0)^{J - O(1)}}")#text(" (here we use the fact that the ")#mi("{z_2^0}")#text(" are all distinct), leading to the inequality")

#align(center)[#tao-fit-display[#mitex("O(RS) \\geq N^2 (J - O(1))")]]

#text("which is false for ")#mi("{\\varepsilon}")#text(" small enough by the choice of ")#mi("{N}")#text(", ")#mi("{J}")#text(", ")#mi("{R}")#text(", and ")#mi("{S}")#text(". This proves Lemma ")#link(<tao-e6f2ad814692e3f553d6>)[#text("1")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Archimedean bound — ")]]

#text("The Archimedean bound is straightforward. For any basis ")#mi("{v_1,\\dots,v_{RS}}")#text(" of ")#mi("{T\\Lambda}")#text(", the quantity ")#mi("{M}")#text(" is simply the square of the ")#mi("{RS}")#text("-dimensional parallelepiped with edges ")#mi("{v_1,\\dots,v_{RS}}")#text(", viewed as elements of ")#mi("{{\\bf C}^{J \\times N^2} = {\\bf R}^{2J \\times N^2}}")#text(". By the ")#link("https://en.wikipedia.org/wiki/Hadamard%27s_inequality")[#text("Hadamard’s inequality")]#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|M\\right| \\leq \\prod_{i=1}^{RS} \\left\\| v_i \\right\\|^2", block: true)]]

#text("(using the usual Euclidean norm), or upon taking logarithms")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|M\\right| \\leq 2 \\sum_{i=1}^{RS} \\log \\left\\|v_i\\right\\|.", block: true)]]

#text("Applying the sampling operator ")#mi("{T}")#text(" to the monomial basis ")#mi("{z_1^i z_2^j}")#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|M\\right| \\leq 2 \\sum_{0 \\leq i < R} \\sum_{0 \\leq j < S} \\log \\left\\|T (z_1^i z_2^j) \\right\\|.", block: true)]]

#text("Each point in the grid ")#mi("{E}")#text(" is of size ")#mi("{O( N \\sqrt{D} ) = O( N^{1+O(\\varepsilon)})}")#text(" by choice of ")#mi("{N}")#text(". Every component of ")#mi("{T(z_1^i z_2^j)}")#text(" then has size ")#mi("{O( R^J O(N^{1+O(\\varepsilon)})^{i+j})}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T (z_1^i z_2^j) \\right\\| \\ll N^{O(1)} R^J O(N^{1+O(\\varepsilon)})^{i+j}", block: true)]]

#text("or on taking logs and using the construction of ")#mi("{R}")

#align(center)[#tao-fit-display[#tao-math("\\log \\left\\|T (z_1^i z_2^j) \\right\\| \\leq (1 + O(\\varepsilon)) (i+j) \\log N + O( J \\log N ).", block: true)]]

#text("Summing the arithmetic series in ")#mi("{i,j}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|M\\right| \\leq (1 + O(\\varepsilon)) (R+S) RS \\log N + O( R S J \\log N ).", block: true)]]

#text("By construction we have ")#mi("{R+S = (1+O(\\varepsilon)) R}")#text(" and ")#mi("{J = O(\\varepsilon R)}")#text(", so Theorem ")#link(<tao-890cabe271136403326f>)[#text("2")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 4. Non-Archimedean bound — ")]]

#text("Let ")#mi("{p}")#text(" be a prime with ")#mi("{\\varepsilon^{-2} \\leq p \\leq \\varepsilon R}")#text(" and ")#mi("{\\left(\\frac{D}{p}\\right) = -1}")#text(". As discussed in the high-level overview, the polynomial ")#mi("{z_1^p - z_2}")#text(" takes values in ")#mi("{p {\\bf Z}[\\sqrt{D}]}")#text(" on the entire grid ")#mi("{E}")#text(". This has the following consequence: any polynomial ")#mi("{P(z_1,z_2)}")#text(" which is divisible by ")#mi("{(z_1^p-z_2)^k}")#text(" for some ")#mi("{k}")#text(" will take values in ")#mi("{p^k {\\bf Z}[\\sqrt{D}]}")#text(". Furthermore, the same is true for any iterated ")#mi("{z_1}")#text("-derivative of ")#mi("{P}")#text(": note from the chain rule that applying ")#mi("{\\partial_{z_1}}")#text(" to ")#mi("{(z_1^p-z_2)^k}")#text(" will lower the exponent ")#mi("{k}")#text(" by ")#mi("{1}")#text(", thus removing one factor of ")#mi("{p}")#text(", but also produce an additional factor of ")#mi("{p z_1^{p-1}}")#text(" which restores that missing factor. We conclude that every coefficient of ")#mi("{TP}")#text(" then lies in ")#mi("{p^k {\\bf Z}[\\sqrt{D}]}")#text(".")

#text("To use this, we replace the standard monomial basis ")#mi("{z_1^i z_2^j}")#text(", ")#mi("{0 \\leq i < R}")#text(", ")#mi("{0 \\leq j < S}")#text(" of ")#mi("{\\Lambda}")#text(" with the modified basis")

#align(center)[#tao-fit-display[#mitex("z_1^{i - p k_{i,j}} (z_1^p - z_2)^{k_{i,j}} z_2^j")]]

#text("for ")#mi("{0 \\leq i < R}")#text(", ")#mi("{0 \\leq j < S}")#text(", where")

#align(center)[#tao-fit-display[#mitex("k_{i,j} := \\min ( \\lfloor \\frac{i}{p} \\rfloor, S-1 - j ).")]]

#text("Note that such a basis element still lies in ")#mi("{\\Lambda}")#text(", and is of the form ")#mi("{z_1^i z_2^j}")#text(" plus a linear combination of monomials that are lower than this in the lexicographical ordering. So this modified basis remains a basis of ")#mi("{\\Lambda}")#text(". Applying ")#mi("{T}")#text(", we see from the previous discussion that each of the basis elements is divisible by ")#mi("{p^{k_{i,j}}}")#text(". Computing the Gram matrix in this basis, we conclude that")

#align(center)[#tao-fit-display[#mitex("v_p(M) \\geq 2 \\sum_{0 \\leq i < R} \\sum_{0 \\leq j < S} k_{i,j}.")]]

#text("For ")#mi("{j \\leq (1 - \\varepsilon) S}")#text(", one has ")#mi("{k_{i,j} = (1 + O(\\varepsilon)) \\frac{i}{p} - O(1)}")#text(" by the hypotheses on ")#mi("{p}")#text(" and the choice of ")#mi("{R,S}")#text(". We thus have")

#align(center)[#tao-fit-display[#mitex("v_p(M) \\geq 2 (1 - O(\\varepsilon)) S \\sum_{0 \\leq i < R} \\frac{i}{p} - O(RS)")]]

#text("and Theorem ")#link(<tao-b7acfaa62a52ec37fafe>)[#text("3")]#text(" then follows by summing the arithmetic series and noting that the second error term is negligible.")

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0ff957cc3a07c7bcf007b031948591baa120075111033161781a507e9142ec-01884b2fd037b1ef9035ecf3ccbd17d1ace80fa06252dcb06df35f484605c646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698405")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Just to add that during the course of today I have received both a 4-page (by Jacob Pescador) and a 3-page (by Kevin Barreto) proof of no Siegel zeros, both containing different and interesting variants of the proof. There will be a communal writeup with all of these ideas (intended to be published in something like the traditional way, as a version of record) in due course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/393329db68906b9c54abbf95ae6c951aa263c721d265fb69756d59f941033801-df86bad959eeb5d401d58d07d249117ef3dc7483f02d93ccd839445d20226ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698406")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Dear Terry,")

#text("Thanks for sharing this post and advertising the digestions. A minor quibble: given the historical development of the problem (I mean exploiting Deuring-Heilbronn type phenomena in biquadratic fields), it seems a bit unfair to call the use of the order ")#mi("\\mathbb{Z}[\\sqrt{2},\\sqrt{d}]")#text(" artificial, even somewhat!")

#text("What is a bit surprising to me is that the OpenAI article does not need the other discriminant vary, and I am not sure any of these digestions presently explain this choice. Of course, given that the zero-free region blows this out of the water, it may not be worth optimizing, but I am curious if redoing the original argument with ")#mi("\\mathbb{Z}[\\sqrt{d},\\sqrt{d^{\\prime}}]")#text(" for ")#mi("d^{\\prime} \\neq 2")#text(" gives better bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698407")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Fair enough, I felt more that the specific choice of ")#mi("\\sqrt{2}")#text(" was artificial rather than the use of a biquadratic field. It appears actually that the choice of discriminants are not important at all – only the degree of the extension is relevant. The original arguments using biquadratic fields (without using Ben’s multiplicity trick) give an upper bound more like ")#mi("\\frac{2}{3} \\log x")#text(" than ")#mi("\\frac{1}{2} \\log x")#text(", but it appears that one can get this constant arbitrarily close to ")#mi("\\frac{1}{2}")#text(" by adjoining enough new square roots (this observation was first made to my knowledge by Alex Pascadi).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/393329db68906b9c54abbf95ae6c951aa263c721d265fb69756d59f941033801-df86bad959eeb5d401d58d07d249117ef3dc7483f02d93ccd839445d20226ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Sahay")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698408")[#strong[#text("Anurag Sahay")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Fair enough — I agree that looked a bit artificial, so it makes sense that the choice of the other discriminant doesn’t matter. Thanks for sharing Alex’s observation; that is quite interesting.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698409")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Can the 7/8 bound for quasi-Riemann be pushed down to 5/6 or 3/4 using currently known techniques?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698413")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Do not worry kids. Arithmetic geometers will prove GRH before 2050.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698427")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("GIVE ME DENINGER COHOMOLOGY OR GIVE ME DEATH.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698495")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("No. The AI developed methods can only push the bounds down to 13/15:")

#link("https://gtimg.github.io/QuasiRiemannTracker/?tab=milestones&view=leaderboard")[#text("https://gtimg.github.io/QuasiRiemannTracker/?tab=milestones&view=leaderboard")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698411")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("The arguments of OpenAI/Kerr/Green are all reminiscent of Dobrowolski’s arguments to prove a lower bound on the height of an algebraic number that is not a root of unity. One uses an auxiliary polynomial (one can also use determinants) to construct a “small” algebraic number that is also divisible by many primes for Frobenius reasons. The small size restricts how many primes can divide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdf2a704665cb0e81f7f4395a904e060d2034e8ddab12fad9d7a18d71571aca-31ad83c33b2223a891e7f6990be9531b9460c64b210b52e85b3fa216a2be62a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698414")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Is it possible to say in a single sentence or two what the AI found that people had not that makes this proof work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698421")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("The proof uses a form of the polynomial method, which is a notoriously fickle tool – when it works, it can work amazingly well, but, as discussed in ")#link("https://mathoverflow.net/questions/43317/how-to-recognise-that-the-polynomial-method-might-work")[#text("this 2010 MathOverflow post")]#text(", we still do not have a good intuitive handle in advance on when this tool is going to work well, and how to deploy it effectively. See also my ")#link("https://arxiv.org/abs/1310.6482")[#text("2013 survey on the polynomial method")]#text(" (which in particular discusses Stepanov’s method in Section 4).")

#text("After the fact, there appear to be close ties between the approach here and with Stepanov’s version of the polynomial method, which can be used to prove the Weil conjectures (the Riemann hypothesis over finite fields). It’s possible that, given the hint to develop some sort of adelic version of Stepanov’s method, and to interpret a quadratic character as an assertion about the representation of a Frobenius element in a quadratic number field, one might be led to something resembling this argument eventually; I’d be interested in seeing impressions from experts in Stepanov’s method on this.")

#text("Despite this recent advance, as well as other relatively recent developments on the polynomial method (e.g., the introduction of the slice rank version of this method to solve problems such as the cap set problem), we still are a long way off from having a truly mature theory of this method (and developing such a theory does not seem to be a task where current AI tools are of any real help).")

#text("One final remark. In my response to the above 2010 MathOverflow post, I wrote “What I would like to see more of in the future is more development of the somewhat vague idea of the “Zariski complexity” of various sets, by which I mean something like the least degree of a non-trivial polynomial which vanishes on that set. “. Kerr’s arrangement of the Siegel zero argument uses a neat lower bound on this complexity for grids (generalized arithmetic progressions) introduced by Masser in 1981 which I was previously unaware of. If Masser’s bound had already been incorporated into an integrated theory of Zariski complexity, I could imagine that this proof could have been found by now if someone had thought to use (an adelic form of) the polynomial method (as opposed to, say, analytic number theory tools) to attack this problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7ddb41483eaadc1349c7af5ef313528e75e3e3e720cc02c220ae7373a47a48c-4e5d686c70fad214fe64251e2c979d9c0f19d77a2adcf6a8b6406291e4357797.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698596")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I may count as an expert on some version of Stepanov’s method. I am baffled by this proof (which is very nice, btw) and have been trying without success to see if there is a stronger analogy with the function field case. I’ve also tried (with AI) to go the other way and see what this argument gives in the function field case. It does give something nontrivial but doesn’t improve on known results (of course, GRH is known for function fields). Another remark is that a baby version of this argument is in Disquisitiones, art 129.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698426")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Is SAIR open source model trustable in the sense there is little to be worried about being scooped? I worry on it if I use corporate models.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("By default, data from using the model is not used for model training, but one can opt into this by selecting a toggle at the top of the web page interface. While we do rely on some donated cloud compute, we are not routing our model interface through the servers of any AI company. More information about our data sovereignty policy can be found at ")#link("https://www.openmathmodel.org/about/")[#text("https://www.openmathmodel.org/about/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698430")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Thank you")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c6830f89eef27daaadb36afcb70dfac332d31ce8f0685f705b200c47b0dfaba-6ab62c74d38b9ede9a015c32d9e5a304059bd4f555aa7fed622550b50a6dde29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dhou")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698438")[#strong[#text("Dhou")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I’m actually concerned its capacity is too limited to compete with big players on large-scale problems; it may only tackle smaller ones.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094daa04d6c3bb0b2619cc0d2b8852188b1c0e319230f7c3334df26b5bed0110-368edc4cb729473c423c02458ce34d83804d3207aedaf6e1cddb70be0d92785b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arsenniy")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698433")[#strong[#text("Arsenniy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("genuinely what did i study analytic NT for if AI does this now. next its gonna be RH for all automorphic L-functions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698434")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("It seems the q is undefined (for the O(log q) term etc.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698437")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("This seems to be a somewhat bad end for the story of Yitang Zhang.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698452")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("I’m hoping actually that Yitang’s two incomplete preprints on the Siegel zero problem now receive some more attention (using AI tools if necessary); for instance, with the tenth discriminant challenge I just posted, it is concievable that some of the ideas from those papers could be combined with one of the existing resolutions of the problem to get a stronger bound on the tenth discriminant than would be available without Yitang’s work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698446")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("In the definition of the horizontal resultant, powers of $z_2$ appear that I think should instead be $z_1$")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08ccd2004879f10b1c23b484c35e8aa6df0989c6ad4fbf23fc18138548273866-373c45592882af36d770a69b2583ca10f1d70add961f9f2a054893a98c19964d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698459")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("The resultant of a polynomial with its first derivative is usually called the discriminant of the polynomial (up to a sign factor that is irrelevant here). The key lemma in the injectivity proof is therefore the claim that a polynomial in ")#mi("z_1, z_2")#text(" whose restriction to a given value of ")#mi("z_2")#text(" vanishes to order ")#mi("J")#text(" at some point has discriminant in ")#mi("z_1")#text(" vanishing to order at least ")#mi("J-1")#text(" at that value of ")#mi("z_2")#text(". This fact about discriminants essentially goes back to Sylvester, who proved in 1852 that all the ")#mi("J-1")#text("st derivatives of the discriminant, expressed as a polynomial in the coefficients of a universal polynomial, vanish at points where the polynomial has a root of multiplicity ")#mi("J")#text(".")

#text("To algebraic number theorists, the analogous fact that if a prime of a number field lying over ")#mi("p")#text(" has ramification index at least ")#mi("J")#text(" then ")#mi("p^{J-1}")#text(" divides the discriminant of the number field might be more familiar.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b0ff957cc3a07c7bcf007b031948591baa120075111033161781a507e9142ec-01884b2fd037b1ef9035ecf3ccbd17d1ace80fa06252dcb06df35f484605c646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698462")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Thanks Will. I did try to use ChatGPT to find the correct reference for this and it failed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Nice! Here is an analysis way of thinking about this fact. The discriminant of a polynomial ")#mi("P(z_1)")#text(" is essentially the product ")#mi("\\prod_\\alpha \\prod_\\beta (\\alpha - \\beta)")#text(" of the differences between the zeroes ")#mi("\\alpha")#text(" and critical points ")#mi("\\beta")#text(" of ")#mi("P")#text(". If there is a vanishing to order ")#mi("J")#text(", then we have ")#mi("J")#text(" zeroes and ")#mi("J-1")#text(" critical points all coinciding at some fixed value ")#mi("z_1^0")#text(". Now suppose that the polynomial depends on an additional parameter ")#mi("z_2")#text(", which has this order ")#mi("J")#text(" vanishing at ")#mi("z_2 = z_2^0")#text(". If we perturb ")#mi("z_2")#text(" by some small quantity ")#mi("\\varepsilon")#text(", then we expect all the zeroes currently at ")#mi("z_1^0")#text(" to move by about ")#mi("\\varepsilon^{1/J}")#text(", and the critical points to move by about ")#mi("\\varepsilon^{1/(J-1)}")#text(" due to the degeneracy. So the ")#mi("J(J-1)")#text(" differences ")#mi("\\alpha-\\beta")#text(" would be expected to move by ")#mi("O(\\varepsilon^{1/J})")#text(", making the product vary by ")#mi("O(\\varepsilon^{J-1})")#text(", explaining the order ")#mi("J-1")#text(" vanishing of the discriminant/resultant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698552")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Dear Professor Tao,")

#text("Thank you very much for your illuminating exposition. I have read Ben Green’s simplified proof and your blog post, and I would like to ask a question about the possible scope of the underlying adelic polynomial method.")

#text("My understanding is that the central idea is to examine a single integer ")#mi("M=\\det G")#text(" from two different perspectives. This integer is the squared covolume of a certain polynomial evaluation lattice. The Frobenius action, reflecting the intrinsic arithmetic structure of the quadratic extension, provides lower bounds for its (p)-adic valuations, while Hadamard’s inequality gives an Archimedean upper bound through the geometry of the evaluation vectors in characteristic zero. Comparing these bounds yields a uniform estimate for the distribution of primes satisfying ")#mi("\\chi(p)=-1")#text(", which can then be used to exclude Landau–Siegel zeros.")

#strong[#text("I wonder whether this argument could be developed into a more refined, multiscale formulation.")]

#text("First, as a small remark, the particular square grid ")#mi("E")#text(" used in Green’s construction does not seem essential. It appears that one could instead choose sufficiently many conjugate points corresponding to lattice points in a larger disk, or in another bounded convex region, provided that the necessary height and interpolation estimates remain valid. In this sense, the construction seems to possess a certain geometric stability.")

#text("This suggests studying ")#mi("M(E)")#text(" as the underlying region expands or changes shape, rather than considering only a single fixed configuration. Could there be a more refined theory describing the evolution of such geometric invariants across different scales? In particular, might inequalities relating these quantities at different scales lead to stronger uniform prime-distribution estimates, perhaps revealing information beyond the cumulative estimates obtained from a single determinant?")

#text("There are already some related developments: your observation that Green’s argument yields a bound of the form")#linebreak()#mi("\\sum_{\\substack{p\\le x\\ \\chi(p)=-1}}\\frac{\\log p}{p}\\le \\frac12\\log x+O(\\log q)+O(\\log\\log x),")#linebreak()#text("and the subsequent refinements by Pescador and Barretto mentioned in your post. In a somewhat different setting, Salberger’s global p-adic determinant method combines information from many primes to obtain uniform rational-point counting estimates. More recently, Frei, Sofos, and Widmer have obtained effective Chebotarev estimates conditional on quasi-RH. I wonder whether a multiscale refinement of Green’s construction might provide another way to understand such uniformity, or perhaps yield more detailed information about its dependence on scale.")

#strong[#text("A more ambitious question concerns higher-degree and non-abelian extensions.")]

#text("If we replace the quadratic extension by a general Galois extension, possibly with Galois group ")#mi("S_n")#text(" or another non-abelian group, the Frobenius structure becomes more complicated. In particular, Frobenius elements are only canonically defined up to conjugacy, and the simple two-coordinate relation exploited in the quadratic case no longer applies directly. Perhaps some of the resulting difficulties could be compensated for by studying more refined invariants of the evaluation lattice.")

#text("The determinant ")#mi("M(E))")#text(" records only its full-dimensional squared covolume. Could one obtain more information by considering its successive minima, intermediate-dimensional covolumes, or the determinantal divisors and Smith invariants of the evaluation map?")

#text("For instance, by Cauchy–Binet, the elementary symmetric sums of the principal minors of ")#mi("G")#text(" can be expressed as sums of squared intermediate-dimensional volumes. Although these particular sums depend on the chosen basis, they suggest that one might study the exterior powers of the evaluation map, or more intrinsic lattice invariants, rather than only its top determinant.")

#text("I wonder whether there could be an adelic theory controlling such quantities simultaneously, perhaps with inequalities relating their behavior at different scales and at different places.")

#strong[#text("Finally, there is a more speculative connection that I would particularly like to ask about.")]

#text("Recent quasi-Riemann hypothesis results for Dedekind zeta functions have used metaplectic methods related to Kazhdan–Patterson theory, where Poisson summation and higher-order Gauss sums play important roles. These methods seem quite different from Green’s determinant argument, but I wonder whether the two approaches might be related through some form of duality.")

#text("What I have in mind is the classical interplay between the geometry of numbers, lattice-point counting, and additive combinatorics through Fourier duality and Poisson summation (cf. Tao–Vu, ")#emph[#text("Additive Combinatorics")]#text(", §§3.5, 4.1, and 4.4).")

#text("Could the geometric information encoded in an evaluation lattice, perhaps through its successive minima or intermediate-dimensional volumes, have a dual description in terms of exponential sums or additive relations? If so, might this provide a conceptual bridge between the Frobenius–determinant method and some of the Fourier-analytic structures underlying metaplectic methods?")

#text("I realize that this last suggestion is quite speculative, and I can certainly try to explore the technical details separately, including with GPT. But what I would particularly appreciate is your intuition about whether there might be a genuine mathematical connection here, or whether there is some fundamental obstruction that I am overlooking.")

#text("Thank you very much for your time and thoughts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698554")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I’m recording here a presentation of the standard proof of Mertens’ theorem ")#mi("\\sum_{p \\leq N} \\frac{\\log p}{p} = \\log N + O(1)")#text(" in the spirit of the above approach. For simplicity I will just focus on the upper bound ")#mi("\\sum_{p \\leq N} \\frac{\\log p}{p} \\leq \\log N + O(1)")#text("; the lower bound can be proven by a variant of the method which I leave to the reader.")

#text("The quantity ")#mi("M")#text(" to analyze here is simply the factorial ")#mi("M = N!")#text(", which is obviously non-zero. For the upper bound, we use the crude bound ")#mi("M \\leq N^N")#text(" (the analogue of the Hadamard bound). For the lower bound, observe that each prime ")#mi("p")#text(" divides ")#mi("N!")#text(" at least ")#mi("\\lfloor N/p\\rfloor = N/p - O(1)")#text(" times. From (3) we thus have")

#mi("\\sum_{p \\leq N} (\\frac{N}{p} - O(1)) \\log p \\leq N \\log N")

#text("giving the required bound (using Chebyshev’s elementary bound ")#mi("\\sum_{p \\leq N} \\log p \\ll N")#text(" to control the error).")

#text("If one replaces ")#mi("N!")#text(" by the square of the Vandermonde determinant ")#mi("\\mathrm{det}( i^j )_{0 \\leq i,j < N}")#text(" (which is the superfactorial of ")#mi("N-1")#text("), then one in fact gets a nearly identical argument to the one in the blog post, but now the role of the quadratic ring of integers is just played by the ordinary rational integers, and one works with polynomials of one variable, rather than two, to get essentially the same Mertens upper bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/343da7ee593f8fe0dabbe2050bf714516d94763484cd9f362503a7fa5e39c11a-c376f792f2bc23c4292cf4323a610d2dee8c025d5b434d013151d0fda24f9b24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698716")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("There is a version of this proof which gives a result for quadratic")#linebreak()#text("characters. Look at ")#mi("M = \\prod_{0 < a^2+Db^2 < R^2} (a^2+Db^2)")#text(". The archimedean estimate is ")#mi("\\log M \\approx \\tfrac{1}{\\sqrt{q}} \\int_{r=1}^R (2 \\pi r) \\log r^2 = \\tfrac{2 \\pi}{\\sqrt{D}} R^2 \\log R")#text(".")

#text("The non-archimedean estimate: if ")#mi("\\left( \\tfrac{D}{p}\\right) = 1")#text(", then there are two primes, ")#mi("\\pi_1")#text(" and ")#mi("\\pi_2")#text(", sitting above ")#mi("p")#text(" and each of them divide ")#mi("\\tfrac{\\pi R^2}{\\sqrt{D} p}")#text(" many points. This gives a contribution of ")#mi("\\sum_{p \\leq R^2,\\left( \\tfrac{D}{p}\\right) = 1} \\tfrac{\\pi R^2}{\\sqrt{D} p} \\log p = \\tfrac{2 \\pi}{\\sqrt{D}} R^2 \\sum_{p \\leq R^2,\\left( \\tfrac{D}{p}\\right) = 1} \\tfrac{\\log p}{p}")#text(".")

#text("So ")#mi("\\sum_{p \\leq R^2,\\left( \\tfrac{D}{p}\\right) = 1} \\tfrac{\\log p}{p} \\approx \\log R = \\tfrac{1}{2} \\log R^2")#text(".")

#text("This isn’t original to me; I can try to track down where I’ve seen")#linebreak()#text("it. I’ve never seen anyone do an error bound about what it would mean for Siegel zeroes, but I assume that someone must have tried this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698719")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("I think this argument can be used to exclude Siegel poles – a pole ")#mi("L(\\beta,\\chi)=\\infty")#text(" really close to ")#mi("1")#text(". Of course we can exclude these poles easily by other means (non-principal L-functions are entire). But this argument gives the matching bound ")#mi("\\sum_{p \\leq R^2, \\left(\\frac{D}{p}\\right) = 1} \\frac{\\log p}{p} \\leq \\log R + \\dots")#text(" to the bound ")#mi("\\sum_{p \\leq R^2, \\left(\\frac{D}{p}\\right) = -1} \\frac{\\log p}{p} \\leq \\log R + \\dots")#text(" essentially proven in the blog post, by a broadly similar method – the difference is that the selection of the quantity ")#mi("M")#text(" is a bit more sophisticated (a determinant rather than a product).")

#text("p.s. I have learned (from Ben Green and Bryce Kerr) that a similar argument also appears in ")#link("https://www.cambridge.org/core/journals/canadian-journal-of-mathematics/article/an-elementary-proof-of-the-primenumber-theorem-for-arithmetic-progressions/4777B9A63C6938A14FA318C1BB593CE4")[#text("this 1949 paper of Selberg")]#text(" (see pages 71-72). In this notation, Selberg shows ")#mi("\\sum_{p \\leq R^2, \\left(\\frac{D}{p}\\right) = 1} \\frac{\\log p}{p} = \\log R + O_D(1)")#text(", though the bound on the error term ")#mi("O_D(1)")#text(" is not strong enough to rule out Siegel zeroes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cc134eb125c7ff951c79ca6e85f0c574792a02b0f5c8386a3b2fa8a30e0cd04-58cef40e760b19306a1f7b5e7bd005ec1afade56acd7969635a3d7a484442804.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Rui")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698555")[#strong[#text("Daniel Rui")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I’m sorry to join the long line of people “trying to pull Excalibur out of the stone” but I wanted to share a beautiful and simple algebraic geometry lemma that I learned about while “vibemathing” the Landau-Siegel proof, especially Kerr’s version of it. I for some reason find Kerr’s route more “tangible”/”geometric” compared to the derivative/multiplicity route in Green, Tao, etc, even if it comes at the cost of a larger (biquadratic) grid (cardinality N^4), compared to a quadratic grid (cardinality N^2).")

#text("Here’s my summary of the polynomial method ideas used:")#linebreak()#text("I want to force a (non-zero) polynomial F (X, Y, Z) to vanish at every grid point ∈ G.")#linebreak()#text("The key trick is to show “sparseness” of residue patterns (of values of polynomials f on G) mod")#linebreak()#text("P (for some large P), use “pigeonhole and subtraction” to get a polynomial F = f − g that")#linebreak()#text("takes values divisible by P on G but has small coefficients, and use essentially the “discreteness")#linebreak()#text("phenomenon” that the only multiple of P in [0, P) is 0.")

#text("The key geometric lemma (pasted below) replaces Kerr’s appeal to Masser’s theorem, and vaguely gives me a similar “flavor” to many other “sumset to subspace” results in additive combinatorics, like PFR/Marton’s conjecture. I’ve cobbled together a very rough set of personal notes on this route ")#link("https://danielrui.com/papers/landauSiegelAGnotes.pdf")[#text("https://danielrui.com/papers/landauSiegelAGnotes.pdf")]#text(" but in light of the huge influx of expositions on the same topic it is not clear that it is worth making it more readable to someone other than me.")

#text("Key geometric input to the main result")#linebreak()#text("Theorem 0.4: Low sumset (polynomial) complexity forces low subspace (translation) complexity.")#linebreak()#text("Let 0 ∈ E ⊆ C^3 be finite and contain the origin. Suppose a (non-zero) degree D polynomial F ∈ C[x, y, z] vanishes on the triple sumset E + E + E. Then there is a (proper) C-vector-space V ⊊ C^3 s.t.")#linebreak()#text("E is covered by ≤D^{codim(V)} many translates of V .")#linebreak()#text("The conclusion can be written equivalently as: letting r := codim(V ),")#linebreak()#text("|(E + V)/V| ≤ D^r or #(E mod V) ≤ D^r .")

#text("Slogan: “if repeated addition doesn’t increase complexity much, then there must be hidden translation symmetry”.")

#text("Some history of “Sumset to Subspace” deductions in additive combinatorics.")

#list(
[#text("A main one that comes to mind for me is a key step in Kelley–Meka’s 2023 work on 3AP’s,")#linebreak()#text("namely “almost periodicity” (Key Step 4 in Bloom–Sisask exposition). Theirs is a much stronger")#linebreak()#text("“filling” conclusion (finding a small-codimension subspace W that fills up a significant fraction of")#linebreak()#text("a sumset A + A of an α-dense A), than the “covering” conclusion we need here, but I think it has")#linebreak()#text("a similar spirit.")],
[#text("Polynomial Frieman-Ruzsa/Marton’s conjecture says that if a sumset is small (doesn’t increase")#linebreak()#text("size by more than a constant factor), then it is covered by a small number (polynomial in the")#linebreak()#text("constant factor) translates of a subspace/subgroup. Very similar flavor to what our key tool here.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698969")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2026")])]

#text("I have since turned most of the non-Appendix portion of the notes into a live talk ")#link("https://www.youtube.com/watch?v=HfCKTUXRakE")[#text("https://www.youtube.com/watch?v=HfCKTUXRakE")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698770")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("I think it should be “in contrast to the situation with E’ (prime missing)”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698773")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#align(center)[
#mi("{(R-1)-(R-2)-k}")
]

#text("should be (R-1)+(R-2)-k")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698774")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("I think it should be “Every component of T(z^i_1 z^j_2)” instead of ||z^i_1 z^j_2||")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-698794")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("I don’t understand ")#link("https://s0.wp.com/latex.php?latex=%7Bk_%7Bi%2Cj%7D+%3D+%281+%2B+O%28%5Cvarepsilon%29%29+%5Cfrac%7Bi%7D%7Bp%7D%7D&bg=ffffff&fg=000000&s=0&c=20201002&zoom=4.5")[#text("https://s0.wp.com/latex.php?latex=%7Bk_%7Bi%2Cj%7D+%3D+%281+%2B+O%28%5Cvarepsilon%29%29+%5Cfrac%7Bi%7D%7Bp%7D%7D&bg=ffffff&fg=000000&s=0&c=20201002&zoom=4.5")]

#text("First of all it’s an upper bound, whereas we need a lower bound. A natural idea to fix this is postulating")

#text("k_{i,j} >= (1-O(eps)) i/p,")

#text("but this is false for small i (eg k = 0 for i < p). What am I missing?")

#emph[#text("[Corrected by adding a second lower order term – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92a68adcd0f913864a3bbd43dc688fbdb13abc06a9f7459a866a131241a21192-dc8edfb71c24678bdf75bd3e38c14cdbd8531086bcc78c413440d2088650fff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terrence Han")]], [#link("https://terrytao.wordpress.com/2026/10/19/a-sketch-of-the-proof-of-non-existence-of-siegel-zeroes/comment-page-1/#comment-699030")[#strong[#text("Terrence Han")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Dear Professor Tao,")

#text("In the introductory paragraph discussing D = −163, the ring of integers should be ℤ[(1 + √(−163))/2], rather than ℤ[√(−163)], as explained in Exercise 3 and Remark 4 of your linked 2014 notes.")

#emph[#text("[Corrected, thanks – T.]")]
]
