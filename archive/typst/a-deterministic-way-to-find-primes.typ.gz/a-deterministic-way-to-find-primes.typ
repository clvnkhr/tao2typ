// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:36:17.471585+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Deterministic methods to find primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Deterministic methods to find primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/")[#text("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve uploaded to the arXiv the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath")]#text(" research paper “D")#link("http://arxiv.org/abs/1009.3956")[#text("eterministic methods to find primes")]#text("“, which is the outcome of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("Polymath4")]#text(" collaborative mathematics project, and has been submitted to ")#link("http://www.ams.org/publications/journals/journalsframework/mcom")[#text("Mathematics of Computation")]#text(".")

#text("The objective of this paper was to find fast ")#emph[#text("deterministic")]#text(" algorithms to solve the following problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Given a (large) integer x, find a prime p larger than x.")
]

#text("Thanks to the ")#link("http://en.wikipedia.org/wiki/AKS_primality_test")[#text("AKS algorithm")]#text(", a number of size O(x) can be deterministically tested for primality in time ")#mi("O( \\log^{O(1)} x ) = O( x^{o(1)} )")#text(". By ")#link("http://en.wikipedia.org/wiki/Bertrand's_postulate")[#text("Bertrand’s postulate")]#text(", there is always at least one prime between x and 2x; by testing each one of these integers in turn for primality, one can thus obtain a deterministic algorithm to find primes in time ")#mi("O( x^{1+o(1)})")#text(".")

#text("But one should be able to do much better. For comparison, if probabilistic algorithms are allowed, then by randomly selecting integers between x and 2x to test for primality, it is easy to see from the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" that one will succeed in obtaining a prime with high probability in time ")#mi("O( \\log^{O(1)} x ) = O( x^{o(1)} )")#text(". However, after some effort we were not able to “derandomise” this algorithm to create any reasonable deterministic counterpart. Nevertheless, we conjecture that a deterministic algorithm with run time ")#mi("O( x^{o(1)})")#text(" exists. Such algorithms can be easily obtained if one assumes some standard conjectures regarding the primes (e.g. ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r's_conjecture")[#text("Cramer’s conjecture")]#text(" on prime gaps), but we do not know of any deterministic algorithms which can be unconditionally proved to run in time ")#mi("O( x^{o(1)})")#text(".")

#text("Currently, the best known deterministic algorithm is due to ")#link("http://www.ams.org/mathscinet-getitem?mr=890871")[#text("Lagarias and Odlyzko")]#text(", and has a run time of ")#mi("O( x^{1/2+o(1)})")#text(". Roughly speaking, it is based on the ability to compute the ")#link("http://en.wikipedia.org/wiki/Prime-counting_function")[#text("prime counting function")]#text(" ")#mi("\\pi(x)")#text(" in time ")#mi("O( x^{1/2+o(1)} )")#text("; once one has this function, one can detect which intervals contain primes or not, and then starting from Bertrand’s postulate and performing a binary search one can then locate a prime. The Lagarias-Odlyzko argument is based on approximating ")#mi("\\pi(x)")#text(" by a certain integral of the Riemann zeta function, which one then approximates in turn by ")#link("http://en.wikipedia.org/wiki/Gaussian_quadrature")[#text("quadrature")]#text(".")

#text("We conjecture that one should be able to compute ")#mi("\\pi(x)")#text(" in faster time, and in particular in time ")#mi("O(x^{1/2-c+o(1)})")#text(" for some ")#mi("c>0")#text(". Unfortunately, we were not able to achieve this; however, we do have a non-trivial method to compute the ")#emph[#text("parity")]#text(" ")#mi("\\pi(x) \\text{ mod } 2")#text(" of ")#mi("\\pi(x)")#text(" in such a time; a bit more generally (and oversimplifying a little bit), we can compute various projections ")#mi("\\sum_{p \\leq x} t^p \\text{ mod } 2, g(t)")#text(" of the prime polynomial ")#mi("\\sum_{p \\leq x} t^p")#text(" modulo some small polynomials g. This seems close to being able to achieve the goal of detecting whether primes exist in a given interval, but unfortunately some additional work seems to be needed in that area. Still, the methods used to get the parity seem to be interesting (involving the Dirichlet hyperbola method, a piecewise approximation of the hyperbola, and the Strassen fast multiplication algorithm), and these techniques might be useful for some other problems.")

#text("Roughly speaking, the idea to compute the parity of ")#mi("\\pi(x) \\text{ mod } 2")#text(" is as follows. The first observation is that, for square-free n, the number ")#mi("\\tau(n)")#text(" of divisors of n is equal to 2 when n is a prime, and a multiple of 4 otherwise. So to compute the parity of ")#mi("\\pi(x)")#text(", it suffices to compute ")#mi("\\sum_{n \\leq x} \\tau(n)")#text(" modulo 4 (or more precisely, the restriction of this sum to squarefree n).")

#text("The restriction to squarefree numbers turns out to be relatively easy to handle, so we ignore it. Since ")#mi("\\tau(n) = \\sum_{a,b: ab=n} 1")#text(", we can rewrite")

#align(center)[#mi("\\sum_{n \\leq x} \\tau(n) = \\sum_{a,b: ab \\leq x} 1")#text(".")]

#text("So it suffices to find an efficient way to count the number of lattice points below the hyperbola ")#mi("\\{ (a,b): ab = x \\}")#text(".")

#text("The classic way to do this is via the ")#link("http://planetmath.org/encyclopedia/HyperbolaMethod.html")[#text("Dirichlet hyperbola method")]#text(". This lets one rewrite the above expression as")

#align(center)[#tao-fit-display[#mitex("2 \\sum_{a \\leq \\sqrt{x}} \\lfloor \\frac{x}{a} \\rfloor - \\lfloor \\sqrt{x}\\rfloor^2")]]

#text("(assuming ")#mi("x")#text(" is not a perfect square, where ")#mi("\\lfloor x \\rfloor")#text(" is the ")#link("http://en.wikipedia.org/wiki/Floor_and_ceiling_functions")[#text("greatest integer function")]#text("). One can then compute this quantity in time ")#mi("O(x^{1/2+o(1)})")#text(" without difficulty.")

#text("To improve this to ")#mi("O(x^{1/2-c+o(1)})")#text(", we used some ideas of Vinogradov, based on using ")#link("http://en.wikipedia.org/wiki/Diophantine_approximation")[#text("Diophantine approximation")]#text(" to find moderately long arithmetic progressions on which the map ")#mi("a \\mapsto \\lfloor \\frac{x}{a} \\rfloor")#text(" is linear, and thus easily summable.")

#text("The same method extends to the polynomial setting, though now, instead of summing an arithmetic progression, one has to find an efficient way to sum quadratic sums such as ")#mi("\\sum_{n=1}^N t^{an^2+bn+c}")#text(". This turns out to be possible by expressing this sum as a matrix product and then using ")#link("http://en.wikipedia.org/wiki/Matrix_multiplication#Algorithms_for_efficient_matrix_multiplication")[#text("fast matrix multiplication")]#text(" algorithms.")

#text("There is still some scope to improve the results and methods further; Ernie Croot is pursuing this with two undergraduate students, David Hollis and David Lowry,")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47191")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("When I look at the paper in the link the title is “Deterministic methods to find primes” instead of “A deterministic way to find primes”. There seems to be a dscrepancy in titles here.")

#emph[#text("[Title corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fa3ab5c173d452443135c0db863e15d964fcf1775ff57677434a83dfd268825-d9dd7dfd545e21c87e20707a54365698fbfb89283d59145d88acee9631451927.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Williams")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47209")[#strong[#text("Ryan Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Hi, this is very interesting work. Wish I’d seen the project earlier.")

#text("Concerning Lemma 3.1: Schoenhage-Strassen is a reference for fast integer multiplication, not matrix multiplication.")

#text("It would be surprising to me if the expression in Lemma 3.1 cannot be solved using a Fast Fourier Transform instead of matrix multiplication (in the most optimistic case, this would result in a complexity of q^{1/2} polylog q rather than q^{1-c}). These matrices are extremely structured. But I understand you are just going for any improvement at all…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Oops, thanks for pointing that out! I’ve changed the reference, which should appear in the next arXiv version.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47318")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Wow, you are still trying to use 19th century mathematics to solve a 21st century problem? Just wow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47319")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Katharine has a point. Very few people have knowledge of sophisticated techniques in mathematics and probably those people are too busy to join polymath projects. Hence may be polymath approach may not work at the highest realm of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47320")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Well, one of the great things about mathematics is that it is cumulative; a tool developed centuries ago can still be used today. For instance, in my work with Ben Green (and Tamar Ziegler) on establishing linear patterns in primes (the final component of which was only finished this month), at one point we relied crucially on a 2300 year old lemma of Archimedes.")

#text("In this particular case, we did consider using some quite high powered machinery, but strangely enough it ended up giving worse results than a more “low-tech” approach. For instance, using the Friedlander-Iwaniec theorem (perhaps one of the deepest results in sieve theory) one only obtained an algorithm with a run time of ")#mi("O( x^{3/4+o(1)} )")#text(" (or ")#mi("O(x^{2/3+o(1)})")#text(" if one uses Heath-Brown’s variant of that theorem), as opposed to the Lagarias-Odlyzko ")#mi("O( x^{1/2+o(1)} )")#text(" algorithm (which came out in 1987, but uses fairly classical methods that would already have been available in the 1920s).")

#text("In general, highly advanced machinery is best suited for problems in mature, well-developed fields. One of the issues here was that while the question was quite simple to state, there had not really been a substantial body of literature built up around this and similar problems. In those situations, classical methods are often quite competitive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47323")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("Professor Tao: Your point is also very correct. Most modern machinery are built from very vast abstraction of classical techniques having been built for specific purposes or problems at hand. At the core one probably can get quite good intuition even with classical methods and it is true that not all classical techniques are put in modern machinery because the need may not have arisen. Hence it may be quite wrong to discard a technique as classical without understanding the fact that a shaving razor may do when a laser may not. But polymath may not attract people from quite mature mathematical fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/332490ee03f370f61a440ba70569b5ca60edc293a4218d277f1b6bd62cde5b37-5626d0625310df53f39d496ff88f7f498d81c19ddf10ad91060f7f4bad6799ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-47375")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("It seems to be possible to multiply the matrices of Lemma 3.1 in time ")#mi("O(N^{o(1)} Q^2)")#text(", up to logarithmic factors in ")#mi("Q")#text(" (everything is “up to log factors in ")#mi("Q")#text("“; I won’t mention it all the time).")

#text("Consider a matrix ")#mi("M")#text(" with entries ")#mi("t^{a i^2 + b j^2 + c ij + d i + e j +f}")#text(", with ")#mi("a,\\dots,f=O(N)")#text(". The main claim is that one can multiply this matrix by a vector in time ")#mi("O(N^{o(1)} Q)")#text(".")

#text("One can factor ")#mi("M")#text(" as ")#mi("D_1 M^{\\prime} D_2")#text(", with ")#mi("D_1")#text(" a diagonal matrix with entries ")#mi("t^{a i^2+d i +f}")#text(", and ")#mi("D_2")#text(" a diagonal matrix with entries ")#mi("t^{b j^2+e j}")#text(". Multiplication of ")#mi("D_1")#text(" or ")#mi("D_2")#text(" by a vector is done in time ")#mi("O(N^{o(1)} Q)")#text(".")

#text("The matrix ")#mi("M^{\\prime}")#text(" has entries ")#mi("t^{c ij}")#text(". To do the matrix-vector product by ")#mi("M^{\\prime}")#text(", one uses the chirp transform algorithm; this takes time ")#mi("O(N^{o(1)} Q)")#text(", using FFT polynomial multiplication. The chirp transform algorithm actually involves divisions by power of ")#mi("t")#text("; I’m not sure if it’s a problem in your context (and I don’t know how to get rid of them…).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cdccd32c075aea66ee418b4746cb67becd4ec18a2c595100e59004ebaed658e-21080ea040839288eadec68653cc4806aa09fa7123566da782feb9ed8b5adb08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahmed")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-83781")[#strong[#text("ahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2011")])]

#text("I was doing some math homework with my 10 year and the general question about prime numbers came up. We did some general explorations to try and find relevance to help learning and we came across your lecture at Northwestern. Useful in cryptography was the best I could do on an explanation.")

#text("A few weeks later: but that use would become defunct if you could calculate Pn…..")

#text("What if Pn could be found by looking at the point at which gravity becomes uneven?")

#text("Given an equal number of equally distributed particles, gravity is evenly distributed as every particle is pulling equally on every other particle. If one particle is lost, the equal distribution collapses and gravity becomes uneven causing the clustering of particles whose gravity increases causes further instability.")

#text("In this case Pn = ∞-1/∞E")

#text("Where:")#linebreak()#text(" ∞ = ∑ of all relevant particles")#linebreak()#text(" E = energy of relevant particles")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-168718")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2012")])]

#text("I have the following question/idea: By the Dirichlet Theorem we know that the sequence ")#mi("ak+b")#text(" has infinitely many primes. Assume that this sequence is ")#mi("(p_1, p_2, \\ldots )")#text(", where ")#mi("p_i= ak_i+b")#text(". Can we find a bound ")#mi("k_{i+1} \\leq f(a,b, k_i)")#text("? Then knowing ")#mi("p_i")#text(", we minimize ")#mi("f(a,b, k_i)")#text(" with respect subject to ")#mi("p_i= ak_i+b")#text(" to find its upper bound ")#mi("k^*")#text(", yielding ")#mi("k_{i+1} \\in [k_i+1, k^*]")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-168729")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2012")])]

#text("If I understand your comment correctly, you are hoping to bound the gap between consecutive primes in arithmetic progressions, after rescaling by the progression spacing. The bounds in this problem are comparable to those for bounding the gap between consecutive primes in the integers; roughly speaking, using a progression of spacing ")#mi("a")#text(" makes the primes denser by a factor of ")#mi("a/\\phi(a)")#text(", but this is a fairly small factor (")#mi("a/\\phi(a)")#text(" can’t get much bigger than ")#mi("\\log \\log a")#text(") and is unfortunately does not give much of an asymptotic saving.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivan Borsenco")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-168854")[#strong[#text("Ivan Borsenco")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2012")])]

#text("Thank you for reply. Yes, that was exactly what I meant. I thought choosing wisely parameters a,b for a given x, we can assure the existence of p in its proximity rescaled by arithmetical progression.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-457300")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2015")])]

#text("Another approach is to use a prime generating polynomial ")#mi("P(x_1,...,x_n)")#text(" (which has the property that its value is a prime number whenever it is positive for nonnegative integer arguments) several explicit such polynomials are known.")#linebreak()#text(" The basic idea (given sufficiently large ")#mi("x")#text(") is to locate ")#mi("X =  (x_1, ... , x_n) \\in [1/2, \\infty)^n")#text(" with the property P0 that ")#mi("P(X^{\\prime}) > x")#text(" whenever ")#mi("X^{\\prime} = (x^{\\prime}_1, ... ,x^{\\prime}_n) \\in \\mathbb R^n")#text(" satisfies")

#tao-math("\\left|x^{\\prime}_i - x_i\\right| \\leq 1/2", block: false)#text(" for ")#mi("i = 1, ... ,n")#text(" (*)")

#text("Therefore, if such ")#mi("X")#text(" (with the above property P0) exists, then by (*) there is ")#mi("X^{\\prime} \\in \\mathbb R^n")#text(" with nonnegative integer components, and therefore ")#mi("P(X^{\\prime})")#text(" must be a prime larger than ")#mi("x")#text(".")

#text("To use this approach, let ")#mi("S_{X, x}")#text(" be the set of ")#mi("X^{\\prime} \\in \\mathbb  R^n")#text(" which satisfy (*) together with ")#mi("P(X^{\\prime}) \\leq x")#text(".")

#text("Clearly, the set ")#mi("S_{X, x}")#text(" (defined for each ")#mi("x \\in \\mathbb R")#text(" and ")#mi("X \\in \\mathbb R^n")#text(") is a semialgebraic set of ")#mi("\\mathbb R^n")#text(". Moreover, if ")#mi("S_{X, x}")#text(" is empty, then ")#mi("X")#text(" should satisfy the above property P0. Hence, to apply this approach, one needs only to locate ")#mi("X \\in [1/2, \\infty)^n")#text(" for which ")#mi("S_{X, x}")#text(" is empty!")

#text("Since ")#mi("S_{X,x}")#text(" is (explicitly constructible) semialgebraic set, it is a finite union of basic semialgebraic sets, and therefore it is empty if and only if ")#mi("X \\in S_x")#text(" where ")#mi("S_x")#text(" is another (explicitly constructible) semialgebraic set of ")#mi("R^n")#text(". Therefore, one needs only to verify that there is ")#mi("X \\in S^{\\prime}_x := [1/2, \\infty)^n \\cap S_x")#text(".")#linebreak()#text(" Since ")#mi("S^{\\prime}_x")#text(" (as a semialgebraic set of ")#mi("\\mathbb R^n")#text(") is nonempty if and only if ")#mi("x \\in S")#text(" where ")#mi("S")#text(" is (explicitly constructible) finite union of real intervals, it remains only to verify that ")#mi("S")#text(" contains every sufficiently large ")#mi("x")#text(". This can be done (at least in principle!), and if it is true (i.e. ")#mi("S^{\\prime}_x")#text(" is nonempty for sufficiently large ")#mi("x")#text("), then the complexity depends mainly on finding ")#mi("X")#text(" in ")#mi("S^{\\prime}_x")#text(" (using algorithmic real algebraic geometry) since finding ")#mi("X^{\\prime}")#text(" from ")#mi("X")#text(" has bounded complexity (just rounding the components of ")#mi("X")#text(") and the computation of the prime ")#mi("P(X^{\\prime})")#text(" has polynomial complexity in the total number of bits representing ")#mi("X^{\\prime}")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e88c7926d9acf39035fcdb3d33ef5c2940f4a00bc7284f30302b5111f1ddb3a4-80cf16a30f288c39529de39aae4b9548b11a77e99b69844b2aea4cfb77fd4807.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of onlyearthleft.")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-474835")[#strong[#text("onlyearthleft.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("Would it be interesting to prove anything non-trivial like improving the O(\\log n) randomized trials needed to get a prime of magnitude n (number of bits is log2 n) assuming abc conjecture?")

#text("Or will such a result be no good?")

#text("Or do you already know deterministic improvement assuming abc?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4067f7136ada9837f2cd5c54851a2f158f21a66ddeb98b8a61b8de837351431b-9c9175531dbabfc034f44dac3161ea55775d2a58aec1bdf463752179b00fb348.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reality")]], [#link("https://terrytao.wordpress.com/2010/09/21/a-deterministic-way-to-find-primes/#comment-490955")[#strong[#text("reality")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2017")])]

#text("The restriction to squarefree numbers turns out to be relatively easy to handle, so we ignore it. Is it sieved away?")
]
