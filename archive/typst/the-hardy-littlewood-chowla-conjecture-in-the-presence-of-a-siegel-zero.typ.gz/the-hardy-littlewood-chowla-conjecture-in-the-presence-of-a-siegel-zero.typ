// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/
// Converted to Typst by tao2typ: "2026-10-14T16:38:59.112465+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Hardy–Littlewood–Chowla conjecture in the presence of a Siegel zero", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Hardy–Littlewood–Chowla conjecture in the presence of a Siegel zero")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 September 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/")[#text("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://sites.google.com/view/joniteravainen/")[#text("Joni Teräväinen")]#text(" and I have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2109.06291")[#text("The Hardy–Littlewood–Chowla conjecture in the presence of a Siegel zero")]#text("“. This paper is a development of the theme that certain conjectures in analytic number theory become easier if one makes the hypothesis that ")#link("https://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zeroes")]#text(" exist; this places one in a presumably “illusory” universe, since the widely believed ")#link("https://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("Generalised Riemann Hypothesis")]#text(" (GRH) precludes the existence of such zeroes, yet this illusory universe seems remarkably self-consistent and notoriously impossible to eliminate from one’s analysis.")

#text("For the purposes of this paper, a Siegel zero is a zero ")#mi("{\\beta}")#text(" of a Dirichlet ")#mi("{L}")#text("-function ")#mi("{L(\\cdot,\\chi)}")#text(" corresponding to a primitive quadratic character ")#mi("{\\chi}")#text(" of some conductor ")#mi("{q_\\chi}")#text(", which is close to ")#mi("{1}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\beta = 1 - \\frac{1}{\\eta \\log q_\\chi}")]]

#text("for some large ")#mi("{\\eta \\gg 1}")#text(" (which we will call the ")#emph[#text("quality")]#text(") of the Siegel zero. The significance of these zeroes is that they force the Möbius function ")#mi("{\\mu}")#text(" and the Liouville function ")#mi("{\\lambda}")#text(" to “pretend” to be like the exceptional character ")#mi("{\\chi}")#text(" for primes of magnitude comparable to ")#mi("{q_\\chi}")#text(". Indeed, if we define an ")#emph[#text("exceptional prime")]#text(" to be a prime ")#mi("{p^*}")#text(" in which ")#mi("{\\chi(p^*) \\neq -1}")#text(", then very few primes near ")#mi("{q_\\chi}")#text(" will be exceptional; in our paper we use some elementary arguments to establish the bounds")

#metadata(none) <tao-e98f0ebacdcc6f322f25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{q_\\chi^{1/2+\\varepsilon} < p^* \\leq x} \\frac{1}{p^*} \\ll_\\varepsilon \\frac{\\log x}{\\eta \\log q_\\chi}")]]

#text("for any ")#mi("{x \\geq q_\\chi^{1/2+\\varepsilon}}")#text(" and ")#mi("{\\varepsilon>0}")#text(", where the sum is over exceptional primes in the indicated range ")#mi("{q_\\chi^{1/2+\\varepsilon} < p^* \\leq x}")#text("; this bound is non-trivial for ")#mi("{x}")#text(" as large as ")#mi("{q_\\chi^{\\eta^{1-\\varepsilon}}}")#text(". (See Section 1 of ")#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/")[#text("this blog post")]#text(" for some variants of this argument, which were inspired by work of Heath-Brown.) There is also a companion bound (somewhat weaker) that covers a range of ")#mi("{p^*}")#text(" a little bit below ")#mi("{q_\\chi^{1/2}}")#text(".")

#text("One of the early influential results in this area was the following ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("result of Heath-Brown")]#text(", which I previously ")#link("https://terrytao.wordpress.com/2015/08/26/heath-browns-theorem-on-prime-twins-and-siegel-zeroes/")[#text("blogged about here")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hardy-Littlewood assuming Siegel zero)")]#text(" Let ")#mi("{h}")#text(" be a fixed natural number. Suppose one has a Siegel zero ")#mi("{\\beta}")#text(" associated to some conductor ")#mi("{q_\\chi}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+h) = ({\\mathfrak S} + O( \\frac{1}{\\log\\log \\eta} )) x")]]

#text("for all ")#mi("{q_\\chi^{250} \\leq x \\leq q_\\chi^{300}}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" and ")#mi("{{\\mathfrak S}}")#text(" is the ")#emph[#text("singular series")]

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} = \\prod_{p|h} \\frac{p}{p-1} \\prod_{p \\nmid h} (1 - \\frac{1}{(p-1)^2})")]]
]

#text("In particular, Heath-Brown showed that if there are infinitely many Siegel zeroes, then there are also infinitely many twin primes, with the correct asymptotic predicted by the Hardy-Littlewood prime tuple conjecture at infinitely many scales.")

#text("Very recently, ")#link("https://arxiv.org/abs/2105.14653")[#text("Chinis established")]#text(" an analogous result for the Chowla conjecture (building upon earlier work ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2607678")[#text("of Germán and Katai")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Chowla assuming Siegel zero)")]#text(" Let ")#mi("{h_1,\\dots,h_\\ell}")#text(" be distinct fixed natural numbers. Suppose one has a Siegel zero ")#mi("{\\beta}")#text(" associated to some conductor ")#mi("{q_\\chi}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\lambda(n+h_1) \\dots \\lambda(n+h_\\ell) \\ll \\frac{x}{(\\log\\log \\eta)^{1/2} (\\log \\eta)^{1/12}}")]]

#text("in the range ")#mi("{q_\\chi^{10} \\leq x \\leq q_\\chi^{\\log\\log \\eta / 3}}")#text(", where ")#mi("{\\lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(".")
]

#text("In our paper we unify these results and also improve the quantitative estimates and range of ")#mi("{x}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Hardy-Littlewood-Chowla assuming Siegel zero)")]#text(" Let ")#mi("{h_1,\\dots,h_k,h^{\\prime}_1,\\dots,h^{\\prime}_\\ell}")#text(" be distinct fixed natural numbers with ")#mi("{k \\leq 2}")#text(". Suppose one has a Siegel zero ")#mi("{\\beta}")#text(" associated to some conductor ")#mi("{q_\\chi}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n+h_1) \\dots \\Lambda(n+h_k) \\lambda(n+h^{\\prime}_1) \\dots \\lambda(n+h^{\\prime}_\\ell)")]]

#align(center)[#tao-fit-display[#mitex("= ({\\mathfrak S} + O_\\varepsilon( \\frac{1}{\\log^{1/10\\max(1,k)} \\eta} )) x")]]

#text("for")

#align(center)[#tao-fit-display[#mitex("q_\\chi^{10k+\\frac{1}{2}+\\varepsilon} \\leq x \\leq q_\\chi^{\\eta^{1/2}}")]]

#text("for any fixed ")#mi("{\\varepsilon>0}")#text(".")
]

#text("Our argument proceeds by a series of steps in which we replace ")#mi("{\\Lambda}")#text(" and ")#mi("{\\lambda}")#text(" by more complicated looking, but also more tractable, approximations, until the correlation is one that can be computed in a tedious but straightforward fashion by known techniques. More precisely, the steps are as follows:")

#list(
[#text("(i) Replace the Liouville function ")#mi("{\\lambda}")#text(" with an approximant ")#mi("{\\lambda_{\\mathrm{Siegel}}}")#text(", which is a completely multiplicative function that agrees with ")#mi("{\\lambda}")#text(" at small primes and agrees with ")#mi("{\\chi}")#text(" at large primes.")],
[#text("(ii) Replace the von Mangoldt function ")#mi("{\\Lambda}")#text(" with an approximant ")#mi("{\\Lambda_{\\mathrm{Siegel}}}")#text(", which is the Dirichlet convolution ")#mi("{\\chi * \\log}")#text(" multiplied by a ")#link("https://en.wikipedia.org/wiki/Selberg_sieve")[#text("Selberg sieve")]#text(" weight ")#mi("{\\nu}")#text(" to essentially restrict that convolution to almost primes.")],
[#text("(iii) Replace ")#mi("{\\lambda_{\\mathrm{Siegel}}}")#text(" with a more complicated truncation ")#mi("{\\lambda_{\\mathrm{Siegel}}^\\sharp}")#text(" which has the structure of a “Type I sum”, and which agrees with ")#mi("{\\lambda_{\\mathrm{Siegel}}}")#text(" on numbers that have a “typical” factorization.")],
[#text("(iv) Replace the approximant ")#mi("{\\Lambda_{\\mathrm{Siegel}}}")#text(" with a more complicated approximant ")#mi("{\\Lambda_{\\mathrm{Siegel}}^\\sharp}")#text(" which has the structure of a “Type I sum”.")],
[#text("(v) Now that all terms in the correlation have been replaced with tractable Type I sums, use standard Euler product calculations and Fourier analysis, similar in spirit to the proof of the pseudorandomness of the Selberg sieve majorant for the primes in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2680398")[#text("this paper of Ben Green and myself")]#text(", to evaluate the correlation to high accuracy.")]
)

#text("Steps (i), (ii) proceed mainly through estimates such as ")#link(<tao-e98f0ebacdcc6f322f25>)[#text("(1)")]#text(" and standard sieve theory bounds. Step (iii) is based primarily on estimates on the number of ")#link("https://en.wikipedia.org/wiki/Smooth_number")[#text("smooth numbers")]#text(" of a certain size.")

#text("The restriction ")#mi("{k \\leq 2}")#text(" in our main theorem is needed only to execute step (iv) of this step. Roughly speaking, the Siegel approximant ")#mi("{\\Lambda_{\\mathrm{Siegel}}}")#text(" to ")#mi("{\\Lambda}")#text(" is a twisted, sieved version of the divisor function ")#mi("{\\tau}")#text(", and the types of correlation one is faced with at the start of step (iv) are a more complicated version of the divisor correlation sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n+h_1) \\dots \\tau(n+h_k).")]]

#text("For ")#mi("{k=1}")#text(" this sum can be easily controlled by the ")#link("https://en.wikipedia.org/wiki/Dirichlet_hyperbola_method")[#text("Dirichlet hyperbola method")]#text(". For ")#mi("{k=2}")#text(" one needs the fact that ")#mi("{\\tau}")#text(" has a level of distribution greater than ")#mi("{1/2}")#text("; in fact Kloosterman sum bounds give a level of distribution of ")#mi("{2/3}")#text(", a folklore fact that seems to have first been observed by Linnik and Selberg. We use a (notationally more complicated) version of this argument to treat the sums arising in (iv) for ")#mi("{k \\leq 2}")#text(". Unfortunately for ")#mi("{k > 2}")#text(" there are no known techniques to unconditionally obtain asymptotics, even for the model sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) \\tau(n+1) \\tau(n+2),")]]

#text("although we do at least have fairly convincing conjectures as to what the asymptotics should be. Because of this, it seems unlikely that one will be able to relax the ")#mi("{k \\leq 2}")#text(" hypothesis in our main theorem at our current level of understanding of analytic number theory.")

#text("Step (v) is a tedious but straightforward sieve theoretic computation, similar in many ways to the correlation estimates of Goldston and Yildirim used in their work on small gaps between primes (as discussed for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3728621")[#text("here")]#text("), and then also used ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2415379")[#text("by Ben Green and myself")]#text(" to locate arithmetic progressions in primes.")

#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634159")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("It looks like you missed replacing a \\cite with a link in the description of Step (v).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1d538fe3b2422e0e16e568b12ccc26a9f8b68d5c7b99329084f8f02cd7df7c9-24b0eeb1a83b1abf7ea39057bdccbc69c0288bef4e2b0ea13cbb02f3b7baac78.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gexahedron")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634161")[#strong[#text("gexahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("If both of the worlds, one where generalized Riemann hypothesis is true, and one where Siegel zeros exist, then maybe they are both correct (“real”)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("The mere existence of a Siegel zero seems helpful for finding “good approximants”, but is it really necessary ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e13182a44f061c8601df5e94f22e72296f833f4520df4541d553abd1d800ae6d-d61f54a7c7316c5d6beeb53fc2349dfd34e87cbd7cb78d48522eb5466abf1291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634166")[#strong[#text("Michele")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("The post and the various references of Prof. Tao concerning this topic are very interesting. With regard the Hardy-Littlewood Conjecture, it is fundamental in several areas of mathematics, mainly in Number Theory. But there are also various applications in some sectors of Theoretical Physics.")#linebreak()#text(" ")#link("https://www.academia.edu/45582699/")[#text("https://www.academia.edu/45582699/")]#linebreak()#text(" ")#link("https://www.academia.edu/45586191/")[#text("https://www.academia.edu/45586191/")]#linebreak()#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6ba709f9f4947c91dd60d61bd058aec89529bcb750b632689c4131ecf7d2543-3774efb36107cee096c1e5ed22760841b6832c5715cdd70cb13a44cc747e6e71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matc")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634192")[#strong[#text("Matc")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("Is there a very hand-waving intuition as to why {\\lambda} pretending to be like the exceptional character {\\chi} helps here? Is there some line of reasoning like “{\\lambda} behaves like {\\chi} and {\\chi} is periodic, so {\\lambda} is “periodic” in some vague sense and this prevents some cancellation and thus gives the main term”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("This is sort of right. The Liouville function is difficult to understand because it is related to the zeros of the zeta function, and we don’t have good unconditional results on zeta zeros. A Siegel zero forces the associated quadratic character to nearly behave like the Liouville function, so one can replace Liouville by a Dirichlet character. As you noted, Dirichlet characters are very nice because they are periodic and you can do Fourier analysis and all sorts of useful things with them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634258")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("One standard way is to start with the Dirichlet series identity")

#mi("\\displaystyle \\sum_{n=1}^\\infty \\frac{\\lambda(n) \\chi(n)}{n^s} = \\frac{L(2s,\\chi)}{L(s,\\chi)}")

#text("(valid for ")#mi("\\mathrm{Re} s > 1")#text("). If ")#mi("L(s,\\chi)")#text(" has a zero ")#mi("\\beta")#text(" near ")#mi("s=1")#text(", this identity suggests that the sum ")#mi("\\sum_{n=1}^\\infty \\frac{\\lambda(n) \\chi(n)}{n^s}")#text(" will be large for ")#mi("s")#text(" near ")#mi("1")#text(", and hence there is not much cancellation in this sum. As such, ")#mi("\\lambda")#text(" should be biased to having the same sign as ")#mi("\\chi")#text(" fairly often (i.e., it “pretends” to be like ")#mi("\\chi")#text("), which is a phenomenon one can quantify using the concept of “pretentiousness” in “pretentious number theory”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53def7312bb0595621e9e1e8ba4928920a6d62d1f5b5db3f1174f73f120b7e47-7bf6d54d3b4cb3fe1751f00326e5a7ec0f06ae32ca83d77789ea320d051dca8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harry")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-635681")[#strong[#text("Harry")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("This may lead to a new theory.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6034a3d947bcc320f52310472f09e13a0840639d2dcc727dd09c9067baae5f67-8696de3686fe8de5348756952d8360a134e4ec5de54b618550b275a8c45a165e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634195")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("The definition of the singular series with the gothic letter, the slash below the second product missed the divide sign")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/247d50c94370d440682a562d3d4ef2261286ded9448b0fd722f401d243791746-513053f6d12b25850cc32555900cd0491b14e068227d5c81b74a065cb036ea40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Revantha")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634198")[#strong[#text("Revantha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("Why is it surprising that we can derive interesting results after assuming the existence of Siegel zeroes (since it is widely believed that there are no Siegel zeroes) ?")

#text("Is the point not about any particular result, but rather that various not-especially-related results are derivable from the same assumption ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634259")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("Well, there are a couple reasons:")

#text("1. By exploring this presumably illusory “Siegel zero universe” more extensively, we may eventually be able to hit upon a contradiction, and thus finally resolve the notorious problem of whether Siegel zeroes exist. This could in turn lead to substantial progress more generally towards GRH. (One should caution though that historically every such discovery of an apparent contradiction has fallen apart under more careful scrutiny; the Siegel zero universe seems highly resistant to being destroyed!)")

#text("2. There are several results in analytic number theory (e.g., Linnik’s theorem) that are proven unconditionally by splitting into two cases, one where Siegel zereos exist, and one where they don’t, and pursuing a separate argument to handle each case. So this sort of result could end up being one half of a later unconditional result. The non-Siegel-zero case usually comes with effective bounds, so it is of particular interest to see if the Siegel zero case also has effective estimates, as this would lead to effective unconditional estimates.")

#text("3. Having a good working understanding of the Siegel zero “alternate universe” helps one detect errors (or at least raise serious red flags) in claimed results in analytic number theory that are inconsistent with that universe, such as results that breeze through various “parity barriers” without demonstrating any awareness at all of the potential existence of Siegel zeroes. Sometimes one can narrow down where the specific error occurs in a manuscript by testing individual assertions in that manuscript under the hypothesis of a Siegel zero to find out the first place where an inconsistency occurs. In a similar spirit, the Siegel zero universe places barriers to improving the constants in various bounds (e.g., the constants in the large sieve inequality) and allows one to assert that certain results are “optimal at the current level of technology” by demonstrating that any further improvement in the bounds would be incompatible with the existence of Siegel zeroes.")

#text("4. In some cases, such as in our paper, the Siegel zero universe is *more* computationally tractable than the GRH universe that one expects to be the real one; GRH does not let us prove either the Hardy-Littlewood or Chowla conjectures at our current level of technology! This allows us to develop calculations to a level of precision that is not available on GRH, which can help develop technology that will one day also be useful for applications outside the Siegel zero universe. For instance, the techniques in this paper seem to be adaptable to allow for relatively straightforward calculations for the predicted asymptotics for divisor correlations such as ")#mi("\\sum_{n \\leq x} d_{k_1}(n+h_1) \\dots d_{k_\\ell}(n+h_\\ell)")#text(", even if we are still missing the technology to rigorously establish these correlations in most cases (right now we can basically only handle the cases when ")#mi("\\ell=1")#text(", or when ")#mi("\\ell=2")#text(" and ")#mi("\\min(k_1,k_2) = 2")#text(").")

#text("5. Related to 4., if one can prove a conjecture such as the Hardy-Littlewood or Chowla conjecture in the Siegel zero universe, it provides some heuristic support for this conjecture also being true in the real universe: it shows that such conjectures are provable “in principle”, albeit not in the universe that we want them to be true in. Nevertheless, some of the ideas, calculations, methods, or insights used to resolve the conjecture in the Siegel zero universe might also be of use attacking the same conjecture in the real universe.")

#text("6. It may end up that the Siegel zero universe is indicative of some other alternate, exotic form of number theory which is actually self-consistent. An analogy here is with the parallel postulate, which was widely believed to be true in the real world. A systematic exploration of the alternate universe where the parallel postulate failed eventually led to the discovery of self-consistent non-Euclidean geometries. Perhaps there is some sort of nonstandard model of some sort of “generalized number theory” in which Siegel zeroes do exist? (One could argue for instance that elliptic curves of high (analytic) rank sort of count as a weak Siegel zero, in that their associated L-function have a zero on the real axis, though so deep inside the critical strip that their influence is rather weak.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/247d50c94370d440682a562d3d4ef2261286ded9448b0fd722f401d243791746-513053f6d12b25850cc32555900cd0491b14e068227d5c81b74a065cb036ea40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Revantha")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634269")[#strong[#text("Revantha")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("Thanks, that clarifies. It is interesting to encounter these persuasive reasons given that the approach is initially unexpected from a logic perspective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7377b629758bde4410a82e66bbe8bac781bda97ea2c56e469c163527504a37df-46656e500bdbf0c447ff6c96c849d56a545b93f76da49029550d60095dfb3c67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siegelvsgrh")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634280")[#strong[#text("Siegelvsgrh")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("Can we conclude a statement is unconditionally valid if it is valid conditionally on siegel zero and valid conditionally on grh? Is it a possible reason 7?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634308")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2021")])]

#text("At a heuristic level perhaps, but at a fully rigorous level there is of course a large middle ground in which Dirichlet L-functions have zeroes that are neither close to 1 nor on the critical line. There is a sort of “unified universe” in which one makes instead the assumption that all zeroes of L-functions lie on either the critical line or the real axis, and there are some interesting conclusions to be drawn there; in particular, ")#link("https://www.projecteuclid.org/journals/duke-mathematical-journal/volume-111/issue-3/Some-remarks-on-Landau-Siegel-zeros/10.1215/S0012-7094-02-11134-X.full")[#text("Sarnak and Zaharescu")]#text(" showed in this case that there are strong limits to the strength of a Siegel zero in this universe.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7377b629758bde4410a82e66bbe8bac781bda97ea2c56e469c163527504a37df-46656e500bdbf0c447ff6c96c849d56a545b93f76da49029550d60095dfb3c67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siegelvsgrh")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634315")[#strong[#text("Siegelvsgrh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2021")])]

#text("Essentially the zero free region improvement and error bound are related. So are you saying there is an error bound (above the optimal GRH bound) below which Sigel zeros can be ruled out?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/143c544571e80a3cf438085cc22cdd6ee5f18e956de7a0f03326247396a9c295-1cd0848b805096874077c387ff9b4ebbbdb0dd350cf3e18158aef72a34e6a0b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duck_master")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634854")[#strong[#text("duck_master")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2021")])]

#text("Random thought: Do you know if it’s possible to use the assumed existence of the Siegel zero ")#mi("\\beta")#text(" of ")#mi("L(s, \\chi)")#text(" to obtain any nontrivial amount of control on sums like ")#mi("\\sum_{n\\leq x} d_{k_1}(n + h_1)\\cdots d_{k_{\\ell}}(n + h_{\\ell})")#text(" (especially, I presume, in the regime ")#mi("x = q_{\\chi}^{O(1)}")#text(", where the currently known Siegel-zero-based results operate)? Since we’re assuming the (presumably illusory) existence of a Siegel zero, we may as well make full use of it.")

#text("Another random thought: Since we expect ")#mi("\\lambda \\approx \\chi")#text(" in some kind of statistical pointwise sense for inputs of size ")#mi("q_{\\chi}^{O(1)}")#text(", not only should we expect “exceptional primes” ")#mi("p*: \\chi(p*)\\neq -1")#text(" to be rare, but we should also expect them to prefer being at places modulo ")#mi("q_{\\chi}")#text(" such that ")#mi("\\chi(p*)")#text(" is closer to -1, rather than at places where the exceptional character gives a value far away from -1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-635202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2021")])]

#text("The divisor functions are not sensitive to zeroes of the zeta function or Dirichlet L-functions, since their Dirichlet series involves zeta functions in the numerator rather than the denominator. So it does not appear that Siegel zeroes are particularly helpful in understanding these functions.")

#text("Note that a quadratic character ")#mi("\\chi")#text(" already only takes on two values, ")#mi("-1")#text(" and ")#mi("+1")#text(", and half of the ")#mi("\\phi(q_\\chi)")#text(" residue classes will take on the value ")#mi("+1")#text(" and half will take on the value ")#mi("-1")#text(". The exceptional primes are those in the first category (as well as the small number of primes that divide ")#mi("q_\\chi")#text(") and the non-exceptional ones are the second category.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634234")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("In the statement of Conjecture 1.3 in the paper, I think ")#mi("\\ell>0")#text(" should be ")#mi("\\ell=0")#text(": any Liouville factors should cause cancellation.")

#emph[#text("[Thanks, this will be fixed in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("In theorem 3, the estimate is dependent on $latek k$ but not on ")#mi("l")#text(" (also there is a restriction on ")#mi("k")#text(" but not on ")#mi("l")#text(") – this asymmetry between ")#mi("k")#text(" and ")#mi("l")#text(" seems incorrect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2021")])]

#text("Actually, this asymmetry seems inherent to our current state of understanding; under the assumption of a Siegel zero, the Liouville function behaves like the exceptional character ")#mi("\\chi")#text(" which is relatively easy to control, while the von Mangoldt function behaves like a twisted version ")#mi("\\chi * \\log")#text(" of the divisor function ")#mi("d_2")#text(" which is moderately difficult to control. In particular we can only handle up to ")#mi("k=2")#text(" copies of the latter, but an unlimited number of copies of the former, and our bounds worsen (and hypotheses tighten) as ")#mi("k")#text(" increases from zero to two.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2021")])]

#text("If there is no Siegel zero, is it still possible to use Dobner’s proof of a generalized Newman’s conjecture for a large class of Dirichlet Series (containing all Dirichlet L-functions associated to primitive characters) by using suitable deformations ")#mi("\\zeta_t")#text(" of these L-functions with positive deformation parameter ")#mi("t")#text(" – thereby ensuring the existence of a Siegel zero for ")#mi("\\zeta_t")#text(" – which can be used to find “good approximants” and corresponding estimates as described in this post ?")

#text("It seems that the deformation parameter ")#mi("t")#text(" should be optimized (as a function of ")#mi("x")#text(") to have a “sufficiently good” quality parameter ")#mi("\\eta")#text(" in a corresponding estimate (analogous to theorem 3).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2021")])]

#text("Unfortunately there does not seem to be much interaction between Siegel zeroes and heat flow type deformations of zeta functions (or L-functions). Note for instance that such deformations fail to have an Euler product, so their number-theoretic impact is sharply limited (indeed, in practice, the only way number theory interacts with the deformations ")#mi("\\zeta_t")#text(" is through the connection between number-theoretic objects such as the primes, and the original Riemann zeta function ")#mi("\\zeta")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2021")])]

#text("In theorem 3, it seems that ")#mi("\\epsilon_0")#text(" (in the exponent of the lower bound for x) should be ")#mi("\\epsilon")#text(", and the estimate error term should have its implied constant be dependent on ")#mi("\\epsilon")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa00dd2108bd00fc573cd544ff51a3dac61048f69b091b42b4d119c305c213c1-b536cb13061f9b689765b2d48d7c9502a8820ac579a7d4d5a1d2789b270e101c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quill")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634330")[#strong[#text("Quill")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2021")])]

#text("Not a relevant question, but do the news and social media affect your productivity these days, and how do you manage your consumption of them? I found it interesting that Timothy Gowers said on his Twitter feed that Twitter is affecting his work, and that he is taking a break from it this month of September. He seems pretty concerned about the climate crisis and also comments on current events and social issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634335")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2021")])]

#text("What about the ‘other direction’ if it comes to GRH violations, i. e. the assumption of zeros very close to x=1/2? Can we expect anything similar fruitful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634337")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2021")])]

#text("and what about allowing almost zeros? From the general heuristics it seems the result should be very similar.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2021")])]

#text("For example an arithmetic progression of Siegel zero like arguments of the L-function converging to zero?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634884")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2021")])]

#text("Siegel zeros do not exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-634885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2021")])]

#text("Is it possible to use these results on the Chowla conjecture (in the presence of a siegel zero) to get new information on the distribution of such zeros?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8af0366ad5a2f600ed182faf957823bc4ae7206a604433a71c5293e30f331bc6-0b995e818eb4ccc7c9661c94419c80f37bd51378ffb9e9bf817af5a32f701736.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RH over finite fields")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-658336")[#strong[#text("RH over finite fields")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2022")])]

#text("Deligne demonstrated RH over finite fields. What would have been the analogous consequences of a siegel type zero in that case? Is there a meta reason why an analog of Siegel zeros are not present in these cases?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-658388")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2022")])]

#text("This may be a rather unsatisfyingly tautological answer, but the meta reason in the finite field case is that we know how to prove the Riemann hypothesis in that setting, rendering the Siegel zero scenario counterfactual there. If we could similarly prove RH in the number field setting, we would also have finally eliminated Siegel zeroes from that context also; but as dearly as we would love to do so, nobody has successfully managed to achieve this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660192")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2022")])]

#text("Hello, Prof. Tao, I’d like to ask a naive question. Yitang Zhang has posted a paper on Landau-Siegel zero. Discrete mean estimates and the Landau-Siegel zero ")#link("https://arxiv.org/abs/2211.02515")[#text("https://arxiv.org/abs/2211.02515")]#text(". proved that")#linebreak()#text(" L(1,\\chi)\\gg (\\log D)^{-2022}")

#text("Does it might right and meaningful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660216")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2022")])]

#text("It seems that the appearance of the exponent 2022 (in the year 2022) is not a pure coincidence !")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660291")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2022")])]

#text("That’s just a bit of (deliberate) humor. If the paper can be straightened out, i.e., if it is essentially correct (it seems to be a bit of a mess at present), then the constant is very unlikely to be the best that the method can give. Rather, there’s a trade-off at some point – improving constants can mean introducing complications. It’s a bit like the accountants of some extremely rich person (Murdoch’s?) declaring his yearly income being 452452452 euros, or something like that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660314")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2022")])]

#text("Zhang claims his methods could get the exponent down to less than 1000, but that he was of course being a bit cute with organising the constants to get 2022.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660236")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2022")])]

#text("At this point the essential correctness of the manuscript is unconfirmed. There are a number of misprints and technical issues in the paper (mostly centering around Sections 11 and 12) that are hindering the verification process and which I have forwarded to Yitang in order to request clarification. For instance, there are references to non-existent equations (8.25) and (8.26) on pages 64, 65, 67, (10.) on page 67, (15.) on pages 98 and 99, “(4) and (4)” on pages 67 and 69, “(5) and (5)” on page 63, and (14) on page 109; there also appears to be a reference missing completely just before Lemma 12.3 on page 70 (as well as just before the aforementioned reference to (14) on page 109), and the function ")#mi("\\varkappa_4")#text(" that appears from page 96 onwards is never defined in the paper. As a consequence, several steps in the manuscript currently have no valid justification provided. It is possible that these (as well as some more serious issues) can be corrected, but it will likely take some time before the process resolves (in particular, I would not want to pressure Yitang to upload a hastily edited revision of the manuscript instead of a carefully proofread one), and so patience is advised.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb72396efab7a2fff7df5abd48f4f50406f875ddf533c825cfcbc6af50d7c60-9f4e4e913c7033ba01c468ae917323ad2ab1921347d27ab2e2d45fc7b79fe4c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2022")])]

#text("“in particular, I would not want to pressure Yitang to upload a hastily edited revision of the manuscript instead of a carefully proofread one.” Very well said. Which math publication might seek for his carefully ‘proofread’ one? Is there ANY ? Or is it too early to tell still?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2022")])]

#text("In Yitang’s arxiv source, he doesn’t use \\ref{}, “(8.25)” is explicitly typed in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yihong")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-666250")[#strong[#text("Yihong")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2022")])]

#text("Dear Professor Tao,")#linebreak()#text(" I would like to ask whether the correctness of “The logarithmically averaged Chowla and Elliott conjectures for two-point correlations” on the arxiv is confirmed.")#linebreak()#text(" I cannot resolve the following issue:")#linebreak()#text(" As I understand, Markov’s inequality after (3.14) implies that ")#mi("P(X_{H}\\in G)=1-o(1)")#text(", where ")#mi("G")#text(" is the set of ALL good values of ")#mi("x")#text(",")#linebreak()#text(" and not ")#mi("P(X_{H}=x)=1-o(1)")#text(" for an individual ")#mi("x\\in G")#text(".")#linebreak()#text(" Thus, to obtain ")#mi("F(X_{H},Y_{H})=\\frac{1}{P_{H}}\\sum_{y\\in Z/P_{H}Z}F(X_{H},y)+O({\\epsilon}^2\\frac{H}{\\log H})")#text(" after the proof of Lemma 3.5, we need the conclusion of Lemma 3.3 to be")#linebreak()#text(" ")#mi("P(Y_{H}\\in{\\cup}_{x\\in G}E_{x} | X_{H}\\in G)=o(1)")#text(",")#linebreak()#text(" and not ")#mi("P(Y_{H}\\in E_{x} | X_{H}=x)=o(1)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-667949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("The bound ")#mi("{\\bf P}(Y_H \\in E_x | X_H = x) = o(1)")#text(" for ")#mi("x \\in G")#text(" implies ")#mi("{\\bf P}(Y_H \\in E_x | X_H \\in G ) = o(1)")#text(" from the ")#link("https://en.wikipedia.org/wiki/Law_of_total_probability")[#text("law of total probability")]#text(", which in this case is")

#mi("\\displaystyle {\\bf P}(Y_H \\in E_x | X_H \\in G ) = \\sum_{x \\in G} {\\bf P}(Y_H \\in E_x | X_H = x) {\\bf P}( X_H = x | X_H \\in G ).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-682172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2023")])]

#text("Is the quantity ")#mi("{\\epsilon}^2\\frac{H}{\\log H}")#text(" in the Hoeffding inequality for the set of all ")#mi("y")#text(" such that")#linebreak()#text(" ")#tao-math("\\left|F(x,y)-\\frac{1}{P_{H}}\\sum_{y^{\\prime}\\in Z/P_{H}Z}F(x,y^{\\prime})\\right|\\ge {\\epsilon}^2\\frac{H}{\\log H}", block: false)#text(" sufficient when we go back to the individual ")#mi("F_{p}(x,y)")#text(" and to the original logarithmically averaged two-point correlation? Obviously, it would suffice if we had the individual inequalities for the set of all ")#mi("y")#text(" such that")#linebreak()#text(" ")#tao-math("\\left|F_{p}(x,y)-\\frac{1}{P_{H}}\\sum_{y^{\\prime}\\in Z/P_{H}Z}F_{p}(x,y^{\\prime})\\right|\\ge {\\epsilon}^2", block: false)

#emph[#text("[I am afraid I do not understand the question. Is there a specific step in the paper that you are requesting clarification on? If so, please provide a precise reference. You may also find the alternate presentation of the argument at ")#link("https://joelmoreira.wordpress.com/2018/11/04/taos-proof-of-logarithmically-averaged-chowlas-conjecture-for-two-point-correlations/")[#text("https://joelmoreira.wordpress.com/2018/11/04/taos-proof-of-logarithmically-averaged-chowlas-conjecture-for-two-point-correlations/")]#text(" to be helpful. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yihong")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-668296")[#strong[#text("Yihong")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("This is unsatisfactory. We need the bound ")#mi("P(Y_{H}\\in\\cup_{x\\in G}E_{x}|X_{H}\\in G)=o(1)")#text(",")#linebreak()#text(" and not ")#mi("P(Y_{H}\\in E_{x}|X_{H}\\in G)=o(1)")#text(" for an individual ")#mi("E_{x}")#text(". Very frustrating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-668322")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("No; we only need the bound ")#mi("{\\bf P}(Y_H \\in E_{X_H}|X_H \\in G) = o(1)")#text(". There was a typo in my previous invocation of the law of total probability; it should be")

#mi("\\displaystyle {\\bf P}( Y_H \\in E_{X_H}|X_H \\in G) =")

#mi("\\displaystyle \\sum_{x \\in G} {\\bf P}( Y_H \\in E_{X_H}|X_H = x) {\\bf P}( X_H = x | X_H \\in G)")

#text("noting of course that ")#mi("{\\bf P}( Y_H \\in E_{X_H}|X_H = x) ={\\bf P}( Y_H \\in E_x|X_H = x)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yihong")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-670006")[#strong[#text("Yihong")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2022")])]

#text("The event ")#mi("Y_{H}\\in E_{X_{H}}")#text(" in the invocation of the law of total probability cannot depend on the events ")#mi("X_{H}=x")#text(" of the partition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yihong")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-668804")[#strong[#text("Yihong")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2022")])]

#text("The event ")#mi("\\{ Y_{H}\\in E_{X_{H}} | X_{H}\\in G \\}")#text(", with ")#mi("E_{X_{H}}")#text(" from Lemma 3.5, is defined correctly if ")#mi("n")#text(" is restricted to the space ")#mi("[1, \\dots , P_{H}]")#text(". If the space of ")#mi("n")#text(" is larger, the set of all locations of the fixed ")#mi("2H")#text("-tuple ")#mi("(x_{i,j})")#text(" among the values of ")#mi("n")#text(" is NOT a union of the FULL residue classes mod ")#mi("P_{H}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-669828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2022")])]

#text("Is the Hoeffding inequality applicable to ")#tao-math("\\left|F(x,y)-\\frac{1}{P_{H}}\\sum_{y^{\\prime}\\in Z/P_{H}Z}F(x,y^{\\prime})\\right|", block: false)#text(" when the sum is not over all ")#mi("y^{\\prime}\\in Z/P_{H}Z")#text(" but over an unknown subset of ")#mi("Z/P_{H}Z")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-672315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2023")])]

#text("Do we now understand better whether Prof. Zhang’s technique works?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-660328")[#strong[#text("Nuevo artículo de Yitang Zhang sobre los ceros de Landau-Siegel - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2022")]

#text("[…] que va a ser un proceso largo. John Baez se hace eco en Twitter de un comentario de Terence Tao en su blog, una de las pocas personas que tendrá que dar el visto bueno a la demostración para que se […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e684f80cb7f5a90e042e972175b386d363ef7db2e8bd606b0729e117dc485a9-fcd596737cbb8e835b1e512a845237419ac1936dfbf0f743ecad4776a1ea9487.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of La Fields que nunca fue. – Luis Alexandher")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-663401")[#strong[#text("La Fields que nunca fue. – Luis Alexandher")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2022")])]

#text("[…] Terry Tao se ha pronunciado al respecto. Alguien en su post que habla sobre el tema de los ceros de Landau-Siegel comentó lo siguiente (los traduje a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb04fddf5a55068841e2c4f9402f4c82e36cda4dae1c42eaf2d1fbc62287bd6-47cffc8c7c1926e5706473987af1e4539a423a9885fad79b2e020ef805eaf337.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drugengmen")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-666236")[#strong[#text("Drugengmen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2022")])]

#text("Dear Professor Tao")

#text("I found such a paper on Zeta Function on the Internet. The author uses the method of Laplace inverse transformation to link the zeta function with the real function, draws some conclusions, and claims to have discussed it with Sir Michael F Atiyah.")

#text("It seems that I have never seen such a research method and perspective before. How do you evaluate it? Thanks!")

#text("The following is the address of the paper:")

#link("https://arxiv.org/abs/1807.00849")[#text("https://arxiv.org/abs/1807.00849")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-667879")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2022")])]

#text("Unfortunately at that time Atiyah himself was proposing major results that were not sound. His approval is not a silver bullet, and should even be treated with caution. In any case, the author’s claim in the abstract that complex functions are difficult to understand because they cannot be graphed seems untrue, since people know a very great deal about complex functions. Mathematicians do much more to study real functions than graph them, and actual visualisations are but one tool, and not generally a conclusive one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb04fddf5a55068841e2c4f9402f4c82e36cda4dae1c42eaf2d1fbc62287bd6-47cffc8c7c1926e5706473987af1e4539a423a9885fad79b2e020ef805eaf337.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drugengmen")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-667899")[#strong[#text("Drugengmen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2022")])]

#text("As far as I understand, what the author says that is difficult to draw the graph of complex function, it is only relative to the real function, and it is not absolutely impossible to draw. The zeta function may also be one of the complex functions that are difficult to draw.")

#text("As for Atiyah’s proof, since he did not provide a detailed demonstration process, it was indeed impossible to identify it is correct or not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-667902")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2022")])]

#text("I’m not talking about Atiyah’s proof(s), but his critical faculties later in life. Getting the thumbs-up from Atiyah shortly before his death is not the same as getting his approval in, say, the 1980s.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb04fddf5a55068841e2c4f9402f4c82e36cda4dae1c42eaf2d1fbc62287bd6-47cffc8c7c1926e5706473987af1e4539a423a9885fad79b2e020ef805eaf337.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drugengmen")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-667993")[#strong[#text("Drugengmen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("I don’t think what Atiyah said is the key point. The author mentioned it probably just to attract other people’s attention")

#text("Do you find any obvious or significant mistakes in this paper? So far, I haven’t found it, but the author’s research perspective and method should be relatively new.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-667997")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("I don’t know the area, so I can only assess it based on generic criteria, like trying to appeal to authority in the abstract, or saying how hard it is to study things because they cannot be graphed. These are not the sort of things that fill me with confidence. If the paper correctly produces a statement that is equivalent to the RH, then that is perhaps mildly interesting, but there are many many such statements, none of them any easier than RH. The author says in the abstract that the innovation in the paper “greatly simplifies” the problem, which I presume is where a mistake may be hiding.")

#text("This is before I open the paper. When I do so I see unexplained notation on the first page that looks like a typo (but which I later find is not), and a claim of the proof of RH. The multi-coloured typsetting and large font claims with multiple exclamation marks are not a good sign. The methods are very elementary, and not the sort of thing one expects will be able to prove the RH, based on my outsider understanding of analytic number theory. Since I don’t know the area, I wouldn’t be spending any time trying to understand where the error surely lies, but this type of paper can be found replicated hundreds of times over (sometimes with the opposite claim!), all of which amount to not much interesting mathematics. So I’m afraid to burst your bubble, but it is more worth investing time in papers that do genuinely new things that are firmly established and verified.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb04fddf5a55068841e2c4f9402f4c82e36cda4dae1c42eaf2d1fbc62287bd6-47cffc8c7c1926e5706473987af1e4539a423a9885fad79b2e020ef805eaf337.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drugengmen")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-668249")[#strong[#text("Drugengmen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("So I understand that you doubt that the main basis of this paper is its writing style rather than its content, is it right?")

#text("I don’t know why the author uses different color fonts, or he just wants to highlight what he thinks is important. But I have read some books and articles on number theory, and I wonder whether it is more likely to make objective comments than you?")

#text("As far as I have read, no one has ever studied the zeta function with the method of Laplace inverse transformation and drawn the corresponding image. I think this is an important new direction, and I also get some interesting inspiration from that. If professional mathematicians also try to research in this direction, they will get many more important results, I think.")

#text("As for the author’s argument, of course, there may be ambiguity or even errors, which requires professional mathematicians to judge. So I would ask Professor Tao or other mathematicians to have a look and comment.")

#text("I think whether the tools used in the paper are “elementary” is not the basis for whether the content is correct. As the author’s research direction is different from that of predecessors, the mathematical tools used are naturally different.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-668300")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("Prof Tao has already written helpful comments that would address (maybe slightly indirectly) your question, so I think it appropriate to point to the addendum at ")#link("https://terrytao.wordpress.com/career-advice/dont-prematurely-obsess-on-a-single-big-problem-or-big-theory/")[#text("https://terrytao.wordpress.com/career-advice/dont-prematurely-obsess-on-a-single-big-problem-or-big-theory/")]#text(" or the advice at ")#link("https://terrytao.wordpress.com/career-advice/be-sceptical-of-your-own-work/")[#text("https://terrytao.wordpress.com/career-advice/be-sceptical-of-your-own-work/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb04fddf5a55068841e2c4f9402f4c82e36cda4dae1c42eaf2d1fbc62287bd6-47cffc8c7c1926e5706473987af1e4539a423a9885fad79b2e020ef805eaf337.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drugengmen")]], [#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-668318")[#strong[#text("Drugengmen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("Thanks for your answer. Professor Tao’s words are applicable to most situations. In fact, I have advised some people who are addicted to “studying big problems” before. In my opinion, many of their works are obviously wrong or childish.")

#text("But there are always exceptions. Now this paper I am referring to, with my mathematical knowledge, I cannot see where its mistakes are. So I hope Professor Tao or other mathematicians can make targeted comments.")

#text("Only mathematical reasons can persuade me, not other things.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/09/15/the-hardy-littlewood-chowla-conjecture-in-the-presence-of-a-siegel-zero/#comment-680593")[#strong[#text("Fields Medal Winner Terence Tao Comments on Yitang Zhang's Landau-Siegel Zeros Conjecture Paper - Tech News Comdash")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2023")]

#text("[…] Tao, an Australian mathematician and winner of the Fields Medal, said on November 14 that he had read the recent paper by Yitang Zhang on proving the Landau-Siegel zeros conjecture. Tao commented that the basic accuracy of the paper has not yet been confirmed, and there are some […]")
]
