// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/
// Converted to Typst by tao2typ: "2026-10-14T09:11:20.860245+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Cotlar-Stein lemma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Cotlar-Stein lemma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/")[#text("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A basic problem in harmonic analysis (as well as in linear algebra, random matrix theory, and high-dimensional geometry) is to estimate the operator norm ")#tao-math("{\\left\\|T\\right\\|_{op}}", block: false)#text(" of a linear map ")#mi("{T: H \\rightarrow H^{\\prime}}")#text(" between two Hilbert spaces, which we will take to be complex for sake of discussion. Even the finite-dimensional case ")#mi("{T: {\\bf C}^m \\rightarrow {\\bf C}^n}")#text(" is of interest, as this operator norm is the same as the largest ")#link("http://en.wikipedia.org/wiki/Singular_value")[#text("singular value")]#text(" ")#mi("{\\sigma_1(A)}")#text(" of the ")#mi("{n \\times m}")#text(" matrix ")#mi("{A}")#text(" associated to ")#mi("{T}")#text(".")

#text("In general, this operator norm is hard to compute precisely, except in special cases. One such special case is that of a ")#emph[#text("diagonal operator")]#text(", such as that associated to an ")#mi("{n \\times n}")#text(" diagonal matrix ")#mi("{D = \\text{diag}(\\lambda_1,\\ldots,\\lambda_n)}")#text(". In this case, the operator norm is simply the supremum norm of the diagonal coefficients: ")#metadata(none) <tao-be3f1b44776624b9c37b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|D\\right\\|_{op} = \\sup_{1 \\leq i \\leq n} \\left|\\lambda_i\\right|.", block: true)]]

#text("A variant of ")#link(<tao-be3f1b44776624b9c37b>)[#text("(1)")]#text(" is ")#link("http://en.wikipedia.org/wiki/Schur_test")[#text("Schur’s test")]#text(", which for simplicity we will phrase in the setting of finite-dimensional operators ")#mi("{T: {\\bf C}^m \\rightarrow {\\bf C}^n}")#text(" given by a matrix ")#mi("{A = (a_{ij})_{1 \\leq i \\leq n; 1 \\leq j \\leq m}}")#text(" via the usual formula")

#align(center)[#tao-fit-display[#mitex("T (x_j)_{j=1}^m := ( \\sum_{j=1}^m a_{ij} x_j )_{i=1}^n.")]]

#text("A simple version of this test is as follows: if all the absolute row sums and columns sums of ")#mi("{A}")#text(" are bounded by some constant ")#mi("{M}")#text(", thus ")#metadata(none) <tao-57263eb850c711fbc20d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{j=1}^m \\left|a_{ij}\\right| \\leq M", block: true)]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(" and ")#metadata(none) <tao-a7d1bf0e0325eb095545>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{i=1}^n \\left|a_{ij}\\right| \\leq M", block: true)]]

#text("for all ")#mi("{1 \\leq j \\leq m}")#text(", then ")#metadata(none) <tao-28720365c5e7476a011e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|T\\right\\|_{op} = \\left\\|A\\right\\|_{op} \\leq M", block: true)]]

#text("(note that this generalises (the upper bound in) ")#link(<tao-be3f1b44776624b9c37b>)[#text("(1)")]#text(".) Indeed, to see ")#link(<tao-28720365c5e7476a011e>)[#text("(4)")]#text(", it suffices by duality and homogeneity to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{i=1}^n (\\sum_{j=1}^m a_{ij} x_j) y_i\\right| \\leq M", block: true)]]

#text("whenever ")#mi("{(x_j)_{j=1}^m}")#text(" and ")#mi("{(y_i)_{i=1}^n}")#text(" are sequences with ")#tao-math("{\\sum_{j=1}^m \\left|x_j\\right|^2 = \\sum_{i=1}^n \\left|y_i\\right|^2 = 1}", block: false)#text("; but this easily follows from the arithmetic mean-geometric mean inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|a_{ij} x_j y_i\\right| \\leq \\frac{1}{2} \\left|a_{ij}\\right| \\left|x_i\\right|^2 + \\frac{1}{2} \\left|a_{ij}\\right| \\left|y_j\\right|^2", block: true)]]

#text("and ")#link(<tao-57263eb850c711fbc20d>)[#text("(2)")]#text(", ")#link(<tao-a7d1bf0e0325eb095545>)[#text("(3)")]#text(".")

#text("Schur’s test ")#link(<tao-28720365c5e7476a011e>)[#text("(4)")]#text(" (and its many generalisations to weighted situations, or to Lebesgue or Lorentz spaces) is particularly useful for controlling operators in which the role of oscillation (as reflected in the ")#emph[#text("phase")]#text(" of the coefficients ")#mi("{a_{ij}}")#text(", as opposed to just their magnitudes ")#tao-math("{\\left|a_{ij}\\right|}", block: false)#text(") is not decisive. However, it is of limited use in situations that involve a lot of cancellation. For this, a different test, known as the ")#link("http://en.wikipedia.org/wiki/Cotlar-Stein_lemma")[#text("Cotlar-Stein lemma")]#text(", is much more flexible and powerful. It can be viewed in a sense as a non-commutative variant of Schur’s test ")#link(<tao-28720365c5e7476a011e>)[#text("(4)")]#text(" (or of ")#link(<tao-be3f1b44776624b9c37b>)[#text("(1)")]#text("), in which the scalar coefficients ")#mi("{\\lambda_i}")#text(" or ")#mi("{a_{ij}}")#text(" are replaced by operators instead.")

#text("To illustrate the basic flavour of the result, let us return to the bound ")#link(<tao-be3f1b44776624b9c37b>)[#text("(1)")]#text(", and now consider instead a ")#emph[#text("block-diagonal")]#text(" matrix ")#metadata(none) <tao-0fff14e9e47b8bea8af3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("A = \\begin{pmatrix} \\Lambda_1 & 0 & \\ldots & 0 \\\\ 0 & \\Lambda_2 & \\ldots & 0 \\\\ \\vdots & \\vdots & \\ddots & \\vdots \\\\ 0 & 0 & \\ldots & \\Lambda_n \\end{pmatrix}")]]

#text("where each ")#mi("{\\Lambda_i}")#text(" is now a ")#mi("{m_i \\times m_i}")#text(" matrix, and so ")#mi("{A}")#text(" is an ")#mi("{m \\times m}")#text(" matrix with ")#mi("{m := m_1 + \\ldots +m_n}")#text(". Then we have ")#metadata(none) <tao-1edb869845d66e8d83ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\|A\\right\\|_{op} = \\sup_{1 \\leq i \\leq n} \\left\\|\\Lambda_i\\right\\|_{op}.", block: true)]]

#text("Indeed, the lower bound is trivial (as can be seen by testing ")#mi("{A}")#text(" on vectors which are supported on the ")#mi("{i^{th}}")#text(" block of coordinates), while to establish the upper bound, one can make use of the orthogonal decomposition ")#metadata(none) <tao-b5039c325d7107d60895>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf C}^m \\equiv \\bigoplus_{i=1}^m {\\bf C}^{m_i}")]]

#text("to decompose an arbitrary vector ")#mi("{x \\in {\\bf C}^m}")#text(" as")

#align(center)[#tao-fit-display[#mitex("x = \\begin{pmatrix} x_1 \\\\ x_2 \\\\ \\vdots \\\\ x_n \\end{pmatrix}")]]

#text("with ")#mi("{x_i \\in {\\bf C}^{m_i}}")#text(", in which case we have")

#align(center)[#tao-fit-display[#mitex("Ax = \\begin{pmatrix} \\Lambda_1 x_1 \\\\ \\Lambda_2 x_2 \\\\ \\vdots \\\\ \\Lambda_n x_n \\end{pmatrix}")]]

#text("and the upper bound in ")#link(<tao-1edb869845d66e8d83ce>)[#text("(6)")]#text(" then follows from a simple computation.")

#text("The operator ")#mi("{T}")#text(" associated to the matrix ")#mi("{A}")#text(" in ")#link(<tao-0fff14e9e47b8bea8af3>)[#text("(5)")]#text(" can be viewed as a sum ")#mi("{T = \\sum_{i=1}^n T_i}")#text(", where each ")#mi("{T_i}")#text(" corresponds to the ")#mi("{\\Lambda_i}")#text(" block of ")#mi("{A}")#text(", in which case ")#link(<tao-1edb869845d66e8d83ce>)[#text("(6)")]#text(" can also be written as ")#metadata(none) <tao-b4cb33b437f6e2d88f3d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|T\\right\\|_{op} = \\sup_{1 \\leq i \\leq n} \\left\\|T_i\\right\\|_{op}.", block: true)]]

#text("When ")#mi("{n}")#text(" is large, this is a significant improvement over the triangle inequality, which merely gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T\\right\\|_{op} \\leq \\sum_{1 \\leq i \\leq n} \\left\\|T_i\\right\\|_{op}.", block: true)]]

#text("The reason for this gain can ultimately be traced back to the “orthogonality” of the ")#mi("{T_i}")#text("; that they “occupy different columns” and “different rows” of the range and domain of ")#mi("{T}")#text(". This is obvious when viewed in the matrix formalism, but can also be described in the more abstract Hilbert space operator formalism via the identities ")#metadata(none) <tao-715bf2907e6f686f6e70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("T_i^* T_j = 0")]]

#text("and ")#metadata(none) <tao-d566ee3b254e2f5e3204>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("T_i T^*_j = 0")]]

#text("whenever ")#mi("{i \\neq j}")#text(". (The first identity asserts that the ranges of the ")#mi("{T_i}")#text(" are orthogonal to each other, and the second asserts that the coranges of the ")#mi("{T_i}")#text(" (the ranges of the adjoints ")#mi("{T_i^*}")#text(") are orthogonal to each other.) By replacing ")#link(<tao-b5039c325d7107d60895>)[#text("(7)")]#text(" with a more abstract orthogonal decomposition into these ranges and coranges, one can in fact deduce ")#link(<tao-b4cb33b437f6e2d88f3d>)[#text("(8)")]#text(" directly from ")#link(<tao-715bf2907e6f686f6e70>)[#text("(9)")]#text(" and ")#link(<tao-d566ee3b254e2f5e3204>)[#text("(10)")]#text(".")

#text("The ")#emph[#text("Cotlar-Stein lemma")]#text(" is an extension of this observation to the case where the ")#mi("{T_i}")#text(" are merely ")#emph[#text("almost orthogonal")]#text(" rather than ")#emph[#text("orthogonal")]#text(", in a manner somewhat analogous to how Schur’s test (partially) extends ")#link(<tao-be3f1b44776624b9c37b>)[#text("(1)")]#text(" to the non-diagonal case. Specifically, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Cotlar-Stein lemma)")]#text(" ")#metadata(none) <tao-4dfc7bef3b9058e08c0d>#text(" Let ")#mi("{T_1,\\ldots,T_n: H \\rightarrow H^{\\prime}}")#text(" be a finite sequence of bounded linear operators from one Hilbert space ")#mi("{H}")#text(" to another ")#mi("{H^{\\prime}}")#text(", obeying the bounds ")#metadata(none) <tao-b95e4a5ce1afdf42c4d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sum_{j=1}^n \\left\\| T_i T_j^* \\right\\|_{op}^{1/2} \\leq M", block: true)]]

#text("and ")#metadata(none) <tao-bfb2f0821be1ad17d369>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{j=1}^n \\left\\| T_i^* T_j \\right\\|_{op}^{1/2} \\leq M", block: true)]]

#text("for all ")#mi("{i=1,\\ldots,n}")#text(" and some ")#mi("{M > 0}")#text(" (compare with ")#link(<tao-57263eb850c711fbc20d>)[#text("(2)")]#text(", ")#link(<tao-a7d1bf0e0325eb095545>)[#text("(3)")]#text("). Then one has ")#metadata(none) <tao-ab6f3bf22956c95540cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| \\sum_{i=1}^n T_i \\right\\|_{op} \\leq M.", block: true)]]
]

#text("Note from the basic ")#emph[#mi("{TT^*}")#text(" identity")]#text(" ")#metadata(none) <tao-317e938a489b10da179b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\|T\\right\\|_{op} = \\left\\|TT^* \\right\\|_{op}^{1/2} = \\left\\|T^* T\\right\\|_{op}^{1/2}", block: true)]]

#text("that the hypothesis ")#link(<tao-b95e4a5ce1afdf42c4d9>)[#text("(11)")]#text(" (or ")#link(<tao-bfb2f0821be1ad17d369>)[#text("(12)")]#text(") already gives the bound ")#metadata(none) <tao-a75c0838e8467bc03dcd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\|T_i\\right\\|_{op} \\leq M", block: true)]]

#text("on each component ")#mi("{T_i}")#text(" of ")#mi("{T}")#text(", which by the triangle inequality gives the inferior bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^n T_i \\right\\|_{op} \\leq nM;", block: true)]]

#text("the point of the Cotlar-Stein lemma is that the dependence on ")#mi("{n}")#text(" in this bound is eliminated in ")#link(<tao-ab6f3bf22956c95540cc>)[#text("(13)")]#text(", which in particular makes the bound suitable for extension to the limit ")#mi("{n \\rightarrow \\infty}")#text(" (see Remark ")#link(<tao-71b4f3a3748cd6843c01>)[#text("1")]#text(" below).")

#text("The Cotlar-Stein lemma was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=80263")[#text("by Cotlar")]#text(" in the special case of commuting self-adjoint operators, and then independently by Cotlar and Stein in full generality, with the proof appearing in a subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=460543")[#text("paper of Knapp and Stein")]#text(".")

#text("The Cotlar-Stein lemma is often useful in controlling operators such as ")#link("http://en.wikipedia.org/wiki/Singular_integral")[#text("singular integral operators")]#text(" or ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudo-differential operators")]#text(" ")#mi("{T}")#text(" which “do not mix scales together too much”, in that operators ")#mi("{T}")#text(" map functions “that oscillate at a given scale ")#mi("{2^{-i}}")#text("” to functions that still mostly oscillate at the same scale ")#mi("{2^{-i}}")#text(". In that case, one can often split ")#mi("{T}")#text(" into components ")#mi("{T_i}")#text(" which essentially capture the scale ")#mi("{2^{-i}}")#text(" behaviour, and understanding ")#mi("{L^2}")#text(" boundedness properties of ")#mi("{T}")#text(" then reduces to establishing the boundedness of the simpler operators ")#mi("{T_i}")#text(" (and of establishing a sufficient decay in products such as ")#mi("{T_i^* T_j}")#text(" or ")#mi("{T_i T_j^*}")#text(" when ")#mi("{i}")#text(" and ")#mi("{j}")#text(" are separated from each other). In some cases, one can use Fourier-analytic tools such as Littlewood-Paley projections to generate the ")#mi("{T_i}")#text(", but the true power of the Cotlar-Stein lemma comes from situations in which the Fourier transform is not suitable, such as when one has a complicated domain (e.g. a manifold or a non-abelian Lie group), or very rough coefficients (which would then have badly behaved Fourier behaviour). One can then select the decomposition ")#mi("{T = \\sum_i T_i}")#text(" in a fashion that is tailored to the particular operator ")#mi("{T}")#text(", and is not necessarily dictated by Fourier-analytic considerations.")

#text("Once one is in the almost orthogonal setting, as opposed to the genuinely orthogonal setting, the previous arguments based on orthogonal projection seem to fail completely. Instead, the proof of the Cotlar-Stein lemma proceeds via an elegant application of the ")#link("http://www.tricki.org/article/The_tensor_power_trick")[#text("tensor power trick")]#text(" (or perhaps more accurately, the ")#link("http://en.wikipedia.org/wiki/Power_iteration")[#text("power method")]#text("), in which the operator norm of ")#mi("{T}")#text(" is understood through the operator norm of a large power of ")#mi("{T}")#text(" (or more precisely, of its self-adjoint square ")#mi("{TT^*}")#text(" or ")#mi("{T^* T}")#text("). Indeed, from an iteration of ")#link(<tao-317e938a489b10da179b>)[#text("(14)")]#text(" we see that for any natural number ")#mi("{N}")#text(", one has ")#metadata(none) <tao-3293ed97ad280b0621b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\|T\\right\\|_{op}^{2N} = \\left\\| (TT^*)^N \\right\\|_{op}.", block: true)]]

#text("To estimate the right-hand side, we expand out the right-hand side and apply the triangle inequality to bound it by ")#metadata(none) <tao-fdc83a285a44e39fc58b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\sum_{i_1,j_1,\\ldots,i_N,j_N \\in \\{1,\\ldots,n\\}} \\left\\| T_{i_1} T_{j_1}^* T_{i_2} T_{j_2}^* \\ldots T_{i_N} T_{j_N}^* \\right\\|_{op}.", block: true)]]

#text("Recall that when we applied the triangle inequality directly to ")#mi("{T}")#text(", we lost a factor of ")#mi("{n}")#text(" in the final estimate; it will turn out that we will lose a similar factor here, but this factor will eventually be attenuated into nothingness by the tensor power trick.")

#text("To bound ")#link(<tao-fdc83a285a44e39fc58b>)[#text("(17)")]#text(", we use the basic inequality ")#tao-math("{\\left\\|ST\\right\\|_{op} \\leq \\left\\|S\\right\\|_{op} \\left\\|T\\right\\|_{op}}", block: false)#text(" in two different ways. If we group the product ")#mi("{T_{i_1} T_{j_1}^* T_{i_2} T_{j_2}^* \\ldots T_{i_N} T_{j_N}^*}")#text(" in pairs, we can bound the summand of ")#link(<tao-fdc83a285a44e39fc58b>)[#text("(17)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_{i_1} T_{j_1}^* \\right\\|_{op} \\ldots \\left\\| T_{i_N} T_{j_N}^* \\right\\|_{op}.", block: true)]]

#text("On the other hand, we can group the product by pairs in another way, to obtain the bound of")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_{i_1} \\right\\|_{op} \\left\\| T_{j_1}^* T_{i_2} \\right\\|_{op} \\ldots \\left\\| T_{j_{N-1}}^* T_{i_N}\\right\\|_{op} \\left\\| T_{j_N}^* \\right\\|_{op}.", block: true)]]

#text("We bound ")#tao-math("{\\left\\| T_{i_1} \\right\\|_{op}}", block: false)#text(" and ")#tao-math("{\\left\\| T_{j_N}^* \\right\\|_{op}}", block: false)#text(" crudely by ")#mi("{M}")#text(" using ")#link(<tao-a75c0838e8467bc03dcd>)[#text("(15)")]#text(". Taking the geometric mean of the above bounds, we can thus bound ")#link(<tao-fdc83a285a44e39fc58b>)[#text("(17)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("M \\sum_{i_1,j_1,\\ldots,i_N,j_N \\in \\{1,\\ldots,n\\}} \\left\\| T_{i_1} T_{j_1}^* \\right\\|_{op}^{1/2} \\left\\| T_{j_1}^* T_{i_2} \\right\\|_{op}^{1/2} \\ldots \\left\\| T_{j_{N-1}}^* T_{i_N}\\right\\|_{op}^{1/2} \\left\\| T_{i_N} T_{j_N}^* \\right\\|_{op}^{1/2}.", block: true)]]

#text("If we then sum this series first in ")#mi("{j_N}")#text(", then in ")#mi("{i_N}")#text(", then moving back all the way to ")#mi("{i_1}")#text(", using ")#link(<tao-b95e4a5ce1afdf42c4d9>)[#text("(11)")]#text(" and ")#link(<tao-bfb2f0821be1ad17d369>)[#text("(12)")]#text(" alternately, we obtain a final bound of")

#align(center)[#tao-fit-display[#mitex("n M^{2N}")]]

#text("for ")#link(<tao-3293ed97ad280b0621b8>)[#text("(16)")]#text(". Taking ")#mi("{N^{th}}")#text(" roots, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T\\right\\|_{op} \\leq n^{1/2N} M.", block: true)]]

#text("Sending ")#mi("{N \\rightarrow \\infty}")#text(", we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-71b4f3a3748cd6843c01>#text(" As observed in a number of places (see e.g. page 318 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1232192")[#text("Stein’s book")]#text(", or ")#link("http://www.math.tamu.edu/~comech/papers/CotlarStein/CotlarStein.pdf")[#text("this paper of Comech")]#text(", the Cotlar-Stein lemma can be extended to infinite sums ")#mi("{\\sum_{i=1}^\\infty T_i}")#text(" (with the obvious changes to the hypotheses ")#link(<tao-b95e4a5ce1afdf42c4d9>)[#text("(11)")]#text(", ")#link(<tao-bfb2f0821be1ad17d369>)[#text("(12)")]#text("). Indeed, one can show that for any ")#mi("{f \\in H}")#text(", the sum ")#mi("{\\sum_{i=1}^\\infty T_i f}")#text(" is unconditionally convergent in ")#mi("{H^{\\prime}}")#text(" (and furthermore has bounded ")#mi("{2}")#text("-variation), and the resulting operator ")#mi("{\\sum_{i=1}^\\infty T_i}")#text(" is a bounded linear operator with an operator norm bound on ")#mi("{M}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" If we specialise to the case where all the ")#mi("{T_i}")#text(" are equal, we see that the bound in the Cotlar-Stein lemma is sharp, at least in this case. Thus we see how the tensor power trick can convert an inefficient argument, such as that obtained using the triangle inequality or crude bounds such as ")#link(<tao-a75c0838e8467bc03dcd>)[#text("(15)")]#text(", into an efficient one.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" One can prove Schur’s test by a similar method. Indeed, starting from the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A\\right\\|_{op}^{2N} \\leq \\text{tr}( (AA^*)^N )", block: true)]]

#text("(which follows easily from the singular value decomposition), we can bound ")#tao-math("{\\left\\|A\\right\\|_{op}^{2N}}", block: false)#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{i_1,\\ldots,j_N \\in \\{1,\\ldots,n\\}} a_{i_1,j_1} \\overline{a_{j_1,i_2}} \\ldots a_{i_N,j_N} \\overline{a_{j_N,i_1}}.")]]

#text("Estimating the other two terms in the summand by ")#mi("{M}")#text(", and then repeatedly summing the indices one at a time as before, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A\\right\\|_{op}^{2N} \\leq n M^{2N}", block: true)]]

#text("and the claim follows from the tensor power trick as before. On the other hand, in the converse direction, I do not know of any way to prove the Cotlar-Stein lemma that does not basically go through the tensor power argument.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2011")])]

#text("Prof. Tao,")

#text("Could you please write an expository note on Calderon-Zygmund decomposition?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53128")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2011")])]

#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes4.dvi")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/notes4.dvi")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2011")])]

#text("Thank you Prof. Tao")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d0c9b6e3d598fc6819a9be70726912eb2945d73e74e961443995e631e7c3e4-e5a143bae28f525b55b430b325d4eaeb879ffbbbaf6aa4f7025a0bb4879843c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joerg Grande")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53123")[#strong[#text("Joerg Grande")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2011")])]

#text("The comment on the triangle inequality between (8) and (9) should use a sum, not the supremum.")

#text("Best regards")#linebreak()#text(" Joerg")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af6d89776fbf07a919d7a9f817191bd8bd1a412b23ec6b8704e81d070719fb83-f00d7cd95adf3f32fd63b826239e27d7131cf2eef8fb812858f97bee71e4911a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Janakiraman")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53258")[#strong[#text("Janakiraman")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2011")])]

#text("Prof.Tao")#linebreak()#text(" I have a question regarding the norm of a block diagonal operator. Eq.8 and Eq. 9 and 10 are if and only if statements? Also i feel if the column vectors of the operator can be normalized such that T=QM where Q is the unitary matrix and M is the diagonal matrix whose diagonal entries are the norms of the column vectors. This is very similar to singular value decomposition (without the unitary operator on the right hand side) where the largest value of M is nothing but the largest norm of the column vector. So is there a way to relate the singular values to the norm of the column vectors?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af6d89776fbf07a919d7a9f817191bd8bd1a412b23ec6b8704e81d070719fb83-f00d7cd95adf3f32fd63b826239e27d7131cf2eef8fb812858f97bee71e4911a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Janakiraman")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53260")[#strong[#text("Janakiraman")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2011")])]

#text("I guess the unitary operator on the right hand side is just the identity. And now i feel it satisfies the singular value decomposition and the norm of the operator is the supremum amongst the norm of the column vectors.")

#text("I’m sorry i got the eqn 8 and 9 wrong. They are orthogonal in sense, i believe they map the vector to different subspaces of the vector space. I guess that has nothing to do with unitary. Sorry for the wrong correlation i tried to create")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-53847")[#strong[#text("Seventh Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")]

#text("[…] Tao: The Cotlar-Stein Lemma, Locally compact groups with faithful finite-dimensional representations, van Dantzig’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85fec62161e04c2ae3b028b5eccf6ff083ede62b26d23968a23e4789869f23bf-0ca208eb6faafa70367604d809ad364a6359d20b904df7c950b7bf3d3c2fa5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Carbery")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-88041")[#strong[#text("Tony Carbery")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2011")])]

#text("The extension of the Cotlar–Stein lemma to infinite sums is classical, and is discussed on p. 318 of Stein’s book Harmonic Analysis. It certainly goes back as far as work by David, Journe and Semmes in the mid 1980’s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-88244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2011")])]

#text("Thanks, Tony! I’m not sure how I managed to miss that bit of discussion; I’ve read through that particular chapter multiple times. Anyway, thanks again for pointing it out.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A spectral theory proof of the algebraic regularity lemma | What's new")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-249474")[#strong[#text("A spectral theory proof of the algebraic regularity lemma | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2013")])]

#text("[…] now prove this lemma, by combining spectral theory with an (iterated) method. We may assume that is sufficiently large depending on , as the claim is trivial otherwise (just […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/05/25/the-cotlar-stein-lemma/#comment-688612")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2025")])]

#text("Hello Terry,")

#text("Just some typos in this post:")

#text("When you use the AM-GM inequality, there is an additional bracket between x_j and y_i.")

#text("In line (10), it should be T*_j not T*j.")

#text("which essentically capture -> which essentially capture")

#text("Thank you for such an insightful post.")

#emph[#text("[Corrected, thanks – T.]")]
]
