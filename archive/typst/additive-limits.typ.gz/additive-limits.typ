// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/10/12/additive-limits/
// Converted to Typst by tao2typ: "2026-10-14T10:20:53.162292+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Additive limits", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Additive limits")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 October 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/")[#text("https://terrytao.wordpress.com/2014/10/12/additive-limits/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In graph theory, the recently developed theory of ")#emph[#text("graph limits")]#text(" has proven to be a useful tool for analysing large dense graphs, being a convenient reformulation of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(". Roughly speaking, the theory asserts that given any sequence ")#mi("{G_n = (V_n, E_n)}")#text(" of finite graphs, one can extract a subsequence ")#mi("{G_{n_j} = (V_{n_j}, E_{n_j})}")#text(" which converges (in a specific sense) to a continuous object known as a “graphon” – a symmetric measurable function ")#mi("{p\\colon [0,1] \\times [0,1] \\rightarrow [0,1]}")#text(". What “converges” means in this context is that subgraph densities converge to the associated integrals of the graphon ")#mi("{p}")#text(". For instance, the edge density")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|V_{n_j}\\right|^2} \\left|E_{n_j}\\right|", block: true)]]

#text("converge to the integral")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 \\int_0^1 p(x,y)\\ dx dy,")]]

#text("the triangle density")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|V_{n_j}\\right|^3} \\left| \\{ (v_1,v_2,v_3) \\in V_{n_j}^3: \\{v_1,v_2\\}, \\{v_2,v_3\\}, \\{v_3,v_1\\} \\in E_{n_j} \\} \\right|", block: true)]]

#text("converges to the integral")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 \\int_0^1 \\int_0^1 p(x_1,x_2) p(x_2,x_3) p(x_3,x_1)\\ dx_1 dx_2 dx_3,")]]

#text("the four-cycle density")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|V_{n_j}\\right|^4} \\left| \\{ (v_1,v_2,v_3,v_4) \\in V_{n_j}^4: \\{v_1,v_2\\}, \\{v_2,v_3\\}, \\{v_3,v_4\\}, \\{v_4,v_1\\} \\in E_{n_j} \\} \\right|", block: true)]]

#text("converges to the integral")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 \\int_0^1 \\int_0^1 \\int_0^1 p(x_1,x_2) p(x_2,x_3) p(x_3,x_4) p(x_4,x_1)\\ dx_1 dx_2 dx_3 dx_4,")]]

#text("and so forth. One can use graph limits to prove many results in graph theory that were traditionally proven using the regularity lemma, such as the triangle removal lemma, and can also reduce many asymptotic graph theory problems to continuous problems involving multilinear integrals (although the latter problems are not necessarily easy to solve!). See ")#link("http://www.ams.org/bookstore-getitem/item=COLL-60")[#text("this text of Lovasz")]#text(" for a detailed study of graph limits and their applications.")

#text("One can also express graph limits (and more generally hypergraph limits) in the language of nonstandard analysis (or of ultraproducts); see for instance ")#link("http://arxiv.org/abs/0810.4062")[#text("this paper of Elek and Szegedy")]#text(", Section 6 of ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(", or ")#link("http://arxiv.org/abs/1312.4882")[#text("this paper of Towsner")]#text(". (In this post we assume some familiarity with nonstandard analysis, as reviewed for instance in the previous blog post.) Here, one starts as before with a sequence ")#mi("{G_n = (V_n,E_n)}")#text(" of finite graphs, and then takes an ultraproduct (with respect to some arbitrarily chosen non-principal ultrafilter ")#mi("{\\alpha \\in\\beta {\\bf N} \\backslash {\\bf N}}")#text(") to obtain a nonstandard graph ")#mi("{G_\\alpha = (V_\\alpha,E_\\alpha)}")#text(", where ")#mi("{V_\\alpha = \\prod_{n\\rightarrow \\alpha} V_n}")#text(" is the ultraproduct of the ")#mi("{V_n}")#text(", and similarly for the ")#mi("{E_\\alpha}")#text(". The set ")#mi("{E_\\alpha}")#text(" can then be viewed as a symmetric subset of ")#mi("{V_\\alpha \\times V_\\alpha}")#text(" which is measurable with respect to the Loeb ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal L}_{V_\\alpha \\times V_\\alpha}}")#text(" of the product ")#mi("{V_\\alpha \\times V_\\alpha}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(" for the construction of Loeb measure). A crucial point is that this ")#mi("{\\sigma}")#text("-algebra is larger than the product ")#mi("{{\\mathcal L}_{V_\\alpha} \\times {\\mathcal L}_{V_\\alpha}}")#text(" of the Loeb ")#mi("{\\sigma}")#text("-algebra of the individual vertex set ")#mi("{V_\\alpha}")#text(". This leads to a decomposition")

#align(center)[#tao-fit-display[#mitex("1_{E_\\alpha} = p + e")]]

#text("where the “graphon” ")#mi("{p}")#text(" is the orthogonal projection of ")#mi("{1_{E_\\alpha}}")#text(" onto ")#mi("{L^2( {\\mathcal L}_{V_\\alpha} \\times {\\mathcal L}_{V_\\alpha} )}")#text(", and the “regular error” ")#mi("{e}")#text(" is orthogonal to all product sets ")#mi("{A \\times B}")#text(" for ")#mi("{A, B \\in {\\mathcal L}_{V_\\alpha}}")#text(". The graphon ")#mi("{p\\colon V_\\alpha \\times V_\\alpha \\rightarrow [0,1]}")#text(" then captures the statistics of the nonstandard graph ")#mi("{G_\\alpha}")#text(", in exact analogy with the more traditional graph limits: for instance, the edge density")

#align(center)[#tao-fit-display[#tao-math("\\text{st} \\frac{1}{\\left|V_\\alpha\\right|^2} \\left|E_\\alpha\\right|", block: true)]]

#text("(or equivalently, the limit of the ")#tao-math("{\\frac{1}{\\left|V_n\\right|^2} \\left|E_n\\right|}", block: false)#text(" along the ultrafilter ")#mi("{\\alpha}")#text(") is equal to the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{V_\\alpha} \\int_{V_\\alpha} p(x,y)\\ d\\mu_{V_\\alpha}(x) d\\mu_{V_\\alpha}(y)")]]

#text("where ")#mi("{d\\mu_V}")#text(" denotes Loeb measure on a nonstandard finite set ")#mi("{V}")#text("; the triangle density")

#align(center)[#tao-fit-display[#tao-math("\\text{st} \\frac{1}{\\left|V_\\alpha\\right|^3} \\left| \\{ (v_1,v_2,v_3) \\in V_\\alpha^3: \\{v_1,v_2\\}, \\{v_2,v_3\\}, \\{v_3,v_1\\} \\in E_\\alpha \\} \\right|", block: true)]]

#text("(or equivalently, the limit along ")#mi("{\\alpha}")#text(" of the triangle densities of ")#mi("{E_n}")#text(") is equal to the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{V_\\alpha} \\int_{V_\\alpha} \\int_{V_\\alpha} p(x_1,x_2) p(x_2,x_3) p(x_3,x_1)\\ d\\mu_{V_\\alpha}(x_1) d\\mu_{V_\\alpha}(x_2) d\\mu_{V_\\alpha}(x_3),")]]

#text("and so forth. Note that with this construction, the graphon ")#mi("{p}")#text(" is living on the Cartesian square of an abstract probability space ")#mi("{V_\\alpha}")#text(", which is likely to be inseparable; but it is possible to cut down the Loeb ")#mi("{\\sigma}")#text("-algebra on ")#mi("{V_\\alpha}")#text(" to minimal countable ")#mi("{\\sigma}")#text("-algebra for which ")#mi("{p}")#text(" remains measurable (up to null sets), and then one can identify ")#mi("{V_\\alpha}")#text(" with ")#mi("{[0,1]}")#text(", bringing this construction of a graphon in line with the traditional notion of a graphon. (See Remark 5 of ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(" for more discussion of this point.)")

#text("Additive combinatorics, which studies things like the additive structure of finite subsets ")#mi("{A}")#text(" of an abelian group ")#mi("{G = (G,+)}")#text(", has many analogies and connections with asymptotic graph theory; in particular, there is the ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("arithmetic regularity lemma of Green")]#text(" which is analogous to the graph regularity lemma of Szemerédi. (There is also a ")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("higher order arithmetic regularity lemma")]#text(" analogous to hypergraph regularity lemmas, but this is not the focus of the discussion here.) Given this, it is natural to suspect that there is a theory of “additive limits” for large additive sets of bounded doubling, analogous to the theory of graph limits for large dense graphs. The purpose of this post is to record a candidate for such an additive limit. This limit can be used as a substitute for the arithmetic regularity lemma in certain results in additive combinatorics, at least if one is willing to settle for qualitative results rather than quantitative ones; I give a few examples of this below the fold.")

#text("It seems that to allow for the most flexible and powerful manifestation of this theory, it is convenient to use the nonstandard formulation (among other things, it allows for full use of the transfer principle, whereas a more traditional limit formulation would only allow for a transfer of those quantities continuous with respect to the notion of convergence). Here, the analogue of a nonstandard graph is an ")#emph[#text("ultra approximate group")]#text(" ")#mi("{A_\\alpha}")#text(" in a nonstandard group ")#mi("{G_\\alpha = \\prod_{n \\rightarrow \\alpha} G_n}")#text(", defined as the ultraproduct of finite ")#mi("{K}")#text("-approximate groups ")#mi("{A_n \\subset G_n}")#text(" for some standard ")#mi("{K}")#text(". (A ")#mi("{K}")#text("-approximate group ")#mi("{A_n}")#text(" is a symmetric set containing the origin such that ")#mi("{A_n+A_n}")#text(" can be covered by ")#mi("{K}")#text(" or fewer translates of ")#mi("{A_n}")#text(".) We then let ")#mi("{O(A_\\alpha)}")#text(" be the external subgroup of ")#mi("{G_\\alpha}")#text(" generated by ")#mi("{A_\\alpha}")#text("; equivalently, ")#mi("{A_\\alpha}")#text(" is the union of ")#mi("{A_\\alpha^m}")#text(" over all standard ")#mi("{m}")#text(". This space has a Loeb measure ")#mi("{\\mu_{O(A_\\alpha)}}")#text(", defined by setting")

#align(center)[#tao-fit-display[#tao-math("\\mu_{O(A_\\alpha)}(E_\\alpha) := \\text{st} \\frac{\\left|E_\\alpha\\right|}{\\left|A_\\alpha\\right|}", block: true)]]

#text("whenever ")#mi("{E_\\alpha}")#text(" is an internal subset of ")#mi("{A_\\alpha^m}")#text(" for any standard ")#mi("{m}")#text(", and extended to a countably additive measure; the arguments in Section 6 of ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(" can be easily modified to give a construction of this measure.")

#text("The Loeb measure ")#mi("{\\mu_{O(A_\\alpha)}}")#text(" is a translation invariant measure on ")#mi("{O(A_{\\alpha})}")#text(", normalised so that ")#mi("{A_\\alpha}")#text(" has Loeb measure one. As such, one should think of ")#mi("{O(A_\\alpha)}")#text(" as being analogous to a locally compact abelian group equipped with a Haar measure. It should be noted though that ")#mi("{O(A_\\alpha)}")#text(" is not ")#emph[#text("actually")]#text(" a locally compact group with Haar measure, for two reasons:")

#list(
[#text("There is not an obvious topology on ")#mi("{O(A_\\alpha)}")#text(" that makes it simultaneously locally compact, Hausdorff, and ")#mi("{\\sigma}")#text("-compact. (One can get one or two out of three without difficulty, though.)")],
[#text("The addition operation ")#mi("{+\\colon O(A_\\alpha) \\times O(A_\\alpha) \\rightarrow O(A_\\alpha)}")#text(" is not measurable from the product Loeb algebra ")#mi("{{\\mathcal L}_{O(A_\\alpha)} \\times {\\mathcal L}_{O(A_\\alpha)}}")#text(" to ")#mi("{{\\mathcal L}_{O(\\alpha)}}")#text(". Instead, it is measurable from the coarser Loeb algebra ")#mi("{{\\mathcal L}_{O(A_\\alpha) \\times O(A_\\alpha)}}")#text(" to ")#mi("{{\\mathcal L}_{O(\\alpha)}}")#text(" (compare with the analogous situation for nonstandard graphs).")]
)

#text("Nevertheless, the analogy is a useful guide for the arguments that follow.")

#text("Let ")#mi("{L(O(A_\\alpha))}")#text(" denote the space of bounded Loeb measurable functions ")#mi("{f\\colon O(A_\\alpha) \\rightarrow {\\bf C}}")#text(" (modulo almost everywhere equivalence) that are supported on ")#mi("{A_\\alpha^m}")#text(" for some standard ")#mi("{m}")#text("; this is a complex algebra with respect to pointwise multiplication. There is also a convolution operation ")#mi("{\\star\\colon L(O(A_\\alpha)) \\times L(O(A_\\alpha)) \\rightarrow L(O(A_\\alpha))}")#text(", defined by setting")

#align(center)[#tao-fit-display[#tao-math("\\text{st} f \\star \\text{st} g(x) := \\text{st} \\frac{1}{\\left|A_\\alpha\\right|} \\sum_{y \\in A_\\alpha^m} f(y) g(x-y)", block: true)]]

#text("whenever ")#mi("{f\\colon A_\\alpha^m \\rightarrow {}^* {\\bf C}}")#text(", ")#mi("{g\\colon A_\\alpha^l \\rightarrow {}^* {\\bf C}}")#text(" are bounded nonstandard functions (extended by zero to all of ")#mi("{O(A_\\alpha)}")#text("), and then extending to arbitrary elements of ")#mi("{L(O(A_\\alpha))}")#text(" by density. Equivalently, ")#mi("{f \\star g}")#text(" is the pushforward of the ")#mi("{{\\mathcal L}_{O(A_\\alpha) \\times O(A_\\alpha)}}")#text("-measurable function ")#mi("{(x,y) \\mapsto f(x) g(y)}")#text(" under the map ")#mi("{(x,y) \\mapsto x+y}")#text(".")

#text("The basic structural theorem is then as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Kronecker factor)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{A_\\alpha}")#text(" be an ultra approximate group. Then there exists a (standard) locally compact abelian group ")#mi("{G}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("G = {\\bf R}^d \\times {\\bf Z}^m \\times T")]]

#text("for some standard ")#mi("{d,m}")#text(" and some compact abelian group ")#mi("{T}")#text(", equipped with a Haar measure ")#mi("{\\mu_G}")#text(" and a measurable homomorphism ")#mi("{\\pi\\colon O(A_\\alpha) \\rightarrow G}")#text(" (using the Loeb ")#mi("{\\sigma}")#text("-algebra on ")#mi("{O(A_\\alpha)}")#text(" and the ")#link("http://en.wikipedia.org/wiki/Baire_set")[#text("Baire")]#text(" ")#mi("{\\sigma}")#text("-algebra on ")#mi("{G}")#text("), with the following properties:")

#list(
[#text("(i) ")#mi("{\\pi}")#text(" has dense image, and ")#mi("{\\mu_G}")#text(" is the pushforward of Loeb measure ")#mi("{\\mu_{O(A_\\alpha)}}")#text(" by ")#mi("{\\pi}")#text(".")],
[#text("(ii) There exists sets ")#mi("{\\{0\\} \\subset U_0 \\subset K_0 \\subset G}")#text(" with ")#mi("{U_0}")#text(" open and ")#mi("{K_0}")#text(" compact, such that")

#metadata(none) <tao-4ea3146203aae8dfbb97>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\pi^{-1}(U_0) \\subset 4A_\\alpha \\subset \\pi^{-1}(K_0).")]]],
[#text("(iii) Whenever ")#mi("{K \\subset U \\subset G}")#text(" with ")#mi("{K}")#text(" compact and ")#mi("{U}")#text(" open, there exists a nonstandard finite set ")#mi("{B}")#text(" such that")

#metadata(none) <tao-623210167553939c87ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\pi^{-1}(K) \\subset B \\subset \\pi^{-1}(U).")]]],
[#text("(iv) If ")#mi("{f, g \\in L}")#text(", then we have the convolution formula")

#metadata(none) <tao-3f22f007dace5d04260f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f \\star g = \\pi^*( (\\pi_* f) \\star (\\pi_* g) )")]]

#text("where ")#mi("{\\pi_* f,\\pi_* g}")#text(" are the pushforwards of ")#mi("{f,g}")#text(" to ")#mi("{L^2(G, \\mu_G)}")#text(", the convolution ")#mi("{\\star}")#text(" on the right-hand side is convolution using ")#mi("{\\mu_G}")#text(", and ")#mi("{\\pi^*}")#text(" is the pullback map from ")#mi("{L^2(G,\\mu_G)}")#text(" to ")#mi("{L^2(O(A_\\alpha), \\mu_{O(A_\\alpha)})}")#text(". In particular, if ")#mi("{\\pi_* f = 0}")#text(", then ")#mi("{f*g=0}")#text(" for all ")#mi("{g \\in L}")#text(".")]
)
]

#text("One can view the locally compact abelian group ")#mi("{G}")#text(" as a “model “or “Kronecker factor” for the ultra approximate group ")#mi("{A_\\alpha}")#text(" (in close analogy with the Kronecker factor from ergodic theory). In the case that ")#mi("{A_\\alpha}")#text(" is a genuine nonstandard finite group rather than an ultra approximate group, the non-compact components ")#mi("{{\\bf R}^d \\times {\\bf Z}^m}")#text(" of the Kronecker group ")#mi("{G}")#text(" are trivial, and this theorem was implicitly established ")#link("http://arxiv.org/abs/1203.2260")[#text("by Szegedy")]#text(". The compact group ")#mi("{T}")#text(" is quite large, and in particular is likely to be inseparable; but as with the case of graphons, when one is only studying at most countably many functions ")#mi("{f}")#text(", one can cut down the size of this group to be separable (or equivalently, second countable or metrisable) if desired, so one often works with a “reduced Kronecker factor” which is a quotient of the full Kronecker factor ")#mi("{G}")#text(". Once one is in the separable case, the Baire sigma algebra is identical with the more familiar Borel sigma algebra.")

#text("Given any sequence of uniformly bounded functions ")#mi("{f_n\\colon A_n^m \\rightarrow {\\bf C}}")#text(" for some fixed ")#mi("{m}")#text(", we can view the function ")#mi("{f \\in L}")#text(" defined by ")#metadata(none) <tao-9f0c710ce3e5bb37de41>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f := \\pi_* \\text{st} \\lim_{n \\rightarrow \\alpha} f_n")]]

#text("as an “additive limit” of the ")#mi("{f_n}")#text(", in much the same way that graphons ")#mi("{p\\colon V_\\alpha \\times V_\\alpha \\rightarrow [0,1]}")#text(" are limits of the indicator functions ")#mi("{1_{E_n}\\colon V_n \\times V_n \\rightarrow \\{0,1\\}}")#text(". The additive limits capture some of the statistics of the ")#mi("{f_n}")#text(", for instance the normalised means")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|A_n\\right|} \\sum_{x \\in A_n^m} f_n(x)", block: true)]]

#text("converge (along the ultrafilter ")#mi("{\\alpha}")#text(") to the mean")

#align(center)[#tao-fit-display[#mitex("\\int_G f(x)\\ d\\mu_G(x),")]]

#text("and for three sequences ")#mi("{f_n,g_n,h_n\\colon A_n^m \\rightarrow {\\bf C}}")#text(" of functions, the normalised correlation")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|A_n\\right|^2} \\sum_{x,y \\in A_n^m} f_n(x) g_n(y) h_n(x+y)", block: true)]]

#text("converges along ")#mi("{\\alpha}")#text(" to the correlation")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f(x) g(y) h(x+y)\\ d\\mu_G(x) d\\mu_G(y),")]]

#text("the normalised ")#mi("{U^2}")#text(" Gowers norm")

#align(center)[#tao-fit-display[#tao-math("( \\frac{1}{\\left|A_n\\right|^3} \\sum_{x,y,z,w \\in A_n^m: x+w=y+z} f_n(x) \\overline{f_n(y)} \\overline{f_n(z)} f_n(w))^{1/4}", block: true)]]

#text("converges along ")#mi("{\\alpha}")#text(" to the ")#mi("{U^2}")#text(" Gowers norm")

#align(center)[#tao-fit-display[#mitex("( \\int_{G \\times G \\times G} f(x) \\overline{f(y)} \\overline{f(z)} f_n(x+y-z)\\ d\\mu_G(x) d\\mu_G(y) d\\mu_G(z))^{1/4}")]]

#text("and so forth. We caution however that some correlations that involve evaluating more than one function at the same point will not necessarily be preserved in the additive limit; for instance the normalised ")#mi("{\\ell^2}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("(\\frac{1}{\\left|A_n\\right|} \\sum_{x \\in A_n^m} \\left|f_n(x)\\right|^2)^{1/2}", block: true)]]

#text("does not necessarily converge to the ")#mi("{L^2}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("(\\int_G \\left|f(x)\\right|^2\\ d\\mu_G(x))^{1/2},", block: true)]]

#text("but can converge instead to a larger quantity, due to the presence of the orthogonal projection ")#mi("{\\pi_*}")#text(" in the definition ")#link(<tao-9f0c710ce3e5bb37de41>)[#text("(4)")]#text(" of ")#mi("{f}")#text(".")

#text("An important special case of an additive limit occurs when the functions ")#mi("{f_n\\colon A_n^m \\rightarrow {\\bf C}}")#text(" involved are indicator functions ")#mi("{f_n = 1_{E_n}}")#text(" of some subsets ")#mi("{E_n}")#text(" of ")#mi("{A_n^m}")#text(". The additive limit ")#mi("{f \\in L}")#text(" does not necessarily remain an indicator function, but instead takes values in ")#mi("{[0,1]}")#text(" (much as a graphon ")#mi("{p}")#text(" takes values in ")#mi("{[0,1]}")#text(" even though the original indicators ")#mi("{1_{E_n}}")#text(" take values in ")#mi("{\\{0,1\\}}")#text("). The convolution ")#mi("{f \\star f\\colon G \\rightarrow [0,1]}")#text(" is then the ultralimit of the normalised convolutions ")#tao-math("{\\frac{1}{\\left|A_n\\right|} 1_{E_n} \\star 1_{E_n}}", block: false)#text("; in particular, the measure of the support of ")#mi("{f \\star f}")#text(" provides a lower bound on the limiting normalised cardinality ")#tao-math("{\\frac{1}{\\left|A_n\\right|} \\left|E_n + E_n\\right|}", block: false)#text(" of a sumset. In many situations this lower bound is an equality, but this is not necessarily the case, because the sumset ")#mi("{2E_n = E_n + E_n}")#text(" could contain a large number of elements which have very few (")#tao-math("{o(\\left|A_n\\right|)}", block: false)#text(") representations as the sum of two elements of ")#mi("{E_n}")#text(", and in the limit these portions of the sumset fall outside of the support of ")#mi("{f \\star f}")#text(". (One can think of the support of ")#mi("{f \\star f}")#text(" as describing the “essential” sumset of ")#mi("{2E_n = E_n + E_n}")#text(", discarding those elements that have only very few representations.) Similarly for higher convolutions of ")#mi("{f}")#text(". Thus one can use additive limits to partially control the growth ")#mi("{k E_n}")#text(" of iterated sumsets of subsets ")#mi("{E_n}")#text(" of approximate groups ")#mi("{A_n}")#text(", in the regime where ")#mi("{k}")#text(" stays bounded and ")#mi("{n}")#text(" goes to infinity.")

#text("Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" can be proven by Fourier-analytic means (combined with Freiman’s theorem from additive combinatorics), and we will do so below the fold. For now, we give some illustrative examples of additive limits.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Bohr sets)")]#text(" We take ")#mi("{A_n}")#text(" to be the intervals ")#tao-math("{A_n := \\{ x \\in {\\bf Z}: \\left|x\\right| \\leq N_n \\}}", block: false)#text(", where ")#mi("{N_n}")#text(" is a sequence going to infinity; these are ")#mi("{2}")#text("-approximate groups for all ")#mi("{n}")#text(". Let ")#mi("{\\theta}")#text(" be an irrational real number, let ")#mi("{I}")#text(" be an interval in ")#mi("{{\\bf R}/{\\bf Z}}")#text(", and for each natural number ")#mi("{n}")#text(" let ")#mi("{B_n}")#text(" be the Bohr set")

#align(center)[#tao-fit-display[#mitex("B_n := \\{ x \\in A^{(n)}: \\theta x \\text{ mod } 1 \\in I \\}.")]]

#text("In this case, the (reduced) Kronecker factor ")#mi("{G}")#text(" can be taken to be the infinite cylinder ")#mi("{{\\bf R} \\times {\\bf R}/{\\bf Z}}")#text(" with the usual Lebesgue measure ")#mi("{\\mu_G}")#text(". The additive limits of ")#mi("{1_{A_n}}")#text(" and ")#mi("{1_{B_n}}")#text(" end up being ")#mi("{1_A}")#text(" and ")#mi("{1_B}")#text(", where ")#mi("{A}")#text(" is the finite cylinder")

#align(center)[#tao-fit-display[#mitex("A := \\{ (x,t) \\in {\\bf R} \\times {\\bf R}/{\\bf Z}: x \\in [-1,1]\\}")]]

#text("and ")#mi("{B}")#text(" is the rectangle")

#align(center)[#tao-fit-display[#mitex("B := \\{ (x,t) \\in {\\bf R} \\times {\\bf R}/{\\bf Z}: x \\in [-1,1]; t \\in I \\}.")]]

#text("Geometrically, one should think of ")#mi("{A_n}")#text(" and ")#mi("{B_n}")#text(" as being wrapped around the cylinder ")#mi("{{\\bf R} \\times {\\bf R}/{\\bf Z}}")#text(" via the homomorphism ")#mi("{x \\mapsto (\\frac{x}{N_n}, \\theta x \\text{ mod } 1)}")#text(", and then one sees that ")#mi("{B_n}")#text(" is converging in some normalised weak sense to ")#mi("{B}")#text(", and similarly for ")#mi("{A_n}")#text(" and ")#mi("{A}")#text(". In particular, the additive limit predicts the growth rate of the iterated sumsets ")#mi("{kB_n}")#text(" to be quadratic in ")#mi("{k}")#text(" until ")#tao-math("{k\\left|I\\right|}", block: false)#text(" becomes comparable to ")#mi("{1}")#text(", at which point the growth transitions to linear growth, in the regime where ")#mi("{k}")#text(" is bounded and ")#mi("{n}")#text(" is large.")

#text("If ")#mi("{\\theta = \\frac{p}{q}}")#text(" were rational instead of irrational, then one would need to replace ")#mi("{{\\bf R}/{\\bf Z}}")#text(" by the finite subgroup ")#mi("{\\frac{1}{q}{\\bf Z}/{\\bf Z}}")#text(" here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Structured subsets of progressions)")]#text(" We take ")#mi("{A_n}")#text(" be the rank two progression")

#align(center)[#tao-fit-display[#tao-math("A_n := \\{ a + b N_n^2: a,b \\in {\\bf Z}; \\left|a\\right|, \\left|b\\right| \\leq N_n \\},", block: true)]]

#text("where ")#mi("{N_n}")#text(" is a sequence going to infinity; these are ")#mi("{4}")#text("-approximate groups for all ")#mi("{n}")#text(". Let ")#mi("{B_n}")#text(" be the subset")

#align(center)[#tao-fit-display[#tao-math("B_n := \\{ a + b N_n^2: a,b \\in {\\bf Z}; \\left|a\\right|^2 + \\left|b\\right|^2 \\leq N_n^2 \\}.", block: true)]]

#text("Then the (reduced) Kronecker factor can be taken to be ")#mi("{G = {\\bf R}^2}")#text(" with Lebesgue measure ")#mi("{\\mu_G}")#text(", and the additive limits of the ")#mi("{1_{A_n}}")#text(" and ")#mi("{1_{B_n}}")#text(" are then ")#mi("{1_A}")#text(" and ")#mi("{1_B}")#text(", where ")#mi("{A}")#text(" is the square")

#align(center)[#tao-fit-display[#tao-math("A := \\{ (a,b) \\in {\\bf R}^2: \\left|a\\right|, \\left|b\\right| \\leq 1 \\}", block: true)]]

#text("and ")#mi("{B}")#text(" is the circle")

#align(center)[#tao-fit-display[#mitex("B := \\{ (a,b) \\in {\\bf R}^2: a^2+b^2 \\leq 1 \\}.")]]

#text("Geometrically, the picture is similar to the Bohr set one, except now one uses a Freiman homomorphism ")#mi("{a + b N_n^2 \\mapsto (\\frac{a}{N_n}, \\frac{b}{N_n})}")#text(" for ")#mi("{a,b = O( N_n )}")#text(" to embed the original sets ")#mi("{A_n, B_n}")#text(" into the plane ")#mi("{{\\bf R}^2}")#text(". In particular, one now expects the growth rate of the iterated sumsets ")#mi("{k A_n}")#text(" and ")#mi("{k B_n}")#text(" to be quadratic in ")#mi("{k}")#text(", in the regime where ")#mi("{k}")#text(" is bounded and ")#mi("{n}")#text(" is large.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Dissociated sets)")]#text(" Let ")#mi("{d}")#text(" be a fixed natural number, and take")

#align(center)[#tao-fit-display[#mitex("A_n = \\{0, v_1,\\dots,v_d,-v_1,\\dots,-v_d \\}")]]

#text("where ")#mi("{v_1,\\dots,v_d}")#text(" are randomly chosen elements of a large cyclic group ")#mi("{{\\bf Z}/p_n{\\bf Z}}")#text(", where ")#mi("{p_n}")#text(" is a sequence of primes going to infinity. These are ")#mi("{O(d)}")#text("-approximate groups. The (reduced) Kronecker factor ")#mi("{G}")#text(" can (almost surely) then be taken to be ")#mi("{{\\bf Z}^d}")#text(" with counting measure, and the additive limit of ")#mi("{1_{A_n}}")#text(" is ")#mi("{1_A}")#text(", where ")#mi("{A = \\{ 0, e_1,\\dots,e_d,-e_1,\\dots,-e_d\\}}")#text(" and ")#mi("{e_1,\\dots,e_d}")#text(" is the standard basis of ")#mi("{{\\bf Z}^d}")#text(". In particular, the growth rates of ")#mi("{k A_n}")#text(" should grow approximately like ")#mi("{k^d}")#text(" for ")#mi("{k}")#text(" bounded and ")#mi("{n}")#text(" large.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5 (Random subsets of groups)")]#text(" Let ")#mi("{A_n = G_n}")#text(" be a sequence of finite additive groups whose order is going to infinity. Let ")#mi("{B_n}")#text(" be a random subset of ")#mi("{G_n}")#text(" of some fixed density ")#mi("{0 \\leq \\lambda \\leq 1}")#text(". Then (almost surely) the Kronecker factor here can be reduced all the way to the trivial group ")#mi("{\\{0\\}}")#text(", and the additive limit of the ")#mi("{1_{B_n}}")#text(" is the constant function ")#mi("{\\lambda}")#text(". The convolutions ")#tao-math("{\\frac{1}{\\left|G_n\\right|} 1_{B_n} * 1_{B_n}}", block: false)#text(" then converge in the ultralimit (modulo almost everywhere equivalence) to the pullback of ")#mi("{\\lambda^2}")#text("; this reflects the fact that ")#tao-math("{(1-o(1))\\left|G_n\\right|}", block: false)#text(" of the elements of ")#mi("{G_n}")#text(" can be represented as the sum of two elements of ")#mi("{B_n}")#text(" in ")#tao-math("{(\\lambda^2 + o(1)) \\left|G_n\\right|}", block: false)#text(" ways. In particular, ")#mi("{B_n+B_n}")#text(" occupies a proportion ")#mi("{1-o(1)}")#text(" of ")#mi("{G_n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Trigonometric series)")]#text(" Take ")#mi("{A_n = G_n = {\\bf Z}/p_n {\\bf C}}")#text(" for a sequence ")#mi("{p_n}")#text(" of primes going to infinity, and for each ")#mi("{n}")#text(" let ")#mi("{\\xi_{n,1},\\xi_{n,2},\\dots}")#text(" be an infinite sequence of frequencies chosen uniformly and independently from ")#mi("{{\\bf Z}/p_n{\\bf Z}}")#text(". Let ")#mi("{f_n\\colon {\\bf Z}/p_n{\\bf Z} \\rightarrow {\\bf C}}")#text(" denote the random trigonometric series")

#align(center)[#tao-fit-display[#mitex("f_n(x) := \\sum_{j=1}^\\infty 2^{-j} e^{2\\pi i \\xi_{n,j} x / p_n }.")]]

#text("Then (almost surely) we can take the reduced Kronecker factor ")#mi("{G}")#text(" to be the infinite torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(" (with the Haar probability measure ")#mi("{\\mu_G}")#text("), and the additive limit of the ")#mi("{f_n}")#text(" then becomes the function ")#mi("{f\\colon ({\\bf R}/{\\bf Z})^{\\bf N} \\rightarrow {\\bf R}}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("f( (x_j)_{j=1}^\\infty ) := \\sum_{j=1}^\\infty e^{2\\pi i x_j}.")]]

#text("In fact, the pullback ")#mi("{\\pi^* f}")#text(" is the ultralimit of the ")#mi("{f_n}")#text(". As such, for any standard exponent ")#mi("{1 \\leq q < \\infty}")#text(", the normalised ")#mi("{l^q}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("(\\frac{1}{p_n} \\sum_{x \\in {\\bf Z}/p_n{\\bf Z}} \\left|f_n(x)\\right|^q)^{1/q}", block: true)]]

#text("can be seen to converge to the limit")

#align(center)[#tao-fit-display[#tao-math("(\\int_{({\\bf R}/{\\bf Z})^{\\bf N}} \\left|f(x)\\right|^q\\ d\\mu_G(x))^{1/q}.", block: true)]]
]

#text("The reader is invited to consider combinations of the above examples, e.g. random subsets of Bohr sets, to get a sense of the general case of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(".")

#text("It is likely that this theorem can be extended to the noncommutative setting, using the ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("noncommutative Freiman theorem of Emmanuel Breuillard, Ben Green, and myself")]#text(", but I have not attempted to do so here (see though ")#link("http://arxiv.org/abs/1405.5629")[#text("this recent preprint of Anush Tserunyan")]#text(" for some related explorations); in a separate direction, there should be extensions that can control higher Gowers norms, in the spirit of the ")#link("http://arxiv.org/abs/0903.0897")[#text("work")]#text(" ")#link("http://arxiv.org/abs/0911.1157")[#text("of")]#text(" ")#link("http://arxiv.org/abs/1001.4282")[#text("Szegedy")]#text(".")

#text("Note: the arguments below will presume some familiarity with additive combinatorics and with nonstandard analysis, and will be a little sketchy in places.")

#metadata(none) <tao-6fcb4ac6faa10932a307>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("By Freiman’s theorem for arbitrary abelian groups (see ")#link("http://www.ams.org/mathscinet-getitem?mr=2302736")[#text("this paper of Green and Ruzsa")]#text("), we can find an ")#emph[#text("ultra coset progression")]#text(" ")#mi("{H+P}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("A_\\alpha \\subset H+P \\subset A_\\alpha^m")]]

#text("for some standard ")#mi("{m}")#text("; we abbreviate the latter inclusion as ")#mi("{H+P \\subset A_\\alpha^{O(1)}}")#text(". By an ultra coset progression, we mean the sumset of a nonstandard finite group ")#mi("{H}")#text(" and a nonstandard generalised arithmetic progression")

#align(center)[#tao-fit-display[#tao-math("P = \\{ l_1 a_1 + \\dots + l_r a_r: \\left|l_i\\right| \\leq L_i \\text{ for } i=1,\\dots,r \\}", block: true)]]

#text("with ")#mi("{r}")#text(" (known as the ")#emph[#text("rank")]#text(") standard, the ")#emph[#text("generators")]#text(" ")#mi("{a_1,\\dots,a_r}")#text(" in ")#mi("{O(A_\\alpha)}")#text(" and the ")#emph[#text("dimensions")]#text(" ")#mi("{L_1,\\dots,L_r}")#text(" being nonstandard natural numbers. (To get the containment ")#mi("{H+P \\subset A_\\alpha^{O(1)}}")#text(", one can first use the Bogulybov lemma to get a large ultra coset progression ")#mi("{H+P^{\\prime}}")#text(" inside ")#mi("{A_\\alpha^4}")#text(", so that ")#mi("{A_\\alpha}")#text(" can be covered by ")#mi("{O(1)}")#text(" translates of ")#mi("{H+P^{\\prime}}")#text("; one can then add these translates to the generators of ")#mi("{P^{\\prime}}")#text(" to obtain an ultra coset progression ")#mi("{H+P}")#text(" with the required properties.")

#text("We call the ultra coset progression ")#emph[#mi("{O(1)}")#text("-proper")]#text(" if the sums ")#mi("{h + l_1 a_1 + \\dots + l_r a_r}")#text(" for ")#mi("{h \\in H}")#text(" and ")#mi("{l_i = O(L_i)}")#text(" for ")#mi("{i=1,\\dots,r}")#text(" are all distinct. If ")#mi("{H+P}")#text(" fails to be ")#mi("{O(1)}")#text("-proper, then we can find a containment")

#align(center)[#tao-fit-display[#mitex("H+P \\subset H^{\\prime}+P^{\\prime} \\subset A_\\alpha^{O(1)}")]]

#text("where the coset progression ")#mi("{H^{\\prime}+P^{\\prime}}")#text(" has strictly smaller rank than ")#mi("{H+P}")#text("; see e.g. Lemma 5.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2435645")[#text("this paper of Van Vu and myself")]#text("). Iterating this fact, we see that we may assume without loss of generality that ")#mi("{H+P}")#text(" is ")#mi("{O(1)}")#text("-proper. In particular, the group ")#mi("{O(A_\\alpha)}")#text(" can now be parameterised by the sums ")#mi("{h + l_1 a_1 + \\dots + l_r a_r}")#text(" with ")#mi("{l_i = O(L_i)}")#text(" for ")#mi("{i=1,\\dots,r}")#text(", with each element of ")#mi("{O(A_\\alpha)}")#text(" having exactly one representation of this form.")

#text("The dimensions ")#mi("{L_1,\\dots,L_r}")#text(" are either bounded (and thus standard natural numbers) or unbounded. After permuting the generators if necessary, we may assume that ")#mi("{L_1,\\dots,L_d}")#text(" are unbounded and ")#mi("{L_{d+1},\\dots,L_{d+m}}")#text(" are bounded for some ")#mi("{d,m}")#text(" with ")#mi("{d+m=r}")#text(". We then have an external surjective group homomorphism ")#mi("{\\pi_0\\colon O(A_\\alpha) \\rightarrow {\\bf R}^d \\times {\\bf Z}^m}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\pi_0( h + l_1 a_1 + \\dots + l_r a_r ) := ( \\text{st} \\frac{l_1}{N_1}, \\dots, \\text{st} \\frac{l_d}{N_d}, l_{d+1},\\dots,l_{d+m} );")]]

#text("this will end up being the non-compact portion of the projection map ")#mi("{\\pi\\colon O(A_\\alpha) \\rightarrow G}")#text(" that we will eventually construct. The image ")#mi("{\\pi_0(A_\\alpha)}")#text(" is precompact in ")#mi("{{\\bf R}^d \\times {\\bf Z}^m}")#text(" (in fact it is compact, thanks to countable saturation).")

#text("Now we perform some Fourier analysis on ")#mi("{O(A_\\alpha)}")#text(" (analogous to the usual theory of Fourier analysis on locally compact abelian groups). Define a ")#emph[#text("frequency")]#text(" to be a measurable homomorphism ")#mi("{\\xi\\colon x \\mapsto \\xi \\cdot x}")#text(" from ")#mi("{O(A_\\alpha)}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", and let ")#mi("{\\widehat{O(A_\\alpha)}}")#text(" denote the space of such frequencies; this is an additive group, which should be thought of as a “Pontryagin dual” to ")#mi("{O(A_\\alpha)}")#text(" (even though ")#mi("{O(A_\\alpha)}")#text(" is not a locally compact group). Meanwhile, we have the (genuine) Pontryagin dual ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text(" of ")#mi("{{\\bf R}^d \\times {\\bf Z}^m}")#text(", using the identification")

#align(center)[#tao-fit-display[#mitex("(\\xi_1,\\dots,\\xi_d,\\theta_1,\\dots,\\theta_m) \\cdot (x_1,\\dots,x_d,a_1,\\dots,a_m) := (\\xi_1 x_1 + \\dots + \\xi_d x_d)")]]

#align(center)[#tao-fit-display[#mitex("\\text{ mod } 1 + a_1\\theta_1 + \\dots + a_m \\theta_m.")]]

#text("The homomorphism ")#mi("{\\pi_0\\colon O(A_\\alpha) \\rightarrow {\\bf R}^d \\times {\\bf Z}^m}")#text(" then induces a dual homomorphism ")#mi("{\\hat \\pi_0\\colon {\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m \\rightarrow \\widehat{O(A_\\alpha)}}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat \\pi_0(\\xi) \\cdot x := \\xi \\cdot \\pi_0(x)")]]

#text("for all ")#mi("{\\xi \\in {\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text(" and ")#mi("{x \\in O(A_\\alpha)}")#text(". This homomorphism ")#mi("{\\hat \\pi_0}")#text(" is easily seen to be injective. If we let ")#mi("{\\Gamma_0}")#text(" denote the cokernel of this map, then ")#mi("{\\Gamma_0}")#text(" is an abelian group (which we will view as a discrete group) and we have the short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow {\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m \\rightarrow \\widehat{O(A_\\alpha)} \\rightarrow \\Gamma_0 \\rightarrow 0.")]]

#text("Observe that ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Divisible_group")[#text("divisible group")]#text(". From this and a Zorn’s lemma argument we can split this short exact sequence, lifting ")#mi("{\\Gamma_0}")#text(" up to a subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{\\widehat{O(A_\\alpha)}}")#text(", so that the latter group can be viewed as the direct sum of ")#mi("{\\Gamma}")#text(" and ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text(".")

#text("Let ")#mi("{T}")#text(" be the Pontryagin dual of ")#mi("{\\Gamma}")#text(", that is to say the space of all homomorphisms ")#mi("{t\\colon \\xi \\mapsto \\xi \\cdot t}")#text(" from ")#mi("{\\Gamma}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (with no measurability or continuity hypotheses imposed). This is a compact abelian group (it is a closed subset of ")#mi("{({\\bf R}/{\\bf Z})^\\Gamma}")#text(", which is compact by Tychonoff’s theorem). Set ")#mi("{G := {\\bf R}^d \\times {\\bf Z}^m \\times T}")#text(". We have a homomorphism ")#mi("{\\pi\\colon O( A_\\alpha ) \\rightarrow G}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\pi( x ) := ( \\pi_0(x), (\\xi \\mapsto \\xi \\cdot x) ).")]]

#text("We claim that ")#mi("{\\pi}")#text(" has dense image. Since ")#mi("{\\pi_0}")#text(" is surjective, it suffices to show that the map from ")#mi("{x}")#text(" to ")#mi("{(\\xi \\mapsto \\xi \\cdot x)}")#text(" has dense image from ")#mi("{o(A_\\alpha)}")#text(" to ")#mi("{T}")#text(", where")

#align(center)[#tao-fit-display[#mitex("o(A_\\alpha) = \\{ h + l_1 a_1 + \\dots + l_r a_r: h \\in H, l_i \\in o(L_i) \\text{ for } i=1,\\dots, d\\}")]]

#text("is the kernel of ")#mi("{\\pi_0}")#text(". The closure of the image of ")#mi("{o(A_\\alpha)}")#text(" is a compact subgroup of ")#mi("{T}")#text(", so this map did not have dense image, there would exist a non-trivial ")#mi("{\\xi}")#text(" in the Pontryagin dual ")#mi("{\\hat T = \\Gamma}")#text(" of ")#mi("{T}")#text(" which annihilates all of ")#mi("{o(A_\\alpha)}")#text(". The map ")#mi("{x \\mapsto \\xi \\cdot x}")#text(" then factors through ")#mi("{{\\bf R}^d \\times {\\bf Z}^m}")#text(" and thus can be identified with an element of ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text("; but ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text(" and ")#mi("{\\Gamma}")#text(" only intersect at ")#mi("{0}")#text(", a contradiction. Thus ")#mi("{\\pi}")#text(" has dense image.")

#text("It is a routine matter to verify that ")#mi("{\\pi}")#text(" is measurable (noting that the Baire algebra is generated by the product of measurable sets in ")#mi("{{\\bf R}^d \\times ({\\bf R}/{\\bf Z})^m}")#text(" and cylinder sets in ")#mi("{T}")#text("), that ")#mi("{\\pi(A_\\alpha)}")#text(" is precompact, and that the inverse image of any compact set is contained in ")#mi("{A_\\alpha^m}")#text(" for some standard ")#mi("{m}")#text(". From this and the Riesz representation theorem, we can define a Haar measure ")#mi("{\\mu_G}")#text(" on ")#mi("{G}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("\\int_G f(x)\\ d\\mu_G(x) := \\int_{O(A_\\alpha)} f(\\pi(x))\\ d\\mu_{O(A_\\alpha)}")]]

#text("for all continuous, compactly supported functions ")#mi("{f\\colon G \\rightarrow {\\bf C}}")#text("; the translation invariance of this measure follows from the surjectivity of ")#mi("{\\pi}")#text(". From Urysohn’s lemma and the inner and outer regularity of Haar measures, one can then show that ")#mi("{\\mu_G}")#text(" is the pushforward of Loeb measure ")#mi("{\\mu_{O(A_\\alpha)}}")#text(" under ")#mi("{\\pi_*}")#text(".")

#text("Now we show the convolution property ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(". First suppose that ")#mi("{\\pi_* f = 0}")#text(", which in particular implies that")

#align(center)[#tao-fit-display[#mitex("\\int_{O(A_\\alpha)} f(x) e^{-2\\pi i \\xi \\cdot x}\\ d\\mu_{O(A_\\alpha)}(x) = 0")]]

#text("for all ")#mi("{\\xi \\in \\widehat{O(A_\\alpha)}}")#text(", since the function ")#mi("{x \\mapsto e^{-2\\pi i \\xi \\cdot x}}")#text(" factors through ")#mi("{G}")#text(". By the Loeb measure construction, we can write ")#mi("{f}")#text(" as the limit (in ")#mi("{L^1}")#text(") of functions ")#mi("{\\text{st} f_j}")#text(", where ")#mi("{f_j\\colon A_\\alpha^m \\rightarrow {}^* {\\bf C}}")#text(" are uniformly bounded nonstandard functions and ")#mi("{m}")#text(" is some standard natural number. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\lim_{j \\rightarrow \\infty} \\sup_{\\xi \\in \\widehat{O(\\alpha)}} \\left|\\int_{O(A_\\alpha)} \\text{st} f_j(x) e^{-2\\pi i \\xi \\cdot x}\\ d\\mu_{O(A_\\alpha)}(x)\\right| = 0,", block: true)]]

#text("which in particular implies that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{j \\rightarrow \\infty} \\text{st} \\sup_{\\xi} \\frac{1}{\\left|A_\\alpha\\right|} \\left|\\sum_{x \\in A_\\alpha^m} f_j(x) e^{-2\\pi i \\xi \\cdot x}\\right| = 0", block: true)]]

#text("where ")#mi("{\\xi}")#text(" ranges over all nonstandard maps ")#mi("{\\xi\\colon A_\\alpha^m \\rightarrow {}^* {\\bf R}/{\\bf Z}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\xi( h + l_1 a_1 + \\dots + l_r a_r ) := \\xi_0(h) + l_1 \\theta_1 + \\dots + l_r \\theta_r")]]

#text("for some ")#mi("{\\theta_1,\\dots,\\theta_r \\in {}^* {\\bf R}/{\\bf Z}}")#text(" and nonstandard homomorphism ")#mi("{\\xi_0\\colon H \\rightarrow {}^* {\\bf R}/{\\bf Z}}")#text(". From (nonstandard) Fourier analysis, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{j \\rightarrow \\infty} \\text{st} \\frac{1}{\\left|A_\\alpha\\right|^3} \\sum_{x \\in A_\\alpha^{m+m^{\\prime}}} \\left|\\sum_{y \\in A_\\alpha^m} f_j(y) g(x-y)\\right|^2 = 0", block: true)]]

#text("for any bounded nonstandard function ")#mi("{g\\colon A_\\alpha^{m^{\\prime}} \\rightarrow {}^* {\\bf C}}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{j \\rightarrow \\infty} \\int_{O(A_\\alpha)} \\left|\\text{st} f_j \\star \\text{st} g(x)\\right|^2\\ d\\mu_{O(A_\\alpha)}(x) = 0", block: true)]]

#text("and thus on taking limits we see that ")#mi("{f \\star \\text{st} g = 0}")#text(", and on taking further limits we see that ")#mi("{f*g=0}")#text(" for any ")#mi("{g \\in L}")#text(", as required. This proves ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(" when ")#mi("{\\pi_* f=0}")#text("; similarly when ")#mi("{\\pi_* g = 0}")#text(". To finish off the general case of ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\pi^* f \\star \\pi^* g = \\pi^* (f \\star g)")]]

#text("for bounded measurable ")#mi("{f,g\\colon G \\rightarrow {\\bf C}}")#text(". By Fourier decomposition, we may assume that ")#mi("{f}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("f(x,t) = f_0(x) e^{2\\pi i \\xi \\cdot t}")]]

#text("for some ")#mi("{\\xi \\in \\Gamma = \\hat T}")#text(" and some continuous compactly supported ")#mi("{f_0\\colon {\\bf R}^d \\times {\\bf Z}^m \\rightarrow {\\bf C}}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("g(x,t) = g_0(x) e^{2\\pi i \\eta \\cdot t}")]]

#text("for some ")#mi("{\\eta \\in \\Gamma}")#text(" and continuous compactly supported ")#mi("{g_0\\colon {\\bf R}^d \\times {\\bf Z}^m\\rightarrow {\\bf C}}")#text(".")

#text("If ")#mi("{\\xi \\neq \\eta}")#text(", then ")#mi("{\\xi \\cdot h \\neq \\eta \\cdot h}")#text(" for some ")#mi("{h \\in T}")#text(", and one can use this to show that ")#mi("{f \\star g}")#text(" and ")#mi("{\\pi^* f \\star \\pi^* g}")#text(" both vanish. Thus we may assume that ")#mi("{\\xi = \\eta}")#text("; using modulation symmetry we may then assume that ")#mi("{\\xi=\\eta=0}")#text(". It thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\pi^*_0 f \\star \\pi^*_0 g = \\pi^*_0 (f \\star g).")]]

#text("A direct calculation shows that the left and right hand sides agree up to constants; but both sides also have integral ")#mi("{(\\int_G f\\ d\\mu_G) (\\int_G g\\ d\\mu_G)}")#text(" when integrated against ")#mi("{\\mu_{O(A_\\alpha)}}")#text(", so they must agree identically.")

#text("Now, we prove the inclusions ")#link(<tao-4ea3146203aae8dfbb97>)[#text("(1)")]#text(". The outer inclusion ")#mi("{4A_\\alpha \\subset \\pi^{-1}( K_0 )}")#text(" comes from the compactness (or precompactness) of ")#mi("{\\pi(A_\\alpha)}")#text(". For the inner inclusion, we note from ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(" and the positive measure and symmetry of ")#mi("{A_\\alpha}")#text(" that ")#mi("{1_{A_\\alpha} * 1_{A_\\alpha}}")#text(" is the pullback ")#mi("{\\pi^*}")#text(" of a continuous function on ")#mi("{G}")#text(" that is positive at the origin, and thus also bounded away from zero on a neighbourhood ")#mi("{U}")#text(" of the origin. This implies that the set ")#mi("{2A_\\alpha}")#text(" has full measure in ")#mi("{\\pi^{-1}(U)}")#text(". We then let ")#mi("{U_0}")#text(" be a smaller symmetric neighbourhood of the origin such that ")#mi("{U_0 + U_0 \\subset U}")#text(". We then see that for any ")#mi("{x \\in \\pi^{-1}(U_0)}")#text(", the sets ")#mi("{2A_\\alpha}")#text(" and ")#mi("{x - 2A_\\alpha}")#text(" both have full measure in ")#mi("{\\pi^{-1}(U_0)}")#text(", and hence ")#mi("{x}")#text(" lies in ")#mi("{4A_\\alpha}")#text(". This gives the inner inclusion ")#mi("{\\pi^{-1}(U_0) \\subset 4A_\\alpha}")#text(" of ")#link(<tao-4ea3146203aae8dfbb97>)[#text("(1)")]#text(".")

#text("Finally, we show the regularity claim ")#link(<tao-623210167553939c87ed>)[#text("(2)")]#text(". Given ")#mi("{K \\subset U \\subset G}")#text(", we may apply Urysohn’s lemma to find non-negative bounded continuous functions ")#mi("{f, g\\colon G \\rightarrow {\\bf C}}")#text(" such that ")#mi("{f \\ast g}")#text(" is supported in ")#mi("{U}")#text(" and is at least ")#mi("{1}")#text(" on ")#mi("{K}")#text(". Letting ")#mi("{\\tilde f, \\tilde g \\in L}")#text(" be the pullbacks of ")#mi("{f, g}")#text(" by ")#mi("{\\pi}")#text(", we conclude using ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(" that ")#mi("{\\tilde f \\ast \\tilde g}")#text(" is at least ")#mi("{1}")#text(" on ")#mi("{K}")#text(" and vanishes outside of ")#mi("{U}")#text(". Approximating ")#mi("{\\tilde f, \\tilde g}")#text(" in ")#mi("{L^2}")#text(" by bounded nonstandard functions ")#mi("{F, G}")#text(" supported in ")#mi("{A_\\alpha^{O(1)}}")#text(", we conclude that ")#mi("{F \\ast G}")#text(" is at least ")#mi("{2/3}")#text(" (say) on ")#mi("{K}")#text(" and less than ")#mi("{1/3}")#text(" (say) outside of ")#mi("{U}")#text(". If one then sets ")#mi("{B}")#text(" to be the non-standard set where ")#mi("{F*G > 1/2}")#text(", we obtain the claim.")

#heading(level: 1)[#strong[#text(" — 2. Sample applications of theorem — ")]]

#text("In this section we illustrate how this theorem can be used to reprove some existing results in additive combinatorics, reducing them to various statements in continuous harmonic analysis. We begin with a qualitative version of a ")#link("http://www.ams.org/mathscinet-getitem?mr=2738997")[#text("result of Croot and Sisask")]#text(" on almost periods, which reduces to the classical fact that the convolution of two square-integrable functions is continuous.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Croot-Sisask)")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group in an additive group ")#mi("{G}")#text(", let ")#mi("{B, C}")#text(" be subsets of ")#mi("{A}")#text(", and let ")#mi("{0 < \\varepsilon < 1}")#text(". Then there exists a subset ")#mi("{S}")#text(" of ")#mi("{4A}")#text(" with ")#tao-math("{\\left|S\\right| \\gg_{K,\\varepsilon} \\left|A\\right|}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_B \\star 1_C - 1_{s+B} \\star 1_C \\right\\|_{\\ell^2} \\leq \\varepsilon \\left|A\\right|^{3/2}", block: true)]]

#text("for all ")#mi("{s \\in S}")#text(" (using the non-normalised convolution ")#mi("{\\star}")#text(").")
]

#text("The Croot-Sisask argument in fact gives a quantitative lower bound of exponential type on ")#mi("{S}")#text(", but such bounds are not available through the qualitative limiting arguments given here. The Croot-Sisask argument also works in non-commutative groups ")#mi("{G}")#text("; it is likely the arguments here would also extend to that setting once one developed a non-commutative version of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", but we have not investigated that here.")

#emph[#text("Proof:")]#text(" By the usual transfer arguments, it suffices to show that when ")#mi("{A}")#text(" is an ultra approximate group, ")#mi("{B,C}")#text(" are non-standard subsets of ")#mi("{A}")#text(", and ")#mi("{0 < \\varepsilon < 1}")#text(", there exists a nonstandard subset ")#mi("{S}")#text(" of ")#mi("{4A}")#text(" with ")#tao-math("{\\left|S\\right| \\gg \\left|A\\right|}", block: false)#text(" such that ")#metadata(none) <tao-1e0bbd6c686ba050b8eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| 1_B \\star 1_C - 1_{s+B} \\star 1_C \\right\\|_{L^2(\\mu_{O(A)})} \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{s \\in S}")#text(" (using the normalised convolution ")#mi("{\\star}")#text("). But by ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(", ")#mi("{1_B \\star 1_C}")#text(" is the pullback via ")#mi("{\\pi_*}")#text(" of a continuous compactly supported function, so ")#link(<tao-1e0bbd6c686ba050b8eb>)[#text("(5)")]#text(" holds for ")#mi("{s}")#text(" in ")#mi("{\\pi^{-1}(U)}")#text(" for some neighbourhood ")#mi("{U}")#text(" of the identity, and thus by ")#link(<tao-623210167553939c87ed>)[#text("(2)")]#text(" it also holds for all ")#mi("{s}")#text(" in some nonstandard ")#mi("{S \\subset O(A)}")#text(" of positive Loeb measure. The claim follows. ")#mi("\\Box")

#text("Now we give a proof of Roth’s theorem (in the averaged form of Varnavides), at least for groups of odd order.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Roth’s theorem)")]#text(" Let ")#mi("{\\delta > 0}")#text(", let ")#mi("{G}")#text(" be a finite group of odd order, and let ")#mi("{A \\subset G}")#text(" be such that ")#tao-math("{\\left|A\\right| \\geq \\delta \\left|G\\right|}", block: false)#text(". Then there are ")#tao-math("{\\gg_\\delta \\left|G\\right|^2}", block: false)#text(" pairs ")#mi("{(a,r) \\in G^2}")#text(" such that ")#mi("{a,a+r,a+2r \\in A}")#text(".")
]

#emph[#text("Proof:")]#text(" By the usual transfer arguments, it suffices to show that when ")#mi("{G_\\alpha}")#text(" is a nonstandard finite group of odd order, and ")#mi("{A}")#text(" is a nonstandard subset of ")#mi("{G_\\alpha}")#text(" with ")#tao-math("{\\left|A\\right| \\gg \\left|G_\\alpha\\right|}", block: false)#text(", then there are ")#tao-math("{\\gg \\left|G_\\alpha\\right|^2}", block: false)#text(" pairs ")#mi("{(a,r) \\in G_\\alpha^2}")#text(" such that ")#mi("{a,a+r,a+2r \\in A}")#text("; equivalently, we need to show that ")#metadata(none) <tao-4f75bb3d593b7636558d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\langle 1_A * 1_A, 1_{2\\cdot A} \\rangle_{L^2} > 0")]]

#text("where ")#mi("{2 \\cdot A := \\{ 2a: a \\in A \\}}")#text(". As ")#mi("{A}")#text(" has positive measure, ")#mi("{\\pi_*(1_A)}")#text(" is not identically zero. By a version of the Lebesgue differentiation theorem, we can then find a point ")#mi("{x_0}")#text(" in the Kronecker factor group ")#mi("{G}")#text(" such that ")#mi("{\\pi_*(1_A)}")#text(" has positive density on every precompact neighbourhood of ")#mi("{x_0}")#text(", and is bounded away from zero on a subset of a symmetric open precompact neighbourhood ")#mi("{x_0+U}")#text(" of ")#mi("{x_0}")#text(" of density greater than ")#mi("{1/2}")#text(". From this and ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(" we see that ")#mi("{1_A * 1_A}")#text(" is bounded away from zero on almost all of ")#mi("{\\pi^{-1}(2x_0 + V)}")#text(" for some neighbourhood ")#mi("{2x_0+V}")#text(" of ")#mi("{2x_0}")#text(". Also, as ")#mi("{G_\\alpha}")#text(" has odd order, the map ")#mi("{x \\mapsto 2x}")#text(" is a measure-preserving map on ")#mi("{G_\\alpha}")#text(", it must also be so on ")#mi("{G}")#text(", and so we conclude that ")#mi("{1_{2 \\cdot A}}")#text(" has positive measure in ")#mi("{\\pi^{-1}(2x_0+V)}")#text(", and ")#link(<tao-4f75bb3d593b7636558d>)[#text("(6)")]#text(" follows. ")#mi("\\Box")

#text("Finally, we give a more advanced application of additive limits, namely reproving ")#link("http://arxiv.org/abs/1301.4579")[#text("a lemma of Eberhard, Green, and Manners")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" For every ")#mi("{\\varepsilon>0}")#text(" there is ")#mi("{\\delta>0}")#text(" such that if ")#mi("{A \\subset \\{1,\\dots,N\\}}")#text(" is such that ")#tao-math("{\\left| \\{ 1_A \\star 1_A \\geq \\delta N\\} \\right| \\leq 4\\left|A\\right| - \\varepsilon N}", block: false)#text(", then there is an arithmetic progression ")#mi("{P \\subset \\{1,\\dots,N\\}}")#text(" such that ")#tao-math("{\\left|P\\right| \\gg_\\varepsilon N}", block: false)#text(" and ")#tao-math("{\\left|A \\cap P\\right| \\geq (\\frac{1}{2} + \\frac{\\varepsilon}{5})\\left|P\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Here, we perform the transfer step more explicitly, as it is slightly trickier here. Suppose for contradiction that the claim failed, then there exists an ")#mi("{\\varepsilon>0}")#text(" and a sequence ")#mi("{A_n \\subset \\{1,\\dots,N_n\\}}")#text(" with ")#metadata(none) <tao-48b676e2b107da679512>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left| \\{ 1_{A_n} \\star 1_{A_n} \\geq \\frac{1}{n} N_n\\} \\right| \\leq 4\\left|A_n\\right| - \\varepsilon N_n", block: true)]]

#text("but such that there is no arithmetic progression ")#mi("{P \\subset \\{1,\\dots,N_n\\}}")#text(" with ")#tao-math("{\\left|P\\right| \\geq N_n/n}", block: false)#text(" such that ")#tao-math("{\\left|A_n \\cap P\\right| \\geq (\\frac{1}{2} - \\frac{\\varepsilon}{5}) \\left|P\\right|}", block: false)#text(". Note that ")#mi("{N_n}")#text(" must go to infinity (otherwise one could take ")#mi("{P}")#text(" to consist of a single element of ")#mi("{A_n}")#text(", which must be non-empty from ")#link(<tao-48b676e2b107da679512>)[#text("(7)")]#text(". Taking ultraproducts, we arrive at a nonstandard subset ")#mi("{A}")#text(" of ")#mi("{\\{1,\\dots,N\\}}")#text(" for some unbounded natural number ")#mi("{N}")#text(", such that ")#metadata(none) <tao-079cdc52e64462dfac51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\mu_{O(N)}(\\{ 1_A \\star 1_A > 0 \\} ) \\leq 4 \\mu_{O(N)}(A) - \\varepsilon")]]

#text("and such that there is no nonstandard arithmetic progression ")#mi("{P \\subset \\{1,\\dots,N\\}}")#text(" with ")#mi("{\\mu_{O(N)}(P) > 0}")#text(" and ")#mi("{\\mu_{O(N)}( A \\cap P ) \\geq (\\frac{1}{2} + 0.21 \\varepsilon) \\mu_{O(N)}(P)}")#text(" (say). Here ")#mi("{\\mu_{O(N)}}")#text(" is the Loeb measure associated with the approximate group ")#mi("{\\{-N/2,\\dots,N/2\\}}")#text(" and the group ")#mi("{O(N) := \\{ n \\in {}^* {\\bf N}: n = O(N) \\}}")#text(" that it generates. By inspection of the proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", the Kronecker factor of this group can be taken to be ")#mi("{G = {\\bf R} \\times T}")#text(" for some compact group ")#mi("{T}")#text(", with projection ")#mi("{\\pi\\colon O(N) \\rightarrow {\\bf R} \\times T}")#text(" given by ")#mi("{\\pi(n) := (\\text{st} \\frac{n}{N}, \\pi_T(n))}")#text(" for some measurable map ")#mi("{\\pi_T\\colon O(N) \\rightarrow T}")#text(", and Haar measure ")#mi("{\\mu_G}")#text(" given by the product of Lebesgue measure on ")#mi("{{\\bf R}}")#text(" and the Haar probability measure ")#mi("{\\mu_T}")#text(" on ")#mi("{T}")#text(". If we let ")#mi("{f := \\pi_* 1_A}")#text(", then ")#mi("{f}")#text(" is supported in ")#mi("{[0,2] \\times T}")#text(" and takes values in ")#mi("{[0,1]}")#text(", and from ")#link(<tao-3f22f007dace5d04260f>)[#text("(3)")]#text(" and ")#link(<tao-079cdc52e64462dfac51>)[#text("(8)")]#text(" we see that the set")

#align(center)[#tao-fit-display[#mitex("E := \\{ (x,t) \\in {\\bf R} \\times T: f \\star f(x,t) > 0 \\}")]]

#text("is such that")

#align(center)[#tao-fit-display[#mitex("\\mu_G(E) \\leq 4 \\int_G f\\ d\\mu_G - \\varepsilon.")]]

#text("We can view ")#mi("{f}")#text(" as a measurable function ")#mi("{\\tilde f\\colon {\\bf R} \\rightarrow L^1(T)}")#text(", defined by ")#mi("{\\tilde f(x)(t) := f(x,t)}")#text(", and similarly the indicator function ")#mi("{1_E}")#text(" can be viewed as a measurable function ")#mi("{\\tilde 1_E\\colon {\\bf R} \\rightarrow L^1(T)}")#text(" defined by ")#mi("{\\tilde 1_E(x)(t) := 1_E(x,t)}")#text(". Being measurable, ")#mi("{\\tilde f}")#text(" may be approximated in ")#mi("{L^1}")#text(" by piecewise constant functions. One can then adapt the proof of the Lebesgue differentiation theorem to show that almost all ")#mi("{x \\in {\\bf R}}")#text(" are a Lebesgue point of ")#mi("{\\tilde f}")#text(", in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{r \\rightarrow 0} \\frac{1}{2r} \\int_{x-r}^{x+r} \\left\\| \\tilde f(y)-\\tilde f(x) \\right\\|_{L^1(T)}\\ dy = 0.", block: true)]]

#text("Similarly, almost all ")#mi("{x \\in {\\bf R}}")#text(" is a Lebesgue point of ")#mi("{\\tilde 1_E}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\lim_{r \\rightarrow 0} \\frac{1}{2r} \\int_{x-r}^{x+r} |\\tilde 1_E(y)-\\tilde 1_E(x)|\\ dy = 0.")]]

#text("From this, we see that for almost all ")#mi("{x \\in {\\bf R}}")#text(", we have the inclusion ")#metadata(none) <tao-fa9383a4bc9106e8f9d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\{ t \\in T: (\\tilde f(x) \\star \\tilde f(x))(t) > 0 \\} \\subset \\{ t \\in T: \\tilde 1_E(2x)(t) > 0 \\}")]]

#text("up to null sets in ")#mi("{T}")#text(", where the convolution is now with respect to the Haar probability measure ")#mi("{\\mu_T}")#text(". On the other hand, from Fubini’s theorem we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (\\int_T \\tilde f(x)\\ d\\mu_T)\\ dx = \\int_G f\\ d\\mu_G")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (\\int_T \\tilde 1_E(2x)\\ d\\mu_T)\\ dx = \\mu_G(E)/2 \\leq 2 \\int_G f\\ d\\mu_G - \\varepsilon/2.")]]

#text("Also ")#mi("{\\int_T \\tilde f(x)\\ d\\mu_T}")#text(" is supported on ")#mi("{[0,2]}")#text(". Thus by the pigeonhole principle, we may find an ")#mi("{x_* \\in (0,2)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_T \\tilde 1_E(2x_*)\\ d\\mu_T \\leq 2 \\int_T \\tilde f(x_*)\\ d\\mu_T - \\varepsilon/2")]]

#text("and such that ")#link(<tao-fa9383a4bc9106e8f9d9>)[#text("(9)")]#text(" holds up to null sets, and such that ")#mi("{x_*}")#text(" is a Lebesgue point for ")#mi("{\\tilde f}")#text(". If we fix this ")#mi("{x_*}")#text(" and now set ")#mi("{F := \\tilde f(x)}")#text(" and ")#mi("{B := \\{ t \\in T: F*F(t) > 0\\}}")#text(", we thus have ")#metadata(none) <tao-ecdd97405c79b408ee77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\mu_T( B ) \\leq 2 \\int_T F\\ d\\mu_T - \\varepsilon/2.")]]

#text("At this point it is convenient to split the compact abelian group ")#mi("{T}")#text(" as")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow T_0 \\rightarrow T \\rightarrow T/T_0 \\rightarrow 0")]]

#text("where ")#mi("{T_0}")#text(" is the connected component of the identity, thus ")#mi("{T/T_0}")#text(" is a totally disconnected group. Let ")#mi("{\\tilde F}")#text(" be the pushforward of ")#mi("{F}")#text(" to ")#mi("{T/T_0}")#text(" via the projection map ")#mi("{\\pi_0\\colon T \\rightarrow T/T_0}")#text(", thus ")#mi("{\\tilde F\\colon T/T_0 \\rightarrow [0,1]}")#text(" is a measurable function of total integral ")#mi("{\\int_T F\\ d\\mu_T}")#text(". We claim that ")#metadata(none) <tao-92aaf17d67568d5f7880>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|\\tilde F \\right\\|_{L^\\infty(T/T_0)} > \\frac{1}{2} + 0.24 \\varepsilon.", block: true)]]

#text("To see this, suppose for contradiction that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\tilde F \\right\\|_{L^\\infty(T/T_0)} \\leq \\frac{1}{2} + 0.24 \\varepsilon.", block: true)]]

#text("We may disintegrate")

#align(center)[#tao-fit-display[#mitex("F = \\int_{T/T_0} \\nu_y\\ d\\mu_{T/T_0}(y)")]]

#text("where ")#mi("{y \\mapsto \\nu_y}")#text(" is a measurable map from ")#mi("{T/T_0}")#text(" to finite measures on ")#mi("{T}")#text(", such that for almost every ")#mi("{y}")#text(", ")#mi("{\\nu_y}")#text(" is supported on ")#mi("{\\pi_0^{-1}(y)}")#text(" and has total mass ")#mi("{\\tilde F(y)}")#text(". For almost every ")#mi("{y_0}")#text(" and ")#mi("{y}")#text(", we then have that")

#align(center)[#tao-fit-display[#mitex("\\nu_y * \\nu_{y_0}")]]

#text("is supported in ")#mi("{B}")#text(". By Fubini’s theorem we have")

#align(center)[#tao-fit-display[#mitex("\\int_{T/T_0} \\mu_{\\pi_0^{-1}(y)}( B )\\ d\\mu_{T/T_0}(y) = \\mu_T(B)")]]

#text("where ")#mi("{\\mu_{\\pi_0^{-1}(y)}}")#text(" is the Haar probability measure on ")#mi("{\\pi_0^{-1}(y)}")#text(". From ")#link(<tao-ecdd97405c79b408ee77>)[#text("(10)")]#text(", we conclude that for almost every ")#mi("{y_0}")#text(", there is a positive measure set of ")#mi("{y}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\pi_0^{-1}(y)}( B ) \\leq 2 \\tilde F( y - y_0 ) - \\varepsilon/2 < 1")]]

#text("for a positive measure set of ")#mi("{y}")#text(" (in particular ")#mi("{\\tilde F(y-y_0)>0}")#text("), and that ")#mi("{\\nu_{y-y_0} * \\nu_{y_0}}")#text(" is supported in ")#mi("{B}")#text(". On the other hand, ")#mi("{\\nu_{y-y_0}}")#text(" and ")#mi("{\\nu_{y_0}}")#text(" are supported on sets of measure at least ")#mi("{\\tilde F(y-y_0)}")#text(" and ")#mi("{F(y_0)}")#text(". Applying Kemperman’s theorem (see ")#link("https://terrytao.wordpress.com/2011/12/26/a-variant-of-kempermans-theorem/")[#text("this previous post")]#text(") , we conclude that")

#align(center)[#tao-fit-display[#mitex("\\tilde F(y-y_0) + \\tilde F(y_0) \\leq 2 \\tilde F( y - y_0 ) - \\varepsilon/2")]]

#text("for almost every ")#mi("{y_0}")#text(" with ")#mi("{\\tilde F(y_0)>0}")#text(", and for a positive measure set of ")#mi("{y}")#text(". But this leads to a contradiction if we take ")#mi("{\\tilde F(y_0)}")#text(" to be within ")#mi("{\\varepsilon/2}")#text(" of the essential supremum of ")#mi("{\\tilde F}")#text(". This proves ")#link(<tao-92aaf17d67568d5f7880>)[#text("(11)")]#text(".")

#text("As ")#mi("{T/T_0}")#text(" is totally disconnected, we can express the origin as the intersection of open subgroups. From this, ")#link(<tao-92aaf17d67568d5f7880>)[#text("(11)")]#text(", and a Lebesgue differentiation argument, we may find a coset ")#mi("{y_0+K_0}")#text(" of an open subgroup ")#mi("{K_0}")#text(" of ")#mi("{T/T_0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{y_0+K_0} \\tilde F\\ d\\mu_{T/T_0} > (\\frac{1}{2} + 0.24 \\varepsilon) \\mu_{T/T_0}(y_0+K_0).")]]

#text("Letting ")#mi("{t_0+K}")#text(" be a pullback of ")#mi("{y_0+K_0}")#text(" to ")#mi("{T}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{t_0+K} F\\ d\\mu_T > (\\frac{1}{2} + 0.24 \\varepsilon) \\mu_{T}(t_0+K).")]]

#text("Since ")#mi("{x_*}")#text(" is a Lebesgue point for ")#mi("{\\tilde f}")#text(", we may thus find a neighbourhood ")#mi("{I}")#text(" of ")#mi("{x_*}")#text(" in ")#mi("{{\\bf R}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{I \\times (t_0+K)} f\\ d\\mu_{{\\bf R} \\times T} > (\\frac{1}{2} + 0.24 \\varepsilon) \\mu_{{\\bf R} \\times T}( I \\times (t_0+K) )")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\mu_{O(N)}( A \\cap \\pi^{-1}(I \\times (t_0+K)) ) > (\\frac{1}{2} + 0.24 \\varepsilon) \\mu_{O(N)}( \\pi^{-1}(I \\times (t_0+K)) ).")]]

#text("To finish the proof of the claim, it then suffices to show that ")#mi("{\\pi^{-1}(I \\times (t_0+K))}")#text(" differs from a nonstandard arithmetic progression by a set of arbitrarily small Loeb measure.")

#text("Consider the quotient homomorphism ")#mi("{\\phi\\colon O(N) \\rightarrow T/K}")#text(" formed by first using ")#mi("{\\pi}")#text(" to project ")#mi("{O(N)}")#text(" to ")#mi("{{\\bf R} \\times T}")#text(", then projecting to ")#mi("{T}")#text(", then to ")#mi("{T/K}")#text(". This is a Loeb measurable map, and thus the pointwise limit (up to null sets) by a nonstandard function. But observe that for ")#mi("{x \\in O(N)}")#text(", one has ")#mi("{\\phi(x) = a}")#text(" if and only if ")#mi("{\\phi(x+y) = \\phi(y) + a}")#text(" for almost every ")#mi("{y \\in \\{1,\\dots,N\\}}")#text(". In particuar, if ")#mi("{\\phi^{\\prime}}")#text(" is a nonstandard function which is sufficiently close to ")#mi("{\\phi}")#text(", then ")#mi("{\\phi(x)=a}")#text(" if and only if ")#mi("{a}")#text(" is the most common value of ")#mi("{\\phi^{\\prime}(x+y)-\\phi^{\\prime}(y)}")#text(" for ")#mi("{y \\in \\{1,\\dots,N\\}}")#text(". Using this, one can find a representative of ")#mi("{\\phi}")#text(" that is precisely a nonstandard function on ")#mi("{\\{-100N,\\dots,100N\\}}")#text(" (say). Thus ")#mi("{\\phi}")#text(" is now a nonstandard map from ")#mi("{\\{-100N,\\dots,100N\\}}")#text(" to the standard finite group ")#mi("{G/K}")#text(", and from construction one can check that ")#mi("{\\phi(x+y)=\\phi(x)+\\phi(y)}")#text(" for all (and not merely almost all) ")#mi("{x,y \\in \\{-10N, \\dots,10N\\}}")#text(". From this it is easy to see that ")#mi("{\\phi}")#text(" is periodic with some bounded period, and that the level sets of ")#mi("{\\phi}")#text(" are infinite nonstandard arithmetic progressions of bounded spacing. The claim then follows. ")#mi("\\Box")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-429582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("A few comments:")

#text("* “What “converges” means in this context means that” –> “What “converges” means in this context is that”")#linebreak()#text(" * Use “")#mi("\\lvert")#text("” and “")#mi("\\rvert")#text("”, reps., for absolut values instead of “")#mi("|")#text("” to get correct horixontal spacing")#linebreak()#text(" * Should there be four integrals instead of three in the sixth displayed expression?")#linebreak()#text(" * Use “")#mi("\\colon")#text("” instead of “")#mi(":")#text("” to get correct horixontal spacing")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-429584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("The last comment should be as follows:")

#text("* Use “")#mi("\\colon")#text("” instead of “")#mi(":")#text("” for maps to get correct horizontal spacing")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36e92e70551710e6fe034fefcda6b827d99fedccf7b4aa60558a6d25e8c12989-c22c31df9b007cfc5c4f1dda0f10332810bff56e6e541c7f0ebaf4944c2ea97a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-429703")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#link("http://arxiv.org/pdf/0712.2749.pdf")[#text("Click to access 0712.2749.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87017ccbea7ab4b80045accc7a4a3b443ac426d0f44137bb914144f2bc2ea585-97d3cd39f6e46e764e09c8f254258b929ab96f29f11738bb870028497d933f21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francisco Javier Thayer")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-429808")[#strong[#text("Francisco Javier Thayer")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("Consider a hyperfinite graph G for which some rescaling of the graph distance of G has the property that its infinitesimal collapse is locally compact. (infinitesimal collapse means the space obtained identifying elements infinitely close to each other — which yields always a complete metric space in which of course distances between points may be infinite). Such a rescaling may not exist, but it does for instance if the graph has polynomial growth for some rescaling. The infinitesimal collapse in this case is a length space and has a natural measure obtained by push-down of Loeb measure. Does this collapse have any relation to the graph-limit construction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-429825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("The two limits are analogous, but correspond to different scaling regimes. For the usual graph limits, one works with dense graphs, in which there are ")#mi("n")#text(" vertices for some large ")#mi("n")#text(", and the number of edges is comparable to ")#mi("n^2")#text("; in particular, the typical graph distance between two vertices is of the order of ")#mi("O(1)")#text(" (in fact, unless the graph is pretty much k-partite for some bounded k, the graph distance between most pairs of vertices will be 1 or 2). For the asymptotic cone construction, one works with Cayley graphs in which the number of edges is instead comparable to ")#mi("n")#text(", and the graph distance between two vertices would be polynomial in ")#mi("n")#text(" (if one is in the polynomial growth case). One then normalises the graph distance to be ")#mi("O(1)")#text(" and takes a limit.")

#text("For bounded degree graphs, there is another notion of graph limit, based on what happens with local neighbourhoods of randomly chosen vertices at graph distance O(1). For Cayley graphs of finitely generated groups, this comes down to taking pointwise limits of the set of relations between generators, for instance ")#mi("{\\bf Z}/N{\\bf Z}")#text(" with generators ")#mi("\\pm 1")#text(" converges in this sense to ")#mi("{\\bf Z}")#text(" with the generators ")#mi("\\pm 1")#text(". This would also correspond to the asymptotic cone construction if one did not rescale the metric beforehand.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea22ab3f8f9e9b71f0a20804321bb9948877bbfb308f66aa6cdbcf48eae70242-217751008671f913a93737c8a0a592ee8ace94c6ad821be55577eca9586f68ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Eagle")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-430002")[#strong[#text("Chris Eagle")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2014")])]

#text("“The set ${E_\\alpha}$ can then be viewed as a symmetric subset of ${E_\\alpha \\times E_\\alpha}$”: surely ${E_\\alpha}$ is a subset of $V_\\alpha \\times V_\\alpha}$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e1dd4c70f3f91ffff65faf4a5c12d9a98e665178bbc68d448592e076078157-bfef78253dd440411fa3afaf419c4a0956d32191309af0ef78ad68e407e0d80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-431879")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2014")])]

#text("Dear Terry,")

#text("This is a nice way of looking at these things. Has such a soft proof of Roth’s theorem (reduction to Lebesgue differentiation theorem) appeared before? I’ve always wanted to see such a proof.")

#text("In the proof of prop 4, by restricting to the symmetric case ")#mi("A+A")#text(" you get away with just the trivial case of Brunn-Minkowski ")#mi("\\mu(A+A)\\geq\\mu(2\\cdot A)= 4\\mu(A)")#text(" in ")#mi("\\mathbf{R}^2")#text(", but if you wanted a similar result for ")#mi("A+B")#text(" or even ")#mi("A-A")#text(" I guess you would actually need to say “Brunn-Minkowski” at some point. In general I tend to think of prop 4 as an incarnation of Brunn-Minkowski. (By the way, in the statement of prop 4 I think you want ")#mi("+\\epsilon/5")#text(", not ")#mi("-\\epsilon/5")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-433233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("Thanks for the correction!")

#text("Regarding Roth’s theorem, certainly the ergodic theory approach to Roth’s theorem can be routed through the Lebesgue differentiation theorem after reducing to the Kronecker factor there, which is also a compact group, and computing the second Host-Kra measure mu^{[2]} on that group. And in the graph theory approach there is an analogous proof (I think in Lovasz’s book, though I don’t have it handy right now) of Roth’s theorem via Lebesgue differentiation on the unit interval [0,1].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e1dd4c70f3f91ffff65faf4a5c12d9a98e665178bbc68d448592e076078157-bfef78253dd440411fa3afaf419c4a0956d32191309af0ef78ad68e407e0d80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-433642")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")])]

#text("Thanks for the references.")

#text("By the way, is it really true in Theorem 1 that ")#mi("\\pi")#text(" is always surjective? In other words, in the proof, is it really true that the image of ")#mi("o(A_\\alpha)")#text(" is a compact subgroup of ")#mi("T")#text("? I do agree that the image of ")#mi("\\pi")#text(" is always dense, and this seems to be enough for you (i.e., this still implies that the push-forward measure is translation-invariant). If ")#mi("T")#text(" happens to be metrizable then ")#mi("\\pi")#text(" is surjective by countable saturation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-433655")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2014")])]

#text("Oh, thanks for pointing out that subtlety! I am so used to dealing with metrisable situations that I forgot that on non-metrisable spaces countable saturation is sometimes insufficient to guarantee closed images. But as you say, dense image is sufficient for the current application.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e1dd4c70f3f91ffff65faf4a5c12d9a98e665178bbc68d448592e076078157-bfef78253dd440411fa3afaf419c4a0956d32191309af0ef78ad68e407e0d80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-450480")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2015")])]

#text("Correct me if I’m wrong but in fact I think ")#mi("\\pi")#text(" is *injective*. If we consider just the ultrafinite genuine group case for the moment, then there are lots of measurable characters on the ultraproduct coming from the ultraproduct of the dual groups: enough to separate points, by finite Fourier analysis. This implies that ")#mi("\\pi")#text(" is injective.")

#text("Somewhat related to this, I’m not sure I believe that ")#mi("\\pi")#text(" is (Loeb, Borel)-measurable. Though indeed the inverse images of the cylinder sets are measurable, unfortunately these do not generate the Borel sigma-algebra. I don’t have an example to prove this point though, so maybe I’ve just overlooked something. However I do beleive that ")#mi("\\pi")#text(" is (Loeb,Baire)-measurable, since by Stone-Weierstrass every continuous function on ")#mi("T")#text(" is the ")#mi("L^1")#text(" limit of a sequence of character sums.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-450481")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2015")])]

#text("Yes, you’re right; I had forgotten about the distinctions between Baire and Borel in the inseparable case; I’ve updated the post to correct this. Regarding injectivity, I think you are right for the “universal” group T constructed in the blog post, but in practice one usually quotients down to a more manageable T (in particular, to a separable T, in order to avoid all these technical issues coming from inseparability), at which point injectivity is lost (but surjectivity is gained!). (But conclusion (iv) of the theorem need not hold for ")#emph[#text("all")]#text(" functions f,g after such a quotienting; one can only save this conclusion for a separable space of functions, though this is usually plenty for applications.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-431968")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2014")])]

#text("I think that the following paper on mine (more recent than the one that you cite) is more relevant to this post:")

#link("http://arxiv.org/abs/1203.2260")[#text("http://arxiv.org/abs/1203.2260")]

#text("In this paper I give a generalisation of the graph limit setting to the additive setting. I discuss how to take limits of subsets (or more generally functions) in compact abelian groups. Quite surprisingly the limit objects are defined on nil manifolds that are non-commutative structures.")

#text("Another very recent paper (joint with Lovasz) is about the non commutative setting:")

#link("http://arxiv.org/abs/1406.4958")[#text("http://arxiv.org/abs/1406.4958")]

#text("Balazs")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b6abe6e330f945806803a4b897171d8295578e39967d8b5fdd04e9b7d42672-b6ab20e545b6a2a88585cc511b9f95d74808fa77e014eb9dc2df2f635a1d9259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Group limits – Random Permutations")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-505188")[#strong[#text("Group limits – Random Permutations")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("[…] few months ago on his blog Terry Tao explained how one could, by analogy with the theory of graph limits, replace the explicit […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b6abe6e330f945806803a4b897171d8295578e39967d8b5fdd04e9b7d42672-b6ab20e545b6a2a88585cc511b9f95d74808fa77e014eb9dc2df2f635a1d9259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Kronecker factor of an ultrafinite group – Random Permutations")]], [#link("https://terrytao.wordpress.com/2014/10/12/additive-limits/#comment-536616")[#strong[#text("The Kronecker factor of an ultrafinite group – Random Permutations")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2020")])]

#text("[…] few months ago on his blog Terry Tao explained how one could, by analogy with the theory of graph limits, replace the explicit […]")
]
