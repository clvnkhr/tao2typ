// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/07/12/mini-polymath4-begins-in-three-hours/
// Converted to Typst by tao2typ: "2026-10-14T15:18:26.763603+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath4 begins in three hours", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath4 begins in three hours")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 July 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-begins-in-three-hours/")[#text("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-begins-in-three-hours/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a reminder that the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2012")[#text("mini-polymath4 project")]#text(" will begin in three hours at ")#link("http://www.timeanddate.com/worldclock/fixedtime.html?iso=20120712T22")[#text("Thu July 12 2012 UTC 22:00")]#text(".")
