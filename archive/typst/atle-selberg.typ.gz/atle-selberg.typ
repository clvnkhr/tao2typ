// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/12/atle-selberg/
// Converted to Typst by tao2typ: "2026-10-14T06:52:42.676216+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Atle Selberg", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Atle Selberg")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/")[#text("https://terrytao.wordpress.com/2007/08/12/atle-selberg/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://en.wikipedia.org/wiki/Atle_Selberg")[#text("Atle Selberg")]#text(", who made immense and fundamental contributions to analytic number theory and related areas of mathematics, ")#link("http://ias.edu/newsroom/announcements/view/1186683853.html")[#text("died last Monday")]#text(", aged 90.")

#text("Selberg’s early work was focused on the study of the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("\\zeta(s)")#text(". In 1942, ")#link("http://www.ams.org/mathscinet-getitem?mr=10712")[#text("Selberg showed")]#text(" that a positive fraction of the zeroes of this function lie on the critical line ")#mi("\\text{Re}(s)=1/2")#text(". Apart from improvements in the fraction (the best value currently being a little over 40%, a result ")#link("http://www.ams.org/mathscinet-getitem?mr=1004130")[#text("of Conrey")]#text("), this is still one of the strongest partial results we have towards the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(". (I discuss Selberg’s result, and the method of mollifiers he introduced there, in a little more detail after the jump.)")

#text("In working on the zeta function, Selberg developed two powerful tools which are still used routinely in analytic number theory today. The first is the method of ")#link("http://en.wikipedia.org/wiki/Mollifier")[#text("mollifiers")]#text(" to smooth out the magnitude oscillations of the zeta function, making the (more interesting) phase oscillation more visible. The second was the method of the ")#link("http://www.ams.org/mathscinet-getitem?mr=44563")[#text("Selberg ")#mi("\\Lambda^2")#text(" sieve")]#text(", which is a particularly elegant choice of sieve which allows one to count patterns in almost primes (and hence to upper bound patterns in primes) quite accurately. Variants of the Selberg sieve were a crucial ingredient in, for instance, the recent ")#link("http://front.math.ucdavis.edu/math.NT/0508185")[#text("work of Goldston-Yıldırım-Pintz")]#text(" on prime gaps, as well as the ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("work of Ben Green and myself")]#text(" on arithmetic progressions in primes. (I discuss the Selberg sieve, as well as the Selberg symmetry formula below, in ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("my post on the parity problem")]#text(". Incidentally, Selberg was the first to formalise this problem as a significant obstruction in sieve theory.)")

#text("For all of these achievements, Selberg was awarded the Fields Medal in 1950. Around that time, Selberg and ")#link("http://en.wikipedia.org/wiki/Paul_Erd%C5%91s")[#text("Erdős")]#text(" also produced the first ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem#Elementary_proofs")[#text("elementary proof of the prime number theorem")]#text(". A key ingredient here was the ")#link("http://mathworld.wolfram.com/SelbergsFormula.html")[#text("Selberg symmetry formula")]#text(", which is an elementary analogue of the prime number theorem for ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost primes")]#text(".")

#text("But perhaps Selberg’s greatest contribution to mathematics was his discovery of the ")#link("http://en.wikipedia.org/wiki/Selberg_trace_formula")[#text("Selberg trace formula")]#text(", which is a non-abelian generalisation of the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(", and which led to many further deep connections between representation theory and number theory, and in particular being one of the main inspirations for the ")#link("http://en.wikipedia.org/wiki/Langlands_program")[#text("Langlands program")]#text(", which in turn has had an impact on many different parts of mathematics (for instance, it plays a role in ")#link("http://en.wikipedia.org/wiki/Andrew_Wiles#Solution_of_Fermat.27s_Last_Theorem")[#text("Wiles’ proof")]#text(" of ")#link("http://en.wikipedia.org/wiki/Fermat's_last_theorem")[#text("Fermat’s last theorem")]#text("). For an introduction to the trace formula, its history, and its impact, I recommend the ")#link("http://www.claymath.org/cw/arthur/pdf/HistoryTraceFormula.pdf")[#text("survey article of Arthur")]#text(".")

#text("Other major contributions of Selberg include the ")#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/sporadic.stanford.edu/bump/rallis.ps")[#text("Rankin-Selberg theory")]#text(" connecting ")#link("http://en.wikipedia.org/wiki/Artin_L-function")[#text("Artin L-functions")]#text(" from representation theory to the integrals of ")#link("http://en.wikipedia.org/wiki/Automorphic_form")[#text("automorphic forms")]#text(" (very much in the spirit of the ")#link("http://en.wikipedia.org/wiki/Langlands_program")[#text("Langlands program")]#text("), and the ")#link("http://en.wikipedia.org/wiki/Chowla-Selberg_formula")[#text("Chowla-Selberg formula")]#text(" relating the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(" at rational values to the ")#link("http://en.wikipedia.org/wiki/Period_%28number%29")[#text("periods")]#text(" of ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curves")]#text(" with ")#link("http://en.wikipedia.org/wiki/Complex_multiplication")[#text("complex multiplication")]#text(". He also made an ")#link("http://www.ams.org/notices/199511/sarnak.pdf")[#text("influential conjecture")]#text(" on the spectral gap of the ")#link("http://en.wikipedia.org/wiki/Laplace-Beltrami_operatorhttp://en.wikipedia.org/wiki/Laplace-Beltrami_operator")[#text("Laplacian")]#text(" on quotients of ")#mi("SL(2,{\\Bbb R})")#text(" by ")#link("http://en.wikipedia.org/wiki/Congruence_subgroup")[#text("congruence groups")]#text(", which is still open today (Selberg had the first non-trivial partial result). As an example of this conjecture’s impact, Selberg’s eigenvalue conjecture has inspired some recent work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("Sarnak-Xue")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("Gamburd")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2227746")[#text("Bourgain-Gamburd")]#text(" on new constructions of ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander graphs")]#text(", and has revealed some further connections between number theory and arithmetic combinatorics (such as sum-product theorems); see ")#link("http://www.ams.org/mathscinet-getitem?mr=2246331")[#text("this announcement of Bourgain-Gamburd-Sarnak")]#text(" for the most recent developments (this work, incidentally, also employs the Selberg sieve). As observed ")#link("http://www.ams.org/mathscinet-getitem?mr=211955")[#text("by Satake")]#text(", Selberg’s eigenvalue conjecture and the more classical ")#link("http://en.wikipedia.org/wiki/Ramanujan-Petersson_conjecture")[#text("Ramanujan-Petersson conjecture")]#text(" can be unified into a single conjecture, now known as the")#emph[#text(" Ramanujan-Selberg conjecture")]#text("; the eigenvalue conjecture is then essentially an archimedean (or “")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("non-dyadic")]#text("“) special case of the general Ramanujan-Selberg conjecture. (The original (dyadic) Ramanujan-Petersson conjecture was finally proved ")#link("http://www.ams.org/mathscinet-getitem?mr=379379")[#text("by Deligne-Serre")]#text(", after many important contributions by other authors, but the non-dyadic version remains open.)")

#align(center)[#metadata(none) <tao-d5b24398f7a68d0b677f>]

#heading(level: 1)[#text("— Selberg’s critical line theorem —")]

#text("I am not qualified to present all of Selberg’s work, but I can discuss one of his earlier results in a bit more detail, namely his critical line theorem establishing that a positive proportion of the zeroes of the zeta function lie on the critical line.")

#text("In Riemann’s famous 1859 memoir on the zeta function, he asserted that the number N(T) of zeroes of the zeta function in the rectangle ")#mi("\\{ \\sigma+it: 0 \\leq \\sigma \\leq 1; 0 \\leq t \\leq T \\}")#text(" was ")#mi("\\frac{T}{2\\pi} \\log \\frac{T}{2\\pi e} + O(\\log T)")#text(" as T went to infinity. The argument was made fully rigorous by von Mangoldt in 1895. The basic idea is to use the ")#link("http://en.wikipedia.org/wiki/Argument_principle")[#text("argument principle")]#text(", reducing matters to understanding the integral of the logarithmic derivative ")#mi("\\zeta^{\\prime}(s)/\\zeta(s)")#text(" of the zeta function on the boundary of the rectangle. The horizontal sides of this rectangle can be shown to give a negligible contribution (after averaging a bit in T), and the left vertical side can be related to the right one by the ")#link("http://en.wikipedia.org/wiki/Functional_equation")[#text("functional equation")]#text(" for the zeta function, so the main task is to control the integral on the right-hand side; but this can be shown to be manageable by fairly crude estimates on the zeta function to the right of the critical strip.")

#text("The Riemann hypothesis of course asserts that all N(T) of these zeroes lie on the critical line ")#mi("s=1/2")#text(", so in particular the number of zeroes on the interval ")#mi("\\{ 1/2+it: 0 \\leq t \\leq T \\}")#text(" should be asymptotically ")#mi("\\frac{1}{2\\pi} T \\log T")#text(". Selberg showed unconditionally that there are at least ")#mi("c T \\log T")#text(" such zeroes for some absolute constant ")#mi("c > 0")#text(". (An earlier result of Hardy and Littlewood in 1921 gave the weaker bound of ")#mi("cT")#text(".) To show this, Selberg first replaced the zeta function by the closely related ")#link("http://en.wikipedia.org/wiki/Xi_function")[#text("xi function")]#text(" ")#mi("\\xi(t)")#text(", which is real-valued and has a zero whenever ")#mi("1/2+it")#text(" is a zero of the zeta function.")

#text("To get a lower bound on the number of zeroes on the critical line, it thus suffices to get a lower bound on the number of times ")#mi("\\xi(t)")#text(" changes sign. One way to do this is to show that there are many intervals ")#mi("[t, t+h]")#text(" in which ")#mi("\\int_t^{t+h} \\xi(t^{\\prime})\\ dt^{\\prime}")#text(" is smaller in magnitude than ")#mi("\\int_t^{t+h} |\\xi(t^{\\prime})|\\ dt^{\\prime}")#text(", since this forces a sign change in ")#mi("\\xi")#text(" within ")#mi("[t,t+h]")#text(". This is basically the Hardy-Littlewood approach that gives the lower bound of ")#mi("cT")#text(", but it does not get as far as ")#mi("c T \\log T")#text(", mainly because of occasional spikes in the magnitude of the xi-function. However, Selberg had the idea of mollifying the xi-function by a non-negative weight (basically ")#tao-math("\\left|\\phi(1/2 + it)\\right|^2", block: false)#text(", where ")#mi("\\phi")#text(" is a smooth truncation of the Dirichlet expansion of ")#mi("\\zeta(s)^{-1/2}")#text("). Intuitively, this weight attempts to eliminates the spikes in the magnitude of the xi-function, leaving only the oscillations which are directly related to the sign changes. With this additional trick, the above approach is now strong enough to give Selberg’s critical line theorem, and the use of mollifiers (or similar devices, such as “zero-detecting polynomials”) is now standard in all subsequent work on controlling the distribution of zeroes in the critical strip.")

#text("[")#emph[#text("Via ")#link("http://in-theory.blogspot.com/2007/08/atle-selberg.html")[#text("Luca Trevisan")]]#text(".]")

#text("[")#emph[#text("Update")]#text(", Aug 13: Relationship between Selberg’s eigenvalue conjecture and the Ramanujan-Petersson conjecture corrected.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-6554")[#strong[#text("Atle Selberg overleden at QED")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2007")]

#text("[…] Addendum 13-08-2007: Terence Tao schreef gisteren een uitgebreide blogpost over het werk van Selberg. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-6559")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2007")])]

#text("Just a quick comment here that as Selberg’s conjecture concerns the so-called (Hecke-)Maass cusp forms, the analogue of the Ramanujan-Petersson conjecture is equally open for these forms. Actually, the two conjectures for congruence subgroups of $SL(2,\\mathbb{R})$ are jointly called the Ramanujan-Selberg conjectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-6582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2007")])]

#text("Dear Gergely,")

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-6653")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2007")]

#text("[…] Atle Selberg Atle Selberg, who made immense and fundamental contributions to analytic number theory and related areas of […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-6767")[#strong[#text("Not Even Wrong » Blog Archive » More of the Usual Sorts of Things")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2007")]

#text("[…] two well-known scientists, mathematician Atle Selberg, and physicist Julius Wess, are no longer with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Selberg’s limit theorem for the Riemann zeta function on the critical line « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-40034")[#strong[#text("Selberg’s limit theorem for the Riemann zeta function on the critical line « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2009")])]

#text("[…] at least 40%, in fact – of these zeroes are known to lie on the critical line; see this earlier blog post of mine for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9996141e5f58d00d06bda579bc0b2900d52db0bd92516ea0ce56c9293c7c8fa0-13046d25a493826bc6881484050d80198ad3dc6c224233045a5ca3e6acd3d597.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jose garcia")]], [#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/#comment-147968")[#strong[#text("jose garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2012")])]

#link("http://vixra.org/pdf/1206.0069v1.pdf")[#text("http://vixra.org/pdf/1206.0069v1.pdf")]#text(" riemann Xi function $ \\xi (z) $ can be expressed as the quotient of the 2 determinants $ det(H-s(1-s)+1/4 ) $ and $det(H+1/4)$")
]
