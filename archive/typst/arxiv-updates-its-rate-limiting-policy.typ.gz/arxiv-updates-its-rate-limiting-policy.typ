// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/
// Converted to Typst by tao2typ: "2026-10-14T15:21:24.467865+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "arXiv updates its rate limiting policy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("arXiv updates its rate limiting policy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/")[#text("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In response to an exponential growth of submissions, the arXiv just ")#link("https://blog.arxiv.org/2026/10/01/updated-rate-limit-policy/")[#text("announced changes to its rate limiting policy")]#text(", which among other things restricts submissions to at most two a month for each submitter.")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696654")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("I think this is a bad idea.")

#text("First, let me say that the arXiv has been an enormous net good for the community. A lot of people do largely thankless work behind the scenes to keep it running, and I understand why they would want to introduce a policy like this.")

#text("Second, I would be happy to live in a world where people actually produced at most two papers a month. I don’t think I have ever produced more than two papers in a single month, and I don’t have plans to start doing so. There certainly are cases of people I respect and admire having produced more than two high-quality papers in a month on occasion, well before AI assistance, but that isn’t my main point.")

#text("The problem is that limiting arXiv submissions does not limit the production of papers. It limits when those papers become publicly available through the place we all look for them.")

#text("The arXiv serves both as a public timestamp and as a common record of new results. If I want to know whether someone has just solved a problem I am working on, I can mostly monitor the arXiv each night. That system is imperfect, but it is enormously useful.")

#text("Under this policy, we will increasingly see situations where someone posts a paper and then receives an email saying that someone else obtained the result a month earlier, but their paper is waiting for an available submission slot or has only been submitted to a journal. People will continue to circulate papers privately, both to establish priority and to share results with interested colleagues. But the rest of the community will have a less complete record of what has been done and when.")

#text("The arXiv lets the community share results and establish a public timestamp, with everyone having access to the same information at the same time. Moving more of this into private correspondence will make both priority and access to new results depend more on whom you know. That will make our community less open and democratic.")

#text("I’m all in favor of trying to change some of the behaviors that have arisen with AI. But we should do that by changing the incentives that encourage those behaviors, not by changing policies in ways that will (predictably) create other problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("It will limit the production of papers, which now is a good thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696715")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I disagree. With the advent of AI and its massive productivity-boost, I having been turning many of my backburner ideas into publications. They’re only backburner for want of time. Now the amount of time it takes to explore an idea and do the literature search is cut by an order of magnitude.")

#text("But I get the arXiv limit. I am not producing more than two papers a month anyway, but that’s partly because I have other things to do.")

#text("For people whose entire job is academic research, the limit may encourage them to focus on deeper problems and ideas that can’t be turned into publications at the rate of more than two per month.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Absolutely not. For example, submission processes were stressed due to some conferences requiring people to put up their work on arxiv. They could not solve it. So, punished the physical sciences, for example. It will apply the other way around as well.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696688")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Valid point. We can start airXiv for the papers that are in the queue for arXiv.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696700")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Or maybe the arXiv could be supplemented by other public forums where results (obtained in whatever way) are announced. There definitely needs to be a stiff hike in professional standards of what we’re willing to call a paper, and maybe the arXiv should be reserved for that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696657")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("Very good news in my eyes, at least a good first step.")

#text("So from now on submitters have to set priorities: Which of my findings are really important?")

#text("And a prediction: In earlier parts of a month “high-frequency submitters” may become modest, and when they realize “already 28th, and I still have an opportunity open; so I make one “last-minute” submission.”")

#text("It would be very interesting to make statistics on the consequences of the new rule(s).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Submitters can simply switch to places other than arxiv, they absolutely do not need to think about prioritization.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("On the one hand, this could be a good move, and making it 5 papers per year would be even better. On the other hand, it’s a pity, as uploading too many papers made it easier to committees to identify such candidates as unsuitable for academic positions and for serious consideration of their work. Thus, the new rate limit could kind of protect some people (who should not be protected) from themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696663")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("How would it limit if users can bundle multiple papers in a dissertation format submit?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a67adbb3403b0bc2383f34ca0e21aa401673381ebc9098df3bd03b15bdd56d55-184ab62e5ae42bbd005374109b66d396ec8b9f0e7c3f92d2578cd2a902895305.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of breadpurple02138716ec")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696711")[#strong[#text("breadpurple02138716ec")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("And in this way reduce salami slicing? I see this as an absolute win.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a67adbb3403b0bc2383f34ca0e21aa401673381ebc9098df3bd03b15bdd56d55-184ab62e5ae42bbd005374109b66d396ec8b9f0e7c3f92d2578cd2a902895305.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of breadpurple02138716ec")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696771")[#strong[#text("breadpurple02138716ec")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Also, I think a large part of this reason is to decrease the bourdon put on the arXiv moderation volunteers. And even if people start to put more in a single paper it would decrease the ammount of work. If someone uploads 500 pages of mathematics that does not meet the quality standard of arXiv, you will find out quickly enough before having read all 500 pages. This is much better then having to look at 10 papers of length 50.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Exceptional change that can only be good for math. I hope journals follow suit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696668")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("They should make it have that you have this rate limit until you can get “verified” in a sense, meaning some application or some form of a certificate that one is not just posting AI slop")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I disagree. If you are submitting more than 2 papers per month on a regular basis you aren’t thinking hard enough about any one of them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("To a reasonable extent i agree with this as it applies to papers written and then uploaded all within the month, certainly i am not fast enough to do this. On the other hand I have uploaded four papers in a month before, written over the course of probably two years. Basically the result of sitting on them and making tiny expositional improvements well into diminishing gains, and then bulk-uploading once I got stressed out and wanted a weight off my mind. Now you might say “just don’t do this” and indeed you would be correct…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I agree that this happens sometimes, but I think there’s little harm in forcing one to wait a bit before submitting the next couple. (I have 3 close to ready to go for which I will need to wait on one. I’ll do that with the one that could use a little more polish.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("That point is true for math papers in my opinion, but for large labs (not necessarily just math) with many students, they tend to publish many more than 2 papers a month")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("The limit is applied to the submitter only, it does not apply to all listed authors. These papers are very likely multi-author and one can just share the burden.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/01/arxiv-updates-its-rate-limiting-policy/#comment-696764")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("i wonder if this policy has been informed by at least some minimal statistical analysis. How many submissions for people who submit the most? Or is AI slop mainly concerning newcomers?")
]
