// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/
// Converted to Typst by tao2typ: "2026-10-14T16:34:54.506920+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Compressed sensing and single-pixel cameras", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Compressed sensing and single-pixel cameras")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")[#text("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve had a number of people ask me (especially in light of some recent publicity) exactly what “")#link("http://www.dsp.ece.rice.edu/cs/")[#text("compressed sensing")]#text("” means, and how a “")#link("http://www.dsp.ece.rice.edu/cs/cscamera/")[#text("single pixel camera")]#text("” could possibly work (and how it might be advantageous over traditional cameras in certain circumstances). There is a ")#link("http://www.dsp.ece.rice.edu/cs/")[#text("large literature on the subject")]#text(", but as the field is relatively recent, there does not yet appear to be a good non-technical introduction to the subject. So here’s my stab at the topic, which should hopefully be accessible to a non-mathematical audience.")

#text("For sake of concreteness I’ll primarily discuss the camera application, although compressed sensing is a more general measurement paradigm which is applicable to other contexts than imaging (e.g. astronomy, MRI, statistical selection, etc.), as I’ll briefly remark upon at the end of this post.")

#metadata(none) <tao-5d8c6597675239349fa1>#text(" The purpose of a camera is, of course, to record images. To simplify the discussion, let us think of an image as a rectangular array, e.g. a 1024 x 2048 array of pixels (thus there are 2 megapixels in all). To ignore the (minor) issue of colour, let us assume that we are just taking a black-and-white picture, so that each pixel is measured in ")#link("http://en.wikipedia.org/wiki/Grayscale")[#text("grayscale")]#text(" as an integer (e.g. an 8-bit integer from 0 to 255, or a 16-bit integer from 0 to 65535) which signifies the intensity of each pixel.")

#text("Now, to oversimplify things quite a bit, a traditional digital camera would take one measurement of intensity for each of its pixels (so, about 2 million measurements in the above example), resulting in a relatively large image file (2MB if one uses 8-bit grayscale, or 4MB if one uses 16-bit grayscale). Mathematically, this file can be represented by a very high-dimensional vector of numbers (in this example, the dimension is about 2 million).")

#text("Before I get to the new story of “compressed sensing”, I have to first quickly review the somewhat older story of plain old “compression”. (Those who already know how image compression works can skip forward a few paragraphs.)")

#text("The images described above can take up a lot of disk space on the camera (or on some computer where the images are later uploaded), and also take a non-trivial amount of time (and energy) to transfer from one medium to another. So, it is common practice to get the camera to ")#emph[#text("compress")]#text(" the image, from an initial large size (e.g. 2MB) to a much smaller size (e.g. 200KB, which is 10% of the size). The thing is that while the space of ")#emph[#text("all ")]#text("images has 2MB worth of “degrees of freedom” or “entropy”, the space of all ")#emph[#text("interesting ")]#text("images is much smaller, and can be stored using much less space, especially if one is willing to throw away some of the quality of the image. (Indeed, if one generates an image at random, one will almost certainly not get an interesting image; instead, one will just get random noise looking much like the static one can get on TV screens.)")

#text("How can one compress an image? There are many ways, some of which are rather technical, but let me try to give a non-technical (and slightly inaccurate) sketch of how it is done. It is quite typical for an image to have a large featureless component – for instance, in a landscape, up to half of the picture might be taken up by a monochromatic sky background. Suppose for instance that we locate a large square, say ")#mi("100 \\times 100")#text(" pixels, which are all exactly the same colour – e.g. all white. Without compression, this square would take 10,000 bytes to store (using 8-bit grayscale); however, instead, one can simply record the dimensions and location of the square, and note a single colour with which to paint the entire square; this will require only four or five bytes in all to record, leading to a massive space saving. Now in practice, we don’t get such an impressive gain in compression, because even apparently featureless regions have some small colour variation between them. So, given a featureless square, what one can do is record the ")#emph[#text("average")]#text(" colour of that square, and then subtract that average off from the image, leaving a small residual error. One can then locate more squares where the average colour is significant, and subtract those off as well. If one does this a couple times, eventually the only stuff left will be very small in magnitude (intensity), and not noticeable to the human eye. So we can throw away the rest of the image and record only the size, location, and intensity of the “significant” squares of the image. We can then reverse this process later and reconstruct a slightly lower-quality replica of the original image, which uses much less space.")

#text("Now, the above algorithm is not all that effective in practice, as it does not cope well with sharp transitions from one colour to another. It turns out to be better to work not with average colours in squares, but rather with average colour ")#emph[#text("imbalances")]#text(" in squares – the extent to which the intensity on (say) the right half of the square is higher on average than the intensity on the left. One can formalise this by using the (two-dimensional) ")#link("http://en.wikipedia.org/wiki/Haar_wavelet")[#text("Haar wavelet system")]#text(". It then turns out that one can work with “smoother” wavelet systems which are less susceptible to artefacts, but this is a technicality which we will not discuss here. But all of these systems lead to similar schemes: one represents the original image as a linear superposition of various “wavelets” (the analogues of the coloured squares in the preceding paragraph), stores all the significant (large magnitude) wavelet coefficients, and throws away (or “thresholds”) all the rest. This type of “hard wavelet coefficient thresholding” compression algorithm is not nearly as sophisticated as the ones actually used in practice (for instance in the ")#link("http://en.wikipedia.org/wiki/JPEG_2000")[#text("JPEG 2000 standard")]#text(") but it is somewhat illustrative of the general principles in compression.")

#text("To summarise (and to oversimplify somewhat), the original ")#mi("1024 \\times 2048")#text(" image may have two million degrees of freedom, and in particular if one wants to express this image in terms of wavelets then one would thus need two million different wavelets in order to reconstruct all images perfectly. However, the typical ")#emph[#text("interesting")]#text(" image is very ")#emph[#text("sparse")]#text(" or ")#emph[#text("compressible ")]#text("in the wavelet basis: perhaps only a hundred thousand of the wavelets already capture all the notable features of the image, with the remaining 1.9 million wavelets only contributing a very small amount of “random noise” which is largely invisible to most observers. (This is not always the case: heavily ")#emph[#text("textured")]#text(" images – e.g. images containing hair, fur, etc. – are not particularly compressible in the wavelet basis, and pose a challenge for image compression algorithms. But that is another story.)")

#text("Now, if we (or the camera) knew in advance which hundred thousand of the 2 million wavelet coefficients are going to be the important ones, then the camera could just measure those coefficients and not even bother trying to measure the rest. (It is possible to measure a single coefficient by applying a suitable “filter” or “mask” to the image, and making a single intensity measurement to what comes out.) However, the camera does not know which of the coefficients are going to be the key ones, so it must instead measure all 2 million pixels, convert the image to a wavelet basis, locate the hundred thousand dominant wavelet coefficients to keep, and throw away the rest. (This is of course only a caricature of how the image compression algorithm really works, but we will use it for sake of discussion.)")

#text("Now, of course, modern digital cameras work pretty well, and why should we try to improve on something which isn’t obviously broken? Indeed, the above algorithm, in which one collects an enormous amount of data but only saves a fraction of it, works just fine for consumer photography. Furthermore, with data storage becoming quite cheap, it is now often feasible to use modern cameras to take many images with no compression whatsoever. Also, the computing power required to perform the compression is manageable, even if it does contribute to the notoriously battery-draining energy consumption level of these cameras. However, there are non-consumer imaging applications in which this type of data collection paradigm is infeasible, most notably in ")#link("http://en.wikipedia.org/wiki/Wireless_sensor_network")[#text("sensor networks")]#text(". If one wants to collect data using thousands of sensors, which each need to stay ")#emph[#text("in situ")]#text(" for long periods of time such as months, then it becomes necessary to make the sensors as cheap and as low-power as possible – which in particular rules out the use of devices which require heavy computer processing power at the sensor end (although – and this is important – we are still allowed the luxury of all the computer power that modern technology affords us at the ")#emph[#text("receiver ")]#text("end, where all the data is collected and processed). For these types of applications, one needs a data collection paradigm which is as “dumb” as possible (and which is also robust with respect to, say, the loss of 10% of the sensors, or with respect to various types of noise or data corruption).")

#text("This is where ")#emph[#text("compressed sensing")]#text(" comes in. The main philosophy is this: if one only needs a 100,000 components to recover most of the image, why not just take a 100,000 measurements instead of 2 million? (In practice, we would allow a safety margin, e.g. taking 300,000 measurements, to allow for all sorts of issues, ranging from noise to ")#link("http://en.wikipedia.org/wiki/Aliasing")[#text("aliasing")]#text(" to breakdown of the recovery algorithm.) In principle, this could lead to a power consumption saving of up to an order of magnitude, which may not mean much for consumer photography but can be of real importance in sensor networks.")

#text("But, as I said before, the camera does not know in advance which hundred thousand of the two million wavelet coefficients are the important ones that one needs to save. What if the camera selects a completely different set of 100,000 (or 300,000) wavelets, and thus loses all the interesting information in the image?")

#text("The solution to this problem is both simple and unintuitive. It is to make 300,000 measurements which are ")#emph[#text("totally unrelated")]#text(" to the wavelet basis – despite all that I have said above regarding how this is the best basis in which to view and compress images. In fact, the best types of measurements to make are (pseudo-)")#emph[#text("random")]#text(" measurements – generating, say, 300,000 random “mask” images and measuring the extent to which the actual image resembles each of the masks. Now, these measurements (or “correlations”) between the image and the masks are likely to be all very small, and very random. But – and this is the key point – each one of the 2 million possible wavelets which comprise the image will generate their own distinctive “signature” inside these random measurements, as they will correlate positively against some of the masks, negatively against others, and be uncorrelated with yet more masks. But (with overwhelming probability) each of the 2 million signatures will be distinct; furthermore, it turns out that arbitrary linear combinations of up to a hundred thousand of these signatures will still be distinct from each other (from a linear algebra perspective, this is because two randomly chosen 100,000-dimensional subspaces of a 300,000 dimensional ambient space will be almost certainly disjoint from each other). Because of this, it is possible ")#emph[#text("in principle")]#text(" to recover the image (or at least the 100,000 most important components of the image) from these 300,000 random measurements. In short, we are constructing a linear algebra analogue of a ")#link("http://en.wikipedia.org/wiki/Hash_function")[#text("hash function")]#text(".")

#text("There are however two technical problems with this approach. Firstly, there is the issue of noise: an image is not perfectly the sum of 100,000 wavelet coefficients, but also has small contributions from the other 1.9 million coefficients also. These small contributions could conceivably disguise the contribution of the 100,000 wavelet signatures as coming from a completely unrelated set of 100,000 wavelet signatures; this is a type of “aliasing” problem. The second problem is how to use the 300,000 measurements obtained to recover the image.")

#text("Let us focus on the latter problem first. If we knew which 100,000 of the 2 million wavelets involved were, then we could use standard linear algebra methods (")#link("http://en.wikipedia.org/wiki/Gaussian_elimination")[#text("Gaussian elimination")]#text(", ")#link("http://en.wikipedia.org/wiki/Least_squares")[#text("least squares")]#text(", etc.) to recover the signal. (Indeed, this is one of the great advantages of linear encodings – they are much easier to invert than nonlinear ones. Most hash functions are practically impossible to invert – which is an advantage in cryptography, but not in signal recovery.) However, as stated before, we don’t know in advance which wavelets are involved. How can we find out? A naive least-squares approach gives horrible results which involve all 2 million coefficients and thus lead to very noisy and grainy images. One could perform a brute-force search instead, applying linear algebra once for each of the possible set of 100,000 key coefficients, but this turns out to take an insanely impractical amount of time (there are roughly ")#mi("10^{170,000}")#text(" combinations to consider!) and in any case this type of brute-force search turns out to be ")#link("http://en.wikipedia.org/wiki/NP-complete")[#text("NP-complete")]#text(" in general (it contains problems such as ")#link("http://en.wikipedia.org/wiki/Subset_sum_problem")[#text("subset-sum")]#text(" as a special case). Fortunately, however, there are two much more feasible ways to recover the data:")

#list(
[#emph[#text("Matching pursuit")]#text(": locate a wavelet whose signature seems to correlate with the data collected; remove all traces of that signature from the data; and repeat until we have totally “explained” the data collected in terms of wavelet signatures.")],
[#emph[#text("Basis pursuit")]#text(" (or ")#mi("l^1")#text(" minimisation): Out of all the possible combinations of wavelets which would fit the data collected, find the one which is “sparsest” in the sense that the total sum of the magnitudes of all the coefficients is as small as possible. (It turns out that this particular minimisation tends to force most of the coefficients to vanish.) This type of minimisation can be computed in reasonable time via ")#link("http://en.wikipedia.org/wiki/Convex_optimization")[#text("convex optimisation")]#text(" methods such as the ")#link("http://en.wikipedia.org/wiki/Simplex_algorithm")[#text("simplex method")]#text(".")]
)

#text("Note that these image recovery algorithms do require a non-trivial (though not ridiculous) amount of computer processing power, but this is not a problem for applications such as sensor networks since this recovery is done on the receiver end (which has access to powerful computers) rather than the sensor end (which does not).")

#text("There ")#link("http://arxiv.org/abs/math.CA/0410542")[#text("are")]#text(" ")#link("http://www.math.lsa.umich.edu/~annacg/papers/TG05-signal-recovery-rev-v2.pdf")[#text("now")]#text(" ")#link("http://www-stat.stanford.edu/~donoho/Reports/2004/l1l0EquivCorrected.pdf")[#text("rigorous")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2230846")[#text("results")]#text(" ")#link("http://arxiv.org/abs/math/0602559")[#text("which")]#text(" show that these approaches can reconstruct the original signals perfectly or almost-perfectly with very high probability of success, given various compressibility or sparsity hypotheses on the original image. The matching pursuit algorithm tends to be somewhat faster, but the basis pursuit algorithm seems to be more robust with respect to noise. Exploring the exact range of applicability of these methods is still a highly active current area of research. (Sadly, there does not seem to be an application to ")#mi("P\\neq NP")#text("; the type of sparse recovery problems which are NP-complete are the total opposite (as far as the measurement matrix is concerned) with the type of sparse recovery problems which can be treated by the above methods.)")

#text("As compressed sensing is still a fairly new field (especially regarding the rigorous mathematical results), it is still a bit premature to expect developments here to appear in actual sensors. However, there are proof-of-concept prototypes already, most notably the ")#link("http://www.dsp.ece.rice.edu/cscamera/")[#text("single-pixel camera")]#text(" developed at Rice.")

#text("Finally, I should remark that compressed sensing, being an abstract mathematical idea rather than a specific concrete recipe, can be applied to many other types of contexts than just imaging. Some examples include:")

#list(
[#link("http://en.wikipedia.org/wiki/Magnetic_resonance_imaging")[#text("Magnetic resonance imaging")]#text(" (MRI). In medicine, MRI attempts to recover an image (in this case, the water density distribution in a human body) by taking a large but finite number of measurements (basically taking a discretised ")#link("http://en.wikipedia.org/wiki/Radon_transform")[#text("Radon transform")]#text(" (or x-ray transform) of the body), and then reprocessing the data. Because of the large number of measurements needed, the procedure is lengthy for the patient. Compressed sensing techniques can reduce the number of measurements required significantly, leading to faster imaging (possibly even to real-time imaging, i.e. MRI videos rather than static MRI). Furthermore, one can trade off the number of measurements against the quality of the image, so that by using the same number of measurements as one traditionally does, one may be able to get much finer scales of resolution.")],
[#text("Astronomy. Many astronomical phenomena (e.g. pulsars) have various frequency oscillation behaviours which make them very sparse or compressible in the frequency domain. Compressed sensing techniques then allow one to measure these phenomena in the time domain (i.e. by recording telescope data) and being able to reconstruct the original signal accurately even from incomplete and noisy data (e.g. if weather, lack of telescope time, or simply the rotation of the earth prevents a complete time-series of data).")],
[#text("Linear coding. Compressed sensing also gives a simple way for multiple transmitters to combine their output in an error-correcting way, so that even if a significant fraction of the output is lost or corrupted, the original transmission can still be recovered. For instance, one can transmit 1000 bits of information by encoding them using a random linear code into a stream of 3000 bits; and then it will turn out that even if, say, 300 of the bits (chosen adversarially) are then corrupted, the original message can be reconstructed perfectly with essentially no chance of error. The relationship with compressed sensing arises by viewing the corruption itself as the sparse signal (it is only concentrated on 300 of the 3000 bits).")]
)

#text("Many of these applications are still only theoretical, but nevertheless the potential of these algorithms to impact so many types of measurement and signal processing is rather exciting. From a personal viewpoint, it is particularly satisfying to see work arising from pure mathematics (e.g. estimates on the determinant or singular values of Fourier minors) end up having potential application to the real world.")

#text("[")#emph[#text("Update")]#text(", April 15: For some explicit examples of how compressed sensing works on test images, see ")#link("https://candes.su.domains/software/l1magic/examples.html")[#text("this page")]#text(".]")

#heading(level: 1)[#text("Comments (122)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6402de7982f2b4dfc3d81354dc86574ba518e1a25daa596310637539622fa88e-52399e397496603732af95eb53194b79914cac95b5f783daf0a2a29b516f7ead.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jorge")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-456988")[#strong[#text("Jorge")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2015")])]

#text("Professor Tao,")#linebreak()#text(" The last link in the article, that should point to examples of compressed sensing, is broken. I believe it needs to link towards ")#link("http://statweb.stanford.edu/~candes/l1magic/examples.html")[#text("http://statweb.stanford.edu/~candes/l1magic/examples.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-465429")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2016")])]

#text("an interesting post by me, related to compressed sensing : ")#link("https://rajeshd007.wordpress.com/2016/01/19/a-concept-in-classical-fourier-analysis-and-its-similarity-to-compressed-sensing-using-minimum-total-variation/")[#text("https://rajeshd007.wordpress.com/2016/01/19/a-concept-in-classical-fourier-analysis-and-its-similarity-to-compressed-sensing-using-minimum-total-variation/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-478979")[#strong[#text("Lec #19: JL etc. | 15-850: CMU Advanced Algorithms")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2017")]

#text("[…] compressive sensing, there are a million resources online. E.g., here’s Terry Tao on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc593aad01a359986db01152975053753c914effa7f766d6e6c61bdd43d0343-e4ffee5a9e88001de70d44577c2981f2202d80fc572d84a111a7becb50694bb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kitty Sasa")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-503084")[#strong[#text("Kitty Sasa")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("The link to examples of CS on test images is broken since its author moved universities a while ago.")

#text("The new link appears to be: ")#link("https://statweb.stanford.edu/~candes/l1magic/examples.html")[#text("https://statweb.stanford.edu/~candes/l1magic/examples.html")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/067415b91474525f8178e4a6de4095562afca5c40271ec115d95a68063a5e53e-f711a5caedd8b0aa156ed9016d90b05dbbfd86beac8447437f89eee0864efb72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mixkino")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-503971")[#strong[#text("Mixkino")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2018")])]

#text("Compressed sensing is an exciting new computational technique for extracting large amounts of information from a signal. In one high-profile demonstration, for instance, researchers at Rice University built a camera that could produce 2-D images using only a single light sensor rather than the millions of light sensors found in a commodity camera.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-556853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2020")])]

#text("link at bottom should be ")#link("https://statweb.stanford.edu/~candes/software/l1magic/examples.html")[#text("https://statweb.stanford.edu/~candes/software/l1magic/examples.html")]

#emph[#text("[Link updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-570806")[#strong[#text("Las herramientas matemáticas que han revolucionado la tecnología digital – Info-spain")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2020")]

#text("[…] en inglés), que posibilita la reconstrucción de una imagen con pocas mediciones. Esto permite, entre otras aplicaciones, reducir el tiempo que se tarda en realizar un escáner sin perder la calidad de la imagen […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-570809")[#strong[#text("Las herramientas matemáticas que han revolucionado la tecnología digital – La Poderosa Bcn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2020")]

#text("[…] en inglés), que posibilita la reconstrucción de una imagen con pocas mediciones. Esto permite, entre otras aplicaciones, reducir el tiempo que se tarda en realizar un escáner sin perder la calidad de la imagen […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-570819")[#strong[#text("Las herramientas matemáticas que han revolucionado la tecnología digital » Mascarillas para protección del coronavirus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2020")]

#text("[…] en inglés), que posibilita la reconstrucción de una imagen con pocas mediciones. Esto permite, entre otras aplicaciones, reducir el tiempo que se tarda en realizar un escáner sin perder la calidad de la imagen […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-570977")[#strong[#text("Las herramientas matemáticas que han revolucionado la tecnología digital – 24 Noticias")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2020")]

#text("[…] en inglés), que posibilita la reconstrucción de una imagen con pocas mediciones. Esto permite, entre otras aplicaciones, reducir el tiempo que se tarda en realizar un escáner sin perder la calidad de la imagen […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-631018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2021")])]

#text("Just a typo in the “To summarise” paragraph (my fingers wrote “to summerise” ^^): “need thus need”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-687151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2025")])]

#text("Thank you for writing this!")

#text("The page with examples seems to have moved again, now to:")

#link("https://candes.su.domains/software/l1magic/examples.html")[#text("https://candes.su.domains/software/l1magic/examples.html")]

#emph[#text("[Link updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-688631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2025")])]

#text("Why didn’t Emmanuel Candes and yourself patent the compressed sensing? Perhaps if you are not motivated by the money you could have given to the UCLA math department?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-688635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2025")])]

#text("We did actually consult with the technology transfer offices at our respective universities to look into this; I forget the finer legal points arising out of the discussion, but I believe the theoretical nature of the results, as well as the existence of precursor algorithms, were significant obstacles to patenting any broad compressed sensing techniques. We did file for, and obtain, a ")#link("https://patents.google.com/patent/US8413019B2/en")[#text("much narrower patent")]#text(" for a related technique, but this patent will soon lapse due to lack of use.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-691945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2026")])]

#text("Professor Tao,")

#text("In the Astronomy part you wrote “…a complete time-series of data”, Does the “time-series” here mean that this series takes time as its independent variable (Like ∑f(t) )?")

#emph[#text("[")#link("https://en.wikipedia.org/wiki/Time_series")[#text("Yes")]#text(", though without the summation. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-3/#comment-691949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2026")])]

#text("Not that Anonymous friend, also my poor memory may be failing me but I remember that “time series” in statistics or other fields, it means a sequence instead of a “series”. So am I missing something Dr Tao?")

#emph[#text("[Clarification added that a ")#link("https://en.wikipedia.org/wiki/Time_series")[#text("time series")]#text(" does not involve summation, in contrast to ")#link("https://en.wikipedia.org/wiki/Series_(mathematics)")[#text("mathematical series")]#text(". -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45fabf92f1d8324df7a1a16dc27e6639f27e9f32aaea7269f71977bb80e1d7c7-feffa154719f7c25410c0770384a1e756a184b73da6d6199a4c6e7fe677bee97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolas")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-5226")[#strong[#text("nicolas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2007")])]

#text("I am very thrilled to discover that you are interested in Information theory problems. being a mathematician by education I have way too often been put off by professionals who like theories not for their power, but for their complexity.")

#text("This is not the case for Information theory, which I view as one of the biggest problems around. It is transverse, potent, and critical in many other areas of science.")

#text("Interestingly I tried to develop sensor compressing on my own in 1994 when I started engineering school, but did not have the necessary math skills to develop it. Also, I had few ways to reach the math literature we now have on the internet, and even fewer ways to connect with like-minded individuals.")#linebreak()#text(" Now a Fields medalist has a blog, and I find, serendipitously, that he works on a subject that interests me….")

#text("Nicolas")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-8502")[#strong[#text("rohitj’s Research » Compressed Sensing in Data Streams")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2007")]

#text("[…] Compressed sensing has emerged as a field of great interest in past very few years, and the Rice’s one pixel camera has surely proven to be a great application. Let me try to explain what compressed sensing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a342778e5efcba709ffa3c856942fe54b7f7b02c747ad9c0c8fca3e057ef9df4-6dc271a72a61e5bd22272bdc9b53439de9245bde8b8f37c5fbd6300bc529c95c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen Downes")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-8629")[#strong[#text("Stephen Downes")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Great article on a subject I never even knew existed (and I am an avid digital photographer). Posts like this are a real service, and help people like me understand (to some degree of depth) the issues that lie behind the things that interest us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-10462")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("All of these comments apply to quantum model order reduction (QMOR) too. To translate “The space of all interesting [quantum wave functions] is much smaller, and can be stored using much less space, especially if one is willing to throw away some of the [high-order correlations of the wave function]. Indeed, if one generates [a wave function] at random, one will almost certainly not get an interesting [quantum wave function].”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of skibum")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-10957")[#strong[#text("skibum")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Hello Professor Tao.")

#text("I was wondering if you might be willing to explain to me why in the Decoding by Linear Programming paper you must restrict attention to the c_j coeffs. being real?")

#text("I haven’t completely internalized all of the nitty-gritty detail of the proof yet, but wouldn’t this be quite restrictive in that any signals of interest (if using the DFT as the orthonormal basis with respect to which the signal is sparse) would have to be zero-phase? Or is it that the coefficients must be real in order to recast the l1-min problem as a linear program? (I believe the Candes tutorial says some such about complex being an SOCP program).")

#text("I’m just an MS student who has yet to take a course on optimization so perhaps this is where I’m missing something, but if you could provide a brief answer to this question, it’d be greatly appreciated.")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-10970")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Skibum: “The devil is in the details” – “Random House Dictionary")#linebreak()#text(" of popular proverbs and sayings (hardcover)” by Gregory Y. Titelman")#linebreak()#text(" (Random House Reference; 1st edition 03.05.1996).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-10971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Skibum,")

#text("The results in my paper with Emmanuel can be largely extended to complex-valued signals with only minor changes (many constants may need to be adjusted by a factor of two, in particular). One “cheap” way to do this is simply to replace an n-dimensional complex state space with a 2n-dimensional real state space by breaking everything up into real and imaginary parts. Though, as you point out, l^1 minimisation in the resulting 2n-dimensional space is not quite the same as l^1 minimisation in the original complex n-dimensional space, because the complex numbers are usually measured in l^2 norm rather than l^1 norm. But either type of minimisation should give the same type of results. (Minimising complex l^1, with the complex numbers measured in l^2 norm, is not a particularly clean linear program, though still fairly feasible; for computational purposes it is probably better to measure complex numbers in l^1 norm, even if this is more artificial.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charlie")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-13403")[#strong[#text("Charlie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2007")])]

#text("This was readable for someone with no background in math or “imaging.” Thanks for the simplification, which is very necessary “to see work arising from pure mathematics … end up having potential application to the real world.” Working at a psychiatry neuroimaging lab, I am a huge fan of any research moving toward increasing temporal and/or spatial resolution for MRI. Plus, ‘maths’ are apparently interesting too.")#linebreak()#text(" Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-24688")[#strong[#text("Smartest Person Blogging ? « Evil Fish")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2008")]

#text("[…] as an example. And how to build one pixel camera as another. The blog is at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/575c12bb99c649382d8a8e3ecdb8c9ef83868e2d5356d0c2d9b806fcff8119cd-af2fe4f90c96f7d0e0c165a50631470e0b059348bb0552da3f2e0406994c2b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of exdj")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-25902")[#strong[#text("exdj")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Dear Folks,")#linebreak()#text(" I think it’s wonderful that Terry managed to find time to give me a hint towards the solution of a homework problem found in his “problem solving ” course designed primarily top get UCLA students ready for the Putnam. The problem: Suppose all points in R^2 were colored , say, red white or blue.Prove that it is always possible to find to points one inch apart with the same color. Problems of this type,usually use proof by contradiction, as this one did.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73c0e3d57b00886275d80464e248e1bcebafdecaa7b53d9714bdc35de9b99145-e014b284c49640ea982cdd01e62212e14ba40c4e3a909d0cc69bec699d0aa292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Infant on compressed sensing « On the learning curve…")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-31201")[#strong[#text("Infant on compressed sensing « On the learning curve…")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("[…] to share his thoughts to the world, in spite of being busy with his work and research. In this blog entry I came across, he describe the problem of compressed sensing with a very very simple example. He […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cacb39b6277ed54f516eb3f55d9fe00bf40edc1379e8cc355ecc34b0cf81cbb3-83212c721fa10bf5229088b5ae49c4a87400f3b47eb0f64e7ed542043e09636a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-31716")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2008")])]

#text("Hi Prof Tao,")

#text("I have a few questions for you, if you don’t mind answering:")

#text("1) With respect to “Decoding by Linear Programming,” isn’t the decoding application somewhat, with all due respect, limited? In particular, since you are operating on the field of real numbers (whereas codes are typically binary, etc.). Has any work been done on extending your results to codes that are in a more realistic system?")

#text("I’m no coding theorist, but just curious. It seems to me that perhaps the general problem of compressing and encoding in one step (as opposed to the usual transforming scheme) is a better application for CS (as you two have mentioned), along with general ill-posed inverse problems.")

#text("2) Also, I am a little confused as to what the best bounds are for the restricted isometry constants. In particular, your “Decoding by LP” paper showed that:")#linebreak()#text(" delta_s + delta_2s + delta_3s < 1 is sufficient (and actually tighter than that if you use the cosine of the angle between subspaces constants … sorry forgot what these are called), but Candes has shown in other papers which he claims have improved the bounds a bit (see ")#link("http://www.acm.caltech.edu/~emmanuel/papers/RIP.pdf")[#text("http://www.acm.caltech.edu/~emmanuel/papers/RIP.pdf")]#text(") that delta_2s < sqrt(2) – 1 is sufficient. Obviously the restricted isometry constants are monotonically increasing, but I’m not quite sure from first glance how delta_2s < ~.4142 is necessarily better than the work in Decoding by LP.")

#text("3) Finally, I really like the approach of decoupling the problem such that the restricted isometry constants to imply the equivalence of the l0 relaxation. That said, verifying the RIP for any given matrix is also NP-hard, correct? Thus, the work thus far has focused on random constructions: gaussian ensembles, binary ensembles, randomly selecting fourier, noiselet, etc. coefficients that are incoherent with the sparsifying basis. The problem subsequently becomes probabilistic in nature; there’s no guarantee of recovery, but just a high probability thereof. That said, my question is: has any work been done on deterministic ensembles that obey the RIP?")

#text("4) Donoho’s work, it seems, has focused largely on higher dimensional geometry. I must admit most of that is fairly over my head, lol. Are the RIP coefficients at all related to what he has been doing?")

#text("Anyway, sorry for all of the questions; just curious. I’m sure you’re very busy, but if you have a moment and wouldn’t mind enlightening all of us, it’d be extremely appreciated. Thanks…")

#text("– Adam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cacb39b6277ed54f516eb3f55d9fe00bf40edc1379e8cc355ecc34b0cf81cbb3-83212c721fa10bf5229088b5ae49c4a87400f3b47eb0f64e7ed542043e09636a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-31717")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2008")])]

#text("And with all that typing, I just saw your other page on deterministic matrices. Sorry for question (3)!!!")

#text("I think you might be right that the approach of developing a (fast) algorithm that can verify the RIP would be the most promising. In particular, at the very least it would provide a quick method to justify using l1 for inverse problems in which there is known to be a sparse representation for the signal class of interest…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-31718")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2008")])]

#text("Dear Adam,")

#text("Regarding (1), it is true that all known CS-based methods right now are based over the reals, and so do not work so well for binary codes (though one could in principle imagine deploying a CS-based linear code over a network such as the internet, as each internet packet could store a high-precision real number; it does not seem though that this is particularly superior to existing transmission protocols, though). Interestingly, though, Feldman has some independent work in which he decodes some binary codes by relaxing the decoding problem into a linear programming problem (accepting some pseudo-codewords in the process) and solving that instead. There is also a certain amount of followup literature on CS-based linear codes, that can for instance be found at the compressedsensing.com website.")

#text("Regarding (2), the two conditions are not directly comparable, but I think when one compares the conditions with experimental or theoretical estimates on the isometry constants, Emmanuel’s condition comes out slightly ahead (and I think it has since been sharpened further by Cai, Xu, and Zhang). There seems to be a reasonably sharp threshold behaviour with the isometry constants – they are usually either very small or very large, with not much of a transition in between – and so getting the 3S down to a 2S in principle extends the range of S for which CS works by about 50%, which tends to be enough of a cushion to absorb losses elsewhere.")

#text("Donoho’s work in (4) uses the special properties of the gaussian ensemble to obtain slightly sharper results than what one can get from the RIP, which is a general-purpose axiom that covers more ensembles but has a slightly sub-optimal efficiency. (There is a paper of Candes, Rudelson, Vershynin, and myself in which we compare the two approaches; there are also several other papers in the literature obtaining more precise results in the gaussian case, including a quite sharp threshold for when l^1 minimisation breaks down.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-40984")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("This is only for response to coding theory.")#linebreak()#text(" Even though binary codes have been well studied. They are of limited use. Codes have to be carved from lattices in real world.")

#text("One can life the binary codes (or finite field codes) to complex numbers. It may no longer be non-linear. An important problem is to lift the codes so that")#linebreak()#text(" 1) they are linear")#linebreak()#text(" 2) if the hamming distance is small b/w the finite field codewords, then their euclidean distance have to be larger. This strategy comes close to achieving the best possoble performance. It is extremely hard to do with finite field codes, but an elementary exercise in function field codes (convolutional codes)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cacb39b6277ed54f516eb3f55d9fe00bf40edc1379e8cc355ecc34b0cf81cbb3-83212c721fa10bf5229088b5ae49c4a87400f3b47eb0f64e7ed542043e09636a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-31719")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2008")])]

#text("Wow thanks for the quick reply! I’ll check out that Candes/Rudelson/Vershynin/Yourself paper…")

#text("If I might ask a couple more questions which I’ve been contemplating….")

#text("I’m thinking about inverse problems where the dimensionality is quite high (as in an image, for instance). Merely storing the Gaussian matrix becomes near impossible for, say, a 512×512 image. Computationally it’s unwieldy too. One could much more efficiently store the Bernoulli ensemble, but still AFAIK there’s no fast algorithm for applying it.")

#text("I presume this is why the incoherent measurements of the noiselet-haar (or other db filters) system are of interest. That said, instead of ")#mi("m \\geq c_1S\\log(n/S)")#text(" as a guarantee for exact reconstruction, it’s ")#mi("m \\geq c_2S(\\log(n))^4")#text(". So two questions really,")

#text("1) I thought I read something about the latter requirement being overly pessimistic on the lower bound for m. What’s the current guess for that power on the log? I thought you had it at 6 in your initial Fourier paper, and then it lowered to 4….")

#text("2) Let’s say that 4 is as low as we can go. I saw that Baraniuk had an ICASSP paper effectively on Toeplitz matrices with iid Gaussian entries, and thus FFT could be used, but the paper didn’t seem to contain any proofs… just sort of “hey this works.” Out of curiousity, do you know if anyone has rigorously analyzed the Toeplitz gaussian ensemble? Seems like an interesting topic to see where the lower bound for m lies if we reduce the DOF of the matrix substantially as in a Toeplitz structure…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cacb39b6277ed54f516eb3f55d9fe00bf40edc1379e8cc355ecc34b0cf81cbb3-83212c721fa10bf5229088b5ae49c4a87400f3b47eb0f64e7ed542043e09636a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-31720")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2008")])]

#text("Point of clarification: I’m looking at a problem where I have ")#mi("y = \\Phi T \\Psi x")#text(", where the T is a convolution operator. I meant to say my gaussian matrix would be 512^2 by 512^2, roughly….. hence I can’t store it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Small samples, and the margin of error « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-32880")[#strong[#text("Small samples, and the margin of error « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2008")])]

#text("[…] to sample the entire population to get a good reading. (The same general philosophy underlies compressed sensing, but that’s another […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/663a319d112e69e9ebe5a1b81f16f1ca183e5d127ae5c1b2eb1aa87baa96d805-9c2595793d0d8578034c0ba335aafa11d92c659623bbeba487d9b6abfbd10acd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jatkesha")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-33016")[#strong[#text("Jatkesha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Dear Prof. Tao,")

#text("Thanks for the wonderful expository article on compressed sensing. It was really helpful for someone with limited mathematical background to understand what compressed sensing is all about.")

#text("I do have a query though. I would be glad if you can answer it for me.")

#text("Doesn’t compressed sensing help to solve problems in inverse theory? Most of the problems in inverse theory involve a large amount of uncertainty because of a large amount of noise as well as linearized methods especially in Geophysics. Does compressed sensing help to solve linear and non-linear inverse problems?")

#text("Apologies if the query sounds too trivial.")

#text("Thanks and warm regards.")

#text("-Jatkesha")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-33029")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Dear Jatkesha,")

#text("Compressed sensing is still largely restricted to linear problems at present, and requires the matrix relating the unknown variables to the actual measurements to be completely known. This is the situation for instance in image recovery from incomplete measurements; I’m not sure if this qualifies as an inverse problem though. There are one or two papers on in situ compressed sensing at ")#link("http://www.compressedsensing.com/")[#text("http://www.compressedsensing.com/")]#text(" which may be slightly related to your query.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b967898071d28883225a6ebe768e92c946086cd4d5d16fbb6d065d85b7a917c1-14e498802fc88f279517786c8f60496f85170daa4fae06d3cdf1b7f26b5bbd04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-34501")[#strong[#text("Josh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2008")])]

#text("Prof. Tao,")

#text("Thank you for this explanation, it continues to be very helpful. After perusing the literature, I have not been able to discern how the aliasing problem is addressed. Could you please provide a brief explanation or a pointer to a reasonably accessible paper?")

#text("Thank you,")#linebreak()#text(" Josh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lia")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-38111")[#strong[#text("lia")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2009")])]

#text("Hi Prof. Tao!")

#text("In regard to your comment, “Many astronomical phenomena (e.g. pulsars) have various frequency oscillation behaviours which make them very sparse or compressible in the frequency domain,” I tried to find a reference on this, but couldn’t manage to do so. Do you know of a good reference?")

#text("Thanks!")#linebreak()#text(" Lia")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-38605")[#strong[#text("Compressed Sampling « Research Jottings")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2009")]

#text("[…] Terrence Tao has a really good description of CS on his blog. Check it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-39813")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("Adam,")

#text("You might be interested in Circulant and Toeplitz Matrices in Compressed Sensing by Holger Rauhut")

#text("In general, when it comes to finding a specific sub-subject within compressed sensing, you might want to do a search on the nuit blanche blog")

#text("The search box is on the top left corner.")

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-40982")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Sparsity implies low entropy. But Low entropy does not imply sparsity. To information theorists entropy is object of interest.")

#text("CS is a curious tool in signal processing. But it is unclear whether there is a generalization of CS to make it related to entropy of sources. If so this generalization of CS would be a powerful tool in information theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-41667")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("Professor Tao:")#linebreak()#text(" You have a great blog. I have a question on compressed sensing. In CS one takes r measurements and tries to find a vector of length n which has considerably fewer non-zeros than r.")

#text("My question is the following. One can imagine several scenarios in which one may not be interested in the entire vector of length n. But say a subset of size m of the vector. In this scenario, does the CS setting still hold. Should one still take r measurements? m could in fact be smaller than r.")

#text("Do you have any leads on this problem?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-41688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2009")])]

#text("Reducing the number of measurements one is interested in may possibly reduce the run time of the recovery algorithm, but does not reduce the number of measurements one needs to reconstruct the data.")

#text("Imagine for instance that one could reconstruct any m of the n components of the data vector from r given measurements. By dividing the n components into about n/m groups of m each, and applying one’s reconstruction algorithm to each group, one sees that one can then reconstruct the entire data vector from the same initial set of r given measurements (but possibly with the run time of the reconstruction increased by a factor of O(n/m)). So one cannot gain any reduction in the number r of measurements this way (except in the trivial case m=0, of course).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-41693")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2009")])]

#text("Professor:")#linebreak()#text(" Conceptually your answer makes sense. However, the reason I have specifically asked this question is because of the existence of locally decodable codes and the applicability of CS technique to coding theory.")

#text("In coding theory, y = Gx +n is received vector where G is the generator, x is message, n is noise.")

#text("Typically one has to process all bits of y to get reliable reconstruction of x.")

#text("However LDC offers the following flexibility:")#linebreak()#text(" Suppose only bit location i of x has to be be found, a q query LDC needs to access only q locations of y.")

#text("Existence of good LDCs have implications in complexity theory. Since CS offers good decoding ability, I was wondering if bounds in CS could be transferred to bounds in LDCs.")

#link("http://research.microsoft.com/en-us/um/people/yekhanin/papers/nice_pir_limits.pdf")[#text("Click to access nice_pir_limits.pdf")]

#text("However known LDCs are non-random. However it might still not be a problem in transferring CS techniques because of the following result:")#linebreak()#text(" ")#link("http://www2.computer.org/portal/web/csdl/doi/10.1109/FOCS.2007.8")[#text("http://www2.computer.org/portal/web/csdl/doi/10.1109/FOCS.2007.8")]

#text("I am working along this line of reasoning. I was wondering if my ideas make sense to you and whether it would be worth proceeding in this route.")

#text("Thank you,")#linebreak()#text(" sincerely,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-41788")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2009")])]

#text("AJ,")

#text("You might be interested in the latest entry on Nuit Blanche.")

#link("http://nuit-blanche.blogspot.com/2009/10/cs-lp-decoding-meets-lp-decoding.html")[#text("http://nuit-blanche.blogspot.com/2009/10/cs-lp-decoding-meets-lp-decoding.html")]

#text("Alex Dimakis and Pascal Vontobel have a new paper entitled: LP Decoding meets LP Decoding: A Connection between Channel Coding and Compressed Sensing")

#text("There is also a mention of another paper by Dongning Guo, Dror Baron, and Shlomo Shamai entitled A Single-letter Characterization of Optimal Noisy Compressed Sensing which uses some of these sparse matrices found in LDPC.")

#text("Cheers,")

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-41792")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2009")])]

#text("Hi Igor:")#linebreak()#text(" Thank you. It looks like CS techniques might be useful in complexity theory as well due to connection between random sparse codes and local decoding. But I do not know how one might transfer CS techniques in sparse codes to this setting.")#linebreak()#text(" AJ")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-41796")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2009")])]

#text("Professor Tao:")#linebreak()#text(" Is there an information theoretic meaning to sparseness?")

#text("It seems to be that from the following two sequences the correspondence might be tricky.")#linebreak()#text(" A=1111111111…….")#linebreak()#text(" B=10100100001000000001……….")

#text("It seems to me that B somehow carries more information that A even though B is sparse.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-45779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2010")])]

#text("Here, A is more sparse than B in an appropriate basis. So it is generally true that a sparse signal carries less information than a less sparse one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-42825")[#strong[#text("科学松鼠会 » 陶哲轩：长大的神童")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")]

#text("[…] （顺便提一句，由于陶哲轩和很多别的数学家的介入，压缩感知这个领域已经在这一两年来成为应用数学里最热门的领域之一，吸引了人们极大的注意。陶哲轩本人在2007年写过一篇极好的关于这个领域的普及性文章，松鼠会大概会在将来推出这篇文章的中文翻译，敬请期待。） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-43728")[#strong[#text("Mini Searches with Answers - Answer My Searches")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2010")]

#text("[…] Compressed sensing and single-pixel cameras « What’s newHow digital cameras work […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-43801")[#strong[#text("Filling In the Blanks « Rich's Random Walks")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2010")]

#text("[…] to construct the most plausible “original”. (A more technical description is given in this blog post by Terence Tao, one of the pioneers of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-45382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2010")])]

#text("Professor Tao,")

#text("Is there a way that we can correlate sparsity or compressibility of the signal to its statistical property such as mean or variance etc.. This is important since, it is not supported on the node to compute number of significant coefficients (K) to compute number of measurements M=cKlog(N/K) . If you could model K=f(V) where V is the variance of the signal then we could determine M=cf(V)log(N/f(V)).")

#text("regards")#linebreak()#text(" Anonymous")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e34b3471ec553dcb8285bbed266bf997689c1290dd0e7161e6f335e844e88757-2755c2a53cf57d044b9b36a28ed376abd26790cfa79e56be90e05a129d3eecc6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-45650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2010")])]

#text("Hello")#linebreak()#text(" I need help.")#linebreak()#text(" Can someone refine a very bad video?")#linebreak()#text(" I heard of this method of treatment of photos, but I do not know who to contact.")#linebreak()#text(" Thank you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-50450")[#strong[#text("Compressed sensing, compressed MDS, compressed clustering, and my talk tomorrow « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")]

#text("[…] World’s most hurried introduction to compressed sensing (see Terry’s blog for a more thorough account.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-59166")[#strong[#text("Compressed Sensing: What is compressed sensing (compressive sampling) in layman's terms? - Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2011")]

#text("[…] Topics or PeopleComment Seb Paquet, University prof Terry Tao has a great answer here: ")#link("https://terrytao.wordpress.com/20")[#text("https://terrytao.wordpress.com/20")]#text("… (more) Sign up for free to read the full text. Login if you already have an account.This answer […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-116026")[#strong[#text("Thought this was cool: 陶哲轩：压缩感知与单像素照相机 « CWYAlpha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2011")]

#text("[…] 科学松鼠会上关于Terence Tao的Compressed sensing and single-pixel cameras的译文《压缩感知与单像素照相机》。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-116053")[#strong[#text("Compressed sensing | Quantum Dot")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")]

#text("[…] Professor Terence Tao: Compressed sensing and single-pixel cameras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/267b8731786e38ed3dfff4ad287ad1a798a33a406063282b723edb6174d507e7-a9dcde1e48f01b633221516b2fe2cc31c885fba37fc9753b9db7405fa3b44878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave Wlson")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-147772")[#strong[#text("Dave Wlson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2012")])]

#text("Thank you for posting this Professor. I’ve been racking my head trying to figure out what this is about for ages. A great straightforward well explained article that was truly needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-228781")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Image compression basics (adapted from “Compressed sensing and single-pixel cameras“) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-228902")[#strong[#text("压缩感知 | TechTrace")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")]

#text("[…] 本部分为陶哲轩在一篇blog中对于comprehensive sensing 文章翻译过来的精华部分，提取了重点，并加入了一些理解，这里用来解释CS的概念堪称经典。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-228915")[#strong[#text("Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")]

#text("[…] [1.2] Compressed sensing and single-pixel cameras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-239747")[#strong[#text("Compressive sensing and bioinformatics | Follow the Data")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2013")]

#text("[…] work in developing compressed sensing, has much better explanations than I can give, for instance this 2007 blog post that exemplifies the theory with the “single-pixel camera” and this PDF presentation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-243807")[#strong[#text("Scikit study | X Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")]

#text("[…] 本部分为陶哲轩在一篇blog中对于comprehensive sensing 文章翻译过来的精华部分，提取了重点，并加入了一些理解，这里用来解释CS的概念堪称经典。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-250385")[#strong[#text("12 interesting things about the 1-norm | The Regularized Singularity")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")]

#text("[…] you really want an introduction to compressed sensing read Terry Tao’s wonderful, wonderful post (")#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")[#text("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")]#text(") on the single pixel camera. His math papers on related topics are pretty great […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e99e7dd892be299715eb802d26406359bdb2dda1a2e56e9c159f3a0a245fd5c4-3b313626e4e12905c8a5d5035cc384fe016cc176525954e06d00a2ab435cb3b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of preethi shreeya")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-268856")[#strong[#text("preethi shreeya")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Hello Professor Tao,")

#text("Given: I have a beam fixed at one end and free at the other. It obviously results in vibrations due to the disturbances in the environment or when induced. This system can be represented using a differential equation. The vibrations are sensed using sensors, analyzed and reduced. Now, the sensing is done through compressed sensing technique.")

#text("My question is: How is it possible to find the optimal sensor placement (minimal number of sensors along with the details of it’s spatial position) just with the help of the Measurement matrix (that we design in compressed sensing for reconstruction purpose)?")

#text("Details: Suppose we want to retrieve x (vibrational info) from: y=cx, where c is the fat matrix (Measurement matrix * sparse matrix). I want to find a relationship that the measurement matrix can hold with the placement of sensors. It’s like an inverse problem, instead of designing a measurement matrix with respect to the sensors placed, I want to place the sensors with the knowledge I have about the measurement matrix.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-269163")[#strong[#text("(转)初识压缩感知Compressive Sensing | Dream's Secret Base")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")]

#text("[…] 本部分为陶哲轩在一篇blog中对于comprehensive sensing 文章翻译过来的精华部分，提取了重点，并加入了一些理解，这里用来解释CS的概念堪称经典。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The restricted isometry property. | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-401554")[#strong[#text("The restricted isometry property. | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2014")])]

#text("[…] sensing and how RIP matrices naturally arise. A more complete exposition of this material is Tao’s blog post on this subject. In the final section I address the (pure) mathematic interest in RIP matrices, describe some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-456588")[#strong[#text("Single Pixel Camera - Making Lens Redundant")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")]

#text("[…] utilizes a technique known as compressed sensing. It first compresses the image data and then records it. On the other hand, conventional cameras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-2/#comment-456756")[#strong[#text("Single Pixel Camera – Making Lens Redundant | planet5D DSLR video news and more!")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2015")]

#text("[…] utilizes a technique known as compressed sensing. It first compresses the image data and then records it. On the other hand, conventional cameras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43bc9de49ac9129298f658cf51a277c650ef1f4ecc1457ef246fa0db483ebb49-078bbd131dd560f57d2de8ced6dc9e0c6492aed0a03a01daf8f252e813f7918b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of randomwalker")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-445")[#strong[#text("randomwalker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("On anyone else’s blog this would be an excellent article, but you should be proving deep and awe-inspiring theorems rather than engaging in pedagogy for non-technical audiences.")

#text("Re. P \\neq NP: were you comparing it with learning-parity-with-noise?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-557097")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("It probably only took him 10 minutes to type this up, even if it were a waste of time (which exposition is *not*), it’s only 10 minutes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-446")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("Randomwalker, I am sure that Terence Tao is perfectly able to prioritize his own time. His track record so far proves it. It’s an interesting phenomenon to me that so many successful people have an unusually broad range of interests, and somehow find the time to pursue them. I believe this may be a help, rather than a hindrance, since having broad interests is helpful both in finding good research topics and in solving them. (I might worry too, if this blog got filled up with the sort of post we see here, but that doesn’t seem likely.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-447")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("tough crowd :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43bc9de49ac9129298f658cf51a277c650ef1f4ecc1457ef246fa0db483ebb49-078bbd131dd560f57d2de8ced6dc9e0c6492aed0a03a01daf8f252e813f7918b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of randomwalker")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-450")[#strong[#text("randomwalker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("Harald: you’re right. I should think before speaking :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9050a8563a491951bac8517849c39421a62876705b27147102260304fd61a42d-64f48ec7554dc0efe9b7031d026fe533f544cb76addecc7caa40d062efebf928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marco")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-451")[#strong[#text("marco")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("I hope Terence Tao will keep publishing posts of this kind: they are very well written, accessible to non-technical people, and full of hints for those who want to dig a bit deeper.")#linebreak()#text(" That’s more than enough for me to read them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("If I were the author, I would be shocked or even saddened by the first comment …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/340b02c273c5b762ff2704091fce6f317819b3440b136110b95ea352717e322c-46821a9b29edbf3b5aa0be1b839f1a6b362cca6dae8eb473253ecab327ad0209.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Grigore")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-453")[#strong[#text("Radu Grigore")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Thank you for this great post.")

#text("Here is something you might find mildly interesting. A month ago TopCoder organized a marathon (i.e., one week long) match in which people had to write a program that reconstructs a 100×100 grid of `densities’ based on the information gathered from 10000 (noisy) measurements. A few tried the Radon transform but none used it in the end because it was hard to implement and didn’t work well at all with so few measurements. I wonder if people would have done better if they would have known about compressed sensing and read some of the articles you link to here…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf09cf30636779f507ac7bb7605f1fa930eb0fd5cf47853823ea8305c6708b7b-57bac54d2fefac22b892cb860f89f82132d79fea9b659911b396aa58fcf1f65b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aravind")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-455")[#strong[#text("aravind")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("thanks for your detailed description as usual, terry. you say: “… two randomly chosen 100,000-dimensional subspaces of a 300,000 dimensional ambient space will be almost certainly disjoint from each other”. i must be missing something, but from the “birthday phenomeon”, isn’t the above true only if the two subspaces have dimension up to about sqrt(300,000), i.e., much smaller than 100,000?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dde9221ad02db29461e5fa4458d79bda2e5cb7d4cd25a5ef10f12ae4a6200d28-78c89c8a7a37b65ff4c16f64c049436192f79e0bfe4b3cd09d79f09c731989e7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Benson")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-457")[#strong[#text("Brian Benson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("randomwalker, to expand on Professor Hanche-Olsen’s comments, it may seem naively true that the opportunity cost of Professor Tao writing this post is quite high; however, this argument is a rather short-sighted. It is my interpretation that the post above seeks to increase overall public awareness of and interest in both Professor Tao’s work and the relatively new field of compressed sensing. This increase in public awareness is likely to increase the demand for further works by Professor Tao and promote future work in the area of compressed sensing. This is not to mention the educational value of the post to the community as a whole.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-459")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Radu, the current results seem to indicate that you need to know exactly the random functions or masks onto which the measurements are made. In other words, the amount of information needed to reconstruct the signal includes all the random functions or the masks on which the original signal was projected on. Therefore, being given only a signal corrupted with noise is not, as far as I understand, a case where one could reconstruct the original signal. Furthermore, nothing in the topcoder problem statement says anything about these densities being sparse in any basis. If these densities are random spikes, then less than 10000 random masks won’t do any good with the current results. For instance, if one uses a one-pixel camera to image some random brownian motion in a microscope application, it would take a long time to get a full picture. It might be better to flip those micro-mirrors one at a time!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-460")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("aravind: No, subspaces are different from subsets. Technically speaking, the subspaces will be disjoint with probability 1. You should instead consider a suitable notion of approximate intersection, so that if one of the angles between the subspaces is merely moderately acute, then that counts as tantamount to an intersection. A “moderately acute” angle is typically an angle less than, say, 80 degrees.")

#text("Nonetheless, if you have two 1/3-dimensional random subspaces of a large vector spaces, the chance of even an approximate intersection is exponentially small. This phenomenon arises, for instance, in quantum computing, where subsets are commonly replaced by subspaces for various purposes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-461")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Brian Benson: You could be right about the merit of Terry’s posts here, but in a way you’re also reading more into the question than is really there. I have met a few Fields Medalists such as Terry, and the truth is that they put their pants on just like everyone else. They can procrastinate, or get distracted, or otherwise be ordinary human beings.")

#text("On the other hand, it is true that Terry in particular does seem to be more efficient in his work than many other mathematicians. It is also true that many award-winning scientists and mathematicians get inundated with attention, most of which is perfectly respectable, but it gets to be too much and they are forced to prioritize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-462")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")]

#text("[…] Compressed sensing and single-pixel cameras I’ve had a number of people ask me (especially in light of some recent publicity) exactly what “compressed […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-470")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Aravind: there is an analogy between the birthday paradox (which regards subsets of a finite set) and the intersection of random subspaces (which regards subspaces of a finite dimensional vector space). The birthday paradox tells you that if you have a set with N elements and you pick two random subsets of size much larger than ")#mi("\\sqrt{N}")#text(", then there will very likely be a collision, but if you pick random subsets of size much smaller than ")#mi("\\sqrt{N}")#text(", then there is very little chance of a collision.")

#text("Very informally, you can think of a d-dimensional space as having ")#mi("\\infty^d")#text(" elements, and an r-dimensional subspace as having ")#mi("\\infty^r")#text(" elements. And, as with birthday, if you pick two random subspaces of dimension r bigger than d/2, there is necessarily a non-trivial intersection, whereas if you pick subspaces of dimension r less than d/2, there is almost surely no intersection except at the origin.")

#text("High-dimensional geometry has a number of unintuitive properties which distinguish it from low-dimensional geometry. One of them is that in very high dimensions, any two randomly chosen directions (or one deterministic direction and one random direction) are very very likely to be very close to orthogonal. (For instance, the angle between two random vectors in ")#mi("{\\Bbb R}^d")#text(" is going to deviate by more than 1 degree from a right angle with a probability something like ")#mi("(0.99)^d")#text(" – i.e. it is very likely to deviate in low dimension but almost never deviates in very high dimensions.) This fact is also related to the law of large numbers.")

#text("Randomwalker: There may well be a connection between parity-with-noise and sparsest-solution-of-linear-systems, but the connection I had in mind was that one can encode the subset-sum problem as a very special case of the sparsest-solution-of-linear-systems problem, showing that the latter problem is NP-hard in the worst case. On the other hand, it seems that this problem can be solved in polynomial time by basis pursuit in the “average case” for suitable definitions of “average case”. As I understand it, this is a fairly typical state of affairs (a general class of problems being NP-hard worst-case but P or P# in average-case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5150e489401cc242bc331e20397612a6d9586d3c9438f9969deb73b65a57acc9-0e5929c5f22860ee29c5223a5b2506d8a7f937886c6ad506e33a9cc48b867db8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of techbuffet")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-471")[#strong[#text("techbuffet")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Thanks for the great explanation. I have heard about compressed sensing for a while, but could not quite wrap my mind around it. I think I understand the basic idea now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ostrowski lecture: The uniform uncertainty principle and compressed sensing « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-478")[#strong[#text("Ostrowski lecture: The uniform uncertainty principle and compressed sensing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2007")])]

#text("[…] mentioned in the previous post here, compressed sensing is a relatively new measurement paradigm which seeks to capture the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3053fac5bbffe85fc1136e7e308f4798885008ae6d01ead6fecd80a8f28d4cf-dd9b81c109425c15fc8341933eaec4744d0e479a9c3dd2ef6530e6f9160c683e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of piotr")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-492")[#strong[#text("piotr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2007")])]

#text("Nice post! One comment: in addition to camera, MRI, astronomy, and linear coding, random linear measurements also have applications to so-called “data stream algorithms”. For example, the signal x could represent a pattern of traffic passing through a network router, with x_i being the number of packets, say, going to destination i. Since x is very high-dimensional, one cannot really store it explicitly. However, one can store the measurement vector Ax instead, and use it to recover an approximation of x. The linearity of measurements is crucial here, since it enables maintaining Ax under linear updates to x. E.g., if you see a new packet with destination i, you can easily compute A(x+e_i)=Ax + Ae_i from Ax. So everything stays in the measurement space, so to speak.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-511")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("Another comment. I was looking at the some of the most advanced work on modeling the brain, and there is an uncanny parallel (if not match) between at least one model of visual processing and compressed sensing.")

#text("T. Serre, A. Oliva and T. Poggio. A feedforward architecture accounts for rapid categorization. Proceedings of the National Academy of Science, 104(15), pp. 6424-6429, April 2007")

#link("http://www.pnas.org/cgi/content/abstract/104/15/6424?etoc")[#text("http://www.pnas.org/cgi/content/abstract/104/15/6424?etoc")]

#text("The model is a layered one where at every layer, cells respond to a specific and increasingly complex stimuli. The interesting bit is that the model shows, with painstaking parallel with current biology understanding, that it is in fact one way (no need to compute all the coefficients first and then threshold them) and moreover, at every step there is a random picking of some of the stimuli to be used by the next layer.")

#text("As stated in the abstract, the model “can predict the level and the pattern of performance achieved by humans on a rapid masked animal vs. non-animal categorization task.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c2216bdb817762c103638bac60e61978daa232c45bcd12a75b8698aa6f66322-48540236e0f55e6efa25b64a360bcc2cba854a83938eba97d749eccc1ddbf3f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-531")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2007")])]

#text("Fascinating thread!")

#text("Re astronomy, here’s an interesting proposal: ")#link("http://news.bbc.co.uk/2/hi/science/nature/6566317.stm")[#text("http://news.bbc.co.uk/2/hi/science/nature/6566317.stm")]#text(" One cannot but ask: what if these miniature gliders carried a single pixel camera and had some way to communicate with an orbiter which could relay information back to Earth?")

#text("Many years ago, I coauthored an argument which I hoped to present to ESA, via a private thinktank, to the effect that it makes good sense to move toward space exploration missions using a highly redundant fleet of small, simple, relatively cheap spacecraft each designed to do just one thing. As far as I know, this never went anywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris forrester")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-556")[#strong[#text("chris forrester")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2007")])]

#text("regarding compression.. do you think that it would be possible to create an infinitely compressible system using arbitrary data?")

#text("that is.. do you think you could utilize a stream to provide a folding mechanism for the data itself?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a67b6424937d504308798a4718327166da7d087b74ad3b71386483dfeada8828-b900c7135c429d7b688c851a213151766f04cba1b4ffbacdec8cf61162ec319e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RD")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-608")[#strong[#text("RD")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2007")])]

#text("Great writeup!!")

#text("But I do not quite understand the following:")

#text("Sadly, there does not seem to be an")#linebreak()#text(" application to P\\neq NP; ………… be")#linebreak()#text(" treated by the above methods")

#text("Terry: Could you please give a few more details?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")])]

#text("Dear RD,")

#text("Suppose you are given a matrix A and a vector b and want to solve the problem “find the sparsest vector x for which Ax=b”.")

#text("For certain matrices A (basically, those in which there are plenty of linear dependencies between a relatively small number of columns) this problem is NP-hard.")

#text("What the work of ourselves and others shows is that for other types of matrices A (where the columns are close to being orthogonal, e.g. random matrices typically satisfy this), the problem can be solved in polynomial time by linear programming methods.")

#text("Unfortunately, these two classes of matrices seem to be totally disjoint, so there is no obvious progress on ")#mi("P \\neq NP")#text(" here. As I said in an earlier comment, this situation (NP-hard in worst case, P in average case) seems to be rather common.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/938039d8e9e20d3403dabd878685e0a6cc6fc81b9b3309ceae13ebeab92a29d2-85d65adada1ad6d83af1efd1431260184f7ed203e46c2001c73e4c1c44fd9983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mttpd")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-74746")[#strong[#text("mttpd")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2011")])]

#text("Just a quick question — regarding the comment: “As I understand it, this is a fairly typical state of affairs (a general class of problems being NP-hard worst-case but P or P# in average-case).”")

#text("Is it in any way related to smoothed analysis?")#linebreak()#text(" ")#link("http://www.cs.yale.edu/homes/spielman/SmoothedAnalysis/framework.html")[#text("http://www.cs.yale.edu/homes/spielman/SmoothedAnalysis/framework.html")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a67b6424937d504308798a4718327166da7d087b74ad3b71386483dfeada8828-b900c7135c429d7b688c851a213151766f04cba1b4ffbacdec8cf61162ec319e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RD")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-633")[#strong[#text("RD")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")])]

#text("Terry: Thanks for the explanation.")

#text("I understand this is a new area and there are possibly")#linebreak()#text(" many open problems.")

#text("Is there any particular (doable!) open problem that you think is interesting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0061af294523e8f94760b71e89c75ee705e544641460f871625488e690ce10fe-12b466ba4777c9e622b91b2a713def2b6ca27814859ea6628d7a7bed55305f97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-644")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")])]

#text("Dear Prof. Tao,")

#text("Thanks so much for taking time to write this post! I feel it is very helpful.")

#text("Regarding your comment on high-dimensional geometry, a couple of months ago, I was actually playing around with the angle \\theta between one fixed vector and another randomly picked vector on n-dim unit ball and trying to calculate the probability Pr( cos(\\theta)>1/n^(0.5-\\epsilon)), I found when \\epsilon>0, this probability decays to zero exponentially fast with n, and if \\epsilon")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris forrester")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-649")[#strong[#text("chris forrester")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")])]

#text("What about using arbitrary data’s harmonic alignments with one another to prove P != NP? If you’re into this idea, please check out ")#link("http://nimbusgear.wordpress.com/")[#text("http://nimbusgear.wordpress.com/")]#linebreak()#text(" to get an idea of what i’m talking about.")#linebreak()#text(" From what i can tell, because of the abstraction levels, this is a really good way of representing the problem in terms of something that is incredibly easy to check, but may take forever to determine the answer of.")#linebreak()#text(" It’s a.. holistic.. approach. My own application was to produce a mechanism for the infinite compression of arbitrary data, and i think the mechanism i discovered/shaped will also be of use in the P != NP problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Does this potentially provide a better way than bicubic interpolation to resize an image from N x N to 2N x 2N? If so, maybe Photoshop should include it as a filter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Dear Andy,")

#text("There is a glitch in the commenting parser: if you have a post which contains both > and < then everything in between gets interpreted as HTML and thus disappears. You can use &gt; and &lt; instead.")

#text("Dear Chris: there are significant theoretical limits as to lossless compression of arbitrary data, even if one asssumes infinite computational time. For instance, for digital data, ")#link("http://en.wikipedia.org/wiki/Lossless_data_compression")[#text("a simple counting argument")]#text(" shows that any lossless compression algorithm must lengthen at least some input data. For analog data one can do something similar once one realises that measurement error (and other sources of error) are non-zero. (Incidentally, this is a common pitfall regarding attempts to prove P=NP; if one wants to run an algorithm using an analog computer, the algorithm will only be equivalent to a P algorithm if _all_ parameters are polynomial size; not just the data input and running time, but also the measurement accuracy, the energy consumption, temperature, etc.)")

#text("Dear Anonymous: In principle one could use compressed sensing techniques for image resizing, but I believe that special-purpose image processing tools customised for this specific task will perform better. Also, the N x N array of measurements do not look particularly “random” with respect to the wavelet basis that one expects the image to be sparse or compressible with respect to, and so these algorithms will not perform as well as they do in the random measurement case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0061af294523e8f94760b71e89c75ee705e544641460f871625488e690ce10fe-12b466ba4777c9e622b91b2a713def2b6ca27814859ea6628d7a7bed55305f97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-664")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Dear Prof. Tao,")

#text("Sorry for the above message and thanks a lot for the help :) I will just type my question again:")#linebreak()#text(" Regarding your comment on high-dimensional geometry, a couple of months ago, I was actually playing around with the angle ")#mi("\\theta")#text(" between one fixed vector and another randomly picked vector on n-dim unit ball and trying to calculate the probability")#linebreak()#text(" ")#mi("{\\mathbb P}( \\cos(\\theta) \\geq 1/n^{0.5-\\epsilon})")#text(", I found when ")#mi("\\epsilon > 0")#text(", this probability decays to zero exponentially fast with n, and if ")#mi("\\epsilon < 0")#text(", it goes to one. Only if ")#mi("\\epsilon=0")#text(", there is a nontrivial probability around 0.1576 and 0.1675 asymptotically. I couldn’t get a good interpretation of what is happening when dimension is high and why ")#mi("\\epsilon=0")#text(" is special. It looks like the surface area of the unit ball is becoming more and more concentrated around the equator when n grows big. I’m interested to know more about its relationship to the law of large numbers and more generally about high dimensional geometry. It will be great if you could point me to any reference or explain briefly. Thanks so much!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecbfae6df64a2d8b5f8315004942f1a1f3312d6f3860604c1d0caab0b4acbbea-2d33ac942547a304c3976622df5433a63026780a8c24a5f9206cd0d4e9fe2fb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Denis Charles")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-667")[#strong[#text("Denis Charles")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Nice article! You are right about the gulf between the worst-case hardness and average case hardness of a problem. To my knowledge the widest such gulf (for a natural problem) occurs for the computation of Groebner bases. This problem is known to be EXPSPACE-hard in the worst case (best time bounds would be doubly exponential), whereas (conjecturally) on average the problem is polynomial time. The conjecture being a conjecture of Bayer on the Mumford regularity of ideals. I would be interested if anyone knows of a wider gulf for a natural problem. It is easy to create artificial problems where the worst case is at least as hard as the Halting problem and the average case is polytime by a technique called padding but that is uninteresting.")

#text("On the other hand there are natural problems where the average case hardness and worst case hardness are believed to coincide. A famous instance being approximating the shortest non-zero lattice vector in L_2 norm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-689")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Dear Andy,")

#text("If you fix one of the vectors to be, say, ")#mi("e_d")#text(", and use Euler angles, one soon sees that ")#mi("\\theta")#text(" has a probability distribution of ")#mi("c_n \\sin^{(n-2)/2} \\theta\\ d\\theta")#text(" for some constant ")#mi("c_n")#text(", and so by changing variables ")#mi("t := \\cos \\theta")#text(" has a probability distribution of ")#mi("c_n (1-t^2)^{(n-3)/2}\\ dt")#text(". Note that this is a constant measure for n=3; this is a theorem of Archimedes, who liked it so much ")#link("http://scidiv.bcc.ctc.edu/Math/ArchimedesTombstone.html")[#text("he engraved it on his tombstone")]#text(". (It is also related to symplectic geometry, toric varieties, and moment mappings, but that’s another story.) When n is large, this measure concentrates in the region ")#mi("t = O(n^{-1/2})")#text(", and in this region we can approximate ")#mi("(1-t^2)^{(n-3)/2} \\approx e^{-nt^2/2}")#text(". This means that asymptotically, ")#mi("\\cos \\theta")#text(" is normalised around the origin with a variance of ")#mi("1 / n")#text(". If you play around with the erf function that probably gives you a close match to your numerical results.")

#text("The connection with the central limit theorem arises when instead of considering the cosine of the angle between two unit vectors, one considers the closely related problem of computing the dot product between two independent normalised Gaussian vectors ")#mi("x = \\frac{1}{\\sqrt{n}}(x_1,\\ldots,x_n)")#text(" and ")#mi("y = \\frac{1}{\\sqrt{n}}(y_1,\\ldots,y_n)")#text(", where the ")#mi("x_i, y_i")#text(" are iid standard Gaussians of mean zero and variance 1. The CLT easily shows that ")#tao-math("\\left|x\\right|^2", block: false)#text(" and ")#tao-math("\\left|y\\right|^2", block: false)#text(" are almost normally distributed with mean 1 and variance ")#mi("O(1/n)")#text(", while ")#mi("x \\cdot y")#text(" is almost normally distributed with mean zero and variance ")#mi("O(1/n)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chris forrester")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-693")[#strong[#text("chris forrester")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Indeed, i did much studying as to pidgeons and holes and the impossibility of arbitrary compression of information.")

#text("however, to expand that specific argument entirely, one would have to say that there could be no meta-algorithms that are composed of multiple ways of encoding the information structures. literally, that there would be a balance of informational structures that couldn’t be compressed by any algorithm, whatsoever.")

#text("this, i’ve found, is not a true precept, since we have something that can convert information from one form to another form, losslessly.")#linebreak()#text(" in such a manner, by utilizing the abstraction of the mathematical base switch, to provide an alternative look at the information without needing to encode an entirely new method of observation (re: algorithm), we find a meta-construct already there in the perspective of how to view the information at all.")

#text("my experiment runs like so:")#linebreak()#text(" Taking F as the arbitrary data, somewhere in the hundreds of digital base 2 bits.")

#text("Since the information is already digitally encoded, it forms a digital wave when you take a look at from the vantage point of a specific base, lets call that E. There is then A, the number of elements involved which form the digital waveshape itself.")

#text("This number of elements has associated with it its own limitations, which are namely the number of integer bases that produce that many elements from the arbitrary information given.")

#text("Using base 2 for E is in fact the worse case scenario, since the next step involves a sort of skimming over the digital waveform.")

#text("That is, to percieve the digital signature as a waveform, one finds that for a specific F, there are multiple E’s, a set Edelta, to percieve F which results in A digits.")

#text("These A digits in bases Edelta, naturally, totally compose F, with zero loss.")

#text("Now, there is an offset, O, which is the same for all A digits that are in bases Edelta. Above that offset, for all A digits, is information in base D.")

#text("At some point, for a specific Efinal and Afinal, there is a waveform D which, combined with the offset O, the information to specify E and the information to specify A, is within ‘compression’ range.")

#text("For lower density F information, this is not that useful. However, the entire algorithm can be run *per binary digit*, which is where the F from Cloud C comes into play. By keeping the entirety of the information that you would want to compress, say an mp3 file, in cloud C, and always moving one single bit at a time to F, then running the algorithm on F, one always finds a way to compress C.")

#text("This of course hinges upon the fact that we have more than we originally thought we had:")

#text("One: that the cloud C, and thusly F, is of suitable length. this is a result of the offset O needing a specific number of bits to encode in the first place. Thus, A must be 3 or higher, and since it is Edelta being checked, this needs to have a suitable number of opportunities to be able to reexpress the information in F.")

#text("Result: yes. information is not infinitely compressible, since at some point, base 2 becomes the most efficient way of perceiving the information. however, this is only a few hundred bits or less. for *anything* over this, there is a guaranteed ‘compression’ by means of digital wave re-expression methodology.")#linebreak()#text(" Thusly, the pidgeons and holes theory does not pan out, since we already have something in the informational system itself that allows for lossless reorientation of the information. And, we can choose between how the information is represented on a case-by-case basis, which reveals, as the possibilities increase, an increasing number of ways to choose between the representations.")

#text("The reason i come up to the P and NP thing with this is that checking per binary bit, all ranges of A, Edelta, is definitely deterministic. To say when the actual D + O + E + A is, bit-wise, less than F, however is non-deterministic. All that can be proved is to say that, eventually, it will happen. At this point, D + O + E + A can even be moved back into C with an ‘expand fold’ marker.")

#text("Thus, folding information, in terms of spacial harmonics.")

#text("To summarize:")

#text("Re-expression utilizing very high bases to recompose the information into different formats.")

#text("Sorting through those recompositions to find minimal change of relative heights, as percieved in two dimensions.")

#text("Encoding the change in heights, the offset, the bases of both the height changes and the offset plus the height changes, and the number of digits utilized.")

#text("In terms of algorithms, since it’s never attempted to fold the non-re-expressional informational spectrum, and guaranteed to always find foldable structures in the larger spectrum, it reveals an infinite compression mechanism, of higher density information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dbdfd86ba1cc90f56b9cb1850f1cf72d4359c8dbd84f790c5c2379a762bbde3-6cc36b87b87d8c35b8ae4809484c32485a04ff3d757a4f8ea9f8442c8d049414.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-714")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2007")])]

#text("Andy:")

#text("The best-known application in high-dimensional geometry of the phenomenon you’ve observed is Dvoretzky’s theorem (in a given proof by Vitali Milman in the early 1970s). Possibly the most accessible reference for this is Lectures 7-9 of K. Ball, “An elementary introduction to modern convex geometry”, in ")#link("http://www.cambridge.org/catalogue/catalogue.asp?isbn=9780521629621")[#text("this volume")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/197ec5bcaa3bbea3eea538dc30d7a312391b2d4f786d6e3bbdb0734912861c59-9ffb32729d224d11695f83fce40135e575da721c3073870421acc7d40678137e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kaleberg")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-724")[#strong[#text("Kaleberg")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2007")])]

#text("This approach reminds me of early X ray astronomy sensors, before they developed grazing lenses. They used a sheet of X ray blocking metal with a random pattern of holes punched in it and rotated the sheet while collecting a single pixel of data, the overall intensity. I think they could also move the sheet further and closer to the single sensor in a sort of “trombone” arrangement. I never worked with this, but I had a roommate who worked on the SAS-C team, and he tried explaining how the sensor, or perhaps an improved sensor, might work.")

#text("I’m not sure of the mathematics of this approach, since their “wavelet basis” was rather simple, and not completely random. Still, they did get the sensor count down to one, they traded off satellite based computing for ground computing, and they did get some neat images, included Cygnus X-1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a90c327f4eaae1d5e54a92f7e0cce0ba8268fd1b818d96a210c188670d15852-80ff7cb84c381fa187a7f5bacee51b8af295f7af183386d9dddd695cd0ca15c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andres Corrada-Emmanuel")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-731")[#strong[#text("Andres Corrada-Emmanuel")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2007")])]

#text("Thank you for this introduction to compressed sensing. I want to point out that the statement on the applicability of this technique to sensor networks needs to be tempered by an actual comparison between the power requirements of on-board processing versus transmission of data. For some sensor networks the greater cost is transmission. This will increasingly become so in the future since network bandwidths are physically limited or turned off by users that want ‘information’ not sensor data. In cases like that, it would pay to process data on-board and then relay extracted information rather than raw data itself. For example, an aerial mapping appliance would process all aerial images on-board and relay a map of the area with a ortho-rectified image on top. This would give a user all the information they require to do an impressive number of tasks and would have a compression ratio running in the 1000:1 range.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-737")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2007")])]

#text("Dear Andres,")

#text("Thanks for your comments! Compressed sensing actually has comparable transmission costs to traditional processed sensing methods; I think you might have been comparing processed sensing with ")#emph[#text("non-compressed")]#text(" non-processed sensing, which indeed would be inefficient on many levels.")

#text("Suppose for instance that a traditional sensor in a sensor network collects 1,000,000 bytes of data, processes the data on-board, and extracts 1,000 bytes to transmit, giving the 1000:1 compression ratio you mention. I agree that the non-compressed non-processed sensing alternative of simply transmitting all 1,000,000 bytes collected without any on-board processing would be expensive and inefficient. However, this is not what compressed sensing does; instead of collecting so much data, it would only collect, say, 3,000 bytes of measurements to transmit, and computers at the user end will extract the 1,000 bytes of processed data they need from the 3,000 transmitted bytes via one of the known data recovery algorithms for compressed sensing. Thus the data transmission costs in this case are comparable to a traditional sensor, but the data collection and processing costs are much lower. (It may seem in this example that the compressed sensing method requires three times as much data transmitted, but actually the gap can be a bit lower in noisy environments, because the traditional sensor will need to lengthen (and possibly retransmit) the data to enable error detection or correction, whereas the compressed sensing data will not need any such lengthening, as there is already significant redundancy contained within the transmitted data, and the recovery algorithms are robust with respect to loss or corruption of a small fraction of this data.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d33b5a8b49301e4ab62bb930e5939e770c4c01ae7975aa899337c4b044801a5-546f553783cfc78e6fcf023d5761b297281ae1f3a6203bf0cb74ab99c1a6464c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sacha")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-753")[#strong[#text("Sacha")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2007")])]

#text("“It’s an interesting phenomenon to me that so many successful people have an unusually broad range of interests, and somehow find the time to pursue them. I believe this may be a help, rather than a hindrance, since having broad interests is helpful both in finding good research topics and in solving them. (I might worry too, if this blog got filled up with the sort of post we see here, but that doesn’t seem likely.)”")

#text("Of course it’s great to have a broad range of interests – it helps keep one’s mind active and alert!")

#text("Why would anyone be concerned if Terry started filling his blog with non-technical or non-mathematically related work? That sounds snobbish to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0061af294523e8f94760b71e89c75ee705e544641460f871625488e690ce10fe-12b466ba4777c9e622b91b2a713def2b6ca27814859ea6628d7a7bed55305f97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-760")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2007")])]

#text("I don’t want to take too much space here, but really want to thank Terry and Mark for their comment and help!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f4973e875503d76738439a7ec101ab7d214f96540614281623391d158b20fd9-848f83ef8eb1d071b1ac1848c853f693ed625d39731fa5f5dfecfdf0383338ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Govind")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-1080")[#strong[#text("Govind")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2007")])]

#text("Thank you Prof. Tao for the blog. It did help me to understand the bascis easily so that now I can attack the real leterature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fe963b2a55ecee7c39fed8cb113960d5bb787ac571aca0af244db60a3b1e5d4-c8ac9c9e74e42dce90793e1c194fbf5dff3823de7bcee797452832783afedda7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qling")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-1803")[#strong[#text("qling")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")])]

#text("Dear Prof. Tao,")

#text("Thanks for your excellent story here. I am studying compressed sensing now and encountering some problem. My focus is on the required sampling size for random Fourier measurement ensemble to recover the sparse signal with l-1 minimization. [1] gave an estimation K=O(M(logN)^6), where K is the sampling size, M is the sparsity of the signal, and N is the dimension of the signal. [2] provided another estimation K=O(MlogN) by assuming a Bernoulli model. In fact, I am not sure if it is a universal conclusion. [3] introduced the result in [2] by saying:")

#text("‘The conjectured optimal estimate would be K=O(MlogN), which is known to hold for nonuniversal measurements, i.e. for one sparse signal f and for a random set \\Omega (the cardinality of \\Omega is K).’")

#text("But this comment makes me even more confused … In [4], the authors directly pointed out K=O(MlogN) without giving any further explanation. So I hope you can help me to clarify this question.")

#text("Thanks for your time!")

#text("[1] Candes E, Tao T: Near-optimal signal recovery from random projections: universal encoding strategies")#linebreak()#text(" [2] Candes E, Romberg J, Tao T: Robust uncertainty principles: exact signal reconstruction from highly incomplete frequency information")#linebreak()#text(" [3] Rudelson M, Vershynin R: Sparse reconstruction by convex relaxation: Fourier and Gaussian measurements")#linebreak()#text(" [4] Candes E, Romberg J: Practical signal recovery from random projections")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-1827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2007")])]

#text("Dear Qing Ling,")

#text("There is a distinction between uniform recovery and non-uniform")#linebreak()#text(" recovery. A set of frequencies Omega can uniformly recover sparse")#linebreak()#text(" signals if it can recover ")#emph[#text("all")]#text(" signals of a given sparsity. If it")#linebreak()#text(" can only recover ")#emph[#text("almost all")]#text(" signals of a given sparsity (i.e. it can")#linebreak()#text(" recover randomly chosen sparse signals with high probability) then we")#linebreak()#text(" only have non-uniform recovery.")

#text("The results of [1] and [3] give uniform recovery, while [2] gives")#linebreak()#text(" non-uniform recovery, so these two types of results are not directly")#linebreak()#text(" comparable.")

#text("See also my page")

#link("http://www.math.ucla.edu/~tao/preprints/sparse.html")[#text("http://www.math.ucla.edu/~tao/preprints/sparse.html")]

#text("for some further discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Open question: deterministic UUP matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-3451")[#strong[#text("Open question: deterministic UUP matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2007")])]

#text("[…] July 2nd, 2007 in question This problem in compressed sensing is an example of a derandomisation problem: take an object which, currently, can only be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-3513")[#strong[#text("What is angular momentum (in quantum physics)? « As I know…")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2007")]

#text("[…] (in quantum physics)? Posted by hoahoangphuong under Quantum physics This problem in compressed sensing is an example of a derandomisation problem: take an object which, currently, can only be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-3986")[#strong[#text("Simfish / InquilineKea’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2007")]

#text("[…] April 13th, 2007 at 10:33 pm […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20810bd1ad51b757d8ae0f6b574531a2fc55a9fcb62c70c6727541f57a13e66a-fe604e19b2816b9f768ae142087c5d8096d4695c005a19e0e2ee2e80932eae8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bhauth")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4644")[#strong[#text("bhauth")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2007")])]

#text("Physical application of desired transforms would be as effective as digital application. “Similar” transforms would be useful in many cases as well. Collected (complete) data must also often be transformed to be useful. (synthetic aperture radar, CAT scans, GRENOUILLE, etc) However, if the measurements are of *random* transforms of the data, then they bear no special relation to the desired compressed data. That means that every piece of the data can be recovered equally well (statistically speaking) as the “desired” pieces. Information theory tells us we cannot get something for nothing. The low correlations mean data will be degraded, as it has finite precision. Information content of a set of numbers is equal to the effective number of digits of them. How is compressed sensing more than a randomly chosen trade of number quality for number quantity?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20810bd1ad51b757d8ae0f6b574531a2fc55a9fcb62c70c6727541f57a13e66a-fe604e19b2816b9f768ae142087c5d8096d4695c005a19e0e2ee2e80932eae8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bhauth")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4648")[#strong[#text("bhauth")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("If the idea is that many single pixel cameras are fitted with masks that approximate wavelet transforms, then")

#text("Practically speaking, this is less effective than an equivalent cost in standard cameras.")

#text("You can’t do wavelet transforms without subtraction, which needs coherent light.")

#text("The compression part of image compression is not done by wavelets. The wavelets concentrate smoothness that can then be compressed by other means taking advantage of that smoothness. There is no way to bring the smoothness together in a single pixel camera, so if you could do the wavelet transforms with masks, and the cameras were cheap enough to be worthwhile, you would still be saving no bits unless the cameras communicate before transmission.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4661")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("Dear bhauth,")

#text("From an information-theoretic perspective, the reason why compressed sensing is a “win” is that the signals one is studying (e.g. images) have special structure which reduces their entropy be significantly less than the number of bits used to store them (before compression). For instance, in the imaging example given above, an image needs 2 million bytes to store it (in uncompressed form), but the structure of the image is such that only 100,000 bytes of information are needed to reconstruct the image to within acceptable levels of error. Because of this, it is information-theoretically possible to make, say, 300,000 random measurements and not lose any further signal quality.")

#text("You can find more about the single-pixel camera at the Rice web page:")

#link("http://www.dsp.ece.rice.edu/cs/cscamera/")[#text("http://www.dsp.ece.rice.edu/cs/cscamera/")]

#text("The masks are not simulating wavelet transforms; instead, they are simulating an inner product with a random 0-1 vector. No subtraction is required.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20810bd1ad51b757d8ae0f6b574531a2fc55a9fcb62c70c6727541f57a13e66a-fe604e19b2816b9f768ae142087c5d8096d4695c005a19e0e2ee2e80932eae8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bhauth")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4693")[#strong[#text("bhauth")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("Well, you should be cautious when telling a Fields medalist something is unworkable, but video compression is my specialty and my understanding is that while linear transforms can compress images in special cases with carefully chosen (*non* random) bases, they are not useful for general purpose image compression. In practical terms that would mean that while you could reconstruct images from your single pixel camera they would statistically be no better than images from a standard camera of resolution equal to the number of measurements. As far as I can tell, that’s the case with the results on that page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4715")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("Dear bhauth,")

#text("I think you are confusing compressed sensing with the more traditional thresholded transform coding which appears for instance in the JPEG-2000 protocol. There, one takes many wavelet coefficients but then only retains the largest ones by applying a thresholding to obtain the compressed output. In compressed sensing, one bypasses the thresholding step and makes the compressed measurements directly, using random measurements rather than wavelet ones. I agree that it is unintuitive, but the random linear measurements do in fact capture almost as much information as a comparable number of carefully chosen (thresholded) wavelet measurements. From an information-theoretic perspective it is not so surprising; an image which can be compressed down to a 100K file with acceptable losses in quality has roughly 100K bytes of entropy and thus should, in principle, be recoverable (with comparable quality) from slightly more than 100K random measurements. The remarkable thing is that (as long as one over-samples by a factor of three or so) that this recovery can be achieved in a practical amount of computer time.")

#text("Some examples of this applied to actual images can be seen at")

#link("http://www.acm.caltech.edu/l1magic/examples.html")[#text("http://www.acm.caltech.edu/l1magic/examples.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-40985")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("I really wonder if CS would work for stationary sources. This could be the key to link entropy with sparsity. Images are non stationary.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20810bd1ad51b757d8ae0f6b574531a2fc55a9fcb62c70c6727541f57a13e66a-fe604e19b2816b9f768ae142087c5d8096d4695c005a19e0e2ee2e80932eae8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bhauth")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4725")[#strong[#text("bhauth")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("A minimum-norm algorithm? That is something quite different from what I understood you to be saying in this post. I’ll think about that for a bit. Computational feasibility isn’t so surprising, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20810bd1ad51b757d8ae0f6b574531a2fc55a9fcb62c70c6727541f57a13e66a-fe604e19b2816b9f768ae142087c5d8096d4695c005a19e0e2ee2e80932eae8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bhauth")]], [#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/comment-page-1/#comment-4730")[#strong[#text("bhauth")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("OK, the norm you’re using isn’t the optimal computationally feasible norm for images in general. I’ll think about what better ones would be some more when I’m less busy.")
]
