// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T07:21:45.345245+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The two-ends reduction for the Kakeya maximal conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The two-ends reduction for the Kakeya maximal conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/")[#text("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this post I would like to make some technical notes on a standard reduction used in the (Euclidean, maximal) Kakeya problem, known as the ")#emph[#text("two ends reduction")]#text(". This reduction (which takes advantage of the approximate scale-invariance of the Kakeya problem) was introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("by Wolff")]#text(", and has since been used many times, both for the Kakeya problem and in other similar problems (e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1969206")[#text("by Jim Wright and myself")]#text(" to study curved Radon-like transforms). I was asked about it recently, so I thought I would describe the trick here. As an application I give a proof of the ")#mi("{d=\\frac{n+1}{2}}")#text(" case of the Kakeya maximal conjecture.")

#metadata(none) <tao-10ebbbfde958372ebd31>

#text("As discussed in the ")#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/")[#text("previous post")]#text(", the ")#emph[#text("Kakeya maximal function conjecture")]#text(" in ")#mi("{{\\mathbb R}^n}")#text(" can be formulated as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Kakeya maximal function conjecture)")]#text(" If ")#mi("{0 < \\delta < 1}")#text(", ")#mi("{1 \\leq d \\leq n}")#text(", and ")#mi("{T_1,\\ldots,T_N}")#text(" is a collection of ")#mi("{\\delta \\times 1}")#text(" tubes oriented in a ")#mi("{\\delta}")#text("-separated set of directions, then ")#metadata(none) <tao-d32f293e971b0859eed0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sum_{i=1}^N 1_{T_i} \\right\\|_{L^{d/(d-1)}({\\mathbb R}^n)} \\ll_\\epsilon (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon}", block: true)]]

#text("for any ")#mi("{\\epsilon > 0}")#text(".")
]

#text("A standard duality argument shows that ")#link(<tao-d32f293e971b0859eed0>)[#text("(1)")]#text(" is equivalent to the estimate")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^N \\int_{T_i} F \\ll_\\epsilon (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon} \\left\\|F\\right\\|_{L^d({\\mathbb R}^n)}", block: true)]]

#text("for arbitrary non-negative measurable functions ")#mi("{F}")#text("; breaking ")#mi("{F}")#text(" ")#link("http://www.tricki.org/article/Control_level_sets")[#text("up into level sets")]#text(" via ")#link("http://www.tricki.org/article/Dyadic_decomposition")[#text("dyadic decomposition")]#text(", this estimate is in turn equivalent to the estimate ")#metadata(none) <tao-5fe8c65d03fc7a891fe4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{i=1}^N \\left|E \\cap T_i\\right| \\ll_\\epsilon (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon} \\left|E\\right|^{1/d}", block: true)]]

#text("for arbitrary measurable sets ")#mi("{E}")#text(". This estimate is then equivalent to the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Kakeya maximal function conjecture, second version)")]#text(" ")#metadata(none) <tao-d164ad30cd61bbb2b32a>#text(" If ")#mi("{0 < \\delta, \\lambda < 1}")#text(", ")#mi("{1 \\leq d \\leq n}")#text(", ")#mi("{T_1,\\ldots,T_N}")#text(" is a collection of ")#mi("{\\delta \\times 1}")#text(" tubes oriented in a ")#mi("{\\delta}")#text("-separated set of directions, and ")#mi("{E}")#text(" is a measurable set such that ")#tao-math("{\\left|E \\cap T_i\\right| \\geq \\lambda \\left|T_i\\right|}", block: false)#text(" for all ")#mi("{i}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left|E\\right| \\gg_\\epsilon (N \\delta^{n-1}) \\lambda^d \\delta^{n-d+\\epsilon}", block: true)]]

#text("for all ")#mi("{\\epsilon > 0}")#text(".")
]

#text("Indeed, to deduce ")#link(<tao-5fe8c65d03fc7a891fe4>)[#text("(2)")]#text(" from Conjecture ")#link(<tao-d164ad30cd61bbb2b32a>)[#text("2")]#text(" one can perform another dyadic decomposition, this time based on the dyadic range of the densities ")#tao-math("{\\left|E \\cap T_i\\right|/\\left|T_i\\right|}", block: false)#text(". Conversely, ")#link(<tao-5fe8c65d03fc7a891fe4>)[#text("(2)")]#text(" implies Conjecture ")#link(<tao-d164ad30cd61bbb2b32a>)[#text("2")]#text(" in the case ")#mi("{N \\delta^{n-1} \\sim 1}")#text(", and the remaining case ")#mi("{N \\delta^{n-1} \\ll 1}")#text(" can then be deduced by the random rotations trick (discussed in ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("this earlier post")]#text(").")

#text("We can reformulate the conjecture again slightly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (Kakeya maximal function conjecture, third version)")]#text(" ")#metadata(none) <tao-110a975473206abdde72>#text(" Let ")#mi("{0 < \\delta, \\lambda < 1}")#text(", ")#mi("{1 \\leq d \\leq n}")#text(", and ")#mi("{T_1,\\ldots,T_N}")#text(" is a collection of ")#mi("{\\delta \\times 1}")#text(" tubes oriented in a ")#mi("{\\delta}")#text("-separated set of directions with ")#mi("{N \\sim \\delta^{1-n}}")#text(". For each ")#mi("{1 \\leq i \\leq N}")#text(", let ")#mi("{E_i \\subset T_i}")#text(" be a set with ")#tao-math("{\\left|E_i\\right| \\geq \\lambda \\left|T_i\\right|}", block: false)#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{i=1}^N E_i\\right| \\gg_\\epsilon \\lambda^d \\delta^{n-d+\\epsilon}", block: true)]]

#text("for all ")#mi("{\\epsilon > 0}")#text(".")
]

#text("We remark that (the Minkowski dimension version of) the Kakeya set conjecture essentially corresponds to the ")#mi("{\\lambda=1}")#text(" case of Conjecture ")#link(<tao-110a975473206abdde72>)[#text("3")]#text(", while the Hausdorff dimension can be shown to be implied by the case where ")#mi("{\\lambda \\gg \\frac{1}{\\log^2 1/\\delta}}")#text(" (actually any lower bound here which is dyadically summable in ")#mi("{\\delta}")#text(" would suffice). Thus, while the Kakeya set conjecture is concerned with how small one can make unions of tubes ")#mi("{T_i}")#text(", the Kakeya maximal function conjecture is concerned with how small one can make unions of ")#emph[#text("portions")]#text(" ")#mi("{E_i}")#text(" of tubes ")#mi("{T_i}")#text(", where the density ")#mi("{\\lambda}")#text(" of the tubes are fixed.")

#text("A key technical problem in the Euclidean setting (which is not present in the finite field case), is that the portions ")#mi("{E_i}")#text(" of ")#mi("{T_i}")#text(" may be concentrated in only a small portion of the tube, e.g. they could fill up a ")#mi("{\\delta \\times \\lambda}")#text(" subtube, rather than being dispersed uniformly throughout the tube. Because of this, the set ")#mi("{\\bigcup_{i=1}^N E_i}")#text(" could be crammed into a far tighter space than one would ideally like. Fortunately, the ")#emph[#text("two ends reduction")]#text(" allows one to eliminate this possibility, letting one only consider portions ")#mi("{E_i}")#text(" which are not concentrated on just one end of the tube or another, but occupy both ends of the tube in some sense. A more precise version of this is as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Two ends condition)")]#text(" Let ")#mi("{E}")#text(" be a subset of ")#mi("{{\\mathbb R}^n}")#text(", and let ")#mi("{\\epsilon > 0}")#text(". We say that ")#mi("{E}")#text(" obeys the ")#emph[#text("two ends condition")]#text(" with exponent ")#mi("{\\epsilon}")#text(" if one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap B(x,r)\\right| \\ll_\\epsilon r^\\epsilon \\left|E\\right|", block: true)]]

#text("for all balls ")#mi("{B(x,r)}")#text(" in ")#mi("{{\\mathbb R}^n}")#text(" (note that the bound is only nontrivial when ")#mi("{r \\ll 1}")#text(").")
]

#text("Informally, the two ends condition asserts that ")#mi("{E}")#text(" cannot concentrate in a small ball; it implies for instance that the diameter of ")#mi("{E}")#text(" is ")#mi("{\\gg_\\epsilon 1}")#text(".")

#text("We now have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Two ends reduction)")]#text(" ")#metadata(none) <tao-2669dd54b1ab9d3ffa70>#text(" To prove Conjecture ")#link(<tao-110a975473206abdde72>)[#text("3")]#text(" for a fixed value of ")#mi("{d}")#text(" and ")#mi("{n}")#text(", it suffices to prove it under the assumption that the sets ")#mi("{E_i}")#text(" all obey the two ends condition with exponent ")#mi("{\\epsilon}")#text(", for any fixed value of ")#mi("{\\epsilon > 0}")#text(".")
]

#text("The key tool used to prove this proposition is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Every set has a large rescaled two-ends piece)")]#text(" ")#metadata(none) <tao-23c8f1bdd488e9bc079b>#text(" Let ")#mi("{E \\subset {\\mathbb R}^n}")#text(" be a set of positive measure and diameter ")#mi("{O(1)}")#text(", and let ")#mi("{0 < \\epsilon < n}")#text(". Then there exists a ball ")#mi("{B(x,r)}")#text(" of radius ")#mi("{r = O(1)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap B(x,r)\\right| \\gg r^\\epsilon \\left|E\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap B(x^{\\prime},r^{\\prime})\\right| \\ll (r^{\\prime}/r)^\\epsilon \\left|E \\cap B(x,r)\\right|", block: true)]]

#text("for all other balls ")#mi("{B(x^{\\prime},r^{\\prime})}")#text(".")
]

#emph[#text("Proof:")]#text(" Consider the problem of maximising the quantity ")#tao-math("{\\left|E \\cap B(x,r)\\right| / r^\\epsilon}", block: false)#text(" among al balls ")#mi("{B(x,r)}")#text(" of radius at most the diameter of ")#mi("{E}")#text(". On the one hand, this quantity can be at least ")#tao-math("{\\gg \\left|E\\right|}", block: false)#text(", simply by taking ")#mi("{B(x,r)}")#text(" equal to the smallest ball containing ")#mi("{E}")#text(". On the other hand, using the trivial bound ")#tao-math("{\\left|E \\cap B(x,r)\\right| \\leq \\left|B(x,r)\\right| \\ll r^n}", block: false)#text(" we see that the quantity ")#tao-math("{\\left|E \\cap B(x,r)\\right| / r^\\epsilon}", block: false)#text(" is bounded. Thus the supremum of the ")#tao-math("{\\left|E \\cap B(x,r)\\right| / r^\\epsilon}", block: false)#text(" is finite. If we pick a ball ")#mi("{B(x,r)}")#text(" which comes within a factor of ")#mi("{2}")#text(" (say) of realising this supremum then the claim easily follows. (Actually one can even attain the supremum exactly by a compactness argument, though this is not necessary for our applications.) ")#mi("\\Box")

#text("One can view the quantity ")#mi("{r}")#text(" in the above lemma as describing the “width” of the set ")#mi("{E}")#text("; this is the viewpoint taken for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=1969206")[#text("my paper with Jim Wright")]#text(".")

#text("Now we prove Proposition ")#link(<tao-2669dd54b1ab9d3ffa70>)[#text("5")]#text(".")

#emph[#text("Proof:")]#text(" Suppose Conjecture ")#link(<tao-110a975473206abdde72>)[#text("3")]#text(" has already been proven (assuming the two ends condition with exponent ")#mi("{\\epsilon}")#text(") for some value of ")#mi("{d,n}")#text(", and some small value of ")#mi("{\\epsilon}")#text(". Now suppose we have the setup of Conjecture ")#link(<tao-110a975473206abdde72>)[#text("3")]#text(" without the two-ends condition.")

#text("The first observation is that the claim is easy when ")#mi("{\\lambda \\ll \\delta}")#text(". Indeed, in this case we can just bound ")#tao-math("{\\left|\\bigcup_{i=1}^N E_i\\right|}", block: false)#text(" from below the volume ")#tao-math("{\\lambda \\left|T_i\\right| \\sim \\lambda \\delta^{n-1}}", block: false)#text(" of a single tube. So we may assume that ")#mi("{\\lambda}")#text(" is much greater than ")#mi("{\\delta}")#text(".")

#text("Let ")#mi("{\\epsilon > 0}")#text(" be arbitrary. We apply Lemma ")#link(<tao-23c8f1bdd488e9bc079b>)[#text("6")]#text(" to each ")#mi("{E_i}")#text(", to find a ball ")#mi("{B(x_i,r_i)}")#text(" such that ")#metadata(none) <tao-c69e28f7e3751847918c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|E_i \\cap B(x_i,r_i)\\right| \\gg r_i^\\epsilon \\left|E_i\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|E_i \\cap B(x^{\\prime},r^{\\prime})\\right| \\ll (r^{\\prime}/r_i)^\\epsilon \\left|E_i \\cap B(x_i,r_i)\\right|", block: true)]]

#text("for all ")#mi("{B(x^{\\prime},r^{\\prime})}")#text(". From ")#link(<tao-c69e28f7e3751847918c>)[#text("(3)")]#text(" and the fact that ")#tao-math("{\\left|E_i\\right| = \\lambda \\left|T_i\\right| \\gg \\lambda \\delta^{n-1} \\gg \\delta^n}", block: false)#text(", as well as the trivial bound ")#tao-math("{\\left|E_i \\cap B(x_i,r_i)\\right| \\leq \\left|B(x_i,r_i)\\right| \\ll r_i^n}", block: false)#text(", we obtain the lower bound ")#mi("{r_i \\gg \\delta^{1+O(\\epsilon)}}")#text(". Thus there are only about ")#mi("{O(\\log \\frac{1}{\\delta})}")#text(" possible dyadic ranges ")#mi("{\\rho \\leq r_i \\leq 2\\rho}")#text(". Using the pigeonhole principle (refining the number ")#mi("{N}")#text(" of tubes by a factor of ")#mi("{\\log \\frac{1}{\\delta}}")#text("), we may assume that there is a single ")#mi("{\\delta^{1+O(\\epsilon)} \\leq \\rho \\ll 1}")#text(" such that ")#emph[#text("all")]#text(" of the ")#mi("{r_i}")#text(" lie in the same dyadic range ")#mi("{[\\rho, 2\\rho]}")#text(".")

#text("The intersection of ")#mi("{T_i}")#text(" with ")#mi("{B(x_i,r_i)}")#text(" is then contained in a ")#mi("{\\delta \\times O(\\rho)}")#text(" tube ")#mi("{\\tilde T_i}")#text(", and ")#mi("{\\tilde E_i := E_i \\cap \\tilde T_i}")#text(" occupies a fraction")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tilde E_i\\right|/\\left|\\tilde T_i\\right| \\gg r_i^\\epsilon \\left|E_i\\right|/\\left|\\tilde T_i\\right| \\gg \\delta^{O(\\epsilon)} \\lambda / \\rho", block: true)]]

#text("of ")#mi("{\\tilde T_i}")#text(". If we then rescale each of the ")#mi("{\\tilde E_i}")#text(" and ")#mi("{\\tilde T_i}")#text(" by ")#mi("{O( 1/\\rho )}")#text(", we can locate subsets ")#mi("{E^{\\prime}_i}")#text(" of ")#mi("{O(\\delta/\\rho) \\times 1}")#text("-tubes ")#mi("{T^{\\prime}_i}")#text(" of density ")#mi("{\\gg \\delta^{O(\\epsilon)} \\lambda/\\rho}")#text(". These tubes ")#mi("{T^{\\prime}_i}")#text(" have cardinality ")#mi("{\\delta^{1-n + O(\\epsilon)}}")#text(" (the loss here is due to the use of the pigeonhole principle earlier) and occupy a ")#mi("{\\delta}")#text("-separated set of directions, but after refining these tubes a bit we may assume that they instead occupy a ")#mi("{\\delta/\\rho}")#text("-separated set of directions, at the expense of cutting the cardinality down to ")#mi("{\\delta^{O(\\epsilon)} (\\delta/\\rho)^{1-n}}")#text(" or so. Furthermore, by construction the ")#mi("{E^{\\prime}_i}")#text(" obey the two-ends condition at exponent ")#mi("{\\epsilon}")#text(". Applying the hypothesis that Conjecture ")#link(<tao-110a975473206abdde72>)[#text("3")]#text(" holds for such sets, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_i E^{\\prime}_i\\right| \\gg_\\epsilon \\delta^{O(\\epsilon)} [\\lambda/\\rho]^d [\\delta/\\rho]^{n-d},", block: true)]]

#text("which on undoing the rescaling by ")#mi("{1/\\rho}")#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_i \\tilde E_i\\right| \\gg_\\epsilon \\delta^{O(\\epsilon)} \\lambda^d \\delta^{n-d}.", block: true)]]

#text("Since ")#mi("{\\epsilon > 0}")#text(" was arbitrary, the claim follows. ")#mi("\\Box")

#text("To give an idea of how this two-ends reduction is used, we give a quick application of it:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" The Kakeya maximal function conjecture is true for ")#mi("{d \\leq \\frac{n+1}{2}}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the “bush” argument of Bourgain. By the above reductions, it suffices to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{i=1}^N E_i\\right| \\gg_\\epsilon \\lambda^{\\frac{n+1}{2}} \\delta^{\\frac{n-1}{2} - \\epsilon}", block: true)]]

#text("whenever ")#mi("{N \\sim \\delta^{1-n}}")#text(", and ")#mi("{E_i \\subset T_i}")#text(" are subsets of ")#mi("{\\delta \\times 1}")#text(" tubes ")#mi("{T_i}")#text(" in ")#mi("{\\delta}")#text("-separated directions with density ")#mi("{\\lambda}")#text(" and obeying the two-ends condition with exponent ")#mi("{\\epsilon}")#text(".")

#text("Let ")#mi("{\\mu}")#text(" be the maximum multiplicity of the ")#mi("{E_i}")#text(", i.e. ")#tao-math("{\\mu := \\left\\| \\sum_{i=1}^N 1_{E_i} \\right\\|_{L^\\infty({\\mathbb R}^n)}}", block: false)#text(". On the one hand, we clearly have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{i=1}^N E_i\\right| \\geq \\frac{1}{\\mu} \\left\\| \\sum_{i=1}^N 1_{E_i} \\right\\|_{L^1({\\mathbb R}^n)} \\gg \\frac{1}{\\mu} \\lambda N \\delta^{n-1} \\gg \\frac{\\lambda}{\\mu}.", block: true)]]

#text("This bound is good when ")#mi("{\\mu}")#text(" is small. What if ")#mi("{\\mu}")#text(" is large? Then there exists a point ")#mi("{x_0}")#text(" which is contained in ")#mi("{\\mu}")#text(" of the ")#mi("{E_i}")#text(", and hence also contained in (at least) ")#mi("{\\mu}")#text(" of the tubes ")#mi("{T_i}")#text(". These tubes form a “bush” centred at ")#mi("{x_0}")#text(", but the portions of that tube near the centre ")#mi("{x_0}")#text(" of the bush have high overlap. However, the two-ends condition can be used to finesse this issue. Indeed, that condition ensures that for each ")#mi("{E_i}")#text(" involved in this bush, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|E_i \\cap B(x_0,r)\\right| \\leq \\frac{1}{2} \\left|E_i\\right|", block: true)]]

#text("for some ")#mi("{r \\sim 1}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|E_i \\backslash B(x_0,r)\\right| \\geq \\frac{1}{2} \\left|E_i\\right| \\gg \\lambda \\delta^{n-1}.", block: true)]]

#text("The ")#mi("{\\delta}")#text("-separated nature of the tubes ")#mi("{T_i}")#text(" implies that the maximum overlap of the portion ")#mi("{T_i \\backslash B(x_0,r)}")#text(" of the ")#mi("{\\mu}")#text(" tubes in the bush away from the origin is ")#mi("{O(1)}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_i E_i \\backslash B(x_0,r)\\right| \\gg \\mu \\lambda \\delta^{n-1}.", block: true)]]

#text("Thus we have two different lower bounds for ")#mi("{\\bigcup_i E_i}")#text(", namely ")#mi("{\\frac{\\lambda}{\\mu}}")#text(" and ")#mi("{\\mu \\lambda \\delta^{n-1}}")#text(". Taking the geometric mean of these bounds to eliminate the unknown multiplicity ")#mi("{\\mu}")#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_i E_i\\right| \\gg \\lambda \\delta^{(n-1)/2},", block: true)]]

#text("which certainly implies the desired bound since ")#mi("{\\lambda \\leq 1}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note that the two-ends condition actually proved a ")#emph[#text("better")]#text(" bound than what was actually needed for the Kakeya conjecture, in that the power of ")#mi("{\\lambda}")#text(" was more favourable than necessary. However, this gain disappears under the rescaling argument used in the proof of Proposition ")#link(<tao-2669dd54b1ab9d3ffa70>)[#text("5")]#text(". Nevertheless, this does illustrate one of the advantages of employing the two-ends reduction; the bounds one gets upon doing so tend to be better (especially for small values of ")#mi("{\\lambda}")#text(") than what one would have had without it, and so getting the right bound tends to be a bit easier in such cases. Note though that for the Kakeya set problem, where ")#mi("{\\lambda}")#text(" is essentially ")#mi("{1}")#text(", the two-ends reduction is basically redundant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One technical drawback to using the two-ends reduction is that if at some later stage one needs to refine the sets ")#mi("{E_i}")#text(" to smaller sets, then one may lose the two-ends property. However, one could invoke the arguments used in Proposition ")#link(<tao-2669dd54b1ab9d3ffa70>)[#text("5")]#text(" to recover this property again by refining ")#mi("{E_i}")#text(" further. One may then lose some other property by this further refinement, but one convenient trick that allows one to take advantage of multiple refinements simultaneously is to iteratively refine the various sets involved and use the pigeonhole principle to find some place along this iteration where all relevant statistics of the system (e.g. the “width” ")#mi("{r}")#text(" of the ")#mi("{E_i}")#text(") stabilise (here one needs some sort of monotonicity property to obtain this stabilisation). This type of trick was introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=1681585")[#text("by Wolff")]#text(" and has been used in several subsequent papers, for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=1891202")[#text("this paper of myself and Izabella Laba")]#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38785")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("Thanks for the great post. two quick questions:")

#text("1. Proposition 7 states the conjecture is true when d > (n+1)/2. If I am reading this correctly one hopes for n> d > n- \\epsilon. What is the best known today?")

#text("2. Is there a nice way to see the bound (1) fails when d=n? (i.e. the conjecture is best possible)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38818")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2009")])]

#text("Oops, there was a typo: Proposition 7 applies for ")#mi("d \\leq (n+1)/2")#text(", not ")#mi("d \\geq (n+1)/2")#text(". As for the “world records”, the survey of Nets and I at ")#link("http://front.math.ucdavis.edu/math.CA/0010069")[#text("http://front.math.ucdavis.edu/math.CA/0010069")]#text(" covers most of the known Euclidean results, though it predates the heat flow methods, the algebraic geometry methods, and the algebraic topology methods mentioned in my earlier post.")

#text("The existence of Besicovitch sets with arbitrarily small measure can be used to disprove the d=n endpoint of (1) (with no epsilon). Because of the presence of the epsilon, the conjecture is closed in d: if it holds for all ")#mi("d < n")#text(", it will also hold for ")#mi("d=n")#text(" (by interpolating with some trivial estimate that loses some power of ")#mi("1/\\delta")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76d36ac7ffb42e9e1634b8f199916e518e12ab220955c7fda203e549f70f5f85-218021d54dd020b9887ffc2d70b26a92980d5bb4cdab607ef67dffd9b1583e8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of small boy")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38859")[#strong[#text("small boy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2009")])]

#text("i have no idea what this post was about :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shuanglin shao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38895")[#strong[#text("shuanglin shao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("Dear Terry,")

#text("Two questions and one corrections.")

#text("1. Can you say a little more on the derivation of the estimate (2) from Conjecture 2?")

#text("2. If formulating this conjecture in terms of")

#mi("L^d(\\mathbb{R}^n) \\to L^{d^{\\prime}}(S^{n-1})")

#text("for the maximal function")

#mi("f^*_\\delta")#text(".")

#text("Then the translation and rotation symmetries are quickly seen. How to reflect these informaton in the formulatons of Conjecture 1, ect? Does it suffice by saying that: fixing a set E; then for any collection of tubes, …?")

#text("(3) In the last 8 lines in the argument of Proposition 5, ")#mi("\\tilde{E}_i")#text(" and ")#mi("E^{\\prime}_i")#linebreak()#text(" may need to be exchanged.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("Dear Shuanglin,")

#text("To deduce (2) from conjecture 2, first observe that the claim is easy if ")#tao-math("\\left|E\\right|", block: false)#text(" is very big or very small (e.g. larger than ")#mi("\\delta^{-C}")#text(" or less than ")#mi("\\delta^C")#text(" for some large C depending only on n) because one can use trivial estimates such as ")#tao-math("\\left|E \\cap T_i\\right| \\leq \\left|E\\right|", block: false)#text(" and ")#tao-math("\\left|E \\cap T_i\\right| \\leq \\left|T_i\\right|", block: false)#text(" in those cases.")

#text("For similar reasons, one can also throw away those tubes ")#mi("T_i")#text(" for which ")#tao-math("\\left|E \\cap T_i\\right|", block: false)#text(" is very small (less than ")#mi("\\delta^C")#text(" for some large C). Once one does all this, there are now only a logarithmic number of ranges ")#tao-math("[\\lambda \\left|T_i\\right|, 2 \\lambda \\left|T_i\\right|]", block: false)#text(" that the ")#tao-math("\\left|E \\cap T_i\\right|", block: false)#text(" could fall into, where ")#mi("\\lambda")#text(" is a dyadic number. For each such range, one applies Conjecture 2, which will establish (2) for that particular subcollection of tubes after some algebra (at one point one has to use the fact that ")#mi("N \\delta^{n-1} = O(1)")#text("); then one sums in the dyadic ranges, absorbing the logarithmic loss into the ")#mi("\\delta^{-\\varepsilon}")#text(" factor on the right-hand side.")

#text("To see the translation and rotation symmetry of the Kakeya problem in this setting, one has to translate and rotate both E and the tubes ")#mi("T_i")#text(".")

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e09bf78a5b24e53c2ae4a1b5ec31aca71160ff96fb4046992966a0267e29c06-b0519a2160f90f455395cdaa3aa185d84be48c5f17bc4a098bb4f8e381f28126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arie israel")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38928")[#strong[#text("arie israel")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Hi Terry,")

#text("Thanks for the wonderful post. A few possible corrections:")

#text("I’m a bit confused with the change from ")#mi("[+\\epsilon]")#text(" to ")#mi("[-\\epsilon]")#text(" going from (2) to Conjecture 2. Also, might ")#mi("[1 < d ]")#text(" be enlarged to become ")#mi("[1 \\leq d]")#text(".")

#text("Also, shouldn't the random rotation trick be used to show Conjecture 2 Conjecture 3? I don’t see why it is needed to prove (2) => Conjecture 2, can’t that be proved directly?")

#text("Thanks again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jzahl")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38946")[#strong[#text("jzahl")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2009")])]

#text("The Wolff paper whose abstract you link to in the first paragraph can be found here:")

#link("http://www.uam.es/departamentos/ciencias/matematicas/ibero/11.3/MATEMATICAIBEROAMERICANA_1995_11_03_08.pdf")[#text("Click to access MATEMATICAIBEROAMERICANA_1995_11_03_08.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e09bf78a5b24e53c2ae4a1b5ec31aca71160ff96fb4046992966a0267e29c06-b0519a2160f90f455395cdaa3aa185d84be48c5f17bc4a098bb4f8e381f28126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arie israel")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38953")[#strong[#text("arie israel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2009")])]

#text("Sorry, what I was trying to say was that it should be ")#mi("1\\leq d \\leq n")#text(" in Conjecture 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38958")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2009")])]

#text("Dear Arie,")

#text("Thanks for the corrections! The random rotations trick is used where it is because of the placement of the exponents. If one replaced the factor ")#mi("N \\delta^{n-1}")#text(" in Conjecture 2 by the weaker factor ")#mi("(N \\delta^{n-1})^d")#text(", then (2) and Conjecture 2 would be equivalent without the random rotations trick, but then one would need that trick to deduce Conjecture 3 from Conjecture 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e09bf78a5b24e53c2ae4a1b5ec31aca71160ff96fb4046992966a0267e29c06-b0519a2160f90f455395cdaa3aa185d84be48c5f17bc4a098bb4f8e381f28126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arie israel")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-38963")[#strong[#text("arie israel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2009")])]

#text("Dear Terry,")

#text("Thanks for the reply, I didn’t notice the difficulty with the exponent of d at first glance. Speaking of exponents, I think there should be a ")#mi("+\\epsilon")#text(" in the statement of Conjecture 3, as well as in the first line of the proof of Proposition 7.")

#text("Thanks again for providing such clear concise expositions regarding Kakeya, they’re truly wonderful to read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb41629b900a04bf9debac4d5eac088c522fb410dada341099521f7f9faeb264-a753dd309490ffe7a3fccee4f133ec9c1bea4ce7d7e270786ca05bf0f89638af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daoguo zhou")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-481007")[#strong[#text("daoguo zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2017")])]

#text("Dear Prof Tao,")#linebreak()#text(" Can you give more details on the procedure from estimate (2) to ")#tao-math("\\displaystyle\\sum_{i=1}^N \\int_{T_i} F \\ll_\\epsilon (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon} \\left\\|F\\right\\|_{L^d({\\mathbb R}^n)}?", block: false)

#text("It seems to me that just breaking ")#mi("F")#text(" up into level sets via dyadic decomposition will not work. In fact, we have")#linebreak()#text(" ")#tao-math("\\displaystyle \\begin{aligned}\\sum_{i=1}^{N}\\int_{T_{i}}F&\\approx\\sum_{i=1}^{N}\\sum_{k\\in\\mathbb{Z}}2^{k}|T_{i}\\cap\\{F\\geq2^{k}\\}|\\\\&\\leq\\sum_{k\\in\\mathbb{Z}}\\sum_{i=1}^{N}2^{k}|T_{i}\\cap\\{F\\geq2^{k}\\}|\\\\&\\ll_\\epsilon (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon} \\sum_{k\\in\\mathbb{Z}}2^{k}\\left|\\{F\\geq2^{k}\\}\\right|^{\\frac{1}{d}}, \\end{aligned}", block: false)#linebreak()#text(" where the estimate (2) has been used. Our target is to bound the above quantity by")#linebreak()#text(" ")#tao-math("\\displaystyle (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon} (\\int_{\\mathbb{R}^d}F^ddx)^{\\frac 1 d}\\approx (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon} (\\sum_{k\\in\\mathbb{Z}}2^{kd}\\left|\\{F\\geq2^{k}\\}\\right|)^{\\frac 1 d}.", block: false)#linebreak()#text(" Now, we need Hölder’s inequality from ")#mi("l^1")#text(" to ")#mi("l^d")#text(", which is not aviable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-481026")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2017")])]

#text("Normalise $\\|F\\|_{L^d({\\bf R}^n)} = 1$. The above arguments will take care of the range when ")#mi("\\delta^{100 n} \\leq 2^k \\leq \\delta^{-100 n}")#text(" (say), since the number of such $k$ is only logarithmic in ")#mi("\\delta")#text(" and one can move from ")#mi("\\ell^1")#text(" to ")#mi("\\ell^d")#text(" with a loss that can be absorbed in the ")#mi("(1/\\delta)^\\varepsilon")#text(" factor. The remaining extreme ranges ")#mi("2^k \\leq \\delta^{100 n}")#text(" or ")#mi("2^k \\geq \\delta^{-100 n}")#text(" can then be handled by trivial estimates (the former by bounding ")#tao-math("\\left|T_i \\cap \\{F \\cap 2^k\\}\\right|", block: false)#text(" by ")#tao-math("\\left|T_i\\right|", block: false)#text("; the latter by bounding ")#mi("|\\{ F \\geq 2^k \\}")#text(" by ")#tao-math("\\left\\| F\\right\\|_{L^d} 2^{-kd}", block: false)#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-691912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("Dear Terry, Can we use the two-ends reduction to prove that “the Furstenberg estimate implies the Kakeya maximal estimate”? Even though the Furstenberg estimate requires $E\\cap T_i$ to be a union of \\delta$-cubes, I suppose we could also assume this property in the context of the Kakeya maximal estimate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-691915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("I am not sure what you precisely mean by the “Furstenberg estimate”, but my current understanding is that while Furstenberg type estimates are certainly very helpful to establish Kakeya type bounds, they do not automatically imply the optimal Kakeya maximal estimates; the current induction on scale technology may only be able to establish non-optimal Kakeya maximal inequalities with such bounds. (But the subject is evolving quickly, and I can certainly imagine that a proof of a good Furstenberg estimate, with suitable modifications, could be adapted to also give a good Kakeya maximal estimate, even if there is no formal implication.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-691926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("I am considering the following scheme: In the ")#mi("2")#text("-dimensional case, the Furstenberg estimate implies that for a collection of maximal tubes with ")#mi("\\delta")#text("-separated directions—forming a (Frostman) ")#mi("(\\delta,1)")#text("-set—if each tube ")#mi("T")#text(" contains a ")#mi("(\\delta,s)")#text("-shading ")#mi("Y(T)")#text(", then the measure of the union satisfies ")#tao-math("\\left| \\bigcup Y(T)\\right| \\gtrapprox \\delta^2 \\min(\\delta^{-s-1},\\delta^{-(3s+1)/2})", block: false)#text(".")

#text("Wolff’s two-ends assumption seems to suggest that we may treat each ")#mi("E\\cap T_i")#text(" as a ")#mi("(\\delta,\\varepsilon)")#text("-set. Consequently, we would have ")#tao-math("\\left|\\bigcup (E\\cap T_i)\\right|\\gtrapprox \\delta^2\\min(\\delta^{-\\varepsilon-1},\\delta^{-(3\\varepsilon+1)/2})=\\lambda^{3/2}", block: false)#text(", since ")#mi("\\lambda\\sim \\delta^{1-\\varepsilon}")#text(". This presumably implies the Kakeya maximal conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/15/the-two-ends-reduction-for-the-kakeya-maximal-conjecture/#comment-691929")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2026")])]

#text("The Kakeya maximal conjecture involves arbitrary values of ")#mi("\\lambda")#text(" in the range ")#mi("\\delta \\leq \\lambda \\leq 1")#text("; handling just the very small values of ")#mi("\\lambda")#text(" does not fully resolve the conjecture. (The very small values ")#mi("0 < \\lambda \\leq \\delta")#text(" of ")#mi("\\lambda")#text(" can be eliminated from consideration by a discretization argument, but I do not know of any comparably simple argument to eliminate medium sized values of ")#mi("\\lambda")#text(".)")
]
]
]
]
