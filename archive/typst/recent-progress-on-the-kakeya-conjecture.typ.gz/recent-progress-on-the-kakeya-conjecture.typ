// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:17:14.581634+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Recent progress on the Kakeya conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Recent progress on the Kakeya conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/")[#text("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Below the fold is a version of my talk “Recent progress on the Kakeya conjecture” that I gave at the Fefferman conference.")

#metadata(none) <tao-98df3f7f09905b787f64>

#text("One of my favourite problems in mathematics is the ")#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Kakeya_conjecture")[#text("Kakeya family of conjectures")]#text(". There are many versions of these conjectures, but one of the simplest to state is the following:")

#text("Let ")#mi("{E \\subset {\\mathbb R}^n}")#text(" be a compact subset of ")#mi("{{\\mathbb R}^n}")#text(" which contains a unit line segment in every direction. Then ")#mi("{E}")#text(" has ")#link("http://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff")]#text(" and ")#link("http://en.wikipedia.org/wiki/Minkowski_dimension")[#text("Minkowski dimension")]#text(" ")#mi("{n}")#text(".")

#text("Sets ")#mi("{E \\subset {\\mathbb R}^n}")#text(" which contain a unit line segment in every direction are known as ")#emph[#text("Kakeya sets")]#text(". It was observed by Besicovitch that for ")#mi("{n \\geq 2}")#text(", Kakeya sets can have arbitrarily small Lebesgue measure; in fact they can have Lebesgue measure zero. This in turn implies that the solution to the Kakeya needle problem (what is the least amount of area in the plane needed to rotate a unit line segment by ")#mi("{360^\\circ}")#text("?) is that a unit needle can be rotated in arbitrarily small area (see this ")#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/")[#text("previous blog post of mine")]#text(" for further discussion).")

#text("The conjecture is trivial in one dimension, and also proven in two dimensions (a result ")#link("http://www.ams.org/mathscinet-getitem?mr=272988")[#text("of Davies")]#text("), but remains open in three and higher dimensions. Nevertheless, there are a number of partial results, typically of the form “Kakeya sets in ")#mi("{{\\mathbb R}^n}")#text(" have Hausdorff or Minkowski dimension at least ")#mi("{d}")#text("” for various values of ")#mi("{n}")#text(" and ")#mi("{d}")#text(" (with the objective being to get ")#mi("{d}")#text(" all the way up to ")#mi("{n}")#text("“. One can also phrase such results in a largely equivalent discrete fashion, as follows. Let ")#mi("{0 < \\delta < 1}")#text(" be a small number, and let ")#mi("{T_1,\\ldots,T_N}")#text(" be a collection of ")#mi("{1 \\times \\delta}")#text(" tubes which are oriented in a ")#mi("{\\delta}")#text("-separated set of directions (thus if ")#mi("{T_i}")#text(", ")#mi("{T_j}")#text(" are oriented in the direction ")#mi("{\\omega_i}")#text(", ")#mi("{\\omega_j}")#text(" respectively for some ")#mi("{1 \\leq i \\leq N}")#text(", then ")#tao-math("{\\left|\\omega_i - \\omega_j\\right| \\geq \\delta}", block: false)#text(" ), then the Kakeya conjecture (for Minkowski dimension) is equivalent to the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{i=1}^N T_i\\right| \\gg_\\epsilon \\delta^\\epsilon", block: true)]]

#text("holding for all ")#mi("{\\epsilon > 0}")#text(", where ")#tao-math("{\\left|E\\right|}", block: false)#text(" denotes the volume of the set ")#mi("{E}")#text(", and ")#mi("{A \\gg_\\epsilon B}")#text(" denotes the estimate ")#mi("{A \\geq c_\\epsilon B}")#text(" for some ")#mi("{c_\\epsilon > 0}")#text(" depending only on ")#mi("{\\epsilon}")#text(". Similarly, a partial result of the form ")#metadata(none) <tao-55412b9b4e635224d161>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\bigcup_{i=1}^N T_i\\right| \\gg_\\epsilon \\delta^{n-d+\\epsilon}", block: true)]]



#text(" for all ")#mi("{\\epsilon > 0}")#text(" and some ")#mi("{0 \\leq d \\leq n}")#text(" would imply (and is basically equivalent to) the assertion that Kakeya sets have (lower) Minkowski dimension at least ")#mi("{d}")#text(".")

#text("There is also a somewhat stronger ")#emph[#text("Kakeya maximal function conjecture")]#text(" which is also of interest; with the same hypotheses as above, the conjecture asserts that ")#metadata(none) <tao-9baf3a40312f39849f46>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\sum_{i=1}^N 1_{T_i} \\right\\|_{L^{d/(d-1)}({\\mathbb R}^n)} \\ll_\\epsilon (\\frac{1}{\\delta})^{\\frac{n}{d}-1+\\epsilon}", block: true)]]



#text(" for all ")#mi("{1 \\leq d \\leq n}")#text(" and ")#mi("{\\epsilon > 0}")#text(". This conjecture is trivial for ")#mi("{d=1}")#text(", but the difficulty increases as ")#mi("{d}")#text(" approaches ")#mi("{n}")#text("; for any fixed ")#mi("{d}")#text(", the estimate ")#link(<tao-9baf3a40312f39849f46>)[#text("(2)")]#text(" easily implies ")#link(<tao-55412b9b4e635224d161>)[#text("(1)")]#text(", and hence that Kakeya sets in ")#mi("{{\\mathbb R}^n}")#text(" have Minkowski dimension at least ")#mi("{d}")#text("; it also can be used to imply that such sets have Hausdorff dimension at least ")#mi("{d}")#text(" as well. (The terminology “Kakeya maximal function conjecture” comes from the fact that ")#link(<tao-9baf3a40312f39849f46>)[#text("(2)")]#text(" is dual to a certain ")#mi("{L^p}")#text(" type bound on the ")#emph[#text("Kakeya maximal function")]

#align(center)[#tao-fit-display[#tao-math("f^*_\\delta(\\omega) := \\sup_{T // \\omega} \\frac{1}{\\left|T\\right|} \\int_T \\left|f\\right|,", block: true)]]

#text("a variant of the Hardy-Littlewood maximal function which averages over ")#mi("{1 \\times \\delta}")#text(" tubes oriented in a direction ")#mi("{\\omega}")#text(", rather than on balls, but we will not discuss the maximal function further here.)")

#text("The Kakeya conjecture is known to have applications to other fields of mathematics, for instance to Fourier analysis (as observed ")#link("http://www.ams.org/mathscinet-getitem?mr=296602")[#text("by Fefferman")]#text("), to wave equations (as observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1660476")[#text("by Wolff")]#text("), to analytic number theory (as observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1863693")[#text("by Bourgain")]#text("), to cryptography (as observed also ")#link("http://www.ams.org/mathscinet-getitem?mr=2206765")[#text("by Bourgain")]#text(") and to random number generation in computer science (as observed ")#link("http://www.math.ias.edu/~dvir/papers/DvirWigderson08.pdf")[#text("by Dvir and Wigderson")]#text("). However, the focus of this talk is not on the fields of mathematics impacted by the Kakeya conjecture, but rather on the fields of mathematics that are used to make ")#emph[#text("progress")]#text(" on this conjecture, as there is a striking diversity of mathematical techniques which have been usefully applied to produce a number of non-trivial partial results on the problem. In particular, I wish to discuss how the following areas of mathematics have been used to attack the Kakeya problem:")

#list(
[#text("Incidence geometry;")],
[#text("Additive combinatorics;")],
[#text("Multiscale analysis;")],
[#text("Heat flows;")],
[#text("Algebraic geometry;")],
[#text("Algebraic topology.")]
)

#heading(level: 1)[#strong[#text(" — 1. Incidence geometry — ")]]

#text("The earliest positive results on the Kakeya problem, when interpreted from a modern perspective, were based primarily on exploiting elementary quantitative results in incidence geometry – the study of how points, lines, planes, and the like (or more precisely, ")#mi("{\\delta}")#text("-thickened versions of such concepts, such as balls, tubes, and slabs) intersect each other. The incidence geometry approach was greatly clarified by the introduction by Wolff in 1995 of the ")#emph[#text("finite field model")]#text(" of the Kakeya conjectures, in which the underlying field ")#mi("{{\\mathbb R}}")#text(" is replaced by a field ")#mi("{{\\Bbb F}_q}")#text(" of some large but finite order ")#mi("{q}")#text(" (which of course must be a prime, or a power of a prime). The analogue of the Kakeya set bound ")#link(<tao-55412b9b4e635224d161>)[#text("(1)")]#text(" is then an estimate of the form ")#metadata(none) <tao-139ebafe0399eb0c6950>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\# \\bigcup_{\\ell \\in L} \\ell \\gg_\\epsilon q^{d-\\epsilon}")]]



#text(" for all ")#mi("{\\epsilon > 0}")#text(", where ")#mi("{L}")#text(" is a family of lines in ")#mi("{{\\Bbb F}_q^n}")#text(" that contains one line in every direction (thus, ")#mi("{L}")#text(" will have cardinality comparable to ")#mi("{q^{n-1}}")#text("), and ")#mi("{\\# E}")#text(" denotes the cardinality of a set ")#mi("{E}")#text(". In a similar vein, the analogue of ")#link(<tao-9baf3a40312f39849f46>)[#text("(2)")]#text(" is the assertion that ")#metadata(none) <tao-1bb4e0f4987e7785400c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| \\sum_{\\ell \\in L} 1_{\\ell} \\right\\|_{\\ell^{d/(d-1)}({\\Bbb F}_q^n)} \\ll_\\epsilon q^{n-1+\\epsilon}", block: true)]]



#text(" under the same hypothesis on ")#mi("{L}")#text(". The fact that ")#link(<tao-1bb4e0f4987e7785400c>)[#text("(4)")]#text(" implies ")#link(<tao-139ebafe0399eb0c6950>)[#text("(3)")]#text(" can be easily seen from the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{\\ell \\in L} 1_{\\ell} \\right\\|_{\\ell^{1}({\\Bbb F}_q^n)} = q \\# L \\sim q^n", block: true)]]

#text("and Hölder’s inequality, using the fact that the multiplicity function ")#mi("{\\sum_{\\ell \\in L} 1_{\\ell}}")#text(" is supported in ")#mi("{\\bigcup_{\\ell \\in L} \\ell}")#text(".")

#text("There is a close analogy between the finite field Kakeya problems and the Euclidean ones; arguments that make progress in one setting can often be adapted to make progress in the other. However, there is no formal correspondence, and there are some arguments that seem to be specific to the finite field setting, and other arguments that are specific to the Euclidean one. Nevertheless, the finite field setting has proven to be an extremely useful toy model to gain intuition and insight into the (more complicated) Euclidean problem.")

#text("Very roughly speaking, every incidence geometry fact in classical Euclidean geometry can be converted (at least in principle) via elementary combinatorial arguments into a lower bound on Kakeya sets. Consider for instance the Euclidean axiom that any two lines intersect in at most one point. This can be converted to the bound ")#mi("{d \\geq 2}")#text(" for any dimension ")#mi("{n \\geq 2}")#text(", for any one of the versions of the Kakeya problem mentioned above; this was established ")#link("http://www.ams.org/mathscinet-getitem?mr=272988")[#text("by Davies")]#text(" for the Euclidean dimension problem and ")#link("http://www.ams.org/mathscinet-getitem?mr=447949")[#text("by Córdoba")]#text(" for the Euclidean maximal function problem. We sketch a heuristic proof for the finite field set problem ")#link(<tao-139ebafe0399eb0c6950>)[#text("(3)")]#text(". Suppose for simplicity that ")#mi("{\\# \\bigcup_{\\ell \\in L} \\ell}")#text(" has size exactly ")#mi("{q^d}")#text(". There are about ")#mi("{q^{n-1}}")#text(" lines ")#mi("{\\ell}")#text(" in ")#mi("{L}")#text(", each containing ")#mi("{q}")#text(" points; if we adopt the heuristic that the ")#mi("{q^{n-1} \\times q = q^n}")#text(" points described this way are spread out uniformly in the set ")#mi("{\\sum_{\\ell \\in L} 1_{\\ell}}")#text(", then each point in that set should be incident to about ")#mi("{q^{n-d}}")#text(" lines. Now, let us count the number of configurations consisting of two distinct lines in ")#mi("{L}")#text(" intersecting at a single point. On the one hand, since ")#mi("{L}")#text(" has about ")#mi("{q^{n-1}}")#text(" lines, and any two lines intersect in at most one point, the number of such configurations is at most ")#mi("{q^{2(n-1)}}")#text("; on the other hand, since there are about ")#mi("{q^d}")#text(" points, and each point is incident to about ")#mi("{q^{n-d}}")#text(" lines, then the number of configurations is at least ")#mi("{q^d \\times q^{n-d} \\times q^{n-d}}")#text(". Comparing the lower and upper bounds gives the desired bound ")#mi("{d \\geq 2}")#text(". (This argument assumed uniform distribution of the multiplicity function, but the general case can be handled similarly by applying the Cauchy-Schwarz inequality.)")

#text("There are several other instances of this incidence geometry strategy in action:")

#list(
[#text("The axiom that two distinct points determine a line can be used to give the bound ")#mi("{d \\geq \\frac{n+1}{2}}")#text(" in any dimension ")#mi("{n}")#text(". This was done (implicitly) ")#link("http://www.ams.org/mathscinet-getitem?mr=684547")[#text("by Drury")]#text(" for the Euclidean set and maximal problems, and explicitly by ")#link("http://www.ams.org/mathscinet-getitem?mr=835805")[#text("by Christ, Duandikoextea, and Rubio de Francia")]#text(" with a refined endpoint estimate at ")#mi("{d=\\frac{n+1}{2}}")#text(".")],
[#text("The fact that any three lines in general position determine a regulus (ruled surface), which contains a one-dimensional family of lines incident to all three of the original lines, can be used to give the bound ")#mi("{d \\geq \\frac{7}{3}}")#text(" in the three-dimensional case ")#mi("{n=3}")#text("; this was achieved ")#link("http://www.ams.org/mathscinet-getitem?mr=1631271")[#text("by Schlag")]#text(" (and the bound was also obtained by a slightly different argument earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=1097257")[#text("by Bourgain")]#text(").")],
[#text("The axiom that any two intersecting lines determine a plane, which contains a one-dimensional family of possible ")#emph[#text("directions")]#text(" of lines, was used ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("by Wolff")]#text(" to give the bound ")#mi("{d \\geq \\frac{n+2}{2}}")#text(" in all dimensions ")#mi("{n \\geq 2}")#text(". This argument relied cruically on the fact that the lines pointed in different directions; note that if one allows lines to be parallel, then a plane contains a ")#emph[#text("two")]#text("-dimensional family of lines rather than a one-dimensional one.")],
[#text("In four dimensions (and for the finite field set problem), ")#link("http://www.ams.org/mathscinet-getitem?mr=2225076")[#text("I managed")]#text(" to improve the Wolff bound of ")#mi("{d \\geq 3}")#text(" in four dimensions ")#mi("{n=4}")#text(" slightly to ")#mi("{d \\geq 3 + \\frac{1}{16}}")#text(", by a more complicated axiom from incidence geometry, namely that any three reguli in general position determine an algebraic hypersurface, the lines in which only point in a two-dimensional family of directions.")]
)

#text("From this sequence, it seems that one needs to imply increasingly “high-degree” facts from incidence geometry to make deeper progress on the Kakeya conjecture, in particular one begins to transition from incidence geometry to algebraic geometry. Indeed, one can view the polynomial method of Dvir (introduced later in this post) as the natural continuation of these methods. However, there is some evidence that the incidence geometry approach, by itself, is not sufficient to establish the full conjecture. For instance, if one heuristically inserts an arbitrary incidence geometry fact involving bounded-degree algebraic varieties into the above method, it appears that one cannot obtain a lower bound on ")#mi("{d}")#text(" of better than ")#mi("{n/2 + O(1)}")#text(". Also, there are near-counterexamples to the Kakeya conjecture (such as the Heisenberg group ")#mi("{\\{ (z_1,z_2,z_3): \\text{Im}(z_3) = \\text{Im}(z_1 \\overline{z_2}) \\}}")#text(" when the field ")#mi("{{\\Bbb F}_q}")#text(" admits a non-trivial conjugation ")#mi("{z \\mapsto \\overline{z}}")#text(") which only fail to contradict that conjecture due to the parallel nature of some of the lines, so any argument establishing the conjecture must make essential use of the fact that lines point in different directions.")

#heading(level: 1)[#strong[#text(" — 2. Additive combinatorics — ")]]

#text("In 1998, ")#link("http://www.ams.org/mathscinet-getitem?mr=1692486")[#text("Bourgain introduced")]#text(" a somewhat different approach to the Kakeya problem, which relied on elementary facts of ")#emph[#text("arithmetic")]#text(" (and in particular, addition and subtraction), rather than that of ")#emph[#text("geometry")]#text(", to obtain new bounds on the Kakeya problem. This additive-combinatorics method fared better than the geometric method in higher dimensions, basically because the additive structure of high-dimensional spaces was much the same as for low-dimensional spaces, even if the geometric structure becomes much different (and less intuitive).")

#text("It is convenient to illustrate the method using the finite field model problem ")#link(<tao-139ebafe0399eb0c6950>)[#text("(3)")]#text(", using the method of “slices” introduced by Bourgain (though it is also possible to perform the additive combinatorial method without slicing the set), though the method can also be adapted to the other variants of the Kakeya problem. As before, we argue heuristically in order to simplify the discussion. Let ")#mi("{E \\subset {\\Bbb F}_q^n}")#text(" be a finite field Kakeya set, and suppose it has cardinality about ")#mi("{q^d}")#text(". We then write ")#mi("{{\\Bbb F}_q^n}")#text(" as ")#mi("{{\\Bbb F} \\times {\\Bbb F}_q^{n-1}}")#text(" and consider the three “slices” ")#mi("{A, B, C}")#text(" of ")#mi("{E}")#text(", defined as the intersection of ")#mi("{E}")#text(" with the horizontal hyperplanes ")#mi("{\\{0\\} \\times {\\Bbb F}_q^{n-1}}")#text(", ")#mi("{\\{1\\} \\times {\\Bbb F}_q^{n-1}}")#text(", and ")#mi("{\\{1/2\\} \\times {\\Bbb F}_q^{n-1}}")#text(" respectively (let us assume ")#mi("{q}")#text(" is odd for the sake of discussion, so that ")#mi("{1/2}")#text(" is well-defined). Then we expect ")#mi("{A, B, C}")#text(" to all have cardinality about ")#mi("{q^{d-1}}")#text(". On the other hand, ")#mi("{E}")#text(" contains about ")#mi("{q^{n-1}}")#text(" lines, each of which connect a point ")#mi("{a \\in A}")#text(" to a point ")#mi("{b \\in B}")#text(", with the midpoint ")#mi("{\\frac{a+b}{2}}")#text(" lying in ")#mi("{C}")#text(". Since two points uniquely determine a line, we thus have about ")#mi("{q^{n-1}}")#text(" many pairs ")#mi("{(a,b)}")#text(" in ")#mi("{A \\times B}")#text(" whose sums ")#mi("{a+b}")#text(" are contained in a small set, namely ")#mi("{2 \\cdot C}")#text(". (This fact alone already leads to the lower bound ")#mi("{d \\geq \\frac{n+1}{2}}")#text(" mentioned earlier.) On the other hand, since the lines all point in different directions, the ")#emph[#text("differences")]#text(" ")#mi("{a-b}")#text(" of all these pairs ")#mi("{(a,b)}")#text(" are distinct. The additive combinatorial strategy is then to play off the compressed nature of the sums on one hand, and the dispersed nature of the differences on the other. One of the main ingredients here are elementary additive identities, such as")

#align(center)[#tao-fit-display[#mitex("a+b = a^{\\prime}+b^{\\prime} \\implies a-b^{\\prime} = a^{\\prime}-b,")]]

#text("which suggests that collisions of sums should imply collisions of differences. This identity, by itself, is insufficient to obtain any new bound on the Kakeya problem, because even if the pairs ")#mi("{(a,b)}")#text(" and ")#mi("{(a^{\\prime},b^{\\prime})}")#text(" come from lines in ")#mi("{E}")#text(", there is no reason why the pairs ")#mi("{(a,b^{\\prime})}")#text(" or ")#mi("{(a^{\\prime},b)}")#text(" should also. But one can then combine the above identity with further identities, such as")

#align(center)[#tao-fit-display[#mitex("a-b = (a-b^{\\prime}) - (a^{\\prime}-b^{\\prime}) + (a^{\\prime}-b)")]]

#text("which can be used to convert collisions of some differences to collisions of other differences. Implementing this strategy rigorously using a combinatorial tool now known as the ")#emph[#text("Balog-Szemerédi-Gowers lemma")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1692486")[#text("Bourgain improved")]#text(" the bound ")#mi("{d \\geq \\frac{n+1}{2} = \\frac{n-1}{2}+1}")#text(" to ")#mi("{d \\geq \\frac{n-1}{2-1/13}+1}")#text(" (for the Minkowski dimension in both Euclidean and finite field settings), which was superior to the bounds obtained by incidence geometry methods in high dimensions. By inserting more and more such additive identities into this framework (and taking more and more slices), the constants improved somewhat; for instance, in high dimensions, the best result so far (on the Minkowski Euclidean problem) is ")#mi("{d \\geq \\frac{n-1}{\\alpha}+1}")#text(", where ")#mi("{\\alpha = 1.675\\ldots}")#text(" is the largest root of ")#mi("{\\alpha^3-4\\alpha+2}")#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=1945284")[#text("result of Nets Katz and myself")]#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1964819")[#text("this survey article of Nets and myself")]#text(" for further discussion.")

#text("It may well be that the arithmetic approach could eventually settle the entire Kakeya conjecture (this would correpsond to lowering the exponent ")#mi("{\\alpha}")#text(" appearing in the above results all the way to ")#mi("{1}")#text("); there is a formalisation of this assertion, known as the “arithmetic Kakeya conjecture”, which has some amusing ")#link("http://www.ams.org/mathscinet-getitem?mr=2157367")[#text("relationships with group theory")]#text(". However, we have not been able to find additive combinatorial arguments that are so efficient that they do not lose anything in the exponents, and it is not clear whether this conjecture is within reach of known technology. One possible direction to pursue is to move from additive combinatorics (the combinatorics of addition and subtraction) to ")#emph[#text("arithmetic")]#text(" combinatorics (the combinatorics of addition, subtraction, multiplication, and division). For instance, the sum-product phenomenon in finite fields was used ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("by Bourgain, Katz, and myself")]#text(" to improve the bound on three-dimensional Kakeya sets slightly from ")#mi("{d \\geq 5/2}")#text(" to ")#mi("{d \\geq 5/2+\\epsilon}")#text(" for some ")#mi("{\\epsilon>0}")#text(". Nets Katz and I are exploring this direction further, and I hope to report on our results at some point in the future.")

#heading(level: 1)[#strong[#text(" — 3. Multiscale analysis — ")]]

#text("The finite field model is considered simpler than the Euclidean model for a number of reasons, but one of the main ones is that the finite field model does not have the infinite number of scales that are present in the Euclidean setting. But one can reverse this viewpoint, and instead look for ways to ")#emph[#text("exploit")]#text(" the multitude of scales available in the Euclidean case. One promising strategy in this direction is the ")#emph[#text("induction on scales")]#text(" strategy, introduced by Bourgain for the closely related restriction and Bochner-Riesz problems, and developed further by Wolff. The basic idea here is to deduce a Kakeya estimate at scale ")#mi("{\\delta}")#text(" from the corresponding the Kakeya estimate at a coarser scale, such as ")#mi("{\\sqrt{\\delta}}")#text(". We sketch the basic idea as follows. Suppose that the Kakeya conjecture was already established at scale ")#mi("{\\sqrt{\\delta}}")#text("; roughly speaking, this means that any connection of ")#mi("{\\sqrt{\\delta}\\times 1}")#text(" tubes that point in different directions (i.e. ")#mi("{\\sqrt{\\delta}}")#text("-separated directions) must be essentially disjoint. One can then argue that that this should implies the same assertion for ")#mi("{\\delta \\times 1}")#text(" tubes. To justify this, we assume that these “thin” ")#mi("{\\delta \\times 1}")#text(" tubes are arranged in a sufficiently “self-similar” (or “sticky”) fashion that they can be organised into “fat” ")#mi("{\\sqrt{\\delta} \\times 1}")#text(" tubes, which themselves point in different (i.e. ")#mi("{\\sqrt{\\delta}}")#text("-separated) directions. By the Kakeya hypotheses, these fat tubes are essentially disjoint. What about the thin tubes inside any given fat tube? Well, if one rescales a fat tube about its axis, dilating its lateral dimensions by ")#mi("{1/\\sqrt{\\delta}}")#text(" so that it becomes a ")#mi("{1 \\times 1}")#text(" cylinder, then the thin tubes inside that fat tube essentially expand into fat tubes, which by hypothesis are again essentially disjoint. Since the thin tubes inside each fat tube are essentially disjoint, and the fat tubes are themselves essentially disjoint, the entire collection of thin tubes should be essentially disjoint as well.")

#text("This argument is remarkably difficult to make rigorous, in part because it is not obvious at all why the tubes should stick together in a self-similar way, but also because the fat tubes can intersect each other in a coplanar fashion, allowing the thin tubes in each fat tube to align up with an unusually high multiplicity. In ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("a 63-page paper")]#text(", Nets Katz, Izabella Laba, and I managed to implement this idea, in conjunction with much of the incidence geometry and additive combinatorics arguments discussed in previous sections, but only managed to improve the (Euclidean Minkowski dimension) bound for three-dimensional Kakeya sets from ")#mi("{d \\geq 5/2}")#text(" to ")#mi("{d \\geq 5/2+10^{-10}}")#text(" (with ")#link("http://www.ams.org/mathscinet-getitem?mr=1866801")[#text("similar small improvements")]#text(" in higher dimensions). Nevertheless, the multiscale method did lead to another method which gave further results, namely the heat flow method which we now discuss.")

#heading(level: 1)[#strong[#text(" — 4. Heat flow — ")]]

#text("It is possible to eliminate the coplanarity and stickiness issues arising in the multiscale approach by replacing a linear Kakeya problem such as ")#link(<tao-9baf3a40312f39849f46>)[#text("(2)")]#text(" with a multilinear variant, namely ")#metadata(none) <tao-4a86480653049caa95e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\prod_{j=1}^n \\sum_{i=1}^N 1_{T^{(j)}_i} \\right\\|_{L^{1/(n-1)}({\\mathbb R}^n)} \\ll_\\epsilon \\delta^{-\\epsilon}", block: true)]]



#text(" whenever ")#mi("{T^{(j)}_i}")#text(" for ")#mi("{1 \\leq j \\leq n}")#text(" are families of ")#mi("{\\delta \\times 1}")#text("-tubes with ")#mi("{\\delta}")#text("-separated directions, pointing close to the ")#mi("{j^{th}}")#text(" cardinal direction ")#mi("{e_j}")#text(". Roughly speaking, the difference between ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" and ")#link(<tao-9baf3a40312f39849f46>)[#text("(2)")]#text(" is that “coplanar” interactions have been abolished from ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" by fiat; the expression inside the norm consists only of products of tubes whose directions are in general position. With these difficulties eliminated, the induction on scales argument comes much closer to working properly. However, the degradation of constants is too poor; when passing from scale ")#mi("{\\sqrt{\\delta}}")#text(" to scale ")#mi("{\\delta}")#text(", the losses get squared, leading to a net loss of ")#mi("{\\delta^{-C}}")#text(" for some constant ")#mi("{C}")#text(", which is unacceptable. However, it turns out (as shown ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("by Bennett, Carbery, and myself")]#text(") that one can avoid all such losses by performing a continuous analogue of the induction on scales procedure, in which the tubes are replaced by distorted Gaussian functions, which are then continuously dilated about their major axis by heat flow, effectively increasing their thickness from ")#mi("{\\delta}")#text(" towards ")#mi("{1}")#text(". One then shows that (a suitable modification of) the expression in ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" increases along this heat flow, allowing one to deduce ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" at scale ")#mi("{\\delta}")#text(" from ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" at scale ")#mi("{1}")#text(". (One still incurs a ")#mi("{\\delta^{-\\epsilon}}")#text(" loss because, for technical reasons, one can only obtain a monotonicity formula if one works with ")#mi("{L^{1/(n-1)-\\epsilon}}")#text(" norms rather than ")#mi("{L^{1/(n-1)}}")#text(" norms, requiring an interpolation to finish the job.)")

#text("Another way to view the heat flow argument is to take the (gaussian-smoothed) tubes ")#mi("{1_{T^{(j)}_i}}")#text(" and slide them continuously toward the origin, so that at the final stage one obtains a “bush” of (smoothed) tubes through the origin, for which ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" is easy to establish. One can use essentially the same monotonicity computations as before to show that the ")#mi("{L^{1/(n-1)}}")#text(" norm (or more precisely, a slightly weighted ")#mi("{L^{1/(n-1)-\\epsilon}}")#text(" norm) in ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" increases along this sliding procedure, thus providing a sort of variational proof of ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(".")

#text("The multilinear Kakeya conjecture ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" implies its usual counterpart ")#link(<tao-9baf3a40312f39849f46>)[#text("(2)")]#text(" in two dimensions by a standard angular rescaling argument, but unfortunately it seems to be strictly weaker than the linear Kakeya conjecture in three and higher dimensions, because it says nothing about the coplanar intersections which seem to be a major feature in the higher-dimensional Kakeya problem. (Indeed, ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" suggests, roughly speaking, that if there is a counterexample to the Kakeya conjecture, it will come from “plany” Kakeya sets, in which the lines that pass through a typical point will essentially all lie on a hyperplane.) Thus far we have been unable to find a monotonicity formula that can handle the coplanar case (and perhaps one should not expect to find one, given that the extremisers for the linear maximal function are likely to resemble Besicovitch sets and thus not be amenable to a simple variational argument). Nevertheless ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" is one of the few Kakeya-type estimates we have in higher dimensions whose exponents are sharp (up to epsilons).")

#heading(level: 1)[#strong[#text(" — 5. Algebraic geometry — ")]]

#text("A striking breakthrough on the finite field side of the Kakeya problem was achieved recently ")#link("http://arxiv.org/abs/0803.2336")[#text("by Dvir")]#text(", by introducing a high-degree analogue of the low-degree algebraic geometry used in the incidence geometry approaches (see also ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("this blog post")]#text(" for more discussion). Indeed, one can view Dvir’s argument in the incidence geometry framework, with the two key incidence geometry inputs involving high-degree hypersurfaces. The first is the following (a high-degree analogue of Wolff’s observation that a plane contains only a one-dimensional family of lines; see also ")#link("http://www.ams.org/mathscinet-getitem?mr=2031165")[#text("my paper with Mockenhaupt")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=2225076")[#text("another paper of mine")]#text(", for similar lemmas):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" If ")#mi("{S}")#text(" is a degree ")#mi("{k}")#text(" hypersurface in ")#mi("{{\\Bbb F}_q^d}")#text(" with ")#mi("{k < q}")#text(", then the number of possible directions of lines in ")#mi("{S}")#text(" is at most ")#mi("{O( k q^{d-2} )}")#text(".")
]

#text("Indeed, if one extends the degree ")#mi("{k}")#text(" hypersurface ")#mi("{S}")#text(" in ")#mi("{{\\Bbb F}_q^d}")#text(" to a degree ")#mi("{\\leq k}")#text(" hypersurface ")#mi("{S_\\infty}")#text(" at the hyperplane at infinity, then every line in ")#mi("{S}")#text(" will extend to a point in ")#mi("{S_\\infty}")#text(", representing the direction of ")#mi("{S}")#text(". (Here we use the fact that a polynomial of degree ")#mi("{k}")#text(" cannot vanish at every point of a line unless it is identically zero (in the algebraic sense) on that line (and in particular, on the extension of that line to the plane at infinity.) So the number of possible directions is bounded by the cardinality of ")#mi("{S_\\infty}")#text(", which is ")#mi("{O(k q^{d-2})}")#text(" by the ")#link("http://en.wikipedia.org/wiki/Schwartz%E2%80%93Zippel_lemma_and_testing_polynomial_identities")[#text("Schwartz-Zippel lemma")]#text(".")

#text("The second ingredient can be viewed as a high-degree analogue of such facts as “two points determine a line” or “three points determine a plane”, and is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-fa9383a4bc9106e8f9d9>#text(" If ")#mi("{E}")#text(" is a set of points in ")#mi("{{\\Bbb F}_q^d}")#text(", then ")#mi("{E}")#text(" is contained inside a hypersurface of degree ")#tao-math("{O( \\left|E\\right|^{1/d} )}", block: false)#text(".")
]

#text("Indeed, to prove this lemma one needs to find a non-trivial polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{D}")#text(" for some ")#tao-math("{D = O(\\left|E\\right|^{1/d})}", block: false)#text(" which vanishes at every point in ")#mi("{E}")#text(". But the vector space of polynomials of degree at most ")#mi("{D}")#text(" has dimension about ")#mi("{D^d}")#text(", and the requirement that ")#mi("{P}")#text(" vanish at every point in ")#mi("{E}")#text(" imposes ")#tao-math("{\\left|E\\right|}", block: false)#text(" linear constraints, so by linear algebra one can find such a polynomial as soon as the ")#mi("{D^d}")#text(" is much larger than ")#mi("{E}")#text(", and the claim follows.")

#text("Putting the two lemmas together, we see that any Kakeya set ")#mi("{E}")#text(" (which, by definition, contains lines in ")#mi("{\\gg q^{d-1}}")#text(" directions) cannot be contained in any hypersurface of degree much less than ")#mi("{q}")#text(", and thus must have cardinality ")#mi("{\\gg q^n}")#text(". (In fact, the optimal size of a Kakeya set is now known to be within a factor of ")#mi("{2}")#text(" of ")#mi("{2^{-n} q^n}")#text(", a result ")#link("http://arxiv.org/abs/0901.2529")[#text("of Dvir, Kopparty, Saraf, and Sudan")]#text(".) The argument can also be adapted to establish the maximal function estimate in finite field vector spaces, and also generalises to other families of curves in algebraic varieties, as was done recently ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("by Ellenberg, Oberlin, and myself")]#text(" (see this blog post for further discussion). There are even some tentative indications that these algebraic geometry methods will adapt well to more abstract algebraic settings, such as that of schemes.")

#heading(level: 1)[#strong[#text(" — 6. Algebraic topology — ")]]

#text("It was thought that the high-degree algebraic geometry methods of Dvir and others were strongly dependent on the discrete nature of the finite field setting, and would not extend to continuous settings such as that of Euclidean space. Very recently, however, ")#link("http://arxiv.org/abs/0811.2251")[#text("Larry Guth")]#text(" managed to partially extend Dvir’s results to this case. One key observation is to replace Lemma ")#link(<tao-fa9383a4bc9106e8f9d9>)[#text("2")]#text(" by a topological counterpart, namely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Polynomial Ham Sandwich theorem)")]#text(" If ")#mi("{B_1,\\ldots,B_N}")#text(" are a collection of bounded open sets in ")#mi("{{\\mathbb R}^d}")#text(", then there exists a hypersurface ")#mi("{\\{ x \\in {\\mathbb R}^d: P(x)=0\\}}")#text(" of degree ")#mi("{O(N^{1/d})}")#text(" which bisects each of these open sets (thus the sets ")#mi("{\\{ x \\in B_i: P(x) > 0 \\}}")#text(" and ")#mi("{\\{ x \\in B_i: P(x) < 0 \\}}")#text(" have equal volume).")
]

#text("Note that if one shrinks these bounded open sets ")#mi("{B_i}")#text(" to a tiny neighbourhood of points ")#mi("{x_i}")#text(", then in the limit one recovers the analogue of Lemma ")#link(<tao-fa9383a4bc9106e8f9d9>)[#text("2")]#text(" over the reals ")#mi("{{\\mathbb R}}")#text(" (note that the proof of Lemma ")#link(<tao-fa9383a4bc9106e8f9d9>)[#text("2")]#text(" is valid over any field). This allows one to adapt Dvir’s method to continuous settings, basically by replacing points by balls. (There is another ingredient needed, which is an isoperimetric-type inequality that asserts that if a hypersurface bisects a ball, then the intersection of that hypersurface with the ball has a large area; see ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("this blog post")]#text(" for further discussion.)")

#text("Unfortunately, the arguments, like the heat flow arguments, so far are restricted to the non-coplanar case, as otherwise certain Jacobian factors begin to enter in an unfavorable fashion in the estimates, so the Euclidean linear Kakeya problem has so far not been in impacted by these results. However, the arguments of Guth are able to recover the multilinear estimate ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(", and in fact can also remove the ")#mi("{\\delta^{-\\epsilon}}")#text(" loss, thus obtaining a very sharp estimate. Even more recently, ")#link("http://arxiv.org/abs/0812.1043")[#text("Guth and Katz have managed")]#text(" to solve a discrete analogue of the Euclidean Kakeya problem in which coplanarity has been eliminated by fiat, namely the ")#emph[#text("joints problem")]#text(" of Sharir. Define a ")#emph[#text("joint")]#text(" in ")#mi("{{\\mathbb R}^d}")#text(" to be a configuration of ")#mi("{d}")#text(" concurrent lines, which do not all lie in a hyperplane. ")#link("http://www.ams.org/mathscinet-getitem?mr=1280600")[#text("Sharir conjectured")]#text(" that a collection of ")#mi("{N}")#text(" lines in ")#mi("{{\\mathbb R}^d}")#text(" could form at most ")#mi("{O( N^{d/(d-1)} )}")#text(" joints (this is optimal, as can be seen by looking at lines parallel to the coordinate axes passing through a discrete cube of sidelength ")#mi("{O(N^{1/(d-1)})}")#text(" and unit spacing); this conjecture has now been verified by Guth and Katz, in the three-dimensional case at least. (The estimate ")#link(<tao-4a86480653049caa95e0>)[#text("(5)")]#text(" was already observed to be closely related to the joints problem ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("by Bennett, Carbery, and myself")]#text(", although it only gives a strong result in the case when one has a quantitative lower bound on the non-coplanarity of the joints.)")

#text("In summary, there has been an influx of techniques from many different areas of mathematics that have each contributed significant progress on the Kakeya conjecture. One may still need a couple more key ideas before the problem is finally solved in full, and such ideas may come from a quite unexpected source, but with the current rate of progress I am now optimistic that we will continue to see significant advances in this area in the near future.")

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38725")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Very nice exposition, Terry. One question: in inequality (1) (the “partial Kakeya” statement) should the exponent be d-n+eps rather than n-d+eps?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38728")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Jordan,")

#text("Actually I think the exponent is correct as it stands. (For instance, a single tube T has volume about ")#mi("\\delta^{n-1}")#text(", leading to the trivial bound that Kakeya sets have dimension at least 1.) The parameter ")#mi("\\delta")#text(" roughly speaking corresponds to the parameter ")#mi("1/q")#text(" in the finite field setting, and volume |E| in the Euclidean setting corresponds to normalised cardinality ")#mi("\\# E / q^n")#text(" in the finite field setting, so (1) corresponds to a lower bound of ")#mi("q^{d-\\varepsilon}")#text(" in the finite field case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38729")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Prof Tao,")

#text("I tried but could not reach Wolff’s paper from the link you gave.")

#text("is there any other way to find it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Anonymous,")

#text("I am not sure which of the two Wolff papers you are referring to, but the survey paper can also be downloaded from Izabella Laba’s web page at")

#link("http://www.math.ubc.ca/~ilaba/wolff/")[#text("http://www.math.ubc.ca/~ilaba/wolff/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38732")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")]

#text("[…] Recent progress on the Kakeya conjecture Below the fold is a version of my talk “Recent progress on the Kakeya conjecture” that I gave at the […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38733")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Terry is right, of course. So let me ask a more substantive question. As you say, there are two big difficulties with pushing through the multiscale analysis you mention. One is possible failure of coplanarity, the other is possible failure of stickiness. In section 4 you deal with the coplanarity problem by fiat. But is it possible to say something about how you ensure stickiness, or some appropriate stickiness substitute?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Ah, this is an interesting point. In the usual (linear) Kakeya conjecture, we now understand that it is essential that the lines (or tubes) all point in different directions, otherwise there are obvious counterexamples (e.g. in three dimensions, take the two-dimensional family of lines all lying in a plane). It is this requirement of distinct directions that forces one to require “stickiness” when trying a multiscale argument, because one needs the fat tubes to lie in ")#mi("\\sqrt{\\delta}")#text("-separated directions.")

#text("But curiously enough, when one banishes coplanarity by working with the multilinear formulation of the Kakeya problem, then one no longer needs the distinct directions hypothesis. This is easiest to see in two dimensions in finite fields: if one had two families ")#mi("L, L^{\\prime}")#text(" of lines, which were transverse in the sense that no line in L pointed in the same direction as a line in L’, then we have the obvious bound")

#tao-math("\\displaystyle \\left\\| (\\sum_{\\ell \\in L} 1_{\\ell}) (\\sum_{\\ell^{\\prime} \\in L^{\\prime}} 1_{\\ell^{\\prime}}) \\right\\|_{\\ell^1(F^2)} \\leq \\left|L\\right| \\left|L^{\\prime}\\right|", block: false)

#text("which is just asserting Euclid’s postulate that two transverse lines intersect in at most one point. (In fact this inequality is even an equality.) The point here is that we don’t care if the lines in L point in distinct directions or not, or if the lines in L’ point in distinct directions or not; it only matters that the lines in L point in distinct directions to the lines in L’.")

#text("Because one no longer cares about distinct directions, the whole stickiness issue fades away in the multilinear setting, and the multiscale argument becomes very clean.")

#text("This is perhaps a key reason why the multiscale or heat flow arguments do not seem to extend to the linear setting – we don’t know how to make them exploit the distinct directions hypothesis. (To a lesser extent, this was one of the main limitations to the incidence geometry method, though after Dvir’s result we now have some idea how to exploit distinct directions via algebraic geometry.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e05a7ff1e23cef0d9904342c78588043db6fb2be2f3034e041cc3ba3abcfd0b-1cf7ab56d224fc2381afac68bbf0bb069b6e3b8b3301bd6c566d4b44edd08419.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Oberlin")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38736")[#strong[#text("Richard Oberlin")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")])]

#text("Nice blog article; I have a nitpicky comment on your history of the incidence geometry strategy, You list Drury’s result as progress on the set problem rather than the maximal operator problem. Although neither of these problems are explicitly mentioned in the paper, his X-ray transform estimate would seem to be slightly stronger than the corresponding maximal operator bound. Maybe you had meant to make some sort of distinction about the endpoint d=(n+1)/2?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38737")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")])]

#text("Ah right, yes, Drury’s x-ray transform result does imply both the set and maximal versions up to n+1/2, and Christ et al prove a refined estimate at the endpoint n+1/2. I’ll adjust the text accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38766")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("” Sharir conjectured that a collection of lines in could form at most joints (this is optimal, as can be seen by looking at lines parallel to the coordinate axes passing through a discrete cube of sidelength and unit spacing); this conjecture has now been verified by Guth and Katz. ”")

#text("The paper by Guth and Katz and a subsequent paper by Elekes, Kaplan and Sharir deal only with the three dimensional case. Are you referring to a more recent developement?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38771")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("Hmm, good point; I’ve adjusted the text accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The two-ends reduction for the Kakeya maximal conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38777")[#strong[#text("The two-ends reduction for the Kakeya maximal conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("[…] discussed in the previous post, the Kakeya maximal function conjecture in can be formulated as follows: Conjecture 1 (Kakeya […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 5: Hausdorff dimension (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-38865")[#strong[#text("245C, Notes 5: Hausdorff dimension (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2009")])]

#text("[…] in particular, to conclude such bounds from the Kakeya maximal function conjecture, as discussed in this previous post). Exercise 22 Let be a Borel set, and let be a locally Lipschitz map. Show that , and that if […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-39179")[#strong[#text("Kakeya猜想的最新进展 « Junfli’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2009")]

#text("[…] Kakeya猜想的最新进展 By junfli 为了促进学习，打算翻译Terrence Tao博客上的这篇文章。题目是：Recent progress on Kakeya Conjecture.. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-39190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2009")])]

#text("The solution to the joints problem in any dimension has appeared on the arXiv in two papers:")

#link("http://arxiv.org/abs/0906.0558")[#text("http://arxiv.org/abs/0906.0558")]#text(" and")#linebreak()#text(" ")#link("http://arxiv.org/abs/0906.0555")[#text("http://arxiv.org/abs/0906.0555")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-39217")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("Well, indeed the higher dimensional case of Sharir’s conjecture was settled by similar methods, and the proof was even further simplified by Kaplan, Sharir and Shustin here:")

#link("http://front.math.ucdavis.edu/0906.0558")[#text("http://front.math.ucdavis.edu/0906.0558")]

#text("Is there something known about this problem? Problem: What is the maximum number of incidences between s lines and t planes in ?")

#text("I do not know if it has a Kakeya connection unless we consider instead of sets in Euclidean spaces sets in Grasmannians. But do we want to do it?")

#text("(I mentioned this problem here:")#linebreak()#text(" ")#link("http://gilkalai.wordpress.com/2008/07/17/extermal-combinatorics-ii-some-geometry-and-number-theory/")[#text("http://gilkalai.wordpress.com/2008/07/17/extermal-combinatorics-ii-some-geometry-and-number-theory/")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-39218")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("And as anonymous pointed out (but I missed it) also René Quilodrán proved the high dimensional case here ")#link("http://arxiv.org/abs/0906.0555")[#text("http://arxiv.org/abs/0906.0555")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-39219")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("The problem should be:")#linebreak()#text(" Problem: What is the maximum number of incidences between s lines and t planes in ")#mi("R^d")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More Mahler lectures « What’s new")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-41239")[#strong[#text("More Mahler lectures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("[…] Recent progress on the Kakeya conjecture. This is an updated and reformatted version of my Fefferman conference lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-44011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2010")])]

#text("I have a question concerning something in your Edinburgh lecture notes on the Kakeya problem. I apologize if this is not the appropriate place for such a question.")

#text("My question concerns the process of converting the argument using “two lines intersect in at most one point” to the continuous setting (pp 15-16 in notes). The following discussion simply concerns the case ")#mi("n = 2")#text(". You state that ")#tao-math("\\left|A\\right| \\approx 1", block: false)#text(" and the number of pairs of tubes with separation ")#mi("\\sim \\theta")#text(" is ")#mi("O(\\theta)")#text(".")

#text("However, if I take my directions in ")#mi("S^1")#text(" to be ")#mi("(\\cos(\\frac{\\pi k}{2 N}), \\sin(\\frac{\\pi k}{2N})")#text(" for ")#mi("k = 0, 1, 2, \\dots, N")#text(" for some ")#mi("N \\in \\mathbf{N}")#text(". (Obviously this set of directions isn’t saturated but that doesn’t matter for what follows.)")

#text("Then, using your estimate on the intersection of two tubes, I have calculated that ")#mi("A")#text(" grows logarithmically in ")#mi("N")#text(" and that the number of pairs of tubes with separation ")#mi("\\sim \\frac{\\pi}{2 N}")#text(" is ")#mi("N")#text(".")

#text("I am obviously missing something simple but I just cannot see it! Any help would be appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-44013")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2010")])]

#text("The ")#mi("\\approx")#text(" notation absorbs logarithmic losses, so for instance ")#mi("\\log N \\approx 1")#text(".")

#text("The number of pairs of tubes with separation ")#mi("\\sim \\theta")#text(" is ")#mi("O( \\delta^{1-n} (\\theta/\\delta)^{n-1} )")#text(", which is ")#mi("O( \\delta^{-2} \\theta )")#text(" (not ")#mi("O(\\theta)")#text(") in two dimensions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-44023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2010")])]

#text("I feel a little silly for how obvious the answer was but I very much appreciate your help.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hu")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-472867")[#strong[#text("Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2016")])]

#text("Dear Prof Tao,")

#text("Nice blog article,i have several questions with this article.")

#text("but i know you is very busy so i ask the most important one.")

#text("follows the proof strategy called Multiscale analysis,although we can use the estimate with large $\\delta_1$ to get estimate with small $\\delta_2$,(may be loss some $\\delta^c$ in the inequality in this way),but the main difficult is we should proof the new tubes with scales $\\delta_2$ is contains in the the olders.as soon as we proof this ,to obtain a lower bound of minkwoski dimension with kakeya set, suffice to get following estimate :")#linebreak()#text(" the new cubes with scale $\\delta_2$ contains a positive constants volumes of every old cubes with scale $\\delta_1$.")#linebreak()#text(" this type of estimate is easy to attain because it is very similar to the “principle of close packing of spheres”.")

#text("in general ,we should not expect this claims:")#linebreak()#text(" the new tubes with scales $\\delta_2$ is contains in the the older.")

#text("but if we can proof in some sense most of new tubes comes from this way maybe we can make progress on the original problem.")

#text("roughly speaking,we should partition the whole set of $T_{\\delta}$ into two part,comes from old ones or not,for the first kind i.e contains in a old one,use the way explained above to treat.the second kind we need to proof the influence is very some or we can sometimes use the cubes from the first kind to instead the cubes from second kind and the measure of $|A|_{\\delta}$ change little.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hu")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-472923")[#strong[#text("Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2016")])]

#text("Dear Prof Tao,")

#text("Nice blog article,i have several questions with this article.")

#text("but i know you is very busy so i ask the most important one.")

#text("follows the proof strategy called Multiscale analysis,although we can use the estimate with large ")#mi("\\delta_1")#text(" to get estimate with small ")#mi("\\delta_2")#text(",(may be loss some ")#mi("\\delta^c")#text(" in the inequality in this way),but the main difficult is we should proof the new tubes with scales ")#mi("\\delta_2")#text(" is contains in the the olders.as soon as we proof this ,to obtain a lower bound of minkwoski dimension with kakeya set, suffice to get following estimate :")#linebreak()#text(" the new cubes with scale ")#mi("\\delta_2")#text(" contains a positive constants volumes of every old cubes with scale ")#mi("\\delta_1")#text(".")#linebreak()#text(" this type of estimate is easy to attain because it is very similar to the “principle of close packing of spheres”.")

#text("in general ,we should not expect this claims:")#linebreak()#text(" the new tubes with scales ")#mi("\\delta_2")#text(" is contains in the the older.")

#text("but if we can proof in some sense most of new tubes comes from this way maybe we can make progress on the original problem.")

#text("roughly speaking,we should partition the whole set of ")#mi("T_{\\delta}")#text(" into two part,comes from old ones or not,for the first kind i.e contains in a old one,use the way explained above to treat.the second kind we need to proof the influence is very some or we can sometimes use the cubes from the first kind to instead the cubes from second kind and the measure of ")#tao-math("\\left|A\\right|_{\\delta}", block: false)#text(" change little.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-487234")[#strong[#text("Kakeya Conjecture | Relationship of relationship")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2017")]

#text("[…] year I read a nice blog articles Recent progress on the Kakeya conjecture and have several questions with this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-487398")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2017")])]

#text("I definitely have more information,or even a whole new frame to deal with the kakeya conjecture with minkwoski dimension,but the steps have not establish in a rigorous way,so I would not post it out at this time,maybe never")#linebreak()#text(" …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OneGuy")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-506571")[#strong[#text("OneGuy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("I have a new way to attack the Kakeya conjectures, when n > 2. In the tube version, the problem is that one tube can intersect many of the “bushes”. Now, we can rotate each tube just a tiny amount,say c, if needed, and end up in a construction where each central line of any tube intersects only one bush. Then we scale the fatness of the tubes to really thin, so that only central lines of the tubes intersect, if the (skinny) tubes intersect at all. This kind of tube set is easy to estimate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OneGuy")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-506572")[#strong[#text("OneGuy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("Then you can just think like this: First scale the tubes a tiny amount and rotate the tubes, if necessary, even tinier amount so that the resulting set includes the original tube set. Then use the properties of the integral, a standard dyadic decomposition and scaling to prove the Kakeya maximal function conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-519229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2019")])]

#text("It seems the equation after (4) should have $q^n$ instead of $q^d$.")

#text("One question: does Dvir’s approach solve the maximal version for finite fields?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-519254")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2019")])]

#text("Thanks for the correction! With Jordan Ellenberg and Richard Oberlin, we adapted Dvir’s method to control the Kakeya maximal function, see ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-519259")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2019")])]

#text("Many thanks for the link!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-649091")[#strong[#text("Kakeya Conjecture - Relationship of relationship")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2022")]

#text("[…] year I read a nice blog articles Recent progress on the Kakeya conjecture and have several questions with this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-677882")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2023")])]

#text("“From this sequence, it seems that one needs to imply increasingly “high-degree” facts from incidence geometry to make deeper progress on the Kakeya conjecture, in particular one begins to transition from incidence geometry to algebraic geometry.”")

#text("In retrospect that is not a good strategy to attack the problem. More likely than to get different facts for each (at least low) dimensions, you need one set of incidence facts for all dimension uniformly, if we assume that the Kakeya conjecture is true for all dimensions n. Otherwise Kakeya is true in different dimensions for different reasons. Moreover, very likely you need in addition metric concepts which are uniform in dimension n, which are for gödelian reasons stronger than concepts from incidence geometry. The geometry starts from the metric concepts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/05/11/recent-progress-on-the-kakeya-conjecture/#comment-687450")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2025")])]

#text("This piece of LaTeX does not parse: ")#raw("respectively for some $latex {1 leq i ...}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
