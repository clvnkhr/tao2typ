// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/
// Converted to Typst by tao2typ: "2026-10-14T10:37:04.167332+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246A, Notes 2: complex integration", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246A, Notes 2: complex integration")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 September 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("Notes 1")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(".")#linebreak()#text(" Having discussed differentiation of complex mappings in the preceding notes, we now turn to the integration of complex maps. We first briefly review the situation of integration of (suitably regular) real functions ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" of one variable. Actually there are ")#emph[#text("three")]#text(" closely related concepts of integration that arise in this setting:")

#list(
[#text("(i) The ")#link("https://en.wikipedia.org/wiki/Integral")[#text("signed definite integral")]#text(" ")#mi("{\\int_a^b f(x)\\ dx}")#text(", which is usually interpreted as the ")#link("https://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(" (or equivalently, the ")#link("https://en.wikipedia.org/wiki/Darboux_integral")[#text("Darboux integral")]#text("), which can be defined as the limit (if it exists) of the ")#link("https://en.wikipedia.org/wiki/Riemann_sum")[#text("Riemann sums")]

#metadata(none) <tao-b9cc272cfc2456cfa99f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{j=1}^n f(x_j^*) (x_j - x_{j-1})")]]

#text("where ")#mi("{a = x_0 < x_1 < \\dots < x_n = b}")#text(" is some ")#link("https://en.wikipedia.org/wiki/Partition_of_an_interval")[#text("partition")]#text(" of ")#mi("{[a,b]}")#text(", ")#mi("{x_j^*}")#text(" is an element of the interval ")#mi("{[x_{j-1},x_j]}")#text(", and the limit is taken as the maximum mesh size ")#tao-math("{\\max_{1 \\leq j \\leq n} \\left|x_j - x_{j-1}\\right|}", block: false)#text(" goes to zero (this can be formalised using the concept of a ")#link("https://en.wikipedia.org/wiki/Net_(mathematics)")[#text("net")]#text("). It is convenient to adopt the convention that ")#mi("{\\int_b^a f(x)\\ dx := - \\int_a^b f(x)\\ dx}")#text(" for ")#mi("{a < b}")#text("; alternatively one can interpret ")#mi("{\\int_b^a f(x)\\ dx}")#text(" as the limit of the Riemann sums ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(1)")]#text(", where now the (reversed) partition ")#mi("{b = x_0 > x_1 > \\dots > x_n = a}")#text(" goes leftwards from ")#mi("{b}")#text(" to ")#mi("{a}")#text(", rather than rightwards from ")#mi("{a}")#text(" to ")#mi("{b}")#text(".")],
[#text("(ii) The ")#emph[#text("unsigned definite integral")]#text(" ")#mi("{\\int_{[a,b]} f(x)\\ dx}")#text(", usually interpreted as the ")#link("https://en.wikipedia.org/wiki/Lebesgue_integration")[#text("Lebesgue integral")]#text(". The precise definition of this integral is a little complicated (see e.g. ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("this previous post")]#text("), but roughly speaking the idea is to approximate ")#mi("{f}")#text(" by simple functions ")#mi("{\\sum_{i=1}^n c_i 1_{E_i}}")#text(" for some coefficients ")#mi("{c_i \\in {\\bf R}}")#text(" and sets ")#mi("{E_i \\subset [a,b]}")#text(", and then approximate the integral ")#mi("{\\int_{[a,b]} f(x)\\ dx}")#text(" by the quantities ")#mi("{\\sum_{i=1}^n c_i m(E_i)}")#text(", where ")#mi("{m(E_i)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" of ")#mi("{E_i}")#text(". In contrast to the signed definite integral, no orientation is imposed or used on the underlying domain of integration, which is viewed as an “undirected” set ")#mi("{[a,b]}")#text(".")],
[#text("(iii) The ")#emph[#text("indefinite integral")]#text(" or ")#link("https://en.wikipedia.org/wiki/Antiderivative")[#text("antiderivative")]#text(" ")#mi("{\\int f(x)\\ dx}")#text(", defined as any function ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" whose derivative ")#mi("{F^{\\prime}}")#text(" exists and is equal to ")#mi("{f}")#text(" on ")#mi("{[a,b]}")#text(". Famously, the antiderivative is only defined up to the addition of an arbitrary constant ")#mi("{C}")#text(", thus for instance ")#mi("{\\int x\\ dx = \\frac{1}{2} x^2 + C}")#text(".")]
)

#text("There are some other variants of the above integrals (e.g. the ")#link("https://en.wikipedia.org/wiki/Henstock%E2%80%93Kurzweil_integral")[#text("Henstock-Kurzweil integral")]#text(", discussed for instance in ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("this previous post")]#text("), which can handle slightly different classes of functions and have slightly different properties than the standard integrals listed here, but we will not need to discuss such alternative integrals in this course (with the exception of some ")#link("https://en.wikipedia.org/wiki/Improper_integral")[#text("improper")]#text(" and ")#link("https://en.wikipedia.org/wiki/Cauchy_principal_value")[#text("principal value integrals")]#text(", which we will encounter in later notes).")#linebreak()#text(" The above three notions of integration are closely related to each other. For instance, if ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is a Riemann integrable function, then the signed definite integral and unsigned definite integral coincide (when the former is oriented correctly), thus")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x)\\ dx = \\int_{[a,b]} f(x)\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_b^a f(x)\\ dx = -\\int_{[a,b]} f(x)\\ dx")]]

#text("If ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is continuous, then by the fundamental theorem of calculus, it possesses an antiderivative ")#mi("{F = \\int f(x)\\ dx}")#text(", which is well defined up to an additive constant ")#mi("{C}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\int_c^d f(x)\\ dx = F(d) - F(c)")]]

#text("for any ")#mi("{c,d \\in [a,b]}")#text(", thus for instance ")#mi("{\\int_a^b f(x)\\ dx = F(b) - F(a)}")#text(" and ")#mi("{\\int_b^a f(x)\\ dx = F(a) - F(b)}")#text(".")#linebreak()#text(" All three of the above integration concepts have analogues in complex analysis. By far the most important notion will be the complex analogue of the signed definite integral, namely the ")#link("https://en.wikipedia.org/wiki/Methods_of_contour_integration")[#text("contour integral")]#text(" ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(", in which the directed line segment from one real number ")#mi("{a}")#text(" to another ")#mi("{b}")#text(" is now replaced by a type of curve in the complex plane known as a contour. The contour integral can be viewed as the special case of the more general ")#link("https://en.wikipedia.org/wiki/Line_integral")[#text("line integral")]#text(" ")#mi("{\\int_\\gamma f(z) dx + g(z) dy}")#text(", that is of particular relevance in complex analysis. There are also analogues of the Lebesgue integral, namely the arclength measure integrals ")#tao-math("{\\int_\\gamma f(z)\\ \\left|dz\\right|}", block: false)#text(" and the area integrals ")#mi("{\\int_\\Omega f(x+iy)\\ dx dy}")#text(", but these play only an auxiliary role in the subject. Finally, we still have the notion of an antiderivative ")#mi("{F(z)}")#text(" (also known as a ")#emph[#text("primitive")]#text(") of a complex function ")#mi("{f(z)}")#text(".")#linebreak()#text(" As it turns out, the fundamental theorem of calculus continues to hold in the complex plane: under suitable regularity assumptions on a complex function ")#mi("{f}")#text(" and a primitive ")#mi("{F}")#text(" of that function, one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz = F(z_1) - F(z_0)")]]

#text("whenever ")#mi("{\\gamma}")#text(" is a contour from ")#mi("{z_0}")#text(" to ")#mi("{z_1}")#text(" that lies in the domain of ")#mi("{f}")#text(". In particular, functions ")#mi("{f}")#text(" that possess a primitive must be ")#link("https://en.wikipedia.org/wiki/Conservative_force")[#text("conservative")]#text(" in the sense that ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for any closed contour. This property of being conservative is not typical, in that “most” functions ")#mi("{f}")#text(" will not be conservative. However, there is a remarkable and far-reaching theorem, the ")#link("https://en.wikipedia.org/wiki/Cauchy%27s_integral_theorem")[#text("Cauchy integral theorem")]#text(" (also known as the Cauchy-Goursat theorem), which asserts that any holomorphic function is conservative, so long as the domain is ")#link("https://en.wikipedia.org/wiki/Simply_connected_space")[#text("simply connected")]#text(" (or if one restricts attention to ")#link("https://en.wikipedia.org/wiki/Contractible_space")[#text("contractible")]#text(" closed contours). We will explore this theorem and several of its consequences in the next set of notes.")#linebreak()#text(" ")#metadata(none) <tao-a19a9e38b4121cd794e3>

#heading(level: 1)[#strong[#text(" — 1. Integration along a contour — ")]]

#text("The notion of a curve is a very intuitive one. However, the precise mathematical definition of what a curve actually is depends a little bit on what type of mathematics one wishes to do. If one is mostly interested in topology, then a good notion is that of a ")#link("https://en.wikipedia.org/wiki/Curve")[#text("continuous (parameterised) curve")]#text(". If one wants to do analysis in somewhat irregular domains, it is convenient to restrict the notion of curve somewhat, to the ")#link("https://en.wikipedia.org/wiki/Rectifiable_curve")[#text("rectifiable curves")]#text(". If one is doing analysis in “nice” domains (such as the complex plane ")#mi("{{\\bf C}}")#text(", a half-plane, a punctured plane, a disk, or an annulus), then it is convenient to restrict the notion further, to the ")#emph[#text("piecewise smooth curves")]#text(", also known as ")#link("https://en.wikipedia.org/wiki/Contour_integration")[#text("contours")]#text(". If one wished to get to the main theorems of complex analysis as quickly as possible, then one would restrict attention only to contours and skip much of this section; however we shall take a more leisurely approach here, discussing curves and rectifiable curves as well, as these concepts are also useful outside of complex analysis. In fact, we will structure our notes so that most of our theorems in fact apply to rectifiable curves (and several will in fact be applicable to arbitrary continuous curves).")#linebreak()#text(" We begin by defining the notion of a continuous curve.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Continuous curves)")]#text(" A ")#emph[#text("continuous parameterised curve")]#text(", or ")#emph[#text("curve")]#text(" for short, is a continuous map ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" from a compact interval ")#mi("{[a,b] \\subset {\\bf R}}")#text(" to the complex plane ")#mi("{{\\bf C}}")#text(". We call the curve ")#emph[#text("trivial")]#text(" if ")#mi("{a=b}")#text(", and ")#emph[#text("non-trivial")]#text(" otherwise. We refer to the complex numbers ")#mi("{\\gamma(a), \\gamma(b)}")#text(" as the ")#emph[#text("initial point")]#text(" and ")#emph[#text("terminal point")]#text(" (or ")#emph[#text("final point")]#text(") of the curve respectively, and refer to these two points collectively as the ")#emph[#text("endpoints")]#text(" of the curve. We say that the curve is ")#emph[#text("closed")]#text(" if ")#mi("{\\gamma(a) = \\gamma(b)}")#text(". We say that the curve is ")#emph[#text("simple")]#text(" if one has ")#mi("{\\gamma(t) \\neq \\gamma(t^{\\prime})}")#text(" for any distinct ")#mi("{t,t^{\\prime} \\in [a,b]}")#text(", with the possible exception of the endpoint cases ")#mi("{t=a, t^{\\prime}=b}")#text(" or ")#mi("{t=b, t^{\\prime}=a}")#text(" (thus we allow closed curves to be simple). We refer to the subset ")#mi("{\\gamma([a,b]) := \\{ \\gamma(t): t \\in [a,b]\\}}")#text(" of the complex plane as the ")#emph[#text("image")]#text(" of the curve.")
]

#text("We caution that the term “closed” here does ")#emph[#text("not")]#text(" refer to the topological notion of closure: for any curve ")#mi("{\\gamma}")#text(" (closed or otherwise), the image ")#mi("{\\gamma([a,b])}")#text(" of the curve, being the continuous image of a compact set, is necessarily a compact subset of ")#mi("{{\\bf C}}")#text(" and is thus always topologically closed.")#linebreak()#text(" A basic example of a curve is the directed line segment ")#mi("{\\gamma_{z_1 \\rightarrow z_2}: [0,1] \\rightarrow {\\bf C}}")#text(" from one complex point ")#mi("{z_1}")#text(" to another ")#mi("{z_2}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\gamma_{z_1 \\rightarrow z_2}(t) := (1-t) z_1 + t z_2")]]

#text("for ")#mi("{0 \\leq t \\leq 1}")#text(". (Thus, contrary to the informal English meaning of the terms, we consider line segments to be examples of curves, despite having zero curvature; in general, it is convenient in mathematics to admit such “degenerate” objects into one’s definitions, in order to obtain good closure properties for these objects, and to maximise the generality of the definition.) If ")#mi("{z_1 \\neq z_2}")#text(", this is a simple curve, while for ")#mi("{z_1 = z_2}")#text(" it is (a rather degenerate, but still non-trivial) closed curve. Another important example of a curve is the anti-clockwise circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}: [0,2\\pi] \\rightarrow {\\bf C}}")#text(" of some radius ")#mi("{r>0}")#text(" around a complex centre ")#mi("{z_0 \\in {\\bf C}}")#text(", defined by ")#metadata(none) <tao-104614612766209ec154>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\gamma_{z_0,r,\\circlearrowleft}(\\theta) := z_0 + r e^{i\\theta}.")]]

#text("This is a simple closed non-trivial curve. If we extended the domain here from ")#mi("{[0,2\\pi]}")#text(" to (say) ")#mi("{[0,4\\pi]}")#text(", the curve would remain closed, but would no longer be simple (every point in the image is now traversed twice by the curve).")#linebreak()#text(" Note that it is technically possible for two distinct curves to have the same image. For instance, the anti-clockwise circle ")#mi("{\\tilde \\gamma_{z_0,r,\\circlearrowleft}: [0,1] \\rightarrow {\\bf C}}")#text(" of some radius ")#mi("{r>0}")#text(" around a complex centre ")#mi("{z_0 \\in {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\tilde \\gamma_{z_0,r,\\circlearrowleft}(\\theta) := z_0 + r e^{2\\pi i \\theta}")]]

#text("traverses the same image as the previous curve ")#link(<tao-104614612766209ec154>)[#text("(2)")]#text(", but is considered a distinct curve from ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(". Nevertheless the two curves are closely related to each other, and we formalise this as follows. We say that one curve ")#mi("{\\gamma_2: [a_2,b_2] \\rightarrow {\\bf C}}")#text(" is a ")#emph[#text("continuous reparameterisation")]#text(" of another ")#mi("{\\gamma_1: [a_1, b_1] \\rightarrow {\\bf C}}")#text(", if there is a ")#link("https://en.wikipedia.org/wiki/Homeomorphism")[#text("homeomorphism")]#text(" ")#mi("{\\phi: [a_1,b_1] \\rightarrow [a_2,b_2]}")#text(" (that is to say, a continuous invertible map whose inverse ")#mi("{\\phi^{-1}: [a_2,b_2] \\rightarrow [a_1,b_1]}")#text(" is also continuous) which is endpoint preserving (i.e., ")#mi("{\\phi(a_1)=a_2}")#text(" and ")#mi("{\\phi(b_1)=b_2}")#text(") such that ")#mi("{\\gamma_2(\\phi(t)) = \\gamma_1(t)}")#text(" for all ")#mi("{t \\in [a_1,b_1]}")#text(" (that is to say, ")#mi("{\\gamma_1 = \\gamma_2 \\circ \\phi}")#text(", or equivalently ")#mi("{\\gamma_2 = \\gamma_1 \\circ \\phi^{-1}}")#text("), in which case we write ")#mi("{\\gamma_1 \\equiv \\gamma_2}")#text(". Thus for instance ")#mi("{\\gamma_{z_0,r,\\circlearrowleft} \\equiv \\tilde \\gamma_{z_0,r,\\circlearrowleft}}")#text(". The relation of being a continuous reparameterisation is an ")#link("https://en.wikipedia.org/wiki/Equivalence_relation")[#text("equivalence relation")]#text(", so one can talk about the notion of a curve “up to continuous reparameterisation”, by which we mean an ")#link("https://en.wikipedia.org/wiki/Equivalence_class")[#text("equivalence class")]#text(" of a curve under this relation. Thus for instance the image of a curve, as well as its initial point and end point, are well defined up to continuous reparameterisation, since if ")#mi("{\\gamma_1 \\equiv \\gamma_2}")#text(" then ")#mi("{\\gamma_1}")#text(" and ")#mi("{\\gamma_2}")#text(" have the same image, the same initial point, and the same terminal point. It is common to depict an equivalence class of a curve ")#mi("{\\gamma}")#text(" graphically, by drawing its image together with an arrow depicting the direction of motion from the initial point to its endpoint. (In the case of a non-simple curve, one may need multiple arrows in order to clarify the direction of motion, and also the possible multiplicity of the curve.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{\\phi: [a_1,b_1] \\rightarrow [a_2,b_2]}")#text(" be a continuous invertible map.")

#list(
[#text("(i) Show that ")#mi("{\\phi^{-1}: [a_2,b_2] \\rightarrow [a_1,b_1]}")#text(" is continuous, so that ")#mi("{\\phi}")#text(" is a homeomorphism. (")#emph[#text("Hint:")]#text(" use the fact that a continuous image of a compact set is compact, and that a subset of an interval is topologically closed if and only if it is compact.)")],
[#text("(ii) If ")#mi("{\\phi(a_1)=a_2}")#text(", show that ")#mi("{\\phi(b_1) = b_2}")#text(" and that ")#mi("{\\phi}")#text(" is monotone increasing. (")#emph[#text("Hint:")]#text(" use the intermediate value theorem.)")],
[#text("(iii) Conversely, if ")#mi("{\\psi: [a_1,b_1] \\rightarrow [a_2,b_2]}")#text(" is a continuous monotone increasing map with ")#mi("{\\psi(a_1) = a_2}")#text(" and ")#mi("{\\psi(b_1) = b_2}")#text(", show that ")#mi("{\\psi}")#text(" is a homeomorphism.")]
)
]

#text("It will be important for us that we do not allow reparameterisations to reverse the endpoints. For instance, if ")#mi("{z_1,z_2}")#text(" are distinct points in the complex plane, the directed line segment ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(" is ")#emph[#text("not")]#text(" a reparameterisation of the directed line segment ")#mi("{\\gamma_{z_2 \\rightarrow z_1}}")#text(" since they do not have the same initial point (or same terminal point); the map ")#mi("{t \\mapsto 1-t}")#text(" is a homeomorphism from ")#mi("{[0,1]}")#text(" to ")#mi("{[0,1]}")#text(" but it does not preserve the initial point or the terminal point. In general, given a curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(", we define its ")#emph[#text("reversal")]#text(" ")#mi("{-\\gamma: [-b,-a] \\rightarrow {\\bf C}}")#text(" to be the curve ")#mi("{(-\\gamma)(t) := \\gamma(-t)}")#text(", thus for instance ")#mi("{\\gamma_{z_2 \\rightarrow z_1}}")#text(" is (up to reparameterisation) the reversal of ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\gamma_{z_2 \\rightarrow z_1} \\equiv - \\gamma_{z_1 \\rightarrow z_2}.")]]

#text("Another basic operation on curves is that of concatenation. Suppose we have two curves ")#mi("{\\gamma_1: [a_1,b_1] \\rightarrow {\\bf C}}")#text(" and ")#mi("{\\gamma_2: [a_2,b_2] \\rightarrow {\\bf C}}")#text(" with the property that the terminal point ")#mi("{\\gamma_1(b_1)}")#text(" of ")#mi("{\\gamma_1}")#text(" equals the initial point ")#mi("{\\gamma_2(a_2)}")#text(" of ")#mi("{\\gamma_2}")#text(". We can reparameterise ")#mi("{\\gamma_2}")#text(" by translation to ")#mi("{\\tilde \\gamma_2: [b_1, b_2+b_1-a_2] \\rightarrow {\\bf C}}")#text(", defined by ")#mi("{\\tilde \\gamma_2(t) := \\gamma_2(t - b_1 + a_2)}")#text(". We then define the ")#emph[#text("concatenation")]#text(" or ")#emph[#text("sum")]#text(" ")#mi("{\\gamma_1 + \\gamma_2: [a_1, b_2+b_1-a_2] \\rightarrow {\\bf C}}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("(\\gamma_1 + \\gamma_2)(t) := \\gamma_1(t)")]]

#text("for ")#mi("{a_1 \\leq t \\leq b_1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("(\\gamma_1 + \\gamma_2)(t) := \\tilde \\gamma_2(t)")]]

#text("for ")#mi("{b_1 \\leq t \\leq b_2+b_1-a_2}")#text(" (note that these two definitions agree on their common domain point ")#mi("{t=b_1}")#text(" by the hypothesis ")#mi("{\\gamma_1(b_1) = \\gamma_2(a_2)}")#text(". It is easy to see that this concatenation ")#mi("{\\gamma_1+\\gamma_2}")#text(" is still a continuous curve. The reader at this point is encouraged to draw a picture to understand what the concatenation operation is doing; it is much simpler to grasp it visually than the above lengthy definition may suggest. If the terminal point of ")#mi("{\\gamma_1}")#text(" does not equal the initial point of ")#mi("{\\gamma_2}")#text(", we leave the sum ")#mi("{\\gamma_1+\\gamma_2}")#text(" undefined. (One can define more general spaces than the space of curves in which such an addition can make sense, such as the space of ")#link("https://en.wikipedia.org/wiki/Current_(mathematics)")[#mi("{1}")#text("-currents")]#text(" if one assumes some rectifiability on the curves, or the space of ")#link("https://en.wikipedia.org/wiki/Chain_(algebraic_topology)")[#mi("{1}")#text("-chains")]#text(", but we will not need such general spaces here.)")#linebreak()#text(" Concatenation is well behaved with respect to equivalence and reversal:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-f3fc1ffa25bbd454fe6a>#text(" Let ")#mi("{\\gamma_1, \\gamma_2, \\gamma_3, \\tilde \\gamma_1, \\tilde \\gamma_2}")#text(" be continuous curves. Suppose that the terminal point of ")#mi("{\\gamma_1}")#text(" equals the initial point of ")#mi("{\\gamma_2}")#text(", and the terminal point of ")#mi("{\\gamma_2}")#text(" equals the initial point of ")#mi("{\\gamma_3}")#text(".")

#list(
[#text("(i) (Concatenation and reversal well defined up to equivalence) If ")#mi("{\\gamma_1 \\equiv \\tilde \\gamma_1}")#text(" and ")#mi("{\\gamma_2 \\equiv \\tilde \\gamma_2}")#text(", show that ")#mi("{\\gamma_1+\\gamma_2 \\equiv \\tilde \\gamma_1 + \\tilde \\gamma_2}")#text(" and ")#mi("{-\\gamma_1 \\equiv - \\tilde \\gamma_1}")#text(".")],
[#text("(ii) (Concatenation associative) Show that ")#mi("{(\\gamma_1+\\gamma_2)+\\gamma_3 = \\gamma_1 + (\\gamma_2 + \\gamma_3)}")#text(". In particular, we certainly have ")#mi("{(\\gamma_1+\\gamma_2)+\\gamma_3 \\equiv \\gamma_1 + (\\gamma_2 + \\gamma_3)}")],
[#text("(iii) (Concatenation and reversal) Show that ")#mi("{-(\\gamma_1+\\gamma_2) \\equiv (-\\gamma_2) + (-\\gamma_1)}")#text(".")],
[#text("(iv) (Non-commutativity) Give an example in which ")#mi("{\\gamma_1+\\gamma_2}")#text(" and ")#mi("{\\gamma_2+\\gamma_1}")#text(" are both well-defined, but not equivalent to each other.")],
[#text("(v) (Identity) If ")#mi("{z_1}")#text(" and ")#mi("{z_2}")#text(" denote the initial and terminal points of ")#mi("{\\gamma_1}")#text(" respectively, and ")#mi("{\\delta_z: [0,0] \\rightarrow {\\bf C}}")#text(" is the trivial curve ")#mi("{\\delta_z: 0 \\rightarrow z}")#text(" defined for any ")#mi("{z \\in {\\bf C}}")#text(", show that ")#mi("{\\delta_{z_1} + \\gamma_1 \\equiv \\gamma_1}")#text(" and ")#mi("{\\gamma_1 + \\delta_{z_2} \\equiv \\gamma_1}")#text(".")],
[#text("(vi) (Non-invertibility) Give an example in which ")#mi("{\\gamma_1 + (-\\gamma_1)}")#text(" is not equivalent to a trivial curve. (It will however be ")#link("https://en.wikipedia.org/wiki/Homology_(mathematics)")[#text("homologous")]#text(" to a trivial curve, as we will discuss in later notes.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The above exercise allows one to view the space of curves up to equivalence as a ")#link("https://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(", with the points in the complex plane being the objects of the category, and each equivalence class of curves being a single ")#link("https://en.wikipedia.org/wiki/Morphism")[#text("morphism")]#text(" from the initial point to the terminal point (and with the equivalence class of trivial curves being the identity morphisms). This point of view can be useful in topology, particularly when relating to concepts such as the ")#link("https://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" (and fundamental groupoid), ")#link("https://en.wikipedia.org/wiki/Monodromy")[#text("monodromy")]#text(", and ")#link("https://en.wikipedia.org/wiki/Holonomy")[#text("holonomy")]#text(". However, we will not need to use any advanced category-theoretic concepts in this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{z_0 \\in {\\bf C}}")#text(" and ")#mi("{r>0}")#text(". For any integer ")#mi("{m}")#text(", let ")#mi("{\\gamma_m: [0,2\\pi] \\rightarrow {\\bf C}}")#text(" denote the curve")

#align(center)[#tao-fit-display[#mitex("\\gamma_m(t) := z_0 + r e^{i m t}")]]

#text("(thus for instance ")#mi("{\\gamma_1 = \\gamma_{z_0,r,\\circlearrowleft}}")#text(").")

#list(
[#text("(i) Show that for any integer ")#mi("{m}")#text(", we have ")#mi("{-\\gamma_m \\equiv \\gamma_{-m}}")#text(".")],
[#text("(ii) Show that for any non-negative integers ")#mi("{m,m^{\\prime}}")#text(", we have ")#mi("{\\gamma_m + \\gamma_{m^{\\prime}} \\equiv \\gamma_{m+m^{\\prime}}}")#text(". What happens for other values of ")#mi("{m,m^{\\prime}}")#text("?")],
[#text("(ii) If ")#mi("{m,m^{\\prime}}")#text(" are distinct integers, show that ")#mi("{\\gamma_m \\not \\equiv \\gamma_{m^{\\prime}}}")#text(".")]
)
]

#text("Given a sequence of complex numbers ")#mi("{z_0,z_1,\\dots,z_n}")#text(", we define the ")#emph[#text("polygonal path")]#text(" ")#mi("{\\gamma_{z_0 \\rightarrow z_1 \\rightarrow \\dots \\rightarrow z_n}}")#text(" traversing these numbers in order to be the curve")

#align(center)[#tao-fit-display[#mitex("\\gamma_{z_0 \\rightarrow z_1 \\rightarrow \\dots \\rightarrow z_n} := \\gamma_{z_0 \\rightarrow z_1} + \\gamma_{z_1 \\rightarrow z_2} + \\dots + \\gamma_{z_{n-1} \\rightarrow z_n}.")]]

#text("This is well-defined thanks to Exercise ")#link(<tao-f3fc1ffa25bbd454fe6a>)[#text("3")]#text("(ii) (actually all we really need in applications is being well-defined up to equivalence). Thus for instance ")#mi("{\\gamma_{z_0 \\rightarrow z_1 \\rightarrow z_2 \\rightarrow z_0}}")#text(" would traverse a closed triangular path connecting ")#mi("{z_0}")#text(", ")#mi("{z_1}")#text(", and ")#mi("{z_2}")#text(" (this path may end up being non-simple if the points ")#mi("{z_0,z_1,z_2}")#text(" are collinear).")#linebreak()#text(" In order to do analysis, we need to restrict our attention to those curves which are ")#link("https://en.wikipedia.org/wiki/Arc_length#Definition")[#text("rectifiable")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6")]#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a curve. The ")#link("https://en.wikipedia.org/wiki/Arc_length")[#text("arc length")]#text(" ")#tao-math("{\\left|\\gamma\\right|}", block: false)#text(" of the curve is defined to be the supremum of the quantities")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^n \\left|\\gamma(t_{j})-\\gamma(t_{j-1})\\right|", block: true)]]

#text("where ")#mi("{n}")#text(" ranges over the natural numbers and ")#mi("{a = t_0 < t_1 < \\dots < t_n = b}")#text(" ranges over the ")#link("https://en.wikipedia.org/wiki/Partition_of_an_interval")[#text("partitions")]#text(" of ")#mi("{[a,b]}")#text(". We say that the curve ")#mi("{\\gamma}")#text(" is ")#emph[#text("rectifiable")]#text(" if its arc length is finite.")
]

#text("The concept is best understood visually: a curve is rectifiable if there is some finite bound on the length of polygonal paths one can form while traversing the curve in order. From Exercise ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text(" we see that equivalent curves have the same arclength, so the concepts of arclength and rectifiability are well defined for curves that are only given up to continuous reparameterisation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{\\gamma :[a,b] \\rightarrow {\\bf C}}")#text(" be a curve. Show that the arclength ")#tao-math("{\\left|\\gamma\\right|}", block: false)#text(" is the limit (in the extended real line) of the path lengths ")#tao-math("{\\sum_{j=1}^n \\left|\\gamma(t_j) - \\gamma(t_{j-1})\\right|}", block: false)#text(", where ")#mi("{a = t_0 \\leq \\dots \\leq t_n = b}")#text(" is a partition of ")#mi("{[a,b]}")#text(" and the mesh size ")#tao-math("{\\max_{1 \\leq j \\leq n} \\left|t_j - t_{j-1}\\right|}", block: false)#text(" goes to zero. In other words, if ")#tao-math("{\\left|\\gamma\\right|}", block: false)#text(" is finite, show that for every ")#mi("{\\varepsilon>0}")#text(" there exists ")#mi("{\\delta>0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\left|\\gamma\\right| - \\sum_{j=1}^n \\right|\\gamma(t_j) - \\gamma(t_{j-1})|| \\leq \\varepsilon", block: true)]]

#text("whenever ")#tao-math("{\\max_{1 \\leq j \\leq n} \\left|t_j - t_{j-1}\\right| \\leq \\delta}", block: false)#text(", and when ")#tao-math("{\\left|\\gamma\\right|}", block: false)#text(" is infinite, show that for every ")#mi("{N>0}")#text(" there exists ")#mi("{\\delta>0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^n \\left|\\gamma(t_j) - \\gamma(t_{j-1})\\right| \\geq N", block: true)]]

#text("whenever ")#tao-math("{\\max_{1 \\leq j \\leq n} \\left|t_j - t_{j-1}\\right| \\leq \\delta}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-a7e7e2f59b128bdb0aa6>#text(" Let ")#mi("{\\gamma_1,\\gamma_2}")#text(" be curves, with the terminal point of ")#mi("{\\gamma_1}")#text(" equal to the initial point of ")#mi("{\\gamma_2}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma_1+\\gamma_2\\right| = \\left|\\gamma_1\\right| + \\left|\\gamma_2\\right|.", block: true)]]

#text("In particular, ")#mi("{\\gamma_1+\\gamma_2}")#text(" is rectifiable if and only if ")#mi("{\\gamma_1, \\gamma_2}")#text(" are both individually rectifiable.")
]

#text("It is not immediately obvious that any reasonable curve (e.g. the line segments ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(" or the circles ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(") are rectifiable. To verify this, we need two preliminary results.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Triangle inequality)")]#text(" ")#metadata(none) <tao-775938b00731baaed8fa>#text(" Let ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" be a continuous function. Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_a^b f(t)\\ dt\\right| \\leq \\int_a^b |f(t)|\\ dt.", block: true)]]

#text("Here we interpret ")#mi("{\\int_a^b f(t)\\ dt}")#text(" as the Riemann integral (or equivalently, ")#mi("{\\int_a^b f(t)\\ dt = \\int_a^b \\mathrm{Re} f(t)\\ dt + i \\int_a^b \\mathrm{Im} f(t)\\ dt}")#text(").")
]

#emph[#text("Proof:")]#text(" We first attempt to prove this inequality by considering the real and imaginary parts separately. From the real-valued triangle inequality (and basic properties of the Riemann integral) we have")

#tao-aligned(keep: true)[


#tao-math("\\left| \\mathrm{Re} \\int_a^b f(t)\\ dt \\right|  & = \\left|\\int_a^b \\mathrm{Re} f(t)\\ dt \\right|", block: true)



#tao-math(" & \\leq \\int_a^b |\\mathrm{Re} f(t)|\\ dt", block: true)



#tao-math(" & \\leq \\int_a^b |f(t)|\\ dt", block: true)
]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathrm{Im} \\int_a^b f(t)\\ dt\\right| \\leq \\int_a^b |f(t)|\\ dt", block: true)]]

#text("but these two bounds only yield the weaker estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_a^b f(t)\\ dt\\right| \\leq \\sqrt{2} \\int_a^b |f(t)|\\ dt.", block: true)]]

#text("To eliminate this ")#mi("{\\sqrt{2}}")#text(" loss we can ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" the above argument by exploiting phase rotation. For any real ")#mi("{\\theta}")#text(", we can repeat the above arguments (using the complex linearity of the Riemann integral, which is easily verified) to give")

#tao-aligned(keep: true)[


#tao-math("\\left| \\mathrm{Re} e^{i\\theta} \\int_a^b f(t)\\ dt \\right|  & = \\left|\\int_a^b \\mathrm{Re} e^{i\\theta} f(t)\\ dt \\right|", block: true)



#tao-math(" & \\leq \\int_a^b |\\mathrm{Re} e^{i\\theta} f(t)|\\ dt", block: true)



#tao-math(" & \\leq \\int_a^b |f(t)|\\ dt.", block: true)
]

#text("But we have ")#tao-math("{\\left|z\\right| = \\sup_\\theta \\mathrm{Re} e^{i\\theta} z}", block: false)#text(" for any complex number ")#mi("{z}")#text(", so taking the supremum of both sides in ")#mi("{\\theta}")#text(" we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-1143da2bc54c495c4be3>#text(" Let ")#mi("{a \\leq b}")#text(" be real numbers. Show that the interval ")#mi("{[a,b]}")#text(" is ")#link("https://en.wikipedia.org/wiki/Connected_space")[#text("topologically connected")]#text(", that is to say the only two subsets of ")#mi("{[a,b]}")#text(" that are both open and closed ")#link("https://en.wikipedia.org/wiki/Relative_topology")[#text("relative")]#text(" to ")#mi("{[a,b]}")#text(" are the empty set and all of ")#mi("{[a,b]}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{E}")#text(" is a non-empty set that is both open and closed in ")#mi("{[a,b]}")#text(" and contains ")#mi("{a}")#text(", consider the supremum of all ")#mi("{T_* \\in [a,b]}")#text(" such that ")#mi("{[a,T_*] \\subset E}")#text(".)")
]

#text("Next, we say that a non-trivial curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("continuously differentiable")]#text(" if the derivative")

#align(center)[#tao-fit-display[#mitex("\\gamma^{\\prime}(t) := \\lim_{t^{\\prime} \\rightarrow t: t^{\\prime} \\in [a,b] \\backslash \\{t\\}} \\frac{\\gamma(t^{\\prime}) - \\gamma(t)}{t^{\\prime}-t}")]]

#text("exists and is continuous for all ")#mi("{t \\in [a,b]}")#text(" (note that we are only taking right-derivatives at ")#mi("{t=a}")#text(" and left-derivatives at ")#mi("{t=b}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Arclength formula)")]#text(" If ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" is a continuously differentiable curve, then it is rectifiable, and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma\\right| = \\int_a^b |\\gamma^{\\prime}(t)|\\ dt.", block: true)]]
]

#emph[#text("Proof:")]#text(" We first prove the upper bound ")#metadata(none) <tao-1cfc2f09a4bdcc9c6fcd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\gamma\\right| \\leq \\int_a^b |\\gamma^{\\prime}(t)|\\ dt", block: true)]]

#text("which in particular implies the rectifiability of ")#mi("{\\gamma}")#text(" since the right-hand side of ")#link(<tao-1cfc2f09a4bdcc9c6fcd>)[#text("(3)")]#text(" is finite. Let ")#mi("{a = t_0 < \\dots < t_n = b}")#text(" be any partition of ")#mi("{[a,b]}")#text(". By the fundamental theorem of calculus (applied to the real and imaginary parts of ")#mi("{\\gamma}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\gamma(t_j) - \\gamma(t_{j-1}) = \\int_{t_{j-1}}^{t_j} \\gamma^{\\prime}(t)\\ dt")]]

#text("for any ")#mi("{1 \\leq j \\leq n}")#text(", and hence by Lemma ")#link(<tao-775938b00731baaed8fa>)[#text("9")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma(t_j) - \\gamma(t_{j-1})\\right| \\leq \\int_{t_{j-1}}^{t_j} |\\gamma^{\\prime}(t)|\\ dt.", block: true)]]

#text("Summing in ")#mi("{j}")#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^n \\left|\\gamma(t_j) - \\gamma(t_{j-1})\\right| \\leq \\int_a^b |\\gamma^{\\prime}(t)|\\ dt", block: true)]]

#text("and taking suprema over all partitions we obtain ")#link(<tao-1cfc2f09a4bdcc9c6fcd>)[#text("(3)")]#text(".")#linebreak()#text(" Now we need to show the matching lower bound. Let ")#mi("{\\varepsilon>0}")#text(" be a small quantity, and for any ")#mi("{a \\leq T \\leq b}")#text(", let ")#mi("{\\gamma_{[a,T]}: [a,T] \\rightarrow {\\bf C}}")#text(" denote the restriction of ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" to ")#mi("{[a,T]}")#text(". We will show the bound ")#metadata(none) <tao-c1299854f2b209632ab2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\gamma_{[a,T]}\\right| \\geq \\int_a^T |\\gamma^{\\prime}(t)|\\ dt - \\varepsilon (T-a)", block: true)]]

#text("for all ")#mi("{a \\leq T \\leq b}")#text("; specialising to ")#mi("{T=b}")#text(" and then sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" will give the claim.")#linebreak()#text(" It remains to prove ")#link(<tao-c1299854f2b209632ab2>)[#text("(4)")]#text(" for a given choice of ")#mi("{\\varepsilon}")#text(". We will use a continuous version of induction known as the ")#link("http://www.tricki.org/article/Use_the_continuity_method")[#text("continuity method")]#text(", which exploits Exercise ")#link(<tao-1143da2bc54c495c4be3>)[#text("10")]#text(".")#linebreak()#text(" Let ")#mi("{\\Omega_\\varepsilon \\subset [a,b]}")#text(" denote the set of ")#mi("{T_* \\in [a,b]}")#text(" such that ")#link(<tao-c1299854f2b209632ab2>)[#text("(4)")]#text(" holds for all ")#mi("{a \\leq T \\leq T_*}")#text(". It is clear (using Exercise ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("8")]#text(", which implies that ")#tao-math("{\\left|\\gamma_{[a,T]}\\right|}", block: false)#text(" is an increasing function of ")#mi("{T}")#text(") that this set ")#mi("{\\Omega_\\varepsilon}")#text(" is topologically closed, and also contains the left endpoint ")#mi("{a}")#text(" of ")#mi("{[a,b]}")#text(". If ")#mi("{T_* \\in \\Omega_\\varepsilon}")#text(" and ")#mi("{T_* < b}")#text(", then from the differentiability of ")#mi("{\\gamma}")#text(" at ")#mi("{T_*}")#text(", we have some interval ")#mi("{[T_*, T_*+\\delta] \\subset [a,b]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\gamma(T) - \\gamma(T_*)}{T-T_*} - \\gamma^{\\prime}(T_*)\\right| \\leq \\varepsilon/2", block: true)]]

#text("for all ")#mi("{T \\in [T_*, T_*+\\delta]}")#text(". Rearranging this using the triangle inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma(T) - \\gamma(T_*)\\right| \\geq \\left|\\gamma^{\\prime}(T_*)\\right| (T-T_*) - \\frac{\\varepsilon}{2} (T-T_*).", block: true)]]

#text("Also, from the continuity of ")#tao-math("{\\left|\\gamma^{\\prime}\\right|}", block: false)#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{T_*}^T |\\gamma^{\\prime}(t)|\\ dt \\leq \\left|\\gamma^{\\prime}(T_*)\\right| (T-T_*) + \\frac{\\varepsilon}{2} (T-T_*)", block: true)]]

#text("for all ")#mi("{T \\in [T_*, T_*+\\delta]}")#text(", if ")#mi("{\\delta}")#text(" is small enough. We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma(T) - \\gamma(T_*)\\right| \\geq \\int_{T_*}^T |\\gamma^{\\prime}(t)|\\ dt - \\varepsilon (T-T_*),", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|\\gamma_{[T_*,T]}\\right| \\geq \\int_{T_*}^T |\\gamma^{\\prime}(t)|\\ dt - \\varepsilon (T-T_*)", block: true)]]

#text("where ")#mi("{\\gamma_{[T_*,T]}: [T_*,T] \\rightarrow {\\bf C}}")#text(" is the restriction of ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" to ")#mi("{[T_*,T]}")#text(". Adding this to the ")#mi("{T=T_*}")#text(" case of ")#link(<tao-c1299854f2b209632ab2>)[#text("(4)")]#text(" using Exercie ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("8")]#text(" we conclude that ")#link(<tao-c1299854f2b209632ab2>)[#text("(4)")]#text(" also holds for all ")#mi("{T \\in [T_*,T_*+\\delta]}")#text(". From this we see that ")#mi("{\\Omega_\\varepsilon}")#text(" is (relatively) open in ")#mi("{[a,b]}")#text("; from the connectedness of ")#mi("{[a,b]}")#text(" we conclude that ")#mi("{\\Omega_\\varepsilon = [a,b]}")#text(", and we are done. ")#mi("\\Box")#linebreak()#text(" It is now easy to verify that the line segment ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(" is rectifiable with arclength ")#tao-math("{\\left|z_2-z_1\\right|}", block: false)#text(", and that the circle ")#mi("{\\gamma_{z_0,r,\\circlearrowleft}}")#text(" is rectifiable with arclength ")#mi("{2\\pi r}")#text(", exactly as one would expect from elementary geometry. Finally, from Exercise ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("8")]#text(", a polygonal path ")#mi("{\\gamma_{z_0 \\rightarrow z_1 \\rightarrow \\dots \\rightarrow z_n}}")#text(" will be rectifiable with arclength ")#tao-math("{\\left|z_0-z_1\\right| + \\dots + \\left|z_{n-1}-z_n\\right|}", block: false)#text(", again exactly as one would expect.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-af9d2c92ddc38ca77b3c>#text(" Show that the curve ")#mi("{\\gamma: [0,1] \\rightarrow {\\bf C}}")#text(" defined by setting ")#mi("{\\gamma(t) := t + i t \\sin(\\frac{1}{t})}")#text(" for ")#mi("{0 < t \\leq 1}")#text(" and ")#mi("{\\gamma(0) := 0}")#text(" is continuous but not rectifiable. (")#emph[#text("Hint:")]#text(" it is not necessary to compute the arclength precisely; a lower bound that goes to infinity will suffice. Graph the curve to discover some convenient partitions with which to generate such lower bounds. Alternatively, one can apply the arclength formula to some subcurves of ")#mi("{\\gamma}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" (This exercise presumes familiarity with Lebesgue measure.) Show that the image of a ")#link("https://en.wikipedia.org/wiki/Lebesgue_measure")[#text("rectifiable curve")]#text(" is necessarily of measure zero in the complex plane. (In particular, ")#link("https://en.wikipedia.org/wiki/Space-filling_curve")[#text("space-filling curves")]#text(" such as the ")#link("https://en.wikipedia.org/wiki/Peano_curve")[#text("Peano curve")]#text(" or the ")#link("https://en.wikipedia.org/wiki/Hilbert_curve")[#text("Hilbert curve")]#text(" cannot be rectifiable.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" As the above exercise suggests, many ")#link("https://en.wikipedia.org/wiki/Fractal")[#text("fractal curves")]#text(" will fail to be rectifiable; for instance the ")#link("https://en.wikipedia.org/wiki/Koch_snowflake")[#text("Koch snowflake")]#text(" is a famous example of an unrectifiable curve. (The situation is clarified once one develops the theory of ")#link("https://en.wikipedia.org/wiki/Hausdorff_dimension")[#text("Hausdorff dimension")]#text(", as is done for instance in ")#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")[#text("this previous post")]#text(": any curve of Hausdorff dimension strictly greater than one will be unrectifiable.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Arclength parameterisation)")]#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a rectifiable curve.")

#list(
[#text("(i) Show that the arclength of the restriction of ")#mi("{\\gamma}")#text(" to ")#mi("{[a,t]}")#text(" for ")#mi("{a \\leq t \\leq b}")#text(" varies continuously in ")#mi("{t}")#text(". (")#emph[#text("Hint:")]#text(" you may find it convenient to first establish the preliminary bound ")#tao-math("{\\left|\\gamma_{[a,T]}\\right| \\leq \\sup_{a \\leq t < T} \\left|\\gamma_{[a,t]}\\right| + \\varepsilon}", block: false)#text(" for any ")#mi("{a < T \\leq b}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", and similarly ")#tao-math("{\\left|\\gamma_{[T,b]}\\right| \\leq \\sup_{T < t \\leq b} \\left|\\gamma_{[t,b]}\\right| + \\varepsilon}", block: false)#text(" for any ")#mi("{a \\leq T < b}")#text(".)")],
[#text("(ii) Assume furthermore that ")#mi("{\\gamma}")#text(" is not constant on any time interval of positive length. Show that there exists a unique reparameterisation ")#tao-math("{\\tilde \\gamma: [0,\\left|\\gamma\\right|] \\rightarrow {\\bf C}}", block: false)#text(" with the property that for each ")#tao-math("{0 \\leq t \\leq \\left|\\gamma\\right|}", block: false)#text(", the restriction of ")#mi("{\\tilde \\gamma}")#text(" to ")#mi("{[0,t]}")#text(" has arclength exactly ")#mi("{t}")#text(".")]
)
]

#text("Much as continuous functions ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" on an interval may be integrated by taking limits of Riemann sums, we may also integrate continuous functions ")#mi("{f: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(" on the image of a rectifiable curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 16 (Integration in rectifiable curves)")]#text(" ")#metadata(none) <tao-0a8cdfe6896d0ee5deb1>#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a rectifiable curve, and let ")#mi("{f: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(" be a continuous function on the image ")#mi("{\\gamma([a,b])}")#text(" of ")#mi("{\\gamma}")#text(". Then the “Riemann sums” ")#metadata(none) <tao-c5aaae59ae273dfa9d9d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{j=1}^n f(\\gamma(t^*_j)) (\\gamma(t_j) - \\gamma(t_{j-1})),")]]

#text("where ")#mi("{a = t_0 < \\dots < t_n = b}")#text(" ranges over the partitions of ")#mi("{[a,b]}")#text(", and for each ")#mi("{1 \\leq j \\leq n}")#text(", ")#mi("{t^*_j}")#text(" is an element of ")#mi("{[t_{j-1},t_j]}")#text(", converge as the maximum mesh size ")#tao-math("{\\max_{1 \\leq j \\leq n} \\left|t_j - t_{j-1}\\right|}", block: false)#text(" goes to zero to some complex limit, which we will denote as ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(". In other words, for every ")#mi("{\\varepsilon>0}")#text(" there exists a ")#mi("{\\delta>0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n f(\\gamma(t^*_j)) (\\gamma(t_j) - \\gamma(t_{j-1})) - \\int_\\gamma f(z)\\ dz\\right| \\leq \\varepsilon", block: true)]]

#text("whenever ")#tao-math("{\\max_{1 \\leq j \\leq n} \\left|t_j - t_{j-1}\\right| \\leq \\delta}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" In real analysis courses, one often uses the order properties of the real line to replace the rather complicated looking Riemann sums with the simpler ")#link("https://en.wikipedia.org/wiki/Darboux_integral")[#text("Darboux sums")]#text(", en route to proving the real-variable analogue of the above proposition. However, in our complex setting the ordering of the real line is not available, so we will tackle the Riemann sums directly rather than try to compare them with Darboux sums.")#linebreak()#text(" It suffices to prove that the “Riemann sums” ")#link(<tao-c5aaae59ae273dfa9d9d>)[#text("(5)")]#text(" are a Cauchy sequence (or more precisely a Cauchy ")#link("https://en.wikipedia.org/wiki/Net_(mathematics)")[#text("net")]#text("), in the sense that the difference")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{j=1}^n f(\\gamma(t^*_j)) (\\gamma(t_j) - \\gamma(t_{j-1})) - \\sum_{k=1}^m f(\\gamma(s^*_k)) (\\gamma(s_k) - \\gamma(s_{k-1}))\\right|", block: true)]]

#text("between two sums of the form ")#link(<tao-c5aaae59ae273dfa9d9d>)[#text("(5)")]#text(" is smaller than any specified ")#mi("{\\varepsilon>0}")#text(" if the maximum mesh sizes of the two partitions ")#mi("{a = t_0 < \\dots < t_n = b}")#text(" and ")#mi("{a = s_0 < \\dots < s_m = b}")#text(" are both small enough. From the triangle inequality, and from the fact that any two partitions have a common refinement, it suffices to prove this under the additional assumption that the second partition ")#mi("{a = s_0 < \\dots < s_m = b}")#text(" is a refinement of ")#mi("{a = t_0 < \\dots < t_n = b}")#text(". This means that there is an increasing sequence ")#mi("{0 = m_0 < m_1 < \\dots < m_n = m}")#text(" of natural numbers such that ")#mi("{s_{m_j} = t_j}")#text(" for ")#mi("{j=0,\\dots,n}")#text(". In that case, the above difference may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n E_j")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("E_j := f(\\gamma(t^*_j)) (\\gamma(t_j) - \\gamma(t_{j-1})) - \\sum_{k=m_{j-1}+1}^{m_j} f(\\gamma(s^*_k)) (\\gamma(s_k) - \\gamma(s_{k-1})).")]]

#text("By telescoping series, we may rearrange ")#mi("{E_j}")#text(" further as")

#align(center)[#tao-fit-display[#mitex("E_j := \\sum_{k=m_{j-1}+1}^{m_j} (f(\\gamma(t^*_j)) - f(\\gamma(s^*_k))) (\\gamma(s_k) - \\gamma(s_{k-1})).")]]

#text("As ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" is continuous and ")#mi("{[a,b]}")#text(" is compact, ")#mi("{\\gamma}")#text(" is ")#link("https://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniformly continuous")]#text(". In particular, if the maximum mesh sizes are small enough, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f(\\gamma(t^*_j)) - f(\\gamma(s^*_k))\\right| \\leq \\varepsilon", block: true)]]

#text("for all ")#mi("{1 \\leq j \\leq n}")#text(" and ")#mi("{m_{j-1} \\leq k \\leq m_j}")#text(". From the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|E_j\\right| \\leq \\varepsilon \\sum_{k=m_{j-1}+1}^{m_j} \\left|\\gamma(s_k) - \\gamma(s_{k-1})\\right|", block: true)]]

#text("and hence on summing in ")#mi("{j}")#text(" and using the triangle inequality, we can bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n E_j\\right| \\leq \\varepsilon |\\gamma|.", block: true)]]

#text("Since ")#tao-math("{\\left|\\gamma\\right|}", block: false)#text(" is finite, and ")#mi("{\\varepsilon}")#text(" can be made arbitrarily small, we obtain the required Cauchy net property. ")#mi("\\Box")#linebreak()#text(" One cannot simply omit the rectifiability hypothesis from the above proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Give an example of a curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" such that the Riemann sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n \\gamma(t^*_j) (\\gamma(t_j) - \\gamma(t_{j-1}))")]]

#text("fail to converge to a limit as the maximum mesh size goes to zero, so the integral ")#mi("{\\int_\\gamma z\\ dz}")#text(" does not exist in the sense of convergent Riemann sums even though the integrand ")#mi("{z}")#text(" is extremely smooth. (Of course, such a curve ")#mi("{\\gamma}")#text(" cannot be rectifiable, thanks to Proposition ")#link(<tao-0a8cdfe6896d0ee5deb1>)[#text("16")]#text(".) ")#emph[#text("Hint:")]#text(" the non-rectifiable curve in Example ")#link(<tao-af9d2c92ddc38ca77b3c>)[#text("12")]#text(" is a good place to start, but it turns out that this curve does not oscillate wildly enough to make the Riemann sums here diverge, because of the decay of the function ")#mi("{z \\mapsto z}")#text(" near the origin. Come up with a variant of this curve which oscillates more. Nevertheless, it is still possible to assign a meaning to integrals such as ")#mi("{\\int_\\gamma z\\ dz}")#text(", as we shall see in the next set of notes once Cauchy’s theorem is established.")
]

#text("By abuse of notation, we will refer to the quantity ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" as the ")#emph[#text("contour integral")]#text(" of ")#mi("{f}")#text(" along ")#mi("{\\gamma}")#text(", even though ")#mi("{\\gamma}")#text(" is not necessarily a contour (we will define this concept shortly). We have some easy properties of this integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-54bca8d2372c18649c81>#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a rectifiable curve, and ")#mi("{f: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(" be a continuous function.")

#list(
[#text("(i) (Independence of parameterisation) If ")#mi("{\\tilde \\gamma \\equiv \\gamma}")#text(" is another curve equivalent to ")#mi("{\\gamma}")#text(", show that ")#mi("{\\int_{\\tilde \\gamma} f(z)\\ dz = \\int_\\gamma f(z)\\ dz}")#text(".")],
[#text("(ii) (Reversal) Show that ")#mi("{\\int_{-\\gamma} f(z)\\ dz = - \\int_\\gamma f(z)\\ dz}")#text(".")],
[#text("(iii) (Concatenation) If ")#mi("{\\gamma = \\gamma_1 + \\gamma_2}")#text(" for some curves ")#mi("{\\gamma_1, \\gamma_2}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz = \\int_{\\gamma_1} f(z)\\ dz + \\int_{\\gamma_2} f(z)\\ dz.")]]],
[#text("(iv) (Change of variables) If ")#mi("{\\gamma}")#text(" is continuously differentiable, show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz = \\int_a^b f(\\gamma(t)) \\gamma^{\\prime}(t)\\ dt.")]]],
[#text("(v) (Upper bound) If there is a pointwise bound of the form ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" for all ")#mi("{z \\in \\gamma([a,b])}")#text(" and some ")#mi("{M>0}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_\\gamma f(z)\\ dz\\right| \\leq M |\\gamma|.", block: true)]]],
[#text("(vi) (Linearity) If ")#mi("{c}")#text(" is a complex number and ")#mi("{g: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(" is a continuous function, show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma c f(z)\\ dz = c \\int_\\gamma f(z)\\ dz")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z) + g(z)\\ dz = \\int_\\gamma f(z)\\ dz + \\int_\\gamma g(z)\\ dz.")]]],
[#text("(vii) (Integrating a constant) If ")#mi("{\\gamma}")#text(" has initial point ")#mi("{z_1}")#text(" and terminal point ")#mi("{z_2}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma\\ dz = z_2 - z_1.")]]],
[#text("(viii) (Uniform convergence) If ")#mi("{f_n: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(", ")#mi("{n \\geq 1}")#text(" is a sequence of continuous functions ")#link("https://en.wikipedia.org/wiki/Uniform_convergence")[#text("converging uniformly")]#text(" to ")#mi("{f}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", show that ")#mi("{\\int_\\gamma f_n(z)\\ dz}")#text(" converges to ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". (The requirement of uniform convergence can be relaxed substantially, thanks to tools such as the ")#link("https://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(", but this weaker convergence theorem will suffice for most of our applications.)")],
[#text("(ix) (Change of variables, II) Let ")#mi("{U}")#text(" be an open neighbourhood of ")#mi("{\\gamma([a,b])}")#text(", let ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" be a holomorphic function, and let ")#mi("{g: \\phi(\\gamma([a,b])) \\rightarrow {\\bf C}}")#text(" be a continuous function. Show that ")#mi("{\\phi \\circ \\gamma}")#text(" is rectifiable, and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\phi \\circ \\gamma} g(w)\\ dw = \\int_\\gamma g(\\phi(z)) \\phi^{\\prime}(z)\\ dz.")]]

#text("(For this question, you may assume without proof that holomorphic functions are continuously differentiable; this fact will be proven (without reliance on this part of the exercise) in the next set of notes.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" (This exercise assumes familiarity with the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Stieltjes_integral")[#text("Riemann-Stieltjes integral")]#text(".) Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a rectifiable curve. Let ")#mi("{g: [a,b] \\rightarrow {\\bf C}}")#text(" denote the monotone non-decreasing function")

#align(center)[#tao-fit-display[#tao-math("g(T) := \\left|\\gamma_{[a,T]}\\right|", block: true)]]

#text("for ")#mi("{a \\leq T \\leq b}")#text(", where ")#mi("{\\gamma_{[a,T]}: [a,T] \\rightarrow {\\bf C}}")#text(" is the restriction of ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" to ")#mi("{[a,T]}")#text(". For any continuous function ")#mi("{f: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(", define the ")#emph[#text("arclength measure integral")]#text(" ")#tao-math("{\\int_\\gamma f(z)\\ \\left|dz\\right|}", block: false)#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\int_\\gamma f(z)\\ \\left|dz\\right| := \\int_a^b f(\\gamma(t))\\ dg(t)", block: true)]]

#text("where the right-hand side is a Riemann-Stieltjes integral. Establish the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_\\gamma f(z)\\ dz\\right| \\leq \\int_\\gamma |f(z)|\\ \\left|dz\\right|", block: true)]]

#text("for any continuous ")#mi("{f: \\gamma([a,b]) \\rightarrow {\\bf C}}")#text(". Also establish the identity")

#align(center)[#tao-fit-display[#tao-math("\\int_\\gamma\\ \\left|dz\\right| = \\left|\\gamma\\right|", block: true)]]

#text("and obtain an alternate proof of Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]#text("(v).")
]

#text("The change of variables formula (iv) lets one compute many contour integrals using the familiar Riemann integral. For instance, if ")#mi("{a < b}")#text(" are real numbers and ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" is continuous, then the contour integral along ")#mi("{\\gamma_{a \\rightarrow b}}")#text(" coincides with the Riemann integral,")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{a \\rightarrow b}} f(z)\\ dz = \\int_a^b f(x)\\ dx")]]

#text("and on reversal we also have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\gamma_{b \\rightarrow a}} f(z)\\ dz = \\int_b^a f(x)\\ dx = - \\int_a^b f(x)\\ dx.")]]

#text("Similarly, if ")#mi("{f}")#text(" is continuous on the circle ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z-z_0\\right| = r \\}}", block: false)#text(", we have ")#metadata(none) <tao-8a39178d327e72a92d3b>

#tao-aligned(keep: true)[


#tao-math("\\int_{\\gamma_{z_0,r,\\circlearrowleft}} f(z)\\ dz  & = i \\int_0^{2\\pi} f(z_0+re^{i\\theta}) r e^{i\\theta}\\ d\\theta", block: true, numbering: n => [#text("(6)")])



#tao-math(" & = 2\\pi i r \\int_0^1 f(z_0 + re^{2\\pi i \\theta}) e^{2\\pi i \\theta}\\ d\\theta.", block: true)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" We caution that if ")#mi("{f(z)}")#text(" is real-valued, we cannot conclude that ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" is also real valued, unless the contour ")#mi("{\\gamma}")#text(" lies in the real line. This is because the complex line element ")#mi("{dz}")#text(" may introduce some non-trivial imaginary part, as is the case for instance in ")#link(<tao-8a39178d327e72a92d3b>)[#text("(6)")]#text(". For similar reasons, we have")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{Re} \\int_\\gamma f(z)\\ dz  & \\neq \\int_\\gamma \\mathrm{Re} f(z)\\ dz", block: true)



#tao-math("\\mathrm{Im} \\int_\\gamma f(z)\\ dz  & \\neq \\int_\\gamma \\mathrm{Im} f(z)\\ dz", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\overline{\\int_\\gamma f(z)\\ dz} \\neq \\int_\\gamma \\overline{f(z)}\\ dz.")]]

#text("in general. If one wishes to mix line integrals with real and imaginary parts, it is recommended to replace the contour integrals above with the ")#link("https://en.wikipedia.org/wiki/Line_integral")[#text("line integrals")]

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(x+iy) dx + g(x+iy) dy,")]]

#text("which are defined as in Proposition ")#link(<tao-0a8cdfe6896d0ee5deb1>)[#text("16")]#text(" but where the expression")

#align(center)[#tao-fit-display[#mitex("f(\\gamma(t^*_j)) (\\gamma(t_j) - \\gamma(t_{j-1}))")]]

#text("appearing in ")#link(<tao-c5aaae59ae273dfa9d9d>)[#text("(5)")]#text(" is replaced by")

#align(center)[#tao-fit-display[#mitex("f(\\gamma(t^*_j)) \\mathrm{Re}(\\gamma(t_j) - \\gamma(t_{j-1})) + g(\\gamma(t^*_j)) \\mathrm{Im}(\\gamma(t_j) - \\gamma(t_{j-1})).")]]

#text("The contour integral corresponds to the special case ")#mi("{g=if}")#text(" (or more informally, ")#mi("{dz = dx + idy}")#text("). Line integrals are in turn special cases of the more general concept of integration of ")#link("https://en.wikipedia.org/wiki/Differential_form")[#text("differential forms")]#text(", discussed for instance in ")#link("http://www.math.ucla.edu/~tao/preprints/forms.pdf")[#text("this article of mine")]#text(", and which are used extensively in differential geometry and geometric topology. However we will not use these more general line integrals or differential form integrals much in this course.")
]

#text("In later notes it will be convenient to restrict to a more regular class of curves than the rectifiable curves. We thus give the definitions here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 21 (Smooth curves and contours)")]#text(" A ")#emph[#text("smooth curve")]#text(" is a curve ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" that is continuously differentiable, and such that ")#mi("{\\gamma^{\\prime}(t) \\neq 0}")#text(" for all ")#mi("{t \\in [a,b]}")#text(". A ")#emph[#text("contour")]#text(" is a curve that is equivalent to the concatenation of finitely many smooth curves (that is to say, a ")#emph[#text("piecewise smooth")]#text(" curve).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 22")]#text(" The line segments ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(" and circles ")#mi("{\\gamma_{z_0, r, \\circlearrowright}, \\gamma_{z_0,r,\\circlearrowleft}}")#text(" are smooth curves and hence contours. Polygonal paths are usually not smooth, but they are contours. Any sum of finitely many contours is again a contour, and the reversal of a contour is also a contour.")
]

#text("Note here that the term “smooth” differs somewhat here from the ")#link("https://en.wikipedia.org/wiki/Smoothness")[#text("real-variable notion of smoothness")]#text(", which is defined to be “infinitely differentiable”. Smooth curves are still only assumed to just be continuously differentiable; we do not assume that the second derivative of ")#mi("{\\gamma}")#text(" exists. (In particular, smooth curves may have infinite ")#link("https://en.wikipedia.org/wiki/Curvature")[#text("curvature")]#text(" at some points.) In practice, this distinction tends to be minor, though, as the smooth curves that one actually uses in complex analysis do tend to be infinitely differentiable. On the other hand, for most applications one does not need to control any derivative of a contour beyond the first.")#linebreak()#text(" The following examples and exercises may help explain why the non-vanishing condition ")#mi("{\\gamma^{\\prime}(t) \\neq 0}")#text(" imbues curves with a certain degree of “smoothness”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 23 (Cuspidal curve)")]#text(" ")#metadata(none) <tao-d0f631ca1ddba8db3bcf>#text(" Consider the curve ")#mi("{\\gamma: [-1,1] \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{\\gamma(t) := t^2 + it^3}")#text(". Clearly ")#mi("{\\gamma}")#text(" is continously differentiable (and even infinitely differentiable), but we do not view this curve as smooth, because ")#mi("{\\gamma^{\\prime}(t) = 2t + 3it^2}")#text(" vanishes at the origin. Indeed, the image of the curve is ")#mi("{\\{ x + i x^{3/2}: 0 \\leq x \\leq 1 \\} \\cup \\{ x - i x^{3/2}: 0 \\leq x \\leq 1 \\}}")#text(", which looks visibly non-smooth at the origin if one plots it, due to the presence of a ")#link("https://en.wikipedia.org/wiki/Cusp_(singularity)")[#text("cusp")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 24 (Absolute value function)")]#text(" ")#metadata(none) <tao-9c0abe51c6e6655d81de>#text(" Consider the curve ")#mi("{\\gamma: [-1,1] \\rightarrow {\\bf C}}")#text(" defined by ")#tao-math("{\\gamma(t) := t^5 + i \\left|t\\right|^5}", block: false)#text(". This curve is certainly continuously differentiable, and in fact is four times continuously differentiable, but is not smooth because ")#tao-math("{\\gamma^{\\prime}(t) = 5 t^4 + i 4 \\left|t\\right|^3 t}", block: false)#text(" vanishes at the origin. The image of this curve is ")#tao-math("{\\{ x + i \\left|x\\right|: -1 \\leq x \\leq 1\\}}", block: false)#text(", which looks visibly non-smooth at the origin (in particular, there is no unique tangent line to this curve here).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 25 (Spiral)")]#text(" ")#metadata(none) <tao-0f0e99f465a65c3cb8a7>#text(" Consider the curve ")#mi("{\\gamma: [-1,1] \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{\\gamma(t) := t^4 e^{i/t}}")#text(" for ")#mi("{t \\neq 0}")#text(", and ")#mi("{\\gamma(0) := 0}")#text(". One can check (exercise!) that ")#mi("{\\gamma}")#text(" is continuously differentiable, even at the origin ")#mi("{t=0}")#text("; but it is not a smooth curve because ")#mi("{\\gamma^{\\prime}(0)}")#text(" vanishes. The image of ")#mi("{\\gamma}")#text(" has some rather complicated behaviour at the origin, for instance it intersects itself multiple times (try to sketch it!).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Local behaviour of smooth curves)")]#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a simple smooth curve, and let ")#mi("{t_0}")#text(" be an interior point of ")#mi("{(a,b)}")#text(". Let ")#mi("{\\theta \\in {\\bf R}}")#text(" be a phase of ")#mi("{\\gamma^{\\prime}(t_0)}")#text(", thus ")#mi("{\\gamma^{\\prime}(t_0)= re^{i\\theta}}")#text(" for some ")#mi("{r>0}")#text(". Show that for all sufficiently small ")#mi("{\\varepsilon>0}")#text(", the portion ")#mi("{\\gamma([a,b]) \\cap D(\\gamma(t_0),\\varepsilon)}")#text(" of the image of ")#mi("{\\gamma}")#text(" near ")#mi("{\\gamma(t_0)}")#text(" looks like a rotated graph, in the sense that")

#align(center)[#tao-fit-display[#mitex("\\gamma([a,b]) \\cap D(\\gamma(t_0),\\varepsilon) = \\{ \\gamma(t_0) + e^{i\\theta} ( s + i f(s) ): s \\in I_\\varepsilon \\}")]]

#text("for some interval ")#mi("{I_\\varepsilon = (-c_-(\\varepsilon), c_+(\\varepsilon))}")#text(" containing the origin, and some continuously differentiable function ")#mi("{f: I_\\varepsilon \\rightarrow {\\bf R}}")#text(" with ")#mi("{f(0) = f^{\\prime}(0) = 0}")#text(". Furthermore, show that ")#mi("{c_-(\\varepsilon), c_+\\varepsilon = \\varepsilon + o(\\varepsilon)}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" (or equivalently, that ")#mi("{\\frac{c_-(\\varepsilon)}{\\varepsilon}, \\frac{c_+(\\varepsilon)}{\\varepsilon} \\rightarrow 1}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text("). (")#emph[#text("Hint:")]#text(" you may find it easier to first work with the model case where ")#mi("{\\gamma(t_0) = 0}")#text(" and ")#mi("{\\gamma^{\\prime}(t_0) = 1}")#text(". The real-variable ")#link("https://en.wikipedia.org/wiki/Inverse_function_theorem")[#text("inverse function theorem")]#text(" will also be helpful.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Show that a curve ")#mi("{\\gamma}")#text(" is a contour if and only if it is equivalent to the concatenation of finitely many ")#emph[#text("simple")]#text(" smooth curves.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Show that the cuspidal curve and absolute value curves in Examples ")#link(<tao-d0f631ca1ddba8db3bcf>)[#text("23")]#text(", ")#link(<tao-9c0abe51c6e6655d81de>)[#text("24")]#text(" are contours, but the curve in Exercise ")#link(<tao-0f0e99f465a65c3cb8a7>)[#text("25")]#text(" is not.")
]

#heading(level: 1)[#strong[#text(" — 2. The fundamental theorem of calculus — ")]]

#text("Now we establish the complex analogues of the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(". As in the real-variable case, there are two useful formulations of this theorem. Here is the first:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 29 (First fundamental theorem of calculus)")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a continuous function, and suppose that ")#mi("{f}")#text(" has an ")#link("https://en.wikipedia.org/wiki/Antiderivative")[#text("antiderivative")]#text(" ")#mi("{F: U \\rightarrow {\\bf C}}")#text(", that is to say a holomorphic function with ")#mi("{f(z) = F^{\\prime}(z)}")#text(" for all ")#mi("{z \\in U}")#text(". Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" be a rectifiable curve in ")#mi("{U}")#text(" with initial point ")#mi("{z_0}")#text(" and terminal point ")#mi("{z_1}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz = F(z_1) - F(z_0).")]]
]

#emph[#text("Proof:")]#text(" If ")#mi("{\\gamma}")#text(" were continuously differentiable, or at least ")#emph[#text("piecewise continuously differentiable")]#text(" (the concatenation of finitely many continuously differentiable curves), we could establish this theorem by using Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]#text(" to rewrite everything in terms of real-variable Riemann integrals, at which point one can use the real-variable fundamental theorem of calculus (and the chain rule). But actually we can just give a direct proof that does not need any differentiability hypothesis whatsoever.")#linebreak()#text(" We again use the continuity method. Let ")#mi("{\\varepsilon > 0}")#text(", and for each ")#mi("{a \\leq T \\leq b}")#text(", let ")#mi("{\\gamma_{[a,T]}: [a,T] \\rightarrow {\\bf C}}")#text(" be the restriction of ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" to ")#mi("{[a,T]}")#text(". It will suffice to show that ")#metadata(none) <tao-72b90a0d25a6e8f71d5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\int_{\\gamma_{[a,T]}} f(z)\\ dz - (F(\\gamma(T)) - F(\\gamma(a)))\\right| \\leq \\varepsilon \\left|\\gamma_{[a,T]}\\right|", block: true)]]

#text("for all ")#mi("{a \\leq T \\leq b}")#text(", as the claim then follows by setting ")#mi("{T=b}")#text(" and sending ")#mi("{\\varepsilon}")#text(" to zero.")#linebreak()#text(" Let ")#mi("{\\Omega_\\varepsilon}")#text(" denote the set of all ")#mi("{T_* \\in [a,b]}")#text(" such that ")#link(<tao-72b90a0d25a6e8f71d5f>)[#text("(7)")]#text(" holds for all ")#mi("{a \\leq T \\leq T_*}")#text(". As before, ")#mi("{\\Omega_\\varepsilon}")#text(" is clearly closed and contains ")#mi("{a}")#text("; as ")#mi("{[a,b]}")#text(" is connected, the only remaining task is to show that ")#mi("{\\Omega_\\varepsilon}")#text(" is open in ")#mi("{[a,b]}")#text(". Let ")#mi("{T_* \\in \\Omega_\\varepsilon}")#text(" be such that ")#mi("{T_* < b}")#text(". As ")#mi("{F}")#text(" is differentiable at ")#mi("{\\gamma(T_*)}")#text(" with derivative ")#mi("{f(\\gamma(T_*))}")#text(", and ")#mi("{\\gamma}")#text(" is continuous, there exists ")#mi("{\\delta>0}")#text(" with ")#mi("{[T_*,T_*+\\delta] \\subset [a,b]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{F(\\gamma(T)) - F(\\gamma(T_*))}{\\gamma(T) - \\gamma(T_*)} - f(\\gamma(T_*))\\right| \\leq \\varepsilon/2", block: true)]]

#text("for any ")#mi("{T_* < T \\leq T_*+\\delta}")#text(", and hence ")#metadata(none) <tao-673c83a7a9f51db40eba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|F(\\gamma(T)) - F(\\gamma(T_*)) - f(\\gamma(T_*)) (\\gamma(T)-\\gamma(T_*))\\right| \\leq \\varepsilon/2 \\left|\\gamma_{[T_*,T]}\\right|", block: true)]]

#text("for any ")#mi("{T \\in [T_*, T_*+\\delta]}")#text(". On the other hand, if ")#mi("{\\delta}")#text(" is small enough, we have that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(\\gamma(t)) - f(\\gamma(T_*))\\right| \\leq \\varepsilon/2", block: true)]]

#text("for all ")#mi("{t \\in [T_*, T_*+\\delta]}")#text(", and hence by Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]#text("(v) we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\gamma_{[T_*,T]}} (f(z) - f(\\gamma(T_*)))\\ dz\\right| \\leq \\frac{\\varepsilon}{2} \\left|\\gamma_{[T_*, T]}\\right|", block: true)]]

#text("where ")#mi("{\\gamma_{[T_*,T]}: [T_*,T] \\rightarrow {\\bf C}}")#text(" is the restriction of ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C}}")#text(" to ")#mi("{[T_*,T]}")#text(". Applying Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]#text("(vi), (vii) we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\gamma_{[T_*,T]}} f(z)\\ dz - f(\\gamma(T_*)) (\\gamma(T)-\\gamma(T_*))\\right| \\leq \\frac{\\varepsilon}{2} |\\gamma_{[T_*, T]}|.", block: true)]]

#text("Combining this with ")#link(<tao-673c83a7a9f51db40eba>)[#text("(8)")]#text(" and the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{\\gamma_{[T_*,T]}} f(z)\\ dz - (F(\\gamma(T)) - F(\\gamma(T_*)))\\right| \\leq \\varepsilon \\left|\\gamma_{[T_*,T]}\\right|", block: true)]]

#text("and on adding this to the ")#mi("{T=T_*}")#text(" case of ")#link(<tao-72b90a0d25a6e8f71d5f>)[#text("(7)")]#text(" and again using the triangle inequality, we conclude that ")#link(<tao-72b90a0d25a6e8f71d5f>)[#text("(7)")]#text(" holds for all ")#mi("{T \\in [T_*,T_*+\\delta]}")#text(". This ensures that ")#mi("{\\Omega_\\varepsilon}")#text(" is open, as desired. ")#mi("\\Box")#linebreak()#text(" One can use this theorem to quickly evaluate many integrals by using an antiderivative for the integrand as in the real-variable case. For instance, for any rectifiable curve ")#mi("{\\gamma}")#text(" with initial point ")#mi("{z_1}")#text(" and terminal point ")#mi("{z_2}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\int_\\gamma z\\ dz  & = \\frac{1}{2} z_2^2 - \\frac{1}{2} z_1^2,", block: true)



#tao-math("\\int_\\gamma e^z\\ dz  & = e^{z_2} - e^{z_1},", block: true)



#tao-math("\\int_\\gamma \\cos(z)\\ dz  & = \\sin(z_2) - \\sin(z_1),", block: true)
]

#text("and so forth. If the curve ")#mi("{\\gamma}")#text(" avoids the origin, we also have")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{1}{z^2}\\ dz = -\\frac{1}{z_2} + \\frac{1}{z_1}")]]

#text("since ")#mi("{-\\frac{1}{z}}")#text(" is an antiderivative of ")#mi("{\\frac{1}{z^2}}")#text(" on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(". If ")#mi("{\\sum_{n=0}^\\infty a_n (z-z_0)^n}")#text(" is a power series with radius of convergence ")#mi("{R}")#text(", and ")#mi("{\\gamma}")#text(" is a rectifiable curve in ")#mi("{D(z_0,R)}")#text(" with initial point ")#mi("{z_1}")#text(" and terminal point ")#mi("{z_2}")#text(", we similarly have")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\sum_{n=0}^\\infty a_n (z-z_0)^n\\ dz = \\sum_{n=0}^\\infty a_n ( \\frac{(z_2-z_0)^{n+1}}{n+1} - \\frac{(z_1-z_0)^{n+1}}{n+1} ).")]]

#text("For the second fundamental theorem of calculus, we need a topological preliminary result.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" ")#metadata(none) <tao-2e68a8e49fe8b9e6e94c>#text(" Let ")#mi("{U}")#text(" be a non-empty open subset of ")#mi("{{\\bf C}}")#text(". Show that the following statements are equivalent:")

#list(
[#text("(i) ")#mi("{U}")#text(" is topologically connected (that is to say, the only two subsets of ")#mi("{U}")#text(" that are both open and closed relative to ")#mi("{U}")#text(" are the empty set and ")#mi("{U}")#text(" itself).")],
[#text("(ii) ")#mi("{U}")#text(" is path connected (that is to say, for any ")#mi("{z_1,z_2 \\in U}")#text(" there exists a curve ")#mi("{\\gamma}")#text(" with image in ")#mi("{U}")#text(" whose initial point is ")#mi("{z_1}")#text(" and terminal point is ")#mi("{z_2}")#text(").")],
[#text("(iii) ")#mi("{U}")#text(" is polygonally path connected (the same as (ii), except that ")#mi("{\\gamma}")#text(" is now required to also be a polygonal path).")]
)

#text("(")#emph[#text("Hint:")]#text(" to show that (i) implies (iii), pick a base point ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" and consider the set of all ")#mi("{z_1}")#text(" in ")#mi("{U}")#text(" that can be reached from ")#mi("{z_0}")#text(" by a polygonal path.)")
]

#text("We remark that the relationship between path connectedness and connectedness is more delicate when one does not assume that the space ")#mi("{U}")#text(" is open; every path-connected space is still connected, but the converse need not be true.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" There is ")#link("http://mathoverflow.net/questions/120536/is-the-empty-graph-a-tree/120580#120580")[#text("some debate")]#text(" as to whether to view the empty set ")#mi("{\\emptyset}")#text(" as connected, disconnected, or neither. I view this as analogous to the debate as to whether the natural number ")#mi("{1}")#text(" should be viewed as prime, composite, or neither. In both cases I personally prefer the convention of “neither” (and like to use the term “unconnected” to describe the empty set, and “unit” to describe ")#mi("{1}")#text("), but to avoid any confusion I will restrict the discussion of connectedness to non-empty sets in this course (which is all we will need in applications).")
]

#text("In real analysis, the second fundamental theorem of calculus asserts that if a function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is continuous, then the function ")#mi("{F: x \\mapsto \\int_a^x f(y)\\ dy}")#text(" is an antiderivative of ")#mi("{f}")#text(". In the complex case, there is an analogous result, but one needs the additional requirement that the function is conservative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Second fundamental theorem of calculus)")]#text(" ")#metadata(none) <tao-05c6f12a0e7f0b9fbad4>#text(" Let ")#mi("{U \\subset {\\bf C}}")#text(" be a non-empty open connected subset of the complex numbers. Let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be a continuous function which is ")#emph[#text("conservative")]#text(" in the sense that ")#metadata(none) <tao-8588aad90351287d5682>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_\\gamma f(z)\\ dz = 0")]]

#text("whenever ")#mi("{\\gamma}")#text(" is a closed polygonal path in ")#mi("{U}")#text(". Fix a base point ")#mi("{z_0 \\in U}")#text(", and define the function ")#mi("{F: U \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("F(z_1) := \\int_{\\gamma_{z_0 \\rightsquigarrow z_1}} f(z)\\ dz")]]

#text("for all ")#mi("{z_1 \\in U}")#text(", where ")#mi("{\\gamma_{z_0 \\rightsquigarrow z_1}}")#text(" is any polygonal path from ")#mi("{z_0}")#text(" to ")#mi("{z_1}")#text(" in ")#mi("{U}")#text(" (the existence of such a path follows from Exercise ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("30")]#text(" and the hypothesis that ")#mi("{U}")#text(" is connected, and the independence of the choice of path for the purposes of defining ")#mi("{F(z_1)}")#text(" follows from Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]#text(" and the conservative hypothesis ")#link(<tao-8588aad90351287d5682>)[#text("(9)")]#text("). Then ")#mi("{F}")#text(" is holomorphic on ")#mi("{U}")#text(" and is an antiderivative of ")#mi("{f}")#text(", thus ")#mi("{f(z_1) = F^{\\prime}(z_1)}")#text(" for all ")#mi("{z_1 \\in U}")#text(".")
]

#emph[#text("Proof:")]#text(" We mimic the proof of the real-variable second fundamental theorem of calculus. Let ")#mi("{z_1}")#text(" be any point in ")#mi("{U}")#text(". As ")#mi("{U}")#text(" is open, it contains some disk ")#mi("{D(z_1,r)}")#text(" centred at ")#mi("{z_1}")#text(". In particular, if ")#mi("{z_2}")#text(" lies in this disk, then the line segment ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(" will have image in ")#mi("{U}")#text(". If ")#mi("{\\gamma_{z_0 \\rightsquigarrow z_1}}")#text(" is any polygonal path from ")#mi("{z_0}")#text(" to ")#mi("{z_1}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("F(z_1) = \\int_{\\gamma_{z_0 \\rightsquigarrow z_1}} f(z)\\ dz")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("F(z_2) = \\int_{\\gamma_{z_0 \\rightsquigarrow z_1} + \\gamma_{z_1 \\rightarrow z_2}} f(z)\\ dz")]]

#text("and hence by Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]

#align(center)[#tao-fit-display[#mitex("F(z_2) - F(z_1) - f(z_1) (z_2-z_1) = \\int_{\\gamma_{z_1 \\rightarrow z_2}} (f(z) - f(z_1))\\ dz.")]]

#text("(The reader is strongly advised to draw a picture depicting the situation here.) Let ")#mi("{\\varepsilon>0}")#text(", then for ")#mi("{z_2}")#text(" sufficiently close to ")#mi("{z_1}")#text(", we have ")#tao-math("{\\left|f(z)-f(z_1)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{z}")#text(" in the image of ")#mi("{\\gamma_{z_1 \\rightarrow z_2}}")#text(". Thus by Exercise ")#link(<tao-54bca8d2372c18649c81>)[#text("18")]#text("(v) we have")

#align(center)[#tao-fit-display[#tao-math("\\left|F(z_2) - F(z_1) - f(z_1) (z_2-z_1)\\right| \\leq \\varepsilon \\left|z_2-z_1\\right|", block: true)]]

#text("for ")#mi("{z_2}")#text(" sufficiently close to ")#mi("{z_1}")#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("\\lim_{z_2 \\rightarrow z_1; z_2 \\in U \\backslash \\{z_1\\}} \\frac{F(z_2)-F(z_1)}{z_2-z_1} = f(z_1)")]]

#text("for any ")#mi("{z_1 \\in U}")#text(", and thus ")#mi("{F}")#text(" is an antiderivative of ")#mi("{f}")#text(" as required. ")#mi("\\Box")#linebreak()#text(" The notion of a non-empty open connected subset ")#mi("{U}")#text(" of the complex plane comes up so frequently in complex analysis that many texts assign a special term to this notion; for instance, Stein-Shakarchi refers to such sets as ")#emph[#text("regions")]#text(", and in other texts they may be called ")#emph[#text("domains")]#text(". We will stick to just “non-empty open connected subset of ")#mi("{{\\bf C}}")#text("” in this course.")#linebreak()#text(" The requirement that ")#mi("{f}")#text(" be conservative is necessary, as the following exercise shows. Actually it is also necessary in the real-variable case, but it is redundant in that case due to the topological triviality of closed polygonal paths in one dimension: see Exercise ")#link(<tao-6b9cd7872ae634539ea1>)[#text("35")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{U}")#text(" be a non-empty connected open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" be continuous. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{f}")#text(" possesses at least one antiderivative ")#mi("{F}")#text(".")],
[#text("(ii) ")#mi("{f}")#text(" is conservative in the sense that ")#link(<tao-8588aad90351287d5682>)[#text("(9)")]#text(" holds for all closed polygonal paths in ")#mi("{U}")#text(".")],
[#text("(iii) ")#mi("{f}")#text(" is conservative in the sense that ")#link(<tao-8588aad90351287d5682>)[#text("(9)")]#text(" holds for all ")#emph[#text("simple")]#text(" closed polygonal paths in ")#mi("{U}")#text(".")],
[#text("(iv) ")#mi("{f}")#text(" is conservative in the sense that ")#link(<tao-8588aad90351287d5682>)[#text("(9)")]#text(" holds for all closed contours in ")#mi("{U}")#text(".")],
[#text("(v) ")#mi("{f}")#text(" is conservative in the sense that ")#link(<tao-8588aad90351287d5682>)[#text("(9)")]#text(" holds for all closed rectifiable curves in ")#mi("{U}")#text(".")]
)

#text("(Hint: to show that (iii) implies (ii), induct on the number of edges in the closed polygonal path, and find a way to decompose non-simple closed polygonal paths into paths with fewer edges. One should avoid non-rigorous “hand-waving” arguments, and make sure that one actually has covered all possible cases, e.g. paths that include some backtracking.) Furthermore, show that if ")#mi("{f}")#text(" has two antiderivatives ")#mi("{F_1, F_2}")#text(", then there exists a constant ")#mi("{C \\in {\\bf C}}")#text(" such that ")#mi("{F_2 = F_1 + C}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Show that the function ")#mi("{\\frac{1}{z}}")#text(" does not have an antiderivative on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(". (")#emph[#text("Hint:")]#text(" integrate ")#mi("{\\frac{1}{z}}")#text(" on ")#mi("{\\gamma_{0,1,\\circlearrowleft}}")#text(".) In later notes we will see that ")#mi("{\\frac{1}{z}}")#text(" nevertheless does have antiderivatives on many subsets of ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", formed by various branches of the ")#link("https://en.wikipedia.org/wiki/Complex_logarithm")[#text("complex logarithm")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" ")#metadata(none) <tao-6b9cd7872ae634539ea1>#text(" If ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" is a continuous function on an interval, show that ")#mi("{f}")#text(" is conservative in the sense that ")#link(<tao-8588aad90351287d5682>)[#text("(9)")]#text(" holds for any closed polygonal path in ")#mi("{[a,b]}")#text(". What happens for closed rectifiable paths?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(" (not necessarily connected).")

#list(
[#text("(i) Show that there is a unique collection ")#mi("{{\\mathcal U}}")#text(" of non-empty subsets of ")#mi("{U}")#text(" that are open, connected, disjoint, and partition ")#mi("{U}")#text(": ")#mi("{U = \\biguplus_{V \\in {\\mathcal U}} V}")#text(". (The elements of ")#mi("{{\\mathcal U}}")#text(" are known as the ")#link("https://en.wikipedia.org/wiki/Connected_space#Connected_components")[#text("connected components")]#text(" of ")#mi("{U}")#text(".)")],
[#text("(ii) Show that the number of connected components of ")#mi("{U}")#text(" is at most countable. (")#emph[#text("Hint:")]#text(" show that each connected component contains at least one complex number with rational real and imaginary parts.)")],
[#text("(iii) If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is a continuous conservative function on ")#mi("{U}")#text(", show that ")#mi("{f}")#text(" has at least one antiderivative ")#mi("{F}")#text(".")],
[#text("(iv) If ")#mi("{U}")#text(" has more than one connected component, show that it is possible for a function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" to have two antiderivatives ")#mi("{F_1, F_2}")#text(" which do not differ by a constant (i.e. there is no complex number ")#mi("{C}")#text(" such that ")#mi("{F_1 = F_2 + C}")#text(").")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37 (Integration by parts)")]#text(" Let ")#mi("{f,g: U \\rightarrow {\\bf C}}")#text(" be holomorphic functions on an open set ")#mi("{U}")#text(", and let ")#mi("{\\gamma}")#text(" be a rectifiable curve in ")#mi("{U}")#text(" with initial point ")#mi("{z_1}")#text(" and terminal point ")#mi("{z_2}")#text(". Prove that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z) g^{\\prime}(z)\\ dz = f(z_2) g(z_2) - f(z_1) g(z_1) - \\int_\\gamma f^{\\prime}(z) g(z)\\ dz.")]]
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (103)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-597478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("1.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("… Also, from the continuity of ")#tao-math("{\\left|\\gamma^{\\prime}\\right|}", block: false)#text(" we have")#linebreak()#text(" ")#tao-math("\\displaystyle  \\int_{T_*}^T |\\gamma^{\\prime}(t)|\\ dt \\leq \\left|\\gamma^{\\prime}(T_*)\\right| (T-T_*) + \\frac{\\varepsilon}{2} (T-T_*)", block: false)

#text("for all ")#mi("{T \\in [T_*, T_*+\\delta]}")#text(", …")
]

#text("One can identify what is going on here by rewriting the RHS:")

#tao-math("\\displaystyle  \\int_{T_*}^T |\\gamma^{\\prime}(t)|\\ dt \\leq \\int_{T_*}^T \\left(\\left|\\gamma^{\\prime}(T_*)\\right|  + \\frac{\\varepsilon}{2} \\right)dt", block: false)

#text("2.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("we conclude that ")#mi("{\\Omega_\\varepsilon = [a,b]}")#text(", and we are done.")
]

#text("By the definition of ")#mi("\\Omega_\\varepsilon")#text(", (4) follows. Recall that in order to prove the proposition, we want to prove (3) and (4).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-598515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Can a simple curve be equivalent to a non-simple curve up to continuous reparameterisation?")

#text("On the one hand, it seems yes by considering (2) with the domains ")#mi("[0,2\\pi]")#text(" and ")#mi("[0,4\\pi]")#text(", and the homomorphism ")#mi("\\phi(x)=2x")#text(" between these two closed intervals. On the other hand, we don’t want (do we?) these two curves to be equivalent since they have different winding numbers. Am I missing something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-598635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("The reparameterisation of (2) using the change of variables ")#mi("\\alpha=2\\theta")#text(" is ")#mi("\\alpha \\mapsto e^{i\\alpha/2}")#text(", ")#mi("0 \\leq \\alpha \\leq 4\\pi")#text(", which continues to wind around the origin exactly once.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-598641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("(Sorry for messing up the LaTeX code.)")

#text("I meant to ask that if the curve")#linebreak()#text(" ")#mi("\\displaystyle  \\gamma_1(\\theta)=re^{i\\theta},\\quad \\theta\\in[0,2\\pi]")#linebreak()#text(" and the curve")#linebreak()#text(" ")#mi("\\displaystyle  \\gamma_2(\\theta)=re^{i\\theta},\\quad \\theta\\in[0,4\\pi]")#linebreak()#text(" are equivalent up to continuous reparameterisation or not.")

#text("So the second one wind around the origin twice.")

#text("Is ")#mi("\\gamma_2")#text(" a reparameterisation of ")#mi("\\gamma_1")#text("?")

#emph[#text("[No. For instance, the arclengths are different. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-598650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Ah, thanks. I confused myself with the definition. The homomorphism ")#mi("\\phi:[0,2\\pi]\\to[0,4\\pi]")#text(" with ")#mi("\\phi(t)=2t")#text(" would not work since ")#mi("\\gamma_2(\\phi(\\pi))\\ne \\gamma_1(\\pi)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-598600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("In the proof of Proposition 10,")

#emph[#linebreak()#text(" … Adding this to the ")#mi("{T=T_*}")#text(" case of (4) using (7) we conclude that (4) also holds for all ")#mi("{T \\in [T_*,T_*+\\delta]}")#text(".")#linebreak()#text(" ")]

#text("I think “(7)” should be “Exercise 7”. Typo?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1bdf2b6021fed403775383e67bd5ad2072fb980e63efd95f0b2dddf5811cc-5250fbc72c4b431e10380bb743fde43273f6b3dbdbb614dc51cb19a6a05621a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wan-Teh Chang")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-599611")[#strong[#text("Wan-Teh Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("Hi Prof. Tao,")

#text("I’d like to report some typos and suggest some minor edits in Notes 2.")

#text("In the sentence “We will explore this theorem and several of its consequences the next set of notes”, I suggest adding the word “in” before “the next set of notes”.")

#text("In Exercise 3 (i), “Concatenation well defined up to equivalence”, I suggest adding “and reversal” after “Concatenation”.")

#text("In Exercise 5 (i), “Show that for any integer ")#mi("m,m^{\\prime}")#text("“, remove “, ")#mi("m^{\\prime}")#text("“.")

#text("In Definition 6, the subscripts in the summand are off by one. The subscripts in the summand should be ")#mi("j")#text(" and ")#mi("j-1")#text(", not ")#mi("j+1")#text(" and ")#mi("j")#text(".")

#text("At the end of the proof of Lemma 8 (Triangle inequality), “so taking the supremum of both sides in ")#mi("\\theta")#text("“, it suffices to take the supremum of the left-hand side because the right-hand side (a constant) is an upper bound of the left-hand side, and the supremum is ")#mi("\\le")#text(" any upper bound. Note: It also suffices to pick a particular value of ")#mi("\\theta")#text(" to make the left-hand side a nonnegative real number.")

#text("In the proof of Proposition 10 (Arclength formula), “for any ")#mi("1 \\le i \\le n")#text("“, change ")#mi("i")#text(" to ")#mi("j")#text(".")

#text("In the proof of Proposition 10 (Arclength formula), in the inequality after “Summing in ")#mi("j")#text(" we obtain”, the indexes in the summand on the left-hand side should be ")#mi("j")#text(" and ")#mi("j-1")#text(", not ")#mi("i")#text(" and ")#mi("i-1")#text(".")

#text("In Proposition 14 (Integration in rectifiable curves), the last sentence “In other words, for every ")#mi("\\epsilon > 0")#text(" there exists a ")#mi("\\delta")#text(" such that”, I suggest adding “")#mi("> 0")#text("” after “")#mi("\\delta")#text(".")

#text("In Exercise 26, “but the curve in Exercise 23 is not”, change “Exercise” to “Example”.")

#text("Optional: In the proof of Theorem 27 (First fundamental theorem of calculus), the variable ")#mi("T")#text(" is generally used to denote a number in the closed interval ")#mi("[T_{*}, T_{*} + \\delta]")#text(". However, in the sentence “On the other hand, if ")#mi("\\delta")#text(" is small enough, we have that …”, the variable ")#mi("t")#text(" is used instead (two occurrences). It would be good to use the variable ")#mi("T")#text(" consistently.")

#text("In the second-to-last sentence before Exercise 28, “…, and ")#mi("\\gamma")#text(" is a curve in ")#mi("D(z_0, R)")#text(" with initial point ")#mi("z_1")#text(" and terminal point ")#mi("x_2")#text("“, should we add “rectifiable” before “curve”?")

#text("In the hypothesis of Exercise 31, “Let ")#mi("U")#text(" be a non-empty connected subset of ")#mi("C")#text("“, does ")#mi("U")#text("” need to be open?")

#text("In Exercise 34 (i), there is an uncommon symbol that looks like the set union operator with a ")#mi("+")#text(" sign inside. Is that a typo?")

#text("Thank you!")

#emph[#text("[Thanks for the corrections. I use ")#mi("t")#text(" in the proof of Theorem 27 to distinguish it from ")#mi("T")#text(" in the next line which will refer to a distinct time variable. ")#mi("\\biguplus")#text(" is the symbol for disjoint union. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-605866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2020")])]

#text("I recall that you called the “continuity method” some sort of induction.")

#text("One version of the continuous induction says the following:")

#text("If ")#mi("A\\subset {\\bf R}^{\\ge 0}")#text(" and")

#text("(1) ")#mi("0\\in A")#linebreak()#text(" (2) if ")#mi("x\\in A")#text(" then there exists ")#mi("\\delta>0")#text(" such that ")#mi("[x,x+\\delta)\\subset A")#linebreak()#text(" (3) if ")#mi("[0,x)\\subset A")#text(" then ")#mi("x\\in A")#text(".")

#text("Then ")#mi("A={\\bf R}^{\\ge 0}")#text(".")

#text("Is the “continuity method” linked in this note the same as the notion of “continuous induction”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-606329")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("This is one instance of the continuity method (using the fact that the half-line ")#mi("{\\bf R}^{\\geq 0}")#text(" is connected with respect to the ")#link("https://en.wikipedia.org/wiki/Lower_limit_topology")[#text("right half-open topology")]#text("). More generally, the continuity method can be applied to arbitrary connected topological spaces (not just the half-line); in particular in this course we frequently apply it to open connected subsets of the complex plane.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-609679")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("Is the continuity method related to (and can it be phrased as) ")#link("https://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-609709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2020")])]

#text("When one applies the continuity method to a totally ordered connected domain such as an interval, one can usually use transfinite induction (or Zorn’s lemma) as a substitute for the method. However the continuity method can also be applied to other connected domains (e.g., open connected subsets of the complex plane), for which it is less evident how to apply transfinite induction (though in many cases one could take advantage of path connectedness and apply transfinite induction along each path separately).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-606804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("If one considers continuous curves but only differentiable reparametrisations, would one loose anything?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-606816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("If ")#mi("\\gamma_1:[a_1,b_1]\\to{\\bf C}")#text(" is equivalent to ")#mi("\\gamma_2:[a_2,b_2]\\to{\\bf C}")#text(" up to continuous reparametrisation, i.e., ")#mi("\\gamma_2\\circ\\phi=\\gamma_1")#text(" for some endpoint preserving ")#mi("\\phi")#text(", is such ")#mi("\\phi")#text(" unique? If not, can one always find a ")#mi("\\phi")#text(" that is differentiable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-607029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2020")])]

#text("It is not unique. One can always find one that is differentiable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-607248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Would it be circular somewhere if one uses Theorem 27 to prove Exercise 16(vii)?")

#emph[#text("[Probably, and in any event Theorem 27 is only applicable to holomorphic functions whereas Exercise 16 only requires continuity of the integrand. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 1: complex differentiation | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-634689")[#strong[#text("246A, Notes 1: complex differentiation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] Previous set of notes: Notes 0. Next set of notes: Notes 2. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-642571")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2022")])]

#emph[#linebreak()#text(" … The contour integral can be viewed as the special case of the more general *line integral* ")#mi("{\\int_\\gamma f(z) dx + g(z) dy}")#text(", that is of particular relevance in complex analysis.")#linebreak()#text(" ")]

#text("The linked Wikipedia article to “line integral” seems a bit confusing. In that article, “complex line integral” refers to the notion of “contour integrals” in this set of notes. On the other hand, they only define the line integral ")#mi("{\\int_\\gamma f(z) dx + g(z) dy}")#text(" when ")#mi("f")#text(" and ")#mi("g")#text(" are both real-valued; that’s what they call the line integral for (real) vector fields. Any other references?")

#text("According to your PCM article on differential forms linked in this note, the Euclidean structure (dot product) is not needed in the integrals of differential forms, particularly the line integrals. Since the contour integral can be viewed as a special line integral, is it also “independent” of the metric structure of paths in the complex plane? But this would seem to contradict the discussion of rectifiable curves where a metric is needed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-642648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2022")])]

#text("One can define line integrals for complex ")#mi("f,g")#text(" simply by computing the real and imaginary parts of the integral separately, much as one can compute the Riemann integral of a complex function in terms of the Riemann integral of the real and imaginary parts.")

#text("Rectificability only needs the metric structure up to Lipschitz equivalence; the Euclidean metric can be replaced by any other Lipschitz equivalent metric and one still has the same notion of rectifiability. Because all norms on a finite dimensional vector space are equivalent, the notion of rectifiability thus does not require any specific metric structure on this space.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-642616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2022")])]

#mi("\\int_a^bF(x)")#text(" should be ")#mi("\\int_a^b f(x)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-643097")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2022")])]

#text("Professor Tao, you have mentioned the terms “signed definite integral” and “unsigned integral” quite a few times in different contexts, and here too you started by stating these while reviewing the notions of integration one has for a real-valued function ")#mi("f: [ a,b] \\to \\mathbf{R}")#text(" of one real variable.")

#text("Could you please motivate these terms? What does it mean to call one of them as signed and the other as unsigned?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-643101")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2022")])]

#text("OK, I realize that the terms are adopted to distinguish between the cases of assigning or not assigning an orientation to the region or domain of integration.")#linebreak()#text(" Is this the only reason?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-643141")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2022")])]

#text("The unsigned integral ")#mi("\\int_{[a,b]} f(x)\\ dx")#text(" of an unsigned function ")#mi("f(x) \\geq 0")#text(" is still unsigned, but the signed integral ")#mi("\\int_a^b f(x)\\ dx")#text(" of an unsigned function can be negative if ")#mi("b < a")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-644124")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2022")])]

#text("Exercise 12 can be solved by noticing that finite arc length implies inite 1-dimensional Hausdorff measure, which yields zero 2-dimensional Hausdorff measure.")#linebreak()#text(" Is there a more elementary proof without considering Hausdorff measures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-644128")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2022")])]

#text("(Minor correction) In Line number 10 in the proof of Proposition 10 (Arc-length formula) there is a mismatch of ")#mi("i")#text(" and ")#mi("j")#text(" when you write ")#mi("t_{i}")#text(" while indexing the summands by ")#mi("j")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-644129")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2022")])]

#text("Also none of the tricki links are in working condition anymore. It says that the “site is offline”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c17ec3c8c170f76c4f87d2feca343bed0d95bb55d09f16538c74d64f056de9e3-fcdd2149c8ddf8d4b57b89e4e6aed10a3341a87049565e49323d42dc43c534d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cheng Yui To")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-2/#comment-644675")[#strong[#text("Cheng Yui To")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2022")])]

#text("For exercise 14, the reparametrization will not be continuous if the curve is constant on some interval right?")

#emph[#text("[Oops, this hypothesis needs to be added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In lines 2-3 below (1), it seems that after “as the maximum mesh size” should appear “tends to zero”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("Below exercise 9, in the definition of ")#mi("\\gamma ^{\\prime}(t)")#text(", it should be ")#mi("t^{\\prime} \\to t")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In the proof of (4), the link to the “continuity method” is not working.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472649")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In the third displayed formula below (4), ")#mi("t - T_*")#text(" in the RHS should be ")#mi("T - T_*")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In the last line of proposition 14, ")#mi("\\epsilon")#text(" should be ")#mi("\\delta")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Friend of Oryx")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472651")[#strong[#text("Friend of Oryx")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("From the proof of theorem 27: “But actually we can just give a direct proof that does not need any rectifiability hypothesis whatsoever.” Should this say “does not need any differentiability hypothesis”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In the proof of proposition 14, the running index in the sum defining ")#mi("E_j")#text(" should be ")#mi("k")#text(" (instead of ")#mi("j")#text("). This typo appears also later in two formulas involving ")#mi("E_j")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("Have you thought of putting the latex for the notes on GitHub? If you know git, it would make correcting the notes a bit easier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In theorem 30, in the line below the definition of ")#mi("F(z_1)")#text(", it should be ")#mi("z_1 \\in U")#text(". Also, in this line “in ")#mi("U")#text("” should be added after “polygonal path”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a8462a72448fe14b69159dccf4634697b80132d3799acbb7467dddc3a6ec8cf-974182dc6a4ce67ea9f5746954ed2a0b06495030cd8473ef785e7fb4cd8b1643.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In proposition 10 (arc length formula)")#linebreak()#text(" 4th formula")#linebreak()#text(" I think it should be <= sign instead of =sign")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("In the third displayed formula below (8), the second “dz” should be deleted.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472669")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("In the last displayed formula in the proof of theorem 27, the first “-” should be “+” (or ")#mi("T, T_*")#text(" should be interchanged).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472673")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("In the second example below theorem 27, the exponent “")#mi("z^1")#text("” should be “")#mi("z_1")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce923a432ae101fe76f27717a5bb7db35e955058a067a72afdaa728e2397fbf4-1feb059a9911eff744d948cc9f1189cb5b2e2f53aebe4c92b903a11e51dcf4b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jarred Barber")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472687")[#strong[#text("Jarred Barber")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("In Exercise 5, the domain of $\\gamma_m$ should be $[0,1]$, since you already have the $2\\pi$ factor in the exponent.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7ef0f6a36d47130f269709a4d446ee4d73ec3d4009cd6e6253407021e3ecabc-0a6575ec824653b06941f38e2140095efadc02777f23e7f051f9b85569f97b9a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of markmca")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472691")[#strong[#text("markmca")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("Hi Terry, if your work could harness a volunteer grid of 400k+ PCs, we have petaflops of processing to spare. Would be our pleasure to see it doing some cutting-edge maths. Cheers, Mark M")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("For the unsigned definite integral notation, ")#mi("\\int_{[a,b]}")#text(" with ")#mi("a,b")#text(" reals, is it defined only when ")#mi("[a,b]")#text(" is a real interval (i.e. ")#mi("a \\leq b")#text(") and is meaningless otherwise?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/454e3ac716c40a25bb66a5ffc9fd1b523cbcc05665c0be90e3c94bd9f51f1a11-b10e2280294c79df2f5419d114d7605f944e8c58d91487a5fb7c3b39557d9508.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurent C.")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472710")[#strong[#text("Laurent C.")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2016")])]

#text("In formula (6), is there a “r” missing just before the second integral ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472729")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("What is the essential difference between the signed and unsigned definite integrals? By convention, ")#mi("\\int_a^b:=\\int_b^a")#text(" for ")#mi("a>b")#text(". Can we also define similarly in the Lebesgue setting ")#mi("\\int_{[a,b]}=-\\int_{[b,a]}")#text(" for ")#mi("a>b")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("Such definition seems somewhat problematic since for ")#mi("a > b")#text(" the “interval” ")#mi("[a, b]")#text(" is (by definition) empty!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("In Proposition 10, you mean an ")#mi("=")#text(" sign instead of ")#mi(":=")#text(" there?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("The integral ")#mi("\\int_\\gamma f(z)\\ dz")#text(" can be just defined as ")#mi("\\int_a^bf(\\gamma(t))\\gamma^{\\prime}(t)\\ dt")#text(" when $\\gamma$ is piece-wise smooth. That is what Stein-Shakarchi does in the book. Proposition 14 considers the more general case that ")#mi("\\gamma")#text(" is only assumed to be continuous. Are there any advantages in applications for such generalization?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("Proposition 14 considers the case of rectifiable curves (not all continuous curves!) and exercise 15 shows that this integral definition can’t be extended for some unrectifiable curves (but perhaps it still may be extended for some other unrectifiable curves.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Topic boi")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472750")[#strong[#text("Topic boi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("In the approach you are describing, I think we have to worry about proving that the value of the integral does not depend on how the contour is broken up into smooth pieces (a point that is rarely handled carefully). Is there a simple way to prove this? (I’m asking because I want to understand this point better myself.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472769")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2016")])]

#text("While that definition is less general in terms of $\\gamma$ (which must be piecewise differentiable), it seems to me that it is much more general in terms of $f$ (interpreting the latter integral as a Lebesgue integral).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("As stated in the text, for most complex analysis applications, integration on piecewise smooth contours suffices. The added ability to integrate rectifiable curves has some use in geometric measure theory when one is working with fairly rough domains. In Notes 3 we extend integration of holomorphic functions further to arbitrary continuous curves, which is convenient for instance when developing a theory of winding numbers without any hypothesis of rectifiability.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472765")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2016")])]

#text("There is a typo in Proposition 14 ! The integral and the Riemann sum are within ")#mi("\\epsilon")#text(" of one another whenever the mesh is smaller than ")#mi("\\delta")#text(".")

#emph[#text("[Corrected, thanks – T.]")]

#text("Consider the function: ")#mi("f(z) = \\sum q^{n^2}")#text(" with ")#mi("q = e^{2\\pi i \\, z}")#text(" and ")#mi("z = x + i y")#text(". Then clearly:")

#mi("\\displaystyle a_n =  1 = e^{2\\pi n y}\\int_0^1  f(x+iy)  e^{-2\\pi i n x} \\, dx")

#text("As ")#mi("y \\to 1")#text(" the function ")#mi("f(x+iy)")#text(" is awfully chaotic. How can such the image curve be rectifiable? The more I think about it, I don’t know.")

#emph[#text("[I do not understand the question – what is the curve in question here, and what is the relevance of the ")#mi("a_n")#text("? -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("Concerning the statement just above exercise 15 (that one can’t simply omit the rectifiability hypothesis from proposition 14), is it still possible to slightly relax this hypothesis?")

#emph[#text("[Possibly, particularly if one assumes some strong regularity hypotheses on the integrand, but personally I think it is more productive instead to move away from the Riemann sum definition of integration if one wants to work with such rough curves. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crust")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472785")[#strong[#text("Crust")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("In Example 23, I think you want ")#mi("\\gamma(t) := t^3 e^{i/t}")#text(" (instead of with ")#mi("t^2")#text(") in order to get ")#mi("\\gamma^{\\prime}(0)=0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math 246A, Notes 3: Cauchy’s theorem and its consequences | What's new")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472786")[#strong[#text("Math 246A, Notes 3: Cauchy’s theorem and its consequences | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2016")])]

#text("[…] , be the midpoints of . Then from the basic properties of contour integration (see Exercise 16 of Notes 2) we can split the triangular integral as the sum of four integrals on smaller triangles, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472906")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2016")])]

#text("I will explain below relates to this post because it verifies that the integral calcules is not an absolute value ( mathematics need it). At any curve either derived or partial derivatives, the midpoint of the slope never coincides with the image of the function ")#mi("f(\\frac{x+x_{n}}{2})")#text(".")

#text("Function of all derivated is:")

#mi("F(x) = x + \\frac{f(x_{n}) - f(x)[(x_{n } - x) - x_{i}}{x_{n} - x}")

#text("We note that this equation applies to any continuous function.")

#text("Therefore if ")#mi("x_{i} = \\frac{x_{n} - x}{2}")#text(" we have:")

#text("$f(x + x_{n}}{2} \\neq x + \\frac{f(x_{n} – f(x)[(x_{n} – x) – x_{i}]}{x_{n} – x}$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3170687540c66dc22acac3ff153a5f7b25b10303e42e1144b148a6cfe32bff3d-0c12835ec5ba8882b4301c470ff7175f999ad4539c3167aabdb48ab191ff6473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eulogio Garcia")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-472936")[#strong[#text("Eulogio Garcia")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2016")])]

#text("Sorry for the tipo in the function F(x), where it is (x) is f(x).")

#mi("F(x) = f(x) + \\frac{f(x_{n}) - f(x)[(x_{n} - x) - x_{i}]}{x_{n} - x}")

#text("So if the midpoint of the interval does not meet the following, it is not is correct the derivative.")

#mi("\\frac{f(x + x_{n}}{2} =  f(x) + \\frac{f(x_{n} - f(x)[(x_{n} - x) - x_{i}]}{x_{n} - x}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-473060")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2016")])]

#text("ex. 15 —")#linebreak()#text(" for “possbile” read “possible”")

#text("ex. 31 —")#linebreak()#text(" for “Furthermoore” read “Furthermore”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f30e52bfb0efec14e2f2b9a34601e855ef5a7089b3fcee7634c602110e70296c-9e7c82894db461683248ff4681bb375ab12b478e61283a97263e8dc35c26e8f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doctor Hyde")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-474594")[#strong[#text("Doctor Hyde")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2016")])]

#text("In the proof of Proposition 10, the definition of the set ")#mi("\\Omega_\\epsilon")#text(" appears as if it ought to form part of a proof of validity of a “continuity method” that is stronger than the one cited, but just as easy to prove (and ")#link("http://math.stackexchange.com/questions/2011732")[#text("a question in Mathematics Stack Exchange")]#text(" suggests that it requires almost as much work to prove that ")#mi("\\Omega_\\epsilon")#text(" is closed), thus:")

#text("Let ")#mi("K")#text(" be a closed subset of ")#mi("[a, b]")#text(" containing ")#mi("a")#text(" and such that, for all ")#mi("x \\in K")#text(", if ")#mi("x < b")#text(" then there exists ")#mi("\\delta > 0")#text(" such that ")#mi("[x, x + \\delta] \\subseteq K")#text(". Define ")#mi("c = \\sup\\{ x \\in [a, b] : [a, x] \\subseteq K \\}")#text(". Then ")#mi("[a, c) \\subseteq K")#text(", therefore, because ")#mi("K")#text(" is closed, ")#mi("c \\in K")#text(". If ")#mi("c < b")#text(", then there exists ")#mi("\\delta > 0")#text(" such that ")#mi("[c, c + \\delta] \\subseteq K")#text(", therefore ")#mi("[a, c + \\delta] \\subseteq K")#text(", contradicting the definition of ")#mi("c")#text(". Hence ")#mi("c = b")#text(", i.e. ")#mi("K = [a, b]")#text(".")

#text("This can be applied directly to the set of all ")#mi("T \\in [a, b]")#text(" satisfying (4).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("The title of Section 1 might better be “Integration along rectifiable curves”:")

#text("… however we shall take a more leisurely approach here, discussing curves and rectifiable curves as well, as these concepts are also useful outside of complex analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478144")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Well, it is said in the note later that")

#emph[#text("By abuse of notation, we will refer to the quantity ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" as the contour integral of ")#mi("{f}")#text(" along ")#mi("{\\gamma}")#text(", even though ")#mi("{\\gamma}")#text(" is not necessarily a contour (we will define this concept shortly).")]

#text("which justifies the title.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Typo in “It one wants to do analysis in somewhat irregular domains”")

#text("It—> If")

#text("Typo in (2):")

#text("\\displaystyle \\gamma_{z_0,r,\\circlearrowleft}(t) := z_0 + r e^{i\\theta}. \\ \\ \\ \\ \\ (2)")

#text("where ")#mi("\\theta")#text(" should be ")#mi("t")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Similar typo in")

#mi("\\displaystyle  \\tilde \\gamma_{z_0,r,\\circlearrowleft}(t) := z_0 + r e^{2\\pi i \\theta}")

#text("where ")#mi("\\theta")#text(" should be ")#mi("t")#text(".")

#text("—————————–")#linebreak()#text(" ")#emph[#linebreak()#text(" The relation of being a continuous reparameterisation is an equivalence relation, so one can talk about the notion of a curve “up to continuous reparameterisation”, by which we mean an equivalence class of a curve under this relation.")#linebreak()#text(" ")]

#text("Is the relation defined only among simple curves?")

#emph[#text("[No – T.]")]

#text("“")#emph[#text("If we extended the domain in (2) from ")#mi("{[0,2\\pi]}")#text(" to (say) ${[0,4\\pi]}$, the curve would remain closed, but would no longer be simple (every point in the image is now traversed twice by the curve). ")]#text("”")

#text("The resulted curve has the same image as the one defined on ")#mi("[0,2\\pi]")#text(". Are they viewed as equivalent according to the equivalence relation mentioned above?")

#emph[#text("[No, these curves are not reparameterisations of each other -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478143")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Similarly as in Proposition 10, can one say that if ")#mi("\\gamma:[a,b]\\to{\\bf C}")#text(" is rectifiable, then its length is given by the integration ")#mi("\\int_a^b|\\gamma^{\\prime}(t)|\\ dt")#text("?")

#emph[#text("[Yes, but this requires the Lebesgue integral as well as the fundamental theorem of calculus for bounded variation functions, which is nontrivial (see e.g. ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")]#text(" ) – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478145")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("The change of variables formula (iv) lets one compute many contour integrals using the familiar Riemann integral. For instance, if ")#mi("{a < b}")#text(" are real numbers and ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" is continuous, then the contour integral along ")#mi("{\\gamma_{a \\rightarrow b}}")#text(" coincides with the Riemann integral,")

#mi("\\displaystyle  \\int_{\\gamma_{a \\rightarrow b}} f(z)\\ dz = \\int_a^b f(x)\\ dx")

#text("I don't understand this identity. How can ")#mi("f")#text(" be a function on both ")#mi("[a,b]")#text(" and also on the image of ")#mi("{\\gamma_{a \\rightarrow b}}")#text(", which is a subset of ")#mi("{\\bf C}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478168")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#mi("{\\mathbf R}")#text(" is a subset of ")#mi("{\\mathbf C}")#text(", so ")#mi("[a,b]")#text(" is also (and this set is equal to the image of ")#mi("\\gamma_{a \\to b}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("In the proof of Theorem 27,")

#text("But actually we can just give a direct proof that does not need any rectifiability hypothesis whatsoever.")

#text("Do you mean “differentiability” not “rectifiability” here? Otherwise why is ")#mi("\\gamma")#text(" assumed to be rectifiable in the theorem?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2017")])]

#text("The last sentence in Proposition 14 seems incomplete: a quantifier for ")#mi("\\varepsilon")#text(" is missing?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2017")])]

#text("For Example 21 and 22, does there exit a smooth curve ")#mi("\\hat{\\gamma}")#text(" so that ")#mi("\\gamma")#text(" and ")#mi("\\hat{\\gamma}")#text(" have the same image, though ")#mi("{\\gamma}")#text(" is not smooth?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478398")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("No; this can be seen by using the fact that smooth curves have to have a well-defined tangent line at every point. (Challenge question: what happens if we use the real variable notion of smooth, i.e. ")#mi("\\gamma")#text(" is infinitely differentiable without the requirement that ")#mi("\\gamma^{\\prime}")#text(" is non-vanishing?)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("Can we define the complex integral ")#mi("\\int_\\gamma f(z)\\ dz")#text(" when ")#mi("f")#text(" has a singularity on the image of ")#mi("\\gamma")#text("?")

#text("Removable singularities are OK. What about other kinds singularities?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478912")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("One can take the average of a contour going to one side of the singularity, and a contour going to the other side of the singularity; for instance, for a simple pole, this gives a principal value integral.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-479051")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2017")])]

#text("Suppose ")#mi("f(z)=z^{i-1}")#text(" with the standard branch of ")#mi("log")#text(" in the definition. Then using the limit definition as suggested in the comment above, one has ")#mi("\\int_{C_R}f(z)\\ dz=0")#text(" for ")#mi("C_R=\\gamma_{0,R,\\circlearrowleft}")#text(" with ")#mi("R>0")#text(". (If my calculation is correct.)")

#text("It seems that other hand holomorphic function, one can still have")#linebreak()#text(" ")#mi("\\displaystyle \\int_\\gamma f(z) \\ dz=0")#text(" for closed curves ")#mi("\\gamma")#text(" where ")#mi("f")#text(" has (non-isolated?) singularities due to some “branch cuts”. Do have some characterization similar to Cauchy’s theorem regarding this sort of functions (say functions like ")#mi("z\\mapsto z^\\alpha")#text(")?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-478918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2017")])]

#text("Such definition is needed only for non-integrable singularities (otherwise, the complex integral is well-defined!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-481926")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] 246A, Notes 2: complex integration […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-494791")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("Hello, Pro Tao, I have a question where you prove the first fundamental theorem of calculus. You construct a set {\\Omega_\\varepsilon} and say it’s clearly closed， and I don’t know why it’s closed. To prove this, my idea is that use continuity to prove inequality (7) for limit points. But I find it’s impossible to prove that arc length of a curve |{\\gamma_{[a,x]}| is continuous function of x on [a,b], otherwise every curve is rectifiable. So, how to prove that {\\Omega_\\varepsilon} is closed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-494799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("By hypothesis, ")#mi("\\gamma_{[a,b]}")#text(" is rectifiable. To prove continuity of ")#tao-math("x \\mapsto \\left|\\gamma_{[a,x]}\\right|", block: false)#text(", which is a monotone function, the main step is to show that ")#tao-math("\\left|\\gamma_{[a,x]}\\right| \\leq \\sup_{y<x} \\left|\\gamma_{[a,y]}\\right| + \\varepsilon", block: false)#text(" for every ")#mi("a  0")#text(" (this will give left-continuity, and there is a similar argument that will give right-continuity).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-494929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Hi, Pro Tao, thanks for your reply, according to your hint, I try to prove that $\\inf_{y<x} {|\\gamma_{[a,x]}| – |\\gamma_{[a,y]}|} \\leq \\varepsilon$")#linebreak()#text(" for every $\\varepsilon$, but I found that it comes back to my original question. That is whether x can be a jump discontinuity points. It means when yx, $|\\gamma_{[y,x]}|$->K, but K>0. If this phenomenon")#linebreak()#text(" exist , I can’t prove that inequality for every $\\varepsilon$ . And I can’t prove that this phenomenon can’t exist in a rectifiable curve. So, how to prove this? or is there any another way can prove the continuity without solve this problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-494949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#tao-math("\\left|\\gamma_{[a,x]}\\right|", block: false)#text(" is the supremum of the length of all polygonal paths from ")#mi("a")#text(" to ")#mi("x")#text(" with vertices increasing along ")#mi("\\gamma_{[a,x]}")#text(". By the triangle inequality, we may assume without loss of generality that the penultimate vertex ")#mi("y")#text(" lies within epsilon of ")#mi("x")#text(". Now use the triangle inequality again to bound the length of this path by ")#tao-math("\\left|\\gamma_{[a,y]}\\right| + \\varepsilon", block: false)#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-495114")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("Thanks a lot，Pro Tao. After tackling the problem that fixing the penultimate vertex in the circle B(\\gamma_{(x)},\\varepsilon} by the continuity of \\gamma_{(t)} , the left step seems become fluid.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7372863f1c5025505c2f0e372bc199488ae50a5b564ba938f96378b1e5c3c9f-201989625023f416037f6f9558889b2717dcd99ac36fd4269049bb986d79e922.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maxis Jaisi")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-551072")[#strong[#text("Maxis Jaisi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("In the proof of Proposition 14, you wrote")

#text("“This means that there is an increasing sequence ")#mi("{0 = m_0 < m_1 < \\dots < m_n = b}")#text(" of natural numbers…\"")

#text("Shouldn't it be")

#text("\"This means that there is an increasing sequence ")#mi("{0 = m_0 < m_1 < \\dots < m_n = n}")#text(" of natural numbers…\"")

#text("instead? ")#mi("b")#text(" is the endpoint of an interval.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1bdf2b6021fed403775383e67bd5ad2072fb980e63efd95f0b2dddf5811cc-5250fbc72c4b431e10380bb743fde43273f6b3dbdbb614dc51cb19a6a05621a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wan-Teh Chang")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-595426")[#strong[#text("Wan-Teh Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("Prof. Tao: I’d like to report a typo. In the second bullet point (ii) for Lebesgue integral at the beginning of this set of notes, we have:")

#text("where ")#mi("{E_i}")#text(" is the Lebesgue measure of ")#mi("{E_i}")

#text("The first ")#mi("{E_i}")#text(" should be changed to ")#mi("m(E_i)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]

#text("I also have a question. This set of notes mentions “(suitably regular) real functions” and “suitable regularity assumptions”. What does regularity mean here?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-595610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("In analysis, regularity is an informal term referring to the amount of differentiability (smoothness) in a function (or manifold, etc.). For instance, ")#mi("C^1")#text(" functions are more regular than ")#mi("C^0")#text(" functions, which are more regular than general measures, which are more regular than distributions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-595696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("Typo: In exercise 5, after “thus for instance”, ")#mi("{\\gamma_1 = \\gamma_{z_0,r,\\circlearrowright}}")#text(" should be ")#mi("{\\gamma_1 = \\gamma_{z_0,r,\\circlearrowleft}}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596126")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("In Proposition 14, can one work with the Darboux sums by formally defining ")#mi("dz=dx+idy")#text(" and then defining ")#mi("\\int_\\gamma f(z)dx")#text(" and ")#mi("\\int_\\gamma f(x)dy")#text(" separately?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596142")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("Yes, this is the approach taken in e.g. Gamelin, ch. 3. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("You mentioned in class that one can indeed interpret ")#mi("dz")#text(" as a complex measure: ")#tao-math("dz=\\theta(z)\\left|dz\\right|", block: false)#text(" for some ")#mi("\\theta(z)")#text(". Could you elaborate how one can define the integral ")#mi("\\int_\\gamma f(z)dz")#text(" in Proposition 14 using the complex measure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("One can write ")#mi("\\int_\\gamma f(z)\\ dz")#text(" as an integral ")#tao-math("\\int_\\gamma f(z) \\theta(z)\\ \\left|dz\\right|", block: false)#text(" with respect to the nonnegative measure ")#tao-math("\\left|dz\\right|", block: false)#text(" on ")#mi("\\gamma")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("If one ")#emph[#text("defines")]#text(" ")#tao-math("dz:=\\theta(z)\\left|dz\\right|", block: false)#text(", how does one choose the function ")#mi("\\theta(z)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("The function ")#mi("\\theta(z)")#text(" is simply the Radon-Nikodym deriative of the complex measure ")#mi("dz")#text(" with respect to the nonnegative measure ")#tao-math("\\left|dz\\right|", block: false)#text(" on ")#mi("\\gamma")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("I do not know Terence’s approach. But for each ")#mi("\\gamma")#text(", we can use the (complex) Riesz representation theorem to get a complex measure corresponding to it. Then ")#mi("\\int_\\gamma f(z)dz")#text(" is same as the integral of ")#mi("f")#text(" with respect to the measure. You can also do this directly because we have already know the value of the integral of ")#mi("\\int_\\gamma f(z)dz")#text(" from Proposition 14, (Let ")#mi("f")#text(" in Proposition 14 be the character function on a Borel set to get the measure of that set.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("Can you explain something more about the project which you have discussed in your today’s class(mostly for non-ucla student).")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69f78ca84676cd596cc590c6317f8ff7b2f20f23ad01251f1373e9c45950429d-939f3e1dfca2696608dd916944f50d7f61d1824cab438612049e6384ee35f0c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596187")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2020")])]

#text("This may answer your question – the CCLE page describes the project in a lot of detail, the (public) link is here: ")#link("https://ccle.ucla.edu/mod/page/view.php?id=3173126")[#text("https://ccle.ucla.edu/mod/page/view.php?id=3173126")]#text(". Nearly everything after the “Final” bullet point is concerned with this project. – Ben")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lemma 8")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596968")[#strong[#text("lemma 8")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("In Proof of Lemma 8(triangle inequality), we hve ")#tao-math("\\left|\\int_a^b f(t) dt\\right| \\leq \\sqrt{(}2) \\int_a^b |f(t)| dt", block: false)#text(". How is the ")#mi("\\sqrt{(}2)")#text(" coming in to this equation?")

#emph[#text("[ Here I am using Pythagoras’ theorem ")#tao-math("\\left|z\\right| = \\sqrt{\\left|\\mathrm{Re}(z)\\right|^2 + \\left|\\mathrm{Im}(z)\\right|^2}", block: false)#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lemma 8 concluding statement")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-596972")[#strong[#text("lemma 8 concluding statement")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("We have at the end of the proof of lemma 8 that ")#tao-math("\\left|z\\right| = sup_\\theta Re e^{i \\theta} z", block: false)#text(". How is this correct? I have the rhs equal to ")#mi("sup_\\theta (xcos \\theta - y sin \\theta)")#text(". How is this equal to ")#tao-math("\\left|z\\right|", block: false)#text("?")

#emph[#text("[It is clearer to see if one uses polar coordinates rather than Cartesian. It should also be geometrically obvious from the interpretation of multiplication of ")#mi("e^{i\\theta}")#text(" as a rotation. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597006")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("Geometrically, then it is sup(")#mi("\\theta")#text(") of the the real part of the rotation of z. I don’t understand.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597007")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("Hope you don’t mind I add a few more words to Tao’s comment to answer your question.")

#text("It would be easier to see what “geometrically” means if you draw a picture.")

#text("Given a non-zero complex number ")#mi("z")#text(", the quantity ")#mi("e^{i\\theta}z")#text(" means rotating ")#mi("z")#text(" around the origin. It is fairly easy to visualize this in a picture: when you vary the values of ")#mi("\\theta")#text(" from ")#mi("0")#text(" to ")#mi("2\\pi")#text(", you get the circle centered at the origin with radius ")#tao-math("\\left|z\\right|", block: false)#text(". Any complex number on this circle, i.e., any ")#mi("e^{i\\theta}z")#text(" has the real part in ")#tao-math("[-\\left|z\\right|,\\left|z\\right|]", block: false)#text(". One can always rotation ")#mi("z")#text(" so that ")#tao-math("\\mathrm{Re}(e^{i\\theta}z)=\\left|z\\right|", block: false)#text(", which proves the identity.")

#text("If you want to see it “algebraically”, suppose ")#mi("z=re^{i\\theta_0}")#text(". Then if you let ")#mi("\\theta=-\\theta_0")#text(", ")#tao-math("e^{i\\theta}z=r=\\left|z\\right|", block: false)#text(", which implies that")#linebreak()#text(" ")#tao-math("\\displaystyle \\sup_{\\theta}\\mathrm{Re}(e^{i\\theta}z)\\ge \\left|z\\right|.", block: false)

#text("But for any ")#mi("\\theta")#text(", ")#tao-math("\\mathrm{Re}(e^{i\\theta}z)\\le \\left|\\mathrm{Re}(e^{i\\theta}z)\\right|\\le \\left|e^{i\\theta}z\\right|=\\left|z\\right|", block: false)#text(". This gives you")#linebreak()#text(" ")#tao-math("\\displaystyle \\sup_{\\theta}\\mathrm{Re}(e^{i\\theta}z)\\le \\left|z\\right|.", block: false)
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("If one works with functions ")#mi("f:\\mathbf{C}\\to X")#text(" where ")#mi("X")#text(" is some real or complex Banach space, how much analysis in this course carries over?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("With regards to vector-valued functions, there are subtleties regarding how to define the integral (e.g., ")#link("https://en.wikipedia.org/wiki/Pettis_integral")[#text("Pettis (weak) integral")]#text(" vs ")#link("https://en.wikipedia.org/wiki/Bochner_integral")[#text("Bochner (strong) integral")]#text(") but generally speaking as long as one has enough regularity to avoid pathologies, most of the basic identities (e.g., fundamental theorem of calculus, Cauchy integral formula, etc.) have analogues, basically because one can apply linear functionals to study vector-valued integrals and derivatives in terms of their scalar counterparts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("Hello,")#linebreak()#text(" How can we guess the identity involving T(precisely the equation 7) that we have used in the proof of fundamental theorem of calculus using continuity method.")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("It is not a guess. It is an educated hypothesis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Proposition 10")]], [#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/comment-page-1/#comment-597463")[#strong[#text("Proposition 10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("In the proof of proposition 10, I have two questions:")#linebreak()#text(" 1. “Also, from the continuity of ")#tao-math("\\left| \\gamma^{\\prime} \\right|(t) dt \\leq \\left| \\gamma^{\\prime} (T_*)\\right|(T-T_*)-\\frac{ \\epsilon(T- T_*)}{2}", block: false)#text(".”. How is this?")#linebreak()#text(" 2. We conclude that ")#mi("\\Omega_\\epsilon = [a,b]")#text(". How does this prove the propositional statement.")
]
