// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:20:11.655918+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Brunn-Minkowski inequality for nilpotent groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Brunn-Minkowski inequality for nilpotent groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/")[#text("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the fundamental inequalities in convex geometry is the ")#link("http://en.wikipedia.org/wiki/Brunn%E2%80%93Minkowski_inequality")[#text("Brunn-Minkowski inequality")]#text(", which asserts that if ")#mi("{A, B}")#text(" are two non-empty bounded open subsets of ")#mi("{{\\bf R}^d}")#text(", then ")#metadata(none) <tao-7292b55d8cfc45bafdf2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu(A+B)^{1/d} \\geq \\mu(A)^{1/d} + \\mu(B)^{1/d},")]]



#text(" where")

#align(center)[#tao-fit-display[#mitex("A+B := \\{a+b: a \\in A, b \\in B \\}")]]

#text("is the sumset of ")#mi("{A}")#text(" and ")#mi("{B}")#text(", and ")#mi("{\\mu}")#text(" denotes Lebesgue measure. The estimate is sharp, as can be seen by considering the case when ")#mi("{A, B}")#text(" are convex bodies that are dilates of each other, thus ")#mi("{A = \\lambda B := \\{ \\lambda b: b \\in B \\}}")#text(" for some ")#mi("{\\lambda>0}")#text(", since in this case one has ")#mi("{\\mu(A) = \\lambda^d \\mu(B)}")#text(", ")#mi("{A+B = (\\lambda+1)B}")#text(", and ")#mi("{\\mu(A+B) = (\\lambda+1)^d \\mu(B)}")#text(".")

#text("The Brunn-Minkowski inequality has many applications in convex geometry. To give just one example, if we assume that ")#mi("{A}")#text(" has a smooth boundary ")#mi("{\\partial A}")#text(", and set ")#mi("{B}")#text(" equal to a small ball ")#mi("{B = B(0,\\epsilon)}")#text(", then ")#mi("{\\mu(B)^{1/d} = \\epsilon \\mu(B(0,1))^{1/d}}")#text(", and in the limit ")#mi("{\\epsilon \\rightarrow 0}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\mu(A+B) = \\mu(A) + \\epsilon \\left|\\partial A\\right| + o(\\epsilon)", block: true)]]

#text("where ")#tao-math("{\\left|\\partial A\\right|}", block: false)#text(" is the surface measure of ")#mi("{A}")#text("; applying the Brunn-Minkowski inequality and performing a Taylor expansion, one soon arrives at the ")#link("http://en.wikipedia.org/wiki/Isoperimetric_inequality")[#text("isoperimetric inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial A\\right| \\geq d \\mu(A)^{1-1/d} \\mu(B(0,1))^{1/d}.", block: true)]]

#text("Thus one can view the isoperimetric inequality as an infinitesimal limit of the Brunn-Minkowski inequality.")

#text("There are many proofs known of the Brunn-Minkowski inequality. Firstly, the inequality is trivial in one dimension:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (One-dimensional Brunn-Minkowski)")]#text(" ")#metadata(none) <tao-de3246094525b21a870f>#text(" If ")#mi("{A, B,C \\subset {\\bf R}}")#text(" are non-empty measurable sets with ")#mi("{A+B \\subset C \\subset {\\bf R}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mu(C) \\geq \\mu(A)+\\mu(B).")]]
]

#emph[#text("Proof:")]#text(" By ")#link("http://en.wikipedia.org/wiki/Regular_measure")[#text("inner regularity")]#text(" we may assume that ")#mi("{A,B}")#text(" are compact. The claim then follows since ")#mi("{C}")#text(" contains the sets ")#mi("{\\sup(A)+B}")#text(" and ")#mi("{A+\\inf(B)}")#text(", which meet only at a single point ")#mi("{\\sup(A)+\\inf(B)}")#text(". ")#mi("\\Box")

#text("For the higher dimensional case, the inequality can be established from the ")#link("http://en.wikipedia.org/wiki/Pr%C3%A9kopa%E2%80%93Leindler_inequality")[#text("Prékopa-Leindler inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Prékopa-Leindler inequality in ")#mi("{{\\bf R}^d}")#text(")")]#text(" ")#metadata(none) <tao-ea7e4017f6d750b4c5fc>#text(" Let ")#mi("{0 < \\theta < 1}")#text(", and let ")#mi("{f, g, h: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be non-negative measurable functions obeying the inequality ")#metadata(none) <tao-3485639faf1591f3c16f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("h(x+y) \\geq f(x)^{1-\\theta} g(y)^\\theta")]]



#text(" for all ")#mi("{x,y \\in {\\bf R}^d}")#text(". Then we have ")#metadata(none) <tao-e55cffc81a5ad8cfe852>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_{{\\bf R}^d} h \\geq \\frac{1}{(1-\\theta)^{d(1-\\theta)} \\theta^{d\\theta}} (\\int_{{\\bf R}^d} f)^{1-\\theta} (\\int_{{\\bf R}^d} g)^\\theta.")]]




]

#text("This inequality is usually stated using ")#mi("{h((1-\\theta)x + \\theta y)}")#text(" instead of ")#mi("{h(x+y)}")#text(" in order to eliminate the ungainly factor ")#mi("{\\frac{1}{(1-\\theta)^{d(1-\\theta)} \\theta^{d\\theta}}}")#text(". However, we formulate the inequality in this fashion in order to avoid any reference to the dilation maps ")#mi("{x \\mapsto \\lambda x}")#text("; the reason for this will become clearer later.")

#text("The Prékopa-Leindler inequality quickly implies the Brunn-Minkowski inequality. Indeed, if we apply it to the indicator functions ")#mi("{f := 1_A, g := 1_B, h := 1_{A+B}}")#text(" (which certainly obey ")#link(<tao-3485639faf1591f3c16f>)[#text("(2)")]#text("), then ")#link(<tao-e55cffc81a5ad8cfe852>)[#text("(3)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\mu(A+B)^{1/d} \\geq \\frac{1}{(1-\\theta)^{1-\\theta} \\theta^{\\theta}} \\mu(A)^{\\frac{1-\\theta}{d}} \\mu(B)^{\\frac{\\theta}{d}}")]]

#text("for any ")#mi("{0 < \\theta < 1}")#text(". We can now optimise in ")#mi("{\\theta}")#text("; the optimal value turns out to be")

#align(center)[#tao-fit-display[#mitex("\\theta := \\frac{\\mu(B)^{1/d}}{\\mu(A)^{1/d}+\\mu(B)^{1/d}}")]]

#text("which yields ")#link(<tao-7292b55d8cfc45bafdf2>)[#text("(1)")]#text(".")

#text("To prove the Prékopa-Leindler inequality, we first observe that the inequality ")#emph[#text("tensorises")]#text(" in the sense that if it is true in dimensions ")#mi("{d_1}")#text(" and ")#mi("{d_2}")#text(", then it is automatically true in dimension ")#mi("{d_1+d_2}")#text(". Indeed, if ")#mi("{f, g, h: {\\bf R}^{d_1} \\times {\\bf R}^{d_2} \\rightarrow {\\bf R}^+}")#text(" are measurable functions obeying ")#link(<tao-3485639faf1591f3c16f>)[#text("(2)")]#text(" in dimension ")#mi("{d_1+d_2}")#text(", then for any ")#mi("{x_1, y_1 \\in {\\bf R}^{d_1}}")#text(", the functions ")#mi("{f(x_1,\\cdot), g(y_1,\\cdot), h(x_1+y_1,\\cdot): {\\bf R}^{d_2} \\rightarrow {\\bf R}^+}")#text(" obey ")#link(<tao-3485639faf1591f3c16f>)[#text("(2)")]#text(" in dimension ")#mi("{d_2}")#text(". Applying the Prékopa-Leindler inequality in dimension ")#mi("{d_2}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("H(x_1+y_1) \\geq \\frac{1}{(1-\\theta)^{d_2(1-\\theta)} \\theta^{d_2\\theta}} F(x_1)^{1-\\theta} G(y_1)^\\theta")]]

#text("for all ")#mi("{x_1,y_1 \\in {\\bf R}^{d_1}}")#text(", where ")#mi("{F(x_1) := \\int_{{\\bf R}^{d_2}} f(x_1,x_2)\\ dx_2}")#text(" and similarly for ")#mi("{G, H}")#text(". But then if we apply the Prékopa-Leindler inequality again, this time in dimension ")#mi("{d_1}")#text(" and to the functions ")#mi("{F}")#text(", ")#mi("{G}")#text(", and ")#mi("{(1-\\theta)^{d_2(1-\\theta)} \\theta^{d_2\\theta} H}")#text(", and then use the ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(", we obtain ")#link(<tao-e55cffc81a5ad8cfe852>)[#text("(3)")]#text(".")

#text("From tensorisation, we see that to prove the Prékopa-Leindler inequality it suffices to do so in the one-dimensional case. We can derive this from Lemma ")#link(<tao-de3246094525b21a870f>)[#text("1")]#text(" by reversing the “Prékopa-Leindler implies Brunn-Minkowski” argument given earlier, as follows. We can normalise ")#mi("{f,g}")#text(" to have sup norm ")#mi("{1}")#text(". If ")#link(<tao-3485639faf1591f3c16f>)[#text("(2)")]#text(" holds (in one dimension), then the super-level sets ")#mi("{\\{f>\\lambda\\}, \\{g>\\lambda\\}, \\{h>\\lambda\\}}")#text(" are related by the set-theoretic inclusion")

#align(center)[#tao-fit-display[#mitex("\\{ h > \\lambda \\} \\supset \\{ f > \\lambda \\} + \\{ g > \\lambda \\}")]]

#text("and thus by Lemma ")#link(<tao-de3246094525b21a870f>)[#text("1")]

#align(center)[#tao-fit-display[#mitex("\\mu(\\{ h > \\lambda \\}) \\geq \\mu(\\{ f > \\lambda \\}) + \\mu(\\{ g > \\lambda \\})")]]

#text("whenever ")#mi("{\\lambda \\leq 1}")#text(". On the other hand, from the Fubini-Tonelli theorem one has the distributional identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} h = \\int_0^\\infty \\mu(\\{h > \\lambda\\})\\ d\\lambda")]]

#text("(and similarly for ")#mi("{f,g}")#text(", but with ")#mi("{\\lambda}")#text(" restricted to ")#mi("{(0,1)}")#text("), and thus")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} h \\geq \\int_{\\bf R} f + \\int_{\\bf R} g.")]]

#text("The claim then follows from the ")#link("http://en.wikipedia.org/wiki/Inequality_of_arithmetic_and_geometric_means")[#text("weighted arithmetic mean-geometric mean inequality")]#text(" ")#mi("{(1-\\theta) x + \\theta y \\geq x^{1-\\theta} y^\\theta}")#text(".")

#text("In this post, I wanted to record the simple observation (which appears in ")#link("http://www.ams.org/mathscinet-getitem?mr=2177813")[#text("this paper of Leonardi and Mansou")]#text(" in the case of the Heisenberg group, but may have also been stated elsewhere in the literature) that the above argument carries through without much difficulty to the nilpotent setting, to give a nilpotent Brunn-Minkowski inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Nilpotent Brunn-Minkowski)")]#text(" Let ")#mi("{G}")#text(" be a connected, simply connected nilpotent Lie group of (topological) dimension ")#mi("{d}")#text(", and let ")#mi("{A, B}")#text(" be bounded open subsets of ")#mi("{G}")#text(". Let ")#mi("{\\mu}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" on ")#mi("{G}")#text(" (note that nilpotent groups are ")#link("http://en.wikipedia.org/wiki/Unimodular_group")[#text("unimodular")]#text(", so there is no distinction between left and right Haar measure). Then ")#metadata(none) <tao-af07ff91ab7ce2a7d1f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mu(A \\cdot B)^{1/d} \\geq \\mu(A)^{1/d} + \\mu(B)^{1/d}.")]]




]

#text("Here of course ")#mi("{A \\cdot B := \\{ ab: a \\in A, b \\in B \\}}")#text(" is the product set of ")#mi("{A}")#text(" and ")#mi("{B}")#text(".")

#text("Indeed, by repeating the previous arguments, the nilpotent Brunn-Minkowski inequality will follow from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Nilpotent Prékopa-Leindler inequality)")]#text(" ")#metadata(none) <tao-e973e8a368ed6011f0cf>#text(" Let ")#mi("{G}")#text(" be a connected, simply connected nilpotent Lie group of topological dimension ")#mi("{d}")#text(" with a Haar measure ")#mi("{\\mu}")#text(". Let ")#mi("{0 < \\theta < 1}")#text(", and let ")#mi("{f, g, h: G \\rightarrow {\\bf R}}")#text(" be non-negative measurable functions obeying the inequality ")#metadata(none) <tao-e9c8046f7618ed3a4f95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("h(xy) \\geq f(x)^{1-\\theta} g(y)^\\theta")]]



#text(" for all ")#mi("{x,y \\in G}")#text(". Then we have ")#metadata(none) <tao-20bac69e5595efa30369>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_G h\\ d\\mu \\geq \\frac{1}{(1-\\theta)^{d(1-\\theta)} \\theta^{d\\theta}} (\\int_G f\\ d\\mu)^{1-\\theta} (\\int_G g\\ d\\mu)^\\theta.")]]




]

#text("To prove the nilpotent Prékopa-Leindler inequality, the key observation is that this inequality not only tensorises; it ")#emph[#text("splits")]#text(" with respect to short exact sequences. Indeed, suppose one has a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K \\rightarrow G \\rightarrow H \\rightarrow 0")]]

#text("of connected, simply connected nilpotent Lie groups. The adjoint action of the connected group ")#mi("{G}")#text(" on ")#mi("{K}")#text(" acts nilpotently on the Lie algebra of ")#mi("{K}")#text(" and is thus unimodular. Because of this, we can split a Haar measure ")#mi("{\\mu_G}")#text(" on ")#mi("{G}")#text(" into Haar measures ")#mi("{\\mu_K, \\mu_H}")#text(" on ")#mi("{K, H}")#text(" respectively so that we have the Fubini-Tonelli formula")

#align(center)[#tao-fit-display[#mitex("\\int_G f(g)\\ d\\mu_G(g) = \\int_H F(h)\\ d\\mu_H(h)")]]

#text("for any measurable ")#mi("{f: G \\rightarrow {\\bf R}^+}")#text(", where ")#mi("{F(h)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("F(h) := \\int_K f(kg) d\\mu_K(k) = \\int_K f(gk)\\ d\\mu_K(k)")]]

#text("for any coset representative ")#mi("{g \\in G}")#text(" of ")#mi("{h}")#text(" (the choice of ")#mi("{g}")#text(" is not important, thanks to unimodularity of the conjugation action). It is then not difficult to repeat the proof of tensorisation (relying heavily on the unimodularity of conjugation) to conclude that the nilpotent Prékopa-Leindler inequality for ")#mi("{H}")#text(" and ")#mi("{K}")#text(" implies the Prékopa-Leindler inequality for ")#mi("{G}")#text("; we leave this as an exercise to the interested reader.")

#text("Now if ")#mi("{G}")#text(" is a connected simply connected Lie group, then the abeliansation ")#mi("{G/[G,G]}")#text(" is connected and simply connected and thus isomorphic to a vector space. This implies that ")#mi("{[G,G]}")#text(" is a retract of ")#mi("{G}")#text(" and is thus also connected and simply connected. From this and an induction of the step of the nilpotent group, we see that the nilpotent Prékopa-Leindler inequality follows from the abelian case, which we have already established in Theorem ")#link(<tao-ea7e4017f6d750b4c5fc>)[#text("2")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Some connected, simply connected nilpotent groups ")#mi("{G}")#text(" (and specifically, the ")#link("http://en.wikipedia.org/wiki/Carnot_group")[#text("Carnot groups")]#text(") can be equipped with a one-parameter family of dilations ")#mi("{x \\mapsto \\lambda \\cdot x}")#text(", which are a family of automorphisms on ")#mi("{G}")#text(", which dilate the Haar measure by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu( \\lambda \\cdot x ) = \\lambda^D \\mu(x)")]]

#text("for an integer ")#mi("{D}")#text(", called the ")#emph[#text("homogeneous dimension")]#text(" of ")#mi("{G}")#text(", which is typically larger than the topological dimension. For instance, in the case of the Heisenberg group")

#align(center)[#tao-fit-display[#mitex("G := \\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix},")]]

#text("which has topological dimension ")#mi("{d=3}")#text(", the natural family of dilations is given by")

#align(center)[#tao-fit-display[#mitex("\\lambda: \\begin{pmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1 \\end{pmatrix} \\mapsto \\begin{pmatrix} 1 & \\lambda x & \\lambda^2 z \\\\ 0 & 1 & \\lambda y \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("with homogeneous dimension ")#mi("{D=4}")#text(". Because the two notions ")#mi("{d, D}")#text(" of dimension are usually distinct in the nilpotent case, it is no longer helpful to try to use these dilations to simplify the proof of the Brunn-Minkowski inequality, in contrast to the Euclidean case. This is why we avoided using dilations in the preceding discussion. It is natural to wonder whether one could replace ")#mi("{d}")#text(" by ")#mi("{D}")#text(" in ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(4)")]#text(", but it can be easily shown that the exponent ")#mi("{d}")#text(" is best possible (an observation that essentially appeared first in ")#link("http://www.ams.org/mathscinet-getitem?mr=1976833")[#text("this paper of Monti")]#text("). Indeed, working in the Heisenberg group for sake of concreteness, consider the set")

#align(center)[#tao-fit-display[#tao-math("A := \\{ \\begin{pmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1 \\end{pmatrix}: \\left|x\\right|, \\left|y\\right| \\leq N, \\left|z\\right| \\leq N^{10} \\}", block: true)]]

#text("for some large parameter ")#mi("{N}")#text(". This set has measure ")#mi("{N^{12}}")#text(" using the standard Haar measure on ")#mi("{G}")#text(". The product set ")#mi("{A \\cdot A}")#text(" is contained in")

#align(center)[#tao-fit-display[#tao-math("A := \\{ \\begin{pmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1 \\end{pmatrix}: \\left|x\\right|, \\left|y\\right| \\leq 2N, \\left|z\\right| \\leq 2N^{10} + O(N^2) \\}", block: true)]]

#text("and thus has measure at most ")#mi("{8N^{12} + O(N^4)}")#text(". This already shows that the exponent in ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(4)")]#text(" cannot be improved beyond ")#mi("{d=3}")#text("; note that the homogeneous dimension ")#mi("{D=4}")#text(" is making its presence known in the ")#mi("{O(N^4)}")#text(" term in the measure of ")#mi("{A \\cdot A}")#text(", but this is a lower order term only.")

#text("It is somewhat unfortunate that the nilpotent Brunn-Minkowski inequality is adapted to the topological dimension rather than the homogeneous one, because it means that some of the applications of the inequality (such as the application to isoperimetric inequalities mentioned at the start of the post) break down. (Indeed, the topic of isoperimetric inequalities for the Heisenberg group is a subtle one, with many naive formulations of the inequality being false. See the ")#link("http://www.ams.org/mathscinet-getitem?mr=1976833")[#text("paper of Monti")]#text(" for more discussion.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The inequality can be extended to non-simply-connected connected nilpotent groups ")#mi("{G}")#text(", if ")#mi("{d}")#text(" is now set to the dimension of the largest simply connected quotient of ")#mi("{G}")#text(". It seems to me that this is the best one can do in general; for instance, if ")#mi("{G}")#text(" is a torus, then the inequality fails for any ")#mi("{d>0}")#text(", as can be seen by setting ")#mi("{A=B=G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Specialising the nilpotent Brunn-Minkowski inequality to the case ")#mi("{A=B}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mu(A \\cdot A) \\geq 2^d \\mu(A).")]]

#text("This inequality actually has a much simpler proof (attributed to Tsachik Gelander in ")#link("http://arxiv.org/abs/0909.2190")[#text("this paper of Hrushovski")]#text(", as pointed out to me by Emmanuel Breuillard): one can show that for a connected, simply connected Lie group ")#mi("{G}")#text(", the exponential map ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" is a measure-preserving homeomorphism, for some choice of Haar measure ")#mi("{\\mu_{{\\mathfrak g}}}")#text(" on ")#mi("{{\\mathfrak g}}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mu_{{\\mathfrak g}}(\\log(A \\cdot A)) \\geq 2^d \\mu_{{\\mathfrak g}}(\\log A).")]]

#text("But ")#mi("{A \\cdot A}")#text(" contains all the squares ")#mi("{\\{a^2: a \\in A \\}}")#text(" of ")#mi("{A}")#text(", so ")#mi("{\\log(A \\cdot A)}")#text(" contains the isotropic dilation ")#mi("{2 \\cdot \\log A}")#text(", and the claim follows. Note that if we set ")#mi("{A}")#text(" to be a small ball around the origin, we can modify this argument to give another demonstration of why the topological dimension ")#mi("{d}")#text(" cannot be replaced with any larger exponent in ")#link(<tao-af07ff91ab7ce2a7d1f9>)[#text("(4)")]#text(".")

#text("One may tentatively conjecture that the inequality ")#mi("{\\mu(A \\cdot A) \\geq 2^d \\mu(A)}")#text(" in fact holds in all unimodular connected, simply connected Lie groups ")#mi("{G}")#text(", and all bounded open subsets ")#mi("{A}")#text(" of ")#mi("{G}")#text("; I do not know if this bound is always true, however.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80192")[#strong[#text("Deane")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2011")])]

#text("This is pretty cool. A consequence of the Brunn-Minkowski inequality is the isoperimetric inequality, which in turn implies sharp Sobolev inequalities. Can this chain of reasoning be used for a nilpotent Lie group, too?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd4d6f7c957fadda199dc126443e196e4eda2db3001bdea48132a5f43607760-fb213bab809261697e135d8664d4102f6329e5923004adbd3b7e525268462344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80199")[#strong[#text("Deane")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2011")])]

#text("Oops. I didn’t read the full posting carefully enough. I see that this chain does break down already when trying to use Brunn-Minkowski to prove an isoperimetric inequality. Interesting…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80236")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2011")])]

#text("Typo: In first para, for “conve bodies” read “convex bodies”")

#text("WFL")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80452")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2011")])]

#text("In Remark 1, when ")#mi("N \\in (0,1)")#text(", the important term is ")#mi("O(N^{4})")#text(" and ")#mi("N^{12}")#text(" is lower order. I mentioned this because in the fictional correspondence between approximate groups and topological groups, large sumsets should be seen (I think) as small balls.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2011")])]

#text("I plan to discuss the correspondence between approximate groups and (local) groups in detail in a subsequent post (probably Lecture 5 or 6 in my course notes; it requires a certain amount of preparatory material, most notably the machinery of ultraproducts, to perform properly). But I will just make three remarks for now:")

#text("1. When N is small, the set A described above fails to be an approximate group because A.A becomes much larger than A (A has measure about N^{12}, while A.A has measure around N^4). As such, this regime is not related to the structural theory of approximate groups (and is also not close to being an extremal example for the Brunn-Minkowski inequality).")

#text("2. When N is large, the topological group associated with the approximate group A is not the Heisenberg group, but rather the Euclidean group R^3. The link is provided by the approximate homomorphism that maps ")#mi("\\begin{pmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1 \\end{pmatrix}")#text(" to ")#mi("(x/N, y/N, z/N^{10})")#text(". The point is that this map (which behaves like a homomorphism near A) compresses almost all of the noncommutative structure of the Heisenberg group to nothingness, leaving only the residual Euclidean structure as a degenerate limit of the Heisenberg structure. (One can see this also by observing that iterated sum sets kA of A for small k grow in measure like k^3 rather than k^4, suggesting Euclidean structure at the scale of A, rather than Heisenberg structure.) Again, to formalise these statements properly one has to consider an ultraproduct of approximate groups, rather than a single approximate group; I’ll discuss this more in a future post.")

#text("3. When N is comparable to 1, then the appropriate group to associate with A is indeed the Heisenberg group (note that kA now grows like k^4 in this regime).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80838")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2011")])]

#text("Thanks for the precise answer. What I wanted to say was that I expect results of the type: “the approximate group A is roughly equivalent with a small ball in the conical group B” (or to a ball in a local conical group B). That is because, probably, at some point you shall identify families of “typical” elements in large(r and larger) sum sets with elements of something having the structure of a local group.")

#text("Remarks 2. and 3. , even 1. with some modification, are an illustration of the fact that the operation of the group where the approximate group lies is not very important. Let us vary the Heisenberg group operation, for example by transporting everything by the map you mention at 2. Then, as ")#mi("N")#text(" becomes larger (there is also a play with ")#mi("k")#text("), the group operation becomes the one of the conical group you are after.")

#text("Your remark showed a new thing to me, namely that, how to put it, the “shape” of the approximate group chooses the right dilations in the conical group from the limit, as a principle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2011")])]

#text("Yes, the asymptotic group that models an approximate group depends quite sensitively on the “shape” of that approximate group, which ends up being more important in many ways than the ambient group that the approximate group lives in.")

#text("In some cases, the asymptotic group model does not have an easy interpretation as a “conical” limit, because the approximate homomorphisms involved are only locally defined rather than globally defined. To give an example, take the ambient group ")#mi("G = ({\\bf R}, +)")#text(", and let A be the set")

#mi("A = [0,1] \\cup [N,N+1] \\cup [2N,2N+1] \\cup \\ldots \\cup [N^2-N,N^2-N+1]")

#text("which is the union of N equally spaced unit intervals, with the spacing between intervals being comparable to N, where N is a large integer. (Actually, this is not quite an approximate group because, by definition, such groups are supposed to be symmetric around the origin, but one can easily modify the above example to be symmetric by a suitable translation.) In this case, the asymptotic group that models A is actually ")#mi("{\\bf R}^2")#text(", and the approximate homomorphism that links A (as well as iterated sumsets ")#mi("kA=A+\\ldots+A")#text(" for small k) to this asymptotic group is given by the map ")#mi("\\phi: aN + b \\mapsto (\\frac{a}{N}, b)")#text(" for a an integer of size O(N), and b a real of size O(1). Note that in this example kA grows quadratically in k for small k (though it eventually reverts to linear growth for ")#mi("k \\gg N")#text("), which is consistent with the two-dimensionality of the asymptotic group. Thus we see here that due to the disconnected nature of A, the asymptotic group model ends up having larger dimension than the ambient group, making it difficult to interpret the former as a conical limit of the latter. So conical limits are certainly one type of example of asymptotic group model of an approximate group, but it turns out that they are not fully representative of this concept.")

#text("(Note also that in this case the approximate homomorphism ")#mi("\\phi")#text(" is only locally defined in some portions of ")#mi("{\\bf R}")#text(", but not globally defined on all of ")#mi("{\\bf R}")#text(". This hints at the fact that the category of local groups is a slightly more natural category to study approximate groups than the category of global groups. Indeed, one can view ")#mi("{\\bf R}^2")#text(" as emerging as a Gromov-Hausdorff limit of certain “local dilations” of ")#mi("{\\bf R}")#text(" if one wishes, and so one can in some sense recover a rather strange, local interpretation of “conical limit” with which to try to understand the concept of an asymptotic group model.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-81259")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2011")])]

#text("Nice example, the one with ")#mi("\\mathbb{R}^{2}")#text(", which is a conical group, but I look forward for your future posts to understand exactly how “shape” chooses the right dilations (or where I am wrong, quite possibly).")

#text("Concerning the matter of local groups versus conical groups, for me all structures, groups and dilations included, are local and only by chance they become global. By definition a (local) conical group is a left distributive uniform idempotent right quasigroup (aka “linear dilation structure”) see arXiv:1005.5031 and references. The (family of) operation(s) of the quasigroup (indexed by a commutative group with an absolute) are the dilations, which generate the (local) group operation by a precise recipe.")

#text("In this (maybe strange) language, the solution of the Hilbert’ 5th problem is that a topological, locally compact, local group admits a a left invariant, linear dilation structure such that the tangent space at identity (in the sense of dilation structures) has the algebraic structure of a commutative conical group. There are many other interesting, or relevant dilation structures, beside this one. Many more “analyses” than the well-known one, say.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-81621")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2011")])]

#text("There are examples in which the asymptotic model group does not have a dilation structure. For instance, if we modify the previous example by setting ")#mi("G = ({\\bf R},+)")#text(" and")

#mi("A = [0,1] \\cup [10,11] \\cup [20,21] \\cup \\ldots \\cup [10 N - 10, 10N-9]")

#text("then the model group is now a cylinder ")#mi("{\\bf R} \\times {\\bf R}/{\\bf Z}")#text(", with the approximate homomorphism mapping ")#mi("10a+b")#text(" to ")#mi("(\\frac{a}{N}, \\frac{b}{10})")#text(" for ")#mi("a = O(N)")#text(" and ")#mi("0 \\leq b < 10")#text(". Here, A is approximately mapped onto the rectangle ")#mi("[0,1] \\times [0,\\frac{1}{10}]")#text(". Note that the dilates kA exhibit quadratic growth up to k=10, and then linear growth for larger values of k.")

#text("On the other hand, the slightly larger set 10A can be safely modeled by ")#mi("{\\bf R}")#text(". One of the theorems we will show later is that if A is an approximate group in an arbitrary ambient group, then for some sufficiently large k, kA can be modeled by a connected, simply connected Lie group, which can be taken to be nilpotent if A was discrete. These groups however need not have a dilation structure. For instance, if one picks a Lie group at random, say G = SL_2(R), and lets A be the unit ball in G (wrt some metric, say a smooth Riemannian left-invariant one), then A is an approximate group which is its own model; the growth of iterates A^k of A is not controlled by any Lie group that is more \"primitive\" than SL_2(R), and this group has no obvious dilation structure.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d989b9ed21e4839fc776407b1879d816bc299be829ee9d7bf48375736e793d-99a0d547d42354728202b801d094076c34be1045a8d002d836a9a508a5292d21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-80462")[#strong[#text("Florian")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2011")])]

#text("Something is wrong in (3) or its conclusion: you take (3) to the power 1/d to get the estimate for $\\mu(A+B)^{1/d}$, but you don’t take $\\mu(A)$ and $\\mu(B)$ to the power 1/d.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82033")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2011")])]

#text("Re: “if A is an approximate group in an arbitrary ambient group, then for some sufficiently large k, kA can be modeled by a connected, simply connected Lie group, which can be taken to be nilpotent if A was discrete.” I look forward to see the proof! I bet that such a group has an action by a commutative group (like ")#mi("(\\mathbb{Z}, +)")#text(" or ")#mi("(\\mathbb{R}, +)")#text(" by automorphisms, which is contracting in some sense.")#linebreak()#text(" This is compatible with your two examples from previous comments (for ")#mi("k")#text(" large).")

#text("Or maybe is just lack of imagination on my side. The trick of dilation structures should be just the tip of an aisberg. It already covers manifolds, symmetric spaces, riemannian and sub-riemannian structures, some p-adic (and tree-like) structures, BUT all these objects are already constructed. Your work, coming from the finite towards the infinite objects, could show how these and many other such objects appear in the limit, that is why I am fascinated by your “finitary” program.")

#text("Re: the group ")#mi("SL_{2}(\\mathbb{R})")#text(", it is a Lie group, therefore it has a trivial dilation structure, given by transport on the group of the multiplication by positive scalars on the algebra (the solution of H5 problem), but indeed, it is not clear if it is of any relevance for the problem at hand.")

#text("Looks maybe as a king of degenerate situation: take a group ")#mi("G")#text(" and a “full” set inside ")#mi("A = G")#text(", then ")#mi("A")#text(" is its own model.")

#text("What about taking the subset ")#mi("A")#text(", seen in the algebra (pick 3 generators and see ")#mi("A")#text(" as a subset of ")#mi("\\mathbb{R}^{3}) to have the form")#text("latex [-1,1]^{\\alpha}\\times [-1,1]^{\\alpha} \\times [-1,1]^{\\beta}$, with ")#mi("\\beta = \\alpha^{m}")#text(", then what happens as ")#mi("\\alpha")#text(" is small(er and smaller)? Are there also three regimes w.r.t. to the choice of ")#mi("m")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82347")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("I think nilpotent-with-dilation (i.e. Carnot) type structures appear for discrete approximate groups when one looks at the asymptotic limit of kA either at very coarse scales ")#mi("k \\to \\infty")#text(", or also at very fine scales ")#mi("k \\to 0")#text(", but when working at medium scales ")#mi("k \\sim 1")#text(" (which is the case of interest to additive combinatorics) one only sees nilpotent structure and not the dilations.")

#text("(Here one has to define ")#mi("kA")#text(" for fractional k in a suitable sense. The precise definition is complicated, but as a first approximation, one can think of ")#mi("\\frac{1}{n} A")#text(" as those elements ")#mi("g")#text(" such that ")#mi("g,\\ldots,g^n")#text(" all lie in ")#mi("A")#text(". Note that this gives Euclidean (or more precisely, Lie algebra) structure in the limit rather than Carnot structure, in contrast to Pansu’s theorem. Thus, the behaviour of kA exhibits three regimes: Euclidean/Lie algebra structure at fine scales, Lie group structure at medium scales, and Carnot group structure at large scales.)")

#text("For instance, take a 3-step nilpotent Lie algebra ")#mi("{\\mathfrak g}")#text(" that has rational structure coefficients wrt some Mal’cev basis ")#mi("e_{1,1},\\ldots,e_{1,r_1}, e_{2,1},\\ldots,e_{2,r_2}, e_{3,1},\\ldots,e_{3,r_3}")#text(" but is not homogeneous (thus, for instance, a Lie bracket ")#mi("[e_{1,i}, e_{1,j}]")#text(" of the 1-step generators may involve both the 2-step generators ")#mi("e_{2,k}")#text(" and the 3-step generators ")#mi("e_{3,k}")#text(", in contrast to a Carnot group when only the 2-step generators are involved. One can exponentiate this to obtain a connected simply connected 3-step nilpotent group G. Inside this group G, one can build a discrete approximate group A consisting of all elements of the form")

#mi("e_{1,1}^{a_{1,1}} \\ldots e_{3,r_3}^{a_{3,r_3}}")

#text("where each ")#mi("a_{i,j}")#text(" is an integer multiple of ")#mi("N^{-i}")#text(" of magnitude at most 1. (Technically, this is not quite an approximate group because A is not perfectly symmetric, but it is close enough to being one for the purpose of this discussion.) In the limit ")#mi("N \\to \\infty")#text(", this group A is modeled by a “unit cube” in G, which is defined similarly to A except that the ")#mi("a_{i,j}")#text(" now range in the continuous interval [-1,1] rather than a discretisation thereof. Because we are not taking an asymptotic limit to very fine scales or very coarse scales, we don’t get to take a Pansu-like scaling limit to pass from the nilpotent group G to its associated Carnot group (or to its Lie algebra, depending on which way one is taking the scaling.)")

#text("This distinction in behaviour is part of a broader distinction between single-scale analysis and asymptotic analysis, which I discuss at ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")]

#text("Broadly speaking, the objects obtained in asymptotic analysis tends to be more symmetric and invariant than their single-scale counterparts, and as such, the former does not fully capture the behaviour of the latter, although it often describes the “main term” or the “principal behaviour” in some sense.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82412")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("Re: “when one looks at the asymptotic limit of kA either at very coarse scales , or also at very fine scales , but when working at medium scales (which is the case of interest to additive combinatorics) one only sees nilpotent structure and not the dilations.” Very interesting, I have to think and come back later. However, only two comments:")

#text("1. Your proof of the Brunn-Minkowski inequality shows that: (a) as expected, (the Haar) measure is related to the counting measure (is like counting an infinity of elements) and (b) as you say at the end of your Remark 1., the inequality does not feel the metric dimension, so it says to me that the measure itself is not fine enough, it is “commutative” somewhere deep inside. As a kind of consequence, this is an argument for counting not being geometrical enough, at asymptotic scales at least.")

#text("2. Let’s suppose that in the asymptotic regime, indeed, appears a conical group structure (Carnot or other, like 2-adic (??)). Then, you have the so much discussed dilations, take one (of nontrivial coefficient). In some sense, there is a “finitary” version of it, accept you have it. Surely, from a combinatorial point of view, it should be very complex (maybe there is no algorithm to define it, only in some specific classes of examples). Why? Because it simplifies very much the addition of “big” elements (apply the dilation and get much smaller elements; add them and then apply the inverse dilation to the result and then proceed to refine this almost exact result). That is why I would be very very interested (I try this anyway) to find out if there is any way to prove the existence (maybe non-constructively) of the finitary shadow of the dilations. I know it goes against the effort of giving quantitative proofs, but it brings geometry into the matter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82947")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2011")])]

#text("Re: “(Here one has to define kA for fractional k in a suitable sense. The precise definition is complicated, but as a first approximation, one can think of \\frac{1}{n} A as those elements g such that g,\\ldots,g^n all lie in A. Note that this gives Euclidean (or more precisely, Lie algebra) structure in the limit rather than Carnot structure, in contrast to Pansu’s theorem.”")

#text("Trivial example:")

#text("Take ")#mi("G= \\mathbb{Z}^{3}")#text(" with the Heisenberg group operation ")#mi("(a,b,c) \\cdot (a^{\\prime},b^{\\prime},c^{\\prime}) = (a+a^{\\prime},b+b^{\\prime},c+c^{\\prime}+ab^{\\prime}-a^{\\prime}b)")#text(" and ")#mi("A(N) = \\left\\{(a,b,c) \\in G \\text{ : } \\mid a \\mid \\leq N , \\mid b \\mid \\leq N , \\mid c \\mid \\leq N^{2} \\right\\}")#text(". The set ")#mi("A(N)")#text(" is an approximate group and, by your definition, for $n \\in \\mathbb{N}^{*}$, that $\\frac{1}{n} A(N) = \\left\\{ (a,b,c) \\in G \\mbox{ : } \\mid a \\mid \\leq \\frac{N}{n}, \\mid b \\mid \\leq \\frac{N}{n} , \\mid c \\mid \\leq \\frac{N^{2}}{n} \\right\\}$, which is far from ")#mi("A(\\frac{N}{n})")#text(". That is why, in the limit “this gives Euclidean …”.")

#text("Define $n \\cdot (a,b,c) =(n a, n b, n^{2} c)$, then $n \\cdot A(\\frac{N}{n}) = A(N)$. This is the “true” self-similarity in this case. As you see, the definition of it is not easy to write, in the sense that if I give you an element ")#mi("y")#text(" of ")#mi("n A(N) \\subset A(nN)")#text(", written as a word with ")#mi("n")#text(" letters from ")#mi("A")#text(", it is far from obvious to tell how to produce the element ")#mi("x")#text(" of ")#mi("A(N)")#text(" such that ")#mi("n \\cdot x")#text(" is closest to ")#mi("y")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-84147")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2011")])]

#text("Excuses for the typos in latex, I can’t see the final look of the comment before submitting.")

#text("Shortly said, what I believe is that the result of Breuillard and Green")#linebreak()#text(" arXiv:0906.3598, saying that approximate groups in Carnot groups are controlled by nilboxes, is true (in some asymptotic regimes maybe) in a more general situation, i.e. without supposing that the ambient group is nilpotent or even without any ambient group hypothesis (other than the ones which can be turned into hypotheses on the approximate group itself).")

#text("My hope is that it is possible to prove this from the start, without invoking a Gromov theorem & Hilbert 5 problem (in order to construct the ambient somehow). One way would be to prove that there are some families of dilations (i.e. some “homomorphisms” of “nilboxes”) and only in the end prove by abstract nonsense that in some limit the “nilboxes” have to be really nilboxes and so on.")

#text("Or, there is another thing maybe, turn the reasoning upside up and use Breuillard-Green like result to prove that any approximate group which is roughly equivalent with a nilbox has some dilations (in a rough sense), then quantify the complexity of such objects by estimating how much the use of said dilations simplify the word problem.")

#text("I have a strong feeling that your program on H5 problem and approximate groups is close to these ideas.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2f96de3f3c7ec49e28dde5e9663d4d5afffcd55acb6ab7a3f640d86dbf4bebc-83be7beacd1e08499af4a1415b6d378a4ca9d42324089899c5e351c066fd378c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sjt")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82327")[#strong[#text("sjt")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("Do “connected” and “simply connected” mean the same thing for Lie groups as they do for general topological spaces? (I ask because if so, saying both is redundant, violating some Gricean maxim or other.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82336")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("I think there may be competing definitions in the literature; in some texts, a Lie group is simply connected iff every closed loop is contractible, whereas in other texts, one also imposes connectedness. Thus, for instance, a discrete group could be considered a simply connected Lie group in some of the literature. So it is common to add “connected” to “simply connected” for emphasis. (Conversely, one could call a disconnected Lie group with all closed loops contractable a “Lie group with simply connected identity component”, again to avoid ambiguity.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2f96de3f3c7ec49e28dde5e9663d4d5afffcd55acb6ab7a3f640d86dbf4bebc-83be7beacd1e08499af4a1415b6d378a4ca9d42324089899c5e351c066fd378c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sjt")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-83473")[#strong[#text("sjt")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2011")])]

#text("I see. Thanks for explaining.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-82431")[#strong[#text("Twelfth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")]

#text("[…] Terence Tao: The inverse function theorem for everywhere differentiable maps, The Brunn-Minkowski inequality for nilpotent groups […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7fe06f6cb2c9b28104cb687080cf5ce2b16be8f0b63e5feb82951ef42234f5-7467020bc3ca449df4980a6efc193f27410bc9148e5e6867b2a9b5e3be2dec89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-84619")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2011")])]

#text("One of the seemingly unexplored encodings of 3x+1 sequences is via irregular convex polygons. One can take sequences convergent to the number 1 and let the number of odds in such sequences denote the vertices, while letting the running sum of evens denote the lengths of the edges. From there all of the obvious questions arise i.e., what subset of irregular polygons map to the 3x+1 sequences? Do all such sequences close under the encoding? Comparison of extremal values and statistics should be done. One may want to know under what conditions the minimal area enclosed of such a 5-gon is smaller than a 4-gon from such a set of irregular n-gons. Where is creativity when you need it most?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fren")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-86194")[#strong[#text("fren")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("Nilpotent Prékopa-Leindler inequality, wow :) Leindler was my professor in two functional analysis courses")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-106144")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2011")])]

#text("It seems that in the last step of the proof (in dimension one) of the Prekopa Leindler inequality")#linebreak()#text(" the Holder inequality CANNOT be used since it is in the reverse order.")#linebreak()#text(" It seems you prove something slightly weaker than the inequality wanted.")#linebreak()#text(" in fact ")#mi("\\int \\mu(f>\\lambda)^{1-\\theta}\\mu(g>\\lambda)^{\\theta}d\\lambda <(\\int f)^{1-\\theta}(\\int g)^{\\theta} d\\lambda")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-106388")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2011")])]

#text("Ah, I had accidentally swapped the last two steps of the argument. It should be fixed now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-225854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2013")])]

#text("If in equation (2) we take h=0, g=0 and f=1, then the arithmetic version of Prekopa-Leindler inequality at the end of the proof of Theorem 2, right above Theorem 3, seems not correct.")

#emph[#text("[Corrected, thanks – there was a missing step in the proof in which one normalised f and g to have sup norm 1. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0bc5af761570063b64bf00fda766916e4bf1f895835fbb1311fe3cecda702cd-ecd0677d5c914fe03317860801d92c5ceb8f6abb90a8f81927f73101c8e935e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-479027")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("In lemma 1 , the sum of two measurable subsets of R need not be measurable")

#emph[#text("[Fair enough; I’ve reworded the lemma. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a24b38007dc03aa218f3eb92b8e79681e6f810e378f3bfa2729b078f8609ac-505d6030ec57e5ef3a5aa385754c06d78ee8b223b1e093b26795af5b0a91bc31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajan anantharaman")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-509868")[#strong[#text("rajan anantharaman")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Thanks for this esp.connecting to other nontrivial.inequalities.may be the reference ,")#linebreak()#text(" Rolf Schneider,s Cambridge tract and later versions have some of this ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c71f8826fb030891f80f5e608e074f5603d72fae7d55390a5729c2c1c1862490-fa4efbfaf42e5dafae4651c20d07b6aed6af38c746e7f7c30d16be7da743a78a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yifan Jing")]], [#link("https://terrytao.wordpress.com/2011/09/16/the-brunn-minkowski-inequality-for-nilpotent-groups/#comment-621893")[#strong[#text("Yifan Jing")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("Regarding the question in Remark 3: Below is a recent preprint about Brunn-Minkowski inequality for general locally compact groups, which shows that the exponent in the inequality in general can be smaller than the topological dimension d:")

#link("https://arxiv.org/abs/2101.07782")[#text("https://arxiv.org/abs/2101.07782")]
]
