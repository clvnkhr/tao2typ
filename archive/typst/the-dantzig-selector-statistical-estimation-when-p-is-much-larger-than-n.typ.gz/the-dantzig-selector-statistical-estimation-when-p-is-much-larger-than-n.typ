// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/
// Converted to Typst by tao2typ: "2026-10-14T16:35:15.239627+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Dantzig selector: Statistical estimation when p is much larger than n", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Dantzig selector: Statistical estimation when p is much larger than n")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/")[#text("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Over two years ago, ")#link("http://www.acm.caltech.edu/~emmanuel/")[#text("Emmanuel Candés")]#text(" and I submitted the paper “")#link("http://arxiv.org/abs/math.ST/0506081")[#text("The Dantzig selector: Statistical estimation when ")#mi("p")#text(" is much")#linebreak()#text(" larger than ")#mi("n")]#text("” to the ")#link("http://www.imstat.org/aos/")[#text("Annals of Statistics")]#text(". This paper, which ")#link("http://projecteuclid.org/euclid.aos/1201012958")[#text("appeared last year")]#text(", proposed a new type of selector (which we called the ")#emph[#text("Dantzig selector")]#text(", due to its reliance on the linear programming methods to which ")#link("http://en.wikipedia.org/wiki/George_Dantzig")[#text("George Dantzig")]#text(", who had died as we were finishing our paper, had contributed so much to) for ")#link("http://en.wikipedia.org/wiki/Estimation_theory")[#text("statistical estimation")]#text(", in the case when the number ")#mi("p")#text(" of unknown parameters is much larger than the number ")#mi("n")#text(" of observations. More precisely, we considered the problem of obtaining a reasonable estimate ")#mi("\\beta^*")#text(" for an unknown vector ")#mi("\\beta \\in {\\Bbb R}^p")#text(" of parameters given a vector ")#mi("y = X \\beta + z \\in {\\Bbb R}^n")#text(" of measurements, where ")#mi("X")#text(" is a known ")#mi("n \\times p")#text(" predictor matrix and ")#mi("z")#text(" is a (Gaussian) noise error with some variance ")#mi("\\sigma^2")#text(". We assumed that the predictor matrix X obeyed the ")#emph[#text("restricted isometry property")]#text(" (RIP, also known as UUP), which roughly speaking asserts that ")#mi("X\\beta")#text(" has norm comparable to ")#mi("\\beta")#text(" whenever the vector ")#mi("\\beta")#text(" is sparse. This RIP property is known to hold for various ensembles of random matrices of interest; see my ")#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/")[#text("earlier blog post on this topic")]#text(".")

#text("Our selection algorithm, inspired by our previous work on compressed sensing, chooses the estimated parameters ")#mi("\\beta^*")#text(" to have minimal ")#mi("l^1")#text(" norm amongst all vectors which are consistent with the data in the sense that the residual vector ")#mi("r := y - X \\beta^*")#text(" obeys the condition")

#align(center)[#tao-math("\\left\\| X^* r \\right\\|_\\infty \\leq \\lambda", block: false)#text(", where ")#mi("\\lambda := C \\sqrt{\\log p} \\sigma")#text(" (1)")]

#text("(one can check that such a condition is obeyed with high probability in the case that ")#mi("\\beta^* = \\beta")#text(", thus the true vector of parameters is ")#emph[#text("feasible")]#text(" for this selection algorithm). This selector is similar, though not identical, to the more well-studied ")#emph[#text("lasso selector")]#text(" in the literature, which minimises the ")#mi("l^1")#text(" norm of ")#mi("\\beta^*")#text(" penalised by the ")#mi("l^2")#text(" norm of the residual.")

#text("A simple model case arises when n=p and X is the identity matrix, thus the observations are given by a simple additive noise model ")#mi("y_i = \\beta_i + z_i")#text(". In this case, the Dantzig selector ")#mi("\\beta^*")#text(" is given by the ")#text("hard")#text(" soft thresholding formula")

#align(center)[#tao-fit-display[#tao-math("\\beta^*_i = \\max(\\left|y_i\\right| - \\lambda, 0 )  \\text{sgn}(y_i).", block: true)]]

#text("The ")#emph[#text("mean square error")]#text(" ")#tao-math("{\\Bbb E}( \\left\\| \\beta - \\beta^* \\right\\|^2 )", block: false)#text(" for this selector can be computed to be roughly")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\lambda^2 + \\sum_{i=1}^n  \\min( \\left|y_i\\right|^2, \\lambda^2)", block: true)]]

#text("and one can show that this is basically best possible (except for constants and logarithmic factors) amongst all selectors in this model. More generally, the main result of our paper was that under the assumption that the predictor matrix obeys the RIP, the mean square error of the Dantzig selector is essentially equal to (2) and thus close to best possible.")

#text("After accepting our paper, the Annals of Statistics took the (somewhat uncommon) step of soliciting responses to the paper from various experts in the field, and then soliciting a rejoinder to these responses from Emmanuel and I. Recently, the Annals posted these responses and rejoinder on the ")#link("http://arxiv.org/")[#text("arXiv")]#text(":")

#metadata(none) <tao-0104baea592a777dd72d>

#enum(start: 1, 
[#link("http://arxiv.org/abs/0803.3124")[#text("Bickel")]#text(" compared these results with recent results on the lasso selector by ")#link("http://www.ams.org/mathscinet-getitem?mr=2351101")[#text("Bunea-Tsybakov-Wegcamp")]#text(" and ")#link("http://www.stats.ox.ac.uk/~meinshau/lasso_recovery.pdf")[#text("Meinshausen-Yu")]#text(", commented on the naturality of the constraint (1), raised the issue of ")#link("http://en.wikipedia.org/wiki/Multicollinearity")[#text("collinearity")]#text(" (which is precluded by the RIP hypothesis, but can of course occur in practice), and proposed the use of tools such as ")#link("http://en.wikipedia.org/wiki/Cross-validation")[#text("cross-validation")]#text(" to estimate the quantity ")#mi("\\lambda")#text(" appearing in the constraint (1).")],
[#link("http://arxiv.org/abs/0803.3126")[#text("Efron, Hastie, and Tibshirani")]#text(" performed numerics to compare the accuracy of the Dantzig selector and the lasso selector, the performance was broadly rather similar, but the Dantzig selector appeared to have some artefacts arising from the constraint (1).")],
[#link("http://arxiv.org/abs/0803.3127")[#text("Cai and Lv")]#text(" asked whether the ")#mi("\\sqrt{\\log p}")#text(" factor in (1) was too conservative in the case when p was extremely large compared to n, leading to an overly sparse model ")#mi("\\beta^*")#text("; similarly, they raised the question of whether the logarithmic losses in (2) were sharp. Concerns were also raised about the verifiability of the RIP condition in this case (which is also the case in which collinearity becomes likely). There were also some issues raised concerning speed and robustness of the implementation of the Dantzig selector.")],
[#link("http://arxiv.org/abs/0803.3130")[#text("Ritov")]#text(" raised a more philosophical point, as to whether the prediction error (which is essentially ")#tao-math("{\\Bbb E} \\left\\| X \\beta - X \\beta^* \\right\\|^2", block: false)#text(" in this model) is a better indicator of accuracy than the loss ")#tao-math("{\\Bbb E} \\left\\| \\beta - \\beta^* \\right\\|^2", block: false)#text(".")],
[#link("http://arxiv.org/abs/0803.3134")[#text("Meinshausen, Rocha, and Yu")]#text(" compared our results with similar (though not perfectly analogous) existing results for the lasso selector, as well as an comparative analysis in low-dimensional situations. Their numerical experiments also suggest that the ")#mi("\\lambda")#text(" parameter in (1) needs to be tuned by cross-validation, and that the Dantzig selector has particular difficulties with collinearity.")],
[#link("http://arxiv.org/abs/0803.3135")[#text("Friedlander and Saunders")]#text(" focused on the speed of implementation of the Dantzig selector, concluding that using general-purpose linear algebra solvers (e.g. the simplex method) was moderately computationally intensive in practice.")]
)

#text("Finally, ")#link("http://arxiv.org/abs/0803.3136")[#text("Candès and myself")]#text(" gave a rejoinder to these responses. Our main points were:")

#enum(start: 1, 
[#text("Regarding collinearity (which in particular implies breakdown of the RIP), an accurate estimation of the parameters ")#mi("\\beta")#text(" is essentially hopeless no matter what selector one uses, and it is indeed more profitable to instead focus on estimating ")#mi("X \\beta")#text(" instead, but our selector is focused on applications (such as imaging, ADC conversion, or genomics) in which ")#mi("\\beta")#text(" is the variable of interest rather than ")#mi("X \\beta")#text(". It is certainly of interest to relax the RIP hypothesis, however, and to see whether one can still obtain good estimates for ")#mi("X \\beta")#text(" in this case. (The ")#emph[#text("canonical selector")]#text(" always gives a near-optimal estimate for ")#mi("X \\beta")#text(", but is NP-hard (and thus infeasible in practice) to compute.)")],
[#text("We agree with the points made that the parameters in (1) need to be tuned further to optimise performance, and in particular that cross-validation is an eminently sensible idea for this purpose. Note that in many applications (e.g. imaging), the variance ")#mi("\\sigma^2")#text(" can be specified from the design of the application.")],
[#text("The mean-square error for the Dantzig selector does tend to underperform that for the the lasso selector slightly in many cases, but (as noted in our original paper) this can be compensated for by using a slightly more complicated ")#emph[#text("Gauss-Dantzig selector")]#text(" in which the Dantzig selector is used to locate the “active” parameters, to which one then applies a classical least-squares regression method.")],
[#text("Running time of off-the-shelf implementations of the Dantzig selector are indeed somewhat of a concern for large data sets (e.g. ")#mi("10^6")#text(" measurements). But the same could have been said of the lasso selector when it was first introduced, and we expect to see faster ways to implement the algorithm in the future.")]
)

#text("It was an interesting and challenging new experience for Emmanuel and myself to engage in a formal discussion over one of my papers in a journal venue; I suppose this sort of thing is more common in the applied sciences such as statistics, but seems to be rather rare in pure mathematics.")

#text("Incidentally, after this rejoinder was submitted, more recent work has appeared showing that the lasso selector enjoys similar performance guarantees to the Dantzig selector: see this paper of ")#link("http://arxiv.org/abs/0801.1095")[#text("Bickel, Ritov, and Tsybakov")]#text(". Also, a nice way to perform cross-validation for general compressed sensing problems via the Johnson-Lindenstrauss lemma was noted very recently ")#link("http://arxiv.org/abs/0803.1845")[#text("by Ward")]#text(".")

#text("[")#emph[#text("Update")]#text(", Mar 22: The journal issue (Vol. 35, No. 6, 2007) in which all these articles appear ")#link("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.aos/1201012955")[#text("can be found here")]#text(".]")

#text("[")#emph[#text("Update")]#text(", Mar 29: I have learned also of the recent paper of ")#link("http://www-rcf.usc.edu/~gareth/research/DASSO.pdf")[#text("James, Radchenko, and Lv")]#text(", which introduces a new “DASSO” algorithm for computing the Dantzig selector in time comparable to that of the best known Lasso algorithms, and provides further theoretical connections between the two selectors.]")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f72245ed53a8ce6f77b7e9fe24fbe0405d43e3192ef62dfa0ca93483fb6e6a6-7626bd2e5b7164cebf3dbb374605d565a0d2e35e059130952b5bac809387185a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jed Harris")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27528")[#strong[#text("Jed Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2008")])]

#text("I’d like to read the articles you reference at arXiv, but all the commentary and your own response are embargoed. I don’t know if there is anything you can do about that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27529")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2008")])]

#text("Oops… these articles should be available within about 24 hours (Sun 8pm EST, to be precise). I guess I posted too soon…")

#text("On the other hand, the articles are available from Project Euclid (if your institution has a subscription), at")

#link("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.aos/1201012955")[#text("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.aos/1201012955")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27573")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Many of the topics on the (wonder-full) weblog — like parameter estimation, compressive sampling, and even Ricci flow — share the common theme of order reduction (the reduction or approximation of complex systems as simpler systems). That is why this is one of my favorite blogs … order reduction is the essence of engineering.")

#text("It can happen, however, the underlying mathematical state-space seems either too restrictive (the linear framework of compressive sampling) or too general (the coordinate-free manifolds of Ricci flow).")

#text("In practice, the state-spaces that we engineers *really* like tend to be the the nonlinear yet computationally tractable state-spaces of algebraic geometry. For us, these state-spaces are “the porridge that is not too hot and not too cold.”")

#text("Speaking only for myself, it is quite challenging to develop an appreciation for what is known, and what is not yet known, in this mathematical area. That is why posts in this area are always *very* welcome.")

#text("And, thanks to all who contribute to this fine weblog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f03cbafc0a94311b96f62f2922ff30643c5c0101849e257d65496643568d09e6-0be204c1623132addbd89f2d27831171619ce3e892b19c2e5f73e68e4e94d0cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel Peyré")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27595")[#strong[#text("Gabriel Peyré")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Small typo : “Hard thresholding” should be replaced by “Soft thresholding”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90db5fbcd58dd58cb2e2bd3024c608f122b9d5c9d73d0de52817bc3ef65d7c04-75e3ddc070a1cf331c0e2d0a9064e48f690ba32d926aa0b0a8cefcda90b62e4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhou Fang")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27750")[#strong[#text("Zhou Fang")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2008")])]

#text("Are you aware of the work by Gareth James on his ‘DASSO’ algorithm? It’s a LARS modification, so substantially faster for full-solution path calculation. (e.g . for CV) Though it’s somewhat slower than lasso/lars (since the Dantzig path seems to have more break points), it looks pretty close to optimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-27757")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2008")])]

#text("Thanks for the reference, which I was unaware of! It now seems, in view of recent literature, that the Dantzig selector and LASSO selector are in fact extremely close cousins of each other in many respects.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/670d896f7bfee3b7ccfa82cafd359f2180df5012c05ab6f8963fd8a075ca6c89-db70323ccf2dceffea767defdbe05df2869b18e74ef330185a458d8fe1b51308.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Molnar")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-29586")[#strong[#text("David Molnar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2008")])]

#text("Gareth James also has a more recent paper with P. Radchenko on “A Generalized Dantzig Selector with Shrinkage Tuning” listed on his web page. He also includes code for the method in R, in case anyone wants to try it:")

#link("http://www-rcf.usc.edu/~gareth/research/gdscode")[#text("http://www-rcf.usc.edu/~gareth/research/gdscode")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-30760")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("“The journal issue (Vol. 35, No. 6, 1997)” you mean 2007, of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-30761")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("Dear anonymous: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15777e1011f8948a9e778200cdc16c26a102819c1868613e9d0fce89e720e965-9387986491f0265a0a57d6694c25420d886c5b5b7b39cd4270776a4baba0f24e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sounak")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-46236")[#strong[#text("sounak")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2010")])]

#text("Dear Prof. Tao,")

#text("Do you think a Bayesian Dantzig selector based on the “loss likelihood duality” principle will be an interesting study. I know directly constructing the likelihood from L-infinity loss may be not very reasonable, but how about some continuous approximations of the L-infinity norm.")

#text("warm regards")

#text("sounak")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5670d68049970aba877b84f6bfc94b07e70095ff79e65bc6d4e26cb698d14c54-c1bc641f4a6adef5926fb615c74f2b8950884cd04a40f5ea593cd99b7e43a415.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Connie Leung")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-227602")[#strong[#text("Connie Leung")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2013")])]

#text("Hi there, I am a student at the University of Southampton, UK. I chose to study subset selection and shrinkage methods techniques in order to see which of the 13 covariates are best to model property values. Of these methods, one of the methods I have chosen to look at is the Dantzig Selector but cannot find the codes for this method. Is there any chance that you could send me what the code would be? (I will acknowledge you in my report! :) ) Many thanks! Connie")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-227643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2013")])]

#text("My co-authors developed the l1-Magic package at ")#link("http://users.ece.gatech.edu/~justin/l1magic/")[#text("http://users.ece.gatech.edu/~justin/l1magic/")]#text(" to do these sorts of computations, though my understanding is that nowadays there are significantly faster methods available than this one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5670d68049970aba877b84f6bfc94b07e70095ff79e65bc6d4e26cb698d14c54-c1bc641f4a6adef5926fb615c74f2b8950884cd04a40f5ea593cd99b7e43a415.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Connie Leung")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-227668")[#strong[#text("Connie Leung")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2013")])]

#text("Many thanks! I understand there are probably faster methods but my study is on this method so this would be useful – thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b7d3dfd36720fae49c538f476998530415bb398ead115b4b23e058ec7276828-01cfbd597bab9e45e5280ea4e3d11a3b9ef8ea6937cb717d43a7bf76510b651d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-480080")[#strong[#text("Rajesh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2017")])]

#text("Prof Terence Tao : Could you please comment on this fundamental problem : ")#link("https://math.stackexchange.com/q/2249528/2987")[#text("https://math.stackexchange.com/q/2249528/2987")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/988c1a59b7eaffb6fd834aa8fdcd5fcbc47aa45611ce376d53c93d3769819ddb-b08b4fc749b6d545056d94f2488dafd925061a9f28bd73c62d08c512112c6c2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Davis")]], [#link("https://terrytao.wordpress.com/2008/03/22/the-dantzig-selector-statistical-estimation-when-p-is-much-larger-than-n/#comment-501710")[#strong[#text("Alexander Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2018")])]

#text("I don’t think you should jump from “X is colinear” to “estimation of β is essentially hopeless”. It depends on the loss function.")

#text("Consider the changepoint problem. A piecewise constant vector Y is equal to Lβ, where L is a lower triangular matrix of 1’s and β is sparse. In the presence of noise you can’t find an estimate β* which will perfectly recover β. But you consider it a job well-done if the non-zero entries of β* are near the non-zero entries of β.")

#text("This suggests a loss function something like")

#tao-fit-display[#tao-math("\\sum_{i=1}^p (\\beta^*_i – a_i)^2 + \\left\\|\\beta\\right\\|_0", block: true)]

#text("where")

#tao-fit-display[#mitex("a_i = \\frac{1}{11}\\sum_{k=i-5}^{i+5} \\beta_i")]

#text("This problem has a sequential structure, and there are similar problems with more complex structures. For example, here’s a similar problem with a tree structure. You are given a phylogenetic tree of $n$ species, and for each species $i$, you are given $y_i$, the copy number of a certain gene in the genome of that species. Where, on the phylogenetic tree, did this gene undergo duplications and deletions?")

#text("My own statistical work involves a sort of hybrid between these two problems, where we have a sequence of identical trees, and each node is linked to the corresponding node in the next tree.")

#text("So, here’s a general problem that might appeal to you as a mathematician. It includes the case of estimating β, the case of estimating Xβ, and all the cases above.")

#text("Given a system Xβ+ε = y, with unknown sparse β, find an estimate β* to minimize the loss function ||Aβ – Αβ||*.")

#text("(And if you know anyone that has studied this, please link me to the papers.)")
]
