// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/
// Converted to Typst by tao2typ: "2026-10-14T16:36:52.459991+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath4 discussion thread", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath4 discussion thread")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 July 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/")[#text("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just opened the ")#link("http://polymathprojects.org/2012/07/12/minipolymath4-project-imo-2012-q3/")[#text("research thread")]#text(" for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2012")[#text("mini-polymath4 project")]#text(" over at the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(" to collaboratively solve one of the six questions from this year’s IMO. This year I have selected Q3, which is a somewhat intricate game-theoretic question. (The full list of questions this year may be found ")#link("http://www.imo-official.org/year_info.aspx?year=2012")[#text("here")]#text(".)")

#text("This post will serve as the discussion thread of the project, intended to focus all the non-research aspects of the project such as organisational matters or commentary on the progress of the project. The third component of the project is the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2012")[#text("wiki page")]#text(", which is intended to summarise the progress made so far on the problem.")

#text("As with the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("previous")]#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010")[#text("mini-polymath")]#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2011")[#text("projects")]#text(", I myself will be serving primarily as a moderator, and hope other participants will take the lead in the research and in keeping the wiki up-to-date.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minipolymath4 project: IMO 2012 Q3 « The polymath blog")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-151699")[#strong[#text("Minipolymath4 project: IMO 2012 Q3 « The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2012")])]

#text("[…] especially if) they are only partially conclusive. Participants are also encouraged to visit the discussion thread for this project, and also to visit and work on the wiki page to organise the progress made so […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-151877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Well, it looks like this mini-polymath was a bit harder than the previous two, which were solved within a few hours; this time around, after about 18 hours, we have a solution to the first part of the problem (finding a winning strategy for B for large enough n) but not the second part (showing B does not have a winning strategy for slightly smaller n). (Note though that mini-polymath1 took about two days to solve.)")

#text("Traditionally, when the number of comments on a thread reaches 100, we roll it over to a new thread; I may do this soon for this thread (currently at 71 comments), in part to refocus on the second part of the question, rather than the first which is now fairly well understood.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d60578eedbc6add83408c7db934d7314aa96aab44b4b7193a33a16d5abf93cfd-09400d0974998369ce283efc8b4fe5522493a7c24880b888696d7e384808421c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of erkjerjkerjkje")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-151935")[#strong[#text("erkjerjkerjkje")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("Terry,")

#text("Have you solved part 2 yet? I recall that you said that you took around 8 hours (off and on) to solve minipolymath1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-151940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("I think I have an idea on how to solve it, but I have deliberately refrained from working too actively on the problem, instead acting primarily as a moderator.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minipolymath4 project, second research thread « The polymath blog")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-151939")[#strong[#text("Minipolymath4 project, second research thread « The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2012")])]

#text("[…] are encouraged to edit the wiki as appropriate with new developments and ideas, and participate in the discussion thread for any meta-discussion about the polymath project. Like this:LikeBe the first to like this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df7fa6a76a5c91fac28dee298c4e5719db787724fb58d8a8471b063a3ec32b90-9a1ce6f403fa5b5de72039cd76de8507a617724e83fe2b4abd1cc9676b94e27f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cosmonut")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-156910")[#strong[#text("Cosmonut")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2012")])]

#text("Looks like Part 2 never got solved. Or am I missing the link ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-157004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2012")])]

#text("There were some solutions posted in the research thread, for instance David Speyer’s solution at ")#link("http://polymathprojects.org/2012/07/13/minipolymath4-project-second-research-thread/#comment-7776")[#text("http://polymathprojects.org/2012/07/13/minipolymath4-project-second-research-thread/#comment-7776")]#text(" or Akash Chayan’s solution at ")#link("http://polymathprojects.org/2012/07/12/minipolymath4-project-imo-2012-q3/#comment-7690")[#text("http://polymathprojects.org/2012/07/12/minipolymath4-project-imo-2012-q3/#comment-7690")]#text(" . (I put David’s solution, which is a little shorter, on the wiki just now.) In both cases the basic idea is for A to always answer questions in order to minimise a certain exponentially weighted sum.")

#text("It seems that the second part was considerably trickier than the first, and also less amenable to a polymath style collaborative effort – either one saw the trick (act to minimise a weighted sum) or one didn’t.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70fb9be21405de6809445718f042bf388c2face3e87ccfe81411b93a195de8bb-1f639770573c1a15ad7a93098cc8521238ba3ae3acae020beb76401bc5c49a36.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of simple")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-239767")[#strong[#text("simple")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2013")])]

#text("IMO 2013 will end immediately. Which problem will you choose?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/12/mini-polymath4-discussion-thread/#comment-239835")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("I am not running a mini-polymath this year, in part due to the two currently active polymath projects, and in part due to lack of expressions of interest in continuing the experiment. (But there’s no particular reason why someone else couldn’t run a similar project, and I would be happy to help others to set up this sort of thing if they would like to.)")
]
]
