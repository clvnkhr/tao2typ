// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:21:12.729775+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Gilbreath’s conjecture: a Cramér random model and a deterministic analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Gilbreath’s conjecture: a Cramér random model and a deterministic analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/")[#text("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.kent.edu/~zchase/")[#text("Zachary Chase")]#text(", ")#link("https://zachhunter.xyz/")[#text("Zach Hunter")]#text(" and I have uploaded to the arXiv our preprint ")#link("https://arxiv.org/abs/2607.08712")[#text("Gilbreath’s conjecture: a Cramér random model and a deterministic analysis")]#text(". This paper is motivated by a ")#link("https://en.wikipedia.org/wiki/Gilbreath%27s_conjecture")[#text("notorious conjecture of Gilbreath")]#text(" (also proposed eighty years prior by Proth), which one can state as follows: if one starts with the sequence of primes and repeatedly takes absolute differences of consecutive terms, then the first term of each subsequent row is always ")#mi("{1}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{ccccccccccc} 2 & & 3 & & 5 & & 7 & & 11 & & 13 \\\\ & 1 & & 2 & & 2 & & 4 & & 2 & \\\\ & & 1 & & 0 & & 2 & & 2 & \\\\ & & & 1 & & 2 & & 0 & & \\\\ & & & & 1 & & 2 & & & \\\\ & & & & & 1 & & & & \\end{array}.")]]

#text("Coming from a PDE background, I like to think of this conjecture as a (discrete) nonlinear “wave equation” problem, where the primes are the “initial data”, the downward direction in the above pyramid is the arrow of “time”, and the “equation of motion” is that the value of the “scalar field” at any given point in “spacetime” is the absolute difference of the values of the two points directly above it. We will informally refer to solutions to such an “equation” as “Gilbreath arrays”.")

#text("Numerically, the conjecture has been verified for the first ")#mi("{3.34 \\times 10^{11}}")#text(" rows ")#link("https://www.jstor.org/stable/2152962")[#text("by Odlyzko")]#text(". Asymptotically, the conjecture can be heuristically justified as follows. Firstly, because all primes other than ")#mi("{2}")#text(" are odd, it is easy to see that the first term of each row is odd, while all other terms are even. Next, if one starts with the first ")#mi("{n}")#text(" primes for some large ")#mi("{n}")#text(" and takes initial differences, then the prime number theorem tells us that the average size of the next row is about ")#mi("{\\log n}")#text(", and ")#link("https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér’s conjecture")]#text(" predicts that the maximum size should be ")#mi("{O(\\log^2 n)}")#text(". With each new row, the maximum size can only decrease (since ")#tao-math("{\\left|a-b\\right| \\leq \\max(a, b)}", block: false)#text(" for any natural numbers ")#mi("{a,b}")#text("), and so one would expect it likely on each row that the maximum size should drop by at least ")#mi("{1}")#text(" (unless it has already reached ")#mi("{2}")#text("). Since there are ")#mi("{n-1}")#text(" rows to go before one reaches the end, it seems extremely likely that the maximum size should drop down to at most ")#mi("{2}")#text(" by then, at which point the result is forced from parity reasons.")

#text("However, it seems well beyond current technology to try to make these heuristics rigorous; even the first step of proving Cramér’s conjecture is far out of reach. In our paper, we consider two more feasible directions:")

#list(
[#text("What is a realistic probabilistic model of the primes, and can one confirm the (asymptotic version of the) conjecture almost surely for such a model?")],
[#text("Can one use deterministic arguments to reduce the (asymptotic) Gilbreath conjecture to more tractable looking (and heuristically plausible) statements about iterated differences of primes?")]
)

#text("Let us first discuss the question of analyzing probabilistic models. One can strip away the first row and initialize using prime gaps ")#mi("{p_{n+1}-p_n}")#text(" rather than primes; it is convenient to also strip away the aforementioned parity structure, by eliminating the initial gap ")#mi("{3-2=1}")#text(", and dividing all remaining gaps by ")#mi("{2}")#text(", so that one now works with an initial sequence ")#mi("{\\frac{p_{n+1}-p_n}{2}, n \\geq 2}")#text(" with no parity bias. The conjecture is now equivalent to the first row always being ")#mi("{\\{0,1\\}}")#text("-valued:")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{ccccccccccccccccc} 0 & & 0 & & 1 & & 0 & & 1 & & 0 && 1 && 2 && 0\\\\ & 0 & & 1 & & 1 & & 1 & & 1 && 1 && 1 && 2\\\\ & & 1 & & 0 & & 0 & & 0 && 0 && 0 && 1\\\\ & & & 1 & & 0 & & 0 & & 0 && 0 && 1\\\\ & & & & 1 & & 0 & & 0 && 0 && 1\\\\ & & & & & 1 & & 0 & & 0 && 1\\\\ & & & & & & 1 & & 0 && 1\\\\ & & & & & & & 1 && 1 \\\\ & & & & & & & & 0 \\end{array}.")]]

#text("The Cramér model suggests that the first ")#mi("{n}")#text(" normalized prime gaps should behave like geometric random variables of mean about ")#mi("{\\frac{\\log n}{2}}")#text(". My co-author, ")#link("https://link.springer.com/article/10.1007/s00208-023-02579-w")[#text("Zachary Chase")]#text(", established an analogue of the Gilbreath conjecture for a more slowly growing model. Here is a special case of his main theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Suppose the initial row entries ")#mi("{a_n}")#text(" of a Gilbreath array are drawn independently from a uniform distribution on ")#mi("{\\{0,\\dots,f(n)-1\\}}")#text(" for some ")#mi("{2 \\leq f(n) \\leq \\frac{1}{10} \\frac{\\log\\log n}{\\log \\log \\log n}}")#text(". Then almost surely, all but finitely many of the rows have a ")#mi("{\\{0,1\\}}")#text("-valued first entry.")
]

#text("The Cramér model morally corresponds to a value of ")#mi("{f(n)}")#text(" comparable to ")#mi("{\\log n}")#text(", which is too large for the above theorem to apply. However, we were able to improve the argument, basically allowing ")#mi("{f(n)}")#text(" to be anything of size ")#mi("{o(n)}")#text(". Furthermore, it was not necessary that the distribution be uniform: the important hypothesis was that the distribution not be concentrated in any ")#mi("{2}")#text("-separated set, such as the even numbers, the odd numbers, or the multiples of ")#mi("{3}")#text(". (See the paper for the precise formulation of “non-concentrated”.) Such a hypothesis is needed since if for instance all initial entries were divisible by ")#mi("{3}")#text(", then this property would propagate down the array, and it would become extremely unlikely that the initial values would remain ")#mi("{\\{0,1\\}}")#text("-valued. Our hypotheses are obeyed by the Cramér random model, and so we obtain a heuristic confirmation of the original Gilbreath conjecture for the primes.")

#text("One can informally explain our proof of the above result as follows. We consider the portion of the array generated by the first ")#mi("{n}")#text(" values ")#mi("{a_1,\\dots,a_n}")#text(" for some large ")#mi("{n}")#text(". Suppose that at some point ")#mi("{P}")#text(" deep in this portion of the array, a value ")#mi("{d}")#text(" that is larger than ")#mi("{1}")#text(" is attained. Then the two values ")#mi("{a,b}")#text(" above ")#mi("{P}")#text(" must satisfy the equation ")#tao-math("{\\left|a-b\\right|=d}", block: false)#text(". So, either one of these values is at least ")#mi("{d+1}")#text(", or one of them is ")#mi("{d}")#text(" and the other is ")#mi("{0}")#text(". If one iterates this observation, one sees that ")#mi("{P}")#text(" is the base of an upside-down triangle of ")#mi("{\\{0,d\\}}")#text(" values, topped off by at least one location ")#mi("{P^{\\prime}}")#text(" where the value is at least ")#mi("{d+1}")#text(". If one iterates that observation in turn, we see that ")#mi("{P}")#text(" forms the base of a “tower” of upside-down triangles stacked atop each other, with the number of such triangles bounded by the maximum size of the initial data (in the “backwards light cone” of ")#mi("{P}")#text("). In the ")#mi("{f(n)=o(n)}")#text(" regime, it turns out that the number (or “entropy”) of such towers is subexponential in ")#mi("{n}")#text(". So if we can show that each tower only can be created with an exponentially small probability, we can conclude by the standard techniques of the union bound and the Borel–Cantelli lemma.")

#text("At this point we use the following elementary observation. Suppose that some finite Gilbreath array coming from say initial data ")#mi("{a_1,\\dots,a_n}")#text(" has been generated, and consider the effect of adding a new value ")#mi("{a_{n+1}}")#text(" to the initial data, which then triggers ")#mi("{n}")#text(" iterations of the absolute value difference operation ")#tao-math("{a \\mapsto \\left|a-c\\right|}", block: false)#text(" for various values of ")#mi("{c}")#text(" until one reaches the new bottom vertex of the array. This difference operation ")#tao-math("{a \\mapsto \\left|a-c\\right|}", block: false)#text(" has the property that the preimage of any ")#mi("{2}")#text("-separated set is still ")#mi("{2}")#text("-separated. Iterating this, we see that the set of values that make ")#mi("{a_{n+1}}")#text(" iterate to a ")#mi("{\\{0,d\\}}")#text("-valued bottom vertex is also ")#mi("{2}")#text("-separated. So as long as the distribution of ")#mi("{a_{n+1}}")#text(" avoids ")#mi("{2}")#text("-separated sets, one can iterate this observation in ")#mi("{n}")#text(" to show that it is exponentially rare that large triangles of ")#mi("{\\{0,d\\}}")#text("-valued vertices can be created.")

#text("We also consider an asymptotic continuous random model, in which the initial data ")#mi("{a_n}")#text(" are not natural numbers, but instead independently random non-negative real numbers with an exponential distribution, which we can normalize to have mean ")#mi("{1}")#text("; this heuristically is an approximate model for the Gilbreath array generated by the first ")#mi("{n}")#text(" normalized prime gaps, after dividing by the mean ")#mi("{\\log n/2}")#text(". In this normalized model, each entry of the ")#mi("{k^{th}}")#text(" row ends up having the same mean ")#mi("{c_k}")#text(". The first few values of ")#mi("{c_k}")#text(" can be computed explicitly")

#align(center)[#tao-fit-display[#mitex("c_0 = 1; c_1 = 1; c_2 = \\frac{7}{9}; c_3 = \\frac{227}{288}.")]]

#text("However, the asymptotic behavior of ")#mi("{c_n}")#text(" remains unclear to us. We were able to show an inequality ")#mi("{c_0 + \\dots + c_n \\geq \\log(n+e)}")#text(" for any ")#mi("{n}")#text(", indicating that ")#mi("{c_k}")#text(" cannot decay faster than ")#mi("{1/k}")#text(", but we do not know whether this is the true decay rate. In any case a decay rate of ")#mi("{1/k}")#text(" (which is very weakly supported by numerical evidence) is consistent with the Gilbreath conjecture, as it would indicate that the Gilbreath array from the first ")#mi("{n}")#text(" prime gaps should end up being almost entirely ")#mi("{\\{0,1\\}}")#text("-valued by merely ")#mi("{O(\\log n)}")#text(" steps, well before the ")#mi("{n}")#text(" steps needed to reach the bottom of the array.")

#text("Now we turn to deterministic analysis of Gilbreath arrays. Suppose we found some initial data ")#mi("{a_1,\\dots,a_N}")#text(" that did not grow too quickly (e.g., one had a Cramér-type bound ")#mi("{a_N = O(\\log^2 N)}")#text("), but still iterated to a final value that was not ")#mi("{\\{0,1\\}}")#text(". What features of the initial data could generate such a failure of a Gilbreath-type conjecture? One way in which the conjecture could fail is if the Gilbreath iteration somehow produced a reasonably long consecutive string of zeroes (say, longer than ")#mi("{\\log^{10} N}")#text("), as then the next few iterations would not act to decrease the magnitude of the non-zero entries bordering this string of zeroes. Such a scenario would be heuristically rate, as the parity of each element of the array can be worked out explicitly using the parity identity ")#tao-math("{\\left|a-b\\right| = a + b \\text{ mod } 2}", block: false)#text(", and so constant-parity sequences of length say ")#mi("{\\log^{10} N}")#text(" should be almost surely non-existent asymptotically by standard probabilistic heuristics.")

#text("Another bad scenario is if the Gilbreath iteration, after some medium number ")#mi("{i}")#text(" of iterations, produced an extremely long consecutive block (say of length ")#mi("{\\exp(\\log^{1/10} N) i}")#text(") which was entirely ")#mi("{\\{0,d\\}}")#text("-valued for some ")#mi("{d \\geq 2}")#text(". This block would then persist as a ")#mi("{\\{0,d\\}}")#text("-block for a large number of iterations (equal to the length of the block), thus potentially delaying for a significant time the drop-down of the maximal value to below ")#mi("{d}")#text(". For odd ")#mi("{d}")#text(", one can use the parity analysis alluded to earlier to argue that the formation of such a block is extremely unlikely; but for even ")#mi("{d}")#text(", we can only use such heuristics if we make strong assumptions of joint independence, as we did in the probabilistic analysis in our paper.")

#text("In any event, we were able to use purely elementary methods to establish an “inverse theorem” that states, roughly speaking, that the above two scenarios are the ")#emph[#text("only")]#text(" ways in which a Gilbreath array can fail to have a ")#mi("{\\{0,1\\}}")#text("-valued first entry. This basically arises from a more careful analysis of the towers of triangles alluded to earlier. (A previous argument involved considering ways to pack a large triangle by smaller triangles, leading to a ")#link("https://mathoverflow.net/questions/468056/packing-an-upwards-equilateral-triangle-efficiently-by-downwards-equilateral-tri")[#text("MathOverflow question")]#text(" which was nicely answered by Fedja Nazarov and Anders Martinsson, but we later managed to optimize the argument to the point where the answer to this packing question was no longer needed.) So this in principle reduces the (deterministic) Gilbreath conjecture to several more tractable-looking (though complicated to state) assertions, though proving those latter statements seems well out of reach at the moment.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Please forgive me for asking a silly question: Why can we model number theory using probability theory? Take the prime number theorem as an example. If expressed in the language of probability, it would be stated as: if we randomly pick a large number n, the probability that n is prime is approximately 1/log n. But a number can only be either prime or not, so why isn’t the probability 1/2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("The more precise claim is that while number-theoretic objects such as the set of primes are deterministic rather than random, they (at least conjecturally) exhibit strong signs of being ")#link("https://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandom")]#text(" in various senses. See ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")]#text(" for more discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("I extended the explicit computation of the constants c_i in Section 1.3 by three further values (c_4, c_5, c_6), using a sign-cone decomposition of your simplex representation with exact rational arithmetic throughout: ")#link("https://github.com/michaelmross/Gilbreath")[#text("https://github.com/michaelmross/Gilbreath")]#text(" (data/exact_values.json)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693365")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Thanks! We will note these extended values in the next revision of the manuscript. A quick check against our Monte Carlo calculation reveals an excellent fit.")

#text("A quick check of the OEIS indicates that neither the numerators nor denominators of this sequence are currently in that database. You might consider submitting both of these (I assume they are in lowest terms) there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0f7c7ad06e697fbe5ee8824464a13ca9e0351b393ef4b2a9ebe6a8c8900dba5-d55c28a7783f11fd299245299491e38d844c474a48cc2b9d89acc6089567d5e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693709")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("Just published today: A397880 and A395556")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0f7c7ad06e697fbe5ee8824464a13ca9e0351b393ef4b2a9ebe6a8c8900dba5-d55c28a7783f11fd299245299491e38d844c474a48cc2b9d89acc6089567d5e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693366")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Yes, lowest terms: gcd(numerator, denominator) = 1. ")#linebreak()#text("OEIS submission underway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Visualizing the Gilbreath expectation sequence | What's new")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693407")[#strong[#text("Visualizing the Gilbreath expectation sequence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("[…] can illustrate this with Figure 1 from my recent paper on the Gilbreath conjecture with Chase and Hunter, reproduced […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1147b8a2e9fefe16b45980723247e4ac51dc9a8c211b447ccd433b2f0ff45533-990149e2e36c44e854c979cce9f5764d80fee535aec0e9dd072342adc9b3fa60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Audigé")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693627")[#strong[#text("Emmanuel Audigé")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2026")])]

#text("Subject: An exact cutoff-parity law and quantitative bound for the Cramér–Gilbreath model")

#text("Dear Professor Tao,")

#text("After reading and working carefully through your paper with Zachary Chase and Zach Hunter, I found that the two-separated concentration parameter appearing in Proposition 4.1 can be evaluated exactly for the geometric model.")

#text("More importantly, the tail replacement used in the proof has an exact parity oscillation. Substituting this exact coefficient into Proposition 4.1 yields an explicit finite-")#mi("n")#text(" failure bound and a computable threshold.")

#strong[#text("Exact two-separated concentration in the geometric model")]

#text("Let ")#mi("X")#text(" have the geometric distribution")

#mi("\\displaystyle \\mathbb P(X=k)=pq^k, \\qquad q=1-p, \\qquad 0 < p < 1, \\qquad k\\geq0,")

#text("and define")

#tao-math("\\displaystyle \\Lambda_2(X) := \\sup_{\\substack{A\\subseteq\\mathbb Z_{\\geq0}\\\\ \\left|a-a^{\\prime}\\right|\\geq2\\ \\text{for }a\\neq a^{\\prime}}} \\mathbb P(X\\in A).", block: false)

#strong[#text("1. Exact extremizer")]

#text("One has")

#mi("\\displaystyle \\boxed{\\Lambda_2(X) = \\sum_{m\\geq0}pq^{2m} = \\frac{1}{1+q} = \\frac{1}{2-p}.}")

#text("The unique maximizing set is")

#mi("\\displaystyle \\boxed{A=2\\mathbb Z_{\\geq0}.}")

#text("Indeed, every 2-separated set contains at most one element of each pair")

#mi("\\displaystyle \\{2m,2m+1\\},")

#text("and")

#mi("\\displaystyle pq^{2m}>pq^{2m+1}.")

#text("Hence")

#mi("\\displaystyle \\mathbb P(X\\in A) \\leq \\sum_{m\\geq0}pq^{2m} = \\frac{1}{2-p},")

#text("with equality precisely for ")#mi("A=2\\mathbb Z_{\\geq0}")#text(".")

#strong[#text("2. Exact stability identity")]

#text("For every 2-separated set ")#mi("A\\subseteq\\mathbb Z_{\\geq0}")#text(",")

#mi("\\displaystyle \\boxed{\\frac{1}{2-p}-\\mathbb P(X\\in A) = \\sum_{m\\geq0} pq^{2m}\\left(\\mathbf 1_{A\\cap\\{2m,2m+1\\}=\\varnothing} + p\\,\\mathbf 1_{2m+1\\in A}\\right).}")

#text("Indeed, the contribution of the pair ")#mi("\\{2m,2m+1\\}")#text(" to the deficit from the extremizer is")

#mi("\\displaystyle \\begin{cases} 0, & 2m\\in A,\\\\[1mm] pq^{2m}-pq^{2m+1}=p^2q^{2m}, & 2m+1\\in A,\\\\[1mm] pq^{2m}, & A\\cap\\{2m,2m+1\\}=\\varnothing. \\end{cases}")

#text("Thus every departure from the even extremizer has an exact probabilistic cost.")

#strong[#text("3. Exact cutoff-parity law")]

#text("Let ")#mi("D\\geq1")#text(", and define the modified variable")

#mi("\\displaystyle X_D = \\begin{cases} X, & X\\leq D,\\\\ \\varepsilon, & X>D, \\end{cases}")

#text("where ")#mi("\\varepsilon")#text(" is independent of ")#mi("X")#text(" and")

#mi("\\displaystyle \\mathbb P(\\varepsilon=0) = \\mathbb P(\\varepsilon=1) = \\frac12.")

#text("Then")

#mi("\\displaystyle \\boxed{\\Lambda_2(X_D) = \\frac{1}{2-p}\\left(1+\\frac{(-1)^D}{2}pq^{D+1}\\right).}")

#text("The maximizing pattern on the support of ")#mi("X_D")#text(" is uniquely the even pattern.")

#text("Indeed,")

#mi("\\displaystyle \\Lambda_2(X_D) = \\sum_{\\substack{0\\leq k\\leq D\\\\ k\\ \\mathrm{even}}} pq^k + \\frac{q^{D+1}}2.")

#text("Consequently,")

#mi("\\displaystyle \\boxed{\\Lambda_2(X_D)-\\Lambda_2(X) = \\frac{(-1)^D}{2(2-p)}pq^{D+1}.}")

#text("Thus the truncation used in the proof exhibits the exact parity oscillation")

#mi("\\displaystyle \\begin{aligned} D\\ \\mathrm{even} &\\Longrightarrow \\Lambda_2(X_D) > \\Lambda_2(X),\\\\ D\\ \\mathrm{odd} &\\Longrightarrow \\Lambda_2(X_D) < \\Lambda_2(X). \\end{aligned}")

#strong[#text("4. Exact coefficient in the Cramér model")]

#text("For the geometric variables in the paper, let")

#mi("\\displaystyle p_j=\\frac{2}{2+\\log j}, \\qquad q_j=\\frac{\\log j}{2+\\log j}.")

#text("Then, for ")#mi("j\\geq2")#text(",")

#mi("\\displaystyle \\boxed{\\rho_j = \\Lambda_2(X_j) = \\frac{\\log j+2}{2(\\log j+1)} = \\frac12+\\frac{1}{2(\\log j+1)}.}")

#text("Also ")#mi("\\rho_1=1")#text(". Hence")

#mi("\\displaystyle \\boxed{\\prod_{j=1}^{n}\\rho_j = 2^{-(n-1)} \\exp\\left(\\frac{n}{\\log n} - \\frac{n}{2\\log^2 n} + O\\left(\\frac{n}{\\log^3 n}\\right)\\right).}")

#text("Indeed,")

#mi("\\displaystyle 2\\rho_j = 1+\\frac{1}{1+\\log j},")

#text("and therefore")

#mi("\\displaystyle \\log(2\\rho_j) = \\log\\left(1+\\frac{1}{1+\\log j}\\right) = \\frac{1}{\\log j} - \\frac{3}{2\\log^2 j} + O\\left(\\frac{1}{\\log^3j}\\right).")

#text("Using")

#mi("\\displaystyle \\sum_{j\\leq n}\\frac{1}{\\log j} = \\frac{n}{\\log n} + \\frac{n}{\\log^2n} + O\\left(\\frac{n}{\\log^3n}\\right)")

#text("and")

#mi("\\displaystyle \\sum_{j\\leq n}\\frac{1}{\\log^2j} = \\frac{n}{\\log^2n} + O\\left(\\frac{n}{\\log^3n}\\right),")

#text("one obtains the displayed product asymptotic.")

#text("In particular,")

#mi("\\displaystyle \\boxed{\\left(\\prod_{j=1}^{n}\\rho_j\\right)^{1/2} = 2^{-(n-1)/2} \\exp\\left(\\frac{n}{2\\log n} - \\frac{n}{4\\log^2n} + O\\left(\\frac{n}{\\log^3n}\\right)\\right).}")

#strong[#text("5. Explicit finite-")#mi("n")#text(" Cramér–Gilbreath bound")]

#text("Let ")#mi("a_1,\\ldots,a_n")#text(" be the independent geometric variables of the Cramér model, and let")

#mi("\\displaystyle F_n := \\left\\{a^{(n-1,1)}>1\\right\\}.")

#text("For ")#mi("D\\geq1")#text(", replace each ")#mi("a_j>D")#text(" independently by a fair value in ")#mi("\\{0,1\\}")#text(", and leave ")#mi("a_j")#text(" unchanged when ")#mi("a_j\\leq D")#text(". Denote the resulting variable by ")#mi("a_{j,D}")#text(".")

#text("Its exact two-separated concentration coefficient is")

#mi("\\displaystyle \\boxed{\\rho_{j,D} = \\frac{1}{2-p_j}\\left(1+\\frac{(-1)^D}{2}p_jq_j^{D+1}\\right).}")

#text("The original and modified Gilbreath arrays coincide whenever")

#mi("\\displaystyle \\max_{1\\leq j\\leq n}a_j\\leq D.")

#text("Therefore")

#mi("\\displaystyle \\mathbb P(F_n) \\leq \\mathbb P\\left(\\max_{j\\leq n}a_j>D\\right) + \\mathbb P\\left(a_D^{(n-1,1)}>1\\right).")

#text("Since")

#mi("\\displaystyle \\mathbb P(a_j>D)=q_j^{D+1}")

#text("and ")#mi("q_j\\leq q_n")#text(" for ")#mi("j\\leq n")#text(",")

#mi("\\displaystyle \\mathbb P\\left(\\max_{j\\leq n}a_j>D\\right) \\leq \\sum_{j=1}^{n}q_j^{D+1} \\leq nq_n^{D+1}.")

#text("Applying Proposition 4.1 to the modified variables gives")

#mi("\\displaystyle \\boxed{\\begin{aligned} \\mathbb P(F_n) \\leq {}& \\sum_{j=1}^{n}q_j^{D+1}\\\\ &+ 2^D\\left(\\frac{en}{D}+e\\right)^{2D} \\left(\\prod_{j=1}^{n}\\rho_{j,D}\\right)^{1/2}. \\end{aligned}}")

#text("In particular,")

#mi("\\displaystyle \\boxed{\\mathbb P(F_n) \\leq nq_n^{D+1} + 2^D\\left(\\frac{en}{D}+e\\right)^{2D} \\left[\\prod_{j=1}^{n} \\frac{1}{2-p_j}\\left(1+\\frac{(-1)^D}{2}p_jq_j^{D+1}\\right)\\right]^{1/2}.}")

#text("Now take")

#mi("\\displaystyle D=\\lfloor\\delta n\\rfloor, \\qquad 0 < \\delta < 1.")

#text("Since")

#mi("\\displaystyle q_n = 1-\\frac{2}{2+\\log n},")

#text("one has")

#mi("\\displaystyle nq_n^{D+1} \\leq n\\exp\\left(-\\frac{2(D+1)}{2+\\log n}\\right) = n\\exp\\left(-(2\\delta+o(1))\\frac{n}{\\log n}\\right).")

#text("Furthermore,")

#mi("\\displaystyle \\sum_{j=1}^{n} p_jq_j^{D+1} = o(1),")

#text("so the cutoff-parity correction contributes only ")#mi("o(1)")#text(" to the logarithm of the product. Hence")

#mi("\\displaystyle \\frac12\\sum_{j=1}^{n}\\log\\rho_{j,D} = -\\frac{n}{2}\\log2 + \\frac{n}{2\\log n} + O\\left(\\frac{n}{\\log^2n}\\right).")

#text("Also,")

#mi("\\displaystyle \\frac{1}{n}\\log\\left[2^D\\left(\\frac{en}{D}+e\\right)^{2D}\\right] = \\delta\\log2 + 2\\delta\\log\\left(\\frac{e(1+\\delta)}{\\delta}\\right) + o(1).")

#text("It follows that")

#mi("\\displaystyle \\boxed{\\mathbb P(F_n) \\leq n\\exp\\left(-(2\\delta+o(1))\\frac{n}{\\log n}\\right) + \\exp\\left((\\Phi(\\delta)+o(1))n\\right),}")

#text("where")

#mi("\\displaystyle \\boxed{\\Phi(\\delta) = \\delta\\log2 + 2\\delta\\log\\left(\\frac{e(1+\\delta)}{\\delta}\\right) - \\frac{\\log2}{2}.}")

#text("The function ")#mi("\\Phi")#text(" has a unique positive zero")

#mi("\\displaystyle \\boxed{\\delta_* = 0.0370366917265559\\ldots.}")

#text("Thus, for every fixed")

#mi("\\displaystyle \\boxed{0 < \\delta < \\delta_*,}")

#text("the failure probabilities satisfy the explicit summable estimate")

#mi("\\displaystyle \\boxed{\\mathbb P\\left(a^{(n-1,1)} > 1\\right) \\leq n\\exp\\left(-(2\\delta+o(1))\\frac{n}{\\log n}\\right) + \\exp\\left(-(c_\\delta+o(1))n\\right),}")

#text("where")

#mi("\\displaystyle c_\\delta=-\\Phi(\\delta)>0.")

#text("For example, taking")

#mi("\\displaystyle \\delta=0.03")

#text("gives")

#mi("\\displaystyle \\Phi(0.03) = -0.0536121728894\\ldots,")

#text("and hence")

#mi("\\displaystyle \\boxed{\\mathbb P\\left(a^{(n-1,1)}>1\\right) \\leq n\\exp\\left(-(0.06+o(1))\\frac{n}{\\log n}\\right) + \\exp\\left(-(0.0536121728\\ldots+o(1))n\\right).}")

#text("The exact chain is therefore")

#mi("\\displaystyle \\boxed{\\text{unique two-separated extremizer} \\Longrightarrow \\text{exact stability defect} \\Longrightarrow \\text{cutoff-parity law} \\Longrightarrow \\text{explicit finite-}n\\text{ failure rate}.}")

#text("This turns the qualitative two-separated estimate in the proof into an exact concentration law and gives a quantitative strengthening of the almost-sure Cramér–Gilbreath conclusion.")

#text("Best regards,")#linebreak()#text(" Emmanuel Audigé")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9580af391efbbce1782924b8c1a8f4acb2e112e9bff2385837abfbd0b4f20ff-18096f248eff194de8b45b4128dc303a0789b5df53e062ebce5c47a01b529e7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wen Huang")]], [#link("https://terrytao.wordpress.com/2026/07/11/gilbreaths-conjecture-a-cramer-random-model-and-a-deterministic-analysis/#comment-693708")[#strong[#text("Wen Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2026")])]

#text("Regarding the length L appearing in Theorem 1.6 of your paper on the Gilbreath conjecture, I have attempted to substitute the pairing condition from the strong Goldbach conjecture for preliminary calculations. Could you check whether my understanding outlined below is correct? At the first level: the pairing gap satisfies D = N – 2p = \\sum g_i. This implies that covering all even integers in the Goldbach problem is equivalent to requiring sufficient flexibility for the consecutive sums of prime gaps. Fundamentally, the two-valued obstacle segments described in your theorem undermine this flexibility. At the second level, the critical divide lies between finiteness and infiniteness. If any \\{0,d\\} two-valued segment remains finite (regardless of whether its length exceeds your defined L), pairings can seemingly be constructed by searching outside this segment. However, once such a segment extends to infinity, the consecutive sums can only take values from discrete linear combinations. As N\\to\\infty, D=N-2p varies continuously, which inevitably causes massive mismatches and directly invalidates the full coverage requirement of the strong Goldbach conjecture. At the third level: Is it therefore reasonable to interpret the matter as follows? The validity of the strong Goldbach conjecture inherently enforces the exclusion of infinitely long obstacle segments. Meanwhile, the explicit constant L proven in your theorem (beyond which a counterexample to the Gilbreath conjecture emerges) precisely quantifies the finite tolerance threshold. For the Goldbach conjecture, there is no need to further shrink L; it suffices merely to guarantee that L remains finite. Does this simplified viewpoint overlook essential sieve-theoretic error terms?")
]
