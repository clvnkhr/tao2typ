// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/
// Converted to Typst by tao2typ: "2026-10-14T06:59:03.543783+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Please help support mathematics at the University of Southern Queensland", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Please help support mathematics at the University of Southern Queensland")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/")[#text("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I usually try to keep political issues out of this blog, and I certainly try to avoid asking friends and readers of this blog for favours, but there is an urgent situation developing in mathematics (and related disciplines) in my home country of Australia, and I need to ask all of you for assistance to prevent an impending disaster.")

#text("When I was an undergraduate at ")#link("http://www.flinders.edu.au")[#text("Flinders University in South Australia")]#text(" from 1989 to 1992, the level of mathematics education in Australia was comparable to that of world-class institutions overseas. Even in a small and little-known university such as Flinders, I received a first-rate honours undergraduate education in mathematics, computer science, and physics which I continue to use daily in my career. (Examples of topics I learned as an undergraduate include wavelets; information theory; Lie algebras; differential geometry; nonlinear PDE; quantum mechanics; statistical mechanics; and harmonic analysis. I rely on my knowledge of all of these topics today, for instance many of them are are helpful for me in teaching my ")#link("http://wordpress.com/tag/285g-poincare-conjecture/")[#text("current class on the Poincaré conjecture")]#text(".) In addition, several of the faculty (including the chair and my undergraduate advisor, Garth Gaudry) had the time to spare an hour a week with me to discuss mathematics, as they were not overloaded with large teaching loads and other duties. I honestly think that I would not be where I am today without the high-quality undergraduate education that I received (in particular, I would definitely have floundered in graduate school at Princeton, if I were admitted at all).")

#text("The situation for mathematics education in Australia began however to deteriorate in later years, due to a combination of factors including government neglect (the federal government is the most significant source of funding for most universities in Australia) and the low priority of basic education in mathematics and sciences among university administrators. In particular, at Flinders University, the School of Mathematics suffered severe attrition due to lack of support and was eventually folded into the School of Informatics and Engineering. In fact the number of mathematicians on the faculty at Flinders has dwindled down to just three (in my day it was close to 20).")

#text("The decline of mathematics departments across the country, particularly in a time in which mathematics skills are desperately needed in the workforce, has been documented thoroughly in the ")#link("http://www.review.ms.unimelb.edu.au/FullReport2006.pdf")[#text("2006 national strategic review of the mathematical sciences")]#text(". In response to that report, the federal government in 2007 ")#link("http://dest.gov.au/ministers/bishop/budget07/bud05_07.htm")[#text("announced an increase in the funding allocation to universities")]#text(" based on their student enrollments in key majors including mathematics and the sciences. The newly elected federal government is also likely to continue and extend this support in its upcoming budget in May of this year.")

#text("Unfortunately, it appears that at many universities, the ")#link("http://www.theaustralian.news.com.au/story/0,25197,23242453-25918,00.html")[#text("additional funding was diverted away from the schools that it was intended to support")]#text(", for the administrator’s own priorities. (See also ")#link("http://blogs.theaustralian.news.com.au/letters/index.php/theaustralian/comments/dont_hold_back_on_maths/")[#text("the letter by the international authors")]#text(" of the above mentioned review, Jean-Pierre Bourguignon, Brenda Dietrich, and Iain Johnstone, condemning this diversion.) As a consequence, many mathematics departments are in fact in worse shape than before.")

#text("There is a particular crisis unfolding at the ")#link("http://www.usq.edu.au/")[#text("University of Southern Queensland")]#text(". On March 17, the university ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/fosrop.pdf")[#text("announced a rationalisation and restructuring proposal")]#text(" that would cut the number of mathematics faculty from 14 to 6, eliminate the majors in mathematics, chemistry, physics, and statistics, and phase out all non-service courses (for instance, any of the types of courses I mentioned above at Flinders would be lost). Similar cuts were also proposed in statistics, computer science, and physics, although other schools retained their funding and some even obtained increases. This is despite the increases in funding from the federal government for mathematics and statistics students (enrollments in these areas at USQ has held steady so far, though of course with the proposed cuts this is unlikely to last). Already as a consequence of these proposals, initiatives of the department such as an education program for high school mathematics teachers have ")#link("http://www.theaustralian.news.com.au/story/0,25197,23430562-12149,00.html")[#text("had to be scrapped")]#text(". Somewhat ironically, the Dean of Sciences at USQ, ")#link("http://apps.usq.edu.au/usqwebsite/aspnet/staffsearch/default.aspx?staffsearchaction=showdetails&staffsearchusername=verbyla")[#text("Janet Verbyla")]#text(", who has been heavily involved in proposing the cuts, had also presided over similar reductions in the school of mathematics at Flinders.")

#text("If the proposed cuts at USQ go ahead, it is likely that other small universities in Australia will be tempted to similarly ignore concerns about mathematics and science education and perform similar cuts, even while receiving government support for these disciplines. (The ")#link("http://www.une.edu.au/")[#text("University of New England")]#text(", which currently shares some statistics courses at USQ, would for instance be particularly vulnerable.) So the crisis here is not purely localised to USQ, but could be very damaging for mathematics and sciences in Australia as a whole.")

#text("The consultation period for these cuts ends very soon, on April 14, and the vice-chancellor of USQ, ")#link("http://www.usq.edu.au/vc/slt/vc.htm")[#text("Bill Lovegrove")]#text(", plans to announce the specific cuts ")#text("on April 18")#text(" at an unspecified future date. While there ")#link("http://www.abc.net.au/pm/content/2008/s2194629.htm")[#text("has")]#text(" ")#link("http://www.theaustralian.news.com.au/story/0,25197,23430562-12149,00.html")[#text("been")]#text(" ")#link("http://www.theaustralian.news.com.au/story/0,25197,23430559-12149,00.html")[#text("some")]#text(" ")#link("http://www.thechronicle.com.au/storydisplay.cfm?storyid=3768570")[#text("media")]#text(" ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/austms-gazette-prescol-eight.pdf")[#text("attention")]#text(" ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/baker_interview.mp3")[#text("in")]#text(" Australia given to this issue, it has not yet had much effect in reversing the decisions of these administrators. Because of this, I am reluctantly turning to my friends and readers of this blog to ask for your urgent assistance in saving the school of mathematics and computing at USQ. In collaboration with several good friends and colleagues in Australia, I have begun a web page on this blog,")

#align(center)[#link("https://terrytao.wordpress.com/support-usq-maths/")[#text("https://terrytao.wordpress.com/support-usq-maths/")]]

#text("that is documenting the situation and outlining ways to help, including an online petition")

#align(center)[#link("https://terrytao.wordpress.com/about/petition-to-support-maths-statistics-and-computing-at-usq/")[#text("https://terrytao.wordpress.com/about/petition-to-support-maths-statistics-and-computing-at-usq/")]]

#text("that you can sign to show support, and ")#link("https://terrytao.wordpress.com/support-usq-maths/")[#text("people to contact in the university administration and in the Australian government")]#text(" to express your concerns, or to express support for mathematics and its role in the sciences. Please also inform others, especially those in Australia and who may have influence in media, political, or administrative circles, of the current crisis. There is still time, especially in view of the expected increase in support for mathematics and sciences in the upcoming federal budget, to reverse the situation before the damage becomes permanent, and to show that the political support for mathematics education is not so negligible as to be easily ignored.")

#text("Thank you all in advance for any help you can give – and I promise that I will keep the remainder of my blog on topic and focus primarily on mathematics. :-)")

#text("[")#emph[#text("Update")]#text(", April 9: See my editorial at the Funneled Web, “")#link("http://www.the-funneled-web.com/Editorial-080409-Tao-guest.htm")[#text("Mathematics in Today’s world")]#text("“, for a more detailed discussion of the USQ crisis, and also the broader context of the importance of higher mathematics education, and the pivotal role universities have to play in providing it.]")

#text("[")#emph[#text("Update")]#text(", April 12: The Toowoomba Chronicle has a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/adam-walsh.jpg")[#text("two-page article")]#text(" by Merryl Miller focusing on the crisis, and in particular focusing on its impact on a 10-year old child prodigy, Adam Walsh, currently taking maths classes at USQ. (Reprinted with permission.)]")

#text("[")#emph[#text("Update")]#text(", April 14: The petition has been ")#link("https://terrytao.wordpress.com/support-usq-maths/presentation-of-the-online-petition-to-chancellor-brazil/")[#text("formally sent to the USQ administration")]#text(". Apparently, the previously planned announcement of the cuts on April")#linebreak()#text(" 18 has been delayed to some unspecified later date, but no further details are currently available.]")

#text("[")#emph[#text("Update")]#text(", April 17: In response to the concerns of constituents, ")#link("http://www.parliament.qld.gov.au/view/legislativeAssembly/documents/memberBio/HoranMichael.htm")[#text("Hon. Mike Horan MP")]#text(", the state member for Toowoomba South, ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/usq-horan-hansard.pdf")[#text("spoke in the Queensland parliament")]#text(" urging the University of Southern Queensland to reconsider its cutbacks to mathematics and statistics. (The full and official transcript of the day’s session in Parliament can be ")#link("http://www.parliament.qld.gov.au/tableoffice/view/legislativeAssembly/hansard/documents/2008.pdf/2008_04_17_DAILY.pdf")[#text("found here")]#text("; the speech above is on page 1198.)]")

#text("[")#emph[#text("Update")]#text(", April 29: The USQ administration released a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/04/faculty-final-plan-draft.pdf")[#text("revised draft proposal")]#text(" on April 22, but the details are largely unchanged (e.g. 11 staff cuts to the department of mathematics and computing instead of 12, and a “review” of the maths major and its courses rather than automatic elimination). The revised plan has already attracted ")#link("http://www.nteu.org.au/bd/usq/rop/response_rdip_facofscience")[#text("criticism")]#text(" from the ")#link("http://www.nteu.org.au/")[#text("National Tertiary Education Union")]#text(", and we are continuing to organise further opposition to the proposals. (For instance, László Lovász, President of the ")#link("http://www.mathunion.org/")[#text("International Mathematical Union")]#text(", ")#link("https://terrytao.wordpress.com/support-usq-maths/letter-from-laszlo-lovasz/")[#text("wrote a letter of support")]#text(" on April 25.]")

#text("[")#emph[#text("Update")]#text(", May 1. A second ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/05/fos_final_template1.pdf")[#text("revised draft proposal")]#text(" has been released, which uses some new (but possibly non-permanent) sources of funding to add some specialised positions to partially offset the cuts (e.g. there will be 2-3 such positions in mathematics and statistics, although the 11 staff cuts are still in effect). The USQ administration has apparently also agreed to recheck the student load and financial data that is being used to underlie these proposals, as there appears to be some irregularities with this data in previous rationales.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-2/#comment-29913")[#strong[#text("Local Events, Turan’s Problem and Limits of Graphs and Hypergraphs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")]

#text("[…] this initiative and skeptical even about the Australian example, and the following post by Terry Tao is telling regarding the Australian reforms. (See also the new blog mathematics in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-2/#comment-472512")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Dear Professor Tao,")

#text("We now have a similar situation at the University of Leicester, UK, 7 out of our 23 teaching and research positions are proposed to be closed. The situation is described in famous blog of professor Gowers ")#link("https://gowers.wordpress.com/2016/09/15/in-case-you-havent-heard-whats-going-on-in-leicester/")[#text("https://gowers.wordpress.com/2016/09/15/in-case-you-havent-heard-whats-going-on-in-leicester/")]#text(" , we have the petition ")#link("http://speakout.web.ucu.org.uk/no-cuts-no-confidence-at-university-of-leicester/")[#text("http://speakout.web.ucu.org.uk/no-cuts-no-confidence-at-university-of-leicester/")]#text(" with almost 3,500 signatures, but I did not hope that this can help. However, I recently learned from Mathoverflow, that “something kind of comparable was announced in Australia a couple years ago, and with the intervention of a lot of mathematicians from around the world, the plan was scaled back, at least temporarily”. Could you please confirm whether the campaign was indeed successful (the last update in this blog is about second revised draft proposal, what was next?), and share any experience which may be useful for us.")

#text("Thank you in advance,")#linebreak()#text(" Sincerely,")#linebreak()#text(" Bogdan Grechuk,")#linebreak()#text(" Lecturer, University of Leicester")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c316d58f0218fa20ab4fad80dd1122f12216353da565877f800e77f5e1071d8d-c8fad91175f7248db71cccb91afb0f48bca7c2b2ee658f9f96b0ce3f9431316b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Aaronson")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-27972")[#strong[#text("Scott Aaronson")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2008")])]

#text("The USQ proposal and rationale are pretty remarkable documents. At least to an outsider, they give the strong impression of being written by people who know they’re dismembering a university and are trying to describe it using as much euphemism as possible.")

#text("I wish you success with this campaign.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28001")[#strong[#text("Please support Prof Terence Tao’s petition « comme appelé du néant")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")]

#text("[…] For more information concerning the situation, I refer you to Prof Tao’s well-documented blog post. The details of the crisis at USQ can be read here. I strongly and very earnestly urge everyone who […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28049")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("So what do they want to spend the money on instead?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fa1af9eba8e3dffdd838fee8051bbffc329d00b6226ddf586ce519c5d0c902f-cda73324864de384319cfe3930819f0b604d2853159413a95dd236230059750c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Meyer")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28073")[#strong[#text("David Meyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("Since the wikipedia entry for USQ appears to have been put there as an advertisement for the university, it seems appropriate to add a section describing this proposed restructuring.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28120")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("I found the planning and rationale document and I get it now. They view students as customers and they want to gut math and science on the principle that the customer is always right. That principle is very popular in America, and so is its abuse and overuse. It’s sad to see it at a public university in Australia!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28149")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2008")])]

#text("“They view students as customers and they want to gut math and science on the principle that the customer is always right. That principle is very popular in America, and so is its abuse and overuse. It’s sad to see it at a public university in Australia!”")

#text("Although top private universities in the USA are flush with huge endowments, many public universities have been struggling with budget cuts and compensatory rising tuition. I’m afraid that the temptation to adopt this attitude here on a larger scale could be just around the corner, so squashing this possible cancer everywhere, even around the world, is imperative.")

#text("An additional problem here is the huge amount of medical and biotechnology research money pouring into universities. This is the new cash cow for some universities, and inevitably distorts and degrades the value of other academic pursuits in the eyes of some administrators, few of whom even realize that math is important in those areas as well. If you’re not bringing in bundles of money, what good are you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28220")[#strong[#text("A Petition to Help Support Maths at USQ « Louis Yang Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")]

#text("[…] Petition to Help Support Maths at USQ Please go to Terry Tao’s Blog and give your endorsement to his petition to help support maths at University of Southern […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Dear Terry,")

#text("I am wondering if this news makes you reflect on your decision to take a faculty position in the US rather than in Australia. (I hope that you do not find this a rude question.) Are you able to comment on the criteria that you considered when you were choosing jobs? Many foreign graduate students in the US (myself included) face similar decisions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petição: Petition to support maths, statistics, and computing at USQ by Terence Tao « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28248")[#strong[#text("Petição: Petition to support maths, statistics, and computing at USQ by Terence Tao « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("[…] na barra lateral): Quem pretender saber as razões desta petição, pode consultar este seu post , onde descreve a situação na Universidade australiana onde estudou (University of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28270")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("A previous post of myself was corrected to myself to:")

#text("O matemático de topo Terence Tao , Professor da UCLA, lançou uma petição online, no seu blogue What´s New (veja “link” na barra lateral):")

#text("Quem pretender saber as razões desta petição, pode consultar este seu post , onde descreve a situação na Universidade australiana “University of Southern Queensland”.")#linebreak()#text(" Serve esta entrada apenas para informar da existência desta petição, embora saiba perfeitamente que nem 0.1% das pessoas será aqui que dela toma conhecimento.")

#text("NOTA: o texto foi corrigido às 20:06")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff3c177929efd5d9520d081bbb7eb51b1d5d8e880fa9e485d53947c9d3979b53-12d7796462b926c9a2062080bb4404955725692745c5b22ff5f32d78d0b6ad7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28294")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Might be worth amending your front page article to refer to the USQ VC as Bill Lovegrove (John is his middle name).")#linebreak()#text(" Also add local MP Ian Macfarlane to the petition list.")#linebreak()#text(" USQ Council appointed the VC and should be held responsible for the significant loss to the University’s reputation (it was formerly joint University of the Year), and loss of good key staff since their decision. At the very least they should take into consideration all factors before reappointment.")

#text("All the best.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("Dear all,")

#text("First of all, thanks to the hundreds of people who have helped out by signing the petition, and for making the case for mathematics. It has already begun to be noticed in the media, such as this ")#link("http://www.the-funneled-web.com/N&V_2008%20(Jan-Dec)/N&V_0804/news__views_item_apr_2008-080407.htm")[#text("Funneled Web article")]#text(" and this ")#link("http://www.theaustralian.news.com.au/story/0,25197,23503892-12332,00.html")[#text("article in the Australian")]#text(".")

#text("It also certainly has not escaped the notice of USQ university administrators – thanks especially to all who have written directly to them, and to the relevant government representatives. The USQ maths department is of course trying to talk with the administration to work out an acceptable solution, and this support will be very valuable in that effort.")

#text("Thanks also for various people who have contributed corrections, suggestions, and links, this is all very helpful.")

#text("I’ll keep you updated on any further developments, of course.")

#text("p.s. Regarding the question by Anonymous, I can point to my 2004 article on the brain drain in Australia in")

#link("http://www.austms.org.au/Publ/Gazette/2004/Jul04/braindrain.pdf")[#text("Click to access braindrain.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28337")[#strong[#text("A math department in danger « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")]

#text("[…] math department in danger 07Apr08 Via Terry Tao: the University of Southern Queensland has announced a plan to eliminate majors in mathematics, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4c9034d73c8265b204f41d7e549a3d42787a364cf0c6d18ea713d7c858e9fbf-aebd49994e65bfcbdb854edb25ce035bebef891739b7fc99c31013d760bdcf24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Howell Tong")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28359")[#strong[#text("Howell Tong")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("As an outsider, the choice facing the University of Southern Queensland is more far-reaching than just sheer economics.")#linebreak()#text(" Does it want to remain a proper university by imparting")#linebreak()#text(" fundamentals of knowledge to its undergraduates? No self-respecting university can kill off its mathematics department.")

#text("Howell Tong")#linebreak()#text(" London School of Economics")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28364")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2008")])]

#text("The Australian has this quote from a USQ administrator: “Professional associations and mathematicians need to recognise the role they have to play in promoting maths at primary school.” What a way to pass up your own responsibility. He wants to let the mathematicians go, but he still expects them to promote math in grade school.")

#text("To reiterate the obvious — maybe it’s a little less obvious outside the United States — American universities are very good while American grade schools are, on average, notoriously mediocre. Universities take primary responsibility to promote interest in higher mathematics. Even math contests and summer math programs for grade school students, at least the serious programs, are generally sponsored by universities. It seems that Australian university administrators need to learn a few things about the American situation, as well as their own situation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28494")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2008")])]

#text("The notorious rationale document is initialed “JLMV”, which is presumably Janet Verbyla. Terry, your staff lookup links for her don’t work; you might want to fix those. In the meantime I found two pages describing her recent appointment at USQ ")#link("http://www.usq.edu.au/resources/usqnewsfeb22pdf.pdf")[#text("here")]#text(" an ")#link("http://www.usq.edu.au/newsevents/news/deansciences07.htm")[#text("here")]#text(".")

#text("What is odd is that despite what happened at Flinders and what is happening at Queensland, she gave upbeat assurances about promoting science and mathematics. Is the idea to promote them by debasing them? Or does she is pressed to appease superiors who want to undercut her own area? Or were her assurances simply disingenuous?")

#text("Anyway, to address the brain-drain and can-it-happen-here issues, the United States is lucky for reasons that have little to do with national wisdom. As Terry’s brain-drain essay explains, mathematicians want to be around other mathematicians. This creates a winner-take-all phenomenon, and the winning country is most likely to be a large, wealthy nation that is also winning the language contest. No one should think that Louisiana is truly more enlightened than Queensland; it isn’t. It’s just good luck for America and bad luck for Australia that the American math research network is a behemoth. The challenge for other countries that appreciate mathematics — in fact many of them appreciate it more than ordinary Americans do — is to network as much as possible. Achieve by fiat what the US achieved by historical luck. This is accepted wisdom with the euro currency and it ought to be so with mathematics employment as well.")

#text("Well, it’s not very useful advice for Australia, which is just too isolated to network much with other countries. Terry mentioned videoconferencing. That would help. Another approach would be to couple aggressive acceptance of education-minded immigrants with social promotion of science and mathematics. Social engineering policies have had some success with issues such as smoking cessation and family planning, so why not mathematics too. A key point is that social engineering is the opposite of “the customer is always right”. Again, the USQ administrators do pay lip service to social promotion, but only to conclude that it’s everyone else’s responsibility and they’re entitled to work against it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf96ffefbeb5fe60d802b0545d1c33272fc56199071bc3e44ad2e67e8e8927d7-9ea472afe3278b22bc85707dcd14fe9eb418b48e7ff896669c4d4b199565a3f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Odd Man Out")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28525")[#strong[#text("Odd Man Out")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2008")])]

#text("@Greg Kuperberg:")

#text("Your opinions of the American University and Research systems are actually quite dated.")

#text("In North American, all but the “Ivy league” Universities have dumbed down their programs to the point where Math Degrees mean very very little. It’s actually the Grad programs that offer “catch up”. And even then it’s only possible because in North America students specialise very very early. Contrast that to the German system which offers *far* more depth and breadth of knowledge at their equivalents to our Undergrad and Grad programs.")

#text("In the North America, especially in the US, funding to the sciences, especially maths and the fundamental sciences, have seen significant cuts over the past many years. In fact, many have said that the American research network, both private and public has effectively collapsed. So, don’t let the contests, etc run by volunteers and/or private funding let you think otherwise.")

#text("The recent and significant shift in Universities today is what the Administrators find important. It used to be how much research funding a department brought in. But, now that doesn’t matter so much as if that funding is tied to something that is “sexy” that they can put in some advertisement. It’s a kind of, “look at this new flavour of the week science/whatever that people think is cool that we’re doing here. Come to school here!” nonsense.")

#text("In fact, at my old University the Math department brought in a significant portion of research funding, yet was (and is) constantly threatened with cuts because they don’t have as many students as other departments. The Physics department has the same issues. Little students means the department is very much in danger no matter how much research funding is brought in. Not to mention that those grades better fit a bell curve, otherwise the Prof. will probably be getting a phone call from “on high.” God forbid students get the grade they earned.")

#text("To be certain, Mathematics and the Sciences are dying. Not only is this a problem with an increased lack of access, but it’s also a problem because we already live in a society that doesn’t know how things work. And no matter how much anyone has informed Administrators of the necessity of Science and Maths to innovation, etc, it has done quite little to keep them at bay. All that has happened is brought a “nickel and dime”ing approach to funding cuts to the Science and Maths before a final push to rid Universities of them (or to relegate them to service courses). A push that we are starting to see right now which means that it is arguably too late to save many Maths/Science departments.")

#text("It’s time that we look at what is possible to save and what’s a lost cause. Because, it’d be a shame to loose more than necessary, lessening the chances of a return. In other words, the community must look at the bigger picture coloured NOT by thoughts of nostalgia.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28535")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2008")])]

#text("Odd Man Out: Well, I don’t mean to sound smug about this. There certainly are a lot of American math departments that are hobbled by an environment of apathy and incomprehension. In other countries, certainly in Germany, there is a great mathematical cultural tradition that is stronger in key ways than in the US. I don’t know much about the mathematical tradition in Australia, but at the very least Australia has an egalitarian spirit that seems more useful for universities than the privatized, anti-tax side of the US.")

#text("But still, where I am at UC Davis, I don’t see the system crashing down. We have 300 math majors. We still find grounds to complain about the administration as I suppose everyone does. But at least once people are hired, they have an admirable amount of job freedom and their research is respected. Yes, a lot of the students are underprepared, including many of the math majors. But just as I would argue about USQ, we have as much responsibility as anyone else to prepare them.")

#text("Are American math courses dumbed down? Sure, calculus is a factory product, but that is partly because it is required for a vast population of students. But the courses for the majors? I’m teaching undergraduate algebra this year using the book by Artin. Am I falling short if I skip some of the hardest sections of Artin? For comparison ")#link("http://www.math.uni-bonn.de/people/vorlverz/vv/vvss07-e.pdf")[#text("here")]#text(" is a math course catalog at the University of Bonn. The undergraduate course offerings seem decent, but not particularly more exciting than what we do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b5ec57e819b6f27fe2fcdf1e439c625c678ce7db7ca608109b4c3d0a988d76c-afcaddd10de8bc6c3bca963160a213f00a34e3f21db1305c30318d031fc2fd92.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kea")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28569")[#strong[#text("Kea")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2008")])]

#text("I say it serves them right. I moved to New Zealand, and I have no intention of wasting my time playing politics back in Oz.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28616")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("Greg Kuperberg says “I don’t see the system crashing down.”")

#text("With respect, Greg, I think what concerns everyone is that “the system” shows clear evidence, not of crashing down, but of what physicians call ")#emph[#text("failure to thrive.")]#text(" Here “the system” is understood to mean “mathematics and the physical sciences”.")

#text("This syndrome has been evident ever since the early 1970s, and it has afflicted every developed nation. Its causes can be debated, but no one denies its cost — the waste of our our planets most precious and abundant resource: young people.")

#text("A diagnosis of “failure to thrive” in infants and children is regarded as a life-threatening medical emergency. Medical ethics requires that no effort be spared and no delay tolerated in identifying the cause and beginning treatment. Is the situation in mathematics and the physical sciences any different?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb7109d2b62e95bac2fbe04a9bea8803f40f5c2e9cb41a2bfce7689178a0cc0f-6560b3b52073c9b6e73cd78a96a64a2bee82ad156ae84553258a1859a54a206d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robert")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28677")[#strong[#text("robert")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("John Sidles")

#text("“Failure to thrive” in an infant is a medical emergency and intervention is mandatory. In an elderly patient, it precipitates an earnest discussion with relatives, and a switching off of life support. Sadly, I think that, to those who hold the purse strings, the latter is the more pertinent analogy.")

#text("BTW I think that both these derelictions of responsibility are gross affronts to the humanity of us all. (Hey – I like math and I’m getting old)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("Greg: thanks for reporting the bad link! It should be fixed now.")

#text("Maths and science education of course faces challenges in every country, though the nature of the challenge can differ from country to country. In the US, I would say that it is the high school maths education system which most in need of strengthening; individual university maths departments may be having some difficulties, but I don’t think we’ve had a real crisis here since the Rochester incident in 1996, although the general lack of understanding of mathematics in the US public may eventually be a real cause for concern. Kea mentioned NZ (and people from NZ have given us a tremendous amount of support through the petition – thank you!); apparently NZIMA has just lost government funding, though perhaps the situation there is still reversible. I guess the point is that no matter what country one is in, one cannot take support for mathematics for granted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28713")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("I wholeheartedly support the petition. That said I think that some of the outrage is getting a bit outrageous.")

#text("Of the 500+ post of support, few acknowledge that university administrators are working with finite resources. It is a straw man argument to say that funding math is better than not funding math. The real conflict is between the advantages of funding math over other programs at a specific university. As an extreme example, Julliard is highly selective American college with a poor (if existent) math program. Even if we all agreed that math has more potential to help humanity than dance, I doubt many would support cutting the dance faculty at Julliard to hire math faculty. I grant you that USC is not a highly specialized school like Julliard, however my point is that decisions, like the one USQ is facing, need to be based on many more variables than the absolute value of mathematics to humanity. Or, for that matter, even the relative value of mathematics over other disciplines. Consideration of these variables (or even acknowledgment that they are factors) has been almost absent from the discussions I have read. As less extreme examples I wouldn’t think it wise for Cornell to invest in their math program at the expense of their world renown hotel school, or, in a similar spirit, I wouldn’t want my local community college to invest in mathematics faculty at the expense of their plumbing and heating program.")

#text("Like many mathematicians I have a healthy sense of self-importance, however I think saying these issues are “gross affronts to the humanity of us all” is a bit over the top. I believe that math is at the heart of innovation and has been the foundation for many of humanity’s greatest advances. But let’s have a bit of perspective. Half the world lives on a dollar a day. How much a society should invest in research and social programs is complex question. However, I don’t think that the amount of money the NSF has invested over the years in, say, trying to improve the exponent in the error estimate of the prime number theorem really can be argued was an allocation of resources that has, or was intended to, maximize any reasonable approximation of humanity’s utility function.")

#text("I wouldn’t even go as extreme as another poster saying “A mathematics and statistics department is the first department that should be established in every modern university.” If I had a family to support at the time I made my career decision I certainly wouldn’t have chosen math — and I certainly wouldn’t advise anyone in that situation to do so today!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28714")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("Dear Professor Terence Tao,")

#text("My comment of 7 April, 2008 at 11:17 am")

#text("ERRATA: Instead of")

#text("“A previous post of myself was corrected to myself to:”")

#text("should be")

#text("“A previous post of mine was corrected by myself to:”")

#text("or something alike.")

#text("This comment of 7 April, 2008 at 11:17 am was made here only to advert that the “ping” of 7 April, 2008 at 8:46 am:")

#text("Petição: Petition to support maths, statistics, and computing at USQ by Terence Tao « problemas | teoremas")

#text("was no longer updated.")

#text("PLEASE EXCUSE this example of poor English and the inaccuracies of mine for all the inconveniences (waste of time, etc.) it causes to you and your readers.")

#text("Américo Tavares")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c619a24c5ca3846879239c84019efb2bcd9f63ee8b44e796cc91c569c893cd6c-cd6cbad0650eab0ee92775904bc904747b06949486252679b46f3fe9131bd3c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TimB")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28716")[#strong[#text("TimB")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2008")])]

#text("Any move that decreases rather than increases the number of academic positions in mathematics and physical science positions is so short-sighted as to be laughable. This is particularly evident when one considers our whole technological age – it relies heavily on developments in these very areas.")

#text("UoSQ, it is not too late reverse your decision and so become the recipient of fantastic, as opposed to derisively negative, publicity for your institution")

#text("TimB")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28738")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("The previous post by “anon” introduced a very welcome global perspective. I wonder whether it is possible to make this same point in a more positive way?")

#text("A planet with six billion people on it — heading for ten billion — definitely has plenty of serious issues to grapple with. Many planetary resources are in short supply … yet fortunately, at least two resources are in ")#emph[#text("abundant")]#text(" supply … smart young people and computing power.")

#text("Aren’t these precisely the two resources that the mathematical disciplines require in order to flourish? Can’t a strong case be made, on this basis, to universities, governments, corporations, and — most importantly — to young people themselves?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66e44683052499f03bf99076f9e907b3f0989a8123df7c26dda86748c2349b07-53b108be53022a9960ad712acc0131e9a58e9c39aa20e0432aa6847716d677d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28749")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("Greg Kuperberg")

#text("There is another option to accepting large numbers of education-minded immigrants-this usually means Asian Legal immigrants. The other option:accept a certain number of elite scientists and mathematicians such as Terrence Tao and……….develope home grown scientific and mathematical talent that resides in such places as Appalachia.")

#text("America is quite capable of producing her own scientists and engineers-just like India and China. It is has been done before.")

#text("The very nasty H-1 B and L-1 B visa programs are bringing about the destruction of native born engineering experience. It really is criminal.")

#text("The day may come when Chinese and Indian scientists and mathematicians stop comming to the US. Then what? The only option then would be to do what should have been done all along:develope home grown talent.")

#text("Completely depending upon China and India for scientists and mathematicians is not a very health state of affairs. There are also serious national security issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66e44683052499f03bf99076f9e907b3f0989a8123df7c26dda86748c2349b07-53b108be53022a9960ad712acc0131e9a58e9c39aa20e0432aa6847716d677d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28751")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("Professor Tao")

#text("It would be very easy to fix the problem of inferior mathematical education in US high schools. Just shut off the supply of foriegn scientist with the exception of elite scientists and mathematicians. To the extent that this causes a serious crisis in the US-technological competitiveness issues for example-it would force the US to devote resources towards the development of home grown talent. We would figure figure out real fast how to solve this problem. The pressure to do so would be enormous. It would be a wonderfull thing if it happened.")

#text("Severe labor scarcities of all soughts-unskilled,semiskilled and very highly skilled -have always been a great benefit to ordinary workers.")

#text("I suspect this argument applies to Australia also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae0a4a738361c55d42c04069eb262640817f148a37e146d5201851ca548ea99f-f2f60c64ec9162f906c535e13d05e005ec9117eee28a06c3da07c69682f39fe0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Vallance")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28758")[#strong[#text("Scott Vallance")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("I studied at Flinders Uni in the department of Infomatics and Engineering (as it became) from 1995 to 2004 and was disappointed with its direction. Not all the cuts came under Janet Verbyla’s tenure (only a portion of that period), and they were supported and encouraged by the administration.")

#text("I think the blame lies in funding models and short sightedness. If you fund education on a per-student basis then departments can get a short term gain by restructuring to meet the trends of the day and reducing their depth. Without independent quality control like the certifying boards of law and medicine there isn’t any particular disincentive to producing graduates without the thorough knowledge of a discipline.")

#text("The funding available to university departments keeps shrinking despite population and economies increasing. Students paying some of their tuition costs should have made even more public money available for universities, but the with the politic burden lifted with the expectation that university could meet their own needs, the money has gone to other uses. I think public pressure needs to be placed on the government to improve the stature of our departments and universities.")

#text("I have a fairly straightforward view of academia. I think departments should investigate their field and teach it to the best of their ability. I think those fields appropriate to a university department are fairly well agreed on. The intersection of a departments knowledge with hype of the time and job market is transitory and unpredicable.")

#text("This is not simply an issue of Mathematics being sidelined by more attractive fields, but a dilution of the study of academic fields altogether in favour of shallow packages attractive to student units with the smallest staff costs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28761")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("Dear anonymous,")

#text("Of course, mathematics and science, like any other component of a university, should share the burden of any budget cuts. But the burden that it is being asked to bear by USQ is, to put it mildly, disproportionate. Here are the numbers: of the 15 net staff cuts at the Faculty of Science, 12 of them are to be borne by the Department of Mathematics and Computing (which includes statistics), and an additional three staff losses occur in physics and chemistry. The remainder of the Biological and Physical sciences will have no net losses, the Nursing and Midwifery school will have two new staff, and the Psychology faculty will lose two staff (though this was due to resignations rather than the current proposal). From a budgetary standpoint, the maths and stats programs earn about $5.5 million a year for USQ (this includes $1.2 million in additional federal government funding last year from a new initiative to support maths and sciences in the universities), but funding to the school is being ")#emph[#text("cut")]#text(" by about $1.2 million instead. Note that the university itself admits that the research and education excellence of this department is unquestioned; its rationale for the cuts are purely “financial exigencies” and “student demand” (though enrollment in maths and statistics has actually held steady). From these numbers, I believe that in fact quite a bit of outrage as to the treatment of mathematics, statistics, and computing by USQ is justified.")

#text("Dear Joshua:")

#text("Artificially restricting external supply to try to increase internal supply will, by textbook economics, create severe deadweight inefficiencies that will leave the US (or any other country) even less equipped to perform maths education than before, while also exacerbating severe skilled labour shortages in other areas. An analogy can be drawn with former communist countries in Eastern Europe such as Hungary or Romania. During the communist era, the safest occupation (politically) for skilled mathematicians or scientists was in high school education; emigration was highly restricted (which, in effect, has much the same impact on supply as immigration restriction, and in any event immigration of skilled teachers into these countries from non-communist countries was negligible) and of course a career in industry under a communist government was hardly attractive (unless you had a lot of political connections, as opposed to scientific and business skills). As a consequence of this and other factors, high school education in those countries became among the best in the world (and have, in fact, produced many mathematicians and scientists of the first rank). Despite this success, the communist model of artificially boosting the supply of skilled high school teachers was not exactly optimal for the teachers involved, or for the larger economy (given that entrepreneurship in a communist country is essentially non-existent). In the post-cold war era, a lot of bright people have left academia and education to start businesses or to join the expatriate community. This has inevitably led to a decline of quality in Eastern European education from its previous very high levels (though it still compares quite well with that in, say, the US), but nevertheless I would not advocate a return to the communist model, as the human and economic cost of artificially increasing the supply of educators is too great.")

#text("To some extent, the lack of mathematically skilled people going into high school teaching in the US is caused in part by the vibrant demand for mathematical skills in other parts of the economy that can offer higher financial compensation. One could perform the draconian measure of destroying those sectors of the economy in order to force those workers back into teaching in high schools, but this is not the solution to the problem I would propose. (Ironically, your proposal to restrict foreign workers may in fact exacerbate the high school education problem, as other industries, facing even more severe skilled labour shortages, will increase their poaching of skilled talent from the education sector. In any even, the net supply of skilled labour available in the US will certainly decrease as a consequence, which is not exactly a positive for the US economy.)")

#text("High school education is a complex problem (being connected to other issues in the larger economy and in society), and complex problems do not, in general, have simple solutions, in part because of the law of unintended consequences, but also because the definition of success or failure is not measured on a one-dimensional scale (e.g. raw numbers of high school teachers is not the only metric here). I have yet to see a proposal in this area that would solve the problem without creating even worse problems elsewhere, though there are more modest reform efforts which could have a net positive impact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c43e06ff537d1a16199da137f3d173fd1dbbc3b0f7f64b649af3237ee522eab3-34621cec0824e8d28ea1592784fcd0c1a80a7985c700e731cfcefd1e6019599f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josie Tomas")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28875")[#strong[#text("Josie Tomas")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2008")])]

#text("I would like to add my strong support to the petition.")#linebreak()#text(" Thank you")#linebreak()#text(" Josie Tomas")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5de452e99e5e6dcf9a82c9174eef69058cb0e390ec0f3631e2bb4f44b93070df-33222a07838c54a327104de894b87716f9197ab93b03654487923e82b14d10cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AlbertEinstein")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-28931")[#strong[#text("AlbertEinstein")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2008")])]

#text("An article last year in the AUSTRALIAN said this: “Thirty years ago, there were no junk universities in Australia. But now, there are several”. Very correct. The bottom ten unis in the country are absolute junk. They cater to extremely weak students who have no business studying in a university; they should either go to TAFE or work in coffee shops or drive trucks. Most of the “research” that goes on in these junk universities is mere consulting. A lecturer who teaches Aviation Maths at one such uni told me, “I cannot even trust these students with a bicycle, how can anyone trust them with a plane?”. These universities survive on fees from dumb students from India (who end up driving taxis in Sydney and Melb for the rest of their lives). The govt should come up with the political will to shut down the bottom ten Australian unis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e29aff4fb9c80b83e3216e1e0cd2b3e40583f5ca9bd25280ac457d9263b940f-aca3dc827272569b6edb9f55ed839747cc65a471b06707d6cffa7fec2e2cfbe0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Horowitz")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29021")[#strong[#text("Joel Horowitz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2008")])]

#text("Australia has produced many outstanding researchers in mathematics, statistics, and related fields. It will be a great loss to Australia and the international community if Australia’s ability to train and employ such people is lost through budget cuts or changes in administrative priorities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfc65793073b037e489eee3dc5994ce5e2457c593fa3ef6347af2bbfe6655e49-d99183eeaf8178d0f8b58685682f73e5921bb89805fabd7a068678f5103b85e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrey")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29040")[#strong[#text("Andrey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2008")])]

#text("Do you have some High technology firms and businesses around this school? Do they hire graduates of this school? (I suppose yes).")#linebreak()#text(" Starting from this point of you, it possible to try to save the situation. The idea is that everyone, who finishes the school, usually pays a LOT of taxes for his whole life (of course if the High technology industry works well), so it should be very efficient for the government to support such a school. I am not talking about many social aspects: more educated people commit less crime and are generally better citizens….")#linebreak()#text(" But if there is no a strong science faculty, it is very difficult to compete with other countries, which do have ones. For example, every big company (Intel, Microsoft, Motorolla…) builds their research centers near universities.")#linebreak()#text(" So I think it is advantage of both sides (school and government) to continue to support this school. Again, it is important that high technology businesses will be involved and will put some pressure on the government, because at the end of the day they have the main beneficiary from the school.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Man Peng")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29078")[#strong[#text("Man Peng")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2008")])]

#text("I strongly support petition!! This short-sighted decision will only lead to worsening Australia in world competition in the long run, and also cause great loss that money can’t buy. Thank you Professor Tao for bringing up this topic and awaken our global math community to call for action.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/701b2ba1f27cad227a984cf1123a25ccc4d50ab59679f6aecccb7197db5c9362-f8084ac76d2816bf11dbf81ce50953557109e7d57761a20b3d05bbb10f45195b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cis Tolk")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29153")[#strong[#text("Cis Tolk")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2008")])]

#text("Apropos to AlbertEinstein’s comment about the bottom ten Australian Universities surviving on fees from dumb students from India, who end up driving taxis in Sydney, I would like to ask a question. May I?")

#text("Is there any statistics on what percentage of Indian students are there in these ten universities as compared to the percentage of Australian students in those universities?")

#text("Maybe someone non-dumb will come up with a dumbness coefficient for a country by taking the ratio of the number of dumb students in the ten dumb Australian universities from a country by its population (or the total number of students – both dumb and non-dumb – from that country studying in Oz, or whatever …).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2008")])]

#text("Given a fixed amount of money that Australia (or any other country or the whole world) decides to spend on college+university mathematics, how should it be spent?")

#text("My answer would be to focus most of the “reserach” part of this money into a few top universities (maybe only 2 or 3 in Australia) which will get really excellent math departments and have only these departments offer a math major. Other universities will only offer the required “service” math courses to students in other disciplines, at the level desired by the other disciplines.")

#text("The logic is that what I can see the value that humanity gets from reserach by a brilliant mathematician, it gets much less value from reserach of half a dozen merely good mathematicians. (This maybe different from what happens in some other disciplines: half a dozen of good reserachers in life sciences or computer science seem to provide great value to humanity today.)")

#text("Maybe the recent math cuts in some Ausralian universities are related to this type of optimization which certainly hurts the “non-math-reserach” schools, but are justified more globally?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William James")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29297")[#strong[#text("William James")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("While feeling despair at the short-sightedness of the policy-makers, I think everyone else is also being a little short-sighted. If the changes (at USQ, nationally, and internationally) are being motivated by student demand, then the answer is simply to promote mathematics to high-school students and the public at large. If students were more aware of the opportunities made possible by mathematics, then more would consider requesting these courses. And if the benefits were common knowledge, then we wouldn’t have the problem.")

#text("Many professions have associations that do this. It is a crying shame that research professionals do not do the same. But it is not obvious how to coax many maths researchers out of their department to do this. Why? Well, many are not aware of what the professional opportunities are!")

#text("But this brings me to an important point: if there is a shortage of good mathematicians, then their shortage will lead to increased demand for these skills in the workplace, which should translate, in the long term, to a resurgent demand from school-leavers. (This relates purely to vocationally motivated people. The others are passionate about maths anyway, and will still do it, whether they have a well-paid research tenure or not!)")

#text("So do not despair! This is just a fluctuation in a socio-economic cycle!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William James")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29298")[#strong[#text("William James")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("Anonymous on 23 Apr:")#linebreak()#text(" This is the problem – mathematics is like many other areas, in that it is required in many occupations and provides a basis for many other fields. If all we are trying to achieve is to have a few brilliant mathematicians solving problems, then we are abandoning mathematics education, as no-one else will be able to use it. You need to remember that we need people of all abilities to be able to implement applications of mathematics, everything from the basic calculus taught in service courses to the new discoveries that comes from research.")

#text("The fact that there are mathematicians who are perpetuating the notion that it is only important for research is why universities are closing departments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("The previous posts touch on an important issue. When math is under attack, many mathematicians are quick to speak of research and teaching as one and the same. However many (not all) of these same mathematicians are just as quick to separate these duties when responsibilities are being delegated in their department. In the US it is not unusual for a school to let a top research mathematician go a decade without teaching an undergraduate course. The presence of such a top research mathematician certainly has its benefits for the university, and may be worth the cost. However the profits from such an arrangement are typically in the form of high quality research, which does little for the department’s role in service education.")

#text("Unfortunately this phenomenon is not restricted to elite mathematicians. Many research mathematicians devote minimal effort to teaching under the (often correct) reasoning that research is where their career will be made or lost. It is certainly unfortunate that many mathematicians are willing to sacrifice the quality of their instruction. However the root of cause (and the larger failing) is that as a community we foster a culture that encourages this behaviour. In effect, this culture punishes those who choose to devote time to teaching.")

#text("In fact, service courses (like calculus) typically pay for math (I’d assume this is the source of the service course revenue that at USQ that Terry references) and departments often relegate instruction in these courses to graduate students and the most junior faculty, with little to no incentive/accountability for the quality of their instruction. In this regard cutting a research program and hiring career lecturers (who typically get the best reviews in these courses) could potentially improve the quality of instruction in these service courses. The (poor) calculus curriculum at university is a related issue, that has also been mentioned in these threads. I find it ironic to see complaints about this in these threads, as it is one of the few issues that the readers and posters on this blog are empowered to fix.")

#text("As I recall these issues played a significant role in the incident at U Rochester. The engineering departments, unhappy with the quality of service course instruction, started offering competing courses. As the math department failed to take corrective action, they started to get (or perpetuated) a reputation as disconnected from the university community, off pursuing their own priorities. As I recall, there was a great “lessons learned” article in the notices about this a number of years after the incident — although these lessons do not seem to have been learned by many.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29357")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2008")])]

#text("Dear anonymous,")

#text("The tradeoff between emphasis on research and emphasis on teaching is certainly an important issue, though actually at USQ the problem is that neither quality is being counted for much by the administration. The department there in fact excels at teaching winning eight internal teaching awards from USQ last year, and initiating a number of innovative programs in distance education, teacher education, and use of software packages such as Moodle for online courses that have since been copied across the university. See also this letter from the local high school maths teachers association:")

#link("https://terrytao.files.wordpress.com/2008/04/twmba-district-maths-teachers-assoc.doc")[#text("https://terrytao.files.wordpress.com/2008/04/twmba-district-maths-teachers-assoc.doc")]

#text("However, the administrators are focusing purely on the numbers of students enrolling into maths, rather than the quality of the education these students (and the much larger body of students receiving maths service education) are receiving. The research output of the department, by the way, is being completely discounted (as stated explicitly in the rationale for the cuts). So the problem here is not poor teaching or poor research; it is narrow and bureaucratic thinking within the administration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57aaf675b85cf0a68ef32d616876a9071ef3f9e520a72cc49f564958ed2955c2-3b7fb47521d028a75742178285a17af93241b03dda3f00d35a53f5b99b84fd3c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zac")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29402")[#strong[#text("Zac")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2008")])]

#text("So you mean it is not going to be worth looking for a mathematics job in an Australian university when I return (because such jobs will have become extinct)?")

#text("Perhaps I’ll stay here in Singapore where they have already set up a ")#link("http://www.highsch.nus.edu.sg/")[#text("High School of Mathematics and Science")]#text(" (which is affiliated with one of the universities here) and they are in the process of setting up a new ")#link("http://www.sst.edu.sg/")[#text("School of Science and Technology")]#text(" which has applied mathematics at its core (I am on the mathematics advisory committee for this school).")

#text("Could all this contribute to Singapore’s pre-eminent position in mathematics? I certainly think so.")

#text("Killing the Australian math goose is not a good idea.")

#text("All the best with your campaign.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d01d3930b74ab9b1761c0c91e7cb5cb52d0dcb1dafe63a89bca01b824cab0cf4-b540807accb663f8cf3e9d4b7c155933d073e9207199bac170fe578107bbbafb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Imre Bokor")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29578")[#strong[#text("Imre Bokor")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2008")])]

#text("There are disciplines, such as philosphy, without which no institute is a university.")

#text("There are disciplines, such as physics, chemistry, statistics, mathematics, and today, computer science, which are indispensible to other disciplines, even if they do not attract large numbers of students, whose primary interest are in these disciplines.")

#text("As a consequence, the student enrolment patterns in these subjects are strongly pyramidal, and “managers” use this as an excuse to undermine these disciplines, which are also the ones students find hard. “Managers” often propose the view that it is not necessary to have experts in a subject teach service courses: they know too much. The fallacy of such a view is easily exposed by the question: “Would you be happy to have your twelve-year-old child taught English by someone whose grasp of English is that of a twelve-year-old-child?”")

#text("Even a cursory look at history teaches that progress in the applied sciences and engineering has always been through application of new developments in the “basic” sciences or through new applications of the “basic” sciences. This is why engineers need experts in statistics, not engineers, to teach them statistics.")

#text("Most importantly, an expert knows what can be safely omitted in a first course without misleading students, without making things harder for them later. You present the crucial ideas, omitting purely technical problems until they become unavoidanble. Such economy of exposition is not available to non-experts.")

#text("The situation with teachers is even more dramatic. It has been argued by university “managers”, that school teachers of mathematics and science have no need for a degree in the disciplines, just enough “units” to meet the minimum required by State Education Ministries. This attitude poses a grave threat to society at large, for the current minimum requirements have been reduced from previous ones as an emergency measure to legalise the filling of vacancies in properly qualified science and mathematics teachers by underqualified ones. Aiming for the bare minimum is a guarantee of declining standards.")

#text("Even worse is the effect on school pupils. Very few recently trained high school mathematics teachers could read an overview article on mathematics, at least in Australia. Dieudonne’s “A Panorama of Pure Mathematics” appeared in English in 1982, and few “mathematics education” graduates have even a vague inkling of the meaning of the chapter titles.")

#text("It is simply impossible for anyone who does not have even a vague overview of the state of mathematics 25 years ago, to generate interest in the subject, not to mention inspiring students. When students ask, as they so often do, where mathematics is heading, where is it used, such teachers have no access to a reasonable answer.")

#text("It has recently been argued that since what is taught in mathematics at high schoools was already know 200 years ago, there is no need for teachers to learn more recent mathematics. I cannot conceive of any other subject, other than pre-French Revolutionary history, where it would be seriously proposed that there is no need for teachers in the 21st century to know nothing that was not known at the end of the 18th century.")

#text("The vicious circle needs to be broken. Only universities can do this, by ensuring that intending teachers are exposed to current developments in their disciplines. That is impossible without a degree in that discipline. At a typical continental university, intending high school teachers do the same courses as intending researchers in mathematics, physics, chemistry. It is the intending engineers, etc. who do less. Even they do more than school teachers do in Australia. Look, for example, at the degree programme of agriculture students in Switzerland:")

#link("http://www.agrl.ethz.ch/docs/WL_AGW_E.pdf")[#text("Click to access WL_AGW_E.pdf")]

#text("Why are maths teachers in Australia not required to know as much mathematics as agriculture students in Switzerland?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d6401d6720b3c7333421b6043e0d6f2c233a0de5a7cec5717e1203988787815-419b68a1d48226f6c1208c72070d4ab2f2488807207c6fe83474a1913bcdb5d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr. Potatohead")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29621")[#strong[#text("Mr. Potatohead")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("People are getting carried away here. It is not just maths that ought to be shut down an USQ, although I feel for those threatened with loss of employment: Going by available evidence, e.g. the Melbourne Institute rankings report, USQ—yes, the whole university–is one of Australia’s junk universities and ought to be shut down or converted into a TAFE.")

#text("That aside, a major problem with maths is Australian universities is the dumbing down of related areas in which maths should play a role. In my uni, all of physics, chemistry, engineering disciplines, and computing have all seen maths courses either cut out completely (computing) or reduced to levels that are a joke; apparently anything too hard for unprepared students who are unwilling to learn had to go. Computing in Australia has particularly suffered: During the dot-com boom, many unis, mine included, introduced some soft-headed mash they called “information technology”, which produced graduates who should never be let anywhere near a computer. (I, sadly, “taught” and still “teach” many of them.) Fortunately, with these sorts now on the unemployment line, as employers want serious people, computer science seems to be reviving.")

#text("What is particularly sorry about the USQ affair is not the threatened cuts but that they come at a time when even the Federal government is going on and on about maths and sciences in Australia. It seems that university managers are simply not listening. Ironic too that in many of the universities outside the Go8, mathematicians and physical scientists are among the very groups that actually do any serious work. I would encourage people to look at the backgrounds of some of these managers—their academic qualifiations, their research record, publications, etc. I suspect you will find many surprises and flakes who actually have very little idea of what scholarship means. Start with USQ.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7474c352f27fae58377382c5c2b33b9ca8dc27cb987051d9c99939032c15b696-9cf1d48ae4a5c7c895d9f477a6bd4563d418d51c4ca907a803bf84611e66f92f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An Mu Shi")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29623")[#strong[#text("An Mu Shi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2008")])]

#text("Here in Asia (e.g. Korea, Japan, Singapore, etc.) math, in general, thrives, for two reasons: (a) It is recognised that that this is an important area that must continue to exist even if it does attract as many students as more popular areas. In other words, “subsidising” the area is, if necessary, understood to be a good thing. (b) In areas where math is an important component, we simply insist that students take the math courses. We do not let them have any say in the matter, nor are we prepared to dumb down things. Those who don’t like that approach are encouraged to go elsewhere. Increasingly such elements choose Australia.")

#text("I am also not conivinced, from everthing I have read about the USQ case, that the financial situation is that dire. So it would not surprise me if USQ suddenly managed to find some extra money elsewhere. Don’t ask why they did not look in the first place.")

#text("Lastly, to USQ: Keep in mind that there is a research assessment coming, and universities such as UQS already don’t look too hot in that regard. What group would do better? The 10 maths lecturers or the 30 or whatever nursing lecturers and their zillion students? Regardless of that, it seems to me that competent university administrators ought to take long-term views and not just a 2 or 3-yr budget plan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d6401d6720b3c7333421b6043e0d6f2c233a0de5a7cec5717e1203988787815-419b68a1d48226f6c1208c72070d4ab2f2488807207c6fe83474a1913bcdb5d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr. Potatohead")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29635")[#strong[#text("Mr. Potatohead")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2008")])]

#text("Anonymous wrote: “The logic is that what I can see the value that humanity gets from reserach by a brilliant mathematician, it gets much less value from reserach of half a dozen merely good mathematicians. (This maybe different from what happens in some other disciplines: half a dozen of good reserachers in life sciences or computer science seem to provide great value to humanity today.)”")

#text("Fair enough. But in that case, why not start the cull with the humanities, social “sciences”, etc.? Even a dozen brilliant ones in some of those fields produce zero value for humanity. Once we are done with them, we can get to maths. The cuts to maths will only make USQ less of a serious university, and it is already in trouble on that front.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7474c352f27fae58377382c5c2b33b9ca8dc27cb987051d9c99939032c15b696-9cf1d48ae4a5c7c895d9f477a6bd4563d418d51c4ca907a803bf84611e66f92f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An Mu Shi")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29642")[#strong[#text("An Mu Shi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2008")])]

#text("“eliminate the majors in mathematics, chemistry, physics, and statistics, and phase out all non-service courses”")

#text("Did anyone else find this funny for a Faculty of Sciences that includes nursing, midwifery, and psychology? By the way, is it the Australian norm to have these in such a Faculty?")

#text("A clarification of my earlier posting: Many science and engineering students who can’t hack the maths here in Asia seem to end up in Australia, but many are increasingly waking up to the fact that (save for a few who make into the Go8), employers here don’t think much of them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b21e7d8a90409ba78d22e0259a5491f582f815615e85aba36a4870d007ae2fb0-411bc9a811cc2aff3e9c733619a1c7802760b1e0afad902f97dfe3f36cc45e2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Flinders Guy")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29647")[#strong[#text("Flinders Guy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2008")])]

#text("Going by the USQ blurbs, hiring Prof. Verbyla was a big win for USQ. It was a big win for Flinders too. Nothing like a win-win situation, eh? You have been given good advice: talk to engineering stuff at Flinders if you want a difference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29785")[#strong[#text("An update on mathematics, statistics, and computing at USQ « Mathematics in Australia")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2008")]

#text("[…] 12 members (almost 50%). More details on this are at the campaign page to support maths at USQ, my own post on this at my other blog, and at my editorial at the Funneled […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/05/please-help-support-mathematics-at-the-university-of-southern-queensland/comment-page-1/#comment-29834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("@Greg Kuperberg:")

#text("You are talking about the University of California system which is still quite good. Don’t let that corner case delude you into thinking that this is the case everywhere.")
]
