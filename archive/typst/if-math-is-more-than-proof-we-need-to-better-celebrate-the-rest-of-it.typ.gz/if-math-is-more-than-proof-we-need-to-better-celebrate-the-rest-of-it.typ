// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/
// Converted to Typst by tao2typ: "2026-10-19T13:40:30.413209+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "If math is more than proof, we need to better celebrate the rest of it", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("If math is more than proof, we need to better celebrate the rest of it")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")[#text("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-19 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.3blue1brown.com/")[#text("Grant Sanderson")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("A sentiment echoing throughout the mathematics community right now is that solving problems and generating proofs have always served as proxies for the true goal of mathematicians, which is to further human understanding. When proofs can be generated without that understanding, it undermines their value as a proxy.")

#text("This immediately raises a question: What other proxies should we use instead?")

#text("I want to propose that we more firmly define a notion of a “motivated explanation” and that we give novel and compelling motivated explanations academic credit similar to what generating new proofs of open problems has had historically.")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2026/09/image-1.png")[Original image]]]

#text("Further, I believe this is an important step to help those outside of math better understand what it is that mathematicians contribute. If outsiders believe that proof-generating machines render mathematicians obsolete, while insiders see that as a misconception of what researchers add, it’s incumbent on this community to better project its true values through the kind of work that it rewards. Outsiders can be forgiven for this misunderstanding if the work most celebrated skews heavily toward generating proofs, while clarification and exposition are treated as second-class.")

#text("I should acknowledge up front an obvious personal bias. I have a non-traditional career in math, focused on producing videos about the topic. This shares the goal of “furthering human understanding”, but my focus has been on explanations and intuitions that resonate with the public, not on solving outstanding problems. A cynic could easily read this proposal as shamelessly self-elevating.")

#text("As a practical matter, though, my own career and funding exist outside academia, and I have no skin in the game for what this community assigns credit to. Moreover, in proposing that we elevate the status of motivated explanations, I don’t mean popularization. I mean any work which primarily aims to answer the question “how would you think of that?”, even if the subject matter requires deep expertise to appreciate.")

#text("The examples I highlight below show this is nothing new. Practicing mathematicians already devote a meaningful amount of mindshare to work like this. The proposal here is mainly to 1) more clearly define this work, and 2) elevate its status.")

#strong[#text("What defines a motivated explanation?")]

#text("Although it might be clear what this phrase “motivated explanation” is intended to mean, it’s worth briefly contrasting it with proof.")

#text("In a proof, definitions sit at the start. It is common and expected to begin with a new construction and proceed by analyzing its properties.")

#text("In a motivated explanation, definitions sit in the middle. New constructions are only allowed to enter the vocabulary if the problem they are addressing has been clearly established.")

#text("In a proof, all statements must be correct, each claim following as a necessary implication from what comes before.")

#text("In a motivated explanation, it is okay and often desirable to start with an idea that is not quite right and requires correction, but whose origins are relatable.")

#text("A genre of motivated explanation I’m fond of is “discovery fiction”, a term coined by Michael Nielsen. You develop an idea with a narrative that starts with a simple-but-wrong solution to a problem, see where it breaks down, fix that problem, discover a new problem, and so on.")

#text("The scope of a proof is to explain why a particular theorem is true.")

#text("The scope of a motivated explanation is not only to clarify why a theorem is true, but why the theorem is the right one to pose in the first place, and how it is used in the surrounding context.")

#text("One clear shortcoming of a motivated explanation is that its validity is not binary the way a proof’s is. This is a big reason proof is so useful a way to measure progress: You can clearly define what does and does not have a proof yet. There will never be Lean for motivated explanations.")

#text("If we’re serious about the goal of advancing human understanding, there’s no way around the fact that this aim is intrinsically squishier than that of finding proofs, because defining human understanding itself is squishier. To shy away from metrics which are more subjective is to shy away from the more human aspects of the field.")

#text("The reason I’m leaning on the word “motivated”, as opposed to other potential choices like “lucid” or “demystifying”, is that this is a more verifiable property. It’s not quite as rigidly verifiable as a proof; almost nothing is. But it’s enough to be a practical measure. In my own work, I often repeat the phrase “I want this to feel like you could have discovered it yourself”. I say this not just to placate a viewer, but because it’s an actionable guideline for myself to assess whether an explanation feels complete or not. For each new idea introduced, you can ask whether it’s clear where that idea comes from. The answer is not quite a binary yes or no, but it’s close enough for practical purposes.")

#strong[#text("Exemplars of motivated explanations")]

#text("One of the best repositories I can think of for motivated explanations is Part IV of the Princeton Companion to Mathematics. It covers over two dozen active fields of research, each one introduced by an expert with a talent for clear communication.")

#text("Whether it’s Andrew Granville explaining analytic number theory, or David Ben-Zvi introducing moduli spaces, these articles offer a level of intuition and motivation more typically found in one-on-one conversation at a blackboard.")

#text("The background on this book is noteworthy for the present discussion. It was edited by Timothy Gowers, who discusses it in ")#link("https://www.numberphile.com/videos/podcast-timothy-gowers")[#text("his interview on the Numberphile Podcast")]#text(" with Brady Haran. Having been asked what impact the Fields Medal had on his life, here’s what he had to say:")

#emph[#text("People who’ve got Fields Medal feel freer to do slightly different things…for example I took on editing a book called the Princeton Companion to Mathematics, which was an absolutely massive task. It took I would estimate half my working time for about five years or something like that…It was a project I believed in and possibly wouldn’t I probably wouldn’t have actually been offered the chance to do it if I hadn’t been a Fields Medalist.")]

#text("He was right to believe in it; this work adds tremendous value to the field of math, but it seems a shame to me that one requires a Fields Medal to feel justified in spending time on it.")

#text("Another example of someone exceptionally talented at writing proofs, but whose contributions extended far beyond proof, is Bill Thurston. His deservedly famous essay ")#link("https://www.math.toronto.edu/mccann/199/thurston.pdf")[#text("On Proof and Progress in Mathematics")]#text(", though written three decades before LLMs, opens by suggesting that the right framing of the question “What is it that mathematicians accomplish?” is to ask “How do mathematicians advance human understanding of mathematics?”")

#text("Here’s one section with uncanny resonance with today:")

#emph[#text("The rapid advance of computers has helped dramatize this point, because computers and people are very different. For instance, when Appel and Haken completed a proof of the 4-color map theorem using a massive automatic computation, it evoked much controversy. I interpret the controversy as having little to do with doubt people had as to the veracity of the theorem or the correctness of the proof. Rather, it reflected a continuing desire for human understanding of a proof, in addition to knowledge that the theorem is true.")]

#emph[#text("On a more everyday level, it is common for people first starting to grapple with computers to make large-scale computations of things they might have done on a smaller scale by hand. They might print out a table of the first 10,000 primes, only to find that their printout isn’t something they really wanted after all. They discover by this kind of experience that what they really want is usually not some collection of “answers”—what they want is understanding.")]

#text("The essay itself offers a beautiful articulation of what the practice of doing math is beyond generating proofs. I want to draw your attention to what he writes at the end.")

#emph[#text("I have put a lot of effort into non-credit-producing activities that I value just as I value proving theorems: mathematical politics, revision of my notes into a book with a high standard of communication, exploration of computing in mathematics, mathematical education, development of new forms for communication of mathematics through the Geometry Center (such as our first experiment, the “Not Knot” video), directing MSRI, etc.")]

#text("Again, why should these “non-credit-producing activities” follow a Fields Medal, and not contribute to it?")

#text("On a personal note, one product from the Geometry Center he referenced had an especially meaningful impact on me when I was younger. It was a short film called ")#link("http://www.geom.uiuc.edu/docs/outreach/oi/")[#text("Outside In")]#text(", perhaps the earliest example of a viral video about substantive math, visualizing the key idea of Thurston’s own construction for sphere eversion.")

#text("An original proof that showed an eversion must exist, say Smale’s, advances human understanding in the sense of going from 0 to 1. A video like this which gets millions of people to engage with the underlying idea, advances it in the sense of going from 1 to N. I’m grateful that Thurston spent so much time on this “non-credit-producing” activity.")

#text("Another relevant paper is Timothy Chow’s ")#link("https://timothychow.net/forcing.pdf")[#text("A beginner’s guide to forcing")]#text(". Not only does the paper itself offer a prime example of a motivated explanation, but its introduction offers helpful vocabulary around it.")

#emph[#text("All mathematicians are familiar with the concept of an open research problem. I propose the less familiar concept of an open exposition problem. Solving an open exposition problem means explaining a mathematical subject in a way that renders it totally perspicuous. Every step should be motivated and clear; ideally, students should feel that they could have arrived at the results themselves.")]

#text("What would it look like for these open exposition problems to be treated similarly to open research problems? As an extreme case, we might imagine what it could look like to have an analog of the Millennium Prize Problems for open exposition problems. An institution or group of researchers would formally define mathematical results they see as important, and which are not yet well understood despite technically having proofs. At the moment, every AI-generated proof is born an unsolved exposition problem. As such, it seems likely the next few years will see a flood of them, and it will be valuable for leaders to clarify which ones deserve focus.")

#text("A rubric would have to be agreed upon for what constitutes a resolution to an important unsolved exposition problem. Again, this is intrinsically more subjective than verifying a proof, but any serious engagement with the more human aspects of math necessarily wades into this kind of subjectivity. And again, I’ll emphasize that checking whether key ideas are motivated is not unlike checking whether the steps of a proof follow logically.")

#text("If the world outside of math sees its leading figures treat open exposition problems with the same seriousness as they treat open research problems, it could go a long way to correcting misconceptions about the role of mathematicians.")

#text("The last example I’ll highlight is one that may better foreshadow things to come.")

#text("In April of this year, Liam Price submitted a solution to Erdős Problem 1196, sometimes called the asymptotic primitive sets conjecture. The solution came from Price’s interaction with GPT-5.4 Pro. Unlike many earlier Erdős problems which had been resolved with help from AI, this is one that those in the field had found both important and elusive. Stories like this are increasingly familiar these days, but at this point in the story, despite a proof technically existing, human understanding had not yet been advanced all that much.")

#text("The proof made its way to Nat Sothanaphan and Jared Lichtman, who were able to interpret what the AI’s approach was and clean up the proof into a human-readable form. In May, Boris Alexeev, Kevin Barreto, Yanyang Li, Jared Duker Lichtman, Liam Price, Jibran Iqbal Shah, Quanyu Tang, and Terence Tao put out ")#link("https://arxiv.org/abs/2605.00301")[#text("a paper")]#text(" which expanded on the key idea underlying the proof. The authors explained how that key idea clarified not only the original problem, but many around it, for instance offering a cleaner proof of the Erdős Primitive Set Conjecture.")

#text("The value here is not that one more Erdős problem could be ticked off as solved. The value lies in the fact that our understanding of primitive sets is notably cleaner and more satisfying now than it was at the start of 2026. The original problem solution played some role in this, but arguably the work that deserves more celebration is this paper expanding, clarifying, and contextualizing its key idea.")

#strong[#text("Practical calls to action")]

#text("At a pragmatic level, what would it look like for us to elevate the status of a motivated explanation? Here are a small handful of suggestions.")

#list(
[#text("A PhD advisor can still assign a small problem from their field for a new student to cut their teeth on, but the deliverable would not be to write up a solution; it would be to present that solution to peers and faculty as a talk. It could be an already-solved problem which lacks clarity, or perhaps it’s a problem that lacks a solution, and the student uses AI to help find it. In either case, the student knows that on a certain date they have to understand it well enough to explain it, and that the desired output is for others to understand it as well. In short, even small problems could be treated like small PhD defenses.")],
[#text("A leading figure (cough, Terry, cough) could enumerate a modern analog of Hilbert’s problems, instead focusing specifically on unsolved exposition problems. What areas are both important and lacking in the deeper understanding we desire?")],
[#text("Written standards could clarify what constitutes a motivated explanation, aiming to make it nearly as verifiable as proof, so that the resolution of unsolved exposition problems can be recognized and celebrated in the same way proofs of open problems can be.")],
[#text("Journals can be established which focus more explicitly on making results understood more widely throughout the mathematics community. ")#link("https://www.mathematicaldiscourse.org/about/")[#text("Mathematical Discourse")]#text(" offers an interesting new example in this direction.")],
[#text("Hiring and tenure decisions could place a higher value on writing great textbooks and similar work. Think of the AMS Steele Prize for Exposition, but at a more granular scale with an emphasis on early-career contributions in this vein.")]
)

#strong[#text("The value of visible cultural shifts")]

#text("I’d like to close with a broader pitch that visible culture shifts in math carry an intrinsic benefit ")#emph[#text("right now")]#text(" with respect to the external image of mathematics as a career.")

#text("Many young students who are otherwise passionate about the field are afraid to pursue it now due to the uncertainty of what happens in an age of proof-generating machines. However, framed correctly, this is one of the most exciting times to go into the field, because there is nothing more exciting than entering a field when it is malleable and you have a chance to actively shape what it will look like in the future. Even if we completely set aside any potential benefits from AI to help with our understanding, young prospective mathematicians should feel energized knowing that they are entering at a unique point in history when they might play a real role in determining what the field as a whole looks like.")

#text("However, change like this is only exciting when it feels deliberate, whereas it feels terrifying if it seems driven by forces outside your control. As such, tangible action from the field’s leaders now to help define and clarify what the field is will reassure young entrants about who is in the driver’s seat, and that the status of the career does not depend on what entities produce the proofs.")

#text("Similarly, I also believe this is one of the best times to fund math. If the next chapter of math is ushered in by the drumbeat of two words “human understanding”, whatever changes are about to happen seem likely to amplify math’s value as a public good.")

#heading(level: 1)[#text("Comments (88)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695681")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Great post Grant! ")#linebreak()#text("Btw, couldn’t professors use AI to write textbooks if tenure depended on this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695683")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("“Hiring and tenure decisions could place a higher value on writing great textbooks and similar work.”")

#text("I don’t like this. Again, Bourgain?")

#text("Clearly you want to reward people who can prove interesting things with the models. Great mathematicians ill be able to prove more with the models than others.")

#text("Terry is a great expositor and the world’s leading mathematician (I guess you could make a case for Scholze but I’d go with Terry) but is not be the world’s best expositor (I mean this literally, he’s great, but “world’s best” is a really high bar). If Terry had been growing up nowadays, would we not want him to stay in math, or would we recognize him as good but not tippy top?")

#text("Terry plus the AI will prove many more interesting and enlightening theorems than person X plus the AI.")

#text("With Bourgain it’s an even bigger deal. Again do you want the next Bourgain to go right to industry? I don’t want this at all. Bourgain plus an AI will do a lot more than the AI by itself.")

#text("Exposition also may well become a solved problem. I don’t see why future AI’s cannot improve at this.")

#text("Essays like this make me extremely uneasy. You could imagine a world where hiring decisions become extremely subjective and political.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695746")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I would argue that Jean’s somewhat infamous focus on problem solving at the expense of exposition was a *consequence* of the incentive system of the era, rather than a *justification* of it. From my personal interactions with Jean, I know that he was perfectly capable at exposition or outreach in various media, from private conversations to public lectures. To give just one example, I offer ")#link("https://www.youtube.com/watch?v=gbRnLrlpLPo")[#text("the video profile of Jean for the 2017 Breakthrough Prize")]#text(".")

#text("In fact I would assert that if the incentive system in the days of Jean’s early career had transferred some of the weight assigned to raw problem solving to that of exposition, that Jean, having adjusted his writing style accordingly, would in fact have had even *more* of an impact on mathematics (and the broader community) than the (considerable) amount he does today.")

#text("Speaking personally, my own views on exposition were heavily shaped as a graduate student both by Thurston’s widely known essay (which came out at that time), as well as the amazing textbooks and lectures of my advisor, Elias Stein. Had I instead started my studies in Bourgain’s era, I may well have adopted a similar writing style to Jean in his early days, for better or for worse.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695806")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("That’s fair.")

#text("I do think and hope that AI will get better at exposition.")

#text("But I think and hope that AI will enable us to push mathematics to new heights. I like your suggestion about a PhD thesis proving hundreds of results and noting statistical patterns in them. What makes some problems true and some problems false? Is it easy to tell? I wonder if this is how we will ultimately prove P=/=NP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695808")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I worry a bit about an overemphasis on exposition. I think it’s OK if there is a ton of mathematics and we don’t quite digest all of it. Just knowing whether many conjectures are true or false without knowing exactly why could be super helpful, and could advance our understanding of mathematics in a lot of ways. Again I think we could prove many interesting and deep theorems with an oracle that was able to just solve open conjectures with some high confidence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695893")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("“You could imagine a world where hiring decisions become extremely subjective and political.”")

#text("They already are. One regularly sees less well-qualified individuals getting jobs over better qualified ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696045")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Definitely. But it could happen to an even greater extent.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695684")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("When you write things such as “Hiring and tenure decisions could place a higher value on writing great textbooks and similar work.”, it implicitly assumes that AI will not be better than humans at writing these, but I think we can not assume this. Thus, your suggestion does not really solve the problem of hiring decisions and assignment of credits.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695753")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("It doesn’t solve it, but at least it positively aligns the outcome (one hopes) with what mathematicians are claiming to be the goal of human mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695686")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Thurston’s essay “On proof and progress in mathematics” has been brought up a lot on this blog. It is frequently cited positively. So that we do not create a false memory of the content of that document, let us not forget that part of the genesis of that document was so that Thurston could talk about his own role in creating proof indigestion that had serious consequences in the community (e.g., “Within a couple of years, a dramatic evacuation of the field started to take place.”). Terry has quoted some of that material recently ")#link("https://terrytao.wordpress.com/2026/09/07/finite-time-blowup-with-smooth-forcing-term-for-the-incompressible-porous-medium-boussinesq-and-incompressible-euler-equations/comment-page-1/#comment-694396")[#text("on this blog")]#text(".")

#text("There is another vexing aspect of that article that I have not heard mentioned yet on this blog, namely the elephant in the room that Thurston was the beneficiary of a massive amount of privilege. He received professional credit at the highest levels for results that he did not share complete written proofs of. Those results had to wait for decades for others to write the proofs. That is a true privilege, which many professors would like to have but do not, to receive professional credit for results that you claim without also having to spend the time and effort to write proofs. Writing is hard for everyone. The reason this is an “elephant in the room” is that the essay does not address it, even though it was a key component in the two incidents of proof indigestion that he discusses.")

#text("Perhaps it’s not fair to judge the essay, written in 1993, for not acknowledging privilege. That judgment is certainly on the table if we are going to lionize it in 2026.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695739")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Not sure if I can quite follow you on the privilege topic: Are you actually implying that everyone should use every opportunity to disclose the privilege she is enjoying? Then all of us here would just be talking all the time about being privileged instead of discussing the actual topic at hand. Also, sadly, it doesn’t seem like you talked enough about your being privileged in your message above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695897")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Ironically, the above comment is very misleading about the contents of the essay.")

#text("The essay was written in response to an article of Jaffe and Quinn that (in passing) criticized Thurston’s work on geometrization for Haken manifolds as lacking a sufficiently rigorous proof. Thurston argued that his main contribution *was not* the formal proof of the geometrization conjecture in a special case. Rather, it was in communicating the ideas behind the proof: by getting topologists interested in hyperbolic geometry, and connecting the communities interested dynamical systems and low dimensional topology.")

#text("The quote ")#emph[#text("“within a couple of years, a dramatic evacuation of the field started to take place,”")]#text(" is from an earlier episode in Thurston’s career on foliations.")

#text("The analysis of privilege above is circular. The reason that Thurston is so famous today (even amongst Fields medallists) is because of the extraordinary amount of mathematical activity that this second period provoked. This was not a case of proof indigestion! (Unlike the case of foliations).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b144706100f1dcbea7105fec2e6c20259668ee807d169b10fb0188ca3ff14b34-74d70e9678e660054cc0192280829e87fdb204b5cdfa019af599da07e946d903.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuxin chen")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695688")[#strong[#text("yuxin chen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I wholeheartedly agree with your opinion. I propose here a first candidate for your ‘Millennium problem list’ in terms of providing a motivated explanation: the classification of finite simple groups. My reasons are as follows:")

#text("1: the basic concepts are accessible to general public. This makes it a good starting point to engage general public into deep and profound research mathematics. It also helps to convey the idea ‘mathematics is not only about proof, but also about human understanding’. When the problem is not very complicated (which is the case for almost all mathematics problems encountered by people outside of professional math), it is hard to distinguish between ‘proof’ and ‘understanding’. It is when the complexity of problem exceeds a critical point that these two things start to look different.")

#text("2: the proof involved many profound mathematics of different areas, and as far as I know, many professional mathematicians don’t fully understand the proof either. Many people are interested in the proof (including me), but are unable (and have no time) to navigate thousands of pages of papers with technical details only very few experts are familiar with. This project does not only bear pedagogical benefit of general public, but also can enhance the understanding of professionals.")

#text("3: there is a real danger that the proof will become a ‘lost craft’ as the experts who really understand everything gradually retire. Many people feared that in an AI dominated future, the whole mathematics will be a ‘lost craft’. But if we have to save entire mathematics from such fate, why don’t we try something easier first? Why don’t we try to rescue classification of finite simple groups from oblivion?")

#text("4: this will be a valuable rehearsal of a very plausible future where we have to decode long and convoluted AI proofs. People keep arguing that machine will produce complicated proofs that are not understandable to humans, but from my point of view, humans have already been doing this for a long time, just in a smaller scale. If we can somehow provide a ‘motivated explanation’ of classification of finite simple groups, we will be better prepared when AI produces a thousand-page long resolution of the Riemann Hypothesis.")

#text("5: this project is obviously very challenging, and requires mass cooperations within and beyond mathematics community. But this is exactly what a ‘Millennium problem’ suppose to inspire.")

#text("I would also like to provide a final remark, which is kind of irrelevant to this particular post. It’s very good to see so many philosophical discussions among mathematicians. But what we need the most, I think, is action. When an earthquake strikes a city, the government has to react within hours. Research mathematics don’t have a central government, but since the impact of AI on it possibly exceeds any earthquake can have on a city, we need to react as fast as possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a359b4b55d633aec44076c9dcea628d140c3963a788710e2c89f28422110d562-0cf7e0e2aa7a0577b150f1a4ca5dc32561813ca6e9187fd5b3020db477d9d51b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tchow8")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695857")[#strong[#text("tchow8")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("A potential starting point would be to offer more support (if it is needed) to Lyons and Solomon, so that the final volumes of the GLS project will be published as soon as possible. In my opinion, before we embark on a third-generation proof, the almost-finished second-generation proof should be brought to a successful conclusion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696496")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Arg. I lost my long comment. tl;dr yes. But then also a semester- or year-long program on the proof to really communicate it and try to understand it better, and recruit new people to the field, to get the 3rd gen proof going. cf Univalent Foundations special year at IAS.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695689")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("“there is nothing more exciting than entering a field when it is malleable and you have a chance to actively shape what it will look like in the future.” I could not agree more. However, it is likely that AI can or will do the bulk of the motivated explanation too once a result is known. The actual process of discovery, setting new rules or axioms, modelling unknown situations, and creativity are what will set mathematicians apart in my view. These are hard to teach, but humans excel at this part and will probe nature (including the mathematical universe) based on intuition and it is not sure that AI will reach that stage fast. The creative breaking of boundaries to pursue new mathematical areas (perhaps in combination with motivated explanation by a human or AI) is rarely taught in mathematics departments (or schools for that matter) and motivated explanation forms part of this of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695690")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#align(center)[

]

#text("Jacob Tsimerman claims we’ll have superhuman expositors by April, so then what hehe? (video is timestamped url)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695715")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Suppose we have “superhuman exposition” by April, but eventually no communities of practice because humans essentially never share mathematics face-to-face. Is there really a reason to engage with such exposition if it will not be brought into a human conversation? One has to also think of the reason we have the exposition in the first place. I do not think this question is vulnerable to the “AI cannot do this *yet*” critique, since in the end humans and their communities are ends and not means.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695725")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I am amazed how AI pilled some people can be. To Tsimerman’s point that “AI will be best expositor”, I say that what is “best exposition” depends highly on the human learner who is trying to ")#strong[#text("understand")]#text(" math. Further, there is no evidence that the exposition effectiveness function is static (or even well-defined) and will stop needing human input as time progresses or new material is developed. That is why it is important to focus on primarily benefits and encourages human understanding of math rather than machine understanding. I am all if AI can help us with this goal rather than get in the way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695756")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("AI is more capable than human to customize and personalize expositions. Humans write books “for all audiences”, but AI can write something just for you, based on past interactions with you and its knowledge about your taste, style, level, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695955")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Let me use an analogy. Let’s say there’s an AI which can make a movie to fit all my tastes. I would still watch other movies done by humans, because they can do things which I would not even have considered to like. In the same way, I would like to know how other mathematicians think about a subject.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695696")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I contend that it was not really generally true that “true goal of mathematicians […] is to further human understanding.”")#linebreak()#text("If you are saying that this might now be the only way human mathematics survives, I can agree.")

#text("But let’s be honest, it has not been often the case up to now. In many cases mathematicians care(d) a lot about how intelligent they appear to the world. ")#linebreak()#text("Del Ferro and Tartaglia kept their formulas a secret to be used in contests, Gauss was said to erase his tracks as a fox, and even in our times many write mainly (for career and) to show that they solved a very difficult problem and they are intelligent. In some cases even worst than that: the more obscure the proof looks to others the more they feel intelligent.")

#text("Mathematics has always had a flavour of contest about who is smarter, with proliferation of fields and problems to allow more and more people to play the game. Usually paid, in most cases with public money.")

#text("I liked it a lot, don’t take me wrong. But honestly, I think the first step is not saying that the goal had always been “further human understanding”, but that this might be the only goal which matters from now on.")#linebreak()#text("I suspect the contest about who does this better will be in any case a relevant aspect for the community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695699")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("From the article: “However, framed correctly, this is one of the most exciting times to go into the field, because there is nothing more exciting than entering a field when it is malleable and you have a chance to actively shape what it will look like in the future.”")

#text("Thank you for this insightful article!")

#text("Am I right, if I summarize the main proposal as to give more material value to the arts/literature aspects of mathematics, while traditionally we gave most values to its scientific/engineering aspects?")

#text("I agree with this idea, and hope we soon find good practical ways to carry it out!")

#text("At the same time, the scientific/engineering aspects of mathematics can also be amplified as well. With the developing AI tools, we can handle the next level challenging problems that we were not being able to even dream. Vision is important here, to know what to aim.")

#text("Also, echoing the author, I think that now is a great time to enter into applied mathematics, as the massive help of AI can let us more effectively approach the really challenging problems that the society is facing for its survival, such as climate change, sustainable economy, pollutions, stable politics, and AI safety, etc.")

#text("I think we also want to look outside of us, although for us as mathematicians, it is really important to sustain our community to preserve and enhance one of the most interesting and valuable human activities. From my personal experience, I know that often the inner problems are solved when we look at outside. Maybe we, as mathematicians, also want to ask, “What can we do AND what we want to do, with our mathematical strength and with the AI tools, to help the society wisely face the challenges (some caused by AI) for its survival?” Maybe it is the time, we, mathematicians, can make more impactful and direct contributions to the society for its benefit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405e1d672c0ab83f1d84482438fbc82652da4b21362c53de0422d09daa52f36c-53f5f0374f5de6e4d825657aeaa8fb1b4adfcda92e0c82cbcb55bcb9224e8536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695701")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("“A PhD advisor can still assign a small problem from their field for a new student to cut their teeth on, but the deliverable would not be to write up a solution; it would be to present that solution to peers and faculty as a talk. It could be an already-solved problem which lacks clarity, or perhaps it’s a problem that lacks a solution, and the student uses AI to help find it. “")

#text("Imagine you’re a smart ambitious 20-year old. Do you find attractive an education path that requires several years of undergraduate learning and then a PhD, which consists mostly of reading AI slop and solving “exposition problems”, and after which it’s not even clear there’s going to be a career? Where is the sense of fun, empowerment and satisfaction in that? The answer is, of course, there is none, or very little. Consequently, young people will simply choose different fields (assuming these won’t also be swallowed up by the Moloch). This is a point I find missing in most discussion of the seismic shifts in the field.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695734")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("thanks. This is a very good point. A lot of very talented and highly driven people go into mathematics. If you tell them that their primary job is now exposition imagine how badly the community has let those young people down.")

#text("If such a situation is forced on the young people we should no longer expect a younger generation working actively in the area")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695750")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("No, there will always be very talented and highly driven people going into mathematics. Only those whose sole talent is hand-solving problems will be no longer needed in the field, just like prodigious mental calculators were needed in the 19th century but not the 20th. So what?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405e1d672c0ab83f1d84482438fbc82652da4b21362c53de0422d09daa52f36c-53f5f0374f5de6e4d825657aeaa8fb1b4adfcda92e0c82cbcb55bcb9224e8536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695760")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("No. If you’re talented and highly driven, you want to create something by yourself. In business, in art, everywhere. If the whole job becomes “digesting slop”, there is very little space for creativity left.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695737")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I’ve seen you post this kind of comment elsewhere. Why would hand-solving obscure problems be the only thing smart, ambitious 20-year-olds be interested in doing? Lots of very bright people go into academia in a variety of fields which don’t require hand-solving problems.")

#text("Those allegedly smart, ambitious 20-year-olds who stake their entire identity on hand-solving problems always seem to be the first to leave for industry, where they’re happier anyway.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/405e1d672c0ab83f1d84482438fbc82652da4b21362c53de0422d09daa52f36c-53f5f0374f5de6e4d825657aeaa8fb1b4adfcda92e0c82cbcb55bcb9224e8536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kotowski")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695759")[#strong[#text("Marcin Kotowski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Yes, there’s a lot of things an ambitious young person can choose to do. Many of them give the opportunity to “make a dent in reality” (discover something new, solve a challenging problem etc.). Why on earth, then, would someone choose a career consisting of AI slop exegesis? Because “it furthers human understanding”? You’re massively underestimating how important feelings of agency, accomplishment and adventure (as opposed to pure contemplation of beauty) are in any human pursuit.")

#text("Point is, literary critics and writers are two different species. Mathematicians used to be writers, now they’re going to be relegated to literary criticism. The most dynamic and creative will not choose this path.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695771")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("The most dynamic and creative will have a lot more imagination about using AI for mathematical work than you seem to.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695763")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("It’s not inherently bad for society. AI/Math will attract different talents, such as those leaning into Youtuber/content creation. The smart people who would have become pure mathematicians will work on AI alignment and collect their $600k paycheck. May be a win-win after all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae9cb37841d0c1f593f1aa7718e92aa28305ef14a88b73278f3e92862bb479db-fe686d3af70bd9ed44d9a69eb877e9834ea597da7f6327853aecdcd723dca118.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Gagnon")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695836")[#strong[#text("Samuel Gagnon")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("It may be anecdotal, but as someone who had the privilege of actually working on “exposition problem” as part of his master degree in mathematics/computer science (before LLMs were “a thing”), I can say without a doubt that I really enjoyed doing that.")

#text("It’s simply not the same activity as writing proofs. While some people may not appreciate solving “exposition problems”, other (like me) will.")

#text("For job perspectives, in days where AI can produce code like never, the same set of skills required to solve “exposition problem” can be extremely useful in making software development more human understandable and more aligned with objectives. That is what my career is currently based on and it really helps me stand out among others.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695706")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("As another commenter here, it does not look to me that a better exposition (and better honesty perhaps) is a solution to the current crisis (though it is a solution for the def/thm format).")

#text("But I think no LLM can cancel the wish to understand the unknown or get over the impossible. And the fact that they can give a formally verified information is just something that did not exist before for the big theorems (and sometimes left the doubt whether the experts did really have a proof, or it was just some understanding between gentlemen, sorry; “a social fact”).")

#text("It is just that it looks like each one (or each group) will now eventually act on his own, and I don’t see how one can escape from the fact that the most capable will be the one having most resources, and having an access to a machine which lies less (they all lie already about “politics”, but recently it was found out that some of them obscure LLM details to hurt competition, for example).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695707")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("The people in the driver’s seat are Altman, Amodei and Musk.")

#text("It is very instructive that Bubeck tried to treat Buckmaster like an employee even though he wasn’t one. It is ten times worse if you actually work for a software company. They are run like totalitarian states.")

#text("Where will the proposed open solutions rent the hardware? At xAi like Anthropic does?")

#text("Nothing is inevitable. Nuclear energy was thought to be inevitable and is now banned in Germany. I leave it open whether that is desirable, but bans, regulations and treaties are absolutely possible.")

#text("It is interesting that there are no guest posts who want to put on the brakes. I’m sure there are such mathematicians. Perhaps they stay off the internet entirely?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44de20ceba094a976aebcaa76df94be7362bdecb1c1211902d1e9369289650e5-10bbffdc1f79a59ba01ada79ca4de568288921b8b820e05f0a2de8d6b8cbfeb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Morgan")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695709")[#strong[#text("Peter Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("A ‘motivated exposition’ seems close to conceptual analysis, which is valued in philosophy. ‡")

#text("Motivated exposition is close to my heart because I am one of five winners of Curt Jaimungal’s #CORE1 Competition for Outstanding Research Explanations, which is a competition that Curt modeled on Grant Sanderson’s similar competition for mathematical explanation. I certainly consider my winning submission to be as much philosophy and mathematics as it is theoretical physics, and it is through that crossover that I think it contributes a little to our understanding of quantum field theory as mathematics.")#linebreak()#text("The title of my submission, “Explaining Quantum Field Theory as a Dataset&Signal Analysis formalism #CORE1” —with ‘explaining’ in the title, yay!— is intended to point to a connection to Machine Learning and the practicalities of experiment as much as to theoretical physics. A focus on ‘data’ is part of the conceptual analysis/motivated explanation that leads to a new understanding of renormalization as a surreptitiously introduced nonlinearity that has an inverse problem relationship with existing path integral methods through the analytic structure of the Wightman axioms. My prejudice is that real discovery takes this kind of path.")

#text("‡ Please ignore the following if you want to see only my opinions, as above:")#linebreak()#text("Having written “A ‘motivated exposition’ seems close to conceptual analysis, which is valued in philosophy.” I gave it as a prompt to Google and then, seeing that Google more-or-less approved, I asked Google AI Mode, “I am writing a comment responding to this guest blog post by Grant Sanderson, ")#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")[#text("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/")]#text(" Do you have any suggestions for how to follow “A ‘motivated exposition’ seems close to conceptual analysis, which is valued in philosophy.”?”")#linebreak()#text("Google AI Mode suggested three options for how to follow my first sentence,")#linebreak()#text("1) The “Why Definitions Matter” Angle (Conceptual)")#linebreak()#text("2) The “AI and the Crisis of Meaning” Angle (Contemporary)")#linebreak()#text("3) The “Actionable Standards” Angle (Pragmatic)")#linebreak()#text("Anyone can do the same with their favorite AI, or follow the link to Google’s result, ")#link("https://share.google/aimode/oyxk1Q4F9MkLBkHjO")[#text("https://share.google/aimode/oyxk1Q4F9MkLBkHjO")]#text(", and I found all three options from Google AI Mode worthwhile, so I won’t choose one of those.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695710")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("The writer of this blog post with his absolutely amazing educational videos earns his credits directly from the social media market. Most mathematicians commenting here earn it from tax payers and students, both a kind of market. While there are notable differences between these markets (YT is brutal, tax payers much more naive, they can be efficiently fooled for a longer time as their market is highly intransparent, the students are paying for the reputation of an institution which is again a complex construct etc.), they are dwarfed by the bottom line: whatever artifacts are produced by the currently paid mathematicians will be infinitely superseded in both quality and quantity by what AI can do. The disruption needs to be and is going to be much bigger than indicated in most of these posts. It’s not about merely choosing another proxy to maintain roughly the same hierarchy. It’s really about how to get paid by the market (to the extent that any of it remains) after it turns out that you can’t produce anything better than your much cheaper competitor. Many professions obviously experienced that throughout the history, you guys are screaming as you were the first ones. The only thing that is different now is that it happens simultaneously to ** all ** professions. But then again, that’s also not about you mathematicians being any special here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695740")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("There is of course no market between taxpayers and professional mathematicians. The mathematicians are mostly paid to teach at universities. Also, you don’t think at all by the logistics of AI producing the vast numbers of mathematical papers (see the number uploaded to arxiv).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695711")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Grant Sanderson doesn’t state this explicitly and his name may not ring a belle but he is the person behind the great ")#link("https://www.3blue1brown.com/")[#text("https://www.3blue1brown.com/")]#text(" project, which is familiar to many of us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695716")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I can not imagine young faculty hired (just) for better exposition. Sorry. I am not saying this is not what one should do, I just can not imagine it; this is too close to hiring TikTok influencers.")

#text("It is much easier to imagine all basic research in universities being gone in a year than that. Maybe it is actually the same.")

#text("Strange times.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695770")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Really strange. Hiring based on exposition would have been somewhat common by now if it was found valuable. Obviously it has not been. This naturally makes people suspicious of the claim that it is a valid thing to do.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c1f39fda4802b07a12426a497a616a2925f6b74301f71b8be661e831a3db403-2059c209ec074d3a72be41d2e6ca3f4b820a344c32e1c151067d6bcddf93fd5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696497")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("What do you think teaching undergrads mathematics is?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695718")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("This is a very well-written piece, and I appreciate the author’s instinct to propose solutions. However, what makes the author believe that “motivated explanations” cannot also be produced by AI?")

#text("I disagree with the examples offered as possible deliverables for PhD students. Imagine that a student is asked to explain a particular problem in a talk, following a rubric designed to assess motivated explanation. That rubric could simply be given to an AI, which would then generate the explanation. The student would be incentivised to understand or memorise the AI-generated material only well enough to satisfy the examiners.")

#text("This would not cultivate creativity or originality. The intellectual faculties responsible for developing an explanation from first principles would remain underdeveloped. Instead, the research student would become optimised for understanding, memorising and reproducing AI-generated explanations. How, then, does this solve the underlying problem?")

#text("There is no doubt that AI is causing massive disruption within the mathematics community. However, I fear that proposals of this kind merely kick the can down the road. The only genuine way forward is through honesty, discipline, integrity and curiosity. The entire academic reward system may also need to be reconsidered so that these virtues are genuinely encouraged.")

#text("Students must be allowed to wrestle with research problems themselves—and, importantly, to fail without being destroyed by that failure. They should be able to get up, try again, fail again and continue until they make meaningful progress, without relying on AI to do the thinking for them.")

#text("This approach may still fail, but I believe it is the only credible way forward.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695724")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Problem is it’s not. It is just proof that the prediction lead to somewhere what the calculation is meant to lead. The reality what the result means is in the mind of explainer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695726")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I don’t know what happened to the other comment that got downvoted into oblivion, but despite the lack of tact, it kind of had a point. The young researchers want stability, they want some degree of certainty that whatever craft they are honing during their PhD won’t be obsolete as soon as they enter the job market. What would prevent AI labs from benchmaxxing any “list of open exposition problems” we give, or use any human-curated “Lean certificate” -> “motivated exposition” dataset as a reinforcement loop? What guarantees that proof exposition won’t be solved in a few months?")

#text("And what can the field’s leaders do aside from yet another strong worded letter? The AI corporations have repeatedly demonstrated that they don’t care about the human mathematician’s profession disappearing, and the market forces are far stronger than any desperate plea we can utter. The math community already served several benchmarks on a golden plate to AI companies (First Proof, Frontier Math…), are we so adamant at accelerating our own irrelevance?")

#text("Granted, I don’t know for sure what will happen from here, but I know that any serious attempt at imagining the future (and painting a more reassuring picture for the junior researchers) must account for all the extreme outcomes. Besides, believing in a human “supplement d’ame” in any mathematical exercise has not served us well so far. So in the most extreme cases, what remains? Understanding the AI expositions? On a purely transactional perspective, will this even be necessary, if AIs can both advance frontier math and apply its discoveries to frontier science and engineering without humans in the loop?")

#text("I know, we can all agree that accelerating progress in the sciences is important, but there is nothing shameful in acknowledging that, deep down, we still want to be relevant and useful in that process. We should be honest about it, at last. We are social animals, it is our nature to want credit and recognition for our hard work, be it proving theorems, canonizing the mathematical cathedral, or devising beautiful expositions. I don’t think mathematics as a human tradition will survive without that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695769")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Best post here. Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695730")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I wonder if mathematics could come to feel more like journalism– you go out, you explore an unfamiliar place or country, and you file a report. Journalists don’t discover or create the places they are covering and yet, journalists have their own system of rewards and some journalists are regarded more highly than others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695735")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Thank you for the excellent piece! I enjoyed reading it and very much agree with lots of the points you make. I am in fact a couple of days into a project to read an AI-generated proof and “digest” it as much as I can to produce a better exposition, and I’m finding it much more enjoyable and fulfilling than I expected. It would still have been more enjoyable to come up with it all myself though.")

#text("One point I wanted to make, more in relation to the comments than the article, regarding whether AI will eventually (or, soon) be superhuman at exposition as well is this: I feel like this article and many of the other ones on this site and others have an unwritten assumption in them. This is that there is so much to mathematics beyond just proving things (even though it can go unappreciated) that if an AI does become genuinely superhuman at all of mathematics in this broader sense, then this will cause such an enormous impact on the entire structure of society that we’ll have much bigger things to worry about than what’s happening to mathematics.")

#text("For example, it’s not inconceivable (though beyond current capabilities of course) that an AI could easily produce an entire 3blue1brown video from a single prompt (make a 30 minute video in this style about this topic) which was as good at explaining the concept at hand as the real deal. But then, an AI which was so much better at mathematical exposition and teaching than us could probably replace so much human labour that society in its current form would become almost nonsensical. To understand what would become of mathematics, we’d first have to understand what would become of everything else, which is a scary thing to think about.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695738")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Why “motivated” explanation instead of “motivating” explanation? “Motivated explanation” sounds too much like “motivated reasoning” to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/771c5fa2faea597ed5a1d545ba1ac31f0810bf23c1770bffd1c286642eab261c-77a7e7f56462bb95dd62747b2861229dbfd43a4b64eabf6155140bf2b747ecf2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695743")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("This is a wonderful idea, which has my full support. I would also be happy to join any nascent efforts in this direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66d142b7d185f39fac1633330a138739d5662b65c6da90f0918ae9834df79457-5ca7ff8185d77fbbce6d3629a760b5865e45b1ddfd67c1649387c3ff4ddbde47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friederrrr")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695744")[#strong[#text("friederrrr")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Mathematics will become more engineering-like. I don’t quite understand why many mathematicians cling to exposition: “A PhD advisor can still assign a small problem from their field for a new student to cut their teeth on, but the deliverable would not be to write up a solution; it would be to present that solution to peers and faculty as a talk. It could be an already-solved problem which lacks clarity.”")

#text("Arguably, explaining a problem better is a much simpler task for AI (and for humans) than finding a novel proof. Unless we assume that human understanding _has_ to originate from humans to be accepted, I am not sure whether this point will prevail.")

#text("The jury is still out on what the activities of a future mathematician will still be. Orchestrator of LLMs is a sure bet 🙂")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695754")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("If there is a problem with mathematicians getting their work stolen by LLMs, then why not make everything analogue, and only correspond with other mathematicians on your progress. Like it was in the old days. This should be done until the owners of the LLMs respect the mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c8580ccb5278fdd3c9f83c8900f7e212787cb1ded66c4cb5b6241cd9c935510-56b5f1ca96865c070a69be83feccd29d4422485effef77502e5b7a3f3f067818.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohamed Alhosani")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695755")[#strong[#text("Mohamed Alhosani")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#align(center)[

]

#text("“Discovery fiction” reminded me of Sussman’s “problem solving by debugging almost right plans”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695757")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("An aspect that seems not to be mentioned is the training of LLMs and other agents. Tsimerman will not get superexpositors in April unless EVERYONE gets involved in training these models to provide good expository content.")

#text("When I start an exploratory project with any agent, I usually insist on explanations at both local and global levels, and I query the agent on specific points. (For some agents I also ask for literature and reference searches to allow correct attribution, and I also ask for other connections to the literature for future explorations by others.) There may be more effective ways of training to do good exposition, but I think this way is a good start.")

#text("I think a better generator of a list of open exposition problems is a leader (not in mathematics, but) in exposition problems. I think a team of various YouTube creators could come up with such a list that would be more to the point and inspiring than a list by a team of experts whose knowledge base is more technically refined and less accessible.")

#text("Gerhard Paseman (still entertaining system design questions)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695762")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("The people that love doing math will continue to do it, with or without institutions, or AI. Institutions will continue to generate slop, they just might not need to extract it directly from mathematicians any longer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695784")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Written standards could clarify what constitutes a motivated explanation, aiming to make it nearly as verifiable as proof,")
]

#text("As the verifiability of the task approaches the verifiability of a proof, I’d conjecture that AI’s ability to perform the task will approach and surpass human performance. The verifiable regime is where AI excels because reinforcement learning with verifiable rewards has been so effective. I like this post, but if this call to action succeeds, we’ll need to find another thing for mathematicians to do before long.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695790")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("There’s an “industry” of chess masters analyzing chess games, now popular on youtube, but done in earlier times through books and magazines. You’d look at a game and explore the possible decisions that could be made at its different board positions, and what was good and bad about them. The strongest players now are all computers, though human players still analyze computer games. They will say “in this position the computer went here because XYZ. Then it made this move and hmm, well I can’t really understand why it did that”. The moves are sometimes beyond human comprehension, and investigating the computer’s “thoughts” (sequences of moves that it expects to see) doesn’t even help much. Maybe math will get that way too. Doron Zeilberger has been predicting it for decades.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695788")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I guess I think of proxies as an extravert thing that ")#emph[#text("real")]#text(" nerds shouldn’t want to worry about ;). Sure, they’re needed for tenure decisions and stuff like that. But I went into math (ok, I didn’t end up staying in it) because I wanted to experience the math directly, and particularly to cultivate the mental states that it took to explore a tantalizing math idea, and to get wound up in them through what I called “raging math hormones”. Artists cultivate similar states to explore the human condition, and they’re stereotypically tortured people because of that condition’s innate ugliness. But math is beautiful in all directions, so I saw math as being like art without the torture, if that makes any sense ;).")

#text("You don’t have to worry about tenure if you don’t mind teaching calculus like Yitang Zhang did (the prime gap theorem was a cherry on top). For that matter, even Grothendieck went off and taught calculus for decades after leaving IHES. He didn’t care about proxies, so I always considered him to be the king of the nerds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695793")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Re: placing the definition in the middle, after the motivation, I had experimented with placing the motivation alongside a (tentative) definition, with help of AI tools. Would love to see more experimentations. ")#linebreak()#link("https://liuyao12.github.io/geometric-tree-search/GCTS-I.html")[#text("https://liuyao12.github.io/geometric-tree-search/GCTS-I.html")]#linebreak()#link("https://liuyao12.github.io/incidence-geometry/")[#text("https://liuyao12.github.io/incidence-geometry/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695805")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Miguel Noether")

#text("One of the biggest problems is that we are mostly listening the thoughts and opinions from mathematicians (and other fields in twitter) which have already established careers before the summer of AI. In such a position, you can safely discuss how to use AI or completely be against it. It barely matter to their future career. The yongest generations are the ones who are the most vulnerable and suceptible to this generational change in how science is done, funded and rewarded. AI has brought solutions and tremendous opportunities but also new problems and unfortunately has worsen the old problmes even more, those problems that the old generation which are the ones that we are listening to refused to solve and are refusing to solve. Thus complicating the way AI is seen from the outside and the role of mathematicians (and scientist in general) should play in this time of change.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695817")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Such an important point. Recently I shared with Grok some maths papers written by 11 and 15 year old kids driven by original insights. They are not maths kids but occasionally get excited by something. Grok dismissed these as old known results and average stuff for 11 year olds. In contrast, Prof Andy Bruckner, a fellow of the American Mathematical society, had liked the originality and insight in the papers.")

#text("So here we have a clear contrast between the views of Grok AI and a professional mathematician on intuitive explanatory value. The AI is dismissive but a human mathematician wasn’t.")

#link("https://www.quora.com/How-is-mathematical-talent-identified-and-nurtured-in-children/answer/Richard-Matthews-8?ch=3&oid=1477743708809925&share=c30666ed&srid=ugKVs&target_type=answer")[#text("https://www.quora.com/How-is-mathematical-talent-identified-and-nurtured-in-children/answer/Richard-Matthews-8?ch=3&oid=1477743708809925&share=c30666ed&srid=ugKVs&target_type=answer")]

#text("PS: The papers were publicly uploaded")

#text("1. Purely Geometric Method Proof for Infinite Series discovered by 11 year old Ismael Afaf:")

#link("https://zenodo.org/records/155710452")[#text("https://zenodo.org/records/155710452")]#text(".")

#text("2.Purely Geometric Method Proof for Alternating Infinite Series discovered by 14 year old Ismael Afaf")

#link("https://zenodo.org/records/155710853")[#text("https://zenodo.org/records/155710853")]#text(".")

#text("3. Combinatorics: An independent rediscovery of doing combinatorics using addition by 14 year old Ismael Afaf")

#link("https://zenodo.org/records/155711104")[#text("https://zenodo.org/records/155711104")]#text(".")

#text("4. A numerical investigation of a conjecture on Goldbach by 11 year old Mikhael and 15 year old Ismael Afaf")

#link("https://zenodo.org/records/155711375")[#text("https://zenodo.org/records/155711375")]#text(".")

#text("5. A probabilistic argument that Prime Number Theorem implies Goldbach by 15 year old Ismael Afaf")

#link("https://zenodo.org/records/155711596")[#text("https://zenodo.org/records/155711596")]#text(".")

#text("A further conjecture on Goldbach statistics with numerical investigation by 15 year old Ismael Afaf")

#link("https://zenodo.org/records/15571181")[#text("https://zenodo.org/records/15571181")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695821")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("The way to deepen our grasp of mathematics is to actively value novel approaches that yield simpler, shorter, or more unifying proofs of existing results.")

#text("There is an obsession with speed in mathematics, heavily conditioned by math competition culture. This mindset has bled into AI development, and the problem goes deeper than just the benchmarks we use. It is rooted in who is building these systems. A disproportionate number of AI researchers and developers are former IMO participants. They bring a competition-math worldview to their work, where mathematical prowess is often equated with solving clever, time-constrained puzzles. Because of this background, they tend to design systems optimized for trick-solving and speed, missing the slow, structural insights that actually drive real mathematical research.")

#text("We need a cultural shift in how the mathematics community rewards and shares knowledge. Instead of just celebrating the final theorem, we should recognize the people who find genuinely new ways to explain it. When we simplify a proof, we do more than verify a fact. We make the underlying concepts accessible. This allows a much wider range of people to understand, adapt, and apply those ideas.")

#text("At its core, mathematics is about expanding the human understanding of universal truths. We should be building tools that help us see the structure of those truths more clearly, rather than just systems designed to crunch through a timed puzzle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696214")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("An excellent example of curiosity-driven research which emphasized novel approaches involves the trigonometry-based proofs of the Pythagorean theorem published in 2024 in AMM by two high-school students:")

#text("Jackson, N., & Johnson, C. (2024). Five or Ten New Proofs of the Pythagorean Theorem. ")#emph[#text("The American Mathematical Monthly")]#text(", ")#emph[#text("131")]#text("(9), 739–752. ")#link("https://doi.org/10.1080/00029890.2024.2370240")[#text("https://doi.org/10.1080/00029890.2024.2370240")]

#text("The backstory is about how two inner-city youth were driven partially by a monetary bonus, but then became obsessed by sheer curiosity to flesh out their ideas. Whither LLMs and this type of exploratory work with human interest as a side effect?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695829")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I think this whole discussion has very weak assumptions:")

#text("– That AI will not become better at writing and drawing motivated explanations.")#linebreak()#text("– That the desires of mathematicians will be well-aligned with the desires of the majority of those who actually pay mathematicians.")

#text("It’s not crazy to imagine a future where only a few sources of money are willing to fund human-led intellectual work anymore, due to AI being able to generate the expected outputs at a lower cost. Even before AI, there’s been a decline in funding for non-applied research and departments in universities, because pure understanding, while popular among academics, is not really that much valued by the outside world; at least not in the sense of it being something people are willing to pay for. Perhaps top departments and mathematicians will be safe from this for a while, but less privileged mathematicians across the world may well be fired if they don’t use AI; not as a policy, but by being outcompeted by those who do use it. We all know the issues with “publish or perish”, and AI may well push for a culture of “publish or perish” on steroids.")

#text("If mathematicians really want to push for intellectual curiosity to be valued, it is people and systems outside of math that need to be the target of the discussion. Else, we might as well be discussing about a future hobby.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695884")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("i agree that ai is inflaming issues that have existed since at least WWII. the institutions that pay mathmeticians are motivated by dominance not “human understanding.” if you arent doing math for fun, ai can replace you")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695839")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("I think if the field of maths goes in this direction it would be so useful in the classroom and for students as well: To encourage understanding, and having fun with things, and exploration, rather than a focus on memorization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/968e3f92df5ad350aa45d26240b0b6efd832847ce54e42c5d23997d7401ee1ea-96e47b6506ca5527ac071de3fcb7c1ff674a2627b44236f9a647aa186098b842.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ferment538")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695847")[#strong[#text("ferment538")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("AI is ")#strong[#text("Hilbert’s program")]#text(". Human intelligence is ")#strong[#text("Gödel’s theorem")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a359b4b55d633aec44076c9dcea628d140c3963a788710e2c89f28422110d562-0cf7e0e2aa7a0577b150f1a4ca5dc32561813ca6e9187fd5b3020db477d9d51b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tchow8")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695859")[#strong[#text("tchow8")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Let me give a concrete example (from the pre-LLM era) of a theorem that could benefit from more digestion: the <a href=”https://www.pnas.org/doi/10.1073/pnas.1019186108″>q-TSPP theorem</a>. The statement of this theorem is very elegant and elementary, and you would expect it to have a simple proof. But the only known proof relies on some monstrous half-gigabyte certificate. I do not think that this is a satisfactory state of affairs, but the status of the q-TSPP theorem as a “solved problem” does not incentivize further attention being devoted to it.")

#text("There are several things that could be done to improve the situation. A first step would be to make sure the proof really is correct, by formalizing it in Lean or some other ITP. (I have it on my todo list to submit the statement of the q-TSPP theorem to LeanEval, but I would be happy if someone else scooped me.) A second step would be to find a simpler proof. The q-TSPP is one of a small family of enumeration problems involving symmetry classes of plane partitions, and most of the other members of the family now have proofs that are not simply computations; they invoke combinatorial constructions and/or representation theory.")

#text("Let me also say that although I strongly resonate with Grant’s notion of a motivated proof (a term also used by <a href=”https://gowers.wordpress.com/2025/09/22/creating-a-database-of-motivated-proofs”>Tim Gowers</a>), creating motivated proofs is not the only important aspect of “digestion.” It would be valuable to understand how I personally could have found the half-gigabyte certificate. But that would still not be the end of the story as far as I’m concerned. Finding “nicer” proofs of theorems that already have proofs is just as important for digestion as finding motivations for the existing proofs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695862")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Fantastic exposition. I wonder, though, about the internal content of human flourishing. Making better tech/ advancements in engineering are one way of characterizing human flourishing.")

#text("But the other side of human flourishing consists of having a sense of belonging and purpose without which human respect to one’s self, peers and colleagues, history and potential future. And I think we need to retain human scale processes (group learning, books, pen and paper, rites of passage) to instill these grounding characteristics, lest we create an even more atomized and nihilistic culture, that is likely to succumb to or abuse the engineering novelty than flourish with it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdff1ba51ed4f8fdfb229428faf7a9e026898e66f7da5485466e4f000126f487-3aa8078e70debae12831228ddb5544a19fc8538c570149f739643d9ab2be075e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arihant Jain")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695872")[#strong[#text("Arihant Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Wonderful blogpost, full of interesting proposals. Thanks!")

#text("I finished my PhD in arithmetic geometry two months ago. I can safely say that “my thesis” was essentially a rewriting of my supervisor’s thoughts. He might not have them in a very structured format in his brain, so my job was to write them in a “digestible” format and present it to others. Grant’s proposal, “A PhD advisor can still assign a small problem from their field for a new student to cut their teeth on, but the deliverable would not be to write up a solution; it would be to present that solution to peers and faculty as a talk..” resonates with me very much. In fact, a lot of emphasis in our research group was to communicate ideas/conceptual understanding in a “digestible” manner instead of just reporting and explaining on board/slide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695877")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("I love this. The AI bros are ultra competitive and will bulldoze into anything they feel they can demonstrate superiority in, but I think the conjecture that they are missing the point of math, is a bit of a rug pull.")

#text("The math community itself made this about fame and acclaim way before AI came in to the fold. Tao has touched on the fact that mathematicians obsess over unsolved problems often and it’s an occupational hazard.")

#text("I’m not sure that it’s necessarily been demonstrated that the indigestion caused by proof verification and ai thwarts the growth of human understanding. This is non-obvious to me and in fact I feel it’s more likely to nurture our knowledge.")

#text("Consolidating power is imo a great threat to our understanding of, as I feel brain drain has been one of the few ways to discover virtue.. Follow the brain drain, bc when power is acting in an unsustainable manner, awesome brains can tell and move to a more habitable power dynamic, leaving that power with less intelligence thus decreasing its power.")

#text("So a power that also never loses intelligence, and in fact grows in intelligence no matter if they abuse their power or not, is kinda the dream scenario for a power end game. This is my fear, although I’m still skeptical of that happening.")

#text("I think the following technologies are quite important")

#list(
[#text("a true open, transparent builder of mainline models that are competitive with current frontier models (possibly an open source company? There has been some stabs for the crypto sector)")],
[#text("powerful indexing of the proof “indigestion” that will occur with AI math")],
[#text("An Internet for agents and an Internet for humans – currently the Internet is becoming ugly because it’s mixed with content best consumed by humans and agents. We will need to learn what it is that makes things consumable by humans and create beacons where humans can get valuable information, in a Jupiter sea of information mostly generated by humans")]
)

#text("This is likely overly simplistic, as I fear everyone’s thoughts likely are.")

#text("I personally subscribe to the belief that technologies that had the potential to consolidate power in the past have been checked (and honestly – beaten) by open source (Linux:OS, Postgres:DB) and academia and open source software do have models that I think can evolve to make humans the powerhouses we can be in this new world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c15dec7f077ae2b0c8dabab394408b7ea117f83a7c5a338ce89740fa1d571d1-22f4ac1302b40ca5193541c0653ac9100fe96ad171641c19ff263480e716397e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695898")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("I think that Grant Sanderson’s notion of a “motivated explanation” could be what Markus Pantsar terms as ‘pre-formal truth/proof’ in his 2009 paper ‘")#link("https://helda.helsinki.fi/server/api/core/bitstreams/312544b1-1f90-4010-95b1-7583848bed74/content")[#text("Truth, Proof and Gödelian Arguments: A Defence of Tarskian Truth in Mathematics")]#text("’; where he remarks (")#emph[#text("§1.1, General background")]#text("):")

#text("[")#strong[#emph[#text("quote")]]#text("] ")#emph[#text("In this work I will argue that without any outer reference, mathematics as we know it could simply not be possible: it could not have developed, and it could not be learnt or practised. Sophisticated formal theories are the pinnacle of mathematics but, philosophically, they cannot be studied separately from all the non-formal background behind them")]#text(".")

#emph[#text("This way, what might seem like a completely formalist theory of mathematics turns out to be nothing of the sort. It could not have existed without a wide pre-formal background, which we will see when we examine mathematical practice in general. Formal systems are not of the self-standing type that extreme formalism seems to claim. My purpose in this work is to show that the formalist program uses the actual practice of mathematics as a ladder that they later discard. This by itself is of course perfectly acceptable, and it mirrors the way we strive for formal axiomatic systems in mathematics. What is not acceptable is how they refuse using the ladder. ")]

#emph[#text("When it comes to the question of truth and proof, this could not be any more relevant")]#text(". [")#strong[#emph[#text("unquote")]]#text("]")

#text("Moreover, apropos Sanderson’s remark that ‘solving problems and generating proofs have always served as proxies for the true goal of mathematicians, which is to further human understanding’, Pantsar’s analysis suggests that:")

#strong[#text("Thesis 1 (Complementarity Thesis)")]#text(" Mathematical ‘provability’ and mathematical ‘truth’ need to be interdependent and complementary, evidence-based, assignments-by-convention towards achieving:")

#text("(1) The goal of proof theory, post Peano, Dedekind and Hilbert, which is:")

#text("– to uniquely characterise each informally defined mathematical structure S (e.g., the Peano Postulates and their associated, classical, predicate logic),")

#text("– by a corresponding, formal, first-order language L, and a set P of finitary axioms/axiom schemas and rules of inference (e.g., the first-order Peano Arithmetic PA and its associated first-order logic FOL),")

#text("– which assign unique provability values (provable/unprovable) to each well-formed proposition of the language L without contradiction;")

#text("(2) The goal of constructive mathematics, post Brouwer and Tarski, which must be:")#emph[#text(" ")]

#text("– to assign unique, evidence-based, truth values (true/false) to each well-formed proposition of the language L,")

#text("– under an, unarguably constructive, well-defined interpretation I over the domain D of the structure S,")

#text("– such that the provable formulas of L are true under the interpretation.")#emph[#text(" ")]

#text("In other words:")

#text("* Whilst the focus of proof theory may be viewed as seeking to ensure that any mathematical language intended to formally represent our ‘pre-formal’ mathematical concepts and their inter-relatedness is unambiguous, and free from contradiction;")

#text("* The focus of constructive mathematics must be viewed as seeking to ensure/validate that any such representation does, indeed, uniquely identify and adequately represent such pre-formal concepts and their inter-relatedness.")

#text("Moreover, the notion of validating ‘pre-formal truth’ and ‘pre-formal proof’ is implicit in Per Martin-Löf’s 1987 analysis ‘")#emph[#link("https://github.com/michaelt/martin-lof")[#text("Truth of a proposition, evidence of a judgement, validity of a proof")]]#text("‘ of the meaning and truth of a proposition; which we could view as:")

#strong[#text("Löf’s Thesis:")]#text(" A proposition ’A’ is a ’truth’ if, and only if, it can be ’asserted/judged’ as ’A is true’ by appeal to some ’evidence/proof’ for the truth of A which can be ’validated’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695901")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("This blog post seems to presuppose that AI will not be able to eventually match or exceed humans in terms of motivated explanations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c15dec7f077ae2b0c8dabab394408b7ea117f83a7c5a338ce89740fa1d571d1-22f4ac1302b40ca5193541c0653ac9100fe96ad171641c19ff263480e716397e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695902")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("[")#emph[#strong[#text("quote")]]#text("] ")#emph[#text("Many young students who are otherwise passionate about the field are afraid to pursue it now due to the uncertainty of what happens in an age of proof-generating machines. … If the next chapter of math is ushered in by the drumbeat of two words “human understanding”, whatever changes are about to happen seem likely to amplify math’s value as a public good.")]#text("[")#strong[#emph[#text("unquote")]]#text("]")

#text("Grant Sanderson’s observations raise the uncomfortable issue:")

#strong[#text("Is there an impending crisis in how mathematics is currently taught and practiced?")]

#text("For instance, reflecting Sanderson’s disquiet, once-aspiring mathematician Jason Polak vividly challenges what he perceives as the blinkered vision of current mathematical pedagogy variously in his impassioned perspective that ‘")#emph[#link("https://medium.com/@jpolak/math-is-running-out-of-problems-14f2911fa46b")[#text("Math is running out of problems")]]#text("’, where he remarks that:")

#emph[#text("[")#strong[#text("quote")]#text("] The truth is, in most cases, modern-day research mathematics is confined to the interest of a handful of people for any given research topic, and that is becoming more and more exaggerated every day. … At what point can we still say with a straight face that it makes sense to pour millions of dollars into mathematics research when its only objective seems [to be] reaching the next highest peak of hyper-specialization? Is all this worth it [just to] produce solutions that will be interesting to about twenty people per paper? It is like the public funding climbers to reach the peaks of Everest or K2. … Graduate students in the future should no longer have to prove something totally new. Instead, their main aim could be simplifying an elegant and truly interesting result of the past. … A culture that encourages endless new research is like pushing an artist to paint dozens of new paintings, even when they have nothing to paint. The resulting ugliness is worse than useless, and goes against the human spirit. [")#strong[#text("unquote")]#text("] ")]

#strong[#text("How acute is the problem? ")]

#text("The relevance of Polak’s perspective—if given significance as that of an aspiring scholar—is highlighted by ")#link("https://sites.google.com/view/wvusmdsreview/home?authuser=0")[#text("the August 2023 developments in West Virginia University")]#text(", apropos the announcement that new admissions to post-graduate courses in mathematics and mathematics research might no longer be offered by the University from the following academic year.")

#text("The question arises:")

#emph[#text("Could such action be viewed as reflection of a gradually growing underswell of frustration—if not outright disillusionment—experienced by economically accountable academic administrators, as well as emerging, and not necessarily disgruntled, scholars, with the relevance to both the individual, and society, of what actually is taught, researched, and sought to be achieved in mathematics at the post-graduate level?")]

#text("To situate the query in an appropriate perspective, it might be pertinent to note that, in a seemingly prescient 1999 ‘spoof’ essay ‘")#link("https://link.springer.com/article/10.1007/BF03024838")[#text("Real fish, real numbers, real jobs")]#text("’—obliquely highlighting this issue and aimed at precisely aspiring scholars—mathematician Norman Wildberger had essentially sought to caution both emerging mathematicians, and their teachers, against conflating:")

#text("– worthwhile falsifiable mathematical research;")

#text("– with the futile pursuit of essentially unfalsifiable, even if formally provable, theorems in the fecundity of artificially defined axiomatic systems that have no verifiable mathematical or reallife model (hence are of debatable scientific or social value);")

#text("a pursuit seemingly aimed predominantly, even then, at the increasing publishing of intellectually impressive, but arcane, ‘research’ purely for ‘embellishing’ job-oriented curriculum vitae.")

#text("A caution that can also be viewed as implicit—albeit from a different perspective—in Melvyn B. Nathanson’s 2008 essay: ‘")#link("https://arxiv.org/pdf/0809.1372")[#text("Desperately Seeking Mathematical Truth")]#text("’; where Nathanson sought to highlight the significance for the mathematical sciences when essentially ‘absolute’ authority is vested by society — albeit tacitly — upon academic ‘bosses’ (a reference, presumably, to the collective of reputed, and respected, experts in any field of human endeavour):")

#emph[#text("[")#strong[#text("quote")]#text("] … many great and important theorems don’t actually have proofs. They have sketches of proofs, outlines of arguments, hints and intuitions that were obvious to the author (at least, at the time of writing) and that, hopefully, are understood and believed by some part of the mathematical community. ")]

#emph[#text("But the community itself is tiny. In most fields of mathematics there are few experts. Indeed, there are very few active research mathematicians in the world, and many important problems, so the ratio of the number of mathematicians to the number of problems is small. In every field, there are “bosses” who proclaim the correctness or incorrectness of a new result, and its importance or unimportance. ")]

#emph[#text("Sometimes they disagree, like gang leaders fighting over turf. In any case, there is a web of semi-proved theorems throughout mathematics. Our knowledge of the truth of a theorem depends on the correctness of its proof and on the correctness of all of the theorems used in its proof. It is a shaky foundation. [")#strong[#text("unquote")]#text("]")]

#text("Nathanson’s comments are intriguing, because addressing such ambiguity in critical cases—such as categorical communication between mechanical artefacts, or a putative communication between terrestrial and extra-terrestrial intelligences—is the very raison d’ˆetre of mathematical activity!")

#text("A similar caution is reflected obliquely in Elliott Mendelson’s earlier 1990 article: ‘")#link("https://www.jstor.org/stable/2026831?seq=1")[#text("Second Thoughts About Church’s Thesis and Mathematical Proofs")]#text("’; where Mendelson implicitly implied that uncritically inherited definitions of various foundational elements can be argued as being either ambiguous, or non-constructive, or both:")

#emph[#text("[")#strong[#text("quote")]#text("] Here is the main conclusion I wish to draw: it is completely unwarranted to say that CT is unprovable just because it states an equivalence between a vague, imprecise notion (effectively computable function) and a precise mathematical notion (partial-recursive function). … The concepts and assumptions that support the notion of partial-recursive function are, in an essential way, no less vague and imprecise than the notion of effectively computable function; the former are just more familiar and are part of a respectable theory with connections to other parts of logic and mathematics. (The notion of effectively computable function could have been incorporated into an axiomatic presentation of classical mathematics, but the acceptance of CT made this unnecessary.) … Functions are defined in terms of sets, but the concept of set is no clearer than that of function and a foundation of mathematics can be based on a theory using function as primitive notion instead of set. Tarski’s definition of truth is formulated in set-theoretic terms, but the notion of set is no clearer than that of truth. The model-theoretic definition of logical validity is based ultimately on set theory, the foundations of which are no clearer than our intuitive understanding of logical validity. … The notion of Turing-computable function is no clearer than, nor more mathematically useful (foundationally speaking) than, the notion of an effectively computable function. [")#strong[#text("unquote")]#text("]")]

#text("Consequently, inherited interpretations of classical theory may, inadvertently, be weakening a desirable perception of mathematics as the lingua franca of scientific expression, by ignoring the possibility that, since mathematics is indisputably accepted as the language that most effectively expresses and communicates semantic truth, the widening chasm between:")

#text("– an increasing under-estimation of the value of ")#emph[#text("semantic")]#text(" arithmetical truth to society; and")

#text("– an increasing over-estimation of the value of ")#emph[#text("syntactic")]#text(" set-theoretical provability to society;")

#text("must, of necessity, be narrowed and bridged not only explicitly, but urgently given the exponentially-evolving, and humanly unmatchable, theorem-proving capability of AI agents.")

#text("In other words, academe must cease playing the game of ‘who’s best at mathematical provability’ with the advent of an unbeatable AI, and change the goalposts to identifying ‘who’s best at validating a mathematical proof as a (significant?) mathematical truth’ (Sanderson’s “human understanding”?)!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-695986")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Besides Mathematical Discourse, one could also mention ")#link("https://www.sciencedirect.com/journal/expositiones-mathematicae/about/news/aims-and-scope-updated-for-expositiones-mathematicae")[#text("Expositiones Mathematicae")]#text(" for a good journal with a focus on exposition and survey articles. Its motto is “Mehr Licht” (more light).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696290")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Yes, but “Expositiones” is owned by Elsevier. For many of us, this is problematic. In fact, mathematics relies too much on (middle scale) money, it depends on it, is transformed by it. And now it is finally under the attack. Certainly a good time to wake up!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696000")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("I think an excellent bridge between the proof world and the exposition world is the book “Proofs from the Book”, where truly beautiful and often intuitive proofs of famous theorems are presented. Some of them are literal one-liners while the original proof was much longer. ")#linebreak()#text("(I’m not saying length of proof is a measure of beauty.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696019")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Sincere question: Since it’s now common knowledge that ChatGPT is able to produce PhD-level research very quickly (a few hours or even less…) and of the type that would take a strong PhD student at least some months of hard work to do, then why would anyone want to start a PhD in math? Unless the PhD has to do with AI, I don’t see many people wanting to pursue that in the future…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696235")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Re the “Why do the phd” question. Because mathematicians have a fire burning in their head made of numbers and logic. My old housemate was a pure maths grad. Didnt do his PhD cos his honors burnt him out. But he wasnt that interested in the paper. what he was interested was the theories and the stuff that would keep him up to 4am pouring over maths papers for his pet interest group symmetry theory. Didnt understand a word of it myself, but his descriptions where pretty fascinating and often had me thinking about symmetry groups and music theory, even though I knew *very* little about it compared to him (Im just a stinkin’ music theory fanatic) .")

#text("Unfortunately a passion doesn’t pay the bills. We need PhDs and research programs, with paycheques associated with them, or those great minds get wasted.")

#text("My old flatmate stacks shelves. I think his autism wont let him move on from the honors degree burnout. Alas.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7641ff75d6f0d9509b9a4149c83e1e36704a25ed99b197ea900ac70f303eadbb-be459a0f2b2b5dbc011a1842e2eb352cf7799d0de007d0acdc8ac91aec7e2704.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of waldyrious")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696236")[#strong[#text("waldyrious")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Regarding the practical calls to action, I think it would also be worthwhile if the mathematical community could find ways to grant social credit and institutional backing (grants, publication norms, etc.) to existing proposals that aim at providing increased intuition in grasping mathematical concepts: from the tau (2pi) notation, to geometric algebra, to the unified representation for the log, exp and sqrt operations that 3b1b already made a video on, etc.")

#text("I believe this kind of tooling might provide useful scaffolding for mathematical thinking, in ways similar to how the Cartesian plane or the concept of negative numbers allowed us to think in terms that were previously much more cumbersome to reason about.")

#text("I’ve seen some of these proposals being scoffed at as unnecessary, e.g. with claims that the pedagogical gains are not worth introducing incompatibilities with the existing body of textbooks. To me, that stance both proves the this post’s point of the lack of recognition of the importance of intuition, guided learning and understanding, but it also gets weakened by the current ability we now have, thanks to AI, to transform or repackage large volumes of content without much human effort.")

#text("I’m quite hopeful that the revolution this text is calling for will also bring about a fresh new look to such proposals for better notation and primitives that could make mathematics both remain rewarding for the experts, and become more accessible for those just taking their first steps 🙂")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696238")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Here’s my pitch: a motivated explanation is a proof with no surprising steps. The “motivation” comes as steps unnecessary for the proof but that help explain the steps necessary for the proof, eg toy examples motivating a scalable construction. 2 claims:")

#enum(start: 1, 
[#text("This is already well-defined enough to gate journal submissions")],
[#text("I object to Grant’s claim that “there will never be Lean for motivated explanations.” As a proof of concept, repurposing Language Modeling’s notion of surprisal to formally define what a surprising step looks like already gets us most of the way to a formal definition. To build a compiler for this, I’d train a “next tactic prediction model” M and require that each subsequent tactic be predicted with probability at least 2^-10 (equivalently, contribute at most 10 bits to the program’s description length under M, interpreted as a list of tactics for simplicity). Happy to design an MVP using open-source language models on Lean code – lmk if you’d like to see it! It should be dirt-cheap: since the language model never has to generate anything, it’ll only take 1 forward-pass 🙂")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-1/#comment-696275")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Hello — apologies for both how long and yet still incomplete this comment will be.")

#text("I finished my Ph.D. in mathematics about two years ago. I decided not to pursue math as a career, in large part because of how miserably competitive the math job market is at the moment, especially at the post-doc and early career point.")

#text("I love to teach, and I am very happy to have gotten to teach mathematics for six years. I quickly came to observe that being a math teacher at the university was as much about being a therapist as it was conveying the material. Almost every student I spoke with 1-1 relayed details of being yelled at by a math teacher at some point in their lives. Combine these experiences with math’s popular reputation — that skill at math can be used to “weed out” the “smart” from the “not-smart” — and it’s no wonder that the overwhelming majority of students had already been pushed over the brink with math before I even met them. Almost none felt math was something they could have a conversation about. Almost none felt math was something they could have any hope of personal ownership over. Math was a class they needed to survive, and they would carry the wounds from the experience with no real healing in sight.")

#text("All the Ph.D. students I knew, and most of the professors who would discuss the subject with me, were deeply saddened by this state of affairs. They also, to a person, rejected the notion that skill at math should carry such a fundamental judgement on a person’s identity, as it did for these students. However, while it is easy to ")#emph[#text("say")]#text(" these things, it is much more difficult to ")#emph[#text("act")]#text(" in accordance with them, when math conversational culture has, historically, been intertwined with justifications for categorizing people as “more than” or “less than,” with consequences of (shall we say) varying brutality for the people on the “less than” end.")

#text("The first suggestion in the search I navigated through before writing this comment was “Terence Tao( IQ)”.")

#text("Mathematics is a funny subject to have a personal relationship with. I love how oddly easy it is to learn humility through the study of mathematics. Most (not all) mathematicians I met in my Ph.D. are extremely kind and humble. I think this is the link between my love of math and my love of mathematicians — not just that we share an interest, but we share a worldview learned from constantly needing to evaluate and re-evaluate our own sense of who we are in the face of the subject itself. We share a part of our sense of self in math, and that links us in our understanding of each other.")

#text("However.")

#text("As much as I love mathematicians, I ")#emph[#text("hate")]#text(" listening to other Ph.D./research mathematicians teach math to undergraduates. Because, as much as math, the subject, tells you that you are bad at math and must always improve, most mathematicians do not get that message ")#emph[#text("socially")]#text(". They have almost always been protected by virtue of falling on the “more than” side of the socially-drawn line of intelligence.")

#text("Most people who teach math at the university level have not experienced reinforcement from ")#emph[#text("the people around them")]#text(": teachers, parents, friends — that they are “bad at math.” These teachers thus have almost no idea how to talk to the students for which they are responsible, almost all of whom have received that message ")#emph[#text("constantly")]#text(". They cannot parse the students’ genuine confusion with the subject from the effects of this abuse, and these teachers cannot mitigate the effects of this abuse enough to allow their students to access more than wrote learning. Wrote learning passes tests, so …")

#text("I have heard the message that I personally and specifically suck at math way more than my former colleagues. I am a gender minority, and being told you suck at math as a default comes with the territory. That can either be directly, or in policing of the language I use to describe concepts, or in just being left out of the conversation.")

#text("I tutored a high school student in math while I was in my Ph.D. program. She went from struggling in pre-calculus to being so confident in her senior year differential equations class that she was comfortable with stopping our sessions midway through the year as I prepared for my dissertation. I believe that a huge impetus to her growth over the years was that ")#emph[#text("I know how to talk like a teenage girl.")]#text(" I could tell her “Hey, you’re actually quite good at math, we just need to work on xyz and look you learned that so fast” in a voice that she could connect with.")

#text("Because it’s not ever just about understanding the math concepts — it is about understanding ")#emph[#text("yourself")]#text(" in relationship to those concepts. And, those people who have been abused by math teachers and math culture need someone ")#emph[#text("within")]#text(" math to help rehabilitate their self-concept. Without which, they will simply learn math as wrote, the backbone of any deep understanding and future growth within mathematics broken by the cruelty of general math culture.")

#text("It would be super cool if teaching math were a job that seemed worth it to me, because I do really love it. And it would be super cool if a lot more people felt inclined to teach the subject they love because they can earn a livable wage and not destroy their bodies in the process. It would definitely be super cool to have the money and administrative infrastructure for that.")

#text("The teaching bodies within U.S. universities have been getting increasingly poor over the years. Fewer tenured positions, more adjunct or freelance teaching positions. It’s complicated, and it’s been trending this way for a while. However, I do think though that mathematics ")#emph[#text("in particular")]#text(" is plagued by an ENORMOUS problem that most other disciplines do not have.")

#text("Mathematicians trust power to behave according to ")#emph[#text("their")]#text(" rationality. Accordingly, mathematicians are power-illiterate.")

#text("Culturally, that makes sense. Math is a discipline with a (mostly) unified rationality. Further, the goal posts a mathematician needs to clear to reach a Ph.D. do not leave a lot of room for interacting with many people who are very different from them. And not just in terms of subject matter, but practical life experience. ")#emph[#text("Structurally")]#text(", mathematics is biased toward homogeneity, and affordances of power ")#emph[#text("regarding math specifically")]#text(" are remarkably legible. Anything else though…")

#text("During my Ph.D., I had two experiences which showed me a bit about how math professors related to power.")

#text("The first was during COVID, when every other department on campus successfully argued with the administration to cut the number of required on-campus classes from 50% to 10-20%. The math department was the only one that did not negotiate, and so all the math Ph.D. students taught in-person that semester while Ph.D. students in other departments had almost no in-person classes. By the time we the grad students even knew about the in-person classes, the Dean of Arts and Sciences told me, it was “too late,” but then, ")#emph[#text("I was a Ph.D. student trying to argue what the department chair should have been arguing.")]#text(" I do not think the Dean of Arts and Sciences particularly cared about what ")#emph[#text("I ")]#text("was asking them to do.")

#text("The second was when I learned, somewhat accidentally, that an invited colloquium speaker was no longer a math professor due to a plethora of very credible sexual assault and harassment claims against him. Many of the claims were by his former Ph.D. students, and they referenced the advisor-advisee power dynamic being a big factor.")

#text("The speaker was disinvited after an expression of general dismay on the part of the Ph.D. students. Afterward, I spoke with the departmental chair. He seemed confused why it even mattered, because, well, the talk would be public, so what could possibly go wrong? I then spoke with a younger professor, who was one of the most aware of the social life within the department, and social dynamics more generally. He expressed his own difficulties with the situation. He could tell it was wrong, but he didn’t quite understand why. He told me there were a lot of things he had read about this situation that he had never really thought about that much before. And now, he was being called to have an opinion, he felt pinioned by his uncertainty. I deeply respect his honesty, and his underlying desire to make sure people are happy and treated well.")

#text("Mathematicians make shitty advocates. They don’t understand the people they are trying to advocate for. They don’t understand the true motivations and limitations that shape different situations. They don’t understand how power really works. Too often, they rely on those areas being “somebody else’s problem,” falling back on trusting it will all work out — at least ")#emph[#text("they")]#text(" will be taken care of in the end. Turning their eyes away like this means fewer people looking out for those that need help.")

#text("This system breaks people. I certainly became a worse teacher, and worse at relating to the younger Ph.D. students. “Well, this worked for me so if you can’t stomach this weird bullshit from such and such professor or class I don’t really know what to tell you” were words I felt too close to saying.")

#text("I’m happy I left math.")

#text("In many ways, AI is riding the coat-tails of abusive math culture. The language used to describe AI plays on the pre-conditioning of the audience that they shouldn’t even try to understand what’s in front of them. At the same time, dangling the carrot that maybe… that understanding doesn’t actually matter.")

#text("You too can have the power of Einstein’s brain through this fun internet slot machine! Maybe the right prompt will give you an Einstein blessing and you can move up that ladder you feel so far down on! Isn’t it wonderful how we are ")#emph[#text("democratizing genius")]#text("?")

#text("Yes, identifying that AI math is very different from the human understanding of math is core to the issue.")

#text("Yet, the Navier-Stokes counter-example, as strange as it might sound, is not ")#emph[#text("for")]#text(" mathematicians. It was not written with the intention of advancing human understanding of mathematics. The audience for this paper is journalists, who are happy to write articles that rely on the tropes that entrench further the belief that AI is the culmination that lies at the end of the “better than” hierarchy that haunts math culture. That the entity atop the “better than” hierarchy — and the people that puppet this wizard — deserve to do whatever they want forever, damn the consequences for those “less than” them.")

#text("Suddenly the rationale for “lay” people being so invested in AI, the fear of being too far down on the ladder “when the time comes” makes a lot more sense. Not because the singularity will happen, but because whether it happens or not, the people at the center of this movement demonstrably do not care about the extent of human suffering they will need to cause in order to keep and grow their power.")

#text("I was not originally a mathematician. I have a background in political campaigning. The people I met in politics were afraid of the economists. The economists I met were afraid of the mathematicians. I followed my nose up the perceived “who gets to dunk on who” ladder and accidentally found that I do actually like math and got a lot out of it, and the people at the heart of math are mostly nice and dunk-free.")

#text("The dunk-chain exists nonetheless.")

#text("Successful politicians know how to talk to people. It might not follow ")#emph[#text("your")]#text(" logic that their “know-how” has the results that it does, but that indicates the limitations of your logic, not any “fundamental” fault in the politician or the people they’re talking to.")

#text("Mathematicians, by and large, don’t know how to talk to people. Them learning how is hamstrung — mathematicians always have that easy out. If the interaction is unsuccessful, it can sooooo easily become justified by, well, whoever they were talking to is actually just too far down, too “less than.” The person on the other end will more often accept that judgement than not. The best intentions struggle against such ingrained habits.")

#text("For math to be a better subject, mathematicians need to expend the effort to learn how to talk to people. Not just write or exposit — ")#emph[#text("talk")]#text(". They need to make the investment in changing their own language habits. They need to overcome social passivity and vociferously correct community members, journalists, high school teachers, elementary school teachers, parents, ")#emph[#text("anyone")]#text(", in order to over-write the language of hierarchy and subordination with support and direction.")

#text("Mathematicians need to take responsibility for their own culture.")

#text("Thurston pushes us to recognize that this culture is more than the math itself. Beyond Thurston, though, it’s even more than the understanding of the math. Math culture also encompasses ")#emph[#text("how humans understand themselves")]#text(". Until we recognize this, and refuse to invest in math culture that destroys people’s sense of self and their own abilities regarding math, the cultural landscape will remain open for AI companies, among others, to do whatever they want.")

#text("The good news is that mathematicians can start doing this for no extra money down. You don’t necessarily need funding to change a culture. The bad news is that mathematicians will need to make significant sacrifices from what they already have. No more easy outs. No more other people being “less than.” No more enjoying the math “cultural cache,” however surreptitiously. Less time for doing math. Less time for talking to colleagues. More time having deeply uncomfortable conversations. More time finding opportunities to have those conversations. More time on learning about institutions, how to read power dynamics, and, well. History.")

#text("Not every mathematician can make these sacrifices and keep their job. But some could. Probably, enough could to fundamentally change how the subject of mathematics lives in human society. They just need to want this change more than the math, social cache, and personal comfort they would need to give up to make it happen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-696436")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I don’t think people ever really thought the primary point of math was solving problems — that’s just a simplification of “this is where there’s a stable solution of providing value that prevents a bureaucratic, hard to measure, mess”. When humans aren’t driving the problem solving, I think it’s safe to say they won’t be driving much else in that field for much longer.")

#text("Eventually if I want a talk, I’ll just ask the ai to give me a talk about the famous theorem it proved in lean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e7929e0eaced3cb823b10f5f8fceff01a79434634357702bf31712da24f067f-44676ded7ae6e8d9339ae89b79ed8d08a39442b1fcf6e59b6ea3d3793eef2e9b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberto Avanzi")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-696476")[#strong[#text("Roberto Avanzi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("I would rebut only one thing:")

#text("”The scope of a proof is to explain why a particular theorem is true.”")

#text("is a bit narrow. I think the proper phrasing should be:")

#text("”The scope of a proof is to provide a rigorous argument that a particular theorem is true.”")

#text("Proofs that actually tell us *why* are rare. All current proofs of the four colour theorem show us that the statement is true, but do not point to a principle that makes us understand WHY four colours are ok and not five. And not all theorems have a why in their current framework.")

#text("The motivated explanation goes further, it builds a framework into which explaining the *why* comes natural, and often it builds the machinery that a proof can use, delegating the technical aspects to the machinery itself. But it does not necessarily bring out the why, if the machinery is contrived.")

#text("Mathematics is a search for truth and beauty. We should reward publications that give a reason for the truth, wrapped in beauty. A long, chaotic, AI proof may be truth but it is not beautiful. If AIs can decode beauty, they will achieve something humans never achieved: we can recognise beauty but do not know how to formalise it. But, I am not sure they will ever be able to.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-696569")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2026")])]

#text("What makes you think that AI won’t provide these “motivated explanations” too, just like they provide proofs?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-696850")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("It’s interesting that proof used to be a good benchmark to tell when human understanding of math had developed. Proof has developed a connotation of honor because it’s finding used to represent a kind of heroism: a person had done work that was helpful to all of us. But now things can be proven without helpful work having been done. And personally, it is very frustrating to see something that used to have a certain social meaning be used in a way where the meaning has shattered. But nevertheless we can’t go back. So we need to put that meaning onto something else, and I think this is a good candidate. But I wish the heroism was preserved somehow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42de12801e7b5b014e04235fd83de6d2442e0e5ca555c73c12d76decfe997514-0ebd082d8aadfb7d8c0f1c21ed06e30f66668643366865ccf24d7fced5bc4c08.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keaswaran")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-696897")[#strong[#text("keaswaran")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Various people have compared the presentation of a mathematical proof to pointing out the landmarks someone needs to follow in order to reach a mountaintop. Following anonymous’s point about finding a proof being an act of heroism, we might think of that as being like the first person to scale a mountain peak. Now that we have plenty of machinery (including helicopters) that can enable reaching lots of peaks, the more valuable work is not getting up there first, but figuring out how to lay out the network of trails so that anyone else can easily visit the peak without having to use a helicopter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e4ac3e8c6505cd8940c10467caef87ce1bf971391a218eb0d6f5f2de65be32c-9aa00a5a608353de938e6d77c35cfd0c41a3c880d244516e3c0e2d56e7914fd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Gochal")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-697958")[#strong[#text("Joseph Gochal")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I think that the work being done by humans to explain and understand the latest Navier-Stokes result seems like a great example of what this article is getting at. Yeah, AI proved and Lean verified it. But we only understand it because of the work of people with deep expertise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d90860f6d32d39fbc73536d92f9dce0b474aaf2bb2984fede69d5a7dde624b6-8fbb47bcd00b944066a142caff7ed6825dd61acb9496245e140d159184d35d32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marek D.")]], [#link("https://terrytao.wordpress.com/2026/09/18/if-math-is-more-than-proof-we-need-to-better-celebrate-the-rest-of-it/comment-page-2/#comment-698341")[#strong[#text("Marek D.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Well, what if AI turned out to be much better at generating these kind of exposition/motivated explanations than the humans? I encourage my students to not just use AI to get the result but to explain the solution exactly to them – if they choose to use it. It is infinitely more patient than me, and it will only get better.")
]
