// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/
// Converted to Typst by tao2typ: "2026-10-14T16:35:57.579972+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "From Bose-Einstein condensates to the nonlinear Schrodinger equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("From Bose-Einstein condensates to the nonlinear Schrodinger equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger equation")]

#align(center)[#tao-fit-display[#mitex("i \\hbar \\partial_t |\\psi \\rangle = H |\\psi\\rangle")]]

#text("is the fundamental equation of motion for (non-relativistic) quantum mechanics, modeling both one-particle systems and ")#mi("{N}")#text("-particle systems for ")#mi("{N>1}")#text(". Remarkably, despite being a ")#emph[#text("linear")]#text(" equation, solutions ")#mi("{|\\psi\\rangle}")#text(" to this equation can be governed by a ")#emph[#text("non-linear")]#text(" equation in the large particle limit ")#mi("{N \\rightarrow \\infty}")#text(". In particular, when modeling a ")#link("http://en.wikipedia.org/wiki/Bose%E2%80%93Einstein_condensate")[#text("Bose-Einstein condensate")]#text(" with a suitably scaled interaction potential ")#mi("{V}")#text(" in the large particle limit, the solution can be governed by the ")#emph[#text("cubic nonlinear Schrödinger equation")]#text(" ")#metadata(none) <tao-7e30cb8b63fde7d4f89e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("i \\partial_t \\phi = \\Delta \\phi + \\lambda \\left|\\phi\\right|^2 \\phi.", block: true)]]

#text("I recently attended a talk by ")#link("http://www.ma.utexas.edu/dev/math/People/fac.html?uid=488")[#text("Natasa Pavlovic")]#text(" on the rigorous derivation of this type of limiting behaviour, which was initiated by the pioneering work of Hepp and Spohn, and has now attracted a vast recent literature. The rigorous details here are rather sophisticated; but the heuristic explanation of the phenomenon is fairly simple, and actually rather pretty in my opinion, involving the foundational quantum mechanics of ")#mi("{N}")#text("-particle systems. I am recording this heuristic derivation here, partly for my own benefit, but perhaps it will be of interest to some readers.")

#text("This discussion will be purely formal, in the sense that (important) analytic issues such as differentiability, existence and uniqueness, etc. will be largely ignored.")

#metadata(none) <tao-102c8f436612a21bcceb>

#heading(level: 1)[#strong[#text(" — 1. A quick review of classical mechanics — ")]]

#text("The phenomena discussed here are purely quantum mechanical in nature, but to motivate the quantum mechanical discussion, it is helpful to first quickly review the more familiar (and more conceptually intuitive) classical situation.")

#text("Classical mechanics can be formulated in a number of essentially equivalent ways: ")#link("http://en.wikipedia.org/wiki/Classical_mechanics")[#text("Newtonian")]#text(", ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamiltonian")]#text(", and ")#link("http://en.wikipedia.org/wiki/Lagrangian_mechanics")[#text("Lagrangian")]#text(". The formalism of Hamiltonian mechanics for a given physical system can be summarised briefly as follows:")

#list(
[#text("The physical system has a ")#link("https://terrytao.wordpress.com/2007/12/21/pcm-article-phase-space/")[#text("phase space")]#text(" ")#mi("{\\Omega}")#text(" of states ")#mi("{\\vec x}")#text(" (which is often parameterised by position variables ")#mi("{q}")#text(" and momentum variables ")#mi("{p}")#text("). Mathematically, it has the structure of a ")#link("http://en.wikipedia.org/wiki/Symplectic_manifold")[#text("symplectic manifold")]#text(", with some ")#link("http://en.wikipedia.org/wiki/Symplectic_form")[#text("symplectic form")]#text(" ")#mi("{\\omega}")#text(" (which would be ")#mi("{\\omega = dp \\wedge dq}")#text(" if one had position and momentum coordinates available).")],
[#text("The complete state of the system at any given time ")#mi("{t}")#text(" is given (in the case of ")#emph[#text("pure states")]#text(") by a point ")#mi("{\\vec x(t)}")#text(" in the phase space ")#mi("{\\Omega}")#text(".")],
[#text("Every physical observable (e.g., energy, momentum, position, etc.) ")#mi("{A}")#text(" is associated to a function (also called ")#mi("{A}")#text(") mapping the phase space ")#mi("{\\Omega}")#text(" to the range of the observable (e.g. for real observables, ")#mi("{A}")#text(" would be a function from ")#mi("{\\Omega}")#text(" to ")#mi("{{\\mathbb R}}")#text("). If one measures the observable ")#mi("{A}")#text(" at time ")#mi("{t}")#text(", one will obtain the measurement ")#mi("{A(x(t))}")#text(".")],
[#text("There is a special observable, the ")#link("https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/")[#text("Hamiltonian")]#text(" ")#mi("{H: \\Omega \\rightarrow {\\mathbb R}}")#text(", which governs the evolution of the state ")#mi("{\\vec x(t)}")#text(" through time, via ")#emph[#text("Hamilton’s equations of motion")]#text(". If one has position and momentum coordinates ")#mi("{\\vec x(t) = (q_i(t), p_i(t))_{i=1}^n}")#text(", these equations are given by the formulae")

#align(center)[#tao-fit-display[#mitex("\\partial_t p_i = - \\frac{\\partial H}{\\partial q_i}; \\partial_t q_i = \\frac{\\partial H}{\\partial p_i};")]]

#text("more abstractly, just from the symplectic form ")#mi("{\\omega}")#text(" on the phase space, the equations of motion can be written as ")#metadata(none) <tao-f9d6cd1ed5cf1ead7b54>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t \\vec x(t) = - \\nabla_\\omega H(\\vec x(t)),")]]

#text("where ")#mi("{\\nabla_\\omega H}")#text(" is the symplectic gradient of ")#mi("{H}")#text(".")]
)

#text("Hamilton’s equation of motion can also be expressed in a dual form in terms of observables ")#mi("{A}")#text(", as ")#emph[#text("Poisson’s equation of motion")]

#align(center)[#tao-fit-display[#mitex("\\partial_t A(\\vec x(t)) = - \\{ H, A \\}(\\vec x(t))")]]

#text("for any observable ")#mi("{A}")#text(", where ")#mi("{\\{H,A\\} := \\nabla_\\omega H \\cdot \\nabla A}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Poisson_bracket")[#text("Poisson bracket")]#text(". One can express Poisson’s equation more abstractly as ")#metadata(none) <tao-e75869ecfb7601f52063>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t A = -\\{H,A\\}.")]]

#text("In the above formalism, we are assuming that the system is in a ")#emph[#text("pure state")]#text(" at each time ")#mi("{t}")#text(", which means that it only occupies a single point ")#mi("{\\vec x(t)}")#text(" in phase space. One can also consider ")#emph[#text("mixed states")]#text(" in which the state of the system at a time ")#mi("{t}")#text(" is not fully known, but is instead given by a ")#emph[#text("probability distribution")]#text(" ")#mi("{\\rho(t,\\vec x)\\ dx}")#text(" on phase space. The act of measuring an observable ")#mi("{A}")#text(" at a time ")#mi("{t}")#text(" will thus no longer be deterministic, but will itself be a random variable, whose expectation ")#mi("{\\langle A \\rangle}")#text(" is given by ")#metadata(none) <tao-cebaaa2027a6822af328>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\langle A \\rangle(t) = \\int_\\Omega A(\\vec x) \\rho(t,\\vec x)\\ d\\vec x.")]]

#text("The equation of motion of a mixed state ")#mi("{\\rho}")#text(" is given by the ")#link("http://en.wikipedia.org/wiki/Advection_equation")[#text("advection equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\rho = \\text{div}( \\rho \\nabla_\\omega H )")]]

#text("using the same vector field ")#mi("{-\\nabla_\\omega H}")#text(" that appears in ")#link(<tao-f9d6cd1ed5cf1ead7b54>)[#text("(2)")]#text("; this equation can also be derived from ")#link(<tao-e75869ecfb7601f52063>)[#text("(3)")]#text(", ")#link(<tao-cebaaa2027a6822af328>)[#text("(4)")]#text(", and a duality argument.")

#text("Pure states can be viewed as the special case of mixed states in which the probability distribution ")#mi("{\\rho(t,\\vec x)\\ d\\vec x}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Dirac_delta_function")[#text("Dirac mass")]#text(" ")#mi("{\\delta_{\\vec x(t)}(\\vec x)}")#text(". (We ignore for now the formal issues of how to perform operations such as derivatives on Dirac masses; this can be accomplished using the ")#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/")[#text("theory of distributions")]#text(" (or, equivalently, by working in the dual setting of observables) but this is not our concern here.) One can thus think of mixed states as continuous averages of pure states, or equivalently the space of mixed states is the convex hull of the space of pure states.")

#text("Suppose one had a ")#mi("{2}")#text("-particle system, in which the joint phase space ")#mi("{\\Omega = \\Omega_1 \\times \\Omega_2}")#text(" is the product of the two one-particle phase spaces. A pure joint state is then a point ")#mi("{x = (\\vec x_1,\\vec x_2)}")#text(" in ")#mi("{\\Omega}")#text(", where ")#mi("{\\vec x_1}")#text(" represents the state of the first particle, and ")#mi("{\\vec x_2}")#text(" is the state of the second particle. If the joint Hamiltonian ")#mi("{H: \\Omega \\rightarrow {\\mathbb R}}")#text(" split as")

#align(center)[#tao-fit-display[#mitex("H(\\vec x_1,\\vec x_2) = H_1(\\vec x_1) + H_2(\\vec x_2)")]]

#text("then the equations of motion for the first and second particles would be completely ")#emph[#text("decoupled")]#text(", with no interactions between the two particles. However, in practice, the joint Hamiltonian contains coupling terms between ")#mi("{\\vec x_1, \\vec x_2}")#text(" that prevents one from totally decoupling the system; for instance, one may have")

#align(center)[#tao-fit-display[#tao-math("H(\\vec x_1,\\vec x_2) = \\frac{\\left|p_1\\right|^2}{2m_1} + \\frac{\\left|p_2\\right|^2}{2m_2} + V(q_1-q_2),", block: true)]]

#text("where ")#mi("{\\vec x_1=(q_1,p_1)}")#text(", ")#mi("{\\vec x_2=(q_2,p_2)}")#text(" are written using position coordinates ")#mi("{q_i}")#text(" and momentum coordinates ")#mi("{p_i}")#text(", ")#mi("{m_1,m_2 > 0}")#text(" are constants (representing mass), and ")#mi("{V(q_1-q_2)}")#text(" is some ")#emph[#text("interaction potential")]#text(" that depends on the spatial separation ")#mi("{q_1-q_2}")#text(" between the two particles.")

#text("In a similar spirit, a mixed joint state is a joint probability distribution ")#mi("{\\rho(\\vec x_1,\\vec x_2)\\ d\\vec x_1 d\\vec x_2}")#text(" on the product state space. To recover the (mixed) state of an individual particle, one must consider a ")#link("http://en.wikipedia.org/wiki/Marginal_distribution")[#text("marginal distribution")]#text(" such as")

#align(center)[#tao-fit-display[#mitex("\\rho_1(\\vec x_1) := \\int_{\\Omega_2} \\rho(\\vec x_1,\\vec x_2) \\ d\\vec x_2")]]

#text("(for the first particle) or")

#align(center)[#tao-fit-display[#mitex("\\rho_2(\\vec x_2) := \\int_{\\Omega_1} \\rho(\\vec x_1,\\vec x_2) \\ d\\vec x_1")]]

#text("(for the second particle). Similarly for ")#mi("{N}")#text("-particle systems: if the joint distribution of ")#mi("{N}")#text(" distinct particles is given by ")#mi("{\\rho(\\vec x_1,\\ldots,\\vec x_N)\\ \\vec dx_1 \\ldots \\vec dx_N}")#text(", then the distribution of the first particle (say) is given by")

#align(center)[#tao-fit-display[#mitex("\\rho_1(\\vec x_1) = \\int_{\\Omega_2 \\times \\ldots \\times \\Omega_N} \\rho(\\vec x_1,\\vec x_2,\\ldots,\\vec x_N)\\ d\\vec x_2 \\ldots d\\vec x_N,")]]

#text("the distribution of the first two particles is given by")

#align(center)[#tao-fit-display[#mitex("\\rho_{12}(\\vec x_1,\\vec x_2) = \\int_{\\Omega_3 \\times \\ldots \\times \\Omega_N} \\rho(\\vec x_1,\\vec x_2,\\ldots,\\vec x_N)\\ d\\vec x_3 \\ldots d\\vec x_N,")]]

#text("and so forth.")

#text("A typical Hamiltonian in this case may take the form")

#align(center)[#tao-fit-display[#tao-math("H(\\vec x_1,\\ldots,\\vec x_n) = \\sum_{j=1}^N \\frac{\\left|p_j\\right|^2}{2m_j} + \\sum_{1 \\leq j < k \\leq N} V_{jk}(q_j-q_k)", block: true)]]

#text("which is a combination of single-particle Hamiltonians ")#mi("{H_j}")#text(" and interaction perturbations. If the momenta ")#mi("{p_j}")#text(" and masses ")#mi("{m_j}")#text(" are normalised to be of size ")#mi("{O(1)}")#text(", and the potential ")#mi("{V_{jk}}")#text(" has an average value (i.e. an ")#mi("{L^1}")#text(" norm) of ")#mi("{O(1)}")#text(" also, then the former sum has size ")#mi("{O(N)}")#text(" and the latter sum has size ")#mi("{O(N^2)}")#text(", so the latter will dominate. In order to balance the two components and get a more interesting limiting dynamics when ")#mi("{N \\rightarrow \\infty}")#text(", we shall therefore insert a normalising factor of ")#mi("{\\frac{1}{N}}")#text(" on the right-hand side, giving a Hamiltonian")

#align(center)[#tao-fit-display[#tao-math("H(\\vec x_1,\\ldots,\\vec x_n) = \\sum_{j=1}^N \\frac{\\left|p_j\\right|^2}{2m_j} + \\frac{1}{N} \\sum_{1 \\leq j < k \\leq N} V_{jk}(q_j-q_k).", block: true)]]

#text("Now imagine a system of ")#mi("{N}")#text(" ")#emph[#text("indistinguishable")]#text(" particles. By this, we mean that all the state spaces ")#mi("{\\Omega_1 = \\ldots = \\Omega_N}")#text(" are identical, and all observables (including the Hamiltonian) are symmetric functions of the product space ")#mi("{\\Omega = \\Omega_1^N}")#text(" (i.e. invariant under the action of the symmetric group ")#mi("{S_N}")#text("). In such a case, one may as well average over this group (since this does not affect any physical observable), and assume that all mixed states ")#mi("{\\rho}")#text(" are also symmetric. (One cost of doing this, though, is one has to largely give up pure states ")#mi("{(\\vec x_1,\\ldots,\\vec x_N)}")#text(", since such states will not be symmetric except in the very exceptional case ")#mi("{\\vec x_1=\\ldots=\\vec x_N}")#text(".)")

#text("A typical example of a symmetric Hamiltonian is")

#align(center)[#tao-fit-display[#tao-math("H(\\vec x_1,\\ldots,\\vec x_n) = \\sum_{j=1}^N \\frac{\\left|p_j\\right|^2}{2m} + \\frac{1}{N} \\sum_{1 \\leq j < k \\leq N} V(q_j-q_k)", block: true)]]

#text("where ")#mi("{V}")#text(" is even (thus all particles have the same individual Hamiltonian, and interact with the other particles using the same interaction potential). In many physical systems, it is natural to consider only ")#emph[#text("short-range")]#text(" interaction potentials, in which the interaction between ")#mi("{q_j}")#text(" and ")#mi("{q_k}")#text(" is localised to the region ")#mi("{q_j-q_k=O(r)}")#text(" for some small ")#mi("{r}")#text(". We model this by considering Hamiltonians of the form")

#align(center)[#tao-fit-display[#mitex("H(\\vec x_1,\\ldots,\\vec x_n) = \\sum_{j=1}^N H(\\vec x_j) + \\frac{1}{N} \\sum_{1 \\leq j < k \\leq N} \\frac{1}{r^d} V(\\frac{\\vec x_j-\\vec x_k}{r})")]]

#text("where ")#mi("{d}")#text(" is the ambient dimension of each particle (thus in physical models, ")#mi("{d}")#text(" would usually be ")#mi("{3}")#text("); the factor of ")#mi("{\\frac{1}{r^d}}")#text(" is a normalisation factor designed to keep the ")#mi("{L^1}")#text(" norm of the interaction potential of size ")#mi("{O(1)}")#text(". It turns out that an interesting limit occurs when ")#mi("{r}")#text(" goes to zero as ")#mi("{N}")#text(" goes to infinity by some power law ")#mi("{r = N^{-\\beta}}")#text("; imagine for instance ")#mi("{N}")#text(" particles of “radius” ")#mi("{r}")#text(" bouncing around in a box, which is a basic model for classical gases.")

#text("An important example of a symmetric mixed state is a ")#emph[#text("factored")]#text(" state")

#align(center)[#tao-fit-display[#mitex("\\rho(\\vec x_1,\\ldots,\\vec x_N) = \\rho_1(\\vec x_1) \\ldots \\rho_1(\\vec x_N)")]]

#text("where ")#mi("{\\rho_1}")#text(" is a single-particle probability density function; thus ")#mi("{\\rho}")#text(" is the tensor product of ")#mi("{N}")#text(" copies of ")#mi("{\\rho_1}")#text(". If there are no interaction terms in the Hamiltonian, then Hamiltonian’s equation of motion will preserve the property of being a factored state (with ")#mi("{\\rho_1}")#text(" evolving according to the one-particle equation); but with interactions, the factored nature may be lost over time.")

#heading(level: 1)[#strong[#text(" — 2. A quick review of quantum mechanics — ")]]

#text("Now we turn to quantum mechanics. This theory is fundamentally rather different in nature than classical mechanics (in the sense that the basic objects, such as states and observables, are a different type of mathematical object than in the classical case), but shares many features in common also, particularly those relating to the Hamiltonian and other observables. (This relationship is made more precise via the ")#link("http://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(", and more precise still using ")#emph[#text("semi-classical analysis")]#text(".)")

#text("The formalism of quantum mechanics for a given physical system can be summarised briefly as follows:")

#list(
[#text("The physical system has a ")#emph[#text("phase space")]#text(" ")#mi("{{\\Bbb H}}")#text(" of states ")#mi("{|\\psi\\rangle}")#text(" (which is often parameterised as a complex-valued function of the position space). Mathematically, it has the structure of a complex ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space")]#text(", which is traditionally manipulated using ")#link("http://en.wikipedia.org/wiki/Bra-ket_notation")[#text("bra-ket notation")]#text(".")],
[#text("The complete ")#link("http://en.wikipedia.org/wiki/Quantum_state")[#text("state")]#text(" of the system at any given time ")#mi("{t}")#text(" is given (in the case of ")#emph[#text("pure states")]#text(") by a unit vector ")#mi("{|\\psi(t)\\rangle}")#text(" in the phase space ")#mi("{{\\Bbb H}}")#text(".")],
[#text("Every physical observable ")#mi("{A}")#text(" is associated to a linear operator on ")#mi("{{\\Bbb H}}")#text("; real-valued observables are associated to self-adjoint linear operators. If one measures the observable ")#mi("{A}")#text(" at time ")#mi("{t}")#text(", one will obtain the random variable whose expectation ")#mi("{\\langle A \\rangle}")#text(" is given by ")#mi("{\\langle \\psi(t) | A | \\psi(t) \\rangle}")#text(". (The full distribution of ")#mi("{A}")#text(" is given by the ")#link("http://en.wikipedia.org/wiki/Spectral_measure#Spectral_measure")[#text("spectral measure")]#text(" of ")#mi("{A}")#text(" relative to ")#mi("{|\\psi(t)\\rangle}")#text(".)")],
[#text("There is a special observable, the ")#emph[#text("Hamiltonian")]#text(" ")#mi("{H: {\\Bbb H} \\rightarrow {\\Bbb H}}")#text(", which governs the evolution of the state ")#mi("{|\\psi(t)\\rangle}")#text(" through time, via ")#emph[#text("Schrödinger’s equations of motion")]

#metadata(none) <tao-955e5e8db1617368bfac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("i\\hbar \\partial_t |\\psi(t)\\rangle = H |\\psi(t) \\rangle.")]]]
)

#text("Schrödinger’s equation of motion can also be expressed in a dual form in terms of observables ")#mi("{A}")#text(", as ")#link("http://en.wikipedia.org/wiki/Heisenberg_picture")[#text("Heisenberg’s equation of motion")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\langle \\psi | A | \\psi \\rangle = \\frac{i}{\\hbar} \\langle \\psi | [ H, A ] | \\psi \\rangle")]]

#text("or more abstractly as ")#metadata(none) <tao-d346039bbc325783b16a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\partial_t A = \\frac{i}{\\hbar} [ H, A ]")]]

#text("where ")#mi("{[,]}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" or ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie bracket")]#text(" (compare with ")#link(<tao-e75869ecfb7601f52063>)[#text("(3)")]#text(").")

#text("The states ")#mi("{|\\psi\\rangle}")#text(" are pure states, analogous to the pure states ")#mi("{x}")#text(" in Hamiltonian mechanics. One also has ")#emph[#text("mixed states")]#text(" ")#mi("{\\rho}")#text(" in quantum mechanics. Whereas in classical mechanics, a mixed state ")#mi("{\\rho}")#text(" is a probability distribution (a non-negative function of total mass ")#mi("{\\int_\\Omega \\rho = 1}")#text("), in quantum mechanics a mixed state is a non-negative (i.e. ")#link("http://en.wikipedia.org/wiki/Positive_semi-definite")[#text("positive semi-definite")]#text(") ")#emph[#text("operator")]#text(" ")#mi("{\\rho}")#text(" on ")#mi("{{\\Bbb H}}")#text(" of total ")#link("http://en.wikipedia.org/wiki/Trace_(linear_algebra)")[#text("trace")]#text(" ")#mi("{\\text{tr} \\rho = 1}")#text(". If one measures an observable ")#mi("{A}")#text(" at a mixed state ")#mi("{\\rho}")#text(", one obtains a random variable with expectation ")#mi("{\\text{tr} A \\rho}")#text(". From ")#link(<tao-d346039bbc325783b16a>)[#text("(6)")]#text(" and duality, one can infer that the correct equation of motion for mixed states must be given by ")#metadata(none) <tao-614894decf7b627e4a77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t \\rho = \\frac{i}{\\hbar} [H,\\rho].")]]

#text("One can view pure states as the special case of mixed states which are rank one projections,")

#align(center)[#tao-fit-display[#mitex("\\rho= |\\psi\\rangle \\langle \\psi|.")]]

#text("Morally speaking, the space of mixed states is the convex hull of the space of pure states (just as in the classical case), though things are a little trickier than this when the phase space ")#mi("{{\\Bbb H}}")#text(" is infinite dimensional, due to the presence of continuous spectrum in the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(".")

#text("Pure states suffer from a ")#emph[#text("phase ambiguity")]#text(": a phase rotation ")#mi("{e^{i\\theta} |\\psi\\rangle}")#text(" of a pure state ")#mi("{|\\psi \\rangle}")#text(" leads to the same mixed state, and the two states cannot be distinguished by any physical observable.")

#text("In a single particle system, modeling a (scalar) quantum particle in a ")#mi("{d}")#text("-dimensional position space ")#mi("{{\\mathbb R}^d}")#text(", one can identify the Hilbert space ")#mi("{{\\Bbb H}}")#text(" with ")#mi("{L^2({\\mathbb R}^d \\rightarrow {\\mathbb C})}")#text(", and describe the pure state ")#mi("{|\\psi\\rangle}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Wave_function")[#text("wave function")]#text(" ")#mi("{\\psi: {\\mathbb R}^d \\rightarrow {\\mathbb C}}")#text(", which is normalised as")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\mathbb R}^d} \\left|\\psi(x)\\right|^2\\ dx = 1", block: true)]]

#text("as ")#mi("{|\\psi\\rangle}")#text(" has to be a unit vector. (If the quantum particle has additional features such as ")#link("http://en.wikipedia.org/wiki/Spin_(physics)")[#text("spin")]#text(", then one needs a fancier wave function, but let’s ignore this for now.) A mixed state is then a function ")#mi("{\\rho: {\\mathbb R}^d \\times {\\mathbb R}^d \\rightarrow {\\mathbb C}}")#text(" which is Hermitian (i.e. ")#mi("{\\rho(x,x^{\\prime}) = \\overline{\\rho(x^{\\prime},x)}}")#text(") and positive definite, with unit trace ")#mi("{\\int_{{\\mathbb R}^d} \\rho(x,x)\\ dx = 1}")#text("; a pure state ")#mi("{\\psi}")#text(" corresponds to the mixed state ")#mi("{\\rho(x,x^{\\prime}) = \\psi(x) \\overline{\\psi(x^{\\prime})}}")#text(".")

#text("A typical Hamiltonian in this setting is given by the operator")

#align(center)[#tao-fit-display[#tao-math("H \\psi(x) := \\frac{\\left|p\\right|^2}{2m} \\psi(x) + V(x) \\psi(x)", block: true)]]

#text("where ")#mi("{m > 0}")#text(" is a constant, ")#mi("{p}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Momentum_operator")[#text("momentum operator")]#text(" ")#mi("{p := -i \\hbar \\nabla_x}")#text(", and ")#mi("{\\nabla_x}")#text(" is the gradient in the ")#mi("{x}")#text(" variable (so ")#tao-math("{\\left|p\\right|^2 = -\\hbar^2 \\Delta_x}", block: false)#text(", where ")#mi("{\\Delta_x}")#text(" is the Laplacian; note that ")#mi("{\\nabla_x}")#text(" is skew-adjoint and should thus be thought of as being imaginary rather than real), and ")#mi("{V: {\\mathbb R}^d \\rightarrow {\\mathbb R}}")#text(" is some potential. Physically, this depicts a particle of mass ")#mi("{m}")#text(" in a potential well given by the potential ")#mi("{V}")#text(".")

#text("Now suppose one has an ")#mi("{N}")#text("-particle system of scalar particles. A pure state of such a system can then be given by an ")#mi("{N}")#text("-particle wave function ")#mi("{\\psi: ({\\mathbb R}^d)^N \\rightarrow {\\mathbb C}}")#text(", normalised so that")

#align(center)[#tao-fit-display[#tao-math("\\int_{({\\mathbb R}^d)^N} \\left|\\psi(x_1,\\ldots,x_N)\\right|^2\\ dx_1 \\ldots dx_N = 1", block: true)]]

#text("and a mixed state is a Hermitian positive semi-definite function ")#mi("{\\rho: ({\\mathbb R}^d)^N \\times ({\\mathbb R}^d)^N \\rightarrow {\\mathbb C}}")#text(" with trace")

#align(center)[#tao-fit-display[#mitex("\\int_{({\\mathbb R}^d)^N} \\rho(x_1,\\ldots,x_N; x_1,\\ldots,x_N)\\ dx_1 \\ldots dx_N = 1,")]]

#text("with a pure state ")#mi("{\\psi}")#text(" being identified with the mixed state")

#align(center)[#tao-fit-display[#mitex("\\rho(x_1,\\ldots,x_N; x^{\\prime}_1,\\ldots,x^{\\prime}_N) := \\psi(x_1,\\ldots,x_N) \\overline{\\psi(x^{\\prime}_1,\\ldots,x^{\\prime}_N)}.")]]

#text("In classical mechanics, the state of a single particle was the marginal distribution of the joint state. In quantum mechanics, the state of a single particle is instead obtained as the ")#emph[#text("partial trace")]#text(" of the joint state. For instance, the state of the first particle is given as")

#align(center)[#tao-fit-display[#mitex("\\rho_1(x_1; x^{\\prime}_1) := \\int_{({\\mathbb R}^d)^{N-1}} \\rho(x_1,x_2,\\ldots,x_N; x^{\\prime}_1,x_2,\\ldots,x_N)\\ dx_2 \\ldots dx_N,")]]

#text("the state of the first two particles is given as")

#align(center)[#tao-fit-display[#mitex("\\rho_{12}(x_1,x_2; x^{\\prime}_1,x^{\\prime}_2) := \\int_{({\\mathbb R}^d)^{N-2}} \\rho(x_1,x_2,x_3,\\ldots,x_N;")]]

#align(center)[#tao-fit-display[#mitex("x^{\\prime}_1,x^{\\prime}_2,x_3,\\ldots,x_N)\\ dx_3 \\ldots dx_N,")]]

#text("and so forth. (These formulae can be justified by considering observables of the joint state that only affect, say, the first two position coordinates ")#mi("{x_1,x_2}")#text(" and using duality.)")

#text("A typical Hamiltonian in this setting is given by the operator")

#tao-aligned(keep: true)[


#tao-math("H \\psi(x_1,\\ldots,x_N)  & = \\sum_{j=1}^N \\frac{\\left|p_j\\right|^2}{2m_j} \\psi(x_1,\\ldots,x_N)", block: true)



#tao-math(" & + \\frac{1}{N} \\sum_{1 \\leq j < k \\leq N} V_{jk}(x_j-x_k) \\psi(x_1,\\ldots,x_N)", block: true)
]

#text("where we normalise just as in the classical case, and ")#mi("{p_j := -i \\hbar\\nabla_{x_j}}")#text(".")

#text("An interesting feature of quantum mechanics – not present in the classical world – is that even if the ")#mi("{N}")#text("-particle system is in a pure state, individual particles may be in a mixed state: the partial trace of a pure state need not remain pure. Because of this, when considering a subsystem of a larger system, one cannot always assume that the subsystem is in a pure state, but must work instead with mixed states throughout, unless there is some reason (e.g. a lack of coupling) to assume that pure states are somehow preserved.")

#text("Now consider a system of ")#mi("{N}")#text(" indistinguishable quantum particles. As in the classical case, this means that all observables (including the Hamiltonian) for the joint system are invariant with respect to the action of the symmetric group ")#mi("{S_N}")#text(". Because of this, one may as well assume that the (mixed) state of the joint system is also symmetric with respect to this action. In the special case when the particles are ")#link("http://en.wikipedia.org/wiki/Boson")[#text("bosons")]#text(", one can also assume that pure states ")#mi("{|\\psi\\rangle}")#text(" are also symmetric with respect to this action (in contrast to ")#link("http://en.wikipedia.org/wiki/Fermion")[#text("fermions")]#text(", where the action on pure states is anti-symmetric). A typical Hamiltonian in this setting is given by the operator")

#tao-aligned(keep: true)[


#tao-math("H \\psi(x_1,\\ldots,x_N)  & = \\sum_{j=1}^N \\frac{\\left|p_j\\right|^2}{2m} \\psi(x_1,\\ldots,x_N)", block: true)



#tao-math(" & + \\frac{1}{N} \\sum_{1 \\leq j < k \\leq N} V(x_j-x_k) \\psi(x_1,\\ldots,x_N)", block: true)
]

#text("for some even potential ")#mi("{V}")#text("; if one wants to model short-range interactions, one might instead pick the variant ")#metadata(none) <tao-fdfe183b2fce95e74b90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("H \\psi(x_1,\\ldots,x_N) = \\sum_{j=1}^N \\frac{\\left|p_j\\right|^2}{2m} \\psi(x_1,\\ldots,x_N) + \\frac{1}{N} \\sum_{1 \\leq j < k \\leq N} r^d V(\\frac{x_j-x_k}{r}) \\psi(x_1,\\ldots,x_N)", block: true)]]

#text("for some ")#mi("{r>0}")#text(". This is a typical model for an ")#mi("{N}")#text("-particle ")#link("http://en.wikipedia.org/wiki/Bose-Einstein_condensate")[#text("Bose-Einstein condensate")]#text(". (Longer-range models can lead to more non-local variants of NLS for the limiting equation, such as the ")#link("http://en.wikipedia.org/wiki/Hartree_equation")[#text("Hartree equation")]#text(".)")

#heading(level: 1)[#strong[#text(" — 3. NLS — ")]]

#text("Suppose we have a Bose-Einstein condensate given by a (symmetric) mixed state")

#align(center)[#tao-fit-display[#mitex("\\rho(t, x_1,\\ldots,x_N; x^{\\prime}_1,\\ldots,x^{\\prime}_N )")]]

#text("evolving according to the equation of motion ")#link(<tao-614894decf7b627e4a77>)[#text("(7)")]#text(" using the Hamiltonian ")#link(<tao-fdfe183b2fce95e74b90>)[#text("(8)")]#text(". One can take a partial trace of the equation of motion ")#link(<tao-614894decf7b627e4a77>)[#text("(7)")]#text(" to obtain an equation for the state ")#mi("{\\rho_1(t, x_1; x^{\\prime}_1)}")#text(" of the first particle (note from symmetry that all the other particles will have the same state function). If one does take this trace, one soon finds that the equation of motion becomes")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\rho_1(t,x_1;x^{\\prime}_1)  & = \\frac{i}{\\hbar} [ (\\frac{\\left|p_1\\right|^2}{2m} - \\frac{\\left|p^{\\prime}_1\\right|^2}{2m}) \\rho_1(t,x_1;x^{\\prime}_1)", block: true)



#tao-math(" & + \\frac{1}{N} \\sum_{j=2}^N \\int_{{\\mathbb R}^d} \\frac{1}{r^d} [ V( \\frac{x_1 - x_j}{r} ) - V( \\frac{x^{\\prime}_1 -x_j}{r} ) ] \\rho_{1j}(t,x_1,x_j; x^{\\prime}_1,x_j)\\ dx_j", block: true)
]

#text("where ")#mi("{\\rho_{1j}}")#text(" is the partial trace to the ")#mi("{1, j}")#text(" particles. Using symmetry, we see that all the summands in the ")#mi("{j}")#text(" summation are identical, so we can simplify this as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\rho_1(t,x_1;x^{\\prime}_1)  & = \\frac{i}{\\hbar} [ (\\frac{\\left|p_1\\right|^2}{2m} - \\frac{\\left|p^{\\prime}_1\\right|^2}{2m}) \\rho_1(t,x_1;x^{\\prime}_1)", block: true)



#tao-math(" & + \\frac{N-1}{N} \\int_{{\\mathbb R}^d} \\frac{1}{r^d} [ V( \\frac{x_1 - x_2}{r} ) - V( \\frac{x^{\\prime}_1 -x_2}{r} ) ] \\rho_{12}(t,x_1,x_2; x^{\\prime}_1,x_2)\\ dx_2.", block: true)
]

#text("This does not completely describe the dynamics of ")#mi("{\\rho_1}")#text(", as one also needs an equation for ")#mi("{\\rho_{12}}")#text(". But one can repeat the same argument to get an equation for ")#mi("{\\rho_{12}}")#text(" involving ")#mi("{\\rho_{123}}")#text(", and so forth, leading to a system of equations known as the ")#link("http://en.wikipedia.org/wiki/BBGKY_hierarchy")[#text("BBGKY hierarchy")]#text(". But for simplicity we shall just look at the first equation in this hierarchy.")

#text("Let us now formally take two limits in the above equation, sending the number of particles ")#mi("{N}")#text(" to infinity and the interaction scale ")#mi("{r}")#text(" to zero. The effect of sending ")#mi("{N}")#text(" to infinity should simply be to eliminate the ")#mi("{\\frac{N-1}{N}}")#text(" factor. The effect of sending ")#mi("{r}")#text(" to zero should be to send ")#mi("{\\frac{1}{r^d} V(\\frac{x}{r})}")#text(" to the Dirac mass ")#mi("{\\lambda \\delta(x)}")#text(", where ")#mi("{\\lambda := \\int_{{\\mathbb R}^d} V}")#text(" is the total mass of ")#mi("{V}")#text(". ")#emph[#text("Formally")]#text(" performing these two limits, one is led to the equation")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\rho_1(t,x_1;x^{\\prime}_1)  & = \\frac{i}{\\hbar} [ (\\frac{\\left|p_1\\right|^2}{2m} - \\frac{\\left|p^{\\prime}_1\\right|^2}{2m}) \\rho_1(t,x_1;x^{\\prime}_1)", block: true)



#tao-math(" & + \\lambda (\\rho_{12}(t,x_1,x_1;x^{\\prime}_1,x_1) - \\rho_{12}(t,x_1,x^{\\prime}_1;x^{\\prime}_1,x^{\\prime}_1)) ].", block: true)
]

#text("One can perform a similar formal limiting procedure for the other equations in the BBGKY hierarchy, obtaining a system of equations known as the ")#emph[#text("Gross-Pitaevskii hierarchy")]#text(".")

#text("We next make an important simplifying assumption, which is that in the limit ")#mi("{N \\rightarrow \\infty}")#text(" any two particles in this system become ")#emph[#text("decoupled")]#text(", which means that the two-particle mixed state factors as the tensor product of two one-particle states:")

#align(center)[#tao-fit-display[#mitex("\\rho_{12}(t,x_1,x_2; x^{\\prime}_1,x_2) \\approx \\rho_1(t,x_1;x^{\\prime}_1) \\rho_1(t,x_2;x^{\\prime}_2).")]]

#text("One can view this as a ")#link("http://en.wikipedia.org/wiki/Mean_field_approximation")[#text("mean field approximation")]#text(", modeling the interaction of one particle ")#mi("{x_1}")#text(" with all the other particles by the mean field ")#mi("{\\rho_1}")#text(".")

#text("Making this assumption, the previous equation simplifies to")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\rho_1(t,x_1;x^{\\prime}_1)  & = \\frac{i}{\\hbar} [ (\\frac{\\left|p_1\\right|^2}{2m} - \\frac{\\left|p^{\\prime}_1\\right|^2}{2m})", block: true)



#tao-math(" & + \\lambda (\\rho_1(t,x_1;x_1) - \\rho_1(t,x^{\\prime}_1;x^{\\prime}_1))] \\rho_1(t,x_1;x^{\\prime}_1).", block: true)
]

#text("If we assume furthermore that ")#mi("{\\rho_1}")#text(" is a pure state, thus")

#align(center)[#tao-fit-display[#mitex("\\rho_1(t,x_1;x^{\\prime}_1) = \\psi(t,x_1) \\overline{\\psi(t,x^{\\prime}_1)}")]]

#text("then (up to the phase ambiguity mentioned earlier), ")#mi("{\\psi(t,x)}")#text(" obeys the ")#link("http://en.wikipedia.org/wiki/Gross%E2%80%93Pitaevskii_equation")[#text("Gross-Pitaevskii equation")]

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\psi(t,x) = \\frac{i}{\\hbar} [ (\\frac{\\left|p\\right|^2}{2m} + \\lambda \\left|\\psi(t,x)\\right|^2 ] \\psi(t,x)", block: true)]]

#text("which (up to some factors of ")#mi("{\\hbar}")#text(" and ")#mi("{m}")#text(", which can be renormalised away) is essentially ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(".")

#text("An alternate derivation of ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(", using a slight variant of the above mean field approximation, comes from studying the Hamiltonian ")#link(<tao-fdfe183b2fce95e74b90>)[#text("(8)")]#text(". Let us make the (very strong) assumption that at some fixed time ")#mi("{t}")#text(", one is in a completely factored pure state")

#align(center)[#tao-fit-display[#mitex("\\psi(x_1,\\ldots,x_N) = \\psi_1(x_1) \\ldots \\psi_1(x_N),")]]

#text("where ")#mi("{\\psi_1}")#text(" is a one-particle wave function, in particular obeying the normalisation")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\mathbb R}^d} \\left|\\psi_1(x)\\right|^2\\ dx = 1.", block: true)]]

#text("(This is an unrealistically strong version of the mean field approximation. In practice, one only needs the two-particle partial traces to be completely factored for the discussion below.) The expected value of the Hamiltonian,")

#align(center)[#tao-fit-display[#mitex("\\langle \\psi|H|\\psi\\rangle = \\int_{({\\mathbb R}^d)^N} \\psi(x_1,\\ldots,x_N) \\overline{H \\psi(x_1,\\ldots,x_N)}\\ dx_1 \\ldots dx_N,")]]

#text("can then be simplified as")

#align(center)[#tao-fit-display[#tao-math("N \\int_{{\\mathbb R}^d} \\psi_1(x) \\overline{\\frac{\\left|p_1\\right|^2}{2m} \\psi_1(x)}\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("+ \\frac{N-1}{2} \\int_{{\\mathbb R}^d \\times {\\mathbb R}^d} r^{-d} V(\\frac{x_1-x_2}{r}) \\left|\\psi_1(x_1)\\right|^2 |\\psi_1(x_2)|\\ dx_1 dx_2.", block: true)]]

#text("Again sending ")#mi("{r \\rightarrow 0}")#text(", this formally becomes")

#align(center)[#tao-fit-display[#tao-math("N \\int_{{\\mathbb R}^d} \\psi_1(x) \\overline{\\frac{\\left|p_1\\right|^2}{2m} \\psi_1(x)}\\ dx + \\frac{N-1}{2} \\lambda \\int_{{\\mathbb R}^d \\times {\\mathbb R}^d} \\left|\\psi_1(x_1)\\right|^4\\ dx_1", block: true)]]

#text("which in the limit ")#mi("{N \\rightarrow \\infty}")#text(" is asymptotically")

#align(center)[#tao-fit-display[#tao-math("N \\int_{{\\mathbb R}^d} \\psi_1(x) \\overline{\\frac{\\left|p_1\\right|^2}{2m} \\psi_1(x)} + \\frac{\\lambda}{2} \\left|\\psi_1(x_1)\\right|^4\\ dx_1.", block: true)]]

#text("Up to some normalisations, this is the Hamiltonian for the NLS equation ")#link(<tao-7e30cb8b63fde7d4f89e>)[#text("(1)")]#text(".")

#text("There has been much progress recently in making the above derivations precise, by ")#link("http://arxiv.org/abs/0704.0813")[#text("Erdös-Schlein-Yau")]#text(", ")#link("http://www-users.math.umd.edu/~mxm/webfinalgp.pdf")[#text("Klainerman-Machedon")]#text(", ")#link("http://arxiv.org/abs/0808.0505")[#text("Kirkpatrick-Schlein-Staffilani")]#text(", ")#link("http://kleine.mat.uniroma3.it/mp_arc/c/08/08-235.pdf")[#text("Chen-Pavlovic")]#text(", and others. A key step is to show that the Gross-Pitaevskii hierarchy necessarily preserves the property of being a completely factored state. This requires a uniqueness theory for this hierarchy, which is surprisingly delicate, due to the fact that it is a system of infinitely many coupled equations over an unbounded number of variables.")

#text("[")#emph[#text("Update, Dec 8: Interestingly, the above heuristic derivation only works when the interaction scale ")#mi("{r}")#text(" is much larger than ")#mi("{N^{-1}}")#text(". For ")#mi("{r \\sim N^{-1}}")#text(", the coupling constant ")#mi("{\\lambda}")#text(" acquires a nonlinear correction, becoming essentially the ")]#emph[#text("scattering length")]#text(" of the potential rather than its mean. See comments below.]")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Professor Tao:")#linebreak()#text(" In the third paragraph, do you mean to say that the discussion will be purely informal?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Mathematicians tend to use the word “formal” to describe an argument in which symbolic manipulations may not be justified rigorously. (You just cross your fingers and hope for the best.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74fe8f5f5ef12162b549053442a59d012066bdf44e6c6ab5d3e4dbad268dd523-310f779dc12b3450006b3529c103f2fd0f223a88176de7b69a129ae0bc30e7da.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mio")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42550")[#strong[#text("Mio")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2009")])]

#text("Dear Prof. Tao, looks like there’s a typo in (7), A should be H instead. Also, the ket above (6) is missing a \\psi inside. Thanks for the post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/726fd4de9a842257ed38ca5b7d8e871daf743924b7b44dd3549e5382a379b2aa-e6412fc65776625134ff8c416722c89efbf89d2d9146f54666235b5679ad9e9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M.S.")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42565")[#strong[#text("M.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2009")])]

#text("Really beautiful and clear, as your other post!")#linebreak()#text(" It made me enjoy my long train trip today, thanks.")

#text("I saw a typo immediately before the introduction of the interaction potential sum normalization, I think it should be:")#linebreak()#text(" If the momenta $p_j$ and masses ")#strong[#text("$m_j$")]#text(" are normalised to be of size")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514c9d2fec4118dc92fb137fc85aa3e6873b3a4ebd44055bfa34d4f9cf0fb6cd-a51c14f3bd738f3fd312256ea6147aeadede1fd214dad6adbd41fd93bf2bd2a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42589")[#strong[#text("CJ")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2009")])]

#text("Prof. Tao–There seems to be a missing equation in your definition of Hamilton’s equations on a sympletic manifold, right after “the equations of motion can be written as”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/514c9d2fec4118dc92fb137fc85aa3e6873b3a4ebd44055bfa34d4f9cf0fb6cd-a51c14f3bd738f3fd312256ea6147aeadede1fd214dad6adbd41fd93bf2bd2a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42591")[#strong[#text("CJ")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2009")])]

#text("Prof. Tao–Actually, it looks like all the numbered equations are having difficulties being displayed. (At least I don’t see them running firefox on Ubuntu.)")

#emph[#text("[Hmm, a strange glitch – I think the equations are restored now. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63c5e3d164b60dbf2c30b341adc5ad73b787518ecb74470ab6a00431ab9dc71a-de3e719e9960b0a44f0116a1201823a8b5ddfd465aacf6c51ba7363425eb9495.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuyao")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42617")[#strong[#text("liuyao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2009")])]

#text("minor typo: ")#mi("\\rho(x, x^{\\prime})=\\psi(x)\\bar{\\psi(x^{\\prime})}")#text(", the prime on x, not on ")#mi("\\psi")#linebreak()#text(" Momentum is usually identified with ")#mi("-i\\hbar\\nabla")#text(", though the minus sign is immaterial when you square it, and is more of a convention.")#linebreak()#text(" Great post, by the way!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42622")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2009")])]

#text("[…] From Bose-Einstein condensates to the nonlinear Schrodinger equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42649")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("Please let me echo the above comments in saying that this is a wonderfully interesting and enjoyable post!")

#text("I would like to offer three comments on how engineering students might read (and mis-read) this post, recornizing that increasing numbers of engineering students are seeking to upgrade their mathematical understanding.")

#text("None of the following remarks should be construed as being in any respect critical of Prof. Tao’s fine essay. Rather, they should be read as fan mail—-and as an expression of thanks—from the engineering community to the mathematical community.")

#text("One of Bjarne Stroustrup’s maxims is “Whenever something can be done in two ways, someone will be confused.” And when it comes to quantum mechanics—with its plethora of invariances and conventions–few people are more easily confused than literal-minded engineering students!")

#text("Engineering students can become confused in ways that might not occur to mathematicians, as follows:")

#text("(1) When discussing dynamical state-spaces endowed with a metric and/or symplectic structure, is it better to give equations in terms of vectors, or in terms of forms? Mathematicians are happy either way, but they tend to choose vector frameworks (as Tao’s essay does), perhaps for the reason that vectors are easier to sketch than forms.")

#text("However, if we have in mind (sooner or later) to pullback dynamical equations onto lower-dimension, noneuclidean manifolds (as engineers ubiquitously do), then it is convenient to express dynamical equations (and complex structures, etc.) in terms of forms rather than vectors … and it helps engineering students to be reminded that forms pullback naturally and vectors don’t.")

#text("This boils down to assuring students that symplectic gradients can be defined to map functions to vectors, or alternatively map functions to forms, with equal validity (given a symplectic and/or metric structure that establishes a natural isomorphism).")

#text("(2) On the arxiv server there is a (unpublished, but very clear) essay by Prof. Tao titled ")#emph[#text("Perelman’s proof of the Poincare conjecture: a nonlinear PDE perspective")]#text(" (arXiv.org:math/0610903). In particular, footnote three of this article is in itself a short yet powerfully thought-provoking essay to the effect that “a PDE flow is in many ways ‘dumber’ than a combinatorial algorithm than a combinatorial algorithm” and yet “if the flow is sufficiently geometrical in nature then the flows acquire a number of deep and delicate additional properties”.")

#text("In quantum mechanics as in topology, there is steadily increasing use of flow/PDE algorithms in conjunction with combinatorical/algebraic algorithms; an essay on this general topic would be *very* welcome (IMHO) to many students/researchers in quantum mechanics (in engineering and otherwise).")

#text("(3) Quantum mechanics has a reputation for being mysterious, and in particular, there is a widespread impression that its basic postulates are inviolate. But as is often the case with no-go arguments, a loophole exists that Prof. Tao’s present essay illustrates beautifully.")

#text("That loophole is that (in Prof. Tao’s words) “despite [quantum dynamics] being a linear equation, solutions can be governed by a non-linear equation”. Thus we are free to invent nonlinear versions of quantum mechanics, without fear of experimental contradiction, provided that we can derive the nonlinear dynamics from linear quantum mechanics.")

#text("This principle applies broadly in quantum mechanics and many other physical theories; for example there is a recent article by Stephen Adler and Angelo Bassi titled ")#emph[#text("Is Quantum Theory Exact?")]#text(" that can be read as an another example of this same general principle.")

#text("Here too an essay on “Mathematical methods for circumventing no-go arguments in physical theories” would be very interesting—and very stimulating too!—to many students.")

#text("That’s all! And thanks also, to everyone who contributes what is becoming (IMHO) the present-day “Golden Era of Mathematical Blogging”. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42daa540bea8c308a113ee8c47d8f237aefd09cbe0a80ad21e5fa838e0a8d3a6-17503e1c148d79a1c7dc820b48b715bfd053a57f63fdfbc2f3b8285c6b479ad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Jerrard")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42742")[#strong[#text("Bob Jerrard")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("nice post. just a few days ago I saw a talk by Laszlo Erdos on some of his work (with Schlein and Yau and others) on these problems, and he emphasized that the correct value of the coupling constant ")#mi("\\lambda")#text(" is not the total mass of the interaction potential ")#mi("V")#text(", but rather is ")#mi("8\\pi a_0")#text(", where ")#mi("a_0")#text(" is the scattering length, defined as follows: consider a solution ")#mi("f")#text(" of the equation ")#mi("-\\Delta f + \\frac 12 V f = 0")#text(" in ")#mi("\\mathbb{R}^d")#text(", such that ")#mi("f\\to 1")#text(" at ")#mi("\\infty")#text(". Then if the potential ")#mi("V")#text(" is sufficiently short-range, it is a fact that ")#mi("w = 1-f")#text(" is asymptotic to ")#tao-math("-a_0/\\left|x\\right|", block: false)#text(" for some ")#mi("a_0>0")#text(" (for example this is clear if ")#mi("V")#text(" is compactly supported), and the constant ")#mi("a_0")#text(" is defined to be the scattering length.")

#text("In order to see the scattering length appear in the Gross-Pitaevsky equation, one needs to modify the product state ansatz you have given above. The modified ansatz has the form")

#mi("\\Psi(x) = \\prod_{j<k} (1 - w(x_j -x_k)) \\prod_{j=1}^N \\psi(x_j),")

#text("writing it for wave functions rather than density matrices, and so takes into account short-range correlations between particles. If I understand correctly, the definitions of ")#mi("a_0")#text(" and ")#mi("w")#text(" imply that")

#tao-math("\\int \\left|\\nabla(1-w)\\right|^2+ \\frac 12V(1-w)^2 = 8\\pi a_0,", block: false)

#text("and it is via this fact that the above modified ansatz gives rise to ")#mi("8\\pi a_0")#text(" in the GP equation.")

#text("The justification of the limit thus requires establishing some information about short-range repulsive interactions between particles.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("That’s a very interesting subtlety! I think it shows up for some ranges of r and N and not others, in particular if the range r of the potential is significantly longer than the mean spacing of the particles then the naive approximation should work, I think (this is for instance the case in the Chen-Pavlovic work, where the potential is rather long range and the nonlinear correction does not appear).")

#text("It is good to have examples of why one should not always trust naive limiting arguments, though…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H.S.")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42749")[#strong[#text("H.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("Thank you for this wonderful post. I just have a couple of questions:")#linebreak()#text(" 1) For classical interacting system, what is the “interesting limit” you mentioned in the post? Could you please explain more about that limit? For instance is there a nonlinear equation in the limit? The power law of r and N is kind of mysterious to me. What’s the value of the exponent there explicitly?")#linebreak()#text(" 2) In quantum case, has the Mean field approximation that the two-particle mixed state can factorize in the limit been rigorously justified? [In classical case at positive temperature, there’re “propagation of chaos” type results, which can justify mean field approximation].")#linebreak()#text(" 3) I feel like, usually, mean field approximation is valid only for long range interactions. But here we are concerned about short range interactions. Well, this is not actually a question, maybe my feeling is just incorrect.")#linebreak()#text(" Thank you again!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-42751")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2009")])]

#text("(1) I don’t have a formal derivation, but it seems to me that the limiting dynamics of the classical model should be governed by the one-particle advection equation but with an effective Hamiltonian containing a potential term proportional to the spatial density ")#mi("\\rho(q) := \\int \\rho(q,p) dp")#text(". There is undoubtedly a name for this type of nonlinear kinetic equation but it escapes me at the moment. This type of limit should obtain whenever r is much smaller than 1 but much larger than 1/N; for r=1/N I suppose one should have a correction in analogy with the quantum case as pointed out by Bob Jerrard above.")

#text("(2) As far as I am aware, most of the rigorous results require the initial state to already be factored or close to factored, and the conclusion is that this near-factored property is more or less preserved (with dynamics given by the effective equation). There are certainly efforts to generalise to broader classes of data, though.")

#text("(3) There is a parallel set of results for long-range interactions, in which the nonlinearity becomes nonlocal (of Hartree type, generally).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/26/from-bose-einstein-condensates-to-the-nonlinear-schrodinger-equation/#comment-420734")[#strong[#text("My great WordPress blog – Econlinks")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] Tao makes a nice and concise exposition of some of the most beautiful parts at the intersection of Mathematics and Theoretical Physics (oh, nostalgia…), including quick reviews of classical and quantum […]")
]
