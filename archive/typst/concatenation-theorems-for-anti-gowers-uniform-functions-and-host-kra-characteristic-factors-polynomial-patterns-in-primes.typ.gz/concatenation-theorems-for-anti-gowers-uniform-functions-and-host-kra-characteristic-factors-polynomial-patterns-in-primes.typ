// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:37:54.090219+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 March 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/")[#text("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.ma.huji.ac.il/~tamarz/index.html")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the arXiv two related papers: “")#link("http://arxiv.org/abs/1603.07815")[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteoristic factors")]#text("” and “")#link("http://arxiv.org/abs/1603.07817")[#text("polynomial patterns in primes")]#text("“, with the former developing a “quantitative Bessel inequality” for local Gowers norms that is crucial in the latter.")

#text("We use the term “concatenation theorem” to denote results in which structural control of a function in two or more “directions” can be “concatenated” into structural control in a ")#emph[#text("joint")]#text(" direction. A trivial example of such a concatenation theorem is the following: if a function ")#mi("{f: {\\bf Z} \\times {\\bf Z} \\rightarrow {\\bf R}}")#text(" is constant in the first variable (thus ")#mi("{x \\mapsto f(x,y)}")#text(" is constant for each ")#mi("{y}")#text("), and also constant in the second variable (thus ")#mi("{y \\mapsto f(x,y)}")#text(" is constant for each ")#mi("{x}")#text("), then it is constant in the joint variable ")#mi("{(x,y)}")#text(". A slightly less trivial example: if a function ")#mi("{f: {\\bf Z} \\times {\\bf Z} \\rightarrow {\\bf R}}")#text(" is affine-linear in the first variable (thus, for each ")#mi("{y}")#text(", there exist ")#mi("{\\alpha(y), \\beta(y)}")#text(" such that ")#mi("{f(x,y) = \\alpha(y) x + \\beta(y)}")#text(" for all ")#mi("{x}")#text(") and affine-linear in the second variable (thus, for each ")#mi("{x}")#text(", there exist ")#mi("{\\gamma(x), \\delta(x)}")#text(" such that ")#mi("{f(x,y) = \\gamma(x)y + \\delta(x)}")#text(" for all ")#mi("{y}")#text(") then ")#mi("{f}")#text(" is a quadratic polynomial in ")#mi("{x,y}")#text("; in fact it must take the form ")#metadata(none) <tao-5312fb609f60384731fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(x,y) = \\epsilon xy + \\zeta x + \\eta y + \\theta")]]



#text(" for some real numbers ")#mi("{\\epsilon, \\zeta, \\eta, \\theta}")#text(". (This can be seen for instance by using the affine linearity in ")#mi("{y}")#text(" to show that the coefficients ")#mi("{\\alpha(y), \\beta(y)}")#text(" are also affine linear.)")

#text("The same phenomenon extends to higher degree polynomials. Given a function ")#mi("{f: G \\rightarrow K}")#text(" from one additive group ")#mi("{G}")#text(" to another, we say that ")#mi("{f}")#text(" is of ")#emph[#text("degree less than ")#mi("{d}")]#text(" along a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" if all the ")#mi("{d}")#text("-fold iterated differences of ")#mi("{f}")#text(" along directions in ")#mi("{H}")#text(" vanish, that is to say")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\dots \\partial_{h_d} f(x) = 0")]]

#text("for all ")#mi("{x \\in G}")#text(" and ")#mi("{h_1,\\dots,h_d \\in H}")#text(", where ")#mi("{\\partial_h}")#text(" is the difference operator")

#align(center)[#tao-fit-display[#mitex("\\partial_h f(x) := f(x+h) - f(x).")]]

#text("(We adopt the convention that the only ")#mi("{f}")#text(" of degree less than ")#mi("{0}")#text(" is the zero function.)")

#text("We then have the following simple proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Concatenation of polynomiality)")]#text(" Let ")#mi("{f: G \\rightarrow K}")#text(" be of degree less than ")#mi("{d_1}")#text(" along one subgroup ")#mi("{H_1}")#text(" of ")#mi("{G}")#text(", and of degree less than ")#mi("{d_2}")#text(" along another subgroup ")#mi("{H_2}")#text(" of ")#mi("{G}")#text(", for some ")#mi("{d_1,d_2 \\geq 1}")#text(". Then ")#mi("{f}")#text(" is of degree less than ")#mi("{d_1+d_2-1}")#text(" along the subgroup ")#mi("{H_1+H_2}")#text(" of ")#mi("{G}")#text(".")
]

#text("Note the previous example was basically the case when ")#mi("{G = {\\bf Z} \\times {\\bf Z}}")#text(", ")#mi("{H_1 = {\\bf Z} \\times \\{0\\}}")#text(", ")#mi("{H_2 = \\{0\\} \\times {\\bf Z}}")#text(", ")#mi("{K = {\\bf R}}")#text(", and ")#mi("{d_1=d_2=2}")#text(".")

#emph[#text("Proof:")]#text(" The claim is trivial for ")#mi("{d_1=1}")#text(" or ")#mi("{d_2=1}")#text(" (in which ")#mi("{f}")#text(" is constant along ")#mi("{H_1}")#text(" or ")#mi("{H_2}")#text(" respectively), so suppose inductively ")#mi("{d_1,d_2 \\geq 2}")#text(" and the claim has already been proven for smaller values of ")#mi("{d_1-1}")#text(".")

#text("We take a derivative in a direction ")#mi("{h_1 \\in H_1}")#text(" along ")#mi("{h_1}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("T^{-h_1} f = f + \\partial_{h_1} f")]]

#text("where ")#mi("{T^{-h_1} f(x) = f(x+h_1)}")#text(" is the shift of ")#mi("{f}")#text(" by ")#mi("{-h_1}")#text(". Then we take a further shift by a direction ")#mi("{h_2 \\in H_2}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("T^{-h_1-h_2} f = T^{-h_2} f + T^{-h_2} \\partial_{h_1} f = f + \\partial_{h_2} f + T^{-h_2} \\partial_{h_1} f")]]

#text("leading to the ")#emph[#text("cocycle equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1+h_2} f = \\partial_{h_2} f + T^{-h_2} \\partial_{h_1} f.")]]

#text("Since ")#mi("{f}")#text(" has degree less than ")#mi("{d_1}")#text(" along ")#mi("{H_1}")#text(" and degree less than ")#mi("{d_2}")#text(" along ")#mi("{H_2}")#text(", ")#mi("{\\partial_{h_1} f}")#text(" has degree less than ")#mi("{d_1-1}")#text(" along ")#mi("{H_1}")#text(" and less than ")#mi("{d_2}")#text(" along ")#mi("{H_2}")#text(", so is degree less than ")#mi("{d_1+d_2-2}")#text(" along ")#mi("{H_1+H_2}")#text(" by induction hypothesis. Similarly ")#mi("{\\partial_{h_2} f}")#text(" is also of degree less than ")#mi("{d_1+d_2-2}")#text(" along ")#mi("{H_1+H_2}")#text(". Combining this with the cocycle equation we see that ")#mi("{\\partial_{h_1+h_2}f}")#text(" is of degree less than ")#mi("{d_1+d_2-2}")#text(" along ")#mi("{H_1+H_2}")#text(" for any ")#mi("{h_1+h_2 \\in H_1+H_2}")#text(", and hence ")#mi("{f}")#text(" is of degree less than ")#mi("{d_1+d_2-1}")#text(" along ")#mi("{H_1+H_2}")#text(", as required. ")#mi("\\Box")

#text("While this proposition is simple, it already illustrates some basic principles regarding how one would go about proving a concatenation theorem:")

#list(
[#text("(i) One should perform induction on the degrees ")#mi("{d_1,d_2}")#text(" involved, and take advantage of the recursive nature of degree (in this case, the fact that a function is of less than degree ")#mi("{d}")#text(" along some subgroup ")#mi("{H}")#text(" of directions iff all of its first derivatives along ")#mi("{H}")#text(" are of degree less than ")#mi("{d-1}")#text(").")],
[#text("(ii) Structure is preserved by operations such as addition, shifting, and taking derivatives. In particular, if a function ")#mi("{f}")#text(" is of degree less than ")#mi("{d}")#text(" along some subgroup ")#mi("{H}")#text(", then any derivative ")#mi("{\\partial_k f}")#text(" of ")#mi("{f}")#text(" is also of degree less than ")#mi("{d}")#text(" along ")#mi("{H}")#text(", ")#emph[#text("even if ")#mi("{k}")#text(" does not belong to ")#mi("{H}")]#text(".")]
)

#text("Here is another simple example of a concatenation theorem. Suppose an at most countable additive group ")#mi("{G}")#text(" acts by measure-preserving shifts ")#mi("{T: g \\mapsto T^g}")#text(" on some probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text("; we call the pair ")#mi("{(X,T)}")#text(" (or more precisely ")#mi("{(X, {\\mathcal X}, \\mu, T)}")#text(") a ")#emph[#mi("{G}")#text("-system")]#text(". We say that a function ")#mi("{f \\in L^\\infty(X)}")#text(" is a ")#emph[#text("generalised eigenfunction of degree less than ")#mi("{d}")]#text(" along some subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" and some ")#mi("{d \\geq 1}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("T^h f = \\lambda_h f")]]

#text("almost everywhere for all ")#mi("{h \\in H}")#text(", and some functions ")#mi("{\\lambda_h \\in L^\\infty(X)}")#text(" of degree less than ")#mi("{d-1}")#text(" along ")#mi("{H}")#text(", with the convention that a function has degree less than ")#mi("{0}")#text(" if and only if it is equal to ")#mi("{1}")#text(". Thus for instance, a function ")#mi("{f}")#text(" is an generalised eigenfunction of degree less than ")#mi("{1}")#text(" along ")#mi("{H}")#text(" if it is constant on almost every ")#mi("{H}")#text("-ergodic component of ")#mi("{G}")#text(", and is a generalised function of degree less than ")#mi("{2}")#text(" along ")#mi("{H}")#text(" if it is an eigenfunction of the shift action on almost every ")#mi("{H}")#text("-ergodic component of ")#mi("{G}")#text(". A basic example of a higher order eigenfunction is the function ")#mi("{f(x,y) := e^{2\\pi i y}}")#text(" on the ")#emph[#text("skew shift")]#text(" ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(" with ")#mi("{{\\bf Z}}")#text(" action given by the generator ")#mi("{T(x,y) := (x+\\alpha,y+x)}")#text(" for some irrational ")#mi("{\\alpha}")#text(". One can check that ")#mi("{T^h f = \\lambda_h f}")#text(" for every integer ")#mi("{h}")#text(", where ")#mi("{\\lambda_h: x \\mapsto e^{2\\pi i \\binom{h}{2} \\alpha} e^{2\\pi i h x}}")#text(" is a generalised eigenfunction of degree less than ")#mi("{2}")#text(" along ")#mi("{{\\bf Z}}")#text(", so ")#mi("{f}")#text(" is of degree less than ")#mi("{3}")#text(" along ")#mi("{{\\bf Z}}")#text(".")

#text("We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Concatenation of higher order eigenfunctions)")]#text(" ")#metadata(none) <tao-b8411c14e1485700f3f8>#text(" Let ")#mi("{(X,T)}")#text(" be a ")#mi("{G}")#text("-system, and let ")#mi("{f \\in L^\\infty(X)}")#text(" be a generalised eigenfunction of degree less than ")#mi("{d_1}")#text(" along one subgroup ")#mi("{H_1}")#text(" of ")#mi("{G}")#text(", and a generalised eigenfunction of degree less than ")#mi("{d_2}")#text(" along another subgroup ")#mi("{H_2}")#text(" of ")#mi("{G}")#text(", for some ")#mi("{d_1,d_2 \\geq 1}")#text(". Then ")#mi("{f}")#text(" is a generalised eigenfunction of degree less than ")#mi("{d_1+d_2-1}")#text(" along the subgroup ")#mi("{H_1+H_2}")#text(" of ")#mi("{G}")#text(".")
]

#text("The argument is almost identical to that of the previous proposition and is left as an exercise to the reader. The key point is the point (ii) identified earlier: the space of generalised eigenfunctions of degree less than ")#mi("{d}")#text(" along ")#mi("{H}")#text(" is preserved by multiplication and shifts, as well as the operation of “taking derivatives” ")#mi("{f \\mapsto \\lambda_k}")#text(" even along directions ")#mi("{k}")#text(" that do not lie in ")#mi("{H}")#text(". (To prove this latter claim, one should restrict to the region where ")#mi("{f}")#text(" is non-zero, and then divide ")#mi("{T^k f}")#text(" by ")#mi("{f}")#text(" to locate ")#mi("{\\lambda_k}")#text(".)")

#text("A typical example of this proposition in action is as follows: consider the ")#mi("{{\\bf Z}^2}")#text("-system given by the ")#mi("{3}")#text("-torus ")#mi("{({\\bf R}/{\\bf Z})^3}")#text(" with generating shifts")

#tao-aligned(keep: true)[


#tao-math("T^{(1,0)}(x,y,z)  & := (x+\\alpha,y,z+y)", block: true)



#tao-math("T^{(0,1)}(x,y,z)  & := (x,y+\\alpha,z+x)", block: true)
]

#text("for some irrational ")#mi("{\\alpha}")#text(", which can be checked to give a ")#mi("{{\\bf Z}^2}")#text(" action")

#align(center)[#tao-fit-display[#mitex("T^{(n,m)}(x,y,z) := (x+n\\alpha, y+m\\alpha, z+ny+mx+nm\\alpha).")]]

#text("The function ")#mi("{f(x,y,z) := e^{2\\pi i z}}")#text(" can then be checked to be a generalised eigenfunction of degree less than ")#mi("{2}")#text(" along ")#mi("{{\\bf Z} \\times \\{0\\}}")#text(", and also less than ")#mi("{2}")#text(" along ")#mi("{\\{0\\} \\times {\\bf Z}}")#text(", and less than ")#mi("{3}")#text(" along ")#mi("{{\\bf Z}^2}")#text(". One can view this example as the dynamical systems translation of the example ")#link(<tao-5312fb609f60384731fc>)[#text("(1)")]#text(" (see ")#link("https://terrytao.wordpress.com/2013/03/27/an-informal-version-of-the-furstenberg-correspondence-principle/")[#text("this previous post")]#text(" for some more discussion of this sort of correspondence).")

#text("The main results of our concatenation paper are analogues of these propositions concerning a more complicated notion of “polynomial-like” structure that are of importance in additive combinatorics and in ergodic theory. On the ergodic theory side, the notion of structure is captured by the ")#emph[#text("Host-Kra characteristic factors")]#text(" ")#mi("{Z^{<d}_H(X)}")#text(" of a ")#mi("{G}")#text("-system ")#mi("{X}")#text(" along a subgroup ")#mi("{H}")#text(". These factors can be defined in a number of ways. One is by duality, using the ")#emph[#text("Gowers-Host-Kra uniformity seminorms")]#text(" (defined for instance ")#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/")[#text("here")]#text(") ")#mi("{\\| \\|_{U^d_H(X)}}")#text(". Namely, ")#mi("{Z^{<d}_H(X)}")#text(" is the factor of ")#mi("{X}")#text(" defined up to equivalence by the requirement that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^d_H(X)} = 0 \\iff {\\bf E}(f | Z^{<d}_H(X) ) = 0.", block: true)]]

#text("An equivalent definition is in terms of the ")#emph[#text("dual functions")]#text(" ")#mi("{{\\mathcal D}^d_H(f)}")#text(" of ")#mi("{f}")#text(" along ")#mi("{H}")#text(", which can be defined recursively by setting ")#mi("{{\\mathcal D}^0_H(f) = 1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}^d_H(f) = {\\bf E}_h T^h f {\\mathcal D}^{d-1}( f \\overline{T^h f} )")]]

#text("where ")#mi("{{\\bf E}_h}")#text(" denotes the ergodic average along a Følner sequence in ")#mi("{G}")#text(" (in fact one can also define these concepts in non-amenable abelian settings as per ")#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/")[#text("this previous post")]#text("). The factor ")#mi("{Z^{<d}_H(X)}")#text(" can then be alternately defined as the factor generated by the dual functions ")#mi("{{\\mathcal D}^d_H(f)}")#text(" for ")#mi("{f \\in L^\\infty(X)}")#text(".")

#text("In the case when ")#mi("{G=H={\\bf Z}}")#text(" and ")#mi("{X}")#text(" is ")#mi("{G}")#text("-ergodic, a deep ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("theorem of Host and Kra")]#text(" shows that the factor ")#mi("{Z^{<d}_H(X)}")#text(" is equivalent to the inverse limit of nilsystems of step less than ")#mi("{d}")#text(". A similar statement holds with ")#mi("{{\\bf Z}}")#text(" replaced by any finitely generated group ")#link("http://www.ams.org/mathscinet-getitem?mr=2713738")[#text("by Griesmer")]#text(", while the case of an infinite vector space over a finite field was treated in ")#link("https://terrytao.wordpress.com/2013/05/21/multiple-recurrence-and-convergence-results-associated-to-f_pomega-actions/")[#text("this paper of Bergelson, Ziegler, and myself")]#text(". The situation is more subtle when ")#mi("{X}")#text(" is not ")#mi("{G}")#text("-ergodic, or when ")#mi("{X}")#text(" is ")#mi("{G}")#text("-ergodic but ")#mi("{H}")#text(" is a proper subgroup of ")#mi("{G}")#text(" acting non-ergodically, when one has to start considering measurable families of directional nilsystems; see for instance this ")#link("http://www.ams.org/mathscinet-getitem?mr=3358029")[#text("paper of Austin")]#text(" for some of the subtleties involved (for instance, higher order group cohomology begins to become relevant!).")

#text("One of our main theorems is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Concatenation of characteristic factors)")]#text(" Let ")#mi("{(X,T)}")#text(" be a ")#mi("{G}")#text("-system, and let ")#mi("{f}")#text(" be measurable with respect to the factor ")#mi("{Z^{<d_1}_{H_1}(X)}")#text(" and with respect to the factor ")#mi("{Z^{<d_2}_{H_2}(X)}")#text(" for some ")#mi("{d_1,d_2 \\geq 1}")#text(" and some subgroups ")#mi("{H_1,H_2}")#text(" of ")#mi("{G}")#text(". Then ")#mi("{f}")#text(" is also measurable with respect to the factor ")#mi("{Z^{<d_1+d_2-1}_{H_1+H_2}(X)}")#text(".")
]

#text("We give two proofs of this proposition in the paper; an ergodic-theoretic proof using the Host-Kra theory of “cocycles of type ")#mi("{<d}")#text(" (along a subgroup ")#mi("{H}")#text(")”, which can be used to inductively describe the factors ")#mi("{Z^{<d}_H}")#text(", and a combinatorial proof based on a combinatorial analogue of this proposition which is harder to state (but which roughly speaking asserts that a function which is nearly orthogonal to all bounded functions of small ")#mi("{U^{d_1}_{H_1}}")#text(" norm, and also to all bounded functions of small ")#mi("{U^{d_2}_{H_2}}")#text(" norm, is also nearly orthogonal to alll bounded functions of small ")#mi("{U^{d_1+d_2-1}_{H_1+H_2}}")#text(" norm). The combinatorial proof parallels the proof of Proposition ")#link(<tao-b8411c14e1485700f3f8>)[#text("2")]#text(". A key point is that dual functions ")#mi("{F := {\\mathcal D}^d_H(f)}")#text(" obey a property analogous to being a generalised eigenfunction, namely that")

#align(center)[#tao-fit-display[#mitex("T^h F = {\\bf E}_k \\lambda_{h,k} F_k")]]

#text("where ")#mi("{F_k := T^k F}")#text(" and ")#mi("{\\lambda_{h,k} := {\\mathcal D}^{d-1}( T^h f \\overline{T^k f} )}")#text(" is a “structured function of order ")#mi("{d-1}")#text("” along ")#mi("{H}")#text(". (In the language of ")#link("http://www.ams.org/mathscinet-getitem?mr=2274314")[#text("this previous paper of mine")]#text(", this is an assertion that dual functions are uniformly almost periodic of order ")#mi("{d}")#text(".) Again, the point (ii) above is crucial, and in particular it is key that any structure that ")#mi("{F}")#text(" has is inherited by the associated functions ")#mi("{\\lambda_{h,k}}")#text(" and ")#mi("{F_k}")#text(". This sort of inheritance is quite easy to accomplish in the ergodic setting, as there is a ready-made language of factors to encapsulate the concept of structure, and the shift-invariance and ")#mi("{\\sigma}")#text("-algebra properties of factors make it easy to show that just about any “natural” operation one performs on a function measurable with respect to a given factor, returns a function that is still measurable in that factor. In the finitary combinatorial setting, though, encoding the fact (ii) becomes a remarkably complicated notational nightmare, requiring a huge amount of “epsilon management” and “second-order epsilon management” (in which one manages not only scalar epsilons, but also function-valued epsilons that depend on other parameters). In order to avoid all this we were forced to utilise a nonstandard analysis framework for the combinatorial theorems, which made the arguments greatly resemble the ergodic arguments in many respects (though the two settings are still not equivalent, see ")#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/")[#text("this previous blog post")]#text(" for some comparisons between the two settings). Unfortunately the arguments are still rather complicated.")

#text("For combinatorial applications, dual formulations of the concatenation theorem are more useful. A direct dualisation of the theorem yields the following decomposition theorem: a bounded function which is small in ")#mi("{U^{d_1+d_2-1}_{H_1+H_2}}")#text(" norm can be split into a component that is small in ")#mi("{U^{d_1}_{H_1}}")#text(" norm, and a component that is small in ")#mi("{U^{d_2}_{H_2}}")#text(" norm. (One may wish to understand this type of result by first proving the following baby version: any function that has mean zero on every coset of ")#mi("{H_1+H_2}")#text(", can be decomposed as the sum of a function that has mean zero on every ")#mi("{H_1}")#text(" coset, and a function that has mean zero on every ")#mi("{H_2}")#text(" coset. This is dual to the assertion that a function that is constant on every ")#mi("{H_1}")#text(" coset and constant on every ")#mi("{H_2}")#text(" coset, is constant on every ")#mi("{H_1+H_2}")#text(" coset.) Combining this with some standard “almost orthogonality” arguments (i.e. Cauchy-Schwarz) give the following Bessel-type inequality: if one has a lot of subgroups ")#mi("{H_1,\\dots,H_k}")#text(" and a bounded function is small in ")#mi("{U^{2d-1}_{H_i+H_j}}")#text(" norm for most ")#mi("{i,j}")#text(", then it is also small in ")#mi("{U^d_{H_i}}")#text(" norm for most ")#mi("{i}")#text(". (Here is a baby version one may wish to warm up on: if a function ")#mi("{f}")#text(" has small mean on ")#mi("{({\\bf Z}/p{\\bf Z})^2}")#text(" for some large prime ")#mi("{p}")#text(", then it has small mean on most of the cosets of most of the one-dimensional subgroups of ")#mi("{({\\bf Z}/p{\\bf Z})^2}")#text(".)")

#text("There is also a generalisation of the above Bessel inequality (as well as several of the other results mentioned above) in which the subgroups ")#mi("{H_i}")#text(" are replaced by more general ")#emph[#text("coset progressions")]#text(" ")#mi("{H_i+P_i}")#text(" (of bounded rank), so that one has a Bessel inequailty controlling “local” Gowers uniformity norms such as ")#mi("{U^d_{P_i}}")#text(" by “global” Gowers uniformity norms such as ")#mi("{U^{2d-1}_{P_i+P_j}}")#text(". This turns out to be particularly useful when attempting to compute polynomial averages such as ")#metadata(none) <tao-dbb890aaa5f37bcbf62b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq N} \\sum_{r \\leq \\sqrt{N}} f(n) g(n+r^2) h(n+2r^2)")]]



#text(" for various functions ")#mi("{f,g,h}")#text(". After repeated use of the van der Corput lemma, one can control such averages by expressions such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} \\sum_{h,m,k \\leq \\sqrt{N}} f(n) f(n+mh) f(n+mk) f(n+m(h+k))")]]

#text("(actually one ends up with more complicated expressions than this, but let’s use this example for sake of discussion). This can be viewed as an average of various ")#mi("{U^2}")#text(" Gowers uniformity norms of ")#mi("{f}")#text(" along arithmetic progressions of the form ")#mi("{\\{ mh: h \\leq \\sqrt{N}\\}}")#text(" for various ")#mi("{m \\leq \\sqrt{N}}")#text(". Using the above Bessel inequality, this can be controlled in turn by an average of various ")#mi("{U^3}")#text(" Gowers uniformity norms along rank two generalised arithmetic progressions of the form ")#mi("{\\{ m_1 h_1 + m_2 h_2: h_1,h_2 \\le \\sqrt{N}\\}}")#text(" for various ")#mi("{m_1,m_2 \\leq \\sqrt{N}}")#text(". But for generic ")#mi("{m_1,m_2}")#text(", this rank two progression is close in a certain technical sense to the “global” interval ")#mi("{\\{ n: n \\leq N \\}}")#text(" (this is ultimately due to the basic fact that two randomly chosen large integers are likely to be coprime, or at least have a small gcd). As a consequence, one can use the concatenation theorems from our first paper to control expressions such as ")#link(<tao-dbb890aaa5f37bcbf62b>)[#text("(2)")]#text(" in terms of ")#emph[#text("global")]#text(" Gowers uniformity norms. This is important in number theoretic applications, when one is interested in computing sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} \\sum_{r \\leq \\sqrt{N}} \\mu(n) \\mu(n+r^2) \\mu(n+2r^2)")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} \\sum_{r \\leq \\sqrt{N}} \\Lambda(n) \\Lambda(n+r^2) \\Lambda(n+2r^2)")]]

#text("where ")#mi("{\\mu}")#text(" and ")#mi("{\\Lambda}")#text(" are the Möbius and von Mangoldt functions respectively. This is because we are able to control global Gowers uniformity norms of such functions (thanks to results such as ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("the proof of the inverse conjecture for the Gowers norms")]#text(", ")#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("the orthogonality of the Möbius function with nilsequences")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("asymptotics for linear equations in primes")]#text("), but much less control is currently available for local Gowers uniformity norms, even with the assistance of the generalised Riemann hypothesis (see ")#link("https://terrytao.wordpress.com/2015/12/02/a-conjectural-local-fourier-uniformity-of-the-liouville-function/")[#text("this previous blog post")]#text(" for some further discussion).")

#text("By combining these tools and strategies with the “transference principle” approach from ")#link("http://www.ams.org/mathscinet-getitem?mr=2461509")[#text("our previous paper")]#text(" (as improved using the recent “densification” ")#link("http://www.ams.org/mathscinet-getitem?mr=3361771")[#text("technique of Conlon, Fox, and Zhao")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/")[#text("this previous post")]#text("), we are able in particular to establish the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Polynomial patterns in the primes)")]#text(" Let ")#mi("{P_1,\\dots,P_k: {\\bf Z} \\rightarrow {\\bf Z}}")#text(" be polynomials of degree at most ")#mi("{d}")#text(", whose degree ")#mi("{d}")#text(" coefficients are all distinct, for some ")#mi("{d \\geq 1}")#text(". Suppose that ")#mi("{P_1,\\dots,P_k}")#text(" is admissible in the sense that for every prime ")#mi("{p}")#text(", there are ")#mi("{n,r}")#text(" such that ")#mi("{n+P_1(r),\\dots,n+P_k(r)}")#text(" are all coprime to ")#mi("{p}")#text(". Then there exist infinitely many pairs ")#mi("{n,r}")#text(" of natural numbers such that ")#mi("{n+P_1(r),\\dots,n+P_k(r)}")#text(" are prime.")
]

#text("Furthermore, we obtain an asymptotic for the number of such pairs ")#mi("{n,r}")#text(" in the range ")#mi("{n \\leq N}")#text(", ")#mi("{r \\leq N^{1/d}}")#text(" (actually for minor technical reasons we reduce the range of ")#mi("{r}")#text(" to be very slightly less than ")#mi("{N^{1/d}}")#text("). In fact one could in principle obtain asymptotics for smaller values of ")#mi("{r}")#text(", and relax the requirement that the degree ")#mi("{d}")#text(" coefficients be distinct with the requirement that no two of the ")#mi("{P_i}")#text(" differ by a constant, provided one had good enough local uniformity results for the Möbius or von Mangoldt functions. For instance, we can obtain an asymptotic for triplets of the form ")#mi("{n, n+r,n+r^d}")#text(" unconditionally for ")#mi("{d \\leq 5}")#text(", and conditionally on GRH for all ")#mi("{d}")#text(", using known results on primes in short intervals on average.")

#text("The ")#mi("{d=1}")#text(" case of this theorem was obtained in ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("a previous paper of myself and Ben Green")]#text(" (using the aforementioned conjectures on the Gowers uniformity norm and the orthogonality of the Möbius function with nilsequences, both of which are now proven). For higher ")#mi("{d}")#text(", an ")#link("http://www.ams.org/mathscinet-getitem?mr=2461509")[#text("older result of Tamar and myself")]#text(" was able to tackle the case when ")#mi("{P_1(0)=\\dots=P_k(0)=0}")#text(" (though our results there only give lower bounds on the number of pairs ")#mi("{(n,r)}")#text(", and no asymptotics). Both of these results generalise my ")#link("https://en.wikipedia.org/wiki/Green%E2%80%93Tao_theorem")[#text("older theorem with Ben Green")]#text(" on the primes containing arbitrarily long arithmetic progressions. The theorem also extends to multidimensional polynomials, in which case there are some additional previous results; see ")#link("http://arxiv.org/abs/1603.07817")[#text("the paper")]#text(" for more details. We also get a ")#link("https://terrytao.wordpress.com/2014/09/04/narrow-progressions-in-the-primes/")[#text("technical refinement of our previous result")]#text(" on narrow polynomial progressions in (dense subsets of) the primes by making the progressions just a little bit narrower in the case of the density of the set one is using is small.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("Should replace the Uncategorized tag with paper.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467318")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("The prime tuples conjecture seems to be the (still unproved) case ")#mi("d=0")#text(" of theorem 4.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2016")])]

#text("Yes, that’s correct! Unfortunately, the d=0 case has “infinite complexity” in the sense that no amount of Cauchy-Schwarz is capable of controlling averages such as ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+h)")#text(" into Gowers uniformity norm type objects in such a way that some cancellation is preserved, so the prime tuples conjecture remains unfortunately out of reach by these methods. However, one could probably use these results to show that the prime tuples conjecture holds “on average” for tuples parameterised by various polynomial families, e.g. that ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+h^2)")#text(" has the right asymptotic for most ")#mi("h = O(\\sqrt{x})")#text(". (In the linear case, there are results of this form by Balog, and by Ben Green and myself, using the circle method and our theorem on linear equations in primes respectively.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2016")])]

#text("Can theorem 4 be made effective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467325")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2016")])]

#text("Unfortunately, at one point we use Siegel’s theorem (in order to establish asymptotic orthogonality of the Mobius function with “major arc” nilsequences), which is still ineffective. Also we rely on the inverse conjecture for the Gowers norms, which is also ineffective currently due to the use of nonstandard analysis techniques. I believe it is possible to remove the latter source of ineffectivity with some significant effort, but there is still no plausible path currently to remove the former (unless one assumes some powerful conjecture, such as GRH).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Are the above nonstandard techniques require only ZFC axioms?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467390")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Yes (in fact one only really needs the ultrafilter lemma, and possibly also countable choice, in place of the full axiom of choice). But it is also possible to appeal to general “proof mining” results to show that any nonstandard argument establishing a standard conclusion can (in principle, at least) be written in a fully standard fashion that avoids the use of choice, though the resulting proof might be significantly larger and messier than the nonstandard one.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caab1168a0c18b1025014734443f0e7cdc931c42ef6886be0aa9e746c9d2b668-ea048e9e7aa2d331c499ac9b6e410a72c41877c97914ce8d7ab6d5186055255a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zoi")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467342")[#strong[#text("Zoi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2016")])]

#text("I feel depressed. I am a 17 years old, new to number theory and I just bought first books (Dirichlet lectures on number theory and Dedekind theory of algebraic integers) and I enjoy taking the time quietly learning from them. But I realize now that there’s so much existing knowledge in modern math, that if I want to do some research of my own someday, I must learn the subject in the most dense and fast way I can.. without really taking the time and enjoying the process and or devoting days to think (instead of simply reading the solution) about problems already solved by people like Gauss. otherwise I’ll be simply too old for research when I’ll finally reach the surface of modern knowledge.")

#text("(and even if I won’t, it is known that mathematicians are best when they are young and I still “lose” those early effective years of research).")

#text("However I simply don’t enjoy math that way. I feel stress and lack of time constantly. Is there any solution?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467349")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2016")])]

#text("Learning mathematics in a university environment is substantially more efficient than learning from self-study alone; you’d be amazed what one can pick up in four years of undergraduate mathematics and four to five years of graduate mathematics (particularly once one has completed the basic courses and started to do some supervised research). But modern mathematics is indeed a vast subject, and one actually learns more maths after one’s PhD than before it. I finished my own PhD with a specialist knowledge in harmonic analysis, and only really picked up PDE, number theory, ergodic theory, combinatorics, algebraic geometry, model theory, etc. after I started research (particularly after collaborating with people in these areas); I had seen each of these topics in various classes, but never internalised them until after my PhD. Once one acquires a really thorough knowledge of one part of mathematics, it becomes a lot easier (particularly in the internet age) to branch out to neighbouring areas, and then to whatever other parts of mathematics one needs; one can pick up far more material this way than one might expect just from linearly extrapolating from one’s learning rate as a student. (But I don’t think anybody these days can really claim mastery of ")#emph[#text("all")]#text(" areas of modern mathematics; perhaps Hilbert and von Neumann were the last to do so, back when mathematics wasn’t quite so large as it is today. On the other hand, one doesn’t have to know all this stuff directly; one can (and should!) work in collaboration with coauthors with complementary areas of expertise.)")

#text("This little illustrated guide is fairly apt, I think: ")#link("http://matt.might.net/articles/phd-school-in-pictures/")[#text("http://matt.might.net/articles/phd-school-in-pictures/")]

#text("The relationship between age and productivity in mathematics is complicated; generally speaking, younger mathematicians have more energy, but older mathematicians have more experience, and it is not always clear which is more advantageous (although a collaboration between a senior mathematician and a junior one can be a particularly effective combination). I remember several times during my own PhD when I would spend an entire week trying to resolve some issue in my research project, trying various fruitless attacks for hours, until I would meet with my advisor, Eli Stein, who would listen for a few minutes and then go over to his filing cabinet to fish out an offprint of a paper where the authors encountered and resolved a similar problem, and hand it to me; after studying the offprint, I was usually able to figure out what to do (and move on to the next issue).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caab1168a0c18b1025014734443f0e7cdc931c42ef6886be0aa9e746c9d2b668-ea048e9e7aa2d331c499ac9b6e410a72c41877c97914ce8d7ab6d5186055255a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zoi")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467391")[#strong[#text("Zoi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Terence and anonymous, thank you very much for your comments :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("You are too young to be depressed! Look at me: I was born in a rural family in a poor 3rd world country and I heard of calculus for the first time when I was 25 years old! I am now 42 years old, working as a shoes seller, and I read math books in my free time just for the pleasure it causes on me (currently I am –slowly :-)– reading the classic “Lehrbuch der Topologie”).")

#text("There is a big difference in enjoying to learn and teach mathematics, and enjoying to do research in mathematics. Just for the sake of analogy: I know people that love to hear about the experimental discoveries of physicists, but would feel really no pleasure in working in experimental physics.")

#text("Maybe you need to discover what is that you really want to do. You should not be depressed with the activity you choose do in your life.")

#text("By the way: very good exposition of the mathematical works of others is (or should be) really appreciated too. I feel that there are really few historians of mathematics nowadays! It is an activity of fundamental importance, but not highly valued in an era where most people (outside mathematics) only want money or fame. This should not discourage you. It’s a profession that can be a source of great happiness (I imagine). You are the only one who can possibly know what will make you happy.")

#text("Make your own decisions, choose patiently and wisely, and then enjoy happiness, young man.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467383")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")])]

#text("Zoi, Terry, and especially Anonymous, your comments made my day.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467378")[#strong[#text("Not mentioned on The Aperiodical, March 2016 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")]

#text("[…] has, as usual, written a post on his blog announcing the result, and the paper itself is on the arXiv, titled “Concatenation theorems for anti-Gowers-uniform […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre-Yves Bienvenu")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467500")[#strong[#text("Pierre-Yves Bienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2016")])]

#text("Hi Terry, looking at Theorem 1.3 of the paper, I wonder whether it could be possible to let the non-constant coefficients of the P_i be unbounded, something like a power (less than A) of log I’d guess. In view of Siegel-Walfisz, this works for k=2. For larger k, when I try to adapt the argument of Linear equations in primes, I run into trouble because the generalised von Neumann theorem seems to seriously require bounded coefficients (while other steps seem to be fine).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467504")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2016")])]

#text("That’s a good question! If one uses existing techniques to try to control these patterns, one ends up wanting to control a Gowers norm of von Mangoldt or Mobius that is not the usual ")#mi("U^k")#text(" norm associated with the usual shift ")#mi("T: x \\mapsto x+1")#text(", but rather a Gowers box norm ")#mi("\\Box^k_{T_1,\\dots,T_k}")#text(" associated to a collection of shifts ")#mi("T_i: x \\mapsto x + a_i")#text(" where each ")#mi("a_i")#text(" is polylogarithmic in size. Unfortunately, in this higher dimensional setting we don’t have a good inverse theorem that reduces everything to nilsequence type objects, so the linear equations in primes strategy doesn’t work, except in some special cases such as when all the ")#mi("a_i")#text(" are equal (which roughly speaking corresponds to the non-constant coefficients of the linear forms being large but equal to each other). One may have to somehow rework the linear equations in primes argument to rely less on nilsequences (e.g. using “soft” dual functions rather than “hard” nilsequences as the obstructions to uniformity), though I don’t know whether this can actually be done with current technology.")

#text("ADDED LATER: Actually, now that I think about it a bit more, I think the “clearing denominators” step in the older polynomial patterns paper of Tamar and myself should resolve this problem (in the linear pattern case, at least), controlling the aforementioned Gowers box norm by a Gowers uniformity norm based on a shift such as ")#mi("T: x \\mapsto x + a_1 \\dots a_k")#text(". (In that previous paper we needed to clear denominators to deal with some pesky ")#mi("W")#text("-dependence in the shifts; here the enemy comes from terms of size ")#mi("\\log N")#text(" rather than ")#mi("W")#text(", but it seems the same method should work nevertheless.) The inverse theorem should control that in terms of nilsequences on arithmetic progressions at this polylogarithmic spacing ")#mi("a_1 \\dots a_k")#text(", and the existing methods should be able to correlate Mobius with the nilsequences on these progressions by using the full power of Siegel-Walfisz. Might be a good project to hammer all this out…")

#text("p.s. Incidentally, in an appendix to ")#link("http://arxiv.org/abs/1408.4505")[#text("a previous paper with Ford, Green, and Konyagin")]#text(" we did at least observe that the ")#emph[#text("constant")]#text(" terms in the linear equations in primes stuff can be made polylogarithmic in size. We didn’t do any clearing of denominators there though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d32be80f807615198799ee9d670efba63e58ce36eebb22d970fb3690534ca5-aa8e286039526ceccde5af82cbc8bc257f59646ed7741ee7ce5b5491d5000018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-467674")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2016")])]

#text("The “{\\o}” in “F{\\o}lner sequence” should be ")#mi("\\o")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-484720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2017")])]

#text("A “.” at the beginning of the last paragraph should be removed.")

#emph[#text("[Actually, that entire paragraph was not meant to be there, and is now deleted. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some recent papers | What's new")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-535672")[#strong[#text("Some recent papers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#text("[…] increment argument efficiently. To resolve the second difficulty one needs to find a quantitative concatenation theorem for Gowers uniformity norms. Many of these ideas were developed in previous papers of Peluse and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-578373")[#strong[#text("Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("[…] conjectures, which of course remain open). Results of this type were previously obtained by Tamar Ziegler and myself in the “true complexity zero” case when the polynomials had distinct degrees, in which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-614518")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Hi Prof. Tao, I was wondering, in the statement of Theorem 4, whether we can say anything about the structure of the “infinitely many n” in the conclusion (perhaps related to the n in the admissibility condition)? For example, I have run into a problem where it would be very useful to know if there are infinitely many n having only a fixed set of prime factors $\\latex \\{p_1,\\ldots,p_n\\}$. This seems like it’s probably too much to ask of the theorem, but I am still wondering if the n are just sporadic or if there is some pattern to them. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-614523")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("I would imagine that if one utilised tools such as the arithmetic regularity lemma, one could show that the set of ")#mi("n")#text(" in Theorem 4 is basically measurable with respect to local nilsequences (in the spirit of the Bergelson-Host-Kra theory of sets of multiple recurrence). But there are error terms in this characterisation that may make this unsuitable for your application; if the set of prime factors is indeed fixed (presumably you want to use something like ")#mi("p_k")#text(" rather than ")#mi("p_n")#text(" here), you have an extremely sparse set of ")#mi("n")#text(" which is probably well beyond the range of what the regularity lemma can control, even when augmented with a transference principle, as these methods allow for an exceptional set of ")#mi("n")#text(" that is small but otherwise unstructured, and which could conceivably contain all the ")#mi("n")#text(" that you are interested in. For instance, I doubt that current technology can establish the infinitude of arithmetic progressions of length three, in which two of the elements are prime and the third is a Mersenne number.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/#comment-614533")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Hi Prof. Tao, thanks for your reply! I will take some time to ponder this; indeed it sounded far-fetched after I thought about it for a bit. However, if we increase the set of ")#mi("n")#text(" to something with positive density (for example, suppose we want ")#mi("n")#text(" to be congruent to 4 modulo 100), would there be more hope of finding pairs ")#mi("(n,r)")#text("?")

#text("I am actually working in the simple case where the degree equals 1 and it would actually be enough for me to find a single pair ")#mi("(n,r)")#text(", but I suspect that finding a single pair is equivalent to finding infinitely many. I’m still working on wrapping my head around the implications and limits of these polynomial patterns, but your comments are extremely helpful! I hope you have a Happy New Year!")
]
]
]
