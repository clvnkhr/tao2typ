// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/
// Converted to Typst by tao2typ: "2026-10-14T16:38:54.206083+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The effective potential of an M-matrix", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The effective potential of an M-matrix")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 January 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/")[#text("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://pmc.polytechnique.fr/spip.php?article24&lang=fr")[#text("Marcel Filoche")]#text(", ")#link("http://www-users.math.umn.edu/~svitlana/")[#text("Svitlana Mayboroda")]#text(", and I have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2101.01672")[#text("The effective potential of an ")#mi("{M}")#text("-matrix")]#text("“. This paper explores the analogue of the effective potential of Schrödinger operators ")#mi("{-\\Delta + V}")#text(" provided by the “landscape function” ")#mi("{u}")#text(", when one works with a certain type of self-adjoint matrix known as an ")#link("https://en.wikipedia.org/wiki/M-matrix")[#mi("{M}")#text("-matrix")]#text(" instead of a Schrödinger operator.")

#text("Suppose one has an eigenfunction")

#align(center)[#tao-fit-display[#mitex("(-\\Delta + V) \\phi = E \\phi")]]

#text("of a Schrödinger operator ")#mi("{-\\Delta+V}")#text(", where ")#mi("{\\Delta}")#text(" is the Laplacian on ")#mi("{{\\bf R}^d}")#text(", ")#mi("{V: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" is a potential, and ")#mi("{E}")#text(" is an energy. Where would one expect the eigenfunction ")#mi("{\\phi}")#text(" to be concentrated? If the potential ")#mi("{V}")#text(" is smooth and slowly varying, the ")#link("https://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" suggests that the eigenfunction ")#mi("{\\phi}")#text(" should be mostly concentrated in the potential energy wells ")#mi("{\\{ x: V(x) \\leq E \\}}")#text(", with an exponentially decaying amount of ")#link("https://en.wikipedia.org/wiki/Quantum_tunnelling")[#text("tunnelling")]#text(" between the wells. One way to rigorously establish such an exponential decay is through ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=745286")[#text("an argument of Agmon")]#text(", which we will sketch later in this post, which gives an exponentially decaying upper bound (in an ")#mi("{L^2}")#text(" sense) of eigenfunctions ")#mi("{\\phi}")#text(" in terms of the distance to the wells ")#mi("{\\{ V \\leq E \\}}")#text(" in terms of a certain “Agmon metric” on ")#mi("{{\\bf R}^d}")#text(" determined by the potential ")#mi("{V}")#text(" and energy level ")#mi("{E}")#text(" (or any upper bound ")#mi("{\\overline{E}}")#text(" on this energy). Similar exponential decay results can also be obtained for discrete Schrödinger matrix models, in which the domain ")#mi("{{\\bf R}^d}")#text(" is replaced with a discrete set such as the lattice ")#mi("{{\\bf Z}^d}")#text(", and the Laplacian ")#mi("{\\Delta}")#text(" is replaced by a discrete analogue such as a ")#link("https://en.wikipedia.org/wiki/Laplacian_matrix")[#text("graph Laplacian")]#text(".")

#text("When the potential ")#mi("{V}")#text(" is very “rough”, as occurs for instance in the random potentials arising in the theory of ")#link("https://en.wikipedia.org/wiki/Anderson_localization")[#text("Anderson localisation")]#text(", the Agmon bounds, while still true, become very weak because the wells ")#mi("{\\{ V \\leq E \\}}")#text(" are dispersed in a fairly dense fashion throughout the domain ")#mi("{{\\bf R}^d}")#text(", and the eigenfunction can tunnel relatively easily between different wells. However, as was first discovered in 2012 ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2990982")[#text("by my two coauthors")]#text(", in these situations one can replace the rough potential ")#mi("{V}")#text(" by a smoother ")#emph[#text("effective potential")]#text(" ")#mi("{1/u}")#text(", with the eigenfunctions typically localised to a single connected component of the effective wells ")#mi("{\\{ 1/u \\leq E \\}}")#text(". In fact, a good choice of effective potential comes from locating the ")#emph[#text("landscape function")]#text(" ")#mi("{u}")#text(", which is the solution to the equation ")#mi("{(-\\Delta + V) u = 1}")#text(" with reasonable behavior at infinity, and which is non-negative from the maximum principle, and then the reciprocal ")#mi("{1/u}")#text(" of this landscape function serves as an effective potential.")

#text("There are now several explanations for why this particular choice ")#mi("{1/u}")#text(" is a good effective potential. Perhaps the simplest (as found for instance in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3995095")[#text("this recent paper of Arnold, David, Jerison, and my two coauthors")]#text(") is the following observation: if ")#mi("{\\phi}")#text(" is an eigenvector for ")#mi("{-\\Delta+V}")#text(" with energy ")#mi("{E}")#text(", then ")#mi("{\\phi/u}")#text(" is an eigenvector for ")#mi("{-\\frac{1}{u^2} \\mathrm{div}(u^2 \\nabla \\cdot) + \\frac{1}{u}}")#text(" with the same energy ")#mi("{E}")#text(", thus the original Schrödinger operator ")#mi("{-\\Delta+V}")#text(" is conjugate to a (variable coefficient, but still in divergence form) Schrödinger operator with potential ")#mi("{1/u}")#text(" instead of ")#mi("{V}")#text(". Closely related to this, we have the integration by parts identity ")#metadata(none) <tao-7d1bc7cfaf1f313f7299>#tao-math("\\displaystyle  \\int_{{\\bf R}^d} \\left|\\nabla f\\right|^2 + V \\left|f\\right|^2\\ dx = \\int_{{\\bf R}^d} u^2 \\left|\\nabla(f/u)\\right|^2 + \\frac{1}{u} \\left|f\\right|^2\\ dx \\ \\ \\ \\ \\ (1)", block: false)#text(" ")#text(" for any reasonable function ")#mi("{f}")#text(", thus again highlighting the emergence of the effective potential ")#mi("{1/u}")#text(".")

#text("These particular explanations seem rather specific to the Schrödinger equation (continuous or discrete); we have for instance not been able to find similar identities to explain an effective potential for the bi-Schrödinger operator ")#mi("{\\Delta^2 + V}")#text(".")

#text("In this paper, we demonstrate the (perhaps surprising) fact that effective potentials continue to exist for operators that bear very little resemblance to Schrödinger operators. Our chosen model is that of an ")#link("https://en.wikipedia.org/wiki/M-matrix")[#mi("{M}")#text("-matrix")]#text(": self-adjoint positive definite matrices ")#mi("{A}")#text(" whose off-diagonal entries are negative. This model includes discrete Schrödinger operators (with non-negative potentials) but can allow for significantly more non-local interactions. The analogue of the landscape function would then be the vector ")#mi("{u := A^{-1} 1}")#text(", where ")#mi("{1}")#text(" denotes the vector with all entries ")#mi("{1}")#text(". Our main result, roughly speaking, asserts that an eigenvector ")#mi("{A \\phi = E \\phi}")#text(" of ")#mi("{A}")#text(" will then be exponentially localised to the “potential wells” ")#mi("{K := \\{ j: \\frac{1}{u_j} \\leq E \\}}")#text(", where ")#mi("{u_j}")#text(" denotes the coordinates of the landscape function ")#mi("{u}")#text(". In particular, we establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_k \\phi_k^2 e^{2 \\rho(k,K) / \\sqrt{W}} ( \\frac{1}{u_k} - E )_+ \\leq W \\max_{i,j} \\left|a_{ij}\\right|", block: true)]]

#text("if ")#mi("{\\phi}")#text(" is normalised in ")#mi("{\\ell^2}")#text(", where the ")#emph[#text("connectivity")]#text(" ")#mi("{W}")#text(" is the maximum number of non-zero entries of ")#mi("{A}")#text(" in any row or column, ")#mi("{a_{ij}}")#text(" are the coefficients of ")#mi("{A}")#text(", and ")#mi("{\\rho}")#text(" is a certain moderately complicated but explicit metric function on the spatial domain. Informally, this inequality asserts that the eigenfunction ")#mi("{\\phi_k}")#text(" should decay like ")#mi("{e^{-\\rho(k,K) / \\sqrt{W}}}")#text(" or faster. Indeed, our numerics show a very strong log-linear relationship between ")#mi("{\\phi_k}")#text(" and ")#mi("{\\rho(k,K)}")#text(", although it appears that our exponent ")#mi("{1/\\sqrt{W}}")#text(" is not quite optimal. We also provide an associated localisation result which is technical to state but very roughly asserts that a given eigenvector will in fact be localised to a single connected component of ")#mi("{K}")#text(" unless there is a resonance between two wells (by which we mean that an eigenvalue for a localisation of ")#mi("{A}")#text(" associated to one well is extremely close to an eigenvalue for a localisation of ")#mi("{A}")#text(" associated to another well); such localisation is also strongly supported by numerics. (Analogous results for Schrödinger operators had been previously obtained by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3995095")[#text("the previously mentioned paper of Arnold, David, Jerison, and my two coauthors")]#text(", and to quantum graphs in a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4068279")[#text("very recent paper of Harrell and Maltsev")]#text(".)")

#text("Our approach is based on Agmon’s methods, which we interpret as a double commutator method, and in particular relying on exploiting the negative definiteness of certain double commutator operators. In the case of Schrödinger operators ")#mi("{-\\Delta+V}")#text(", this negative definiteness is provided by the identity ")#metadata(none) <tao-7507462c842221b8e6a8>#tao-math("\\displaystyle  \\langle [[-\\Delta+V,g],g] u, u \\rangle = -2\\int_{{\\bf R}^d} \\left|\\nabla g\\right|^2 \\left|u\\right|^2\\ dx \\leq 0 \\ \\ \\ \\ \\ (2)", block: false)#text(" ")#text(" for any sufficiently reasonable functions ")#mi("{u, g: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", where we view ")#mi("{g}")#text(" (like ")#mi("{V}")#text(") as a multiplier operator. To exploit this, we use the commutator identity")

#tao-aligned(keep: true)[


#tao-math("\\langle g [\\psi, -\\Delta+V] u, g \\psi u \\rangle  & = \\frac{1}{2} \\langle [[-\\Delta+V, g \\psi],g\\psi] u, u \\rangle", block: true)



#tao-math(" & -\\frac{1}{2} \\langle [[-\\Delta+V, g],g] \\psi u, \\psi u \\rangle", block: true)
]

#text("valid for any ")#mi("{g,\\psi,u: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" after a brief calculation. The double commutator identity then tells us that")

#align(center)[#tao-fit-display[#tao-math("\\langle g [\\psi, -\\Delta+V] u, g \\psi u \\rangle \\leq \\int_{{\\bf R}^d} \\left|\\nabla g\\right|^2 \\left|\\psi u\\right|^2\\ dx.", block: true)]]

#text("If we choose ")#mi("{u}")#text(" to be a non-negative weight and let ")#mi("{\\psi := \\phi/u}")#text(" for an eigenfunction ")#mi("{\\phi}")#text(", then we can write")

#align(center)[#tao-fit-display[#mitex("[\\psi, -\\Delta+V] u = [\\psi, -\\Delta+V - E] u = \\psi (-\\Delta+V - E) u")]]

#text("and we conclude that")

#metadata(none) <tao-de2b0db64a9c8465b9b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\int_{{\\bf R}^d} \\frac{(-\\Delta+V-E)u}{u} \\left|g\\right|^2 \\left|\\phi\\right|^2\\ dx \\leq \\int_{{\\bf R}^d} \\left|\\nabla g\\right|^2 \\left|\\phi\\right|^2\\ dx.", block: true)]]

#text("We have considerable freedom in this inequality to select the functions ")#mi("{u,g}")#text(". If we select ")#mi("{u=1}")#text(", we obtain the clean inequality")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} (V-E) \\left|g\\right|^2 \\left|\\phi\\right|^2\\ dx \\leq \\int_{{\\bf R}^d} \\left|\\nabla g\\right|^2 \\left|\\phi\\right|^2\\ dx.", block: true)]]

#text("If we take ")#mi("{g}")#text(" to be a function which equals ")#mi("{1}")#text(" on the wells ")#mi("{\\{ V \\leq E \\}}")#text(" but increases exponentially away from these wells, in such a way that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla g\\right|^2 \\leq \\frac{1}{2} (V-E) \\left|g\\right|^2", block: true)]]

#text("outside of the wells, we can obtain the estimate")

#align(center)[#tao-fit-display[#tao-math("\\int_{V > E} (V-E) \\left|g\\right|^2 \\left|\\phi\\right|^2\\ dx \\leq 2 \\int_{V < E} (E-V) \\left|\\phi\\right|^2\\ dx,", block: true)]]

#text("which then gives an exponential type decay of ")#mi("{\\phi}")#text(" away from the wells. This is basically the classic exponential decay estimate of Agmon; one can basically take ")#mi("{g}")#text(" to be the distance to the wells ")#mi("{\\{ V \\leq E \\}}")#text(" with respect to the Euclidean metric conformally weighted by a suitably normalised version of ")#mi("{V-E}")#text(". If we instead select ")#mi("{u}")#text(" to be the landscape function ")#mi("{u = (-\\Delta+V)^{-1} 1}")#text(", ")#link(<tao-de2b0db64a9c8465b9b6>)[#text("(3)")]#text(" then gives")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} (\\frac{1}{u} - E) \\left|g\\right|^2 \\left|\\phi\\right|^2\\ dx \\leq \\int_{{\\bf R}^d} \\left|\\nabla g\\right|^2 \\left|\\phi\\right|^2\\ dx,", block: true)]]

#text("and by selecting ")#mi("{g}")#text(" appropriately this gives an exponential decay estimate away from the effective wells ")#mi("{\\{ \\frac{1}{u} \\leq E \\}}")#text(", using a metric weighted by ")#mi("{\\frac{1}{u}-E}")#text(".")

#text("It turns out that this argument extends without much difficulty to the ")#mi("{M}")#text("-matrix setting. The analogue of the crucial double commutator identity ")#link(<tao-7507462c842221b8e6a8>)[#text("(2)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\langle [[A,D],D] u, u \\rangle\t= \\sum_{i \\neq j} a_{ij} u_i u_j (d_{ii} - d_{jj})^2 \\leq 0")]]

#text("for any diagonal matrix ")#mi("{D = \\mathrm{diag}(d_{11},\\dots,d_{NN})}")#text(". The remainder of the Agmon type arguments go through after making the natural modifications.")

#text("Numerically we have also found some aspects of the landscape theory to persist beyond the ")#mi("{M}")#text("-matrix setting, even though the double commutators cease being negative definite, so this may not yet be the end of the story, but it does at least demonstrate that utility the landscape does not purely rely on identities such as ")#link(<tao-7d1bc7cfaf1f313f7299>)[#text("(1)")]#text(".")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-615797")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2021")])]

#text("Terry, I am writing a new book for which I must obtain legal releases if I mention a “real live person.” I mentioned your name in the unfinished draft of the unpublished book, with the highest regards in every way. When I finish the draft, I will be making copies to send to the people that I mentioned in the book, from whom I need to obtain a release. I also hope that you have Time to read the draft, as I would very much appreciate your opinion.")

#text("Very Sincerely, David W. Fry")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-619892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2021")])]

#link("https://www.math.ucla.edu/~tao/media.html")[#text("https://www.math.ucla.edu/~tao/media.html")]#text(" might be a better contact point for stuff like this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-617974")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2021")])]

#text("Thanks for this, it’s amazing how this Schrodinger operator stuff keeps coming back.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73f06a036929ed8fa684029d5a47d2dd25b75600b29c5a2eccb70b45965af0f8-bf7d21f3c0a55fe90e97b45935f035d62d63da9707ef87228fc776b905873cdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TutorEye")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-620607")[#strong[#text("TutorEye")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2021")])]

#text("Really like the way, the M-Matrix explained by you. Thanks for the help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c43642f94fd02fca843c8afae6be5ffbad1361b13b431b704905d020040c895d-99862dee739e9a7d07ad9f28f989a7bd813820c2cf550014baee08b457a3e0c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek Hannegan")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-623997")[#strong[#text("Derek Hannegan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2021")])]

#text("When I initially commented I clicked the -Notify me when new comments are added- checkbox and now every time a remark is added I get four emails with the identical comment. Is there any means you can remove me from that service? Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Closing the “green gap”: from the mathematics of the landscape function to lower electricity costs for households | What's new")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-687254")[#strong[#text("Closing the “green gap”: from the mathematics of the landscape function to lower electricity costs for households | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("[…] discussed in this previous blog post (discussing a paper on this topic I wrote with some of the members of this collaboration), one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6e1e76d56870819f60c86aa5cc26c6618b4b9c83584815ee7345f9e77091a7a-554af172f62a4ce0d898ed15a5709df1634e7a5d44380c990328f9930340b380.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Martin")]], [#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/#comment-693199")[#strong[#text("David Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Dear Prof. Tao,")

#text("Your result on eigenvector localization for M-matrices via the landscape function raises a natural question in spectral graph theory.")

#text("Setup. Let ")#mi("G")#text(" be a connected graph with Laplacian ")#mi("L")#text(", adjacency matrix ")#mi("A")#text(", degree matrix ")#mi("D")#text(", and let ")#mi("L_t = \\mathrm{diag}(\\sigma) - A^2 \\circ A")#text(" be the “triangle Laplacian,” where ")#mi("\\sigma_v")#text(" counts triangles at vertex ")#mi("v")#text(", ")#mi("(A^2 \\circ A)_{ij} = t_{ij}")#text(" is the number of common neighbors of adjacent vertices ")#mi("i,j")#text(", and ")#mi("\\circ")#text(" denotes the Hadamard (entrywise) product.")

#text("Define the matrix ")#mi("S = \\frac{1}{2}(LD + DL) - L_t")#text(".")

#text("For any Laplacian eigenvector ")#mi("f")#text(" with ")#mi("Lf = \\lambda f")#text(", one obtains the exact identity ")#mi("f^T S f = \\lambda \\sum_v d_v f_v^2 - \\sum_e t_e (f_a - f_b)^2")#text(".")

#text("The key structural fact: ")#mi("S")#text(" is a Z-matrix (verified computationally on large graph families: off-diagonal entries satisfy ")#mi("t_{ij} - (d_i+d_j)/2 \\le 0")#text(" since ")#mi("t_{ij} \\le \\min(d_i, d_j) - 1")#text("). Moreover, ")#mi("S")#text(" is an M-matrix (i.e., positive semidefinite) if and only if ")#mi("G")#text(" is regular, in which case ")#mi("S = dL - L_t")#text(" is positive semidefinite and the inequality ")#mi("f^T S f \\ge 0")#text(" follows.")

#text("The question. For irregular graphs, ")#mi("S")#text(" is an indefinite Z-matrix (typically 1-2 negative eigenvalues). Nevertheless, we have verified computationally on ")#mi("10^5")#text("+ connected graphs that ")#mi("f^T S f \\ge 0")#text(" holds for every Laplacian eigenvector ")#mi("f")#text(". The mechanism is an anti-correlation forced by the eigenvector equation: edges with large triangle count ")#mi("t_e")#text(" carry small Fiedler gradient ")#mi("(f_a - f_b)^2")#text(", and vice versa (")#mi("\\mathrm{corr}(t_e, g_e^2) < 0")#text(" on 100% of tested graphs).")

#text("Has the extension of the landscape/effective-potential framework to indefinite Z-matrices but restricted to eigenvectors of a related operator (here, the Laplacian) been considered? The inequality ")#mi("f^T S f \\ge 0")#text(" is not a global PSD statement, but a spectral-subspace positivity condition for a Z-matrix that is “almost” an M-matrix (low-rank negative part). Any pointers to related results would be greatly appreciated.")

#text("(A preprint with the full computational verification, the exhaustive list of eliminated proof routes, and the Lean 4 formalization of all surrounding results is in preparation.)")
]
]
