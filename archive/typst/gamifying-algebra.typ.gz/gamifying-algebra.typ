// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/
// Converted to Typst by tao2typ: "2026-10-14T09:24:51.946650+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Gamifying algebra?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Gamifying algebra?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 April 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/")[#text("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("High school algebra marks a key transition point in one’s early mathematical education, and is a common point at which students feel that mathematics becomes really difficult. One of the reasons for this is that the problem solving process for a high school algebra question is significantly more free-form than the mechanical algorithms one is taught for elementary arithmetic, and a certain amount of planning and strategy now comes into play. For instance, if one wants to, say, write ")#mi("{\\frac{1,572,342}{4,124}}")#text(" as a mixed fraction, there is a clear (albeit lengthy) algorithm to do this: one simply sets up the long division problem, extracts the quotient and remainder, and organises these numbers into the desired mixed fraction. After a suitable amount of drill, this is a task that can be accomplished by a large fraction of students at the middle school level. But if, for instance, one has to solve a system of equations such as")

#tao-aligned(keep: true)[


#tao-math("a^2 + bc  & = 7", block: true)



#tao-math("2b - c  & = 1", block: true)



#tao-math("a + 2  & = c", block: true)
]

#text("for ")#mi("{a,b,c}")#text(", there is no similarly mechanical procedure that can be easily taught to a high school student in order to solve such a problem “mindlessly”. (I doubt, for instance, that any attempt to teach ")#link("http://en.wikipedia.org/wiki/Buchberger%27s_algorithm")[#text("Buchberger’s algorithm")]#text(" to such students will be all that successful.) Instead, one is taught the basic “moves” (e.g. multiplying both sides of an equation by some factor, subtracting one equation from another, substituting an expression for a variable into another equation, and so forth), and some basic principles (e.g. simplifying an expression whenever possible, for instance by gathering terms, or solving for one variable in terms of others in order to eliminate it from the system). It is then up to the student to find a suitable combination of moves that isolates each of the variables in turn, to reveal their identities.")

#text("Once one is sufficiently expert in algebraic manipulation, this is not all that difficult to do, but when one is just starting to learn algebra, this type of problem can be quite daunting, in part because of an “embarrasment of riches”; there are several possible “moves” one could try to apply to the equations given, and to the novice it is not always clear in advance which moves will simplify the problem and which ones will make it more complicated. Often, such a student may simply try moves at random, which can lead to a dishearteningly large amount of effort expended without getting any closer to a solution. What is worse, each move introduces the possibility of an arithmetic error (such as a sign error), the effect of which is usually not apparent until the student finally arrives at his or her solution and either checks it against the original equation, or submits the answer to be graded. (My own son can get quite frustrated after performing a lengthy series of computations to solve an algebra problem, only to be told that the answer was wrong due to an arithmetic error; I am sure this experience is common to many other schoolchildren.)")

#text("It occurred to me recently, though, that the set of problem-solving skills needed to solve algebra problems (and, to some extent, calculus problems also) is somewhat similar to the set of skills needed to solve puzzle-type computer games, in which a certain limited set of moves must be applied in a certain order to achieve a desired result. (There are countless games of this general type; a typical example is “")#link("http://www.bartbonte.com/factoryballs/")[#text("Factory balls")]#text("“.) Given that the computer game format is already quite familiar to many schoolchildren, one could then try to teach the strategy component of algebraic problem-solving via such a game, which could automate mechanical tasks such as gathering terms and performing arithmetic in order to reduce some of the more frustrating aspects of algebra. (Note that this is distinct from the type of maths games one often sees on educational web sites, which are usually based on asking the player to correctly answer some maths problem in order to advance within the game, making the game essentially a disguised version of a maths quiz. Here, the focus is not so much on being able to supply the correct answer, but on being able to select an effective problem-solving strategy.)")

#text("It is difficult to explain in words exactly what type of game I have in mind, so I decided to create a quick mockup of what a sample “level” would look like ")#link("http://scratch.mit.edu/projects/teorth/2472326")[#text("here")]#text(" (note: requires Java). I didn’t want to spend too much time to make this mockup, so I wrote it in ")#link("http://en.wikipedia.org/wiki/Scratch_(programming_language)")[#text("Scratch")]#text(", which is a somewhat limited programming language intended for use by children, but which has the benefit of being able to churn out simple but functional apps very quickly (the mockup took less than half an hour to write). (I would certainly not attempt to write a full game in this language, though.) In this mockup level, the objective is to solve a single linear equation in one variable, such as ")#mi("{2x+7=11}")#text(", with only two “moves” available: the ability to subtract ")#mi("{1}")#text(" from both sides of the equation, and the ability to divide both sides of the equation by ")#mi("{2}")#text(", which one performs by clicking on an appropriate icon.")

#text("It seems to me that one could actually teach a fair amount of algebra through a game such as this, with a progressively difficult sequence of levels that gradually introduce more and more types of “moves” that can handle increasingly difficult problems (e.g. simultaneous linear equations in several unknowns, quadratic equations in one or more variables, inequalities, etc.). Even within a single class of problem, such as solving linear equations, one could create additional challenge by placing some restriction on the available moves, for instance by limiting the number of available moves (as was done in the mockup), or requiring that each move cost some amount of game currency (which might possibly be waived if one is willing to perform the move “by hand”, i.e. by entering the transformed equation manually). And of course one could also make the graphics, sound, and gameplay fancier (e.g. by allowing for various competitive gameplay modes). One could also imagine some other types of high-school and lower-division undergraduate mathematics being amenable to this sort of gamification (calculus and ODE comes to mind, and maybe propositional logic), though I doubt that one could use it effectively for advanced undergraduate or graduate topics. (Though I have sometimes wished for an “integrate by parts” or “use Sobolev embedding” button when trying to control solutions to a PDE…)")

#text("This would however be a fair amount of work to actually implement, and is not something I could do by myself with the time I have available these days. But perhaps it may be possible to develop such a game (or platform for such a game) collaboratively, somewhat in the spirit of the polymath projects? I have almost no experience in modern software development (other than a summer programming job I had as a teenager, which hardly counts), so I would be curious to know how projects such as this actually get started in practice.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/867d426940413bcd4ce8420114ad9baf91b11e65d1ca7c1556632ec73b494cf6-cb5e346fdfde42ceb0b7bf825199badc1173d44f1858d69018412eea94e80405.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay Daigle")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138347")[#strong[#text("Jay Daigle")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2012")])]

#text("Professor Tao: there actually is software like this out there, or at least there was ten years ago when I was in high school. I was part of the EPGY program–if you’re not familiar with it, it’s a set of electronic correspondence courses run out of Stanford intended for advanced high schoolers. I worked through Algebra I with them, and part of the course module was software exactly like what you describe. I don’t know if the software is available in any other context, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed740a0d5decac007a26bcf18f8407b46942cc77e17975fc9e2e29eb9d95993f-101559ec0cf853cfae40cb86e4f5a37f9af3f5bd0c02eb8fe8f7b92bfa097bef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Gwynne (@aeternus)")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138350")[#strong[#text("Matthew Gwynne (@aeternus)")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2012")])]

#text("It would be interesting to consider the connection to this and interactive theorem provers like Isabelle (")#link("http://isabelle.in.tum.de/index.html")[#text("http://isabelle.in.tum.de/index.html")]#text("). I’d guess even slightly more complicated proof constructs could be handled in some way. The syntax and interface are likely too complicated for kids, but a lot of the underlying proof “actions” from things like Isabelle might be useful as a starting point for actions in such games.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138380")[#strong[#text("Jacob")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Professor Tao,")

#text("You might find the Bootstrap project (")#link("http://www.bootstrapworld.org/")[#text("http://www.bootstrapworld.org/")]#text(") interesting. From their mission statement:")

#text("“Bootstrap is a standards-based curriculum for middle-school students, which teaches them to program their own videogames using purely algebraic and geometric concepts.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cc083fb7ae921cbc63af6d0f4bb94b0f2f453c9311a170f95b758f16fd62362-e58c89776b88d4d0e0afee87deb6a63861c4acb17531d4407b75f700574a6bbd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bjk5")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138381")[#strong[#text("bjk5")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("This is right on. While we’re far from achieving the goals you set out, we’re trying to build more and more of this learning-via-intrinsic gamification into our interactive exercises at Khan Academy. A couple recent examples:")

#link("http://www.khanacademy.org/math/statistics/e/exploring_standard_deviation_1")[#text("http://www.khanacademy.org/math/statistics/e/exploring_standard_deviation_1")]#linebreak()#text(" ")#link("http://www.khanacademy.org/math/statistics/e/exploring_mean_and_median")[#text("http://www.khanacademy.org/math/statistics/e/exploring_mean_and_median")]#linebreak()#text(" ")#link("http://www.khanacademy.org/math/calculus/e/derivative_intuition")[#text("http://www.khanacademy.org/math/calculus/e/derivative_intuition")]

#text("…and while we’re just getting started, our platform for building this type of interaction is open, if anyone has ideas or wants to help: github.com/khan/khan-exercises")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efac3fe4c920ea9aa54da11e4e8b19d1614cb22b4468048b70687505ed0f40c7-961770245eb45326e8db4d54a697b892d7aeed2b8a2c9cc0e5983b87b3301404.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gustaf")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138409")[#strong[#text("Gustaf")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Think you’re spot on. You should give the games at ")#link("http://www.mangahigh.com/en_gb/games")[#text("http://www.mangahigh.com/en_gb/games")]#text(" a try!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/770ee43696a0192b1576e358a6800b098ad1d3185f67b6ff195e385312c97434-26349e8804cce7aed22f7e31c725b9bda287c4a96eaa9779aab8485144f2b678.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138418")[#strong[#text("Charles")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Exactly this. Edu gaming should not be about rocketships and laser guns. Its about using technology to simplify the problem solving approach to the most simple core element (then you take away supports until they can do it themselves). For example, the first time you drive a car, you might go to an empty parking lot or quiet street just to get a handle on acceleration and steering, sure, you don’t *actually* know how to drive from these scenarios, but it helps you master the basics before you go ahead and crash into somebody.")

#text("There is currently a FANTASTIC little app which would solve exactly the problem your son was having with his algebra work. Here’s a link:")#linebreak()#text(" ")#linebreak()#text(" Notice that the arithmetic and rewrites are all handled by the software, so the student can focus on applying different strategies to solve these algebra “puzzles”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138441")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("That Algebra Touch app looks beautiful and useful, but I wouldn’t quite call it a gamification.")

#text("I think that the ideal algebra game wouldn’t look much like algebra at all, so that it could be used well before formal instruction begins. I’m thinking of a game in which the equation (or equations) is represented completely pictorially. For example, 16x+7=87 could be a scale with 16 red balls and 7 blue balls on one side and 87 blue balls on the other. There could be a “Tool 1” that lets you click on identical items on each side of the scale and “additively cancel” them away. (Or of course, anothet tool that adds the same things to both sides.) That would leave you with 16x=80. “Tool 2” would then let you execute the division step by physically arranging the balls into groups. (For example, 4 groups of 4 red balls each on one side, and 4 groups of 20 blue balls each.) I guess subtraction could be achieved with negative balls that cancel the blue ones. (I guess that hurts the simple physical interpretation of weights.) More advanced levels would allow you to do things like break balls into fractional wedges, or re-package the balls into stuff like a red box representing 234/7 red balls, or something like that (so that you can easily deal with harder numbers). Higher levels would give you access to tools that automate processes mastered earlier on (e.g. “divide by 4” would automate the previously physical process of making 4 equal sized groups on each side). I’m sure there are even better ways of doing this than what I am describing (for example, x^2 doesn’t work so easily with this visualization), but I think a game along these lines would be pretty awesome.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Ah, you’ve reminded me that I’ve already seen a quite nice game like this: ")#link("http://www.mathplayground.com/balance_scales.html")[#text("http://www.mathplayground.com/balance_scales.html")]

#text("I agree that one should use non-numeric representations for these equations at early levels, with perhaps a transition to numeric ones occurring at some more advanced stage of the game. (One can also imagine using various animations to illustrate basic concepts such as cancelling, such as having the objects representing the left-hand side “go to war” with those on the right-hand side.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e6ae09609e2af75674e0148c5ccdfd1890b2141c5957bcbe6e66b3708dff06-86e24ab119777fcf481bacc29a0775c178571d32b0c54d3c6f9d054968ed2846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan L")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138689")[#strong[#text("Dan L")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2012")])]

#text("Professor Tao, do you happen to have a list of games that you like from mathplayground.com? I’ve poked around there a few times, but I always get overwhelmed by the huge number of games available there (and the minimal organization and lack of a rating system).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138444")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Sign errors are common in elementary algebra. They are avoided by defining m=-1 by the equation m+1=0 and replacing ‘-‘ by ‘+m’ everywhere where the minus sign occurs in the formulas. For example (a+b)(a-b) = (a+b)(a+mb) = (a+b)a+(a+b)mb = aa+ba+amb+bmb = aa+ab+mab+mbb = aa+(1+m)ab+mbb = aa+0ab+mbb = aa+mbb. Here all the intermediate results are included and all the steps are elementary. Doing this will free the student from making sign errors. And later introducing complex numbers by ii+1=0 will be less surprising.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db20ff5b8c0a318bfcda99f22767c1a4dbd3aa9976a62c12afd43f815dde0109-fab726c9d4fe1431dc1c98262796546428e3cdf0f5ddaa5a9760d7a777db3258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sigfpe")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138481")[#strong[#text("sigfpe")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Here’s a gamified version of an algebraic problem: proving that X=X^7 in the semiring where X=1+X^2. It’s related to the classic method of studying positions in peg Solitaire. ")#link("http://blog.sigfpe.com/2007/09/arboreal-isomorphisms-from-nuclear.html")[#text("http://blog.sigfpe.com/2007/09/arboreal-isomorphisms-from-nuclear.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/745de7e1ff53e8a6f60ff88865dfef07982fe6ddb3e254e4d9cf880def122a75-9c8c9eb9ac6dcd52a1792a6a84c4ab50c979808c6123e8f910af707d9537ee9c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward C. Jones")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138484")[#strong[#text("Edward C. Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("A little quiz:")

#text("What is “x”? What is “a”?")

#text("Give four answers: an answer suited for a PhD logician, an answer suited for an undergraduate who has had a semester of mathematical logic and set theory, an answer suited for a middle school teacher, and an answer suited for a middle school student. How equivalent are the answers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/103228f3b115a98dfdec691a59201bf7acbd272526237388c89cdb0b05232465-592cb343c8a10f813ca25193ab4ba123918a7cf22160feb9771589bbf324cc5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MK")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138514")[#strong[#text("MK")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("I think a lot of people out there must have wished for a program just as you describe. I am definitely hoping someone out there will build one some day. After college I spent about a year on the idea but have very limited programming skills so it was a dead end. I envisioned a learner having the freedom to try different operations but they only get certain ‘moves’ at first, such as cancel, or move x from left side to right side. Then as they level up there are more types of operations and more difficult problems. The benefit of the computer environment is it eliminates the worry of arithmetic error. Also, the nice thing with a computer is you can do ‘handicap’ problems, where you disable certain moves so the player has to learn different ways to solve/view the same problem.")

#text("Also just wanted to suggest Polya’s ‘Plausible Reasoning’ as a useful reference. I found it very inspiring when I was making my attempt on the program, since it is the clearest guidance I could find on the mechanics of solving math problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcc2c1260143d5d496620fb65f237be2da0c71759cf7830e15a468bdfce4b0af-7bfb5de796bca5d272d1cabc75e6d8f57da9d1d024a12676968e815dc4c95f66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saurabh srivastava")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138528")[#strong[#text("saurabh srivastava")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Hi Terence,")

#text("You should look at two directions of work:")#linebreak()#text(" – sumit gulwani’s “program synthesis for automated education” effort: He is a researcher at MSR in program synthesis and he has been attempting to design automated tutoring systems along the lines you describe. See his paper “Synthesizing Geometry Constructions”, or “Automatically Generating Algebra Problems” for examples.")#linebreak()#text(" – math.mettl.com: is a platform that guides, and corrects, students through K-12 math. They are different from what you describe the website game where they make users progress though the exercises laid out in a game; i.e., khan academy style. Since they are commercial establishment, their approach is opaque, but good to know.")#linebreak()#text(" – In general the program synthesis community (shameless plug :), has been recently interested in these applications as our techniques have direct applicability to this domain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monsieurcactus")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138530")[#strong[#text("monsieurcactus")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("This is more advanced but I always had trouble learning undergraduate real analysis with all the delta-epsilons. It is easier to learn it as a two-player game?")

#text("Continuity looks terrible for a first-timer.")#linebreak()#text(" ")#tao-math("\\forall \\epsilon > 0, \\exists \\epsilon > 0 : \\left|x - x_0\\right|< \\delta \\to \\left|f(x) - f(x_0)\\right| < 0", block: false)#linebreak()#text(" We could turn it into a game between two players.")

#text("First A choose ")#mi("\\epsilon > 0")#linebreak()#text(" B’s turn to pick ")#mi("\\delta > 0")#linebreak()#text(" A choose an ")#mi("x_0 - \\epsilon < x < x_0 + \\epsilon")#linebreak()#text(" B verifies ")#mi("f(x_0) - \\delta < f(x)  < f(x_0) + \\delta")

#text("Uniform Continuity is not much better… This is how I navigated through my analysis classes. I’m not sure if verifying continuity is a collective effort. I could imagine both sides quite actively choosing bad values of delta and epsilon to stump the other. And I’m not sure why I made “choose” and “verify” on equal footing.")

#text("I imagine a game-theoretic interpretation of analysis might be more fun…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/327f9f3a1db74ee8538c313fa50ba96659d0fc9ab39b57f89967d180c8a1c49b-7b6476e6a50027d124a4788e61f3f2ab851a84f748b5965d3072ebb12e85b5cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of william42")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138790")[#strong[#text("william42")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2012")])]

#text("Actually, one of my professors at UNC uses a game-like metaphor for nested quantifiers like that: “Suppose the enemy gives you an ")#mi("\\varepsilon")#text(", then you can choose a ")#mi("\\delta")#text(" such that …”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/194bff3076789f1d0029843fa6171f9ead45ccab7937ed54655e9fa4b8549e37-7233950bd76149f164cc5bf350a765cf9e90e615eb5647925634ed36fdda2a19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron F.")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138541")[#strong[#text("Aaron F.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("I think the “Balance Scales” game linked in this comment (")#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138451")[#text("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138451")]#text(") is a bit silly. In pretty much all the levels I’ve seen so far, the heaviest object is the unique object that never appears on the high end of a scale or on a balanced scale. I don’t think this is a universal feature of the kinds of inequalities being played with… is it just lazy level design?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("I think this is a universal feature of this type of puzzle, provided that one asks for a unique solution. Clearly the (unique) heaviest object A satisfies the condition that it never appears on the high end of a scale or on a balanced scale (in terms of inequalities, this says that the mass of the object is always greater than some other quantity). On the other hand, if any other object B satisfies the same condition, then it is impossible to distinguish which one is heavier (for instance, if we assume that mass(A)>mass(B)>0, then note that the inequalities mass(B) satisfies would be also be satisfied by A+B).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138591")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2012")])]

#text("Here’s an example of gamifying higher-dimensional algebra (aka symmetric monoidal categories).")

#link("http://dream.inf.ed.ac.uk/projects/quantomatic/")[#text("http://dream.inf.ed.ac.uk/projects/quantomatic/")]

#text("In this case it is a research tool, and very useful because the classically notated calculations are horrendous, and the more modern string diagram notation (only a couple of decades old) can be time consuming to draw.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56ce2a22e59696d5e5a8173c747ffe625d9425fcbe556abfa6d861e4c5e5133e-34f417d3a0657719afc5240013e4b7e4432d5d25ef21e55768be39a73f9b1f4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gert Vercleyen")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-625053")[#strong[#text("Gert Vercleyen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2021")])]

#text("The link points to a website where you need to log in to get access. Is there an alternative link? I’m really interested in this example as symmetric monoidal categories are part of my research")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee89f7be5db84c69427e542c843fce8ef950081c46c1d97f90c35d66fd32a12f-aebd9da958af9f6d8842f374a0daafcf96130da3c271896c6306f8689019624d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Cipra")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138703")[#strong[#text("Barry Cipra")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2012")])]

#text("This is at a somewhat lower level and doesn’t really call for any snazzy software, but I thought I’d mention it here as it fits in with the general pedagogical objective. A couple of years ago I came up with a game I call “Factor Subtractor” intended to motivate practice in elementary arithmetic. Analyzing the strategy for best play leads to some open questions of potential interest. There is a short write-up describing the game available among the links for the OEIS sequence ")#link("http://oeis.org/A208980")[#text("http://oeis.org/A208980")]#text(" (4,9,10,14,16,18,22,25,…). A key point: I’ve had positive reports from some teachers who’ve tried it with their students that kids actually enjoy playing the game.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9ddf40795cc0559c50c9add99aea7cfdc5826aa69e50e1d49fc1bb215c81bac-8e90a524452d1eca30d4d3d2b94faa32b8e75874ef2595e6f791be491b02fcf6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Altekruse")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138787")[#strong[#text("Jason Altekruse")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2012")])]

#text("I have actually been working on an application for doing these types of interactive algebra problems for about a year now. My goal with the software is to give teachers better insight into the day to day learning of their students, by storing their work in the cloud. While I believe that creating a more game-like atmosphere could be useful for engaging students, I have been focusing my efforts on creating a system that fits within a classic educational model. Some of the the students’ busywork is reduced with the application copying expressions from one line to the next, but in terms of adding functionality to perform operations like combining terms, the difficulty has not been in creating algorithms, but deciding how to allow teachers to turn these features on and off for different exercises/courses without making the system too complicated. If you would be interested in hearing more about the project email me at dev AT open-math.com")

#text("Nice blog post, and for what its worth a pretty workable demo for a half and hour with scratch.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of New version of algebra game « What’s new")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-138976")[#strong[#text("New version of algebra game « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")])]

#text("[…] a quick update on my previous post on gamifying the problem-solving process in high school algebra. I had a little time to spare (on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-139520")[#strong[#text("Gamifying Algebra? | EnGaming")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2012")]

#text("[…] Read the full article on Terrytao.wordpress.com […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4d42988afbb0b874dc6de28d7c63d9948b7ccbb620ce3e8e8c5d6c4ecf856cd-a6dcda6165c36a4fc77967ec4791cad63420d222b314e56788929ff1c269a90c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-140451")[#strong[#text("Terry")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2012")])]

#text("Reblogged this on ")#link("http://secretblognumber2.wordpress.com/2012/04/26/41/")[#text("Secret Blog #2")]#text(" and commented:")#linebreak()#text(" I once used Geometry to sell provolone cheese,. This guy takes that idea and moves it all the way up to Gruyere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f9e7ebd094956f03f9379cdfd63933fcc35dda97816b546e51e795edab7a902-36d74dad9e4753db72b6897dcbc12885a775a95d01ab05ed7b61ce326ddb34c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mariadroujkova")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-142532")[#strong[#text("mariadroujkova")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2012")])]

#text("I see you got a fair amount of interest (and links) for your project. Would you like to have a webinar about it at Math Future? There are several game designers involved – including Bootstrap and Math Playground creators.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a70bb7060e971a779144b627f5b33a4ec8983c8fbf836fef6454d7801e549d11-b79b37b1b3204e6eb074164bcbbe75d92edde7c41f35d2480abf8f40b37971e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-147006")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2012")])]

#text("Hi Terry,")

#text("You may like to know that there is an app now available for iOS and Android called DragonBox, which is exactly algebra gamified. Moreover, in the author’s native country (Norway), the app has been outselling Angry Birds, which of course is one of the most popular games thusfar.")

#text("Please see Wired’s column GeekDad: ")#link("http://www.wired.com/geekdad/2012/06/dragonbox/all/")[#text("http://www.wired.com/geekdad/2012/06/dragonbox/all/")]

#text("Best,")#linebreak()#text(" Boris")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-236197")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/06/26/gamifying-algebra/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa76c1ecffbda168f10650a0d353648e6012a93c67eee90babd1e8c61c533c6b-b8ca66ae006067deff7f58d42253485ac9faf8c09c384ff40b617ec68094c585.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cindy")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-476701")[#strong[#text("Cindy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Dear Dr. Tao,")#linebreak()#text(" I have played your ‘Algebra Game’, and have mentally completed the levels in game. I wonder if there is a general methodical approach to simplifying linear equations with fixed moves within a limited amount of steps. The closest concepts to this idea is the “Shortest Path Algorithm”, but proves unhelpful to the case. I am unable to even devise a graphical representation of how operations like ‘/3’ or ‘-2’ affects equations like ‘3x +6 = 6x -9’. How do you think these operations can be represented in terms of simplifying single-variable linear equations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gamifying propositional logic: QED, an interactive textbook | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-503385")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("[…] six years ago on this blog, I started thinking about trying to make a web-based game based around high-school algebra, and ended up using Scratch […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/15/gamifying-algebra/#comment-503436")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook - Finance Crypto Community")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2018")]

#text("[…] six years ago on this blog, I started thinking about trying to make a web-based game based around high-school algebra, and ended up using Scratch […]")
]
