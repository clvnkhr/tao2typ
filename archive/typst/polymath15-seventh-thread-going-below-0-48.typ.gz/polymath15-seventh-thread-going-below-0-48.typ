// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/
// Converted to Typst by tao2typ: "2026-10-14T15:20:03.745950+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, seventh thread: going below 0.48", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, seventh thread: going below 0.48")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 March 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/")[#text("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is the seventh “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("The most recent news is that we appear to have completed the verification that ")#mi("{H_t(x+iy)}")#text(" is free of zeroes when ")#mi("{t=0.4}")#text(" and ")#mi("{y \\geq 0.4}")#text(", which implies that ")#mi("{\\Lambda \\leq 0.48}")#text(". For very large ")#mi("{x}")#text(" (for instance when the quantity ")#mi("{N := \\lfloor \\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}} \\rfloor}")#text(" is at least ")#mi("{300}")#text(") this can be done analytically; for medium values of ")#mi("{x}")#text(" (say when ")#mi("{N}")#text(" is between ")#mi("{11}")#text(" and ")#mi("{300}")#text(") this can be done by numerically evaluating a fast approximation ")#mi("{A^{eff} + B^{eff}}")#text(" to ")#mi("{H_t}")#text(" and using the argument principle in a rectangle; and most recently it appears that we can also handle small values of ")#mi("{x}")#text(", in part due to some new, and significantly faster, numerical ways to evaluate ")#mi("{H_t}")#text(" in this range.")

#text("One obvious thing to do now is to experiment with lowering the parameters ")#mi("{t}")#text(" and ")#mi("{y}")#text(" and see what happens. However there are two other potential ways to bound ")#mi("{\\Lambda}")#text(" which may also be numerically feasible. One approach is based on trying to exclude zeroes of ")#mi("{H_t(x+iy)=0}")#text(" in a region of the form ")#mi("{0 \\leq t \\leq t_0}")#text(", ")#mi("{X \\leq x \\leq X+1}")#text(" and ")#mi("{y \\geq y_0}")#text(" for some moderately large ")#mi("{X}")#text(" (this acts as a “barrier” to prevent zeroes from flowing into the region ")#mi("{\\{ 0 \\leq x \\leq X, y \\geq y_0 \\}}")#text(" at time ")#mi("{t_0}")#text(", assuming that they were not already there at time ")#mi("{0}")#text("). This require significantly less numerical verification in the ")#mi("{x}")#text(" aspect, but more numerical verification in the ")#mi("{t}")#text(" aspect, so it is not yet clear whether this is a net win.")

#text("Another, rather different approach, is to study the evolution of statistics such as ")#mi("{S(t) = \\sum_{H_t(x+iy)=0: x,y>0} y e^{-x/X}}")#text(" over time. One has fairly good control on such quantities at time zero, and their time derivative looks somewhat manageable, so one may be able to still have good control on this quantity at later times ")#mi("{t_0>0}")#text(". However for this approach to work, one needs an effective version of the Riemann-von Mangoldt formula for ")#mi("{H_t}")#text(", which at present is only available asymptotically (or at time ")#mi("{t=0}")#text("). This approach may be able to avoid almost all numerical computation, except for numerical verification of the Riemann hypothesis, for which we can appeal to existing literature.")

#text("Participants are also welcome to add any further summaries of the situation in the comments below.")

#heading(level: 1)[#text("Comments (112)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("In the “barrier” approach, is it possible for a non-real zero to flow undetected through the barrier with ")#mi("y")#text(" slightly below ")#mi("y_0")#text(", and then (with ")#tao-math("\\left|x\\right| < X", block: false)#text(") increase (temporarily) somehow its imaginary part ")#mi("y")#text(" slightly above ")#mi("y_0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("No; see Lemma 2 of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")[#text("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")]#text(" . The point is that the only thing that could pull the zero with the highest value of ")#mi("y")#text(" to the left of the barrier back up would be a zero that has an even higher value of ")#mi("y")#text(" on the right of the barrier (or to the left of the reflection of this barrier across the imaginary axis), but this zero, together with its complex conjugate, turns out to exert a net downwards force on the original zero. (Here is where it becomes necessary that the barrier has some nonzero thickness: I used a unit thickness here, though as noted in the web page above one could use a slightly smaller barrier (bounded by a line and a hyperbola).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494960")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("For the barrier approach, can we compute d/dt(H_t) by differentiating within the integral sign? (for example, by using the integrand (u^2)*(H_t integrand), or differentiating the more numerically feasible xi based integrand). Also, with all three t,x,y varying, can we still use contour integration as earlier?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Yes, everything is smooth and the integrals are rapidly decreasing so it should not be a problem to justify differentiation under the integral sign. There is also the heat equation ")#mi("\\partial_t H_t = \\partial_{zz} H_z")#text(" available, though it probably doesn’t change much of anything.")

#text("On the other hand, while ")#mi("H_t(x+iy)")#text(" is holomorphic in ")#mi("x+iy")#text(", it is not holomorphic in say ")#mi("x")#text(" and ")#mi("t")#text(", so the argument principle can only be applied in the ")#mi("x+iy")#text(" variables. Nevertheless Rouche’s theorem is still available. For instance, if we can numerically compute that ")#mi("H_{t_0}(x+iy)")#text(" does not wind around the origin when ")#mi("x+iy")#text(" traverses the boundary of some rectangle ")#mi("R")#text(", and in fact stays a distance ")#mi("\\geq c")#text(" away from the origin, and we also know that ")#tao-math("\\left|\\frac{d}{dt} H_t(x+iy)\\right| \\leq D", block: false)#text(" for all ")#mi("x+iy")#text(" on the boundary of the rectangle and all ")#mi("t_0 \\leq t \\leq t_1")#text(", then this also implies by Rouche’s theorem that ")#mi("H_{t}(x+iy)")#text(" has no zeroes for ")#mi("t_0 \\leq t \\leq t_1")#text(" and ")#mi("x+iy \\in R")#text(" as long as ")#mi("t_1 - t_0 \\leq \\frac{c}{D}")#text(". So one could do a more advanced version of an adaptive mesh in which one advances (or decrements) ")#mi("t")#text(" by an amount depending on how much the contour stayed away from the origin at each time step.")

#text("The main difficulty I foresee is that the bounds on ")#tao-math("\\left|\\frac{d}{dt} H_t(x+iy)\\right|", block: false)#text(" may start deteriorating as ")#mi("t")#text(" approaches zero (mainly because ")#mi("\\sum_n \\frac{1}{n^{\\frac{1+y}{2}}}")#text(" diverges), though ")#mi("H_t(x+iy)")#text(" itself should be reasonably well behaved. As a preliminary exploration we may try taking Newton quotients or evaluate ")#mi("\\frac{d}{dt} H_t(x+iy)")#text(" (or maybe ")#mi("\\frac{d}{dt} (H_t / B_0^{eff})")#text(", or maybe replace ")#mi("H_t")#text(" by ")#mi("A^{eff}+B^{eff}")#text(") at a few points to see what things look like.")

#text("It’s also not clear to me yet what the most efficient choice of ")#mi("X")#text(" should be. Anything in the range ")#mi("N \\geq 300")#text(" should be available (at least if we want to match what we were getting in the toy problem) since we can preclude zeroes of ")#mi("H_{0.4}(x+0.4i)")#text(" beyond this point. Probably we want to take ")#mi("X")#text(" as small as we can, so maybe something like ")#mi("X = 10^6")#text(" to start?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495062")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("I attempted to derive the t derivative of (A+B)/B0 as")#linebreak()#text(" ")#mi("\\displaystyle \\frac{d}{dt} \\frac{A^{eff}+B^{eff}}{B^{eff}_0} = b_{t}^{\\prime} + a_{t}^{\\prime}")#linebreak()#text(" ")#mi("\\displaystyle  b_{t}^{\\prime} = \\frac{1}{4}\\sum_{n=1}^N \\frac{b^{t}_n {(\\log^2 n - 2 \\log(n) \\alpha_1(s_B))}}{n^{s^{\\prime}_B}}")#linebreak()#text(" ")#mi("\\displaystyle  a_{t}^{\\prime} = \\frac{\\lambda}{4}\\sum_{n=1}^N \\frac{b^{t}_n {(\\log^2 n - 2 \\log(n) \\alpha_1(s_A) + \\alpha_1^2(s_A) - \\alpha_1^2(s_B))}}{n^{s^{\\prime}_A}}")#linebreak()#text(" with some simple upper bounds")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|b_{t}^{\\prime}\\right| <= \\frac{1}{4}\\sum_{n=1}^N \\frac{b^{t}_n {\\left|\\log^2 n - 2 \\log(n) \\alpha_1(s_B)\\right|}}{n^{Re(s^{\\prime}_B)}}", block: false)#linebreak()#text(" ")#tao-math("\\displaystyle \\left|a_{t}^{\\prime}\\right| <= \\frac{\\left|\\lambda\\right|}{4}\\sum_{n=1}^N \\frac{b^{t}_n {\\left|\\log^2 n - 2 \\log(n) \\alpha_1(s_A) + \\alpha_1^2(s_A) - \\alpha_1^2(s_B)\\right|}}{n^{Re(s^{\\prime}_A)}}", block: false)

#text("where ")#mi("s^{\\prime}_A := s_A + \\frac{t}{2} \\alpha_1(s_A)")#text(" and ")#mi("s^{\\prime}_B := s_B + \\frac{t}{2} \\alpha_1(s_B)")#text(".")#linebreak()#text(" Also, the derivative was verified with the corresponding newton quotient.")

#text("On running the mesh for each t step with c=0.05, X=10^6 to 10^6 + 1, y=0.4 to 1 and going from t=0.4 to 0, we get the winding number as 0 for each t. The t derivative bound does deteriorate from 11.14 to 154.67 with smaller and smaller t steps near the end, but atleast at this X value, the whole exercise completes pretty fast. For any given t, I used the t derivative bound at the lower left point of the rectangle (for eg. 10^6, 0.4). For a given t, while the bound seems to decrease consistently with y, the same is not clear with X, although for a given ")#mi("y")#text(" it stays relatively constant given the narrow X range. e_(a+b) for t=0,y=0.4,N=300 is around 0.019 and decreases with t, hence c stays above the error bound.")

#text("Also, once the formulas and calculations are confirmed, should we run it for X closer to 10^12 and clear off large ranges of (t,y), or is that a bit ambitious at this point?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("Great! I’ve added this to the wiki. It looks like this zero-free region can be used as a substitute for the existing verifications of ")#mi("H_t(x+iy) \\neq 0")#text(" for ")#mi("x \\leq 10^6")#text(", ")#mi("t = 0.4")#text(", ")#mi("y \\geq 0.4")#text(". The derivative bound for ")#mi("t")#text(" near zero is still manageable at this point, but it should grow like ")#mi("x^{(1-y)/4}")#text(", and the computation of a single value of ")#mi("A^{eff} + B^{eff} / B^{eff}_0")#text(" scales roughly like ")#mi("N \\sim x^{1/2}")#text(", so going to larger ")#mi("x")#text(" such as ")#mi("10^{12}")#text(" could be challenging, particularly if one also attempts to lower y. The main advantage of this approach though is that it allows one to lower ")#mi("t_0")#text(" without much cost. Perhaps to get optimal results one should actually ")#emph[#text("raise")]#text(" y a little bit in order to push x out and to lower ")#mi("t_0")#text(" by enough to compensate for the increase in ")#mi("y")#text(".")

#text("In view of your other data, one could perhaps first try the ")#mi("t_0 = 0.2, y=0.4")#text(" choice of parameters, which would correspond to a rather ambitious ")#mi("\\Lambda \\leq 0.28")#text(". If the Euler mollifier can handle the range ")#mi("N \\geq 18000")#text(" that corresponds to something like ")#mi("X \\sim 10^9")#text(" and this could potentially be within the range of feasibility for the second approach. If it doesn’t work out one can try increasing ")#mi("y")#text(", e.g. ")#mi("t_0=0.2, y = 0.5")#text(" which would give ")#mi("\\Lambda \\leq 0.325")#text(" and would also allow us to move ")#mi("X")#text(" down a bit.")

#text("Also, after double checking with the most recent numerical verification of RH (due to ")#link("http://www.ams.org/journals/mcom/2017-86-307/S0025-5718-2017-03198-7/")[#text("Platt")]#text("), it seems the ")#mi("X")#text(" parameter will in fact be limited to about ")#mi("6.1 \\times 10^{10}")#text(" (roughly ")#mi("N \\approx 70,000")#text(") at best, so extending to ")#mi("10^{12}")#text(" is moot anyway (unless we want to convert this project into a numerical RH verification project…).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495070")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("These are some non-optimal (t,y,N) sets (with y gte 0.3) for which the euler5 mollifier+lemma bound was found positive.")

#text("t, y, N")#linebreak()#text(" 0.3, 0.3, 2000")#linebreak()#text(" 0.25, 0.3, 6500")#linebreak()#text(" 0.2, 0.4, 18000")#linebreak()#text(" 0.2, 0.3, 50000 (x ~ 31.5 billion)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495074")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("Thanks. I will start working on this.")

#text("In an attempt to write neater formulas, I made a few more typos. ")#mi("s_{A}")#text(" and ")#mi("s_{B}")#text(" in the numerators and denominators are different. For minimal change, the denominator ones could be written as ")#mi("s_{A}^{\\prime}")#text(" and ")#mi("s_{B}^{\\prime}")#text(" (with ")#mi("s_{A} = 1 - s_{B}")#text(" and ")#mi("s_{A}^{\\prime} = s_{A} + (t/2) \\alpha_1(s_A)")#text(" and ")#mi("s_{B}^{\\prime} = s_{B} + (t/2) \\alpha_1(s_B)")#text(") ")#emph[#text("[Corrected, thanks – T.]")]

#text("Also, while RH verification is a major project on its own, I was discussing with Rudolph earlier in the day that the barrier method, by creating a link between the verified height of zeta zeroes and the dbn bound would allow such a future project to lower the bound further (and also hopefully tighten the density estimates of the off-critical line zeta zeroes which would be a major motivation to do it, but the latter has been asked earlier by other commenters in different forms and probably is quite difficult to formalize).")

#text("I had referred to the 10^12 number due to Gourdon et al (although it’s not clear whether the large heights in their work were independently verified).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495075")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("Gourdon-Demichel claim to have verified RH for the first ")#mi("10^{13}")#text(" zeroes. Using the Riemann-von Mangoldt formula ")#mi("N \\approx \\frac{x}{4\\pi} \\log \\frac{x}{4\\pi} - \\frac{x}{4\\pi}")#text(" this suggests that ")#mi("x")#text(" can get up to about ")#mi("4.95 \\times 10^{11}")#text(" if one accepts the Gourdon-Demichel numerics. In any case I see your point that it can be worthwhile to obtain some results that is conditional on a numerical RH verification that could be feasible in the future even if it is not currently available. (e.g. “We can prove ")#mi("\\Lambda \\leq 0.26")#text(", but can improve this to ")#mi("\\Lambda \\leq 0.22")#text(" if the first ")#mi("10^{14}")#text(" zeroes of zeta obey RH”, etc..).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495082")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("In “On running the mesh for each t step with c=0.05” what does c=0.05 mean? What is c and why is it 0.05?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495098")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("At each time step, the rectangle (X,X+1,y0,1) is traversed using an adaptive mesh, and the c parameter is used to to ensure f=|a+b| does not go below c between the mesh points (the 0.05 value is arbitrary, but c should not exceed the expected min |f(z)|, otherwise the mesh will get stuck at a certain point) Now there is also a lower bound of |f(z_(i+1)|/2 if we choose c=0, so having a non-zero value may not be necessary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495147")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("One of the numerics participants had asked yesterday whether the t derivative bound estimated using the triangle inequality at the lower coordinates (X,y0,t0) has monotonicity properties for X,y,t and is good enough to act as a substitute for D, while jumping to t1 = t0 + c’/D. Here we are using c’ as (c + min|a+b|_t0_mesh)/2")#linebreak()#text(" From observations it seems that the bound decreases as t and y increase, and if we approximate the terms, we get a toy model like formula")#linebreak()#text(" ")#tao-math("\\sum_{n=1}^N \\frac {\\log(n) \\log(N^2/n)}{4} (\\frac{1}{n^{\\frac{1+y}{2} + (t/4)\\log(N^2/n)}} + \\frac {\\left|\\lambda\\right|}{n^{\\frac{1-y}{2} + (t/4)\\log(N^2/n)}})", block: false)#linebreak()#text(" whose values stay close (but not at the level of decimal points) to the exact bound. It does indicate the desired properties for atleast t and y. So we wanted to confirm that the bound calculated earlier is usable for the mesh calculations.")

#text("Also, we started with X=5*10^9+(0,1), y=(0.4,1), t=(0,0.2), moving forward in time t, and while it is somewhat slow, it is looking doable, and the computations get faster with time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("It might be possible to rigorously prove that the derivative bound is indeed monotone, but even if this isn’t easily done, I think it is close enough to being provably monotone that it will probably be safe to use the derivative bound at the lower values of ")#mi("x,y,t")#text(", plus some safety margin, as the derivative for higher values of ")#mi("x, y, t")#text(" (keeping ")#mi("N")#text(" fixed of course). The main difficulty compared with the toy model is understanding the behaviour of the quantity ")#mi("\\alpha(s)")#text(", however the derivative of ")#mi("\\alpha")#text(" is quite small (of the order of ")#mi("1/x")#text(") and so one should be able to approximate its behaviour by a constant (e.g. by the value of ")#mi("\\alpha")#text(" at the lower values of ")#mi("x,y")#text(") with only a small error incurred. Once ")#mi("\\alpha")#text(" is replaced by a constant, it looks like one will get the desired monotonicity properties.")

#text("If one is able to evaluate ")#mi("H_t")#text(" for ")#mi("x")#text(" comparable to the limits of numerical RH verification then there is probably no need right now to develop the potential third approach (based on trying to control sums like ")#mi("\\sum y_j e^{-x_j/X}")#text(") since at best this approach will also be limited by the same requirement to have numerics for RH.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495321")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("We ran the mesh for X=5*10^9 (N=19947), y0=0.4, t=0.2 and the winding number came out to be zero for each rectangle. The ddt bound used was the same as derived earlier. p15 or Anonymous likely completed it a few days back with a much faster script, and has also shared the script in another comment.")

#text("The winding number summary for the different t values is ")#link("https://drive.google.com/file/d/1XO5G8qksOBAVqV5mn2r7HJ0VguKln3o6/view")[#text("here")]#text(" and the detailed output of all the rectangles is ")#link("https://drive.google.com/file/d/1XrMEntj7qz9BSJuJduChnTL1v2umzbkq/view")[#text("here")]#text(".")

#text("The large x formula in the wiki gives an estimate ~0.0555 at N=300000, y=0.4, t=0.2. Should we run the Euler mollifier bound between N=19947 and 300k?")

#text("Also, can we use a mollifier to lower the ddt bound (which would then provide a safety margin in this case)? I tried")#linebreak()#text(" ")#mi("\\lambda_1=1, \\lambda_2 = -exp{((t/4) log^2 2)}")#linebreak()#text(" and new_ddt_bound = mollified_ddt_bound/|mollifier|")#linebreak()#text(" which seems to result in a lower ddt bound for any x,y,t in the strip we have considered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495330")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("Thanks for this! I’ve added these announcements to the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Zero-free_regions")[#text("zero free regions page")]#text(" on the wiki. I assume for the winding number calculations that the upper range of ")#mi("y")#text(" is ")#mi("1")#text("?")

#text("If the Euler mollifier bound is feasible in the indicated range then it is certainly worth running, though this is about four orders of magnitude larger a range of x values which is a bit worrisome (but one should presumably be able to get some cutdown by improving the large x calculations, e.g. by using mollifiers; I did not seriously try to optimise those calculations as they seemed to be more than adequate back in the t=0.4, y=0.4 test problem). If it isn’t, one can raise y a little bit in this range at the expense of slightly worsening the bound on ")#mi("\\Lambda")#text(": the barrier you just constructed at ")#mi("X = 5\\times 10^9, y_0 = 0.4, t = 0.2")#text(" automatically works for any larger value of ")#mi("y")#text(" without any further computation. (One also gets to lower t for free here, but this of course will make the large x calculations harder.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495351")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("We had used the upper range of y as 1, although Rudolph had midway suggested based on the old result that y_max=sqrt(1-2t)+small epsilon could also be used, which we can do for future computations.")

#text("Also just wanted to mention that the mesh calculations were difficult and everyone contributed to optimizing and completing them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("OK, thanks! If you have a list of contributors I can update the attributions on the zero free regions page accordingly (or if one of you has an account on the wiki you can do it directly).")

#text("To get a crude idea of how far one may be able to push the large x analysis, let us return to the toy model approximation ")#mi("A^{toy}+B^{toy} / B^{toy}_0")#text(" and consider the question of when this is provably nonzero. The triangle inequality lower bound for this quantity is")

#mi("2 - \\sum_{n=1}^N \\frac{1}{n^{(1+y)/2 + t \\log \\frac{N^2}{n}}} - N^{-y} \\sum_{n=1}^N \\frac{1}{n^{(1-y)/2 + t \\log \\frac{N^2}{n}}}")

#text("so one has a chance of doing something as long as")

#mi("\\sum_{n=1}^N \\frac{1}{n^{(1+y)/2 + t \\log \\frac{N^2}{n}}} + N^{-y} \\sum_{n=1}^N \\frac{1}{n^{(1-y)/2 + t \\log \\frac{N^2}{n}}} < 2.")

#text("It looks to me like this is actually the case at ")#mi("N = 19947")#text(" with quite a bit of room to spare (I get 1.076122 for the LHS), so one should be able to analytically verify this for larger N too (I had some tools for doing this at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum")[#text("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum")]#text(" , basically evaluate a bounded number of terms numerically and then estimate the tail analytically).")

#text("For ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" (in the regime ")#mi("y \\geq 1/3")#text(", which is the case here) the corresponding triangle lower bound is")

#mi("2 - \\sum_{n=1}^N \\frac{1}{n^{(1+y)/2 + t \\log \\frac{N^2}{n}}} - \\exp( \\delta + \\frac{t \\log N}{2(x_N-6)} ) N^{-y} \\sum_{n=1}^N \\frac{1}{n^{(1-y)/2 + t \\log \\frac{N^2}{n}}}")

#text("where ")#mi("x_N = 4\\pi N^2 - \\frac{\\pi t}{4}")#text(" and ")#mi("\\delta")#text(" is a moderately complicated quantity defined in equation (1) of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Large_.5Bmath.5Dx.5B.2Fmath.5D_case")[#text("http://michaelnielsen.org/polymath1/index.php?title=Controlling_A%2BB/B_0#Large_.5Bmath.5Dx.5B.2Fmath.5D_case")]#text(" but it looks like things are also good here (")#mi("\\delta")#text(" should decay like ")#mi("1/N^2")#text("). I haven't computed the E_1, E_2, E_3 errors but with N so large I would expect them to be quite small. So I think we may soon be able to clear all of the region ")#mi("N \\geq 19947, y \\geq 0.4, t = 0.2")#text(", which would give ")#mi("\\Lambda \\leq 0.2 + \\frac{1}{2} 0.4^2 = 0.28")#text(" without any further mesh evaluations! I might have some time this afternoon to write this out properly, hopefully in a form in which it will be clear how to adjust all the numerical parameters if needed.")

#text("p.s. regarding lowering y_max to ")#mi("\\sqrt{1-2t}")#text(", this will probably only be a modest saving since the main difficulty arises at t near 0, and also the derivative analysis gets a bit more complicated if the contour varies in time. It turns out that for related reasons one can narrow the thickness ")#mi("X \\leq x \\leq X+1")#text(" of the barrier a little bit to ")#mi("X \\leq x \\leq X + \\sqrt{1-y_0^2}")#text(" and even ")#mi("X \\leq x \\leq X + \\sqrt{1-y^2-2t}")#text(" but again this would be a rather modest savings and perhaps not really worth the additional conceptual and coding complexity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("Oops, I made a numerically significant typo: the factor of ")#mi("t \\log \\frac{N^2}{n}")#text(" should be ")#mi("\\frac{t}{4} \\log \\frac{N^2}{n}")#text(", and the sum is now a lot worse at the t=0.2 level, the LHS that needs to be less than 2 is now 3.135 or so at N = 19947. (I guess I should have been more suspicious that the sum was so small!) So we are not close to knocking out the entire ")#mi("N \\geq 19947")#text(" region just from the triangle inequality (even in the case of the toy approximation); it looks like N has to be something like 10 times larger, roughly matching what you had previously worked out. One may be able to get a bit further (as before) using Euler mollifiers and also the Dirichlet series lemma, but it does look like there will have to be a region that is covered by a numerical mesh.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495400")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2018")])]

#text("Is the t factor in the denominator actually t/4. With that, the estimate increases to 3.129.")

#text("Also, the wiki seems to have a login but not a create account facility. Rudolph and David are the other two contributors.")

#text("Additionally, Anonymous’s script is likely fast enough that it’s possible to run the mesh (t=0.2,y=0.3,appropriate X) in reasonable time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495464")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2018")])]

#text("Thanks for pointing this out (I independently figured this out it seems, judging by the near-simultaneous comments).")

#text("Michael Nielsen locked down account creation on the wiki because of spam issues. You can contact him at ")#link("mailto:mn@michaelnielsen.org")[#text("mn@michaelnielsen.org")]#text(" to request an account. In any event I have added the attributions.")

#text("One thing that may be relatively quick to execute is to create a table of the minimal N, for given values of t,y, for which the toy criterion")

#mi("\\sum_{n=1}^N \\frac{1 + (n/N)^y}{n^{\\frac{1+y}{2} + \\frac{t}{4} \\log \\frac{N^2}{n}}} < 2")

#text("holds (assuming for now that the sum is decreasing in N, as it appears to be numerically). One can then invert this table to find, for a given value of N, what the optimal value of ")#mi("t + \\frac{1}{2} y^2")#text(" would be, which would indicate roughly what we could expect to reach as a bound for ")#mi("\\Lambda")#text(" for say ")#mi("N = 19947")#text(" without any further work. Then we could run the same exercise with some Euler mollifiers and see if there is significant improvement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2018")])]

#text("For t=0.29 and y=0.29 I get t + (1/2)*y^2 = 0.33205 < 1/3 and the sum for the toy criterion with N=19947 is 1.99378 < 2. This is the best in a grid search with step size 0.01. The t and y were not constrained to be equal, it just turned out that way if I didn't make a mistake.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2018")])]

#text("Thanks for this! The fact that ")#mi("y < 1/3")#text(" should not be an issue, it contributes an additional error term in a number of estimates which will be very small for ")#mi("N")#text(" as large as ")#mi("19947")#text(" (the additional error is roughly of size ")#mi("O( \\log N / N^4 )")#text("). It’s likely all the remaining error terms (which are all of size ")#mi("O( 1/N )")#text(" or better) can fit inside the gap between 1.99378 and 2.")

#text("On the other hand, the barrier computations may become significantly harder with y reduced from 0.4 to 0.29, so it's not completely clear that we could get all the way down to 0.33205 this way. But it should be relatively easy to continue the barrier at ")#mi("y=0.4")#text(" up to time ")#mi("t=0.29")#text(" (the barrier calculations get faster as t moves away from zero) so we should have ")#mi("0.29 + \\frac{1}{2} 0.4^2 = 0.37")#text(" fairly cheaply this way, at least.")

#text("Given that we have some additional techniques (Euler mollifiers, mesh evaluations of A+B) to clear the region to the right of the barrier, probably the bottleneck is now how low one can lower the value of y in the barrier calculations. (One could also increase X a bit, since we're not quite at the threshold of the best RH verification in the literature, but I believe this would only lead to relatively modest gains and probably also make the barrier computations harder.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2018")])]

#text("Some of the bounds need y >= 1/3, and y=0.29 is not in that regime.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495580")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2018")])]

#text("The Euler 3 mollifier with triangle inequality is positive (0.044) at N=19900,y=0.4,t=0.2")

#text("Similarly, the Euler 2 mollifier with triangle inequality is positive (0.056) at N=40000,y=0.4,t=0.2")

#text("If as in the Estimating a sum wiki, we fix N0=40000, that leaves the corresponding buffer for the tail sum (estimated from D*N0 +1 to D*N). Estimating the B and A parts of the tail sum numerically for different N values using a bisection method, it seems the B tail is less than 0.019 and the A tail (including the N^y denominator) is less than 0.017. There is a tradeoff as the summands decrease with increasing N, but the number of terms in the sum increase. The maximum is reached differently for the B and A tails near N=150k.")

#text("Is it possible to use two integrals here to bound the tail analytically? The alternate summand sequences seem to be decreasing, with the odd sequence similar to earlier. The even summand is a product of an increasing and decreasing term, hence it’s not clear how to prove its trend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2018")])]

#text("The Euler 3 data is very promising, it brings us very close to getting ")#mi("\\Lambda \\leq 0.2 + \\frac{1}{2} 0.4^2 = 0.28")#text(" when combined with the barrier. How fast is it to compute the Euler 3 bound for a given value of N? If we can use it to clear, say, the region ")#mi("19900 \\leq N \\leq 2 \\times 10^6")#text(", then we only need to do analysis past ")#mi("N \\geq 2 \\times 10^6")#text(", and here the ordinary triangle inequality bound seems to work, thus avoiding the need to work out what the Euler 3 tails look like. One could also imagine splitting the range ")#mi("19900 \\leq N \\leq 2 \\times 10^6")#text(" and using Euler 3 for the lower part (e.g. ")#mi("19900 \\leq N \\leq 40000")#text(") and the (presumably faster) Euler 2 bound for the upper part.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495596")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2018")])]

#text("I tried to derive formulas for some parts of the Euler 2 mollifier based tail using the wiki approach, assuming N>2N_0.")

#mi("\\textrm{For non zero odd terms } (2N_0+1 \\textrm{ to } N)")#linebreak()#text(" ")#mi("\\frac{1}{2} \\max ((2N_0+1)^{1-\\sigma-\\frac{t}{4}\\log\\frac{N^2}{2N_0+1}}, N^{1-\\sigma-\\frac{t}{4}\\log(N)}) \\log\\frac{N}{2N_0+1}")

#mi("\\textrm{For non zero } n > N \\textrm{ even terms in the B sum } (N \\textrm{ to } 2N)")#linebreak()#text(" ")#mi("\\frac{2^{\\frac{t}{2}\\log2}}{2} \\max (N^{1-\\sigma-\\frac{t}{2}\\log2-\\frac{t}{4}\\log N}, (2N)^{1-\\sigma-\\frac{t}{2}\\log2-\\frac{t}{4}\\log\\frac{N}{2}}) \\log 2")

#mi("\\textrm{For non zero } n > N \\textrm{ even terms in the A sum } (N \\textrm{ to } 2N)")#linebreak()#text(" ")#mi("\\frac{2^{\\frac{t}{2}\\log2}}{2^{1+y}} \\max (N^{1-\\sigma-\\frac{t}{2}\\log2-\\frac{t}{4}\\log N}, (2N)^{1-\\sigma-\\frac{t}{2}\\log2-\\frac{t}{4}\\log\\frac{N}{2}}) \\log 2")

#text("The even terms with n < N look more difficult.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495628")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2018")])]

#text("The E3 mollifier currently takes 6 to 12 seconds for each N (20k to 40k), while the E2 mollifier takes around 2 to 10 seconds (40k to 2*10^5).")#linebreak()#text(" At 2*10^6, the E2 mollifier takes around a couple of minutes.")

#text("It should be possible to makes this 2-3X faster through some simple means, and probably it can go much faster if done in a faster library.")

#text("Also wanted to confirm on the 2*10^6 part, since the non-mollified bound including the tail seems to turn positive in the lower 10^5 magnitude (with N_0 of a similar magnitude).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495633")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2018")])]

#text("Sorry, that was a typo, I meant ")#mi("2 \\times 10^5")#text(". So it looks like we can use E2 and E3 to cover the ")#mi("19900 \\leq N \\leq 2 \\times 10^5")#text(" region in a somewhat reasonable amount of time (less than a month, presumably less with some speedup). One potential way to speed things up is to do something like a mesh, e.g. only compute the bounds for N a multiple of 10, and get some upper bound on how the bound changes when one moves from N to N+1 (basically, differentiate each summand in N, add up bounds for each that are uniform in the interval [N,N+1], and add the additional N+1^th term). In any event even a crude mesh (e.g. spacings of 100) should give the right picture as to how much room there is to insert all the error terms (but I expect that with N this large, all the error terms are going to be well below dangerous levels).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495707")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("Thanks. We will start working on this.")

#text("Also, few days back I had tried deriving an N dependent ddt bound as a replacement for the x dependent one. The derivation is kept ")#link("https://github.com/km-git-acc/dbn_upper_bound/files/1887072/ddt_improved_Nbound_derivation.pdf")[#text("here")]#text(". After checking it for many different values of N,y,t (with N large), it seems to be around 1.2X of the x dependent bound, and we kind of hit a wall. Does the derivation seem correct and is it possible to improve the bound further using this approach?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495725")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("The denominator lower bounds aren’t quite right, you need to lower bound ")#mi("\\mathrm{Re} \\alpha_1(s)")#text(", and this is not necessarily bounded from below by ")#mi("\\alpha_L")#text(", though the value of ")#tao-math("\\frac{1}{2} \\log \\frac{\\left|1-y+ix_N\\right|}{4\\pi}", block: false)#text(" comes quite close to being a lower bound here. For ")#mi("\\alpha_U")#text(", you can do slightly better by using Pythagoras theorem ")#tao-math("\\left|a+ib\\right| = \\sqrt{a^2+b^2}", block: false)#text(" rather than the triangle inequality bound ")#tao-math("\\left|a+ib\\right| \\leq \\left|a\\right|+\\left|b\\right|", block: false)#text(", getting something like ")#tao-math("\\frac{3}{2x_N} + \\sqrt{ \\frac{\\pi^2}{16} + \\frac{1}{4} \\log^2 \\frac{\\left|1+y+ix_{N+1}\\right|}{4\\pi}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495780")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("Thanks. I think in the denominator I had used ")#tao-math("\\left|\\alpha_{1}(s)\\right|", block: false)#text(" as a proxy for ")#mi("\\Re(\\alpha_{1}(s))")#text(" Is the issue with ")#mi("\\alpha_L")#text(" that ")#mi("\\Re(\\frac{1}{2s} + \\frac{1}{s-1})")#text(" can be negative and should be accounted for? I tried estimating a lower bound for this term as well.")

#mi("\\textrm{For } s=\\frac{1-y+ix}{2}")#linebreak()#text(" ")#mi("\\Re(\\frac{1}{2s} + \\frac{1}{s-1})")#linebreak()#text(" ")#mi("= (\\frac{1-y}{(1-y)^2 + x^2} - \\frac{2(1+y)}{(1+y)^2+x^2}) >= \\frac{(1-y)-2(1+y)}{(1+y)^2 + x^2}")#linebreak()#text(" ")#mi("= -\\frac{1+3y}{(1+y)^2 + x^2} >= -\\frac{1+3y}{(1+y)^2 + x_{N}^2}")

#mi("\\textrm{For } s=\\frac{1+y-ix}{2}")#linebreak()#text(" ")#mi("\\Re(\\frac{1}{2s} + \\frac{1}{s-1})")#linebreak()#text(" ")#mi("= (\\frac{1+y}{(1+y)^2 + x^2} - \\frac{2(1-y)}{(1-y)^2+x^2})")#linebreak()#text(" ")#mi("\\textrm{This is } >= -\\frac{1+3y}{(1+y)^2 + x^2} \\textrm{ if}")#linebreak()#text(" ")#mi("\\frac{2(1-y)}{(1-y)^2 + x^2} <= \\frac{2+4y}{(1+y)^2+x^2}")#linebreak()#text(" ")#mi("\\textrm{or } \\frac{1-y}{1+2y} <= \\frac{(1-y)^2 + x^2}{(1+y)^2+x^2}")#linebreak()#text(" ")#mi("\\frac{(1-y)^2 + x^2}{(1+y)^2+x^2} >= \\frac{x^2}{x^2+2} \\textrm{ and } \\frac{1-y}{1+2y} \\textrm{ is monotone decreasing in y}")#linebreak()#text(" ")#mi("\\frac{1-y}{1+2y} <= \\frac{x^2}{x^2+2} \\textrm{ holds for } (y >= 0.4,x >= 1),(y >= 0.1,x >= 3),\\textrm{ and so on}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("Yes, this was the issue, though the effect of this term on the derivative bounds should be very small, especially in the most dangerous region when t is close to 0.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494939")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("It just occurred to me that counting the zeroes on the real line may be easier. Zeroes don’t just suddenly appear or disappear, so track a zero, r, at the edge of the boundary, then count the number of zeroes on the real line between z=0 and z=r’. If the number of zeroes is the same, the de Bruijn-Newman can be lowered.")#linebreak()#text(" If this plan would not work, I would like to know why. Calculating along the real line rather than a rectangular chunk of the complex plane just seems easier.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494950")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Unfortunately, the potential problem is that even if the real zeroes are completely frozen in time, one or more pairs of complex zeroes could fly in at high speed from horizontal infinity, passing above a large number of the real zeroes, potentially leading to a zero ")#mi("H_t(x+iy)=0")#text(" for a large value of ")#mi("t")#text(" (e.g. t = 0.4) with a large value of y (e.g. y=0.4), while still being consistent with the ability to preclude such zeroes for large values of x.")

#text("A key difference here between the real and complex numbers is that the real numbers are totally ordered, so that zeroes cannot move past each other without colliding, whereas complex numbers are unordered, and zeroes can move past each other in complicated ways.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494965")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Can checking the absence of zeroes of ")#mi("H_{t}")#text(" for ")#mi("0 < t  y_{0}")#text(" be reduced to checking for only finitely many values of ")#mi("t")#text(" ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("It would be nice to include in the main page (as done e.g. in polymath8) an updates table of ")#mi("\\Lambda")#text(" upper bounds records.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("I think what might work is to have a table of known zero-free regions for the equation ")#mi("H_t(x+iy)=0")#text(", e.g. ")#mi("t=0.4, 30 \\leq x \\leq 100, 0.4 \\leq y \\leq 0.45")#text(", and keep a separate column for the optimal value of ")#mi("\\Lambda")#text(" that can be deduced from all of these zero-free regions. I might work on such a table later today.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("The table is now in place at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Zero-free_regions")[#text("http://michaelnielsen.org/polymath1/index.php?title=Zero-free_regions")]#text(" . Hopefully I have the attributions and dates correct. Any corrections welcome (Actually everyone is welcome to create an account on the wiki to edit the wiki directly also.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("It is still not sufficiently clear from this table how the sides of the whole rectangle (")#mi("0 \\le N \\le 2000")#text(" and ")#mi("0.4 \\le y \\le 0.45")#text(") where tested by the argument principle to show it to be ")#mi("H_t")#text(" zero-free for ")#mi("t = 0.4")#text(" (in particular, it seems that the horizontal interval ")#mi("300 \\le N \\le 2000")#text(" for ")#mi("y =0.45")#text(" is missing from the table, as well as the right vertical side with ")#mi("N=2000")#text(" of the whole rectangle.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494972")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("For the region ")#mi("300 \\leq N \\leq 2000, 0.4 \\leq y \\leq 0.45")#text(" we don’t need the argument principle and can establish non-vanishing of ")#mi("H_t(x+iy)")#text(" directly as follows. Here what one does is obtain lower bounds on ")#tao-math("\\left|A^{eff}+B^{eff}/B^{eff}_0(x+iy)\\right|", block: false)#text(" and upper bounds on the error ")#tao-math("\\left|H_t-A^{eff}-B^{eff}/B^{eff}_0(x+iy)\\right|", block: false)#text(". The former had already been lower bounded for ")#mi("y=0.4")#text(" using Euler product mollifiers and variants of the triangle inequality in the ")#mi("y=0.4")#text(" case, but one nice feature of these arguments is that the bounds always improve as ")#mi("y")#text(" increases, so the lower bounds extend automatically to ")#mi("0.4 \\leq y \\leq 0.45")#text(". Now, on the other hand, the upper bounds on the error degrade slightly as ")#mi("y")#text(" increases (in particular there is an annoying ")#mi("9^\\sigma = 9^{(1+y)/2}")#text(" factor in the main error term ")#mi("E_3")#text(", see e.g. Proposition 5.3 of the ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("writeup")]#text("), but I think there is enough room (particularly with recent slight improvements to this error term) to accommodate this loss.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494977")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("Despite the 3^y factor, the error bounds seem to decrease as y increases. The [T’/(2*Pi)]^[-(1/4)*(1+y)] factor exerts more influence even at low values of N. For example, |h-(a+b)| error bound for some (N,y) pairs:")#linebreak()#text(" N, with y=0.4, with y=0.45")#linebreak()#text(" 3, 0.932, 0.917")#linebreak()#text(" 10, 0.154, 0.147")#linebreak()#text(" 50, 0.0148, 0.0135")

#text("Also, with t=0.4, y=0.3, the euler5 mollifier with the lemma bound (as in the wiki, maybe slightly different from the paper) gives a positive lower bound for |a+b| at N=319 (compared to N=192 with t=0.4, y=0.4). Earlier we had run the mesh upto N=300, but since the error bound is quite low by this point, and even a slight increase in N helps |a+b| stay above it, is it fine to run the mesh for y=0.3 upto N=350?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("Ah, good point! The error term ")#mi("E_3")#text(" degrades relative to ")#mi("C^{eff}")#text(" as ")#mi("y")#text(" increases, but improves relative to ")#mi("B^{eff}_0")#text(" due to the ")#mi("(T^{\\prime}/2\\pi)^{-(1+y)/4}")#text(" factor. Conversely, it means that it will cause more trouble as we lower y.")

#text("Certainly there’s nothing particularly special about 300, if it looks like mesh evaluations of ")#mi("A^{eff} + B^{eff}")#text(" can be stretched up to 350 for instance then we can shift the transition point to using Euler product mollifiers etc. to later. I think that the low x calculations should be fairly insensitive (as far as run time and accuracy go) with the values of ")#mi("t")#text(" and ")#mi("y")#text(", so hopefully we should always be able to cover the region ")#mi("N \\leq 300")#text(" (or ")#mi("N \\leq 350")#text(") numerically. (There are some factors of ")#mi("\\frac{1}{t^{3/2}}")#text(" in some of the derivative bounds, but as long as we don’t send t to be very small, I don’t think this will hurt us that much, e.g. one should still be OK for say t=0.2, and I doubt we want to go much below that in any case unless we are trying the second approach (based on barriers) to getting zero free regions.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494943")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("It seems somewhat easier to start with lowering ")#mi("y_0")#text(" below ")#mi("0.4")#text(" while keeping ")#mi("t = 0.4")#text(". A good start seems to be ")#mi("y_0 = 0.3")#text(" (which should give ")#mi("\\Lambda \\leq 0.4 + 0.3^2 / 2 = 0.445")#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494958")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("One minor observation is that by keeping ")#mi("t=0.4")#text(" fixed, one can reuse some of the previous calculations, for instance the ")#mi("y=0.45")#text(" data can be reused without any modification.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495065")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("Using the 3rd approach integral, a clockwise run around the rectangle ")#mi("x=0 \\dots 3000, y=0.4 \\dots 0.45")#text(" for ")#mi("t=0.4")#text(" confirms and stretches Anonymous’ earlier result that ")#mi("H_t")#text(" does not vanish in this region. It ran for roughly 8 hours. Please find the output below.")

#link("https://drive.google.com/open?id=1LLAO38N97QLxqmb82LhNBSgJiUaVZ7UN")[#text("Run x=0..3000 y=0.4..045 t=0.4")]

#emph[#text("[Added to wiki, thanks! – T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5869d8b1448ca10fca0bd94d7cbc089633423849ab93255b0123f887992ce41a-6ba6395656430792a6ea6ae7d9ac3e6b5677fa135c4d519e4810981160304521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Dear Prof. Tao, I am not sure if there is a typo in the last inequality about S(t).")

#link("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")[#text("http://michaelnielsen.org/polymath1/index.php?title=Dynamics_of_zeros")]

#text("According to Groenwall’s inequality, the function S(t) should be bounded by S(0), while in the wiki page it is bounded by S(t) itself.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494973")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("One relatively easy numerical exploration that we can do is to get some sense of the ranges of ")#mi("t, x, y")#text(" for which the quantity ")#mi("A^{eff}+B^{eff} / B^{eff}_0")#text(" stays reasonably close to 1 (enough so that we have a chance of verifying that it does not wind around the origin). In the ")#mi("t=0.4, y=0.4")#text(" case it seems that this happens all the way down to quite low values of ")#mi("x")#text(" (e.g. ")#mi("N \\geq 10")#text(", or ")#mi("x \\geq 1250")#text("), and we had already seen that increasing ")#mi("y")#text(" tightens the clustering (see e.g., ")#link("https://drive.google.com/file/d/1akQn7JrgX17rqPNbrfLfeKge4uFV5_Uf/view")[#text("this plot of KM’s")]#text(", with the orange dots being the ")#mi("y=0.45")#text(" values of ")#mi("A+B/B_0")#text(" and the green dots being the ")#mi("y=0.4")#text("). Conversely, as we lower t and y (or go to smaller values of x) we will get more of a spread and eventually we will lose control of the winding number. Perhaps for various values of (t,y) we could numerically locate ranges of x (or of N) for which a coarse mesh evaluation ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" behaves well enough that we have a hope of working out the winding number? (One of course also has to deal with the error terms, but the bounds we have on these terms do not get much worse as we decrease t,y, in fact they might actually improve slightly in some cases.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-494974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("It seems that the analytic threshold ")#mi("N=2000")#text(" (which is related to the analytic threshold ")#mi("e^{C/t}")#text(") should be quite sensitive to changes in ")#mi("t")#text(" (in particular for small ")#mi("t")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("Does ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")]#text(" provide bounds of the derivative of Ht that apply to intervals of x? There might be blog comments or github comments about how it’s trivial to do with the triangle inequality, but it would be helpful to me to see it on the wiki.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("The dependence of bounds on ")#tao-math("\\left|E\\right|", block: false)#text(" and ")#tao-math("\\left|E^{\\prime}\\right|", block: false)#text(" on ")#mi("x")#text(" as given in the wiki is quite simple, so one can just use monotonicity. For instance, if ")#mi("x")#text(" ranges in the interval ")#mi("[x_1,x_2]")#text(", then ")#tao-math("\\left|T-x/2\\right|", block: false)#text(" will not exceed ")#tao-math("\\max( \\left|T-x_1/2\\right|, \\left|T-x_2/2\\right|)", block: false)#text(", so one can use that to upper bound ")#tao-math("\\left|T-x/2\\right|", block: false)#text(" to obtain bounds for ")#tao-math("\\left|E\\right|, \\left|E^{\\prime}\\right|", block: false)#text(" that are uniform in that interval.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("Suppose that ")#mi("H_t(X+i y) \\neq 0")#text(" (with some fixed (large) ")#mi("X > 0")#text(") for any ")#mi("y \\ge y_0")#text(" (with some fixed ")#mi("y_0 > 0")#text(") and any ")#mi("t  \\ge 0")#text(". Is this “zero width barrier” sufficient to show that if ")#mi("H_0")#text(" is zero-free in the region ")#mi("0 \\le x \\le X, y \\ge y_0")#text(" so is ")#mi("H_t")#text(" for any ")#mi("t > 0")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495073")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("I don’t know how to achieve this, because i need a thick barrier to prevent a zero sneaking under the barrier and then being pulled upwards by the attractive force of a higher up zero to the right of the barrier. This is a very implausible scenario, but not one I know how to rule out with a zero thickness barrier. On the other hand, by the argument principle, verifying that a two-dimensional region is zero-free is actually not that much harder than verifying a one-dimensional region.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495133")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("If we wanted a name for the functions ")#mi("H_{t}")#text(" , one possibility would be to refer to these as the “de Bruijn-Newman family of functions ")#mi("H_{t}")#text("“, or the “de Bruijn-Newman functions ")#mi("H_{t}")#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("Does this function already have some combination of names, identifiers, symbols, characters, data, or conductors or whatever in ")#link("http://www.lmfdb.org/")[#text("http://www.lmfdb.org/")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495137")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("I doubt these parameterized functions are “real” L-functions. Unless I’m mistaken, ")#mi("H_{-0.1}")#text(" should have non-real zeroes.")#linebreak()#text(" Prof. Tao searched the literature for the origin of the ")#mi("H")#text(" designation, please see his comment here ")#link("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494089")[#text("https://terrytao.wordpress.com/2018/03/18/polymath15-sixth-thread-the-test-problem-and-beyond/#comment-494089")]#text(" .")#linebreak()#text(" Perhaps Csordas, Varga et al deserve some credit too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495138")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("Let’s use the distinguished naming procedure that led to coining “tropical geometry.” Begin by a identifying a person prominently associated with the concept. For tropical geometry it was Imre Simon. In our case we have Nicolaas Govert de Bruijn. Next, identify where that person is from or where they live. For Imre Simon it was Brazil and for de Bruijn it was the Netherlands. Finally, identify a stereotypical or even vaguely racist property of that location or nationality. For Brazil it was “tropical”. For the Netherlands I’m not sure what to use. The Dutch are stereotypically tall and wear clogs and ride bicycles, so let’s call it the “tall H function”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("“clogarithmic H function”")#linebreak()#text(" “bicyclic H function”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495145")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("I was thinking that going into negative ")#mi("t")#text(" region, one should soon see Lehmer pairs and almost-Lehmer pairs of zeroes collide and move away from the real line, following the evolution of the zeroes of the ")#mi("H_{t}")#text(" with ")#mi("t")#text(" decreasing from zero…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495197")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2018")])]

#text("Yes, ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("it is now known")]#text(" that for any negative t, there must be non-real zeroes. Presumably one could see this numerically (I vaguely recall someone doing this a few weeks ago). The methods to compute ")#mi("H_t")#text(" in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_second_approach")]#text(" should continue to work without much modification for negative ")#mi("t")#text(" (indeed the convergence should be even better now). The methods in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")]#text(" are more problematic, but the first equation on that page should still give a correct and convergent formula (bearing in mind that ")#mi("\\sqrt{t}")#text(" is now imaginary – it doesn’t matter which branch one takes), even if the remaining contour integration and tail bound estimates are no longer valid as stated. Also I think the ")#mi("A^{eff}+B^{eff}")#text(" and ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" approximations should still be reasonably accurate, though the rigorous error bounds currently in the wiki or pdf writeup no longer apply. If someone has spare time and numerical capability on their hands they are welcome to experiment with the ")#mi("t<0")#text(" regime; as far as I can tell it won't directly impact the primary goal of this project, but may help deepen our general intuition regarding the behavior of the ")#mi("H_t")#text(" (and on the reliability of various numerical approximations).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495253")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("Using the first equation from the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounding_the_derivative_of_H_t_-_third_approach")[#text("third integral approach")]#text(", and verifying the data with ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(", here are some ")#link("https://drive.google.com/open?id=155kMpxm7e9ImJZLZmtK0peNwDmO7KKAr")[#text("implicit plots")]#text(" for the ")#mi("t \\le 0")#text(" domain.")

#text("The first picture shows some complex zeros for ")#mi("y=0.4")#text(" in the x,t-plane, fortunately all below ")#mi("t=0")#text(" :), and the plot also illustrates the intriguing complexity in this domain.")

#text("In the second picture,the trajectory of a single complex zero is followed all the way till its unavoidable collision with its conjugate.")

#text("Few initial observations/questions:")#linebreak()#text(" * Similar to the real zeros, above a certain ")#mi("t")#text(", all complex zeros that I tested appear to also march up leftwards (and of course also towards their conjugates). Is this true/provable?")#linebreak()#text(" * Complex zeros that reside at a more negative ")#mi("t")#text(", appear to have to ‘surround’ multiple complex zeros at less negative ")#mi("t")#text(" (see second picture). Does this imply that the density of complex zeros has to decrease when ")#mi("t")#text(" goes increasingly negative?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495258")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("Thanks for these graphics! I think all zeroes ")#mi("z_j")#text(" should in general experience a leftward “pressure”, coming from the contributions to the velocity ")#mi("\\dot z_j = 2 \\sum_{k \\neq j} \\frac{1}{z_j-z_k}")#text(" coming from those zeroes ")#mi("z_k")#text(" at distance to ")#mi("z_j")#text(" comparable to ")#tao-math("\\left|z_j\\right|", block: false)#text(". At most scales, the zeroes to the right and to the left of ")#mi("z_j")#text(" should exert a roughly equal “force” on the ")#mi("z_j")#text(" zero that more or less cancels out, but at the scale ")#tao-math("\\left|z_j\\right|", block: false)#text(", there are more zeroes on the right than on the left (because zeroes are sparser near the origin than away from the origin), and so all zeroes (real or complex) should move leftwards on the average. But occasionally they can be influenced by more short-range interactions to go against this trend.")

#text("I’m not sure I understand what you mean by complex zeroes “surrounding” other complex zeroes, though. One would expect to have more and more complex zeros as t becomes more negative, as the remaining real zeroes collide and become complex; though at some point this process exhausts all the real zeroes and then the number of complex zeroes in a given region should stabilise (other than marching to the right on average as t increases, as discussed earlier).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("It seems that (similar to the “attraction” of complex zeros to the real axis – due to their vertical attraction to their complex conjugates) their is a similar horizontal “repulsion” of complex zeros from the imaginary axis – due to their horizontal repulsion from their images with respect to the imaginary axis. In this sense, the imaginary axis is acting like a barrier for complex zeros in the right-half-plane moving leftward.")#linebreak()#text(" In particular, it seems that the imaginary axis, acting as a “barrier”, should be zero-free for any real t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("In fact, ")#mi("H_t (i y) > 0")#text(" for any real ")#mi("t, y")#text(", since the integrand in its defining integral is clearly positive in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("That’s a nice observation – simple, but somehow I missed it before. I was initially a bit confused because ")#link("https://drive.google.com/file/d/1855iryE-7uDDEyW7hXJ5-3Njomsz-mMH/view")[#text("this graphic")]#text(" indicates that ")#mi("H_t/B^{eff}_0")#text(" is negative real rather than positive real on the imaginary axis, but this is because ")#mi("B^{eff}_0")#text(" is negative there.")

#text("Anyway, now we understand the left side of the region ")#mi("\\{ x+iy: 0 \\leq x \\leq X; y \\geq y_0 \\}")#text(" very well. Not that this was the most dangerous side in any case, but every little bit helps…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5869d8b1448ca10fca0bd94d7cbc089633423849ab93255b0123f887992ce41a-6ba6395656430792a6ea6ae7d9ac3e6b5677fa135c4d519e4810981160304521.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2018")])]

#text("I did ask a question about the evolution of a Lehmer pair when t varies, and the Polymath 15 participant Rudolph generated several beautiful graphs here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2018/02/12/polymath15-third-thread-computing-and-approximating-h_t/")[#text("Polymath15, third thread: computing and approximating H_t")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2018")])]

#text("If ")#mi("\\Lambda > 0")#text(", we know that ")#mi("H_t")#text(" has finitely many (")#mi("N_*(t)")#text(", say) non-real zeros for each ")#mi("t \\in (0, \\Lambda)")#text(". Hence, by fixing ")#mi("t_0 \\in (0, \\Lambda)")#text(", we see that ")#mi("N_*(t)")#text(" is a positive, bounded, non-increasing, integer-valued function on ")#mi("(t_0, \\Lambda)")#text(" with ")#mi("N_*(\\Lambda) = 0")#text(" – meaning that by letting ")#mi("t \\to  \\Lambda")#text(", the last non-real zero of ")#mi("H_t")#text(" (with its complex conjugate) should arrive to the real axis precisely for ")#mi("t = \\Lambda")#text(" – showing that ")#mi("H_{\\Lambda}")#text(" must have a multiple (real) zero (assuming ")#mi("\\Lambda > 0")#text(".)")#linebreak()#text(" The conclusion is that ")#mi("\\Lambda = 0")#text(" (i.e. RH !) is implied by requiring ")#mi("H_{\\Lambda}")#text(" to have only simple zeros.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495249")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("In the wiki page on the dynamics of zeros, the limit expressing the zero velocity should apply to the expression inside parentheses.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495274")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("Just for fun, I have prepared ")#link("https://drive.google.com/open?id=1KtD0vUc6WATXWadsCve8mWA8MMAev-qI")[#text("two visuals")]#text(" that attempt to explain our latest approach to keep complex zeros out of the ‘forbidden’ zone < X. Hope they are a reflection of what's really going on, but at least these already helped me a lot to explain the De Bruijn-Newman constant to my family :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("These are indeed nice visuals – it is hard to depict what is going on in the ")#mi("t, x, y")#text(" directions simultaneously, but it does seem possible to do so with your visuals (though I had to think a little bit to convert it back to my own mental imagery, where ")#mi("t")#text(" is a time variable rather than a spatial one, so that one thinks of 2D videos of zeroes flying around, rather than 3D worldlines of zeros).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("Here’s a C/arb script for the winding number for f(z) = (Aeff(z) + Beff(z))/Beff0(z).")#linebreak()#text(" ")#link("https://pastebin.com/5ngVh4QG")[#text("https://pastebin.com/5ngVh4QG")]

#text("At its core is a procedure that uses forward mode automatic differentiation and interval arithmetic to obtain uniform bounds on |f’| on segments of the contour. These segments are recursively split, the bounds are refined, and f is evaluated at segment endpoints until |f| is proven to be greater than c on all segments.")

#text("The usage notes follow…")

#text("—")

#text("Usage:")#linebreak()#text(" ./a.out N c t xa xb ya yb")

#text("This script computes the winding number about 0 of f(p).")#linebreak()#text(" Let r be a rectangle in the complex plane")#linebreak()#text(" r : [xa <= x <= xb] + i[ya <= y <= yb]")#linebreak()#text(" and let p be the counterclockwise path along the boundary of r")#linebreak()#text(" starting and ending at (xa + i*ya).")#linebreak()#text(" Let f(z) = (Aeff_t(z) + Beff_t(z)) / Beff0_t(z).")#linebreak()#text(" Additionally, f(p) is required to stay away from 0 so")#linebreak()#text(" the script will either abort or will fail to terminate")#linebreak()#text(" if |f(z)| <= c at any point z on the path p.")#linebreak()#text(" The Nth partial sum is used in Aeff and Beff.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("Is it possible to show (for suitable ")#mi("t_0 > 0")#text(") that ")#mi("\\Lambda \\leq t_0")#text(" by showing that ")#mi("H_{t_0}")#text(" has only real zeros?")#linebreak()#text(" A natural strategy consists of")

#text("1. Showing analytically that ")#mi("H_{t_0}")#text(" has only real zeros if their real parts are above a sufficiently good explicit numerical threshold ")#mi("X(t_0)")#text(".")

#text("2. Showing that there are no non-real zeros ")#mi("x_k + i y_k")#text(" in the rectangle ")#tao-math("\\left|x\\right| \\leq \\left|X(t_0)\\right|, \\left|y\\right| \\leq 1", block: false)#text(" by counting the number of zeros inside this rectangle (using the argument principle) and comparing it to the number of real zeros in this rectangle (counting sign changes – using sufficiently good approximations of ")#mi("H_{t_0}")#text(" (obtained e.g. by tracking the time dynamics of ")#mi("H_t")#text(" zeros – starting with approximate zeros of ")#mi("H_0")#text(" as computed e.g. in Platt’s paper.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("This would basically be the limiting version of our current strategy when ")#mi("y")#text(" is set to 0 rather than something like ")#mi("0.4")#text(". While this does have the advantage of allowing one to increase ")#mi("t_0")#text(" (since currently we are using the bound ")#mi("\\Lambda \\leq t_0 + \\frac{1}{2} y^2")#text("), there are some non-trivial difficulties in executing your steps 1 and 2 in the y=0 setting. For ")#mi("y")#text(" away from zero, there is an imbalance between the two main terms ")#mi("A^{eff}, B^{eff}")#text(" in the approximation for ")#mi("H_t")#text(" that makes it relatively easy to establish a zero-free region. It is possible to asymptotically push this down to ")#mi("y>0")#text(" using some additional tricks based on the argument principle and Jensen’s inequality, as is done in the current writeup but it involves a number of unspecified constants and would probably lead to a numerically large value of ")#mi("X(t_0)")#text(".")

#text("Evolving the time dynamics of zeroes is going to be computationally quite difficult – this is a system of ODE involving an infinite number of zeroes, all but a finite number of which we don’t actually know the value of! In principle there is this potential scenario in which a whole bunch of non-real zeroes of ")#mi("H_0")#text(", lurking just outside the numerical verification of RH, zoom in at high speeds to small values of ")#mi("x")#text(", and then mess around with the locations of the numerically visible real zeroes and move them to strange locations. For large values of ")#mi("y")#text(" we can erect a barrier to stop this scenario from happening, but it looks significantly harder to do so near the real axis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("I meant to evolve the time dynamics not via the (numerically problematic) infinite ODE system, but by following the dynamics of each ")#mi("H_t")#text(" zero from ")#mi("t = 0")#text(" to ")#mi("t = t_0")#text(" with sufficiently small “time steps” such that the k-th zero ")#mi("x_k(t_j)")#text(" of ")#mi("H_{t_k}")#text(" should converge (by fast local root finding algorithm) to the corresponding zero ")#mi("x_k(t_{j+1})")#text(" of ")#mi("H_{t_{k+1}}")#text(".")

#text("If the number of zeros in the rectangle (computed by the argument principle) would be equal to the number of real zeros in the rectangle (computed by sign changes) then it should imply that all the zeros in this rectangle are real.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495723")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("I just added to ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/Writeup")[#text("the writeup")]#text(" a proper treatment of the very large x case when ")#mi("t=0.2")#text(" and ")#mi("y=0.4")#text(", namely when ")#mi("N \\geq 3 \\times 10^5")#text(", using the triangle inequality and bounding all error terms and tails. I had previously thought ")#mi("N \\geq 2 \\times 10^5")#text(" would suffice for the triangle inequality bound, but it seems fall just a little bit short, even if one uses the lemma to sharpen the bound slightly. This may make things a little more computationally challenging for the Euler2 portion of the verification, but hopefully we can get a mesh argument to work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("In the writeup, in the line below (11), it seems that “zero” should be “nonzero at the origin” (as in the wiki sub-page on ")#mi("H_t")#text(" zeros dynamics.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495841")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("The Euler2 mollifier bound data for t=0.2,y=0.4,N 40k to 100k with stepsize of 100 is kept ")#link("https://drive.google.com/open?id=1VYhjaIJ9XQad9hRrQMKCwasvBCWpwcxg")[#text("here")]#text(". The bound reaches 0.2 around N=60k and 0.3 around N=85K. The change between successive values (N+100,N) also seems to be gradually decreasing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("I’m a bit confused as to what the bound represents; I would have expected the lower bound for ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" to be decreasing with ")#mi("N")#text(", not increasing as this table seems to suggest. Could you clarify what euler2_moll_bound is measuring?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495854")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("I calculated ")#tao-math("1 - a_1 - \\sum_{n=2}^{2N} \\frac{\\left|b_n\\right|}{n^\\sigma} - \\sum_{n=2}^{2N} \\frac{\\left|a_n\\right|}{n^\\sigma}", block: false)#text(" where b_n and a_n are the mollified terms and a_n includes (n/N)^y, exp(delta) and other terms. Also, from the t=y=0.4 exercise, the function turns positive at N=478.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495890")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Ah, ok, thanks. Actually the bound should be decreasing in N; I don’t know why I thought it would be increasing.")

#text("I’ll try to see if there is some reasonable way to control the size of the difference between the bound at N and the bound at N+1. If one can get it under 0.002 or so then the step size 100 mesh should be fine; otherwise we have ot increase the mesh size a bit (or try to also control second differences or double derivatives, but this looks a bit messy).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495898")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("These are some ddN values I got for the Euler2 toy bound (using the 2 – Sum_B – Sum_A formula). Values were verified against the newton quotient. They do seem to be well under 0.002 (excluding the additional terms at N+1, which seem to be smaller than the derivative).")

#text("t=0.2,y=0.4")#linebreak()#text(" N, ddN")#linebreak()#text(" 40k, 1.32*10^-5")#linebreak()#text(" 100k, 3.25*10^-6")#linebreak()#text(" 200K, 1.10*10^-6")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495909")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Also, since all the multipliers and summands in the calculated ddN formula are positive, is it fine to estimate the lower bound of |a+b| for intermediate N points as lower_mesh_point_estimate – additional terms. Or do we have to penalize the mesh estimate with something like -ddN*1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Yes, if we let ")#mi("f(N)")#text(" be the lower bound for ")#mi("A^{eff} + B^{eff} / B^{eff}_0")#text(", extending the definition to non-integer ")#mi("N")#text(" (with jump discontinuities at each integer), and if we have a derivative bound of the form ")#tao-math("\\left|f^{\\prime}(N)\\right| \\leq D", block: false)#text(" for all non-integer ")#mi("N")#text(" in an interval ")#mi("[N_0, N_0 + M]")#text(" and a jump discontinuity bound of ")#mi("J")#text(" at each integer ")#mi("N")#text(" in that interval, then we have ")#mi("f(N) \\geq f(N_0) - M(D+J)")#text(" throughout ")#mi("[N_0,N_0+M]")#text(". Actually we can do a bit better than this by also working backwards from ")#mi("f(N_0+M)")#text(", but given how good the bounds on ")#mi("D")#text(" are (and I am guessing ")#mi("J")#text(" will also be very good, it should be about ")#mi("1/N")#text(" the size of the whole sum given that it comes from just a single term) we probably don’t need to be too sophisticated (it would only save a factor of two at best anyway).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495922")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("In the E2 mollified sum, it seems there are 3 terms (in B and A each) which change or get added as N increases by 1. The two terms n=2N+1 and 2N+2, although the first one is zero, and also the n=N+1 term due to the delta function. Should we consider the 2M non zero terms while deriving MJ? I also tried deriving a bound for MJ (dropping any conditional negative part from the first M affected terms).")

#mi("\\sum_{N_0+1}^{N_0+M}(\\frac{b_{n}^t}{n^{\\sigma+(t/2)\\log N_0}} - \\frac{1_{2|n} \\lambda_2 b_{n/2}^t}{n^{\\sigma+(t/2)\\log (N_0+M)}})+ \\sum_{2N_0+1}^{2N_0+2M}\\frac{1_{2|n} \\lambda_2 b_{n/2}^t}{n^{\\sigma+(t/2)\\log N_0}}")

#text("Also, should we set M as stepsize-1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496026")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("The previous proposed formula for MJ had some typos regarding mods. Also, by removing any subtractions and making the formula simpler and conservative, is it fine to take MJ (including the A sum contribution) as")

#tao-math("\\sum_{N_0+1}^{N_0+M}\\frac{b_{n}^t (1+ (n/N)^y)}{n^{\\sigma+(t/2)\\log N_0}}+ \\sum_{2N_0+1}^{2N_0+2M}\\frac{\\left|1_{2|n} \\lambda_2 b_{n/2}^t (1+ (n/N)^y)\\right|}{n^{\\sigma+(t/2)\\log N_0}}", block: false)

#text("For t=0.2,y=0.4,N=40K,M=99, the above estimate comes out to ~ 0.00056.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("Here’s a C/arb script to compute the Euler mollified dirichlet series lower bound of abs(Aeff + Beff)/abs(Beff0).")#linebreak()#text(" ")#link("https://pastebin.com/WZi63kCq")[#text("https://pastebin.com/WZi63kCq")]

#text("Usage notes and examples follow…")

#text("—")

#text("Usage:")#linebreak()#text(" ./a.out t y Na Nb Nstep m n d")

#text("This script computes a lower bound of abs(Aeff + Beff)/abs(Beff0)")#linebreak()#text(" for N between ‘Na’ and ‘Nb’ with steps of size ‘Nstep’.")#linebreak()#text(" It uses an Euler mollification that includes m primes,")#linebreak()#text(" so that for example m=0 corresponds to no mollification")#linebreak()#text(" and m=3 corresponds to an Euler mollification that uses")#linebreak()#text(" the first three primes {2, 3, 5}.")#linebreak()#text(" Each row of output consists of N followed by the bound")#linebreak()#text(" and n derivatives with respect to N, so that for example")#linebreak()#text(" n=2 would print rows consisting of N, the bound,")#linebreak()#text(" the first derivative of the bound with respect to N,")#linebreak()#text(" and the second derivative of the bound with respect to N.")#linebreak()#text(" All output has d significant decimal digits of accuracy.")

#text("—")

#text("Examples:")

#text("./a.out 0.4 0.4 321 322 1 2 1 10")#linebreak()#text(" 321 -0.0003790530744 0.002782680281")#linebreak()#text(" 322 0.001790379319 0.002767556381")

#text("./a.out 0.4 0.4 477 478 1 1 1 10")#linebreak()#text(" 477 -0.001301082303 0.001626307626")#linebreak()#text(" 478 5.427798648e-05 0.001620293615")

#text("./a.out 0.2 0.4 20000 20000 1 0 1 10")#linebreak()#text(" 20000 -1.127467428 4.94147775e-05")

#text("./a.out 0.2 0.4 20000 20000 1 1 1 10")#linebreak()#text(" 20000 -0.243596499 3.68902378e-05")

#text("./a.out 0.2 0.4 20000 20000 1 2 1 10")#linebreak()#text(" 20000 0.04755850292 3.381699674e-05")

#text("./a.out 0.4 0.4 500 500 1 1 1 10")#linebreak()#text(" 500 0.02370202975 0.001510382076")

#text("./a.out 0.4 0.4 500 500 1 2 1 10")#linebreak()#text(" 500 0.2259563455 0.00138754766")

#text("./a.out 0.4 0.4 500 500 1 3 1 10")#linebreak()#text(" 500 0.2935839092 0.001354301778")

#text("time ./a.out 0.2 0.4 40000 100000 100 1 1 10 | tail -n 3")#linebreak()#text(" 99800 0.3411359593 3.256440052e-06")#linebreak()#text(" 99900 0.341388428 3.251396669e-06")#linebreak()#text(" 100000 0.3416405273 3.246366034e-06")

#text("real 3m43.574s")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-495981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("Here’s the output for the 384 minute run of")#linebreak()#text(" ./a.out 0.2 0.4 40000 300000 10 1 1 10")

#link("https://gist.githubusercontent.com/p15-git-acc/5298cb724b7731641ae203abe5d6ed2a/raw/e442ce9e28b24e0a201abb5b462521e68d2a4e42/gistfile1.txt")[#text("https://gist.githubusercontent.com/p15-git-acc/5298cb724b7731641ae203abe5d6ed2a/raw/e442ce9e28b24e0a201abb5b462521e68d2a4e42/gistfile1.txt")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("Here are the E2 mollified bounds for all N between 40000 and 300000 (step size 1). t=0.2 y=0.4.")

#link("https://gist.githubusercontent.com/p15-git-acc/17ef55b4143a6cc9e7c082004ca185f5/raw/b937bbb2b1d9e2a85fe457984ee993a75107595f/gistfile1.txt")[#text("https://gist.githubusercontent.com/p15-git-acc/17ef55b4143a6cc9e7c082004ca185f5/raw/b937bbb2b1d9e2a85fe457984ee993a75107595f/gistfile1.txt")]

#text("Together with Rudolph’s E3 mollified bounds calculation (linked below) for all N between 19947 and 40000 (also step size 1 and t=0.2 y=0.4) this may help with the intermediate sizes of ")#mi("x")#text(" in a ")#mi("\\Lambda \\leq 0.28")#text(" proof.")

#link("https://github.com/km-git-acc/dbn_upper_bound/files/1904955/Output19947to40000.txt")[#text("https://github.com/km-git-acc/dbn_upper_bound/files/1904955/Output19947to40000.txt")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496122")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("Thanks for this! I have added it to the wiki.")

#text("It looks like we are now close to clearing the middle range ")#mi("4 \\times 10^4 \\leq N \\leq 3 \\times 10^5")#text(". The path of least resistance may simply be to run your code with mesh size 1 rather than 10 so that we don’t have to do any derivative analysis; if the 10-mesh run took 384 minutes then the mesh 1 run should take three days (also it could be parallelised simply by chopping up the range into pieces; one could also save 10% of the work by reusing the existing mesh when N is a multiple of 10). But it looks like the derivative bound approach would work also (now that we have an extra order of magnitude of room coming from working with a mesh of 10 rather than 100).")

#text("If one combines that with an Euler3 calculation in the remaining range ")#mi("19947 \\leq N \\leq 4 \\times 10^4")#text(" and E_1,E_2,E_3 estimates in ")#mi("19947 \\leq N \\leq 3 \\times 10^5")#text(" then we seem to have filled in all the jigsaw pieces to prove ")#mi("\\Lambda \\leq 0.28")#text(". This may well be a good place to declare victory; one may be able to shave a 0.01 or so from this bound by pushing a little bit further, but I think we are already beginning to hit the limits of the method (and progress is roughly inversely logarithmic to the amount of computer power thrown at it, so that’s not really the bottleneck). I guess we could do some exploratory calculations though to see if there is any relatively cheap way to lower the t or y parameters further while keeping the lower bounds for A+B/B away from zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496126")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("“The path of least resistance may simply be to run your code with mesh size 1 rather than 10 so that we don’t have to do any derivative analysis” The 384 minute run used mesh size 10, but the later one and Rudolph’s have already used mesh size 1!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496123")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("I should clarify that by “E2 mollified bound” I meant the lower bound of |Aeff+Beff|/|Beff0| computed with the Euler product mollification of the dirichlet series, where the largest prime in the Euler product is 2. At least that’s what I think I mean. Same thing with Rudolph’s E3. I was using the E2 and E3 terminology because I saw other people using it, but now I see that it’s confusing with the error terms E1, E2, E3 and I should have said Euler2 and Euler3 instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496125")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("OK, thanks for the clarification! I’m correcting the wiki now to reflect this. I guess we can agree to use Euler1, Euler2, Euler3 for the mollified bounds and Error1, Error2, Error3 for the error bounds to avoid misunderstanding.")

#text("Also, on closer rereading I now see that you’ve already done the mesh 1 calculation for the mid range ")#mi("4 \\times 10^4 \\leq N \\leq 3 \\times 10^5")#text(". So it looks like we don’t have to do any derivative analysis in N at all! So, it seems like the only remaining computational task is to compute Error1, Error2, Error3 in the ")#mi("19947 \\leq N \\leq 3 \\times 10^5")#text(" ranges, which should be relatively quick compared to the other tasks already completed. (Note that the formulae on the writeup are slightly different from that in the wiki.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496147")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("Given the speed at which the current scripts output results, I was just checking the feasibility at t=0.2,y=0.3, and things seem quite feasible for a follow-on exercise later. Euler 3 triangle bound at N=69098 (x ~ 6*10^10) is ~ 0.22, and the non-mollified bound at N=600K is 0.0564.")

#text("At t=0.15 and y even at 0.4, N=10^7 gives a positive non mollified bound, but at N=69098 all the mollified bounds considered so far (Euler 2/3/5, with triangle/lemma are sufficiently negative).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496211")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("That’s more promising than I thought! But I would imagine the real bottleneck would be the barrier computation. Still I guess we could shoot for a nice clean bound ")#mi("\\Lambda \\leq \\frac{1}{4}")#text(" this way…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496201")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("There seems to be a small typo on pg 21 of the paper for the errors e_C and e_C,0. The 6.72 factor should be 6.92 according to pg 24.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Some of the estimates and bounds currently require y >= 1/3. Would these need to be reworked for smaller y if we go for t=0.2 y=0.3?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Some of the wiki estimates have this restriction, but the writeup estimates have been written so as not to need these. (Note in particular the ")#mi("(1-3y)_+")#text(" factor of Proposition 6.6(ii), which activates once ")#mi("y")#text(" goes below 1/3.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496265")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("The writeup doesn’t seem to have the ddx bound formula yet (present at the bottom of the Controlling A+B/B 0 wiki). In the wiki, it mentions the y>1/3 restriction for this bound. If we go below y=1/3, will this bound change as well?")#linebreak()#text(" Also, there seems to be a typo on pg 22 of the writeup, where the 2(1-y) factor while bounding Re(alpha(s)) should be -2(1-y). On checking against the final bound for Re(alpha) at some x+iy, for eg. x=1000,y=0.5, we seem to get a small negative difference for Re(alpha)-bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Thanks for pointing out the typo, which actually required a non-trivial rewrite here; the restriction ")#mi("y > 1/3")#text(" needs to be replaced by the slightly more restrictive ")#mi("y > 1/3 + \\frac{4y(1+y)}{3x^2}")#text(", though at y=0.4 this is still certainly safe. I’ll work on the writeup to fix this; also will put in some more details on how to deal with the medium ranges of N and to extend the derivative bound below this restriction (I guess this is needed to extend the barrier calculations below y=0.4).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496302")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("We have started work on the remaining computational task to compute Error1, Error2, Error3 bounds in the ")#mi("19947 \\leq N \\leq 3 \\times 10^5")#text(" range to complete the ")#mi("t=0.2,y=0.4")#text(" case. These error bounds are named eA, eB and eC0 (since we are not using ")#mi("C^{eff}")#text(") in the write-up. Here are some sample data (respectively eA, eB, eC0):")

#mi("N=19947")#linebreak()#text(" 5.2812559935137…e-11")#linebreak()#text(" 7.2181152722662…e-10")#linebreak()#text(" 7.2698636640998…e-6")

#mi("N=1 \\times 10^5")#linebreak()#text(" 8.3090086061558…e-13")#linebreak()#text(" 2.8949570104373…e-11")#linebreak()#text(" 4.1858191562622…e-7")

#mi("N=2 \\times 10^5")#linebreak()#text(" 1.3746978215374…e-13")#linebreak()#text(" 7.3836305552204…e-12")#linebreak()#text(" 1.1325230648234…e-7")

#mi("N=3 \\times 10^5")#linebreak()#text(" 4.8124550500060…e-14")#linebreak()#text(" 3.3324044232747…e-12")#linebreak()#text(" 5.1555261007475…e-8")

#text("All error bounds seems to be monotonically decreasing and the overall bound is dominated by eC0 with eA and eB a few orders of magnitude smaller. When eC0 was first derived on the wiki,")#link("http://michaelnielsen.org/polymath1/index.php?title=Controlling_H_t-A-B/B_0")[#text("wiki (The Estimating E3 section)")]#text(", it was proved to be monotonically decreasing. Is that still the case for latest version of eC0 in the write-up?")

#text("Now, if eA and eB are much smaller than eC0, and eC0 is monotonically decreasing with its delta at each successive N much larger than any possible increase in eA or eB, then are the error bounds required to be evaluated at each N or could we take steps of say ")#mi("N=N+1000")#text("?")

#text("Here is the output of a ")#link("https://drive.google.com/open?id=1cJhwpFcOYrUXN4gsno1Xvt-Rd6DxTXvc")[#text("test run")]#text(" (in steps of ")#mi("10")#text(", accurate at ")#mi("10")#text(" digits) for ")#mi("4 \\times 10^4 \\leq N \\leq 1 \\times 10^5")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Thanks for starting this! The bound for ")#mi("e_{C,0}")#text(" in Proposition 6.6(vi) is indeed monotone decreasing in ")#mi("x")#text(" once ")#mi("x")#text(" is larger than say 200; this is clear from inspection except possibly for the term ")#tao-math("\\frac{\\left|\\log \\frac{x}{4\\pi} + i \\frac{\\pi}{2}\\right|}{x-8.52}", block: false)#text(", but Lemma 5.1 ensures that ")#mi("\\frac{\\log \\frac{x}{4\\pi}}{x-8.52}")#text(" is decreasing, and so is ")#tao-math("\\left|1 + i \\frac{\\pi}{2\\log \\frac{x}{4\\pi}}\\right|", block: false)#text(", so the claim follows from multiplying.")

#text("The bound for ")#mi("e_A")#text(" in Proposition 6.6(iv) is at most ")#tao-math("\\left|\\gamma\\right| N^{\\left|\\kappa\\right|+y}", block: false)#text(" times the corresponding bound for ")#mi("e_B")#text(". This factor ")#tao-math("\\left|\\gamma\\right| N^{\\left|\\kappa\\right|+y}", block: false)#text(" can be bounded by ")#mi("\\exp( 0.02y + \\frac{ty}{2(x-6)} \\log N - \\frac{y}{2} \\log \\frac{x}{4\\pi N^2} )")#text(" which is only a little bit larger than 1, in particular it should be easily bounded by 2 in the range of interest. So up to a factor of say 3 we can ignore ")#mi("e_A")#text(" and just bound ")#mi("e_B")#text(".")

#text("One can bound ")#mi("e_B")#text(" in a range such as ")#mi("N_0 \\leq N \\leq N_0+1000")#text(" by using the upper bound ")#mi("N_0+1000")#text(" for the summation range of ")#mi("n")#text(" and the lower bound ")#mi("x_0 = 4\\pi N_0^2 - \\frac{\\pi t}{4}")#text(" for the value of ")#mi("x")#text(" in summands, if we bound ")#mi("\\log^2 \\frac{x}{4\\pi n^2}")#text(" by ")#mi("\\log^2 \\frac{x}{4\\pi}")#text(" (here we use that $\\frac{\\log^2 \\frac{x}{4\\pi}}{\\frac{x}{2}-3.33}$ is monotone decreasing for ")#mi("x \\geq 200")#text("), thus getting the somewhat crude bound")

#mi("e_B \\leq \\sum_{n=1}^{N_0+1000} \\frac{b_n^t}{n^{\\mathrm{Re}(s_*)}} (\\exp(\\frac{\\frac{t^2}{32} \\log^2 \\frac{x_0}{4\\pi} + 0.313}{\\frac{x_0}{2}-3.33})-1)")

#text("(and then using the lower bound for ")#mi("\\mathrm{Re}(s_*)")#text(" and again substituting ")#mi("x_0")#text(" for ")#mi("x")#text(") but given your numerical data I would imagine that this bound will still be more than serviceable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496410")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2018")])]

#text("The new, “step” bound formula for ")#mi("e_B")#text(" provides a great speed boost :) Below are the outputs for respectively step sizes ")#mi("m=1000, 10000, 100000")#text(". The fields are: ")#mi("N_0,3 \\times e_B, e_{C,0}, 3 \\times e_B + e_{C,0}")#text(".")

#text("Further optimisation could be done by calculating ")#mi("e_{C,0}")#text(" only once at the start of the range, rather than for each ")#mi("N_0")#text(".")

#text("I have used the most recently updated definition of ")#mi("Re(s_*)")#text(" from the write-up, but since we are using ")#mi("y=0.4")#text(" and a sufficiently large ")#mi("x")#text(", there is no difference compared to the previous version.")

#text("Since all values of the upper bound of the error terms stay way below the lower bound of ")#mi("\\frac{A^{eff}+B^{eff}}{B_0^{eff}}")#text(", does this complete our ")#mi("t=0.2, y=0.4")#text(" case?")

#link("https://drive.google.com/open?id=1xiHQWxx-C-8OJ7LgUO_HjQIENT9axLaQ")[#text("Step 1000")]

#link("https://drive.google.com/open?id=1lS7wcqrFrhpDK0aWqSrhjy7mcz7i4a8o")[#text("Step 10000")]

#link("https://drive.google.com/open?id=1ASET-x5bxQ7rPHOYW0_ii7O4gapjClg6")[#text("Step 100000")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496456")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("Great! It does seem that we have indeed finished off the numerical verifications needed to show that ")#mi("\\Lambda \\leq 0.28")#text(". In this particular case the bounds for ")#mi("e_A,e_B,e_{C,0}")#text(" are so small that one can probably use some of the analytic techniques currently used in the ")#mi("N \\geq 3 \\times 10^5")#text(" case to safely cover this range also, but this sort of numerical verification could be useful if we want to make one last push to say ")#mi("\\Lambda \\leq \\frac{1}{4}")#text(" (one could joke that this is “halfway towards RH :)”).")

#text("I’m in the process of putting the derivative bounds on A+B/B in the writeup, trying to clean things up a bit from the wiki version. Nearly done with the x and y derivative bound, will also work on the t derivative bound which is not currently on the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496464")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("We were able to test the (A+B)/B0 lower bound formulas as in the writeup, and the estimates seem to be only slightly more conservative than earlier.")

#text("Also, I was reading a blog post from 2015 on bounding exponential sums,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("254A, Notes 5: Bounding exponential sums and the zeta function")]
]

#linebreak()#text(" and just wanted to check if such estimates are applicable here and could provide further improvement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496478")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("In principle one can do this. For instance, in ")#link("https://projecteuclid.org/euclid.rmjm/1181069799")[#text("https://projecteuclid.org/euclid.rmjm/1181069799")]#text(" Cheng and Graham obtain explicit bounds on ")#mi("\\zeta(\\frac{1}{2}+it)")#text(" are proven such as ")#tao-math("\\left|\\zeta(\\frac{1}{2}+it)\\right| \\leq 6t^{1/4} + 41.124", block: false)#text(" for ")#mi("t \\geq e")#text(", which compare favorably to what one would get from the Riemann-Siegel formula and the triangle inequality (which would give something of the order of ")#mi("O(t^{1/2})")#text(") (Cheng-Graham get an upper bound of the form ")#mi("2t^{1/2} + 5.505")#text(", though not directly from a Riemann-Siegel formula). The sums in ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" and their derivatives are broadly of a similar form and one may even be able to just directly use some of the lemmas in Cheng-Graham together with summation by parts to get a reasonable estimate. I guess one way to check if there is a lot of opportunity for gain here is to compare the upper bounds for ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(" and their derivatives with what one actually gets numerically when evaluating at mesh points. If there are one or more orders of magnitude of discrepancy, one can try to look for smarter upper bounds than the triangle inequality so as to allow for a sparser mesh which may then speed up the barrier computations significantly.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("In section 9.4 (page 35) of the paper, in the estimation of ")#mi("Q_3")#text(", it is stated that a certain exponent is upper-bounded by ")#mi("-1.009")#text(" (which is clearly impossible!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Oops, there was an extra exponential on the left-hand side; this is now removed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("A small copypaste typo in definition (59) of the pdf, ")#mi("E_{C} := E_{C, 0}(x + i y) := \\ldots")#text(" should be ")#mi("E_{C} := E_{C}(x + i y) := \\ldots")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("In corollary 10.3(iii) in the paper, is the constant ")#mi("C")#text(" required to be the same as in part (i) (i.e. that ")#mi("H_t")#text(" zeros with real parts greater than ")#mi("\\exp (C/ t)")#text(" should be simple) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496491")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("Strictly speaking, yes, but it doesn’t really matter, since one if one used different constants ")#mi("C")#text(" in different places one could simply increase the smaller values of the constants to match the larger ones.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, eighth thread: going below 0.28 | What's new")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496492")[#strong[#text("Polymath15, eighth thread: going below 0.28 | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a50128a1029796eaced95c75ca816a8afc43264d7c6aa862d7f57c19a592adc-7ce3002720ef7a902229bc377792047b2829345ef0ec86dd68c4ac1adea8e518.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey Yankovich")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496568")[#strong[#text("Sergey Yankovich")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Epsilon-Zeta Hypothesis:")#linebreak()#text(" There exists an epsilon > 0 such that : there are no zeros of the zeta function having a real part > (1 – epsilon).")

#text("Does the the De Bruijn-Newman constant relate to this hypothesis?")#linebreak()#text(" Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/#comment-496594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Well, there is an upper bound ")#mi("\\Lambda \\leq \\frac{1}{2} (1-\\varepsilon)^2")#text(" (see Theorem 13 of ")#link("https://pure.tue.nl/ws/files/1769368/597490.pdf")[#text("de Bruijn’s paper")]#text("). So such a zero free region would in principle give new bounds on ")#mi("\\Lambda")#text(". However the converse implication is not available; certainly I don’t see any way to use what we’ve done so far to get new zero free regions for zeta.")
]
]
