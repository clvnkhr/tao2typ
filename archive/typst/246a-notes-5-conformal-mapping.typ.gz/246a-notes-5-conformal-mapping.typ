// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/
// Converted to Typst by tao2typ: "2026-10-14T15:19:49.863627+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246A, Notes 5: conformal mapping", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246A, Notes 5: conformal mapping")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("246B Notes 1")]#text(".")#linebreak()#text(" In the ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("previous set of notes")]#text(" we introduced the notion of a ")#emph[#text("complex diffeomorphism")]#text(" ")#mi("{f: U \\rightarrow V}")#text(" between two open subsets ")#mi("{U,V}")#text(" of the complex plane ")#mi("{{\\bf C}}")#text(" (or more generally, two Riemann surfaces): an invertible holomorphic map whose inverse was also holomorphic. (Actually, the last part is automatic, thanks to Exercise 41 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(".) Such maps are also known as ")#link("https://en.wikipedia.org/wiki/Biholomorphism")[#text("biholomorphic maps")]#text(" or ")#link("https://en.wikipedia.org/wiki/Conformal_map")[#text("conformal maps")]#text(" (although in some literature the notion of “conformal map” is expanded to permit maps such as the complex conjugation map ")#mi("{z \\mapsto \\overline{z}}")#text(" that are angle-preserving but not orientation-preserving, as well as maps such as the exponential map ")#mi("{z \\mapsto \\exp(z)}")#text(" from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" that are only locally injective rather than globally injective). Such complex diffeomorphisms can be used in complex analysis (or in the analysis of harmonic functions) to change the underlying domain ")#mi("{U}")#text(" to a domain that may be more convenient for calculations, thanks to the following basic lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Holomorphicity and harmonicity are conformal invariants)")]#text(" ")#metadata(none) <tao-785fda86872f7ba2ab7c>#text(" Let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a complex diffeomorphism between two Riemann surfaces ")#mi("{U,V}")#text(".")

#list(
[#text("(i) If ")#mi("{f: V \\rightarrow W}")#text(" is a function to another Riemann surface ")#mi("{W}")#text(", then ")#mi("{f}")#text(" is holomorphic if and only if ")#mi("{f \\circ \\phi: U \\rightarrow W}")#text(" is holomorphic.")],
[#text("(ii) If ")#mi("{U,V}")#text(" are open subsets of ")#mi("{{\\bf C}}")#text(" and ")#mi("{u: V \\rightarrow {\\bf R}}")#text(" is a function, then ")#mi("{u}")#text(" is harmonic if and only if ")#mi("{u \\circ \\phi: U \\rightarrow {\\bf R}}")#text(" is harmonic.")]
)
]

#emph[#text("Proof:")]#text(" Part (i) is immediate since the composition of two holomorphic functions is holomorphic. For part (ii), observe that if ")#mi("{u: V \\rightarrow {\\bf R}}")#text(" is harmonic then on any ball ")#mi("{B(z_0,r)}")#text(" in ")#mi("{V}")#text(", ")#mi("{u}")#text(" is the real part of some holomorphic function ")#mi("{f: B(z_0,r) \\rightarrow {\\bf C}}")#text(" thanks to Exercise 62 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(". By part (i), ")#mi("{f \\circ \\phi: \\phi^{-1}(B(z_0,r)) \\rightarrow {\\bf C}}")#text(" is also holomorphic. Taking real parts we see that ")#mi("{u \\circ \\phi}")#text(" is harmonic on each ball preimage ")#mi("{\\phi^{-1}(B(z_0,r))}")#text(" in ")#mi("{V}")#text(", and hence harmonic on all of ")#mi("{V}")#text(", giving one direction of (ii); the other direction is proven similarly. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Establish Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text("(ii) by direct calculation, avoiding the use of holomorphic functions. (")#emph[#text("Hint:")]#text(" the calculations are cleanest if one uses Wirtinger derivatives, as per Exercise 27 of ")#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-24a9245816c9847718fd>#text(" Let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a complex diffeomorphism between two open subsets ")#mi("{U,V}")#text(" of ")#mi("{{\\bf C}}")#text(", let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(", let ")#mi("{m}")#text(" be a natural number, and let ")#mi("{f: V \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" be holomorphic. Show that ")#mi("{f: V \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" has a zero (resp. a pole) of order ")#mi("{m}")#text(" at ")#mi("{\\phi(z_0)}")#text(" if and only if ")#mi("{f \\circ \\phi: U \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" has a zero (resp. a pole) of order ")#mi("{m}")#text(" at ")#mi("{z_0}")#text(".")
]

#text("From Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text("(ii) we can now define the notion of a harmonic function ")#mi("{u: M \\rightarrow {\\bf R}}")#text(" on a Riemann surface ")#mi("{M}")#text("; such a function ")#mi("{u}")#text(" is harmonic if, for every coordinate chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" in some atlas, the map ")#mi("{u \\circ \\phi_\\alpha^{-1}: V_\\alpha \\rightarrow {\\bf R}}")#text(" is harmonic. Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text("(ii) ensures that this definition of harmonicity does not depend on the choice of atlas. Similarly, using Exercise ")#link(<tao-24a9245816c9847718fd>)[#text("3")]#text(" one can define what it means for a holomorphic map ")#mi("{f: M \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" on a Riemann surface ")#mi("{M}")#text(" to have a pole or zero of a given order at a point ")#mi("{p_0 \\in M}")#text(", with the definition being independent of the choice of atlas; we can also identify such functions as equivalence classes of meromorphic functions ")#mi("{f: M \\backslash S \\rightarrow {\\bf C}}")#text(" in complete analogy with the case of meromorphic functions on domains ")#mi("{U}")#text(". Finally, we can define the notion of an essential singularity of a holomorphic function ")#mi("{f: M \\backslash S \\rightarrow {\\bf C}}")#text(" at some isolated singularity ")#mi("{p \\in S}")#text(" in a Riemann surface as one that cannot be extended to a holomorphic function ")#mi("{f: (M \\backslash S) \\cup \\{p\\} \\rightarrow{\\bf C} \\cup \\{\\infty\\}}")#text(".")#linebreak()#text(" In view of Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text(", it is thus natural to ask which Riemann surfaces are complex diffeomorphic to each other, and more generally to understand the space of holomorphic maps from one given Riemann surface to another. We will initially focus attention on three important ")#emph[#text("model Riemann surfaces")]#text(":")

#list(
[#text("(i) (Elliptic model) The Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(";")],
[#text("(ii) (Parabolic model) The complex plane ")#mi("{{\\bf C}}")#text("; and")],
[#text("(iii) (Hyperbolic model) The unit disk ")#mi("{D(0,1)}")#text(".")]
)

#text("The designation of these model Riemann surfaces as elliptic, parabolic, and hyperbolic comes from ")#link("https://en.wikipedia.org/wiki/Riemannian_geometry")[#text("Riemannian geometry")]#text(", where it is natural to endow each of these surfaces with a constant curvature Riemannian metric which is positive, zero, or negative in the elliptic, parabolic, and hyperbolic cases respectively. However, we will not discuss Riemannian geometry further here.")#linebreak()#text(" All three model Riemann surfaces are simply connected, but none of them are complex diffeomorphic to any other; indeed, there are no non-constant holomorphic maps from the Riemann sphere to the plane or the disk, nor are there any non-constant holomorphic maps from the plane to the disk (although there are plenty of holomorphic maps going in the opposite directions). The complex automorphisms (that is, the complex diffeomorphisms from a surface to itself) of each of the three surfaces can be classified explicitly. The automorphisms of the Riemann sphere turn out to be the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_transformation")[#text("Möbius transformations")]#text(" ")#mi("{z \\mapsto \\frac{az+b}{cz+d}}")#text(" with ")#mi("{ad-bc \\neq 0}")#text(", also known as ")#link("https://en.wikipedia.org/wiki/Linear_fractional_transformation")[#text("fractional linear transformations")]#text(". The automorphisms of the complex plane are the linear transformations ")#mi("{z \\mapsto az+b}")#text(" with ")#mi("{a \\neq 0}")#text(", and the automorphisms of the disk are the fractional linear transformations of the form ")#mi("{z \\mapsto e^{i\\theta} \\frac{\\alpha - z}{1 - \\overline{\\alpha} z}}")#text(" for ")#mi("{\\theta \\in {\\bf R}}")#text(" and ")#mi("{\\alpha \\in D(0,1)}")#text(". Holomorphic maps ")#mi("{f: D(0,1) \\rightarrow D(0,1)}")#text(" from the disk ")#mi("{D(0,1)}")#text(" to itself that fix the origin obey a basic but incredibly important estimate known as the ")#link("https://en.wikipedia.org/wiki/Schwarz_lemma")[#text("Schwarz lemma")]#text(": they are “dominated” by the identity function ")#mi("{z \\mapsto z}")#text(" in the sense that ")#tao-math("{\\left|f(z)\\right| \\leq \\left|z\\right|}", block: false)#text(" for all ")#mi("{z \\in D(0,1)}")#text(". Among other things, this lemma gives guidance to determine when a given Riemann surface is complex diffeomorphic to a disk; we shall discuss this point further below.")#linebreak()#text(" It is a beautiful and fundamental fact in complex analysis that these three model Riemann surfaces are in fact an exhaustive list of the simply connected Riemann surfaces, up to complex diffeomorphism. More precisely, we have the ")#link("https://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Uniformization_theorem")[#text("uniformisation theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Riemann mapping theorem)")]#text(" ")#metadata(none) <tao-804009875b8f14742850>#text(" Let ")#mi("{U}")#text(" be a simply connected open subset of ")#mi("{{\\bf C}}")#text(" that is not all of ")#mi("{{\\bf C}}")#text(". Then ")#mi("{U}")#text(" is complex diffeomorphic to ")#mi("{D(0,1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Uniformisation theorem)")]#text(" ")#metadata(none) <tao-ef379363dd0cb7be6663>#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface. Then ")#mi("{M}")#text(" is complex diffeomorphic to ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", ")#mi("{{\\bf C}}")#text(", or ")#mi("{D(0,1)}")#text(".")
]

#text("As we shall see, every connected Riemann surface can be viewed as the quotient of its simply connected ")#link("https://en.wikipedia.org/wiki/Universal_cover")[#text("universal cover")]#text(" by a discrete group of automorphisms known as ")#link("https://en.wikipedia.org/wiki/Covering_space#Deck_transformation")[#text("deck transformations")]#text(". This in principle gives a complete classification of Riemann surfaces up to complex diffeomorphism, although the situation is still somewhat complicated in the hyperbolic case because of the wide variety of discrete groups of automorphisms available in that case.")#linebreak()#text(" We will prove the Riemann mapping theorem in these notes, using the elegant argument of Koebe that is based on the Schwarz lemma and Montel’s theorem (Exercise 58 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions")[#text("Notes 4")]#text("). The uniformisation theorem is however more difficult to establish; we discuss some components of a proof (based on the ")#link("https://en.wikipedia.org/wiki/Perron_method")[#text("Perron method")]#text(" of subharmonic functions) here, but stop short of providing a complete proof.")#linebreak()#text(" The above theorems show that it is ")#emph[#text("in principle")]#text(" possible to conformally map various domains into model domains such as the unit disk, but the proofs of these theorems do not readily produce ")#emph[#text("explicit")]#text(" conformal maps for this purpose. For some domains we can just write down a suitable such map. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Cayley transform)")]#text(" Let ")#mi("{{\\bf H} := \\{ z \\in {\\bf C}: \\mathrm{Im} z > 0 \\}}")#text(" be the upper half-plane. Show that the ")#link("https://en.wikipedia.org/wiki/Cayley_transform")[#text("Cayley transform")]#text(" ")#mi("{\\phi: {\\bf H} \\rightarrow D(0,1)}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\phi(z) := \\frac{z-i}{z+i},")]]

#text("is a complex diffeomorphism from the upper half-plane ")#mi("{{\\bf H}}")#text(" to the disk ")#mi("{D(0,1)}")#text(", with inverse map ")#mi("{\\phi^{-1}: D(0,1) \\rightarrow {\\bf H}}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("\\phi^{-1}(w) := i \\frac{1+w}{1-w}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-2090ee93ba7ae1ffc3ca>#text(" Show that for any real numbers ")#mi("{a<b}")#text(", the strip ")#mi("{\\{ z \\in {\\bf C}: a < \\mathrm{Re}(z) < b \\}}")#text(" is complex diffeomorphic to the disk ")#mi("{D(0,1)}")#text(". (")#emph[#text("Hint:")]#text(" use the complex exponential and a linear transformation to map the strip onto the half-plane ")#mi("{{\\bf H}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that for any real numbers ")#mi("{a<b<a+2\\pi}")#text(", the strip ")#mi("{\\{ re^{i\\theta}: r>0, a < \\theta < b \\}}")#text(" is complex diffeomorphic to the disk ")#mi("{D(0,1)}")#text(". (")#emph[#text("Hint:")]#text(" use a branch of either the complex logarithm, or of a complex power ")#mi("{z \\mapsto z^\\alpha}")#text(".)")
]

#text("We will discuss some other explicit conformal maps in this set of notes, such as the ")#link("https://en.wikipedia.org/wiki/Schwarz%E2%80%93Christoffel_mapping")[#text("Schwarz-Christoffel maps")]#text(" that transform the upper half-plane ")#mi("{{\\bf H}}")#text(" to polygonal regions. Further examples of conformal mapping can be found in the text of Stein-Shakarchi.")#linebreak()#text(" ")#metadata(none) <tao-a87209d86a5418c612ee>

#heading(level: 1)[#strong[#text(" — 1. Maps between the model Riemann surfaces — ")]]

#text("In this section we study the various holomorphic maps, and conformal maps, between the three model Riemann surfaces ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", ")#mi("{{\\bf C}}")#text(", and ")#mi("{D(0,1)}")#text(".")#linebreak()#text(" From Exercise 20 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(", we know that the only holomorphic maps ")#mi("{f: {\\bf C} \\cup \\{\\infty\\} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" from the Riemann sphere to itself (besides the constant function ")#mi("{\\infty}")#text(") take the form of a rational function ")#mi("{f(z) = P(z) / Q(z)}")#text(" away from the zeroes of ")#mi("{Q}")#text(" (and from ")#mi("{\\infty}")#text("), with these singularities all being removable, and with ")#mi("{Q}")#text(" not identically zero. We can of course reduce to lowest terms and assume that ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" have no common factors. In particular, if ")#mi("{f}")#text(" is to take values in ")#mi("{{\\bf C}}")#text(" rather than ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", then ")#mi("{Q}")#text(" can have no roots (since ")#mi("{f}")#text(" will have a pole at these roots) and so by the fundamental theorem of algebra ")#mi("{Q}")#text(" is constant and ")#mi("{f}")#text(" is a polynomial; in order for ")#mi("{f}")#text(" to have no pole at infinity, ")#mi("{f}")#text(" must then be constant. Thus the only holomorphic maps from ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to ")#mi("{{\\bf C}}")#text(" are the constants; in particular, the only holomorphic maps from ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to ")#mi("{D(0,1)}")#text(" are the constants. In particular, ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" is not complex diffeomorphic to ")#mi("{{\\bf C}}")#text(" or ")#mi("{D(0,1)}")#text(" (this is also topologically obvious since the Riemann sphere is compact, and ")#mi("{{\\bf C}}")#text(" and ")#mi("{D(0,1)}")#text(" are not).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" More generally, show that if ")#mi("{M}")#text(" is a connected compact Riemann surface and ")#mi("{N}")#text(" is a connected non-compact Riemann surface, then the only holomorphic maps from ")#mi("{M}")#text(" to ")#mi("{N}")#text(" are the constants. (")#emph[#text("Hint:")]#text(" use the open mapping theorem, Theorem 38 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(".)")
]

#text("Now we consider complex automorphisms of the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to itself. There are some obvious examples of such automorphisms:")

#list(
[#emph[#text("Translation maps")]#text(" ")#mi("{z \\mapsto z + c}")#text(" for some ")#mi("{c \\in {\\bf C}}")#text(", with the convention that ")#mi("{\\infty}")#text(" is mapped to ")#mi("{\\infty}")#text(";")],
[#emph[#text("Dilation maps")]#text(" ")#mi("{z \\mapsto \\lambda z}")#text(" for some ")#mi("{\\lambda \\in {\\bf C} \\backslash \\{0\\}}")#text(", with the convention that ")#mi("{\\infty}")#text(" is mapped to ")#mi("{\\infty}")#text("; and")],
[#text("The ")#emph[#text("inversion map")]#text(" ")#mi("{z \\mapsto 1/z}")#text(", with the convention that ")#mi("{\\infty}")#text(" is mapped to ")#mi("{0}")#text(".")]
)

#text("More generally, given any complex numbers ")#mi("{a,b,c,d}")#text(" with ")#mi("{ad-bc \\neq 0}")#text(", we can define the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_transformation")[#text("Möbius transformation")]#text(" (or ")#emph[#text("fractional linear transformation")]#text(") ")#mi("{z \\mapsto \\frac{az+b}{cz+d}}")#text(" for ")#mi("{z \\neq \\infty, -d/c}")#text(", with the convention that ")#mi("{-d/c}")#text(" is mapped to ")#mi("{\\infty}")#text(" and ")#mi("{\\infty}")#text(" is mapped to ")#mi("{a/c}")#text(" (where we adopt the further convention that ")#mi("{a/0=\\infty}")#text(" for non-zero ")#mi("{a}")#text("). For ")#mi("{c=0}")#text(", this is an affine transformation ")#mi("{z \\mapsto \\frac{a}{d} z + \\frac{b}{d}}")#text(", which is clearly a composition of a translation and dilation map; for ")#mi("{c \\neq 0}")#text(", this is a combination ")#mi("{z \\mapsto \\frac{a}{c} - \\frac{ad-bc}{cz+d}}")#text(" of translations, dilations, and the inversion map. Thus all Möbius transformations are formed from composition of the translations, dilations, and inversions, and in particular are also automorphisms of the Riemann sphere; it is also easy to see that the Möbius transformations are closed under composition, and are thus the group generated by the translations, dilations, and inversions.")#linebreak()#text(" One can interpret the Möbius transformations as ")#link("https://en.wikipedia.org/wiki/Projective_linear_group")[#text("projective linear transformations")]#text(" as follows. Recall that the ")#link("https://en.wikipedia.org/wiki/General_linear_group")[#text("general linear group")]#text(" ")#mi("{GL_2({\\bf C})}")#text(" is the group of ")#mi("{2 \\times 2}")#text(" matrices ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" with non-vanishing determinant ")#mi("{ad-bc}")#text(". Clearly every such matrix generates a Möbius transformation ")#mi("{z \\mapsto \\frac{az+b}{cz+d}}")#text(". However, two different elements of ")#mi("{GL_2({\\bf C})}")#text(" can generate the same Möbius transformation if they are scalar multiples of each other. If we define the ")#link("https://en.wikipedia.org/wiki/Projective_linear_group")[#text("projective linear group")]#text(" ")#mi("{PGL_2({\\bf C})}")#text(" to be the quotient group of ")#mi("{GL_2({\\bf C})}")#text(" by the group of scalar invertible matrices, then we may identify the set of Möbius transformations with ")#mi("{PGL_2({\\bf C})}")#text(". The group ")#mi("{GL_2({\\bf C})}")#text(" acts on the space ")#mi("{{\\bf C}^2}")#text(" by the usual map")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\begin{pmatrix} z \\\\ w \\end{pmatrix} = \\begin{pmatrix} az+bw \\\\ cz+dw \\end{pmatrix}.")]]

#text("If we let ")#mi("{{\\bf CP}^1}")#text(" be the complex ")#link("https://en.wikipedia.org/wiki/Projective_space")[#text("projective line")]#text(", that is to say the space of one-dimensional subspaces of ")#mi("{{\\bf C}^2}")#text(", then ")#mi("{GL_2({\\bf C})}")#text(" acts on this space also, with the action of the scalars being trivial, so we have an action of ")#mi("{PGL_2({\\bf C})}")#text(" on ")#mi("{{\\bf CP}^1}")#text(". We can identify the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" with the complex projective line by identifying each ")#mi("{c \\in {\\bf C} \\subset {\\bf C} \\cup \\{\\infty\\}}")#text(" with the one-dimensional subspace ")#mi("{\\{ (cw,w): w \\in {\\bf C} \\}}")#text(" of ")#mi("{{\\bf C}^2}")#text(", and identifying ")#mi("{\\infty \\in {\\bf C} \\cup \\{\\infty\\}}")#text(" with ")#mi("{\\{ (z,0): z \\in {\\bf C}\\}}")#text(". With this identification, one can check that the action of ")#mi("{PGL_2({\\bf C})}")#text(" on ")#mi("{{\\bf CP}^1}")#text(" has become identified with the action of the group of Möbius transformations on ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". (In particular, the group of Möbius transformations is isomorphic to ")#mi("{PGL_2({\\bf C})}")#text(".)")#linebreak()#text(" There are enough Möbius transformations available that their action on the Riemann sphere is not merely ")#link("https://en.wikipedia.org/wiki/Group_action#Types_of_actions")[#text("transitive")]#text(", but is in fact ")#mi("{3}")#text("-transitive:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (")#mi("{3}")#text("-transitivity)")]#text(" ")#metadata(none) <tao-0aa096ad9e737ef3cb1c>#text(" Let ")#mi("{z_1,z_2,z_3}")#text(" be distinct elements of the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", and let ")#mi("{w_1,w_2,w_3}")#text(" also be three distinct elements of the Riemann sphere. Then there exists a unique Möbius transformation ")#mi("{T}")#text(" such that ")#mi("{T(z_j) = w_j}")#text(" for ")#mi("{j=1,2,3}")#text(".")
]

#emph[#text("Proof:")]#text(" We first show existence. As the Möbius transformations form a group, it suffices to verify the claim for a single choice of ")#mi("{z_1,z_2,z_3}")#text(", for instance ")#mi("{z_1 = 0, z_2 = 1, z_3 = \\infty}")#text(". If ")#mi("{w_3=\\infty}")#text(" then the affine transformation ")#mi("{z \\mapsto w_1 + z(w_2-w_1)}")#text(" will have the desired properties. If ")#mi("{w_3 \\neq \\infty}")#text(", we can use translation and inversion to find a Möbius transformation ")#mi("{S}")#text(" that maps ")#mi("{w_3}")#text(" to ")#mi("{\\infty}")#text("; applying the previous case with ")#mi("{w_1,w_2,w_3}")#text(" with ")#mi("{S(w_1), S(w_2), S(w_3)}")#text(" and then applying ")#mi("{S^{-1}}")#text(", we obtain the claim.")#linebreak()#text(" Now we prove uniqueness. By composing on the left and right with Möbius transforms we may assume that ")#mi("{z_1=w_1=0, z_2=w_2=1, z_3=w_3=\\infty}")#text(". A Möbius transformation ")#mi("{z \\mapsto \\frac{az+b}{cz+d}}")#text(" that fixes ")#mi("{0,1,\\infty}")#text(" must obey the constraints ")#mi("{b=0, a+b=c+d, c=0}")#text(" and so must be the identity, as required. ")#mi("\\Box")#linebreak()#text(" Möbius transformations are not 4-transitive, thanks to the invariant known as the ")#link("https://en.wikipedia.org/wiki/Cross-ratio")[#text("cross-ratio")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Define the ")#emph[#text("cross-ratio")]#text(" ")#mi("{[z_1,z_2; z_3,z_4]}")#text(" between four distinct points ")#mi("{z_1,z_2,z_3,z_4}")#text(" on the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("[z_1,z_2; z_3,z_4] = \\frac{(z_1-z_3)(z_2-z_4)}{(z_2-z_3)(z_1-z_4)}")]]

#text("if all of ")#mi("{z_1,z_2,z_3,z_4}")#text(" avoid ")#mi("{\\infty}")#text(", and extended continuously to the case when one of the points equals ")#mi("{\\infty}")#text(" (e.g. ")#mi("{[z_1,z_2;z_3,\\infty] = \\frac{z_1-z_3}{z_2-z_3}}")#text(").")

#list(
[#text("(i) Show that an injective map ")#mi("{T: {\\bf C} \\cup \\{\\infty\\} \\rightarrow {\\bf C} \\rightarrow \\{\\infty\\}}")#text(" is a Möbius transform if and only if it preserves the cross-ratio, that is to say that ")#mi("{[T(z_1),T(z_2);T(z_3),T(z_4)] = [z_1,z_2;z_3,z_4]}")#text(" for all distinct points ")#mi("{z_1,z_2,z_3,z_4 \\in {\\bf C} \\cup \\{\\infty\\}}")#text(". (")#emph[#text("Hint:")]#text(" for the “only if” part, work with the basic Möbius transforms. For the “if” part, reduce to the case when ")#mi("{T}")#text(" fixes three points, such as ")#mi("{0,1,\\infty}")#text(".)")],
[#text("(ii) If ")#mi("{z_1,z_2,z_3,z_4}")#text(" are distinct points in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", show that ")#mi("{z_1,z_2,z_3,z_4}")#text(" lie on a common extended line (i.e., a line in ")#mi("{{\\bf C}}")#text(" together with ")#mi("{\\infty}")#text(") or circle in ")#mi("{{\\bf C}}")#text(" if and only if the cross-ratio ")#mi("{[z_1,z_2;z_3,z_4]}")#text(" is real. Conclude that a Möbius transform will map an extended line or circle to an extended line or circle.")]
)
]

#text("As one quick application of Möbius transformations, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" is simply connected.")
]

#emph[#text("Proof:")]#text(" We have to show that any closed curve ")#mi("{\\gamma}")#text(" in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" is contractible to a point in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". By deforming ")#mi("{\\gamma}")#text(" locally into line segments in either of the two standard coordinate charts of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" we may assume that ")#mi("{\\gamma}")#text(" is the concatenation of finitely many such line segments; in particular, ")#mi("{\\gamma}")#text(" cannot be a ")#link("https://en.wikipedia.org/wiki/Space-filling_curve")[#text("space-filling curve")]#text(" (as one can see from e.g. the ")#link("https://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(") and thus avoids at least one point in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". If ")#mi("{\\gamma}")#text(" avoids ")#mi("{\\infty}")#text(" then it lies in ")#mi("{{\\bf C}}")#text(" and can thus be contracted to a point in ")#mi("{{\\bf C}}")#text(" (and hence in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(") since ")#mi("{{\\bf C}}")#text(" is convex. If ")#mi("{\\gamma}")#text(" avoids any other point ")#mi("{z_0}")#text(", then we can apply a Möbius transformation to move ")#mi("{z_0}")#text(" to ")#mi("{\\infty}")#text(", contract the transformed curve to a point, and then invert the Möbius transform to contract ")#mi("{\\gamma}")#text(" to a point in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Jordan curve theorem in the Riemann sphere)")]#text(" Let ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" be a simple closed curve in the Riemann sphere. Show that the complement of ")#mi("{\\gamma([a,b])}")#text(" in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" is the union of two disjoint simply connected open subsets of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". (")#emph[#text("Hint:")]#text(" one first has to exclude the possibility that ")#mi("{\\gamma}")#text(" is space-filling. Do this by verifying that ")#mi("{\\gamma([a,b])}")#text(" is homeomorphic to the unit circle.)")
]

#text("It turns out that there are no other automorphisms of the Riemann sphere than the Möbius transformations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 14 (Automorphisms of Riemann sphere)")]#text(" ")#metadata(none) <tao-28720365c5e7476a011e>#text(" Let ")#mi("{T: {\\bf C} \\cup \\{\\infty\\} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" be a complex diffeomorphism. Then ")#mi("{T}")#text(" is a Möbius transformation.")
]

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-0aa096ad9e737ef3cb1c>)[#text("10")]#text(" and composing ")#mi("{T}")#text(" with a Möbius transformation, we may assume without loss of generality that ")#mi("{T}")#text(" fixes ")#mi("{0,1,\\infty}")#text(". From Exercise 20 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(" we know that ")#mi("{T}")#text(" is a rational function ")#mi("{T(z) = P(z)/Q(z)}")#text(" (with all singularities removed); we may reduce terms so that ")#mi("{P,Q}")#text(" have no common factors. Since ")#mi("{T}")#text(" is bijective and fixes ")#mi("{\\infty}")#text(", it has no poles in ")#mi("{{\\bf C}}")#text(", and hence ")#mi("{Q}")#text(" can have no roots; by the fundamental theorem of algebra, this makes ")#mi("{Q}")#text(" constant. Similarly, ")#mi("{P}")#text(" has no zeroes other than ")#mi("{0}")#text(", and so must be a monomial; as ")#mi("{T}")#text(" also fixes ")#mi("{1}")#text(", it must be of the form ")#mi("{T(z) = z^n}")#text(" for some natural number ")#mi("{n}")#text(". But this is only injective if ")#mi("{n=1}")#text(", in which case ")#mi("{T}")#text(" is clearly a Möbius transformation. ")#mi("\\Box")#linebreak()#text(" Now we look at holomorphic maps on ")#mi("{{\\bf C}}")#text(". There are plenty of holomorphic maps from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf C}}")#text("; indeed, these are nothing more than the entire functions, of which there are many (indeed, an entire function is nothing more than a power series with an infinite radius of convergence). There are even more holomorphic maps from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", as these are just the meromorphic functions on ")#mi("{{\\bf C}}")#text(". For instance, any ratio ")#mi("{f/g}")#text(" of two entire functions, with ")#mi("{g}")#text(" not identically zero, will be meromorphic on ")#mi("{{\\bf C}}")#text(". On the other hand, from Liouville’s theorem (Theorem 28 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") we see that the only holomorphic maps from ")#mi("{{\\bf C}}")#text(" to ")#mi("{D(0,1)}")#text(" are the constants. In particular, ")#mi("{{\\bf C}}")#text(" and ")#mi("{D(0,1)}")#text(" are not complex diffeomorphic (despite the fact that they are diffeomorphic over the reals, as can be seen for instance by using the projection ")#tao-math("{z \\mapsto \\frac{z}{\\sqrt{1+\\left|z\\right|^2}}}", block: false)#text(").")#linebreak()#text(" The affine maps ")#mi("{z \\mapsto az+b}")#text(" with ")#mi("{a \\in {\\bf C} \\backslash \\{0\\}}")#text(" and ")#mi("{b \\in {\\bf C}}")#text(" are clearly complex automorphisms on ")#mi("{{\\bf C}}")#text(". In analogy with Proposition ")#link(<tao-28720365c5e7476a011e>)[#text("14")]#text(", these turn out to be the only automorphisms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 15 (Automorphisms of complex plane)")]#text(" ")#metadata(none) <tao-0cfd796f24f1965dca77>#text(" Let ")#mi("{T: {\\bf C} \\rightarrow {\\bf C}}")#text(" be a complex diffeomorphism. Then ")#mi("{T}")#text(" is an affine transformation ")#mi("{T(z) = az+b}")#text(" for some ")#mi("{a \\in {\\bf C} \\backslash \\{0\\}}")#text(" and ")#mi("{b \\in {\\bf C}}")#text(".")
]

#emph[#text("Proof:")]#text(" By the open mapping theorem (Theorem 38 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text("), ")#mi("{T(D(0,1))}")#text(" is open, and hence ")#mi("{T}")#text(" avoids the non-empty open set ")#mi("{T(D(0,1))}")#text(" on ")#mi("{{\\bf C} \\backslash D(0,1)}")#text(". By the Casorati-Weierstrass theorem (Theorem 12 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text("), we conclude that ")#mi("{T}")#text(" does not have an essential singularity at infinity. Thus ")#mi("{T}")#text(" extends to a holomorphic function from ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", hence by Exercise 20 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(" is rational. As the only pole of ")#mi("{T}")#text(" is at infinity, ")#mi("{T}")#text(" is a polynomial; as ")#mi("{T}")#text(" is a diffeomorphism, the derivative has no zeroes and is thus constant by the fundamental theorem of algebra. Thus ")#mi("{T}")#text(" must be affine, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" be an injective holomorphic map. Show that ")#mi("{f}")#text(" is a Möbius transformation (restricted to ")#mi("{{\\bf C}}")#text(").")
]

#text("We remark that injective holomorphic maps are often referred to as ")#link("https://en.wikipedia.org/wiki/Univalent_function")[#text("univalent functions")]#text(" in the literature.")#linebreak()#text(" Finally, we consider holomorphic maps on ")#mi("{D(0,1)}")#text(". There are plenty of holomorphic maps from ")#mi("{D(0,1)}")#text(" to ")#mi("{{\\bf C}}")#text(" (indeed, these are just the power series with radius of convergence at least ")#mi("{1}")#text("), and even more holomorphic maps from ")#mi("{D(0,1)}")#text(" to ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" (for instance, one can take the quotient of two holomorphic functions ")#mi("{f,g: D(0,1) \\rightarrow {\\bf C}}")#text(" with ")#mi("{g}")#text(" non-zero). There are also many holomorphic maps from ")#mi("{D(0,1)}")#text(" to ")#mi("{D(0,1)}")#text(", for instance one can take any bounded holomorphic function ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" and multiply it by a small constant. However, we have the following fundamental estimate concerning such functions, the ")#link("https://en.wikipedia.org/wiki/Schwarz_lemma")[#text("Schwarz lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17 (Schwarz lemma)")]#text(" ")#metadata(none) <tao-2993f8453f06da87d9df>#text(" Let ")#mi("{f: D(0,1) \\rightarrow D(0,1)}")#text(" be a holomorphic map such that ")#mi("{f(0)=0}")#text(". Then we have ")#tao-math("{\\left|f(z)\\right| \\leq \\left|z\\right|}", block: false)#text(" for all ")#mi("{z \\in D(0,1)}")#text(". In particular, ")#tao-math("{\\left|f^{\\prime}(0)\\right| \\leq 1}", block: false)#text(".")#linebreak()#text(" Furthermore, if ")#tao-math("{\\left|f(z)\\right|=\\left|z\\right|}", block: false)#text(" for some ")#mi("{z \\in D(0,1) \\backslash \\{0\\}}")#text(", or if ")#tao-math("{\\left|f^{\\prime}(0)\\right|=1}", block: false)#text(", then there exists a real number ")#mi("{\\theta}")#text(" such that ")#mi("{f(z) = e^{i \\theta} z}")#text(" for all ")#mi("{z \\in D(0,1)}")#text(".")
]

#emph[#text("Proof:")]#text(" By the factor theorem (Corollary 22 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), we may write ")#mi("{f(z) = z g(z)}")#text(" for some holomorphic ")#mi("{g: D(0,1) \\rightarrow {\\bf C}}")#text(". On any circle ")#tao-math("{\\{ z: \\left|z\\right| = 1-\\varepsilon \\}}", block: false)#text(" with ")#mi("{0 < \\varepsilon < 1}")#text(", we have ")#tao-math("{\\left|f(z)\\right| <1}", block: false)#text(" and hence ")#tao-math("{\\left|g(z)\\right| < \\frac{1}{1-\\varepsilon}}", block: false)#text("; by the maximum principle we conclude that ")#tao-math("{\\left|g(z)\\right| \\leq \\frac{1}{1-\\varepsilon}}", block: false)#text(" for all ")#mi("{z \\in D(0,1-\\varepsilon)}")#text(". Sending ")#mi("{\\varepsilon}")#text(" to zero, we conclude that ")#tao-math("{\\left|g(z)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{z \\in D(0,1)}")#text(", and hence ")#tao-math("{\\left|f(z)\\right| \\leq \\left|z\\right|}", block: false)#text(" and ")#tao-math("{\\left|f^{\\prime}(0)\\right| \\leq 1}", block: false)#text(".")#linebreak()#text(" Finally, if ")#tao-math("{\\left|f(z)\\right|=\\left|z\\right|}", block: false)#text(" for some ")#mi("{z \\in D(0,1) \\backslash \\{0\\}}")#text(" or ")#tao-math("{\\left|f^{\\prime}(0)\\right|=1}", block: false)#text(", then ")#tao-math("{\\left|g(z)\\right|}", block: false)#text(" equals ")#mi("{1}")#text(" for some ")#mi("{z \\in D(0,1)}")#text(", and hence by a variant of the maximum principle (see Exercise ")#link(<tao-9baf3a40312f39849f46>)[#text("18")]#text(" below) we see that ")#mi("{g}")#text(" is constant, giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Variant of maximum principle)")]#text(" ")#metadata(none) <tao-9baf3a40312f39849f46>#text(" Let ")#mi("{U}")#text(" be a connected Riemann surface, and let ")#mi("{z_0}")#text(" be a point in ")#mi("{U}")#text(".")

#list(
[#text("(i) If ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" is a harmonic function such that ")#mi("{u(z) \\leq u(z_0)}")#text(" for all ")#mi("{z \\in U}")#text(", then ")#mi("{u(z) = u(z_0)}")#text(" for all ")#mi("{z \\in U}")#text(".")],
[#text("(ii) If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is a holomorphic function such that ")#tao-math("{\\left|f(z)\\right| \\leq \\left|f(z_0)\\right|}", block: false)#text(" for all ")#mi("{z \\in U}")#text(", then ")#mi("{f(z) = f(z_0)}")#text(" for all ")#mi("{z \\in U}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" use Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(" .)")
]

#text("One can think of the Schwarz lemma as follows. Let ")#mi("{{\\mathcal H}_0}")#text(" denote the collection of holomorphic functions ")#mi("{f: D(0,1) \\rightarrow D(0,1)}")#text(" with ")#mi("{f(0)=0}")#text(". Inside this collection we have the rotations ")#mi("{R_\\theta: D(0,1) \\rightarrow D(0,1)}")#text(" for ")#mi("{\\theta \\in {\\bf R}}")#text(" defined by ")#mi("{R_\\theta(z) :=e^{i\\theta} z}")#text(". The Schwarz lemma asserts that these rotations “dominate” the remaining functions ")#mi("{f}")#text(" in ")#mi("{{\\mathcal H}_0}")#text(" in the sense that ")#tao-math("{\\left|f(z)\\right| \\leq \\left|R_\\theta(z)\\right|}", block: false)#text(" on ")#mi("{D(0,1) \\backslash \\{0\\}}")#text(", and in particular ")#tao-math("{\\left|f^{\\prime}(z)\\right| \\leq \\left|R^{\\prime}_\\theta(z)\\right|}", block: false)#text("; furthermore these inequalities are strict as long as ")#mi("{f}")#text(" is not one of the ")#mi("{R_\\theta}")#text(".")#linebreak()#text(" As a first application of the Schwarz lemma, we characterise the automorphisms of the disk ")#mi("{D(0,1)}")#text(". For any ")#mi("{\\alpha \\in D(0,1)}")#text(", one can check that the Möbius transformation ")#mi("{z \\mapsto \\frac{z-\\alpha}{1-\\overline{\\alpha} z}}")#text(" preserves the boundary of the disk ")#mi("{D(0,1)}")#text(" (since ")#mi("{1 - \\overline{\\alpha} z = z \\overline{(z-\\alpha)}}")#text(" when ")#tao-math("{\\left|z\\right|=1}", block: false)#text("), and maps the point ")#mi("{\\alpha}")#text(" to the origin, and thus maps the disk ")#mi("{D(0,1)}")#text(" to itself. More generally, for any ")#mi("{\\alpha \\in D(0,1)}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text(", the Möbius transformation ")#mi("{z \\mapsto e^{i\\theta} \\frac{z-\\alpha}{1-\\overline{\\alpha} z}}")#text(" is an automorphism of the disk ")#mi("{D(0,1)}")#text(". It turns out that these are the only such automorphisms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 19 (Automorphisms of disk)")]#text(" Let ")#mi("{f: D(0,1) \\rightarrow D(0,1)}")#text(" be a complex diffeomorphism. Then there exists ")#mi("{\\alpha \\in D(0,1)}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text(" such that ")#mi("{f(z) = e^{i\\theta} \\frac{z-\\alpha}{1-\\overline{\\alpha} z}}")#text(" for all ")#mi("{z \\in D(0,1)}")#text(". If furthermore ")#mi("{f(0)=0}")#text(", then we can take ")#mi("{\\alpha=0}")#text(", thus ")#mi("{f(z) =e^{i\\theta} z}")#text(" for ")#mi("{z \\in D(0,1)}")#text(".")
]

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{f(0)=0}")#text(". By the Schwarz lemma applied to both ")#mi("{f}")#text(" and its inverse ")#mi("{f^{-1}}")#text(", we see that ")#tao-math("{\\left|f^{\\prime}(0)\\right|, \\left|(f^{-1})^{\\prime}(0)\\right| \\leq 1}", block: false)#text(". But by the inverse function theorem (or the chain rule), ")#mi("{(f^{-1})^{\\prime}(0) = 1/f^{\\prime}(0)}")#text(", hence ")#tao-math("{\\left|f^{\\prime}(0)\\right|=1}", block: false)#text(". Applying the Schwarz lemma again, we conclude that ")#mi("{f(z) = e^{i\\theta} z}")#text(" for some ")#mi("{\\theta}")#text(", as required.")#linebreak()#text(" In the general case, there exists ")#mi("{\\alpha \\in D(0,1)}")#text(" such that ")#mi("{f(\\alpha) = 0}")#text(". If one then applies the previous analysis to ")#mi("{f \\circ g^{-1}}")#text(", where ")#mi("{g: D(0,1) \\rightarrow D(0,1)}")#text(" is the automorphism ")#mi("{g(z) := \\frac{z-\\alpha}{1-\\overline{\\alpha} z}}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Automorphisms of half-plane)")]#text(" ")#metadata(none) <tao-05b774dc2a4b086d2ae3>#text(" Let ")#mi("{f: {\\bf H} \\rightarrow {\\bf H}}")#text(" be a complex diffeomorphism from the upper half-plane ")#mi("{{\\bf H} := \\{z \\in {\\bf C}: \\mathrm{Im}(z) > 0 \\}}")#text(" to itself. Show that there exist real numbers ")#mi("{a,b,c,d}")#text(" with ")#mi("{ad-bc = 1}")#text(" such that ")#mi("{f(z) = \\frac{az+b}{cz+d}}")#text(" for ")#mi("{z \\in {\\bf H}}")#text(". Conclude that the automorphism group of either ")#mi("{D(0,1)}")#text(" or ")#mi("{{\\bf H}}")#text(" is isomorphic as a group to the ")#link("https://en.wikipedia.org/wiki/Projective_linear_group")[#text("projective special linear group")]#text(" ")#mi("{PSL_2({\\bf R})}")#text(" formed by starting with the ")#link("https://en.wikipedia.org/wiki/Special_linear_group")[#text("special linear group")]#text(" ")#mi("{SL_2({\\bf R})}")#text(" of ")#mi("{2 \\times 2}")#text(" real matrices ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" of determinant ")#mi("{1}")#text(", and then quotienting out by the ")#link("https://en.wikipedia.org/wiki/Central_subgroup")[#text("central subgroup")]#text(" ")#mi("{\\{ \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix} -1 & 0 \\\\ 0 & -1 \\end{pmatrix} \\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" Collecting the various assertions above about the holomorphic maps between the elliptic, parabolic, and hyperbolic model Riemann surfaces ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", ")#mi("{{\\bf C}}")#text(", ")#mi("{D(0,1)}")#text(", one arrives at the following rule of thumb: there are “many” holomorphic maps from “more hyperbolic” surfaces to “less hyperbolic” surfaces, but “very few” maps going in the other direction (and also relatively few automorphisms from one space to an “equally hyperbolic” surface). This rule of thumb also turns out to be accurate in the context of compact Riemann surfaces, where “higher ")#link("https://en.wikipedia.org/wiki/Genus_(mathematics)")[#text("genus")]#text("” becomes the analogue of “more hyperbolic” (and similarly for “less hyperbolic” or “equally hyperbolic”). One can formalise this latter version of the rule of thumb using such results as the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Hurwitz_formula")[#text("Riemann-Hurwitz formula")]#text(" and the ")#link("https://en.wikipedia.org/wiki/De_Franchis_theorem")[#text("de Franchis theorem")]#text(", but these are beyond the scope of this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{f: M \\rightarrow N}")#text(" be a non-constant holomorphic map between Riemann surfaces ")#mi("{M,N}")#text(". If ")#mi("{M}")#text(" is compact connected and ")#mi("{N}")#text(" is connected, show that ")#mi("{f}")#text(" is surjective and ")#mi("{N}")#text(" is compact. Conclude in particular that there are no non-constant bounded holomorphic functions ")#mi("{f: M \\rightarrow {\\bf C}}")#text(" on a compact connected Riemann surface.")
]

#heading(level: 1)[#strong[#text(" — 2. Quotients of the model Riemann surfaces — ")]]

#text("The three model Riemann surfaces ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", ")#mi("{{\\bf C}}")#text(", ")#mi("{D(0,1)}")#text(" are all simply connected, and the uniformisation theorem will tell us that up to complex diffeomorphism, these are the ")#emph[#text("only")]#text(" simply connected Riemann surfaces that exist. However, it is possible to form non-simply-connected Riemann surfaces from these model surfaces by the procedure of taking ")#emph[#text("quotients")]#text(", as follows. Let ")#mi("{M}")#text(" be a Riemann surface, and let ")#mi("{\\Gamma}")#text(" be a group of complex automorphisms of ")#mi("{M}")#text(". We assume that the action of ")#mi("{\\Gamma}")#text(" on ")#mi("{M}")#text(" is ")#link("https://en.wikipedia.org/wiki/Group_action")[#text("free")]#text(", which means that the non-identity transformations ")#mi("{T: M \\rightarrow M}")#text(" in ")#mi("{\\Gamma}")#text(" have no fixed points (thus ")#mi("{T p \\neq p}")#text(" for all ")#mi("{p \\in M}")#text("). We also assume that the action is ")#emph[#text("proper")]#text(" (viewing ")#mi("{\\Gamma}")#text(" as a discrete group), which means that for any compact subset ")#mi("{K}")#text(" of ")#mi("{M}")#text(", there are only finitely many automorphisms ")#mi("{T}")#text(" in ")#mi("{\\Gamma}")#text(" for which ")#mi("{TK}")#text(" intersects ")#mi("{K}")#text(". If the action is both free and proper, then we see that every point ")#mi("{p \\in M}")#text(" has a small neighbourhood ")#mi("{U_p}")#text(" with the property that the images ")#mi("{TU_p, T \\in \\Gamma}")#text(" are all disjoint; by making ")#mi("{U_p}")#text(" small enough we can also find a holomorphic coordinate chart ")#mi("{\\phi_p: U_p \\rightarrow V_p}")#text(" to some open subset ")#mi("{V_p}")#text(" of ")#mi("{{\\bf C}}")#text(". We can then form the quotient manifold ")#mi("{\\Gamma \\backslash M}")#text(" of orbits ")#mi("{\\Gamma p := \\{ Tp: T \\in \\Gamma\\}}")#text(", using the coordinate charts ")#mi("{\\tilde \\phi_p: \\Gamma \\backslash \\bigcup_{T \\in \\Gamma} TU_p \\rightarrow V_p}")#text(" for any ")#mi("{p \\in M}")#text(" defined by setting")

#align(center)[#tao-fit-display[#mitex("\\tilde \\phi_p( \\Gamma q ) := \\phi_p( q )")]]

#text("for all ")#mi("{q \\in U_p}")#text(". One can easily verify that ")#mi("{\\Gamma \\backslash M}")#text(" is a Riemann surface, and that the quotient map ")#mi("{\\pi: M \\rightarrow \\Gamma \\backslash M}")#text(" defined by ")#mi("{\\pi(p) := \\Gamma p}")#text(" is a surjective holomorphic covering map. The ability to easily take quotients is one of the key advantages of the Riemann surface formalism; another is the converse ability to construct covers, such as the universal cover of a Riemann surface, defined in Theorem ")#link(<tao-dbdbc8ce6333f81b460c>)[#text("25")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-586abb54469a8ddcc161>#text(" Let ")#mi("{M}")#text(" be a Riemann surface, ")#mi("{\\Gamma}")#text(" a group of complex automorphisms of ")#mi("{M}")#text(" acting in a proper and free fashion, and let ")#mi("{\\pi: M \\rightarrow \\Gamma \\backslash M}")#text(" be the quotient map. Let ")#mi("{f: M \\rightarrow N}")#text(" be a holomorphic map to another Riemann surface ")#mi("{N}")#text(". Show that there exists a holomorphic map ")#mi("{\\tilde f: \\Gamma \\backslash M \\rightarrow N}")#text(" such that ")#mi("{f = \\tilde f \\circ \\pi}")#text(" if and only if ")#mi("{f = f \\circ T}")#text(" for all ")#mi("{T \\in \\Gamma}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 24")]#text(" It is also of interest to quotient a Riemann surface ")#mi("{M}")#text(" by a group ")#mi("{\\Gamma}")#text(" of complex automorphisms whose action is not free. In that case, the quotient space ")#mi("{\\Gamma \\backslash M}")#text(" might ")#emph[#text("a priori")]#text(" fail to be a manifold, but instead be a more general object known as an ")#link("https://en.wikipedia.org/wiki/Orbifold")[#text("orbifold")]#text(". A typical example is the ")#link("https://en.wikipedia.org/wiki/Modular_curve")[#text("modular curve")]#text(" ")#mi("{SL_2({\\bf Z}) \\backslash {\\bf H}}")#text(" (where ")#mi("{SL_2({\\bf Z})}")#text(" is the group of ")#mi("{2 \\times 2}")#text(" matrices with integer coefficients and determinant ")#mi("{1}")#text("); this is of great importance in analytic number theory. However, we will not study orbifolds in this course (and in the case of quotients of Riemann surfaces, it turns out that these quotients still fortunately turn out to be Riemann surfaces).")
]

#text("Since the continuous image of a connected space is always connected, we see that any quotient ")#mi("{\\Gamma \\backslash M}")#text(" of a connected Riemann surface is again connected. In the converse direction, one can use this construction to describe a connected Riemann surface as a quotient of a simply connected Riemann surface:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Universal cover)")]#text(" ")#metadata(none) <tao-dbdbc8ce6333f81b460c>#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface. Then there exists a simply connected Riemann surface ")#mi("{N}")#text(", and a group ")#mi("{\\Gamma}")#text(" of complex automorphisms acting on ")#mi("{N}")#text(" in a proper and free fashion, such that ")#mi("{M}")#text(" is complex diffeomorphic to ")#mi("{\\Gamma \\backslash N}")#text(".")
]

#emph[#text("Proof:")]#text(" For sake of brevity we omit some of the details of the construction as exercises.")#linebreak()#text(" We use the following abstract construction to build the Riemann surface ")#mi("{N}")#text(". Fix a base point ")#mi("{p_0}")#text(" in ")#mi("{M}")#text(". For any point ")#mi("{p}")#text(" in ")#mi("{M}")#text(", we can form the space of all continuous paths ")#mi("{\\gamma: [a,b] \\rightarrow M}")#text(" from ")#mi("{p_0}")#text(" to ")#mi("{p}")#text(" for some interval ")#mi("{[a,b]}")#text(" with ")#mi("{a<b}")#text(". We let ")#mi("{N_p}")#text(" denote the space of equivalence classes of such paths with respect to the operation of homotopy with fixed endpoints up to reparameterisation; for instance, if ")#mi("{M}")#text(" was simply connected, then ")#mi("{N_p}")#text(" would simply be a point. (One could also omit the reparameterisation by restricting the domain of ")#mi("{\\gamma}")#text(" to be a fixed interval such as ")#mi("{[0,1]}")#text(".) As ")#mi("{M}")#text(" is connected, all the ")#mi("{N_p}")#text(" are non-empty. We then let ")#mi("{N}")#text(" be the (disjoint) union of all the ")#mi("{N_p}")#text(". This defines a set ")#mi("{N}")#text(" together with a projection map ")#mi("{\\pi: N \\rightarrow M}")#text(" that sends all the homotopy classes in ")#mi("{N_p}")#text(" to ")#mi("{p}")#text(" for each ")#mi("{p \\in M}")#text("; this is clearly a surjective map.")#linebreak()#text(" This defines ")#mi("{N}")#text(" as a set, but we want to give ")#mi("{N}")#text(" the structure of a Riemann surface, and thus must create an atlas of coordinate charts. For every ")#mi("{p \\in M}")#text(", let ")#mi("{\\phi_p: U_p \\rightarrow D(0,1)}")#text(" be a coordinate chart that is a diffeomorphism between some neighbourhood ")#mi("{U_p}")#text(" of ")#mi("{p}")#text(" and the unit disk. Given a homotopy class ")#mi("{\\tilde p}")#text(" in ")#mi("{N_p}")#text(" and a point ")#mi("{p^{\\prime}}")#text(" in ")#mi("{U_p}")#text(", we can then associate a point ")#mi("{\\tilde p^{\\prime}}")#text(" in ")#mi("{N_{p^{\\prime}}}")#text(" by taking a path ")#mi("{\\gamma}")#text(" from ")#mi("{p_0}")#text(" to ")#mi("{p}")#text(" in the homotopy class ")#mi("{\\tilde p}")#text(", and concatenating it with the path ")#mi("{\\phi_p^{-1} \\circ \\gamma_{0 \\rightarrow \\phi_p(p^{\\prime})}}")#text(" that connects ")#mi("{p}")#text(" to ")#mi("{p^{\\prime}}")#text(" via a line segment in the disk ")#mi("{D(0,1)}")#text(" using the coordinate chart ")#mi("{\\phi_p}")#text("; the homotopy class of this concatenated path does not depend on the precise choice of ")#mi("{\\gamma}")#text(" and will be denoted ")#mi("{\\tilde p^{\\prime}}")#text(". If we let ")#mi("{\\tilde U_{\\tilde p}}")#text(" denote all the points ")#mi("{\\tilde p^{\\prime}}")#text(" obtained in this fashion as ")#mi("{p^{\\prime}}")#text(" varies over ")#mi("{U_p}")#text(", then it is easy to see (Exercise!) that the ")#mi("{\\tilde U_{\\tilde p}, \\tilde p \\in N_p}")#text(" are disjoint and partition the set ")#mi("{\\pi^{-1}(U_p)}")#text(". We can then form coordinate charts ")#mi("{\\tilde \\phi_{\\tilde p}: \\tilde U_{\\tilde p} \\rightarrow D(0,1)}")#text(" for each ")#mi("{\\tilde p \\in N_p}")#text(" and ")#mi("{p \\in M}")#text(" by setting ")#mi("{\\tilde \\phi_{\\tilde p}(\\tilde p^{\\prime}) = \\phi_p \\circ \\pi(\\tilde p^{\\prime})}")#text(" for all ")#mi("{\\tilde p^{\\prime} \\in \\tilde U_{\\tilde p}}")#text(". This defines both a topology on ")#mi("{N}")#text(" (by declaring a subset ")#mi("{U}")#text(" of ")#mi("{N}")#text(" to be open if ")#mi("{\\tilde \\phi_{\\tilde p}( U \\cap \\tilde U_{\\tilde p})}")#text(" is open for all ")#mi("{\\tilde p \\in N}")#text(") and a complex structure, as the transition maps are easily verified (Exercise!) to be both continuous and holomorphic (after first shrinking the neighbourhoods ")#mi("{U_p}")#text(" and ")#mi("{\\tilde U_p}")#text(" if necessary). By construction we now see that ")#mi("{N}")#text(" is a covering space of ")#mi("{M}")#text(", with ")#mi("{\\pi: N \\rightarrow M}")#text(" the covering map.")#linebreak()#text(" Let ")#mi("{\\tilde p_0 \\in N_{p_0}}")#text(" be the homotopy class of the constant curve at ")#mi("{p_0}")#text(". It is easy to see (Exercise!) that ")#mi("{N}")#text(" is connected (indeed, any point ")#mi("{\\tilde p}")#text(" in ")#mi("{N}")#text(" determines (more or less tautologically) a family of paths in ")#mi("{N}")#text(" from ")#mi("{\\tilde p_0}")#text(" to ")#mi("{\\tilde p}")#text("). Next, we make the stronger claim that ")#mi("{N}")#text(" is simply connected. It suffices to show that any closed path ")#mi("{\\tilde \\gamma: [0,1] \\rightarrow N}")#text(" from ")#mi("{\\tilde p_0}")#text(" to ")#mi("{\\tilde p_0}")#text(" is contractible to a point. Let ")#mi("{\\gamma: [0,1] \\rightarrow M}")#text(" denote the projected curve ")#mi("{\\gamma := \\pi \\circ \\tilde \\gamma}")#text(", thus ")#mi("{\\gamma}")#text(" is a closed curve from ")#mi("{p_0}")#text(" to itself. From the continuity method (Exercise!) we see that for any ")#mi("{0 \\leq t \\leq 1}")#text(", the restriction ")#mi("{\\gamma_{[0,t]}: [0,t] \\rightarrow M}")#text(" of ")#mi("{\\gamma}")#text(" to ")#mi("{[0,t]}")#text(" lies in the homotopy class of ")#mi("{\\tilde \\gamma(t)}")#text("; in particular, ")#mi("{\\gamma}")#text(" itself lies in the homotopy class of ")#mi("{\\tilde p_0}")#text(", and is thus homotopic to a point. Another application of the continuity method (Exercise!) then shows that as one continuously deforms ")#mi("{\\gamma}")#text(" to a point, each of the curves ")#mi("{\\gamma_s}")#text(" obtained in this deformation lifts to a closed curve ")#mi("{\\tilde \\gamma_s}")#text(" in ")#mi("{N}")#text(" from ")#mi("{\\tilde p_0}")#text(" to ")#mi("{\\tilde p_0}")#text(", in the sense that ")#mi("{\\gamma_s = \\pi \\circ \\tilde \\gamma_s}")#text("; furthermore, ")#mi("{\\tilde \\gamma_s}")#text(" varies continuously in ")#mi("{s}")#text(", giving the required homotopy from ")#mi("{\\tilde \\gamma}")#text(" to a point.")#linebreak()#text(" Define a ")#link("https://en.wikipedia.org/wiki/Covering_space#Deck_transformation_group.2C_regular_covers")[#text("deck transformation")]#text(" to be a holomorphic map ")#mi("{T: N \\rightarrow N}")#text(" such that ")#mi("{\\pi \\circ T = \\pi}")#text(" (that is to say, ")#mi("{T}")#text(" preserves each of the “fibres” ")#mi("{N_p}")#text(" of ")#mi("{N}")#text("). Clearly the composition of two deck transformations is again a deck transformation. From Corollary 51 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(" we see that for any ")#mi("{p \\in M}")#text(" and ")#mi("{\\tilde p, \\tilde q \\in N_p}")#text(", there exists a unique deck transformation that maps ")#mi("{\\tilde p}")#text(" to ")#mi("{\\tilde q}")#text(". Composing that a deck transformations with the deck transformations that maps ")#mi("{\\tilde q}")#text(" to ")#mi("{\\tilde p}")#text(" we see that all deck transformations are invertible and are thus complex automorphisms. If we let ")#mi("{\\Gamma}")#text(" denote the collection of all deck transformations then we see that ")#mi("{\\Gamma}")#text(" is a group that acts freely on ")#mi("{N}")#text(" and transitively on each fibre ")#mi("{N_p}")#text(". For any ")#mi("{p \\in M}")#text(", and the neighbourhoods ")#mi("{U_p}")#text(" as before, one can verify (Exercise!) that each deck transformation in ")#mi("{\\Gamma}")#text(" permutes the disjoint open sets ")#mi("{\\tilde U_{\\tilde p}, \\tilde p \\in N_p}")#text(" covering ")#mi("{U_p}")#text(", and given any two of these sets ")#mi("{\\tilde U_{\\tilde p}, \\tilde U_{\\tilde q}}")#text(" there is exactly one deck transformation that maps ")#mi("{\\tilde U_{\\tilde p}}")#text(" to ")#mi("{\\tilde U_{\\tilde q}}")#text(". From this one can check (Exercise!) that ")#mi("{\\Gamma \\backslash N}")#text(" is complex diffeomorphic to ")#mi("{M}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Write out the steps marked “Exercise!” in the above argument.")
]

#text("The manifold ")#mi("{N}")#text(" in the above theorem is called a ")#link("https://en.wikipedia.org/wiki/Covering_space#Universal_covers")[#text("universal cover")]#text(" of ")#mi("{M}")#text(", and the group ")#mi("{\\Gamma}")#text(" is (a copy of) the ")#link("https://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" of ")#mi("{M}")#text(". These objects are basically uniquely determined by ")#mi("{M}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Suppose one has two simply connected Riemann surfaces ")#mi("{N, N^{\\prime}}")#text(" and two groups ")#mi("{\\Gamma, \\Gamma^{\\prime}}")#text(" of automorphisms of ")#mi("{N, N^{\\prime}}")#text(" respectively acting in proper and free fashions. Show that the following statements are equivalent:")

#list(
[#text("(i) The quotients ")#mi("{\\Gamma \\backslash N}")#text(" and ")#mi("{\\Gamma^{\\prime} \\backslash N^{\\prime}}")#text(" are complex diffeomorphic.")],
[#text("(ii) There exists a complex diffeomorphism ")#mi("{\\phi: N \\rightarrow N^{\\prime}}")#text(" and a group isomorphism ")#mi("{\\iota: \\Gamma \\rightarrow \\Gamma^{\\prime}}")#text(" such that")

#metadata(none) <tao-4bda4ceeb0d37bab4b02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\iota(T) (\\phi(p)) = \\phi( Tp )")]]

#text("for all ")#mi("{p \\in N}")#text(" and ")#mi("{T \\in \\Gamma}")#text(". In particular ")#mi("{N}")#text(" and ")#mi("{N^{\\prime}}")#text(" are complex diffeomorphic, and the groups ")#mi("{\\Gamma}")#text(" and ")#mi("{\\Gamma^{\\prime}}")#text(" are isomorphic.")]
)

#text("(")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-586abb54469a8ddcc161>)[#text("23")]#text(" for one direction of the implication, and Corollary 51 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(" for the other implication.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface, and let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(". Define the ")#link("https://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" ")#mi("{\\pi_1(M)}")#text(" based at ")#mi("{p_0}")#text(" to be the collection of equivalence classes ")#mi("{[\\gamma]}")#text(" of closed curves ")#mi("{\\gamma:[a,b] \\rightarrow M}")#text(" from ")#mi("{p_0}")#text(" to ")#mi("{p_0}")#text(", under the relation of homotopy with fixed endpoints up to reparameterisation.")

#list(
[#text("(i) Show that ")#mi("{\\pi_1(M)}")#text(" is indeed a group, with the equivalence class of the constant curves as the identity element, the inverse of a homotopy class ")#mi("{[\\gamma]}")#text(" of a curve ")#mi("{\\gamma}")#text(" defined as ")#mi("{[-\\gamma]}")#text(", and the product ")#mi("{[\\gamma_1] [\\gamma_2]}")#text(" of two homotopy classes of curves ")#mi("{\\gamma_1,\\gamma_2}")#text(" as ")#mi("{[\\gamma_1+\\gamma_2]}")#text(".")],
[#text("(ii) If ")#mi("{N, \\Gamma}")#text(" are as in Theorem ")#link(<tao-dbdbc8ce6333f81b460c>)[#text("25")]#text(", show that ")#mi("{\\Gamma}")#text(" is isomorphic to ")#mi("{\\pi_1(M)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Show that the fundamental group of ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" is isomorphic to the integers ")#mi("{{\\bf Z}}")#text(" (viewed as an additive group).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Universality)")]#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface, let ")#mi("{N}")#text(" be a universal cover of ")#mi("{M}")#text(" with covering map ")#mi("{\\pi: N \\rightarrow M}")#text(", and let ")#mi("{L}")#text(" be another Riemann surface cover of ")#mi("{M}")#text(" with a covering map ")#mi("{\\psi: L \\rightarrow M}")#text(". Let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(", let ")#mi("{q_0 \\in N}")#text(" be a point in ")#mi("{\\pi^{-1}(p_0)}")#text(", and let ")#mi("{r_0}")#text(" be a point in ")#mi("{\\psi^{-1}(r_0)}")#text(". Show that there is a unique covering map ")#mi("{\\phi: N \\rightarrow L}")#text(" with ")#mi("{\\phi(q_0)=r_0}")#text(" such that ")#mi("{\\pi = \\psi \\circ \\phi}")#text(". This helps justify the terminology “universal cover”.")
]

#text("If we assume for now the uniformisation theorem, we conclude that every connected Riemann surface is the quotient of one of the three model surfaces ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", ")#mi("{{\\bf C}}")#text(", ")#mi("{D(0,1)}")#text(" by a group of complex automorphisms that act freely and properly; depending on which surface is used, we call these Riemann surfaces of ")#emph[#text("elliptic type")]#text(", ")#emph[#text("parabolic type")]#text(", and ")#emph[#text("hyperbolic type")]#text(" respectively. We can then study each of the three model types in turn:")#linebreak()#text(" ")#strong[#text("Elliptic type:")]#text(" By Proposition ")#link(<tao-28720365c5e7476a011e>)[#text("14")]#text(", the automorphisms of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" are the Möbius transformations. From the quadratic formula (or the fundamental theorem of algebra) we see that every Möbius transformation has at least one fixed point (for instance, the translations ")#mi("{z \\mapsto z+c}")#text(" fix ")#mi("{\\infty}")#text("). Thus the only group of complex automorphisms that can act freely on ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" is the trivial group, so the only Riemann surfaces of elliptic type are those that are complex diffeomorphic to the Riemann sphere.")#linebreak()#text(" ")#strong[#text("Parabolic type:")]#text(" By Proposition ")#link(<tao-28720365c5e7476a011e>)[#text("14")]#text(", the automorphisms of ")#mi("{{\\bf C}}")#text(" are the affine transformations ")#mi("{z \\mapsto az+b}")#text(". These transformations have fixed points in ")#mi("{{\\bf C}}")#text(" if ")#mi("{a \\neq 1}")#text(", so in order to obtain a free action we must restrict ")#mi("{\\Gamma}")#text(" to the translations ")#mi("{z \\mapsto z+b}")#text(". Thus we can view ")#mi("{\\Gamma}")#text(" as an additive subgroup of ")#mi("{{\\bf C}}")#text(", with ")#mi("{\\Gamma \\backslash {\\bf C}}")#text(" now being the group quotient; as the action is additive, we can also write ")#mi("{\\Gamma \\backslash {\\bf C}}")#text(" as ")#mi("{{\\bf C} / \\Gamma}")#text(". In order for the action to be proper, ")#mi("{\\Gamma}")#text(" must be a discrete subgroup of ")#mi("{{\\bf C}}")#text(" (every point isolated). We can classify all such subgroups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Let ")#mi("{\\Gamma}")#text(" be a discrete additive subgroup of ")#mi("{{\\bf C}}")#text(". Show that ")#mi("{\\Gamma}")#text(" takes on one of the following three forms:")

#list(
[#text("(i) (Rank zero case) the trivial group ")#mi("{\\{0\\}}")#text(";")],
[#text("(ii) (Rank one case) a cyclic group ")#mi("{\\omega {\\bf Z} := \\{ n \\omega: n \\in {\\bf Z}\\}}")#text(" for some ")#mi("{\\omega \\in {\\bf C} \\backslash \\{0\\}}")#text("; or")],
[#text("(iii) (Rank two case) a group ")#mi("{\\omega_1 {\\bf Z} + \\omega_2 {\\bf Z} := \\{ n_1 \\omega_1 + n_2 \\omega_2: n_1,n_2 \\in {\\bf Z} \\}}")#text(" for some ")#mi("{\\omega_1,\\omega_2 \\in {\\bf C} \\backslash \\{0\\}}")#text(" with ")#mi("{\\omega_2/\\omega_1}")#text(" strictly complex (i.e., not real).")]
)
]

#text("We conclude that every Riemann surface of parabolic type is complex diffeomorphic to a plane ")#mi("{{\\bf C}}")#text(", a cylinder ")#mi("{\\omega{\\bf Z} \\backslash {\\bf C}}")#text(" for some ")#mi("{\\omega \\in {\\bf C} \\backslash \\{0\\}}")#text(", or a torus ")#mi("{(\\omega_1 {\\bf Z} + \\omega_2{\\bf Z}) \\backslash {\\bf C}}")#text(" for ")#mi("{\\omega_1,\\omega_2 \\in {\\bf C} \\backslash \\{0\\}}")#text(" and ")#mi("{\\omega_1/\\omega_2}")#text(" strictly complex.")#linebreak()#text(" The case of the plane is self-explanatory. Using dilation maps we see that all cylinders are complex diffeomorphic to each other; for instance, they are all diffeomorphic to ")#mi("{2\\pi i {\\bf Z} \\backslash {\\bf C}}")#text(". The exponential map ")#mi("{z \\mapsto \\exp(z)}")#text(" is ")#mi("{2\\pi i}")#text("-periodic and thus descends to a map from ")#mi("{2\\pi i {\\bf Z} \\backslash {\\bf C}}")#text(" to ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text("; it is easy to see that this map is a complex diffeomorphism, thus the punctured plane ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" can be used as a model for all Riemann surface cylinders.")#linebreak()#text(" The case of the tori ")#mi("{(\\omega_1 {\\bf Z} + \\omega_2{\\bf Z}) \\backslash {\\bf C}}")#text(" are more interesting. One can use dilations to normalise one of the ")#mi("{\\omega_1,\\omega_2}")#text(" to be a specific value such as ")#mi("{1}")#text(", but one cannot normalise both:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Let ")#mi("{(\\omega_1 {\\bf Z} + \\omega_2{\\bf Z}) \\backslash {\\bf C}}")#text(" and ")#mi("{(\\omega^{\\prime}_1 {\\bf Z} + \\omega^{\\prime}_2{\\bf Z}) \\backslash {\\bf C}}")#text(" be two tori. Show that these two tori are complex diffeomorphic if and only if there exists an element ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" of the special linear group ")#mi("{SL_2({\\bf Z})}")#text(" (thus ")#mi("{a,b,c,d}")#text(" are integers with ")#mi("{ad-bc=1}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\omega^{\\prime}_1}{\\omega^{\\prime}_2} = \\pm \\frac{a \\omega_1 + b \\omega_2}{c \\omega_1 + d \\omega_2}.")]]

#text("(")#emph[#text("Hint:")]#text(" lift any such diffeomorphism to a diffeomorphism of ")#mi("{{\\bf C}}")#text(".)")
]

#text("In contrast to the cylinders ")#mi("{\\omega {\\bf Z} \\backslash {\\bf C}}")#text(", which are complex diffeomorphic to a subset ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" of the complex plane, one cannot model a torus by a subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text("; indeed, if there were a complex diffeomorphism ")#mi("{\\phi: (\\omega_1 {\\bf Z} + \\omega_2{\\bf Z}) \\backslash {\\bf C} \\rightarrow U}")#text(", then ")#mi("{U}")#text(" would have to be non-empty, compact, and (by the open mapping theorem) open in ")#mi("{{\\bf C}}")#text(", which is impossible since ")#mi("{{\\bf C}}")#text(" is non-compact and connected. However, it is an important fact in algebraic geometry, classical analysis and number theory that these tori can be modeled instead by ")#link("https://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curves")]#text(". The theory of elliptic curves is extremely rich, but is beyond the scope of this course and will not be discussed further here (but the ")#link("https://en.wikipedia.org/wiki/Weierstrass%27s_elliptic_functions")[#text("Weierstrass elliptic functions")]#text(" used to construct the complex diffeomorphism between tori and elliptic curves may be covered in subsequent quarters).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" ")#metadata(none) <tao-c266ada2b324936aa923>#text(" Let ")#mi("{U}")#text(" be a connected subset of ")#mi("{{\\bf C}}")#text(" that omits at least two points of ")#mi("{{\\bf C}}")#text(". Show that ")#mi("{U}")#text(" cannot be of elliptic or parabolic type. (")#emph[#text("Hint:")]#text(" in addition to the open mapping theorem argument given above, one can use either the little Picard theorem, Theorem 56 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(", or the simpler Casorati-Weierstrass theorem (Theorem 12 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(").) In particular, assuming the uniformisation theorem, such sets ")#mi("{U}")#text(" must be of hyperbolic type. (Note this is compatible with our previous intuition that “more hyperbolic” is analogous to “higher genus” or “has more holes”.)")
]

#strong[#text("Hyperbolic type:")]#text(" Here it is convenient to model the hyperbolic Riemann surface using the upper half-plane ")#mi("{{\\bf H}}")#text(" (the ")#link("https://en.wikipedia.org/wiki/Hyperbolic_space#The_Poincar.C3.A9_half_space_model")[#text("Poincaré half-plane model")]#text(") rather than the disk ")#mi("{D(0,1)}")#text(" (the ")#link("https://en.wikipedia.org/wiki/Hyperbolic_space#The_Poincar.C3.A9_ball_model")[#text("Poincaré disk model")]#text("). By Exercise ")#link(<tao-05b774dc2a4b086d2ae3>)[#text("20")]#text(", a Riemann surface of hyperbolic type is then isomorphic to a quotient ")#mi("{\\Gamma \\backslash {\\bf H}}")#text(" of ")#mi("{{\\bf H}}")#text(" by some subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{PSL_2({\\bf R})}")#text(" that acts freely and properly. Properness is easily seen to be equivalent to ")#mi("{\\Gamma}")#text(" being a discrete subgroup of ")#mi("{PSL_2({\\bf R})}")#text(" (using the topology inherited from the embedding of ")#mi("{SL_2({\\bf R})}")#text(" in ")#mi("{{\\bf R}^4}")#text("); such groups are known as ")#link("https://en.wikipedia.org/wiki/Fuchsian_group")[#text("Fuchsian groups")]#text(". Freeness can also be described explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Show that a subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{PSL_2({\\bf R})}")#text(" acts freely on ")#mi("{{\\bf H}}")#text(" if and only if it avoids all (equivalence classes) of matrices ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" in ")#mi("{PSL_2({\\bf R})}")#text(" that are ")#link("https://en.wikipedia.org/wiki/SL2(R)#Elliptic_elements")[#text("elliptic")]#text(" in the sense that they obey the trace condition ")#tao-math("{\\left|a+d\\right| < 2}", block: false)#text(".")
]

#text("It turns out that in contrast to the elliptic type and parabolic type situations, there are a very large number of possible subgroups ")#mi("{\\Gamma}")#text(" obeying these conditions, and a complete classification of them is basically hopeless. The theory of Fuchsian groups is again very rich, being a foundational topic in hyperbolic geometry, but is again beyond the scope of this course.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 35")]#text(" The twice-punctured plane ")#mi("{{\\bf C} \\backslash \\{0,1\\}}")#text(" must be of hyperbolic type by the uniformisation theorem and Exercise ")#link(<tao-c266ada2b324936aa923>)[#text("33")]#text(". This gives another proof of the little Picard theorem: an entire function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\backslash \\{0,1\\}}")#text(" that omits (say) the points ")#mi("{0,1}")#text(" must then lift (by Corollary 51 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(") to a holomorphic map from ")#mi("{{\\bf C}}")#text(" to ")#mi("{D(0,1)}")#text(", which must then be constant by Liouville’s theorem. A more complicated argument along these lines also proves the great Picard theorem. It turns out that the covering map from ")#mi("{D(0,1)}")#text(" to ")#mi("{{\\bf C} \\backslash \\{0,1\\}}")#text(" can be described explicitly using the theory of elliptic functions (and specifically the ")#link("https://en.wikipedia.org/wiki/Modular_lambda_function")[#text("modular lambda function")]#text("), but this is beyond the scope of this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Show that any annulus ")#tao-math("{\\{ z: r < \\left|z\\right| < R \\}}", block: false)#text(" is of hyperbolic type, and is in fact complex diffeomorphic to ")#mi("{\\Gamma \\backslash {\\bf H}}")#text(" for some cyclic group ")#mi("{\\Gamma}")#text(" of dilations. (")#emph[#text("Hint:")]#text(" first use the complex exponential to cover the annulus by a strip, then use Exercise ")#link(<tao-2090ee93ba7ae1ffc3ca>)[#text("7")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37 (Schottky’s theorem on conformal maps between annuli)")]#text(" Let ")#tao-math("{A_1 := \\{ z: r_1 < \\left|z\\right| < R_1\\}}", block: false)#text(" and ")#tao-math("{A_2 := \\{ z: r_2 < \\left|z\\right| < R_2 \\}}", block: false)#text(" be two annuli with ")#mi("{0 < r_1 < R_1}")#text(" and ")#mi("{0 < r_2 < R_2}")#text(". Show that ")#mi("{A_1}")#text(" and ")#mi("{A_2}")#text(" are complex diffeomorphic (with the conformal map extending continuously to the boundary) if and only if ")#mi("{R_2/r_2 = R_1/r_1}")#text(". (")#emph[#text("Hint:")]#text(" one can either argue by lifting to the half-plane using the previous exercise, or else using the Schwarz reflection principle (adapted to circles in place of lines) repeatedly to extend a holomorphic map from ")#mi("{A_1}")#text(" to ")#mi("{A_2}")#text(" to a holomorphic map from a punctured disk to a punctured disk; one can also combine the methods by taking logarithms to lift ")#mi("{A_1}")#text(", ")#mi("{A_2}")#text(" to strips, and then using the original Schwarz reflection principle. This result is due to Schottky, but should not be confused with ")#link("https://en.wikipedia.org/wiki/Schottky%27s_theorem")[#text("another theorem of Schottky")]#text(" in complex analysis. The constraint that the conformal map extends continuously to the boundary can be removed, for instance by appealing to a version of ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_theorem_(conformal_mapping)")[#text("Carathéodory’s theorem")]#text(", but this is beyond the scope of the course.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]

#list(
[#text("(i) Show that the punctured disk ")#mi("{D(0,1) \\backslash \\{0\\}}")#text(" is of hyperbolic type, and is complex diffeomorphic to ")#mi("{{\\bf Z} \\backslash {\\bf H}}")#text(", where ")#mi("{{\\bf Z}}")#text(" acts on ")#mi("{{\\bf H}}")#text(" by translations.")],
[#text("(ii) Show that the ")#link("https://en.wikipedia.org/wiki/Joukowsky_transform")[#text("Jowkowsky transform")]#text(" ")#mi("{z \\mapsto \\frac{1}{2} (z + \\frac{1}{z})}")#text(" is a complex diffeomorphism from ")#mi("{D(0,1)}")#text(" to the slitted extended complex plane ")#mi("{({\\bf C} \\cup \\{\\infty\\}) \\backslash [-1,1]}")#text(". Conclude that ")#mi("{{\\bf C} \\backslash [-1,1]}")#text(" is also complex diffeomorphic to ")#mi("{{\\bf Z} \\backslash {\\bf H}}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. The Riemann mapping theorem — ")]]

#text("We are now ready to prove the Riemann mapping theorem, Theorem ")#link(<tao-804009875b8f14742850>)[#text("4")]#text(", using an argument of Koebe. To motivate the argument, let us rephrase the Schwarz lemma in the following form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 39 (Schwarz lemma, again)")]#text(" ")#metadata(none) <tao-12919cd5a1038a00a78c>#text(" Let ")#mi("{U}")#text(" be a Riemann surface, and let ")#mi("{p_0}")#text(" be a point in ")#mi("{U}")#text(". Let ")#mi("{{\\mathcal H}_{p_0}}")#text(" denote the collection of holomorphic functions ")#mi("{f: U \\rightarrow D(0,1)}")#text(" with ")#mi("{f(p_0) = 0}")#text(". If ")#mi("{{\\mathcal H}_{p_0}}")#text(" contains an element ")#mi("{\\phi}")#text(" that is a complex diffeomorphism, then ")#tao-math("{\\left|f(p)\\right| \\leq \\left|\\phi(p)\\right|}", block: false)#text(" for all ")#mi("{p \\in U \\backslash \\{p_0\\}}")#text("; if ")#mi("{U}")#text(" is a subset of the complex plane ")#mi("{{\\bf C}}")#text(", we also have ")#tao-math("{\\left|f^{\\prime}(p_0)\\right| \\leq \\left|\\phi^{\\prime}(p_0)\\right|}", block: false)#text(". Furthermore, in either of these two inequalities, equality holds if and only if ")#mi("{f = e^{i\\theta} \\phi}")#text(" for some real number ")#mi("{\\theta}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Lemma ")#link(<tao-2993f8453f06da87d9df>)[#text("17")]#text(" to the map ")#mi("{f \\circ \\phi^{-1}: D(0,1) \\rightarrow D(0,1)}")#text(". ")#mi("\\Box")#linebreak()#text(" This lemma suggests the following strategy to prove the Riemann mapping theorem: starting with the open subset ")#mi("{U}")#text(" of the complex plane ")#mi("{{\\bf C}}")#text(", pick a point ")#mi("{p_0}")#text(" in that subset, and form the collection ")#mi("{{\\mathcal H}_{p_0}}")#text(" of holomorphic maps ")#mi("{f: U \\rightarrow D(0,1)}")#text(" that map ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(", and locate an element ")#mi("{\\phi}")#text(" of this collection for which the magnitude ")#tao-math("{\\left|\\phi^{\\prime}(p_0)\\right|}", block: false)#text(" is maximal. If the Riemann mapping theorem were true, then Lemma ")#link(<tao-12919cd5a1038a00a78c>)[#text("39")]#text(" would ensure that this ")#mi("{\\phi}")#text(" would be a complex diffeomorphism, and we would be done.")#linebreak()#text(" It turns out to be convenient to work with the somewhat smaller collection ")#mi("{{\\mathcal I}_{p_0}}")#text(" of ")#emph[#text("injective")]#text(" holomorphic maps ")#mi("{f: U \\rightarrow D(0,1)}")#text(" (also known as ")#link("https://en.wikipedia.org/wiki/Univalent_function")[#text("univalent")]#text(" functions from ")#mi("{U}")#text(" to ")#mi("{D(0,1)}")#text("). We first observe that this collection is non-empty for the sets ")#mi("{U}")#text(" of interest:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 40")]#text(" ")#metadata(none) <tao-139d544b821b13ebea14>#text(" Let ")#mi("{U}")#text(" be a simply connected subset of ")#mi("{{\\bf C}}")#text(" that is not all of ")#mi("{{\\bf C}}")#text(". Then there exists an injective holomorphic map ")#mi("{f: U \\rightarrow D(0,1)}")#text(".")
]

#emph[#text("Proof:")]#text(" By applying a translation to ")#mi("{U}")#text(", we may assume that ")#mi("{U}")#text(" avoids the origin ")#mi("{0}")#text(". If ")#mi("{U}")#text(" in fact avoided a disk ")#mi("{D(z_0,r)}")#text(", then we could use the map ")#mi("{z \\mapsto \\frac{r}{2(z-z_0)}}")#text(" to map ")#mi("{U}")#text(" injectively into the disk ")#mi("{D(0,1)}")#text(". At present, ")#mi("{U}")#text(" need not avoid any disk (e.g. ")#mi("{U}")#text(" could be the complex plane with the negative axis ")#mi("{\\{ t \\in {\\bf R}: t \\leq 0 \\}}")#text(" removed). However, as ")#mi("{U}")#text(" is simply connected and avoids ")#mi("{0}")#text(", we can argue as in Section 4 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(" to obtain a holomorphic branch ")#mi("{f: U \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" of the square root function, that is to say a holomorphic map ")#mi("{f}")#text(" such that ")#mi("{f^2(z) = z}")#text(" for all ")#mi("{z \\in U}")#text(". As ")#mi("{f^2}")#text(" is injective, ")#mi("{f}")#text(" must also be injective; it is also clearly non-constant, so from the open mapping theorem ")#mi("{f(U)}")#text(" is open and thus contains some disk ")#mi("{D(z_0,r)}")#text(". But if ")#mi("{w}")#text(" lies in ")#mi("{f(U)}")#text(" then ")#mi("{-w}")#text(" cannot lie in ")#mi("{f(U)}")#text(" since this would make the map ")#mi("{f^2}")#text(" non-injective; thus ")#mi("{f(U)}")#text(" avoids a disk ")#mi("{D(-z_0,r)}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" If ")#mi("{p_0}")#text(" is a point in ")#mi("{U}")#text(", then the map ")#mi("{f}")#text(" constructed by the above proposition need not map ")#mi("{p_0}")#text(" to the origin, but this is easily fixed by composing ")#mi("{f}")#text(" with a suitable automorphism of ")#mi("{D(0,1)}")#text(". To prove the Riemann mapping theorem, it will thus suffice to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 41")]#text(" ")#metadata(none) <tao-6c45cb72a36e63d522aa>#text(" Let ")#mi("{U}")#text(" be a simply connected Riemann surface, let ")#mi("{p_0}")#text(" be a point in ")#mi("{U}")#text(", and let ")#mi("{{\\mathcal I}_{p_0}}")#text(" be the collection of injective holomorphic maps ")#mi("{f: U \\rightarrow D(0,1)}")#text(" with ")#mi("{f(p_0)=0}")#text(". If ")#mi("{{\\mathcal I}_{p_0}}")#text(" is non-empty, then ")#mi("{U}")#text(" is complex diffeomorphic to ")#mi("{D(0,1)}")#text(".")
]

#emph[#text("Proof:")]#text(" By identifying ")#mi("{U}")#text(" with its image under one of the elements of ")#mi("{{\\mathcal I}_{p_0}}")#text(", we may assume without loss of generality that ")#mi("{U}")#text(" is itself an open subset of ")#mi("{D(0,1)}")#text(", with ")#mi("{p_0=0}")#text(".")#linebreak()#text(" Define the quantity")

#align(center)[#tao-fit-display[#tao-math("M := \\sup \\{ \\left|f^{\\prime}(0)\\right|: f \\in {\\mathcal I}_0 \\}.", block: true)]]

#text("As ")#mi("{{\\mathcal I}_0}")#text(" contains the identity map, ")#mi("{M}")#text(" is at least ")#mi("{1}")#text("; from the Cauchy inequalities (Corollary 27 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") we see that ")#mi("{M}")#text(" is finite. Hence there exists a sequence ")#mi("{f_n}")#text(" in ")#mi("{{\\mathcal I}_0}")#text(" with ")#tao-math("{\\left|f^{\\prime}_n(0)\\right|}", block: false)#text(" converging to ")#mi("{M}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". From Montel’s theorem (Exercise 58(i) of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(") we know that ")#mi("{{\\mathcal I}_0}")#text(" is a normal family, so on passing to a subsequence we may assume that the ")#mi("{f_n}")#text(" converge locally uniformly to some limit ")#mi("{f: U \\rightarrow \\overline{D(0,1)}}")#text(". By Hurwitz’s theorem (Exercise 42 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text("), the limit ")#mi("{f}")#text(" is holomorphic and is either injective or constant. But from the higher order Cauchy integral formula (Theorem 25 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text("), ")#mi("{f^{\\prime}_n(0)}")#text(" converges to ")#mi("{f^{\\prime}(0)}")#text(", hence ")#tao-math("{\\left|f^{\\prime}(0)\\right|=M}", block: false)#text(" and so ")#mi("{f}")#text(" cannot be constant, and is thus injective. From the maximum principle (Exercise ")#link(<tao-9baf3a40312f39849f46>)[#text("18")]#text(") or the open mapping theorem, we know that ")#mi("{f}")#text(" takes values in ")#mi("{D(0,1)}")#text(", and not just ")#mi("{\\overline{D(0,1)}}")#text(".")#linebreak()#text(" To conclude the proposition, we need to show that ")#mi("{f}")#text(" is also surjective. Here we use a variant of the argument used to prove Proposition ")#link(<tao-139d544b821b13ebea14>)[#text("40")]#text(". Suppose for contradiction that ")#mi("{f(U)}")#text(" avoids some point ")#mi("{\\alpha}")#text(" in ")#mi("{D(0,1)}")#text(". Let ")#mi("{R_\\alpha: D(0,1) \\rightarrow D(0,1)}")#text(" be an automorphism of ")#mi("{D(0,1)}")#text(" that sends ")#mi("{\\alpha}")#text(" to ")#mi("{0}")#text(", then ")#mi("{R_\\alpha \\circ f(U)}")#text(" avoids the origin. As ")#mi("{U}")#text(" is simply connected, we can thus find a holomorphic square root ")#mi("{g: U \\rightarrow D(0,1) \\backslash \\{0\\}}")#text(" of ")#mi("{R_\\alpha \\circ f}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("R_\\alpha \\circ f = g^2.")]]

#text("Since ")#mi("{f}")#text(" and hence ")#mi("{R_\\alpha \\circ f}")#text(" are injective, ")#mi("{g}")#text(" is also. Finally, if ")#mi("{R_{g(0)}: D(0,1) \\rightarrow D(0,1)}")#text(" is an automorphism of ")#mi("{D(0,1)}")#text(" that sends ")#mi("{g(0)}")#text(" to ")#mi("{0}")#text(", then the map ")#mi("{h := R_{g(0)} \\circ g}")#text(" lies in ")#mi("{{\\mathcal I}_{0}}")#text(". The map ")#mi("{h}")#text(" is related to ")#mi("{f}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f = R_\\alpha^{-1} \\circ s \\circ R_{g(0)}^{-1} \\circ h")]]

#text("where ")#mi("{s: z \\mapsto z^2}")#text(" is the squaring map. Observe that the map ")#mi("{R_\\alpha^{-1} \\circ s \\circ R_{g(0)}^{-1}}")#text(" is a holomorphic map from ")#mi("{D(0,1)}")#text(" to ")#mi("{D(0,1)}")#text(" that maps ")#mi("{0}")#text(" to ")#mi("{0}")#text(", and is not a rotation map (since ")#mi("{s}")#text(" is not a Möbius transformation). Thus by the Schwarz lemma (Lemma ")#link(<tao-2993f8453f06da87d9df>)[#text("17")]#text("), we have")

#align(center)[#tao-fit-display[#tao-math("\\left|(R_\\alpha^{-1} \\circ s \\circ R_{g(0)}^{-1})^{\\prime}(0)\\right| < 1", block: true)]]

#text("and hence by the chain rule")

#align(center)[#tao-fit-display[#tao-math("M = \\left|f^{\\prime}(0)\\right| < \\left|h^{\\prime}(0)\\right|.", block: true)]]

#text("But this contradicts the definition of ")#mi("{M}")#text(", and we are done. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" Let ")#mi("{U}")#text(" be an open connected non-empty subset of ")#mi("{{\\bf C}}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{U}")#text(" is simply connected.")],
[#text("(ii) One has ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for every holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" and every closed curve ")#mi("{\\gamma}")#text(" in ")#mi("{U}")#text(".")],
[#text("(iii) For every holomorphic function ")#mi("{f: U \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" there exists a holomorphic ")#mi("{g: U \\rightarrow {\\bf C}}")#text(" with ")#mi("{f = \\exp(g)}")#text(".")],
[#text("(iv) For every holomorphic function ")#mi("{f: U \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" there exists a holomorphic ")#mi("{g: U \\rightarrow {\\bf C} \\backslash \\{0\\}}")#text(" with ")#mi("{f = g^2}")#text(".")],
[#text("(v) The complement ")#mi("{({\\bf C} \\cup \\{\\infty\\}) \\backslash U}")#text(" of ")#mi("{U}")#text(" in the Riemann sphere is connected.")]
)

#text("(")#emph[#text("Hint:")]#text(" to relate (v) to the other claims, use Exercise 44 from ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(".)")
]

#heading(level: 1)[#strong[#text(" — 4. Schwarz-Christoffel mappings — ")]]

#text("The Riemann mapping theorem guarantees the existence of complex diffeomorphisms ")#mi("{f: U \\rightarrow D(0,1)}")#text(" for any simply connected subset ")#mi("{U}")#text(" of the complex plane that is not all of ")#mi("{{\\bf C}}")#text("; in particular, such diffeomorphisms exist if ")#mi("{U}")#text(" is a ")#emph[#text("polygon")]#text(", by which we mean the interior region of a simple closed anticlockwise polygonal path ")#mi("{\\gamma_{z_1 \\rightarrow z_2 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(". However, the proof of the Riemann mapping theorem does not supply an easy way to compute what this map ")#mi("{f}")#text(" is. Nevertheless, in the case of polygons a reasonably explicit formula for ")#mi("{f}")#text(" (or more precisely, for the derivative of the inverse of ")#mi("{f}")#text(") may be found. Our arguments here are based on those in the ")#link("http://www.ams.org/mathscinet-getitem?mr=510197")[#text("text of Ahlfors")]#text(".")#linebreak()#text(" To motivate the answer we will arrive at, let us first consider the equivalent problem of finding a complex diffeomorphism ")#mi("{f: U \\rightarrow H}")#text(" from an arbitrary given polygon ")#mi("{U}")#text(" to to the standard half-plane ")#mi("{H = \\{ z: \\mathrm{Im} z > 0 \\}}")#text(". It turns out that it is easier to think about the inverse problem of finding a complex diffeomorphism ")#mi("{F: H \\rightarrow U}")#text(" from the standard half-plane ")#mi("{H}")#text(" to an arbitrary given polygon ")#mi("{U}")#text(". A good near-example here is the standard branch ")#mi("{F(z) = \\exp( \\alpha \\mathrm{Log} z )}")#text(" of the exponentiation map ")#mi("{z^\\alpha}")#text(" for some real number ")#mi("{0 < \\alpha < 2}")#text("; this is a complex diffeomorphism from ")#mi("{H}")#text(" to the sector ")#mi("{U = \\{ re^{i\\theta}: r > 0; 0 < \\theta < \\alpha \\}}")#text(", which one can think of as an infinite version of a polygon with just one vertex and two sides. Note in this example that ")#mi("{F}")#text(" actually extends continuously as a map from the closed half-plane ")#mi("{\\overline{H} = \\{ z: \\mathrm{Im} z \\geq 0 \\}}")#text(" to the closed sector ")#mi("{\\overline{U} = \\{ re^{i\\theta}: r \\geq 0; 0 \\leq \\theta \\leq \\pi \\alpha \\}}")#text(", and in particular maps the real line ")#mi("{{\\bf R}}")#text(" to the polygonal path ")#mi("{\\{ r: r \\geq 0 \\} \\cup \\{ re^{\\pi i\\alpha}: r \\geq 0 \\}}")#text(". Explicitly, we have")

#align(center)[#tao-fit-display[#tao-math("F(x) = \\left|x\\right|^\\alpha", block: true)]]

#text("for positive real ")#mi("{x}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("F(x) = e^{\\pi i \\alpha} \\left|x\\right|^\\alpha", block: true)]]

#text("for negative real ")#mi("{x}")#text(". Thus as ")#mi("{x}")#text(" goes from ")#mi("{-\\infty}")#text(" to ")#mi("{\\infty}")#text(", ")#mi("{F(x)}")#text(" first traverses down the ray ")#mi("{\\{ re^{\\pi i\\alpha}: r \\geq 0 \\}}")#text(" (moving at velocity parallel to ")#mi("{e^{\\pi i (\\alpha-1)}}")#text(") and then along the ray ")#mi("{\\{ r: r \\geq 0\\}}")#text(" (with a velocity parallel to ")#mi("{1}")#text("), with a turning point in the direction of travel as ")#mi("{x}")#text(" crosses the origin. The velocity ")#mi("{F^{\\prime}(z)}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(z) = \\alpha \\exp( (\\alpha-1) \\mathrm{Log} z ),")]]

#text("so ")#mi("{F^{\\prime}(x)}")#text(" is the standard branch of ")#mi("{\\alpha x^{\\alpha-1}}")#text(", which exhibits the desired “turning point” effect.")#linebreak()#text(" By inserting more turning points at different points in the real line, one can make ")#mi("{F}")#text(" map the real line to more complicated polygonal paths, which should hopefully then lead to mapping the half-plane to the interior of the polygon. Suppose for instance we try to make ")#mi("{F^{\\prime}}")#text(" the branch of ")#mi("{(1-z^2)^{-1/2}}")#text(" which is holomorphic on ")#mi("{H}")#text(" and positive for ")#mi("{z \\in (-1,1)}")#text(" (this is possible because ")#mi("{H}")#text(" is simply connected and avoids the ")#link("https://en.wikipedia.org/wiki/Branch_point")[#text("branch points")]#text(" ")#mi("{-1,+1}")#text(" where branches of ")#mi("{(1-z^2)^{-1/2}}")#text(" cannot be analytically continued to). More precisely, we could take")

#align(center)[#tao-fit-display[#mitex("F(z) = \\int_{\\gamma_{0 \\rightarrow z}} (1-w^2)^{-1/2}\\ dw")]]

#text("for ")#mi("{z \\in H}")#text(", where we implicitly use the branch of ")#mi("{(1-z^2)^{-1/2}}")#text(" mentioned above. Formally at least, ")#mi("{F}")#text(" extends continuously to the real line and we should have")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(x) = (1-x^2)^{-1/2}.")]]

#text("Some thought reveals that ")#mi("{F^{\\prime}(x)}")#text(" should then lie on the lower imaginary axis for ")#mi("{x < -1}")#text(", the positive real axis for ")#mi("{-1 < x < 1}")#text(", and the upper imaginary axis for ")#mi("{x > 1}")#text(". Some elementary calculus leads us to then compute that ")#mi("{F(x), -\\infty < x < \\infty}")#text(" traverses the polygonal path")

#align(center)[#tao-fit-display[#mitex("\\{ -\\pi/2+it: t \\geq 0\\} \\cup [-\\pi/2,\\pi/2] \\cup \\{ \\pi/2+it: t \\geq 0 \\}")]]

#text("and with more effort one can show that ")#mi("{F}")#text(" is in fact a conformal map from ")#mi("{H}")#text(" to the half-strip")

#align(center)[#tao-fit-display[#mitex("\\{ \\sigma+it: t > 0, -\\pi/2 < \\sigma < \\pi \\}.")]]

#text("These examples leads us to suggest that in general we should look for maps ")#mi("{F}")#text(" whose derivatives are branches of polynomials raised to various fractional powers if we wish to map the half-plane into polygonal regions. It turns out a similar situation occurs for maps from the unit disk into a polygonal region. To make the discussion rigorous we need to continuously extend the conformal maps required to the boundary, which turns out to be a somewhat non-trivial task; we will also call upon a version of the Schwartz reflection principle to make the maps analytic even at the boundary, except at branch points. But once we do so we will indeed be able to describe the conformal maps between the disk and a polygon in the desired terms, although the precise specification of the polynomials that show up will not be completely determined.")#linebreak()#text(" To turn to the details we set up some notation. Let ")#mi("{\\gamma_{z_1 \\rightarrow z_2 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(" be a simple closed anticlockwise polygonal path (in particular, the ")#mi("{z_1,\\dots,z_n}")#text(" are all distinct), let ")#mi("{U}")#text(" be the polygon enclosed by this path, and let ")#mi("{f: U \\rightarrow D(0,1)}")#text(" be a complex diffeomorphism, the existence of which is guaranteed by the Riemann mapping theorem. (The map ")#mi("{f}")#text(" is only unique up to composition by an automorphism of ")#mi("{D(0,1)}")#text(", but this will not concern us for the present analysis.) We adopt the convention that ")#mi("{z_0 := z_n}")#text(" and ")#mi("{z_{n+1} := z_1}")#text(", and for ")#mi("{j=1,\\dots,n}")#text(", we let ")#mi("{0 < \\alpha_j < 2}")#text(" denote the counterclockwise angle subtended by the polygon at ")#mi("{z_j}")#text(" (normalised by a factor of ")#mi("{1/\\pi}")#text("), in the sense that")

#align(center)[#tao-fit-display[#mitex("(z_{j-1}-z_j) = c_j e^{i \\alpha_j \\pi} (z_{j+1} - z_j)")]]

#text("for some real ")#mi("{c_j > 0}")#text(". (Note that ")#mi("{\\alpha_j}")#text(" cannot attain the values ")#mi("{0}")#text(" or ")#mi("{2}")#text(" as this would cause the polygonal path to be non-simple.) It is also convenient to introduce the normalised exterior angle ")#mi("{-1 < \\beta_j < 1}")#text(" by ")#mi("{\\beta_j := 1 - \\alpha_j}")#text(" (thus ")#mi("{\\beta_j}")#text(" is positive at a convex angle of the polygon, zero at a reflex angle, and negative at a concave angle), so that")

#align(center)[#tao-fit-display[#mitex("(z_{j+1}-z_j) = c_j^{-1} e^{i \\beta_j \\pi} (z_j - z_{j-1}).")]]

#text("Telescoping this identity, we conclude that ")#mi("{\\beta_1+\\dots+\\beta_n}")#text(" must be an even integer. Indeed, from Euclidean geometry we know that the sum of the exterior angles of a polygon add up to ")#mi("{2\\pi}")#text(", so that ")#metadata(none) <tao-e81935fb86434cdaaeee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\beta_1+\\dots+\\beta_n = 2;")]]

#text("we will give an analytic proof of this fact presently.")#linebreak()#text(" From the local structure of the interior of a closed contour (Exercise 54 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") we see that ")#mi("{U}")#text(" always lies to the left of the polygonal path ")#mi("{\\gamma_{z_1 \\rightarrow z_2 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(". We can formalise this statement as follows. First suppose that ")#mi("{z_*}")#text(" is a non-vertex boundary point of ")#mi("{U}")#text(", thus ")#mi("{z_* = (1-t) z_{j} + t z_{j+1}}")#text(" for some ")#mi("{1 \\leq j \\leq n}")#text(" and ")#mi("{0 < t < 1}")#text(". Then we can form the affine map ")#mi("{\\phi_{z_*}: {\\bf C} \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\phi_{z_*}( \\zeta ) := z_* + (z_{j+1} - z_{j}) \\zeta,")]]

#text("and the numbering rule tells us that for ")#mi("{\\varepsilon > 0}")#text(" small enough, the half-disk")

#align(center)[#tao-fit-display[#tao-math("D_+(0,\\varepsilon) := \\{ z \\in {\\bf C}: \\left|z\\right| < \\varepsilon, \\mathrm{Im}(z) > 0 \\}", block: true)]]

#text("is mapped holomorphically by ")#mi("{\\phi_{z_*}}")#text(" into ")#mi("{U}")#text(". If ")#mi("{z_* = z_j}")#text(" is instead a vertex of ")#mi("{U}")#text(", the situation is a little trickier; we now define the map ")#mi("{\\phi_{z_j}: {\\bf C} \\backslash I_- \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\phi_{z_j}( \\zeta ) := z_* + (z_{j+1}- z_{j}) \\zeta^{\\alpha_j}")]]

#text("where we choose the branch of ")#mi("{\\zeta \\rightarrow \\zeta^{\\alpha_j}}")#text(" with branch cut at the negative imaginary axis ")#mi("{I_- := \\{ iy: y \\leq 0 \\}}")#text(" and to be positive real on the positive real axis. Then again ")#mi("{\\phi_{z_j}}")#text(" will map ")#mi("{D_+(0,\\varepsilon)}")#text(" holomorphically into ")#mi("{U}")#text(" for ")#mi("{\\varepsilon}")#text(" small enough. (The reader is encouraged to draw a picture to understand these maps.)")#linebreak()#text(" Now we perform some local analysis near the boundary. We first need a version of the Schwarz reflection principle (Exercise 37 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(") for harmonic functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43 (Dirichlet problem)")]#text(" ")#metadata(none) <tao-2b64c6d9afd8a34ed0db>#text(" Let ")#mi("{f: S^1 \\rightarrow {\\bf R}}")#text(" be a continuous function. Show that there exists a unique function ")#mi("{u: \\overline{D(0,1)} \\rightarrow {\\bf R}}")#text(" that is continuous on the closed disk ")#mi("{\\overline{D(0,1)}}")#text(", harmonic on the open disk ")#mi("{D(0,1)}")#text(", and equal to ")#mi("{f}")#text(" on the boundary ")#mi("{S^1}")#text(". Furthermore, show that ")#mi("{u}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("u(z) = \\frac{1}{2\\pi} \\int_0^{2\\pi} P( e^{-i\\alpha}z) f(e^{i\\alpha})\\ d\\alpha")]]

#text("for ")#mi("{z \\in D(0,1)}")#text(", where ")#mi("{P}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]

#align(center)[#tao-fit-display[#mitex("P(z) := \\mathrm{Re} \\frac{1+z}{1-z}")]]

#text("(compare with Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("Notes 3")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 44 (Schwarz reflection for harmonic functions)")]#text(" ")#metadata(none) <tao-e925260155c960671fc1>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(" symmetric around the real axis, and let ")#mi("{u: \\overline{U_+} \\rightarrow {\\bf R}}")#text(" be a continuous function on the region ")#mi("{\\overline{U_+} := \\{z \\in U: \\mathrm{Im} z \\geq 0\\}}")#text(" that vanishes on ")#mi("{U \\cap {\\bf R}}")#text(" and is harmonic in ")#mi("{U_+ := \\{ z \\in U: \\mathrm{Im} z > 0 \\}}")#text(". Let ")#mi("{\\tilde u: U \\rightarrow {\\bf R}}")#text(" be the antisymmetric extension of ")#mi("{u}")#text(", defined by setting ")#mi("{\\tilde u(z) = u(z)}")#text(" and ")#mi("{\\tilde u(\\overline{z}) = -u(z)}")#text(" for ")#mi("{z \\in \\overline{U_+}}")#text(". Then ")#mi("{\\tilde u}")#text(" is harmonic.")
]

#emph[#text("Proof:")]#text(" Morally speaking, this lemma follows from the analogous reflection principle for holomorphic functions, but there is a difficulty because we do not have enough regularity on the real axis to easily build a harmonic conjugate that is continuous all the way to the real axis. Instead we shall rely on the maximum principle as follows.")#linebreak()#text(" It is clear that ")#mi("{\\tilde u}")#text(" is continuous and harmonic away from the real axis, so it suffices to show for any ")#mi("{x_0 \\in U \\cap {\\bf R}}")#text(" and any small ")#mi("{\\varepsilon>0}")#text(" that ")#mi("{\\tilde u}")#text(" is harmonic on ")#mi("{D(x_0,\\varepsilon)}")#text(".")#linebreak()#text(" Using Exercise ")#link(<tao-2b64c6d9afd8a34ed0db>)[#text("43")]#text(", we can find a continuous function ")#mi("{v: \\overline{D(x_0,\\varepsilon)} \\rightarrow {\\bf R}}")#text(" which agrees with ")#mi("{\\tilde u}")#text(" on the boundary and is harmonic on the interior. From the antisymmetry of ")#mi("{\\tilde u}")#text(" and uniqueness (or the Poisson kernel formula) we see that ")#mi("{v}")#text(" is also antisymmetric and thus vanishes on the real axis. The difference ")#mi("{\\tilde u-v}")#text(" is then harmonic on the half-disks ")#mi("{\\{ z \\in D(x_0,\\varepsilon): \\mathrm{Im} z > 0\\}}")#text(" and ")#mi("{\\{ z \\in D(x_0,\\varepsilon): \\mathrm{Im} z < 0\\}}")#text(" and vanishes on the boundary of these half-disks, so by the maximum principle they vanish everywhere in ")#mi("{D(x_0,\\varepsilon)}")#text(". Thus ")#mi("{\\tilde u}")#text(" agrees with ")#mi("{v}")#text(" on ")#mi("{D(x_0,\\varepsilon)}")#text(" and is therefore harmonic on this disk as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 45")]#text(" ")#metadata(none) <tao-504a6c94c1c5e0939608>#text(" Let ")#mi("{z_*}")#text(" be a boundary point of ")#mi("{U}")#text(" (which may or may not be a vertex). Then for ")#mi("{\\varepsilon > 0}")#text(" small enough, the maps ")#mi("{f \\circ \\phi_{z_*}: D_+(0,\\varepsilon) \\rightarrow D(0,1)}")#text(" extend holomorphically to a map from ")#mi("{D(0,\\varepsilon)}")#text(" to ")#mi("{{\\bf C}}")#text(" which maps the origin to a point on the unit circle. Furthermore, this map is injective for ")#mi("{\\varepsilon}")#text(" small enough.")
]

#emph[#text("Proof:")]#text(" For any ")#mi("{0 < r < 1}")#text(", the preimage ")#mi("{f^{-1}(\\overline{D(0,r)})}")#text(" of the closed disk ")#mi("{\\overline{D(0,r)}}")#text(" is a compact subset of ")#mi("{U}")#text(" and thus stays a positive distance away from the boundary of ")#mi("{U}")#text(". In particular, for ")#mi("{z \\in U}")#text(" sufficiently close to the boundary of ")#mi("{U}")#text(", ")#tao-math("{\\left|f(z)\\right|}", block: false)#text(" must exceed ")#mi("{r}")#text(". We conclude that the function ")#tao-math("{\\left|f\\right|: U \\rightarrow [0,1)}", block: false)#text(" extends continuously to a map from ")#mi("{\\overline{U}}")#text(" to ")#mi("{[0,1]}")#text(", by declaring the map to equal ")#mi("{1}")#text(" on the boundary. In particular, for ")#mi("{\\varepsilon}")#text(" small enough, the map ")#tao-math("{\\left|f\\right| \\circ \\phi_{z_*}: D_+(0,\\varepsilon) \\rightarrow [0,1)}", block: false)#text(" also extends continously to ")#mi("{\\overline{D_+(0,\\varepsilon)}}")#text(", and equals ")#mi("{1}")#text(" on the real boundary of ")#mi("{D_+(0,\\varepsilon)}")#text(". For ")#mi("{\\varepsilon}")#text(" small enough, ")#tao-math("{\\left|f\\right|}", block: false)#text(" avoids zero on this region, and so the function ")#tao-math("{\\log \\left|f\\right| \\circ \\phi_{z_*}: D_+(0,\\varepsilon) \\rightarrow {\\bf R}}", block: false)#text(" will extend continuously to ")#mi("{\\overline{D_+(0,\\varepsilon)}}")#text(", and vanish on the real portion of the boundary. By taking local branches of ")#mi("{\\log f}")#text(" we see that this function ")#tao-math("{\\log \\left|f\\right| \\circ \\phi_{z_*}}", block: false)#text(" is also harmonic. By Lemma ")#link(<tao-e925260155c960671fc1>)[#text("44")]#text(", ")#tao-math("{\\log \\left|f\\right| \\circ \\phi_{z_*}}", block: false)#text(" extends harmonically to ")#mi("{D(0,\\varepsilon)}")#text(", and on taking harmonic conjugates we conclude that ")#mi("{\\log f \\circ \\phi_{z_*}}")#text(" extends holomorphically to ")#mi("{D(0,\\varepsilon)}")#text(". Taking exponentials, we obtain a holomorphic extension ")#mi("{g_{z_*}: D(0,\\varepsilon) \\rightarrow {\\bf C}}")#text(" of ")#mi("{f \\circ \\phi_{z_*}}")#text(" to ")#mi("{D(0,\\varepsilon)}")#text(", with ")#tao-math("{\\left|g_{z_*}(0)\\right|=1}", block: false)#text(". To prove injectivity, it suffices (shrinking ")#mi("{\\varepsilon}")#text(" as necessary) to show that the derivative of ")#mi("{g_{z_*}}")#text(" at ")#mi("{0}")#text(" is non-zero. But if this were not the case, then ")#mi("{g_{z_*} - g_{z_*}(0)}")#text(" would have a zero of order at least two, which by the factor theorem implies that ")#mi("{g_{z_*} - g_{z_*}(0)}")#text(" would not map ")#mi("{D_+(0,\\varepsilon)}")#text(" to a half-plane bordering the origin, and in particular cannot map to ")#mi("{D(0,1) - g_{z_*}(0)}")#text(", a contradiction. ")#mi("\\Box")#linebreak()#text(" As a corollary, we see that ")#mi("{f}")#text(" extends to a continuous map ")#mi("{f: \\overline{U} \\rightarrow \\overline{D(0,1)}}")#text(" that maps ")#mi("{\\partial U}")#text(" to ")#mi("{S^1}")#text(", and around every point ")#mi("{z_*}")#text(" in the boundary of ")#mi("{U}")#text(", ")#mi("{f}")#text(" maps a small neighbourhood ")#mi("{\\phi_{z_*}(D_+(0,\\varepsilon))}")#text(" of ")#mi("{z_*}")#text(" in ")#mi("{U}")#text(" to a small neighbourhood of ")#mi("{f(z_*)}")#text(" in ")#mi("{D(0,1)}")#text(". As ")#mi("{f}")#text(" is injective on ")#mi("{U}")#text(", this implies that ")#mi("{f}")#text(" is also injective on the boundary of ")#mi("{U}")#text(". The image ")#mi("{f(\\overline{U})}")#text(" is compact in ")#mi("{\\overline{D(0,1)}}")#text(" and contains ")#mi("{D(0,1)}")#text(", hence ")#mi("{f: \\overline{U} \\rightarrow \\overline{D(0,1)}}")#text(" is in fact a bijective continuous map between compact Hausdorff spaces and is thus a homoeomorphism. Thus we can form an inverse map ")#mi("{F: \\overline{D(0,1)} \\rightarrow \\overline{U}}")#text(", which maps ")#mi("{D(0,1)}")#text(" holomorphically to ")#mi("{U}")#text(". (This latter claim in fact works if one replaces the polygonal path ")#mi("{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(" by a arbitrary simple closed curve; this is a ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_theorem_(conformal_mapping)")[#text("theorem of Carathéodory")]#text(".)")#linebreak()#text(" Consider the function ")#mi("{f}")#text(" on the line segment from ")#mi("{z_j}")#text(" to ")#mi("{z_{j+1}}")#text(". By Proposition ")#link(<tao-504a6c94c1c5e0939608>)[#text("45")]#text(", ")#mi("{f}")#text(" is smooth on this line segment, has non-zero derivative, and takes values in ")#mi("{S^1}")#text("; setting ")#mi("{w_j := f(z_j) \\in S^1}")#text(", we see that ")#mi("{f}")#text(" must traverse a simple curve from ")#mi("{w_j}")#text(" to ")#mi("{w_{j+1}}")#text(" in ")#mi("{S^1}")#text(". As ")#mi("{f}")#text(" is orientation preserving, ")#mi("{U}")#text(" lies to the left of the line segment ")#mi("{\\gamma_{z_j \\rightarrow z_{j+1}}}")#text(", and the disk ")#mi("{D(0,1)}")#text(" lies to the left of ")#mi("{S^1}")#text(" traversed anticlockwise, we see that ")#mi("{f}")#text(" must traverse the anticlockwise arc from ")#mi("{w_j}")#text(" to ")#mi("{w_{j+1}}")#text(". Following ")#mi("{f}")#text(" all around ")#mi("{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(", we see that ")#mi("{w_1,\\dots,w_n}")#text(" must be arranged anticlockwise in the unit circle in the sense that we have ")#mi("{w_j = e^{\\pi i \\theta_j}}")#text(" for all ")#mi("{1 \\leq j \\leq n}")#text(" for some")

#align(center)[#tao-fit-display[#mitex("\\theta_1 < \\theta_2 < \\dots < \\theta_n < \\theta_{n+1} := \\theta_1 + 2.")]]

#text("Inverting, we see that for any ")#mi("{1 \\leq j \\leq n}")#text(", ")#mi("{F}")#text(" smoothly maps the anticlockwise arc ")#mi("{\\{ e^{i\\theta}: \\theta_j < \\theta < \\theta_{j+1}\\}}")#text(" from ")#mi("{w_j}")#text(" to ")#mi("{w_{j+1}}")#text(" to the line segment ")#mi("{\\{ (1-t) z_j + t z_{j+1}: 0 < t < 1 \\}}")#text(" from ")#mi("{z_j}")#text(" to ")#mi("{z_{j+1}}")#text(", with derivative nonvanishing. Thus on taking arguments")

#align(center)[#tao-fit-display[#mitex("\\mathrm{arg} \\frac{d}{d\\theta} F(e^{i\\theta}) = \\mathrm{arg}(z_{j+1} - z_j)")]]

#text("and thus by the chain rule ")#metadata(none) <tao-9414886b1ebf025db067>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mathrm{arg} i e^{i\\theta} F^{\\prime}(e^{i\\theta}) = \\mathrm{arg}(z_{j+1} - z_j)")]]

#text("for ")#mi("{\\theta_j < \\theta < \\theta_{j+1}}")#text(".")#linebreak()#text(" Next, we study ")#mi("{f}")#text(" near ")#mi("{z_j}")#text(" (and ")#mi("{F}")#text(" near ")#mi("{w_j}")#text(") for some ")#mi("{1 \\leq j \\leq m}")#text(". From Proposition ")#link(<tao-504a6c94c1c5e0939608>)[#text("45")]#text(" we see that in a sufficiently small neighbourhood of ")#mi("{w_j}")#text(" in ")#mi("{\\overline{D(0,1)}}")#text(", one has ")#mi("{F = \\phi_{z_j} \\circ h_{z_j}}")#text(" for some injective holomorphic map ")#mi("{h_{z_j}}")#text(" from a neighbourhood of ")#mi("{w_j}")#text(" in ")#mi("{{\\bf C}}")#text(" to a neighbourhood of ")#mi("{0}")#text(" in ")#mi("{{\\bf C}}")#text(" that maps ")#mi("{w_j}")#text(" to zero. Since ")#mi("{F}")#text(" maps the arc from ")#mi("{w_j}")#text(" to ")#mi("{w_{j+1}}")#text(" to the line segment from ")#mi("{z_j}")#text(" to ")#mi("{z_{j+1}}")#text(", ")#mi("{h_{z_j}}")#text(" must map the portion of the arc from ")#mi("{w_j}")#text(" to ")#mi("{w_{j+1}}")#text(" near ")#mi("{w_j}")#text(" to a portion of the positive real axis; in particular, by the chain rule, ")#mi("{i w_j h^{\\prime}_{z_j}(w_j)}")#text(" is a positive real, call it ")#mi("{a_j}")#text(". If we factor")

#align(center)[#tao-fit-display[#mitex("h_{z_j}(w) = a_j \\frac{w-w_j}{iw_j} \\frac{h_{z_j}(w)}{h^{\\prime}_{z_j}(w_j) (w - w_j)},")]]

#text("noting that the third factor is close to one and the second factor lies in the upper half-plane, we have")

#align(center)[#tao-fit-display[#mitex("h_{z_j}(w)^{\\alpha_j} = a_j^{\\alpha_j} (\\frac{w-w_j}{iw_j})^{\\alpha_j} (\\frac{h_{z_j}(w)}{h^{\\prime}_{z_j}(w_j) (w - w_j)})^{\\alpha_j}")]]

#text("and hence from ")#mi("{F = \\phi_{z_j} \\circ h_{z_j}}")#text(" we have the factorisation")

#align(center)[#tao-fit-display[#mitex("F(w) = z_j + (\\frac{w-w_j}{iw_j})^{\\alpha_j} G_j(w)")]]

#text("for ")#mi("{w}")#text(" near ")#mi("{w_j}")#text(" in ")#mi("{D(0,1)}")#text(", for some ")#mi("{G_j}")#text(" that is holomorphic and non-zero in a neighbourhood of ")#mi("{w_j}")#text(" in ")#mi("{{\\bf C}}")#text(". Differentiating using ")#mi("{\\beta_j = 1 - \\alpha_j}")#text(", we conclude that ")#metadata(none) <tao-9b6b882bf8be9361dacc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("F^{\\prime}(w) = (\\frac{w-w_j}{iw_j})^{-\\beta_j} \\tilde G_j(w)")]]

#text("for ")#mi("{w}")#text(" near ")#mi("{w_j}")#text(" in ")#mi("{D(0,1)}")#text(", for some ")#mi("{\\tilde G_j}")#text(" that is also holomorphic and non-zero in a neighbourhood of ")#mi("{w_j}")#text(" in ")#mi("{{\\bf C}}")#text(".")#linebreak()#text(" The function ")#mi("{F^{\\prime}: D(0,1) \\rightarrow {\\bf C}}")#text(" is holomorphic and non-vanishing; as ")#mi("{D(0,1)}")#text(" is simply connected, we must therefore have ")#mi("{F^{\\prime} = \\exp(H)}")#text(" for some holomorphic ")#mi("{H: D(0,1) \\rightarrow {\\bf C}}")#text(" (by Exercise 47 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text("). For any ")#mi("{\\theta}")#text(" between ")#mi("{\\theta_j}")#text(" and ")#mi("{\\theta_{j+1}}")#text(", we see from the previous discussion that ")#mi("{F}")#text(" extends holomorphically to a neighbourhood of ")#mi("{e^{i\\theta}}")#text(", with ")#mi("{F^{\\prime}}")#text(" non-vanishing at ")#mi("{e^{i\\theta}}")#text(", so ")#mi("{H}")#text(" extends also. From ")#link(<tao-9414886b1ebf025db067>)[#text("(3)")]#text(" we see that the argument of ")#mi("{i e^{i\\theta} \\exp( H(e^{i\\theta}) )}")#text(" is constant on the interval ")#mi("{(\\theta_j, \\theta_{j+1})}")#text(", and hence ")#metadata(none) <tao-63bc9e3734391984de9d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\theta + \\mathrm{Im}( H(e^{i\\theta}))")]]

#text("is also constant on this interval. Meanwhile, from ")#link(<tao-9b6b882bf8be9361dacc>)[#text("(4)")]#text(" we see that for ")#mi("{w}")#text(" near ")#mi("{w_j = e^{i\\theta_j}}")#text(" in ")#mi("{D(0,1)}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("H(w) = - \\beta_j \\mathrm{Log}_{I_-}( \\frac{w-w_j}{iw_j}) + g_j(w)")]]

#text("for some ")#mi("{g_j}")#text(" holomorphic in a neighbourhood of ")#mi("{w_j}")#text(" in ")#mi("{{\\bf C}}")#text(", where ")#mi("{\\mathrm{Log}_{I_-}}")#text(" is a branch of the complex logarithm with branch cut at ")#mi("{I_-}")#text(". From this we see that the function ")#mi("{\\theta \\mapsto \\theta + \\mathrm{Im}( H(e^{i\\theta}))}")#text(" has a jump discontinuity with jump ")#mi("{\\beta_j \\pi}")#text(" as ")#mi("{\\theta}")#text(" crosses ")#mi("{\\theta_j}")#text(". As this function clearly increases by ")#mi("{2\\pi}")#text(" when ")#mi("{\\theta}")#text(" increases by ")#mi("{2\\pi}")#text(", we conclude the geometric identity ")#link(<tao-e81935fb86434cdaaeee>)[#text("(2)")]#text(".")#linebreak()#text(" Now consider the modified function ")#mi("{\\tilde H: D(0,1) \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\tilde H(w) := H(w) + \\sum_{j=1}^n \\beta_j \\mathrm{Log}_{I_-}( \\frac{w-w_j}{iw_j}).")]]

#text("Then ")#mi("{\\tilde H}")#text(" is holomorphic on ")#mi("{D(0,1)}")#text(", and by the above analysis it extends continuously to ")#mi("{\\overline{D(0,1)}}")#text(". We consider the imaginary part at ")#mi("{w = e^{i\\theta}}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Im} \\tilde H(e^{i\\theta}) := \\mathrm{Im} H(e^{i\\theta}) + \\sum_{j=1}^n \\beta_j \\mathrm{Arg}_{I_-}( \\frac{e^{i\\theta}-w_j}{iw_j}),")]]

#text("where ")#mi("{\\mathrm{Arg}_{I_-}}")#text(" is a branch of the argument function with branch cut at ")#mi("{I_-}")#text(". Writing ")#mi("{e^{i\\theta} - w_j = 2 i e^{i(\\theta+\\theta_j)/2} \\sin( (\\theta - \\theta_j)/2 )}")#text(", we see that ")#mi("{\\mathrm{Arg}_{I_-}( \\frac{e^{i\\theta}-w_j}{iw_j}) - \\theta/2}")#text(" is constant as long as ")#mi("{\\theta - \\theta_j}")#text(" is not an integer multiple of ")#mi("{2\\pi}")#text(". From this, ")#link(<tao-63bc9e3734391984de9d>)[#text("(5)")]#text(", and ")#link(<tao-e81935fb86434cdaaeee>)[#text("(2)")]#text(", we see that the function ")#mi("{\\theta \\mapsto \\mathrm{Im} \\tilde H(e^{i\\theta})}")#text(" is constant on each arc ")#mi("{\\theta_j < \\theta < \\theta_{j+1}}")#text(". Thus the function ")#mi("{\\mathrm{Im} \\tilde H}")#text(" is harmonic on ")#mi("{D(0,1)}")#text(", continuous on ")#mi("{\\overline{D(0,1)}}")#text(", and constant on the boundary ")#mi("{S^1}")#text(", so by the maximum principle it is constant, which from the Cauchy-Riemann equations makes ")#mi("{\\tilde H}")#text(" constant also. Thus we have")

#align(center)[#tao-fit-display[#mitex("H(w) = c - \\sum_{j=1}^n \\beta_j \\mathrm{Log}_{I_-}( \\frac{w-w_j}{iw_j})")]]

#text("on ")#mi("{D(0,1)}")#text(" for some complex constant ")#mi("{c}")#text(", which on exponentiating gives ")#metadata(none) <tao-b1f528cad50461bcce79>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("F^{\\prime}(w) = \\frac{C_1}{\\prod_{j=1}^n ( \\frac{w-w_j}{iw_j} )^{\\beta_j} }")]]

#text("on ")#mi("{D(0,1)}")#text(" for some non-zero complex constant ")#mi("{C_1}")#text(". Applying the fundamental theorem of calculus, we obtain the ")#link("https://en.wikipedia.org/wiki/Schwarz%E2%80%93Christoffel_mapping")[#text("Schwarz-Christoffel formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 46 (Schwarz-Christoffel for the disk)")]#text(" Let ")#mi("{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(" be a closed simple anticlockwise polygonal path, and define the exterior angles ")#mi("{-1 < \\beta_1,\\dots,\\beta_n < 1}")#text(" as above. Let ")#mi("{U}")#text(" be the polygon enclosed by this path, and let ")#mi("{F: D(0,1) \\rightarrow U}")#text(" be a complex diffeomorphism. Then there exist phases ")#mi("{w_j = e^{i \\pi \\theta_j}}")#text(", ")#mi("{j=1,\\dots,n}")#text(" for some ")#mi("{\\theta_1 < \\dots < \\theta_n < \\theta_1+2}")#text(", a non-zero complex number ")#mi("{C_1}")#text(", and a complex number ")#mi("{C_2}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("F(w) = C_1 \\int_0^w \\frac{d\\omega}{\\prod_{j=1}^n ( \\frac{\\omega-w_j}{iw_j} )^{\\beta_j} } + C_2")]]

#text("for all ")#mi("{w \\in D(0,1)}")#text(", where the integral is over an arbitrary curve from ")#mi("{0}")#text(" to ")#mi("{w}")#text(", and one selects a branch of ")#mi("{z \\mapsto z^{\\beta_j}}")#text(" with branch cut on the negative imaginary axis ")#mi("{I_- := \\{iy: y \\geq 0\\}}")#text(". Furthermore, ")#mi("{F(w)}")#text(" converges to ")#mi("{z_j}")#text(" as ")#mi("{w}")#text(" approaches ")#mi("{w_j}")#text(" for every ")#mi("{1 \\leq j \\leq n}")#text(".")
]

#text("Note that one can change the branches of ")#mi("{z \\mapsto z^{\\beta_j}}")#text(" here, and also modify the normalising factors ")#mi("{iw_j}")#text(", by adjusting the constant ")#mi("{C_1}")#text(" in a suitable fashion, as long one does not move the branch cut for ")#mi("{\\prod_{j=1}^n ( \\frac{\\omega-w_j}{iw_j} )^{\\beta_j}}")#text(" into the disk ")#mi("{D(0,1)}")#text("; one can similarly change the initial point ")#mi("{0}")#text(" of the curve to any other point in ")#mi("{D(0,1)}")#text(" by adjusting ")#mi("{C_2}")#text(". By taking log-derivatives in ")#link(<tao-b1f528cad50461bcce79>)[#text("(6)")]#text(", we can also express the Schwarz-Christoffel formula equivalently as a partial fractions decomposition of ")#mi("{F^{\\prime\\prime}/F^{\\prime}}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\frac{F^{\\prime\\prime}(w)}{F^{\\prime}(w)} = \\sum_{j=1}^n \\frac{\\beta_j}{w-w_j}.")]]

#text("The Schwarz-Christoffel formula does not completely describe the conformal mappings from ")#mi("{U}")#text(" to the disk, because it does not specify exactly what the phases ")#mi("{w_j}")#text(" and the complex constants ")#mi("{C_1,C_2}")#text(" are. As the group of automorphisms ")#mi("{z \\mapsto e^{i\\theta} \\frac{z-\\alpha}{1-\\overline{\\alpha}z}}")#text(" of ")#mi("{D(0,1)}")#text(" has three degrees of freedom (one real parameter ")#mi("{\\theta}")#text(" and one complex parameter ")#mi("{\\alpha}")#text("), one can for instance fix three of the phases ")#mi("{w_j}")#text(", but in general there are no simple formulae to then reconstruct the remaining parameters in the Schwarz-Christoffel formula, although numerical algorithms exist to compute them approximately. (In the case when the polygon is a rectangle, though, the Schwarz-Christoffel formula essentially produces an ")#link("https://en.wikipedia.org/wiki/Elliptic_integral")[#text("elliptic integral")]#text(", and the complex diffeomorphisms from the rectangle to the disk or half-space are closely tied to ")#link("https://en.wikipedia.org/wiki/Elliptic_function")[#text("elliptic functions")]#text("; see Section 4.5 of Stein-Shakarchi for more discussion.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Schwarz-Christoffel in a half-plane)")]#text(" Let ")#mi("{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(" be a closed simple anticlockwise polygonal path, and define the exterior angles ")#mi("{-1 < \\beta_1,\\dots,\\beta_n < 1}")#text(" as above. Let ")#mi("{U}")#text(" be the polygon enclosed by this path, and let ")#mi("{F: {\\bf H} \\rightarrow U}")#text(" be a complex diffeomorphism from the upper half-plane ")#mi("{{\\bf H} := \\{ w \\in {\\bf C}: \\mathrm{Im} w > 0 \\}}")#text(" to ")#mi("{U}")#text(".")

#list(
[#text("(i) Show that ")#mi("{F}")#text(" extends to a homeomorphism from the closure ")#mi("{\\overline{{\\bf H}}}")#text(" of the upper half-plane in the Riemann sphere to ")#mi("{\\overline{U}}")#text(", and that ")#mi("{f(z_1),\\dots,f(z_n)}")#text(" all lie on ")#mi("{{\\bf R} \\cup \\{\\infty\\}}")#text(", where ")#mi("{f: \\overline{U} \\rightarrow {\\bf H}}")#text(" is the inverse of the extension of ")#mi("{F}")#text(".")],
[#text("(ii) If all of the ")#mi("{f(z_1),\\dots,f(z_n)}")#text(" are finite, show that after a cyclic permutation one has ")#mi("{f(z_1) < \\dots < f(z_n)}")#text(", and that there exists a non-zero complex number ")#mi("{C_1}")#text(", and a complex number ")#mi("{C_2}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("F(w) = C_1 \\int_i^w \\frac{d\\omega}{\\prod_{j=1}^{n} ( \\omega-f(z_j) )^{\\beta_j} } + C_2")]]

#text("for all ")#mi("{w \\in {\\bf H}}")#text(", where the integral is over any curve from ")#mi("{i}")#text(" to ")#mi("{w}")#text(" in ")#mi("{{\\bf H}}")#text(".")],
[#text("(iii) If one of the ")#mi("{f(z_1),\\dots,f(z_n)}")#text(" are infinite, show after a cyclic permutation that one has ")#mi("{f(z_1) < \\dots < f(z_{n-1})}")#text(" and ")#mi("{f(z_n) = \\infty}")#text(", and there exists a non-zero complex number ")#mi("{C_1}")#text(", and a complex number ")#mi("{C_2}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("F(w) = C_1 \\int_i^w \\frac{d\\omega}{\\prod_{j=1}^{n-1} ( \\omega-f(z_j) )^{\\beta_j} } + C_2")]]

#text("for all ")#mi("{w \\in {\\bf H}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 48")]#text(" One could try to apply the Schwarz-Christoffel formula to a closed polygonal path ")#mi("{\\gamma_{z_1 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}}")#text(" that is not simple. In such cases (and after choosing the parameters ")#mi("{C_1,C_2,w_1,\\dots,w_n}")#text(" correctly), what tends to happen is that the map ")#mi("{F}")#text(" still maps the circle ")#mi("{S^1}")#text(" to the closed path, but fails to be injective.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" Let ")#mi("{F: P \\rightarrow {\\bf H}}")#text(" be a complex diffeomorphism from the half-strip ")#mi("{P := \\{ z \\in {\\bf C}: \\mathrm{Im} z > 0; -\\frac{\\pi}{2} < \\mathrm{Re} z < \\frac{\\pi}{2} \\}}")#text(" to the upper half-plane ")#mi("{{\\bf H}}")#text(", which extends to a continuous map ")#mi("{F: \\overline{P} \\rightarrow \\overline{{\\bf H}}}")#text(" to the closures of ")#mi("{P}")#text(", ")#mi("{{\\bf H}}")#text(" in the Riemann sphere. Suppose that ")#mi("{F}")#text(" maps ")#mi("{-\\frac{\\pi}{2}, \\frac{\\pi}{2}, \\infty}")#text(" to ")#mi("{-1,1,\\infty}")#text(" respectively. Show that ")#mi("{F^{\\prime}(w) = \\frac{1}{(1-w^2)^{1/2}}}")#text(", where we take the branch of the square root that is positive on the real axis and has a branch cut at ")#mi("{I_-}")#text(". (")#emph[#text("Hint:")]#text(" ")#mi("{P}")#text(" is not quite a polygon, so one cannot directly apply the Schwarz-Christoffel formula; however the ")#emph[#text("proof")]#text(" of that formula will still apply.)")#linebreak()#text(" There is a simple description of ")#mi("{F}")#text(" in terms of trigonometric functions. What is it?")
]

#heading(level: 1)[#strong[#text(" — 5. The uniformisation theorem (optional) — ")]]

#text("Now we discuss a proof of the uniformisation theorem, Theorem ")#link(<tao-ef379363dd0cb7be6663>)[#text("5")]#text(", following the approach in ")#link("https://www.math.washington.edu/~marshall/preprints/uniformizationII.pdf")[#text("these notes of Marshall")]#text(". Unfortunately the argument is rather complicated, and we will only give a portion of the proof here. One of the many difficulties in trying to prove this theorem is the fact that the conclusion is a disjunction of three alternatives, each with a rather different complex geometry; it would be easier if there was only one target geometry that one was trying to impose on the Riemann surface ")#mi("{M}")#text(". To begin separating the three geometries from each other, recall from Liouville’s theorem that there are no non-constant bounded holomorphic functions on ")#mi("{{\\bf C}}")#text(" or ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", but plenty of non-constant bounded holomorphic functions on ")#mi("{D(0,1)}")#text(". By Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text(", the same claims hold for Riemann surfaces that are complex diffeomorphic to ")#mi("{{\\bf C}}")#text(" or ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" or to ")#mi("{D(0,1)}")#text(" respectively. Note that without loss of generality we may normalise “bounded” by replacing it with “mapping into ")#mi("{D(0,1)}")#text("“. From this we see that the uniformisation theorem can be broken up into two simpler pieces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 50 (Uniformisation theorem, hyperbolic case)")]#text(" ")#metadata(none) <tao-91e235e3f8168853b4d9>#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface that admits a non-constant holomorphic map from ")#mi("{M}")#text(" to ")#mi("{D(0,1)}")#text(". Then ")#mi("{M}")#text(" is complex diffeomorphic to ")#mi("{D(0,1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 51 (Uniformisation theorem, non-hyperbolic case)")]#text(" ")#metadata(none) <tao-1259d90a976742a1738d>#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface that does not admit a non-constant holomorphic map from ")#mi("{M}")#text(" to ")#mi("{D(0,1)}")#text(". Then ")#mi("{M}")#text(" is complex diffeomorphic to ")#mi("{{\\bf C}}")#text(" or ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(".")
]

#text("Let us now focus on the hyperbolic case of the uniformisation theorem, Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(". Now we do not have the disjunction problem as there is only one target geometry to impose on ")#mi("{M}")#text("; we will be able to give a complete proof of this theorem here (in contrast to Theorem ")#link(<tao-1259d90a976742a1738d>)[#text("51")]#text(", where we will only give part of the proof). Let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(", and recall that ")#mi("{{\\mathcal H}_{p_0}}")#text(" denotes the collection of holomorphic maps ")#mi("{f: M \\rightarrow D(0,1)}")#text(" that maps ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(". By hypothesis (and applying a suitable automorphism of ")#mi("{D(0,1)}")#text("), ")#mi("{{\\mathcal H}_{p_0}}")#text(" contains at least one non-constant map. If Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(" were true, then from Lemma ")#link(<tao-12919cd5a1038a00a78c>)[#text("39")]#text(" we see that ")#mi("{{\\mathcal H}_{p_0}}")#text(" would contain a “maximal” element ")#mi("{\\phi}")#text(" which would exhibit the desired complex diffeomorphism between ")#mi("{M}")#text(" and ")#mi("{D(0,1)}")#text(".")#linebreak()#text(" It turns out that the converse statement is true: if we can locate “maximal” elements of ")#mi("{{\\mathcal H}_{p_0}}")#text(" with certain properties, then we can prove Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(". More precisely, Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(" can be readily deduced from the following claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 52 (Maximal maps into ")#mi("{D(0,1)}")#text(")")]#text(" ")#metadata(none) <tao-16e0a9115980c4261929>#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface, let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(", and let ")#mi("{{\\mathcal H}_{p_0}}")#text(" be the collection of holomorphic maps from ")#mi("{M}")#text(" to ")#mi("{D(0,1)}")#text(" that map ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(". Suppose that ")#mi("{{\\mathcal H}_{p_0}}")#text(" contains a non-constant map. Then ")#mi("{{\\mathcal H}_{p_0}}")#text(" contains a map ")#mi("{\\phi_{p_0}: M \\rightarrow D(0,1)}")#text(" with the property that ")#tao-math("{\\left|f(p)\\right| \\leq \\left|\\phi_{p_0}(p)\\right|}", block: false)#text(" for all ")#mi("{p \\in M \\backslash \\{p_0\\}}")#text(" and ")#mi("{f \\in {\\mathcal H}_{p_0}}")#text(", with equality only if ")#mi("{f = e^{i\\theta} \\phi_{p_0}}")#text(" for some real number ")#mi("{\\theta}")#text(". Furthermore ")#mi("{\\phi_{p_0}}")#text(" has a simple zero at ")#mi("{p_0}")#text(", and no other zeroes.")
]

#text("We have seen how Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(" implies Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(". Let us now demonstrate the converse implication, assuming Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" for the moment and deriving Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(". Let ")#mi("{M}")#text(" be a simply connected Riemann surface that admits non-constant holomorphic maps from ")#mi("{M}")#text(" to ")#mi("{D(0,1)}")#text(", and pick a point ")#mi("{p_0}")#text(" in ")#mi("{M}")#text(". By applying a suitable automorphism of ")#mi("{D(0,1)}")#text(" we see that ")#mi("{{\\mathcal H}_{p_0}}")#text(" has a non-constant map, so by Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" this collection contains an element ")#mi("{\\phi_{p_0}}")#text(" with the stated properties. Now let ")#mi("{p_0,p_1}")#text(" be two points in ")#mi("{M}")#text(". Since ")#mi("{\\phi_{p_0}}")#text(" has a zero only at ")#mi("{p_0}")#text(", we thus have ")#mi("{\\phi_{p_0}(p_1) \\neq 0}")#text(". Let ")#mi("{R: D(0,1) \\rightarrow D(0,1)}")#text(" be the automorphism")

#align(center)[#tao-fit-display[#mitex("R(z) := \\frac{z - \\phi_{p_0}(p_1)}{1 - \\overline{\\phi_{p_0}(p_1)} z}")]]

#text("that maps ")#mi("{\\phi_{p_0}(p_1)}")#text(" to ")#mi("{0}")#text(" and ")#mi("{0}")#text(" to ")#mi("{-\\phi_{p_0}(p_1)}")#text(", then the function ")#mi("{R \\circ \\phi_{p_0}: M \\rightarrow D(0,1)}")#text(" lies in ")#mi("{{\\mathcal H}_{p_1}}")#text(". From Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|R \\circ \\phi_{p_0}(p_0)\\right| \\leq \\left|\\phi_{p_1}(p_0)\\right|;", block: true)]]

#text("since ")#mi("{\\phi_{p_0}(p_0)}")#text(" vanishes, we thus have from the definition of ")#mi("{R}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\phi_{p_0}(p_1)\\right| \\leq \\left|\\phi_{p_1}(p_0)\\right|.", block: true)]]

#text("Swapping the roles of ")#mi("{p_0}")#text(" and ")#mi("{p_1}")#text(" gives the reverse inequality, thus we in fact have")

#align(center)[#tao-fit-display[#tao-math("\\left|R \\circ \\phi_{p_0}(p_0)\\right| = \\left|\\phi_{p_1}(p_0)\\right|", block: true)]]

#text("and ")#metadata(none) <tao-a2052ddf9e8c0c3d01cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\phi_{p_0}(p_1)\\right| =\\left|\\phi_{p_1}(p_0)\\right|.", block: true)]]

#text("Applying Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" again, we conclude that ")#metadata(none) <tao-308c94b67244d5a57d16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("R \\circ \\phi_{p_0} = e^{i\\theta} \\phi_{p_1}")]]

#text("for some ")#mi("{\\theta \\in {\\bf R}}")#text(".")#linebreak()#text(" Using this identity, we can now show that each of the ")#mi("{\\phi_{p_0}}")#text(" are injective. Indeed, if ")#mi("{\\phi_{p_0}}")#text(" was not injective, then we must have ")#mi("{\\phi_{p_0}(p_1) = \\phi_{p_0}(p_2)}")#text(" for some distinct ")#mi("{p_1,p_2 \\in M}")#text(", neither of which can equal ")#mi("{p_0}")#text(" since ")#mi("{\\phi_{p_0}}")#text(" has no other zeroes than ")#mi("{p_0}")#text(". But then by ")#link(<tao-308c94b67244d5a57d16>)[#text("(8)")]#text(" we see that ")#mi("{\\phi_{p_1}(p_2) = \\phi_{p_1}(p_1) = 0}")#text(", contradicting the fact that ")#mi("{\\phi_{p_1}}")#text(" has a zero only at ")#mi("{p_1}")#text(". Thus ")#mi("{\\phi_{p_0}}")#text(" is indeed injective. Applying Proposition ")#link(<tao-6c45cb72a36e63d522aa>)[#text("41")]#text(" we conclude that ")#mi("{M}")#text(" and ")#mi("{D(0,1)}")#text(" were complex diffeomorphic. This concludes the derivation of Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(" from Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 53")]#text(" We only established that ")#mi("{\\phi_{p_0}: M \\rightarrow D(0,1)}")#text(" was injective in the above argument, but by inspecting the proof of Proposition ")#link(<tao-6c45cb72a36e63d522aa>)[#text("41")]#text(" and using the maximality properties of ")#mi("{\\phi_{p_0}}")#text(" we see that ")#mi("{\\phi_{p_0}}")#text(" is also surjective, and thus supplies the required complex diffeomorphism between ")#mi("{M}")#text(" and ")#mi("{D(0,1)}")#text(". In a similar vein, the arguments in the preceding section show that under the hypotheses of Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(", there exists a ")#emph[#text("surjective")]#text(" map from ")#mi("{M}")#text(" to ")#mi("{D(0,1)}")#text(", but one needs something like Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" to obtain the crucial additional property of injectivity (which was automatic in the preceding section, since one already started with an injection in hand).")
]

#text("To finish off the hyperbolic case of the uniformisation theorem, it remains to prove Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(". It is convenient to work with harmonic functions instead of holomorphic functions. Observe that if ")#mi("{\\phi_{p_0}: M \\rightarrow D(0,1)}")#text(" were holomorphic with a simple zero at ")#mi("{p_0}")#text(" but no other zeroes, then we have local holomorphic branches of ")#mi("{\\log \\frac{1}{\\phi_{p_0}}}")#text(" on small neighbourhoods of any point in ")#mi("{M \\backslash \\{p_0\\}}")#text(". Taking real parts, we conclude that the function ")#tao-math("{g_{p_0} := \\log \\frac{1}{\\left|\\phi_{p_0}\\right|}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}", block: false)#text(" is harmonic on the punctured surface ")#mi("{M \\backslash \\{p_0\\}}")#text("; it is also positive since ")#mi("{\\phi_{p_0}}")#text(" takes values in ")#mi("{D(0,1)}")#text(". Furthermore, the function ")#mi("{g_{p_0}}")#text(" has a logarithmic singularity at ")#mi("{p_0}")#text(" in the following sense: if ")#mi("{z: U_{p_0} \\rightarrow D(0,1)}")#text(" was any coordinate chart on some neighbourhood ")#mi("{U_{p_0}}")#text(" of ")#mi("{p_0}")#text(" that mapped ")#mi("{p_0}")#text(" to ")#mi("{D(0,1)}")#text(", then as ")#mi("{\\phi_{p_0}}")#text(" had a simple zero at ")#mi("{p_0}")#text(", the function ")#tao-math("{\\log \\frac{1}{\\left|\\phi_{p_0}\\right|} - \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(", defined on ")#mi("{U_{p_0} \\backslash \\{p_0\\}}")#text(", stays bounded as one approaches ")#mi("{p_0}")#text(".")#linebreak()#text(" Conversely, one can reconstruct ")#mi("{\\phi_{p_0}}")#text(" from ")#mi("{g_{p_0}}")#text(" (up to a harmless phase ")#mi("{e^{i\\theta}}")#text(") by the following lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 54 (Reconstructing a holomorphic function from its magnitude)")]#text(" ")#metadata(none) <tao-9ec6f84751b054853670>#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface, let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(", and let ")#mi("{g_{p_0}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" be harmonic. Suppose that ")#mi("{g_{p_0}}")#text(" has a logarithmic singularity at ")#mi("{p_0}")#text(" in the sense that ")#tao-math("{g_{p_0} - \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is bounded near ")#mi("{p_0}")#text(" for some coordinate chart ")#mi("{z: U_{p_0} \\rightarrow D(0,1)}")#text(" on a neighbourhood ")#mi("{U_{p_0}}")#text(" of ")#mi("{p_0}")#text(" that maps ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(". Then there exists a holomorphic function ")#mi("{\\phi: M \\rightarrow {\\bf C}}")#text(" with a simple zero at ")#mi("{p_0}")#text(" and no other zeroes, such that ")#tao-math("{g_{p_0} = \\log \\frac{1}{\\left|\\phi\\right|}}", block: false)#text(" on ")#mi("{M \\backslash \\{p_0\\}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{g_{p_0}}")#text(" be as above. Call a function ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" on an open subset ")#mi("{U}")#text(" of ")#mi("{M}")#text(" ")#emph[#text("good")]#text(" if it is holomorphic with ")#tao-math("{g_{p_0} = \\log \\frac{1}{\\left|\\phi\\right|}}", block: false)#text(" on ")#mi("{U \\backslash \\{p_0\\}}")#text(" (in particular this forces ")#mi("{\\phi}")#text(" to be non-zero away from ")#mi("{p_0}")#text("), and has a simple zero at ")#mi("{p_0}")#text(" if ")#mi("{p_0}")#text(" lies in ")#mi("{U}")#text(". Clearly it will suffice to find a good function on all of ")#mi("{M}")#text(".")#linebreak()#text(" We first solve the local problem, showing that for any ")#mi("{p \\in M}")#text(" there exists a neighbourhood ")#mi("{U_p}")#text(" of ")#mi("{p}")#text(" that supports a good function ")#mi("{\\phi_p: U_p \\rightarrow {\\bf C}}")#text(". If ")#mi("{p \\neq p_0}")#text(", we can work in a chart ")#mi("{U_p}")#text(" avoiding ")#mi("{p_0}")#text(" which is diffeomorphic to a disk ")#mi("{D(0,1)}")#text(". If we identify ")#mi("{U_p}")#text(" with ")#mi("{D(0,1)}")#text(" then ")#mi("{g_{p_0}}")#text(" restricted to ")#mi("{U_p}")#text(" can be viewed as a harmonic function on ")#mi("{D(0,1)}")#text(". As this disk is simply connected, ")#mi("{g}")#text(" will have a harmonic conjugate and is thus the real part of a holomorphic function ")#mi("{f}")#text(" on this disk. Taking ")#mi("{\\phi_p}")#text(" to be ")#mi("{e^{-f}}")#text(" we obtain the required good function. Now suppose instead that ")#mi("{p = p_0}")#text(". Using the coordinate chart ")#mi("{z: U_{p_0} \\rightarrow D(0,1)}")#text(" to identify ")#mi("{U_{p_0}}")#text(" with ")#mi("{D(0,1)}")#text(", we now have a harmonic function ")#mi("{g_{p_0}: D(0,1) \\backslash \\{0\\} \\rightarrow {\\bf R}}")#text(" with ")#tao-math("{g_{p_0} - \\log\\frac{1}{\\left|z\\right|}}", block: false)#text(" bounded near zero. Applying Exercise 60 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(", we conclude that ")#tao-math("{g_{p_0} - \\log\\frac{1}{\\left|z\\right|}}", block: false)#text(" extends to a harmonic function ")#mi("{h}")#text(" on ")#mi("{D(0,1)}")#text(", which is then the real part of a holomorphic function ")#mi("{f}")#text("; taking ")#mi("{\\phi_{p_0} := z e^{-f}}")#text(" then gives a good function on ")#mi("{U_{p_0}}")#text(".")#linebreak()#text(" Next, we make the following compatibility observation: if ")#mi("{\\phi: U \\rightarrow {\\bf R}}")#text(" and ")#mi("{\\psi: V \\rightarrow {\\bf R}}")#text(" are both good functions, then ")#mi("{\\phi/\\psi}")#text(" is constant on every connected component of ")#mi("{U \\cap V}")#text(" (after removing any singularity at ")#mi("{p_0}")#text("). Indeed, by construction ")#mi("{\\phi/\\psi}")#text(" is holomorphic and of magnitude one, so locally there are holomorphic branches of ")#mi("{\\log(\\phi/\\psi)}")#text(" that have vanishing real part, hence locally constant imaginary part by the Cauchy-Riemann equations. Hence ")#mi("{\\phi/\\psi}")#text(" is locally constant as claimed.")#linebreak()#text(" Now we need to glue together the local good functions into a global good function. This is a “monodromy problem”, which can be solved using analytic continuation and the simply connected nature of ")#mi("{M}")#text(" by the following “")#link("https://en.wikipedia.org/wiki/Monodromy_theorem")[#text("monodromy theorem")]#text("” argument. Let us pick a good function ")#mi("{\\phi_{p_0}: U_{p_0} \\rightarrow {\\bf R}}")#text(" on some neighbourhood of ")#mi("{p_0}")#text(". Given any other point ")#mi("{p}")#text(" in ")#mi("{M}")#text(", we can form a path ")#mi("{\\gamma: [0,1] \\rightarrow M}")#text(" from ")#mi("{p_0}")#text(" to ")#mi("{p}")#text(". We claim that for any ")#mi("{0 \\leq T \\leq 1}")#text(", we can find a finite sequence ")#mi("{0 = t_0 < t_1 < \\dots < t_n = T}")#text(" and good functions ")#mi("{\\phi_j: U_j \\rightarrow {\\bf R}}")#text(" for ")#mi("{j=1,\\dots,n}")#text(" such that each ")#mi("{U_j}")#text(" contains ")#mi("{\\gamma([t_{j-1},t_j])}")#text(", and such that ")#mi("{\\phi_j}")#text(" and ")#mi("{\\phi_{j+1}}")#text(" agree on a neighbourhood of ")#mi("{\\gamma(t_j)}")#text(" for each ")#mi("{j=1,\\dots,n-1}")#text(", and ")#mi("{\\phi_1}")#text(" and ")#mi("{\\phi_{p_0}}")#text(" also agree on a neighbourhood of ")#mi("{\\gamma(t_0)}")#text(". The set ")#mi("{\\Omega}")#text(" of such ")#mi("{T}")#text(" is easily seen to be an open non-empty subset of ")#mi("{[0,1]}")#text(". Now we claim that it is closed. Suppose that ")#mi("{T_k \\in \\Omega}")#text(" converges to a limit ")#mi("{T_* \\in \\Omega}")#text(" as ")#mi("{k \\rightarrow \\infty}")#text(". If any of the ")#mi("{T_k}")#text(" are greater than or equal to ")#mi("{T_*}")#text(" it is easy to see that ")#mi("{T_* \\in \\Omega}")#text(", so suppose instead that the ")#mi("{T_k}")#text(" are all less than ")#mi("{T_*}")#text(". We take a good function ")#mi("{\\psi_*: U_* \\rightarrow {\\bf R}}")#text(" supported on some neighbourhood ")#mi("{U_*}")#text(" of ")#mi("{\\gamma(T_*)}")#text(". By continuity, ")#mi("{U_*}")#text(" will contain ")#mi("{\\gamma([T_k,T_*])}")#text(" for some sufficiently large ")#mi("{k}")#text(". We would like to append ")#mi("{\\psi_*}")#text(" and ")#mi("{U_*}")#text(" to the sequence of good functions ")#mi("{\\phi_j: U_j \\rightarrow {\\bf R}}")#text(", ")#mi("{j=1,\\dots,k}")#text(" one obtains from the hypothesis ")#mi("{T_k \\in \\Omega}")#text(", but there is the issue that ")#mi("{\\psi_*}")#text(" need not agree with ")#mi("{\\phi_k}")#text(" at the endpoint ")#mi("{\\gamma(T_k)}")#text(". However, they only differ by a constant of magnitude one near this endpoint, so after multiplying ")#mi("{\\psi_*}")#text(" by an appropriate constant of magnitude one, we can conclude that ")#mi("{T_*\\in \\Omega}")#text(" as claimed.")#linebreak()#text(" By the continuity method, ")#mi("{\\Omega}")#text(" is all of ")#mi("{[0,1]}")#text(", and in particular contains ")#mi("{1}")#text(". Thus we can find ")#mi("{0 = t_0 < t_1 < \\dots < t_n = 1}")#text(" and good functions ")#mi("{\\phi_j: U_j \\rightarrow {\\bf R}}")#text(" for ")#mi("{j=1,\\dots,n}")#text(" such that each ")#mi("{U_j}")#text(" contains ")#mi("{\\gamma([t_{j-1},t_j])}")#text(", and such that ")#mi("{\\phi_j}")#text(" and ")#mi("{\\phi_{j+1}}")#text(" agree on a neighbourhood of ")#mi("{\\gamma(t_j)}")#text(" for each ")#mi("{j=1,\\dots,n-1}")#text(", and ")#mi("{\\phi_1}")#text(" and ")#mi("{\\phi_{p_0}}")#text(" also agree on a neighbourhood of ")#mi("{\\gamma(t_0)}")#text(". Consider the final value ")#mi("{\\phi_n(p)}")#text(" obtained by the last good function ")#mi("{\\phi_n: U_n \\rightarrow {\\bf R}}")#text(" at the endpoint ")#mi("{\\gamma(t_n) = p}")#text(" of the curve ")#mi("{\\gamma}")#text(". From analytic continuation and a continuity argument we see that if we perform a homotopy of ")#mi("{\\gamma}")#text(" with fixed endpoints, this final value does not change (even if the number ")#mi("{n}")#text(" of good functions may vary). Thus we can define a function ")#mi("{\\phi: M \\rightarrow {\\bf R}}")#text(" by setting ")#mi("{\\phi(p) := \\phi_n(p)}")#text(" whenever ")#mi("{\\gamma}")#text(" is a path from ")#mi("{p_0}")#text(" to ")#mi("{p}")#text(" and ")#mi("{\\phi_n}")#text(" is the final good function constructed by the above procedure. From construction we see that ")#mi("{\\phi}")#text(" is locally equal to a good function at every point in ")#mi("{M}")#text(", and is thus itself a good function, as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55 (Monodromy theorem)")]#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface, let ")#mi("{N}")#text(" be another Riemann surface, let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(", let ")#mi("{U_{p_0}}")#text(" be an open neighbourhood of ")#mi("{p_0}")#text(", and let ")#mi("{\\phi_{p_0}: U_{p_0} \\rightarrow N}")#text(" be holomorphic. Prove that the following statements are equivalent.")

#list(
[#text("(i) ")#mi("{\\phi_{p_0}}")#text(" has a holomorphic extension to ")#mi("{M}")#text("; that is to say, there is a holomorphic function ")#mi("{f: M \\rightarrow N}")#text(" whose restriction to ")#mi("{U_{p_0}}")#text(" is equal to ")#mi("{\\phi_{p_0}}")#text(".")],
[#text("(ii) For every curve ")#mi("{\\gamma: [0,1] \\rightarrow M}")#text(" starting at ")#mi("{p_0}")#text(", we can find ")#mi("{0 = t_0 < t_1 < \\dots < t_n = 1}")#text(" and holomorphic functions ")#mi("{\\phi_j: U_j \\rightarrow N}")#text(" for ")#mi("{j=1,\\dots,n}")#text(" with ")#mi("{\\phi_1 = \\phi_{p_0}}")#text(", such that ")#mi("{U_j}")#text(" is an open subset of ")#mi("{M}")#text(" containing ")#mi("{\\gamma([t_{j-1},t_{j}])}")#text(", and ")#mi("{\\phi_j}")#text(" and ")#mi("{\\phi_{j+1}}")#text(" agree on a neighbourhood of ")#mi("{\\gamma(t_j)}")#text(" for each ")#mi("{j=1,\\dots,n-1}")#text(".")]
)

#text("Furthermore, if (i) holds, show that the holomorphic extension ")#mi("{f: M \\rightarrow N}")#text(" is unique. Give a counterexample that shows that the monodromy theorem fails if ")#mi("{M}")#text(" is only assumed to be connected rather than simply connected.")
]

#text("We remark that while the condition (ii) in the monodromy theorem looks somewhat complicated, it becomes more geometrically natural if one adopts the language of ")#link("https://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("sheaves")]#text(", which we will not do here.")#linebreak()#text(" In view of Lemma ")#link(<tao-9ec6f84751b054853670>)[#text("54")]#text(", we may reduce the task of establishing Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" to that of establishing the existence of a special type of harmonic function on ")#mi("{M}")#text(" (with one point ")#mi("{p_0}")#text(" removed), namely a ")#link("https://en.wikipedia.org/wiki/Green%27s_function")[#text("Green’s function")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 56 (Green’s function)")]#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface, and let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(". A ")#emph[#text("Green’s function")]#text(" for ")#mi("{M}")#text(" at ")#mi("{p_0}")#text(" is a function ")#mi("{g_{p_0}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" with the following properties:")

#list(
[#text("(i) ")#mi("{g_{p_0}}")#text(" is harmonic on ")#mi("{M \\backslash \\{p_0\\}}")#text(".")],
[#text("(ii) ")#mi("{g_{p_0}}")#text(" is non-negative on ")#mi("{M \\backslash \\{p_0\\}}")#text(".")],
[#text("(iii) ")#mi("{g_{p_0}}")#text(" has a logarithmic singularity at ")#mi("{p_0}")#text(" in the sense that ")#tao-math("{g_{p_0} - \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is bounded near ")#mi("{p_0}")#text(" for some coordinate chart ")#mi("{z: U_{p_0} \\rightarrow D(0,1)}")#text(" that maps ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(".")],
[#text("(iv) ")#mi("{g_{p_0}}")#text(" is minimal with respect to the properties (i)-(iii), in the sense that for any other ")#mi("{g^{\\prime}_{p_0}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" obeying (i)-(iii), we have ")#mi("{g_{p_0} \\leq g^{\\prime}_{p_0}}")#text(" pointwise in ")#mi("{M \\backslash \\{p_0\\}}")#text(".")]
)
]

#text("Clearly if a Green’s function for ")#mi("{M}")#text(" at ")#mi("{p_0}")#text(" exists, it is unique by property (iv), so we can talk about ")#emph[#text("the")]#text(" Green’s function for ")#mi("{M}")#text(" at ")#mi("{p_0}")#text(", if it exists. In the case of the disk ")#mi("{D(0,1)}")#text(", a Greens’ function may be explicitly computed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 57")]#text(" If ")#mi("{\\alpha \\in D(0,1)}")#text(", show that the function ")#mi("{g_\\alpha: D(0,1) \\rightarrow {\\bf R}}")#text(" defined by ")#tao-math("{g_\\alpha(z) := \\log \\frac{\\left|1-\\overline{\\alpha} z\\right|}{\\left|z-\\alpha\\right|}}", block: false)#text(" is a Green’s function for ")#mi("{D(0,1)}")#text(" at ")#mi("{\\alpha}")#text(".")
]

#text("Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" may now be deduced from the following claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 58 (Existence of Green’s function)")]#text(" ")#metadata(none) <tao-ba4788b226aa8dc2e6dc>#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface, let ")#mi("{p_0}")#text(" be a point in ")#mi("{M}")#text(", and suppose that the collection ")#mi("{{\\mathcal H}_{p_0}}")#text(" of holomorphic maps ")#mi("{f: M \\rightarrow D(0,1)}")#text(" that map ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(" contains at least one non-constant map. Then the Green’s function ")#mi("{g_{p_0}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" for ")#mi("{M}")#text(" at ")#mi("{p_0}")#text(" exists. Furthermore, for any ")#mi("{f \\in {\\mathcal H}_{p_0}}")#text(", one has ")#tao-math("{\\left|f(p)\\right| \\leq e^{-g_{p_0}(p)}}", block: false)#text(" for any ")#mi("{p \\in M \\backslash \\{p_0\\}}")#text(".")
]

#text("(Note that in this proposition we no longer need ")#mi("{M}")#text(" to be simply connected.) Indeed, suppose that Proposition ")#link(<tao-ba4788b226aa8dc2e6dc>)[#text("58")]#text(" held. Let ")#mi("{M}")#text(" be a simply connected Riemann surface, and let ")#mi("{p_0 \\in M}")#text(" with ")#mi("{{\\mathcal H}_{p_0}}")#text(" containing a non-constant map. By hypothesis, the Green’s function ")#mi("{g_{p_0}}")#text(" is non-negative on ")#mi("{M \\backslash \\{p_0\\}}")#text(". Noting that ")#mi("{M}")#text(" remains connected if we remove a small disk around ")#mi("{p_0}")#text(", and from (iii) that ")#mi("{g_{p_0}}")#text(" will be strictly positive on the boundary of that disk, we observe from the maximum principle (Exercise ")#link(<tao-9baf3a40312f39849f46>)[#text("18")]#text(") and (ii) that ")#mi("{g_{p_0}}")#text(" is in fact strictly positive on ")#mi("{M \\backslash \\{p_0\\}}")#text(". By Lemma ")#link(<tao-9ec6f84751b054853670>)[#text("54")]#text(" we can find a holomorphic function ")#mi("{\\phi_{p_0}: M \\rightarrow {\\bf C}}")#text(" with a simple zero at ")#mi("{p_0}")#text(" and no other zeroes, such that ")#tao-math("{\\left|\\phi_{p_0}\\right| = e^{-g_{p_0}}}", block: false)#text(" on ")#mi("{M \\backslash \\{p_0\\}}")#text(". As ")#mi("{g_{p_0}}")#text(" is strictly positive, ")#mi("{\\phi_{p_0}}")#text(" takes values in ")#mi("{D(0,1)}")#text(" and is thus in ")#mi("{{\\mathcal H}_{p_0}}")#text(". From Proposition ")#link(<tao-ba4788b226aa8dc2e6dc>)[#text("58")]#text(" we see that ")#tao-math("{\\left|f(p)\\right| \\leq \\left|\\phi_{p_0}(p)\\right|}", block: false)#text(" for all ")#mi("{p \\in M \\backslash \\{p_0\\}}")#text(". If equality occurs anywhere, then the quotient ")#mi("{f/\\phi_{p_0}}")#text(" (after removing the singularity) is a function taking values in the closed unit disk ")#mi("{\\overline{D(0,1)}}")#text(", which has magnitude ")#mi("{1}")#text(" at ")#mi("{p}")#text("; by the maximum principle (or open mapping theorem) we then have ")#mi("{f/\\phi_{p_0} = e^{i\\theta}}")#text(" for some real ")#mi("{\\theta}")#text(". Thus ")#mi("{\\phi_{p_0}}")#text(" obeys all the properties required for Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(".")#linebreak()#text(" It remains to obtain the existence of the Green’s function ")#mi("{g_{p_0}}")#text(". To do this, we use a powerful technique for constructing harmonic functions, known as ")#link("https://en.wikipedia.org/wiki/Perron_method")[#text("Perron’s method of subharmonic functions")]#text(". The basic idea is to build a harmonic function by taking a suitable large family of ")#link("https://en.wikipedia.org/wiki/Subharmonic_function")[#text("subharmonic functions")]#text(" and then forming their supremum. We first give a definition of subharmonic function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 59 (Subharmonic function)")]#text(" Let ")#mi("{M}")#text(" be a Riemann surface. A ")#emph[#text("subharmonic function")]#text(" on ")#mi("{M}")#text(" is an ")#link("https://en.wikipedia.org/wiki/Semi-continuity")[#text("upper semi-continuous")]#text(" function ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" obeying the following upper maximum principle: for any connected compact set ")#mi("{K}")#text(" in ")#mi("{M}")#text(" with non-empty boundary and any function ")#mi("{v: K \\rightarrow {\\bf R}}")#text(" that is continuous on ")#mi("{K}")#text(" and harmonic on the interior of ")#mi("{K}")#text(", if ")#mi("{u(p) \\leq v(p)}")#text(" for all ")#mi("{p \\in \\partial K}")#text(", then ")#mi("{u(p) \\leq v(p)}")#text(" for all ")#mi("{p \\in K}")#text(".")#linebreak()#text(" A superharmonic function is similarly defined as a lower semi-continuous function ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{+\\infty\\}}")#text(" such that for any connected compact ")#mi("{K \\subset M}")#text(" with non-empty boundary and any function ")#mi("{v: K \\rightarrow {\\bf R}}")#text(" continuous on ")#mi("{K}")#text(" and harmonic on the interior of ")#mi("{K}")#text(", the bound ")#mi("{u(p) \\geq v(p)}")#text(" for ")#mi("{p \\in \\partial K}")#text(" implies that ")#mi("{u(p) \\geq v(p)}")#text(" for all ")#mi("{p \\in K}")#text(".")
]

#text("Clearly subharmonicity and superharmonicity are conformal invariants in the sense that the analogue of Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text(" holds for these concepts. We have the following elementary properties of subharmonic functions and superharmonic functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 60")]#text(" ")#metadata(none) <tao-89c4ec9f6b3f1086b158>#text(" Let ")#mi("{M}")#text(" be a Riemann surface.")

#list(
[#text("(i) Let ")#mi("{h: M \\rightarrow {\\bf R}}")#text(" be harmonic. Show that a function ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" is subharmonic if and only if ")#mi("{h-u}")#text(" is superharmonic.")],
[#text("(ii) Show that a function ")#mi("{u: M \\rightarrow {\\bf R}}")#text(" is harmonic if and only if it is both subharmonic and superharmonic.")],
[#text("(iii) If ")#mi("{u,v: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" are subharmonic, show that ")#mi("{\\max(u,v)}")#text(" is also.")],
[#text("(iv) Let ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" be subharmonic, and let ")#mi("{U}")#text(" be an open subset of ")#mi("{M}")#text(". Show that the restriction of ")#mi("{u}")#text(" to ")#mi("{U}")#text(" is subharmonic.")],
[#text("(v) (Subharmonicity is a local property) Conversely, let ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" is subharmonic, and suppose that for each ")#mi("{p \\in M}")#text(" there is a neighbourhood ")#mi("{U_p}")#text(" of ")#mi("{p}")#text(" such that the restriction of ")#mi("{u}")#text(" to ")#mi("{U_p}")#text(" is subharmonic. Show that ")#mi("{u}")#text(" is itself subharmonic. (")#emph[#text("Hint:")]#text(" If ")#mi("{v}")#text(" is continuous on a connected compact set ")#mi("{K}")#text(" with non-empty boundary and harmonic on the interior, and ")#mi("{v-u}")#text(" attains a minimum at an interior point of ")#mi("{K}")#text(", show that ")#mi("{v-u}")#text(" is constant in some neighbourhood of that point. Exercise ")#link(<tao-2b64c6d9afd8a34ed0db>)[#text("43")]#text(" may come in handy, as well as the fact (which you can use without proof) that upper (resp. lower) semi-continuous functions on a compact subset of ")#mi("{{\\bf C}}")#text(" can be expressed as the pointwise limit of a decreasing (resp. increasing) sequence of continuous functions.)")],
[#text("(vi) (Maximum principle) Let ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" be subharmonic, let ")#mi("{v: M \\rightarrow {\\bf R} \\cup \\{+\\infty\\}}")#text(" be superharmonic, and let ")#mi("{K}")#text(" be a connected compact subset of ")#mi("{M}")#text(" with non-empty boundary such that ")#mi("{u(p) \\leq v(p)}")#text(" for all ")#mi("{p \\in \\partial K}")#text(". Show that ")#mi("{u(p) \\leq v(p)}")#text(" for all ")#mi("{p \\in K}")#text(". (This is a similar argument to (v).)")],
[#text("(vii) Show that the sum of two subharmonic functions is again subharmonic (using the usual conventions on adding ")#mi("{-\\infty}")#text(" to itself or to another real number).")],
[#text("(viii) (Harmonic patching) Let ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" be subharmonic, let ")#mi("{K}")#text(" be connected compact with non-empty boundary, and let ")#mi("{v: K \\rightarrow {\\bf R}}")#text(" be a continuous function on ")#mi("{K}")#text(" that is harmonic on the interior of ")#mi("{K}")#text(" and agrees with ")#mi("{u}")#text(" on the boundary of ")#mi("{K}")#text(". Show that the function ")#mi("{\\tilde u: M \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(", defined to equal ")#mi("{v}")#text(" on ")#mi("{K}")#text(" and ")#mi("{u}")#text(" on ")#mi("{M \\backslash K}")#text(", is subharmonic.")],
[#text("(ix) Let ")#mi("{f: M \\rightarrow {\\bf C}}")#text(" be a holomorphic function. Show that ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(" is subharmonic, with the convention that ")#mi("{\\log 0 = -\\infty}")#text(". (")#emph[#text("Hint:")]#text(" first use the maximum principle and harmonic conjugates to show that if ")#mi("{M}")#text(" contains a copy of a closed disk ")#mi("{\\overline{D(z_0,r)}}")#text(", and ")#tao-math("{\\log \\left|f\\right| \\leq u}", block: false)#text(" on the boundary of this disk for some continuous ")#mi("{u: \\overline{D(z_0,r)} \\rightarrow {\\bf R}}")#text(" that is harmonic in the interior of the disk, then ")#tao-math("{\\log \\left|f\\right| \\leq u}", block: false)#text(" in the interior of the disk also.)")]
)
]

#text("For smooth functions on an open subset of ")#mi("{{\\bf C}}")#text(", one can express the property of subharmonicity quite explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 61")]#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{u: U \\rightarrow {\\bf R}}")#text(" be continuously twice (Fréchet) differentiable. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{u}")#text(" is subharmonic.")],
[#text("(ii) For all closed disks ")#mi("{\\overline{D(z_0,r)}}")#text(" in ")#mi("{U}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("u(z_0) \\leq \\frac{1}{2\\pi} \\int_0^{2\\pi} u(z_0+re^{i\\theta})\\ d\\theta.")]]],
[#text("(iii) One has ")#mi("{\\Delta u(z_0) \\geq 0}")#text(" for all ")#mi("{z_0 \\in U}")#text(".")]
)

#text("Show that the equivalence of (i) and (ii) in fact holds even if ")#mi("{u}")#text(" is only assumed to be continuous rather than continuously twice differentiable.")
]

#text("However, we will not use the above exercise in our analysis here as it will not be convenient to impose a hypothesis of continuous twice differentiability on our subharmonic functions. For instance, in the unit disk ")#mi("{D(0,1)}")#text(", the function ")#tao-math("{\\log \\left|z\\right|}", block: false)#text(" is an example of a subharmonic function that attains the value ")#mi("{-\\infty}")#text(" at the origin. A more sophisticated example is ")#tao-math("{\\sum_{k=2}^\\infty \\frac{1}{k^2} \\log \\left|z-1/k\\right|}", block: false)#text(", which is also subharmonic but is now discontinuous at the origin (even if one uses the topology of the extended reals).")#linebreak()#text(" The Perron method is based on the observation that under certain conditions, the supremum of a family of subharmonic functions is not just subharmonic (as per Exercise ")#link(<tao-89c4ec9f6b3f1086b158>)[#text("60")]#text("(iii)), but is in fact harmonic. A key concept here is that of a Perron family:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 62")]#text(" Let ")#mi("{M}")#text(" be a Riemann surface. A ")#emph[#text("continuous Perron family")]#text(" on ")#mi("{M}")#text(" is a family ")#mi("{{\\mathcal F}}")#text(" of continuous subharmonic functions ")#mi("{u: M \\rightarrow {\\bf R}}")#text(" with the following properties:")

#list(
[#text("(i) If ")#mi("{u, v \\in {\\mathcal F}}")#text(", then ")#mi("{\\max(u,v) \\in {\\mathcal F}}")#text(".")],
[#text("(ii) (Harmonic patching) If ")#mi("{u \\in {\\mathcal F}}")#text(", ")#mi("{K}")#text(" is a connected compact subset of ")#mi("{M}")#text(" with non-empty boundary, and ")#mi("{v: K \\rightarrow {\\bf R}}")#text(" is a continuous function that is harmonic in the interior of ")#mi("{K}")#text(" and equals ")#mi("{u}")#text(" on the boundary of ")#mi("{K}")#text(", then the function ")#mi("{\\tilde u: M \\rightarrow {\\bf R}}")#text(" defined to equal ")#mi("{v}")#text(" on ")#mi("{K}")#text(" and ")#mi("{u}")#text(" outside of ")#mi("{K}")#text(" also lies in ")#mi("{{\\mathcal F}}")#text(".")]
)
]

#text("One can also consider more general Perron families of subharmonic functions that are merely upper semi-continuous rather than continuous, but for the current application continuous Perron families will suffice.")#linebreak()#text(" The fundamental theorem that powers the Perron method is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 63 (Perron method)")]#text(" ")#metadata(none) <tao-5111f93f8a30fe634de9>#text(" Let ")#mi("{{\\mathcal F}}")#text(" be a non-empty continuous Perron family on a connected Riemann surface ")#mi("{M}")#text(", and set ")#mi("{u: M \\rightarrow {\\bf R} \\cup \\{+\\infty\\}}")#text(" to be the function ")#mi("{u(p) := \\sup_{v \\in {\\mathcal F}} v(p)}")#text(". Then one of the following two statements hold:")

#list(
[#text("(i) ")#mi("{u(p) = +\\infty}")#text(" for all ")#mi("{p \\in M}")#text(".")],
[#text("(ii) ")#mi("{u}")#text(" is a harmonic function on ")#mi("{M}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let us first work locally in some open subset ")#mi("{U}")#text(" of ")#mi("{M}")#text(" that is complex diffeomorphic to a disk ")#mi("{D(0,1)}")#text("; to simplify the discussion we abuse notation by identifying ")#mi("{U}")#text(" with ")#mi("{D(0,1)}")#text(" in the following discussion.")#linebreak()#text(" Assume for the moment that ")#mi("{u}")#text(" is not identically equal to ")#mi("{+\\infty}")#text(" on ")#mi("{D(0,1/2)}")#text(". Let ")#mi("{p_0}")#text(" be an arbitrary point in ")#mi("{D(0,1/2)}")#text(" (viewed as a subset of ")#mi("{U}")#text("). Then we can find a sequence ")#mi("{u_n \\in {\\mathcal F}}")#text(" such that ")#mi("{u_n(p_0) \\rightarrow u(p_0)}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")#linebreak()#text(" We can use Exercise ")#link(<tao-2b64c6d9afd8a34ed0db>)[#text("43")]#text(" to find a continuous function ")#mi("{v_1: \\overline{D(0,1/2)} \\rightarrow {\\bf R} \\cup \\{-\\infty\\}}")#text(" that equals ")#mi("{u_1}")#text(" on the boundary of this disk (viewed as a subset of ")#mi("{U}")#text(") and is harmonic and at least as large as ")#mi("{u_1}")#text(" in the interior; if we then let ")#mi("{\\tilde u_1}")#text(" be the function defined to equal ")#mi("{v_1}")#text(" on ")#mi("{\\overline{D(0,1/2)}}")#text(" and ")#mi("{u_1}")#text(" outside of this disk, then ")#mi("{\\tilde u_1}")#text(" is larger than ")#mi("{u_1}")#text(" and also lies in ")#mi("{{\\mathcal F}}")#text(" thanks to axiom (ii). Thus, by replacing ")#mi("{u_1}")#text(" with ")#mi("{\\tilde u_1}")#text(", we may assume that ")#mi("{u_1}")#text(" is harmonic on ")#mi("{D(0,1/2)}")#text(". Next, by replacing ")#mi("{u_2}")#text(" with ")#mi("{\\max(u_1,u_2)}")#text(" and using axiom (i), we may assume that ")#mi("{u_1 \\leq u_2}")#text(" pointwise; replacing ")#mi("{u_2}")#text(" with a harmonic function on ")#mi("{D(0,1/2)}")#text(" as before we may assume that ")#mi("{u_2}")#text(" is harmonic on ")#mi("{D(0,1/2)}")#text(". Continuing in this fashion we may assume that ")#mi("{u_1 \\leq u_2 \\leq \\dots}")#text(" and that ")#mi("{u_1,u_2,\\dots}")#text(" are harmonic on ")#mi("{D(0,1/2)}")#text(". Form the function ")#mi("{w_{p_0} := \\sup_n u_n}")#text(", then we have ")#mi("{w_{p_0} \\leq u}")#text(" pointwise with ")#mi("{w_{p_0}(p_0) = u(p_0)}")#text(". By the Harnack principle (Exercise 59 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text("), we thus see that ")#mi("{w_{p_0}}")#text(" is either harmonic on ")#mi("{D(0,1/2)}")#text(", or equal to ")#mi("{+\\infty}")#text(" on ")#mi("{D(0,1/2)}")#text(". The latter cannot occur since we are assuming ")#mi("{u}")#text(" not identically equal to ")#mi("{+\\infty}")#text(", thus ")#mi("{w_{p_0}}")#text(" is harmonic.")#linebreak()#text(" Now let ")#mi("{p_1}")#text(" be another point in ")#mi("{D(0,1/2)}")#text(". We can find another sequence ")#mi("{u^{\\prime}_n \\in {\\mathcal F}}")#text(" with ")#mi("{u^{\\prime}_n(p_1) \\rightarrow u(p_1)}")#text(". As before we may assume that the ")#mi("{u^{\\prime}_n}")#text(" are increasing and are harmonic on ")#mi("{D(0,1/2)}")#text("; we may also assume that ")#mi("{u^{\\prime}_n \\geq u_n}")#text(" pointwise. Setting ")#mi("{w_{p_1} := \\sup_n u^{\\prime}_n}")#text(", we conclude that ")#mi("{w_{p_1}}")#text(" is harmonic with ")#mi("{w_{p_0} \\leq w_{p_1} \\leq u}")#text(" on ")#mi("{D(0,1/2)}")#text(". In particular ")#mi("{w_{p_0}(p_0) = w_{p_1}(p_0)}")#text(". The harmonic function ")#mi("{w_{p_1}-w_{p_0}}")#text(" is non-negative on ")#mi("{D(0,1/2)}")#text(" and vanishes at ")#mi("{p_0}")#text(", hence is identically zero on ")#mi("{D(0,1/2)}")#text(" by the maximum principle. Since ")#mi("{w_{p_1}(p_1) = u(p_1)}")#text(", we conclude that ")#mi("{w_{p_0}}")#text(" and ")#mi("{u}")#text(" agree at ")#mi("{p_1}")#text(". Since ")#mi("{p_1}")#text(" was an arbitrary point on ")#mi("{D(0,1/2)}")#text(", we conclude that ")#mi("{u=w_{p_0}}")#text(" is harmonic at ")#mi("{D(0,1/2)}")#text(".")#linebreak()#text(" Putting all this together, we see that for any point ")#mi("{p}")#text(" in ")#mi("{M}")#text(" there is a neighbourhood ")#mi("{U_p}")#text(" (corresponding to the disk ")#mi("{D(0,1/2)}")#text(" in the above arguments) with the property that ")#mi("{u}")#text(" is either equal to ")#mi("{+\\infty}")#text(" on ")#mi("{U_p}")#text(", or is harmonic on ")#mi("{U_p}")#text(". By a continuity argument we conclude that one of the two options (i), (ii) of the theorem must hold. ")#mi("\\Box")#linebreak()#text(" Now we can conclude the proof of Proposition ")#link(<tao-ba4788b226aa8dc2e6dc>)[#text("58")]#text(", and hence the hyperbolic case of the uniformisation theorem, by applying the above theorem to a well-chosen Perron family. Let ")#mi("{M}")#text(" be a simply connected Riemann surface, and let ")#mi("{{\\mathcal F}}")#text(" be the collection of all continuous subharmonic functions ")#mi("{u: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" that vanish outside of a compact subset of ")#mi("{K}")#text(", and which have a logarithmic singularity at ")#mi("{p_0}")#text(" in the sense that ")#tao-math("{u - \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is bounded near ")#mi("{p_0}")#text(" for some coordinate chart ")#mi("{z: U_{p_0} \\rightarrow D(0,1)}")#text(" that takes ")#mi("{p_0}")#text(" to ")#mi("{0}")#text(" (note that the precise choice of chart here is irrelevant). This collection is non-empty, for it contains the function ")#mi("{u}")#text(" that equals (say) ")#tao-math("{\\log \\frac{1}{2\\left|z\\right|}}", block: false)#text(" on ")#mi("{z^{-1}(D(0,1/2))}")#text(", and zero elsewhere (this follows from the observation that ")#tao-math("{\\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is harmonic away from the origin, and ")#mi("{0}")#text(" is harmonic everywhere, as well as the various properties in Exercise ")#link(<tao-89c4ec9f6b3f1086b158>)[#text("60")]#text("). From Exercise ")#link(<tao-89c4ec9f6b3f1086b158>)[#text("60")]#text(" we see that ")#mi("{{\\mathcal F}}")#text(" is a Perron family; thus, by Theorem ")#link(<tao-5111f93f8a30fe634de9>)[#text("63")]#text(", the function ")#mi("{g_{p_0} := \\sup_{u \\in {\\mathcal F}} u}")#text(" is either harmonic on ")#mi("{M \\backslash \\{p_0\\}}")#text(", or is infinite everywhere. Using the element of ")#mi("{{\\mathcal F}}")#text(" used above we see that ")#mi("{g_{p_0}}")#text(" is non-negative.")#linebreak()#text(" Let ")#mi("{f: M \\rightarrow D(0,1)}")#text(" be an arbitrary element of ")#mi("{{\\mathcal H}_{p_0}}")#text(". By Exercise ")#link(<tao-89c4ec9f6b3f1086b158>)[#text("60")]#text("(ix), ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(" is subharmonic, hence ")#tao-math("{\\log \\frac{1}{\\left|f\\right|}}", block: false)#text(" is superharmonic and also non-negative since ")#mi("{f}")#text(" takes values in ")#mi("{D(0,1)}")#text("; as ")#mi("{f}")#text(" vanishes at ")#mi("{p_0}")#text(", ")#tao-math("{\\log \\frac{1}{\\left|f\\right|}}", block: false)#text(" has at least a logarithmic singularity at ")#mi("{p_0}")#text(" in the sense that ")#tao-math("{\\log \\frac{1}{\\left|f\\right|} - \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is bounded from below near ")#mi("{p_0}")#text(". If ")#mi("{u \\in {\\mathcal F}}")#text(", then ")#mi("{u}")#text(" vanishes outside of a compact set ")#mi("{K}")#text(", hence ")#tao-math("{u \\leq (1+\\varepsilon) \\log \\frac{1}{\\left|f\\right|}}", block: false)#text(" outside of ")#mi("{K}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(". As ")#mi("{u}")#text(" has a logarithmic singularity at ")#mi("{p_0}")#text(" we also have ")#tao-math("{u \\leq (1+\\varepsilon) \\log \\frac{1}{\\left|f\\right|}}", block: false)#text(" in a sufficiently small neighbourhood of ")#mi("{p_0}")#text(". Appying the maximum principle (Exercise ")#link(<tao-89c4ec9f6b3f1086b158>)[#text("60")]#text("(vi)) we conclude that ")#tao-math("{u \\leq (1+\\varepsilon) \\log \\frac{1}{\\left|f\\right|}}", block: false)#text(" on all of ")#mi("{M \\backslash \\{p_0\\}}")#text("; sending ")#mi("{\\varepsilon}")#text(" to zero and then taking suprema in ")#mi("{u}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("g_{p_0} \\leq \\log \\frac{1}{\\left|f\\right|}", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\left|f\\right| \\leq e^{-g_{p_0}}", block: true)]]

#text("pointwise on ")#mi("{M \\backslash \\{p_0\\}}")#text(". In particular, since ")#mi("{{\\mathcal H}_{p_0}}")#text(" contains at least one non-constant map, ")#mi("{g_{p_0}}")#text(" cannot be infinite everywhere and must therefore be harmonic.")#linebreak()#text(" Similarly, if ")#mi("{g^{\\prime}_{p_0}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" is a function obeying the properties (i)-(iii) of a Green’s function, and ")#mi("{u \\in {\\mathcal F}}")#text(", then another application of the maximum principle shows that ")#mi("{u \\leq (1+\\varepsilon) g^{\\prime}_{p_0}}")#text(" on ")#mi("{M \\backslash \\{p_0\\}}")#text(" for any ")#mi("{\\varepsilon > 0}")#text("; sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" and taking suprema in ")#mi("{u}")#text(" we see that ")#mi("{g_{p_0} \\leq g^{\\prime}_{p_0}}")#text(" pointwise.")#linebreak()#text(" The only remaining task to show is that ")#mi("{g_{p_0}}")#text(" has a logarithmic singularity at ")#mi("{p_0}")#text(". Certainly it has at least this much of a singularity, in that ")#tao-math("{g_{p_0} - \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is bounded from below near ")#mi("{p_0}")#text(", as can be seen by comparing ")#mi("{g_{p_0}}")#text(" to any element of ")#mi("{{\\mathcal F}}")#text(". To get the upper bound, observe that for any ")#mi("{u \\in {\\mathcal F}}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", the function ")#tao-math("{u - (1+\\varepsilon) \\log \\frac{1}{\\left|z\\right|}}", block: false)#text(" is subharmonic on ")#mi("{z^{-1}(D(0,1)) \\backslash \\{p_0\\}}")#text(" and diverges to ")#mi("{-\\infty}")#text(" at ")#mi("{p_0}")#text(", and is hence in fact subharmonic on all of ")#mi("{M}")#text(". In particular, for ")#mi("{p}")#text(" in the disk ")#mi("{z^{-1}(D(0,1/2))}")#text(", we have from the maximum principle that")

#align(center)[#tao-fit-display[#tao-math("u(p) - (1+\\varepsilon) \\log \\frac{1}{\\left|z(p)\\right|} \\leq \\sup_{q \\in U_{p_0}: \\left|z(q)\\right| = 1/2} u(q) - (1+\\varepsilon) \\log 2", block: true)]]

#text("and hence on taking suprema in ")#mi("{u}")#text(" and limits in ")#mi("{\\varepsilon}")

#align(center)[#tao-fit-display[#tao-math("g_{p_0}(p) - \\log \\frac{1}{\\left|z(p)\\right|} \\leq \\sup_{q \\in U_{p_0}: \\left|z(q)\\right| = 1/2} g_{p_0}(q) - \\log 2.", block: true)]]

#text("The right-hand side is finite, and this gives the required upper bound to complete the proof that ")#mi("{g_{p_0}}")#text(" has a logarithmic singularity at ")#mi("{p_0}")#text(". This concludes the proof of Proposition ")#link(<tao-ba4788b226aa8dc2e6dc>)[#text("58")]#text(" and hence Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(".")#linebreak()#text(" Before we turn to the non-hyperbolic case of the uniformisation theorem, we record a symmetry property of the Green’s functions that is used to establish that case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 64 (Symmetry of Green’s functions)")]#text(" ")#metadata(none) <tao-0599b22abfb1eb4db9c1>#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface, and suppose that the Green’s functions ")#mi("{g_{p_0}: M \\backslash \\{p_0\\} \\rightarrow {\\bf R}}")#text(" exist for all ")#mi("{p_0}")#text(". Then for all distinct ")#mi("{p_0,p_1 \\in M}")#text(", we have ")#mi("{g_{p_0}(p_1) = g_{p_1}(p_0)}")#text(".")
]

#text("When ")#mi("{M}")#text(" is simply connected, this symmetry can be deduced from ")#link(<tao-a2052ddf9e8c0c3d01cb>)[#text("(7)")]#text(". For ")#mi("{M}")#text(" that are not simply connected, the argument is trickier, requiring one to pass to a universal cover ")#mi("{N}")#text(" of ")#mi("{M}")#text(", establish the existence of Green’s functions on ")#mi("{N}")#text(", and find an identity relating the Green’s functions on ")#mi("{N}")#text(" with the Green’s functions on ")#mi("{M}")#text(". For details see ")#link("https://www.math.washington.edu/~marshall/preprints/uniformizationII.pdf")[#text("Marshall’s notes")]#text(".")#linebreak()#text(" Now we can discuss to the non-hyperbolic case of the uniformisation theorem, Theorem ")#link(<tao-1259d90a976742a1738d>)[#text("51")]#text(". Now we do not have any Green’s functions, or any non-constant bounded holomorphic functions. However, note that all three of the model Riemann surfaces ")#mi("{D(0,1)}")#text(", ")#mi("{{\\bf C}}")#text(" and ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" still have plenty of ")#emph[#text("meromorphic")]#text(" functions: in particular, for any two distinct points ")#mi("{z_0,z_1}")#text(" in ")#mi("{{\\bf C}}")#text(", one can find a holomorphic function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" that has a simple zero at ")#mi("{z_0}")#text(", a simple pole at ")#mi("{z_1}")#text(", and no other zeroes and poles, namely ")#mi("{f(z) := \\frac{z-z_0}{z-z_1}}")#text("; one can think of this function with a zero-pole pair as a “")#link("https://en.wikipedia.org/wiki/Dipole")[#text("dipole")]#text("“. Similarly if one works on the domain ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" or ")#mi("{D(0,1)}")#text(" rather than ")#mi("{{\\bf C}}")#text(". From this we see that Theorem ")#link(<tao-1259d90a976742a1738d>)[#text("51")]#text(" would imply the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 65 (Existence of dipoles)")]#text(" ")#metadata(none) <tao-5409b497e52958574794>#text(" Let ")#mi("{M}")#text(" be a simply connected Riemann surface. Let ")#mi("{p_0,p_1}")#text(" be distinct points in ")#mi("{M}")#text(". Then there exists a holomorphic map ")#mi("{f_{p_0,p_1}: M \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" that has a simple zero at ")#mi("{p_0}")#text(", a simple pole at ")#mi("{p_1}")#text(", and no other zeroes and poles. Furthermore, outside of a compact set ")#mi("{K}")#text(" containing ")#mi("{p_0,p_1}")#text(", the function ")#mi("{f_{p_0,p_1}}")#text(" can be chosen to be bounded away from both ")#mi("{0}")#text(" and ")#mi("{\\infty}")#text(" (that is, there exists ")#mi("{C > c > 0}")#text(" such that ")#tao-math("{c \\leq \\left|f_{p_0,p_1}(p)\\right| \\leq C}", block: false)#text(" for all ")#mi("{p \\in M \\backslash K}")#text(").")
]

#text("In the converse direction, we can use Theorem ")#link(<tao-5409b497e52958574794>)[#text("65")]#text(" to recover Theorem ")#link(<tao-1259d90a976742a1738d>)[#text("51")]#text(" in a manner analogous to how Theorem ")#link(<tao-16e0a9115980c4261929>)[#text("52")]#text(" implies Theorem ")#link(<tao-91e235e3f8168853b4d9>)[#text("50")]#text(". Indeed, let ")#mi("{M}")#text(" be a simply connected Riemann surface without non-constant holomorphic maps from ")#mi("{M}")#text(" to ")#mi("{D(0,1)}")#text(". Given any three distinct points ")#mi("{p_0,p_1,p_2}")#text(" in ")#mi("{M}")#text(", we consider the dipoles ")#mi("{f_{p_0,p_1}}")#text(" and ")#mi("{f_{p_2,p_1}}")#text(". The function ")#metadata(none) <tao-6ea43e45ff5cd60af903>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{f_{p_0,p_1} - f_{p_0,p_1}(p_2)}{f_{p_2,p_1}}")]]

#text("has removable singularities at ")#mi("{p_1}")#text(" and at ")#mi("{p_2}")#text(", no poles, and is also bounded away from a compact set. Thus this function extends to a bounded holomorphic function on ")#mi("{M}")#text(". Since ")#mi("{M}")#text(" does not have any non-constant bounded holomorphic functions, the function ")#link(<tao-6ea43e45ff5cd60af903>)[#text("(9)")]#text(" must be constant, thus ")#mi("{f_{p_0,p_1} = a f_{p_2,p_1} + b}")#text(" for some complex numbers ")#mi("{a,b}")#text("; as ")#mi("{f_{p_0,p_1}}")#text(" is non-constant, ")#mi("{a}")#text(" must be non-zero. Since ")#mi("{f_{p_2,p_1}}")#text(" vanishes only at ")#mi("{p_2}")#text(", we conclude that ")#mi("{f_{p_0,p_1}(p_2) \\neq f_{p_0,p_1}(p)}")#text(" for any ")#mi("{p \\neq p_2}")#text(". Since ")#mi("{f_{p_0,p_1}}")#text(" also has its only zero at ")#mi("{p_0}")#text(" and its only pole at ")#mi("{p_1}")#text(", we conclude that ")#mi("{f_{p_0,p_1}}")#text(" is injective. By Exercise 41 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Notes 4")]#text(", ")#mi("{f_{p_0,p_1}}")#text(" is thus a complex diffeomorphism from ")#mi("{M}")#text(" to an open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", which of course is simply connected since ")#mi("{M}")#text(" is. If ")#mi("{U}")#text(" is all of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" then we are in the elliptic case and we are done. If ")#mi("{U}")#text(" omits at least one point in ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" then by applying a Möbius transform ")#mi("{U}")#text(" is complex diffeomorphic to a simply connected open subset of ")#mi("{{\\bf C}}")#text("; by the Riemann mapping theorem, we conclude that ")#mi("{M}")#text(" is either complex diffeomorphic to ")#mi("{{\\bf C}}")#text(" or to ")#mi("{D(0,1)}")#text(". The latter case cannot occur by hypothesis, and we are done.")#linebreak()#text(" It remains to prove Theorem ")#link(<tao-5409b497e52958574794>)[#text("65")]#text(". As before, we convert the problem to one of finding a specific harmonic function. More precisely, one can derive Theorem ")#link(<tao-5409b497e52958574794>)[#text("65")]#text(" from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 66 (Existence of dipole Green’s functions)")]#text(" ")#metadata(none) <tao-eecd61e32e1b5ce6aa81>#text(" Let ")#mi("{M}")#text(" be a connected Riemann surface. Let ")#mi("{p_0,p_1}")#text(" be distinct points in ")#mi("{M}")#text(", and let ")#mi("{z_0: U_{p_0} \\rightarrow D(0,1)}")#text(" and ")#mi("{z_1: U_{p_1} \\rightarrow D(0,1)}")#text(" be coordinate charts on disjoint neighbourhoods ")#mi("{U_{p_0}, U_{p_1}}")#text(" of ")#mi("{p_0,p_1}")#text(" respectively, which map ")#mi("{p_0}")#text(" and ")#mi("{p_1}")#text(" respectively to ")#mi("{0}")#text(". Then there exists a harmonic function ")#mi("{g_{p_0,p_1}: M \\backslash \\{p_0,p_1\\} \\rightarrow {\\bf R}}")#text(" such that ")#tao-math("{g_{p_0,p_1} - \\log \\left|z_0\\right|}", block: false)#text(" is bounded near ")#mi("{p_0}")#text(", and ")#tao-math("{g_{p_0,p_1} + \\log \\left|z_1\\right|}", block: false)#text(" is bounded near ")#mi("{p_1}")#text(". Furthermore, ")#mi("{g_{p_0,p_1}}")#text(" is bounded outside of a compact subset ")#mi("{K}")#text(" of ")#mi("{M}")#text(".")
]

#text("In the case ")#mi("{M = {\\bf C}}")#text(", one can take the dipole Green’s function ")#mi("{g_{p_0,p_1}}")#text(" to be the function ")#tao-math("{\\log \\left|z-p_0\\right| - \\log \\left|z-p_1\\right| + C}", block: false)#text(" for an arbitrary constant ")#mi("{C}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 67")]#text(" Adapt the proof of Lemma ")#link(<tao-9ec6f84751b054853670>)[#text("54")]#text(" to show that Theorem ")#link(<tao-eecd61e32e1b5ce6aa81>)[#text("66")]#text(" implies Theorem ")#link(<tao-5409b497e52958574794>)[#text("65")]#text(" (and hence Theorem ")#link(<tao-1259d90a976742a1738d>)[#text("51")]#text(").")
]

#text("We still need to prove Theorem ")#link(<tao-eecd61e32e1b5ce6aa81>)[#text("66")]#text(". If ")#mi("{M}")#text(" admitted Green’s functions ")#mi("{g_{p_0}}")#text(" for every point ")#mi("{p_0 \\in M}")#text(", we could simply take ")#mi("{g_{p_0,p_1}}")#text(" to be the difference ")#mi("{g_{p_1} - g_{p_0}}")#text(". Unfortunately, as we are in the non-hyperbolic case, ")#mi("{M}")#text(" is not expected to have Green’s functions, and it does not appear possible to construct the dipole Green’s functions ")#mi("{g_{p_0,p_1}}")#text(" directly from Perron’s method due to the indefinite sign of these functions. However, it turns out that if one removes a small disk from ")#mi("{M}")#text(" of some small radius ")#mi("{t>0}")#text(" around a third reference point ")#mi("{p_\\infty}")#text(" in a given coordinate chart, then the resulting Riemann surface ")#mi("{M_t}")#text(" will admit Green’s functions ")#mi("{g_{p_0,t}}")#text(" (the basic idea is to apply Perron’s method to non-negative subharmonic functions with a logarithmic singularity at ")#mi("{p_0}")#text(" and which vanish on the boundary of the disk), and by considering limits of the sequence ")#mi("{g_{p_0,t} - g_{p_1,t}}")#text(" as ")#mi("{t \\rightarrow 0}")#text(" using a version of Montel’s theorem one will be able to obtain the required dipole Green’s function, after first making heavy use of the maximum principle (and an important variant of that principle known as ")#link("https://en.wikipedia.org/wiki/Harnack%27s_inequality")[#text("Harnack’s inequality")]#text(", see Exercise ")#link(<tao-07e237d2b7a088638c35>)[#text("69")]#text(" below) to obtain some locally uniform control on the difference ")#mi("{g_{p_1,t} - g_{p_0,t}}")#text(" in ")#mi("{t}")#text(". To obtain this locally uniform control, the symmetry property in ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("(64)")]#text(" is key, as it allows one to write")

#align(center)[#tao-fit-display[#mitex("g_{p_1,t}(p) - g_{p_0,t}(p) = (g_{p_1,t}(p) - g_{p_1,t}(p_0)) - (g_{p_0,t}(p) - g_{p_0,t}(p_1))")]]

#text("so that the main challenge is to show that the differences ")#mi("{g_{p_1,t}(p) - g_{p_1,t}(p_0)}")#text(" and ")#mi("{g_{p_0,t}(p) - g_{p_0,t}(p_1)}")#text(" are bounded uniformly in ")#mi("{t}")#text(", which can be done from the maximum principle and the Harnack inequality. The details are unfortunately a little complicated, and we refer the reader to ")#link("https://www.math.washington.edu/~marshall/preprints/uniformizationII.pdf")[#text("Marshall’s notes")]#text(" for the complete argument.")#linebreak()#text(" To close this section we give a quick corollary to the uniformisation theorem, namely ")#link("https://en.wikipedia.org/wiki/Rad%C3%B3%27s_theorem_(Riemann_surfaces)")[#text("Rado’s theorem")]#text(" on the topology of Riemann surfaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 68 (Rado’s theorem)")]#text(" Every connected Riemann surface is ")#link("https://en.wikipedia.org/wiki/Second-countable_space")[#text("second countable")]#text(" and ")#link("https://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(".")
]

#emph[#text("Proof:")]#text(" By passing to the universal cover, it suffices to verify this claim for simply connected Riemann surfaces. But the three model surfaces ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", ")#mi("{{\\bf C}}")#text(", ")#mi("{D(0,1)}")#text(" are clearly second countable and separable, so the claim follows from the uniformisation theorem. ")#mi("\\Box")#linebreak()#text(" It is remarkably difficult to prove this theorem directly, without going through the uniformisation theorem. (As just one indication of the difficulty of this theorem, the analogue of Rado’s theorem for complex manifolds in two and higher dimensions is known to be false.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 69 (Harnack inequality)")]#text(" ")#metadata(none) <tao-07e237d2b7a088638c35>#text(" Let ")#mi("{u: \\overline{D(z_0,R)} \\rightarrow {\\bf R}}")#text(" be a non-negative continuous function on a closed disk ")#mi("{\\overline{D(z_0,R)}}")#text(" that is harmonic on the interior of the disk. Show that for every ")#mi("{0 \\leq r \\leq R}")#text(" and ")#mi("{z \\in \\overline{D(z_0,r)}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{R-r}{R+r} u(z_0) \\leq u(z) \\leq \\frac{R+r}{R-r} u(z_0).")]]

#text("(")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-2b64c6d9afd8a34ed0db>)[#text("43")]#text(".)")
]

#heading(level: 1)[#text("Comments (65)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473441")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("Int he proof of Schwarz’s lemma (Lemma 15), the statement ")#tao-math("{\\left|f(z)\\right| \\leq z}", block: false)#text(" should be replace with ")#tao-math("{\\left|f(z)\\right| \\leq \\left|z\\right|}", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473443")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2016")])]

#text("I have a notational question. Why do you write ")#mi("L \\setminus \\mathbb{C}")#text(" instead of ")#mi("C / L")#text(" when the later seems more commonly used to describe the quotient spaces?")

#text("Sorry for the spam, I have midterms this week and of course trying to do anything but study for them.")

#emph[#text("[This is an artefact of the fact that my automorphisms area acting on the left. Of course in the case of additive actions, there is no distinction between ")#mi("\\Gamma \\backslash {\\bf C}")#text(" and ")#mi("{\\bf C} / \\Gamma")#text("; I’ll adjust the text accordingly. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473472")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("The adjustment has a typo: to the text above you added ")#mi("\\mathbb{C}\\backslash\\Gamma")#text(" instead of ")#mi("\\mathbb{C} / \\Gamma")#text(" (wrong direction of slash).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("In the proof of lemma 1(part ii), it should be “By part (i)”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473581")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("According to definition 58, if ")#mi("u = -\\infty")#text(" identically, it is (trivially!) subharmonic. Should this trivial example be excluded from the definition?")

#emph[#text("[Some authors adopt this convention, but it will not make a difference in the current notes. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("In theorem 51 (line 5), ")#mi("\\phi (p)")#text(" should be ")#mi("\\phi_{p_0}(p)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2016")])]

#text("Mathoverflow: A Generalization of Goldbach’s Conjecture : 2n=p+q,p≡q≡a(mod m)")#linebreak()#text(" ")#link("http://mathoverflow.net/questions/252597/a-generalization-of-goldbach-s-conjecture-2n-pq-p-equiv-q-equiv-a-pmod")[#text("http://mathoverflow.net/questions/252597/a-generalization-of-goldbach-s-conjecture-2n-pq-p-equiv-q-equiv-a-pmod")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473628")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("The Schwarz-Christoffel formulas in theorem 45 and exercise 46 are for bounded polygons. Are there similar formulas for unbounded polygons?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-473683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("Few typos")#linebreak()#text(" 1. Second paragraph of section 1, “fundamental theorem of calculus” should be “fundamental theorem of algebra”.")#linebreak()#text(" 2. Proof of Theorem 25, “concatenating it with the path ")#mi("{\\phi_p \\circ \\gamma_{0 \\rightarrow \\phi_p^{-1}(p^{\\prime})}}")#text("“, the expression should be ")#mi("{\\phi_p^{-1} \\circ \\gamma_{0 \\rightarrow \\phi_p (p^{\\prime})}}")#text(".")#linebreak()#text(" 3. Proof of Proposition 40, Corollary 27 is from Notes 3, not 2 (the link is actually correct).")#linebreak()#text(" 4. Same paragraph, “")#mi("{f^{\\prime}_n}")#text(" converge locally uniformly” should be ")#mi("{f_n}")#text(" instead.")#linebreak()#text(" Thank you!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2016")])]

#text("In proposition 40, is it possible to make the proof more constructive by using the explicit construction of the function ")#mi("h")#text(" from the function ")#mi("f")#text(" to give an explicit recursive construction of ")#mi("f_{n+1}")#text(" from ")#mi("f_n")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474023")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2016")])]

#text("In principle, yes, but the convergence of this algorithm is incredibly slow. Numerically, there are faster methods, such as the “Zipper” method of Kuhnau and Marshall, discussed for instance ")#link("https://arxiv.org/abs/math/0605532")[#text("here")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db05029042d920a266f6d181662e0b9cb9489201ad3ef5ce183d2cdc40564976-6daac5b6e2364943d6a6c3a7fcdb467d14531d0ce00b11e55fc13bc3501de858.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474046")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2016")])]

#text("Is it obvious somehow that the group of Moebius-transformations is a simple group? This is an exercise in Conway, preceded by an easy check that the kernel of a homomorphism from GL2(C) to the Moebius transformations under composition is all the multiples of the identity-matrix by the units in C, i.e. GL2(C) is not simple. So, identifying the group of Moebius trans. with GL2(C) seems to contradict this exercise (?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2016")])]

#text("The Mobius transformations are identified with ")#mi("{\\mathrm PGL}_2({\\bf C})")#text(", not ")#mi("{\\mathrm GL}_2({\\bf C})")#text(".")

#text("Saying a group is simple is equivalent to saying that every non-trivial conjugacy class generates the group, so one can establish the simpleness of the Mobius transforms through an understanding of the conjugacy classes. For instance, all parabolic Mobius transforms are conjugate to each other, and it is not difficult to see (e.g. by Gaussian elimination) that all Mobius transforms can be expressed as products of parabolic transforms. If instead one starts with a hyperbolic or elliptic element, one can find a conjugate of it which differs from it by a parabolic element, so from the previous fact we know that these conjugacy classes also generate the group. One can also proceed using the more general structural theory of Lie groups and Lie algebras, but this is probably overkill.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db05029042d920a266f6d181662e0b9cb9489201ad3ef5ce183d2cdc40564976-6daac5b6e2364943d6a6c3a7fcdb467d14531d0ce00b11e55fc13bc3501de858.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474067")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2016")])]

#text("Thanks. Is there a book out there that takes a more algebraic approach to complex analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/445caf57ee66ed5cf5ae23df7d4d093c698c49ce4478c58da5e88dff80844cb6-3c328d96909e2b83842f619b7c3ddff993a85afdbb511df5b7a42e2ba5ef9d00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heinrichs Gerhard")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474092")[#strong[#text("Heinrichs Gerhard")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2016")])]

#text("There are books about Riemannian Surfaces with more (commutative) algebra e.g. S. Lang Therory of algebraic and abelian Function’s")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Can you add some information on more recent approaches (e.g. the circle packing approach) to conformal mapping ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of venkyclement")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474690")[#strong[#text("venkyclement")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("In Proposition 12, why doesn’t the strategy of taking local line segments and passing to a finite subcover of the Riemann sphere not work for an open curve? This proposition suggests that all space filling curves of a unit square must be open.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("Both open and closed curves can be space-filling (in the unit square or in the Riemann sphere). What the proof of Proposition 12 shows is that either such curve can be deformed by continuous homotopy to a set which is locally the union of finitely many line segments, and is thus not space filling (but this still permits the original curve to be space-filling).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09b856866e933ff1ec819dd4ed54dc78e6417a35ae3fa8a0de6f98947ce06dd7-553661d70debfc24119d22947b255957da218fa27f53904dd9520351283a1846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nassoro mtandani")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-474697")[#strong[#text("nassoro mtandani")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("pro. tao i am so interested on how you solve mathematical problems i need to study math please helpme")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-477771")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("One can tell from context though, it might be better to indicate explicitly that the unit disk in the hyperbolic model is an “open” disk?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-477928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2017")])]

#text("This video ")#link("http://www-users.math.umn.edu/~arnold/moebius/")[#text("http://www-users.math.umn.edu/~arnold/moebius/")]#text(" seems to suggest that Möbius transformations are simplest when viewed on the sphere. But actually, that video only “defines” a Mobius transformation on the sphere and then project the image on the sphere back to the complex plane. Can one show (without using the Cartician coordinates ")#mi("z=x+iy")#text(" tediously maybe) that it is actually the same as the linear fractional transformation ")#mi("z\\mapsto\\frac{az+b}{cz+d}")#text(" on the complex plane?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-477992")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2017")])]

#text("This is perhaps simplest to see for special Mobius transformations such as translation, dilation, rotation, and inversion; general Mobius transformations are compositions of these (see discussion after Exercise 9), so once special Mobius transformations are identified with three-dimensional motions of the sphere, general Mobius transformations are also (because three-dimensional motions of Euclidean space form a group).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-477994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2017")])]

#text("In this note, what “inversion” really means is “reciprocation” while in geometry, inversion means ")#mi("z\\mapsto \\dfrac{1}{\\overline{z}}")#text("? (")#link("https://en.wikipedia.org/wiki/Inversive_geometry")[#text("https://en.wikipedia.org/wiki/Inversive_geometry")]#text(") It might be just a taste of terminology though. Or is there a higher point of view that they are actually the same thing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-478133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("Is this true that the Schwarz-Christoffel map ")#mi("F(w)")#text(" in Theorem 45 maps the exterior of ")#mi("D(0,1)")#text(" onto the complement of the polygon ")#mi("U")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-478167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("I’m not sure there is any natural way to extend ")#mi("F(w)")#text(" holomorphically to the entire complex plane (basically because of the branch cuts of ")#mi("(\\frac{w-w_j}{iw_j})^{\\beta_j}")#text(" that one would start encountering). Note that as the only automorphisms of the Riemann sphere are the Mobius transformations, one would only expect to conformally map both the interior and exterior of a domain in a Riemann sphere simultaneously to a disk and its exterior if the domain was already a disk, an exterior of a disk, or a half-plane.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-478172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2017")])]

#text("And if we wish to construct a conformal map that maps ")#mi("D(0,1)")#text(" onto the ")#emph[#text("complement")]#text(" of the polygon ")#mi("U")#text(", can we use the same Schwarz-Christoffel construction (replacing ")#mi("\\beta_j")#text(" with the complement angles)?")

#emph[#text("[Yes – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-481929")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] 246A, Notes 5: conformal mapping, covers Picard’s great theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 2: Circle packings, conformal maps, and quasiconformal maps | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-496020")[#strong[#text("246C notes 2: Circle packings, conformal maps, and quasiconformal maps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("[…] theorem was proven in these 246A lecture notes, using an argument of Koebe. At a very high level, one can sketch Koebe’s proof of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-497897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2018")])]

#text("In exercise 9, it seems that M should be connected. From the contradiction, I can just deduce that f is constant on f^{-1}(U’_β)∩U_α(this is defined in notes 4 definition 17) rather than on M. If I wanna expand the domain to M, I find that it’s necessary f^{-1}(U’_β)∩U_α intersects with another f^{-1}(U’_p)∩U_q, but without connectivity I can’t ensure f^{-1}(U’_β)∩U_α intersects with at least one another f^{-1}(U’_p)∩U_q. (if we mark f^{-1}(U’_i)∩U_j as E_ij， we can get M actually equals the union of all the E_ij, and M=E_pq ∪ (the union of the left E_ij), both of the right-hand is open, if M is connected, E_pq ∩ (the union of the left E_ij)!=Φ, E_pq can intersect with at least one another E_ij)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-497947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2018")])]

#text("In exercise 22, M should be revised again(2 position in exercise 22, beginning and end).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60bada27ceb85adeb58597a2693c4150f0cabaf138f14eb4951b73b3912e1961-6916e81074c68cf55d246c15bdf65fbfeae41584765c0efb5c996fd25b6e1655.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-555186")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("Some of the latex code in exercise 8 doesn’t render.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33b26edc4ef5e000529026ac77dd839231886a7bffaa8c1dd07531e238933100-5f9603ca0a37873cafc810cfe8dd5f2e70a532324b85eb4e9b217e39c16faaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prateek P Kulkarni")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-594324")[#strong[#text("Prateek P Kulkarni")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2020")])]

#text("By the definition of the Mobius Transformation, can we also infer that given functions f(z)=Re(z) and g(z)=Im(z) are also Mobius Transformations of z, z∈C ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-594486")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")])]

#text("These are not Mobius transformations (among other things, they are not even meromorphic or conformal).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-607886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("In proving that the only holomorphic map from riemann sphere (denote by R) to C are constant can we go as follows :-")

#text("Let f : R –> C be a holomorphic function. Since R is compact so, the image of R under f must be compact in particular a bounded subset of C. f is holomorphic on R means f is an entire function and hence by liouville’s theorem f must be constant on C and C is dense in R so, f must be constant on R .")

#text("Thanks.")

#emph[#text("[Yes. See also Exercise 22. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-607997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("If ")#mi("f:D(0,1)\\to{\\bf C}")#text(" is holomorphic and has a continuous extension up to the boundary ")#tao-math("\\{\\left|z\\right|=1\\}", block: false)#text(", can ")#mi("f")#text(" be extended to a holomorphic function on an open neighborhood ")#mi("U")#text(" of the closed unit disk?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-608001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("The function ")#mi("f(z) = (1-z)^{1/2}")#text(" satisfies the above conditions but has a branch point at ")#mi("z=1")#text(" – hence can’t be holomorphic in any neighborhood of ")#mi("z=1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-608041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#emph[#text("… in order for ")#mi("{f}")#text(" to have no pole at infinity, ")#mi("{f}")#text(" must then be constant.")#linebreak()#text(" ")]

#text("I don’t find the notion of “pole at infinity” in notes 4. Do I miss the definition somewhere in the notes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-608042")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("Intuitively, it is understood as zero at ")#mi("z=0")#text(". I was wondering if the notion of “poles” was defined for elements in the Riemann sphere in the notes.")

#emph[#text("[This is briefly discussed after Exercise 3 in the current notes. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-608161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2020")])]

#text("Similarly, “essential singularity at infinity” is mentioned in the proof of Proposition 15; I don’t find where it is defined in the notes.")

#emph[#text("[Discussion after Exercise 3 expanded to include such a definition. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-608164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2020")])]

#text("In the real case, zero derivatives imply local non-injectivity. How do you show in the proof of Proposition 15 that “as T is a diffeomorphism, the derivative has no zeroes”?")

#emph[#text("[This is Exercise 40 from Notes 4. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Course announcement: 246B, complex analysis | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-609492")[#strong[#text("Course announcement: 246B, complex analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2020")])]

#text("[…] Schwartz-Christoffel transformations and the uniformisation theorem (using the remainder of the 246A notes); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1bdf2b6021fed403775383e67bd5ad2072fb980e63efd95f0b2dddf5811cc-5250fbc72c4b431e10380bb743fde43273f6b3dbdbb614dc51cb19a6a05621a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wan-Teh Chang")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-615089")[#strong[#text("Wan-Teh Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2021")])]

#text("Prof. Tao: The second part of the proof of Lemma 1 (ii), starting from “By part (i), …”, has an error. The domain of ")#mi("f \\circ \\phi")#text(" and ")#mi("u \\circ \\phi")#text(" is ")#mi("U")#text(", not ")#mi("V")#text(", and therefore we can’t apply ")#mi("f \\circ \\phi")#text(" or ")#mi("u \\circ \\phi")#text(" to a ball ")#mi("B(z_0, r)")#text(" in ")#mi("V")#text(".")

#text("I found a proof by zhw in ")#link("https://math.stackexchange.com/questions/151827/composition-of-a-harmonic-function-with-a-holomorphic-function-is-still-harmonic")[#text("https://math.stackexchange.com/questions/151827/composition-of-a-harmonic-function-with-a-holomorphic-function-is-still-harmonic")]#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1bdf2b6021fed403775383e67bd5ad2072fb980e63efd95f0b2dddf5811cc-5250fbc72c4b431e10380bb743fde43273f6b3dbdbb614dc51cb19a6a05621a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wan-Teh Chang")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-615346")[#strong[#text("Wan-Teh Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("Prof. Tao: In Section 4. Schwarz-Christoffel mappings, in the equation ")#mi("(z_{j+1} - z_j) = c_j e^{i\\beta_j \\pi}(z_j - z_{j-1})")#text(", the factor ")#mi("c_j")#text(" should be changed to ")#mi("\\frac{1}{c_j}")#text(".")

#text("Also in Section 4, in the sentence “…, thus ")#mi("z_* = (1-t) z_{j-1} + t z_j")#text(", the subscripts for $z$ on the right hand side should be ")#mi("j")#text(" and ")#mi("j+1")#text(", not ")#mi("j-1")#text(" and ")#mi("j")#text(".")

#text("I have a question about the statement “From the Alexander numbering rule (Exercise 55 of Notes 3) we see that ")#mi("U")#text(" always lies to the left of the polygonal path ")#mi("\\gamma_{z_1 \\rightarrow z_2 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}")#text(".” This fact seems intuitively obvious because the simple closed polygonal path is anticlockwise. Why do we need to invoke the Alexander numbering rule to see this fact? To apply the Alexander numbering rule, we need a contour ")#mi("\\sigma")#text(" that intersects the closed contour ")#mi("\\gamma_{z_1 \\rightarrow z_2 \\rightarrow \\dots \\rightarrow z_n \\rightarrow z_1}")#text(". How should we pick the contour ")#mi("\\sigma")#text("?")

#text("Thank you!")

#emph[#text("[Corrected, thanks. Exercise 54 should be used in place of Exercise 55. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-616859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2021")])]

#text("Do you define the notion of “branch points” somewhere in this series of notes?")

#text("Searching around the 246A Notes 4, I don’t see any definition of it.")

#emph[#text("[Brief definition of branch point added. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-619303")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2021")])]

#text("In Exercise 60 (iii) we can approach by using the variant of maximum principle for harmonic functions in the case when M is connected. How to deal with the case when M is not connected ?")

#emph[#text("[Connectedness (or the maximum principle) is not necessary for part (iii) of this exercise. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-619504")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2021")])]

#text("Yes this just follow tautologically as indicated during yesterday’s class by prof. Tao.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-620693")[#strong[#text("246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2021")])]

#text("[…] can be viewed as a more precise assertion of the subharmonicity of (see Exercises 60(ix) and 61 of 246A Notes 5). Here are some quick applications of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math 246A, Notes 4: singularities of holomorphic functions | What's new")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-634694")[#strong[#text("Math 246A, Notes 4: singularities of holomorphic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] Previous set of notes: Notes 3. Next set of notes: Notes 5. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-641386")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2022")])]

#text("The authors of the video below state the following theorem in an AMS Notice article:")

#text("A complex mapping is a Möbius transformation if and only if it can be obtained by stereographic projection of the complex plane onto an admissible sphere in ")#mi("{\\bf R}^3")#text(", followed by a rigid motion of the sphere in ")#mi("{\\bf R}^3")#text(" which maps it to another admissible sphere, followed by stereographic projection back to the plane.")

#text("A sphere ")#mi("S")#text(" in ")#mi("{\\bf R}^3")#text(" is admissible if its north pole lies in the upper half-space.")

#text("They say that “We have not been able to ascertain the origin of this simple, elegant result.” (Does anyone know the origin of this result?)")

#text("Can the result above be proved by theorems/propositions in this set of notes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-641407")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2022")])]

#text("The Notice article actually gives a proof. Denoting by ")#mi("P_S")#text(" the stereographic projection from the north pole of ")#mi("S")#text(" and ")#mi("T")#text(" a rigid motion of ")#mi("{\\bf R}^3")#text(", one can cook up ")#mi("f=P_{S^{\\prime}}\\circ T\\circ P_S^{-1}")#text(" (")#mi("S^{\\prime}=TS")#text(") for a given Mobius transformation ")#mi("f")#text(" using the composition of translation, inversion, dilation, rotation and then a translation. (This may be a good exercise to put into this set of notes.)")

#text("I am wondering if there are any group theory points of view showing that the choice of the sphere ")#mi("S")#text(" and rigid motion ")#mi("T")#text(" is not unique.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-641413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2022")])]

#text("The group of Mobius transformations can also be characterized as the largest group of meromorphic transformations on the Riemann sphere.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-642795")[#strong[#text("A Detailed Proof of the Riemann Mapping Theorem – 爱读书网")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")]

#text("[…] This proof is a reproduction of W. Rudin’s Real and Complex Analysis. For a comprehensive further reading, I highly recommend Tao’s blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643467")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("In the proof of Proposition 15:")

#text("… we conclude that ")#mi("{T}")#text(" does not have an essential singularity at infinity. Thus ")#mi("{T}")#text(" extends to a holomorphic function from ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(".")

#text("Can you elaborate on how exactly Casorati-Weierstrass is used here? When you write “essential singularity at infinity” for the map ")#mi("T")#text(", do you first consider ")#mi("{\\bf C}")#text(" as an open submanifold of the Riemann sphere ")#mi("{\\bf C}\\cup\\{\\infty\\}")#text(" (and *then* use the discussion after Exercise 3)? (I am probably thinking this in a too complicated way. )")

#text("Also, why can be ")#mi("T")#text(" extended? Can’t infinity be a non-isolated singularity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643562")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2022")])]

#text("Here we are applying a coordinate chart to identify a neighborhood of ")#mi("\\infty")#text(" with some portion of the complex plane, for instance by looking at the function ")#mi("z \\mapsto T(1/z)")#text(" which has an isolated singularity at zero, and for which the image of the unit disk avoids ")#mi("T(D(0,1))")#text(", so that the singularity of ")#mi("T(1/z)")#text(" at the origin, which is already isolated, cannot be essential. Which is the statement claimed, expressed in a coordinate chart.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643468")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("Do you have any heuristic on how one can come up with the key Blaschke factor ")#mi("{\\frac{z-\\alpha}{1-\\overline{\\alpha} z}}")#text(" (moving ")#mi("\\alpha")#text(" to the origin and maps the disk to itself) in the proof of Theorem 19? (There are so many Mobius transformations, why this one? Any way to see how one can get this naturally?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643563")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2022")])]

#text("If the Mobius transformation is to move ")#mi("\\alpha")#text(" to the origin then it basically has to have a ")#mi("z - \\alpha")#text(" in the numerator (up to constants at least, but the constant can always be transferred to the denominator). If it is to preserve the unit circle, then for ")#mi("z = e^{i\\theta}")#text(" the numerator has to be the same magnitude as the denominator, so in particular must be a unit phase multiple of that numerator (or its complex conjugate). From this and some trial and error one can soon come up with the above choice of transform (up to a unit phase rotation).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643483")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("In Section 2, given a Riemann surface ")#mi("M")#text(" and a group ")#mi("\\Gamma")#text(" of complex automorphisms of ")#mi("M")#text(", one has the quotient set (orbit space) ")#mi("\\Gamma\\backslash M")#text(", which has the Riemann surface structure (as the “quotient manifold”). Does one always have such inheritance if ")#mi("M")#text(" is a set with other structure S (e.g., groups, vectors spaces, topological spaces, etc.) and ")#mi("\\Gamma")#text(" an automorphism group in the corresponding category?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2022")])]

#text("Not automatically. In the Riemann surface category, for instance, it is important that the action be free and proper; in the group category, one needs the orbits to be conjugation invariant (and in particular, if one is acting via a subgroup, the subgroup has to be normal); and so forth. The structure of quotient spaces (or moduli spaces) in general can be quite subtle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643542")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2022")])]

#text("In the proof of Theorem 52 (Maximal maps into ")#mi("D(0,1)")#text(") implying Theorem 50 (hyperbolic case of the uniformisation theorem), swapping the roles of ")#mi("p_0")#text(" and ")#mi("p_1")#text(" gives the equality (7), but how does one get the equality ")#tao-math("\\left|R\\circ\\phi_{p_0}(p_0)\\right|=\\left|\\phi_{p_1}(p_0)\\right|", block: false)#text(" above (7)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-643565")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2022")])]

#text("Since ")#mi("\\phi_{p_0}(p_0)")#text(" vanishes, ")#tao-math("\\left|R \\circ \\phi_{p_0}(p_0)\\right|", block: false)#text(" is equal to ")#tao-math("\\left|\\phi_{p_0}(p_1)\\right|", block: false)#text(" by definition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-677474")[#strong[#text("Complex diffeomorphism and a domain being Polygon – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2023")]

#text("[…] ")#link(<tao-a87209d86a5418c612ee>)[#text("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#more-9481")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-693866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("Dear Prof. Tao,")

#text("In Exercise 43, this problem is solved by conformal mapping and the Poisson integral formula. However, other ways to solve it include the heat equation, and even Brownian motion. I would like to ask, what exactly is the core of solving this problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-693873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("All of the techniques you listed are naturally adapted for conformal geometry (e.g., Brownian motion is conformally invariant, thanks to Levy’s theorem). Generally speaking, when a problem has some sort of symmetry or invariance (such as conformal invariance), it makes sense to use proof techniques that also respect that invariance (unless one deliberately chooses to “spend” the symmetry to achieve a useful normalization or gauge fixing).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-693882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("What an insightful reply! I would also like to ask: since the conformal invariance only holds in two dimensions, then in the general case, what is the corresponding “invariance”, or what is the core of this problem? And what are the corresponding techniques?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/#comment-693883")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2026")])]

#text("In higher dimensions one only has the invariance of Riemannian isometries (e.g., rigid motions of Euclidean space), which can be helpful to solve the Dirichlet problems in very symmetric domains, such as half-spaces or balls, where the symmetry can be used to reduce the dimension of the problem or suggest representation-theoretic, or Fourier-analytic techniques; but this invariance is not particularly useful for general domains (in particular, one does not expect anything as nice as the Riemann mapping theorem to hold in higher dimensions). In general, one does not expect to have good explicit formulae to solve the Dirichlet problem here, though the Brownian motion interpretation of the solution can be arguably viewed as a “explicit formula” in some weak sense. In practice it is more useful to focus on upper and lower bounds for such solutions, such as what can be obtained from the maximum principle or by working with subharmonic or superharmonic functions.")
]
]
]
]
