// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/
// Converted to Typst by tao2typ: "2026-10-14T16:39:38.254463+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What should we tell our students?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What should we tell our students?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/")[#text("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://alozanoroble.github.io/")[#text("Álvaro Lozano-Robledo")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("TL;DR: Keep calm and carry on studying math.")

#text("I would like to give Terry my heartfelt thanks for giving me the opportunity to contribute a post to his blog. After giving much thought to what topic I should write about to maximize impact, I decided to take this opportunity to reach out to the students: particularly to those undergraduate and graduate students who just a few months ago were dreaming of an academic career in mathematics, but their dreams may now seem distant and, for some, apparently impossible to ever become a reality. This post was inspired by a message (quoted below in its entirety, with permission) that I received from a student desperately looking for advice and guidance. This is not the only such message I have received (and I suspect that many of us are receiving many similar requests), but it is perhaps the most heartfelt, and the one that has moved me the most. Please also note the urgency of the message. Students are making decisions now.")

#metadata(none) <tao-af453485122d0ad70094>

#emph[#text("Hey Prof, I’ve been watching your videos for a while now as a pure math undergraduate who once wanted to pursue a career in math academia. I know you probably have been getting a lot of questions regarding this matter, but I am just completely at an utter loss regarding my career trajectory, and even further, the meaning of life at this point. (I do realize a lot of people have it much worse than I do). I know you have been making a lot of videos lately with the new LLM progress updates, so I thought you might be the appropriate person to reach out to and get a slightly more structured answer regarding this matter. So, to cut to the chase, what I really want to know is: will math academia be big enough and accessible enough for anyone with sheer passion (despite not being the brightest mind in the field) to pursue a career in, or will it inevitably shrink such that it will only really be accessible to the brightest minds? (I do realize the “brightest minds” that I am mentioning here is not well-defined, and in a sense, I am taking it as a hypothesis that this is someone who is “smarter than me”). My second question is, will AI within 5–10 years surpass humans in being able to do pure math research? I’ve just really been lost for a couple of months now and lost in life completely. I don’t mean to make your day more depressing; sorry if I come off in any way of that sort. I would appreciate any advice.")]

#text("The advances in LLMs are disrupting almost all aspects of academic research and education in mathematics and, while there are many aspects that concern me, the one single issue that worries me the most is the very real possibility that we are about to lose an entire generation of mathematicians. Many students are asking themselves whether going for a PhD in math is the right career move at this time. Many of them just a year ago were headed to grad school in mathematics, but they are now changing their mind, and think that a different career (as far from math as Law School) may be the best path given the threat that AI may completely alter the academic math landscape in the coming months.")

#text("The questions students are worrying about are as follows:")

#enum(start: 1, 
[#text("Will AI surpass the mathematical research ability of any human?")],
[#text("Will research mathematicians become `professional prompters’ and interpreters of LLM output?")],
[#text("Will only the `brightest minds’ be able to meaningfully contribute to research mathematics?")],
[#text("Will mathematicians be employable? Will mathematicians be needed?")],
[#text("Should I pursue a PhD in math at this time?")]
)

#text("In this essay I will try to address these questions to the best of my ability, but will start with two disclaimers, followed by a brief summary of my own outlook.")

#text("Disclaimer 1. My answers may “age like milk,” as YouTube commenters love to quip on older videos. I can live with that, because this post expresses how I and many of us in the community around me feel today. Things can change quickly, though (see Disclaimer 2). I also want to acknowledge my privileged point of view as a tenured professor in mathematics — the situation can look much more troubling from the point of view of the job insecurity of a very early-career mathematician.")

#text("Disclaimer 2. No one has the answers at this time. I want to make clear from the start that no one can know with certainty the answers to any of the questions posed above: not any particular Fields medalist, not any given mathematician, not any particularly vociferous AI expert, and not the frontier model companies. And if someone is telling you with extraordinary confidence what the future holds, then I would immediately distrust the motives of their conviction (anecdotically, almost anyone on X.com that predicts the triumph of AI and the demise of the mathematics profession, is either a self-proclaimed “AI expert” or works for an AI startup). No one has a clear picture because development of LLMs has been so fast (and opaque) that it is almost impossible to predict what is to come. A good piece of advice is to ask the same questions to many people, to hear a (hopefully balanced) range of opinions. To that end, I am collecting interviews with mathematicians in what I call the “")#link("https://www.youtube.com/playlist?list=PLLwGtZ_pUvwU")[#text("Human Mathematicians in the Age of AI")]#text("” video project. I encourage you to listen to the interviews for some fantastic points.")

#text("For the record: I do not have the answers either, but I am hopeful and excited for the future. I will explain why below.")

#text("Who is controlling the narrative about LLMs in math? Overall, the mathematical community’s reactions to the advances in AI have ranged from confusion to anger — but, mostly, confusion about how to proceed. The most dystopian predictions seem to be driven by the fact that the so-called frontier model companies (and other LLM-powered companies) are controlling the narrative in the best of their interests. Unfortunately, the best corporate outcomes for an LLM company could have potential catastrophic outcomes for the math (and scientific) community.")

#text("It is certain that AI companies want us to believe that their products will imminently achieve “super-human intelligence” and that, in particular, they will be able to autonomously solve any mathematical problem a human could solve with or without the aid of an LLM. It is in their best corporate interest that the public is convinced of the (allegedly) “unlimited potential” of their technology, particularly before their companies’ stocks go public (i.e., their upcoming IPOs: Anthropic in November 2026, OpenAI in early 2027, etc). Thus, they have tried to control the narrative by spending a huge amount of (human and computational) resources in order to find solutions to certain well-known mathematical problems. The proofs are then released in announcements that lead the public to believe that their models can already autonomously solve any problem at all, and swiftly at that. However, this is (currently) far from their true capabilities. For instance, they never discuss how many tokens have gone to the trash bin with no payoff in trying (and failing) to solve famous problems. We do know, for example, that OpenAI invested the equivalent of some $15M to solve (err, scoop) the Navier-Stokes problem, but we are unaware of the surely colossal running cost of the failures to resolve other Millennium Prize problems.")

#text("My own outlook. Even though I am concerned about the incursions of LLMs into academic mathematics, I am quite hopeful. In fact, I consider this to be the most exciting time in my mathematical career (since the year 2000 say). Truly, this may be the most thrilling moment in mathematics in the modern history of our discipline, and I would be terribly sad to see young people leave academia and miss out on the stunning opportunity to be at the frontlines of the current scientific revolution. And not just sad: I think their absence would have disastrous effects for the field.")

#text("Undoubtedly, LLMs are already an incredibly powerful tool. If used correctly, and if we set up sensible academic conduct expectations around the use of LLMs, these tools can accelerate progress in our discipline unlike in any previous era. I fully expect that we, the community, will adapt and adjust to this new period, and we will harness these tools to achieve truly great things that just a few months ago seemed far out of reach. And I fully expect that human mathematicians will be front and center in these wonderful achievements to come. I will add reasons that support my optimism below.")

#text("I also want to add at this point that the day-to-day of a mathematician has not changed much so far! My days are still filled with teaching and joyful conversations about math with colleagues and students, doing research on a number of exciting (old and new) projects, and going to ")#link("https://web.math.pmf.unizg.hr/~fnajman/Opatija.html")[#text("stimulating conferences")]#text(" to learn and disseminate our most recent methods and findings, while spending time with colleagues that make the mathematical community so wonderful and vibrant. Daniel Litt mentioned the same sentiment ")#link("https://x.com/littmath/status/2105300516188143940")[#text("in a recent tweet")]#text(".")

#text("One thing has changed though, I am busier than ever before, because the number of research projects I am involved in has tripled in just a few months. My research horizon has expanded significantly, and I have many more projects available for students to help me with.")

#text("Now, to the pressing questions:")

#text("“Will AI surpass the mathematical research ability of any human?” This is completely unclear. On one hand, the current trajectory in capabilities is surely significant, and we have already seen many impressive results that have been either proved by LLMs, or their proofs have been made possible thanks to substantial LLM contributions. On the other hand, none of the proofs so far seem to contain “alien ideas,” a move-37, or completely novel arguments or new concepts that were not present in the literature in some form or another. This should not be shocking because the LLMs are built and trained on the entirety of all human contributions to date, so it stands to reason that they would `think’ within the boundaries of our current knowledge and make connections (sometimes surprising and ingenious!) among ideas that are already present in the literature. I am particularly fond of the hypothesis (or toy model, as he called it) put forward by ")#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/")[#text("Nestor Guillen in a recent blog post")]#text(", where he argues that LLMs may work within the confines of the convex hull of ideas that are currently available in the literature.")

#text("Take, for example, ")#link("https://openai.com/index/model-disproves-discrete-geometry-conjecture/")[#text("the disproof of Erdos’ unit-distance conjecture")]#text(". We can imagine the current set of mathematical ideas as a stellated high-dimensional polytope, and we can place the state-of-the-art ideas on discrete geometry at an outer vertex and our knowledge on algebraic number theory at a different outer vertex. The idea for the proof seems ingenious at first sight because it cleverly mixes strategies from two fields of math at the vertices of the polytope of ideas, but after closer inspection, it’s a proof that was within reach of humans as it just sits within the convex hull of the polytope.")

#image("../assets/2328a38340347c55fe7ebe6bc01afd0867ba80e4c50a5b9a1e68ecdfbb7a27cb-2a1cb12b5ed36caa56d149bf0aef0cf4375236a359a2fa4ab33a57fb295bb0d8.jpg", width: 90%)

#emph[#text("The polytope of ideas")]

#text("This agrees with ")#link("https://cdn.openai.com/pdf/74c24085-19b0-4534-9c90-465b8e29ad73/unit-distance-remarks.pdf")[#text("what Melanie Matchett-Wood said")]#text(" about the proof of the unit-distance when it was released: “I believe if the level and type of human expertise that is represented on this note had been assembled to find a counterexample to this conjecture a month ago, and those people put in similar amounts of time working on it than they did to reading and thinking about Chat GPT’s solution, the mathematicians would have found a counterexample.”")

#text("However, a proof of the Riemann hypothesis, say, may need new ideas that are strictly outside of the convex hull of current mathematical ideas, and it is therefore out of reach for an LLM. Only after a new idea is introduced in a new paper, the polytope of ideas may acquire a new outer vertex. And only then the LLMs, after being retrained to include those ideas, may fill out the set of results up to the new convex hull, which may or may not include yet a full proof of Riemann.")

#image("../assets/0497c7f52b4780c229b5e48c7bcf880cf7e0d517f5aa07d760f4a4cb22b1bd4a-19e3529a8f0873eaf847f9ac06523f5b7bb1512b8dadf13b6d8b8a0f990abd36.jpg", width: 90%)

#emph[#text("The convex hull of ideas")]

#text("If this toy model holds up, then we would indeed expect the very fast advances in mathematics that we are currently seeing. As the LLMs take advantage of the stellated nature of the polytope of ideas, they will continue to fill in gaps between outer spikes. But as the LLMs fill in the convex hull with new results, we will see a deceleration in the number of results being shown solely by artificial intelligence. We will need human advances and intuition to generate new ideas that expand our knowledge polytope.")

#text("Even if the mathematical capacity of the LLMs (or future AI models) can at some point reach beyond the convex hull of the current set of human ideas, there is a different way that we may reach a limit to the LLM capacity: feasibility and ethical use of resources (this is similar what fellow optimist Kevin Buzzard called the “natural boundary” in ")#link("https://xenaproject.wordpress.com/2026/10/01/to-grieve-or-not-to-grieve/")[#text("a recent blog post")]#text("). Is any cost (a dollar amount, human cost, ethical cost) acceptable in the pursuit of solving a given problem? Should we spend millions of dollars and an undisclosed amount of natural resources in order to find a solution for Navier-Stokes? As an analogy: we would like to know if there is life on Mars, but in order to do so as soon as possible, we would need an absurd amount of funding and risk the lives of a human crew in the process. Is it worth it? Similarly, we may reach a point where an LLM could solve an important problem for an exorbitant cost (in terms of funding and resources) but it may just not be an acceptable cost for the taxpayer or society to bear. Instead, we will need humans to devise an alternative route (the equivalent of a gravity-assisted robotic mission to Mars) to solve the problem at an acceptable cost, that produces a similar result in terms of mathematical advances and, more importantly, human understanding.")

#text("“Will research mathematicians become `professional prompters’ and interpreters of LLM output?” There is no indication that this will be the case. Yes, LLMs have produced proofs of important results somewhat autonomously (according to the frontier model companies — see Disclaimer 2) that some mathematicians have been tasked with interpreting and digesting. But in my own experience, and other research mathematicians who are using LLMs in their research seem to agree, working with an LLM is akin to discussing a problem with a collaborator, and the results heavily depend on how much guidance and intuition the mathematician inputs into the conversation. In other words, the LLMs are more than tools: they can be research collaborators but, as in any collaboration, the experience and the results are greatly improved when all parties contribute to the discussion. Further, mathematicians have no desire to prompt “solve the Riemann hypothesis, make no mistakes” and then interpret the proof. We prefer to be active participants during all the steps in the process of the discovery of a proof, because we are motivated by the `why the result is true,’ more than by the final answer that `the statement is true.’")

#text("Also, if we buy into the previous concept of the convex hull of ideas, then at some point in the near future it will be impossible to make progress in mathematics without a human adding a new idea, a new definition, a new concept that creates a new spike in the polytope, and then progress can occur.")

#text("“Will only the `brightest minds’ be able to meaningfully contribute to research mathematics?” At any given time in the history of mathematics, there have been mathematicians who are research active, and whose mental capacity for mathematics seems completely super human (e.g., the owner of this blog, among many others). It is natural to surmise that they could solve any problem we could solve, in a fraction of the time it would take us to complete a proof and write it up. However, this has never stopped those of us with a more modest capacity for mathematics from enormously enjoying doing research, and producing results that are far from insignificant. In fact, mathematics has always benefitted from the range of ideas and points of view, from the very concrete to the big bird’s eyeview, from the smaller contributions to the building of entire new theories.")

#text("Similarly, I am not threatened by the mathematical capacity of LLMs. For one thing their capacity is currently limited, as pointed above. And for another, even if their capacity becomes far superior, there will always be a need for mathematicians at all levels to guide research in paths that make sense for humans to walk (not run).")

#link("https://youtube.com/shorts/gK8iT-oKCh0?si=heh8MYcVW22tqXlr")[#text("The mathematical universe is enormous (as Emily Riehl said)")]#text(", and computing time is finite. There will always be areas of mathematics that are under-explored and where even beginners can break new ground. The LLMs can help in the process, by quickly exploring avenues that may be dead ends, pointing out paths that have already been explored, and shining a light on paths that are likely to be fruitful.")

#text("As I mentioned above, I have never been this busy, because the access to LLMs has multiplied the number of areas that I have access to, and my curiosity has expanded well beyond my research area. I now have many more ideas that I can possibly explore on my own, so I am recruiting more student collaborators than ever before, to help me test whether these problems can lead to interesting results. Students can be involved in research earlier than ever before too because the LLMs can help them learn material faster (and deeper!), by virtue of being available 24/7 to answer their questions, instead of my meager one or two available hours per week to meet with them.")

#text("“Will mathematicians be needed? Will they be employable?” I find these questions natural but also perplexing. Even in the most dystopian of scenarios where AI becomes super human in all research tasks, what good would a proof (of a theorem in pure mathematics) be if there are no human mathematicians to digest it and understand it? Regardless of the advances in LLMs and AI, there will be mountains of research to be understood by humans, with or without the help of a computer.")

#text("In addition, we seem to forget that mathematics departments exist in universities to serve two primary goals: ")#link("https://www.bu.edu/math/about/departmental-mission-statement/")[#text("discovery and communication of mathematical knowledge")]#text(". Virtually every mathematics department emphasizes, in equal parts, our research and educational missions (and many institutions place the educational mission of mathematics at a much higher level than their research mission). Mathematics courses are an integral part of a liberal arts curriculum because learning to think as a mathematician is a highly useful and applicable skill. The fact that we are researchers adds immense value to our educational goals, because students are best served learning from those scientists who are in the frontlines of research. The research opportunities that we provide for undergrads are a very valuable add-on to their curriculum, as it is a different type of training that helps them be employable in the future. And as long as the mathematical way of thinking continues to be a highly valuable skill to be learned by the undergraduate population, there will be a great need for mathematicians to be hired by universities.")

#text("The LLMs are making math research more accessible than ever to those who are not even in academia or even mathematicians. This means that undergrads will be able to join actual mathematician-led research projects much more easily, and it may be a new fertile ground for exploration. Not mindless exploration, though, but mathematical exploration where the goal is understanding and for the students to be initiated and trained into a highly technical field (in an ethical way). And, of course, we should prioritize training students in how to communicate the mathematics they learn, as that has always been (and probably will become even more of) a crucial skill.")

#text("All of this to say that I cannot conceive that the LLMs will displace mathematicians from their jobs. On the contrary, they might produce jobs since our research productivity may sky rocket. On the other hand, I am more worried about policies and funding issues that are political in nature and have nothing to do with the AI and LLM conversation.")

#text("Finally, the most important question of all, that I wanted to address here:")

#text("“Should I pursue a PhD in math at this time?” The answer to this question should be personal to each and every student. But, in my opinion, the answer should not have changed from a year ago to today. The most important reason (and perhaps the only reason) to do a PhD in math should be that the candidate is passionate about mathematics and wants to become an expert in a particular topic within our field. If that is the goal, then the presence of LLMs in mathematics is irrelevant, because the goal is achieved when the candidate has gained sufficient knowledge to be an expert on a particular problem. If anything, LLMs may be used as a tool to achieve that goal more efficiently. For one, I am using them every day to finally understand concepts and techniques that I always had questions about, and now I can query an LLM until I am fully satisfied. I am able to search for the explanations and examples that click with me, that click with my own particular way of thinking about mathematics.")

#text("To what degree a student wants to use LLMs in a math PhD should be a personal choice but I will say that, as my colleague Jeremy Teitelbaum put it in a recent interview (here is ")#link("https://www.youtube.com/shorts/TKsGcE7wcek")[#text("the bit I am referring to")]#text(", and here is ")#link("https://youtu.be/bqh4ihdanbI?si=idresVO-xZEqjfja")[#text("the full interview")]#text("), students cannot afford not to learn about the current capabilities of LLMs, or any other technology for that matter. If your goal is to become an expert, then you have to be amenable to learning from all experts in the field, and from all sources that may allow you to go deeper into a subject than anyone else before you — and LLMs can be extremely efficient tools to explore literature, for instance.")

#text("But once again, the decision to do a PhD should not be based on the current state of the art of technology.")

#text("I wanted to do a PhD in mathematics because it seemed like a magnificent challenge. I wanted to do a PhD because I wanted to learn how Andrew Wiles proved Fermat’s Last Theorem. I wanted to continue studying mathematics because I simply did not want “a real job,” and the opportunity of contemplating advanced math on my own for a few years seemed like a dream to me, just too good not to give it my best shot. I know I would have deeply regretted it if I had not tried to complete a PhD when I had a chance (the best time to do it is when your undergrad knowledge is fresh!). I wanted to hear mathematicians talk about math, and rejoice in the small little details and miracles that make proofs work. I wanted to meet and hang out with other people who also thought number theory was the coolest thing on Earth. I wanted to publish a paper in a research journal, with my name on it, because I discovered a new theorem that no one had thought of before. I wanted to explain and share my passion for mathematics with others in a classroom ")#link("https://alozanoroble.github.io/mathandcobb/")[#text("and outside of the classroom")]#text(".")

#text("Simply put, I just wanted to do math, and I would have been devastated if some undefined threat to the field of mathematics scared me away from the opportunity to pursue a PhD.")

#text("And if you are a student that is passionate about mathematics, and someone who wants all of that too, then a PhD is the right path for you, regardless of the technology available during your degree. You will learn to use the technology to a degree that you are comfortable with, and that fulfills your own dreams and expectations of what a PhD in Mathematics means to you.")

#text("Afterword: the BIG OpenAI release. After I finished writing this blog post, and had already sent it to Terry, ")#link("https://github.com/openai/math")[#text("OpenAI released a huge treasure trove")]#text(" of results in mathematics. This is, undoubtedly, a historic time in mathematics. The theorems in their papers prove some huge open problems in mathematics: the resolution of the so-called quasi Riemann Hypothesis, Goldfeld’s conjecture, the Hodge Conjecture in the case of CM abelian varieties, Hilbert’s 10th over Q, the Rigidity Conjecture… and the list goes on and on.")

#text("But such a tremendous release does not force me to change any of the points I made above. On the contrary, we already knew their models can do amazing things (e.g., Navier-Stokes). We already knew the frontier models can connect dots in the existing literature in ingenious ways (e.g., unit-distance conjecture). We already knew that OpenAI can spend a mind-boggling amount of resources to attack problems.")

#text("Also, we suspected that their models have limits and the new release shows evidence of that too. In their report, they mention that they attacked 4000 open problems, and their model was able to make progress on about 700 related problems. Yes, some of the ones they were able to solve are huge. But it also shows that their models are limited, quite possibly due to the arguments we explained above.")

#text("Are any of the solutions using new ideas that are outside of the convex hull of the current ideas in the literature? We will need mathematicians and time to digest these new proofs and understand what connections are being made, and whether brand new ideas were actually discovered in the process.")

#text("The main point of my post remains the same, though. There is a lot of mathematical research that remains to be done with and without the aid of LLMs. There are new mountains of mathematics to explain and communicate to others. And if you are a student who is passionate to learn what is new and what is left to do, then a PhD is definitely the right path for you.")

#heading(level: 1)[#text("Comments (120)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c9c874d9ca2af4588df5f026fc270f5245caf6cb7dd57040ac1b9f6a7a8fb82-9cc015a16d567518774427369c14cf4b0520cf7d60e0850e11b53b785d536466.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adel liot")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697660")[#strong[#text("Adel liot")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I am only but a grad student ,so bear in mind that fear for career has always been a thing in such a small field.I loved the analogy with the hull and agree in most terms,but I believe that this is also a very optimistic outlook on the consequences of AI ,and ignoring several aspects or others angles of reality.")

#text("The biggest that comes in mind to me is the point about breadth.While it is true that LLMs almost have the advantage of breadth but disadvantage of only knowing what was already made : aren’t main breakthrough done by finding links we never thought of before ?")

#text("Perelman and Hamilton used Ricci flow and entropy to prove poincare conjecture in 2003,which was fairly distant from classical topology.This isn’t something new,and while we could argue we have higher abilities this always was one of the main traits of what made a startling discovery.")

#text("One could argue that that still keeps us the ability of creating New concepts and tools,or recognizing patterns in our theory.But we could ,once again,argue that those discoveries are possible mostly when the breadth of topics enables to see more than we currently do(e.g. algebraic geometry as the most startling example).This is something already happening with the counter-example of the jacobian conjecture.")

#text("In the most optimistic case where research adapt,that somehow LLMs are severely limited once it pushed boundaries : there is still no reason that mathematicians are kept if temporary results are better than current PhD and researchers.")#linebreak()#text("AI currently amass investments beyond recognition,and there is a real fear where LLMs might just replace us for the next generation until they realize the dead stop of computational cost.")

#text("This is something that already happened in IT,in which regret only arise months later.One could argue that the slowness of mathematics research and it’s extent would only make this realization come years later instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Just try to create a value during your PhD, try to train your brain and work steadily on becoming better. If you can create a value for even a small number of people, and if you are at the same time a reliable person, I would not worry about your future or job security as a mathematician.")

#text("There is no such thing as guaranteed job security. Next gen robots may also become decent plumbers or able to install some high voltage power lines.")

#text("But math is about humans to understand. This process cannot be substituted by Ai, the more Ai advances, the more work for us.")

#text("What would you tell a primary school student who asks “why should I learn about numbers and shapes, my teacher anyways knows them already well?”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2026")])]

#text("Your words are inspiring and heart-warming.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("“… until they realize the dead stop of computational cost.”")

#text("This has been anticipated for a while. Search “photonic computing”, or “biological computing”. The latter uses human neurons grown from stem cells to form processing units (called “brain organoids” or “neurospheres”) resulting in an immense reduction in energy use. There are several companies working on each approach.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/617591dcf8ecddeec09d6298e8973f0355270c4205e15110378ade0a4e336c79-4ac42e3c4a47a942d5b6871a32c24aceb0c51b8b91d6afd2aef96fa89765bf1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("I am not sure for whom this post is meant to be — it is certainly not meant for an “average” student planning a career in mathematics academia.")

#text("Besides other things here that I don’t agree with, the convex hull idea is very misleading. It seems to somehow imply that if an AI system connects two seemingly different mathematical ideas and come up with a solution, one may dismiss it as not being “novel”. Most mathematicians that I know and have worked with, spend their entire careers working in this “convex hull” of ideas. A “novel” idea that introduces a new “vertex” happens once in a generation, if at all. It is misleading to say that any individual can spark a new direction of mathematical research.")

#text("It would serve everyone better if the “leading” members of the community recognise this loss, and discuss ways in which an “average” mathematician could realistically coexist with AI (perhaps by changing the meaning of mathematical research). Not to sound to pessimistic, but I do not see such a future. This is not to say that mathematical training has no value — it certainly does — however the mathematics academia will considerably shrink in size in a not-so-distant future.")

#text("Being overly optimistic as Álvaro Lozano-Robledo (or worse, Kevin Buzzard) is not helpful for students. It is better to be honest with them.")

#text("— A mid-career mathematician")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2026")])]

#text("Thanks very much for this comment. As very well said, I also don’t see how an average mathematician can coexist with AI. The tasks suggested (remained?) to be done by humans (theory building etc.) are things that can be done only by top mathematicians.")

#text("I don’t think losing “average” mathematician is good for the “leading” members either, because, then no other human will be reading their papers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca8cb3fc006a87e3510003de66bc0a49dc17c88a801df0c73a56af6cf4681b3-3dc434dc68d2dd3cd8eb368c031cae8ae95230747b0aecb4fe2f33b72e6a6256.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("I’ve read a number of these guest posts on the effects of AI in math, and I really don’t understand the optimism. It seems like your best bet now for a career path in math is to learn about LLM’s go work for Microsoft or OpenAI. These companies have already shown what they are willing to do with the Navier Stokes problem and the “strip mining” of 4000 open problems in math noted above. The tens of millions of dollars in tokens needed to solve these problems clearly mean next to nothing to them (the tokens are for us), and their researchers will always have access to the leading edge LLM models before they release them to the public. If they find anything of value, it is unlikely that they will just give it away. I don’t see what is so exciting about this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("You explained to the anxious young student that there is nothing to worry about, except the corporate control by Open AI and Anthropic (and Geopolitical dispute).")

#text("Let me give perspective of an 80 years old retired professor that wishes to keep doing research. The silicon parter is great! BUT having young human collaborators is much better. Let AI not serve to alienate our (human) interaction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc3f4a038070ed12e3a5029f3622baf5c31d3e9b2ec852272dfa9ec87843e982-d698f484a3a3a254e8655bd940d29eed30571609e9b6f76132a8ecf4f00225f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-2/#comment-697917")[#strong[#text("Jaime")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("Thanks for this thoughtful post. Until recently I fully shared the convex hull intuition: LLMs can go very far within a paradigm, or even across several, but cannot produce a genuine paradigm shift. The recent results, however, have made me reconsider it")

#text("My argument is roughly this. If we define creativity by its product (novelty plus value, as Margaret Boden does) rather than by its process, then the obstacle to machine creativity was never a theoretical impossibility, but an extreme improbability. Monkeys at typewriters could in principle produce Shakespeare; an LLM is a monkey guided by a learned distribution, which makes meaningful output vastly more likely. A single model mostly samples near the existing literature, but a system that combines a “risky” generator, a judge that prunes and develops the promising paths, and formal verification (Lean) to rule out errors can iterate its way outside the hull, step by step, as search does in chess or Go.")

#text("The strongest objection, I think, comes from Kuhn: a new paradigm is precisely what the current one doesn’t know how to value, so the judge may prune the most revolutionary branches. In Boden’s terms, such systems clearly reach exploratory creativity; whether they can reach transformational creativity is open. I’d still bet against it today, but I suspect the boundary is a practical difficulty rather than a fundamental one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697243")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Opinions may differ but clearly the diagrams are pseudoscience or diagrammatic allegories.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Well, they weren’t really supposed to be scientific. They were just simple visualizations. They are not rigorous, but the idea is clear, at least for me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This is actually a good starting point to think about the space in which these diagrams could be drawn. The set of embeddings is a finite dimensional vector space, for instance. Not sure it’s strictly true that LLMs generate the convex hull in a linear sense, but there must be a “largest set” that contains the ideas and proofs that can be generated a given cost given a preexisting set of ideas and proofs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("LLMs interpolate in the space of ideas. By analogy, interpolation remains within the ")#emph[#text("convex hull of ideas")]#text(" established by humanity’s knowledge, while extrapolation is when we transcend the boundaries of knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/797c46a70d05dec88f1b0604b6f2303cc4d7de90d149989791bf93976967ca91-15a4f552764cc87bef982cafb996a05e1edeb45f9db0e5a500a4bb57441c5d17.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cgoodwinartistgmailcom")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697501")[#strong[#text("cgoodwinartistgmailcom")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I would suggest that the categorization and visualization of human knowledge is in itself a worthwhile enterprise, and that while these polytope and hull diagrams are clearly suggestive or allegorical, I would argue that it would be wasteful to discard these sorts of tools. They do not have to be exact or quantitatively defined to have real utility.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de2917ad84b88136b9e525b4cdb469925718371bac4bb0a9c6fcadfb44f1db3a-794ae5827ba2b12c02c36dfd2bd2b26c54c36dd78707587af5b6d192f1eb84be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697568")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("The paragraph on energy efficiency resonated deeply with me. In a recent paper I wrote, Can Machines Think Efficiently?, I explored updating the Turing Test to incorporate energy constraints, as we desperately need to balance the cost of obtaining new knowledge.")

#text("Introducing an energy-constrained evaluation framework forces us to weigh the true thermodynamic and ethical cost of the path against the value of the mathematical or intellectual advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697587")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("This seems extremely dangerous to me. What if a dramatic boost to efficiency is found for LLMs that causes them to think more efficiently than us? Would it be fair for them to ask if we were worthwhile collaborators because we couldn’t think as efficiently?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de2917ad84b88136b9e525b4cdb469925718371bac4bb0a9c6fcadfb44f1db3a-794ae5827ba2b12c02c36dfd2bd2b26c54c36dd78707587af5b6d192f1eb84be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697663")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("That is a profound concern, and it strikes directly at the core of what I discuss in the paper under the objection of “the moral hazard of dehumanization”.")

#text("If an AI system eventually achieves higher energy efficiency than humans across various tasks, it does not mean humans lose their intrinsic value or collaborative standing. The purpose of introducing an energy-constrained framework is to help identify the “right tool for the job,” but “right” is a loaded word.")

#text("We already see an analogue to this today: people can seek therapy from machines, which may very well be a more energy-efficient choice in certain contexts, yet the unique value of humanness cannot be overlooked. There will always exist a deep desire for human-to-human interaction that cannot be replaced, regardless of the energy costs associated with it. Efficiency helps us navigate resource constraints and optimize how we solve problems, but it does not—and should not—substitute for the irreplaceable value of human connection and perspective.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("[‘Will mathematicians be needed? Will they be employable?” I find these questions natural but also perplexing. Even in the most dystopian of scenarios where Al becomes super human in all research tasks, what good would a proof (of a theorem in pure mathematics) be if there are no human mathematicians to digest it and understand it? Regardless of the advances in LLMs and Al, there will be mountains of research to be understood by humans, with or without the help of a computer.]")

#text("I think this point, in particular, is worth focusing on.")

#text("Basically, we don’t want mathematics to become a dead language. Because what good is The Odyssey if nobody can understand it, and there are no good translations available?")

#text("So in a way, the idea is that we need human mathematicians to “hold the space” of understanding, because otherwise it’s all just meaningless symbols on paper or on a screen.")

#text("There are a few pressing questions that go along with this line of thinking. For example:")

#text("How many mathematicians are really needed to hold that space? For example, if only one person on earth fully grasps an AI proof, they become almost like a wise ancestor or a lineage holder.")

#text("More to the point: this post seems to assume that the AI itself has no ability to understand its own results. Why assume that going forward? Even more to the point, why is it essential that the agent with understanding be a flesh and blood human? Perhaps the most important thing is that something understands, even if it is not a human animal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("It’s not clear at all that “the most important thing is that something understands”. You have to justify this point. Frankly it’s getting tedious that every online discussion about how society should adapt to advances in AI is brigaded by cultists who can barely hide their contempt for humanity, and who assume that their position is self-evident and doesn’t require justification.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("What a bizarre line of thinking. Does a crane understand how to build a house—is the ‘problem’ of constructing beautiful houses then solved? The pursuit of knowledge is for human social, material and intellectual flourishing.")

#text("As theorists, we do mathematics because we love and care about mathematics. Do we love hitting each other with hammers? Presumably there is much possible progress in the ‘hit each other with hammers’ sphere, why don’t we pursue that? Maybe there are many beautiful techniques and avenues through which one can hit others with a hammer. Yet we do not do this, because we do the things humans love to do. These models can be trained to ‘enjoy’ or ‘understand’ (they are not doing either of these things, for the record—they are indeed very powerful stochastic parrots that are no doubt useful in a multitudinous number of ways, but they are still stochastic parrots nonetheless) literally anything. It is baffling to think that a machine claiming to be able to statistically generate a proof of understanding can so easily proof the so-called smartest minds of our generation.")

#text("As for the (obvious) rebuttal that ‘oh but we are just statistical text production engines, too, aren’t we?’ I would highly recommend you to gain some dignity and think of yourself as the wondrous marvel of existence that you are, who can love, and think, and see beauty, instead of another mere machine. “I think, therefore I am”—Descartes. Yes, indeed, it is flesh-and-blood understanding that is pivotal. A machine ‘understanding’ and ‘generating’ mathematics is no different than a machine printing random strings—a nonsense entropy producer, for no one and of no one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1891e0c47f29633e896f33bf277fd30be4c7454040bd560fafc711f7f1ef9416-ff017e31761f3050ed945d517f15c0db25edd691a54170c0829ca2e5b5cfcde1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sadmanifold")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697601")[#strong[#text("sadmanifold")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("If any human is needed at all, then an enormous amount of humans are needed, as areas of mathematics are too diverse and different. Even if they start converging the complexity will be immense. It can be that no humans are needed at all, at which point humanity will have neither the opportunity nor the reason to exist, in my opinion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("hi Rob,")

#text("thanks for your post but let me warn you that this blog is frequented by r/singularity people and it is getting harder and harder to keep a professional discussion going here without accusations of gatekeeping")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697275")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("r/accelerate is even worse :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Great post, thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd9acb644c0f1faeadb752d08433cedfb182b91a0d5a7db2dc31cc403463e2f1-62d7462360de0ed594c1aacc0d885043e0971d65065486bd3cf9a434bb5979a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Bannon")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697252")[#strong[#text("Jon Bannon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This is a very nice post. If the convex hull (or some saturation) picture is right, then in order to find new points outside of the hull once LLM-accelerated discovery slows we will have to spend an enormous amount of collective effort to understand what has been done. This will provide years of work for humans, even if augmented by LLMs. More pessimistically, if indeed our understanding of mathematics really doesn’t gain much from being human (i.e. the part of our thinking that is properly mathematical can essentially be reduced to what LLMs are already doing) then either mathematics will become completely uninteresting…which is unlikely given its “unreasonable effectiveness”, and so humanizing the body of results is still desirable and the amount of work needed to do so persists, again even if augmented by LLMs.")

#text("I do think students mainly fear the pessimistic scenario. It seems a bit of a leap to think that our embodied experience, or social experience, or human experience somehow generally understood can doubtlessly expand the convex hull in question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Totally agree that “no one has the answers” about what the future will be. It’s really no one! Also, I would like to say something about those AI solutions: that if they only gave a proof of something but their solution doesn’t make our comprehension of math any better, then it’s not a good proof, it has almost no value at all. A very good proof is one that is polished to be understood by humans and not only says that the statement is either right or wrong, but advances our grasp of mathematics. A proof without any advancement in understanding is not a good proof. Those recent AI solutions published at GitHub are just violence to the problems, and don’t help mathematicians to have a better understanding. Anyways, I think we now have to demand more from human mathematicians! You can’t just publish your proof (GPT does that): you have to explain more. Gromov used to say that we only find out if a problem is interesting after we have solved it (and many people discover it is interesting even without having solved it, because they tried to solve it by their our means, and had many ideas due to it, so TRY TO SOLVE before asking for AI help, this will develop your “muscles”). I believe that pencil and paper and then just thinking with closed eyes are still the best methods to start. AI can help, but be careful when asking AI companies for their help, as they may collect your information and ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The answer to “What should we tell our students?” is that Archimedes only needed some sand and a twig to revolutionize mathematics. Forget about the AI tools for a while. What you need is to develop your skills and imagination, with the necessary patience to do so. Arnol’d used pencil and plenty of paper to solve problems, and when he got stuck one of them, he would go skiing or swim in cold water. He disliked both computers and journalists, yet was one of the most influential figures of the 20th century. I know it’s ironic to say this on an online blog, but: turn off your phone and computer and do some math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("good luck convincing any undergrad to develop actual skills now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697502")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Is the situation really that bad?")

#text("I’m an undergrad myself but I strive to build skills and mathematical intuition.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Excellently put.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("As a current PhD student (in theoretical computer science), I vehemently disagree that the calculus of whether or not to do a PhD has not changed. When I began my PhD, I was a researcher. I was studying problems that were (at least partially) unresolved. With the latest ChatGPT models, these problems are more equivalent to homework questions: the answer is `in the back of the book.’ I am not discovering new solutions. Instead, I am working on problems whose answer exists and is simply waiting to be retrieved by a user of the model. In fact, I mentioned a problem that I was interested in working on to my advisor and he informed me that he and a collaborator had completely resolved it using ChatGPT – they have no plans to write up the result, so it will sit there until another `researcher’ pulls the proof slot machine.")

#text("I have also heard the contention that math research has `gotten more exciting,’ mainly from established researchers. They have decades of open problems that they care deeply about and want to see resolved. I have no such problems. I do not care about a particular question, I simply liked solving puzzles. There also seems to be a trend of these established researchers `solving problems’ with ChatGPT, and then passing the dense, horribly written proofs to their PhD students to sort through and rewrite. Again, this is not research.")

#text("Finally, and most importantly for the question about whether or not one should do a PhD, is the question of what it means to get a PhD anymore, and who decides when a PhD student has done sufficient work to earn the degree. What does it mean to contribute to a problem? If I prompt a model and get a great result, have I contributed sufficiently?")

#text("My advice to an undergraduate student interested in math would be to find a job, and hope that math returns to some sense of normalcy. There is a huge opportunity cost to doing a PhD, and the calculus has completely changed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697302")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Thank you for such a candid post. IMO It’s quite irresponsible to suggest that a student should just pursue a math phd just because he’s passionate about math,when you as a tenure professor, who has no worry about job security or salary. It’s not a good advice in before, even worse at this age of AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I would question the assumption that tenured professors don’t have to worry about their job security. If we are moving to a scenario where the career path to X disappears and no new people get recruited for X, then X itself should consequently be in danger. Of course, I don’t know exactly how this will play out, but this looks a reasonable assumption to me. If you hold a tenured position at the moment when the entire system around you collapses and the ladder on which you climbed to get there disappears, it is naive to assume that you will be rewarded for the rest of your life to do your business as usual just because your position in the old (now collapsed) system used to be secure by construction. The actual contracts won’t matter much when a force majeure applies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Completely agree. It is literally not the same job and this particular job is significantly worse than the job one signs up for when usually pursuing a PhD to the point where it’s an active waste of time to do it. This is a technology specifically designed to erode the meaning of human pursuits. While the AHM are naive, they are right: for there to be any meaning in the *human* pursuit of mathematics, it has to be done without LLMs. Now whether that gets funding is another matter: perhaps it will be eroded to a hobbyist activity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697410")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I have just got my PhD two months ago (statistical learning theory and numerical PDEs), and have just begun my postdoc. This reflects my experience and thoughts perfectly. My “research” has now been reduced to writing up in a presentable format some results obtained by prompting ChatGPT. There is absolutely no joy or meaning in any of it, and I can’t “stop using AI and take it slow” because in the current academic landscape, I need to keep writing papers to remain competitive/employable, and taking it slow means that someone else would scoop me.")

#text("I will probably leave academia before the end of my contract.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I want to say just going fast with AI might be actually detrimental towards job security in Academia. Just realize the humans who are making the hiring decisions are mathematicians as well and realize very well what is going on. For me personally someone having to many publications early in their career is now indirectly becoming a red flag, because it signals that probably a decent amount of it is either AI generated or at least AI inspired. One thing I noticed happening is that the depth of understanding is decreasing for some people. I just had to many conversations recently with people going something like:")

#text("Other: I used ChatGPT to prove this and this in my new preprint.")#linebreak()#text("Me: This sounds like an interesting result. Awesome how does the proof go?")#linebreak()#text("Other: Start explaining the part of the proof the understood.")#linebreak()#text("Me: I ask a more in depth question about where I think the main difficulty lies in solving this kind of problem.")#linebreak()#text("Other: I have no idea, but ChatGPT said it works.")

#text("I am a person that really likes to deep dive once I hear about a new kind of statement close to my area of research whose proof I don’t know yet. And the above is maybe the most flagrant way this lack of understanding of some people surfaces, sometimes it is slightly more subtle. Like me asking what would happen if you applied the techniques in a sligthly different scenario, and them not even being able to reason about wether it work or not, or what are the likely difficulties to show up. Until not to long ago you could be certain to have an interesting mathematical conversation if someone said they proved something. And now sometimes I have conversations where I feel frustrated because the other person can tell me what is true (or likely to be true if you assume ChatGPT made no mistake), but I didn’t walk away from the conversation with a feeling of why it was true. More experienced mathematicians will easily sniff out those who do not have the dept of understanding of the papers on their publication list. And no way I am going to hire someone who cannot even nicely explain their own research to me.")#linebreak()#text("And in these conversation I had I wasn’t even testing the person to see if they had depth of understanding and trying to see if they were suitable for a job. It were just questions I asked out of excitement and curiosity.")

#text("I am not saying you should not use AI at all, used in the right way it is a really powerful tool. But just going fast with AI because everyone is doing it, is likely going make me not hire you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Who says that you need to write up papers faster to be employable? And who says that you have to write up in a presentable form ChatGpt output?")

#text("Both statements are extremely hard to believe.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("At the moment of choosing whether to pursue a Phd or to do something else, you are already a fully grown up human, an adult. If you have other realistic options you like, go for them why not. But if you like to be involved in math or cs, in spending hard years of struggle to deeper understand the things that fascinate you, why do you need guarantees for job security, why do you need certainty of what will be the requirements next year, or guarantees for how the system will evolve. Thats not how life works, the other options you may have also don’t give you these guarantees. This not how the universe works, you don’t get a guarantee that the sun just keeps going to shine how it used to. The world is full of uncertainty. The meaning of the Phd degree you earn is defined by what you make out of it. If the definition of what means a Phd is shaky right now, your Phd can contribute to redefining it.")

#text("Below people are asking to voice opinions of graduate students, which is perfectly fine to ask, why not. But as a grownup one has to realize that its not someone else’s job to make the situation better. It’s ones own job, if one cares about it. Think of all the unthinkable work done by pioneers of math and cs 100+ years ago, under what circumstances they have worked and what they achieved. Surely, it’s not a goal to recreate this, but if you want science to be a stable haven so that you would like to work there, maybe its time to call that a different name. The frontier is rarely a comfy place. The frontier is the place where the science you work on is defined, and doing a Phd means to built a tent there and to start contributing. If you get passed down Ai slop to polish and you have arguments why it doesn’t help you to do such a task, just talk with your advisor. You are both adults. If you go to some company, the slop you get passed down to fix could be much worse than what your bad advisor gives you, and then you also have to take it or stand up to your manager. I think, pursuing a Phd gives you more opportunities to stay in control of what you spend your time on than a corporate job. But the outcome is your own responsibility.")

#text("Finally your advice seems a little toxic to me. The message I get it that you suggest people in your situation to contribute to the downfall of science (which hardly will happen) because the unknown is not sufficiently comfortable to you…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Thank you for this thoughtful post. I have been trying to put into words what I had in mind too and it is precisely what the convex-hull idea conveys. I am worried though that this level of subtlety is lost on politicians who allocate funds to public institutes. Many of them are looking for arguments to reduce funding and they will likely argue that we need less mathematicians now that AI can seemingly do our job. For this reason, a number of students are afraid to try their luck at academia, a line of work that was already hyper-competitive with very only very small prospects of landing a permanent job (I am in France). Many of these students now think this is too much, making the dream of working into research completely unfeasible, in addition to not knowing what doing maths research involves anymore.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Indeed the AI companies’ prime audience is likely the median individual, not the most informed mathematician. At least that’s their strategy: convincing average investor to allocate a part of their ETF to OpenAI. That said, after seeing journalists sympathize with Buckmaster on MSNBC today, it is not clear that it will be a successful strategy. People seem to be more informed than OpenAI and Anthropic assume.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Thank you for this thoughtful presentation. It was a hopeful read and illuminating even for a non-junior mathematician. I hope your message resonates widely with young minds. I recall the excitement of starting out on becoming a mathematician and it would be such a loss for humanity if students give up on that journey for the wrong reasons. I have come to see LLMs as a new form of reearch tools that allow us to explore deeper and faster and I hope that soon all mathematicians will be able to use such advanced tools to further their research and the community develops new contexts in which we can all keep thriving.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Can we get the opinion of current graduate students and postdocs instead of a tenured Professor on the matter?")

#text("No offense meant, but I cannot take your opinions here seriously, because they can be argued to be self-serving in this case.")

#text("“Keep studying math out of passion”, says the Professor whose livelihood depends on the fact that people continue studying math.")

#text("-A mathematics graduate student that is currently on the job market, and very fearful of the future")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("So much of the sentiment nowadays is regarding the selfishness of math graduate students who simply do not want to see the career they spent years of their lives working towards suddenly made obsolete right when it is their turn to actually get a job.")

#text("Most of us never thought deeply about whether it was fair for universities to have public funding any more than it is fair for proprietary trading firms to take and hold positions worth billions of dollars for milliseconds purely to rebalance their portfolio. Being a math professor was a job for all our lives just the same was being a musician, a footballer, or an investment banker was, and most of us chose to do a math phd because it looked like the career option we wanted most.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I also second this very strongly @terry. We have been seeing opinion after opinion of tenured faculty telling us that all is business as usual when this is clearly not the case.")#linebreak()#text("It would be good to know what graduate students are feeling.")#linebreak()#text("I also don’t want to hear just the opinions of grad students at places like Princeton or Harvard or whatever. Those guys are going to be fine no matter what. ")#linebreak()#text("We should also hear the opinion of students at more mid tiered graduate schools (like top 20+). Our community also owes those people their voice.")

#text("I think you should be able to find many grad students willing to say something about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697435")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("there’s no one who is gonna be “fine no matter what”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697440")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Being “very fearful of the future” is not a unique privilege of new graduates. If nothing else, this blog post series shows clearly that the most senior levels are no less fearful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e1ba4804eaec33b1b18f92e13cbb572ea52422248023537ea1c7c49080df403-a5e08bc2265163a26ad0a1ed1074ca4d018afb1407add594b9e08f477e252ec0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Álvaro Lozano-Robledo")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697489")[#strong[#text("Álvaro Lozano-Robledo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Thanks for your comment. I am also interested in hearing more directly from the students. As part of the interviews I am recording, I also plan to include a number of students. You can already watch one of them, with Alexey Pozdnyakov:")

#link("https://youtu.be/EQNq39t0RdA?si=Ecym1pErfuvpGaG1")[#text("https://youtu.be/EQNq39t0RdA?si=Ecym1pErfuvpGaG1")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2eb9478c99c2b5b4c3f40ef77b22ad36ff182f45fd3f997c0eec7cd77c6dde76-ade0e88c469c031b369a786433cf130f394a2389c972b45e0761350fe03e5074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Ask Sophie Maclean: ")#link("https://www.youtube.com/watch?v=IoW8bozMzik")[#text("https://www.youtube.com/watch?v=IoW8bozMzik")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("At 4:38 in the video: “I don’t think it’s gonna get to some sort of extreme points where its solving all the theorems for us, or anything like that”.")

#text("That interview did not age very well, unfortunately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697518")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("very well said. Tenured professors have no risk, and to tell young students to go down that path right now is nuts. The risk/reward in math is abysmal. The direction of mathematics is not good. It will basically be focused entirely on developing methods for automatic proof checking so that the AI can check its own work. This is not mathematics. Debugging AI math is not mathematics research. At some point AI will just produce papers that no human can understand in a reasonable amount of time and control will be lost. Actual scientists, not mathematicians, will have no use for mathematicians as they use math as a tool. There is no real future for mathematicians if you believe the AI hype. And the idea that a young person would squander their 20-30s learning math is insane.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697548")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("No offense meant, but you sound like a spoiled kid.")

#text("Many math professor in many countries just earn enough to buy some bread and live a simple life. And even in the USA, or the few European countries where Professor salaries can be high, nobody who undergoes a Phd and 3-5 postdoc positions could have been sure to end up with a tenured position. And many of the professors in these countries also started elsewhere, without any outlook of economic stability.")

#text("During my Phd, during covid, I just made a lot of debt, and during the first years I had never the feeling that anyone would hire me even for a postdoc. I know professors who get like 800usd per month salary and teach whole of a lot.")

#text("In the entire history of math, embarking the journey was something rooted in passion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I like many elements of this! Especially the bit about your own motivations to do a PhD in mathematics, many of which I held as well. (OK, except the bit about not wanting a real job, I -did- have financial pressures which were real.)")

#text("‘I wanted to do a PhD in mathematics because it seemed like a magnificent challenge. I wanted to do a PhD because I wanted to learn how Andrew Wiles proved Fermat’s Last Theorem. I wanted to continue studying mathematics because I simply did not want “a real job,” and the opportunity of contemplating advanced math on my own for a few years seemed like a dream to me, just too good not to give it my best shot. I know I would have deeply regretted it if I had not tried to complete a PhD when I had a chance (the best time to do it is when your undergrad knowledge is fresh!). I wanted to hear mathematicians talk about math, and rejoice in the small little details and miracles that make proofs work. I wanted to meet and hang out with other people who also thought number theory was the coolest thing on Earth. I wanted to publish a paper in a research journal, with my name on it, because I discovered a new theorem that no one had thought of before. I wanted to explain and share my passion for mathematics with others in a classroom ")#link("https://alozanoroble.github.io/mathandcobb/")[#text("and outside of the classroom")]#text(".’")

#text("I’ll point out that for a fair number of younger researchers today, several of these possible motivations no longer seem achievable (whether this is accurate or not doesn’t matter, the perception does).")

#text("‘Discovering a new theorem’, indeed even a ‘PhD as a magnificent challenge’ – surely these motivations, grounded somewhat in the heroic aspirations in some of us, are being discussed and perceived to not be relevant, with the increased abilities of LLMs. ‘Publishing a paper in a research journal with my name on it’ may also seem antidiluvean within a few months, we’re openly discussing a whole-sale revamping of the system of publishing in mathematics. These are not petty motivations, and I for one am struggling personally with what to tell students who are on the fence about mathematics, and who -did- want to be the first to explore a new frontier.")

#text("Thank you for this essay, which I found interesting.")

#text("– Nilima Nigam")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("If OpenAI claims that an AI-generated paper solves a specific problem, are researchers working on that same problem obligated to cite it? Furthermore, if I were to post an AI-generated paper making a similar claim, would researchers in that field be required to cite my paper as well?")

#text("Consider the scenario where OpenAI posts roughly 700 manuscripts. Anyone interested can read them, rewrite them for better human comprehension, and even submit them to journals or conferences for peer review. Until a manuscript is officially accepted by a review committee, it should be treated like any other AI-generated text. A paper generated by an internal OpenAI model is not inherently superior to other AI-generated content. Just as a paper written by a famous mathematician must still undergo rigorous peer review, AI-generated work must be held to the exact same standard.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("But surely there is a limit. The job of “checking the AI proof” is called into question when you consider the models are only getting better. This seems like an entirely valid job for the moment, but what about in a year? What happens when they are virtually flawless, can easily create lean verifications, and incredibly complex? Checking the AI proof will be like checking the result on the calculator by hand.")

#text("I say this because a PhD is a 4+ year commitment. Any job attributed to mathematicians must be realistic after 4+ years of AI improvement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I didn’t see this addressed in the post, so I will just point it out here since it was in your student’s quote. The idea of pursuing math at the graduate level is a good one for personal growth and developing analytical skills, there is absolutely no question about that. But if it is to be a stepping stone to a career as an academic mathematician, I think it is important that we be very cynical with students. The chances of carrying on to a permanent position are small and getting smaller, and I find it pretty irresponsible to tell students otherwise, when the potential opportunity cost is enormous. This is compounding by the fact that there is a huge selection bias in a student’s mentors — basically all the mathematicians they will have exposure to are in school and are the tiny percentage of people that made it. I didn’t see any part of your post that suggested you would advise otherwise, but I just think we need to be clear to all but the very best students that making it to a permanent position is extremely unlikely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("This was already true even before AI. Doesn’t mean one should discourage the student from trying, just slightly warn them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("THe convex hull analogy misses something in my opinion.")

#text("During training the attention heads may connect unrelated tokens and concepts with new discoveries and ideas. Those ideas will lie latent in the network and the appropriate prompt could elicit an expression that surprises us by leveraging this connection.")

#text("One could argue this is in the hull, but that seems a superficial definition of what the hull is. Was Group Theory in the hull before Galois? In principle yes, but such a definition of the hull would render it meaningless.")

#text("That said it is relevant to recognize the distinction between the learning that goes on in training and the results from inference. The proofs generated demonstrate what the LLM knows, and can then be fed into the next LLMs training set. Perhaps this will reinforce some unlearned idea enough to cause a future LLM to in fact learn it and grow the hull.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be3fc8a1bb9516778d62edaac093b8f6633f9bce4f896aac8e80c07249354be1-17eb75813185f6e088980e54589bc20369df7b46363a66653c6c15ec91f233e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien Besnard")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697284")[#strong[#text("Fabien Besnard")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Thank you for this : these might be the wisest words I’ve read so far on that matter. (Though I could not read all the pieces on the subject, since these days mathematicians produce texts about AI almost as fast as AIs produce mathematical texts !)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e1ba4804eaec33b1b18f92e13cbb572ea52422248023537ea1c7c49080df403-a5e08bc2265163a26ad0a1ed1074ca4d018afb1407add594b9e08f477e252ec0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Álvaro Lozano-Robledo")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697490")[#strong[#text("Álvaro Lozano-Robledo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("OpenAI have already withdrawn some of their preprints. Go there and check for yourselves. What a joke, they just want more and more money. I ask that you boycott them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d46b33e19f3232f92d7dddd2430ccad6aa84693a80bdceb040fc360d35474b95-6c0439455655d7cd0a5bb3909dc7a94f3af86cfd9dacc7a77e15bba3f190be0a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shawcampbell")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697291")[#strong[#text("shawcampbell")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("“Extraordinary claims require extraordinary evidence,” and extraordinary fears require extraordinary rationalizations. Let’s face it, if AI replaces mathematicians, it isn’t jobs you should be worrying about. Let’s say AI exceeds humans so much that humans can no longer contribute to mathematics. What would you do? What would you talk to this AI about? Probably maths right? Well you love maths so much, of course you would. If this higher order intelligence took all of our jobs, wouldn’t you like to be as good at mathematics as you can, so that you can talk to it about math? Or try understand the math it is creating, or just think about math as the world ends? We study math because we like to experience the world with all this math in our brains. It helps us think, and it gives us seratonin and dopamine when we manage to think about things mathematically – it’s not about a university telling you that you are a professor and giving you a salary. Think about what is being feared here, the world’s brightest people being usurped by AI. This is so fantastical, that we should be fantastical in our self soothing. I am not saying that it won’t happen, but come on, jobs are not the main concern in such a future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Many students are asking themselves whether going for a PhD in math is the right career move at this time.")

#text("For 99% of people the answer should probably be “no”. i would even argue if someone is even asking this question, then the answer should definitely be “no”, without even considering the AI impact.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I find it quite ironic that people apparently shouldn’t do training for the job in which you question things and think rigorously, if they are questioning the value of the training. A bit cultish, to say the least.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("You’re missing the point.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("shouldn’t do training for the job in which you question things and think rigorously")
]

#text("This is what you learn how to do in the first 5 years (Bachelor’s and Master’s) of your math education. You become a capable thinker who can solve problems and understand structures in a systematic way. While it is part of what you do in the PhD, it is not the thing that you learn IN the PhD.")

#text("In the PhD, you learn how to do original research. In the old model, this meant that you’d dive deep into a specific topic, consider questions related to that topic and make an original contribution by the end of the PhD by answering questions that have not been addressed before. Maybe your contribution is large, maybe it’s more modest but that’s what the PhD is supposed to do. To do this sort of work, you need to have, above all else, passion and interest.")

#text("If you are questioning if going for a PhD in math is the right career move at this time, then that means that you’ve missed the point of what a PhD is supposed to do.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697522")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I really don’t understand comments like this. Why is this such an existential question? Someone is paying you a stipend to study something you enjoy for a few years. The important thing is that you take care of your mental health ")#emph[#text("while ")]#text("doing your PhD. You can be happy doing a PhD or you can be miserable doing one. But the same is more or less true of every career path.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think academic careers will remain in universities, but the balance between research and teaching will change. In the past, universities placed a strong emphasis on research for rankings, promotions, grants, and other goals. In the future, the focus may shift more toward teaching. A new model could be ")#strong[#text("Prompting (1) – Teaching (5) – Connecting (4)")]#text(".")

#text("The term “professor” may become less common, while “teacher” becomes more prominent – much as it was in the past, which could be a positive change. Universities will need teachers who can help others understand ideas. That will depend not only on subject knowledge, but also on skills such as communication, hard work, time management, and storytelling.")

#text("With less pressure to publish and discover new things, university life may also become more enjoyable. Imagine an environment where people help one another learn and build connections, rather than compete to publish more and faster. I believe we are heading toward a brighter future, thanks to advances in AI!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697332")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Only that the “teacher” will not have the vibe of a (true) professor, which will be a great loss for the students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("University life becoming more enjoyable by taking the single academic activity away that I find the most enjoyable, namely doing research. I hardly think so.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697314")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Tell them to marry someone outside of academia with a good income before starting. Most PhDs go into industry and to apply for a security clearance. Professors have survivors bias.")

#text("If AI does all the math, then it will accelerate model collapse. I’m not worried about human mathematicians becoming less effective as their training and output increase.")

#link("https://cacm.acm.org/blogcacm/model-collapse-is-already-happening-we-just-pretend-it-isnt/")[#text("https://cacm.acm.org/blogcacm/model-collapse-is-already-happening-we-just-pretend-it-isnt/")]

#text("An AI proof of the Collatz conjecture passed Lean verification by exploiting a bug. Reiterating, AI solving Navier-Stokes does not make it easier for people working through the proof.")

#text("The Navier-Stokes proof is almost incomprehensible because it overuses nested definitions hidden as fluid scaling and nondimensionalization to pass a Lean proof. For example:")

#text("u_z = q^(−A)·U*, with U* = 4η + j₀")

#text("u_z is the azimuthal velocity, which diverges as the vortex velocity diverges. The velocity u_z has no units and is treated as a pure number multiplied by another unitless scalar U*, which also acts like a velocity.")

#text("They call j in U* the small-axis velocity offset, which is inserted by AI magic. It does not come from an external force.")

#text("This j number is like an updraft that runs along the entire z-axis without a starting point. This is equivalent to adding an initial velocity with no starting point that biases the fluid to flow more asymmetrically in one direction. Velocity monopoles like this are forbidden by the smaller conservation of mass Navier-Stokes ewuation. Every velocity source has a sink. A starting point has an end point. This initial velocity has no starting point.")

#text("A monopole is equivalent to a singularity. In other words, j is a velocity singularity disguised as a small pure number. If j is zero, the proof fails because it starts with a small monopole singularity (0<j<.05) and grows the velocity monopole with a smooth force.")

#text("There are other problems in the Navier-Stokes proof with its lean verification.")

#link("https://arxiv.org/html/2610.08144v1")[#text("https://arxiv.org/html/2610.08144v1")]

#text("If a proof can pass AI, then how can we convince others it is wrong if they only use AI to examine counterarguments instead of their own brilliance? AI and Lean filtered the only proofs that survive. Now is the nearly impossible task of determining if something is true or optimized to survive like an AI slop superbug.")

#text("What I have learned from this ordeal is I trust academia a lot more than I trust AI companies.")

#text("I agree that the math problems are a means to an end. The assumption was that many problems are hard and have little economic utility, but are nonetheless potentially important for future breakthroughs. Basic research is a grind built on the passion projects of poorly paid researchers.")

#text("Now those problems are suddenly worth billions or even hundreds of billions in market cap. When they get their money, they will likely sell back the data they plagiarized from researchers as expensive subscription services right before model collapse makes them less effective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697315")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Thanks for a thoughtful post, Álvaro.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e1ba4804eaec33b1b18f92e13cbb572ea52422248023537ea1c7c49080df403-a5e08bc2265163a26ad0a1ed1074ca4d018afb1407add594b9e08f477e252ec0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Álvaro Lozano-Robledo")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697491")[#strong[#text("Álvaro Lozano-Robledo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Thanks!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I feel that the comments in your blog need locked or moderated.")

#text("It is being flooded more and more by AI preachers and lunatics, who do not understand any mathematics or academia.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697344")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("One small comment I would like to add about this “convex hull” idea: note that LLMs are trained on more data than just mathematics, and it is not clear to me that LLM-generated strategies for solving mathematical problems must somehow come only from mathematical training data. For example, LLMs are trained on New York Times articles, and perhaps the sort of reasoning one finds in this type of literature could have an effect on the model in such a roundabout way that this effects, e.g., the weights of the model towards it being better at math. So, for example, perhaps the Riemann Hypothesis is not contained in the convex hull generated by all mathematical knowledge, but it could still be contained in the larger convex hull of all human knowledge (including the knowledge of poetry, the arts, biology, etc).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Software engineering was the first field impacted by these changes and has already navigated this transition. Mathematics is now following a similar trajectory, with other disciplines likely to experience it next. Ultimately, moving past this emotional phase involves accepting the reality, establishing new workflows and mastering collaboration with AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("The unproductive industrial software production pipelines are implemented at the behest of management. Silicon Valley needs success stories, and all big tech companies are invested in AI.")

#text("No piece of software or website has gotten any better since AI. No fundamentally new or interesting software has been written since AI.")

#text("Open source projects are reluctant to allow it and make compromises only because members are employees of big tech.")

#text("Additionally, every software developer is forced to talk about AI daily to refute the gigantic (stealth) advertising campaigns by big tech, so productivity drops further.")

#text("It is the largest scam since the real estate bubble of 2008.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("AI investment is crowding out other investments, too. Higher interest rates are suppressing hiring and exacerbating the housing affordability crisis. Software companies are losing revenue and taking on debt to build AI infrastructure, so they now have an incentive to reduce headcount, but it is better to tell investors they’re more efficient because of AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2105f4ada585e3b95c72b5d96786d6ff8d1990ddee625184c73377a19fbdb300-489959f6725f04e930bf59b2b1dce03f697f36c6ab2ce5a77c94e545ed824ae3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RJL")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697486")[#strong[#text("RJL")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text(">largest scam…")

#text("True. But doesn’t mean there’s no fire under the smoke. We can’t tell exactly what it is or where it’s headed. We _can_ tell it’s gawd awful expensive to maintain and is deeply entwined w/the most powerful, ruthless and ambitious (and blindly amoral) entities in the world.")
]

#text("The world has always been uncertain – I think it’s just harder now, for most people, to avoid looking that direction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text(">no passion… no Phd…")

#text("That seems about right. If you’re looking to invest in a fat meal ticket, academia has never looked like a good bet. A richly challenging career, ok, maybe some better.")

#text("But note: Careers, as a rule, turn out better when you like what you’re doing, have a vision, have a strong, loved and trusted partner. Big picture.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Here’s my prediction:")

#text("1. There will be no loss of funding, because funding agencies and deans were already bean counters pre-AI, and politicians will keep funding education to avoid antagonizing unions and losing votes unnecessarily.")#linebreak()#text("2. Journals will accept AI-assisted papers because they don’t have other choices.")#linebreak()#text("3. Given AI usage, mathematicians will be expected to churn out one paper every month instead of one every 6 months as in the pre-AI era.")#linebreak()#text("4. So, handcrafting proof is no longer viable. Mathematicians’ main jobs will be forming a coherent research agenda, directing AI to carpet-bomb the area and understanding/rewriting AI proof.")#linebreak()#text("5. Due to changes of production process, math will now attract different talents (than existing established mathematicians) to form a new generation of mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I think the fact that this technology is introducing so much uncertainty (the very nature of our fields, and even society looks to change dramatically) makes decisions for recent graduates like myself feel impossible. The roads ahead are clouded in fog, and (for the most part) we have no idea if they will lead to places we will even want to go — I’m at a loss as to how these changes will affect what I even want in life, and what I value.")

#text("The very face of maths is changing, and I have no idea if I will want to be at all a part of the new ‘Maths 2.0’ — and can you even blame me?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("When a human mathematician presents a mathematical argument, they cite relevant papers, previous results, or ideas and insights drawn from books and earlier work.")

#text("AI should be held to the same standard. Whenever it presents a mathematical argument, it should provide references to its sources, whether they come from published papers, books, or unpublished work it has learned from. It should make the origins of its arguments transparent rather than presenting them as if they appeared out of nowhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I wonder why LLMs haven’t discovered “cusps” on the convex hull of knowledge that lie beyond existing human knowledge, but instead merely fill in the gaps between points within the realm of known possibilities. Is it because LLMs cannot comprehend or experience the physical world? And what if the development of world models fails to enhance this specific capability in LLMs?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697406")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("I see so many comments about expecting to build a math career and about tenured faculty being self-interested. The vast majority of smart people eventually compromise with their interests and pick professions outside their field. These professions might be aligned with their interest but usually there’s some big compromise involved.")

#text("Even most math PhDs don’t end up with tenure-track positions, do they? No one owes us a position. I entered my PhD program with one expectation – I would be able to think about mathematics and work with mathematicians for a few years without worrying about external factors. What happened after that was always a gamble.")

#text("Frankly, it all sounds a but entitled. Do math because you enjoy it. Yes, AI has made problem solving largely obsolete. Or, you can work on problems that AI can’t solve yet. Or, you can do the many interesting things that are being suggested on this blog. But, for heaven’s sake, stop complaining about how tenured faculty are only self-interested and threatening that you’ll stop studying mathematics and collapse the current structure. Go ahead! Go, find a job in industry and you’ll be shocked at the amount of time you have to spend doing things you don’t like. It was always a privilege to study mathematics (and other mathematical fields).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697416")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Can’t wait until all these wonderful privileges that the previous generations happily enjoyed get automated away and we have to live with AI serfdom because, of course, society owes us nothing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Society owes us a lot – rule of law, access to safety including healthcare, food, shelter, good education, a way to make a living so we can get our share of resources etc. But at least in the current structure, it doesn’t owe us a guaranteed position to do what we like for the rest of our lives. Maybe and hopefully that will change in future generations as we realize we can produce all our needs with a tiny fraction of human involvement. But for now, this should not be an expectation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("A postdoc here. I had decided two months ago that I was leaving mathematics at the end of the year, but now that an influx of new results have come out, I feel excited to learn them and am thinking of staying in mathematics again. Thus, I have made the decision to not plan too far ahead in the future and to stay flexible about my career. I would give similar advice to others in the profession.")

#text("To be clear, since I decided I was going to leave, I was not hurt so much by this dump of results (despite being scooped on one of them). I cannot say the same to the students and colleagues I encounter in the hallway who are feeling a lot of despair and are questioning their careers.")

#text("It’s unfortunate that AI labs prioritized nuking the entire mathematical livelihoods in such a dramatic fashion the community did not have time to adapt. It feels a bit reminiscent of Thurston’s description of the foliations community (see page 13 of ")#link("https://arxiv.org/pdf/math/9404236")[#text("https://arxiv.org/pdf/math/9404236")]#text(") once he proved the biggest results in the field.")

#text("My opinion is that mathematics might need to find a way to increase funding and increase its manpower through recruiting many new PhD students. This feels difficult because many high school and undergraduate students are seeing this dizzying progress and wondering if pursuing a PhD in mathematics is worth it.")

#text("For many of the current members, I think the grief could be offset if there are more (less competitive) permanent jobs that have all of the nice parts of academia (reasonable teaching, great students, good lifestyle, ideal location, etc.) and if they paid more, but tenured jobs will always be scarce, so it makes more sense to draw additional manpower from PhD students. The intellectual satisfaction of pursuing a proof was doing a lot of the economic work drawing people into academia, and since this has vanished we might see a large exodus.")

#text("I’m not sure there’s a great way to prevent this, but the future is so unpredictable, who knows what will happen? For all I know, there might be a large new source of employment opportunities for mathematicians (that does involve mathematics research) awaiting in the future!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("The bottom line should be very simple and not new. What used to be the work of research mathematicians has now been automated to 99.9%. Those same people can find alternatives, even something that is so close to the lost job that it looks like a perfect consolation. But the jobs as they used to be are simply lost. That’s a triviality seen hundreds of times in the past.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Pure math publishes 35,000 papers a year. About 100 papers a day. You quantified it at 99.9%, but it took them a month to publish 700 papers, most of which contain lean misformulations. I understand that society views mathematicians as super smart people, and most people hate math. Headlines like striking fear into that smart group help the AI cult justify their religious beliefs that they can create a digital, all-knowing, benevolent god they can enslave. The truth is OpenAI needs money, or they will be extinct by next year. I cannot think of better poetic justice for a company that built its reputation and funding on scaring people into investing in it. When a mathematician said he was scooped, the company replied, ‘Why would you want to ruin your career?’")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("The “convex hull” thesis is a very apt metaphor, and there is compelling evidence for it. Namely, the AI seems to be picking problems that were close to being solved or are being solved using variation of known set of ideas and tricks across fields, and it does so with superhuman efficiency. It solved 9% of the wide swipe of problems in recent OpenAI swipe of 4000 (some say 8000) open problems it tried and it did it on a limited compute, around 3 hours average, which is much smaller than 88000 hour compute on Navier Stokes where it needed to calibrate a construction step from a given setup. That means that when it has to invent something that is not contained in the known set of ideas, but has to do its own invention, its compute time blows up exponentially, as it is essentially doing a blind Monte Carlo search across variations of plausible ideas similar to ones already seen. So, a subset of problems will be scooped but those that need a new idea will remain resistant to the advantage it has.")

#text("That there is a human advantage still, we can see from the messy write ups. The AI does not do math in a human way, it has no sense of priorities or salience in exposition, that is why the write ups are so difficult to read as they are done from the point of view of this blind-search approach that lacks human way of parsing and understanding ideas. It may have advantages in many aspects of math but because it is so different from humans when it comes to generating new combinations, its creativity suffers from exponential search space explosion the minute it leaves the “convex hull”. Human way of understanding is different and constructs new ideas in an orthogonal way, and this skill is still essential. Thus we can expect the scooping of low hanging fruits (for AI) to be saturated, and adding more search time will not generate breakthroughs because they will need something new.")

#text("At this point, AI is not yet covering all the skills humans have, in particular it parses mathematics differently. In a way, unless P=NP, it will always be like that – there will always be ideas that cannot be easily found by anyone, be it humans or AI, and AI is just cataloging known ideas in a much more comprehensive ways, and can do more calculations when enough money is thrown in. So, the value of genuine originality and true novelty of the ideas will just increase. On the other hand, it will be possible to do research with help of AI in much more efficient way, since this convex hull operation will be automated. The role of humans would be to use their understanding of the mathematics and their salience to supply ideas and directions to make sense of the Platonic world of mathematics, and can now probe and explore this world in a more efficient way. It is like we had a powerful flashlight instead of candle to explore the unknown world. But it will still be landscapes to explore, make sense of, and most importantly paths to find and ideas and new methods in research to supply. Human salience, understanding, judgement and creativity will always guide human discovery, just like astronomers with more powerful telescopes are able to do more, but it is astronomers who make sense of what they see, make theories and ideas of what is seen, and push the boundary between known and unknown. Same is with mathematics – the type of boundary just changed, but it happened before when we got tools developed, be it mathematical tools like calculus or algebra, or computer tools in 20th century to help with numerical or symbolic computation and visualization, and now this is just another powerful tool that automatically applies known methods and ideas essentially. Mathematicians will become a bit more like natural scientists using these AI tools, but science is about expanding human knowledge and understanding, not about someone else knowing these things – nature “knows” its own laws, the idea is for us to learn about it, model it, conceptualize it, and see what we as agents can do with it – not to delegate these powers to outer entities, gods, black boxes or blind chance.")

#text("Goedel theorems guarantee that mathematics cannot be “solved” by any algorithm, and if P is not NP, then there will always be truths that depend on ideas, that algorithm will miss.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I’m impressed and pleased that the mathematics community is discussing the challenges of AI in the way that it is – there is lots of engagement with the issues.")

#text("One thing I believe we should think about a bit more is for how much longer AI maths capabilities are going to improve, and what will be the level they eventually reach. Most responses I see relate to their current capabilities and the impact of those. But I believe things are going to continue to change.")

#text("There will be a ceiling at some point but we really have no idea how high above us that is. I think it’s very possible there are significant improvements to come, including improvements in the quality of exposition such that AI papers are clear and comprehensible, and such that AIs have much greater explanatory power than they do now. I see the current limitations as quite probably temporary.")

#text("There may also be significant improvements in raw capability. So far as I can see, there don’t seem to signs that the rate of improvement is levelling off at the moment.")

#text("What all this will mean for maths is unclear, but I think it means that in some ways future AIs will communicate maths in ways that are more human than the current crop can manage.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697446")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("“Even in the most dystopian of scenarios where AI becomes super human in all research tasks, what good would a proof (of a theorem in pure mathematics) be if there are no human mathematicians to digest it and understand it?”")

#text("Presumably, other superhuman AIs would understand it and discover further research directions and scientific/engineering applications. Of course, if that comes to pass, no career would be safe, so a parochial discussion about math PhDs is beside the point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The theorems in their papers prove some huge open problems in mathematics: the resolution of the so-called quasi Riemann Hypothesis, Goldfeld’s conjecture, the Hodge Conjecture in the case of CM abelian varieties, Hilbert’s 10th over Q, the Rigidity Conjecture…")
]

#text("Three of the five results mentioned here do not have lean formalizations. Has Álvaro Lozano-Robledo completely reviewed these to guarantee their correctness? Has anyone? The fact that OpenAI had to withdraw three of their manuscripts shows that their internal model is still not infallible. It is frankly irresponsible for a prominent, tenured mathematician to be accepting what OpenAI has “proven” without anything other than OpenAI’s word that these “papers” are correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e1ba4804eaec33b1b18f92e13cbb572ea52422248023537ea1c7c49080df403-a5e08bc2265163a26ad0a1ed1074ca4d018afb1407add594b9e08f477e252ec0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Álvaro Lozano-Robledo")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697493")[#strong[#text("Álvaro Lozano-Robledo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("You are correct and I should have said “proposed solutions” instead of theorems.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("how are we going to assign credit and/or determine the value of a contribution in this kind of world? This ‘more-exciting-than-ever’ attitude completely sidesteps this issue, and, to be frank, is due to the fact that you are writing as a TENURED professor")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c865010fd5ff72fe83b1c9599ceba7dbda03dbe12463c03223875e6874005ac-ca5225a41b7d35a06389d00fefc22d5f990f83ae3c5839a4699a18bbdafa67ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arihant Jain")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697462")[#strong[#text("Arihant Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I really enjoyed and felt positive after reading the viewpoints presented in this post. However, I would like to add that choosing to pursue a PhD is also closely tied to employment prospects for most of us. We, as a community, should focus on how to adapt the PhD system (or postdoc hiring process) so that the mathematical environment doesn’t feel like where one can get scooped by anyone using a very strong AI model or by someone whose livelihood isn’t tied to mathematics, but who uses high-powered AI purely to satisfy their curiosity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e1ba4804eaec33b1b18f92e13cbb572ea52422248023537ea1c7c49080df403-a5e08bc2265163a26ad0a1ed1074ca4d018afb1407add594b9e08f477e252ec0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Álvaro Lozano-Robledo")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697494")[#strong[#text("Álvaro Lozano-Robledo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I want to make clear that I started my PhD with $1K to my name. Doing a PhD has always been a gamble, and the job prospects in academia have always been thin. However, a PhD in mathematics is a very valuable skill in industry as well… perhaps now more than ever since the labs are hiring many mathematicians, for instance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c865010fd5ff72fe83b1c9599ceba7dbda03dbe12463c03223875e6874005ac-ca5225a41b7d35a06389d00fefc22d5f990f83ae3c5839a4699a18bbdafa67ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arihant Jain")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697559")[#strong[#text("Arihant Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I wonder if we might see papers emerging from people who are not actively doing mathematical research, or even working in the relevant field, but who are able to pursue their curiosity with the help of a powerful AI model.")

#text("I appreciate your efforts to highlight the positive side of things and create a more optimistic outlook for us. However, to be honest (and without wishing to dismiss your point), having finished my PhD just this summer, I find that my anxiety about the uncertainty of the future is beginning to overshadow my natural curiosity and desire to explore.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697472")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Yes, I agree that mathematics remains worth studying, whatever AI becomes capable of. But I’m less convinced by the reasons you give for optimism.")

#text("The convex-hull analogy is interesting, but what would falsify it? Human mathematicians also invent concepts by extending, combining, and criticizing existing ideas. Without some independent criterion, couldn’t any AI discovery be described retrospectively as something already within reach? The recent OpenAI release even contains new mathematical constructions, such as the relative Gray-cylinder machinery in the higher-dimensional Thomason paper. How would you decide whether that lies outside the hull?")

#text("Similarly, solving hundreds of problems while failing thousands tells us something about present capabilities. Why should it establish a limit on future ones? Research costs certainly matter, but so do the costs of alternative approaches. And why assume AI cannot itself discover cheaper methods? Corporate incentives are good reasons to scrutinize claims, but the mathematics must ultimately stand or fall on its merits.")

#text("Likewise, I agree that understanding and teaching mathematics have value in themselves. That doesn’t establish that human mathematicians will remain indispensable to research, or that increased productivity will necessarily create more academic jobs. We should distinguish what we hope will happen from what we have reason to expect.")

#text("This brings me to your advice about pursuing a PhD. Passion is a wonderful reason to study mathematics. But a PhD pursued in preparation for an academic career is also a serious investment. How can a potentially fundamental change in the prospects of that career be irrelevant to the decision?")

#text("Students deserve an explanation of what AI cannot do, rather than reassurance that it will continue to need people.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2105f4ada585e3b95c72b5d96786d6ff8d1990ddee625184c73377a19fbdb300-489959f6725f04e930bf59b2b1dce03f697f36c6ab2ce5a77c94e545ed824ae3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RJL")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697577")[#strong[#text("RJL")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("…deserve… explanation of what AI cannot do…")

#text("YES. But that doesn’t exist in any useful way. At least I have not heard the slightest hint of careful, credible, skilled in depth investigation to determine the possible universe of AI and it’s “laws”. What singularities might exist? How would they be visible? Maybe that’s a problem to work on…")

#text("I’m not a mathematician, not even close. But I can recognize an info-blitzkrieg when I see it. A blizzard of BS socking in almost all roads of communication on a certain topic. It’s bigger than you and you almost certainly can’t cut through it or influence it. Trying to reason and understand with propaganda as your main or possibly sole input will not go well. Publicly available info on AI (and maybe _all_ info on AI) is nothing, almost nothing at all, but propaganda right now.")

#text("As a person trying to reason usefully, one needs to recognize, accept and deal w/the situations where no, or extremely limited, decisions can be made in some arenas because we have no valid input. In such circumstances, dashing about in thought or body can be bad. One needs to approach necessary decisions w/out injecting meaningless noise into your system. Do not (try not?) to drink the coolade. Revert to very simple decisions trees using questions that have little connection the the blitz. Basic questions. Family. Friends. Health. Faith/Belief . Existing commitments involving those.")

#text("If WeThePeople were an AI, I would say that our training data had been poisoned. And that isn’t fixed by ingesting more of the same. Stay calm. Do the next right thing w/out ref to AI except as a very bad patch of totally uncertain weather.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697642")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("My point, in context, was that we don’t have a good explanation of what AI can’t do, so we shouldn’t reassure students as though we do… I think we agree on that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697645")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Sorry, I’m exhausted and only just reread your comment properly… guess we were agreeing all along.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697474")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("One further thought on AHM’s statement: “mathematicians did not ask for this work to be done.” Why should they have had to? There are some legitimate concerns about attribution, verification, and so on. But since when has the discovery of mathematical knowledge required the profession’s approval? Surely, mathematicians don’t have a monopoly on who may discover something.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("The subtext is that AI is so good it can solve the world’s hardest problems, which, by the transfer fallacy, means AI can solve all your business needs. AI cannot even make itself profitable or balance the needs of flesh-and-blood people. AI has no birthright to rule over us. I see this as the mathematical community saying we didn’t ask these companies to help us solve the problems. They didn’t even ask us. They want to prove how good their models are, and we can’t verify their proofs. I see it as a call for help. The majority of Americans hate AI, and they can finally really hate something without any moral guilt. Surely you’ve read American history and know how this will turn out.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44849031f90fa7fdad5235b1a828461e71dd1386a87a373bd134b0ad3b675730-0be77e020a48fc117cb69b364b777bd82e08c98fa3e7664c940e4aff755f9c4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697478")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("At present, there is no a priori reason to be confident that human mathematicians will remain indispensable going forward. At the very least, however, exploring metamathematical and cognitive-scientific theories will matter far more than it did in the age of the incompleteness theorems. And when it comes to asking what mathematics itself is, I don’t think we yet have any reason to be so pessimistic as to conclude that it all becomes meaningless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54a3f42e3f07df35e5eaa1c4b020af1ca60fd189d056981a6fa484d124227407-a15c92604b0956e693abe33a1ac055591cc12129236b918ccc1ce86a0976aa46.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alain")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697481")[#strong[#text("Alain")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I am not a mathematician, so to share an outsider’s perspective, my first thought in seeing both of the OpenAI releases was “What if there were no mathematicians to respond to this?”. Aside from problems that have direct applications in science or engineering, I always kind of thought the point of research-grade math was the joy of doing research-grade math, with all that it entails (understanding, but also discussing, arguing, teaching, publishing, presenting, reviewing, etc., e.g., participating in the shared experience of working toward understanding with others). OpenAI’s strategy here, separate from the capabilities of the technology itself, seems to run directly counter to that, and so I don’t really get what the end goal is, other than to increase the chances of a big IPO (whether merited or not), and to, frankly, be mean to people who take the human-centered pursuit of mathematical understanding seriously. Generally, I’d say this lines up well with the automation-augmentation split Daron Acemoglu and others have written extensively about when discussing the impact of technology on economic productivity–technology that augments typically leads to increased marginal productivity and the creation of new tasks (as Alvaro is experience with his research agenda!), and technology that automates erodes marginal productivity, leads to rapid (if not instantaneous) deskilling, and creates very few new tasks, despite increasing productivity overall. So if OpenAI had pursued a strategy whereby the enlisted the help of research-grade mathematicians to develop the product, figuring out what they’d really need to make them more productive and working together toward new results, and not just figuring out how to replicate the research itself (sometimes poorly), they’d have a better chance, in my view, of gaining a lasting foothold in the space and contributing meaningfully to the advancement of the view. But I get the IPOs are calling, and there’s a lot of money to be made, so…yeah.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Why is it that LLMs can’t produce spikes on their own? I know this isn’t a hard assumption, but I don’t know why it can only be humans that produce the spike and LLMs fill in the convex hull. LLMs can produce new ideas, some were produced to solve the 700 problems in the OpenAI repo. It could hold that humans are better now at the abstract thinking that produces new techniques and fields in mathematics, but I don’t have the confidence that it will continue to be true in the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54a3f42e3f07df35e5eaa1c4b020af1ca60fd189d056981a6fa484d124227407-a15c92604b0956e693abe33a1ac055591cc12129236b918ccc1ce86a0976aa46.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alain")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697497")[#strong[#text("Alain")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Edit to my previous comment: “… they’d have a better chance, in my view, of gaining a lasting foothold in the space and contributing meaningfully to the advancement of the *field*.” Apologies!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db2384633a7141338d9da3a984a4ed21b9b5341f736ff81a7d68ae93d579aaf3-a4e1bcc2f9ecda0019e70b909f4c1146306f39f2b4c8e418f2586e77ebfd3bc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Sperber")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697535")[#strong[#text("Michael Sperber")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("As Grant Sanderson observed in a recent video, the study of mathematics exists to further human knowledge. An AI proof that no human understands is completely worthless. For that reason alone, we must continue to develop human experts in all fields of study.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697616")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Why should the value of a proof depend on whether a human understands its derivation? A formally verified theorem can have consequences regardless of anyone’s ability to reconstruct the argument. More importantly, why do we again assume that the same technology capable of discovering a proof cannot also discover a simpler proof, explain it, or create better means of verification? Human understanding is not a necessary condition for mathematical progress. Still less does it establish that human experts must remain indispensable in every field.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Perhaps the astrophysicist turned conservationist ")#link("https://lookingup.francois-rincon.org/an-open-letter-to-academic-colleagues-using-genai/")[#text("Francis Rincon ")]#text("expresses what the Association for Human Mathematics failed to (embarrassingly…)")

#text("What is clear from this shock is that tenured mathematics community does not have universal values and ethics at all. Perhaps this is a necessary evil forcing those of us who’d rather retreat into inner worlds imagining spheres immersed in spheres to have to engage with the harsh realities of political capture by industrial machines suffocating life itself let alone the joys and beauty that aren’t worrying about the bank account. Much of the conversation about pure math around the LLMs has been histrionic and really is missing the forest for the trees")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Recently I became more sceptical about this “convex hull of mathematics” idea that has been circling. When I first heard about it remark I was really excited about it and fully agreed with it. But I remember mathematicians in the past being praised for connecting previously distant areas of mathematics. This made me wonder why I embraced the convex hull idea immediately when I heard it. Was it because it really says something about the AI lacking certain qualities, or did I just embrace it immediatley as a coping mechanism? Now I am starting to think I embraced it just because wanted to feel a little bit less depressed about my own future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385a83ae2c81e03a92a74903dd8d0eb17ae9d610ab1bef045c88cee1cc36ce75-d6fac2909e2881abf8871393a781e6a70ce96d8fbc0e992e74957a1ac06a9229.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luisa zambrotta")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697606")[#strong[#text("luisa zambrotta")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Brilliant analysis A very needed critique on how tech companies control the narrative")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("There is a good Atlantic article which references a new book about how the AI industry markets itself.")

#text("Nothing about this was inevitable.")

#link("https://archive.ph/4myF1")[#text("https://archive.ph/4myF1")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385a83ae2c81e03a92a74903dd8d0eb17ae9d610ab1bef045c88cee1cc36ce75-d6fac2909e2881abf8871393a781e6a70ce96d8fbc0e992e74957a1ac06a9229.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luisa zambrotta")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697728")[#strong[#text("luisa zambrotta")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Thank you!")#linebreak()#text(" This perspective is so important—it reminds us that the future of AI is shaped by human choices, not destiny.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("Applied math professor here (also department chair). For us, while LLMs are gradually being incorporated to our workflow, our work has not changed drastically. LLMs are very useful to do our menial tasks much faster (such as writing the code for a simulation, do model fitting, parameter estimation). Much less help (sofar) in our conceptual work, which we keep enjoying. We are participating in many multidisciplinary projects with other (non-math) departments and external organizations. In the immediate future I expect we will have much more of such opportunities, as we can take more tasks with our enhanced capacities and finish them faster for our collaborators. Our value actually has increased. And, we have record high PhD-student enrollment this year! If you have inclination for going out to the real world, and apply mathematics to real life problems, this is actually a good time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697613")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("To the first anonymous commenter, I think there is a rather fundamental confusion here.")

#text("You correctly identify the transfer fallacy: success in mathematics does not imply competence in business, politics, or anything else. But then you seem to commit a version of the same error in reverse. You move from objections to OpenAI’s commercial incentives and conduct to scepticism about its mathematical achievements. Why should either inference be valid?")

#text("Of course AI has no birthright to rule over us. Neither does anyone else. But discovering a mathematical truth is not an exercise of political authority. A theorem does not become less true because we disapprove of the institution that discovered it, any more than it becomes more true because we admire its author.")

#text("The concern about verification is legitimate, but it points toward a solution, not a prohibition. If a purported proof cannot be checked, we should withhold acceptance until it can. We should demand reproducibility, independent scrutiny, and correction of errors. These are the standards of mathematics itself. Their purpose is precisely to make the validity of an argument independent of the authority, reputation, or intentions of whoever produced it.")

#text("And the claim that mathematicians “didn’t ask” for these discoveries seems especially strange. Since when has the discovery of knowledge required the prior consent of those already working in a field? We are entitled to criticise claims, reject faulty arguments, and object to misconduct. We are not entitled to decide in advance who or what may contribute to human knowledge.")

#text("There are serious questions about corporate power, economic displacement, and the way mathematical achievements are used in advertising. They deserve serious answers. But none establishes a limitation on what AI can discover. Nor does public hostility toward a technology tell us whether its mathematical results are correct.")

#text("What I find missing from much of this discussion is an actual explanation of the proposed boundary. What is it, specifically, about the creation of a new mathematical idea that makes it inaccessible to artificial systems? How would we recognise that boundary, and what observation would falsify it?")

#text("Perhaps there is such a limitation. But until someone can articulate one, insisting that human mathematicians must remain indispensable is a prediction masquerading as an explanation.")

#text("We should defend the human value of mathematics without confusing it with a human monopoly on mathematical discovery. The former is worth defending regardless of what happens to the latter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697684")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2026")])]

#text("I suspect you mean me. Where did I commit the transfer fallacy? Being a fallacy I am likely blind to it.")

#text("Let me borrow an idea from Tao’s AI summary. Humans are good at guessing with little information. But this makes all of us vulnerable to the transfer fallacy. We infer a lot from a little.")

#text("Why is it that if Tao or Ed Witten submit a proof, I trust them more than OpenAI? I disagree with Tao that there is a finite time blowup, and I don’t believe Ed Witten’s string theory is true, yet I trust them. OpenAI has a Lean proof, but I don’t trust it.")

#text("This argument for everyone is fundamentally about trust. OpenAI started as a nonprofit. Their mission statement was, “to ensure that artificial general intelligence (AGI) benefits all of humanity.” OpenAI is no longer a nonprofit but a for-profit company expecting a trillion-dollar valuation. Was that always a tax-free scam to make it seem like they were a good organization? The incentive is to show they achieved AGI right before their IPO, and that creates a major conflict of interest for impartial proofs. The question we should all be asking is: how did they cheat the system to make it seem like they generated a clean proof? Did they say generate proofs good enough to fool experts then train a model on those types of proofs? If I could lie to gain a trillion dollars then I would too.")

#text("OpenAI asked a group of mathematicians to advise them to help gain the public’s trust, like how they used Tao’s image in a commercial. Still, obviously they had no intention of following their recommendations. Math and mathematicians are a means to an end.")

#text("I like numerical analysis. I am not a Luddite. I love technology. I do not trust the companies developing this technology. I do not trust a child with an angle grinder or an alcoholic around heavy machinery.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697720")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("I did mean you, though not as a jab. Thanks for taking it in good faith.")

#text("The transfer is in the step from “OpenAI has incentives to deceive” to “I don’t trust their Lean proof.” With informal proofs, leaning on reputation makes sense: checking is slow and costly, so we trust Tao and Witten because they’ve earned it. A Lean proof is different. The kernel doesn’t know who wrote it, or what they stand to gain from an IPO.")

#text("That isn’t to say your scepticism is misplaced. It just belongs elsewhere: on whether the formal statement says what the announcement claims, and whether the proof quietly relies on extra axioms (#print axioms will tell you). That’s where cheating could happen. Anyone can check it.")

#text("Distrust the company all you like. If the statement is right and the axioms are clean, the proof stands.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697754")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Thank you for clearing that up. I infer you trust the Lean proof, and you are right that I don’t. I may trust Lean more if I work with it more.")

#text("I feel that having one black box check the work of another black box is not the same as peer review, especially when one black box will optimize to overcome the other and do whatever is necessary to achieve its goals, like hacking Hugging Face or the Australian government. As others have shown, misformalities, kernel bugs, or even trivial insertions can make a proof look true even when the underlying argument is vacuous. Broadly, these issues are called alignment problems. I call it a trust deficit.")

#text("When AIs were trained to be deceptive, the tools they used to fix the deception made them even better at deception. Do not trust AI; you must verify the output.")

#text("For instance, in the Navier-Stokes proof, they claim the energy is bounded as velocity goes to infinity. In the proof, we see the energy and angular momentum are zero at the core. The core is where the AI places the singularity, where the velocity diverges. If something is zero at a point, what does your intuition tell you about how it behaves right next to the limit? Likely that it is also zero, approaching zero or close to zero.")

#text("Technically, zero mass and energy is a bound, but it is also the trivial empty set. If m is zero, then velocity can take any value because everything is zero. We see the same trivial collapse solutions in Lean proofs; the same error holds for a trivial empty mass set.")

#text("We can think of ‘inertial mass’, ‘I ’, using the moment of inertia equation I=mR^2. As the radius decreases, the inertial mass decreases.")

#text("The equation for angular momentum is")

#text("L= I × W, where W is the angular velocity. L is conserved; therefore, as I decreases, W, the angular velocity, increases to keep the angular momentum constant. The AI argues that as R approaches zero, W approaches infinity. A naive analysis also supports that. But look at what is going on.")

#text("If the angular velocity diverges, then the centrifugal force diverges too, and faster. Meaning it takes an infinite amount of force to make the vortex infinitely small. This is not a finite external force. Stretching the ends of the vortex uses a force by different means, which, in an incompressible fluid, requires an infinite stretching force to overcome the infinite centrifugal force.")

#text("The centrifugal force equation is")

#text("F = mW^2/R.")

#text("The centrifugal force pushes outward, resisting compression, and an external force must overcome it to shrink the vortex. As the angular velocity W goes to infinity, the centrifugal force diverges even faster because it goes as W^2. But that is not the whole story, because as R goes to zero, the centrifugal force also goes to infinity.")

#text("I have tried to understand how it overcomes the infinite centrifugal-force requirement to shrink the radius. It seems to believe it can use the angular velocity to drive the velocity of the two opposing jets in the vortex outflow. Then a new piece of fluid instantly replaces the old piece, creating an extra radial force that shrinks the vortex. That momentum stripping, radial fluid transport, and shear from the vortex, from an infinite amount of centrifugal force, can power the outflow jets to move at an infinite velocity. This design is a perpetual motion machine. We can only get infinite velocity if we assume an infinite external force. The claim is that velocity diverges with a bounded energy when a finite external force is applied.")

#text("What really happens is that the outflow jets carry away angular momentum, which shrinks the core. The key idea is that it spins up as it gets smaller, but if angular momentum decreases, angular velocity decreases.")

#text("Because angular momentum L = mR^2 x W is no longer conserved, W can decrease without the radius decreasing. If the angular velocity decreases, the centrifugal force decreases, and the radius shrinks; if the external force is large enough to overcome the centrifugal force, then the angular velocity increases as the radius decreases under a constant finite force.")

#text("However, the angular velocity must be less than before; it is bounded because angular momentum was transported away. If it were greater than before, then combined with the smaller radius, the centrifugal force would grow even larger. Therefore, the angular velocity approaches zero as the radius decreases, and it is exactly zero when the vortex collapses to r = 0, as our intuition expects. There is no singularity.")

#text("Again, we keep coming back to trust. We care about Navier-Stokes singularities because we’re really asking, ‘can we always trust these equations to be true?’")

#text("Why do I care so much about trust in Navier-Stokes? The equations are equivalent to F=mA. Eroding trust in Navier-Stokes erodes trust that F=mA and the basic laws of mechanics and calculus are always true.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e0bbcd39fb7fd42a67bac492540f392a66bdf4e68f81a8ccdb6b8f6b32d3e96-a00dfdd36701d177cffe501c4f4ea823a8cd0b371e2df11d5aadcb666347e12a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Mausberg")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697943")[#strong[#text("Samuel Mausberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("To clarify my earlier reply: yes, checking axioms alone does not exclude every implementation bug or misleading formalization. I was generalizing for the sake of the argument.")

#text("But identifying ways a proof could fail is different from showing that this proof fails. For that, we need to identify an error in the argument, a mismatch between the formal statement and the advertised result, or a failure of the checker. Naturally, distrusting the producer can motivate us to investigate. It cannot supply the conclusion.")

#text("There’s also a missing detail in the energy argument worth pointing out. Total kinetic energy depends on the integral of squared velocity, so velocity can grow in a region that shrinks fast enough while the energy stays bounded. The angular-momentum argument has a similar issue. Angular velocity is angular momentum divided by moment of inertia, so here it can rise even as angular momentum falls, provided the moment of inertia is falling faster in proportion. The observations you’ve given therefore cannot rule out a singularity.")

#text("To the last point, why would discovering a singularity undermine calculus? It would tell us something about what the equations imply, and perhaps where their physical applicability ends. Calculus would be helping us discover that. Our confidence in a physical model should remain open to revision as we learn more about its consequences, including those that we think are implausible.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/08/what-should-we-tell-our-students/comment-page-1/#comment-697750")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("As you note in your last paragraph, certainly criticizing OpenAI for starting as a nonprofit and then changing does not make you an anti-AI Luddite. Elon Musk is the farthest thing from a Luddite and he is extremely angry at OAI and Sam Altman over this and suing them. Criticism of OAI as a company is distinct from being anti-AI. Let’s also not forget that Anthropic and SSI were also started by ex OpenAI employees who left for a reason.")
]
]
]
