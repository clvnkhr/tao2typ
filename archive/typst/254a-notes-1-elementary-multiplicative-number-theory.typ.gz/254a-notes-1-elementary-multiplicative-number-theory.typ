// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/
// Converted to Typst by tao2typ: "2026-10-14T15:19:16.689577+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 1: Elementary multiplicative number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 1: Elementary multiplicative number theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 November 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In analytic number theory, an ")#link("http://en.wikipedia.org/wiki/Arithmetic_function")[#text("arithmetic function")]#text(" is simply a function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" from the natural numbers ")#mi("{{\\bf N} = \\{1,2,3,\\dots\\}}")#text(" to the real or complex numbers. (One occasionally also considers arithmetic functions taking values in more general rings than ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(", as in ")#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/")[#text("this previous blog post")]#text(", but we will restrict attention here to the classical situation of real or complex arithmetic functions.) Experience has shown that a particularly tractable and relevant class of arithmetic functions for analytic number theory are the ")#link("http://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative functions")]#text(", which are arithmetic functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" with the additional property that ")#metadata(none) <tao-4bd77cffb0da8cbda839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(nm) = f(n) f(m)")]]

#text("whenever ")#mi("{n,m \\in{\\bf N}}")#text(" are coprime. (One also considers arithmetic functions, such as the logarithm function ")#mi("{L(n) := \\log n}")#text(" or the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", that are not genuinely multiplicative, but interact closely with multiplicative functions, and can be viewed as “derived” versions of multiplicative functions; see ")#link("https://terrytao.wordpress.com/2014/09/24/derived-multiplicative-functions/")[#text("this previous post")]#text(".) A typical example of a multiplicative function is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#metadata(none) <tao-d008361e302ca2079cf7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\tau(n) := \\sum_{d|n} 1")]]

#text("that counts the number of divisors of a natural number ")#mi("{n}")#text(". (The divisor function ")#mi("{n \\mapsto \\tau(n)}")#text(" is also denoted ")#mi("{n \\mapsto d(n)}")#text(" in the literature.) The study of asymptotic behaviour of multiplicative functions (and their relatives) is known as ")#link("http://en.wikipedia.org/wiki/Multiplicative_number_theory")[#text("multiplicative number theory")]#text(", and is a basic cornerstone of modern analytic number theory.")#linebreak()#text(" There are various approaches to multiplicative number theory, each of which focuses on different asymptotic statistics of arithmetic functions ")#mi("{f}")#text(". In ")#emph[#text("elementary multiplicative number theory")]#text(", which is the focus of this set of notes, particular emphasis is given on the following two statistics of a given arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(":")

#enum(start: 1, 
[#text("The ")#emph[#text("summatory functions")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n)")]]

#text("of an arithmetic function ")#mi("{f}")#text(", as well as the associated ")#link("http://en.wikipedia.org/wiki/Natural_density")[#text("natural density")]

#align(center)[#tao-fit-display[#mitex("\\lim_{x \\rightarrow \\infty} \\frac{1}{x} \\sum_{n \\leq x} f(n)")]]

#text("(if it exists).")],
[#text("The ")#emph[#text("logarithmic sums")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n\\leq x} \\frac{f(n)}{n}")]]

#text("of an arithmetic function ")#mi("{f}")#text(", as well as the associated ")#emph[#text("logarithmic density")]

#align(center)[#tao-fit-display[#mitex("\\lim_{x \\rightarrow \\infty} \\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{f(n)}{n}")]]

#text("(if it exists).")]
)

#text("Here, we are normalising the arithmetic function ")#mi("{f}")#text(" being studied to be of roughly unit size up to logarithms, obeying bounds such as ")#mi("{f(n)=O(1)}")#text(", ")#mi("{f(n) = O(\\log^{O(1)} n)}")#text(", or at worst ")#metadata(none) <tao-f185d43145d180df586c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(n) = O(n^{o(1)}).")]]

#text("A classical case of interest is when ")#mi("{f}")#text(" is an indicator function ")#mi("{f=1_A}")#text(" of some set ")#mi("{A}")#text(" of natural numbers, in which case we also refer to the natural or logarithmic density of ")#mi("{f}")#text(" as the natural or logarithmic density of ")#mi("{A}")#text(" respectively. However, in analytic number theory it is usually more convenient to replace such indicator functions with other related functions that have better multiplicative properties. For instance, the indicator function ")#mi("{1_{\\mathcal P}}")#text(" of the primes is often replaced with the von Mangoldt function ")#mi("{\\Lambda}")#text(".")#linebreak()#text(" Typically, the logarithmic sums are relatively easy to control, but the summatory functions require more effort in order to obtain satisfactory estimates; see Exercise ")#link(<tao-70ba33708cbfb103f1a8>)[#text("6")]#text(" below.")#linebreak()#text(" If an arithmetic function ")#mi("{f}")#text(" is multiplicative (or closely related to a multiplicative function), then there is an important further statistic on an arithmetic function ")#mi("{f}")#text(" beyond the summatory function and the logarithmic sum, namely the ")#link("http://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]#text(" ")#metadata(none) <tao-580c490253f4585abf17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\mathcal D}f(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s}")]]

#text("for various real or complex numbers ")#mi("{s}")#text(". Under the hypothesis ")#link(<tao-f185d43145d180df586c>)[#text("(43)")]#text(", this series is absolutely convergent for real numbers ")#mi("{s>1}")#text(", or more generally for complex numbers ")#mi("{s}")#text(" with ")#mi("{\\text{Re}(s)>1}")#text(". As we will see below the fold, when ")#mi("{f}")#text(" is multiplicative then the Dirichlet series enjoys an important ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product")]#text(" factorisation which has many consequences for analytic number theory.")#linebreak()#text(" In the elementary approach to multiplicative number theory presented in this set of notes, we consider Dirichlet series only for real numbers ")#mi("{s>1}")#text(" (and focusing particularly on the asymptotic behaviour as ")#mi("{s \\rightarrow 1^+}")#text("); in later notes we will focus instead on the important ")#emph[#text("complex-analytic")]#text(" approach to multiplicative number theory, in which the Dirichlet series ")#link(<tao-580c490253f4585abf17>)[#text("(4)")]#text(" play a central role, and are defined not only for complex numbers with large real part, but are often extended analytically or meromorphically to the rest of the complex plane as well.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The elementary and complex-analytic approaches to multiplicative number theory are the two classical approaches to the subject. One could also consider a more “Fourier-analytic” approach, in which one studies convolution-type statistics such as ")#metadata(none) <tao-19c736c55a13429960ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_n \\frac{f(n)}{n} G( t - \\log n )")]]

#text("as ")#mi("{t \\rightarrow \\infty}")#text(" for various cutoff functions ")#mi("{G: {\\bf R} \\rightarrow {\\bf C}}")#text(", such as smooth, compactly supported functions. See ")#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("this previous blog post")]#text(" for an instance of such an approach. Another related approach is the “pretentious” approach to multiplicative number theory currently being developed by Granville-Soundararajan and their collaborators. We will occasionally make reference to these more modern approaches in these notes, but will primarily focus on the classical approaches.")
]

#text("To reverse the process and derive control on summatory functions or logarithmic sums starting from control of Dirichlet series is trickier, and usually requires one to allow ")#mi("{s}")#text(" to be complex-valued rather than real-valued if one wants to obtain really accurate estimates; we will return to this point in subsequent notes. However, there is a cheap way to get ")#emph[#text("upper bounds")]#text(" on such sums, known as ")#emph[#text("Rankin’s trick")]#text(", which we will discuss later in these notes.")#linebreak()#text(" The basic strategy of elementary multiplicative theory is to first gather useful estimates on the statistics of “smooth” or “non-oscillatory” functions, such as the constant function ")#mi("{n \\mapsto 1}")#text(", the harmonic function ")#mi("{n \\mapsto \\frac{1}{n}}")#text(", or the logarithm function ")#mi("{n \\mapsto \\log n}")#text("; one also considers the statistics of periodic functions such as ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet characters")]#text(". These functions can be understood without any multiplicative number theory, using basic tools from real analysis such as the (quantitative version of the) ")#link("http://en.wikipedia.org/wiki/Integral_test_for_convergence")[#text("integral test")]#text(" or ")#link("http://en.wikipedia.org/wiki/Summation_by_parts")[#text("summation by parts")]#text(". Once one understands the statistics of these basic functions, one can then move on to statistics of more arithmetically interesting functions, such as the divisor function ")#link(<tao-d008361e302ca2079cf7>)[#text("(2)")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda}")#text(" that we will discuss below. A key tool to relate these functions to each other is that of ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("Dirichlet convolution")]#text(", which is an operation that interacts well with summatory functions, logarithmic sums, and particularly well with Dirichlet series.")#linebreak()#text(" This is only an introduction to elementary multiplicative number theory techniques. More in-depth treatments may be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=2378655")[#text("this text of Montgomery-Vaughan")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=2111739")[#text("this text of Bateman-Diamond")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-c314edaf40a6abce674c>

#heading(level: 1)[#strong[#text(" — 1. Summing monotone functions — ")]]

#metadata(none) <tao-5188e5f0d53682262e1d>#linebreak()#text(" The most fundamental estimate regarding the equidistribution of the natural numbers is the trivial bound ")#metadata(none) <tao-ec5e78e0e9e93182a4e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\leq x} 1 = x + O(1)")]]

#text("for any ")#mi("{x > 0}")#text(", which reflects the evenly spaced nature of the natural numbers. One also has the variant ")#metadata(none) <tao-1aa20c854d615577b910>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\leq x} 1 \\leq x,")]]

#text("also valid for any ")#mi("{x > 0}")#text(". (But note that if the summation is not over the natural numbers, but is also allowed to contain ")#mi("{n=0}")#text(", then the sum ")#mi("{\\sum_{0 \\leq n \\leq x} 1}")#text(" (or ")#tao-math("{\\sum_{n \\in {\\bf Z}: \\left|n\\right| \\leq x} 1}", block: false)#text(") is no longer ")#mi("{O(x)}")#text(" when ")#mi("{x}")#text(" is small, and one should instead revert to ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(".)")#linebreak()#text(" We have the following generalisation of ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" to summation of monotone functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Quantitative integral test)")]#text(" ")#metadata(none) <tao-1a20f6d5510e063e9244>#text(" Let ")#mi("{y < x}")#text(" be real numbers, and let ")#mi("{f: [y,x] \\rightarrow {\\bf R}}")#text(" be a monotone function. Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in {\\bf Z}: y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + O( \\left|f(x)\\right| + \\left|f(y)\\right| ).", block: true)]]
]

#text("Note that monotone functions are automatically Riemann integrable and Lebesgue integrable, so there is no difficulty in defining the integral appearing above.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" By replacing ")#mi("{f}")#text(" with ")#mi("{-f}")#text(" if necessary, we may assume that ")#mi("{f}")#text(" is non-decreasing. By rounding up ")#mi("{y}")#text(" and rounding down ")#mi("{x}")#text(", we may assume that ")#mi("{x,y}")#text(" are integers. We have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\in {\\bf Z}: y \\leq n \\leq x} f(n)  & = \\int_y^{x} f(\\lfloor t\\rfloor)\\ dt + f(x)", block: true)



#tao-math(" & \\leq \\int_y^{x} f(t)\\ dt + f(x)", block: true)
]

#text("and similarly")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\in {\\bf Z}: y \\leq n \\leq x} f(n)  & = \\int_y^{x} f(\\lceil t\\rceil)\\ dt + f(y)", block: true)



#tao-math(" & \\geq \\int_y^{x} f(t)\\ dt + f(y)", block: true)
]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" Thus, for instance, one has ")#metadata(none) <tao-4011393f356a69582a25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{n \\leq x} \\log n = x \\log x - x + O(\\log(2+x))")]]

#text("for any ")#mi("{x>0}")#text(" (a weak form of ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this previous blog post")]#text("), and more generally one has ")#metadata(none) <tao-718e649231fd95a3315a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{n \\leq x} \\log^k n = x P_k(\\log x) + O_k( \\log^k(2+x))")]]

#text("for all ")#mi("{x > 0}")#text(" and some polynomial ")#mi("{P_k(t)}")#text(" with leading term ")#mi("{t^k}")#text(". (The remaining terms in ")#mi("{P_k(t)}")#text(" may be computed explicitly, but for our purposes it will not be essential to know what they are.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" If ")#mi("{x,y}")#text(" are not required to be integers, then one cannot improve substantially on the size of the error term ")#mi("{O(f(x)+f(y))}")#text(", as one can see by considering what happens if ")#mi("{x}")#text(" or ")#mi("{y}")#text(" transitions from being infinitesimally smaller than an integer to infinitesimally larger than that integer. But if ")#mi("{x,y}")#text(" are integer and one assumes more differentiability on ")#mi("{f}")#text(", one can get more precise control on the error term in Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text(" using ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("the Euler-Maclaurin formula")]#text("; see e.g. Exercise ")#link(<tao-2f57d47a3370b4376ace>)[#text("7")]#text(" below. However, we will usually not need these more refined estimates here. In any event, one can get even better control on the error term if one works with smoother sums such as ")#link(<tao-19c736c55a13429960ca>)[#text("(5)")]#text(" with ")#mi("{G}")#text(" smooth, thanks to tools such as the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(". See ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(" for some related discussion.")#linebreak()#text(" In the converse direction, if ")#mi("{f}")#text(" is highly oscillatory then there is usually no simple relationship between the sum ")#mi("{\\sum_{n \\in {\\bf Z}: y \\leq n \\leq x} f(n)}")#text(" and the integral ")#mi("{\\int_y^x f(t)\\ dt}")#text("; consider for instance the example ")#mi("{f(t) := \\cos(2\\pi t)}")#text(", in which the sum grows linearly in ")#mi("{x-y}")#text(" but the integral stays bounded.")
]

#text("Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text(" combines well with the following basic lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Cauchy sequences converge)")]#text(" ")#metadata(none) <tao-27368d421f0ff4d182b6>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(", ")#mi("{F: {\\bf R}^+ \\rightarrow {\\bf C}}")#text(" and ")#mi("{g: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" be functions such that ")#mi("{g(x) \\rightarrow 0}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". Then the following are equivalent:")

#list(
[#text("(i) One has")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n < x} f(n) = F(x) - F(y) + O( g(x) + g(y) )")]]

#text("for all ")#mi("{1 \\leq y < x}")#text(".")],
[#text("(ii) There exists a constant ")#mi("{c \\in {\\bf C}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n < x} f(n) = c + F(x) + O( g(x) )")]]

#text("for all ")#mi("{x \\geq 1}")#text(". In particular, ")#mi("{c = -F(1) + O(g(1))}")#text(".")]
)

#text("The quantity ")#mi("{c}")#text(" in (ii) is unique; it is also real-valued if ")#mi("{f,F}")#text(" are real-valued.")#linebreak()#text(" If in addition ")#mi("{F(x) \\rightarrow 0}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", then when (ii) holds, ")#mi("{\\sum_{n=1}^\\infty f(n)}")#text(" converges conditionally to ")#mi("{c}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Prove Lemma ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(".")
]

#text("We now give some basic applications of these lemmas. If ")#mi("{s>0}")#text(" is a real number not equal to ")#mi("{1}")#text(", then from Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text(" we have ")#metadata(none) <tao-909104cdb5b06af2606e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{y \\leq n \\leq x} \\frac{1}{n^s} = \\frac{y^{1-s}}{s-1} - \\frac{x^{1-s}}{s-1} + O( \\frac{1}{y^s} )")]]

#text("for ")#mi("{1 \\leq y < x}")#text(", and hence by Lemma ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(", there is a real number ")#mi("{\\zeta(s)}")#text(" with ")#metadata(none) <tao-3a44788d006adcb566a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\zeta(s) = \\frac{1}{s-1} + O(1)")]]

#text("such that ")#metadata(none) <tao-e1754a9974fb0df68e45>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n \\leq x} \\frac{1}{n^s} = \\zeta(s) - \\frac{x^{1-s}}{s-1} + O( \\frac{1}{x^s} ).")]]

#text("for all ")#mi("{x \\geq 1}")#text(". In the case ")#mi("{s>1}")#text(", we conclude that the sum ")#mi("{\\sum_n \\frac{1}{n^s}}")#text(" is absolutely convergent, and ")#metadata(none) <tao-c0e9520306518bffa7ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\zeta(s) := \\sum_{n=1}^\\infty \\frac{1}{n^s};")]]

#text("however for ")#mi("{s<1}")#text(" this identity is technically not true, since the sum on the right-hand side is now divergent using the usual conventions for infinite sums. (The identity can however be recovered by using more general interpretations of infinite sums; see ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous blog post")]#text(".) The function ")#mi("{\\zeta}")#text(" is of course the famous ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(".")#linebreak()#text(" For the ")#mi("{s=1}")#text(" case, we again see from Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n \\leq x} \\frac{1}{n} = \\log x - \\log y + O( \\frac{1}{y} )")]]

#text("for ")#mi("{1 \\leq y \\leq x}")#text(", and thus there exists a real number ")#mi("{\\gamma}")#text(" such that ")#metadata(none) <tao-af3ce03f6874c53162b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{n \\leq x} \\frac{1}{n} = \\log x + \\gamma + O( \\frac{1}{x} )")]]

#text("for ")#mi("{x \\geq 1}")#text(". The constant ")#mi("{\\gamma}")#text(" is known as ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler’s constant")]#text(" (or the ")#emph[#text("Euler-Mascheroni constant")]#text("), and has a value of ")#mi("{\\gamma = 0.57721566\\dots}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-70ba33708cbfb103f1a8>#text(" Let ")#mi("{f}")#text(" be an arithmetic function. If the natural density ")#mi("{\\lim_{x \\rightarrow \\infty} \\frac{1}{x} \\sum_{n \\leq x} f(n)}")#text(" of ")#mi("{f}")#text(" exists and is equal to some complex number ")#mi("{\\alpha}")#text(", show that the logarithmic density ")#mi("{\\lim_{x \\rightarrow \\infty} \\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{f(n)}{n}}")#text(" also exists and is equal to ")#mi("{\\alpha}")#text(". (")#emph[#text("Hint:")]#text(" first establish the identity ")#mi("{\\sum_{n \\leq x} \\frac{f(n)}{n} = \\frac{1}{x} \\sum_{n \\leq x} f(n) + \\int_1^x \\frac{1}{t} \\sum_{n \\leq t} f(n) \\frac{dt}{t}}")#text(".) An important counterexample to the converse claim is given in Exercise ")#link(<tao-2f57d47a3370b4376ace>)[#text("7")]#text(" below.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-2f57d47a3370b4376ace>#text(" Let ")#mi("{y < x}")#text(" be real numbers, and let ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(" be a continuously differentiable function. Show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in {\\bf Z}: y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + O( \\int_y^x |f^{\\prime}(t)|\\ dt + \\left|f(y)\\right| ).", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" compare ")#mi("{f(n)}")#text(" with ")#mi("{\\int_n^{n+1} f(t)\\ dt}")#text(". One may first wish to consider the case when ")#mi("{x,y}")#text(" are integers, and deal with the roundoff errors when this is not the case later.) Conclude that if ")#mi("{t}")#text(" is a non-zero real number, that the function ")#mi("{n \\mapsto n^{it}}")#text(" has logarithmic density zero, but does not have a natural density. (")#emph[#text("Hint:")]#text(" for the latter claim, argue by contradiction and consider sums of the form ")#mi("{\\sum_{x \\leq n \\leq (1+\\varepsilon) x} n^{it}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The above exercise demonstrates that logarithmic density is a cruder statistic than natural density, as it completely ignores oscillations by ")#mi("{n^{it}}")#text(", whereas natural density is very sensitive to such oscillations. As such, controlling natural density of some arithmetic functions (such as the von Mangoldt function ")#mi("{\\Lambda}")#text(") often boils down to determining to what extent such functions “conspire”, “correlate”, or “pretend to be” ")#mi("{n^{it}}")#text(" for various real numbers ")#mi("{t}")#text(". This fact is a little tricky to discern in the elementary approach to multiplicative number theory, but is more readily apparent in the complex analytic approach, which we will discuss in later notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" For non-negative natural numbers ")#mi("{k,l \\geq 0}")#text(", show that ")#metadata(none) <tao-16998845d34cbe77670b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\sum_{n \\leq x} \\log^k n \\log^l \\frac{x}{n} = x P_{k,l}(\\log x) + O_{k,l}(\\log^{k+l}(2+x))")]]

#text("for all ")#mi("{x \\geq 0}")#text(" and some polynomial ")#mi("{P_{k,l}(t)}")#text(" with leading term ")#mi("{l! t^k}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]

#list(
[#text("(i) For any integer ")#mi("{k \\geq 0}")#text(", show that")

#metadata(none) <tao-a2f45baa601696ccfe19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_{n \\leq x} \\frac{\\log^k n}{n} = Q_k( \\log x ) + O_k( \\frac{\\log^k (2+x)}{x} )")]]

#text("for all ")#mi("{x \\geq 1}")#text(", where ")#mi("{Q_k(t)}")#text(" is a polynomial with leading term ")#mi("{\\frac{1}{k+1} t^{k+1}}")#text(" (in fact ")#mi("{Q_k(t)}")#text(" is exactly equal to ")#mi("{\\frac{1}{k+1} t^{k+1} + c_k}")#text(" for some constant ")#mi("{c_k}")#text(").")],
[#text("(ii) More generally, for any integers ")#mi("{k,l \\geq 0}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\log^k n \\log^l \\frac{x}{n}}{n}")]]

#metadata(none) <tao-9fab93dfd27b425a5a60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("= Q_{k,l}( \\log x ) + O_{k,l}( \\frac{\\log^{k+l} (2+x)}{x} )")]]

#text("for all ")#mi("{x \\geq 1}")#text(", where ")#mi("{Q_{k,l}(t)}")#text(" is a polynomial with leading term ")#mi("{\\frac{k! l!}{(k+l+1)!} t^{k+l+1}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-609f6817b74bff31d755>#text(" Show rigorously that for any non-negative integer ")#mi("{k \\geq 0}")#text(" and real ")#mi("{s>1}")#text(", the Riemann zeta function ")#mi("{\\zeta}")#text(" is ")#mi("{k}")#text("-times differentiable at ")#mi("{s}")#text(" and one has ")#metadata(none) <tao-fc613b4dfd6736a7bd26>

#tao-aligned(keep: true)[


#tao-math("\\zeta^{(k)}(s)  & = (-1)^k \\sum_{n=1}^\\infty \\frac{\\log^k n}{n^s}", block: true, numbering: n => [#text("(18)")])



#tao-math(" & = (-1)^k \\frac{k!}{(s-1)^{k+1}} + O_k(1).", block: true)
]

#text("(There are several ways to justify the term-by-term differentiation in the first equation; one way is to instead establish a term-by-term integration formula and then apply the fundamental theorem of calculus. Another is to use Taylor series with remainder to control the error in Newton quotients. A third approach is to use complex analysis. You may find Exercise ")#link(<tao-2f57d47a3370b4376ace>)[#text("7")]#text(" to be useful for some of these approaches.)")
]

#heading(level: 1)[#strong[#text(" — 2. Mertens’ theorems — ")]]

#metadata(none) <tao-096b3764d961902778a5>#linebreak()#text(" We can now use the above estimates to gain some useful initial estimates on the primes. Our starting point will be the ")#link("https://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(", which asserts that every natural number ")#mi("{n}")#text(" can be factored as ")#metadata(none) <tao-3c15dc2308570c62ec4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("n = \\prod_p p^{\\nu_p(n)},")]]

#text("where ")#mi("{\\nu_p(n)}")#text(" is the number of times ")#mi("{p}")#text(" divides ")#mi("{n}")#text(" (this number will be ")#mi("{0}")#text(" for all but finitely many primes). Taking logarithms, we obtain")

#align(center)[#tao-fit-display[#mitex("\\log n = \\sum_p \\nu_p(n) \\log p")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\log n = \\sum_p \\sum_{j \\geq 1: p^j | n} \\log p.")]]

#text("(Here we use the standard notation in analytic number theory of using ")#mi("{d|n}")#text(" to denote the assertion that ")#mi("{d}")#text(" divides ")#mi("{n}")#text(".) We can rearrange this as ")#metadata(none) <tao-7e96deb41db0db73f454>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\log n = \\sum_{d|n} \\Lambda(d)")]]

#text("where ")#mi("{\\Lambda(d)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", defined to equal ")#mi("{\\log p}")#text(" when ")#mi("{d}")#text(" is a power ")#mi("{d=p^j}")#text(" of a prime ")#mi("{p}")#text(" for some ")#mi("{j \\geq 1}")#text(", and zero otherwise. Roughly speaking, this function is the indicator function of the primes ")#mi("{{\\mathcal P}}")#text(" weighted by the logarithm function; indeed, we have ")#metadata(none) <tao-fce144e53afe0ea9e827>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\Lambda(n) = \\log n 1_{\\mathcal P}(n)")]]

#text("except when ")#mi("{n}")#text(" is a power ")#mi("{n=p^j}")#text(" of a prime ")#mi("{p}")#text(" for some ")#mi("{j \\geq 2}")#text(". This latter situation occurs quite rarely, and so as a first approximation one can heuristically view the left and right-hand sides of ")#link(<tao-fce144e53afe0ea9e827>)[#text("(21)")]#text(" as being morally the same.")#linebreak()#text(" To control some error terms, we first use some elementary number theory to give a crude but useful upper bound.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Chebyshev upper bound)")]#text(" ")#metadata(none) <tao-43b68e0e178454bb7e96>#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\ll x")]]

#text("for all ")#mi("{x \\geq 0}")#text(". In particular, specialising ")#mi("{n}")#text(" to primes we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\log p \\ll x.")]]
]

#emph[#text("Proof:")]#text(" We use the following slick (but perhaps somewhat unmotivated) argument. By telescoping series it suffices to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{N < n \\leq 2N} \\Lambda(n) \\ll N")]]

#text("for all natural numbers ")#mi("{N}")#text(". We first consider the contribution of those ")#mi("{n}")#text(" that are powers ")#mi("{p^j}")#text(" of a prime ")#mi("{p}")#text(" for some ")#mi("{j \\geq 2}")#text(". One has ")#mi("{p \\ll \\sqrt{N}}")#text(", so there are at most ")#mi("{O(\\sqrt{N})}")#text(" such primes, and each prime contributes at most ")#mi("{O( \\log 2N )}")#text(" to the above sum; since ")#mi("{\\sqrt{N} \\log 2N = O(N)}")#text(", we may discard this contribution and reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{N < p \\leq 2N} \\log p \\ll N.")]]

#text("We will achieve this through an inspection of the binomial coefficient")

#align(center)[#tao-fit-display[#mitex("\\binom{2N}{N} = \\frac{(2N)!}{(N!)^2}.")]]

#text("Observe that if ")#mi("{p}")#text(" is a prime with ")#mi("{N < p \\leq 2N}")#text(", then ")#mi("{p}")#text(" divides ")#mi("{(2N)!}")#text(" but not ")#mi("{(N!)^2}")#text(", and so divides ")#mi("{\\binom{2N}{N}}")#text(". Taking logarithms, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{N < p \\leq 2N} \\log p \\leq \\log \\binom{2N}{N}.")]]

#text("From the binomial theorem we have ")#mi("{\\binom{2N}{N} \\leq 2^{2N}}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" By manipulating the basic identity ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(" in several ways, we can start getting more control on various sums of ")#mi("{\\Lambda}")#text(", and hence over the primes. We begin with")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (First Mertens theorem)")]#text(" ")#metadata(none) <tao-3bbb50f290900e9385d0>#text(" We have the estimate ")#metadata(none) <tao-6fde02e046acf68c1c28>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} = \\log x + O(1)")]]

#text("and ")#metadata(none) <tao-9d211ae51a7f6764d47c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{p \\leq x} \\frac{\\log p}{p} = \\log x + O(1)")]]

#text("for all ")#mi("{x \\geq 1}")#text(".")
]

#emph[#text("Proof:")]#text(" If we sum ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(" over all ")#mi("{n \\leq x}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\log n = \\sum_{n \\leq x} \\sum_{d|n} \\Lambda(d).")]]

#text("By ")#link(<tao-4011393f356a69582a25>)[#text("(8)")]#text(", the left-hand side is ")#mi("{x \\log x + O(x)}")#text(". As for the right-hand side, we can rewrite the conditions ")#mi("{n \\leq x, d|n}")#text(" by the change of variables ")#mi("{n=dm}")#text(" as ")#mi("{d \\leq x}")#text(" and ")#mi("{m \\leq x/d}")#text(", to rearrange the right-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\Lambda(d) \\sum_{n \\leq x/d} 1.")]]

#text("Applying ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(", we conclude that ")#metadata(none) <tao-63f75c890b05405e6e1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("x\\log x + O(x) = x\\sum_{d \\leq x} \\frac{\\Lambda(d)}{d} + O( \\sum_{d \\leq x} \\Lambda(d) )")]]

#text("and so ")#link(<tao-6fde02e046acf68c1c28>)[#text("(22)")]#text(" follows from Proposition ")#link(<tao-43b68e0e178454bb7e96>)[#text("12")]#text(".")#linebreak()#text(" Now we prove ")#link(<tao-9d211ae51a7f6764d47c>)[#text("(23)")]#text(". From the definition of the von Mangoldt function, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} = \\sum_{p \\leq x} \\frac{\\log p}{p} + \\sum_{j=2}^\\infty \\sum_{p \\leq x^{1/j}} \\frac{\\log p}{p^j}.")]]

#text("We crudely bound ")#mi("{\\frac{\\log p}{p^j} \\ll \\frac{1}{2^{j/2}} \\frac{\\log p}{p^{3/2}}}")#text(" for ")#mi("{j \\geq 2}")#text(". Since ")#mi("{\\sum_n \\frac{\\log n}{n^{3/2}} = O(1)}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} = \\sum_{p \\leq x} \\frac{\\log p}{p} + O(1)")]]

#text("and the claim follows ")#link(<tao-9d211ae51a7f6764d47c>)[#text("(23)")]#text(" from ")#link(<tao-6fde02e046acf68c1c28>)[#text("(22)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Chebyshev’s theorem)")]#text(" ")#metadata(none) <tao-9fc0cc876de8c0521306>#text(" Show that there exists an absolute constant ")#mi("{0 < c < 1}")#text(" such that there are ")#mi("{\\asymp \\frac{x}{\\log x}}")#text(" primes in ")#mi("{[cx,x]}")#text(" for all sufficiently large ")#mi("{x}")#text(" (that is to say, the number of primes is ")#mi("{\\gg \\frac{x}{\\log x}}")#text(" and ")#mi("{\\ll \\frac{x}{\\log x}}")#text("). Conclude in particular that ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\asymp x}")#text(".")
]

#text("From this we can obtain a sharper form of Theorem ")#link(<tao-a6b11d00651364ac58e3>)[#text("19")]#text(", controlling logarithmic sums of the primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Second Mertens’ theorem)")]#text(" ")#metadata(none) <tao-091f39f5ce0570bc5337>#text(" One has")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{1}{p} = \\log\\log x + c_1 + O(\\frac{1}{\\log x})")]]

#text("for ")#mi("{x \\geq 2}")#text(" and some absolute constant ")#mi("{c_1}")#text(". Similarly, one has ")#metadata(none) <tao-6bccb52d60bbaa199a43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n \\log n} = \\log\\log x + c_2 + O(\\frac{1}{\\log x})")]]

#text("for ")#mi("{x \\geq 2}")#text(" and some absolute constant ")#mi("{c_2}")#text(".")
]

#text("The constant ")#mi("{c_1}")#text(" has no particular significance in applications, but the constant ")#mi("{c_2}")#text(" can be usefully computed: see ")#link(<tao-f8d45c75a553ede2e061>)[#text("(34)")]#text(" below.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We just prove the first claim, as the second is similar (and can be deduced from the first by a modification of the argument used to deduce ")#link(<tao-9d211ae51a7f6764d47c>)[#text("(23)")]#text(" from ")#link(<tao-6fde02e046acf68c1c28>)[#text("(22)")]#text("). One could proceed here using ")#link("http://en.wikipedia.org/wiki/Summation_by_parts")[#text("summation by parts")]#text(", but we will argue using an essentially equivalent method, based on the fundamental theorem of calculus.")#linebreak()#text(" By Lemma ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq p \\leq x} \\frac{1}{p} = \\log\\log x - \\log\\log y + O(\\frac{1}{\\log y})")]]

#text("for ")#mi("{2 \\leq y<x}")#text(" both go to infinity. From the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} = \\frac{\\log p}{p} ( \\frac{1}{\\log x} + \\int_y^x 1_{p \\leq t}\\ \\frac{dt}{t \\log^2 t} )")]]

#text("for all ")#mi("{y \\leq p \\leq x}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq p \\leq x} \\frac{1}{p} = \\frac{1}{\\log x} \\sum_{y \\leq p \\leq x} \\frac{\\log p}{p} + \\int_y^x \\sum_{y \\leq p \\leq t} \\frac{\\log p}{p} \\frac{dt}{t \\log^2 t}.")]]

#text("From ")#link(<tao-9d211ae51a7f6764d47c>)[#text("(23)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq p \\leq t} \\frac{\\log p}{p} = \\log t - \\log y + O(1)")]]

#text("for all ")#mi("{t \\geq y}")#text("; since")

#align(center)[#tao-fit-display[#mitex("\\int_y^x \\frac{dt}{t \\log^2 t} = \\frac{1}{\\log y} - \\frac{1}{\\log x} = O(\\frac{1}{\\log x})")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\int_y^x (\\log t - \\log y) \\frac{dt}{t \\log^2 t}  & = \\log\\log x - \\log\\log y + \\frac{\\log y}{\\log x} - 1", block: true)



#tao-math(" & = \\log\\log x - \\log\\log y + O(1),", block: true)
]

#text("the claim follows. ")#mi("\\Box")#linebreak()#text(" This leads to a useful general formula for computing various slowly varying sums over primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-4a630b8e79a0cd2fbae3>

#list(
[#text("(i) For any fixed ")#mi("{0 < a < b < \\infty}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^a \\leq p \\leq x^b} \\frac{1}{p} = \\log \\frac{b}{a} + o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) If ")#mi("{f: (0,+\\infty) \\rightarrow {\\bf C}}")#text(" is a fixed compactly supported, Riemann integrable function, show that")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\frac{1}{p} f( \\frac{\\log p}{\\log x} ) = \\int_0^\\infty f(t)\\ \\frac{dt}{t} + o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(iii) If ")#mi("{d \\geq 1}")#text(" is a fixed natural number and ")#mi("{f: (0,+\\infty)^d \\rightarrow {\\bf C}}")#text(" is a fixed compactly supported, Riemann integrable function, show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1,\\dots,p_d} \\frac{1}{p_1 \\dots p_d} f( \\frac{\\log p_1}{\\log x}, \\dots, \\frac{\\log p_d}{\\log x} )")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{(0,\\infty)^d} f(t_1,\\dots,t_d)\\ \\frac{dt_1 \\dots dt_d}{t_1 \\dots t_d} + o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(iv) Obtain analogues of (i)-(iii) when the sum over primes ")#mi("{p}")#text(" are replaced by the sum over integers ")#mi("{n}")#text(", but with factors of ")#mi("{\\frac{1}{p}}")#text(" replaced by ")#mi("{\\frac{\\Lambda(n)}{n \\log n}}")#text(" (with the convention that this expression vanishes at ")#mi("{n=0}")#text(").")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" An alternate way to phrase the above exercise is that the ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measures")]

#align(center)[#tao-fit-display[#mitex("\\sum_p \\frac{1}{p} \\delta_{\\frac{\\log p}{\\log x}}")]]

#text("on ")#mi("{(0,+\\infty)}")#text(" converge in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to the absolutely continuous measure ")#mi("{\\frac{dt}{t}}")#text(" in the limit ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{\\delta_t}")#text(" denotes the Dirac probability measure at ")#mi("{t}")#text(". Similarly for the Radon measures")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n\\log n} \\delta_{\\frac{\\log n}{\\log x}}.")]]

#text("To put this another way, the Radon measures ")#mi("{\\sum_p \\frac{\\log p}{p} \\delta_{\\log p}}")#text(" or ")#mi("{\\sum_n \\frac{\\Lambda(n)}{n} \\delta_{\\log n}}")#text(" behave like Lebesgue measure on dyadic intervals such as ")#mi("{[u, (1+\\varepsilon) u]}")#text(" for fixed ")#mi("{\\varepsilon > 0}")#text(" and large ")#mi("{u}")#text(". This is weaker than the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" that we will prove in later notes, which basically asserts the same statement but on the much smaller intervals ")#mi("{[u, u+\\varepsilon]}")#text(". (Statements such as the Riemann hypothesis make the same assertion on even finer intervals, such as ")#mi("{[u, u + \\exp( - (\\frac{1}{2}-\\varepsilon) u) ]}")#text(".) See ")#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("this previous blog post")]#text(" for some examples of this Radon measure perspective, which we will not emphasise in this set of notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Smooth numbers)")]#text(" ")#metadata(none) <tao-19b738c219c435150a1b>#text(" For any ")#mi("{x, z > 0}")#text(", let ")#mi("{S(x,z)}")#text(" denote the set of natural numbers less than ")#mi("{x}")#text(" which are ")#link("http://en.wikipedia.org/wiki/Smooth_number")[#mi("{z}")#text("-smooth")]#text(", in the sense that they have no prime factors larger than ")#mi("{z}")#text(".")

#list(
[#text("(i) Show that for any fixed ")#mi("{u > 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|S(x, x^{1/u})\\right| = (\\rho(u) + o(1)) x", block: true)]]

#text("where the ")#link("http://en.wikipedia.org/wiki/Dickman_function")[#text("Dickman function")]#text(" ")#mi("{\\rho(u)}")#text(" is defined by the alternating series")

#align(center)[#tao-fit-display[#mitex("\\rho(u) := 1 + \\sum_{j=1}^\\infty \\frac{(-1)^j}{j!} \\int_{[1,+\\infty)^j} 1_{t_1+\\dots+t_j \\leq u} \\frac{dt_1 \\dots dt_j}{t_1 \\dots t_j}")]]

#text("(note that for any given ")#mi("{u}")#text(" that only finitely many of the summands are non-zero; one can also view the ")#mi("{1}")#text(" term as the ")#mi("{j=0}")#text(" term of the summation after carefully working out what zero-dimensional spaces and empty products evaluate to). ")#emph[#text("Hint:")]#text(" Use the ")#link("http://en.wikipedia.org/wiki/Inclusion%E2%80%93exclusion_principle")[#text("inclusion-exclusion principle")]#text(" to remove the multiples of ")#mi("{p}")#text(" from ")#mi("{[1,x]}")#text(" for each prime ")#mi("{p > z}")#text(". This is a simple example of a ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve")]#text(", which we will study in more detail in later notes.")],
[#text("(ii) (Delay-differential equation) Show that ")#mi("{\\rho}")#text(" is continuous on ")#mi("{(0,+\\infty)}")#text(", continuously differentiable except at ")#mi("{u=1}")#text(", equals ")#mi("{1}")#text(" for ")#mi("{0 \\leq u \\leq 1}")#text(" and obeys the equation")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{du} \\rho(u) = - \\frac{1}{u} \\rho(u-1)")]]

#text("for ")#mi("{u > 1}")#text(". Give a heuristic justification for this equation by considering how ")#mi("{S(x,x^{1/u})}")#text(" varies with respect to small perturbations of ")#mi("{u}")#text(".")],
[#text("(iii) (Wirsing integral equation) Show that")

#align(center)[#tao-fit-display[#mitex("u \\rho(u) = \\int_0^u 1_{[0,1]}(t) \\rho(u-t)\\ dt")]]

#text("for all ")#mi("{u \\geq 0}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#mitex("u \\rho = 1_{[0,1]} * \\rho.")]]

#text("Give a heuristic justification for this equation by starting with a ")#mi("{x^{1/u}}")#text("-smooth number ")#mi("{n \\in [1,x]}")#text(" and considering a factor ")#mi("{n/p}")#text(", where ")#mi("{p}")#text(" is a prime factor of ")#mi("{n}")#text(" chosen at random with probability ")#mi("{j \\frac{\\log p}{\\log n}}")#text(" (if ")#mi("{p}")#text(" occurs ")#mi("{j}")#text(" times in the prime factorisation of ")#mi("{n}")#text(").")],
[#text("(iv) (Laplace transform) Show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\rho(u) e^{-su}\\ du = \\frac{1}{s} \\exp( - \\int_s^\\infty \\frac{e^{-t}}{t}\\ dt )")]]

#text("for all ")#mi("{s > 0}")#text(".")]
)
]

#text("To proceed further we will start using the Riemann zeta function ")#link(<tao-c0e9520306518bffa7ea>)[#text("(13)")]#text(" that made an appearance in the previous section. We again use the fundamental theorem of arithmetic ")#link(<tao-3c15dc2308570c62ec4a>)[#text("(19)")]#text(", this time to observe the ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product identity")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^s} = \\prod_p (\\sum_{j=0}^\\infty \\frac{1}{p^{sj}})")]]

#text("for any ")#mi("{s \\in {\\bf R}}")#text(" (where we allow both sides to be infinite). Indeed, by ")#link(<tao-3c15dc2308570c62ec4a>)[#text("(19)")]#text(", the truncated version")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\leq P} (\\sum_{j=1}^J \\frac{1}{p^{sj}})")]]

#text("of the right-hand side is the product of those ")#mi("{\\frac{1}{n^s}}")#text(" for which ")#mi("{n}")#text(" is the product of powers of primes up to ")#mi("{P}")#text(", by exponents that are at most ")#mi("{J}")#text(", and then by sending ")#mi("{P}")#text(" and ")#mi("{J}")#text(" to infinity via the monotone convergence theorem we obtain the claim. For ")#mi("{s>1}")#text(", the left-hand side converges to ")#mi("{\\zeta(s)}")#text(", and the geometric series ")#mi("{\\sum_{j=0}^\\infty \\frac{1}{p^{sj}}}")#text(" converges to ")#mi("{(1-\\frac{1}{p^s})^{-1}}")#text(", thus ")#metadata(none) <tao-43385991f0be5fed6db7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\prod_p (1 - \\frac{1}{p^s})^{-1} = \\zeta(s)")]]

#text("for all ")#mi("{s>1}")#text(".")#linebreak()#text(" The formula ")#link(<tao-43385991f0be5fed6db7>)[#text("(26)")]#text(" gives a fundamental relationship between the Riemann zeta function and the primes that can be manipulated and exploited in a number of ways. For instance, from ")#link(<tao-3a44788d006adcb566a2>)[#text("(11)")]#text(" we now have")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1 - \\frac{1}{p^s})^{-1} = \\frac{1}{s-1}+O(1)")]]

#text("for ")#mi("{s>1}")#text(".")#linebreak()#text(" Taking logarithms, we thus have ")#metadata(none) <tao-4030f0c0b99ba5e189b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("- \\sum_p \\log( 1 - \\frac{1}{p^s} ) = \\log \\zeta(s) = \\log \\frac{1}{s-1} + O( s-1 )")]]

#text("when ")#mi("{s > 1}")#text(" (note that ")#mi("{\\zeta(s)}")#text(" is clearly at least one). The logarithm here on the left-hand side is not so desirable, but we may remove it by using the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("- \\log (1 - \\frac{1}{p^s}) = \\frac{1}{p^s} + O( \\frac{1}{p^{2s}} )")]]

#text("and noting that ")#mi("{\\sum_p \\frac{1}{p^{2s}} \\leq \\sum_n \\frac{1}{n^2}}")#text(" is absolutely convergent, to conclude that ")#metadata(none) <tao-18ad7cdfebe8fc9e003d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\sum_p \\frac{1}{p^s} = \\log \\frac{1}{s-1} + O(1)")]]

#text("when ")#mi("{s > 1}")#text(" is bounded. Taking ")#mi("{s \\rightarrow 1}")#text(", and using monotone convergence, we recover Euler’s theorem ")#mi("{\\sum_p \\frac{1}{p} = +\\infty}")#text(", but ")#link(<tao-18ad7cdfebe8fc9e003d>)[#text("(28)")]#text(" gives more precise information. For instance we get a “cheap” version of Mertens’ second theorem, already anticipated by Euler:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 19 (Cheap second Mertens’ theorem)")]#text(" ")#metadata(none) <tao-a6b11d00651364ac58e3>#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{1}{p} \\ll \\log\\log x")]]

#text("for ")#mi("{x \\geq 10}")#text(".")
]

#emph[#text("Proof:")]#text(" We use a device known as ")#emph[#text("Rankin’s trick")]#text(" to compare a Dirichlet series with a natural or logarithmic mean. Namely, observe that whenever ")#mi("{1 \\leq n \\leq x}")#text(", one has ")#mi("{1 \\leq n^{1/\\log x} \\leq e}")#text(", so in particular ")#mi("{n^{1/\\log x} \\asymp 1}")#text(". This gives us the ability to insert or remove factors of ")#mi("{n^{1/\\log x}}")#text(" in sums up to ")#mi("{x}")#text(" while only losing constant factors; in particular")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{1}{p} \\asymp \\sum_{p \\leq x} \\frac{1}{p^{1+1/\\log x}} \\leq \\sum_p \\frac{1}{p^{1+1/\\log x}}.")]]

#text("The claim now follows from ")#link(<tao-18ad7cdfebe8fc9e003d>)[#text("(28)")]#text(". ")#mi("\\Box")#linebreak()#text(" While this bound is worse (by a factor of ")#mi("{e}")#text(") than what one could get in Theorem ")#link(<tao-091f39f5ce0570bc5337>)[#text("15")]#text(", Rankin’s trick will end up being useful later in some other contexts (again, in applications where losing a factor such as ")#mi("{e}")#text(" is acceptable).")#linebreak()#text(" We can get more mileage out of ")#link(<tao-4030f0c0b99ba5e189b6>)[#text("(27)")]#text(" by differentiating in ")#mi("{s}")#text(". Formally differentiating in ")#mi("{s}")#text(", we arrive at the identity ")#metadata(none) <tao-c9e835b3a12dc51302a1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\sum_p \\frac{\\log p}{p^s - 1} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("for all ")#mi("{s>1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Derive ")#link(<tao-c9e835b3a12dc51302a1>)[#text("(29)")]#text(" rigorously. (")#emph[#text("Hint:")]#text(" For fixed ")#mi("{s>1}")#text(" and small ")#mi("{\\varepsilon>0}")#text(", expand ")#mi("{\\log(1 - \\frac{1}{p^{s+\\varepsilon}})}")#text(" using Taylor series with remainder.)")
]

#text("Using the geometric series expansion")

#align(center)[#tao-fit-display[#mitex("\\frac{\\log p}{p^s - 1} = \\frac{\\log p}{p^s} + \\frac{\\log p}{p^{2s}} + \\frac{\\log p}{p^{3s}} + \\dots")]]

#text("and recalling the von Mangoldt function, we thus obtain the important identity ")#metadata(none) <tao-4cd0c492d897ef69a196>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^s} = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("for the Dirichlet series of ")#mi("{\\Lambda}")#text(", and for all ")#mi("{s>1}")#text(". (In fact this identity will hold for a wider range of ")#mi("{s}")#text(", but we will address this in later notes.) For comparison, a Taylor expansion of ")#link(<tao-4030f0c0b99ba5e189b6>)[#text("(27)")]#text(" gives the closely related identity ")#metadata(none) <tao-5aacae98463e7ba28903>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^s \\log n} = \\log \\zeta(s).")]]

#text("Indeed, ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(" is essentially the derivative of ")#link(<tao-5aacae98463e7ba28903>)[#text("(31)")]#text(" in ")#mi("{s}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Give an alternate proof of ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(" based on ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(". (")#emph[#text("Hint:")]#text(" expand out the product of ")#mi("{\\sum_n \\frac{\\Lambda(n)}{n^s}}")#text(" with ")#mi("{\\zeta(s)}")#text(" and collect terms.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" ")#metadata(none) <tao-d217316d88da9c9b9ddd>#text(" We have seen that the von Mangoldt function ")#mi("{\\Lambda}")#text(" obeys at least three useful identities: ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(", ")#link(<tao-5aacae98463e7ba28903>)[#text("(31)")]#text(" and ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(". (Not surprisingly, these identities are closely related to each other: ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(" is basically the derivative of ")#link(<tao-5aacae98463e7ba28903>)[#text("(31)")]#text(", which is the Dirichlet series transform of ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(".) It is because of these identities (and further related identities which we will see in later posts) that the von Mangoldt function is an extremely convenient proxy for the prime numbers in analytic number theory. Indeed, many question about primes in analytic number theory are most naturally tackled by converting them to a statement about the von Mangoldt function, by adding or subtracting the contribution of prime powers ")#mi("{p^j}")#text(" for ")#mi("{j>2}")#text(", which are typically of significantly lower order), in order to access identities such as ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(", ")#link(<tao-5aacae98463e7ba28903>)[#text("(31)")]#text(" or ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(".")
]

#text("From ")#link(<tao-3a44788d006adcb566a2>)[#text("(11)")]#text(", ")#link(<tao-fc613b4dfd6736a7bd26>)[#text("(18)")]#text(", ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(" we have ")#metadata(none) <tao-bac7bd5972ec6620439b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^s} = \\frac{1}{s-1} + O(1)")]]

#text("for ")#mi("{s>1}")#text(" (note the claim is trivial if ")#mi("{s-1}")#text(" is large).")#linebreak()#text(" This gives us a weaker version of Theorem ")#link(<tao-3bbb50f290900e9385d0>)[#text("13")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Cheap first Mertens’ theorem)")]#text(" ")#metadata(none) <tao-b37bb2890b4109acc224>#text(" Use ")#link(<tao-bac7bd5972ec6620439b>)[#text("(32)")]#text(" and Rankin’s trick to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{\\log p}{p} \\leq \\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} \\ll \\log x")]]

#text("for all ")#mi("{x \\geq 2}")#text(".")
]

#text("Thus far, the estimates coming from the Euler product of the zeta function have led to worse bounds than what the first and second Mertens’ theorems give us. But now we can combine the two together. Recall from ")#link(<tao-3a44788d006adcb566a2>)[#text("(11)")]#text(", ")#link(<tao-5aacae98463e7ba28903>)[#text("(31)")]#text(" that ")#metadata(none) <tao-184c926681179fdf7098>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\sum_n \\frac{\\Lambda(n)}{n^s \\log n} = -\\log(s-1) + O(s-1)")]]

#text("for ")#mi("{s>1}")#text(". We can compare this against ")#link(<tao-6bccb52d60bbaa199a43>)[#text("(25)")]#text(" by a variant of the Rankin trick. Namely, if we apply ")#link(<tao-184c926681179fdf7098>)[#text("(33)")]#text(" with ")#mi("{s = 1 + \\frac{1}{\\log x}}")#text(" for some large ")#mi("{x}")#text(", one obtains")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n \\log n} e^{-\\log n / \\log x} = \\log \\log x + O(\\frac{1}{\\log x})")]]

#text("and thus on subtracting ")#link(<tao-6bccb52d60bbaa199a43>)[#text("(25)")]

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n \\log n} ( e^{-\\log n / \\log x} - 1_{[0,1]}(\\frac{\\log n}{\\log x})) = - c_2 + O(\\frac{1}{\\log x}).")]]

#text("For any fixed ")#mi("{0 < \\varepsilon < 1 < N}")#text(", we see from Exercise ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("16")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^\\varepsilon \\leq n \\leq x^N} \\frac{\\Lambda(n)}{n \\log n} ( e^{-\\log n / \\log x} - 1_{[0,1]}(\\frac{\\log n}{\\log x}))")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\int_\\varepsilon^N (e^{-t} - 1_{[0,1]}(t)) \\frac{dt}{t} + o(1)", block: true)



#tao-math(" & = \\int_\\varepsilon^N \\frac{e^{-t}}{t}\\ dt - \\log \\frac{1}{\\varepsilon} + o(1).", block: true)
]

#text("From Mertens’ first theorem, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n < x^\\varepsilon} \\frac{\\Lambda(n)}{n \\log n} ( e^{-\\log n / \\log x} - 1_{[0,1]}(\\frac{\\log n}{\\log x}))")]]

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\sum_{n < x^\\varepsilon} \\frac{\\Lambda(n)}{n \\log n} \\frac{\\log n}{\\log x}", block: true)



#tao-math(" & \\ll\\frac{\\log x^\\varepsilon}{\\log x}", block: true)



#tao-math(" & = O(\\varepsilon)", block: true)
]

#text("while from Mertens’ second theorem and dyadic decomposition of ")#mi("{\\log n}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n > x^N} \\frac{\\Lambda(n)}{n \\log n} ( e^{-\\log n / \\log x} - 1_{[0,1]}(\\frac{\\log n}{\\log x}))")]]

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\sum_{k=0}^\\infty \\sum_{x^{2^k N} < n \\leq x^{2^{k+1}N}} \\frac{\\Lambda(n)}{n \\log n} e^{-\\log n / \\log x}", block: true)



#tao-math(" & \\ll \\sum_{k=0}^\\infty e^{-\\log x^{2^kN}/\\log x}", block: true)



#tao-math(" & \\ll e^{-N}.", block: true)
]

#text("Taking limits as ")#mi("{x \\rightarrow \\infty}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("-c_2 = \\int_\\varepsilon^N \\frac{e^{-t}}{t}\\ dt - \\log \\frac{1}{\\varepsilon} + O( \\varepsilon) + O(e^{-N})")]]

#text("for any ")#mi("{0 < \\varepsilon < N < \\infty}")#text(", hence on sending ")#mi("{N \\rightarrow \\infty}")#text(" and then ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("-c_2 = \\lim_{\\varepsilon \\rightarrow 0} \\int_\\varepsilon^\\infty \\frac{e^{-t}}{t} - \\log \\frac{1}{\\varepsilon}.")]]

#text("We can compute this limit explicitly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 24 (Exponential integral asymptotics)")]#text(" For sufficiently small ")#mi("{\\varepsilon}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\varepsilon^\\infty \\frac{e^{-t}}{t}\\ dt = \\log \\frac{1}{\\varepsilon} - \\gamma + O(\\varepsilon).")]]
]

#emph[#text("Proof:")]#text(" We start by using the identity ")#mi("{\\frac{1}{i} = \\int_0^1 x^{i-1}\\ dx}")#text(" to express the harmonic series ")#mi("{H_n := 1+\\frac{1}{2}+\\ldots+\\frac{1}{n}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("H_n = \\int_0^1 1 + x + \\ldots + x^{n-1}\\ dx")]]

#text("or on summing the geometric series")

#align(center)[#tao-fit-display[#mitex("H_n = \\int_0^1 \\frac{1-x^n}{1-x}\\ dx.")]]

#text("Since ")#mi("{\\int_0^{1-\\varepsilon/n} \\frac{1}{1-x} = \\log n + \\log \\frac{1}{\\varepsilon}}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("H_n - \\log n - \\log \\frac{1}{\\varepsilon} = \\int_0^1 \\frac{1_{[1-\\varepsilon/n,1]}(x) - x^n}{1-x}\\ dx;")]]

#text("making the change of variables ")#mi("{x = 1-\\frac{t}{n}}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("H_n - \\log n - \\log \\frac{1}{\\varepsilon} = \\int_0^n \\frac{1_{[0,\\varepsilon]}(t) - (1-\\frac{t}{n})^n}{t}\\ dt.")]]

#text("As ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{\\frac{1_{[0,\\varepsilon]}(t) - (1-\\frac{t}{n})^n}{t}}")#text(" converges pointwise to ")#mi("{\\frac{1_{[0,\\varepsilon]}(t) - e^{-t}}{t}}")#text(" and is pointwise dominated by ")#mi("{O( e^{-t} )}")#text(". Taking limits as ")#mi("{n \\rightarrow \\infty}")#text(" using dominated convergence and ")#link(<tao-af3ce03f6874c53162b7>)[#text("(14)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\gamma - \\log \\frac{1}{\\varepsilon} = \\int_0^\\infty \\frac{1_{[0,\\varepsilon]}(t) - e^{-t}}{t}\\ dt.")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\varepsilon \\frac{1 - e^{-t}}{t}\\ dt = \\int_0^\\varepsilon O(1)\\ dt = O(\\varepsilon),")]]

#text("the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-t} \\log t\\ dt = -\\gamma.")]]

#text("Conclude that if ")#mi("{\\Gamma(s)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", defined for ")#mi("{\\text{Re}(s)>0}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) := \\int_0^\\infty e^{-t} t^{s-1}\\ dt,")]]

#text("then one has ")#mi("{\\Gamma^{\\prime}(1)=-\\gamma}")#text(".")
]

#text("From this lemma we see that ")#metadata(none) <tao-f8d45c75a553ede2e061>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("c_2 = \\gamma,")]]

#text("thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n \\log n} = \\log\\log x + \\gamma + O(\\frac{1}{\\log x}).")]]

#text("This implies (using ")#link(<tao-909104cdb5b06af2606e>)[#text("(10)")]#text(") that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{p \\leq x} \\sum_{j=1}^\\infty \\frac{1}{j p^j}  & = \\log\\log x + \\gamma + O(\\frac{1}{\\log x}) + O(\\sum_{j \\geq 2} \\sum_{p > x^{1/j}} \\frac{1}{jp^j})", block: true)



#tao-math(" & = \\log\\log x + \\gamma + O(\\frac{1}{\\log x}) + \\sum_{j \\geq 2} O( \\sum_{n > \\max(2, x^{1/j})} \\frac{1}{n^j} )", block: true)



#tao-math(" & = \\log\\log x + \\gamma + O(\\frac{1}{\\log x}) + \\sum_{j \\geq 2} O( \\max(2,x^{1/j})^{-j+1} )", block: true)



#tao-math(" & = \\log\\log x + \\gamma + O(\\frac{1}{\\log x}) + \\sum_{j \\geq 2} O( \\min(2^{-j}, x^{-1/2} ) )", block: true)



#tao-math(" & = \\log\\log x + \\gamma + O(\\frac{1}{\\log x})", block: true)



#tao-math("- \\sum_{p \\leq x} \\log(1-\\frac{1}{p})  & = \\log\\log x + \\gamma + O(\\frac{1}{\\log x}).", block: true)
]

#text("Taking exponentials, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Third Mertens’ theorem)")]#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\leq x} (1 - \\frac{1}{p}) = \\frac{e^{-\\gamma} + O(\\frac{1}{\\log x})}{\\log x}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#text("Because of this theorem, the factors ")#mi("{e^\\gamma = 1.78107\\dots}")#text(" and ")#mi("{e^{-\\gamma} = 0.56145\\dots}")#text(" frequently arise in analytic prime number theory. We give two examples of this below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Let ")#mi("{\\rho}")#text(" be the Dickman function from Exercise ")#link(<tao-19b738c219c435150a1b>)[#text("18")]#text(". Show that ")#mi("{\\int_0^\\infty \\rho(u)\\ du = e^\\gamma}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" For any natural number ")#mi("{n}")#text(", define the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(" ")#mi("{\\phi(n)}")#text(" of ")#mi("{n}")#text(" to be the number of natural numbers less than ")#mi("{n}")#text(" that are coprime to ")#mi("{n}")#text(", or equivalently ")#mi("{\\phi(n)}")#text(" is the order of the multiplicative group ")#mi("{({\\bf Z}/n{\\bf Z})^\\times}")#text(" of ")#mi("{{\\bf Z}/n{\\bf Z}}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("(e^{-\\gamma} - o(1)) \\frac{n}{\\log\\log n} \\leq \\phi(n) \\leq n")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". ({")#emph[#text("Hint:")]#text(" treat the contribution of small primes ")#mi("{p \\leq \\log n}")#text(" and large primes ")#mi("{p>\\log n}")#text(" separately.) Show that ")#mi("{e^{-\\gamma}}")#text(" cannot be replaced here by any larger quantity. (This result is due to Landau.)")
]

#heading(level: 1)[#strong[#text(" — 3. The number of divisors — ")]]

#text("We now consider the asymptotics of the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]

#align(center)[#tao-fit-display[#mitex("\\tau(n) := \\sum_{d|n} 1")]]

#text("that counts the number of divisors of a given natural number ")#mi("{n}")#text(". Informally: how many divisors does one expect a typical large number ")#mi("{n}")#text(" to have? Remarkably, the answer turns out to depend on exactly on what one means by “typical”.")#linebreak()#text(" The first basic observation to make is that ")#mi("{\\tau}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative function")]#text(": ")#mi("{\\tau(nm) = \\tau(n) \\tau(m)}")#text(" whenever ")#mi("{n,m}")#text(" are coprime, since every divisor of ")#mi("{nm}")#text(" can be uniquely expressed as the product of a divisor of ")#mi("{n}")#text(" and a divisor of ")#mi("{m}")#text(". The same argument has an important generalisation: if ")#mi("{f,g: {\\bf N}\\rightarrow {\\bf C}}")#text(" are multiplicative functions, then the ")#link("http://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(" ")#mi("{f*g: {\\bf N} \\rightarrow {\\bf C}}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("f*g(n) := \\sum_{d|n} f(d) g(\\frac{n}{d})")]]

#text("is also multiplicative. The multiplicativity of the divisor function then follows from the identity")

#align(center)[#tao-fit-display[#mitex("\\tau = 1 * 1,")]]

#text("since the constant function ")#mi("{n \\mapsto 1}")#text(" is clearly multiplicative. For comparison, the identity ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(" can be written in this notation as ")#metadata(none) <tao-7cf246e7f6b0385d85dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("L = \\Lambda * 1")]]

#text("where ")#mi("{L(n) := \\log n}")#text(" is the logarithm function. The operation of Dirichlet convolution is basically a special case of the more familiar Fourier-analytic notion of ")#link("https://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(", if one views the natural numbers ")#mi("{{\\bf N}}")#text(" as a subset of the group ")#mi("{{\\bf Q}^\\times}")#text(" of non-zero rational numbers with multiplication as the group law. In particular, it is commutative, associative, and bilinear. Fourier analysis teaches us that it is often profitable to understand convolution via the Fourier transform; in this context, the counterpart of the Fourier transform becomes the operation of forming a ")#emph[#text("Dirichlet series")]#text(", which we will see more of later on.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Show that the Dirichlet convolution of two multiplicative functions is again multiplicative.")
]

#text("Returning to the divisor function, we begin with a crude bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 30 (Divisor bound)")]#text(" ")#metadata(none) <tao-039d927ee7a98f0a0f2c>#text(" We have ")#mi("{\\tau(n) = n^{o(1)}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Equivalently, we have ")#mi("{\\tau(n) \\ll n^\\varepsilon}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(" be fixed. Observe that for any prime power ")#mi("{p^j}")#text(", we have ")#mi("{\\tau(p^j) = j+1}")#text(". In particular, we see that ")#mi("{\\tau(p^j) \\leq p^{\\varepsilon j}}")#text(" whenever ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", and ")#mi("{j}")#text(" is a natural number. For the remaining values of ")#mi("{p}")#text(", we have ")#mi("{\\tau(p^j) \\ll p^{\\varepsilon j}}")#text(". By the multiplicativity of ")#mi("{\\tau}")#text(", we thus have ")#mi("{\\tau(n) \\ll n^\\varepsilon}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Obtain the sharper bound ")#mi("{\\tau(n) \\leq n^{O(1 / \\log\\log n )}}")#text(" for all ")#mi("{n \\geq 10}")#text(". (")#emph[#text("Hint:")]#text(" first establish that ")#mi("{\\tau(n) \\leq \\exp(\\exp(O(1/\\varepsilon))) n^\\varepsilon}")#text(" for any ")#mi("{\\varepsilon > 0}")#text(" by performing the proof of Lemma ")#link(<tao-039d927ee7a98f0a0f2c>)[#text("30")]#text(" more carefully, then optimise in ")#mi("{\\varepsilon}")#text(".) It was in fact established by Wigert (in 1907) that one in fact has ")#mi("{\\tau(n) \\leq n^{\\frac{\\log 2+o(1)}{\\log\\log n}}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and that the constant ")#mi("{\\log 2}")#text(" cannot be replaced by any smaller constant.")
]

#text("Now we consider the mean value of ")#mi("{\\tau}")#text(". We will take advantage of the general identity")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} f*g(n)  & = \\sum_{n \\leq x} \\sum_{d|n} f(d) g(\\frac{n}{d})", block: true)



#tao-math(" & = \\sum_{d,m: dm \\leq x} f(d) g(m)", block: true)
]

#text("for Dirichlet convolutions, and thus ")#metadata(none) <tao-eac3df746d7d7f0a8232>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\sum_{n \\leq x} f*g(n) = \\sum_d f(d) (\\sum_{m \\leq x/d} g(m)).")]]

#text("In fact we have already implicitly used this identity to prove Mertens’ first theorem (Theorem ")#link(<tao-3bbb50f290900e9385d0>)[#text("13")]#text("). A similar argument gives the variant ")#metadata(none) <tao-127c394dfe8bca2b95cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\sum_{n \\leq x} \\frac{f*g(n)}{n} = \\sum_{d \\leq x} \\frac{f(d)}{d} (\\sum_{m \\leq x/d} \\frac{g(m)}{m}).")]]

#linebreak()#text(" We can use this to control the summatory function and logarithmic sum of the divisor function. For instance, by applying ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" with ")#mi("{f=g=1}")#text(" followed by ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\tau(n)  & = \\sum_{d \\leq x} ( \\sum_{m \\leq x/d} 1 )", block: true)



#tao-math(" & = \\sum_{d \\leq x} (\\frac{x}{d} + O( 1 ))", block: true)
]

#text("and hence by ")#link(<tao-af3ce03f6874c53162b7>)[#text("(14)")]#text(" ")#metadata(none) <tao-a1d9890884c1b4b960c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\sum_{n \\leq x} \\tau(n) = x \\log x + O(x).")]]

#text("(We will improve the control on the error term here later in this section.) Similarly, from ")#link(<tao-127c394dfe8bca2b95cb>)[#text("(37)")]#text(" followed by ")#link(<tao-af3ce03f6874c53162b7>)[#text("(14)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\frac{\\tau(n)}{n}  & = \\sum_{d \\leq x} \\frac{1}{d} (\\sum_{m \\leq x/d} \\frac{1}{m})", block: true)



#tao-math(" & = \\sum_{d \\leq x} \\frac{1}{d} ( \\log\\frac{x}{d} + \\gamma + O( \\frac{d}{x} ) )", block: true)
]

#text("and thus by ")#link(<tao-a2f45baa601696ccfe19>)[#text("(16)")]#text(" and a brief calculation ")#metadata(none) <tao-b16f173eaf978090de28>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\sum_{n \\leq x} \\frac{\\tau(n)}{n} = P( \\log x ) + O(1)")]]

#text("for some quadratic polynomial ")#mi("{P}")#text(" with leading term ")#mi("{\\frac{1}{2} t^2}")#text(". Comparing these bounds with ")#link(<tao-718e649231fd95a3315a>)[#text("(9)")]#text(" and ")#link(<tao-4011393f356a69582a25>)[#text("(8)")]#text(", we arrive at the heuristic ")#mi("{\\tau(n)}")#text(" behaves (as a rough first approximation) like ")#mi("{\\log n}")#text(" “on the average”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 32")]#text(" ")#metadata(none) <tao-cd35a2426062b7d58fd4>#text(" One can justify the heuristic ")#mi("{\\tau(n) \\approx \\log n}")#text(" by the following non-rigorous probabilistic argument: for a typical large number ")#mi("{n}")#text(", each number ")#mi("{d \\leq n}")#text(" would be expected to divide ")#mi("{n}")#text(" with probability about ")#mi("{\\frac{1}{d}}")#text("; since ")#mi("{\\sum_{d \\leq n} \\frac{1}{d} \\sim \\log n}")#text(", the “expected value” of ")#mi("{\\tau(n)}")#text(" should thus be about ")#mi("{\\log n}")#text(". We will continue this heuristic argument later in this set of notes.")
]

#text("We now give a supporting justification for the heuristic ")#mi("{\\tau(n) \\approx \\log n}")#text(". Given any arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(", define the ")#emph[#text("Dirichlet series")]#text(" ")#mi("{{\\mathcal D}f(s)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}f(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s}")]]

#text("whenever the series is absolutely convergent (in some cases we will be able to extend the domain of definition of this series to other choices of ")#mi("{s}")#text(", but we will address this point later). For instance, we have from definition ")#link(<tao-c0e9520306518bffa7ea>)[#text("(13)")]#text(" of the Riemann zeta function that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} 1(s) = \\zeta(s)")]]

#text("when ")#mi("{s>1}")#text(", and more generally from ")#link(<tao-fc613b4dfd6736a7bd26>)[#text("(18)")]#text(" ")#metadata(none) <tao-a211145008e7ca177d69>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("{\\mathcal D} L^k(s) = (-1)^k \\zeta^{(k)}(s)")]]

#text("for any natural number ")#mi("{k}")#text(" and ")#mi("{s>1}")#text(", where we use ")#mi("{L : {\\bf N} \\rightarrow {\\bf R}^+}")#text(" to denote the logarithm function ")#mi("{L(n) := \\log n}")#text(". The identities ")#link(<tao-c9e835b3a12dc51302a1>)[#text("(29)")]#text(", ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(" similarly become ")#metadata(none) <tao-6ab9f1eb8f7d3388f4f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("{\\mathcal D} \\Lambda(s) = -\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")]]

#text("and ")#metadata(none) <tao-015f7e6bc5aeaf483724>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("{\\mathcal D} (\\Lambda/L)(s) = \\log \\zeta(s)")]]

#text("for ")#mi("{s>1}")#text(".")#linebreak()#text(" We record some basic properties of the Dirichlet series transform ")#mi("{{\\mathcal D}}")#text(", under a mild hypothesis on ")#mi("{f,g}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33 (Basic properties of Dirichlet series)")]#text(" ")#metadata(none) <tao-6160c5bb20b39c6a7cfc>#text(" Suppose that ")#mi("{f,g: {\\bf N} \\rightarrow {\\bf C}}")#text(" are arithmetic functions that are of at most subpolynomial growth in the sense that ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("f(n), g(n) \\ll n^{o(1)}")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#mitex("f(n), g(n) \\ll_\\varepsilon n^\\varepsilon")]]

#text("for all ")#mi("{\\varepsilon>0}")#text(".")

#list(
[#text("(i) (Existence and uniqueness) Show that ")#mi("{{\\mathcal D}(f), {\\mathcal D}(g)}")#text(" are well-defined for ")#mi("{s>1}")#text(", and that ")#mi("{{\\mathcal D}(f)={\\mathcal D}(g)}")#text(" for all ")#mi("{s>1}")#text(" if and only if ")#mi("{f=g}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{{\\mathcal D}(f) = {\\mathcal D}(g)}")#text(", first show that ")#mi("{f}")#text(" and ")#mi("{g}")#text(" agree at ")#mi("{1}")#text(", then proceed inductively.)")],
[#text("(ii) (Multiplication by logarithm transforms to differentiation) Show that ")#mi("{{\\mathcal D}(f)}")#text(" is differentiable for ")#mi("{s>1}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{ds} {\\mathcal D}(f) = - {\\mathcal D}(Lf).")]]

#text("(note that this generalizes ")#link(<tao-a211145008e7ca177d69>)[#text("(40)")]#text(", and also is consistent with ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("(41)")]#text(", ")#link(<tao-015f7e6bc5aeaf483724>)[#text("(42)")]#text(").")],
[#text("(iii) (Convolution transforms to multiplication) Show that ")#mi("{f*g}")#text(" is of subpolynomial and that")

#metadata(none) <tao-16ba121a04d5ad3b885f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("{\\mathcal D}(f*g)(s) = {\\mathcal D} f(s) {\\mathcal D}g(s)")]]

#text("for all ")#mi("{s>1}")#text(". Use this and ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(" to obtain an alternate proof of ")#link(<tao-4cd0c492d897ef69a196>)[#text("(30)")]#text(". We will make heavier use of ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(44)")]#text(" in later notes. Note that ")#link(<tao-16ba121a04d5ad3b885f>)[#text("(44)")]#text(" also helps explain the commutative and associative nature of Dirichlet convolution.")],
[#text("(iv) (Euler product) If ")#mi("{f}")#text(" is multiplicative, show that")

#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("{\\mathcal D} f(s) = \\prod_p \\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{js}}")]]

#text("for any ")#mi("{s>1}")#text(" (in particular, all products and sums here are absolutely convergent). If ")#mi("{f}")#text(" is ")#link("https://en.wikipedia.org/wiki/Completely_multiplicative_function")[#text("completely multiplicative")]#text(", which means that ")#mi("{f(nm) = f(n) g(m)}")#text(" for all ")#mi("{n,m \\geq 1}")#text(" (not necessarily coprime), simplify this to")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = \\prod_p (1 - \\frac{f(p)}{p})^{-1}.")]]],
[#text("(v) (Dirichlet series and logarithmic density) If the logarithmic density of ")#mi("{f}")#text(" exists and is equal to ")#mi("{\\alpha}")#text(", show that ")#mi("{(s-1) {\\mathcal D} f(s) \\rightarrow \\alpha}")#text(" as ")#mi("{s \\rightarrow 1^+}")#text(", or in other words that ")#mi("{{\\mathcal D} f(s) = \\frac{\\alpha}{s-1} + o(\\frac{1}{s-1})}")#text(" as ")#mi("{s \\rightarrow 1^+}")#text(". (")#emph[#text("Hint:")]#text(" ")#mi("{\\frac{1}{n^s} = \\frac{1}{n} \\int_n^\\infty \\frac{s-1}{x^{s}}\\ dx}")#text(".)")],
[#text("(vi) (Leibniz rule) Establish the ")#link("https://en.wikipedia.org/wiki/Product_rule")[#text("Leibniz rule")]

#align(center)[#tao-fit-display[#mitex("L(f*g) = (Lf) * g + f * (Lg)")]]

#text("and comment on how this is compatible with parts (i)-(iii) of this exercise.")]
)
]

#text("From Exercise ")#link(<tao-6160c5bb20b39c6a7cfc>)[#text("33")]#text("(iii) we have in particular that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} \\tau(s) = \\zeta(s)^2")]]

#text("so in particular from ")#link(<tao-3a44788d006adcb566a2>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} \\tau(s) = \\frac{1}{(s-1)^2} + O( \\frac{1}{s-1})")]]

#text("when ")#mi("{1 < s \\ll 1}")#text(". We can now use Rankin’s trick to upper bound the logarithmic sums ")#mi("{\\sum_{n\\leq x} \\frac{\\tau(n)}{n}}")#text(": ")#metadata(none) <tao-23670cabf30801a3160e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("\\sum_{n\\leq x} \\frac{\\tau(n)}{n} \\ll \\sum_n \\frac{\\tau(n)}{n^{1+1/\\log x}} \\ll \\log^2 x.")]]

#text("This is of course compatible with the more precise asymptotic ")#link(<tao-b16f173eaf978090de28>)[#text("(39)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Cheap upper bound on multiplicative functions)")]#text(" ")#metadata(none) <tao-b67dd8737744df681122>#text(" Let ")#mi("{k \\geq 0}")#text(" be a real number, and let ")#mi("{f}")#text(" be a multiplicative function such that ")#metadata(none) <tao-a3c357766d08bb8c3ee8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#tao-math("\\left|f(p)\\right| \\leq k + O_k( \\frac{1}{p} )", block: true)]]

#text("for all primes ")#mi("{p}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\left|f(p^j)\\right| \\ll_k j^{O_k(1)}", block: true)]]

#text("for all primes ")#mi("{p}")#text(" and ")#mi("{j \\geq 1}")#text(". Show that ")#mi("{f}")#text(" is of at most subpolynomial growth, and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\frac{\\left|f(n)\\right|}{n} \\ll_k \\log^k x", block: true)]]

#text("for ")#mi("{x \\geq 2}")#text(".")
]

#text("It is then natural to ask whether Dirichlet series methods can also confirm the bound ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(". In the spirit of Rankin’s trick, a first attempt would be to exploit the simple inequality ")#metadata(none) <tao-fc7cb0c881d10508371e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\leq \\sum_{n \\leq x} \\frac{x}{n} \\tau(n)")]]

#text("and use ether ")#link(<tao-23670cabf30801a3160e>)[#text("(46)")]#text(" or ")#link(<tao-b16f173eaf978090de28>)[#text("(39)")]#text(", but this gives the very weak upper bound ")#metadata(none) <tao-481ba4019c9d2710c338>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\ll x \\log^2 x")]]

#text("which is significantly inferior to ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(". The problem is that ")#link(<tao-fc7cb0c881d10508371e>)[#text("(48)")]#text(" is very inefficient when ")#mi("{n}")#text(" is much smaller than ")#mi("{x}")#text(". To do better, there is a standard rearrangement trick that moves much of the “mass” of a summatory function ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" to smaller values of ")#mi("{n}")#text(", effectively increasing the cutoff ")#mi("{1_{n \\leq x}}")#text(" and so replacing ")#link(<tao-fc7cb0c881d10508371e>)[#text("(48)")]#text(" with a less inefficient comparison. To describe this rearrangement trick, we return to the fundamental identity ")#link(<tao-7e96deb41db0db73f454>)[#text("(20)")]#text(" and rearrange it as")

#align(center)[#tao-fit-display[#mitex("1 = \\frac{1}{\\log x} ( \\log \\frac{x}{n} + \\sum_{d|n} \\Lambda(d) )")]]

#text("which allows us to rewrite an arbitrary summatory function ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" for some ")#mi("{x > 1}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n) = \\frac{1}{\\log x} ( \\sum_{n \\leq x} f(n) \\log \\frac{x}{n} + \\sum_{n \\leq x} f(n) (\\sum_{d|n} \\Lambda(d)) ).")]]

#text("For the latter sum, we write ")#mi("{n = dm}")#text(" and interchange summations to obtain (after replacing ")#mi("{d,m}")#text(" with ")#mi("{d,n}")#text(") the rearrangement identity ")#metadata(none) <tao-7b83ad20072c894d1527>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#mitex("\\sum_{n \\leq x} f(n) = \\frac{1}{\\log x} \\sum_{n \\leq x} ( f(n) \\log \\frac{x}{n} + \\sum_{d \\leq x/n} \\Lambda(d) f(dn) ).")]]

#text("The expression in parentheses can be viewed as a weighted version of ")#mi("{f(n)}")#text(", with the weight tending to be larger for small ")#mi("{n}")#text(" than for large ")#mi("{n}")#text(". Because of this reweighting, if one applies Rankin’s trick to bound the sum on the right-hand side, one can often obtain an upper bound on ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" that recovers the loss of ")#mi("{\\log x}")#text(" that would occur if one applied Rankin’s trick directly. For instance, suppose we take ")#mi("{f(n)=\\tau(n)}")#text(". Since ")#mi("{\\log \\frac{x}{n} \\ll \\frac{x}{n}}")#text(", we conclude from ")#link(<tao-b16f173eaf978090de28>)[#text("(39)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x} \\sum_{n \\leq x} \\tau(n) \\log \\frac{x}{n} \\ll x \\log x")]]

#text("Now we turn to the sum ")#mi("{\\frac{1}{\\log x} \\sum_{n \\leq x} \\sum_{d \\leq x/n} \\Lambda(d) \\tau(dn)}")#text(". Here we use the bound ")#mi("{\\tau(dn) \\leq \\tau(d) \\tau(n)}")#text(" to bound this by ")#mi("{\\frac{1}{\\log x} \\sum_{n \\leq x} \\tau(n) \\sum_{d \\leq x/n} \\Lambda(d) \\tau(d)}")#text(". Using the Chebyshev bound (Proposition ")#link(<tao-43b68e0e178454bb7e96>)[#text("12")]#text("), together with some crude bound to control the contribution of prime powers, one can show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq y} \\Lambda(d) \\tau(d) \\ll y")]]

#text("for any ")#mi("{y \\geq 1}")#text(" (the bound is trivial for ")#mi("{y < 2}")#text("), hence we can bound this contribution by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{1}{\\log x} \\sum_{n \\leq x} \\tau(n) x / n,")]]

#text("which by ")#link(<tao-23670cabf30801a3160e>)[#text("(46)")]#text(" gives the bound ")#mi("{O(x \\log x)}")#text(", which is consistent with ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(" (though the bounds are weaker).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Cheap upper bound for summatory functions)")]#text(" ")#metadata(none) <tao-1ee85ee1c94ef46b6455>#text(" With ")#mi("{k, f}")#text(" as in Exercise ")#link(<tao-b67dd8737744df681122>)[#text("34")]#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n) \\ll_k x \\log^{k-1} x")]]

#text("for ")#mi("{x \\geq 2}")#text(".")
]

#text("We continue the analysis of the divisor function. Even though ")#mi("{\\tau(n)}")#text(" behaves like ")#mi("{\\log n}")#text(" on the average, it can fluctuate to be much larger or much smaller than this value. For instance, ")#mi("{\\tau(n)}")#text(" equals ")#mi("{2}")#text(" when ")#mi("{n}")#text(" is prime, and when ")#mi("{n}")#text(" is odd, ")#mi("{\\tau(2n)}")#text(" is twice as large as ")#mi("{\\tau(n)}")#text(", even though ")#mi("{\\log(2n)}")#text(" and ")#mi("{\\log n}")#text(" are roughly the same size. A further hint of the irregularity of distribution can be seen by considering the ")#emph[#mi("{k^{th}}")#text(" moments")]#text(" ")#mi("{\\sum_{n \\leq x} \\frac{\\tau^k(n)}{n}}")#text(" and ")#mi("{\\sum_{n \\leq x} \\tau^k(n)}")#text(" of ")#mi("{n}")#text(" for natural numbers ")#mi("{k \\geq 0}")#text(". The function ")#mi("{\\tau^k}")#text(" is multiplicative with ")#mi("{\\tau^k(p) = 2^k}")#text(" for every prime ")#mi("{p}")#text(". From Exercise ")#link(<tao-b67dd8737744df681122>)[#text("34")]#text(" and Exercise ")#link(<tao-1ee85ee1c94ef46b6455>)[#text("35")]#text(" we have the upper bounds")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\tau^k(n)}{n} \\ll_k \\log^{2^k} x")]]

#text("and ")#metadata(none) <tao-06bee518a7a1cf4dd557>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#mitex("\\sum_{n \\leq x} \\tau^k(n) \\ll_k x \\log^{2^k-1} x")]]

#text("for all ")#mi("{x \\geq 2}")#text(", suggesting that ")#mi("{\\tau^k(n)}")#text(" behaves like ")#mi("{\\log^{2^k-1} n}")#text(" on average. This may seem at first glance to be incompatible with the heuristic that ")#mi("{\\tau(n)}")#text(" behaves like ")#mi("{\\log n}")#text(" on the average, but what is happening here is that ")#mi("{\\tau(n)}")#text(" can occasionally be much larger than ")#mi("{\\log n}")#text(", which does not significantly affect the mean of ")#mi("{\\tau(n)}")#text(", but does affect higher moments with ")#mi("{k > 1}")#text(". (Continuing Remark ")#link(<tao-cd35a2426062b7d58fd4>)[#text("32")]#text(", the issue here is that the events “")#mi("{d}")#text(" divides ")#mi("{n}")#text("” can be highly correlated with each other as ")#mi("{d}")#text(" varies, due to common factors between different choices of ")#mi("{d}")#text(".) In fact, the ")#emph[#text("typical")]#text(" value (in the sense of median, rather than mean) of ")#mi("{\\tau(n)}")#text(" is not ")#mi("{\\log n}")#text(" or ")#mi("{\\log^{2^k-1} n}")#text(", but is in fact ")#mi("{\\log^{\\log 2+o(1)} n}")#text(". See Section ")#link(<tao-0228b04eac39d6751c8f>)[#text("4")]#text(" below.")#linebreak()#text(" We can be more precise on the mean behaviour of ")#mi("{\\tau^k}")#text(", by establishing the following variant of Exercise ")#link(<tao-b67dd8737744df681122>)[#text("34")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 36 (Mean values of divisor-type multiplicative functions)")]#text(" ")#metadata(none) <tao-2f52d2e69eecafc262ca>#text(" Let ")#mi("{k \\geq 0}")#text(" be a natural number, and let ")#mi("{f}")#text(" be a multiplicative function obeying the estimates ")#metadata(none) <tao-5db88cc1b7a53c61b0db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#mitex("f(p) = k + O_k( \\frac{1}{p} )")]]

#text("for all primes ")#mi("{p}")#text(", and")

#align(center)[#tao-fit-display[#mitex("f(p^j) = O_k(j^{O_k(1)})")]]

#text("for all primes ")#mi("{p}")#text(" and all ")#mi("{j \\geq 1}")#text(". Let ")#mi("{{\\mathfrak S} = {\\mathfrak S}_{k,f}}")#text(" denote the ")#emph[#text("singular series")]#text(" ")#metadata(none) <tao-544ea986dba899d5db95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(53)")])
#mitex("{\\mathfrak S} := \\prod_p (1-\\frac{1}{p})^k (1 + \\frac{f(p)}{p} + \\frac{f(p^2)}{p^2} + \\dots ).")]]

#text("Note from Taylor expansion that")

#align(center)[#tao-fit-display[#mitex("(1-\\frac{1}{p})^k (1 + \\frac{f(p)}{p} + \\frac{f(p^2)}{p^2} + \\dots ) = 1 + O_k( \\frac{1}{p^2} )")]]

#text("so ")#mi("{{\\mathfrak S}}")#text(" is finite (though it may vanish, if one of its factors vanishes), with ")#mi("{{\\mathfrak S} = O_k(1)}")#text(".")

#list(
[#text("(i) If ")#mi("{k \\geq 0}")#text(", then one has")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = \\frac{\\mathfrak S}{(s-1)^k} + O_k( 1 + \\frac{1}{(s-1)^{k-1}} )")]]

#text("for all ")#mi("{s>1}")#text(".")],
[#text("(ii) If ")#mi("{k \\geq 0}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n} = \\frac{1}{k!} {\\mathfrak S} \\log^k x + O_k( \\log^{k-1}(2+x) )")]]

#text("for ")#mi("{x \\geq 1}")#text(".")],
[#text("(iii) If ")#mi("{k \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) = \\frac{1}{(k-1)!} {\\mathfrak S} \\log^{k-1} x + O_k( \\log^{k-2}(2+x) )")]]

#text("for ")#mi("{x \\geq 1}")#text(".")]
)
]

#text("Note that the ")#mi("{k=2}")#text(" case of this proposition gives (a slightly weaker form of) the above estimates for ")#mi("{\\tau}")#text(", since in that case ")#mi("{{\\mathfrak S}=1}")#text(". Comparing with ")#link(<tao-718e649231fd95a3315a>)[#text("(9)")]#text(", ")#link(<tao-a2f45baa601696ccfe19>)[#text("(16)")]#text(", ")#link(<tao-fc613b4dfd6736a7bd26>)[#text("(18)")]#text(" we see that ")#mi("{f}")#text(" behaves approximately like ")#mi("{\\frac{1}{(k-1)!} {\\mathfrak S} \\log^k x}")#text(" on the average for ")#mi("{k \\geq 1}")#text(". The hypotheses on this theorem may be relaxed somewhat; see Exercise ")#link(<tao-1248e893d3faf0dec4a2>)[#text("38")]#text(" below.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" For brevity we omit the dependence of implicit constants on ")#mi("{k}")#text(". We begin with (i). If ")#mi("{s-1 \\gg 1}")#text(", then from ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(45)")]#text(" and crude bounds we have ")#mi("{{\\mathcal D} f(s) = O(1)}")#text(", which suffices, so we will assume that ")#mi("{s}")#text(" is sufficiently close to ")#mi("{1}")#text(". From ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(45)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = \\prod_p (1-\\frac{1}{p^s})^{-k} \\gamma_p(s)")]]

#text("where ")#mi("{\\gamma_p(s) := (1-\\frac{1}{p^s})^{k} \\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{sj}}}")#text(". For ")#mi("{s}")#text(" close to ")#mi("{1}")#text(", we see from applying the chain rule and Taylor expansion that")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{ds} \\gamma_p(s) = O( \\frac{\\log p}{p^2} )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\gamma_p(s) = (\\gamma_p(1) + O( (s-1) \\frac{\\log p}{p^2} ))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\gamma_p(1) := (1-\\frac{1}{p})^k (1 + \\frac{f(p)}{p} + \\frac{f(p^2)}{p^2} + \\dots ) = 1 + O(\\frac{1}{p^2} ).")]]

#text("Since ")#mi("{\\sum_p \\frac{\\log p}{p^2} \\leq \\sum_n \\frac{\\log n}{n^2}}")#text(" is convergent, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) = (\\prod_p (1 - \\frac{1}{p^s})^{-k}) ({\\mathfrak S} + O( s-1 ) ),")]]

#text("and the claim follows from ")#link(<tao-43385991f0be5fed6db7>)[#text("(26)")]#text(".")#linebreak()#text(" To prove (ii) we induct on ")#mi("{k}")#text(". First we establish the base case ")#mi("{k=0}")#text(" of (ii). From ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(45)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{f(n)}{n} = {\\mathfrak S}")]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n>x} \\frac{f(n)}{n} = O( \\frac{1}{\\log x} ).")]]

#text("But from ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(45)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\frac{\\left|f(n)\\right|}{n^{2/3}} = O(1)", block: true)]]

#text("(for instance), and the claim follows.")#linebreak()#text(" Now suppose that ")#mi("{k \\geq 1}")#text(" and the claim (ii) has already been proven for ")#mi("{k-1}")#text(". We let ")#mi("{g}")#text(" be the multiplicative function with")

#align(center)[#tao-fit-display[#mitex("g(p^j) := f(p^j) - f(p^{j-1})")]]

#text("for primes ")#mi("{p}")#text(" and ")#mi("{j \\geq 1}")#text(", then one easily verifies that ")#mi("{f = 1*g}")#text(". Note that ")#mi("{g}")#text(" satisfies the same hypotheses as ")#mi("{f}")#text(", but with ")#mi("{k}")#text(" replaced by ")#mi("{k-1}")#text(". A brief calculation shows that")

#align(center)[#tao-fit-display[#mitex("(1 - \\frac{1}{p})^{-1} (1 + \\frac{g(p)}{p} + \\frac{g(p^2)}{p^2} + \\dots) = 1 + \\frac{f(p)}{p} + \\frac{f(p^2)}{p^2} + \\dots")]]

#text("and thus ")#mi("{{\\mathfrak S}_{k-1,g} = {\\mathfrak S}_{k,f} = {\\mathfrak S}}")#text(". From ")#link(<tao-127c394dfe8bca2b95cb>)[#text("(37)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n} = \\sum_{d \\leq x} \\frac{1}{d} (\\sum_{m \\leq x/d} \\frac{g(m)}{m})")]]

#text("and thus by induction hypothesis")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n} = \\sum_{d \\leq x} \\frac{1}{d} (\\frac{1}{(k-1)!} {\\mathfrak S} \\log^{k-1}(x/d) + O( \\log^{k-2}(2 + x/d) )).")]]

#text("From Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{\\log^{k-1}(x/d)}{d} = \\frac{1}{k} \\log^k x + O( \\log^{k-1}(2+x) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{\\log^{k-2}(2+x/d)}{d} \\ll \\log^{k-1}(2+x)")]]

#text("and the claim (ii) follows.")#linebreak()#text(" Finally, we prove (iii). Let ")#mi("{k \\geq 1}")#text("; if ")#mi("{k>1}")#text(", we assume inductively that (iii) is established for ")#mi("{k-1}")#text(". Let ")#mi("{g}")#text(" be as before. From ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) = \\sum_{d \\leq x} \\frac{g(d)}{d} (\\frac{1}{x/d} \\sum_{m \\leq x/d} 1)")]]

#text("and thus by ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\sum_{n \\leq x} f(n) = \\sum_{d \\leq x} \\frac{g(d)}{d} + O( \\frac{1}{x} \\sum_{d \\leq x} \\left|g(d)\\right| ).", block: true)]]

#text("From (ii) we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{g(d)}{d} = \\frac{1}{(k-1)!} {\\mathfrak S} \\log^{k-1}(x) + O( \\log^{k-2}(2 + x) ).")]]

#text("The error term ")#tao-math("{\\frac{1}{x} \\sum_{d \\leq x} \\left|g(d)\\right|}", block: false)#text(" can be treated by the induction hypothesis when ")#mi("{k > 1}")#text(", giving the claim. When ")#mi("{k=1}")#text(", we instead use the Rankin trick and bound")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\sum_{d \\leq x} \\left|g(d)\\right| \\leq \\frac{1}{x^{1/3}} \\sum_n \\frac{\\left|g(n)\\right|}{n^{2/3}}", block: true)]]

#text("and use ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(45)")]#text(" to bound ")#tao-math("{\\sum_n \\frac{\\left|g(n)\\right|}{n^{2/3}} = O(1)}", block: false)#text(" as before, giving the claim. ")#mi("\\Box")#linebreak()#text(" Thus for instance we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\tau^k(n) = \\frac{1}{(2^k-1)!} {\\mathfrak S}_k \\log^{2^k-1} x + O_k( \\log^{2^k-2}(2+x) )")]]

#text("for any ")#mi("{k \\geq 1}")#text(", where ")#mi("{0 < {\\mathfrak S}_k < \\infty}")#text(" is the quantity")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_k := \\prod_p (1-\\frac{1}{p})^{-2^k} (1 + \\frac{2^k}{p} + \\frac{3^k}{p^2} + \\dots ).")]]

#text("Among other things, this shows that ")#mi("{\\tau(n)}")#text(" can be larger than any fixed power of ")#mi("{\\log n}")#text(" for arbitrarily large ")#mi("{n}")#text("; compare with Lemma ")#link(<tao-039d927ee7a98f0a0f2c>)[#text("30")]#text(".")#linebreak()#text(" A more accurate description of the distribution of ")#mi("{\\tau(n)}")#text(" is that ")#mi("{\\log \\tau(n)}")#text(" for ")#mi("{n \\leq x}")#text(" is asymptotically distributed in the limit ")#mi("{x \\rightarrow \\infty}")#text(" like a gaussian random variable with mean and variance comparable to ")#mi("{\\log\\log x}")#text("; see Section ")#link(<tao-0228b04eac39d6751c8f>)[#text("4")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-33ef130f13091aaf8de2>#text(" Let ")#mi("{\\mu^2}")#text(" be the arithmetic function defined by setting ")#mi("{\\mu^2(n) := 1}")#text(" when ")#mi("{n}")#text(" is ")#link("http://en.wikipedia.org/wiki/Square-free_integer")[#text("squarefree")]#text(" (that is, ")#mi("{n}")#text(" is not divisible by any perfect square other than ")#mi("{1}")#text(") and zero otherwise; the reason for the notation ")#mi("{\\mu^2}")#text(" will be given later. Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\mu^2(n) = \\frac{1}{\\zeta(2)} + O( \\frac{1}{\\log x} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{\\mu^2(n)}{n} = \\frac{1}{\\zeta(2)} + O( \\frac{1}{\\log x})")]]

#text("for ")#mi("{x > 2}")#text(". Thus, the square-free numbers have natural and logarithmic density ")#mi("{\\frac{1}{\\zeta(2)}}")#text(". It can be shown by a variety of methods that ")#mi("{\\zeta(2) = \\frac{\\pi^2}{6}}")#text(", although we will not use this fact here. The error term ")#mi("{O( \\frac{1}{\\log x})}")#text(" may also be improved significantly (as we shall see when we turn to sieve-theoretic methods).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" ")#metadata(none) <tao-1248e893d3faf0dec4a2>#text(" The purpose of this exercise is to give an alternate derivation of parts (ii) and (iii) of Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(" that does not rely so strongly on ")#mi("{k}")#text(" being an integer; it also allows ")#mi("{f(p)}")#text(" to only be close to ")#mi("{k/p}")#text(" on average, rather than in the pointwise sense. The arguments here are from Appendix A.2 ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(", which are in turn based on ")#link("http://www.ams.org/mathscinet-getitem?mr=131389")[#text("this paper of Wirsing")]#text(".")

#list(
[#text("(i) Let ")#mi("{k, f}")#text(" be as in Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(", and define ")#mi("{M_f(x) := \\sum_{n \\leq x} \\frac{f(n)}{n}}")#text(". By using ")#link(<tao-7b83ad20072c894d1527>)[#text("(50)")]#text(" with ")#mi("{f(n)}")#text(" replaced by ")#mi("{f(n)/n}")#text(", establish the integral equation")

#align(center)[#tao-fit-display[#mitex("M_f(x) = \\frac{k+1}{\\log x} \\int_1^x M_f(t) \\frac{dt}{t} + O_k( \\log^{k-1}(2+x) )")]]

#text("for all ")#mi("{x \\geq 1}")#text(", and deduce that")

#align(center)[#tao-fit-display[#mitex("M_f(x) = c \\log^k x + O_k( \\log^{k-1}(2+x) )")]]

#text("for all ")#mi("{x \\geq 1}")#text(" and some ")#mi("{c}")#text(" independent of ")#mi("{x}")#text(". Then use part (i) of Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(" to deduce that ")#mi("{c = {\\mathfrak S}/k!}")#text(", thus establishing part (ii) of Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(".")],
[#text("(ii) Assume the following form of the prime number theorem: ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + O(x/\\log x)}")#text(" for all ")#mi("{x \\geq 2}")#text(". By using ")#link(<tao-7b83ad20072c894d1527>)[#text("(50)")]#text(" for ")#mi("{f(n)}")#text(", establish part (iii) of Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(".")],
[#text("(iii) Extend Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(" to the case when ")#mi("{k \\geq 0}")#text(" is real rather than integer (replacing factorials by Gamma functions as appropriate), and ")#link(<tao-5db88cc1b7a53c61b0db>)[#text("(52)")]#text(" is replaced by ")#mi("{\\sum_{p \\leq x} f(p) \\log p = k x + O_k(x/\\log x)}")#text(" for all ")#mi("{x \\geq 10}")#text(". (For part (ii) of Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text(", one can weaken ")#link(<tao-5db88cc1b7a53c61b0db>)[#text("(52)")]#text(" further to ")#mi("{\\sum_{p \\leq x} \\frac{f(p) \\log p}{p} = k \\log x + O_k(1)}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\phi(n)}{n} = \\frac{1}{\\zeta(2)} x + O( x / \\log x )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\phi(n) = \\frac{1}{2\\zeta(2)} x^2 + O( x^2 / \\log x )")]]

#text("for any ")#mi("{x>2}")#text(". (Hint: the first estimate can be used to derive the second.) Conclude that the proportion of pairs ")#mi("{(n,m)}")#text(" of natural numbers in the square ")#mi("{\\{ (n,m) \\in {\\bf N}^2: n,m \\leq x\\}}")#text(" which are coprime converges to ")#mi("{\\frac{1}{\\zeta(2)} = \\frac{6}{\\pi^2}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Let ")#mi("{p}")#text(" be a prime, and let ")#mi("{a\\ (p)}")#text(" be a residue class mod ")#mi("{p}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (p)} \\tau(n) = \\frac{p-1}{p^2} x \\log x + O(x)")]]

#text("when ")#mi("{a \\neq 0\\ (p)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (p)} \\tau(n) = \\frac{2p-1}{p^2} x \\log x + O(x)")]]

#text("when ")#mi("{a = 0\\ (p)}")#text(". Give an intuitive explanation as to why the second estimate is roughly twice as large as the first.")
]

#text("We now present a basic method to improve upon the estimate ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(", namely the ")#link("https://en.wikipedia.org/wiki/Dirichlet_hyperbola_method")[#text("Dirichlet hyperbola method")]#text(". The point here is that the error term in ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" is much stronger for large ")#mi("{x}")#text(" than for small ")#mi("{x}")#text(", so one would like to rearrange the proof of ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(" so that ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" is only used in the former case and not the latter. To do this, we decompose")

#align(center)[#tao-fit-display[#mitex("1 = 1_{>\\sqrt{x}} + 1_{\\leq \\sqrt{x}}")]]

#text("where ")#mi("{1_{>\\sqrt{x}}(n) := 1_{n > \\sqrt{x}}}")#text(" and ")#mi("{1_{\\leq \\sqrt{x}}(n) := 1_{n \\leq \\sqrt{x}}}")#text(", so that ")#mi("{\\tau(n)}")#text(" may be decomposed as")

#align(center)[#tao-fit-display[#mitex("\\tau = 1_{>\\sqrt{x}} * 1_{>\\sqrt{x}} + 2 \\times 1_{>\\sqrt{x}} * 1_{\\leq \\sqrt{x}} + 1_{\\leq \\sqrt{x}} * 1_{\\leq \\sqrt{x}}.")]]

#text("Actually, it is traditional to rearrange this a bit as the identity ")#metadata(none) <tao-123fa41e68313e4b53c8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#mitex("\\tau = 1_{>\\sqrt{x}} * 1_{>\\sqrt{x}} + 2 \\times 1_{\\leq \\sqrt{x}} * 1 - 1_{\\leq \\sqrt{x}} * 1_{\\leq \\sqrt{x}}.")]]

#text("This decomposition is convenient for improving ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(" for two reasons. Firstly, ")#mi("{1_{>\\sqrt{x}} * 1_{>\\sqrt{x}}}")#text(" is supported on ")#mi("{(x,+\\infty)}")#text(" and thus makes no contribution to ")#mi("{\\sum_{n \\leq x} \\tau(n)}")#text(". At the other extreme, ")#mi("{1_{\\leq \\sqrt{x}} * 1_{\\leq \\sqrt{x}}}")#text(" is supported in ")#mi("{[1,x]}")#text(" and so the restriction ")#mi("{n \\leq x}")#text(" may be removed here, simplifying the sum substantially:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1_{\\leq \\sqrt{x}} * 1_{\\leq \\sqrt{x}}(n) = \\sum_n 1_{\\leq \\sqrt{x}} * 1_{\\leq \\sqrt{x}}(n) = (\\sum_n 1_{\\leq \\sqrt{x}}(n))^2.")]]

#text("For the final sum ")#mi("{1_{\\leq \\sqrt{x}} * 1}")#text(", we use ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" and ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" as before, to conclude that ")#metadata(none) <tao-acdabe7a2f8d8888ab05>

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\tau(n)  & = 2 \\sum_{d \\leq \\sqrt{x}} \\sum_{n \\leq x/d} 1 - (\\sum_{n \\leq \\sqrt{x}} 1)^2", block: true, numbering: n => [#text("(55)")])



#tao-math(" & = 2 \\sum_{d \\leq \\sqrt{x}} (\\frac{x}{d} + O(1)) - (\\sqrt{x} + O(1))^2", block: true)



#tao-math(" & = 2 \\sum_{d \\leq \\sqrt{x}} \\frac{x}{d} - x+ O( \\sqrt{x} ).", block: true)
]

#text("By ")#link(<tao-af3ce03f6874c53162b7>)[#text("(14)")]#text(", we thus obtain an improved version of ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(": ")#metadata(none) <tao-9d83d740d78074f607ff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(56)")])
#mitex("\\sum_{n \\leq x} \\tau(n) = x\\log x + (2\\gamma - 1)x + O(\\sqrt{x}).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" The Dirichlet hyperbola method may be visualised geometrically as follows, in a fashion that explains the terminology “hyperbola method”. The sum ")#mi("{\\sum_{n \\leq x}\\tau(n) = \\sum_{d \\leq x} \\sum_{n \\leq x/d} 1}")#text(" can be interpreted as the number of lattice points (that is to say, elements of ")#mi("{{\\bf N}^2}")#text(") lying underneath the hyperbola ")#mi("{\\{ (a,b): ab \\leq x \\}}")#text(". The proof of ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(38)")]#text(" basically proceeded to count these lattice points by summing up the contribution of each column separately; this was an efficient process for the columns close to the ")#mi("{y}")#text("-axis, but led to relatively large error terms for columns far away from the ")#mi("{y}")#text("-axis. Symmetrically, one could proceed by summing by rows, which is efficient for rows close to the ")#mi("{x}")#text("-axis, but not far from that axis. The hyperbola method splits the difference between these two counting procedures, counting rows within ")#mi("{\\sqrt{x}}")#text(" of the ")#mi("{x}")#text("-axis and columns within ")#mi("{\\sqrt{x}}")#text(" of the ")#mi("{y}")#text("-axis, and then removing one copy of the square ")#mi("{[0,\\sqrt{x}]^2}")#text(" to correct for it being double-counted. The estimation of this lattice point problem can be made more precise still by more sophisticated decompositions and approximations of the hyperbola, but we will not discuss this problem (known as the ")#link("http://en.wikipedia.org/wiki/Divisor_summatory_function#Dirichlet.27s_divisor_problem")[#text("Dirichlet divisor problem")]#text(") here.")#linebreak()#text(" From an algebraic perspective, it is the identity ")#link(<tao-123fa41e68313e4b53c8>)[#text("(54)")]#text(", decomposing ")#mi("{\\tau}")#text(" into Dirichlet convolutions of expressions with good spatial support properties, that is the key to the successful application of the hyperbola method. In later posts we will encounter more sophisticated identities that decompose various arithmetic functions (such as the von Mangoldt function ")#mi("{\\Lambda}")#text(") into similar convolutions of spatially localised expressions. Unfortunately these identities are not as easy to visualise geometrically as the hyperbola method identity, as the corresponding geometric picture often takes place in three or higher dimensions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" Define the third divisor function ")#mi("{\\tau_3}")#text(" by ")#mi("{\\tau_3 := 1 * 1 * 1}")#text(", or equivalently ")#mi("{\\tau_3(n) = \\sum_{d_1,d_2,d_3: d_1 d_2 d_3 = n} 1}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau_3(n) = xP(\\log x) + O( x^{2/3} \\log x)")]]

#text("for all ")#mi("{x \\geq 2}")#text(" and some polynomial ")#mi("{P(t)}")#text(" with leading term ")#mi("{\\frac{1}{2} t^2}")#text(". (Note that Theorem ")#link(<tao-2f52d2e69eecafc262ca>)[#text("36")]#text("(iii) only gives ")#mi("{\\frac{1}{2} x\\log^2 x + O(x\\log x)}")#text("; one needs a three-dimensional version of the hyperbola method to get the better error term. ")#emph[#text("Hint:")]#text(" Decompose ")#mi("{1}")#text(" at the threshold ")#mi("{x^{1/3}}")#text(". If one is having difficulty figuring out exactly what identity to use, try working backwards, by writing down all the relevant convolutions (e.g. ")#mi("{1_{\\leq x^{1/3}} * 1_{\\leq x^{1/3}} * 1}")#text(") that look tractable, and then do some elementary linear algebra to express ")#mi("{\\tau_3}")#text(" in terms of all the expressions that you know how to estimate well.) The ")#mi("{O(x^{2/3} \\log x)}")#text(" term can be improved further (for instance, the logarithmic factor can be removed), but this requires more sophisticated methods than the ones given above.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" State and prove an extension of the previous exercise to the ")#mi("{k^{th}}")#text(" divisor function ")#mi("{\\tau_k = 1^{*k}}")#text(" for ")#mi("{k \\geq 1}")#text(", defined as the Dirichlet convolution ")#mi("{1^{*k}}")#text(" of ")#mi("{k}")#text(" copies of ")#mi("{1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 44")]#text(" The error terms we have been able to obtain for sums involving ")#mi("{\\tau}")#text(" are significantly superior to those we can obtain for ")#mi("{\\Lambda}")#text(" by similar methods. The general reason for this is that it is relatively easy to control the convolution ")#mi("{f*g}")#text(" of two functions ")#mi("{f,g}")#text(" that are themselves well understood, but it is significantly more difficult to try to control the ")#link("http://en.wikipedia.org/wiki/Deconvolution")[#text("deconvolution")]#text(" ")#mi("{f}")#text(" of a convolution ")#mi("{f*g}")#text(" by a factor ")#mi("{g}")#text(" even when one has good understanding of the latter two functions ")#mi("{f*g, g}")#text(". From a Fourier-analytic perspective, the problem is that dividing one Fourier transform by another can create singularities, whereas multiplying two Fourier series cannot. This can become problematic when the latter Fourier transform vanishes; in our arithmetic context, this corresponds to zeroes of the Dirichlet series ")#mi("{{\\mathcal D} g}")#text(". As such, we will see the location of the zeroes of Dirichlet series such as the Riemann zeta function play an extremely important role in later posts. However, the elementary approach cannot easily access this information directly; as Mertens’ theorems demonstrate, some control on the deconvolution is still possible, but it is not as satisfactory as it could be.")
]

#heading(level: 1)[#strong[#text(" — 4. The number of prime factors (optional) — ")]]

#metadata(none) <tao-0228b04eac39d6751c8f>#linebreak()#text(" Given a natural number ")#mi("{n}")#text(", we use ")#mi("{\\omega(n)}")#text(" to denote the number of prime factors of ")#mi("{n}")#text(" (not counting multiplicity), and ")#mi("{\\Omega(n)}")#text(" to denote the number of prime factors of ")#mi("{n}")#text(" (counting multiplicity). Thus we can write ")#mi("{\\omega,\\Omega}")#text(" as ")#emph[#text("divisor sums")]#text(" ")#metadata(none) <tao-35bce2b6d46de0fe8f3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(57)")])
#mitex("\\omega(n) = \\sum_{p|n} 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Omega(n) = \\sum_{j=1}^\\infty \\sum_{p: p^j|n} 1.")]]

#text("We can ask what the mean values of ")#mi("{\\omega}")#text(" and ")#mi("{\\Omega}")#text(" are. We start with the estimation of")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\omega(n).")]]

#text("We can rearrange this sum (cf. ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(") as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\sum_{m \\leq x/p} 1")]]

#text("which by ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{x}{p} + O( \\sum_{p \\leq x} 1 )")]]

#text("so by Theorem ")#link(<tao-091f39f5ce0570bc5337>)[#text("15")]#text(" (and crudely bounding ")#mi("{O( \\sum_{p \\leq x} 1 )}")#text(" by ")#mi("{O(x)}")#text(", as we will not need additional accuracy here) gives ")#metadata(none) <tao-02f027e452de23e99f89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(58)")])
#mitex("\\sum_{n \\leq x} \\omega(n) = x \\log \\log x + O(x)")]]

#text("for ")#mi("{x \\geq 10}")#text(" (say). Thus we see that for ")#mi("{n \\leq x}")#text(", one expects ")#mi("{n}")#text(" to have about ")#mi("{\\log\\log x}")#text(" prime factors on the average.")#linebreak()#text(" Now we look at the second moment")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\omega(n)^2.")]]

#text("If we expand this out directly, we get")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\sum_{p_1,p_2: p_1,p_2|n} 1")]]

#text("which we can rearrange as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1,p_2 \\leq x} \\sum_{m \\leq \\frac{x}{[p_1,p_2]}} 1")]]

#text("where ")#mi("{[p_1,p_2]}")#text(" is the least common multiple of ")#mi("{p_1,p_2}")#text(", that is to say ")#mi("{p_1p_2}")#text(" if ")#mi("{p_1 \\neq p_2}")#text(" and ")#mi("{p_1}")#text(" if ")#mi("{p_1 = p_2}")#text(". Here we run into a serious problem, which is that ")#mi("{\\frac{x}{[p_1,p_2]}}")#text(" can be significantly less than ")#mi("{1}")#text(", in which case the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq \\frac{x}{[p_1,p_2]}} 1 = \\frac{x}{[p_1,p_2]} + O(1)")]]

#text("is horrendously inefficient (the error term is larger than the main term, which is always a bad sign). One could fix this by using the trivial estimate ")#mi("{\\sum_{m \\leq \\frac{x}{[p_1,p_2]}} 1 = 0}")#text(" when ")#mi("{[p_1,p_2] > x}")#text(". But there is another cheap trick one can use here, due to Turán, coming from the fact that a given natural number ")#mi("{n \\leq x}")#text(" can have at most ")#mi("{O(1)}")#text(" prime factors that are larger than, say, ")#mi("{x^{1/10}}")#text(". Thus we can approximate the divisor sum ")#link(<tao-35bce2b6d46de0fe8f3e>)[#text("(57)")]#text(" by a ")#emph[#text("truncated")]#text(" divisor sum:")

#align(center)[#tao-fit-display[#mitex("\\omega(n) = \\sum_{p|n: p \\leq x^{1/10}} 1 + O(1).")]]

#text("One can then run the previous argument with the truncated divisor sum and avoid the problem of ")#mi("{\\frac{x}{[p_1,p_2]}}")#text(" dipping below ")#mi("{1}")#text(". Indeed, on squaring we see that")

#align(center)[#tao-fit-display[#mitex("\\omega(n)^2 = (\\sum_{p|n: p \\leq x^{1/10}} 1)^2 + O( \\omega(n) ) + O(1)")]]

#text("and hence (by ")#link(<tao-02f027e452de23e99f89>)[#text("(58)")]#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\omega(n)^2 = \\sum_{n \\leq x} \\sum_{p_1,p_2 \\leq x^{1/10}: p_1,p_2|n} 1 + O( x \\log\\log x )")]]

#text("for ")#mi("{x \\geq 10}")#text(". Rearranging and using ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" as before, we obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\omega(n)^2 = \\sum_{p_1,p_2 \\leq x^{1/10}} (\\frac{x}{[p_1,p_2]} + O(1)) + O( x \\log\\log x ).")]]

#text("The contribution of the ")#mi("{O(1)}")#text(" error may be crudely bounded by ")#mi("{O( x^{1/10} \\times x^{1/10} )}")#text(", which can easily be absorbed into the error term. The diagonal case ")#mi("{p_1=p_2}")#text(" also contributes ")#mi("{O( x \\log\\log x)}")#text(" thanks to Theorem ")#link(<tao-091f39f5ce0570bc5337>)[#text("15")]#text(". We conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\omega(n)^2 = \\sum_{p_1,p_2 \\leq x^{1/10}} \\frac{x}{p_1 p_2} + O( x \\log\\log x )")]]

#text("and thus by a final application of Theorem ")#link(<tao-091f39f5ce0570bc5337>)[#text("15")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\omega(n)^2 = x (\\log\\log x)^2 + O( x \\log\\log x ).")]]

#text("We can combine this with ")#link(<tao-02f027e452de23e99f89>)[#text("(58)")]#text(" to give a variance bound:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\omega(n) - \\log \\log x)^2 \\ll x \\log\\log x.")]]

#text("To interpret this probabilistically, we see that if we pick ")#mi("{n \\leq x}")#text(" uniformly at random, then the random quantity ")#mi("{\\omega(n)}")#text(" will have mean ")#mi("{\\log\\log x + O(1)}")#text(" and standard deviation ")#mi("{O( \\sqrt{\\log\\log x} )}")#text(". In particular, by Chebyshev’s inequality, we expect ")#mi("{n}")#text(" to have ")#mi("{\\log \\log x + O( \\sqrt{\\log\\log x})}")#text(" prime factors most of the time.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 45")]#text(" The strategy of truncating a divisor sum to obtain better control on error terms (perhaps at the expense of some inefficiency in the main terms) is one of the core techniques in ")#emph[#text("sieve theory")]#text(", which we will discuss in later notes.")
]

#text("The same estimates are true for ")#mi("{\\Omega}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\Omega(n) - \\omega(n))^k \\ll x")]]

#text("for ")#mi("{k=1,2}")#text(", and conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\Omega(n) - \\log \\log x)^2 \\ll x \\log\\log x.")]]],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\Omega(n) - \\omega(n))^k \\ll_k x")]]

#text("for all natural numbers ")#mi("{k}")#text(".")]
)
]

#text("From the above exercise and Chebyshev’s inequality, we now know the typical number of prime factors of a large number, a fact known as the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy-Ramanujan theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 47 (Hardy-Ramanujan theorem)")]#text(" Let ")#mi("{x}")#text(" be an asymptotic parameter going to infinity, and let ")#mi("{a(x)}")#text(" be any quantity depending on ")#mi("{x}")#text(" that goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text(". Let ")#mi("{n}")#text(" be a natural number selected uniformly at random from ")#mi("{\\{ n \\in {\\bf N}: n \\leq x \\}}")#text(". Then with probability ")#mi("{1-o(1)}")#text(", ")#mi("{n}")#text(" has ")#mi("{\\log\\log x + O( a(x) \\sqrt{\\log\\log x} )}")#text(" distinct prime factors, and ")#mi("{O(a(x))}")#text(" repeated prime factors (counting multiplicity, thus ")#mi("{p^j}")#text(" counts as ")#mi("{j-1}")#text(" repeated prime factors). In particular, ")#mi("{n}")#text(" has ")#mi("{\\log\\log x + O(a(x) \\sqrt{\\log\\log x})}")#text(" prime factors counting multiplicity.")
]

#text("This already has a cute consequence with regards to the multiplication table:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 48 (Multiplication table bound)")]#text(" At most ")#mi("{o(x^2)}")#text(" of the natural numbers up to ")#mi("{x^2}")#text(" can be written in the form ")#mi("{ab}")#text(" with ")#mi("{a,b \\leq x}")#text(" natural numbers.")
]

#text("In other words, for large ")#mi("{N}")#text(", the ")#mi("{N \\times N}")#text(" multiplication table only uses a small fraction of the numbers up to ")#mi("{N^2}")#text(". This simple-sounding fact is surprisingly hard to prove if one does not use the simple argument provided below.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" Pick natural numbers ")#mi("{a,b \\leq x}")#text(" uniformly at random. By the Hardy-Ramanujan theorem, with probability ")#mi("{1-o(1)}")#text(", ")#mi("{a}")#text(" and ")#mi("{b}")#text(" will each have ")#mi("{(1+o(1)) \\log\\log x}")#text(" prime factors counting multiplicity. Hence with probability ")#mi("{1-o(1)}")#text(", ")#mi("{ab}")#text(" will have ")#mi("{(2+o(1)) \\log\\log x}")#text(" prime factors counting multiplicity. But by a further application of the Hardy-Ramanujan theorem, the set of natural numbers up to ")#mi("{x^2}")#text(" with this property has cardinality ")#mi("{o(x^2)}")#text(". Thus all but ")#mi("{o(x^2)}")#text(" of the products ")#mi("{ab}")#text(" with ")#mi("{a,b \\leq x}")#text(" are contained in a set of cardinality ")#mi("{o(x^2)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 49")]#text(" In fact, the cardinality of the ")#mi("{N \\times N}")#text(" multiplication table is known to be comparable to ")#mi("{\\frac{N^2}{\\log^\\delta N (\\log\\log N)^{3/2}}}")#text(" with ")#mi("{\\delta := 1 - \\frac{1+\\log\\log 2}{\\log 2}}")#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2437965")[#text("this paper of Ford")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50 (Typical number of divisors)")]#text(" ")#metadata(none) <tao-217aea095091e0544b93>#text(" Let ")#mi("{x}")#text(" be an asymptotic parameter going to infinity. Show that one has ")#mi("{\\tau(n) = \\log^{\\log 2+o(1)} n = \\log^{\\log 2+o(1)} x}")#text(" for all but ")#mi("{o(x)}")#text(" of the natural numbers ")#mi("{n}")#text(" less than ")#mi("{x}")#text(". (")#emph[#text("Hint:")]#text(" first establish the bounds ")#mi("{2^{\\omega(n)} \\leq \\tau(n) \\leq 2^{\\Omega(n)}}")#text(".)")
]

#text("In fact, one can describe the distribution of ")#mi("{\\omega(n)}")#text(" or ")#mi("{\\Omega(n)}")#text(" more precisely, a fact known as the ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdös-Kac theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51 (Erdös-Kac theorem)")]#text(" (This exercise is intended for readers who are familiar with probability theory, and more specifically with the moment method proof of the central limit theorem, as discussed in ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("this previous set of notes")]#text(".) Let ")#mi("{x}")#text(" be an asymptotic parameter going to infinity, and let ")#mi("{\\omega^{\\prime}}")#text(" denote the truncated divisor sum")

#align(center)[#tao-fit-display[#mitex("\\omega^{\\prime}(n) := \\sum_{p|n: p \\leq x^{1/(\\log \\log x)^{1/10}}} 1.")]]

#text("Define the quantity")

#align(center)[#tao-fit-display[#mitex("\\mu := \\sum_{p \\leq x^{1/(\\log \\log x)^{1/10}}} \\frac{1}{p},")]]

#text("thus by Mertens’ theorem")

#align(center)[#tao-fit-display[#mitex("\\mu = \\log\\log x + o( (\\log\\log x)^{1/2} ).")]]

#list(
[#text("(i) Show that ")#mi("{\\omega^{\\prime}(n) = \\omega(n) + o( (\\log\\log x)^{1/2} )}")#text(" for all ")#mi("{n \\leq x}")#text(".")],
[#text("(ii) For any fixed natural number ")#mi("{k}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} (\\omega^{\\prime}(n)-\\mu)^k = (c_k + o(1)) (\\log \\log x)^{k/2},")]]

#text("where the quantity ")#mi("{c_k}")#text(" is defined to equal zero when ")#mi("{k}")#text(" is odd, or")

#align(center)[#tao-fit-display[#mitex("c_k := \\frac{k!}{(k/2)! 2^{k/2}}")]]

#text("when ")#mi("{k}")#text(" is even.")],
[#text("(iii) If ")#mi("{n}")#text(" is drawn uniformly at random from the natural numbers up to ")#mi("{x}")#text(", show that the random variable")

#align(center)[#tao-fit-display[#mitex("\\frac{\\omega(n) - \\log\\log x}{\\sqrt{\\log \\log x}}")]]

#text("converges in distribution to the standard normal distribution ")#mi("{\\frac{1}{\\sqrt{2\\pi}} e^{-t^2/2}\\ dt}")#text(" in the limit ")#mi("{x \\rightarrow \\infty}")#text(". (You will need something like the ")#emph[#text("moment continuity theorem")]#text(" from Theorem 4 ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("of these notes")]#text(".)")],
[#text("(iv) Obtain the same claim as (iii), but with ")#mi("{\\omega(n)}")#text(" replaced by ")#mi("{\\Omega(n)}")#text(".")]
)
]

#text("Informally, we thus have the heuristic formula")

#align(center)[#tao-fit-display[#mitex("\\omega(n),\\Omega(n) \\approx \\log\\log x + \\sqrt{\\log\\log x} G")]]

#text("for ")#mi("{n \\leq x}")#text(", where ")#mi("{G}")#text(" is distributed approximately according to a standard normal distribution. As in Exercise ")#link(<tao-217aea095091e0544b93>)[#text("50")]#text(", this leads to a related heuristic formula ")#metadata(none) <tao-bd144d4b9250b5395989>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(59)")])
#mitex("\\tau(n) \\approx 2^{\\log\\log x + \\sqrt{\\log\\log x} G}")]]

#text("for the number of divisors. This helps reconcile (though does not fully explain) the discrepancy between the typical (or median) value of ")#mi("{\\tau(n)}")#text(", which is ")#mi("{\\log^{\\log 2 + o(1)} x}")#text(", and the mean (or higher moments) of ")#mi("{\\tau(n)}")#text(", which is of the order of ")#mi("{\\log x}")#text(" or ")#mi("{\\log^{2^k-1} x}")#text(", as it suggests that ")#mi("{\\tau(n)}")#text(" is in fact significantly larger than its median value of ")#mi("{\\log^{\\log 2+o(1)} x}")#text(" with a relatively high probability. (Unfortunately, though, the heuristic ")#link(<tao-bd144d4b9250b5395989>)[#text("(59)")]#text(" is not very accurate at the very tail end of the distribution when ")#mi("{\\tau(n)}")#text(" is extremely large, and one cannot recover the correct exponent of the logarithm in ")#link(<tao-06bee518a7a1cf4dd557>)[#text("(51)")]#text(", for instance, through a naive application of this heuristic.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 52")]#text(" Another rough heuristic to keep in mind is that a “typical” number ")#mi("{n}")#text(" less than ")#mi("{x}")#text(" would be expected to have ")#mi("{\\asymp 1}")#text(" divisors in any dyadic block ")#mi("{[\\exp(j), \\exp(j+1)]}")#text(" between ")#mi("{1}")#text(" and ")#mi("{x}")#text(", and ")#mi("{\\asymp 1}")#text(" ")#emph[#text("prime divisors")]#text(" in any hyper-dyadic block ")#mi("{[\\exp(\\exp(j)), \\exp(\\exp(j+1))]}")#text(" between ")#mi("{1}")#text(" and ")#mi("{x}")#text(". For instance, for any fixed ")#mi("{0 < \\alpha < \\beta < 1}")#text(", one should have ")#mi("{\\asymp \\log x}")#text(" divisors in the interval ")#mi("{[x^\\alpha, x^\\beta]}")#text(", but only ")#mi("{\\asymp 1}")#text(" prime divisors. Typically, the only prime divisors that occur with multiplicity will be quite small (of size ")#mi("{O(1)}")#text("). Note that such heuristics are compatible with the fact that ")#mi("{\\tau(n)}")#text(" has mean ")#mi("{\\sim \\log x}")#text(" and that ")#mi("{\\omega(n)}")#text(" and ")#mi("{\\Omega(n)}")#text(" both have mean ")#mi("{\\sim \\log\\log x}")#text(". One can make these heuristics more precise by introducing the Poisson-Dirichlet process, as is done in ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this previous blog post")]#text(", but we will not do so here. The study of the distribution of factors of “typical” large natural numbers is a topic sometimes referred to as ")#emph[#text("anatomy of integers")]#text(". Interestingly, there is a strong analogy between this problem and the problem of studying the distribution of cycles of “typical” large permutations; see for instance ")#link("http://www.dms.umontreal.ca/~andrew/PDF/Anatomy.pdf")[#text("this article of Granville")]#text(" for further discussion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53")]#text(" Let ")#mi("{k}")#text(" be a natural number. Show that for sufficiently large ")#mi("{x}")#text(", the number of natural numbers up to ")#mi("{x}")#text(" that are the products of exactly ")#mi("{k}")#text(" distinct primes is ")#mi("{\\asymp_k \\frac{x}{\\log x} (\\log\\log x)^{k-1}}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. Mobius inversion and the Selberg symmetry formula — ")]]

#text("In Section ")#link(<tao-096b3764d961902778a5>)[#text("2")]#text(", we used the identity ")#mi("{L = \\Lambda * 1}")#text(", together with elementary estimates on ")#mi("{L}")#text(" and ")#mi("{1}")#text(", to deduce various estimates on the von Mangoldt function ")#mi("{\\Lambda}")#text(". Another way to extract information about ")#mi("{\\Lambda}")#text(" from this identity is to “deconvolve” or “invert” the operation of convolution to ")#mi("{1}")#text(". This can be achieved by the basic tool of ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_inversion_formula")[#text("Möbius inversion")]#text(", which we now discuss. We first observe that the Kronecker delta function ")#mi("{\\delta: {\\bf N} \\rightarrow {\\bf R}}")#text(", defined by ")#mi("{\\delta(n) := 1_{n=1}}")#text(", is an identity for Dirichlet convolution, thus")

#align(center)[#tao-fit-display[#mitex("f * \\delta = \\delta * f = f")]]

#text("for any arithmetic function ")#mi("{f}")#text(". Since Dirichlet convolution is associative and commutative, this implies that if we can find an arithmetic function ")#mi("{\\mu}")#text(" with the property that ")#metadata(none) <tao-91e0c0ac729c11015162>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(60)")])
#mitex("\\mu * 1 = \\delta,")]]

#text("then any formula of the form ")#mi("{f * 1 = F}")#text(" may be inverted to the equivalent form ")#mi("{F * \\mu = f}")#text(", a fact known as the ")#emph[#text("Möbius inversion formula")]#text(". It is then a routine matter to locate such a function ")#mi("{\\mu}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54")]#text(" Define the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu: {\\bf N} \\rightarrow {\\bf R}}")#text(" by setting ")#mi("{\\mu(n) := (-1)^k}")#text(" when ")#mi("{n}")#text(" is the product of ")#mi("{k}")#text(" distinct primes for some ")#mi("{k \\geq 1}")#text(", and ")#mi("{\\mu(n)=0}")#text(" otherwise. Show that ")#mi("{\\mu}")#text(" is the unique arithmetic function that obeys ")#link(<tao-91e0c0ac729c11015162>)[#text("(60)")]#text(".")
]

#text("Observe that ")#mi("{\\mu}")#text(" is a multiplicative function that obeys the trivial bound ")#metadata(none) <tao-fe1325133d4d83de2de4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(61)")])
#tao-math("\\left|\\mu(n)\\right| \\leq 1", block: true)]]

#text("for all ")#mi("{n}")#text(". Furthermore, ")#mi("{\\mu^2(n)}")#text(" is ")#mi("{1}")#text(" precisely when ")#mi("{n}")#text(" is square-free, and zero otherwise, so the notation here is consistent with that in Exercise ")#link(<tao-33ef130f13091aaf8de2>)[#text("37")]#text(".")#linebreak()#text(" One can express the Möbius inversion formula as the assertion that ")#metadata(none) <tao-bfbb6e2e4bb0c75d524d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(62)")])
#mitex("f(1) = \\sum_d \\mu(d) \\sum_m f(dm)")]]

#text("for any compactly supported arithmetic function ")#mi("{f}")#text(". This already reveals that ")#mi("{\\mu}")#text(" must exhibit some cancellation beyond the trivial bound ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 55 (Weak cancellation for ")#mi("{\\mu}")#text(")")]#text(" ")#metadata(none) <tao-9b550d15e298bd082ff0>#text(" For any non-negative integer ")#mi("{k}")#text(", we have ")#metadata(none) <tao-a6ce0cd43cce601892f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(63)")])
#mitex("\\sum_{n \\leq x} \\frac{\\mu(n)}{n} \\log^k \\frac{x}{n} = Q_k( \\log x ) + O_k(1)")]]

#text("for all ")#mi("{x}")#text(" and some polynomial ")#mi("{Q_k(t)}")#text(" with leading term ")#mi("{k t^{k-1}}")#text(" if ")#mi("{k \\geq 1}")#text(" (and ")#mi("{Q_k=0}")#text(" if ")#mi("{k=0}")#text(").")
]

#emph[#text("Proof:")]#text(" We may of course take ")#mi("{x \\geq 1}")#text(".")#linebreak()#text(" First suppose that ")#mi("{k=0}")#text(". We apply ")#link(<tao-bfbb6e2e4bb0c75d524d>)[#text("(62)")]#text(" with ")#mi("{f(n) := 1_{n \\leq x}}")#text(" to conclude that ")#metadata(none) <tao-86463b0505fc8f383638>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(64)")])
#mitex("\\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} 1 = 1.")]]

#text("Since ")#mi("{\\sum_{m \\leq x/d} 1 = \\frac{x}{d} + O(1)}")#text(", we conclude from ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\mu(d) \\frac{x}{d} = O(x),")]]

#text("and the ")#mi("{k=0}")#text(" case of ")#link(<tao-a6ce0cd43cce601892f7>)[#text("(63)")]#text(" follows.")#linebreak()#text(" Now suppose inductively that ")#mi("{k \\geq 1}")#text(", and that the claim has already been proven for smaller values of ")#mi("{k}")#text(". We apply ")#link(<tao-bfbb6e2e4bb0c75d524d>)[#text("(62)")]#text(" with ")#mi("{f(n) := 1_{n \\leq x} \\frac{\\log^{k-1} \\frac{x}{n}}{n}}")#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{\\mu(d)}{d} \\sum_{m \\leq x/d} \\frac{\\log^{k-1} \\frac{x}{dm}}{m} = \\log^{k-1} x.")]]

#text("By ")#link(<tao-9fab93dfd27b425a5a60>)[#text("(17)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/d} \\frac{\\log^{k-1} \\frac{x}{dm}}{m} = P( \\log \\frac{x}{d} ) + O_k( \\frac{1 + \\log^{k-1} \\frac{x}{d}}{x/d} )")]]

#text("for some polynomial ")#mi("{P(t)}")#text(" with leading term ")#mi("{\\frac{1}{k} t^k}")#text(". Inserting this asymptotic and using the induction hypothesis to handle all the lower order terms of ")#mi("{P}")#text(", and ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(" to handle the error term, we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{k} \\sum_{d \\leq x} \\frac{\\mu(d)}{d} \\log^k \\frac{x}{d}  & = \\log^{k-1} x + P( \\log x )", block: true)



#tao-math(" & + O_k(1 + \\sum_{d \\leq x} \\frac{1 + \\log^{k-1} \\frac{x}{d}}{x} )", block: true)
]

#text("for some polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{k-2}")#text(". By ")#link(<tao-16998845d34cbe77670b>)[#text("(15)")]#text(" the error term is ")#mi("{O_k(1)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 56")]#text(" Sharpen the ")#mi("{k=0}")#text(" case of the above lemma to ")#tao-math("{\\left|\\sum_{n \\leq x} \\frac{\\mu(n)}{n}\\right| \\leq 1}", block: false)#text(", for any ")#mi("{x>0}")#text(".")
]

#text("From Möbius inversion we can write ")#mi("{\\Lambda}")#text(" in terms of ")#mi("{\\mu}")#text(": ")#metadata(none) <tao-2a2da19f99ee0c6c79fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(65)")])
#mitex("\\Lambda = \\mu * L.")]]

#text("Since ")#mi("{L(nm) = L(n) + L(m)}")#text(", we have the general Leibniz-type identity ")#metadata(none) <tao-803118bb3829b6e62873>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(66)")])
#mitex("L \\times (f * g) = (Lf)*g + f * (Lg).")]]

#text("Since ")#mi("{L\\delta = 0}")#text(", we can obtain the alternative representation ")#metadata(none) <tao-822a8e5da4327ffa9e85>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(67)")])
#mitex("\\Lambda = -(L\\mu) * 1")]]

#text("by multiplying ")#link(<tao-91e0c0ac729c11015162>)[#text("(60)")]#text(" by ")#mi("{L}")#text(" then applying ")#link(<tao-803118bb3829b6e62873>)[#text("(66)")]#text(", ")#link(<tao-2a2da19f99ee0c6c79fe>)[#text("(65)")]#text(".")#linebreak()#text(" Using these identities and Lemma ")#link(<tao-9b550d15e298bd082ff0>)[#text("55")]#text(", we can recover many of the estimates in Section ")#link(<tao-096b3764d961902778a5>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 57 (Alternate proof of Chebyshev and Mertens bounds)")]#text(" Use ")#link(<tao-2a2da19f99ee0c6c79fe>)[#text("(65)")]#text(" and Lemma ")#link(<tao-9b550d15e298bd082ff0>)[#text("55")]#text(" to reprove the estimates")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\ll x")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} = \\log x + O(1).")]]
]

#text("If one has a little bit more cancellation in the Möbius function, one can do better:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 58 (Equivalent forms of the prime number theorem)")]#text(" The following three statements are logically equivalent:")

#list(
[#text("(i) We have ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + o(x)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) We have ")#mi("{\\sum_{n \\leq x} \\mu(n) = o(x)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(iii) We have ")#mi("{\\sum_{n \\leq x} \\frac{\\mu(n)}{n} = o(1)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")]
)
]

#text("In later notes we will prove that the claims (i), (ii), (iii) are indeed true; this is the famous ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(". This result also illustrates a general principle, that one route to distribution estimates of the primes is via distribution estimates on the Möbius function, which can sometimes be a simpler object to study (for instance, the Möbius function is bounded in magnitude by ")#mi("{1}")#text(", whereas the von Mangoldt function can grow logarithmically).")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We use ")#link("http://www.ams.org/mathscinet-getitem?mr=670132")[#text("some arguments of Diamond")]#text(". We first show that (i) implies (ii). From ")#link(<tao-822a8e5da4327ffa9e85>)[#text("(67)")]#text(" and Möbius inversion we have ")#metadata(none) <tao-efbaa8cbfffc1af3afcf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(68)")])
#mitex("L\\mu = - \\mu * \\Lambda.")]]

#text("By ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log n = - \\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} \\Lambda(m).")]]

#text("For any fixed ")#mi("{\\varepsilon > 0}")#text(", we may use (i) to write ")#mi("{\\sum_{m \\leq x/d} \\Lambda(m)}")#text(" as ")#mi("{x/d + O(\\varepsilon x/d)}")#text(" when ")#mi("{x/d}")#text(" is sufficiently large, and ")#mi("{O(x/d)}")#text(" otherwise. From this, ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(", and the ")#mi("{k=0}")#text(" case of ")#link(<tao-a6ce0cd43cce601892f7>)[#text("(63)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log n = O( \\varepsilon x \\log x )")]]

#text("when ")#mi("{x}")#text(" is large enough. By ")#link(<tao-16998845d34cbe77670b>)[#text("(15)")]#text(", ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\log \\frac{x}{n} = O(x);")]]

#text("summing and then dividing by ")#mi("{\\log x}")#text(", we obtain (ii) since ")#mi("{\\varepsilon}")#text(" is arbitrary.")#linebreak()#text(" Now we show that (ii) implies (iii). We start with the identity ")#link(<tao-86463b0505fc8f383638>)[#text("(64)")]#text(", which we write as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor = 1.")]]

#text("Let ")#mi("{\\varepsilon>0}")#text(" be a small fixed quantity. For ")#mi("{\\varepsilon x < d \\leq x}")#text(", ")#mi("{\\lfloor \\frac{x}{d} \\rfloor}")#text(" decreases through a fixed set of values, and from (ii) we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\varepsilon x < d \\leq x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor = o(x).")]]

#text("Meanwhile, since ")#mi("{\\lfloor \\frac{x}{d} \\rfloor = \\frac{x}{d} + O(1)}")#text(", we see from ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\varepsilon x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor = x \\sum_{d \\leq \\varepsilon x} \\frac{\\mu(d)}{d} + O(\\varepsilon x).")]]

#text("Combining all three inequalities and dividing by ")#mi("{x}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\varepsilon x} \\frac{\\mu(d)}{d} = O(\\varepsilon) + o(1);")]]

#text("replacing ")#mi("{x}")#text(" by ")#mi("{x/\\varepsilon}")#text(", then sending ")#mi("{\\varepsilon}")#text(" to zero, we obtain (iii).")#linebreak()#text(" To prove that (iii) implies (ii), we observe the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) = \\int_0^x \\sum_{t \\leq n \\leq x} \\frac{\\mu(n)}{n}\\ dt.")]]

#text("For any ")#mi("{\\varepsilon>0}")#text(", we have from (iii) that ")#mi("{\\sum_{t \\leq n \\leq x} \\frac{\\mu(n)}{n} = O(\\varepsilon)}")#text(" if ")#mi("{t}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", and ")#mi("{O(1)}")#text(" otherwise; thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) = O(1) + O( \\varepsilon x ) = O(\\varepsilon x)")]]

#text("if ")#mi("{x}")#text(" is large enough, and the claim follows.")#linebreak()#text(" To conclude the theorem, it suffices to show that (ii) and (iii) jointly imply (i). From ")#link(<tao-2a2da19f99ee0c6c79fe>)[#text("(65)")]#text(", ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = \\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} \\log m.")]]

#text("Meanwhile, since ")#mi("{1 = 1 * 1 * \\mu = \\tau * \\mu}")#text(", we have from ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1 = \\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} \\tau(m).")]]

#text("From ")#link(<tao-ec5e78e0e9e93182a4e3>)[#text("(6)")]#text(" we have ")#mi("{\\sum_{n \\leq x} 1 = x + O(1)}")#text(". It will thus suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} (\\tau(m)-\\log m) = o(x).")]]

#text("Let ")#mi("{\\varepsilon>0}")#text(" be a small fixed quantity. Arguing as in the implication of (iii) from (ii), we see from (ii) that ")#metadata(none) <tao-80d078c7dc84b0746fb0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(69)")])
#mitex("\\sum_{\\varepsilon x < d \\leq x} \\mu(d) \\sum_{m \\leq x/d} (\\tau(m)-\\log m) = o(x).")]]

#text("Next, we see from ")#link(<tao-4011393f356a69582a25>)[#text("(8)")]#text(", ")#link(<tao-9d83d740d78074f607ff>)[#text("(56)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/d} (\\tau(m)-\\log m) = 2 \\gamma \\frac{x}{d} + O( \\sqrt{x/d} ).")]]

#text("From Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\varepsilon x} \\sqrt{x/d} \\ll \\varepsilon^{1/2} x")]]

#text("and so from (iii) and ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\varepsilon x} \\mu(d) \\sum_{m \\leq x/d} (\\tau(m)-\\log m) = O(\\varepsilon^{1/2} x ) + o(x).")]]

#text("Summing this with ")#link(<tao-80d078c7dc84b0746fb0>)[#text("(69)")]#text(" and then sending ")#mi("{\\varepsilon}")#text(" to zero, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 59 (Further reformulations of the prime number theorem)")]#text(" Show that the statements (i)-(iii) in the above theorem are also equivalent to the following statements:")

#list(
[#text("(iv) The number of primes less than or equal to ")#mi("{x}")#text(" is ")#mi("{(1+o(1)) \\frac{x}{\\log x}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(v) The ")#mi("{n^{th}}")#text(" prime number ")#mi("{p_n}")#text(" is equal to ")#mi("{(1+o(1)) n\\log n}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#text("Unfortunately it is not so easy to actually obtain the required cancellation of the Möbius function ")#mi("{\\mu}")#text(", and to obtain the desired asymptotics for ")#mi("{\\Lambda}")#text(". However, one can do better if one works with the ")#emph[#text("higher-order von Mangoldt functions")]#text(" ")#mi("{\\Lambda_2, \\Lambda_3, \\dots}")#text(", defined by setting ")#metadata(none) <tao-c611d6a37942f2993545>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(70)")])
#mitex("\\Lambda_k := \\mu * L^k")]]

#text("for all ")#mi("{k \\geq 1}")#text(". Thus ")#mi("{\\Lambda_1}")#text(" is the usual von Mangoldt function, and from ")#link(<tao-803118bb3829b6e62873>)[#text("(66)")]#text(", ")#link(<tao-efbaa8cbfffc1af3afcf>)[#text("(68)")]#text(" we easily obtain the recursive identity ")#metadata(none) <tao-d029fa3a95e174a19934>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(71)")])
#mitex("\\Lambda_{k+1} = L \\Lambda_k + \\Lambda_k * \\Lambda")]]

#text("for ")#mi("{k \\geq 1}")#text(". Among other things, this implies by induction that the ")#mi("{\\Lambda_k}")#text(" are non-negative, and are supported on those natural numbers that have at most ")#mi("{k}")#text(" distinct prime factors. We have the following asymptotic for the summatory functions of ")#mi("{\\Lambda_k}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 60 (Summatory function of ")#mi("{\\Lambda_k}")#text(")")]#text(" ")#metadata(none) <tao-2c771cf00a8a471ab58a>#text(" For any ")#mi("{k \\geq 1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda_k(n) = x R_k( \\log x ) + O_k(x)")]]

#text("for all ")#mi("{x \\geq 1}")#text(", and for some polynomial ")#mi("{R_k(t)}")#text(" of leading term ")#mi("{k t^{k-1}}")#text(".")
]

#text("For ")#mi("{k=1}")#text(", the error term here is comparable to the main term, and we obtain no improvement over the Chebyshev bound (Proposition ")#link(<tao-43b68e0e178454bb7e96>)[#text("12")]#text("). However, the estimates here become more useful for ")#mi("{k \\geq 2}")#text(". For an explicit formula for the polynomials ")#mi("{R_k}")#text(", together with sharper bounds on the error term, see ")#link("http://www.ams.org/mathscinet-getitem?mr=2382467")[#text("this paper of Balazard")]#text(".")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" From ")#link(<tao-c611d6a37942f2993545>)[#text("(70)")]#text(", ")#link(<tao-eac3df746d7d7f0a8232>)[#text("(36)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda_k(n) = \\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} \\log^k m.")]]

#text("By ")#link(<tao-718e649231fd95a3315a>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/d} \\log^k m = \\frac{x}{d} P_k(\\log \\frac{x}{d}) + O_k( 1 + \\log^k \\frac{x}{d} )")]]

#text("for some polynomial ")#mi("{P_k(t)}")#text(" with leading term ")#mi("{t^k}")#text(". The claim then follows from ")#link(<tao-a6ce0cd43cce601892f7>)[#text("(63)")]#text(", using ")#link(<tao-fe1325133d4d83de2de4>)[#text("(61)")]#text(", ")#link(<tao-16998845d34cbe77670b>)[#text("(15)")]#text(" to control the error term. ")#mi("\\Box")#linebreak()#text(" The ")#mi("{k=2}")#text(" case of this proposition is known as the ")#emph[#text("Selberg symmetry formula")]#text(": ")#metadata(none) <tao-d540bc942a291eca7304>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(72)")])
#mitex("\\sum_{n \\leq x} \\Lambda_2(n) = 2x \\log x + O(x).")]]

#linebreak()#text(" Among other things, this gives an upper bound that comes within a factor of two of the prime number theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 61 (Cheap Brun-Titchmarsh theorem)")]#text(" For any ")#mi("{1 \\leq y \\leq x}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n \\leq x} \\Lambda(n) \\leq 2(x - y) + O( \\frac{x}{\\log x} ).")]]
]

#text("Using the methods of sieve theory, we will obtain a stronger inequality, known as the ")#link("http://en.wikipedia.org/wiki/Brun%E2%80%93Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]#text(", in later notes. This loss of a factor of two reflects a basic problem in analytic prime number theory known as the ")#link("http://en.wikipedia.org/wiki/Parity_problem_(sieve_theory)")[#text("parity problem")]#text(": estimates which involve only primes (or more generally, numbers whose number of prime factors has a fixed parity) often lose a factor of two in their upper bounds, and are trivial with regards to lower bounds, unless some non-trivial input about prime numbers is somehow injected into the argument. We will discuss the parity problem in more detail in later notes.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" From the Selberg symmetry formula we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n\\leq x} \\Lambda_2(n) = 2(x-y) \\log x + O( x )")]]

#text("(since ")#mi("{y \\log \\frac{x}{y} = O(y \\frac{x}{y} ) = O(x)}")#text("). From ")#link(<tao-d029fa3a95e174a19934>)[#text("(71)")]#text(" we have the pointwise bound ")#mi("{\\Lambda(n) \\log n \\leq \\Lambda_2(n)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n\\leq x} \\Lambda(n) \\log n \\leq 2(x-y) \\log x + O( x ).")]]

#text("By Proposition ")#link(<tao-43b68e0e178454bb7e96>)[#text("12")]#text(" and dyadic decomposition we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\log \\frac{x}{n} \\ll x,")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" With some additional argument of a “Fourier-analytic” flavour (or using arguments closely related to Fourier analysis, such as Tauberian theorems or Gelfand’s theory of Banach algebras), one can use the Selberg symmetry formula to derive the prime number theorem; see for instance ")#link("https://terrytao.wordpress.com/2014/10/25/a-banach-algebra-proof-of-the-prime-number-theorem/")[#text("these previous")]#text(" ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("blog posts")]#text(" for examples of this. However, in this course we will focus instead on the more traditional complex-analytic proof of the prime number theorem, which highlights an important connection between the distribution of the primes and the zeroes of the Riemann zeta function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 62 (Cheap Brun-Titchmarsh, again)")]#text(" Show that for any ")#mi("{1 \\leq y \\leq x}")#text(", the number of primes between ")#mi("{y}")#text(" and ")#mi("{x}")#text(" is at most ")#mi("{2\\frac{x-y}{\\log x} + O( \\frac{x}{\\log^2 x})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 63 (Golomb identity)")]#text(" Let ")#mi("{a_1,\\dots,a_k}")#text(" be coprime natural numbers. Show that")

#align(center)[#tao-fit-display[#mitex("\\Lambda(a_1) \\dots \\Lambda(a_k) = \\frac{(-1)^k}{k!} (L^k\\mu * 1)(a_1 \\dots a_k ),")]]

#text("an ")#link("http://www.ams.org/mathscinet-getitem?mr=257013")[#text("identity of Golomb")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 64 (Diamond-Steinig identity)")]#text(" Let ")#mi("{k \\geq 1}")#text(". Show that ")#mi("{\\frac{1}{(2k-1)!} L^{2k-1} \\Lambda + (\\frac{1}{(k-1)!} L^{k-1} \\Lambda) * (\\frac{1}{(k-1)!} L^{k-1} \\Lambda)}")#text(" can be expressed as a linear combination of convolutions of the form ")#mi("{\\mu * \\dots * \\mu * L^{a_1} * \\dots * L^{a_r}}")#text(", where ")#mi("{\\mu}")#text(" appears ")#mi("{k}")#text(" times and ")#mi("{a_1,\\dots,a_r}")#text(" are non-negative integers with ")#mi("{a_1+\\dots+a_r = 2k}")#text(" and ")#mi("{r \\leq k}")#text(". Identities of this form are ")#link("http://www.ams.org/mathscinet-getitem?mr=280449")[#text("due to Diamond and Steinig")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 6. Dirichlet characters — ")]]

#text("Now we consider the following vaguely worded question: how many primes are there in a given congruence class ")#mi("{a\\ (q)}")#text("? For instance, how many primes are there whose last digit is ")#mi("{7}")#text(" (i.e. lie in ")#mi("{7\\ (10)}")#text(")?")#linebreak()#text(" If the congruence class ")#mi("{a\\ (q)}")#text(" is not ")#link("http://en.wikipedia.org/wiki/Multiplicative_group_of_integers_modulo_n")[#text("primitive")]#text(", that is to say that ")#mi("{a}")#text(" and ")#mi("{q}")#text(" share a common factor, then clearly the answer is either zero or one, with the latter occurring if the greatest common divisor ")#mi("{(a,q)}")#text(" of ")#mi("{a}")#text(" and ")#mi("{q}")#text(" is a prime ")#mi("{p}")#text(" which is congruent to ")#mi("{a}")#text(" modulo ")#mi("{q}")#text(". So the interesting case is when ")#mi("{a\\ (q)}")#text(" is primitive, that is to say that it lies in the multiplicative group ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(" of primitive congruence classes.")#linebreak()#text(" In this case, we have the fundamental ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("theorem of Dirichlet")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 65 (Dirichlet’s theorem, Euclid form)")]#text(" Every primitive congruence class ")#mi("{a\\ (q)}")#text(" contains infinitely many primes.")
]

#text("For a small number of primitive congruence classes, such as ")#mi("{1\\ (q)}")#text(" or ")#mi("{3\\ (8)}")#text(", it is possible to prove Dirichlet’s theorem by mimicking one of the elementary proofs of Euclid’s theorem, but we do not know of a general way to do so; see ")#link("http://www.math.uconn.edu/~kconrad/blurbs/gradnumthy/dirichleteuclid.pdf")[#text("this paper of Keith Conrad")]#text(" for some further discussion. For instance, there is no proof known that there are infinitely many primes that end in ")#mi("{7}")#text(" that does not basically go through most of the machinery of Dirichlet’s proof (in particular introducing the notion of a Dirichlet character). Indeed, it looks like the problem of finding a new proof of Dirichlet’s theorem is an excellent test case for any proposed alternative approach to studying the primes that does not go through the standard approach of analytic number theory (cf. Remark 2 from ")#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")[#text("the announcement for this course")]#text(").")#linebreak()#text(" In fact, Dirichlet’s arguments prove the following stronger statement, generalising Euler’s theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")[#text("this set of notes")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 66 (Dirichlet’s theorem, Euler form)")]#text(" ")#metadata(none) <tao-51b04f99498b634679ea>#text(" Let ")#mi("{a\\ (q)}")#text(" be a primitive residue class. Then the sum ")#mi("{\\sum_{p = a\\ (q)} \\frac{1}{p}}")#text(" is divergent.")
]

#text("There is a more quantitative form, analogous to Mertens’ theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 67 (Dirichlet’s theorem, Mertens form)")]#text(" ")#metadata(none) <tao-a0a7f9cbf4cffd22e447>#text(" Let ")#mi("{a\\ (q)}")#text(" be a primitive residue class. Then one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} 1_{n=a\\ (q)} = \\frac{1}{\\phi(q)} \\log x + O_q(1)")]]

#text("for any ")#mi("{x \\geq 1}")#text(", where the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(" ")#mi("{\\phi(q)}")#text(" is defined as the order of the multiplicative group ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 68")]#text(" Let ")#mi("{a\\ (q)}")#text(" be a primitive residue class. Use Theorem ")#link(<tao-a0a7f9cbf4cffd22e447>)[#text("67")]#text(" to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p = a\\ (q): p \\leq x} \\frac{1}{p} = \\frac{1}{\\phi(q)} \\log\\log x + c_{a,q} + o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for some quantity ")#mi("{c_{a,q}}")#text(", thus giving Theorem ")#link(<tao-51b04f99498b634679ea>)[#text("66")]#text(". (")#emph[#text("Hint:")]#text(" adapt the proof of Theorem ")#link(<tao-091f39f5ce0570bc5337>)[#text("15")]#text(".)")
]

#text("If one tries to adapt one of the above proofs of Mertens’ theorem (or Euler’s theorem) to this setting, one soon runs into the problem that the function ")#mi("{1_{n=a\\ (q)}}")#text(" is not multiplicative: ")#mi("{1_{nm = a\\ (q)} \\neq 1_{n = a\\ (q)} 1_{m = a\\ (q)}}")#text(". To resolve this issue, Dirichlet used some Fourier analysis to express ")#mi("{1_{n=a\\ (q)}}")#text(" in terms of completely multiplicative functions, known as Dirichlet characters.")#linebreak()#text(" We first quickly recall the Fourier analysis of finite abelian groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 69 (Fourier transform for finite abelian groups)")]#text(" ")#text(" Let ")#mi("{G}")#text(" be a finite abelian group (which can be written additively or multiplicatively). Define a ")#emph[#text("character")]#text(" on ")#mi("{G}")#text(" to be a homomorphism ")#mi("{\\chi: G \\rightarrow S^1}")#text(" to the unit circle ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right|=1\\}}", block: false)#text(" of the complex numbers, and let ")#mi("{\\hat G}")#text(" be the set of characters. Then ")#tao-math("{\\left|\\hat G\\right| = \\left|G\\right|}", block: false)#text(". Furthermore, given any function ")#mi("{f: G \\rightarrow {\\bf C}}")#text(", one has a Fourier decomposition")

#align(center)[#tao-fit-display[#mitex("f(x) = \\sum_{\\chi \\in \\hat G} \\hat f(\\chi) \\chi(x)")]]

#text("for all ")#mi("{x \\in G}")#text(", where the Fourier coefficients ")#mi("{\\hat f(\\chi)}")#text(" are given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\hat f(\\chi) := \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} f(x) \\overline{\\chi(x)}.", block: true)]]

#text("Thus for instance one has ")#metadata(none) <tao-941a1aef5afdc3dae10f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(73)")])
#tao-math("1_{x=a} = \\frac{1}{\\left|G\\right|} \\sum_{\\chi \\in \\hat G} \\chi(x) \\overline{\\chi(a)}", block: true)]]

#text("for all ")#mi("{x,a \\in G}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\ell^2(G)}")#text(" be the ")#tao-math("{\\left|G\\right|}", block: false)#text("-dimensional complex Hilbert space of functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" with inner product ")#tao-math("{\\langle f, g \\rangle := \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} f(x) \\overline{g(x)}}", block: false)#text(". Clearly any character ")#mi("{\\chi \\in \\hat G}")#text(" is a unit vector in this space. Furthermore, for any two characters ")#mi("{\\chi,\\chi^{\\prime} \\in \\hat G}")#text(", we may shift the ")#mi("{x}")#text(" variable by any shift ")#mi("{h \\in G}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle \\chi, \\chi^{\\prime} \\rangle = \\chi(h) \\overline{\\chi^{\\prime}}(h) \\langle \\chi, \\chi^{\\prime} \\rangle")]]

#text("for any ")#mi("{h \\in G}")#text("; in particular, we see that if ")#mi("{\\chi \\neq \\chi^{\\prime}}")#text(", then ")#mi("{\\langle \\chi,\\chi^{\\prime} \\rangle =0}")#text(". Thus ")#mi("{\\hat G}")#text(" is an orthonormal system in ")#mi("{\\ell^2(G)}")#text(". To complete the proof of the theorem, it thus suffices to show that this orthonormal system is complete, that is to say that the characters span ")#mi("{\\ell^2(G)}")#text(".")#linebreak()#text(" Each shift ")#mi("{h \\in G}")#text(" generates a unitary shift operator ")#mi("{T_h: \\ell^2(G) \\rightarrow \\ell^2(G)}")#text(", defined by setting ")#mi("{T_h f(x) := f(hx)}")#text(" (if the group ")#mi("{G}")#text(" is written multiplicatively). These shifts collectively form what is known as the ")#link("https://en.wikipedia.org/wiki/Regular_representation")[#text("regular representation")]#text(" of ")#mi("{G}")#text(". These operators all commute with each other, so by the spectral theorem they may all be simultaneously diagonalised by an orthonormal basis of joint eigenvectors. It is easy to see that these eigenvectors are characters (up to scaling), and so the characters span ")#mi("{\\ell^2(G)}")#text(" as required. ")#mi("\\Box")#linebreak()#text(" See ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("this previous post")]#text(" for a more detailed discussion of the Fourier transform on both finite and infinite abelian groups. We remark that an alternate way to establish that the characters of ")#mi("{\\ell^2(G)}")#text(" span is to use the ")#link("http://en.wikipedia.org/wiki/Finitely-generated_abelian_group")[#text("classification of finite abelian groups")]#text(" to express ")#mi("{G}")#text(" as the product of cyclic groups, at which point one can write down the characters explicitly.")#linebreak()#text(" Define a ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" of modulus ")#mi("{q}")#text(" to be a function ")#mi("{\\chi: {\\bf N} \\rightarrow {\\bf C}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\chi(n) = 1_{(n,q)=1} \\tilde \\chi( n \\text{ mod } q )")]]

#text("where ")#mi("{\\tilde \\chi: ({\\bf Z}/q{\\bf Z})^\\times \\rightarrow {\\bf C}}")#text(" is a character of ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(". Thus, for instance, we have the ")#emph[#text("principal character")]

#align(center)[#tao-fit-display[#mitex("\\chi_0(n) = 1_{(n,q)}=1")]]

#text("of modulus ")#mi("{q}")#text(". Another important example of a Dirichlet character is the quadratic character ")#mi("{\\chi_p}")#text(" to a prime modulus ")#mi("{p}")#text(", defined by setting ")#mi("{\\chi_p(n)}")#text(" to be ")#mi("{+1}")#text(" when ")#mi("{n}")#text(" is a non-zero quadratic residue modulo ")#mi("{p}")#text(", ")#mi("{-1}")#text(" if ")#mi("{n}")#text(" is a quadratic residue modulo ")#mi("{p}")#text(", and zero if ")#mi("{n}")#text(" is divisible by ")#mi("{p}")#text(". (There are quadratic characters to composite moduli as well, but one needs to define them using the ")#link("http://en.wikipedia.org/wiki/Kronecker_symbol")[#text("Kronecker symbol")]#text(".) One can also easily verify that the product of two Dirichlet characters is again a Dirichlet character (even if the characters were initially of different modulus).")#linebreak()#text(" A technical remark: we consider two Dirichlet characters ")#mi("{\\chi, \\chi^{\\prime}}")#text(" to be equal if they are equal as functions, that is to say that ")#mi("{\\chi(n)=\\chi^{\\prime}(n)}")#text(" for all ")#mi("{n}")#text(". As such, it is possible for a Dirichlet character to have multiple moduli: if ")#mi("{\\chi}")#text(" is a character of modulus ")#mi("{q}")#text(", it is also a character of modulus ")#mi("{kq}")#text(" for any natural number ")#mi("{k}")#text(" whose prime factors also divide ")#mi("{q}")#text(". As such, it is slightly inaccurate to talk about “the” modulus of a Dirichlet character (though one could always work with the ")#emph[#text("minimal")]#text(" modulus of a Dirichlet character, if desired), but this ambiguity will not cause much difficulty in practice.")#linebreak()#text(" Dirichlet characters ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" are completely multiplicative (thus ")#mi("{\\chi(nm)=\\chi(n) \\chi(m)}")#text(" for all ")#mi("{n,m \\in {\\bf N}}")#text(", not necessarily coprime) and periodic of period ")#mi("{q}")#text(" (thus ")#mi("{\\chi(n+q)=\\chi(n)}")#text(" for all ")#mi("{n \\in {\\bf Z}}")#text("). From Theorem ")#link(<tao-f185d43145d180df586c>)[#text("43")]#text(" we see that there are exactly ")#mi("{\\phi(q)}")#text(" Dirichlet characters of modulus ")#mi("{q}")#text(", and from ")#link(<tao-941a1aef5afdc3dae10f>)[#text("(73)")]#text(" one has the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("1_{n=a\\ (q)} = \\frac{1}{\\phi(q)} \\sum_\\chi \\overline{\\chi(a)} \\chi(n).")]]

#text("From Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n)}{n} \\chi_0(n) = \\log x + O_q(1),")]]

#text("since the contribution of those ")#mi("{n}")#text(" for which ")#mi("{n}")#text(" is not coprime to ")#mi("{q}")#text(" is easily seen to be ")#mi("{O_q(1)}")#text(" (")#mi("{n}")#text(" must be a power of a prime dividing ")#mi("{q}")#text(" in these cases). Thus, Theorem ")#link(<tao-a0a7f9cbf4cffd22e447>)[#text("67")]#text(" follows from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 70 (Dirichlet’s theorem, character form)")]#text(" ")#metadata(none) <tao-caef3a8f5c87d8037407>#text(" Let ")#mi("{\\chi}")#text(" be a non-principal Dirichlet character of modulus ")#mi("{q}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\Lambda(n) \\chi(n)}{n} = O_\\chi(1)")]]

#text("for any ")#mi("{x \\geq 1}")#text(".")
]

#text("To prove this theorem, we use the “deconvolution” strategy. Observe that for any completely multiplicative function ")#mi("{\\chi}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\chi(f*g) = (\\chi f) * (\\chi g)")]]

#text("for any arithmetic functions ")#mi("{f, g}")#text(". In particular, from ")#link(<tao-7cf246e7f6b0385d85dd>)[#text("(35)")]#text(" one has ")#metadata(none) <tao-5313f9cc80fefb4a8cbd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(74)")])
#mitex("L\\chi = (\\Lambda \\chi) * \\chi.")]]

#text("Theorem ")#link(<tao-caef3a8f5c87d8037407>)[#text("70")]#text(" is seeking control on the logarithmic sums of ")#mi("{\\Lambda \\chi}")#text(", so it is natural to first control the logarithmic sums of ")#mi("{L\\chi}")#text(" and ")#mi("{\\chi}")#text(". To do this we use a somewhat crude lemma (which can be viewed as a twisted version of the quantitative integral test in Lemma ")#link(<tao-1a20f6d5510e063e9244>)[#text("2")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 71 (Twisted quantitative integral test)")]#text(" ")#metadata(none) <tao-f9b0078b5df596d2ea19>#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character of modulus ")#mi("{q}")#text(", and let ")#mi("{f}")#text(" be an arithmetic function that is monotone on an interval ")#mi("{[x,y]}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\leq n < y} f(n) \\chi(n) = O( q(\\left|f(x)\\right| + \\left|f(y)\\right|) ).", block: true)]]
]

#emph[#text("Proof:")]#text(" Without loss of generality we may assume that ")#mi("{f}")#text(" is monotone non-increasing. By rounding ")#mi("{x}")#text(" up and ")#mi("{y}")#text(" down to the nearest multiple of ")#mi("{q}")#text(", we may assume that ")#mi("{x, y}")#text(" are multiples of ")#mi("{q}")#text(", then the left-hand side may be split into the sum of expressions of the form ")#mi("{\\sum_{jq \\leq n < (j+1)q} f(n) \\chi(n)}")#text(". As ")#mi("{\\chi}")#text(" is non-principal, it is orthogonal to the principal character, and in particular ")#mi("{\\sum_{jq \\leq n < (j+1) q} \\chi(n) = 0}")#text(". Thus we may write ")#mi("{\\sum_{jq \\leq n < (j+1)q} f(n) \\chi(n)}")#text(" as ")#mi("{\\sum_{jq \\leq n < (j+1)q} (f(n)-f(jq)) \\chi(n)}")#text(", which by the trivial bound ")#tao-math("{\\left|\\chi(n)\\right| \\leq 1}", block: false)#text(" and monotonicity may be bounded by ")#mi("{O( q(f(jq) - f((j+1)q)) )}")#text(". The claim then follows from telescoping series. ")#mi("\\Box")#linebreak()#text(" From this lemma we obtain the crude upper bounds ")#metadata(none) <tao-938645cc357aff04e4d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(75)")])
#mitex("\\sum_{n \\leq x} \\frac{\\chi(n) \\log n}{n} = O_q( 1 )")]]

#text("and ")#metadata(none) <tao-2e29037297fca96551a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(76)")])
#mitex("\\sum_{x \\leq n < y} \\frac{\\chi(n)}{n} = O_q( \\frac{1}{x} )")]]

#text("for any ")#mi("{1 \\leq x \\leq y}")#text(". (Strictly speaking, the function ")#mi("{x \\mapsto \\frac{\\log x}{x}}")#text(" is not monotone decreasing for ")#mi("{x \\leq e}")#text(", but clearly we may just delete this portion of the sum from ")#link(<tao-938645cc357aff04e4d6>)[#text("(75)")]#text(" without significantly affecting the estimate.) By Lemma ")#link(<tao-27368d421f0ff4d182b6>)[#text("4")]#text(" we thus have ")#metadata(none) <tao-3bc85fdb9b4965793a1c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(77)")])
#mitex("\\sum_{n \\leq x} \\frac{\\chi(n)}{n} = L(1,\\chi) + O_q( \\frac{1}{x} )")]]

#text("for all ")#mi("{x \\geq 1}")#text(" and some complex number ")#mi("{L(1,\\chi)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 72 (Continuity of ")#mi("{L}")#text("-function at ")#mi("{1}")#text(")")]#text(" ")#metadata(none) <tao-988c8979d5d706a1b7d2>#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character. For any ")#mi("{s>1}")#text(", define the ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet ")#mi("{L}")#text("-function")]#text(" ")#mi("{L(s,\\chi)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) := \\sum_n \\frac{\\chi(n)}{n^s}.")]]

#text("Show that ")#mi("{L(s,\\chi) = L(1,\\chi) + O(q(s-1))}")#text(" for any ")#mi("{s>1}")#text(". In particular, the Dirichlet ")#mi("{L}")#text("-function extends continuously to ")#mi("{s=1}")#text(". (In later notes we will extend this function to a much larger domain.)")
]

#text("We will shortly prove the following fundamental fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 73 (Non-vanishing)")]#text(" ")#metadata(none) <tao-8ffaac9a31a611a9315c>#text(" One has ")#mi("{L(1,\\chi) \\neq 0}")#text(" for any non-principal character ")#mi("{\\chi}")#text(".")
]

#text("Let us assume this theorem for now and conclude the proof of Theorem ")#link(<tao-caef3a8f5c87d8037407>)[#text("70")]#text(". Starting with the identity ")#link(<tao-5313f9cc80fefb4a8cbd>)[#text("(74)")]#text(" and using ")#link(<tao-127c394dfe8bca2b95cb>)[#text("(37)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\chi(n) \\log n}{n} = \\sum_{d \\leq x} \\frac{\\Lambda(d) \\chi(d)}{d} (\\sum_{m \\leq x/d} \\frac{\\chi(m)}{m}).")]]

#text("Inserting ")#link(<tao-938645cc357aff04e4d6>)[#text("(75)")]#text(", ")#link(<tao-3bc85fdb9b4965793a1c>)[#text("(77)")]#text(" and using the trivial bound ")#tao-math("{\\left|\\chi(d)\\right| \\leq 1}", block: false)#text(" to control error terms, we conclude that")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) \\sum_{d \\leq x} \\frac{\\Lambda(d) \\chi(d)}{d} = O_q(1) + O_q( \\sum_{d \\leq x} \\frac{\\Lambda(d)}{d} \\frac{1}{x/d} ),")]]

#text("and Theorem ")#link(<tao-caef3a8f5c87d8037407>)[#text("70")]#text(" follows by dividing by ")#mi("{L(1,\\chi)}")#text(" and using Proposition ")#link(<tao-43b68e0e178454bb7e96>)[#text("12")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 74")]#text(" It is important to observe that this argument is potentially ")#emph[#text("ineffective")]#text(": the implied constant in Theorem ")#link(<tao-caef3a8f5c87d8037407>)[#text("70")]#text(" will depend on what upper bound one can obtain for the quantity ")#tao-math("{\\frac{1}{\\left|L(1,\\chi)\\right|}}", block: false)#text(". Theorem ")#link(<tao-8ffaac9a31a611a9315c>)[#text("73")]#text(" ensures that this quantity is finite, but does not directly supply a bound for it, and so we cannot explicitly (or ")#emph[#text("effectively")]#text(") describe what the implied constant is as a computable function of ")#mi("{q}")#text(", at least if one only uses Theorem ")#link(<tao-8ffaac9a31a611a9315c>)[#text("73")]#text(" as a “black box”. It is thus of interest to strengthen Theorem ")#link(<tao-8ffaac9a31a611a9315c>)[#text("73")]#text(" by obtaining effective lower bounds on ")#tao-math("{\\left|L(1,\\chi)\\right|}", block: false)#text(" for various characters ")#mi("{\\chi}")#text(". This can be done in some cases (particularly if ")#mi("{\\chi}")#text(" is not real-valued), but to get a good effective bound for all characters ")#mi("{\\chi}")#text(" is a surprisingly difficult problem, essentially the ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero problem")]#text("; we will return to this issue in later notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 75")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda_k(n) \\chi(n) = O_{k,\\chi}(x)")]]

#text("for any ")#mi("{k \\geq 1}")#text(" and any non-principal character ")#mi("{\\chi}")#text(". (You will not need to know the non-vanishing of ")#mi("{L(1,\\chi)}")#text(" to establish this.) Conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda_k(n) = \\frac{1}{\\phi(q)} x R_k( \\log x ) + O_{k,q}(x)")]]

#text("for any ")#mi("{k \\geq 1}")#text(" and any primitive residue class ")#mi("{a\\ (q)}")#text(", where ")#mi("{R_k}")#text(" is the polynomial in Proposition ")#link(<tao-2c771cf00a8a471ab58a>)[#text("60")]#text(". Deduce in particular the cheap Brun-Titchmarsh bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n \\leq x: n = a\\ (q)} \\Lambda(n) \\leq \\frac{2}{\\phi(q)}(x - y) + O_q( \\frac{x}{\\log x} )")]]

#text("for any ")#mi("{1 \\leq y \\leq x}")#text(" and primitive residue class ")#mi("{a\\ (q)}")#text(".")
]

#text("It remains to prove the non-vanishing of ")#mi("{L(1,\\chi)}")#text(". Here we encounter a curious ")#emph[#text("repulsion")]#text(" phenomenon (a special case of the ")#link("http://en.wikipedia.org/wiki/Deuring%E2%80%93Heilbronn_phenomenon")[#text("Deuring-Heilbronn repulsion phenonemon")]#text("): the vanishing of ")#mi("{L(1,\\chi)}")#text(" for one character ")#mi("{\\chi}")#text(" prevents (or “repels”) the vanishing of ")#mi("{L(1,\\chi^{\\prime})}")#text(" for another character ")#mi("{\\chi^{\\prime}}")#text(". More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 76")]#text(" Let ")#mi("{q \\geq 1}")#text(". Then there is at most one non-principal Dirichlet character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" for which ")#mi("{L(1,\\chi) = 0}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\chi_0, \\chi_1,\\dots,\\chi_{\\phi(q)-1}}")#text(" denote all the Dirichlet characters of modulus ")#mi("{q}")#text(", including the principal character ")#mi("{\\chi_0}")#text(". The idea is to exploit a certain positivity when all the characters are combined together, which will be incompatible with two or more of the ")#mi("{L(1,\\chi_i)}")#text(" vanishing.")#linebreak()#text(" There are a number of ways to see the positivity, but we will start with the Euler product identity")

#align(center)[#tao-fit-display[#mitex("- \\sum_p \\log( 1 - \\frac{1}{p^s} ) = \\log \\zeta(s)")]]

#text("from ")#link(<tao-4030f0c0b99ba5e189b6>)[#text("(27)")]#text(". We can “twist” this identity by replacing ")#mi("{\\frac{1}{p^s}}")#text(" by ")#mi("{\\frac{\\chi(p)}{p^s}}")#text(" for any Dirichlet character ")#mi("{\\chi}")#text(", which by the complete multiplicativity of ")#mi("{\\chi}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("- \\sum_p \\log( 1 - \\frac{\\chi(p)}{p^s} ) = \\log L(s,\\chi)")]]

#text("for any ")#mi("{s>1}")#text(", where we allow for logarithms to be ambiguous up to multiples of ")#mi("{2\\pi i}")#text(". By Taylor expansion, we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n) \\chi(n)}{n^s \\log n} = \\log L(s,\\chi)")]]

#text("for ")#mi("{s>1}")#text(" (cf. ")#link(<tao-5aacae98463e7ba28903>)[#text("(31)")]#text("). Summing this for ")#mi("{\\chi = \\chi_0,\\dots,\\chi_{\\phi(q)-1}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n) \\sum_{j=0}^{\\phi(q)-1} \\chi_j(n)}{n^s \\log n} = \\sum_{j=0}^{\\phi(q)-1} \\log L(s,\\chi_j).")]]

#text("From ")#link(<tao-941a1aef5afdc3dae10f>)[#text("(73)")]#text(" we see that ")#mi("{\\sum_{j=0}^{\\phi(q)-1} \\chi_j(n) = \\phi(q) 1_{n = 1\\ (q)}}")#text(". In particular, the left-hand side is non-negative. Exponentiating, we conclude the lower bound ")#metadata(none) <tao-4e336a8946fd5683580b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(78)")])
#mitex("\\prod_{j=0}^{\\phi(q)-1} L(s,\\chi_j) \\geq 1.")]]

#text("Now we let ")#mi("{s \\rightarrow 1^+}")#text(". For non-principal characters ")#mi("{\\chi_j}")#text(", we see from Exercise ")#link(<tao-988c8979d5d706a1b7d2>)[#text("72")]#text(" that ")#mi("{L(s,\\chi_j)}")#text(" stays bounded as ")#mi("{s \\rightarrow 1^+}")#text(", and decays like ")#mi("{O_q(s-1)}")#text(" if ")#mi("{L(1,\\chi_j)}")#text(" vanishes. For the principal character ")#mi("{\\chi_0}")#text(", we will just use the crude upper bound ")#tao-math("{\\left|L(s,\\chi_0)\\right| \\leq \\zeta(s)}", block: false)#text(". By ")#link(<tao-3a44788d006adcb566a2>)[#text("(11)")]#text(", we conclude that if two or more ")#mi("{L(1,\\chi_j)}")#text(" are vanishing, then the product ")#mi("{\\prod_{j=0}^{\\phi(q)-1} L(s,\\chi_j)}")#text(" will go to zero as ")#mi("{s \\rightarrow 1}")#text(", contradicting ")#link(<tao-4e336a8946fd5683580b>)[#text("(78)")]#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Call a Dirichlet character ")#mi("{\\chi}")#text(" ")#emph[#text("real")]#text(" if it only takes real values, and ")#emph[#text("complex")]#text(" if it is not real. For instance, the character of modulus ")#mi("{5}")#text(" that takes the values ")#mi("{i}")#text(" on ")#mi("{2\\ (5)}")#text(", ")#mi("{-1}")#text(" on ")#mi("{4\\ (5)}")#text(", ")#mi("{-i}")#text(" on ")#mi("{3\\ (5)}")#text(", ")#mi("{1}")#text(" on ")#mi("{1\\ (5)}")#text(", and ")#mi("{0}")#text(" on ")#mi("{0\\ (5)}")#text(" is a complex character. The above theorem, together with conjugation symmetry, quickly disposes of the complex characters ")#mi("{\\chi}")#text(", as such characters can be “repelled” by their complex conjugates:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 77")]#text(" Let ")#mi("{\\chi}")#text(" be a complex character. Then ")#mi("{L(1,\\chi) \\neq 0}")#text(".")
]

#emph[#text("Proof:")]#text(" If ")#mi("{\\chi}")#text(" is a complex character of some modulus ")#mi("{q}")#text(", then its complex conjugate ")#mi("{\\overline{\\chi}}")#text(" is a different complex character with the same modulus ")#mi("{q}")#text(", and ")#mi("{L(1,\\overline{\\chi}) = \\overline{L(1,\\chi)}}")#text(". If ")#mi("{L(1,\\chi)}")#text(" vanishes, we therefore have at least two non-principal characters of modulus ")#mi("{q}")#text(" whose ")#mi("{L}")#text("-function vanishes at ")#mi("{1}")#text(", contradicting Theorem ")#link(<tao-8ffaac9a31a611a9315c>)[#text("73")]#text(". ")#mi("\\Box")#linebreak()#text(" This only leaves the case of real non-principal characters ")#mi("{\\chi}")#text(" to deal with. These characters are also known as ")#emph[#text("quadratic characters")]#text(", as ")#mi("{\\chi^2}")#text(" is the principal character; they are also connected to quadratic number fields, as we will discuss in a subsequent post. In this case, we cannot exploit the repulsion phenomenon, as we now only have one character for which ")#mi("{L(1,\\chi)}")#text(" vanishes. On the other hand, for quadratic characters we have a much simpler positivity property, namely that ")#metadata(none) <tao-cf07849a6245416dfc90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(79)")])
#mitex("1 + \\chi(n) \\geq 0")]]

#text("for all natural numbers ")#mi("{n}")#text(". Actually, it is convenient to use a variant of this positivity property, namely that ")#metadata(none) <tao-9b5407f9c53e2b66172e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(80)")])
#mitex("1 * \\chi(n) \\geq 0,")]]

#text("which can be proven first by working in the case that ")#mi("{n}")#text(" is a power of a prime ")#mi("{p}")#text(" and using ")#link(<tao-cf07849a6245416dfc90>)[#text("(79)")]#text(", and then using multiplicativity to handle the general case. Crucially, we can do a little better than this: we can improve ")#link(<tao-9b5407f9c53e2b66172e>)[#text("(80)")]#text(" to ")#metadata(none) <tao-cd13469df289f6920de7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(81)")])
#mitex("1 * \\chi(n) \\geq 1")]]

#text("whenever ")#mi("{n}")#text(" is a perfect square. Again, this can be verified by first working in the case when ")#mi("{n}")#text(" is an even prime power.")#linebreak()#text(" It is now natural to consider sums such as ")#mi("{\\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^s}}")#text(" to exploit this positivity. It turns out that the best choice of ")#mi("{s}")#text(" to use here is ")#mi("{s=1/2}")#text(", that is to say to control the sum ")#metadata(none) <tao-bf792f8512eec194eec2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(82)")])
#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{\\sqrt{n}}.")]]

#text("On the one hand, from positivity on the squares ")#link(<tao-cd13469df289f6920de7>)[#text("(81)")]#text(", we can bound this sum by")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq \\sqrt{x}} \\frac{1}{\\sqrt{m^2}} \\gg \\log x")]]

#text("for ")#mi("{x \\geq 2}")#text(" (say), thanks to ")#link(<tao-af3ce03f6874c53162b7>)[#text("(14)")]#text(". On the other hand, we can expand ")#link(<tao-bf792f8512eec194eec2>)[#text("(82)")]#text(" using the Dirichlet hyperbola method (cf. ")#link(<tao-acdabe7a2f8d8888ab05>)[#text("(55)")]#text(") as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{\\sqrt{d}} \\sum_{m \\leq x/d} \\frac{1}{\\sqrt{m}} + \\sum_{m \\leq \\sqrt{x}} \\frac{1}{\\sqrt{m}} \\sum_{\\sqrt{x} < d \\leq x/m} \\frac{\\chi(d)}{\\sqrt{d}}.")]]

#text("From ")#link(<tao-e1754a9974fb0df68e45>)[#text("(12)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/d} \\frac{1}{\\sqrt{m}} = 2 \\sqrt{x/d} + \\zeta(1/2) + O( \\sqrt{d/x} )")]]

#text("while from Lemma ")#link(<tao-f9b0078b5df596d2ea19>)[#text("71")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\sqrt{x} < d \\leq x/m} \\frac{\\chi(d)}{\\sqrt{d}} = O_q(\\frac{1}{x^{1/4}})")]]

#text("and so (using the trivial bound ")#tao-math("{\\left|\\chi(d)\\right| \\leq 1}", block: false)#text(" to control error terms) the previous expression can be rewritten as")

#align(center)[#tao-fit-display[#mitex("2 \\sqrt{x} \\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{d} + \\zeta(1/2) \\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{\\sqrt{d}} + O( 1 ) + O_q( \\frac{1}{\\sqrt{x}} \\sum_{m \\leq \\sqrt{x}} \\frac{1}{m^{1/2} x^{1/4}} ).")]]

#text("The final error is ")#mi("{O_q(1)}")#text(". From Lemma ")#link(<tao-f9b0078b5df596d2ea19>)[#text("71")]#text(" we have ")#mi("{\\sum_{d \\leq x} \\frac{\\chi(d)}{\\sqrt{d}} = O_q(1)}")#text(". Inserting ")#link(<tao-3bc85fdb9b4965793a1c>)[#text("(77)")]#text(", we conclude that ")#metadata(none) <tao-8f9a922c666cd07bfadd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(83)")])
#mitex("\\log x \\ll 2 x^{1/2} L(1,\\chi) + O_q(1).")]]

#text("If ")#mi("{L(1,\\chi) = 0}")#text(" vanishes, then this leads to a contradiction if ")#mi("{x}")#text(" is large enough. This concludes the proof of Theorem ")#link(<tao-8ffaac9a31a611a9315c>)[#text("73")]#text(", and hence Dirichlet’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 78")]#text(" The inequality ")#link(<tao-8f9a922c666cd07bfadd>)[#text("(83)")]#text(" in fact shows that ")#mi("{L(1,\\chi)}")#text(" is positive for every real character ")#mi("{\\chi}")#text(". In fact, with the assistance of some algebraic number theory, one can show the ")#link("http://en.wikipedia.org/wiki/Class_number_formula")[#text("class number formula")]#text(" which asserts (roughly speaking) that ")#mi("{L(1,\\chi)}")#text(" is proportional to the class number of a certain quadratic number field. This will be discussed in a subsequent post.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 79")]#text(" By using an effective version of the above arguments, establish the lower bound ")#metadata(none) <tao-4e3795d05d9d3ed261ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(84)")])
#tao-math("\\left|L(1,\\chi)\\right| \\gg \\exp( - O( q \\log q ) )", block: true)]]

#text("for all non-principal characters ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" (both real and complex).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 80")]#text(" The bound ")#link(<tao-4e3795d05d9d3ed261ea>)[#text("(84)")]#text(" is very poor and can be improved. For instance, the class number formula alluded to in the previous remark gives the effective bound ")#mi("{L(1,\\chi) \\gg 1/\\sqrt{q}}")#text(" for real non-principal characters. In later notes we will also establish ")#emph[#text("Siegel’s theorem")]#text(", which gives an ")#emph[#text("ineffective")]#text(" bound of the form ")#mi("{L(1,\\chi) \\gg_\\varepsilon q^{-\\varepsilon}}")#text(" for such characters, and any ")#mi("{\\varepsilon>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 81")]#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character. Show that the sum ")#mi("{\\sum_p \\frac{\\chi(p)}{p}}")#text(" is conditionally convergent. Then show that the product ")#mi("{\\prod_p (1 - \\frac{\\chi(p)}{p})^{-1}}")#text(" is conditionally convergent to ")#mi("{L(1,\\chi)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 82")]#text(" If ")#mi("{\\chi}")#text(" is a non-principal character of modulus ")#mi("{q}")#text(", establish the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1*\\chi(n) = L(1,\\chi) x + O( q \\sqrt{x} )")]]

#text("for any ")#mi("{x \\geq 1}")#text(". (Hint: use the hyperbola method.) Use this to give an alternate proof of the non-negativity of ")#mi("{L(1,\\chi)}")#text(" when ")#mi("{\\chi}")#text(" is real. (This exercise gives evidence for a useful heuristic that ")#mi("{1*\\chi}")#text(" is expected to be small on average when ")#mi("{L(1,\\chi)}")#text(" is small.)")
]

#heading(level: 1)[#text("Comments (146)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-453803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2015")])]

#text("In regards to exercise 11, is there a good explanation as to why $e^(i n t)$ has zero mean value ($t \\neq 2k\\pi$), but when one replaces the $n$ with a $\\log(n)$, this is no longer the case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78b6bb1b526b84f2401b6affa5c7be46eef64b91f3158c598b28de0bdf1ee0ef-5d7fbc184c468ac2b51bf113e3dd31010165e3cfeb41bdf779afeaeef573361d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karaskas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-454059")[#strong[#text("Karaskas")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2015")])]

#text("Exercise 31: It should be ")#mi("\\tau (n)")#text(" instead of ")#mi("\\tau (x)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-454085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2015")])]

#text("The summand ")#mi("\\tau_3(x)")#text(" should be ")#mi("\\tau_3(n)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-458477")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] , one can show through summation by parts (see Lemma 71 of this previous post) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jarek Kuben")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-466065")[#strong[#text("Jarek Kuben")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2016")])]

#text("Small typographic remark: you’re using ")#mi("\\mathfrak G")#text(" (Fraktur G) instead of ")#mi("\\mathfrak S")#text(" (Fraktur S) for singular series. Same in Notes 2, however you got it right in Supplement 4 and Notes 4. :)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Biases between consecutive primes | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-466952")[#strong[#text("Biases between consecutive primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")])]

#text("[…] One can also establish (2) (with smoothing) using elementary number theory methods (as in this previous post); we sketch the argument as follows. We can factor as a Dirichlet […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-470232")[#strong[#text("254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2016")])]

#text("[…] use a trick previously employed to prove Lemma 40 of Notes 1. By (12) and the dominated convergence theorem, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic computation of correlations of higher order divisor functions | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-472047")[#strong[#text("Heuristic computation of correlations of higher order divisor functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2016")])]

#text("[…] is a certain explicit polynomial of degree with leading coefficient ; see e.g. Exercise 31 of this previous post for a discussion of the case (which is already typical). Similarly if . For more general , there […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-472486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("The 6th line in the proof of Theorem 36: o(1) should be O(1).")

#emph[#text("[Actually, I think the equation is correct as it stands – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-472511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Did you implicitly assume that \\frac{\\log y}{\\log x}-1=o(1)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-472513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2016")])]

#text("Please ignore my previous comment. I forgot to add the first summand in the final computation. Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-473002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2016")])]

#text("In Remark 49: ")#mi("\\frac{N}{\\log^\\delta N (\\log\\log N)^{3/2}}")#text(" should be ")#mi("\\frac{N^2}{\\log^\\delta N (\\log\\log N)^{3/2}}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-477026")[#strong[#text("254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("[…] Notes 1, we approached multiplicative number theory (the study of multiplicative functions and their […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-483763")[#strong[#text("An Epsilon of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")]#text(" (Terry what’s new) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-483873")[#strong[#text("An Epsilon of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math student")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-484866")[#strong[#text("Math student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2017")])]

#text("Dear Prof. Tao,")

#text("in (8) and (9), do you mean ")#mi("2x")#text(" in the argument on the RHS instead of ")#mi("2 + x")#text("?")

#emph[#text("[The two are equivalent up to constants – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math student")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-484884")[#strong[#text("Math student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2017")])]

#text("Dear Prof. Tao,")

#text("I have a question regarding number theory in general. It seems as though sometimes, the same problem can be done using different methods (in fact, in ex. 10 there are ")#mi("\\ge 3")#text("). Would you deem it advisable to do the problem several times, using the different methods, or rather to use the one one is least familiar with and then go on to the next exercise for brevity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-484930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2017")])]

#text("One shouldn’t be measuring progress in terms of the number of exercises solved per unit time; it’s about how well you understand the material. The purpose of doing exercises is to test this understanding and to develop your technique and intuition; as long as you feel you have learned something at the completion of an exercise, it has not been time wasted.")

#text("See also my advice pages on this blog, including:")

#link("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-grades-and-exams-and-methods/")[#text("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-grades-and-exams-and-methods/")]#linebreak()#text(" ")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/learn-and-relearn-your-field/")[#text("Learn and relearn your field")]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/learn-the-limitations-of-your-tools/")[#text("Learn the limitations of your tools")]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/learn-the-power-of-other-mathematicians-tools/")[#text("Learn the power of other mathematicians’ tools")]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/continually-aim-just-beyond-your-current-range/")[#text("Continually aim just beyond your current range")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math student")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-484944")[#strong[#text("Math student")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2017")])]

#text("The question of course always being WHICH tools and tricks to learn about in a given amount of time, which doubtlessly an experienced world-class number theorist can answer more readily than a rather mediocre “maths script-kiddy” like myself. I wonder whether the way mathematics is built favours the one who learns rather fringe material, the one who studies that which no-one else studies, so that he can make discoveries that withstand the attempts of the “mainstreamers”, if there is such a thing.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d8a4081d922da7e9e03e63ea7b497dae8f4f067794579b1f0242401555fa3d8-8d1552c7bdcbf561537a0c5290f71d3623fcc2d02962f9fabe2d75fc3d4929bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Gannon")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-485400")[#strong[#text("Tom Gannon")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2017")])]

#text("Thanks for these notes! In the first paragraph, “to the classical situation of real ofr complex arithmetic functions,” I imagine should be “real or complex”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-486538")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2017")])]

#text("Dear Prof. Tao,")

#text("I think in the paragraph before equation (20), one needs ")#mi("\\mathrm{Re}(s) > C")#text(", where ")#mi("C > 0")#text(" is the majorizing constant implicit in the ")#mi("O")#text(" notation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-486600")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2017")])]

#text("I realize now that it’s a little o, so that it’s correct.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Continuous approximations to arithmetic functions | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-488633")[#strong[#text("Continuous approximations to arithmetic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("[…] which matches what one actually gets from the Dirichlet hyperbola method (see e.g. equation (44) of this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-493913")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2018")])]

#text("As I realize now, in lemma 2, the monotonicity even seems to imply that we have in fact ")#tao-math("O(\\left|f(x)\\right|)", block: false)#text(", instead of ")#tao-math("O(\\left|f(x)\\right| + \\left|f(y)\\right|)", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-493916")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2018")])]

#text("This is true for monotonically increasing ")#mi("f")#text(" (for monotonically decreasing ")#mi("f")#text(", the remainder term is ")#tao-math("O(\\left|f(y)\\right|)", block: false)#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3af19ce28436b53c69630e7af195ed5d400af74491991891fa0ce0d669c8097c-a4bc7118173d38dff48318d1de76da0d6c66f2c29cffc8c5b42cf82f8fbaeeeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helen")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-517002")[#strong[#text("Helen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")])]

#text("For Exercise 11, what do you have in mind there? I could only show it by (basically) proving Euler’s summation formula, but it feels as if there should be a much more elementary argument for this. Would you mind expanding?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-517020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2019")])]

#text("The main step is to show that ")#mi("\\int_n^{n+1} f(t)\\ dt = f(n) + O( \\int_n^{n+1} |f^{\\prime}(t)|\\ dt )")#text(" for any integer ")#mi("n")#text(". This already deals with the case when ")#mi("x,y")#text(" are integers by splitting ")#mi("[x,y]")#text(" into intervals ")#mi("[n,n+1]")#text("; to handle the general case one just needs to handle two short intervals near the endpoints ")#mi("x,y")#text(" which end up being controlled by the ")#tao-math("O( \\int_y^x |f^{\\prime}(t)|\\ dt + \\left|f(y)\\right| )", block: false)#text(" error term (which controls the sup norm of ")#mi("f")#text(" on ")#mi("[x,y]")#text(", thanks to the fundamental theorem of calculus).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-521315")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("[…] Elementary multiplicative number theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-521424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2019")])]

#text("There is a “formula does not parse” error after “Comparing with (9), (14), (16) we see that {f} behaves approximately like”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-528574")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] Section 5 of Notes 1 (indeed this is essentially the same argument as in that section, dressed up in probabilistic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-532951")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] preferred in some of the literature cited here.) For instance, as we established in Theorem 58 of Notes 1, the prime number theorem is equivalent to the assertion […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195fe8df264fe6d1254e3292cca14244b7cde366291d246923466a353eb46a91-c63e64ce1bb29ed409dfc50d6b0d09529a886a2b63af8b0a28b2b60ffffa48b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yu-Chen Sun")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-557202")[#strong[#text("Yu-Chen Sun")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" The exercies 9 might not be true, because when k = 0, the error term has to be O(1) rather than O_{k} (1/x)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195fe8df264fe6d1254e3292cca14244b7cde366291d246923466a353eb46a91-c63e64ce1bb29ed409dfc50d6b0d09529a886a2b63af8b0a28b2b60ffffa48b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yu-Chen Sun")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-557204")[#strong[#text("Yu-Chen Sun")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("Sorry for not noticing that Q_k is a ploynomial")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cc01096dfae0d47d35cb3171f7dad28225c1afc36014761583d461d23d7397c-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Desgrottes")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-579084")[#strong[#text("Mike Desgrottes")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("For exercise 39, I was able to get the results by using the result from exercise 37, but would this imply that 39(i) holds as x goes to infinity? I’m not sure how to get the same results for a specific x. Any help would be appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-579136")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("I’m not sure I understand the question. Due to the presence of the ")#mi("o(1)")#text(" error, both Exercise 37 and Exercise 39(i) only have content in the asymptotic limit ")#mi("x \\to \\infty")#text(", and do not make any assertions about any fixed choice of ")#mi("x")#text(" (though with more effort one could sharpen the ")#mi("o(1)")#text(" error to something more quantitative and effective that would have content for fixed ")#mi("x")#text(" as well).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cc01096dfae0d47d35cb3171f7dad28225c1afc36014761583d461d23d7397c-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Desgrottes")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-579393")[#strong[#text("Mike Desgrottes")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2020")])]

#text("Thank you. I think I forgot about the error.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-584882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2020")])]

#text("I am in the process of learning analytic number theory, with one of my materials being these lecture notes. I feel that while I understand the high level overviews, the proofs feel often quite technical and sometimes even unmotivated. (These notes do contain more motivation and intuition than some other materials, which has been very helpful in learning.) To me it seems that analytic number theory *is* technical, which makes it difficult to really understand the proofs. (Though perhaps this gets easier over time.) Any thoughts on overcoming this? Thanks.")

#text("To pinpoint on something specific, Notes 3 (link: ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")]#text(") contains a proof of the Bombieri-Vinogradov theorem, and while there is a nice overview about using a suitable factorization for the von Mangoldt function, in the end the proof is (to me) quite technical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-586490")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2020")])]

#text("I have some general on how to read mathematical texts in the second half of ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("https://terrytao.wordpress.com/advice-on-writing-papers/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 1: A little bit of algebraic number theory (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-601784")[#strong[#text("254A, Supplement 1: A little bit of algebraic number theory (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2020")])]

#text("[…] Dirichlet characters, thus connecting the material discussed above with the last section of the previous set of notes. Here is a typical instance of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/565cc4f24ae487569bf8d1cf0238d083778cdbfb8c5ba67512f7f0d1545533de-6ce5f428bb2b46ca5191abfe64b463994560d6192dc62bdf0c71e08fa88b3976.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of limsup")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-606290")[#strong[#text("limsup")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("Not quite sure about what you meant at the end of Remark 3. First, I think there is a typo in the definition of f and it should be f(t)=cos(2pi t) and thus the sum remains bounded as well (see")#linebreak()#text(" ")#link("https://math.stackexchange.com/questions/17966/how-can-we-sum-up-sin-and-cos-series-when-the-angles-are-in-arithmetic-pro")[#text("https://math.stackexchange.com/questions/17966/how-can-we-sum-up-sin-and-cos-series-when-the-angles-are-in-arithmetic-pro")]#text(" ). Otherwise, I am afraid I did not get your point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-606341")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("Thanks for the correction. Note that ")#mi("\\sum_{y \\leq n \\leq x} \\cos(2\\pi n) = \\sum_{y \\leq n \\leq x} 1 = \\lfloor x\\rfloor - \\lfloor y \\rfloor")#text(" grows linearly in ")#mi("y-x")#text(" (the formula you linked to is only valid when the denominator is non-zero).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Prendiville")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-624059")[#strong[#text("Sean Prendiville")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2021")])]

#text("Should Exercise 9 have O_k(1+log^k(2+x)/x) in (14) (and similarly for (15))? Certainly for k=0 one needs to account for Euler’s constant, and such constants seem to persist for higher values of k,l in my solution.")

#emph[#text("[Euler’s constant can be absorbed into the ")#mi("Q_k")#text(" polynomial. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Prendiville")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-624368")[#strong[#text("Sean Prendiville")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2021")])]

#text("Thanks. Should the parenthetical comments then be altered (‘in fact Q_k is exactly equal to ….’), or am I still missing something?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Prendiville")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-625096")[#strong[#text("Sean Prendiville")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2021")])]

#text("Sorry to be a bore about this, but in part (ii) of Exercise 9, I get that Q_{k,l} is exactly equal to \\frac{ k! l! }{(k+l+1)!} t^{k+l+1} + \\sum_{m=0}^l \\binom{l}{m} (-1)^m c_{k+m} t^{l-m}, where c_k is the constant term for Q_k. So for instance, Q_{0,1} = (1/2) t^2 + \\gamma t – c_1.")

#emph[#text("[Fair enough, I have deleted the additional remark about this – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-635691")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] now move away from the world of multiplicative prime number theory covered in Notes 1 and Notes 2, and enter the wider, and complementary, world of non-multiplicative prime number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-637367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2021")])]

#text("In exercise 37, shouldn’t it be piecewise continuous instead of Riemann integrable? Thanks for the post; really enjoyed it.")

#emph[#text("[Once you can handle the piecewise continuous (or piecewise constant) case, the Riemann integrable case follows by upper and lower approximation (cf., the equality between the Riemann integral and the Darboux integral). -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-637720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2021")])]

#text("Thank you for the reply! What I don’t understand is how this could be true if you allow for a countable number of discontinuities. Here’s how I was thinking you could construct a counterexample:")

#text("Let ")#mi("f")#text(" be some Riemann integrable function satisfying the necessary hypotheses of the exercise. Define the countable collection of points ")#mi("S = \\{ \\frac{\\log p }{\\log x}: p \\text{ prime}, \\, x \\in \\{2,3,4, \\dots\\}\\}")#text(". Define ")#mi("F(x)")#text(" to be ")#mi("2f(x)")#text(" whenever ")#mi("x \\in S")#text(" and ")#mi("f(x)")#text(" otherwise. Since ")#mi("F=f")#text(" almost everywhere, then ")#mi("F")#text(" is also Riemann integrable and so satisfies the conditions needed in the exercise. Thus, whenever ")#mi("x")#text(" is a large integer, we have")#linebreak()#text(" ")#mi("\\displaystyle{2\\sum_p \\frac{1}{p} f \\Big{\\left( \\frac{\\log p }{\\log x } \\right)}=\\sum_p \\frac{1}{p} F \\Big{\\left( \\frac{\\log p }{\\log x } \\right)} =  \\int_0^\\infty F(t) \\frac{dt}{t} + o(1) .}")#linebreak()#text(" We could then apply the exercise again for ")#mi("f")#text(". Since the integral on the right-hand side of the above equation is the same when ")#mi("F")#text(" is replaced by ")#mi("f")#text(", this would apply that for any integer ")#mi("x")#text(", we would have ")#mi("\\sum_p \\frac{1}{p} f \\Big{\\left( \\frac{\\log p }{\\log x } \\right)} = o(1)")#text(". Sorry if I’m totally confused about all of this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-637728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2021")])]

#text("It is not true that if f is Riemann integrable and F = f almost everywhere, then F is Riemann integrable. For example, the indicator function of the rational numbers is equal to the zero function almost everywhere, but the former is not Riemann integrable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-637737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2021")])]

#text("Yes, of course. And I guess in my case, ")#mi("F")#text(" would no longer be continuous almost everywhere and so wouldn’t be Riemann integrable. Sorry about that and thanks for clarifying.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-660254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2022")])]

#text("Do you have any suggestions for a complementary textbook for this set of notes?")

#emph[#text("[Montgomery-Vaughan or Bateman-Diamond would be appropriate. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-660378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2022")])]

#text("Applying Lemma 2 directly, in (8), one has")#linebreak()#text(" ")#tao-math("\\displaystyle \\int_1^x\\log(t)dt+O(\\left|\\log x\\right|)=x\\log x-(x-1)+O(\\left|\\log x\\right|).", block: false)#linebreak()#text(" How do you get the term ")#mi("O(\\log(2+x))")#text(" from ")#tao-math("1+O(\\left|\\log x\\right|)", block: false)#text("?")

#emph[#text("[We have ")#mi("1 = O(\\log(2+x))")#text(" and ")#mi("\\log x = O(\\log(2+x))")#text(" when ")#mi("x \\geq 1")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-667803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2022")])]

#text("The exponents ")#mi("k")#text(" and ")#mi("l")#text(" seem to be “symmetric” in the integral ")#mi("\\int_1^x \\log^kx \\log^l\\frac{x}{t}dt")#text(". Does one also have a term ")#mi("xP_{l,k}(\\log x)")#text(" in the bound (10)? Or is it somehow absorbed somewhere?")

#text("If both k, l >0, integration by parts gives")#linebreak()#text(" ")#mi("\\displaystyle \\int_1^x\\log^kt\\log^l\\frac{x}{t}dt =-\\int_1^xk\\log^{k-1}t\\log^l\\frac{x}{t}dt+ \\int_1^xl\\log^kt\\log^{k-l}\\frac{x}{t}dt")#linebreak()#text(" The first term contributes a factor of ")#mi("k")#text(" while the second gives an ")#mi("l")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-667957")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("If one applies induction on l and k,")#linebreak()#text(" ")#mi("\\displaystyle \\int_1^x\\log^kt\\log^l\\frac{x}{t}dt =")#linebreak()#text(" ")#mi("\\displaystyle -\\int_1^xk\\log^{k-1}t\\log^l\\frac{x}{t}dt+ \\int_1^xl\\log^kt\\log^{k-l}\\frac{x}{t}dt")#linebreak()#text(" ")#mi("\\displaystyle =-kxP_{k-1,l}(\\log x)+l xP_{k,l-1}(\\log x)+O(\\log^{k+l-1}(2+x))")#linebreak()#text(" ")#mi("\\displaystyle =-kxP_{k-1,l}(\\log x)+xP_{k,l}(\\log x)+O(\\log^{k+l-1}(2+x))")#linebreak()#text(" How does one get")#linebreak()#text(" ")#mi("\\displaystyle -kxP_{k-1,l}(\\log x)+O(\\log^{k+l-1}(2+x)) =O(\\log^{k+l}(2+x))?")#linebreak()#text(" It is trivial to get ")#mi("O(\\log^{k+l-1}(2+x)) =O(\\log^{k+l}(2+x))")#text(". But is it possible to get")#linebreak()#text(" ")#mi("-kxP_{k-1,l}(\\log x)=O(\\log^{k+l}(2+x))")#text("?")

#emph[#text("[I have no idea how you are justifying your first identity here, this is certainly not a standard integration by parts. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-667968")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("I used")#linebreak()#text(" ")#mi("\\displaystyle \\int_1^xf(t)dt=f(t)t|_1^x-\\int_1^xf^{\\prime}(t)tdt")#linebreak()#text(" with")#linebreak()#text(" ")#mi("\\displaystyle f(t)=\\log^kt\\log^l\\frac{x}{t}")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\displaystyle f^{\\prime}(t) = \\frac1t k\\log^{k-1}t\\log^l\\frac{x}{t} +l\\log^{l-1}\\frac{x}{t}(\\frac{-1}{t})")#linebreak()#text(" Also, ")#mi("f(x)=f(1)=0")#text(". Do I get something wrong here?")

#text("Ah… I guess the confusion may be that in your notation, ")#mi("\\log^2x=\\log(\\log(x))")#text(" instead of ")#mi("\\log^2x=(\\log x)^2")#text(" as in ")#mi("\\sin^2x=(\\sin x)^2")#text("??")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-667969")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("I meant to write above that")#linebreak()#text(" ")#mi("\\displaystyle f^{\\prime}(t) = \\frac1t k\\log^{k-1}t\\log^l\\frac{x}{t} +l\\log^kt\\log^{l-1}\\frac{x}{t}(\\frac{-1}{t})")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-667970")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("No, here ")#mi("\\log^k x")#text(" is the ")#mi("k^{th}")#text(" power of ")#mi("x")#text(".")

#text("Now that I understand what you are trying to calculate, you should just recursively define ")#mi("P_{k,l}(t)")#text(" equal to ")#mi("-k P_{k-1,l}(t) + l P_{k,l-1}(t)")#text(" for ")#mi("k,l \\geq 1")#text(" (with the initial condition ")#mi("P_{0,0}=1")#text(", and some modifications to the formula in the boundary cases ")#mi("k=0")#text(" and ")#mi("l=0")#text(") and your calculation then gives the formula ")#mi("\\int_1^x \\log^k t \\log^l \\frac{x}{t}\\ dt = xP_{k,l}( \\log x) + O_{k,l}(\\log^{k+l-1}(2+x))")#text(" by induction.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668250")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("How would you deal with the boundary cases when ")#mi("k=0")#text("? Particularly what is ")#mi("P_{0,l}(t)")#text("? (10) says it should be just ")#mi("l!")#text(". But")

#mi("\\displaystyle \\int_1^x\\log^l\\frac{x}{t}dt=t\\log^l\\frac{x}{t}|_1^x -l\\int_1^x  t\\cdot (\\frac{-1}{t})\\cdot\\log^{l-1}\\frac{x}{t}dt")#linebreak()#text(" ")#mi("\\displaystyle =-\\log^l\\frac{x}{t}+l\\int_1^x  \\log^{l-1}\\frac{x}{t}dt")#linebreak()#text(" which seems to give the bound ")#mi("P_{l,0}(\\log x)")#text(" with ")#mi("P^{l,0}(t)=t^l+\\cdots")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668251")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#mi("P^{l,0}")#text(" in the last display above is meant to be ")#mi("P_{l,0}")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-667963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("There is no symmetry in ")#mi("k,l")#text(" here (the change of variables ")#mi("t \\mapsto x/t")#text(" does not preserve the additive Haar measure ")#mi("dt")#text(", only the multiplicative Haar measure ")#mi("dt/t")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668417")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("Above Exercise 56, the formula (in the proof of Lemma 55)")#linebreak()#text(" ")#mi("\\displaystyle \\frac{1}{k} \\sum_{d \\leq x} \\frac{\\mu(d)}{d} \\log^k \\frac{x}{d}")#linebreak()#text(" ")#mi("\\displaystyle = \\log^{k-1} x + P( \\log x ) + O_k(1 + \\sum_{d \\leq x} \\frac{1 + \\log^{k-1} \\frac{x}{d}}{x} )")#linebreak()#text(" does not show up completely.")

#emph[#text("[The post has now undergone a major revision (for unrelated reasons), and in particular this overflow is now corrected. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668423")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("According to the conclusion in Exercise 4:")

#mi("\\displaystyle \\sum_{n \\leq x} \\log^l \\frac{x}{n} = x P_{0,l}(\\log x) + O_{l}(\\log^{l}(2+x)) \\ \\ \\ \\ \\ (10)")#linebreak()#text(" for all ")#mi("{x \\geq 0}")#text(" and some polynomial ")#mi("{P_{0,l}(t)}")#text(" with leading term ")#mi("{l! t^0}")#text(".")

#text("In other words, one has")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n \\leq x} \\log^l \\frac{x}{n} = x l! + O_{l}(\\log^{l}(2+x)) \\ \\ \\ \\ \\ (10^{\\prime})")

#text("But by applying Lemma 2, I got")#linebreak()#text(" ")#tao-math("\\displaystyle \\sum_{n \\leq x} \\log^l \\frac{x}{n} = \\int_1^x\\log^l\\frac{x}{t}dt+O(\\left|\\log^l x\\right|)", block: false)#linebreak()#text(" The ")#tao-math("O(\\left|\\log^l x\\right|)", block: false)#text(" is dominated by ")#mi("O_{l}(\\log^{l}(2+x))")#text(" for ")#mi("x\\ge 1")#text(". But I don’t get ")#mi("\\int_1^x\\log^l\\frac{x}{t}dt=x l! + O_{l}(\\log^{l}(2+x))")#text(".")

#text("Using the calculation mentioned above (with the typos corrected), I got")#linebreak()#text(" ")#mi("\\displaystyle  \\int_1^x\\log^l\\frac{x}{t}dt= t\\log^l\\frac{x}{t}|_1^x  -l\\int_1^x  t\\cdot (\\frac{-1}{t})\\cdot\\log^{l-1}\\frac{x}{t}dt")#linebreak()#text(" ")#mi("\\displaystyle  =-\\log^lx+l\\int_1^x  \\log^{l-1}\\frac{x}{t}dt")#linebreak()#text(" ")#mi("\\displaystyle =-\\log^lx-l\\log^{l-1}x-\\cdots -l!\\log x+x")#linebreak()#text(" How can one get the desired bound ")#mi("x l! + O_{l}(\\log^{l}(2+x))")#text(" as in (10)?")

#text("(Am I thinking too hard or just missing something…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668447")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("The last term in your expansion should be ")#mi("xl!")#text(". All the other terms are ")#mi("O_l(\\log^l(2+x))")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668511")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2022")])]

#text("Ah, thanks! Just realize that this exercise has now been moved to be after Exercise 7. I naively applied Lemma 2 without noticing that the function is not monotone.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668529")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2022")])]

#text("What is the definition of the symbol ")#mi("\\ll")#text(" in Proposition 12：")#linebreak()#text(" ")#mi("\\displaystyle  \\sum_{n \\leq x} \\Lambda(n) \\ll x")#linebreak()#text(" I don’t find one in this set of notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-668747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2022")])]

#text("f(x)<<g(x) means f(x)=O(g(x)), see the big O notation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/889e2c49704f0511448d7a57c61ca00b531b046130568999a184f5ac54fd063c-a65039254ee02c31c2f2be7d59a197e1868ecfde8b7b15e52905756d2b58e4fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian(myname)Math")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-677638")[#strong[#text("Christian(myname)Math")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2023")])]

#text("What did you mean by O(g(1))?")

#emph[#text("[This means a quantity bounded in magnitude by ")#mi("C g(1)")#text(" for some absolute constant ")#mi("C")#text(", as per standard ")#link("https://en.wikipedia.org/wiki/Big_O_notation")[#text("big-O notation")]#text(". See also ")#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")[#text("this blog post")]#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a99ff6510a8a29e2abb2e05b699aafb3325781e06b8556fc768f21edf986eef-386503048e66b80da023ec3ad5b52b9ade51b6fef3986a4c42c4eae8b8ddb4bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yong Zhou")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-681168")[#strong[#text("Yong Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("Dear Prof. Tao.")#linebreak()#text(" The proof of Theorem 58:")#linebreak()#text(" Let ")#mi("\\varepsilon>0")#text(" be a small fixed quantity. For ")#mi("\\varepsilon x < d \\leq x")#text(", ")#mi("\\lfloor \\frac{x}{d} \\rfloor")#text(" decreases through a fixed set of values, and from (ii) we conclude that")

#mi("\\displaystyle  \\sum_{\\varepsilon x < d \\leq x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor = o(x).")

#text("I don't get why ")#mi("\\lfloor \\frac{x}{d} \\rfloor")#text(" decreases through a fixed set of values, and then")

#mi("\\displaystyle  \\sum_{\\varepsilon x < d \\leq x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor = o(x).")

#text("Might be ")#mi("{\\lfloor \\frac{x}{d} \\rfloor}")#text(" repalce by any other fixed set of values ")#mi("{a_k}")#text(" and then we have")

#mi("\\displaystyle  \\sum_{\\varepsilon x < d \\leq x} \\mu(d)     a_k= o(x)")

#text("the above property due to ")#mi("\\mu(d)")#text(" have an strong cancellation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-681185")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("Suppose for instance that ")#mi("\\varepsilon = 1/3")#text(". Then as ")#mi("d")#text(" increases from ")#mi("x/3")#text(" to $x$, the quantity ")#mi("\\lfloor \\frac{x}{d} \\rfloor")#text(" will first equal ")#mi("2")#text(" (in the range ")#mi("x/3 < d \\leq x/2")#text("), and then decrease to ")#mi("1")#text(" (in the range ")#mi("x/2 < d \\leq x")#text(", so that")

#mi("\\displaystyle \\sum_{\\varepsilon x < d \\leq x} \\mu(d) \\lfloor \\frac{x}{d} \\rfloor = 2 \\sum_{x/3 < d \\leq x/2} \\mu(d) + \\sum_{x/2 < d \\leq x} \\mu(d).")

#text("From (ii), both of the sums on the right-hand side are ")#mi("o(x)")#text(", so the left-hand side is also. (Here it is important that ")#mi("\\varepsilon")#text(" remain fixed, as opposed to depending on ")#mi("x")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding sums or integrals of non-negative quantities | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-681884")[#strong[#text("Bounding sums or integrals of non-negative quantities | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("[…] are reals and is monotone (either increasing or decreasing); see Lemma 2 of this previous post. Such bounds allow one to switch back and forth quite easily between sums and integrals as long as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("I’m wondering if I can get a hint for exercise 16 part (ii)? I recognize that if ")#mi("[a,b]")#text(" is the support of ")#mi("f")#text(" then the sum runs over the primes in ")#mi("[x^a, x^b]")#text(" as in part (i) but i am unsure how to proceed. My instinct is to use partial summation to get an integral but the derivative of ")#mi("f")#text(" does not appear in the integrand. Also the argument of ")#mi("f")#text(" being a quotient of logarithms is a little unusual and slightly off-putting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2024")])]

#text("Is it accurate to say that Rankin’s trick is a trick used to find upperbounds for logarithmic sums of f(n), which depends upon one having an estimate for the Dirichlet series associated to f?")

#text("Is Rankin’s trick useful in modern research? Or is it more of a cute observation to get “cheap” fast bounds?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685460")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("Rankin’s trick is indeed optimized for quickly obtaining upper bounds of logarithmic sums of arithmetic functions that are typically only off from the truth by a constant factor; because of this, it also can be sometimes used to quickly bound ordinary sums with losses that are often logarithmic in nature. This can be good enough for various research applications; for instance, Rankin trick bounds sufficed for me in my recent paper ")#link("https://arxiv.org/abs/2405.11610")[#text("https://arxiv.org/abs/2405.11610")]#text(" . There are more sophisticated methods (e.g., complex analytic methods) that can give far greater precision, but in situations where such precision is not needed, it can make sense to use the cruder bounds from Rankin’s trick, in order to not distract the reader from the more interesting components of an argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2024")])]

#text("Is there a mistake in equation (50) in the final sum (specifically the argument of the Von Mangoldt function). If I’m not mistaken I think the error carries on to the ensuing calculation.")

#emph[#text("[I do not see any issue, can you be more specific? -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("I think it should be ")#mi("\\Lambda(n)\\sum_{d \\leq \\frac{x}{n}}f(nd)")#text(" in equation (50).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("Can I get a hint for Exercise 40?")

#text("Also exercise 40 has typos I think “pgx” should be logx.")

#emph[#text("[Corrected, thanks. What have you tried so far on the exercise? For instance, have you tried simple choices of ")#mi("a, q")#text(" to begin with? -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-2/#comment-685654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2024")])]

#text("Figured this out!")

#text("For anyone with a similar question:")

#text("My confusion was I tried using Theorem 36 which gives estimates for “Mean values of divisor type multiplicative functions” which worked for the previous couple exercises.")

#text("What worked was simply expressing ")#mi("\\tau(n) = \\sum_{d | n} 1")#text(" and proceeding from there.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2014")])]

#text("Good")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76b680da4cc56180b168101d98497124b6cab3d4b3d3fed25a92dfdd74909bc0-c88284a62c4531cae2f2d6aa011912e29e39c4f4c43e79df1d8c0f86b95417e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MaDiha HouRi")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442283")[#strong[#text("MaDiha HouRi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442330")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Beyond excellence!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442354")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Reblogged this on ")#link("http://tomcircle.wordpress.com/2014/11/24/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442374")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Can theorem 7 be generalized for any ")#mi("k \\geq 0")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442386")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Yes (after replacing factorials with Gamma functions, of course), for instance by using the arguments of ")#link("http://www.ams.org/mathscinet-getitem?mr=131389")[#text("Wirsing")]#text(" (which are basically a refined version of what is needed to solve Exercise 12, which also works for non-integer k). I’ve updated the notes with this remark.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442410")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Thanks! (in fact, this seems plausible because part (i) is proved for any ")#mi("k \\geq 0")#text(", and the main terms of parts (ii), (iii) can be calculated by Perron’s formula from the main term in (i). Although the estimation of the remainder terms in (ii), (iii) seems to be the real difficulty!)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442482")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Equation (8) is identical to the equation before it.")

#emph[#text("[Duplicate equation removed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("Is there a sign error in the “In particular” part of Lemma 2(ii)?")

#emph[#text("[No, but I have swapped around x and y to avoid the confusion. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442572")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("I see now. Sorry.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of schlafly")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442571")[#strong[#text("schlafly")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("Do you always exclude zero from N, the natural numbers? Maybe that is more convenient for 19th century multiplicative number theory, but including the additive identity seems preferable for just about every other area of math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("The convention does vary with the field, see my earlier comment at ")#link("https://terrytao.wordpress.com/books/analysis-i/#comment-439818")[#text("https://terrytao.wordpress.com/books/analysis-i/#comment-439818")]#text(" . Personally, when such minor notational conflicts occur, I believe it better to adapt the notation to the local application at hand, rather than artificially enforce a globally consistent notation, the justification for which may be completely irrelevant for the application.")

#text("In number theory, for instance, both the fundamental theorem of arithmetic and the definition of the zeta function (and other Dirichlet series) are much more natural to state if zero is excluded from ")#mi("{\\bf N}")#text(". These concepts (and their generalisations to other number fields, etc.) are both fundamentally important concepts to the subject (in the 19th, 20th, or 21st centuries), so it makes sense to reserve the symbol ")#mi("{\\bf N}")#text(" in this context for the multiplicative natural numbers ")#mi("\\{1,2,3,\\dots\\}")#text(". In contrast, the additive natural numbers ")#mi("\\{0,1,2,3,\\dots\\}")#text(" plays a much more minor role in analytic number theory; in most cases, the multiplicative natural numbers or the integers ")#mi("{\\bf Z}")#text(" can be used instead as a substitute. (Perhaps the one exception is in combinatorial number theory, in which cardinalities of (possibly empty) sets play a more prominent role, although even in those cases the empty set case is often degenerate and needs to be removed anyway.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442613")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("In the discussion after (26), there is the temporary requirement that $s>1$ is sufficiently close to 1. This appeared in the formal derivation of (25), but as far as I could tell the rigorous derivation in Exercise 8 is valid for all $s>1$. Or did I miss something here?")

#emph[#text("[You’re right, the restriction is unnecessary (since ")#mi("\\zeta(s)")#text(" is clearly non-zero for all ")#mi("s \\geq 1")#text("). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442615")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("In the second equation of (15), it looks as though the main term should be ")#mi("(-1)^k k!/(s-1)^{k+1}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442752")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2014")])]

#text("Holy cow, that’s lecture 1? That looks like a whole course!")

#text("Slightly more substantively, I now know a new argument for nonvanishing of ")#mi("L(1, \\chi)")#text(", thanks. It’s interesting that you manage to use a computation at ")#mi("s=1/2")#text(" to control what happens at ")#mi("s=1")#text("; is there some intuitive way to think about that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2014")])]

#text("I don’t plan to cover all of the sections of the notes explicitly in class (for instance, I will skip Section 5). I expect this set of notes to take maybe five lectures to get through.")

#text("The way I think of the ")#mi("s=1/2")#text(" argument is that this exponent is the natural exponent associated to the squares ")#mi("\\{1, 4, 9, 16, \\dots\\}")#text(", just as ")#mi("s=1")#text(" is the natural exponent associated to the natural numbers ")#mi("\\{1,2,3,\\dots\\}")#text(". The argument here is exploiting information at the squares, namely that ")#mi("1 * \\chi \\geq 1")#text(" on the square numbers, so ")#mi("s=1/2")#text(" is the natural place to try to manipulate that information at the Dirichlet series level. But by the same token, the fact that ")#mi("s=1/2")#text(" is so far from ")#mi("s=1")#text(" makes this argument quite poor from a quantitative point of view.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-452323")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2015")])]

#text("My feeling on this 1/2 v.s. 1 problem is a little different: it is because we are not powerful enough (at this point) to directly show the Dirichlet series of ")#mi("1*\\chi")#text(" diverges at 1. If we were allowed to use quadratic residues, we would be able to include something more than the squares, e.g., integers of the form ")#mi("x^2-dy^2")#text(", which must have an even number of factors of ")#mi("p")#text(" of which ")#mi("d")#text(" is not a quadratic residue. Now the set of integers has enough density to allow us to take s=1 and still get divergence… But wait, am I cheating by implicitly using something related to the class number?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-442765")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2014")])]

#text("From the proof of theorem 7, it seems that condition (38) can be relaxed to")#linebreak()#text(" ")#mi("f(p) = k + O_k(p^{- \\varepsilon})")#linebreak()#text(" For any fixed ")#mi("\\varepsilon > 0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f24d279d7db6d0474bffaf110e99c6a2db242a1cf27848aea5609aa638dd52e4-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maga Péter")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443090")[#strong[#text("Maga Péter")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2014")])]

#text("Beautiful notes! Thanks.")

#text("In the last display of Theorem 10 (second Mertens’), {\\log \\log} should be. The middle display of Corollary 18 (cheap Brun-Titchmarsh) is an inequality. The hyperlinks (42) point to (36). In Exercise 21, ‘itme’ is written.")

#emph[#text("[Corrected, thanks, though I am unsure what the first issue was – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f24d279d7db6d0474bffaf110e99c6a2db242a1cf27848aea5609aa638dd52e4-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maga Péter")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443121")[#strong[#text("Maga Péter")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2014")])]

#text("Sorry, I mean the proof of Theorem 10. I guess the integral in the last display is evaluated incorrectly, it should be ")#mi("\\log \\log x - \\log \\log y")#text(" in place of ")#mi("\\log x - \\log y")#text(". And also ")#mi("log y/log x - 1")#text(" in place of ")#mi("- log y/log x + 1")#text(". Sorry if speak nonsense.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2014")])]

#text("(24) is undefined for ")#mi("x=1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2014")])]

#text("In (25) ")#mi("O_k(\\frac{1}{p^2})")#text(" can be replaced (as in (39)) by ")#mi("O_k(\\frac{1}{p})")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443190")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("Here’s an entry for the most trivial typo competition: There is a repeated ‘the’ half way through the proof of Theorem 7 (iii).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443250")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("For the base case ")#mi("k=0")#text(" of Theorem 7 (ii) when you’re estimating the tail of the Dirichlet series, I think you need to take a power greater than 1/2 to ensure that ")#tao-math("\\sum_{n=1}^\\infty \\left|f(n)\\right|/n^\\alpha = O(1)", block: false)#text(". If ")#mi("f(p^2)=1")#text(" for all ")#mi("p")#text(" and ")#mi("f(p^j)=0")#text(" for all other powers and you use the square root, then you get ")#mi("\\prod (1+1/p)")#text(". Is this right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443255")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("I think the same issue arises in the ")#mi("k=1")#text(" case of Theorem 7(iii).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443252")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("For the inductive step of Theorem 7(ii), I think there’s a small mistake in the relationship between ")#mi("\\sum g(p^j)/p^j")#text(" and ")#mi("\\sum f(p^j)/p^j")#text(". I think it should read ")#mi("(1-1/p)^{-1}\\sum g(p^j)/p^j=\\sum f(p^j)/p^j")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443278")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("I think there is a mistake in Exercise 16 (i). If ")#mi("M_f(x)=c\\log^k x+O_k(\\log^{k-1}(2+x))")#text(", then ")#mi("(1/\\log x)\\int_1^x M_f(t)dt/t=M_f(x)/(k+1)+O(\\log^{k-1}(2+x)")#text(" (that is there is a extra factor of ")#mi("k+1")#text(" that does not appear in the integral equation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443286")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("I think the middle term of (41) should be ")#mi("2\\times 1_{\\le \\sqrt {x}}*1")#text(". Also, this term shows up 6 lines below (but it is the ")#mi("1_{\\le\\sqrt {x}}")#text(" that is used in the calculation).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d1e8524076171c12ae4d45145b6fcd6a22fafb0c256d0d17940a7b8351fff8-7dccf94ca8b29f3c9ea02e229abf05db0755c35ac93f39ffc1a19f25e2cbfe9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443349")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2014")])]

#text("Can anyone help me understand how Lemma 1 implies equation 8? Where does the log(2+x) in equation 8 come from?")

#emph[#text("[Apply Lemma 1 with ")#mi("f(t) := \\log t")#text(" and ")#mi("y=1")#text(". The ")#mi("O(\\log(2+x))")#text(" is a convenient form of the error term that can absorb both the ")#mi("O(1)")#text(" and the ")#mi("O(\\log x)")#text(" errors that arise from Lemma 1. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443398")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2014")])]

#text("In Exercise 21(i), presumably ")#mi("u")#text(" should be greater than 1 for the statement to make sense.")

#emph[#text("[Actually, I believe the statement is still true (albeit somewhat trivial) in the ")#mi("u<1")#text(" regime. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443509")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("So I think (48) has a sign error. Also, I think it follows more from (21) and (28) rather than (29).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443512")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("I think there’s a superfluous ")#mi("j")#text(" exponent in the principal term of the right side of the first equation in Corollary 9.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("In Lemma 2 (ii), if taking y=1 in (i), should c= – F(1)+O(g(1))?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82107e4192a7d0d0712810d2fbc888629ea870d4f1069955b3304d0f508e9ab6-9d6adbd323b978c92e8e75137874f245a6813e6e9a92daadf2a6c24142bf8307.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cnpde")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443523")[#strong[#text("cnpde")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("Reblogged this on ")#link("http://cnpde.wordpress.com/2014/12/01/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Qingtian's Garden 晴天的后花园")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443547")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("A typo and two comments/questions.")

#text("Typo: In the last line of Lemma 15, the polynomial ")#mi("P")#text(" should be ")#mi("R")#text(".")

#text("Q1: I hope it’s OK that I’m pointing out a succession of essentially trivial corrections. I’ve always wanted to know something about this field, and am trying to read through the notes in detail and do the exercises. Let me know if you’ve had enough of me point out these minor issues;")

#text("Q2: Having now spent a chunk of time reading these notes, I have a minor formatting comment. The fact that there are many different parallel indexing sequences (Theorems/Lemmas in one sequence; Exercises in another; Remarks in another) makes eyeball navigation using scrollbars a bit tricky (for me at least).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("Thanks for all the corrections! Given that my class will be going through these notes soon, I am sure they will appreciate all the proofreading.")

#text("As an experiment, I have put all the theorems/lemmas, remarks, and exercises under a single numbering system (which makes some of the previous references to the numbering in the blog comments to now be incorrect, unfortunately). It would be good to get some feedback as to whether this is an improvement that should be continued in subsequent notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443551")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("In (59), I wonder if you need to point out that ")#mi("L(f*g)")#text(" means the pointwise product of ")#mi("L(n)")#text(" and ")#mi("f*g(n)")#text(". I spent some time trying to understand why this was true as a composition(!)")

#emph[#text("[Clarified, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443637")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2014")])]

#text("In the proof of Theorem 16, at the beginning of the proof of (ii) and (iii) jointly imply (i), I think the equality should read ")#mi("1=1*1*\\mu = \\tau*\\mu")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443651")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2014")])]

#text("So I’m having a hard time understanding the error term in the displayed equation prior to (76). The error term in the sum of the ")#mi("1/\\sqrt {m}")#text(" is of size ")#mi("O(\\sqrt{d/x})")#text(". This is divided by ")#mi("\\sqrt {d}")#text(" (giving ")#mi("O(x^{-1/2})")#text(") and summed over ")#mi("x\\le d")#text(". Why is this ")#mi("O(1)")#text("? Apologies if I’m missing something obvious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443723")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("I think you can write the ")#mi("O(\\sqrt{d/x})")#text(" term as ")#mi("c(x/d)^{-1/2}+O((x/d)^{-3/2})")#text(". This seems that it would be enough to control the error, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443729")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("Unfortunately it’s more complicated than that because ")#mi("x/d")#text(" need not be an integer. But actually the Dirichlet hyperbola method works here (the usual proof in fact uses this method; I had experiented with not using this method to try to simplify the argument and made an error in the computations); I’ve reverted back to that proof here.")

#text("An alternative method is to use a smoother sum, such as ")#mi("\\sum_n (1*\\chi)(n) \\psi(n/x)")#text(" for some bump function ")#mi("\\psi")#text(" supported on some compact interval in ")#mi("(0,+\\infty)")#text(". It is particularly convenient to take ")#mi("\\psi")#text(" of the form ")#mi("\\psi(t) = \\int_0^\\infty \\phi(s) \\phi(\\frac{t}{s}) \\frac{ds}{s}")#text(" for some other bump function ")#mi("\\phi")#text(" supported near ")#mi("1")#text(", since in that case the sum factors cleanly as ")#mi("\\int_0^\\infty (\\sum_d \\phi(d/y)) (\\sum_m \\chi(m) \\phi(m/(x/y))) \\frac{dy}{y}")#text(". Actually this is ultimately the superior way to proceed here (it ends up giving a lower bound on ")#mi("L(1,\\chi)")#text(" that is polynomial in q rather than exponential in q), but is further from the spirit of the elementary approach of this blog post, so I did not detail it here (it is more of a Fourier-analytic approach, as one needs things like the Poisson summation formula to get the best estimates).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52a5b6041caef3d72428cbbb7c02a1dab44bb4ee0e83dc48002f93fb2cc30a10-ed14da61abe4b2a432c2437dba18b04774429511dd909720bd1197648369fd75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of apatch")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443726")[#strong[#text("apatch")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("Should the error term in (10) above be of order ")#mi("log^{k+l}(2+x)")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("The alternate notation ")#mi("d(n)")#text(" for the divisor function may be used in cases when ")#mi("\\tau(n)")#text(" denotes Ramanujan tau function (which is also multiplicative.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/362e144982f3fc99b95b0d096fa6f5eb28ecc52dc28e2ae2b97258ee2e65d61d-e20fbfb5ee20fd2d31da29c5898e770b35c6a37338b9dfc0032f8a540ba0c556.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Enrique Treviño")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443860")[#strong[#text("Enrique Treviño")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("In the proof of proposition 18 it seems one should take into account the case ")#mi("n=1")#text(". If ")#mi("n = 1")#text(", then ")#mi("\\Lambda(dn)\\Lambda(d)")#text(" is nonzero for any ")#mi("p \\le x")#text(" (in fact it would be ")#mi("\\log^2{p}")#text(").")#linebreak()#text(" So it seems there is an extra error term of size: ")#mi("\\frac{1}{\\log{x}}\\left(\\displaystyle\\sum_{\\sqrt{x} < p \\le x} \\log^2{p}\\right)")#text(". Maybe I'm missing something here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/711da5091036366bb2d70639f051f1410d9e2973cb17acfa4b5ec0335e2464cd-496fd9f514d40b38b845cfa43ef42d99003dba251e6a9f2729d9f1be8889a2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jcs")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443864")[#strong[#text("jcs")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("I think you’re right. In fact the first sum in the second member of the first equation of the proof is O(x) as one can see by integrating by part, and so the main contribution, in O(xLog(x)), comes precisely from those {p\\gep\\sqrt{x}} which have to be taken into account as you point out")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("Gah, you’re right, my proposed proof of Proposition 18 does not work at all. In retrospect this is obvious, as ")#mi("\\Lambda")#text(" is supported on numbers with very few factors, so rearranging based on the factors of ")#mi("n")#text(" will not do very much. I’ve rearranged the material to give instead the textbook proof of Chebyshev’s bound at this point (which I personally find a bit too slick, but the only other proofs I know require material that is covered later in the notes, such as Mobius inversion).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f026b9d11810dd94a50ccd047993490d842148ba88454fbd446206f18967e28b-2704072eee32906e408b314c7fa3a4b11750419c3db3d93d937c779ba941f873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444747")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("There’s an approach on p. 33 of Iwaniec and Kowalski that while still ‘slick’ in its application of monotonicity, doesn’t involve inspecting binomial coefficients. It invokes your identity (31) instead of using Mobius inversion proper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444748")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("Actually, the approach in I&K uses binomial coefficients in disguise (note, for instance, that the quantity ")#mi("L(x)-2L(\\frac{x}{2})")#text(" in I&K is simply the logarithm of the binomial coefficient ")#mi("\\binom{x}{x/2}")#text(" if ")#mi("x")#text(" is an even natural number)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f026b9d11810dd94a50ccd047993490d842148ba88454fbd446206f18967e28b-2704072eee32906e408b314c7fa3a4b11750419c3db3d93d937c779ba941f873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444750")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("Yah.. I just came back because I had that realization. The phrasing is more natural there anyway. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f026b9d11810dd94a50ccd047993490d842148ba88454fbd446206f18967e28b-2704072eee32906e408b314c7fa3a4b11750419c3db3d93d937c779ba941f873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444754")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2014")])]

#text("These are very nice notes by the way. Along with everyone else I’m enjoying reading them!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52a5b6041caef3d72428cbbb7c02a1dab44bb4ee0e83dc48002f93fb2cc30a10-ed14da61abe4b2a432c2437dba18b04774429511dd909720bd1197648369fd75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of apatch")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-443876")[#strong[#text("apatch")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("In Ex 4 did you mean that the lead term is $l!t^k$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/915cd7f354b1a5ba6194f09029544f6b1208c2052a27bf60bf41879e832f9022-656f1d6042266fa2aad88b968a6f20a6dd73ba432673db8b99c98d6ede74eacb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Santiago López")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444296")[#strong[#text("Santiago López")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2014")])]

#text("Cuáles son los últimos adelantos en cuanto a los Primos de Sophie Germain?")#linebreak()#text(" Encontré una serie que involucra a los primos de Sophie Germain con la constante sqrt(2)-1 (razón plateada)")#linebreak()#text(" Gracias")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52a5b6041caef3d72428cbbb7c02a1dab44bb4ee0e83dc48002f93fb2cc30a10-ed14da61abe4b2a432c2437dba18b04774429511dd909720bd1197648369fd75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of apatch")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444896")[#strong[#text("apatch")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2014")])]

#text("Ex 8: I wasn’t able to see how to use the hint but using Abel’s Identity I got the equality valid for all s>1. But my little-o term is of the right order but based on x tending to infinity, not s tending to ")#mi("1^{+}")#text(".")#linebreak()#text(" What is the right way of looking at this?")#linebreak()#text(" Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-444904")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2014")])]

#text("There is no dependence on ")#mi("x")#text(" in either side of the desired asymptotic ")#mi("{\\mathcal D} f(s) = \\frac{\\alpha}{s-1} + o(\\frac{1}{s-1})")#text(", so I recommend going through your argument again and clarifying the role of the ")#mi("x")#text(" variable.")

#text("The purpose of the hint is to be able to rewrite ")#mi("{\\mathcal D} f(s)")#text(" as an integral involving the logarithmic sums ")#mi("x \\mapsto \\sum_{n \\leq x} \\frac{f(n)}{n}")#text(", after interchanging a summation and integral.")

#text("A warmup exercise may be to prove the classical fact that any sequence of complex numbers that converges to a limit, also converges in the Cesaro sense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-449161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2015")])]

#text("Is the reason why we use Monotone Convergence to show (18) because we want to justify the interchange of limits in ")#mi("\\lim_{N \\rightarrow \\infty}\\lim_{M \\rightarrow \\infty}\\prod_{p \\leq M}\\sum_{k \\leq N}f(p^{k})")#text("? If so, how does Monotone Convergence apply? Doesn’t monotone convergence just deal with interchanging limits and integrals/sums?")

#emph[#text("[By using logarithms, monotone convergence can also be used to interchange limits and products, if the factors in the products are at least one. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qiu")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-449422")[#strong[#text("qiu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2015")])]

#text("How did you obtain the crude bound ")#mi("\\sum_{j = 2}^{\\infty}j^{O(1)}/p^{j} \\ll 1/p^2")#text(" in the proof of Theorem 15?")

#emph[#text("[")#mi("\\sum_{j=2}^\\infty \\frac{j^{O(1)}}{2^{j-2}}")#text(" converges. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c1c0b8ecf1f8e26fde963351d36af846622f063831c196d16dde3e65a06958-c8422f7cdc929d7ea493e8085d5fa90c83c3eb9e463e20966813ca5c460c210e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kazekkurz")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-449662")[#strong[#text("kazekkurz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#text("I do not know why O(s-1) i (22) appears? In (21) there was only O(1) and the step was taking log on both sides…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-449671")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#mi("\\frac{1}{s-1} + O(1)")#text(" is factored as ")#mi("\\frac{1}{s-1} ( 1 + O( s-1 ) )")#text(", and from the Taylor expansion of the logarithm one has ")#mi("\\log( 1 + O(s-1) ) = O( s-1)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c1c0b8ecf1f8e26fde963351d36af846622f063831c196d16dde3e65a06958-c8422f7cdc929d7ea493e8085d5fa90c83c3eb9e463e20966813ca5c460c210e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kazekkurz")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-449672")[#strong[#text("kazekkurz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")])]

#text("Thank You!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-450360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2015")])]

#text("By considering ")#mi("f(-n)")#text(" in exercise 11, it seems that the RHS holds also with ")#mi("f(x)")#text(" replacing ")#mi("f(y)")#text(", so it seems that the RHS can be improved by replacing ")#tao-math("\\left|f(y)\\right|", block: false)#text(" with ")#tao-math("\\min (\\left|f(x)\\right|, \\left|f(y)\\right|)", block: false)#text(" – which is also more symmetric.")#linebreak()#text(" Moreover, if ")#mi("x, y")#text(" are integers, it seems that this result may be generalized for bounded variation functions ")#mi("f")#text(" simply by replacing the remainder term in the RHS by the (total) variation of ")#mi("f")#text(" (by considering ")#mi("f")#text(" as a difference between two functions with monotone real and imaginary parts – for which the result seems to be easy.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-450864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2015")])]

#text("I think there’s an extra ")#mi("1/\\sqrt{x}")#text(" in front of the big-Oh term in the centered equation before (78).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: Bounding exponential sums and the zeta function | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-451618")[#strong[#text("254A, Notes 5: Bounding exponential sums and the zeta function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2015")])]

#text("[…] the arguments, we will use an analogy between the sums and the integrals (cf. Exercise 11 from Notes 1). This analogy can be made rigorous by the Poisson summation formula (after applying some smoothing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-451887")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] from mean value theorems on multiplicative functions (see Proposition 21 of Notes 1), if one is allowed to delete some unit intervals from the range of , with the bound improving as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-451972")[#strong[#text("254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2015")])]

#text("[…] we have seen in Notes 1, the von Mangoldt function does indeed admit several factorisations into Dirichlet convolution […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Some sieve theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-452119")[#strong[#text("254A, Notes 4: Some sieve theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("[…] from Mertens’ third theorem (Theorem 42 from Notes 1) one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-452283")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] Theorem 69 of Notes 1), we thus […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-452367")[#strong[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("[…] adequately estimated by Mertens’ theorem, which can be easily proven by elementary means (see Notes 1); but a satisfactory estimate on the summatory function requires the prime number theorem, which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aca168b3b67ecf7c35926a15d02864b30588f4620795437363ae74d51d6aac0c-dc9d2cc1716aad62d3b9b2aa1e79b7e016b3eb123de94be328dd9f4d3d9cfd02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jt")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-452565")[#strong[#text("jt")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2015")])]

#text("I believe that the polynomial in part (ii) of Exercise 9 should say Q_{k,l}(t) instead of Q_k(t) after the statement of the formula.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52a5b6041caef3d72428cbbb7c02a1dab44bb4ee0e83dc48002f93fb2cc30a10-ed14da61abe4b2a432c2437dba18b04774429511dd909720bd1197648369fd75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of apatch")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-453186")[#strong[#text("apatch")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")])]

#text("Should the big-oh term in Ex11 include ")#tao-math("\\left\\|f(x)\\right\\|", block: false)#text("?")

#emph[#text("[One can add this factor if desired, but it is not necessary since it is controlled by the other two error terms. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/comment-page-1/#comment-453608")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] (Hint: for the latter estimate, use Theorem 27 of Notes 1.) […]")
]
