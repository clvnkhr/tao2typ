// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/02/02/ipam-industrial-short-course-in-generative-ai-algorithms-deadline-for-applications-closing-soon/
// Converted to Typst by tao2typ: "2026-10-14T11:15:27.478511+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IPAM industrial short course in generative AI algorithms – deadline for applications closing soon", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IPAM industrial short course in generative AI algorithms – deadline for applications closing soon")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 February 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/02/02/ipam-industrial-short-course-in-generative-ai-algorithms-deadline-for-applications-closing-soon/")[#text("https://terrytao.wordpress.com/2026/02/02/ipam-industrial-short-course-in-generative-ai-algorithms-deadline-for-applications-closing-soon/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("(Sharing this in my capacity of director of special projects at IPAM.)")

#link("https://www.ipam.ucla.edu/")[#text("IPAM")]#text(" is holding an ")#link("https://www.ipam.ucla.edu/programs/special-events-and-conferences/industrial-short-course-generative-ai-algorithms/")[#text("Industrial Short Course on Generative AI Algorithms")]#text(" on March 5-6, 2026.")

#text("The short course is aimed at people from industry or government who want to get started in deep learning, apply deep learning to their projects, learn how to code deep learning algorithms, and upgrade their skills to the latest AI algorithms, including generative AI. The course will be taught be Professor ")#link("https://graphdeeplearning.github.io/authors/xavier-bresson/")[#text("Xavier Bresson")]#text(" from the Department of Computer Science at the National University of Singapore (NUS).")

#text("The course will be limited to 25 participants. The fee for this course is $2,500 for participants. ")#link("https://www.ipam.ucla.edu/programs/special-events-and-conferences/industrial-short-course-generative-ai-algorithms/")[#text("Registration closes soon")]#text(" (Feb 5); we still have a few spots available.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/02/ipam-industrial-short-course-in-generative-ai-algorithms-deadline-for-applications-closing-soon/#comment-691744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2026")])]

#text("Thanks for sharing!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/02/02/ipam-industrial-short-course-in-generative-ai-algorithms-deadline-for-applications-closing-soon/#comment-691750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2026")])]

#text("can ucla students who dont have resources audit?")

#emph[#text("[This course is specifically geared towards industry and industry-specific training; for such courses, the employer is expected to sponsor this sort of training. -T]")]
]
