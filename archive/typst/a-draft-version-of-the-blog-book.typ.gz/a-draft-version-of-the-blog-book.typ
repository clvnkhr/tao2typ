// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/
// Converted to Typst by tao2typ: "2026-10-14T16:35:17.691566+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A draft version of the blog book", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A draft version of the blog book")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/")[#text("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A few months ago, ")#link("https://terrytao.wordpress.com/2008/01/25/book-version-of-the-blog/")[#text("I announced")]#text(" that I was going to convert a significant fraction of my 2007 blog posts into a book format. For various reasons, this conversion took a little longer than I had anticipated, but I have finally completed a draft copy of this book, which I have ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/05/whatsnew_onlineversion.pdf")[#text("uploaded here")]#text("; note that this is a moderately large file (")#text("1.5MB")#text(" ")#text("1.3MB ")#text("1.1MB), as the book is ")#text("374 pages")#text(" ")#text("287 pages")#text(" 270 pages long. There are still several formatting issues to resolve, but the content has all been converted.")

#text("It may be a while before I hear back from the editors at the American Mathematical Society as to the status of the book project, but in the meantime any comments on the book, ranging from typos to suggestions as to the format, are of course welcome.")

#text("[")#emph[#text("Update")]#text(", April 21: New version ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/05/whatsnew_onlineversion.pdf")[#text("uploaded")]#text(", incorporating contributed corrections. The formatting has been changed for the internet version to significantly reduce the number of pages. As a consequence, note that the page numbering for the internet version of the book will differ substantially from that in the print version.]")

#text("[")#emph[#text("Update")]#text(", April 21: As some readers may have noticed, I have placed paraphrased versions of some of the blog comments in the book, using the handles given in the blog comments to identify the authors. If any such commenters wish to change one’s handle (e.g. to one’s full name) or to otherwise modify or remove any comments I have placed in the book, you are welcome to contact me by email to do so.]")

#text("[")#emph[#text("Update")]#text(", April 23: Another new version ")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/05/whatsnew_onlineversion.pdf")[#text("uploaded")]#text(", incorporating contributed corrections and shrinking the page size a little further.]")

#text("[")#emph[#text("Update")]#text(", May 8: A few additional corrections to the book.]")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JZ")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29171")[#strong[#text("JZ")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2008")])]

#text("Reading your blog is very beneficial even for a non-math guy like me. It is so generous of you to organize your articles into a book, which offer great convenience to readers. Could you please offer an alternative version, in which the margin size is shrunk. (I think most readers will print it out on Letter or A4 paper.) In this way, thousands of papers, and subsequently trees and many natural resources, can be saved. Thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29173")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2008")])]

#text("In the section on Einstein’s proof of ")#mi("E = mc^2")#text(", there’s a sentence which begins “To compute this matrix, let us make the plausible assumption”. In this sentence, “-v” should be in math mode.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29174")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2008")])]

#text("The same goes for “where h is Planck’s constant” in the section “Energy and momentum of photons”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29178")[#strong[#text("tom")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2008")])]

#text("It’s great to see the book taking shape! I guess many people will be very happy to add it to their bookshelf, next to the Open Problems ones of Guy, of Croft-Falconer-Guy, and of Arnold for example.")

#text("A typo: in section 2.9 nonfirstorderisability, in the fourth paragraph a space is missing in ")#emph[#text("yindependent")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phu")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29180")[#strong[#text("Phu")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("There appears to be a few instances of “Erdo”s” when perhaps you mean Erdős’ or just Erdős?")

#text("For example,")#linebreak()#text(" page 2, paragraph 2, about the 5th sentence;")#linebreak()#text(" page 72, first paragraph, last sentence;")#linebreak()#text(" page 211, second paragraph, first sentence;")#linebreak()#text(" page 211, line 14;")#linebreak()#text(" page 335, line 1 (perhaps there’s also a missing “by” before Erdős);")#linebreak()#text(" page 335, line 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y J")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29181")[#strong[#text("Y J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("There is a small typo on Page 2, Erdo”s is written instead of Erd\\”os.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffa174a479a5934ffc8d85ac51954b684c7282154b5e145b5b220c7e95723971-f46e92455ff52a75c934a5d34a3eae4d3c278d3b141035808dba5019c873d2bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bew([R(q),q])->not(Bew([R(q),q])")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29183")[#strong[#text("Bew([R(q),q])->not(Bew([R(q),q])")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("Thank you so much Terence Tao for this book and for your classes.")

#text("Your blog is an amazing source of knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29184")[#strong[#text("A draft version of the blog book « Abner’s Postgraduate Days")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")]

#text("[…] A draft version of the blog book Ref.: A draft version of the blog book « What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2a7319b4c813add912eb7cbcb445bb0501c65e22a0d20ccf3125e288439487-15e66ce58b68b90fe19e4e74be7b94f81a691f4d226a6d01999f4f5193efe092.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedfan")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29191")[#strong[#text("fedfan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("What method did you use to convert to latex format? Cut and paste or")#linebreak()#text(" export to a file and hand edit?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29194")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("Firstly let me thank you for this book and for your blog.")

#text("Now a brief comment regarding the typing of some URL’s.")

#text("Page 11, 1.3.1 Notes. (…) ")#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies")[#text("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies")]

#text("The typing of this URL has to have a line break (hyphenation), I guess.")#linebreak()#text(" Since I do not know whether this kind of things is going to be done automatically, in the professional editing process of the final document, I make this comment here. If that is the case, you can remove this comment, of course.")#linebreak()#text(" This applies in general to other URL’s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("How about a convention where if in your blog you link to a wikipedia definition of something, then in the print book you underline the term and put a Wikipedia symbol (e.g. a W) in the margin? That could probably be done with a TeX macro.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MK")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29196")[#strong[#text("MK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("Professor Tao, this is a great book! A couple of small errors in note on random matrices in your Milman lectures.")

#text("1) On p 329, the quantity in (3.12) is not the Stieltjes transform – which is \\sum 1/(z-\\lambda_k).")

#text("2) By Gaussian orthogonal and unitary ensembles you seem to be referring to the real and complex Gaussian ensembles (eg. on p 326 and 330-331) but those names are always used in literature for the Hermitian ensembles invariant under O(n) and U(n).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29199")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("In fact, it should be {Erd\\H{o}s} — the Hungarian {\\H{o}} is not an umlaut {\\”o}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29200")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2008")])]

#text("Indeed, the book-to-be looks interesting. Thanks in particular for your courteous summary of non-trivial comments on the blog posts.")

#text("On that note, I should state more clearly my proposal for solving the Mahler conjecture in 3D. It is not based on a parabolic PDE, but rather on the moduli space of polyhedra (or centrally symmetric polyhedra) with a given combinatorial type. It is known that this moduli space is morally contractible, which is to say that it is homotopy equivalent to O(3) divided by available symmetries. This suggests looking at a gradient flow (not some parabolic flow) of the Mahler volume of a polyhedron. Since the moduli space has no unpredictable topology, it is plausible that you can always flow downhill until the polyhedron simplifies. In context, this proof strategy works in 2D and can’t work in 4D.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29213")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("There is misprint in the Contents. To my mind Chapter 2.5 is not real Chapter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29221")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("Thanks for all the corrections! I have uploaded a new version to reflect the changes, in particular changing the margins which happened to magically eliminate almost 90 pages from the book (though I imagine the print version will now look substantially different from the online version).")

#text("The wide URLs are still a problem, but I have at least deleted the http:// prefix which saves a little bit of space.")

#text("There appears to be no really useful substitute for the wikipedia links for the book version of the blog; the closest print analogue would be a lengthy glossary of terms, but this would be rather tedious to create and perhaps not the best use of page space. In the end it seems better to adapt the content to suit the medium, rather than to try to make it as close to an exact clone of the blog format as possible; after all, the readers can always visit the original web pages for the articles if they want a true hypertext version.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e23ea31230ea71ae18ec0dbd2a8a603ed2a04a629e852bb276b96c9ba2b2e2f1-e89718d62ddbc42fd300ead58f018902393318d642672627d62f6cced1c3b79c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29229")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("If you really want to reduce pages, the most effective way to do this is two-column REVTeX, which I use in my recent papers for this very purpose. In fact I would be happy to show you if you e-mailed me the TeX source. I bet that it would be under 200 pages, maybe even 150.")

#text("As for the long URLs, the main part of the problem is the long identifier for each post. The right solution is to see if WordPress can give you short identifiers, or maybe number the posts instead of naming them in the URLs.")

#text("Ah, here is a discovery: If you just remove the cumbersome title from the URL, it instead points you to a daily archive, which typically only has one posting in it. For example ")#link("https://terrytao.wordpress.com/2008/04/19/")[#text("https://terrytao.wordpress.com/2008/04/19/")]#text(" points only to this posting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of harrison")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29235")[#strong[#text("harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("Various typos, grammatical inconsistencies, etc. (what I could find in part one while procrastinating on homework):")

#text("p. 4: In the parenthetical comment, “the implicit constants in the conclusion depends on…” should probably be “the implicit constants in the conclusion depend on…”")

#text("p. 11: Is the plural of PDE “PDE” or “PDEs?” You use both here and elsewhere. (Same for “ODE” vs. “ODEs.”)")

#text("p. 14: “repeats” is misspelled as “repeates.”")

#text("p. 18: “Simply sticking in the existing energy bounds into the Navier-Stokes")#linebreak()#text(" equation and seeing what comes out will provide a few more bounds…” “Sticking in into” is redundant.")

#text("p. 32: There is an open parenthesis that needs a complementary close parenthesis.")

#text("p. 33: “invariant” is misspelled as “invraiant.”")

#text("p. 44: There is a close parenthesis without an open parenthesis.")

#text("p. 44-45, elsewhere: There looks to be a formatting issue with “modp,” etc.")

#text("p. 47: There’s a parenthetical comment which should probably be in parentheses which is in brackets.")

#text("All page numbers refer to the pdf of the new version.")

#text("Best,")

#text("Harrison")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29250")[#strong[#text("tom")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("In some URLs you mention at the end of each chapter a tilde is missing sometimes, for example in the one of Tim Gowers at paragraph 2.9.5. I think in the LaTeX code you should use \\~{} instead of ~ to force it to print.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29254")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("Two comments:")

#text("(a) I would not say that the fact that two elements that commute with a third one are likely to commute with each other is specific to SL_2. That fact is true for SL_n, and, if memory serves me correctly, for any semisimple group of Lie type: a generic element of a semisimple group is regular semisimple. (It would be nice to have a reference for this, actually.)")

#text("(b) Less importantly: my paper on SL_2 finally appeared last month.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("Thanks for the comments and suggestions! I may upload a second revised version soon to incorporate them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29257")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("Harald’s comment (a) is correct, and is stated in various places when ‘generic’ is in the sense of algebraic geometry (or more concretely, in a semisimple group, there is an open dense subset of regular semisimple elements, in the Zariski topology). For instance, I’m pretty sure it’s in Borel’s book on linear algebraic groups, and I just checked it’s explicitly stated in Steinberg’s paper “Regular elements of semi-simple algebraic groups”, Publ. IHES 25 (1965), 49-80, which can be downloaded from ")#link("http://www.numdam.org")[#text("http://www.numdam.org")]#text(" (see 2.14 there).")

#text("In fact, one can also ask the slightly stronger property of “strong” regularity, meaning that the centralizer of the element is a maximal torus (another standard fact being that regular semisimple elements are those with centralizer whose connected component of the identity is a maximal torus; see 2.11 in Steinberg’s paper). For a group like SL(n) – “simply-connected” being the keyword -, regular and strongly regular coincide (another theorem of Steinberg), but for SO(n) or PSL(n), it’s not necessarily the case. The genericity of strongly regular elements is 2.15 in Steinberg’s paper.")

#text("(Another comment about url’s: the LaTeX package url has a macro \\url{…} which typesets long URLs with line-breaks; whether it’s a good thing to have line-breaks is debatable, but at least it avoids oveflowing lines).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29267")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2008")])]

#text("A couple more corrections:")

#text("1. p73, “that combination down on two piece of paper (one for Lara, one for Indiana),”")#linebreak()#text(" Should be pieces.")

#text("2. p103, under Algebra Homomorphism, the product limit equality is wrong (or rather, is right, but is the wrong equality).")

#text("I’m also rather interested in the conclusion of the wonderfully bright Tomb Raider article. It’s been snipped off in such a cruel way ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29311")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("Thanks for the corrections! I’ve restored the last few paragraphs of the Tomb Raider article, which had mysteriously gotten lost earlier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karlik")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29440")[#strong[#text("Karlik")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2008")])]

#text("page 183, line 6 from bottom")#linebreak()#text(" \\alpha \\leq maxflow -> 1/\\alpha\\leq maxflow")#linebreak()#text(" and in Menger’s theorem")#linebreak()#text(" max-flow -> maxflow")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/955432e8e29fb2f9bd41d4a36093de5be10ce3f255cfd76fea5dc1ebc82765e5-f8ce4298d511f8ce48771c2dcca76d4fcc5e684c2150513bbd7fdc3a027da248.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hasan")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-29729")[#strong[#text("hasan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2008")])]

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-30359")[#strong[#text("Google, Wikipedia and blogosphere « What Is Research?")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")]

#text("[…] idea of what goes on inside mathematics, has experimented with a number of ventures, ranging from a blog book (a book in blog form) to making a contribution to Scholarpedia, a site that aims to aggregate […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4d181fde52b12c41ab1c2aecb4e22a6a9af5d08a44c1a7d52b88cc7a324b10-7d4619dfe126cd222d40de844c1b508709ceadbfa1c6618eeae1711371fc16c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isterimki")]], [#link("https://terrytao.wordpress.com/2008/04/19/a-draft-version-of-the-blog-book/#comment-31942")[#strong[#text("isterimki")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2008")])]

#text("Thank you so much Terence Tao for this book and for your classes.")
]
