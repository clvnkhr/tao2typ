// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/
// Converted to Typst by tao2typ: "2026-10-14T15:19:28.792200+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The standard branch of the matrix logarithm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The standard branch of the matrix logarithm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 May 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/")[#text("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Because of ")#link("http://en.wikipedia.org/wiki/Euler%27s_identity")[#text("Euler’s identity")]#text(" ")#mi("{e^{\\pi i} + 1 = 0}")#text(", the ")#link("http://en.wikipedia.org/w/index.php?title=Complex_exponential")[#text("complex exponential")]#text(" is not injective: ")#mi("{e^{z + 2\\pi i k} = e^z}")#text(" for any complex ")#mi("{z}")#text(" and integer ")#mi("{k}")#text(". As such, the ")#link("http://en.wikipedia.org/wiki/Complex_logarithm")[#text("complex logarithm")]#text(" ")#mi("{z \\mapsto \\log z}")#text(" is not well-defined as a single-valued function from ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" to ")#mi("{{\\bf C}}")#text(". However, after making a ")#link("http://en.wikipedia.org/wiki/Branch_point#Branch_cuts")[#text("branch cut")]#text(", one can create a branch of the logarithm which is single-valued. For instance, after removing the negative real axis ")#mi("{(-\\infty,0]}")#text(", one has the ")#emph[#text("standard branch")]#text(" ")#tao-math("{\\text{Log}: {\\bf C} \\backslash (-\\infty,0] \\rightarrow \\{ z \\in {\\bf C}: \\left|\\text{Im} z\\right| < \\pi \\}}", block: false)#text(" of the logarithm, with ")#mi("{\\text{Log}(z)}")#text(" defined as the unique choice of the complex logarithm of ")#mi("{z}")#text(" whose imaginary part has magnitude strictly less than ")#mi("{\\pi}")#text(". This particular branch has a number of useful additional properties:")

#list(
[#text("The standard branch ")#mi("{\\text{Log}}")#text(" is holomorphic on its domain ")#mi("{{\\bf C} \\backslash (-\\infty,0]}")#text(".")],
[#text("One has ")#mi("{\\text{Log}( \\overline{z} ) = \\overline{ \\text{Log}(z) }}")#text(" for all ")#mi("{z}")#text(" in the domain ")#mi("{{\\bf C} \\backslash (-\\infty,0]}")#text(". In particular, if ")#mi("{z \\in {\\bf C} \\backslash (-\\infty,0]}")#text(" is real, then ")#mi("{\\text{Log} z}")#text(" is real.")],
[#text("One has ")#mi("{\\text{Log}( z^{-1} ) = - \\text{Log}(z)}")#text(" for all ")#mi("{z}")#text(" in the domain ")#mi("{{\\bf C} \\backslash (-\\infty,0]}")#text(".")]
)

#text("One can then also use the standard branch of the logarithm to create standard branches of other multi-valued functions, for instance creating a standard branch ")#mi("{z \\mapsto \\exp( \\frac{1}{2} \\text{Log} z )}")#text(" of the square root function. We caution however that the identity ")#mi("{\\text{Log}(zw) = \\text{Log}(z) + \\text{Log}(w)}")#text(" can fail for the standard branch (or indeed for any branch of the logarithm).")

#text("One can extend this standard branch of the logarithm to ")#mi("{n \\times n}")#text(" complex matrices, or (equivalently) to linear transformations ")#mi("{T: V \\rightarrow V}")#text(" on an ")#mi("{n}")#text("-dimensional complex vector space ")#mi("{V}")#text(", provided that the spectrum of that matrix or transformation avoids the branch cut ")#mi("{(-\\infty,0]}")#text(". Indeed, from the spectral theorem one can decompose any such ")#mi("{T: V \\rightarrow V}")#text(" as the direct sum of operators ")#mi("{T_\\lambda: V_\\lambda \\rightarrow V_\\lambda}")#text(" on the non-trivial generalised eigenspaces ")#mi("{V_\\lambda}")#text(" of ")#mi("{T}")#text(", where ")#mi("{\\lambda \\in {\\bf C} \\backslash (-\\infty,0]}")#text(" ranges in the spectrum of ")#mi("{T}")#text(". For each component ")#mi("{T_\\lambda}")#text(" of ")#mi("{T}")#text(", we define")

#align(center)[#tao-fit-display[#mitex("\\text{Log}( T_\\lambda ) = P_\\lambda( T_\\lambda )")]]

#text("where ")#mi("{P_\\lambda}")#text(" is the Taylor expansion of ")#mi("{\\text{Log}}")#text(" at ")#mi("{\\lambda}")#text("; as ")#mi("{T_\\lambda-\\lambda}")#text(" is nilpotent, only finitely many terms in this Taylor expansion are required. The logarithm ")#mi("{\\text{Log} T}")#text(" is then defined as the direct sum of the ")#mi("{\\text{Log} T_\\lambda}")#text(".")

#text("The matrix standard branch of the logarithm has many pleasant and easily verified properties (often inherited from their scalar counterparts), whenever ")#mi("{T: V \\rightarrow V}")#text(" has no spectrum in ")#mi("{(-\\infty,0]}")#text(":")

#list(
[#text("(i) We have ")#mi("{\\exp( \\text{Log} T ) = T}")#text(".")],
[#text("(ii) If ")#mi("{T_1: V_1 \\rightarrow V_1}")#text(" and ")#mi("{T_2: V_2 \\rightarrow V_2}")#text(" have no spectrum in ")#mi("{(-\\infty,0]}")#text(", then ")#mi("{\\text{Log}( T_1 \\oplus T_2 ) = \\text{Log}(T_1) \\oplus \\text{Log}(T_2)}")#text(".")],
[#text("(iii) If ")#mi("{T}")#text(" has spectrum in a closed disk ")#mi("{B(z,r)}")#text(" in ")#mi("{{\\bf C} \\backslash (-\\infty,0]}")#text(", then ")#mi("{\\text{Log}(T) = P_z(T)}")#text(", where ")#mi("{P_z}")#text(" is the Taylor series of ")#mi("{\\text{Log}}")#text(" around ")#mi("{z}")#text(" (which is absolutely convergent in ")#mi("{B(z,r)}")#text(").")],
[#text("(iv) ")#mi("{\\text{Log}(T)}")#text(" depends holomorphically on ")#mi("{T}")#text(". (Easily established from (ii), (iii), after covering the spectrum of ")#mi("{T}")#text(" by disjoint disks; alternatively, one can use the Cauchy integral representation ")#mi("{\\text{Log}(T) = \\frac{1}{2\\pi i} \\int_\\gamma \\text{Log}(z)(z-T)^{-1}\\ dz}")#text(" for a contour ")#mi("{\\gamma}")#text(" in the domain enclosing the spectrum of ")#mi("{T}")#text(".) In particular, the standard branch of the matrix logarithm is smooth.")],
[#text("(v) If ")#mi("{S: V \\rightarrow W}")#text(" is any invertible linear or ")#link("http://en.wikipedia.org/wiki/Antilinear_map")[#text("antilinear")]#text(" map, then ")#mi("{\\text{Log}( STS^{-1} ) = S \\text{Log}(T) S^{-1}}")#text(". In particular, the standard branch of the logarithm commutes with matrix conjugations; and if ")#mi("{T}")#text(" is real with respect to a complex conjugation operation on ")#mi("{V}")#text(" (that is to say, an antilinear involution), then ")#mi("{\\text{Log}(T)}")#text(" is real also.")],
[#text("(vi) If ")#mi("{T^*: V^* \\rightarrow V^*}")#text(" denotes the transpose of ")#mi("{T}")#text(" (with ")#mi("{V^*}")#text(" the complex dual of ")#mi("{V}")#text("), then ")#mi("{\\text{Log}(T^*) = \\text{Log}(T)^*}")#text(". Similarly, if ")#mi("{T^\\dagger: V^\\dagger \\rightarrow V^\\dagger}")#text(" denotes the adjoint of ")#mi("{T}")#text(" (with ")#mi("{V^\\dagger}")#text(" the complex conjugate of ")#mi("{V^*}")#text(", i.e. ")#mi("{V^*}")#text(" with the conjugated multiplication map ")#mi("{(c,z) \\mapsto \\overline{c} z}")#text("), then ")#mi("{\\text{Log}(T^\\dagger) = \\text{Log}(T)^\\dagger}")#text(".")],
[#text("(vii) One has ")#mi("{\\text{Log}(T^{-1}) = - \\text{Log}( T )}")#text(".")],
[#text("(viii) If ")#mi("{\\sigma(T)}")#text(" denotes the spectrum of ")#mi("{T}")#text(", then ")#mi("{\\sigma(\\text{Log} T) = \\text{Log} \\sigma(T)}")#text(".")]
)

#text("As a quick application of the standard branch of the matrix logarithm, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" Let ")#mi("{G}")#text(" be one of the following matrix groups: ")#mi("{GL_n({\\bf C})}")#text(", ")#mi("{GL_n({\\bf R})}")#text(", ")#mi("{U_n({\\bf C})}")#text(", ")#mi("{O(Q)}")#text(", ")#mi("{Sp_{2n}({\\bf C})}")#text(", or ")#mi("{Sp_{2n}({\\bf R})}")#text(", where ")#mi("{Q: {\\bf R}^n \\rightarrow {\\bf R}}")#text(" is a non-degenerate real quadratic form (so ")#mi("{O(Q)}")#text(" is isomorphic to a ")#link("http://en.wikipedia.org/wiki/Indefinite_orthogonal_group")[#text("(possibly indefinite) orthogonal group ")#mi("{O(k,n-k)}")]#text(" for some ")#mi("{0 \\leq k \\leq n}")#text(". Then any element ")#mi("{T}")#text(" of ")#mi("{G}")#text(" whose spectrum avoids ")#mi("{(-\\infty,0]}")#text(" is exponential, that is to say ")#mi("{T = \\exp(X)}")#text(" for some ")#mi("{X}")#text(" in the Lie algebra ")#mi("{{\\mathfrak g}}")#text(" of ")#mi("{G}")#text(".")
]

#emph[#text("Proof:")]#text(" We just prove this for ")#mi("{G=O(Q)}")#text(", as the other cases are similar (or a bit simpler). If ")#mi("{T \\in O(Q)}")#text(", then (viewing ")#mi("{T}")#text(" as a complex-linear map on ")#mi("{{\\bf C}^n}")#text(", and using the complex bilinear form associated to ")#mi("{Q}")#text(" to identify ")#mi("{{\\bf C}^n}")#text(" with its complex dual ")#mi("{({\\bf C}^n)^*}")#text(", then ")#mi("{T}")#text(" is real and ")#mi("{T^{*-1} = T}")#text(". By the properties (v), (vi), (vii) of the standard branch of the matrix logarithm, we conclude that ")#mi("{\\text{Log} T}")#text(" is real and ")#mi("{- \\text{Log}(T)^* = \\text{Log}(T)}")#text(", and so ")#mi("{\\text{Log}(T)}")#text(" lies in the Lie algebra ")#mi("{{\\mathfrak g} = {\\mathfrak o}(Q)}")#text(", and the claim now follows from (i). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that ")#mi("{\\text{diag}(-\\lambda, -1/\\lambda)}")#text(" is not exponential in ")#mi("{GL_2({\\bf R})}")#text(" if ")#mi("{-\\lambda \\in (-\\infty,0) \\backslash \\{-1\\}}")#text(". Thus we see that the branch cut in the above proposition is largely necessary. See ")#link("http://www.ams.org/mathscinet-getitem?mr=575783")[#text("this paper of Djokovic")]#text(" for a more complete description of the image of the exponential map in classical groups, as well as ")#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")[#text("this previous blog post")]#text(" for some more discussion of the surjectivity (or lack thereof) of the exponential map in Lie groups.")
]

#text("For a slightly less quick application of the standard branch, we have the following result (recently worked out in the answers to ")#link("http://mathoverflow.net/questions/204460/how-to-prove-this-determinant-is-positive")[#text("this MathOverflow question")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" Let ")#mi("{T}")#text(" be an element of the split orthogonal group ")#mi("{O(n,n)}")#text(" which lies in the connected component of the identity. Then ")#mi("{\\text{det}(1+T) \\geq 0}")#text(".")
]

#text("The requirement that ")#mi("{T}")#text(" lie in the identity component is necessary, as the counterexample ")#mi("{T = \\text{diag}(-\\lambda, -1/\\lambda )}")#text(" for ")#mi("{\\lambda \\in (-\\infty,-1) \\cup (-1,0)}")#text(" shows.")

#emph[#text("Proof:")]#text(" We think of ")#mi("{T}")#text(" as a (real) linear transformation on ")#mi("{{\\bf C}^{2n}}")#text(", and write ")#mi("{Q}")#text(" for the quadratic form associated to ")#mi("{O(n,n)}")#text(", so that ")#mi("{O(n,n) \\equiv O(Q)}")#text(". We can split ")#mi("{{\\bf C}^{2n} = V_1 \\oplus V_2}")#text(", where ")#mi("{V_1}")#text(" is the sum of all the generalised eigenspaces corresponding to eigenvalues in ")#mi("{(-\\infty,0]}")#text(", and ")#mi("{V_2}")#text(" is the sum of all the remaining eigenspaces. Since ")#mi("{T}")#text(" and ")#mi("{(-\\infty,0]}")#text(" are real, ")#mi("{V_1,V_2}")#text(" are real (i.e. complex-conjugation invariant) also. For ")#mi("{i=1,2}")#text(", the restriction ")#mi("{T_i: V_i \\rightarrow V_i}")#text(" of ")#mi("{T}")#text(" to ")#mi("{V_i}")#text(" then lies in ")#mi("{O(Q_i)}")#text(", where ")#mi("{Q_i}")#text(" is the restriction of ")#mi("{Q}")#text(" to ")#mi("{V_i}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\text{det}(1+T) = \\text{det}(1+T_1) \\text{det}(1+T_2).")]]

#text("The spectrum of ")#mi("{T_2}")#text(" consists of positive reals, as well as complex pairs ")#mi("{\\lambda, \\overline{\\lambda}}")#text(" (with equal multiplicity), so ")#mi("{\\text{det}(1+T_2) > 0}")#text(". From the preceding proposition we have ")#mi("{T_2 = \\exp( X_2 )}")#text(" for some ")#mi("{X_2 \\in {\\mathfrak o}(Q_2)}")#text("; this will be important later.")

#text("It remains to show that ")#mi("{\\text{det}(1+T_1) \\geq 0}")#text(". If ")#mi("{T_1}")#text(" has spectrum at ")#mi("{-1}")#text(" then we are done, so we may assume that ")#mi("{T_1}")#text(" has spectrum only at ")#mi("{(-\\infty,-1) \\cup (-1,0)}")#text(" (being invertible, ")#mi("{T}")#text(" has no spectrum at ")#mi("{0}")#text("). We split ")#mi("{V_1 = V_3 \\oplus V_4}")#text(", where ")#mi("{V_3,V_4}")#text(" correspond to the portions of the spectrum in ")#mi("{(-\\infty,-1)}")#text(", ")#mi("{(-1,0)}")#text("; these are real, ")#mi("{T}")#text("-invariant spaces. We observe that if ")#mi("{V_\\lambda, V_\\mu}")#text(" are generalised eigenspaces of ")#mi("{T}")#text(" with ")#mi("{\\lambda \\mu \\neq 1}")#text(", then ")#mi("{V_\\lambda, V_\\mu}")#text(" are orthogonal with respect to the (complex-bilinear) inner product ")#mi("{\\cdot}")#text(" associated with ")#mi("{Q}")#text("; this is easiest to see first for the actual eigenspaces (since ")#mi("{ \\lambda \\mu u \\cdot v = Tu \\cdot Tv = u \\cdot v}")#text(" for all ")#mi("{u \\in V_\\lambda, v \\in V_\\mu}")#text("), and the extension to generalised eigenvectors then follows from a routine induction. From this we see that ")#mi("{V_1}")#text(" is orthogonal to ")#mi("{V_2}")#text(", and ")#mi("{V_3}")#text(" and ")#mi("{V_4}")#text(" are null spaces, which by the non-degeneracy of ")#mi("{Q}")#text(" (and hence of the restriction ")#mi("{Q_1}")#text(" of ")#mi("{Q}")#text(" to ")#mi("{V_1}")#text(") forces ")#mi("{V_3}")#text(" to have the same dimension as ")#mi("{V_4}")#text(", indeed ")#mi("{Q}")#text(" now gives an identification of ")#mi("{V_3^*}")#text(" with ")#mi("{V_4}")#text(". If we let ")#mi("{T_3, T_4}")#text(" be the restrictions of ")#mi("{T}")#text(" to ")#mi("{V_3,V_4}")#text(", we thus identify ")#mi("{T_4}")#text(" with ")#mi("{T_3^{*-1}}")#text(", since ")#mi("{T}")#text(" lies in ")#mi("{O(Q)}")#text("; in particular ")#mi("{T_3}")#text(" is invertible. Thus")

#align(center)[#tao-fit-display[#mitex("\\text{det}(1+T_1) = \\text{det}(1 + T_3) \\text{det}( 1 + T_3^{*-1} ) = \\text{det}(T_3)^{-1} \\text{det}(1+T_3)^2")]]

#text("and so it suffices to show that ")#mi("{\\text{det}(T_3) > 0}")#text(".")

#text("At this point we need to use the hypothesis that ")#mi("{T}")#text(" lies in the identity component of ")#mi("{O(n,n)}")#text(". This implies (by a continuity argument) that the restriction of ")#mi("{T}")#text(" to any maximal-dimensional positive subspace has positive determinant (since such a restriction cannot be singular, as this would mean that ")#mi("{T}")#text(" positive norm vector would map to a non-positive norm vector). Now, as ")#mi("{V_3,V_4}")#text(" have equal dimension, ")#mi("{Q_1}")#text(" has a balanced signature, so ")#mi("{Q_2}")#text(" does also. Since ")#mi("{T_2 = \\exp(X_2)}")#text(", ")#mi("{T_2}")#text(" already lies in the identity component of ")#mi("{O(Q_2)}")#text(", and so has positive determinant on any maximal-dimensional positive subspace of ")#mi("{V_2}")#text(". We conclude that ")#mi("{T_1}")#text(" has positive determinant on any maximal-dimensional positive subspace of ")#mi("{V_1}")#text(".")

#text("We choose a complex basis of ")#mi("{V_3}")#text(", to identify ")#mi("{V_3}")#text(" with ")#mi("{V_3^*}")#text(", which has already been identified with ")#mi("{V_4}")#text(". (In coordinates, ")#mi("{V_3,V_4}")#text(" are now both of the form ")#mi("{{\\bf C}^m}")#text(", and ")#mi("{Q( v \\oplus w ) = v \\cdot w}")#text(" for ")#mi("{v,w \\in {\\bf C}^m}")#text(".) Then ")#mi("{\\{ v \\oplus v: v \\in V_3 \\}}")#text(" becomes a maximal positive subspace of ")#mi("{V_1}")#text(", and the restriction of ")#mi("{T_1}")#text(" to this subspace is conjugate to ")#mi("{T_3 + T_3^{*-1}}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("\\text{det}( T_3 + T_3^{*-1} ) > 0.")]]

#text("But since ")#mi("{\\text{det}( T_3 + T_3^{*-1} ) = \\text{det}(T_3) \\text{det}( 1 + T_3^{-1} T_3^{*-1} )}")#text(" and ")#mi("{ 1 + T_3^{-1} T_3^{*-1}}")#text(" is positive definite, so ")#mi("{\\text{det}(T_3)>0}")#text(" as required. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("It seems that the standard logarithm can be extended for a more general class of operators ")#mi("T")#text(" on a complex Banach space via its Cauchy integral formula representation (provided that the integration contour encloses the spectrum of ")#mi("T")#text(" and avoids the branch cut).")

#emph[#text("[Remark added – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454980")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("In the Cauchy integral representation (property (iv) before proposition 1), the denominator ")#mi("T-z")#text(" in the integrand should be ")#mi("z-T")#text(" (but it seems better to use the standard notation ")#mi("(z-T)^{-1}")#text(" for the nonscalar resolvent of ")#mi("T")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a451715cbcf60bab91164c36308ad6500cd206ded8207a315c34a656ea1c615-df1ba33d5ef4fdd007bc3ad925ec5414a3994b27ace2788e03655f1da70f63ac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo Stein")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454965")[#strong[#text("Leo Stein")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("You currently have ${z\\in \\mathbb{C} : |\\Im z| < \\pi }$ in your definition of the standard branch of Log. I believe this is a typo, and you mean \\arg instead of \\Im")

#emph[#text("[The restriction on ")#mi("\\text{Im}(z)")#text(" is on the range of Log, not the domain – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc2f46e9cb8f11b3f5c898727e57ed70e7097d4253339d71e597725f67988df5-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jarred Barber")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454966")[#strong[#text("Jarred Barber")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("You have a minor typo in Prop 1: 0 <= k <= n-k should be 0 <= k <= n")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cb494461e4227fc760398a7b4f79d876e3d5159331759c9de724d7026bc1a64-f16b27a8814218c3040363c4e9cad3c0155e128c287aa4b5b3d4df51fd50a291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454967")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("It may be good to remark that the standard branch (like any branch) of the logarithm also has one not so nice property: In general Log (zw) is not equal to Log z + Log w. For the multivalued function log it is true that log (zw) = log z + log w in the sense of (Minkowski) sum of sets.")

#emph[#text("[Remark added – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("The identity ")#mi("\\log (z w) = \\log z +\\log w")#text(" is satisfied for the standard branch near ")#mi("(z, w) = (1, 1)")#text(" in ")#mi("\\mathbb C^2")#text(" and therefore (by analytic continuation) also globally on the product of the corresponding domains (for ")#mi("z")#text(" and ")#mi("w")#text(") in ")#mi("\\mathbb C^2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("Correction: In order to use the analytic continuation argument, the domains of ")#mi("z")#text(" and ")#mi("w")#text(" should be sufficiently restricted (e.g. to the open right half plane) so that their “productset” should be connected and not intersecting the branch line (i.e. ")#mi("\\log (z w)")#text(" should be well defined).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("Since the standard logarithm is holomorphic on its domain, it is uniquely determined (via analytic continuation) by its value at any single point in the domain (e.g. ")#mi("0")#text(" at ")#mi("z=1")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8266701e032ace9dc4310277b0ebeb7a9e11f13ac2c40d3d04e7c20b1ad2ff3-4e71f90e0551e51505764ccaed4ed00daf95b1a268b543bb7960a38f5390263c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454976")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("Typo: you wrote Log(zw)=Log(z)Log(w).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454977")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("This choice of standard branch has the slightly odd property that, if ")#mi("G")#text(" is a Lie subgroup of ")#mi("GL_n")#text(", then ")#mi("\\mathrm{Log}(G)")#text(" may not land in the Lie algebra of ")#mi("G")#text(". For example, if ")#mi("G")#text(" is ")#mi("SU(3)")#text(", and ")#mi("g")#text(" has eigenvalues ")#mi("e^{(2 \\pi i) 1.1/3}")#text(", ")#mi("e^{(2 \\pi i) /3 }")#text(" and ")#mi("e^{(2 \\pi i)0.9/3 }")#text(", then your logarithm will have eigenvalues ")#mi("(2 \\pi i) (1.1/3, 1/3, 0.9/3)")#text(" and hence trace ")#mi("2 \\pi i")#text(", not ")#mi("0")#text(". Indeed, for ")#mi("SU(3)")#text(", I think your fundamental domain is disconnected, having three regions where the logarithm has trace ")#mi("(2 \\pi i)")#text(", ")#mi("0")#text(" and ")#mi("- (2 \\pi i)")

#text("A while back I noticed a way to fix this for simply connected compact groups. Let ")#mi("\\mathfrak{g}")#text(" be the Lie algebra. Let ")#mi("U \\subset \\mathfrak{g}")#text(" be the set of ")#mi("g")#text(" such that the spectrum of ")#mi("\\mathrm{ad}_g")#text(" lies in ")#mi("(- 2 \\pi, 2 \\pi)")#text(". Then ")#mi("U")#text(" is a convex neighborhood of the origin in ")#mi("\\mathfrak{g}")#text(", and the exponential map ")#mi("U \\to G")#text(" is an open immersion with dense image. In the ")#mi("SU(3)")#text(" case, this means that we lift ")#mi("(e^{i \\alpha}, e^{i \\beta}, e^{i \\gamma})")#text(" in the unique manner such that ")#tao-math("\\left|\\alpha-\\beta\\right|", block: false)#text(", ")#tao-math("\\left|\\beta- \\gamma\\right|", block: false)#text(" and ")#tao-math("\\left|\\alpha-\\gamma\\right| < 2 \\pi", block: false)#text(" and ")#mi("\\alpha+\\beta+\\gamma = 0")#text(". For example, we lift ")#mi("(e^{(2 \\pi i) 1.1/3}, e^{(2 \\pi i) /3 }, e^{(2 \\pi i)0.9/3 })")#text(" to ")#mi("(2 \\pi i) (-1.9/3, 1/3, 0.9/3)")#text(".")

#text("The argument I found went through a bunch of root system combinatorics, although I assume there is a simple explanation for it that I missed. I'd be curious whether people have seen this before.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75cab974d3e4b36d278f8d4f55e5561ef1f5c2e617221aa4785aeeb609de8914-7c7719acb3209aefbac96b72879bf9fb02032b2907f1a7d31cae1f59cc60695c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-454979")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2015")])]

#text("For a simply connected compact group, consider the composite ")#mi("{\\mathfrak g} \\stackrel{\\exp}{\\to} G \\to G/\\sim \\cong T/W \\cong ({\\mathfrak t}/\\Lambda)/W = {\\mathfrak t}/(\\Lambda \\rtimes W) \\cong A")#text(" where ")#mi("\\Lambda")#text(" is the coweight lattice and ")#mi("A")#text(" the Weyl alcove. Now consider the preimage of the far wall of the Weyl alcove; I think your ")#mi("U")#text(" is the connected component around ")#mi("0\\in \\mathfrak g")#text(" of the complement.")

#text("Maybe this is the root system combinatorics you were talking about. Anyway yes, at least one person has seen it before.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455037")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2015")])]

#text("Yup, that’s the root system combinatorics I was thinking about, although I phrased it differently in my mind.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afc511369a55df59d8b9fa8e97beba56080c5ed8623f15fbfcc80ffae4a21c7d-8eecaeef4d9a1e16e5693192bb1eb07eabbd7826d049167e157afd9aebba198f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei Wang")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455106")[#strong[#text("Lei Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2015")])]

#text("About Proposition 3, what about ")#mi("T")#text(" lies in the other components of ")#mi("O(n,n)")#text(" ? I feel one can still show bounds on ")#mi("\\det(1+T)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("It appears that the same argument gives either ")#mi("\\text{det}(1+T) \\geq 0")#text(" or ")#mi("\\text{det}(1+T) \\leq 0")#text(" for any ")#mi("T \\in O(n,n)")#text(", where the sign of the inequality depends on whether the restriction (and projection) of ")#mi("T")#text(" to a maximal totally positive subspace is orientation preserving or not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afc511369a55df59d8b9fa8e97beba56080c5ed8623f15fbfcc80ffae4a21c7d-8eecaeef4d9a1e16e5693192bb1eb07eabbd7826d049167e157afd9aebba198f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei Wang")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455154")[#strong[#text("Lei Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("There are four components in total, right ? Can one prove a stronger statement like ")#mi("\\text{det}(1+T) \\equiv 0")#text(" in one (or even two) of the four ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("I believe this is the case when ")#mi("n")#text(" is odd. For instance, for odd ")#mi("n")#text(", the component of ")#mi("O(n,n)")#text(" containing ")#mi("\\text{diag}( I_n, -I_n)")#text(" will necessarily have an odd number of eigenvalues at -1 (counted with algebraic multiplicity), since all nearby eigenvalues come in pairs ")#mi("\\{\\lambda,1/\\lambda\\}")#text(", and so ")#mi("\\det(1+T)")#text(" is necessarily zero on this component. (One way to think about this is that one inequality comes from considering the projection of ")#mi("T")#text(" onto the totally positive space, and the other inequality comes from analysing the totally negative space. When ")#mi("n")#text(" is even, it looks like both arguments give the same inequality rather than opposing inequalities.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afc511369a55df59d8b9fa8e97beba56080c5ed8623f15fbfcc80ffae4a21c7d-8eecaeef4d9a1e16e5693192bb1eb07eabbd7826d049167e157afd9aebba198f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei Wang")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455193")[#strong[#text("Lei Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("It appears to me this is independent of ")#mi("n")#text(". In the ")#mi("(+,-)")#text(" and ")#mi("(-,+)")#text(" component one has ")#mi("\\text{det}(1+T) = 0")#text(", while in the ")#mi("(+,+)")#text(" component ")#mi("\\text{det}(1+T) \\geq 0")#text("; ")#mi("(-,- )")#text(" component ")#mi("\\text{det}(1+T) \\leq 0")#text(". Again, just an empirical observation plus some guesswork from a computational physicists :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2015")])]

#text("I think you are correct. In particular, ")#mi("1+T")#text(" is always singular on the ")#mi("(+,-), (-,+)")#text(" components. It would be interesting to have an elementary proof of this in the case when n is even (the argument I gave only worked then n is odd). It generalises the assertion that an orthogonal matrix of determinant -1 necessarily has an odd number of eigenvalues at -1 (because the product of all the other eigenvalues is positive), regardless of the parity of dimension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-456276")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("Dear Lei, here is a direct argument that you asked for in our email correspondence. Assume that ")#mi("T\\in O(n,n)")#text(". Following the blog entry, we can assume that ")#mi("T_1")#text(" has no spectrum at ")#mi("-1")#text(", for otherwise ")#mi("\\text{det}(1+T)=0")#text(". Then,")

#mi("\\displaystyle \\text{det}(T)=\\text{det}(T_2)\\text{det}(T_3)\\text{det}(T_4)")

#mi("\\displaystyle =\\text{det}(T_2)\\text{det}(T_3)\\text{det}(T_3^{*-1})")

#mi("\\displaystyle =\\text{det}(T_2)=1")#text(",")

#text("hence ")#mi("T\\in SO(n,n)")#text(". Furthermore, the sign of ")#mi("\\text{det}(1+T)")#text(" equals the sign of ")#mi("\\det(T_3+T_3^{*-1})")#text(", which in turn equals ")#mi("\\pm 1")#text(" depending whether ")#mi("T")#text(" lies in the ")#mi("(+,+)")#text(" component or the ")#mi("(-,-)")#text(" component. Done.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2015")])]

#text("I share the assessment of:")

#mi("e^{2\\pi i k} = 1 \\rightarrow e^{0k}")

#text("therefore ")#mi("\\forall(z) = \\frac{1 + i\\sqrt{n}}{n}")#text("; ")#mi("n \\in Z")#text(" we have.")

#text("$latex e^{\\frac{1+i \\sqrt{n}}{n}} = e^{\\frac{1}{n}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-455851")[#strong[#text("Sign problems, Terry Tau, and open science | This Condensed Life")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2015")]

#text("[…] For spin unpolarized systems it’s pretty clear why each A_i is of this form, but for others systems it’s not as clear. Anyways, this was the question he posed to mathoverflow. Amazingly people jumped on it, and it wasn’t long before Fields Medalist Terrance Tao got involved! It was then only a matter of 3 days before the conjecture was proven to be true in a mathematically rigorous way. For a full writeup of the proof, you can check out Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-456222")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")])]

#text("Reblogged this on ")#link("https://pinkiguana2.wordpress.com/2015/05/31/the-standard-branch-of-the-matrix-logarithm/")[#text("Pink Iguana")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-459728")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2015")])]

#text("There is a clear link between the natural logarithm, and trigonometric functions (cosine, sine, which are defined on the two-dimensional space). I have a question. Built on whether the model such as four-dimensional space? I mean the same functions for the study of the nature of prime numbers for example.Until I see the study of the same prime numbers only with a two-dimensional space.And I’m still interested in the nature of prime numbers in what space they are located? Maybe in the third? At least describe them by using the same two-dimensional space is difficult. Perhaps this is more a philosophy than mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a493bc680c194a6b8e73610d391f256d757714288d517e2360c971c025a5ac-2ccaa27a88e27073787a543e69b2eb052d48b75c08438dedb6b716a5fb21d0f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2015/05/03/the-standard-branch-of-the-matrix-logarithm/#comment-459729")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2015")])]

#text("I mean the opening of a Cartesian system, and then the natural logarithm. Later there were complex numbers.")
]
]
