// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/
// Converted to Typst by tao2typ: "2026-10-14T11:19:28.994647+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Fast math/slow math", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Fast math/slow math")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/")[#text("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://antieau.github.io/")[#text("Ben Antieau")]#text(", crossposted ")#link("https://antieau.github.io/2026/09/15/fast-math-slow-math.html")[#text("from his blog")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("To resolve a central tension in the practice of mathematics by academics, I suggest the parallel with fast food and its attendant slow food movement.")

#metadata(none) <tao-33e8d92c3bfb87bc9380>

#strong[#text("Three hearts")]

#text("Mathematical work comprises many activities and experiences. Among my favorites are:")

#enum(start: 1, 
[#text("Reading a single paper over the course of several months.")],
[#text("The thrill of the chase, when the scent of a theorem, discovery, or the right definition is in the air.")],
[#text("The moment a PhD student shows me their first theorem or paper.")]
)

#text("The first and second constitute gaining and creating knowledge. The third is about transmitting meta-knowledge: the ability to perform 1 and 2.")

#text("Mathematics for me has always been about the joy of personal understanding and the engagement in bringing others around to that understanding, usually slowly over the course of many months or years.")

#text("In recent months, a deep unease has been growing within the mathematical community around the role of language models in our research. The fear is fundamentally economic. LLMs ")#emph[#text("can")]#text(" produce mathematical statements and proofs, some certainly interesting.")

#text("Are we ourselves, mathematicians, obsolete? Will our students fail to get jobs? Will our funding agencies, or even our universities, abandon us? Is mathematics in fact solved?")

#text("No. Mathematics is not the collection of true statements implying, by complement, the collection of false statements as well. It cannot be solved any more than human experience can be.")

#strong[#text("Mathematics and society")]

#text("Most academic mathematicians are slow math practitioners at heart, even if the pressures of paper-writing, grant-proposing, teaching, and administration seem rather far from our idealized contemplative life.")

#text("Yet, math also forms the bedrock of the sciences and engineering and as such is central to how human societies solve technical problems. Mathematicians cannot expect our esteemed place within our culture to survive unchanged if we do not use every tool possible to help it face its grand challenges.")

#text("Alexander Nazaryan wrote in the New York Times on 19 June 2025:")

#emph[#text("“Problems in mathematics take decades or centuries, sometimes, to solve,” [Patrick Shafto] said in a recent presentation at DARPA’s headquarters on the Exponentiating Mathematics project, which is accepting applications through mid-July. He then shared a slide showing that, in terms of the number of papers published, math had stagnated during the last century while life and technical sciences had exploded. In case the point wasn’t clear, the slide’s heading drove it home: “Math is sloooowwww. …”")]

#text("We exist, professionally, in part to educate engineers and scientists, to provide researchers to national laboratories, and to provide highly-trained workers to companies. Occasionally, theoretical results open up new areas of specific application, for example the use of lattice-based methods in post-quantum cryptography standards. If we turn our back on this part of our role, we can certainly say goodbye to our grants and teaching reductions. We can go the way of the Department of —, permitted to exist out of nostalgia, but decreasingly relevant.")

#text("To address the central contradiction between our personal practice and our external purpose, I propose fast math and slow math as ways of thinking about different types of mathematics. Just as we all prefer slow food, sometimes fast is what we need, or crave.")

#text("These different ways are not meant to separate human mathematicians into “slow math” and “fast math” camps. Indeed, I strongly urge against the temptation to split into us and them. I don’t want to sit on hiring committees fractured by debates over AI use or virtue testing instead of honest evaluation of candidates.")

#text("The goal of slow math and fast math is the same: to increase human understanding of what is true and false in those regions of “proposition-space” of interest to us. These take their places as different modalities of doing mathematics, alongside computer algebra, exposition, the creation of visualizations, editorial work, and so on. Not every mathematician does, or should do, all of these.")

#strong[#text("Dream bigger dreams")]

#text("Thanks in part to technological advances, but largely driven by an unending thirst to know, physicists have gone in the span of a couple of centuries from tabletop experiments to running some of the largest collective endeavors of humankind.")

#text("LLMs represent a tremendous technological advance and some might choose to dream bigger dreams. We should deliberately and thoughtfully use these models and other AI tools to have those dreams. Some of these might be to answer new, pressing questions created by the very existence of the tools themselves, like the problems of interpretability in LLM systems. These tools were built with mathematics and our discipline provides one of the principal means by which we understand them and use them safely.")

#text("Other dreams should be to undertake audacious programs, which would not have been practical in the past. I have in mind research directions at the scale of the Langlands program or Grothendieck’s dream of motives.")

#text("One example could be higher-dimensional algebraic geometry. Many counterexamples that have been established with LLM assistance have to do with the fact that we do not know the zoo of algebraic varieties in higher dimension the way we do curves and surfaces. (Although, of course, there have been many, many amazing results, like Beauville–Bogomolov.)")

#text("Such programs should be pursued rigorously with a back-and-forth between humans and LLMs. These programs should have directors, postdocs, students, standards. The goal would be to leverage LLMs to understand high-dimensional phenomena — for humans to understand. It is not to produce a slurry of results no human has read or understood.")

#text("These programs are fast math: far-reaching, ambitious, almost reckless. They would aim at transformative new discoveries and organizations of mathematical knowledge, perhaps particularly motivated by grand challenges at the boundary of mathematics and applied mathematics. But they would not end with a given discovery. They would also be responsible for producing lecture notes, textbooks, databases, and other tools to aid human apprehension of their discoveries. They would exist to truly harness AI capabilities and prepare the outputs for human understanding.")

#strong[#text("Collective standards")]

#text("I suggest the following standards for the mathematical community. Please consider these as a first proposal and feel free to send me feedback. The overall goal is that we should use LLMs to aid in human mathematicians’ understanding, not merely to increase our production.")

#enum(start: 1, 
[#emph[#text("Disclose all collaborations, including with LLMs.")]#text(" It is my hope that eventually we can use open source models for much of the day-to-day work that people might turn to LLMs right now. We already cite computer algebra systems as soon as the work goes beyond the totally routine. We should do so here.")

#emph[#text("Do not judge mathematicians for their LLM use.")]#text(" The standards of our community are still in flux. We can fight over what those standards should be, but individuals have to act in the meantime and we should not litigate their behavior.")

#emph[#text("Posting a paper to the arXiv or publishing it means three criteria have been met by the authors:")]

#list(
[#text("you could reproduce the main ideas if on a desert island (excepting large computer computations);")],
[#text("you have written it for human understanding, to the best of your ability;")],
[#text("you take intellectual and reputational responsibility and credit for the results.")]
)

#text("In the second point, using LLMs for polishing writing, spell-checking, finding inaccuracies, or creating diagrams is completely fine. Using an LLM to generate a first draft of a paper is not acceptable.")

#emph[#text("LLMs should not be used to compete with other mathematicians, to scoop them or otherwise embarrass them.")]#text(" It goes without saying that we are somewhat competitive, but there is nothing to be gained from this behavior and a lot to lose in terms of collegiality. We are extremely lucky to be in a field where we talk openly at conferences not only about what we’ve done but what we are working on, sometimes years before those results see the light of day.")

#emph[#text("Refrain from asking every random question to LLMs, or at least from making the answers public.")]#text(" Simple results are important for training students. Many have been excited to ask questions long-abandoned in their research programs, including myself. Of course, we cannot say that any given question is off-limits. But I expect that this fervor will die down in the coming weeks or months. And we do not need to repeat it with every new “release” from the big labs.")

#emph[#text("Focus, if you choose to use LLMs, on developing your own research, intuition, and results.")]#text(" No one owns an area of mathematics or a certain problem. But it is not acceptable for me to wake up one day and say, you know I know famous mathematician — is working on problem — and I’m just going to solve it. They will be impressed with me, or I will get that next job I need. The easiest way to guard against this behavior in the long run is to just not reward it.")

#strong[#text("Do not work faster than you can understand or effectively communicate.")]#text(" This golden rule informs all of the others.")

#emph[#text("Do not recruit, hire, promote, or praise based on the number of papers.")]#text(" In the past, the production of high-quality papers has provided a proxy for evaluating understanding and brilliance. Of course, you want to hire the individuals who’ve written these papers to access their insight for your own research or for the sake of the students in your department’s charge. Each department will have to find new ways of judging.")

#emph[#text("Do not delegate the previous task entirely to LLMs.")]]
)

#text("Before LLMs, I typically had 5-10 projects on the burners or in the fridge at any one time, probably working actively on 2-3 at any one time. This reflects my interests and personal capability to pay attention to them. Having used language models, specifically agentic coding systems (basically nonstop for coding for 7 months), I can attest that there is a tendency to do more and more and more, but that the pleasure in doing so drops, the quality is hard to verify, and my understanding of the output goes down as well. As such, I strongly disagree with the premise of Shafto’s slide that stagnation in mathematics is measurable by slower growth in publication rates than in other sciences. Papers are only a proxy for understanding.")

#text("There are also areas where I believe it is explicitly permitted to use LLMs. They can provide translation services, whether to improve writing in a non-native tongue, or to translate into one’s own language. They can proofread. Let’s face it, no one is doing this for us anymore at most journals. They can act as tutors.")

#text("Experiments will inevitably produce writing largely generated by an LLM and possibly understood by no human. These texts deserve a home too, because they might later be useful for human work, but that home is not the arXiv.")

#strong[#text("Pascal")]

#text("We have known since von Neumann, Turing, and Gödel in the 1930s and 40s that mathematical theorems are nothing but provable propositions in a formal language. These could be produced automatically by any computer.")

#text("Humans care about individual statements and theorems. Perhaps in part because of our intuition from the natural world, these propositions are ")#emph[#text("not")]#text(" equal in our eyes. Mathematics is what human mathematicians understand. Beyond is darkness: true absence, or inscrutable trophies of alien intelligence.")

#text("In ")#emph[#text("Pascal’s Sphere")]#text(", Borges invokes Blaise Pascal: “nature is a fearful sphere whose center is everywhere and circumference nowhere” to propose that “universal history is the history of the different intonations given a handful of metaphors.” Indeed, mathematics is an infinite sphere whose center is everywhere and circumference nowhere.")

#text("Like Pascal, overwhelmed by humanity’s simultaneous insignificance ")#emph[#text("and")]#text(" ability to understand our insignificance, mathematicians work in a habitable zone in which the theorems, questions, and conjectures are configured so that some structure ")#emph[#text("is")]#text(" visible.")

#text("The fact that LLMs can seemingly be organized into their own societies is interesting. The mathematics that they produce there is not interesting to me. Language models have not solved mathematics for humans. They are practicing mathematics for a nascent civilization.")

#strong[#text("Closing")]

#text("I believe civilizations beyond ours exist, have existed, and will exist in the future. Our theorems have already been proved. They will be forgotten, and proved again and again until the last ember goes out. The exercise of mathematics is the work of civilization, and we will continue.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cef49c69dbf15fa46a6f11fa580177bcfe52fa707aabe33de03a331e7240393a-44a86df58494527c99095f7a0f5ed2f1315a2caeec286488a02ad8f34ef2f979.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of birdbriskly6a8a1d7ac5")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695348")[#strong[#text("birdbriskly6a8a1d7ac5")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Very good advice here. And let me add something I posted yesterday: I think the AMS — in collaboration with world math organizations — should set up a new kind of on-line reviewing journal. Quick response is essential. Various Blogs have facilities for reader comments (which can also be reviewed). Reviews do not have to be “complete” — as early awareness is important. A new kind of index will also be needed so people can search quickly for relevant opinions. AI is here to stay, and we have to learn how to cope in real time with these developments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("If people had time to quickly review papers they would already be doing that through the current journal system. The problem is not one that the AMS can solve.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc66262c9a27a674c7ecc32b20434fda91b7cd91c8080566c4d8d205e3cc4af-5403fcc05fa44b6dfe6d06b7e14804a0afb42573fc3e4acfd8e330eb002e927b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeraoulia")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695357")[#strong[#text("zeraoulia")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("I fear a day will come when we find no problems left to solve, nor are even able to propose new ones.")

#text("Prof. Zeraoulia Elhadj")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695395")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I don’t have such fears. Anycase,if that happens, such day belongs to distant future where mankind and machines going to look like totally different than we know")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("i don’t think this will happen anytime soon")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68982e106f53535e22c5191d2b372e1d179829027341443eeadafc3c91569b65-7c9cafc6870d0d87060aa3b7ecb8d34153fea780620bf000e72342af4be76274.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zeon")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695378")[#strong[#text("Zeon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Hi Terence,")

#text("I’m a professional Surveyor in NSW Australia and have been working on simplifying transformation equations developing algorithms for reducing GNSS Coords to Ground Coords and i have been using a few LLMs to help in the derivations after i have completed the geometrical reconfigurations with my techniques.")

#text("It taken me on more than a few occasions of +50 chats and responses before i get the workings to my satisfaction. Its frustrating as hell but there is a positive that it makes me still have to carry out the rigour and contemplations, more than a superficial exercise. The other bonus is that through all the AI slop, sometimes something pops up that i hadnt thought of and actually turns out to be a good path or conjecture/proof bypass.")

#text("People shouldnt hide or feel ashamed they have used an LLM in any capacity whatsoever, it should only ever be considered as an assistant tool (unless they’re stupid enough to just accept the results it outputs, then that would be embarrassing). This is the beginning of an evolution in education and training.")

#text("I see it like the progression of computer software, started of as binary code of 0 & 1s, then into bytes,then words, then compilers, so each time a coder didnt have to go back to ‘first principles’. The same looks like applying with LLMs. No more first principle work (except for the purest), less calculus, algrba, etc as the tools will do that for us. But at the moment there is no way in hell thats going to happen with the current crop. Too much noise in the sampling and too many guardrails being set to normalise the results. (Obviously the private ones can circumvent tis but the mainstream ones won’t and will be probably 99.9% of global users.)")

#text("Its like the LLM’s bits and bytes are now skyscrapers but are filled with 0 & 1s + # +*+5!@")

#text("The current architecture is inadequate and that probably goes with those who rely on it too much already. Academia needs to be ready to accept Human/AI collaborations as legit work and its not cheating in my view if a LLM helps a new discovery. From my experience dealing with a sevant who acts like a 7 year old is far from pleasant and if something comes out unique, well its like winning lotto at present.")

#text("In my opinion the AI industry’s trajectory under the current architecture norms is heading for a catastrophe for state and global economics. Its is going to have a huge impact on the skills base for future generations if its not fixed in the next couple of years.")

#text("Cheers")

#text("Zeon")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695379")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("“Such programs should be pursued rigorously with a back-and-forth between humans and LLMs. … It is not to produce a slurry of results no human has read or understood.”")

#text("I don’t understand why you call this “fast” math unless you really are envisioning an industrial scale production of result in gigantic CERN like laboratories. Nothing about collective understanding is fast, it’s intrinsically a slow process…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Dear Ben,")

#text("This is a great post. Indeed, after a literal onslaught of doomposting about LLMs and the end of mathematics (not on this blog ofc, but elsewhere), this post gives me some much needed hope.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Here is an analogy to the present state of mathematics which I cannot seem to get out of my head:")

#text("I like to run quite a lot. I have competed in races, including a marathon, and intend to do so again. It has never crossed my mind to show up in the starting line with a Ferrari, though.")

#text("Technological advances are, of course, a part of life. How we choose to use them is up to us. When cars were invented, we didn’t just say “that’s it, we are bringing them to our running events.” On the contrary, running remained. They did the logical thing: a new sport was created (i.e. Formula 1).")

#text("Somehow a great deal of mathematicians seem to have accepted that we need to allow people in cars to compete with those on foot. And, most surprisingly of all, not only should people in cars be allowed to compete with those on foot, but we should not judge them for doing so.")

#text("If you want to use AI, go ahead. I can’t stop you. I have no power. All I can say is, don’t judge me for judging you, especially when I have all the reason in the world to do so. I am not the one showing up to your sport with the car. I am not the one with a syringe filled with steroids ready to be injected into my bloodstream.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695567")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I share the general feeling of this comment.")

#text("But, somehow it is not so easy to see mathematics as a “sports”.")

#text("The question lies in what science is or the activity of acquiring (mathematical) “knowledge” is.")

#text("Even if we view mathematics similarly as we view a sports, it is still that our rules are not something we can make arbitrarily, as it is about scientific/mathematical knowledge, but about who wins as in sports.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695570")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("There should be an honest introspection why we (math community) do what we do? Why do we prove theorems? Why do we publish? Then WHO IS READING?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695581")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("The thing is that mathematics is not a sport. It’s a science. Using all the instruments available to find the truth and deeper understanding of the subject is not analogous to an athlete showing up to a race with a sports car, but to an astronomer refusing to use telescopes because the sport is naked-eye observation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695617")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I am happy to see all the comments to my original post. It is good to see that we are engaging in a discussion, and that the intended effect of my post has been achieved.")

#text("Of course, mathematics is not a sport in the classical sense. However, unless you have luxury of already being a tenured professor in a university (like the vast plurality of the authors to of the recent blog posts: Antieau, Gowers, Kra, Koukoulopolous … not to forget the man who runs this blog, Tao), it is quite frankly ridiculous to pretend that mathematics is not a competition. Notice also that Antieau admits in point 4 above that mathematicians are competitive by nature (obviously). By the way, I don’t see how you can use an LLM to generate mathematics while also claiming, as he does in point 4, that it should “not be used to compete.” By definition, our papers are how we compete.")

#text("The fact is that there are many more people who want to do mathematics than there are academic positions. Up until now, one of the most beautiful things that is unique to the mathematical profession (and is not even shared in the experimental sciences) is that it was more-or-less a meritocracy. I am of course not so naive as to believe there is no politics involved (I myself, just beginning a postdoc, had three strong papers when applying (two solo) and lost numerous positions to people who had 0… politics matters a lot, unfortunately).")

#text("However in the past, if you were sufficiently good, things would eventually “work out” and you would get a job you more or less deserved. Unfortunately it seems more and more likely that this will no longer be the case.")

#text("So in this case, mathematics is indeed a sport. And I refuse to cheat, which is, plain and simple, what using generative AI is.")

#text("I could not live guilt-free if I used AI and got a job over somebody who did not. This is just who I am. Maybe it is not who you are.")

#text("Maybe you don’t like the analogy with sports. Mathematicians seem to be incredibly fond though of comparing the role of AI in math to the role of chess engines in chess. Would you like to know what the biggest sin is in a game of chess between two humans, the action which, if discovered, can permanently ruin your career? It is using an engine in a match with a human.")

#text("Please explain to me how this differs from using AI to write papers? And if you still don’t agree, perhaps this will finally open your eyes: ")#link("https://annals.math.princeton.edu")[#text("https://annals.math.princeton.edu")]

#text("Annals of Math recently changed its submission system. They seemed to have removed the justification for this change, but previously they wrote it was because of the “significant increase in the number of papers submitted to the journal.”")

#text("Surprise, surprise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#enum(start: 1, 
[#text("I think using LLM is not cheating, because it is not prohibited by the rules explicitly. Rather, we see a number of well-known mathematicians encouraging scientists to integrate LLM in their research (though I suppose it is important to declare AI usage openly in this case).")],
[#text("Chess is also a sport. So revealing the person who has the best ability to play chess without a computer is a quite appropriate goal for chess competition. On the contrary, revealing the person who has the best ability to do a math research without a computer as a goal of writing papers seems ridiculous to me. As mentioned above, the goal of mathematical research is to acquire new knowledge and not to decide which scientist is cleverer.")],
[]
)
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I think these posts that clarify our values and advocate for community norms are very valuable. But I think the most important thing right now is to make the case for the societal value of human understanding of mathematics, so I hope to see posts focussing on that in the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Maybe major AI-assisted papers will eventually need a short closed-book oral exam: can the authors actually explain the key idea, say what breaks if the assumptions change, and adapt the argument on the spot? We used to assume a correct proof and real understanding came together. AI may force us to check both.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("You might be interested in the book “The Slow Professor” that came out ten years ago. It also draws on the slow food movement as an analogy. This is a different argument though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("This list of ethical practices is good, and what makes sense to follow as a tenured well-established academic. But the incentives for younger people, subject to an extremely competitive job market, push away from this. What happens when LLMs can produce high-quality paper, written better than the average math paper? (Not really so high a bar!)")

#text("And if the systems become truly capable, people will want to push them to their limit, even if they are not mathematicians. Suppose a hobbyist can amass enough compute and have a machine spin-up a vast program at the push of a button, that resolves and formalizes the answers to many questions. How should mathematicians deal with the output?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695414")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("this is a hypothetical which we have no evidence has come to happen")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Obviously it hasn’t happened yet. The second scenario is speculative. But the first is not: do you really think that, given the rate of progress, these systems will not be able to summarize and compress arguments well within a few years?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("the rate of progress on LLMs is jagged. There are some aspects which we see them getting really good at really fast. But they haven’t gotten good at (for example) the conceptual aspects of mathematics. ")#linebreak()#text("this is not to say that they can’t but it’s not clear to me how they would get good at that")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695463")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Hi Ben, Your 2nd bullet in point 3 raises the obvious question. Are we still writing mathematics for human understanding? There are many such questions, regarding the math profession, that is unlikely to be palatable for public consumption.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("You are right: “human mathematician” might have been better.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Nothing to add except that I wish that more public thought from leaders in the community was so well-written, concise, useful, and clear-headed. Bravo")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/#comment-695649")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("AI is not a threat to math profession, given the way it is practiced now. Proving theorems and publishing has become a “test” or “exam”. A graduate student publishes a paper to earn a degree and a job. That is a pure exam, and very few read their paper. For the rest of us (professors) it is a livelihood and part of the job. It is a test we need to pass to earn our annual salary raise (inflation adjustment), or next promotion, or funding. Vast majority of published papers are not read by more than 10 people. These 10 readers usually consist of the a circle of collaborators of the author, for the purpose of writing the next paper. If you accept my characterization of what we do, AI cannot hurt. You will give the exam, that we need to pass. I am sure this not something that the math establishment want to hear. (I may post this on X).")
]
