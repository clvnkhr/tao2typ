// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/
// Converted to Typst by tao2typ: "2026-10-14T16:39:00.891782+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Measurable tilings by abelian group actions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Measurable tilings by abelian group actions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 March 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/")[#text("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#linebreak()#link("https://homepages.warwick.ac.uk/staff/Jan.Grebik/")[#text("Jan Grebik")]#text(", ")#link("https://www.math.ucla.edu/~greenfeld/")[#text("Rachel Greenfeld")]#text(", ")#link("https://n.ethz.ch/~rozhonv/")[#text("Vaclav Rozhon")]#text(" and I have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2203.01511")[#text("Measurable tilings by abelian group actions")]#text("“. This paper is related to an ")#link("https://terrytao.wordpress.com/2020/10/08/the-structure-of-translational-tilings-in-zd/")[#text("earlier paper of Rachel Greenfeld and myself")]#text(" concerning tilings of lattices ")#mi("{{\\bf Z}^d}")#text(", but now we consider the more general situation of tiling a measure space ")#mi("{X}")#text(" by a tile ")#mi("{A \\subset X}")#text(" shifted by a finite subset ")#mi("{F}")#text(" of shifts of an abelian group ")#mi("{G = (G,+)}")#text(" that acts in a measure-preserving (or at least quasi-measure-preserving) fashion on ")#mi("{X}")#text(". For instance, ")#mi("{X}")#text(" could be a torus ")#mi("{{\\bf T}^d = {\\bf R}^d/{\\bf Z}^d}")#text(", ")#mi("{A}")#text(" could be a positive measure subset of that torus, and ")#mi("{G}")#text(" could be the group ")#mi("{{\\bf R}^d}")#text(", acting on ")#mi("{X}")#text(" by translation.")#linebreak()

#linebreak()#text("If ")#mi("{F}")#text(" is a finite subset of ")#mi("{G}")#text(" with the property that the translates ")#mi("{f+A}")#text(", ")#mi("{f \\in F}")#text(" of ")#mi("{A \\subset X}")#text(" partition ")#mi("{X}")#text(" up to null sets, we write ")#mi("{F \\oplus A =_{a.e.} X}")#text(", and refer to this as a measurable tiling of ")#mi("{X}")#text(" by ")#mi("{A}")#text(" (with tiling set ")#mi("{F}")#text("). For instance, if ")#mi("{X}")#text(" is the torus ")#mi("{{\\bf T}^2}")#text(", we can create a measurable tiling with ")#mi("{A = [0,1/2]^2 \\text{ mod } {\\bf Z}^2}")#text(" and ")#mi("{F = \\{0,1/2\\}^2}")#text(". Our main results are the following:")#linebreak()

#list(
[#text("By modifying arguments from previous papers (including the one with Greenfeld mentioned above), we can establish the following “dilation lemma”: a measurable tiling ")#mi("{F \\oplus A =_{a.e.} X}")#text(" automatically implies further measurable tilings ")#mi("{rF \\oplus A =_{a.e.} X}")#text(", whenever ")#mi("{r}")#text(" is an integer coprime to all primes up to the cardinality ")#mi("{\\# F}")#text(" of ")#mi("{F}")#text(".")],
[#text("By averaging the above dilation lemma, we can also establish a “structure theorem” that decomposes the indicator function ")#mi("{1_A}")#text(" of ")#mi("{A}")#text(" into components, each of which are invariant with respect to a certain shift in ")#mi("{G}")#text(". We can establish this theorem in the case of measure-preserving actions on probability spaces via the ergodic theorem, but one can also generalize to other settings by using the device of “measurable medial means” (which relates to the concept of a ")#link("https://en.wikipedia.org/wiki/Universally_measurable_set")[#text("universally measurable set")]#text(").")],
[#text("By applying this structure theorem, we can show that all measurable tilings ")#mi("{F \\oplus A = {\\bf T}^1}")#text(" of the one-dimensional torus ")#mi("{{\\bf T}^1}")#text(" are ")#emph[#text("rational")]#text(", in the sense that ")#mi("{F}")#text(" lies in a coset of the rationals ")#mi("{{\\bf Q} = {\\bf Q}^1}")#text(". This answers a recent conjecture ")#link("https://arxiv.org/abs/2012.07567")[#text("of Conley, Grebik, and Pikhurko")]#text("; we also give an alternate proof of this conjecture using some ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1369421")[#text("previous results of Lagarias and Wang")]#text(".")],
[#text("For tilings ")#mi("{F \\oplus A = {\\bf T}^d}")#text(" of higher-dimensional tori, the tiling need not be rational. However, we can show that we can “slide” the tiling to be rational by giving each translate ")#mi("{f + A}")#text(" of ")#mi("{A}")#text(" a “velocity” ")#mi("{v_f \\in {\\bf R}^d}")#text(", and for every time ")#mi("{t}")#text(", the translates ")#mi("{f + tv_f + A}")#text(" still form a partition of ")#mi("{{\\bf T}^d}")#text(" modulo null sets, and at time ")#mi("{t=1}")#text(" the tiling becomes rational. In particular, if a set ")#mi("{A}")#text(" can tile a torus in an irrational fashion, then it must also be able to tile the torus in a rational fashion.")],
[#text("In the two-dimensional case ")#mi("{d=2}")#text(" one can arrange matters so that all the velocities ")#mi("{v_f}")#text(" are parallel. If we furthermore assume that the tile ")#mi("{A}")#text(" is connected, we can also show that the union of all the translates ")#mi("{f+A}")#text(" with a common velocity ")#mi("{v_f = v}")#text(" form a ")#mi("{v}")#text("-invariant subset of the torus.")],
[#text("Finally, we show that tilings ")#mi("{F \\oplus A = {\\bf Z}^d \\times G}")#text(" of a finitely generated discrete group ")#mi("{{\\bf Z}^d \\times G}")#text(", with ")#mi("{G}")#text(" a finite group, cannot be constructed in a “local” fashion (we formalize this probabilistically using the notion of a “factor of iid process”) unless the tile ")#mi("{F}")#text(" is contained in a single coset of ")#mi("{\\{0\\} \\times G}")#text(". (Nonabelian local tilings, for instance of the sphere by rotations, are of interest due to connections with the Banach-Tarski paradox; see the aforementioned ")#link("https://arxiv.org/abs/2012.07567")[#text("paper of Conley, Grebik, and Pikhurko")]#text(". Unfortunately, our methods seem to break down completely in the nonabelian case.)")]
)

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641077")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")])]

#text("“my preprint”? I would expect “our preprint”. (I see the joke now: How many mathematicians does it take to upload a preprint? I’ll leave the punchline for you.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2022")])]

#text("He makes typos, relax")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2022")])]

#text("Is this the first time the expression HaHaHa has appeared in a maths paper 😉 ? Or is it an in-joke?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2022")])]

#text("Is there any known example of similar tiling in the nonabelian case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641221")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2022")])]

#text("We discuss some examples of nonabelian tilings in our paper. We know that the dilation lemma and structure theorem fail quite dramatically in these cases, and also have an example of a non-trivial local tiling in the nonabelian case. There are still some interesting questions concerning measurable tilings of higher-dimensional spheres by rotations (as studied in ")#link("https://arxiv.org/abs/2012.07567")[#text("this previous paper")]#text("), but unfortunately our methods do not have much to say about this situation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2022")])]

#text("Consider the (nonabelian) group of Mobius transformation on the Riemann sphere generated by translation ")#mi("z \\to z+1")#text(" and inversion ")#mi("z \\to 1/z")#text(". Is it possible to find a modular function corresponding to this group such that its fundamental domain creates a tilings of the Riemann sphere by the actions of this group?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641299")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2022")])]

#text("I want to say yes. Did you think of an example?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641298")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2022")])]

#text("What’s a way of thinking of abelian group actions geometrically? When I think of a group action I naively only think of rotating S^1 in the complex plane which I think is abelian? But S^n has too perfect symmetry sometimes, so I can’t imagine other things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/03/03/measurable-tilings-by-abelian-group-actions/#comment-641300")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2022")])]

#text("Forgive me for all the questions, especially if they are easily answered by understanding the paper (which I do not), but what is an example of a nonmeasurable tiling?")

#emph[#text("[A ")#link("https://en.wikipedia.org/wiki/Vitali_set")[#text("Vitali set")]#text(" gives a non-measurable tiling of the real line by the rationals -T.]")]
]
