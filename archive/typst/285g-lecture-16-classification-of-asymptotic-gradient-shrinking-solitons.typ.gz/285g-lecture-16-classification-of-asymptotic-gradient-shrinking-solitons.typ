// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/
// Converted to Typst by tao2typ: "2026-10-14T16:35:20.706560+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 16: Classification of asymptotic gradient shrinking solitons", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")[#text("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In the ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("previous lecture")]#text(", we showed that every ")#mi("\\kappa")#text("-solution generated at least one asymptotic gradient shrinking soliton ")#mi("t \\mapsto (M,g(t))")#text(". This soliton is known to have the following properties:")

#enum(start: 1, 
[#text("It is ancient: t ranges over ")#mi("(-\\infty,0)")#text(".")],
[#text("It is a Ricci flow.")],
[#text("M is complete and connected.")],
[#text("The Riemann curvature is non-negative (though it could theoretically be unbounded).")],
[#mi("\\frac{dR}{dt}")#text(" is non-negative.")],
[#text("M is ")#mi("\\kappa")#text("-noncollapsed.")],
[#text("M is not flat.")],
[#text("It obeys the gradient shrinking soliton equation")]
)

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\text{Ric} + \\text{Hess}(f) = \\frac{1}{2\\tau} g")]]

#text("for some smooth f.")

#text("The main result of this lecture is to classify all such solutions in low dimension:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Classification of asymptotic gradient shrinking solitons) Let ")#mi("t \\mapsto (M,g(t))")#text(" be as above, and suppose that the dimension d is at most 3. Then one of the following is true (up to isometry and rescaling):")

#enum(start: 1, 
[#text("d=2,3 and M is a round shrinking spherical space form (i.e. a round shrinking ")#mi("S^2")#text(", ")#mi("S^3")#text(", ")#mi("\\Bbb{RP}^2")#text(", or ")#mi("S^3/\\Gamma")#text(" for some finite group ")#mi("\\Gamma")#text(" acting freely on ")#mi("S^3")#text(").")],
[#text("d=3 and M is the round shrinking cylinder ")#mi("S^2 \\times {\\Bbb R}")#text(" or the oriented or unoriented quotient of this cylinder by an involution.")]
)
]

#text("The case d=2 of this theorem is due to Hamilton; the compact d=3 case is due to Ivey; and the full d=3 case was sketched out by Perelman. In higher dimension, partial results towards the full classification (and also relaxing many of the hypotheses 1-8) have been established ")#link("http://www.math.ucla.edu/%7Ewylie/preprints/ConformalFlat.pdf")[#text("by Petersen-Wylie,")]#text(" ")#link("http://arxiv.org/abs/0710.3194")[#text("by Ni-Wallach")]#text(", and ")#link("http://arxiv.org/abs/0710.5579")[#text("by Naber")]#text("; these papers also give alternate proofs of Perelman’s classification.")

#text("To prove this theorem, we induct on dimension. In 1 dimension, all manifolds are flat and so the claim is trivial. We will thus take d=2 or d=3, and assume that the result has already been established for dimension d-1. We will then split into several cases:")

#enum(start: 1, 
[#text("Case 1: Ricci curvature has a zero eigenvector at some point. In this case we can use Hamilton’s splitting theorem to reduce the dimension by one, at which point we can use the induction hypothesis.")],
[#text("Case 2: Manifold noncompact, and Ricci curvature is positive and unbounded. In this case we can take a further geometric limit (using some Toponogov theory on the asymptotics of rays in a positively curved manifold) which is a round cylinder (or quotient thereof), and also a gradient steady soliton. One can easily rule out such an object by studying the potential function of that soliton on a closed loop.")],
[#text("Case 3: Manifold noncompact, and Ricci curvature is positive and bounded. Here we shall follow the gradient curves of f using some identities arising from the gradient shrinking soliton equation to get a contradiction.")],
[#text("Case 4: Manifold compact, and curvature positive. Here we shall use Hamilton’s rounding theorem to show that one is a round shrinking sphere or spherical space form.")]
)

#text("We will follow ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text("‘s treatment of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s argument")]#text("; see also the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(", the paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=2233789")[#text("Cao-Zhu")]#text(", and the ")#link("http://www.ams.org/mathscinet-getitem?mr=2274812")[#text("book of Chow-Lu-Ni")]#text(" for other treatments of this argument.")

#metadata(none) <tao-43ad97a4826ad148ed5d>

#heading(level: 1)[#text("— Case 1: Ricci curvature degenerates at some point —")]

#text("This case cannot happen in two dimensions. Indeed, since the Ricci curvature is conformal in this case, the only way that the Ricci curvature can degenerate is if the scalar curvature vanishes also. But then the strong maximum principle (Exercise 7 from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") forces the gradient shrinking soliton to be flat at all sufficiently early times (and hence at all times), a contradiction. (It turns out that this application of strong maximum principle can be extended to cover the case in which one does not have bounded curvature.)")

#text("So now suppose that we are in three dimensions with bounded Ricci curvature, and a point where the Ricci curvature vanishes. Then by Hamilton’s splitting theorem (Proposition 1 from ")#link("http://www.ams.org/mathscinet-getitem?mr=2274812")[#text("Lecture 13")]#text(") the gradient shrinking soliton locally splits into the product of a two-dimensional flow and a line (for sufficiently early times, at least), with the Ricci curvature being degenerate along these lines that foliate the flow. (Again, one has to extend the strong maximum principle argument to cover the case of unbounded curvature, but this can be done.) In particular, from (1) we see that ")#mi("\\text{Hess}(f)")#text(" is constant and strictly positive along these lines; in other words, f is strictly convex (and quadratic) along these lines. As a consequence, the lines cannot loop back upon themselves.")

#text("By lifting to a double cover if necessary, we can find a global unit vector field X along these lines, thus ")#mi("\\text{Ric}(X,\\cdot) = 0")#text(" and ")#mi("\\nabla X = 0")#text(". If we set ")#mi("F := \\nabla_X f")#text(", we conclude from (1) that ")#mi("\\nabla F = X / 2\\tau")#text(", thus the level sets of F have X as a unit normal. Thus, at any fixed time, we use F to ")#emph[#text("globally")]#text(" split the manifold M (or a double cover thereof) as the product of a line and a two-dimensional manifold (given by the level sets of F). Applying the induction hypothesis, we conclude that M (or a double cover) is a product of a line and a round shrinking ")#mi("S^2")#text(" or ")#mi("\\Bbb{RP}^2")#text(" (as these are the only two-dimensional spherical space forms), at which point we end up in alternative 2 of Theorem 1. (We initially establish this fact only for sufficiently early times, but then by uniqueness of Ricci flow one obtains it for late times also.)")

#strong[#text("Remark 1.")]#text(" We can also proceed here using the global splitting theorem from Lemma 9.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=862046")[#text("Hamilton’s paper")]#text(". ")#mi("\\Box")

#heading(level: 1)[#text("— Case 2: Manifold non-compact, curvature positive and unbounded —")]

#text("Now we handle the case in which M is non-compact (and in particular has a meaningful notion of convergence to spatial infinity) with Ricci curvature strictly positive and unbounded. In particular one has a sequence of points ")#mi("x_n \\to \\infty")#text(" in M such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("R(x_n) d(x_0,x_n)^2 \\to \\infty")]]

#text("at some time (which we can normalise to t=-1), where we arbitrarily pick an origin ")#mi("x_0 \\in M")#text(". Thus the curvature is not decaying as fast as ")#mi("1/d(x_0,\\cdot)^2")#text(" at infinity, and may even be unbounded. Henceforth we normalise t as t=-1 and write g for g(-1).")

#text("The basic idea here is to look at the rescaled pointed manifolds ")#mi("(M_n, g_n, p_n) := (M, R(x_n)^{1/2} g, x_n)")#text(" and extract a limit in which the original base point ")#mi("x_0")#text(" has now been sent off to infinity (thanks to (2)). There is a technical obstacle to doing this, though, which is that the rescaled manifolds have bounded curvature at ")#mi("x_n")#text(" (indeed, it has been normalised to equal 1) but might have unbounded curvature at nearby points ")#mi("y_n")#text(" with respect to the rescaled metric (i.e. points ")#mi("y_n")#text(" within distance ")#mi("O( R(x_n)^{-1/2} ) = o( d(x_n,x_0) )")#text(" in the original metric) because such points may have significantly higher curvature than ")#mi("x_n")#text(" (e.g. ")#mi("R(y_n) \\geq 4 R(x_n)")#text("). But it is easy to resolve this: simply pick ")#mi("y_n")#text(" instead of ")#mi("x_n")#text(". Now ")#mi("y_n")#text(" may itself be close to another point of even higher curvature, but we can then move that point instead. We can continue in this manner, moving in a geometrically decreasing sequence of distances, until we stop (which we must, since the manifold is smooth and so curvature is locally bounded). The precise result of this “point-picking argument”, originally due to Hamilton, that we will need is as follows:")

#strong[#text("Exercise 1. ")]#text("(Point picking lemma) Assuming that (2) holds for some sequence ")#mi("x_n \\to \\infty")#text(", show that there exists another sequence ")#mi("y_n \\to \\infty")#text(" also obeying (2), and such that for any ")#mi("A > 1")#text(", and for all n sufficiently large depending on A, we have ")#mi("R(z_n) \\leq 4 R(y_n)")#text(" for all ")#mi("z_n \\in B( y_n, A R(y_n)^{-1/2} )")#text(". If the original manifold had unbounded curvature, show that we can also ensure that ")#mi("R(y_n) \\to \\infty")#text(". ")#mi("\\diamond")

#text("We now let ")#mi("y_n")#text(" be as above, and consider the rescaled manifolds ")#mi("(M_n, g_n, p_n) := (M, R(y_n)^{1/2} g, y_n)")#text(". Using Hamilton’s compactness theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(") we may assume that these manifolds converge geometrically to a limit ")#mi("(M_\\infty, g_\\infty, p_\\infty)")#text(" of nonnegative Riemann curvature whose scalar curvature is at most 4 (and is equal to 1 at ")#mi("p_\\infty")#text("); in particular the limit has bounded curvature. From the analogue of (2) for ")#mi("y_n")#text(" we have ")#mi("d_{g_n}( x_0, p_n ) \\to \\infty")#text(", and so ")#mi("x_0")#text(" has “escaped to infinity” in the limit ")#mi("M_\\infty")#text(" (this shows in particular that ")#mi("M_\\infty")#text(" is non-compact).")

#text("Let ")#mi("r_n := d(x_0,y_n)")#text(", thus ")#mi("r_n \\to \\infty")#text(". By refining this sequence we may assume that we have rapid growth in the sense that ")#mi("r_n = o(r_{n+1})")#text(". Let ")#mi("x_0y_n")#text(" be a minimising geodesic from ")#mi("x_0")#text(" to ")#mi("y_n")#text("; by compactness we may assume that the direction of ")#mi("x_0y_n")#text(" at ")#mi("x_0")#text(" is convergent. In particular, the angle subtended between ")#mi("x_0y_n")#text(" and ")#mi("x_0y_{n+1}")#text(" is ")#mi("o(1)")#text(". If we let ")#mi("y_ny_{n+1}")#text(" be a minimising geodesic from ")#mi("y_n")#text(" to ")#mi("y_{n+1}")#text(", we thus see from the triangle inequality and the cosine rule (Lemma 2) that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("d(y_n,y_{n+1}) = r_{n+1} - r_n + o(r_n).")]]

#text("Using the cosine rule again, we see that the angle subtended between ")#mi("x_0y_n")#text(" and ")#mi("y_n y_{n+1}")#text(" is ")#mi("\\pi-o(1)")#text(". Using relative Toponogov comparison (Exercise 3) we see that the rays ")#mi("x_0y_n")#text(" and ")#mi("y_n y_{n+1}")#text(" asymptotically form a minimising geodesic, in the sense that ")#mi("d(z,y_n) + d(y_n,w) = d(z,w) + o(1)")#text(" for any z, w at a bounded distance away from ")#mi("y_n")#text(" on ")#mi("x_0 y_n")#text(" and ")#mi("y_n y_{n+1}")#text(" respectively. From this, we see in the limit ")#mi("(M_\\infty, g_\\infty, p_\\infty)")#text(" that there exists a minimising geodesic line through ")#mi("p_\\infty")#text(". But by the Cheeger-Gromoll splitting theorem (Theorem 2) we see that ")#mi("M_\\infty")#text(" splits into the product of a line and a manifold ")#mi("\\Sigma")#text(" of one dimension less. This cannot happen in the two-dimensional case d=2, since ")#mi("\\Sigma")#text(" becomes one-dimensional and thus flat, and ")#mi("M_\\infty")#text(" has non-zero curvature at ")#mi("p_\\infty")#text(" (indeed, its scalar curvature is equal to 1). So we can now assume d=3.")

#text("We have only taken limits at time t=-1. But we can use Hamilton’s compactness theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(") again (using the property ")#mi("\\partial_t R \\geq 0")#text(") and extend ")#mi("M_\\infty")#text(" to a Ricci flow backwards in time from t=-1; this is a limit of rescaled versions of ")#mi("(M, g, y_n)")#text(" by ")#mi("R(y_n)^{1/2}")#text(". Since M was originally a gradient shrinking soliton, and ")#mi("R(y_n)")#text(" is going to infinity, the limit ")#mi("(M_\\infty,g_\\infty,p_\\infty)")#text(" can be shown to be a gradient steady soliton: ")#mi("\\text{Ric}_\\infty + \\text{Hess}(f_\\infty) = 0")#text(" for some ")#mi("f_\\infty")#text(".")

#text("Since ")#mi("M_\\infty")#text(" had bounded curvature at time t=-1, it had bounded curvature for all previous times also. Since the Ricci curvature is vanishing along one direction, we can now apply the Case 1 argument and show that ")#mi("M_\\infty")#text(" is the product of a line and a round shrinking ")#mi("S^2")#text(" or ")#mi("\\Bbb{RP}^2")#text(". In particular, ")#mi("M_\\infty")#text(" contains closed geodesic loops ")#mi("\\gamma")#text(" on which the Ricci curvature ")#mi("\\text{Ric}(X,X)")#text(" is strictly positive. From the gradient steady equation, this means that ")#mi("f_\\infty")#text(" is strictly concave on this loop, which is absurd. Thus this situation does not occur.")

#strong[#text("Remark 2.")]#text(" In ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(", the contradiction was obtained using the ")#link("http://en.wikipedia.org/wiki/Soul_theorem")[#text("soul theorem")]#text(", and a rather non-trivial result asserting that complete manifolds of non-negative sectional curvature cannot contain arbitrarily small necks, but the above argument seems to be somewhat shorter. An even simpler argument (avoiding the use of the splitting theorem altogether) was given ")#link("http://arxiv.org/abs/0710.5579")[#text("by Naber")]#text(", based on the observation (from (1)) that the normalised gradient vector field ")#tao-math("\\nabla f / \\left|\\nabla f\\right|", block: false)#text(" of the potential function becomes increasingly parallel to the connection if ")#tao-math("\\left|\\nabla f\\right|", block: false)#text(" goes to infinity. We thank Peter Petersen for pointing out Naber’s argument to us. ")#mi("\\diamond")

#heading(level: 1)[#text("— Case 3: M noncompact, curvature positive and bounded —")]

#text("Now we assume that M is compact, with Ricci curvature strictly positive but also bounded. By Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/05/27/285g-lecture-15-geometric-limits-of-ricci-flows-and-asymptotic-gradient-shrinking-solitons/")[#text("Lecture 15")]#text(", we conclude in particular that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_\\gamma \\text{Ric}(X,X)\\ ds \\leq C")]]

#text("for some C and all minimising geodesics (thus the Ricci curvature must decay along long geodesics). On the other hand, along such a geodesic, we see from (1) that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{d^2}{ds^2} f(\\gamma(s)) = \\frac{1}{2} - \\text{Ric}(X,X).")]]

#text("From (4) and (5) we see that ")#mi("\\nabla_X f(\\gamma(s))")#text(" increases like ")#mi("s/2")#text(" as ")#mi("s \\to \\infty")#text(". Similarly, if E is any vector field orthogonal to X and transported by parallel transport along ")#mi("\\gamma")#text(", an application of Cauchy-Schwarz, (4), and the bounded curvature hypothesis gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\int_\\gamma \\text{Ric}(X,E)\\right|\\ ds \\leq C^{\\prime} \\left|\\gamma\\right|^{1/2}", block: true)]]

#text("while (1) gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{d}{ds} \\nabla_E f(\\gamma s)) = - \\text{Ric}(X,E)")]]

#text("and so ")#mi("\\nabla_E f(\\gamma(s))")#text(" grows like at most ")#mi("O(s^{1/2})")#text(" as ")#mi("s \\to \\infty")#text(". These bounds ensure that f goes to ")#mi("+\\infty")#text(" at infinity (in particular, it is ")#link("http://en.wikipedia.org/wiki/Proper_function")[#text("proper")]#text("), and that there exist curves following the gradient ")#mi("\\nabla f")#text(" of f which go to infinity.")

#text("On the other hand, using the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\nabla_\\alpha R = 2 \\text{Ric}_{\\alpha \\beta} \\nabla^\\beta f")]]

#text("(see (27) from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") we see that ")#mi("\\nabla_{\\nabla f} R > 0")#text(", thus R is increasing along gradient flow curves. In particular, ")#mi("R(\\infty) := \\limsup_{x \\to \\infty} R(x)")#text(" is strictly positive (and finite, since curvature is bounded).")

#text("As a consequence, we can repeat the point-picking arguments from Case 2 and extract a sequence of points ")#mi("y_n \\to \\infty")#text(" for which ")#mi("(M, g, x_n)")#text(" converges geometrically to a limit ")#mi("(M_\\infty,g_\\infty,p_\\infty)")#text(", which has scalar curvature ")#mi("R(\\infty)")#text(" at ")#mi("p_\\infty")#text(". Since M is a gradient shrinking soliton on ")#mi("(-\\infty,0)")#text(", one can show that ")#mi("M_\\infty")#text(" is also. By repeating the Case 2 analysis one can show that ")#mi("M_\\infty")#text(" is also a round shrinking ")#mi("{\\Bbb R} \\times S^2")#text(" or ")#mi("{\\Bbb R} \\times \\Bbb{RP}^2")#text(". Since these solitons have scalar curvature 1 at time -1, we thus have ")#mi("R(\\infty)=1")#text(".")

#text("For sake of argument let us take M to be the round shrinking cylinder ")#mi("{\\Bbb R} \\times S^2")#text("; the other case is similar but with all areas divided by a factor of two. (One can also eliminate this case by appealing to the ")#link("http://en.wikipedia.org/wiki/Soul_theorem")[#text("soul theorem")]#text(", or by adding an additional hypothesis throughout the argument that the manifolds being studied do not contain embedded ")#mi("\\Bbb{RP}^2")#text("‘s with trivial normal bundle.)")

#text("Now we return to the original gradient shrinking soliton M. Since R is strictly increasing along gradient flow curves, we conclude that ")#mi("R < 1")#text(" near infinity. Since M has non-negative Riemann curvature, this implies ")#mi("\\text{Ric} < \\frac{1}{2} g")#text(" near infinity. From (1) this implies that f is strictly convex (i.e. ")#mi("\\text{Hess}(f) > 0")#text(") near infinity. Thus the level sets of f have increasing area. On the other hand, on any region of M that approaches ")#mi("M_\\infty")#text(" (e.g. in the neighbourhoods of ")#mi("y_n")#text(") one easily sees (e.g. from (1), or from the analysis from Case 2) that the level sets of f converge to the sections ")#mi("S^2")#text(" of the cylinder, which have area ")#mi("8\\pi")#text(" (note we are normalising the scalar curvature here to be 1, rather than the sectional curvature, which is 1/2). Thus the level sets ")#mi("\\Sigma")#text(" of f have area strictly less than ")#mi("8\\pi")#text(".")

#text("On the other hand, from the Gauss-Codazzi formula (equation (4) from Lecture 4), the Gaussian curvature K of ")#mi("\\Sigma")#text(" is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("K = K_M + \\det(\\Pi)")]]

#text("where ")#mi("K_M")#text(" is the sectional curvature of ")#mi("\\Sigma")#text(", and ")#tao-math("\\Pi = \\frac{\\text{Hess}(f)|_\\Sigma }{\\left|\\nabla f\\right|}", block: false)#text(" is the second fundamental form. Applying (1) we eventually compute")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("2K \\leq R - 2\\text{Ric}(n,n) - \\frac{(1-R+\\text{Ric}(n,n))^2}{2\\left|\\nabla f\\right|^2}.", block: true)]]

#text("Following the gradient flow lines of f, we see from previous analysis that ")#tao-math("\\left|\\nabla f\\right|", block: false)#text(" goes to infinity (while curvature stays bounded and strictly positive), and so it is not hard to see that the right-hand side must be strictly less than 1 near infinity. But this means that ")#mi("\\int_\\Sigma K < 4\\pi")#text(", contradicting the ")#link("http://en.wikipedia.org/wiki/Gauss%E2%80%93Bonnet_theorem")[#text("Gauss-Bonnet formula")]#text(" (Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("Lecture 4")]#text("). Thus Case 3 cannot in fact occur.")

#heading(level: 1)[#text("— Case 4: M compact, strictly positive curvature —")]

#text("Let us first deal with the two-dimensional case. Here one could use ")#link("http://www.ams.org/mathscinet-getitem?mr=954419")[#text("Hamilton’s results on Ricci flow for surfaces")]#text(" to show that this gradient shrinking soliton must be a round shrinking ")#mi("S^2")#text(" or ")#mi("\\Bbb{RP}^2")#text(", but we give here an argument adapted from the book of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061425")[#text("Chow and Knopf")]#text(". It relies on the following identity, that provides an additional global constraint on the curvature R beyond that provided by the ")#link("http://en.wikipedia.org/wiki/Gauss%E2%80%93Bonnet_theorem")[#text("Gauss-Bonnet theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" (")#link("http://www.ams.org/mathscinet-getitem?mr=343205")[#text("Kazhdan-Warner")]#text(" type identity) Let (M,g) be a compact surface, and let X be a conformal ")#link("http://en.wikipedia.org/wiki/Killing_vector_field")[#text("Killing vector field")]#text(" (thus ")#mi("{\\mathcal L}_X g")#text(" is a scalar multiple of g). Then ")#mi("\\int_M R \\text{div} X\\ d\\mu = 0")#text(".")
]

#strong[#text("Proof.")]#text(" When M has constant curvature, the claim is clear by integration by parts. On the other hand, by the ")#link("http://en.wikipedia.org/wiki/Uniformization_theorem")[#text("uniformization theorem")]#text(", any metric g can be conformally deformed to a constant curvature metric. Note also from definition that a conformal Killing vector field remains conformal after any conformal change of metric. Thus it suffices to show that ")#mi("\\int_M R \\text{div} X\\ d\\mu")#text(" is constant under any conformal change ")#mi("\\dot g = u g")#text(" of g, keeping X static.")

#text("From the variation formulae from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(", we have ")#mi("\\dot R = -Ru-\\Delta u")#text(" and ")#mi("\\dot{d\\mu} = u\\ d\\mu")#text(". Inserting these formulae and integrating by parts to isolate u, we see that it suffices to show that ")#mi("\\nabla_\\alpha(X^\\alpha R) + \\Delta(\\nabla_\\alpha X^\\alpha) = 0")#text(". On the other hand, since ")#mi("{\\mathcal L}_X  g_{\\alpha\\beta}= \\nabla_\\alpha X_\\beta + \\nabla_\\beta X_\\alpha")#text(" is conformal, we have the identity ")#mi("\\nabla_\\alpha X_\\beta + \\nabla_\\beta X_\\alpha = (\\nabla^\\gamma X_\\gamma) g_{\\alpha \\beta}")#text(". Taking divergences of this identity twice and rearranging derivatives repeatedly, we eventually obtain this claim. ")#mi("\\Box")

#text("[")#emph[#text("Aside")]#text(": I do not know of any proof of the Kazhdan-Warner identity that does not require the uniformisation theorem; the result seems to have an irreducibly “global” nature to it.]")

#text("Now we apply this lemma to the vector field ")#mi("\\nabla f")#text(", which is conformal thanks to (1). We conclude that ")#mi("\\int_M R \\Delta f\\ d\\mu = 0")#text(". On the other hand, from the trace of (1) we have ")#mi("R - 1/\\tau = \\Delta f")#text(". Integrating this against ")#mi("\\Delta f")#text(" we conclude that ")#tao-math("\\int_M \\left|\\Delta f\\right|^2\\ d\\mu = 0", block: false)#text(", thus f is harmonic; and so ")#mi("R = 1/\\tau")#text(". M is now constant curvature and is therefore either a round shrinking ")#mi("S^2")#text(" or ")#mi("\\Bbb{RP}^2")#text(" as required.")

#text("Now we turn to three dimensions. The result in this case follows immediately from ")#link("http://www.ams.org/mathscinet-getitem?mr=664497")[#text("Hamilton’s rounding theorem")]#text(", but we will take advantage of the gradient shrinking soliton structure to extract just the key components of that theorem here. Let ")#mi("\\lambda \\geq \\mu \\geq \\nu \\geq 0")#text(" denote the eigenvalues of the Riemann curvature. Note that as the Ricci curvature is positive, ")#mi("\\mu+\\nu")#text(" is strictly greater than zero.")

#text("The quantity ")#mi("(\\mu+\\nu)/\\lambda")#text(" ranges between 0 and 2 and reaches a minimum value ")#mi("\\delta")#text(" at some point x. If we rewrite things in terms of the tensor ")#mi("{\\mathcal T}")#text(" from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(", the gradient shrinking soliton structure means that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{1}{\\tau} {\\mathcal T} = \\Delta {\\mathcal T} + {\\mathcal L}_{\\nabla f} {\\mathcal T} + {\\mathcal T}^2 + {\\mathcal T}^\\#")]]

#text("But the region ")#mi("\\{ {\\mathcal T}: \\nu \\geq 0; \\mu + \\nu \\geq \\delta \\lambda \\}")#text(" is fibrewise convex and parallel, and at x, ")#mi("\\frac{1}{\\tau} {\\mathcal T}")#text(" and ")#mi("{\\mathcal L}_{\\nabla f} {\\mathcal T}")#text(" are tangential to this region and ")#mi("\\Delta {\\mathcal T}")#text(" is tangential or inward. On the other hand, a computation shows that ")#mi("{\\mathcal T}^2 + {\\mathcal T}^\\#")#text(" is strictly inward unless ")#mi("\\delta=2")#text(", in which case it is tangential. So we must have ")#mi("\\delta=2")#text(", which implies that ")#mi("\\lambda=\\mu=\\nu")#text(". In other words, the Ricci tensor is conformal: ")#mi("\\text{Ric} = \\frac{1}{3} R g")#text(". Comparing this with the ")#link("http://en.wikipedia.org/wiki/Bianchi_identity#Bianchi_identities")[#text("Bianchi identity")]#text(" ")#mi("\\nabla_\\alpha R =  2 \\nabla^\\beta \\text{Ric}_{\\alpha \\beta}")#text(" (equation (28) from ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("Lecture 0")]#text(") we conclude that ")#mi("\\nabla R = 0")#text(", and thus ")#mi("\\nabla \\text{Ric}=0")#text(". Thus M has constant sectional curvature and is therefore a round shrinking spherical space form, as required.")

#heading(level: 1)[#text("— Appendix: Toponogov theory —")]

#text("Roughly speaking, ")#link("http://www.ams.org/mathscinet-getitem?mr=103510")[#text("Toponogov")]#text(" comparison theory is to triangle geometry as Bishop-Gromov theory is to volumes of balls: in both cases, lower bounds on curvature are used to bound the geometry of Riemannian manifolds by model geometries such as Euclidean space. This theory links modern Riemannian geometry with the more classical approach to curved space (or non-Euclidean geometries) which often proceeded via analysing the angles formed by a triangle. The material here is loosely drawn from ")#link("http://www.ams.org/mathscinet-getitem?mr=1480173")[#text("Petersen’s book")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2. ")]#text("(Toponogov cosine rule) Let ")#mi("(M,g)")#text(" be a complete Riemannian manifold of non-negative sectional curvature, and let ")#mi("x_0, x_1, x_2")#text(" be three distinct points in M. Let ")#mi("\\theta")#text(" be the angle formed at ")#mi("x_1")#text(" by the minimising geodesics from ")#mi("x_0, x_2")#text(" to ")#mi("x_1")#text(". Then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12).")])
#mitex("d(x_2, x_0)^2 \\leq d(x_1,x_0)^2 + d(x_2,x_1)^2 - 2 d(x_1,x_0) d(x_2,x_1) \\cos \\theta")]]
]

#text("Of course, when M is flat we have equality in (12), by the classical ")#link("http://en.wikipedia.org/wiki/Law_of_cosines")[#text("cosine rule")]#text(".")

#strong[#text("Proof.")]#text(" Let f be the function ")#mi("f(x) := \\frac{1}{2} d(x,x_0)^2")#text(", and let ")#mi("\\gamma: [0, d(x_2,x_1)] \\to M")#text(" be the unit speed geodesic from ")#mi("x_1")#text(" to ")#mi("x_2")#text(". Our task is to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("f(\\gamma(t)) \\leq f(\\gamma(0)) + \\frac{1}{2} t^2 - t d(x_1,x_0) \\cos \\theta")]]

#text("for t = d(x_2,x_1). From the Gauss lemma we know that ")#mi("\\frac{d}{dt} f(\\gamma(t))|_{t=0} \\leq - d(x_1,x_0) \\cos \\theta")#text(". On the other hand, from the second variation formula for distance (or more precisely, equation (21) of ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(") and the non-negative sectional curvature assumption we have ")#mi("\\frac{d^2}{dt^2} f(\\gamma(t)) \\leq 1")#text(". (Actually one has to justify this in a suitable barrier sense when one is in the cut locus, but let us ignore this issue here for simplicity.) The claim follows. ")#mi("\\Box")

#text("There is an appealing reformulation of this lemma. Define a ")#emph[#text("triangle")]#text(" to be three points A, B, C connected by three minimising geodesics AB, BC, CA.")

#strong[#text("Exercise 2. ")]#text(" (Positive curvature increases angles) Let ABC be a triangle in a Riemannian manifold of non-negative sectional curvature, and let A’B’C’ be a triangle in Euclidean space with the same side lengths as ABC. Show that the angle subtended at A is larger than or equal to that subtended at A’ (and similarly of course for B and B’, and C and C’). In particular, the sum of the angles of ABC is at least ")#mi("\\pi")#text(". ")#mi("\\diamond")

#text("There is also a relative version of this result:")

#strong[#text("Exercise 3. ")]#text(" (Relative Toponogov comparison) Let the notation and assumptions be as in the previous exercise. Let X, Y be points on AB, AC respectively, and let X’, Y’ be the corresponding points on A’B’ and A’C’. Show that the length of XY is greater than or equal to the length of X’Y’. (Hint: it suffices to do this in the case X=B (or Y=C), since the general case follows by two applications of this special case. Now repeat the argument used to prove Lemma 2.) ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" Similar statements hold when one assumes that the sectional curvatures are bounded below by some number K other than zero. In this case, one replaces Euclidean space with the model geometry of constant curvature K, much as in the discussion of the Bishop-Gromov inequality in ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("Lecture 9")]#text(". See ")#link("http://www.ams.org/mathscinet-getitem?mr=1480173")[#text("Petersen’s book")]#text(" for details. ")#mi("\\diamond")

#heading(level: 1)[#text("— The Cheeger-Gromoll splitting theorem —")]

#text("When a manifold has positive curvature, it is difficult for long geodesics to be minimising; see for example ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers’ theorem")]#text(" for one instance of this phenomenon.")#linebreak()#text(" Another important example of this is the ")#link("http://www.ams.org/mathscinet-getitem?mr=303460")[#text("Cheeger-Gromoll splitting theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" (splitting theorem). Let ")#mi("(M,g)")#text(" be a complete Riemannian manifold of nonnegative Ricci curvature that contains a minimising geodesic line ")#mi("\\gamma: {\\Bbb R} \\to M")#text(". Then M splits as the product of ")#mi("{\\Bbb R}")#text(" with a manifold of one lower dimension.")
]

#strong[#text("Remark 4.")]#text(" If one strengthens the non-negative Ricci curvature assumption to non-negative sectional curvature, this is a result ")#link("http://www.ams.org/mathscinet-getitem?mr=185551")[#text("of Toponogov")]#text("; if one strengthens further to have a uniform positive lower bound on sectional curvature, then this follows from ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers’ theorem")]#text(". ")#mi("\\diamond")

#strong[#text("Proof. ")]#text(" We can parameterise ")#mi("\\gamma")#text(" to be unit speed. Consider the ")#emph[#text("Busemann functions")]#text(" ")#mi("B_+, B_-: M \\to {\\Bbb R}")#text(" defined by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("B_\\pm(x) := \\lim_{t \\to \\pm \\infty} d( \\gamma(t), x ) - t.")]]

#text("One can show that the limits exist (because, by the triangle inequality, the expressions in the limits are bounded and monotone), and that ")#mi("B_+, B_-")#text(" are both Lipschitz. From the non-negative curvature we have the upper bound ")#mi("\\text{Hess}(r)(v,v) \\leq 1/r")#text(" for any distance function ")#mi("r = d(x,x_0)")#text(" (see e.g. equation (21) from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text("); applying this with ")#mi("x_0 = \\gamma(t)")#text(" and letting ")#mi("t \\to \\pm \\infty")#text(" we obtain the concavity ")#mi("\\text{Hess}(B_\\pm) \\leq 0")#text(". In particular, ")#mi("B_+ + B_-")#text(" is concave. On the other hand, from the triangle inequality we see that ")#mi("B_+ + B_-")#text(" is non-negative and vanishes on ")#mi("\\gamma")#text(". Applying the (elliptic) strong maximum principle (which can be viewed as the static case of the parabolic strong maximum principle, Exercise 5 from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(", though in the static case the bounded curvature hypothesis is not needed) we conclude that ")#mi("B_+ + B_-")#text(" vanishes identically. Since ")#mi("B_+")#text(" and ")#mi("B_-")#text(" were both concave, they now must flat in the sense that ")#mi("\\text{Hess}(B_+) = \\text{Hess}(B_-) = 0")#text(". In particular they are smooth, and the gradient vector field ")#mi("X := \\nabla B_+")#text(" is parallel to the Levi-Civita connection. On the other hand, by applying the ")#link("http://en.wikipedia.org/wiki/Gauss%27s_lemma_%28Riemannian_geometry%29")[#text("Gauss lemma")]#text(" carefully we see that X is a unit vector field. Thus X splits M into a line and the level sets of ")#mi("B_+")#text(" (cf. Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("Lecture 13")]#text(") as desired. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/#comment-30175")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] Having classified all asymptotic gradient shrinking solitons in three and fewer dimensions in the previous lecture, we now use this classification, combined with extensive use of compactness and contradiction […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noether’s theorem, and the conservation laws for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2008/05/30/285g-lecture-16-classification-of-asymptotic-gradient-shrinking-solitons/#comment-273681")[#strong[#text("Noether’s theorem, and the conservation laws for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")])]

#text("[…] non-trivial” integral identities of a topological nature, such as the Gauss-Bonnet or Kazhdan-Warner identities, but is quite reliable for “local” or “cohomologically trivial” identities, […]")
]
