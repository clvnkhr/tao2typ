// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/
// Converted to Typst by tao2typ: "2026-10-14T09:37:00.914540+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Metric entropy analogues of sum set theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Metric entropy analogues of sum set theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 March 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/")[#text("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A core foundation of the subject now known as ")#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#text("arithmetic combinatorics")]#text(" (and particularly the subfield of ")#emph[#text("additive combinatorics")]#text(") are the elementary sum set estimates (sometimes known as “Ruzsa calculus”) that relate the cardinality of various sum sets")

#align(center)[#tao-fit-display[#mitex("A+B := \\{ a+b: a \\in A, b \\in B \\}")]]

#text("and difference sets")

#align(center)[#tao-fit-display[#mitex("A-B := \\{ a-b: a \\in A, b \\in B \\},")]]

#text("as well as iterated sumsets such as ")#mi("{3A=A+A+A}")#text(", ")#mi("{2A-2A=A+A-A-A}")#text(", and so forth. Here, ")#mi("{A, B}")#text(" are finite non-empty subsets of some additive group ")#mi("{G = (G,+)}")#text(" (classically one took ")#mi("{G={\\bf Z}}")#text(" or ")#mi("{G={\\bf R}}")#text(", but nowadays one usually considers more general additive groups). Some basic estimates in this vein are the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Ruzsa covering lemma)")]#text(" Let ")#mi("{A, B}")#text(" be finite non-empty subsets of ")#mi("{G}")#text(". Then ")#mi("{A}")#text(" may be covered by at most ")#tao-math("{\\frac{\\left|A+B\\right|}{\\left|B\\right|}}", block: false)#text(" translates of ")#mi("{B-B}")#text(".")
]

#emph[#text("Proof:")]#text(" Consider a maximal set of disjoint translates ")#mi("{a+B}")#text(" of ")#mi("{B}")#text(" by elements ")#mi("{a \\in A}")#text(". These translates have cardinality ")#tao-math("{\\left|B\\right|}", block: false)#text(", are disjoint, and lie in ")#mi("{A+B}")#text(", so there are at most ")#tao-math("{\\frac{\\left|A+B\\right|}{\\left|B\\right|}}", block: false)#text(" of them. By maximality, for any ")#mi("{a^{\\prime} \\in A}")#text(", ")#mi("{a^{\\prime}+B}")#text(" must intersect at least one of the selected ")#mi("{a+B}")#text(", thus ")#mi("{a^{\\prime} \\in a+B-B}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Ruzsa triangle inequality)")]#text(" Let ")#mi("{A,B,C}")#text(" be finite non-empty subsets of ")#mi("{G}")#text(". Then ")#tao-math("{\\left|A-C\\right| \\leq \\frac{\\left|A-B\\right| \\left|B-C\\right|}{\\left|B\\right|}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Consider the addition map ")#mi("{+: (x,y) \\mapsto x+y}")#text(" from ")#mi("{(A-B) \\times (B-C)}")#text(" to ")#mi("{G}")#text(". Every element ")#mi("{a-c}")#text(" of ")#mi("{A - C}")#text(" has a preimage ")#mi("{\\{ (x,y) \\in (A-B) \\times (B-C)\\}}")#text(" of this map of cardinality at least ")#tao-math("{\\left|B\\right|}", block: false)#text(", thanks to the obvious identity ")#mi("{a-c = (a-b) + (b-c)}")#text(" for each ")#mi("{b \\in B}")#text(". Since ")#mi("{(A-B) \\times (B-C)}")#text(" has cardinality ")#tao-math("{\\left|A-B\\right| \\left|B-C\\right|}", block: false)#text(", the claim follows. ")#mi("\\Box")

#text("Such estimates (which are covered, incidentally, in Section 2 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(") are particularly useful for controlling finite sets ")#mi("{A}")#text(" of small doubling, in the sense that ")#tao-math("{\\left|A+A\\right| \\leq K\\left|A\\right|}", block: false)#text(" for some bounded ")#mi("{K}")#text(". (There are deeper theorems, most notably ")#link("http://en.wikipedia.org/wiki/Freiman's_theorem")[#text("Freiman’s theorem")]#text(", which give more control than what elementary Ruzsa calculus does, however the known bounds in the latter theorem are worse than polynomial in ")#mi("{K}")#text(" (although it is ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("conjectured otherwise")]#text("), whereas the elementary estimates are almost all polynomial in ")#mi("{K}")#text(".)")

#text("However, there are some settings in which the standard sum set estimates are not quite applicable. One such setting is the continuous setting, where one is dealing with bounded open sets in an additive Lie group (e.g. ")#mi("{{\\bf R}^n}")#text(" or a torus ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(") rather than a finite setting. Here, one can largely replicate the discrete sum set estimates by working with a Haar measure in place of cardinality; this is the approach taken for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=2501249")[#text("this paper of mine")]#text(". However, there is another setting, which one might dub the “discretised” setting (as opposed to the “discrete” setting or “continuous” setting), in which the sets ")#mi("{A}")#text(" remain finite (or at least discretisable to be finite), but for which there is a certain amount of “roundoff error” coming from the discretisation. As a typical example (working now in a non-commutative multiplicative setting rather than an additive one), consider the orthogonal group ")#mi("{O_n({\\bf R})}")#text(" of orthogonal ")#mi("{n \\times n}")#text(" matrices, and let ")#mi("{A}")#text(" be the matrices obtained by starting with all of the orthogonal matrice in ")#mi("{O_n({\\bf R})}")#text(" and rounding each coefficient of each matrix in this set to the nearest multiple of ")#mi("{\\epsilon}")#text(", for some small ")#mi("{\\epsilon>0}")#text(". This forms a finite set (whose cardinality grows as ")#mi("{\\epsilon\\rightarrow 0}")#text(" like a certain negative power of ")#mi("{\\epsilon}")#text("). In the limit ")#mi("{\\epsilon \\rightarrow 0}")#text(", the set ")#mi("{A}")#text(" is not a set of small doubling in the discrete sense. However, ")#mi("{A \\cdot A}")#text(" is still close to ")#mi("{A}")#text(" in a metric sense, being contained in the ")#mi("{O_n(\\epsilon)}")#text("-neighbourhood of ")#mi("{A}")#text(". Another key example comes from graphs ")#mi("{\\Gamma := \\{ (x, f(x)): x \\in G \\}}")#text(" of maps ")#mi("{f: A \\rightarrow H}")#text(" from a subset ")#mi("{A}")#text(" of one additive group ")#mi("{G = (G,+)}")#text(" to another ")#mi("{H = (H,+)}")#text(". If ")#mi("{f}")#text(" is “approximately additive” in the sense that for all ")#mi("{x,y \\in G}")#text(", ")#mi("{f(x+y)}")#text(" is close to ")#mi("{f(x)+f(y)}")#text(" in some metric, then ")#mi("{\\Gamma}")#text(" might not have small doubling in the discrete sense (because ")#mi("{f(x+y)-f(x)-f(y)}")#text(" could take a large number of values), but could be considered a set of small doubling in a discretised sense.")

#text("One would like to have a sum set (or product set) theory that can handle these cases, particularly in “high-dimensional” settings in which the standard methods of passing back and forth between continuous, discrete, or discretised settings behave poorly from a quantitative point of view due to the exponentially large doubling constant of balls. One way to do this is to impose a translation invariant metric ")#mi("{d}")#text(" on the underlying group ")#mi("{G = (G,+)}")#text(" (reverting back to additive notation), and replace the notion of cardinality by that of metric entropy. There are a number of almost equivalent ways to define this concept:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3")]#text(" Let ")#mi("{(X,d)}")#text(" be a metric space, let ")#mi("{E}")#text(" be a subset of ")#mi("{X}")#text(", and let ")#mi("{r>0}")#text(" be a radius.")

#list(
[#text("The ")#emph[#text("packing number")]#text(" ")#mi("{N^{pack}_r(E)}")#text(" is the largest number of points ")#mi("{x_1,\\dots,x_n}")#text(" one can pack inside ")#mi("{E}")#text(" such that the balls ")#mi("{B(x_1,r),\\dots,B(x_n,r)}")#text(" are disjoint.")],
[#text("The ")#emph[#text("internal covering number")]#text(" ")#mi("{N^{int}_r(E)}")#text(" is the fewest number of points ")#mi("{x_1,\\dots,x_n \\in E}")#text(" such that the balls ")#mi("{B(x_1,r),\\dots,B(x_n,r)}")#text(" cover ")#mi("{E}")#text(".")],
[#text("The ")#emph[#text("external covering number")]#text(" ")#mi("{N^{ext}_r(E)}")#text(" is the fewest number of points ")#mi("{x_1,\\dots,x_n \\in X}")#text(" such that the balls ")#mi("{B(x_1,r),\\dots,B(x_n,r)}")#text(" cover ")#mi("{E}")#text(".")],
[#text("The ")#emph[#text("metric entropy")]#text(" ")#mi("{N^{ent}_r(E)}")#text(" is the largest number of points ")#mi("{x_1,\\dots,x_n}")#text(" one can find in ")#mi("{E}")#text(" that are ")#mi("{r}")#text("-separated, thus ")#mi("{d(x_i,x_j) \\geq r}")#text(" for all ")#mi("{i \\neq j}")#text(".")]
)
]

#text("It is an easy exercise to verify the inequalities")

#align(center)[#tao-fit-display[#mitex("N^{ent}_{2r}(E) \\leq N^{pack}_r(E) \\leq N^{ext}_r(E) \\leq N^{int}_r(E) \\leq N^{ent}_r(E)")]]

#text("for any ")#mi("{r>0}")#text(", and that ")#mi("{N^*_r(E)}")#text(" is non-increasing in ")#mi("{r}")#text(" and non-decreasing in ")#mi("{E}")#text(" for the three choices ")#mi("{* = pack,ext,ent}")#text(" (but monotonicity in ")#mi("{E}")#text(" can fail for ")#mi("{*=int}")#text("!). It turns out that the external covering number ")#mi("{N^{ent}_r(E)}")#text(" is slightly more convenient than the other notions of metric entropy, so we will abbreviate ")#mi("{N_r(E) = N^{ent}_r(E)}")#text(". The cardinality ")#tao-math("{\\left|E\\right|}", block: false)#text(" can be viewed as the limit of the entropies ")#mi("{N^*_r(E)}")#text(" as ")#mi("{r \\rightarrow 0}")#text(".")

#text("If we have the bounded doubling property that ")#mi("{B(0,2r)}")#text(" is covered by ")#mi("{O(1)}")#text(" translates of ")#mi("{B(0,r)}")#text(" for each ")#mi("{r>0}")#text(", and one has a Haar measure ")#mi("{m}")#text(" on ")#mi("{G}")#text(" which assigns a positive finite mass to each ball, then any of the above entropies ")#mi("{N^*_r(E)}")#text(" is comparable to ")#mi("{m( E + B(0,r) ) / m(B(0,r))}")#text(", as can be seen by simple volume packing arguments. Thus in the bounded doubling setting one can usually use the measure-theoretic sum set theory to derive entropy-theoretic sumset bounds (see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2501249")[#text("this paper of mine")]#text(" for an example of this). However, it turns out that even in the absence of bounded doubling, one still has an entropy analogue of most of the elementary sum set theory, except that one has to accept some degradation in the radius parameter ")#mi("{r}")#text(" by some absolute constant. Such losses can be acceptable in applications in which the underlying sets ")#mi("{A}")#text(" are largely “transverse” to the balls ")#mi("{B(0,r)}")#text(", so that the ")#mi("{N_r}")#text("-entropy of ")#mi("{A}")#text(" is largely independent of ")#mi("{A}")#text("; this is a situation which arises in particular in the case of graphs ")#mi("{\\Gamma = \\{ (x,f(x)): x \\in G \\}}")#text(" discussed above, if one works with “vertical” metrics whose balls extend primarily in the vertical direction. (I hope to present a specific application of this type here in the near future.)")

#text("Henceforth we work in an additive group ")#mi("{G}")#text(" equipped with a translation-invariant metric ")#mi("{d}")#text(". (One can also generalise things slightly by allowing the metric to attain the values ")#mi("{0}")#text(" or ")#mi("{+\\infty}")#text(", without changing much of the analysis below.) By the Heine-Borel theorem, any precompact set ")#mi("{E}")#text(" will have finite entropy ")#mi("{N_r(E)}")#text(" for any ")#mi("{r>0}")#text(". We now have analogues of the two basic Ruzsa lemmas above:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Ruzsa covering lemma)")]#text(" ")#metadata(none) <tao-965c2d9c5200c50411f5>#text(" Let ")#mi("{A, B}")#text(" be precompact non-empty subsets of ")#mi("{G}")#text(", and let ")#mi("{r>0}")#text(". Then ")#mi("{A}")#text(" may be covered by at most ")#mi("{\\frac{N_r(A+B)}{N_r(B)}}")#text(" translates of ")#mi("{B-B+B(0,2r)}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{a_1,\\dots,a_n \\in A}")#text(" be a maximal set of points such that the sets ")#mi("{a_i + B + B(0,r)}")#text(" are all disjoint. Then the sets ")#mi("{a_i+B}")#text(" are disjoint in ")#mi("{A+B}")#text(" and have entropy ")#mi("{N_r(a_i+B)=N_r(B)}")#text(", and furthermore any ball of radius ")#mi("{r}")#text(" can intersect at most one of the ")#mi("{a_i+B}")#text(". We conclude that ")#mi("{N_r(A+B) \\geq n N_r(B)}")#text(", so ")#mi("{n \\leq \\frac{N_r(A+B)}{N_r(B)}}")#text(". If ")#mi("{a \\in A}")#text(", then ")#mi("{a+B+B(0,r)}")#text(" must intersect one of the ")#mi("{a_i + B + B(0,r)}")#text(", so ")#mi("{a \\in a_i + B-B + B(0,2r)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Ruzsa triangle inequality)")]#text(" ")#metadata(none) <tao-b10827da3d072f4fbbfe>#text(" Let ")#mi("{A,B,C}")#text(" be precompact non-empty subsets of ")#mi("{G}")#text(", and let ")#mi("{r>0}")#text(". Then ")#mi("{N_{4r}(A-C) \\leq \\frac{N_r(A-B) N_r(B-C)}{N_r(B)}}")#text(".")
]

#emph[#text("Proof:")]#text(" Consider the addition map ")#mi("{+: (x,y) \\mapsto x+y}")#text(" from ")#mi("{(A-B) \\times (B-C)}")#text(" to ")#mi("{G}")#text(". The domain ")#mi("{(A-B) \\times (B-C)}")#text(" may be covered by ")#mi("{N_r(A-B) N_r(B-C)}")#text(" product balls ")#mi("{B(x,r) \\times B(y,r)}")#text(". Every element ")#mi("{a-c}")#text(" of ")#mi("{A - C}")#text(" has a preimage ")#mi("{\\{ (x,y) \\in (A-B) \\times (B-C)\\}}")#text(" of this map which projects to a translate of ")#mi("{B}")#text(", and thus must meet at least ")#mi("{N_r(B)}")#text(" of these product balls. However, if two elements of ")#mi("{A-C}")#text(" are separated by a distance of at least ")#mi("{4r}")#text(", then no product ball can intersect both preimages. We thus see that ")#mi("{N_{4r}^{ent}(A-C) \\leq \\frac{N_r(A-B) N_r(B-C)}{N_r(A-C)}}")#text(", and the claim follows. ")#mi("\\Box")

#text("Below the fold we will record some further metric entropy analogues of sum set estimates (basically redoing much of Chapter 2 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text("). Unfortunately there does not seem to be a direct way to abstractly deduce metric entropy results from their sum set analogues (basically due to the failure of a certain strong version of Freiman’s theorem, as discussed in ")#link("https://terrytao.wordpress.com/2008/11/09/a-counterexample-to-a-strong-polynomial-freiman-ruzsa-conjecture/")[#text("this previous post")]#text("); nevertheless, the proofs of the discrete arguments are elementary enough that they can be modified with a small amount of effort to handle the entropy case. (In fact, there should be a very general model-theoretic framework in which both the discrete and entropy arguments can be processed in a unified manner; see ")#link("http://www.ams.org/mathscinet-getitem?mr=3091666")[#text("this paper of Hrushovski")]#text(" for one such framework.)")

#text("It is also likely that many of the arguments here extend to the non-commutative setting, but for simplicity we will not pursue such generalisations here.")

#metadata(none) <tao-a9f898ce3df3f14ce1bf>

#heading(level: 1)[#strong[#text(" — 1. Approximate groups — ")]]

#text("In discrete sum set theory, a key concept is that of a ")#emph[#mi("{K}")#text("-approximate group")]#text(" – a finite symmetric subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" containing the origin such that ")#mi("{A+A}")#text(" is covered by at most ")#mi("{K}")#text(" translates of ")#mi("{A}")#text(". The analogous concept here will be that of a ")#emph[#mi("{(K,r)}")#text("-approximate group")]#text(": a precompact symmetric subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" containing the origin such that ")#mi("{A+A}")#text(" is covered by at most ")#mi("{K}")#text(" copies of ")#mi("{A+B(0,r)}")#text(". Such sets obey good iterated doubling properties; for instance, ")#mi("{mA}")#text(" is covered by at most ")#mi("{K^{m-1}}")#text(" copies of ")#mi("{A+B(0,(m-1)r)}")#text(" for any ")#mi("{m \\geq 1}")#text(". They can be generated from sets of small tripling:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-4785977e0e0c03ef0b0c>#text(" Let ")#mi("{A}")#text(" be a precompact non-empty subset of ")#mi("{G}")#text(", and let ")#mi("{K, r > 0}")#text(". If ")#mi("{N_r(3A) \\leq K N_{16r}(A)}")#text(" or ")#mi("{N_r(2A-A) \\leq K N_{16 r}(A)}")#text(", then ")#mi("{A-A}")#text(" is a ")#mi("{(K^4,32r)}")#text("-approximate group.")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-b10827da3d072f4fbbfe>)[#text("5")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("N_{4r}(2A-2A) \\leq \\frac{N_r(2A \\pm A) N_r(\\mp A-2A)}{N_r(A)} \\leq K^2 N_{16r}(A)")]]

#text("(for an appropriate choice of sign) and")

#align(center)[#tao-fit-display[#mitex("N_{16r}(3A-2A) \\leq \\frac{N_{4r}((A-2A)+A) N_{4r}(-A-(-2A))}{N_{4r}(A)} \\leq K^4 N_{16r}(A)")]]

#text("and thus by Lemma ")#link(<tao-965c2d9c5200c50411f5>)[#text("4")]#text(", ")#mi("{2A-2A}")#text(" may be covered by at most ")#mi("{K^4}")#text(" copies of ")#mi("{A-A + B(0,32r)}")#text(", giving the claim. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. From small doubling to small tripling or quadrupling — ")]]

#text("As we saw above, Lemma ")#link(<tao-b10827da3d072f4fbbfe>)[#text("5")]#text(" and Lemma ")#link(<tao-965c2d9c5200c50411f5>)[#text("4")]#text(" are already very powerful once one has some sort of control on triple or higher sums such as ")#mi("{3A}")#text(", ")#mi("{2A-A}")#text(", or ")#mi("{2A-2A}")#text(". But if only controls a double sum such as ")#mi("{A-A}")#text(" or ")#mi("{A+A}")#text(", it is a bit trickier to proceed. Here is one estimate (somewhat analogous to Proposition 2.18 from ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(", but with slightly worse numerology):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" Let ")#mi("{A}")#text(" be a precompact non-empty subset of ")#mi("{G}")#text(", and let ")#mi("{K, r > 0}")#text(". If ")#mi("{N_r(A-A) \\leq K N_{4r}(A)}")#text(", then ")#mi("{N_{24r}(2A-2A) \\leq 32 K^5 N_{4r}(A)}")#text(".")
]

#text("One can combine this lemma with Lemma ")#link(<tao-b10827da3d072f4fbbfe>)[#text("5")]#text(" to obtain similar conclusions starting with a hypothesis on ")#mi("{A+A}")#text(" rather than ")#mi("{A-A}")#text("; we leave this to the interested reader. Of course, the conclusion can also be combined with Lemma ")#link(<tao-4785977e0e0c03ef0b0c>)[#text("6")]#text("; we again leave this as an exercise.")

#emph[#text("Proof:")]#text(" Write ")#mi("{N := N_{4r}(A)}")#text(". Then ")#mi("{N^{ent}_{4r}(A) \\geq N}")#text(", so we may find a ")#mi("{4r}")#text("-separated subset ")#mi("{\\Sigma}")#text(" of ")#mi("{A}")#text(" with ")#tao-math("{\\left|\\Sigma\\right| = N}", block: false)#text(". By hypothesis, we may cover ")#mi("{A-A}")#text(" by balls ")#mi("{B(x_1,r),\\dots,B(x_m,r)}")#text(" with ")#mi("{m \\leq K N}")#text(". Call a centre ")#mi("{x_i}")#text(" ")#emph[#text("popular")]#text(" if ")#mi("{B(x_i,r)}")#text(" contains at least ")#mi("{N/2K}")#text(" differences ")#mi("{a-b}")#text(" with ")#mi("{a,b \\in \\Sigma}")#text(" (counting multiplicity), and let ")#mi("{S}")#text(" denote the set of popular centres. Then at most ")#mi("{KN \\times (N/2K)}")#text(" of the ")#mi("{N^2}")#text(" pairs ")#mi("{(a,b) \\in \\Sigma^2}")#text(" have ")#mi("{a-b}")#text(" lying in an unpopular ball ")#mi("{B(x_i,r)}")#text(", thus we have ")#mi("{a-b \\in S + B(0,r)}")#text(" for at least ")#mi("{N^2/2}")#text(" pairs ")#mi("{(a,b)}")#text(" in ")#mi("{\\Sigma^2}")#text(". Thus, by the pigeonhole principle, there exists ")#mi("{b \\in \\Sigma}")#text(" such that at least ")#mi("{N/2}")#text(" elements of ")#mi("{\\Sigma-b}")#text(" lie in ")#mi("{S + B(0,r)}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("N^{ent}_{4r}( S + B(0,r) ) \\geq N/2")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("N_{2r}( S + B(0,r) ) \\geq N/2")]]

#text("and thus ")#metadata(none) <tao-201941a5aa4f4c012c7d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("N_{r}( S ) \\geq N/2.")]]

#text("Next, for any ")#mi("{x \\in -A + S + A}")#text(", we consider the set ")#mi("{U_x}")#text(" of pairs ")#mi("{(x_i,x_j)}")#text(" such that ")#mi("{-x_i + x_j \\in x + B(0,3r)}")#text(". We may write")

#align(center)[#tao-fit-display[#mitex("x = -a + s + b")]]

#text("for some ")#mi("{a,b \\in A}")#text(" and ")#mi("{s \\in S}")#text(". By definition of ")#mi("{S}")#text(", we can find distinct pairs ")#mi("{(a_k,b_k) \\in \\Sigma}")#text(" for ")#mi("{1 \\leq k \\leq k_*}")#text(" with ")#mi("{k_* \\geq N/2K}")#text(" such that ")#mi("{a_k-b_k \\in B(s,r)}")#text(" for all ")#mi("{k}")#text(". As ")#mi("{\\Sigma}")#text(" is ")#mi("{4r}")#text("-separated and ")#mi("{B(s,r)}")#text(" has diameter at most ")#mi("{2r}")#text(", the ")#mi("{a_k}")#text(" must be distinct in ")#mi("{k}")#text(", and similarly for the ")#mi("{b_k}")#text(". We then have")

#align(center)[#tao-fit-display[#mitex("x \\in (a_k - a) + (b-b_k) + B(0,r)")]]

#text("for ")#mi("{k=1,\\dots,k_*}")#text(". Each ")#mi("{a - a_k}")#text(" lies in ")#mi("{A-A}")#text(" and is thus lies in ")#mi("{B(x_i,r)}")#text(" for some ")#mi("{i}")#text(", and similarly ")#mi("{b-b_k \\in B(x_j,r)}")#text(" for some ")#mi("{j}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("-x_i + x_j \\in (a_k-a) + (b-b_k) + B(0,2r) \\subset x + B(0,3r)")]]

#text("and so ")#mi("{(x_i,x_j) \\in U_x}")#text(". Also, since ")#mi("{a_k - a \\in B(x_i,r)}")#text(" and the ")#mi("{a_k}")#text(" are ")#mi("{4r}")#text("-separated, we see that the ")#mi("{x_i}")#text(" are distinct as ")#mi("{k}")#text(" varies. We conclude that ")#tao-math("{\\left|U_x\\right| \\geq k_* \\geq N/2K}", block: false)#text(". On the other hand, the total number of pairs ")#mi("{(x_i,x_j)}")#text(" is ")#mi("{m^2 \\leq (KN)^2}")#text(", and any two ")#mi("{6r}")#text("-separated points ")#mi("{x,y}")#text(" in ")#mi("{-A+S+A}")#text(" generate disjoint sets ")#mi("{U_x, U_y}")#text(". We conclude that there can be at most ")#mi("{(KN)^2 / (N/2K) = 4K^3 N}")#text(" ")#mi("{6r}")#text("-separated points in ")#mi("{-A+S+A}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("N^{ent}_{6r}( -A + S + A ) \\leq 4 K^3 N")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("N_{6r}(S + A-A) \\leq 4 K^2 N.")]]

#text("By Lemma ")#link(<tao-b10827da3d072f4fbbfe>)[#text("5")]#text(" and ")#link(<tao-201941a5aa4f4c012c7d>)[#text("(1)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("N_{24r}( 2A-2A) \\leq \\frac{(4K^2 N)^2}{N_{6r}(S)} \\leq 32 K^5 N")]]

#text("and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. The Balog-Szemeredi-Gowers lemma — ")]]

#text("One of the most difficult, but powerful, components of the elementary sum set theory is the tool now known as the ")#emph[#text("Balog-Szemerédi-Gowers lemma")]#text(", which converts control on partial sumsets (or equivalently, lower bounds on “additive energy”) to control on total sumsets, after suitable refinements of the sets. Here is one metric entropy version of this lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Balog-Szemerédi-Gowers)")]#text(" Let ")#mi("{N,r > 0}")#text(" and ")#mi("{K \\geq 1}")#text(", and let ")#mi("{A,B}")#text(" be precompact subsets of ")#mi("{G}")#text(". Suppose that")

#align(center)[#tao-fit-display[#mitex("N_{r}(A), N_{r}(B) \\leq N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_{22r}( \\{ (a,b,a^{\\prime},b^{\\prime}) \\in A \\times B \\times A \\times B: d(a+b, a^{\\prime}+b^{\\prime}) < r \\} )")]]

#align(center)[#tao-fit-display[#mitex("\\geq N^3/K,")]]

#text("where we endow ")#mi("{G \\times G \\times G \\times G}")#text(" with the sup norm metric. Then there exist subsets ")#mi("{A^{\\prime}}")#text(", ")#mi("{B^{\\prime}}")#text(" of ")#mi("{A, B}")#text(" respectively with")

#align(center)[#tao-fit-display[#mitex("N_r(A^{\\prime}), N_r(B^{\\prime}) \\gg K^{-O(1)} N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_{54r}( A^{\\prime} + B^{\\prime} ) \\ll K^{O(1)} N.")]]
]

#text("Again, this lemma may be usefully combined with the previous sum set estimates, much as was done in my book with Van Vu; I leave the details to the interested reader.")

#emph[#text("Proof:")]#text(" Let ")#mi("{\\Sigma_A}")#text(", ")#mi("{\\Sigma_B}")#text(" be maximal ")#mi("{2r}")#text("-separated subsets of ")#mi("{A, B}")#text(" respectively, thus ")#tao-math("{\\left|\\Sigma_A\\right| \\leq N^{ent}_{2r}(A) \\leq N_r(A) \\leq N}", block: false)#text(", and similarly ")#tao-math("{\\left|\\Sigma_B\\right| \\leq N}", block: false)#text(".")

#text("By hypothesis, we can find at least ")#mi("{N^3/K}")#text(" quadruples ")#mi("{(a,b,a^{\\prime},b^{\\prime})}")#text(" which are ")#mi("{22r}")#text("-separated in ")#mi("{A \\times B \\times A \\times B}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("d(a+b,a^{\\prime}+b^{\\prime}) < r")]]

#text("for all such quadruples. By construction of ")#mi("{\\Sigma_A, \\Sigma_B}")#text(", each such quadruple can be associated to a nearby quadruple ")#mi("{(\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime}) \\in \\Sigma_A \\times \\Sigma_B \\times \\Sigma_A \\times \\Sigma_B}")#text(" with")

#align(center)[#tao-fit-display[#mitex("d(\\alpha,a), d(\\beta,b), d(\\alpha^{\\prime},a^{\\prime}), d(\\beta^{\\prime},b^{\\prime}) < 2r")]]

#text("and thus by the triangle inequality ")#metadata(none) <tao-5835a2460f0994134d10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("d(\\alpha+\\beta,\\alpha^{\\prime}+\\beta^{\\prime}) < 9r.")]]

#text("Also by the triangle inequality we see that each ")#mi("{(\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime})}")#text(" can be associated to at most one of the quadruples ")#mi("{(a,b,a^{\\prime},b^{\\prime})}")#text(", and as the ")#mi("{(a,b,a^{\\prime},b^{\\prime})}")#text(" are ")#mi("{22r}")#text("-separated, the ")#mi("{\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime})}")#text(" are ")#mi("{18r}")#text("-separated. We conclude that there is a set of at least ")#mi("{N^3/K}")#text(" quadruples ")#mi("{(\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime})}")#text(" in ")#mi("{\\Sigma_A \\times \\Sigma_B \\times \\Sigma_A \\times \\Sigma_B}")#text(" obeying ")#link(<tao-5835a2460f0994134d10>)[#text("(2)")]#text(" that are ")#mi("{18r}")#text("-separated.")

#text("Call a pair ")#mi("{(\\alpha,\\beta) \\in \\Sigma_A \\times \\Sigma_B}")#text(" ")#emph[#text("popular")]#text(" if there are at least ")#mi("{N/4K}")#text(" of the above quadruples ")#mi("{(\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime})}")#text(" in ")#mi("{\\Sigma_A \\times \\Sigma_B \\times \\Sigma_A \\times \\Sigma_B}")#text(" obeying ")#link(<tao-5835a2460f0994134d10>)[#text("(2)")]#text(" with the indicated first two coefficients. The unpopular pairs ")#mi("{(\\alpha,\\beta)}")#text(" absorb at most ")#mi("{N^3/2K}")#text(" of the ")#mi("{N^3/K}")#text(" quadruples, so at least ")#mi("{N^3/2K}")#text(" of the quadruples are associated to popular pairs ")#mi("{(\\alpha,\\beta)}")#text(". On the other hand, as the quadruples are ")#mi("{18r}")#text("-separated, we see from ")#link(<tao-5835a2460f0994134d10>)[#text("(2)")]#text(" and the triangle inequality that for each ")#mi("{\\alpha,\\beta,\\alpha^{\\prime}}")#text(" there is at most one ")#mi("{\\beta^{\\prime}}")#text(" giving rise to a quadruple ")#mi("{(\\alpha,\\beta,\\alpha^{\\prime},\\beta^{\\prime})}")#text(". Thus each ")#mi("{(\\alpha,\\beta)}")#text(" can be associated to at most ")#mi("{N}")#text(" quadruples, and we conclude that the set ")#mi("{E \\subset \\Sigma_A \\times \\Sigma_B}")#text(" of popular pairs ")#mi("{(\\alpha,\\beta)}")#text(" has size at least ")#mi("{N^2/2K}")#text(". In particular this shows that ")#tao-math("{\\left|\\Sigma_A\\right|, \\left|\\Sigma_B\\right| \\gg N/K}", block: false)#text(".")

#text("We now apply the graph-theoretic Balog-Szemerédi-Gowers lemma (see Corollary 6.19 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(") to conclude that there exists a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{\\Sigma_A}")#text(" and ")#mi("{B^{\\prime}}")#text(" of ")#mi("{\\Sigma_B}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime}\\right|, \\left|B^{\\prime}\\right| \\gg N/K^{O(1)}", block: true)]]

#text("such that for every ")#mi("{a \\in A^{\\prime}}")#text(" and ")#mi("{b \\in B^{\\prime}}")#text(" there exist ")#mi("{\\gg N^2/K^{O(1)}}")#text(" pairs ")#mi("{(a^{\\prime},b^{\\prime}) \\in A \\times B}")#text(" such that ")#mi("{(a,b^{\\prime}), (a^{\\prime},b^{\\prime}), (a^{\\prime},b)}")#text(" lie in ")#mi("{E}")#text(". Since ")#mi("{\\Sigma_A, \\Sigma_B}")#text(" was already ")#mi("{2r}")#text("-separated, we conclude that")

#align(center)[#tao-fit-display[#mitex("N_r(A^{\\prime}), N_r(B^{\\prime}) \\gg N/K^{O(1)}.")]]

#text("Now fix ")#mi("{a \\in A^{\\prime}}")#text(" and ")#mi("{b \\in B^{\\prime}}")#text(", and let ")#mi("{(a^{\\prime},b^{\\prime})}")#text(" be one of the above ")#mi("{\\gg N^2/K^{O(1)}}")#text(" pairs. As ")#mi("{(a,b^{\\prime})}")#text(" is popular, we can thus find ")#mi("{\\gg N/K}")#text(" pairs ")#mi("{(\\alpha_1,\\beta_1) \\in \\Sigma_A \\times \\Sigma_B}")#text(" such that ")#metadata(none) <tao-8b5cc4df7eec7d32a781>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\alpha_1 - \\beta_1 \\in a - b^{\\prime} + B(0,9r);")]]

#text("furthermore, the ")#mi("{(a,b^{\\prime},\\alpha_1,\\beta_1)}")#text(" lie in an ")#mi("{18r}")#text("-separated set. Similarly, we can find ")#mi("{\\gg N/K}")#text(" pairs ")#mi("{(\\alpha_2,\\beta_2) \\in \\Sigma_A \\times \\Sigma_B}")#text(" and ")#mi("{\\gg N/K}")#text(" pairs ")#mi("{(\\alpha_3,\\beta_3) \\in \\Sigma_A \\times \\Sigma_B}")#text(" such that ")#metadata(none) <tao-ac0f09c0f8bf5e7a4b06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\alpha_2 - \\beta_2 \\in a^{\\prime} - b^{\\prime} + B(0,9r)")]]

#text("and ")#metadata(none) <tao-cef7fc13a38180936ffa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\alpha_3 - \\beta_3 \\in a^{\\prime} - b + B(0,9r)")]]

#text("with the ")#mi("{(a^{\\prime},b^{\\prime},\\alpha_2,\\beta_2)}")#text(" and ")#mi("{(a^{\\prime},b,\\alpha_3,\\beta_3)}")#text(" also lying in an ")#mi("{18r}")#text("-separated set. In particular, we see that given ")#mi("{a, b}")#text(", ")#mi("{\\alpha_1,\\beta_1}")#text(" uniquely determine ")#mi("{b^{\\prime}}")#text(", and ")#mi("{\\alpha_3,\\beta_3}")#text(" uniquely determine ")#mi("{a^{\\prime}}")#text(", so a single sextuple ")#mi("{(\\alpha_1,\\beta_1,\\alpha_2,\\beta_2,\\alpha_3,\\beta_3)}")#text(" can arise from at most one pair ")#mi("{(a^{\\prime},b^{\\prime})}")#text("; in particular, we see that ")#mi("{\\gg (N^2/K^{O(1)}) \\times (N/K)^3 = N^5 / K^{O(1)}}")#text(" sextuples are associated to each pair ")#mi("{(a,b)}")#text(". Taking alternating combinations of ")#link(<tao-8b5cc4df7eec7d32a781>)[#text("(3)")]#text(", ")#link(<tao-ac0f09c0f8bf5e7a4b06>)[#text("(4)")]#text(", ")#link(<tao-cef7fc13a38180936ffa>)[#text("(5)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\alpha_1 - \\beta_1 - \\alpha_2 + \\beta_2 - \\alpha_3 + \\beta_3 \\in a - b + B(0,27r).")]]

#text("In particular, if ")#mi("{(a,b)}")#text(" and ")#mi("{(\\tilde a, \\tilde b)}")#text(" are two pairs in ")#mi("{A^{\\prime} \\times B^{\\prime}}")#text(" with ")#mi("{a-b, \\tilde a - \\tilde b}")#text(" at least ")#mi("{54r}")#text(" apart, then a single sextuple ")#mi("{(\\alpha_1,\\beta_1,\\alpha_2,\\beta_2,\\alpha_3,\\beta_3)}")#text(" can be associated to at most one of these pairs. Since the number of sextuples is at most ")#mi("{N^6}")#text(", we conclude that there are at most ")#mi("{K^{O(1)} N}")#text(" pairs ")#mi("{(a,b)}")#text(" with ")#mi("{54r}")#text("-separated differences ")#mi("{a-b}")#text(", thus ")#mi("{N_{54r}(A^{\\prime}-B^{\\prime}) \\ll K^{O(1)} N}")#text(" as required. ")#mi("\\Box")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("Is there a typo in the definition of difference sets?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277106")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("In proof of Lemma 1, {|A|} should be {|B|}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277118")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("Another typo above Def 3: odubling")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277125")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("And at the end of Def 3 there is an extra {itemize}")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277126")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("Closing parenthesis missing from para above lemma 4.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277120")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("The internal covering number, {N^{int}_r(E)}, might decrease in E – consider r=3 and E={0,2,4} and E’={0,4}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22e5db36544cc5f7a418ae3c5eefecea3091af8001e1f66747b6ef2af2df586c-68aacf1fe5a22b0e0db8c09a743749e6a00b3dd47d61d04d4f3cd08be18f51f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kyle")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277176")[#strong[#text("kyle")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("I think there are some typos in the proof of lemma 1. For example, I think the maximal set that is chosen should be a subset of A, not a subset of B as stated. I also agree with the earlier comment by domotorp that the cardinality of each of these translates is |B|, not |A|.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22e5db36544cc5f7a418ae3c5eefecea3091af8001e1f66747b6ef2af2df586c-68aacf1fe5a22b0e0db8c09a743749e6a00b3dd47d61d04d4f3cd08be18f51f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kyle")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277177")[#strong[#text("kyle")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("Sorry, didn’t mean to post a reply under this comment.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277175")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("Kind of being in this frame of “discretized”, but not discrete, nor continuous, in ")#link("http://arxiv.org/abs/1304.3358")[#text("arXiv:1304.3358")]#text(" there is a very simple note about a “geometric Ruzsa triangle intequality”, which does not even use group operations, maybe is of some interest here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3781a03781efe0a0dc0756225ab0de9ffe20b11f0ed8631acb2cab59dd63d98-26df9f525f20b7810cf415078216b23cf0a5e4593134df6e9fa00c61427997f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pascal")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277230")[#strong[#text("Pascal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("Is there a version of the basic results of additive combinatorics for multisets rather than sets, or even better for multisets where negative cardinalities are allowed?")

#text("If this looks like a baroque idea, note that there is a quite natural interpretation: if c_a denotes the mulitplicity of element a, we can represent a multiset by the polynomial sum_a c_a X^a. Taking a sum set A+B then amounts to multiplying the 2 corresponding polynomials.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277247")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("There is a closely analogous theory to discrete sumset theory for random variables, with Shannon entropy taking the place of cardinality: see ")#link("http://www.ams.org/mathscinet-getitem?mr=2647496")[#text("http://www.ams.org/mathscinet-getitem?mr=2647496")]#text(" . For signed functions, the appropriate tool is Fourier analysis and convolution, for which there are certainly a lot of estimates available (though once one gives up positivity, many of the more combinatorial estimates in the sumset theory no longer have good analogues).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0330c9b6c47e9aa3fbd6ef8912b9e58a78d810eeb3c446a4fcc1cd4a024a430-568f4f52bdd2b1c46af531d89e349275a87d8e2b91aa02e6119fa5ee66f6d642.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Sang")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-279447")[#strong[#text("Geoff Sang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("Hi Terence,")#linebreak()#text(" I am a year 9 student from Western Australia, and I find your blog very fascinating. The school maths I do are easy however I know that there are many more students better than I am.")

#text("I have never done complicated maths before like the Australian Maths Olympiad (unlike you when you were my age), but now I am starting to learn the fundamentals. Proof has always been an obstacle when I do competitions (e.g. The Western Australian Junior Mathematical Olympiad). How could I practice proof and also understand a question better when doing competitions?")

#text("Thank you,")#linebreak()#text(" Geoff Sang")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-277432")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2014")])]

#text("In the proof of Lemma 1 should “lie in |A + B|” be “lie in A + B”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-278698")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2014")])]

#text("In the orthogonal nxn matrix example: “…let A be the matrices obtained by starting with an orthogonal matrix in On(R) and rounding each coefficient to the nearest multiple of epsilon…. This is a finite set (whose cardinality grows as [epsilon goes to 0] like a certain negative power of epsilon).”")

#text("The above recipe seems to me to produce exactly one matrix, regardless of epsilon’s value, so I must be missing something real basic. Can someone help?")

#emph[#text("[Reworded for clarity – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-280001")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("It looks like you are describing some sort of generalized Hamming Code? For noisy channel coding the “buzzwords” should be a certain Hammin distance apart.")

#text("At this point I am taking a step back and reading through your book with Van Vu.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f7b4558834c04e32311956fc31c90bd6ac03586a7389209c350068c1d4d238b-84c9048c1d65e60920319e0d1511fc922313caa554272a2e377432b5acd3ff0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-356138")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")])]

#text("Prof. Tao,")

#text("In general, we can not replace ")#mi("B-B")#text(" by ")#mi("B")#text(" in Ruzsa’s covering lemma without some sort of loss. That is showed in an exercise in the book of you and Prof. Vu. If ")#mi("A, B")#text(" are finite subsets of integers, is it true that we can cover ")#mi("A")#text(" by at most ")#tao-math("\\left|A+B\\right|/\\left|B\\right|", block: false)#text(" (")#tao-math("\\left|A-B\\right|/\\left|B\\right|", block: false)#text(") translates of ")#mi("B")#text("? I did some simulations, and no counterexample was found.")

#text("Best,")#linebreak()#text(" Jiange")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-356256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")])]

#text("Unfortunately not; one can take a counterexample ")#mi("A,B")#text(" in a finite group such as ")#mi("{\\bf Z}/N{\\bf Z}")#text(" (e.g. the one in Exercise 2.4.1 of my book with Van), and “transfer” it to the integers by considering a set such as ")#mi("A^{\\prime} := \\{ 1 \\leq n \\leq M: n \\text{ mod } N \\in A \\}")#text(" and ")#mi("B^{\\prime} := \\{ 1 \\leq n \\leq M: n \\text{ mod } N \\in B \\}")#text(", where ")#mi("M")#text(" is much larger than ")#mi("N")#text(". This modifies the covering number by a factor of 2 or so, but the failure in ")#mi("{\\bf Z}/N{\\bf Z}")#text(" of the naive Ruzsa covering lemma is by an arbitrarily large constant, so it can also create an arbitrarily large failure of that covering lemma in the integers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-497627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("Typo:")#linebreak()#text(" In the paragraph following Definition 3,")#linebreak()#text(" “…the external covering number ")#mi("N^{ent}_r (E)")#text(" is slightly more convenient than the other notions of metric entropy, so we will abbreviate ")#mi("N_r(E) = N^{ent}_r (E)")#text("”")#linebreak()#text(" should be")#linebreak()#text(" “…the external covering number ")#mi("N^{ext}_r (E)")#text(" is slightly more convenient than the other notions of metric entropy, so we will abbreviate ")#mi("N_r(E) = N^{ext}_r (E)")#text("” (The difference is in the superscript.)")#linebreak()#text(" I think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/214a5b5ce764f02b1743e8f3ce644bb8639759d2c3474e2906499adc3eb6f1c0-21b1d4bcf8fbdf6fede4d8bbe1abf084e1ac6df136e34a2837fd1670aef8fdcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aetjmaison")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-515576")[#strong[#text("aetjmaison")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2019")])]

#text("In your definitions of entropies, are the balls open? If they are closed, should the inequality be strict in the definition of r-separation? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/03/19/metric-entropy-analogues-of-sum-set-theory/#comment-515584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2019")])]

#text("It doesn’t make too much difference to the arguments, but in my post the balls are open, and I believe all the statements in the post are valid with non-strict inequality in the definition of separation.")
]
]
