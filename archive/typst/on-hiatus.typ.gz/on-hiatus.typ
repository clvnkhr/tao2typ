// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/09/19/on-hiatus/
// Converted to Typst by tao2typ: "2026-10-14T07:03:06.776460+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On hiatus", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On hiatus")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 September 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/09/19/on-hiatus/")[#text("https://terrytao.wordpress.com/2008/09/19/on-hiatus/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Due to various other things that have come up, I will be cutting back on my blogging for a while. I hope to resume here in a couple weeks, though.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Singularitarian")]], [#link("https://terrytao.wordpress.com/2008/09/19/on-hiatus/#comment-32643")[#strong[#text("Singularitarian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2008")])]

#text("Take your time, Terence Tao! We all know you have many other things you need to do!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashesoftime")]], [#link("https://terrytao.wordpress.com/2008/09/19/on-hiatus/#comment-32644")[#strong[#text("Ashesoftime")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2008")])]

#text("Understand that.I ‘ve been very grateful for your sharing of your great mathematical ideas here and your lecture notes online.Thanks so much.")
]
