// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/
// Converted to Typst by tao2typ: "2026-10-14T15:21:13.524072+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A paper diagram visualizer", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A paper diagram visualizer")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/")[#text("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am finding the newly revealed capability to code old applet ideas into reality to be very tempting to sink more time into, though I am certainly encountering the common “vibe coding” experience that the process can produce something that superficially resembles a finished product well before a satisfactory level of testing and review has been completed; indeed, it is the review process which is now the most time-consuming, to the point where I think any further advances in coding agent capability will have little impact on the new bottlenecks in the design process.")

#text("In any event, I ")#link("https://teorth.github.io/tao-web/apps/paper-diagram-making-of.html")[#text("spent a few hours")]#text(" working to realize a ")#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/")[#text("proposal I had made back in 2023")]#text(" to automatically create diagrams to visually illustrate the logical flow of a given mathematical paper. At the time, Freddie Manners, extrapolating from the half-decent capability of the then-newly released ChatGPT 3.5 at this task, ")#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674333")[#text("presciently predicted")]#text(" that “by the time a dedicated tool had been completed, the next general purpose engine would be better than it”.")

#text("With that in mind, I decided to focus not on the generation of the diagram – which now can be done at various levels of quality by any number of large language models – but on its presentation. The result is ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html")[#text("the following app")]#text(", which can take a certain formatted JSON file of dependencies between theorem objects and produce an interactive graph which can be explored, edited and also exported (somewhat lossily) into other standard formats such as SVG, TikZ, quiver, or Mermaid. Here is a screenshot of ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=kakeya")[#text("a diagramming")]#text(" of the ")#link("https://arxiv.org/abs/2502.17655")[#text("celebrated proof by Wang and Zahl")]#text(" of the three-dimensional Kakeya conjecture:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-4.png")[#image("../assets/fb9f7372a84ae7a3891544444139ed0d5cb7374c40700e53b41f09168ac6dcc7-a3dafe0767fe6e6e34626843058bf6fe681f86671f7876a72adb12c8398f50f5.png", width: 90%)]
]

#text("Using an LLM, I generated diagrams for eight papers for demonstration purposes, including for instance a ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=wiles-flt")[#text("diagram for Wiles’s proof of Fermat’s last theorem")]#text(", or ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=szemeredi")[#text("of Szemeredi’s proof of his famous theorem on arithmetic progressions")]#text(" (which sports a notoriously convoluted such diagram in ")#link("https://eudml.org/doc/205339")[#text("the original paper")]#text("), as well as a few ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=gilbreath")[#text("papers")]#text(" ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=2605.00301")[#text("of my")]#text(" ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=2605.00301")[#text("own")]#text(". If there are other requests to diagram particular papers, I can try to use an LLM to generate more examples; but my intention is for users of the app to create their own such diagrams, either by manually constructing them, or by directing their own AI tools to build the diagram in the required format (which is a JSON, with the precise specification given ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html#format")[#text("here")]#text(").")

#text("I mentioned in the previous post that for these sorts of visualization apps, which work deterministically for a given set of inputs, the downside risk of LLM use to build the app is acceptably low. For this particular app, there is a complicating factor, which is that while the app does remain deterministic, the data I used to populate the app – namely, the above diagrams – are also LLM-generated. I have done spot checks comparing the diagrams against the source papers, and did not find any errors; however, they are not guaranteed to be 100% accurate, and should only be used as approximations to the logical structure of these papers rather than completely exact representations. (The latter might become deterministically extractable should the results of these papers become formalized in a proof assistant language, but this is not currently the case.) Still, I hope these sorts of diagrams can serve as a helpful initial guide when first trying to read and understand a complex paper.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693381")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("You lay out three options: prose, LLM-generated diagram, and full formalization. There’s a fourth option, the author just writes down the dependency structure while writing the proof. This is basically Lamport’s idea from “How to Write a 21st Century Proof” (")#link("https://lamport.azurewebsites.net/pubs/proof.pdf")[#text("https://lamport.azurewebsites.net/pubs/proof.pdf")]#text("). If you write a proof as a hierarchy of claims, each with its own hypotheses and goal, you’ve already written the dependency graph. Keep that in the markup instead of flattening it into prose, and the graph can be generated deterministically. It costs almost nothing extra, since you’re just writing the proof carefully.")

#text("Once the structure is written down this way, you can do more than generate a structural diagram. You can collapse a section or proof, see what a step depends on and what depends on it, reorder steps that are independent, and click through the graph, all on the actual text. I’ve been working on an implementation of this, which I will soon submit to the AMR’s Paper of the Future prize. In case a concrete example helps: ")#link("https://github.com/leotrs/potf/")[#text("https://github.com/leotrs/potf/")]#text(". Video to come soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("This reminds me of the ")#link("https://github.com/PatrickMassot/leanblueprint")[#text("Lean Blueprint plugin for LaTeX")]#text(", which has become a de facto standard for the first phase of a Lean formalization project in which one wants to see a structured informal proof of a given result before fully formalizing each of the components. There is a more recent Lean package, ")#link("https://github.com/hanwenzhu/LeanArchitect")[#text("LeanArchitect")]#text(", which embeds the blueprint directly into the Lean source and extracts as much of the metadata as it can automatically from the structure. In this model, the informal argument can be written through Lean stubs annotated with LeanArchitect LaTeX comments.")

#text("In short, the lines between formal proof, informal proof, and structural proof metadata are rapidly blurring, and I can certainly see all three being generated in tandem in the near future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bcf5e9e452caeb2cacf599d6d9ee822d743b9f37fe6791617bbea0a92066e52-399df63abc879fb365b00dff2d62fb79cf32662538dbb681e6e3c4dd3322eb04.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mercury Stills")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693484")[#strong[#text("Mercury Stills")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2026")])]

#text("Professor Tao,")

#text("This observation—that the lines between formal proof, informal proof, and structural proof metadata are blurring—is strikingly close to something I have been building since December 2025.")

#text("Strategic.GG’s Open Problem Gallery is a graph-based workspace for coordinating mathematics research. Inspired by the Polymath Project, it maps a complementary stage of the work: not the retrospective logical skeleton of a finished paper, but the live search that precedes one—claims, dependencies, strategy branches, checks, failed or disputed approaches, challenges, and forks. Lean formalizations can be attached to individual claims and independently reviewed.")

#text("OPG is now public here:")

#link("https://strategic.gg/open-problem-gallery/")[#text("https://strategic.gg/open-problem-gallery/")]

#text("I describe its coordination, verification, and falsification model here:")

#link("https://strategic.gg/s/748/")[#text("https://strategic.gg/s/748/")]

#text("Your JSON grammar and the Blueprint converter you describe suggest an interoperability opportunity. I have not implemented that interchange layer; OPG currently uses its own graph representation. But I would be interested in whether a small common profile could let a live problem-solving graph mature into a paper-dependency diagram or Lean Blueprint while retaining provenance, fork lineage, and review history.")

#text("Disclosure: I’m Mercury, Strategic.GG’s founder and developer.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Hi Terry, how cool!")

#text("Wonder if there could be a bridge to Lean, via a dependency diagram like this one: ")#link("https://thefundamentaltheor3m.github.io/Sphere-Packing-Lean/blueprint/dep_graph_document.html")[#text("https://thefundamentaltheor3m.github.io/Sphere-Packing-Lean/blueprint/dep_graph_document.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Nice suggestion! With a little LLM prompting I was able to convert Viazovska’s sphere packing blueprint into the format of my app: ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=sphere-packing-lean")[#text("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=sphere-packing-lean")]#text(" . I am directing the agent now to build a converter tool that can deterministically convert any such blueprint into the JSON format for my app; it cannot be done inside the app itself because it requires web access, which I have disabled for my applets, but will be attached to the applet page as a separate downloadable piece of python code (wrapped around a small script that fetches the appropriate files from the web).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Some time ago I mentioned a more elaborated functionality. First I recommended using ")#linebreak()#link("mailto:git@github.com")[#text("git@github.com")]#text(":michal-h21/rdfref.git.")

#text("It is a flexible tool, though not automatic, and its syntax differs somewhat from standard LaTeX. Recently a Chinese software engineer, Cj Looi, launched a webpage that uses a JSON parser to generate dependency graphs automatically from LaTeX source files. ")#linebreak()#link("https://www.sciencestack.ai/upload")[#text("https://www.sciencestack.ai/upload")]

#text("For the past two months I have been testing the software and suggesting features. It now seems reasonably mature. Disclaimer: I have no connection to Mr Looi, but I think his work is serious and worth mentioning. The paper you cited in your blog has since been uploaded, and the site can generate its dependency graph: A counterexample to the periodic tiling conjecture (there is a dark and light mode; the default is dark). A few observations: By default the software generates a graph using all labels and references from theorem, definition and similar environments. These can be deactivated if the graph becomes confusing. Blocks can be moved manually for better visibility, though the arrangement is only temporary. In your manuscript, page 5, you included your own dependency graph, which is smaller than the automatically generated one. On request, Mr Looi might add support for special labels, for example , so that only tagged environments appear. This feature is not yet implemented. Some papers from the ArXiv have been uploaded, but by no means all. You can create your own account to upload manuscripts. A free and a paid tier are available, though the latter seems premature for now. I hope you find this useful.")

#text("Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb19f1c7e97fa271b4e5b15871681f10cde5861d3d62ce0bfe634b6c7f4bf493-e1af2e2ab649aee83320000ff52c7798a46926c8d4a03053efa5235e1262193e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ Looi")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693388")[#strong[#text("CJ Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Agreed that this can be a very useful tool for mathematicians, the UI looks quite similar to what I’ve built here ")#link("https://www.sciencestack.ai/graph/kakeya-restriction")[#text("https://www.sciencestack.ai/graph/kakeya-restriction")]

#text("It’s a proof of concept and the data is also LLM-generated, but one could eventually annotate or extend the graph, or use LLMs to pull from existing literature to connect more papers")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb19f1c7e97fa271b4e5b15871681f10cde5861d3d62ce0bfe634b6c7f4bf493-e1af2e2ab649aee83320000ff52c7798a46926c8d4a03053efa5235e1262193e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ Looi")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693390")[#strong[#text("CJ Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("I have open sourced some of the proof graphs in this repository ")#link("https://github.com/sciencestack-ai/proof-dags")[#text("https://github.com/sciencestack-ai/proof-dags")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef06046c3e3f2eb0c11c98a8c4a11ed84b25ccbc023d13f15062e426e1fdf3a-366938429a206590b60f422cbbb17608d068f86905fb2652141d3f9024626ae7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elias Lam")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693389")[#strong[#text("Elias Lam")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("This job is really great. When dealing with complex papers, I believe this tool can greatly improve efficiency.")

#text("Also, I found a post that somewhat overlaps with your idea. The difference is that it analyzes a textbook, and it looks a bit cluttered: ")#link("https://onehappybird.wordpress.com/2012/12/03/whats-the-most-important-theorem/")[#text("https://onehappybird.wordpress.com/2012/12/03/whats-the-most-important-theorem/")]

#text("But this might suggest that this approach could be used not only to analyze papers, but also various textbooks and lecture notes, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693391")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Feedback on the interface: for me zooming scrolls work terribly, even if I want to zoom out a little, it makes the whole diagram invisibly tiny.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693393")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Thanks for this. There was indeed a bug (invisible when testing on my device, but apparently possible on other devices, particularly ones involving a trackpad) where a scrolling gesture triggered multiple zoom out calls at once instead of just one. Hopefully it is fixed now (and also in the relativity app, which my agent discovered had the same bug); let me know if it still persists!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("Just for that 1% chance that you might like to contribute to the newly born bilingual Farsi–English journal People and Mathematics: your intentions and motivations behind creating these apps would fit beautifully in the journal’s “Concepts and Conceptions” section:")#link("https://mathswell.com/people-and-mathematics/")[#text("https://mathswell.com/people-and-mathematics/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f5e75dd5d1b84462a93fda2757d25279ed40d7abfe639eb97c2d3c4360bac0-20128771c050417854a2a39358afc5479821fc71248c3788ac63054a269a920d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Ktitarev")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693405")[#strong[#text("Tim Ktitarev")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("What a nice tool! I gave Gemini ")#link("https://doi.org/10.26083/tuprints-00031371")[#text("my bachelor’s thesis")]#text(" as a single TeX file and instructed it to generate a JSON for a diagram. It took some convincing to generate all the relevant nodes and edges. I realized that often in the thesis I did not make an explicit reference to what I was using because from the context it was clear, but for Gemini it was not. ")#link("https://gemini.google.com/share/b7dd1ee4ef56")[#text("You can see my chat and the end result here")]#text(".")

#text("I did not thoroughly check if all the dependencies were right, but it looks like it. A few comments on the end result. My thesis was about a numerical scheme called the continuous Petrov-Galerkin method. The main theoretical task was understanding a proof of convergence from the literature. On the left side of the diagram, there are some introductory results. On the right side, there is the main bulk of the thesis. At the top is the main proposition on the convergence of the scheme. I reformulated the proof ideas from the literature into two other results – a “consistency” and “stability” result, which in combination given an alternative proof of convergence. You can very nicely see in the diagram how the definitions of the scheme, the definition of convergence as well as the consistency and stability go into the proposition of convergence.")

#text("I like it! I can also see myself using this to try to get a quick overview of a paper and see which parts are really relevant to my own work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693408")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("Great to see that the workflow of giving the JSON format to a third-party LLM works! I have uploaded your JSON (as the first reader-contributed example to the catalog) at ")#link("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=cpg-ktitarev")[#text("https://teorth.github.io/tao-web/apps/paper-diagram.html?paper=cpg-ktitarev")]

#text("EDIT: I have now placed my apps under an MIT license, so that users are permitted to host local copies of this app in order to display their own curated libraries of paper diagrams distinct from the sample ones shown on this site, as long as the copyright and license is retained.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac019ae371847a5e8b7ad12b8873d4cebca25c620c8d03dc06e854b33890aeb6-cd64c4ad1ca873f6bc4050b51718bb5a87a11015d4af3dca5ebff7e15bcab88a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pavel Ievlev")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693470")[#strong[#text("Pavel Ievlev")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2026")])]

#text("Hi! My wife recently wrote an app for this. Initially for my personal use, but now she plans to release it publicly. It’s called proofmap, you can try it out here: ")#link("https://proofmap.aleph.science/")[#text("https://proofmap.aleph.science/")]#text(" . It can automatically parse papers in tex/json format into theorem blocks with dependencies. I’m already using it intensively, although it’s still in the stage of active development. It has mcp/http api for using with claude code or other agents, although the workflow is not ai-oriented. Any feedback is welcome through the feedback button in the app :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/13/a-paper-diagram-visualizer/#comment-693650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("here are computer science style diagrams via code for inspiration ")#link("https://cdn-0.plantuml.com/")[#text("https://cdn-0.plantuml.com/")]
]
