// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:16:37.853636+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 8: The mean ergodic theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 8: The mean ergodic theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("We now begin our study of ")#emph[#text("measure-preserving systems")]#text(" ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(", i.e. a ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(" ")#mi("(X, {\\mathcal X}, \\mu)")#text(" together with a probability space isomorphism ")#mi("T: (X, {\\mathcal X}, \\mu) \\to (X, {\\mathcal X}, \\mu)")#text(" (thus ")#mi("T: X \\to X")#text(" is invertible, with T and ")#mi("T^{-1}")#text(" both being ")#link("http://en.wikipedia.org/wiki/Measurable")[#text("measurable")]#text(", and ")#mi("\\mu(T^n E) = \\mu(E)")#text(" for all ")#mi("E \\in {\\mathcal X}")#text(" and all n). For various technical reasons it is convenient to restrict to the case when the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Separable_sigma_algebra")[#text("separable")]#text(", i.e. countably generated. One reason for this is as follows:")

#strong[#text("Exercise 1.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" be a probability space with ")#mi("{\\mathcal X}")#text(" separable. Then the ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach spaces")]#text(" ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("L^p(X, {\\mathcal X}, \\mu)")]#text(" are ")#link("http://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(" (i.e. have a countable dense subset) for every ")#mi("1 \\leq p < \\infty")#text("; in particular, the ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space")]#text(" ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(" is separable. Show that the claim can fail for ")#mi("p = \\infty")#text(". (We allow the ")#mi("L^p")#text(" spaces to be either real or complex valued, unless otherwise specified.) ")#mi("\\diamond")

#strong[#text("Remark 1. ")]#text("In practice, the requirement that ")#mi("{\\mathcal X}")#text(" be separable is not particularly onerous. For instance, if one is studying the recurrence properties of a function ")#mi("f: X \\to {\\Bbb R}")#text(" on a non-separable measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(", one can restrict ")#mi("{\\mathcal X}")#text(" to the separable sub-")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}^{\\prime}")#text(" generated by the level sets ")#mi("\\{ x \\in X: T^n f(x) > q \\}")#text(" for integer n and rational q, thus passing to a separable measure-preserving system ")#mi("(X, {\\mathcal X}^{\\prime}, \\mu, T)")#text(" on which f is still measurable. Thus we see that in many cases of interest, we can immediately reduce to the separable case. (In particular, for many of the theorems in this course, the hypothesis of separability can be dropped, though we won’t bother to specify for which ones this is the case.) ")#mi("\\diamond")

#text("We are interested in the recurrence properties of sets ")#mi("E \\in {\\mathcal X}")#text(" or functions ")#mi("f \\in L^p(X, {\\mathcal X}, \\mu)")#text(". The simplest such recurrence theorem is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_recurrence_theorem")[#text("Poincaré recurrence theorem")]#text(") Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("E \\in {\\mathcal X}")#text(" be a set of positive measure. Then ")#mi("\\limsup_{n \\to +\\infty} \\mu( E \\cap T^n E ) \\geq \\mu(E)^2")#text(". In particular, ")#mi("E \\cap T^n E")#text(" has positive measure (and is thus non-empty) for infinitely many n.")
]

#text("(Compare with Theorem 1 of ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(".)")

#strong[#text("Proof.")]#text(" For any integer ")#mi("N > 1")#text(", observe that ")#mi("\\int_X \\sum_{n=1}^N 1_{T^n E}\\ d\\mu = N \\mu(E)")#text(", and thus by ")#link("http://en.wikipedia.org/wiki/Cauchy-Schwarz_inequality")[#text("Cauchy-Schwarz")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X (\\sum_{n=1}^N 1_{T^n E})^2\\ d\\mu \\geq N^2 \\mu(E)^2.")]]

#text("The left-hand side of (1) can be rearranged as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n=1}^N \\sum_{m=1}^N \\mu( T^n E \\cap T^m E ).")]]

#text("On the other hand, ")#mi("\\mu( T^n E \\cap T^m E) = \\mu( E \\cap T^{m-n} E )")#text(". From this one easily obtains the asymptotic")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(2)\\leq (\\limsup_{n \\to \\infty} \\mu( E \\cap T^n E ) + o(1)) N^2,")]]

#text("where o(1) denotes an expression which goes to zero as N goes to infinity. Combining (1), (2), (3) and taking limits as ")#mi("N \\to +\\infty")#text(" we obtain")

#mi("\\limsup_{n \\to \\infty} \\mu( E \\cap T^n E ) \\geq \\mu(E)^2")#text(" (4)")

#text("as desired. ")#mi("\\Box")

#strong[#text("Remark 2.")]#text(" In classical physics, the evolution of a physical system in a compact ")#link("http://en.wikipedia.org/wiki/Phase_space")[#text("phase space")]#text(" is given by a (continuous-time) measure-preserving system (this is ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamilton’s equations of motion")]#text(" combined with ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_%28Hamiltonian%29")[#text("Liouville’s theorem")]#text("). The Poincaré recurrence theorem then has the following unintuitive consequence: every collection E of states of positive measure, no matter how small, must eventually return to overlap itself given sufficient time. For instance, if one were to burn a piece of paper in a closed system, then there exist arbitrarily small perturbations of the initial conditions such that, if one waits long enough, the piece of paper will eventually reassemble (modulo arbitrarily small error)! This seems to contradict the ")#link("http://en.wikipedia.org/wiki/Second_Law_of_Thermodynamics")[#text("second law of thermodynamics")]#text(", but the reason for the discrepancy is because the time required for the recurrence theorem to take effect is inversely proportional to the measure of the set E, which in physical situations is exponentially small in the number of degrees of freedom (which is already typically quite large, e.g. of the order of the ")#link("http://en.wikipedia.org/wiki/Avogadro_constant")[#text("Avogadro constant")]#text("). This gives more than enough opportunity for ")#link("http://en.wikipedia.org/wiki/Maxwell%27s_demon")[#text("Maxwell’s demon")]#text(" to come into play to reverse the increase of entropy. (This can be viewed as a manifestation of the ")#link("http://en.wikipedia.org/wiki/Curse_of_dimensionality")[#text("curse of dimensionality")]#text(".) The more sophisticated recurrence theorems we will see later have much poorer quantitative bounds still, so much so that they basically have no direct significance for any physical dynamical system with many relevant degrees of freedom. ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Prove the following generalisation of the Poincaré recurrence theorem: if ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is a measure-preserving system and ")#mi("f \\in L^1(X, {\\mathcal X},\\mu)")#text(" is non-negative, then ")#mi("\\limsup_{n \\to +\\infty} \\int_X f T^n f \\geq (\\int_X f\\ d\\mu)^2")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Give examples to show that the quantity ")#mi("\\mu(E)^2")#text(" in the conclusion of Theorem 1 cannot be replaced by any larger quantity in general, regardless of the actual value of ")#mi("\\mu(E)")#text(". (Hint: use a Bernoulli system example.) ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Using the ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(" instead of the Cauchy-Schwarz inequality (and in particular, the statement that if ")#mi("\\mu(E_1) + \\ldots + \\mu(E_n) > 1")#text(", then the sets ")#mi("E_1,\\ldots,E_n")#text(" cannot all be disjoint), prove the weaker statement that for any set E of positive measure in a measure-preserving system, the set ")#mi("E \\cap T^n E")#text(" is non-empty for infinitely many n. (This exercise illustrates the general point that the Cauchy-Schwarz inequality can be viewed as a quantitative strengthening of the pigeonhole principle.) ")#mi("\\diamond")

#text("For this lecture and the next we shall study several variants of the Poincaré recurrence theorem. We begin by looking at the ")#link("http://en.wikipedia.org/wiki/Ergodic_theory#Mean_Ergodic_Theorem_.28Von_Neumann.27s_Ergodic_Theorem.29")[#text("mean ergodic theorem")]#text(", which studies the limiting behaviour of the ergodic averages ")#mi("\\frac{1}{N} \\sum_{n=1}^N T^n f")#text(" in various ")#mi("L^p")#text(" spaces, and in particular in ")#mi("L^2")#text(".")

#metadata(none) <tao-b4c3e9aa8c28edd4e2e9>

#heading(level: 1)[#text("— Hilbert space formulation —")]

#text("We begin with the Hilbert space formulation of the mean ergodic theorem, due to von Neumann.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Von Neumann ergodic theorem) Let ")#mi("U: H \\to H")#text(" be a ")#link("http://en.wikipedia.org/wiki/Unitary_operator")[#text("unitary")]#text(" operator on a separable Hilbert space H. Then for every ")#mi("v \\in H")#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lim_{N \\to +\\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} U^n v = \\pi(v),")]]

#text("where ")#mi("\\pi: H \\to H^U")#text(" is the ")#link("http://en.wikipedia.org/wiki/Orthogonal_projection")[#text("orthogonal projection")]#text(" from H to the closed subspace ")#mi("H^U := \\{ v \\in H: Uv = v \\}")#text(" consisting of the U-invariant vectors.")
]

#strong[#text("Proof.")]#text(" We give the slick (but not particularly illuminating) proof of Riesz. It is clear that (5) holds if v is already invariant (i.e. ")#mi("v \\in H^U")#text("). Next, let W denote the (possibly non-closed) space ")#mi("W := \\{ Uw - w: w \\in H \\}")#text(". If Uw-w lies in W and v lies in ")#mi("H^U")#text(", then by unitarity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\langle Uw-w, v \\rangle = \\langle w, U^{-1} v \\rangle - \\langle w, v \\rangle = \\langle w, v \\rangle - \\langle w, v \\rangle = 0")]]

#text("and thus W is orthogonal to ")#mi("H^U")#text(". In particular ")#mi("\\pi(Uw-w) = 0")#text(". From the ")#link("http://en.wikipedia.org/wiki/Telescoping_series")[#text("telescoping identity")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{1}{N} \\sum_{n=0}^{N-1} U^n (Uw - w) = \\frac{1}{N} (U^{N} w - w )")]]

#text("we conclude that (5) also holds if ")#mi("v \\in W")#text("; by linearity we conclude that (5) holds for all v in ")#mi("H^U + \\overline{W}")#text(". A standard limiting argument (using the fact that the linear transformations ")#mi("v \\mapsto \\pi(v)")#text(" and ")#mi("v \\mapsto \\frac{1}{N} \\sum_{n=0}^{N-1} U^n v")#text(" are bounded on H, uniformly in n) then shows that (5) holds for v in the closure ")#mi("\\overline{H^U + W}")#text(".")

#text("To conclude, it suffices to show that the closed space ")#mi("\\overline{H^U + W}")#text(" is all of H. Suppose for contradiction that this is not the case. Then there exists a non-zero vector w which is orthogonal to all of ")#mi("\\overline{H^U + W}")#text(". In particular, w is orthogonal to Uw – w. Applying the easily verified identity ")#tao-math("\\left\\| Uw-w\\right\\|^2 = -2 \\text{Re} \\langle Uw-w, w\\rangle", block: false)#text(" (related to the ")#link("http://en.wikipedia.org/wiki/Parallelogram_law")[#text("parallelogram law")]#text(") we conclude that Uw=w, thus w lies in ")#mi("H^U")#text(". This implies that w is orthogonal to itself and is thus zero, a contradiction. ")#mi("\\Box")

#text("On a measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(", the shift map ")#mi("f \\mapsto Tf")#text(" is a unitary transformation on the separable Hilbert space ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(". We conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (mean ergodic theorem) Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(". Then we have ")#mi("\\frac{1}{N} \\sum_{n=1}^N T^n f")#text(" converges in ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" norm to ")#mi("\\pi(f)")#text(", where ")#mi("\\pi(f): L^2(X,{\\mathcal X},\\mu) \\to L^2(X,{\\mathcal X},\\mu)^T")#text(" is the orthogonal projection to the space ")#mi("\\{ f \\in L^2(X,{\\mathcal X},\\mu): Tf =f \\}")#text(" consists of the shift-invariant functions in ")#mi("L^2(X, {\\mathcal X},\\mu)")#text(".")
]

#strong[#text("Example 4.")]#text(" (Finite case) Suppose that ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is a finite measure-preserving system, with ")#mi("{\\mathcal X}")#text(" discrete and ")#mi("\\mu")#text(" the uniform probability measure. Then T is a permutation on X and thus decomposes as the direct sum of disjoint cycles (possibly including trivial cycles of length 1). Then the shift-invariant functions are precisely those functions which are constant on each of these cycles, and the map ")#mi("f \\mapsto \\pi(f)")#text(" replaces a function ")#mi("f: X \\to {\\Bbb C}")#text(" with its average value on each of these cycles. It is then an instructive exercise to verify the mean ergodic theorem by hand in this case. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" With the notation and assumptions of Corollary 1, show that the limit ")#mi("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X T^n f \\overline{f}\\ d\\mu")#text(" exists, is real, and is greater than or equal to ")#tao-math("\\left|\\int_X f\\right|^2", block: false)#text(". (Hint: the constant function ")#mi("1")#text(" lies in ")#mi("L^2(X, {\\mathcal X}, \\mu)^T")#text(".) Note that this is stronger than the conclusion of Exercise 2. ")#mi("\\diamond")

#text("Let us now give some other proofs of the von Neumann ergodic theorem. We first give a proof (close to von Neumann’s original proof) using the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem ")]#text("for unitary operators. This theorem asserts (among other things) that a unitary operator ")#mi("U: H \\to H")#text(" can be expressed in the form ")#mi("U = \\int_{S^1} \\lambda\\ d\\mu(\\lambda)")#text(", where ")#tao-math("S^1 := \\{ z \\in {\\Bbb C}: \\left|z\\right|=1\\}", block: false)#text(" is the unit circle and ")#mi("\\mu")#text(" is a projection-valued Borel measure on the circle. More generally, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("U^n = \\int_{S^1} \\lambda^n\\ d\\mu(\\lambda)")]]

#text("and so for any vector v in H and any positive integer N")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{1}{N} \\sum_{n=0}^{N-1} U^n v = \\int_{S^1} \\frac{1}{N} \\sum_{n=0}^{N-1} \\lambda^n\\ d\\mu(\\lambda) v.")]]

#text("We separate off the ")#mi("\\lambda=1")#text(" portion of this integral. For ")#mi("\\lambda \\neq 1")#text(", we have the ")#link("http://en.wikipedia.org/wiki/Geometric_series")[#text("geometric series ")]#text("formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{1}{N} \\sum_{n=0}^{N-1} \\lambda^n = \\frac{1}{N} \\frac{\\lambda^{N}-1}{\\lambda-1}")]]

#text("(compare with (7)), thus we can rewrite (9) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\mu(\\{1\\}) v + \\int_{S^1 \\backslash \\{1\\}} \\frac{1}{N} \\frac{\\lambda^{N}-1}{\\lambda-1}\\ d\\mu(\\lambda) v.")]]

#text("Now observe (using (10)) that ")#mi("\\frac{1}{N} \\frac{\\lambda^{N}-1}{\\lambda-1}")#text(" is bounded in magnitude by 1 and converges to zero as ")#mi("N \\to \\infty")#text(" for any fixed ")#mi("\\lambda \\neq 1")#text(". Applying the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" (which requires a little bit of justification in this vector-valued case), we see that the second term in (11) goes to zero as ")#mi("N \\to \\infty")#text(". So we see that (9) converges to ")#mi("\\mu(\\{1\\}) v")#text(". But ")#mi("\\mu(\\{1\\})")#text(" is just the orthogonal projection to the eigenspace of U with eigenvalue 1, i.e. the space ")#mi("H^U")#text(", thus recovering the von Neumann ergodic theorem. (It is instructive to use spectral theory to interpret Riesz’s proof of this theorem and see how it relates to the argument just given.)")

#strong[#text("Remark 3. ")]#text(" The above argument in fact shows that the rate of convergence in the von Neumann ergodic theorem is controlled by the ")#link("http://en.wikipedia.org/wiki/Spectral_gap")[#text("spectral gap")]#text(" of U – i.e. how well-separated the trivial component ")#mi("\\{1\\}")#text(" of the spectrum is from the rest of the spectrum. This is one of the reasons why results on spectral gaps of various operators are highly prized. ")#mi("\\diamond")

#text("We now give another proof of Theorem 2, based on the ")#emph[#text("energy decrement method")]#text("; this proof is significantly lengthier, but is particularly well suited for conversion to finitary quantitative settings. For any positive integer N, define the averaging operators ")#mi("A_N := \\frac{1}{N} \\sum_{n=0}^{N-1} U^n")#text("; by the ")#link("http://en.wikipedia.org/wiki/Triangle_inequality")[#text("triangle inequality")]#text(" we see that ")#tao-math("\\left\\| A_N v \\right\\| \\leq \\left\\|v\\right\\|", block: false)#text(" for all v. Now we observe")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Lack of uniformity implies energy decrement) Suppose ")#tao-math("\\left\\| A_N v \\right\\| \\geq \\varepsilon", block: false)#text(". Then ")#tao-math("\\left\\| v - A_N^* A_N v \\right\\|^2 \\leq \\left\\|v\\right\\|^2 - \\varepsilon^2", block: false)#text(".")
]

#strong[#text("Proof.")]#text(" This follows from the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| v - A_N^* A_N v \\right\\|^2 = \\left\\|v\\right\\|^2 - 2 \\left\\|A_N v \\right\\|^2 + \\left\\| A_N^* A_N v \\right\\|^2", block: true)]]

#text("and the fact that ")#mi("A_N^*")#text(" has operator norm at most 1. ")#mi("\\Box")

#text("We now iterate this to obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Koopman-von Neumann type theorem) Let v be a unit vector, let ")#mi("\\varepsilon > 0")#text(", and let ")#mi("1 < N_1 < N_2 < \\ldots < N_J")#text(" be a sequence of integers with ")#mi("J > 1/\\varepsilon^2 + 2")#text(". Then there exists ")#mi("1 \\leq j < J")#text(" and a decomposition ")#mi("v = s + r")#text(" where ")#tao-math("\\left\\| Us - s\\right\\| = O( J \\frac{1}{N_{j+1}} )", block: false)#text(" and ")#tao-math("\\left\\| A_N r \\right\\| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\geq N_j")#text(".")
]

#text("(The letters s, r stand for “structured” and “random” (or “residual”) respectively. For more on decompositions into structured and random components, see my ")#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/")[#text("FOCS lecture notes")]#text(".)")

#text("Proof. We perform the following algorithm:")

#enum(start: 1, 
[#text("Initialise j := J-1, s := 0, and r := v.")],
[#text("If ")#tao-math("\\left\\| A_N r \\right\\| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\geq N_j")#text(" then STOP. If instead ")#tao-math("\\left\\|A_N r \\right\\| > \\varepsilon", block: false)#text(" for some ")#mi("N \\geq N_j")#text(", observe from Lemma 1 that ")#tao-math("\\left\\| r - A_N^* A_N r \\right\\|^2 \\leq \\left\\|r\\right\\|^2 - \\varepsilon^2", block: false)#text(".")],
[#text("Replace r with ")#mi("r - A_N^* A_N r")#text(", replace s with ")#mi("s + A_N^* A_N r")#text(", and replace j with j-1. Then return to Step 2.")]
)

#text("Observe that this procedure must terminate in at most ")#mi("1/\\varepsilon^2")#text(" steps (since the energy ")#tao-math("\\left\\|r\\right\\|^2", block: false)#text(" starts at 1, drops by at least ")#mi("\\varepsilon^2")#text(" at each stage, and cannot go below zero). In particular, j stays positive. Observe also that r always has norm at most 1, and thus ")#tao-math("\\left\\| (U - I) A_N^* A_N r \\right\\| = O( 1/N )", block: false)#text(" at any given stage of the algorithm. From this and the triangle inequality one easily verifies the required claims. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" (partial von Neumann ergodic theorem). For any vector v, the averages ")#mi("A_N v")#text(" form a Cauchy sequence in H.")
]

#strong[#text("Proof.")]#text(" Without loss of generality we can take v to be a unit vector. Suppose for contradiction that ")#mi("A_N v")#text(" was not Cauchy. Then one could find ")#mi("\\varepsilon > 0")#text(" and ")#mi("1 < N_1 < M_1 < N_2 < M_2 < \\ldots")#text(" such that ")#tao-math("\\left\\|A_{N_j} v - A_{M_j} v \\right\\| \\geq 5 \\varepsilon", block: false)#text(" (say) for all j. By sparsifying the sequence if necessary we can assume that ")#mi("N_{j+1}")#text(" is large compared to ")#mi("N_j")#text(", ")#mi("M_j")#text(" and ")#mi("\\varepsilon")#text(". Now we apply Proposition 1 to find ")#mi("j = O_\\varepsilon(1)")#text(" and a decomposition v = s + r such that ")#tao-math("\\left\\|Us-s\\right\\| = O_\\varepsilon( 1 / N_{j+1} )", block: false)#text(" and ")#tao-math("\\left\\| A_{N_j} r \\right\\|, \\left\\|A_{M_j} r \\right\\| \\leq \\varepsilon", block: false)#text(". If ")#mi("N_{j+1}")#text(" is large enough depending on ")#mi("N_j, M_j, \\varepsilon")#text(", we thus have ")#tao-math("\\left\\|A_{N_j} s - s\\right\\|, \\left\\|A_{M_j} s - s \\right\\| \\leq \\varepsilon", block: false)#text(", and thus by the triangle inequality, ")#tao-math("\\left\\|A_{N_j} v - A_{M_j} v \\right\\| \\leq 4 \\varepsilon", block: false)#text(", a contradiction. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" This result looks weaker than Theorem 2, but the argument is much more robust; for instance, one can modify it to establish convergence of multiple averages such as ")#mi("\\frac{1}{N} \\sum_{n=1}^N T_1^n f_1 T_2^n f_2 T_3^n f_3")#text(" in ")#mi("L^p")#text(" norms for commuting shifts ")#mi("T_1, T_2, T_3")#text(", which does not seem possible using the other arguments given here; see this ")#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("paper of mine")]#text(" for details. Further quantitative analysis of the mean ergodic theorem can be found in ")#link("http://arxiv.org/abs/0706.1512")[#text("this paper of Avigad, Gerhardy, and Towsner")]#text(". ")#mi("\\diamond")

#text("Corollary 2 can be used to recover Theorem 2 in its full strength, by combining it with a weak form of Theorem 2:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" (Weak von Neumann ergodic theorem) The conclusion (5) of Theorem 2 holds in the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak topology")]#text(".")
]

#strong[#text("Proof.")]#text(" The averages ")#mi("A_N v")#text(" lie in a bounded subset of the separable Hilbert space H, and are thus precompact in the weak topology by the sequential ")#link("http://en.wikipedia.org/wiki/Banach-Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(". Thus, if (5) fails, then there exists a subsequence ")#mi("A_{N_j} v")#text(" which converges in the weak topology to some limit w other than ")#mi("\\pi(v)")#text(". By telescoping series we see that ")#tao-math("\\left\\| U A_{N_j} v - A_{N_j} v \\right\\| \\leq 2 \\left\\|v\\right\\|/N_j", block: false)#text(", and so on taking limits we see that ")#tao-math("\\left\\|Uw - w\\right\\|=0", block: false)#text(", i.e. ")#mi("w \\in H^U")#text(". On the other hand, if y is any vector in ")#mi("H^U")#text(", then ")#mi("A_{N_j}^* y = y")#text(", and thus on taking inner products with v we obtain ")#mi("\\langle y, A_{N_j} v \\rangle = \\langle y, v \\rangle")#text(". Taking limits we obtain ")#mi("\\langle y, w \\rangle = \\langle y, v \\rangle")#text(", i.e. v-w is orthogonal to ")#mi("H^U")#text(". These facts imply that ")#mi("w = \\pi(v)")#text(", giving the desired contradiction. ")#mi("\\Box")

#heading(level: 1)[#text("— Conditional expectation —")]

#text("We now turn away from the abstract Hilbert approach to the ergodic theorem (which is excellent for proving the mean ergodic theorem, but not flexible enough to handle more general ergodic theorems) and turn to a more measure-theoretic dynamics approach, based on manipulating the four components ")#mi("X, {\\mathcal X}, \\mu, T")#text(" of the underlying system separately, rather than working with the single object ")#mi("L^2( X, {\\mathcal X}, \\mu)")#text(" (with the unitary shift T). In particular it is useful to replace the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" by a sub-")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}^{\\prime} \\subset {\\mathcal X}")#text(", thus reducing the number of measurable functions. This creates an isometric embedding of Hilbert spaces")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("L^2( X, {\\mathcal X}^{\\prime}, \\mu) \\subset L^2( X, {\\mathcal X}, \\mu)")]]

#text("and so the former space is a closed subspace of the latter. In particular, we have an orthogonal projection ")#mi("{\\Bbb E}( \\cdot|{\\mathcal X}^{\\prime}): L^2( X, {\\mathcal X}, \\mu) \\to L^2( X, {\\mathcal X}^{\\prime}, \\mu)")#text(", which can be viewed as the adjoint of the inclusion (13). In other words, for any ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(", ")#mi("{\\Bbb E}(f|{\\mathcal X}^{\\prime})")#text(" is the unique element of ")#mi("L^2(X, {\\mathcal X}^{\\prime},\\mu)")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\int_X {\\Bbb E}(f|{\\mathcal X}^{\\prime}) \\overline{g}\\ d\\mu = \\int_X f \\overline{g}\\ d\\mu")]]

#text("for all ")#mi("g \\in L^2(X, {\\mathcal X}^{\\prime}, \\mu)")#text(". (A reminder: when dealing with ")#mi("L^p")#text(" spaces, we identify any two functions which agree ")#mi("\\mu")#text("-almost everywhere. Thus, technically speaking, elements of ")#mi("L^p")#text(" spaces are not actually functions, but rather equivalence classes of functions.)")

#strong[#text("Example 5")]#text(". (Finite case) Let X be a finite set, thus ")#mi("{\\mathcal X}")#text(" can be viewed as a partition of X, and ")#mi("{\\mathcal X}^{\\prime} \\subset {\\mathcal X}")#text(" is a coarser partition of X. To avoid degeneracies, assume that every point in X has positive measure with respect to ")#mi("\\mu")#text(". Then an element f of ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(" is just a function ")#mi("f: X \\to {\\Bbb C}")#text(" which is constant on each atom of ")#mi("{\\mathcal X}")#text(". Similarly for ")#mi("L^2(X, {\\mathcal X}^{\\prime}, \\mu)")#text(". The conditional expectation ")#mi("{\\Bbb E}(f|{\\mathcal X}^{\\prime})")#text(" is then the function whose value on each atom A of ")#mi("{\\mathcal X}^{\\prime}")#text(" is equal to the average value ")#mi("\\frac{1}{\\mu(A)} \\int_A f\\ d\\mu")#text(" on that atom. (What needs to be changed here if some points have zero measure?) ")#mi("\\diamond")

#text("We leave the following standard properties of conditional expectation as an exercise.")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" be a probability space, and let ")#mi("{\\mathcal X}^{\\prime}")#text(" be a sub-")#mi("\\sigma")#text("-algebra. Let ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(".")

#enum(start: 1, 
[#text("The operator ")#mi("f \\mapsto {\\Bbb E}( f|{\\mathcal X^{\\prime}})")#text(" is a bounded self-adjoint projection on ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(". It maps real functions to real functions, it preserves constant functions (and more generally preserves ")#mi("{\\mathcal X^{\\prime}}")#text("-measurable functions), and commutes with complex conjugation.")],
[#text("If f is non-negative, then ")#mi("{\\Bbb E}( f|{\\mathcal X^{\\prime}})")#text(" is non-negative (up to sets of measure zero, of course). More generally, we have a ")#emph[#text("comparison principle")]#text(": if f, g are real-valued and ")#mi("f \\leq g")#text(" pointwise a. e., then ")#mi("{\\Bbb E}( f|{\\mathcal X^{\\prime}}) \\leq {\\Bbb E}( g|{\\mathcal X^{\\prime}})")#text(" a.e. Similarly, we have the ")#emph[#text("triangle inequality ")]#tao-math("\\left|{\\Bbb E}( f|{\\mathcal X^{\\prime}})\\right| \\leq {\\Bbb E}( \\left|f\\right||{\\mathcal X^{\\prime}})", block: false)#text(" a.e..")],
[#text("(Module property) If ")#mi("g \\in L^\\infty(X, {\\mathcal X}^{\\prime}, \\mu)")#text(", then ")#mi("{\\Bbb E}( f g|{\\mathcal X^{\\prime}}) = {\\Bbb E}( f|{\\mathcal X^{\\prime}}) g")#text(" a.e..")],
[#text("(Contraction) If ")#mi("f \\in L^2(X, {\\mathcal X},\\mu) \\cap L^p(X, {\\mathcal X},\\mu)")#text(" for some ")#mi("1 \\leq p \\leq \\infty")#text(", then ")#tao-math("\\left\\|{\\Bbb E}(f|{\\mathcal X^{\\prime}})\\right\\|_{L^p} \\leq \\left\\|f\\right\\|_{L^p}", block: false)#text(". (Hint: do the p=1 and ")#mi("p=\\infty")#text(" cases first.) This implies in particular that conditional expectation has a unique continuous extension to ")#mi("L^p(X, {\\mathcal X},\\mu)")#text(" for ")#mi("1 \\leq p \\leq \\infty")#text(" (the ")#mi("p=\\infty")#text(" case is exceptional, but note that ")#mi("L^\\infty")#text(" is contained in ")#mi("L^2")#text(" since ")#mi("\\mu")#text(" is finite). ")#mi("\\diamond")]
)

#text("For applications to ergodic theory, we will only be interested in taking conditional expectations with respect to a ")#emph[#text("shift-invariant")]#text(" sub-")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X^{\\prime}}")#text(", thus ")#mi("T")#text(" and ")#mi("T^{-1}")#text(" preserve ")#mi("{\\mathcal X^{\\prime}}")#text(". In that case T preserves ")#mi("L^2(X,{\\mathcal X}^{\\prime},\\mu)")#text(", and thus T commutes with conditional expectation, or in other words that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("{\\Bbb E}( T^n f | {\\mathcal X}^{\\prime} ) = T^n {\\Bbb E}( f | {\\mathcal X}^{\\prime} )")]]

#text("a.e. for all ")#mi("f \\in L^2(X,{\\mathcal X}, \\mu)")#text(" and all n.")

#text("Now we connect conditional expectation to the mean ergodic theorem. Let ")#mi("{\\mathcal X}^T := \\{ E \\in {\\mathcal X}: TE = E \\text{ a.e.} \\}")#text(" be the set of essentially shift-invariant sets. One easily verifies that this is a shift-invariant sub-")#mi("\\sigma")#text("-algebra of ")#mi("{\\mathcal X}")#text(".")

#strong[#text("Exercise 7.")]#text(" Show that if E lies in ")#mi("{\\mathcal X}^T")#text(", then there exists a set ")#mi("F \\in {\\mathcal X}")#text(" which is genuinely invariant (TF=F) and which differs from E only by a set of measure zero. Thus it does not matter whether we deal with shift-invariance or essential shift-invariance here. (More generally, it will not make any significant difference if we modify any of the sets in our ")#mi("\\sigma")#text("-algebras by null sets.) ")#mi("\\diamond")

#text("The relevance of this algebra to the mean ergodic theorem arises from the following identity:")

#strong[#text("Exercise 8. ")]#text("Show that ")#mi("L^2( X, {\\mathcal X}, \\mu)^T = L^2( X, {\\mathcal X}^T, \\mu)")#text(". ")#mi("\\diamond")

#text("As a corollary of this and Corollary 1, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2. ")]#text("(Mean ergodic theorem, again) Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system. Then for any ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(", the averages ")#mi("\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f")#text(" converge in ")#mi("L^2")#text(" norm to ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)")#text(".")
]

#strong[#text("Exercise 9. ")]#text("Show that Corollary 2 continues to hold if ")#mi("L^2")#text(" is replaced throughout by ")#mi("L^p")#text(" for any ")#mi("1 \\leq p < \\infty")#text(". (Hint: for the case ")#mi("p<2")#text(", use that ")#mi("L^2")#text(" is dense in ")#mi("L^p")#text(". For the case ")#mi("p>2")#text(", use that ")#mi("L^\\infty")#text(" is dense in ")#mi("L^p")#text(".) What happens when ")#mi("p = \\infty")#text("? ")#mi("\\diamond")

#text("Let us now give another proof of Corollary 2 (leading to a fourth proof of the mean ergodic theorem). The key here will be the decomposition ")#mi("f = f_{U^\\perp} + f_U")#text(", where ")#mi("f_{U^\\perp} := {\\Bbb E}(f|{\\mathcal X}^T)")#text(" is the “structured” part of f (at least as far as the mean ergodic theorem is concerned) and ")#mi("f_U := f - f_{U^\\perp}")#text(" is the “random” part. (The subscripts ")#mi("U^\\perp, U")#text(" stand for “anti-uniform” and “uniform” respectively; this notation is not standard.) As ")#mi("f_{U^\\perp}")#text(" is shift-invariant, we clearly have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f_{U^\\perp} = f_{U^\\perp}")]]

#text("so it suffices to show that")

#align(center)[#tao-math("\\left\\| \\frac{1}{N} \\sum_{n=0}^{N-1} T^n f_U \\right\\|_{L^2}^2 \\to 0", block: false)#text(" (17)")#linebreak()#text(" as ")#mi("N \\to \\infty")#text(". But we can expand out the left-hand side (using the unitarity of T) as")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\langle F_N, f_U \\rangle := \\int_X F_N \\overline{f_U}\\ d\\mu")]]

#text("where ")#mi("F_N")#text(" is the ")#emph[#text("dual function")]#text(" of f_U, defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("F_N := \\frac{1}{N^2} \\sum_{n=0}^{N-1} \\sum_{m=0}^{N-1} T^{n-m} f_U.")]]

#text("Now, from the triangle inequality we know that the sequence of dual functions ")#mi("F_N")#text(" is uniformly bounded in ")#mi("L^2")#text(" norm, and so by Cauchy-Schwarz we know that the inner products ")#mi("\\langle F_N, f_U \\rangle")#text(" are bounded. If they converge to zero, we are done; otherwise, by the ")#link("http://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(", we have ")#mi("\\langle F_{N_j}, f_U \\rangle \\to c")#text(" for some subsequence ")#mi("N_j")#text(" and some non-zero c.")#linebreak()#text(" (One could also use ultrafilters instead of subsequences here if desired, it makes little difference to the argument.) By the ")#link("http://en.wikipedia.org/wiki/Banach-Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(" (or more precisely, the sequential version of this in the separable case), there is a further subsequence ")#mi("F_{N^{\\prime}_j}")#text(" which converges ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weakly")]#text(" (or equivalently in this Hilbert space case, in the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak-* sense")]#text(") to some limit ")#mi("F_\\infty \\in L^2(X, {\\mathcal X}, \\mu)")#text(". Since c is non-zero, ")#mi("F_\\infty")#text(" must also be non-zero. On the other hand, from telescoping series one easily computes that ")#tao-math("\\left\\| T F_N - F_N\\right\\|_{L^2}", block: false)#text(" decays like O(1/N) as ")#mi("N \\to \\infty")#text(", so on taking limits we have ")#mi("T F_\\infty - F_\\infty = 0")#text(". In other words, ")#mi("F_\\infty")#text(" lies in ")#mi("L^2(X, {\\mathcal X}^T, \\mu)")#text(".")

#text("On the other hand, by construction of ")#mi("f_U")#text(" we have ")#mi("{\\Bbb E}(f_U|{\\mathcal X}^T) = 0")#text(". From (15) and linearity we conclude that ")#mi("{\\Bbb E}(F_N|{\\mathcal X}^T) = 0")#text(" for all N, so on taking limits we have ")#mi("{\\Bbb E}(F_\\infty|{\\mathcal X}^T) = 0")#text(". But since ")#mi("F_\\infty")#text(" is already in ")#mi("L^2(X, {\\mathcal X}^T, \\mu)")#text(", we conclude ")#mi("F_\\infty=0")#text(", a contradiction.")

#strong[#text("Remark 5. ")]#text("This argument is lengthier than some of the other proofs of the mean ergodic theorem, but it turns out to be fairly robust; it demonstrates (using the compactness properties of certain “dual functions”) that a function ")#mi("f_U")#text(" with sufficiently strong “mixing” properties (in this case, we require that ")#mi("{\\Bbb E}(f_U | {\\mathcal X}^T) = 0")#text(") will cancel itself out when taking suitable ergodic averages, thus reducing the study of averages of f to the study of averages of ")#mi("f_U = {\\Bbb E}(f|{\\mathcal X}^T)")#text(". In the modern jargon, this means that ")#mi("{\\mathcal X}^T")#text(" is (the ")#mi("\\sigma")#text("-algebra induced by) a characteristic factor of the ergodic average ")#mi("f \\mapsto \\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N T^n f")#text(". We will see further examples of characteristic factors for other averages later in this course. ")#mi("\\diamond")

#strong[#text("Exercise 10. ")]#text(" Let ")#mi("(\\Gamma,\\cdot)")#text(" be a countably infinite discrete group. A ")#emph[#text("Følner sequence")]#text(" is a sequence of increasing finite non-empty sets ")#mi("F_n")#text(" in ")#mi("\\Gamma")#text(" with ")#mi("\\bigcup_n F_n = \\Gamma")#text(" with the property that for any given finite set ")#mi("S \\subset \\Gamma")#text(", we have ")#tao-math("\\left|(F_n \\cdot S) \\Delta F_n\\right|/\\left|F_n\\right| \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(", where ")#mi("F_n \\cdot S := \\{ fs: f \\in F_n, s \\in S\\}")#text(" is the product set of ")#mi("F_n")#text(" and S, ")#tao-math("\\left|F_n\\right|", block: false)#text(" denotes the cardinality of ")#mi("F_n")#text(", and ")#mi("\\Delta")#text(" denotes ")#link("http://en.wikipedia.org/wiki/Symmetric_difference")[#text("symmetric difference")]#text(". (For instance, in the case ")#mi("\\Gamma = {\\Bbb Z}")#text(", the sequence ")#mi("F_n := \\{-n,\\ldots,n\\}")#text(" is a Følner sequence.) If ")#mi("\\Gamma")#text(" acts (on the left) in a measure-preserving manner on a probability space ")#mi("(X, {\\mathcal X}, \\mu)")#text(", and ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(", show that ")#tao-math("\\frac{1}{\\left|F_n\\right|} \\sum_{\\gamma \\in F_n} f \\circ \\gamma^{-1}", block: false)#text(" converges in ")#mi("L^2")#text(" to ")#mi("{\\Bbb E}(f|{\\mathcal X}^\\Gamma)")#text(", where ")#mi("{\\mathcal X}^\\Gamma")#text(" is the collection of all measurable sets which are ")#mi("\\Gamma")#text("-invariant modulo null sets, and ")#mi("f \\circ \\gamma^{-1}")#text(" is the function ")#mi("x \\mapsto f(\\gamma^{-1} x)")#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 30: exercise corrected, another exercise added.]")

#text("[")#emph[#text("Update")]#text(", Feb 1: Some corrections.]")

#text("[")#emph[#text("Update")]#text(", Feb 4: Ergodic averages changed to sum over 0 to N-1 rather than over 1 to N.]")

#text("[")#emph[#text("Update")]#text(", Feb 11: Discussion of the ergodic theorem in weak topologies (Proposition 2) added.]")

#text("[")#emph[#text("Update")]#text(", Feb 21: Exercise 10 corrected.]")

#text("[")#emph[#text("Update,")]#text(" Mar 31: Exercise 5 corrected.]")

#text("[")#emph[#text("Update")]#text(", Jun 14: Some corrections.]")

#heading(level: 1)[#text("Comments (69)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-506778")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2018")])]

#text("Unfortunately, there seems to have been a flaw in my argument, but I believe also that I see how it may be corrected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-506779")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2018")])]

#text("Apparently, the “slick” proof is the best way forward, because it seems as though no matter what, one needs to exploit the dychotomy between being in the invariant space and being orthogonal to it. Too bad that that one computation I made is not valid…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34fe015f817c3dd9340e17ae98f385ad85553e8fae28b7e209cd250dd2ae2be2-8b01185168223e4ad9252c8b2ed32a764301b1857342b7a775e7feca84563a87.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-607334")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Dear professor")

#text("I read your proof of theorem 1, and I have one question. Why inequality (3) is true?. I have tried to prove it using intuition, that the greatest element of a given set is greater than arithmetic mean of this set. I would be grateful if you gave me at least a hint.")

#text("Regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-607978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("Hint: For any ")#mi("\\varepsilon>0")#text(" one has ")#mi("M > 0")#text(" such that ")#tao-math("\\mu(T^n E \\cap T^m E) = \\mu(E \\cap T^{\\left|n-m\\right|} E) \\leq \\limsup_{n \\to\\infty} \\mu(E \\cap T^n E) + \\varepsilon", block: false)#text(" for all ")#mi("n,m")#text(" except possibly for those pairs for which ")#tao-math("\\left|n-m\\right| \\leq M", block: false)#text(", for which one can instead use the trivial bound ")#mi("\\mu(T^n E \\cap T^m E) \\leq 1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-684490")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2024")])]

#text("For exercise 1, I used that we have a sigma-finite space and not a probability space, I am wondering if I made a mistake.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-687509")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2025")])]

#text("I never realized that the CS inequality can be contrasted with the pigeonhole principle in a way suggested by Exercise 4 and the ensuing discussion.")

#text("This makes me feel like asking for two things:")

#mi("\\bullet")#text(" 1. We observe that ")#linebreak()#text("if one uses the principle of inclusion and exclusion in place of the pigeonhole principle then one can also show the slightly stronger result that ")#mi("\\mu (T^n E \\cap E) > 0")#text(" for infinitely many ")#mi("n")

#text("I wonder if this highlights anything about where the inclusion-exclusion principle stands when compared against the pigeonhole principle and the Cauchy-Schwarz inequality.")

#mi("\\bullet")#text(" 2. Is there a more direct way to see how the Cauchy Schwarz inequality is a quantitative strengthening of the pigeonhole principle?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-687510")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2025")])]

#text("I think we can see Riesz’s proof of the von Neumann ergodic theorem as a rigorous version of the following loose justification for believing that the claim is true.")#linebreak()#text("We write ")#mi("v")#text(" as ")#mi("v = v_U + v_{U^{\\perp}}")#text(" where ")#mi("v_U")#text(" is in ")#mi("H^U")#text(" and ")#mi("v_{U^{\\perp}}")#text(" is in the orthogonal complement of ")#mi("H^U")#text(" (we know that every v has a unique representation of this form).")#linebreak()#text("Now since ")#mi("U")#text(" is a unitary transformation so the vectors ")#mi("U^n(v_{U^{\\perp}})")#text(" can be thought of as a collection of rotated copies of ")#mi("v_{U^{\\perp}}")#text(" or at least we have a reason to expect that the sum ")#mi("\\sum_{n=1}^{N} U^n (v_{U^{\\perp}})")#text(" grows like the sum $latex ")#mi("\\sum_{n=1}^{N} \\text{rot}_{\\theta} ^n (v_{U^{\\perp}})")#text(" for some angle ")#mi("\\theta")#text(" where the rot function rotates the vector by the angle ")#mi("\\theta")#text(".")#linebreak()#text("But this sum is like ")#tao-math("\\left|\\left|v_{U^{\\perp}} \\right|\\right|", block: false)#text(" times a sum N ")#mi("e^{i\\theta (\\cdot)}")#text(" s and so when we divide by ")#mi("N")#text(" and send ")#mi("N")#text(" to infinity the ratio (sum/N) should go to 0.")

#text("So in ")#mi("\\frac{1}{N} \\sum_{n=1}^{N} U^n (v)")#text(" when we send ")#mi("N \\to \\infty")#text(" we shall be left with ")#mi("\\frac{1}{N} \\sum_{n=1}^{N} U^n (v_U)")#text(" but each summand is just ")#mi("\\pi (v)")#text(" and so we (must) believe the claim.")

#text("(PS: I won’t say that this makes Riesz’s proof less non-illuminating because the proof does not give us any by product, but I think it does make it more natural.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An intuitive derivation of Riesz’s proof of von Neumann’s ergodic theorem | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-687512")[#strong[#text("An intuitive derivation of Riesz’s proof of von Neumann’s ergodic theorem | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2025")])]

#text("[…] I present an intuitive derivation of Riesz’s proof of von Neumann’s ergodic theorem (see this blogpost by Terence Tao). Along the way, I also discuss general strategies for devising proofs or solutions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-692667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2026")])]

#text("Dr Tao: I am not an expert in measure theory, so I’m a bit lost by your description of conditional expectation, especially that you just glossed over this: Why is it an ")#emph[#text("orthogonal projection")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-2/#comment-692678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2026")])]

#text("I am ")#link("https://claude.ai/share/def8cc02-ef2c-4610-985f-28d569649cf7")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25177")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("Hi Terry: you’re missing a \\sum in Exercise 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25179")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("Thanks, Lior, for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25184")[#strong[#text("Hao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("Dear Terry,")

#text("My friend asked me a question this afternoon: Do the digits of the decimal expansion of \\pi contains all finite patterns?")

#text("I tried to use ergodic theory and only got that the decimal expansion of almost every numbers in [0,1] contains all patterns. (and every pattern has the expected limiting frequency).")

#text("I know that whether \\pi is normal is still an open problem (I am not sure whether someone has proven \\pi is 10-normal. But at least for 2-normal, it’s open.). But is there any method to prove my weaker proposition? Is there any theorems in ergodic theory describing whether the orbit of a specific point is dense?")

#text("Thanks for reading my comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25203")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2008")])]

#text("You mean “Avogadro (constant)” instead of “Avagadro” in Remark 2, I suppose…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25224")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2008")])]

#text("Dear Hao: This problem is likely to be extremely difficult with current technology. Basically, because there do exist (uncountably many) numbers in [0,1] which do not contain all digit patterns, one is going to have to use some special property of ")#mi("\\pi")#text(" which is not satisfied by those other numbers. In particular, this special property should allow one to obtain non-trivial control on the fractional parts of ")#mi("10^n \\pi")#text(" for large n. While there are some interesting formulae for these sorts of things (some of which are in fact used when computing the digits of ")#mi("\\pi")#text("), they do not seem to have a rich enough algebraic structure that we can use existing technology to control their distribution, either in the qualitative sense you ask (which is equivalent to the orbit of ")#mi("\\{ 10^n \\pi \\}")#text(" being dense) or in the more traditional sense of 10-normality (which is equivalent to the orbit being equidistributed).")

#text("More generally, the task of rigorously demonstrating pseudorandom behaviour from deterministic processes without much algebraic structure (such as the digit sequence of ")#mi("\\pi")#text(") is a very important class of problem to which we still do not have nearly enough tools to tackle. In the absence of algebraic structure, ergodic theory methods seem to require the injection of a little bit of randomness (e.g. replacing ")#mi("\\pi")#text(" by a randomly chosen number) before they can really say anything, and in any case this is probably too “soft” of a tool for the problem at hand, which needs to fully exploit the structure of ")#mi("\\pi")#text(". (Incidentally, I would start with ")#mi("\\sqrt{2}")#text(" or the golden ratio instead of ")#mi("\\pi")#text(", and work base 2 or base 5 respectively, as there is a slightly better hope of detecting some exploitable structure, though even here it’s not clear how to proceed.)")

#text("Dear Pedro: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ben green")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25299")[#strong[#text("ben green")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2008")])]

#text("Terry, Hao")

#text("As Terry hints, there *are* some special properties of ")#mi("\\pi")#text(" which have to do with digits, though only in base 16 so far as I know and not in base 10. Specifically, there is the Borwein-Bailey-Plouffe algorithm, which has its own Wikipedia entry:")

#link("http://en.wikipedia.org/wiki/Bailey-Borwein-Plouffe_formula")[#text("http://en.wikipedia.org/wiki/Bailey-Borwein-Plouffe_formula")]

#text("This allows one to compute the ")#mi("n")#text("th hexadecimal digit of ")#mi("\\pi")#text(" without computing all the previous digits. It’s actually remarkably explicit, but just complicated enough to make one think twice about sitting down to try and prove that each hex digit of ")#mi("\\pi")#text(" occurs one sixteenth of the time. For example one seems to need to understand the distribution of ")#mi("16^{n-k}")#text(" modulo ")#mi("8k + 1")#text(" for ")#mi("k = 1,\\dots,n")#text(" and this already looks very tricky to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of orr")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25309")[#strong[#text("orr")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2008")])]

#text("I enjoy the posts in this course very much, thanks!")#linebreak()#text(" It looks like a very difficult course. I was wondering:")#linebreak()#text(" does every post like this one fit in a two hour lecture?")#linebreak()#text(" you must have exeptionially good students, if this is the pace.")#linebreak()#text(" It would be very interesting to hear from the students in the course")#linebreak()#text(" how it is.")

#text("BTW, I saw two typos:")#linebreak()#text(" 1. eq. 10, a minus sign in the denominator.")#linebreak()#text(" 2. proof of proposition 1, step 2 of the alg. – reverse an inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25312")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2008")])]

#text("Dear Orr: thanks for the corrections! The lecture notes are being posted somewhat asynchronously to the actual lectures; for instance, we are currently about halfway through Lecture 6 in the actual class. (Each notes takes about 1-2 classes to cover, though my lectures often do not correspond exactly with what is posted here.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 9: Ergodicity « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25473")[#strong[#text("254A, Lecture 9: Ergodicity « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2008")])]

#text("[…] as we derived the mean ergodic theorem from the more abstract von Neumann ergodic theorem in the previous lecture, we shall derive the maximal ergodic theorem from the following abstract maximal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-25932")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] 2 is trivial, while the k=2 case follows from the Poincaré recurrence theorem (Theorem 1 from Lecture 8). We will prove the higher k cases of this theorem in later lectures. In this one, we will explain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-26020")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("[…] we can normalise a.e.. By modifying each eigenfunction on a set of measure zero (cf. Exercise 7 of Lecture 8) we can assume that and everywhere rather than just almost everywhere. Then the map is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-26464")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Concerning Exercise 10, I am wondering whether the \\gamma^-1 in the summation should be replaced by \\gamma (replacing the group representation with an antirepresentation)?")

#text("(Otherwise, when averaging the images of f – f o \\gamma^-1 under the action of the Folner set, the fact that \\gamma^-1 is applied before the Folner set means that we’re taking the difference between F_n and its right coset, a ‘cancellation’ not allowed by our definition.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-26499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("Hmm, you’re right. I’ve flipped the definition of a Folner set to be near-invariant under right translations instead of left translations to address this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-26509")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("[…] so we only need to consider the case when n is positive. The mean ergodic theorem (Corollary 2 from Lecture 8) tells us the Cesàro behaviour of these coefficients. Indeed, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0ddfce9f9f08f406798d7b4de58f45b6f368b447009164f76844fb3ce8c3fa5-1b2d279fd3543fc06cf76e42fa7b6e8df832af294f05854a0427470590918394.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Diaz-Espinosa")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-26725")[#strong[#text("Oliver Diaz-Espinosa")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("Dear Terence,")

#text("I found this byproduct of the ergodic theory which can be used to prove the Shannon-MacMillan-Breiman theorem:")#linebreak()#text(" Let ")#mi("(X,\\mathcal{A},\\mu)")#text(" a probability space ")#mi("T")#text(" invariant.")#linebreak()#text(" ")#mi("f_n\\rightarrow f")#text(" a.s and in ")#mi("L_1")#linebreak()#text(" then")

#mi("\\frac1n \\sum^{n-1}_k f_{n-k}\\circ T^k \\rightarrow  \\tilde{f}")

#text("almost surely and in ")#mi("L_1")

#text("If ")#mi("f_n")#text(" is dominated, which occurs in many applications, it is relatively easy to prove the statement above. However, what happens is ")#mi("f_n")#text(" is not dominated?")#linebreak()#text(" A common reference to this result is the book af Ma\\~ne on ergodic theory. However, his argument in the non dominated case is shaky. Do you know if the almost surely convergence still holds in this case?")

#text("best")#linebreak()#text(" ode")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-26728")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("Dear Oliver,")

#text("It looks doubtful that almost sure convergence holds without a domination assumption. Consider for instance a finitary counterpart in which X is the cyclic system ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" with uniform measure and shift ")#mi("T: x \\mapsto x+1")#text(", and let ")#mi("f_n")#text(" be ")#mi("\\varepsilon N")#text(" times the Kronecker delta function at ")#mi("-n")#text(" for ")#mi("0 \\leq n \\leq \\varepsilon N")#text(" (with ")#mi("f_n=0")#text(" for all other n), thus each function has an ")#mi("L^1")#text(" norm of ")#mi("\\varepsilon")#text(". Then for each ")#mi("x \\in X")#text(", the averages ")#mi("\\frac{1}{n} \\sum_{k=0}^{n-1} f_{n-k} \\circ T^k(x)")#text(" get as large as ")#mi("\\varepsilon^2 N")#text(" for some ")#mi("\\varepsilon N < n < N")#text(", despite the fact that the functions have small L^1 norm and vanish outside of a set ")#mi("\\{0,-1,\\ldots,-\\varepsilon N\\}")#text(" of small measure. I would imagine that by taking a suitable combination of infinitely many copies of this example (with N going off to infinity and ")#mi("\\varepsilon")#text(" going slowly to zero) one could obtain a counterexample to your claim.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sugata")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-27780")[#strong[#text("sugata")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("sir,")#linebreak()#text(" in exc.5,there are some problems i suppose.first of all,f is not real,so the limit is ‘greater than or equal to’ does not make any sense.also,if we take f in the orthogonal complement of the subspace itself then the limit is zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-27803")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Dear sugata,")

#text("Thanks for the comments. I corrected ")#mi("(\\int_X f)^2")#text(" to ")#tao-math("\\left|\\int_X f\\right|^2", block: false)#text(". Note though that if f is in the orthogonal complement of ")#mi("L^2(X,{\\mathcal X},\\mu)^T")#text(" then ")#mi("\\int_X f")#text(" is zero too (since f is orthogonal to 1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-30294")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2008")])]

#text("Dear Professor 陶：")#linebreak()#text(" I’ve got several corrections( if I am right):")#linebreak()#text(" 1,At the end of the proof of Theorem 2, I think it should be the identity ")#tao-math("\\left\\|Uw-w\\right\\|^2=- \\langle w,Uw-w\\rangle -\\langle Uw-w,w \\rangle =0", block: false)#text(".")#linebreak()#text(" 2,The proof of Proposition 2, the end of the second sentence, it should be ")#mi("\\pi(v)")#text(".")#linebreak()#text(" 刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-30348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("Dear 刘: thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The strong law of large numbers « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-30513")[#strong[#text("The strong law of large numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("[…] as special cases of the mean and pointwise ergodic theorems respectively (see Exercise 9 from 254A Lecture 8 and Theorem 2 from 254A Lecture […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-32351")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("[…] N, arising from iterating F about times. This result is essentially proven as Corollary 2 of my 254A lecture notes on this topic. Possibly related posts: (automatically generated)254A, Lecture 10: The Furstenberg correspondence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第八讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-34172")[#strong[#text("陶哲轩遍历论习题解答：第八讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2008")])]

#text("[…] (注：遍历论为陶哲轩教授于今年年初的一门课程，我尝试将所有习题做出来，这是第八讲的十个习题。第八讲是关于保测度变换的第一讲。这里是本讲的链接。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1634d0f905bb6c3a69ce73c6db7239899df8140e62c8d486d1cc9f72fdd7e457-179a2e9ca5ace2816b65d3d29b1722583a1b2c7ca83eac472589455d3c778569.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raja")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-35637")[#strong[#text("Raja")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Dr. Tao,")#linebreak()#text(" I have been working on the formulation close to what is described in Exercise 9 for some time now (I am at Wichita State University, Wichita, Kansas). I wondered if I can obtain a copy of the proof for that Exercise?")#linebreak()#text(" Thank you.")#linebreak()#text(" — Raja")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moser’s entropy compression argument « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-40843")[#strong[#text("Moser’s entropy compression argument « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("[…] theory, which then underlies a number of arguments in ergodic theory, as discussed for instance in this earlier blog post. Another basic example is the standard proof of the Szemerédi regularity lemma (where the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-41555")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2009")])]

#text("Terry,")

#text("I believe the proof you give for the abstract mean ergodic theorem is due to F. Riesz. Von Neumann used the spectral theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-41572")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-41618")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2009")])]

#text("Well, a reorganization of the proof allows to prove (equally simply) the abstract mean erg thm for contractions. It then appears that the main ingredient is the Pythagorian theorem to show that the orthocomplement of the invariant functions is spanned by ")#mi("W")#text(".")

#link("http://otthon.csi.hu/mw/proof_of_mean_erg_thm.pdf")[#text("Click to access proof_of_mean_erg_thm.pdf")]

#link("http://otthon.csi.hu/mw/proof_of_mean_erg_thm.tex")[#text("http://otthon.csi.hu/mw/proof_of_mean_erg_thm.tex")]

#text("As you see, if we just want to show convergence, then all follows from the Pythagorean theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-41739")[#strong[#text("ERT1: Poincaré’s Recurrence Theorem and Von Neumann’s Theorems « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")]

#text("[…] So, expressions of the type , from now on called ergodic averages, are important when dealing with recurrence. This will be our main interest in the next posts. For another perspective on Von Neumann’s Theorem and related results, the reader is referred to this Terry Tao’s lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nonconventional ergodic averages and multiple recurrence for von Neumann dynamical systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-42997")[#strong[#text("Nonconventional ergodic averages and multiple recurrence for von Neumann dynamical systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("[…] For , the answer to the above four questions is also “yes”, thanks to the von Neumann ergodic theorem for unitary operators. For , we were able to establish a positive answer to the “recurrence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-43035")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("[…] 6 One can interpret conditional expectation as a type of orthogonal projection; see for instance these previous lecture notes of mine. But we will not use this perspective in this course. Just as conditioning on an event and its […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71fa2fcc4d7b7e1afe258f1cdb98254812150fe91064d92620f85cae8bae1827-c67a8cd6b627d3dce1bde6df446f3c6a978a81d269c1eddbf0687947662c8198.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of beni22sof")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-43780")[#strong[#text("beni22sof")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2010")])]

#text("Mr. Tao,")#linebreak()#text(" I want to ask you if you have a pdf version of your notes. I am trying to study ergodic theory by myself, since we don’t study it in our school. I managed to obtain some books on ergodic theory, but my progress is very slow. I think your courses would be very helpful, but I cannot read them all on my computer.")#linebreak()#text(" Thank you.")

#text("with respect,")#linebreak()#text(" Beni Bogosel")#linebreak()#text(" (student Timisoara, Romania)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-43781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2010")])]

#text("These notes are contained in my book")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/books/poincares-legacies-course-notes-expository-articles-and-lecture-series-from-a-mathematical-blog/")[#text("Poincaré’s legacies: pages from year two of a mathematical blog")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e58625db1953eee19c28de26f4a69a7dd562d02ceee0f8561ae9ddcd150dd60-57da48480f6f130d3dc480a1825db6c69366f40f876ac44af00168b231707a8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiannis")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-46207")[#strong[#text("Yiannis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2010")])]

#text("hi — a couple of small possible typos: do you need the last sentence in the proof of Theorem 1? it looks like (4) is the same as the stated claim. also, in Exercise 3, should the two appearances of $\\mu(X)$ be replaced by $\\mu(E)$? thanks — yiannis")

#emph[#text("[Corrected (very belatedly) – thanks – T.[")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Choi")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-50906")[#strong[#text("Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Hi Terry!")#linebreak()#text(" I am looking at different books about ergodic theory. Poincare recurrent theorem is stated differently in different books. For example, your statement is already different from the wiki’s one. Another example, Silva states theorem that almost every point in a set of positive measure will return to this set. (p86, p88, Invitation to Ergodic theory, ")#link("http://www.ams.org/bookstore/pspdf/stml-42-prev.pdf")[#text("http://www.ams.org/bookstore/pspdf/stml-42-prev.pdf")]#text(")")

#text("Why do all authors pick their own Poincare recurrent theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-50911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("The various formulations of the Poincare recurrence theorem are closely related to each other. For instance, the version of Wikipedia can be deduced from the one given here using the Borel-Cantelli lemma. The version you cite from Silva can be deduced from either of the other two versions by considering the set of points that do not return to the set.")

#text("More generally, in the more analytic portions of mathematics, the precise statement of a mathematical result is often not of primary importance; it is the ")#emph[#text("nature")]#text(" of the result (and of the methods used to prove it) which tends to be more important. See Tim Gowers’ “")#link("http://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("two cultures of mathematics")]#text("” for further discussion of this point.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-70090")[#strong[#text("254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2011")])]

#text("[…] 2. Prove this claim. (Hint: obtain continuous analogues of the theory from Lecture 8 and Lecture […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-146642")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2012")])]

#text("How is it possible for the statement of Exercise 1 to fail for ")#mi("L^\\infty(X)")#text(" if it holds for ")#mi("L^p(X)")#text(" when ")#mi("1 \\leq p < \\infty")#text(", given that ")#mi("X")#text(" is a probability space?")

#text("Since ")#mi("\\mu(X) = 1")#text(", don't we have ")#mi("L^\\infty(X) \\subseteq L^p(X)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-146643")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2012")])]

#text("On second thought, I suppose the norms could be different.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-173860")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("Just to make sure we have the same conventions:")

#text("In the definition of measure-preserving system, when you say “")#mi("T")#text(" is invertible”, you mean that the map ")#mi("T: X \\longrightarrow X")#text(" is a (measurable) bijection, so that ")#mi("T^{-1}")#text(" is defined on the level of sets?")

#text("In this case, we are not considering examples such as the doubling map on the circle? I think some other texts only require that ")#mi("T")#text(" satisfy ")#mi("\\mu(T^{-1} E) = \\mu(E)")#text(" for all measurable ")#mi("E \\subset X")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-173924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("(a) yes; see ")#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")]

#text("(b) Not directly, though in practice one can often derive recurrence results for non-invertible ergodic systems from the invertible case by a lifting trick, see e.g. Exercise 9 of ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")]#text(" for an instance of this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-173991")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("Typo: where you write “Now observe (using (10)) that ")#mi("\\frac{1}{N} \\frac{\\lambda^{N}-\\lambda}{\\lambda-1}")#text(" is bounded in magnitude by 1…”")

#text("I think you want:")

#mi("\\frac{1}{N} \\frac{\\lambda^{N}-1}{\\lambda-1}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-185893")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] averages, namely the orthogonal projection of to the -invariant factors. (See for instance my lecture notes on this theorem.) While this theorem ostensibly involves measure theory, it can be abstracted to the more general […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-187542")[#strong[#text("Advanced Analyis, Notes 5: Hilbert spaces (Application: Von Neumann’s mean ergodic theorem) « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2012")]

#text("[…] operators-on-Hilbert-space theory, by proving von Neumann’s mean ergodic theorem. See also this treatment by Terry Tao on his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-197052")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("In this note, the “conditional expectation” is defined as the projection on the closed subspace of a Hilbert space. I learned another version on [this Wikipedia article] (")#link("http://en.wikipedia.org/wiki/Conditional_expectation#Formal_definition")[#text("http://en.wikipedia.org/wiki/Conditional_expectation#Formal_definition")]#text("). And I also see one in 254A Note 0")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/#as-rem")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/#as-rem")]#text("), which is for the discrete random variables. Are they essentially the same?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-197059")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("Yes; I recommend the exercise of verifying that the definition given in the Wikipedia article is indeed the orthogonal projection to the Hilbert space ")#mi("L^2({\\mathcal B})")#text(" (this is also alluded to in Section 5 of the Wikipedia article, as well as in equation (14) of the present article), and that in the case when the factor ")#mi("{\\mathcal B}")#text(" is generated by a discrete random variable, the definition collapses (outside of an event of probability zero, at least) to the definition given in Notes 0 (or at the beginning of the Wikipedia article); this is alluded to in Remark 6 of these notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc432133cc7bb678ccaddd39f5d06fc2fa366a26055221358e0b9770e0b1081d-c41763bf02c74eaa7b40b7df0b4c93eaee173920c976a386019b320f575d442c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alok Bakshi")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-215615")[#strong[#text("Alok Bakshi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2013")])]

#text("Dear Professor Tao, have you applied Jensen’s inequality with ")#mi("\\phi(x) = x^2")#text(" to obtain (1), because I couldn’t see how Cauchy Schwartz inequality be applied here.")

#text("[")#emph[#text(" To show ")#mi("\\int_X f^2\\ d\\mu \\geq (\\int_X f\\ d\\mu)^2")#text(", one can either use Jensen, or else apply Cauchy-Schwarz to the functions ")#mi("f")#text(" and ")#mi("1")#text(". -T")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-230671")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] e.g. this previous blog post. Informally, one can interpret this limit formula as an equidistribution result: if is drawn at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06e5c34dc999aaa6414658125d5f7b8474aafa0a6604c81938e8b8025d3f7f1a-be436002aeb66d276a5fe16978c10dd7097e0870ce0afbad5f01829093b15e53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cezary Ferens")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-262954")[#strong[#text("Cezary Ferens")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("In 1966 I have proved the conjecture of Ryll-Nardzewski that each sigma-algebra of power c is separable under the continuum hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/912205ad2a28354910341a38755d63d96faf9e960045b2ad6e6fc3485ef9533c-7b669d7d37fbfdbe75a6c145a4b9730e078c26e4662310614ef54070bab356bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuki")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-409399")[#strong[#text("Shuki")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2014")])]

#text("Thanks for these notes.")#linebreak()#text(" Where the separability assumption were used in the first proof of Theorem 2?")

#emph[#text("[The first proof is in fact valid for inseparable Hilbert spaces also. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The ergodic theorem and Gowers-Host-Kra seminorms without separability or amenability | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-454023")[#strong[#text("The ergodic theorem and Gowers-Host-Kra seminorms without separability or amenability | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2015")])]

#text("[…] topology, where is the -invariant subspace of , and is the orthogonal projection to . (See e.g. these previous lecture notes for a proof.) The same proof extends to more general amenable groups: if is a countable amenable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-454037")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2015")])]

#text("Why does this post have a tag “uncategorized”?")

#emph[#text("[Removed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-457844")[#strong[#text("What's the universe collapsing into? | Page 3")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2015")]

#text("[…] Can the 2nd law of thermodynamics be derived from first principles? Yes – but the math is deep: ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")]#text(" The above is a very famous theorem The trouble is it isn't quite general enough to fully […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-478885")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] (including those without logarithmic averaging). Invoking the mean ergodic theorem (discussed in this previous post), this assertion is in turn equivalent to the observable that corresponds to the Liouville […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724a5f80344d8c833d5f96098156b6474d7241d0645221f832a2cf430c495e55-d0c51b33bad4c6bd68b860e2c692845dc25308fcf7971962b7e0162cc488bbfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hc")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-486815")[#strong[#text("hc")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")])]

#text("Some corrections:")

#text("1. Exercise 3: “… cannot be replaced by any smaller quantity in general” – probably bigger rather than smaller.")

#text("2. Exercise 6, part 1 : “… more generally preserves $\\chi’$-valued functions” – probably $\\chi’$-measurable instead.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-506720")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2018")])]

#text("Dear Prof. Tao,")

#text("I believe that there exists a straightforward proof of the von Neumann ergodic theorem that uses the Banach‒Steinhaus theorem and the geometrical definition of an orthogonal projection (as well as the continuity of the scalar product). Hence, I’d like to ask why this proof has not been given. Do you believe that the other proofs have “pedagogical” merit, and that the methods therein are applicable to the subject at hand? Or were you merely enjoying yourself?")

#text("With best regards")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-506722")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2018")])]

#text("(I just realised that the application of the Banach‒Steinhaus theorem is non-essential. This makes the result constructive even in the case of non-separable Hilbert space.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-506767")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2018")])]

#text("I’ve put the proof into Wikibooks (")#link("https://en.wikibooks.org/wiki/Topological_Modules/Orthogonal_projection")[#text("https://en.wikibooks.org/wiki/Topological_Modules/Orthogonal_projection")]#text("; language buffs may also enjoy the original German here: ")#link("https://de.wikibooks.org/wiki/Topologische_Moduln/_Orthogonalprojektion")[#text("https://de.wikibooks.org/wiki/Topologische_Moduln/_Orthogonalprojektion")]#text("). I found it very intuitive, because I thought that it gives an explanation, in very simple terms, of why the convergence really does occur. Moreover, the rate of convergence is seen to be ")#tao-math("\\frac{2\\left\\|x\\right\\|}{n}", block: false)#text(", so that we have convergence in operator norm.")

#text("Maybe this proof can also be adapted to some of the more general statements?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/comment-page-1/#comment-506787")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2018")])]

#text("There cannot be a rate of convergence the way you state it. Indeed, the second line of the math display following “we obtain” of the wikibook entry is not correct. There needs to be a dependence on m there. :(")
]
]
