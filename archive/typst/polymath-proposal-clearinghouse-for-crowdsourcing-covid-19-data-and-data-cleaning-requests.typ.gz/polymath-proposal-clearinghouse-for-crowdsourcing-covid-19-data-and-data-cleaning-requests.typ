// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/
// Converted to Typst by tao2typ: "2026-10-14T15:20:27.211800+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath proposal: clearinghouse for crowdsourcing COVID-19 data and data cleaning requests", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath proposal: clearinghouse for crowdsourcing COVID-19 data and data cleaning requests")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/")[#text("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("After some discussion with the applied math research groups here at UCLA (in particular the groups led by ")#link("https://www.math.ucla.edu/~bertozzi/")[#text("Andrea Bertozzi")]#text(" and ")#link("https://www.math.ucla.edu/~deanna/")[#text("Deanna Needell")]#text("), one of the members of these groups, ")#link("https://www.math.ucla.edu/people/grad/c.strohmeier")[#text("Chris Strohmeier")]#text(", has produced ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/03/covid_19_polymath_project-1.pdf")[#text("a proposal")]#text(" for a Polymath project to crowdsource in a single repository (a) a collection of public data sets relating to the COVID-19 pandemic, (b) requests for such data sets, (c) requests for data cleaning of such sets, and (d) submissions of cleaned data sets. (The proposal ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/03/covid_19_polymath_project-1.pdf")[#text("can be viewed as a PDF")]#text(", and is also available ")#link("https://www.overleaf.com/project/5e7acd0e03821500012262bb")[#text("on Overleaf")]#text("). As mentioned in the proposal, this database would be slightly different in focus than existing data sets such as the ")#link("https://www.kaggle.com/tags/covid19")[#text("COVID-19 data sets hosted on Kaggle")]#text(", with a focus on producing high quality cleaned data sets. (Another relevant data set that I am aware of is the ")#link("https://docs.google.com/forms/d/e/1FAIpQLSc501xfAzEPADOwRmsdHmu-v8aN14jnKHBmEmdJJcTgRLddqw/viewform")[#text("SafeGraph aggregated foot traffic data")]#text(", although this data set, while open, is not quite public as it requires a non-commercial agreement to execute. Feel free to mention further relevant data sets in the comments.)")

#text("This seems like a very interesting and timely proposal to me and I would like to open it up for discussion, for instance by proposing some seed requests for data and data cleaning and to discuss possible platforms that such a repository could be built on. In the spirit of “building the plane while flying it”, one could begin by creating a basic github repository as a prototype and use the comments in this blog post to handle requests, and then migrate to a more high quality platform once it becomes clear what direction this project might move in. (For instance one might eventually move beyond data cleaning to more sophisticated types of data analysis.)")

#text("UPDATE, Mar 25: a prototype page for such a clearinghouse is now ")#link("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse")[#text("up at this wiki page")]#text(".")

#text("UPDATE, Mar 27: the data cleaning aspect of this project largely duplicates the existing efforts at the ")#link("http://united-against-covid.org/")[#text("United against COVID-19")]#text(" project, so we are redirecting requests of this type to that project (and specifically to ")#link("https://discourse.data-against-covid.org/c/i-have-data/15")[#text("their data discourse page")]#text("). The polymath proposal will now refocus on crowdsourcing a list of public data sets relating to the COVID-19 pandemic.")

#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548156")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Unfortunately, the overleaf link shows that entry to the page is restricted. Could you share it publicly please ?")

#emph[#text("[PDF link also added. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548157")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("This is an excellent COVID data collection: ")#link("https://ourworldindata.org/coronavirus")[#text("https://ourworldindata.org/coronavirus")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548160")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("I think, World Health Organisation (WHO) can provide us with valuable information we want to get hold of.")#linebreak()#text(" Recently, I have been aware of the fact that WHO has launched online support to individuals via communication through social platforms such as Whatsapp and Telegram.")#linebreak()#text(" Given that, one can seek information regarding some common concerns of the individual, and also seek information regarding the data that is being provided to WHO via such medium.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548163")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/")[#text("1. Mathematics Scouts")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548166")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Terry,")

#text("I have noticed over time that you are beginning to use your God-given talents for the good of others, more and more. To me, it is simply your, conscious or subconscious, realization of God’s purpose for you: to use your talent to help others. If you keep widening this realization, your platform for reaching and influencing others will become World wide, Then, you can Really change the World for the better.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("I agree with you. I wonder why all biology scientists and doctors over the world not combine with Pro.Tao ‘s intelligent to invent vaccine to kill virus. Try one time! Pro.Tao is very talented in many fields. I always belive in Pro.Tao.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("A possible method to “clean” the data is to use sufficiently realistic parametric (possibly stochastic) models for the epidemic dynamics and estimate the parameters (including possible data “noise” parameters) which should help to remove most of the “noise” from the data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b3c4469088543cc994173661acb4f8b6365b2e98984dfaa87523edfb26a23c0-56b60a7063d4006fff7dd34809eaa6b004c4f19eefc7c26d1483318432e45bd1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carcar")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548176")[#strong[#text("carcar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("The available data are quite messy; in particular there is no homogeneity in the methods followed to collect them. This has awkward results, such as a huge discrepancy in the mortality rate:")#linebreak()#text(" ")#link("https://www.theguardian.com/world/2020/mar/22/germany-low-coronavirus-mortality-rate-puzzles-experts?fbclid=IwAR0aoxfS5O9ZHbHkigS2PdSBRpPBySvy1yhiWIUuAzT2e8dW4BOv7-HzBZ4")[#text("https://www.theguardian.com/world/2020/mar/22/germany-low-coronavirus-mortality-rate-puzzles-experts?fbclid=IwAR0aoxfS5O9ZHbHkigS2PdSBRpPBySvy1yhiWIUuAzT2e8dW4BOv7-HzBZ4")]

#text("Therefore it is not clear how we could possibly ‘polish the data’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80e8decda9a3b3efdf9a2b1ebeca32f69157723d5944684a8f5d46fdb2389117-79ef810c6cf2c76d471e6380c00899985b3d0c87feee95dc615ba6c8e7ae1911.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Morgan")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548187")[#strong[#text("Peter Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("There is a github dataset that seems fairly clean here: ")#link("https://github.com/datasets/covid-19")[#text("https://github.com/datasets/covid-19")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a09971234162a15562647a9298f2360626bba53001f4aeea0032eb6628efe388-14bee498c35907261aa2cb911d5eeecc8a147dde11ac3c0e361d90d8bcd34052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of popcubed")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548191")[#strong[#text("popcubed")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("I’m sure the following sources are well known but perhaps not to all. The data for the Johns Hopkins COVID-19 dashboard is openly available at Github (")#link("https://github.com/CSSEGISandData/COVID-19")[#text("https://github.com/CSSEGISandData/COVID-19")]#text(") in convenient csv format. Similarly for the covid tracking data (")#link("https://github.com/COVID19Tracking/covid-tracking-data")[#text("https://github.com/COVID19Tracking/covid-tracking-data")]#text("), though it applies only to the US. Both are curated to an extent but are limited by the sources on which they depend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2807644ebda9274985960435bffd7b1dc0dfef3c0568bdc501c32516e0063f51-b51cd194f3b7afe1eac6266ad32c4f0a1be9025d62b95aa5be0175ffdf8bde46.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YY Ahn")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548197")[#strong[#text("YY Ahn")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Here is another one: ")#link("https://github.com/covid19-data/covid19-data")[#text("https://github.com/covid19-data/covid19-data")]#text(" We aim to make the whole pipeline open and transparent. Countries and state names are normalized with ISO 3166-1 code.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("I’ve started a wiki page at ")#link("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse")[#text("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse")]#text(" to collate these links. Thanks for all the contributions!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("As an illustration of the types of requests we envision the clearinghouse could assist with, Chris has sent me an actual example of a data cleaning request (tabulating all recent COVID-19 research articles) that their group could use as an illustration. For now I’ve placed it on the above wiki page at ")#link("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse#From_Chris_Strohmeier.2C_Mar_25")[#text("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse#From_Chris_Strohmeier.2C_Mar_25")]#text(" . Presumably if we scale this project up a wiki is not going to be the ideal platform, but for sake of “proof of concept” this may suffice for now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548407")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Dear Professor Tao,")

#text("I am the founder of a Polymath Project-inspired open science startup called AsOne.")

#text("My mission was to create a scalable platform which could house hundreds of Polymath-style Projects simultaneously.")

#text("Topics on our platform are organized as a tree. Currently under our COVID-19 topic, we are providing the forum for a citizen science project called 1 Million Ventilators. We would LOVE to house your dataset clearinghouse as one of our topics.")

#text("Here is our COVID-19 topic page:")#linebreak()#text(" ")#link("https://asone.ai/topic/covid19")[#text("https://asone.ai/topic/covid19")]

#text("Please consider us as your platform!")

#text("Sincerely,")#linebreak()#text(" Thomas Vu")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548413")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Here is what the page looks like on our platform:")#linebreak()#text(" ")#link("https://asone.ai/a/C19Datasets")[#text("https://asone.ai/a/C19Datasets")]

#text("We are a fast-moving startup and can implement whichever features are needed quickly.")

#text("My email is ")#link("mailto:thomas@asone.ai")[#text("thomas@asone.ai")]#text(" for anyone who wants to get in touch.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548447")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Thanks for this! At present it does not seem like activity is scaling up to require such a platform, but if there are many more data cleaning requests and cleaned data submissions then we would probably need a more sophisticated platform to evaluate submissions, request clarification on requests, and the like.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548454")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Please keep us in mind if the requests and submissions start to pile up!")

#text("We are trying to get the word out about our platform, and hope to become the central hub of all Polymath-style Projects.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548648")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("Unfortunately, due to spam and hosting restrictions, at the moment on the Polymath wiki new accounts are manually created by admins (mostly: me). This is slow and inconvenient. Much of this is due to the nature of the hosting – I use a shared, commercial host, and don’t have the expertise to run my own host.")

#text("One possibility: would you or someone else with the expertise be able to provide long-term hosting for the Polymath wiki? We could potentially migrate content there, and add some kind of redirect from the existing URLs.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548670")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("Michael, you are the exact person I wanted to get in touch with!")

#text("> would you or someone else with the expertise be able to provide long-term hosting for the Polymath wiki?")

#text("Yes, absolutely! That would be incredible. Please let me know how I can help the Polymath wiki in any way.")

#text("Could you open your DMs to me on Twitter?")

#link("https://twitter.com/thomazvu?ref_src=twsrc%5Etfw")[#text("Tweets by thomazvu")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548672")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("Sorry, I didn’t know linking to Twitter would cause it to embed itself like that!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548834")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("Email sent.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("This is a good idea but I worry that many of the participants will start with certain preconceived ideas about the findings that they want to find, for instance about the lethality of COVID-19 in young populations. Since this is not a purely mathematical project it is easier to torture the data towards the finding one desires. Thus it is particularly important to start the project without preconceived ideas. This is difficult in the current media climate. Moreover because of the actions already taken by many governments there is a certain societal pressure to conclude that COVID-19 is an exceptional danger to humanity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f44fe5eddb40e6f70ecca6076841d6a7f3c6fbe5a4c80c5f2e7a877b582f1f28-f25b9750343a89b3aac5b149ededf310bd7ffeeef29384cea988f81e3f12dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gönenç Onay")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548230")[#strong[#text("Gönenç Onay")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Good news. This is, of course, a must. Most of the current data is biased.")

#text("I would also say that some of us should also work on applications of -clean(ed)- data.")

#text("Here there is one by Yoshua Bengio (Turing Award 2018), which seems to me promising:")

#link("https://yoshuabengio.org/2020/03/23/peer-to-peer-ai-tracing-of-covid-19/")[#text("https://yoshuabengio.org/2020/03/23/peer-to-peer-ai-tracing-of-covid-19/")]

#text("Last, maybe the most important: we have to warn some of our colleagues.")#linebreak()#text(" I think, we are not in a moment where one can benefit for enhancing his/her publication record. There are already about 25K corona-virus publications.")#linebreak()#text(" We should better organize our collaboration: maybe an international statement recalling the ethics of scientific work can be useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Please be aware of this, though it’s about research papers rather than data per se: ")#link("https://www.ncbi.nlm.nih.gov/research/coronavirus/")[#text("https://www.ncbi.nlm.nih.gov/research/coronavirus/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#link("https://coronavirus.1point3acres.com/en")[#text("https://coronavirus.1point3acres.com/en")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548472")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("This 1point3acres site seems to be made by lots of engineers and scientists. They might be willing to share their raw data.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ddb2932f75fce714a4ee7d91dae89a8bd85d72e3a60b5795d6a2434f5e71af-a788db6748036dabecc6eaea2fb41740c9f05215f2630ece0f1a46929cc5c196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JosephSugar")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548288")[#strong[#text("JosephSugar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Given that German media such as ZDF sometimes share with the viewers astoundingly precise scientific data and projections on COVID, I am sure that Germany is way ahead in this project. Might as well just ask the Bundesamt fuer Statistik or the Robert Koch Institut to share their database.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548361")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#link("https://www.mygov.in/covid-19/")[#text("https://www.mygov.in/covid-19/")]#text(" The current updates about the figures for India can be found by visiting the link above. Couldn’t update it on the wiki page unfortunately.")

#emph[#text("[Added, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39e470bd66d66a713e142fd5e240c49360ef9423d7ecf47b78eefa0a12600cdd-ffb382f31e86ef901d3123e8617e626192716544179cf645560f19edaf5b5f8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RSamyak")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548422")[#strong[#text("RSamyak")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("There’s a dataset at the bottom of this page: ")#link("http://www.covid19india.org")[#text("http://www.covid19india.org")]#text(", this is also crowdsourced")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548582")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("This tracks testing and is updated frequently: ")#link("https://covidtracking.com/data/")[#text("https://covidtracking.com/data/")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e95f200e40a729dbf754a1f2dc680cf8c0ca5280e56b368320fd5cb98e151e89-a9dadae0bbc9243d7a36c3d8de2297d0a3e5c86f27f94ad6d8b4c4ec1b8a841c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of juan")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548617")[#strong[#text("juan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("Hello.")

#text("We need much more detail (date when each person was diagnosed, date of infection for the same person, discharge date, date of death, gender, age, treatments, temperatures…) not just summaries.")

#text("I mean we need information (on a person basis) to perform survival analyses, regressions with random effects…")

#text("I’ve found some data")#linebreak()#text(" ")#link("https://www.kaggle.com/sudalairajkumar/novel-corona-virus-2019-dataset/data")[#text("https://www.kaggle.com/sudalairajkumar/novel-corona-virus-2019-dataset/data")]#linebreak()#text(" ")#link("https://www.kaggle.com/kimjihoo/coronavirusdataset")[#text("https://www.kaggle.com/kimjihoo/coronavirusdataset")]#linebreak()#text(" ")#link("https://www.kaggle.com/imdevskp/covid-19-analysis-visualization-comparisons/data")[#text("https://www.kaggle.com/imdevskp/covid-19-analysis-visualization-comparisons/data")]#linebreak()#text(" ")#link("https://www.sirm.org/category/senza-categoria/covid-19/")[#text("https://www.sirm.org/category/senza-categoria/covid-19/")]

#text("But they don’t provide enough information yet. It’s easy to find data aggregated by countries, but they are just summaries.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548630")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("I’ve added your request to the wiki page, but as per my other comment, you may wish to also submit your request to ")#link("https://www.united-against-covid.org/")[#text("https://www.united-against-covid.org/")]#text(" (probably by posting at ")#link("https://discourse.data-against-covid.org/c/i-have-data/15")[#text("https://discourse.data-against-covid.org/c/i-have-data/15")]#text(" ).")

#text("The UCLA hospitals do have records of this type for the COVID patients passing through their system, but for reasons of patient privacy they are unfortunately not available to researchers outside of UCLA. (Potentially this can be solved by anonymizing the data, but this cannot be crowdsourced, for obvious reasons.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548626")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("We’ve been contacted by the organisers of the ")#link("https://united-against-covid.org/")[#text("United against COVID-19")]#text(" project, which is an existing clearinghouse for data, data scientists, and medical researchers working on COVID-19 projects. The data cleaning aspect of this polymath proposal appears to basically be a duplicate of this existing project, so it seems to make sense to redirect these efforts to that site in order to not fragment the pool of requests and volunteers. On the other hand, this polymath project has already been rather successful in assembling a ")#link("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse#Data_sets")[#text("list of public data sets relating to COVID-19")]#text(", so perhaps the thing to do is to refocus the polymath proposal down to this narrower goal, and refer subsequent data cleaning requests to the “United against COVID-19” project. (But we can still use this comment thread to also make requests and answer them.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548659")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("Now that the polymath project is focusing on curating public COVID-19 data sets, I would like to start a discussion about what features would be desirable for a platform to host this collection. Right now we are using an ")#emph[#text("ad hoc")]#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=COVID-19_dataset_clearinghouse#Data_sets")[#text("wiki page")]#text(" to list the collection, grouped into rough categories, but as the list grows it will become difficult to rapidly search for an appropriate data set for one’s needs, and we should eventually migrate to something more scaleable than a wiki page. (And there are entire categories of data not yet present: for instance regarding the impact of COVID-19 on other aspects of wellness like mental health.)")

#text("One could envision a searchable “database of databases” where each database in the list has various metadata attached to it regarding the type of data, the sources used, the host organisation, relations to other databases (e.g., if one is a subset or cleaned version of the other) and so forth, with the ability to crowdsource various annotations and commentary on each such database. I don’t know if there are any existing platforms that are suitable for this sort of structure; hopefully others here may be able to suggest some.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548679")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("Terry,")

#text("We at AsOne are working hard to create the type of platform you are describing. We allow nesting of categories for better organization.")

#text("I have recreated the “possible layout” described in the COVID-19 Polymath Project Proposal PDF to better demonstrate our platform.")

#link("https://asone.ai/topic/C19Datasets")[#text("https://asone.ai/topic/C19Datasets")]

#text("We are willing to implement any desired features from the resulting discussion into our platform!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb75deada56f0e0c2274dae314c4ed690f818a137730fc6e2a776e0794e58e81-9e3b4afc76c4bcbcb3f266e6a811fc652fe38666f3cce29e7608ef4bb1091888.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Wainwright")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548960")[#strong[#text("Mark Wainwright")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("There’s CKAN (ckan.org), if it’s not too heavy duty.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7416feefd12fc57292fdf3129ebcf9f5f74c1018967ea94a68c33cc87812265-4ea95fe39c4dd9e889a6551c60cd60af1508552686fde45633216f01ff1fdbf2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan Funke")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548794")[#strong[#text("Jan Funke")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("Martin (@headsortails on data-against-covid.org) suggested using Kaggle to publish curated datasets and offered help to do so. I think this is a great idea. In fact, there is a request for collecting and curating datasets on Kaggle itself already (in the form of a challenge: ")#link("https://www.kaggle.com/data/139140")[#text("https://www.kaggle.com/data/139140")]#text(").")

#text("Thomas, maybe we can aim for a hybrid solution: AsOne provides a category browser, the leave nodes would then point to the Kaggle datasets?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7416feefd12fc57292fdf3129ebcf9f5f74c1018967ea94a68c33cc87812265-4ea95fe39c4dd9e889a6551c60cd60af1508552686fde45633216f01ff1fdbf2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan Funke")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548796")[#strong[#text("Jan Funke")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("By the way, [here](")#link("https://discourse.data-against-covid.org/t/request-for-help-build-a-platform-to-catalogue-covid-19-related-datasets/750/2")[#text("https://discourse.data-against-covid.org/t/request-for-help-build-a-platform-to-catalogue-covid-19-related-datasets/750/2")]#text(") is the related thread on data-against-covid.org, just that you are aware. Feel free to move the discussion there, if you think that makes sense.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/009693f0c52b167e5ee8c2c9cf09d24573ec5e39850a00663f551dfaf1f7aef6-a975e124f1b4dadc7dd89a36e2f7636cc276385951ebe1d7b07cee4fb77e5c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Vu")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548815")[#strong[#text("Thomas Vu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("I am definitely open to a hybrid solution! I agree that Kaggle has many advantages for hosting a data science focused effort.")

#text("AsOne has a more broad focus, under our COVID-19 topic we currently house a citizen science project for rapid distribution of ventilators, and we would like to create a category to gather the evidence around possible treatments. We’re trying to become the platform where all COVID-19 research and relief efforts can be collaborated on in a more organized fashion. I believe a true “COVID-19 Polymath Project” should encompass the whole problem at hand.")

#text("That said, I would love to coordinate with you and Martin on the dataset clearinghouse front over on Kaggle if that’s where we decide to go!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8be264c2ade6a9db13365bf127d2d6bfffd37760573fa5aed51ace3408b78692-113492ca9a8cd238ef8b1baafd540ac43a08ed41359f8a472ea8887f3476e78c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of headsortails (Martin)")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548833")[#strong[#text("headsortails (Martin)")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("Hi both, I’m happy to help in adding the data to the Kaggle platform.")

#text("A major advantage of Kaggle is that they already host a lot of datasets with e.g. demographic or geospatial information on many different countries, which could be easily joined to more COVID-19 specific data for a more comprehensive analysis. The Kaggle platform is very mature and has robust search and tagging functionality. In addition, analysis notebooks in R/Python can be hosted together with the data to illustrate the extent of a dataset or provide (collaborative) analysis capabilities.")

#text("I had a look through the wiki that Jan linked, and I think that most of the datasets are already on Kaggle in some shape or form. There is a certain focus on US numbers, but Kaggle has a very international community and COVID-19 data from multiple other countries is also already present.")

#text("Maybe you guys can have a look at what’s already there: ")#link("https://www.kaggle.com/datasets?search=covid-19")[#text("https://www.kaggle.com/datasets?search=covid-19")]

#text("And then we can coordinate how to prioritise adding the missing datasets, and how to best maintain them / add future ones.")

#text("We can either continue the thread here or over at data-against-covid, which might be a bit better equipped to handle more detailed discussion:")#linebreak()#text(" ")#link("https://discourse.data-against-covid.org/t/request-for-help-build-a-platform-to-catalogue-covid-19-related-datasets/750")[#text("https://discourse.data-against-covid.org/t/request-for-help-build-a-platform-to-catalogue-covid-19-related-datasets/750")]

#text("Cheers, Martin")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548954")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("Thanks for this! The Kaggle platform does have a lot of nice features, with each data set coming with a page that can contain a lot of auxiliary data, such as the notebooks you mention. But my view of this clearinghouse is at the next level up of organisation; it isn’t intended to host data directly, but instead to crowdsource links to data at other sources (including Kaggle), and to also create various “directory” pages and other search features to locate subcollections of data easily; I’m thinking something resembling the Wikipedia model where there are various “lists of X” pages, that can be independently curated by different sets of people with varying degrees of automation. To give just one example, one could imagine a page devoted to social data related to COVID-19 (on the existing clearinghouse there is already some data on foot traffic and on twitter feeds). One could have a page devoted to COVID data in a specific country. And so forth; presumably there would be datasets that would show up in multiple such pages (right now the clearinghouse is organised in a tree structure where each data set only shows up once).")

#text("Another desirable feature would be for each data set to come with its own dedicated web page on the clearinghouse, that gives further metadata such as a description of the data set, any restrictions on use, the institutions or individuals involved in maintaining it, any gaps or other issues with the data, and any dependencies on other data sets (e.g., whether the data set is a cleaned version of another data set, or is part of a larger corpus that also has its own page on the site). Plus anything else that might be relevant (commentary, example code, APIs, etc.). A dedicated wiki (with some templates for data set pages containing the above sort of information) might already be good enough for this.")

#text("EDIT: On thinking about it a bit more, one problem with having too much metadata associated to each data set is that it makes it harder to casually add a data set to the clearinghouse. Perhaps one needs some sort of “submit” button where anyone without any special training can submit a new dataset with a form where a lot of entries can be left blank, and then later on the metadata can be cleaned up (and possibly merged with another dataset in case of duplicates) by someone else who is more familiar with the site. (The OEIS roughly follows this sort of model for instance.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548798")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("Maybe not a nice logistic function. Should we fit or ignore this curve? ")#link("https://nypost.com/2020/03/28/shipments-of-urns-in-wuhan-raise-questions-about-chinas-coronavirus-reporting/")[#text("https://nypost.com/2020/03/28/shipments-of-urns-in-wuhan-raise-questions-about-chinas-coronavirus-reporting/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0545852da5807914429ef5ae24101202050d1b410f4c40859ea6459d39e306c7-d47625e23651b8423526a35f6e40ecdfa22a915d923b0d2c0d66cf3cf80cb2eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Hayes")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-549740")[#strong[#text("Daniel Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Over the last 2 weeks up to this time (Friday 3/4/2020 10 am, Melbourne Australia time) the total worldwide deaths from corona virus has pretty much followed a logistic model on using the data from ")#link("https://ourworldindata.org/coronavirus")[#text("https://ourworldindata.org/coronavirus")]#text(".")#linebreak()#text(" I constructed the model a week ago using data from 2 weeks to a week ago and it pretty much predicted last week’s data.")#linebreak()#text(" The logistic model used is dp/dt = a p – b p^2 where p(80)=8843 and a=.1293655842, b=4.382456229*10^(-7).")#linebreak()#text(" Note that the data here is changing too with time in an unexpected way, eg p(80) was 8843 a week ago, now it is p(80) =8842. At this time we are currently at p(94)=46891 and the model above gives about p(94)=46905.")#linebreak()#text(" If the model is good for another week then in one week’s time we will be at about p(101)=94000.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9a3e7c8ec22ed049900fd7b212f3589166ad5dd284c61b39907cca623c4f1cc-6747c888e8d6fc5de550bb8c055d6489f7a29e313ddc9c16dc47e01b61a0e264.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Selby")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548856")[#strong[#text("Alex Selby")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("I’m concerned that many people and institutions are using the JHU dataset ")#link("https://github.com/CSSEGISandData/COVID-19")[#text("https://github.com/CSSEGISandData/COVID-19")]#text(", presumably because it is in a convenient form, but it has some serious errors in it that are not being corrected. For example half of the March 12th entries (109 countries) are wrong as they erroneously copy across data from March 11th. (This is not the only error.) These errors are carried over into derived datasets such as the one listed on the clearinghouse wiki: ")#link("https://github.com/datasets/covid-19")[#text("https://github.com/datasets/covid-19")]#text(".")

#text("These errors remain, apparently unnoticed by JHU, on the JHU issue tracker. (I’ve tried contacting them by email, but just get an autoresponder.)")

#text("I suggest that the polymath wiki puts a warning flag against these datasets so that people may decide for themselves if such errors are acceptable or fatal for their analysis. Also, I’m hoping such a note may spur the creation of a corrected fork of the JHU dataset (or even nudge JHU into correcting it).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548930")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("NSF funding up to $200K immediately available for COVID-19 modelling. ")#link("https://www.nsf.gov/pubs/2020/nsf20052/nsf20052.jsp")[#text("https://www.nsf.gov/pubs/2020/nsf20052/nsf20052.jsp")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb75deada56f0e0c2274dae314c4ed690f818a137730fc6e2a776e0794e58e81-9e3b4afc76c4bcbcb3f266e6a811fc652fe38666f3cce29e7608ef4bb1091888.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Wainwright")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548958")[#strong[#text("Mark Wainwright")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("There is a similar effort as part of the Coronavirus Tech Handbook:")

#link("https://coronavirustechhandbook.com/data")[#text("https://coronavirustechhandbook.com/data")]

#text("You might wish to note this, link to it, add datasources directly to it etc (it is easy to edit and welcomes all help).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548977")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("The New York Times has been maintaining a .csv file recording the cumulative number of confirmed cases and deaths in the U.S by state, county, and date:")

#link("https://github.com/nytimes/covid-19-data")[#text("https://github.com/nytimes/covid-19-data")]

#text("If you click on the Raw tab in ")#link("https://github.com/nytimes/covid-19-data/blob/master/us-counties.csv")[#text("https://github.com/nytimes/covid-19-data/blob/master/us-counties.csv")]#text(" you should get to another page that you can save as a .csv file (ie., in your browser, select File/Save Page).")

#text("This data is apparently the source for their very detailed map:")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-548991")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("Vaccine and treatment tracker: ")#link("https://milkeninstitute.org/covid-19-tracker")[#text("https://milkeninstitute.org/covid-19-tracker")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-549016")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("I’ve asked Michael Nielsen (who maintains the PolymathWiki) to temporarily open up account registration on the wiki so that it is easier for people to contribute to the clearinghouse. We may lock it down again if we encounter significant spam problems (which is why account creation was locked down in the first place).")

#text("EDIT: OK, the spam account creation started more or less immediately, we will soon lock it back down again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a2f82ab59f61ed660ae8458a71a617937e630afa5a1c680d1b277d4e4e00e69-ddc46ed5ca6e57f12b7e26f85a6fd7be5d42322c9f7d71f3ea8f58f7bd0b34a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Larry Adams")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-549214")[#strong[#text("Larry Adams")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Not sure if this is useful. ")#link("https://midasnetwork.us/covid-19/")[#text("https://midasnetwork.us/covid-19/")]#text(" has some data aimed at COVID-19 modelling research complete with documented metadata.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-551447")[#strong[#text("Some Select COVID-19 Modeling Resources | R-bloggers")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2020")]

#text("[…] Tao’s March 25th post which announces the Christopher Strohmeier COVID-19 Polymath Proposal initiated a valuable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a999d593035d7e2b9ea8dd30059fef11fd087df25fbcc7f71fbeb082971c3-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-557437")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("Hello everyone from Spain. We have been hit hard by this pandemic, with many human and economic losses, and our health system has overflowed in large cities, and nursing homes have been severely damaged.")#linebreak()#text(" This is not the time or the place to discuss whether our politicians or our scientists have failed. After stopping our economy almost entirely and staying the whole country confined at home, we started the de-escalation phase.")#linebreak()#text(" Most of us want to leave home, but the fear of possible outbreaks grips us, with our health personnel very tired and depleted.")#linebreak()#text(" I want to trust our experts, but I cannot do it, I do not feel safe, I do not usually blindly trust, I need to see the plan clearly, I need some mathematical certainty that we can control the epidemic and how it will be done, but they do not give such information. accurate.")#linebreak()#text(" At this point I want to understand that there must be an algorithm that allows us to know if we can control the pandemic, with the focus on not exceeding the capacity of the health system and monitoring the most vulnerable population, a kind of day counter for collapse.")#linebreak()#text(" an algorithm that seems to be a good implementation for an AI.")#linebreak()#text(" Maybe it’s already being done, but since I don’t know, I don’t feel safe")#linebreak()#text(" This algorithm should be open source so that all countries could use and improve it, and find the most optimal possible. It would give us a lot of peace of mind.")#linebreak()#text(" taking into account each health area, its availability of beds and respirators, available protective material and masks, available health personnel, the population, the ability to accurately test and monitor the epidemic situation, assuming the minimum risk possible, or any other variable of importance, and with the known epidemiological data, without being an expert in the field, I do not think it is so difficult to create this collapse alert system, with enough time to take measures to avoid it, such as isolation of infected population, … Of course always making use of masks, social distancing and hand hygiene.")#linebreak()#text(" surely this optimal algorithm exists and is open source and available to all countries, and above all reliable. That would give us much peace of mind, much more than the words of politicians.")#linebreak()#text(" but if it does not exist, it should exist, for optimal and safe de-escalation. and if it does not exist, it is you, mathematicians, computer scientists, scientists, … who can make it possible. Thank you all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aacd21ee7af279659adc7c18642c3a65d6b738f77d3dd5a7cfbe728f3bf2ab7-6ae45ea2a340246d66b6a49a25cdaf88dbdb82d02559bd0368bad07c4c28ebb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Clark")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-558036")[#strong[#text("Robert Clark")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("Big-data to search for COVID-19 cures.")

#text("Hello, Prof. Tao. I wanted to discuss with you a topic that I thought you as a highly regarded mathematician could help with. It’s in regard to the COVID-19 crisis. I would have thought it obvious that one approach to address a search for cures is to look for medications in the collected medical histories of COVID-19 patients either for medications absent from that list, suggesting they may be protective, or ones appearing in common in patients with positive outcomes, suggesting they may be curative.")

#text("Yet, with now over 1 million cases and tens of thousands of deaths in the U.S. this still has not been done. Back in March there were only a few tens of thousands of cases, and a few hundred deaths. If this had been done then likely an answer could have been found within a matter of days. And in an outbreak in its exponential growth phase, every day is vital.")

#text("I have been arguing for this to be done since March, but I am only a lone voice in the wilderness, and not a very loud voice. I thought you with a much louder voice could make it clear this in an obvious, low cost, and quick means of searching for cures.")

#text("Some discussions on the topic:")

#text("Big Data to fight COVID-19 and Other Diseases.")#linebreak()#text(" ")#link("https://medium.com/@rgregoryclark/big-data-to-fight-covid-19-and-other-diseases-10cfd217920f")[#text("View at Medium.com")]

#text("This searches for cures in the reverse sense, by looking for medications absent from the collected medical histories of patients.")

#text("Big Data to fight COVID-19 and Other Diseases, Page 2.")#linebreak()#text(" ")#link("https://medium.com/@rgregoryclark/big-data-to-fight-covid-19-and-other-diseases-page-2-babd6eee36c8")[#text("View at Medium.com")]

#text("This searches for cures in the direct sense, by looking for medications that patients with positive outcomes have in common.")

#text("Thank You,")

#text("Robert Clark")

#text("___________________________")

#text("Robert Clark")

#text("Dept. of Mathematics")

#text("Widener University")

#text("One University Place")

#text("Chester, PA 19013 USA")#linebreak()#text(" ___________________________")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-558100")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("David Fry @Theorist Papers")

#text("Terry, I said it before, and please allow me to say it again:")

#text("I have noticed over time that you are beginning to use your God-given talents for the good of others, more and more. To me, it is simply your, conscious or subconscious, realization of God’s purpose for you: to use your talent to help others. If you keep widening this realization, your platform for reaching and influencing others will become World wide, Then, you can Really change the World for the better.")

#text("It’s happening right now, and here it is,")#linebreak()#text(" David")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a614b841f31ef078012587b93c01f2916076c2d1a6fa35ca40af747449dc53-88e4d1e5fa747b704e7f93601f47e0a863201e5fb0a7a8583aa9dcea600ac8be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-559849")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("Good observations here: ")#link("https://hjstein.blogspot.com/2020/05/covid-19-data-collection-garbage-in_33.html?m=1")[#text("https://hjstein.blogspot.com/2020/05/covid-19-data-collection-garbage-in_33.html?m=1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-561388")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2020")])]

#text("Note this COVID-19 DREAM Challenge is just starting: ")#link("https://www.synapse.org/#!Synapse:syn21849255/wiki/601865")[#text("https://www.synapse.org/#!Synapse:syn21849255/wiki/601865")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-564577")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("FYI, Government money: ")#link("https://beta.sam.gov/opp/d73216413c334184a7bc1df690946ee7/view?keywords=IARPA&sort=-relevance&index=&is_active=true&page=1")[#text("https://beta.sam.gov/opp/d73216413c334184a7bc1df690946ee7/view?keywords=IARPA&sort=-relevance&index=&is_active=true&page=1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99425511ad62bc22a2cc4d2d3b0c259c52c1f11ffa2de638939e3ed11140d762-1737602942a691904a3d8554b6d042fe88e6cc2186c5ee71c9ba493d70cbc300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zcp")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-592567")[#strong[#text("Zcp")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("Who can be believed? ")#link("https://www.un.org/en/coronavirus")[#text("https://www.un.org/en/coronavirus")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99425511ad62bc22a2cc4d2d3b0c259c52c1f11ffa2de638939e3ed11140d762-1737602942a691904a3d8554b6d042fe88e6cc2186c5ee71c9ba493d70cbc300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of I am not chiNA 007")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-592705")[#strong[#text("I am not chiNA 007")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("American, come on! For human being, it is a terrible disaster!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8648153892e62a8b8530cf1aba25e67660694cf59892eb8d32a997cd923b41b0-26da1c25c12c26e10761c7396dd14c8e3ac0c5b754112828d62feaaa61ab7022.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/25/polymath-proposal-clearinghouse-for-crowdsourcing-covid-19-data-and-data-cleaning-requests/#comment-623004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2021")])]

#text("Collatz")

#text("Could a Collatz like process explain why there is matter and not anti-matter in our universe. I was never satisfied with the mutual destruction explanation. But a Collatz process that skewed everything to “matter” makes more sense to me.")
]
