// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/
// Converted to Typst by tao2typ: "2026-10-14T16:38:17.332832+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Long gaps in sieved sets", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Long gaps in sieved sets")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 February 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/")[#text("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://faculty.math.illinois.edu/~ford/")[#text("Kevin Ford")]#text(", Sergei Konyagin, ")#link("http://www.magd.ox.ac.uk/member-of-staff/james-maynard/")[#text("James Maynard")]#text(", ")#link("https://www.math.dartmouth.edu/~carlp/")[#text("Carl Pomerance")]#text(", and I have uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1802.07604")[#text("Long gaps in sieved sets")]#text("“, submitted to ")#link("https://www.ems-ph.org/journals/journal.php?jrn=jems")[#text("J. Europ. Math. Soc.")]#text(".")

#text("This paper originated from the ")#link("https://www.msri.org/programs/297")[#text("MSRI program in analytic number theory last year")]#text(", and was centred around variants of the question of finding large gaps between primes. As discussed for instance in ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("this previous post")]#text(", it is now known that within the set of primes ")#mi("{{\\mathcal P} = \\{2,3,5,\\dots\\}}")#text(", one can find infinitely many adjacent elements ")#mi("{a,b}")#text(" whose gap ")#mi("{b-a}")#text(" obeys a lower bound of the form")

#align(center)[#tao-fit-display[#mitex("b-a \\gg \\log a \\frac{\\log_2 a \\log_4 a}{\\log_3 a}")]]

#text("where ")#mi("{\\log_k}")#text(" denotes the ")#mi("{k}")#text("-fold iterated logarithm. This compares with the trivial bound of ")#mi("{b-a \\gg \\log a}")#text(" that one can obtain from the prime number theorem and the pigeonhole principle. Several years ago, Pomerance posed the question of whether analogous improvements to the trivial bound can be obtained for such sets as")

#align(center)[#tao-fit-display[#mitex("{\\mathcal P}_2 = \\{ n \\in {\\bf N}: n^2+1 \\text{ prime} \\}.")]]

#text("Here there is the obvious initial issue that this set is not even known to be infinite (this is the fourth ")#link("https://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau problem")]#text("), but let us assume for the sake of discussion that this set is indeed infinite, so that we have an infinite number of gaps to speak of. Standard sieve theory techniques give upper bounds for the density of ")#mi("{{\\mathcal P}_2}")#text(" that is comparable (up to an absolute constant) to the prime number theorem bounds for ")#mi("{{\\mathcal P}}")#text(", so again we can obtain a trivial bound of ")#mi("{b-a \\gg \\log a}")#text(" for the gaps of ")#mi("{{\\mathcal P}_2}")#text(". In this paper we improve this to")

#align(center)[#tao-fit-display[#mitex("b-a \\gg \\log a \\log^c_2 a")]]

#text("for an absolute constant ")#mi("{c>0}")#text("; this is not as strong as the corresponding bound for ")#mi("{{\\mathcal P}}")#text(", but still improves over the trivial bound. In fact we can handle more general “sifted sets” than just ")#mi("{{\\mathcal P}_2}")#text(". Recall from the sieve of Eratosthenes that the elements of ")#mi("{{\\mathcal P}}")#text(" in, say, the interval ")#mi("{[x/2, x]}")#text(" can be obtained by removing from ")#mi("{[x/2, x]}")#text(" one residue class modulo ")#mi("{p}")#text(" for each prime up to ")#mi("{\\sqrt{x}}")#text(", namely the class ")#mi("{0}")#text(" mod ")#mi("{p}")#text(". In a similar vein, the elements of ")#mi("{{\\mathcal P}_2}")#text(" in ")#mi("{[x/2,x]}")#text(" can be obtained by removing for each prime ")#mi("{p}")#text(" up to ")#mi("{x}")#text(" zero, one, or two residue classes modulo ")#mi("{p}")#text(", depending on whether ")#mi("{-1}")#text(" is a quadratic residue modulo ")#mi("{p}")#text(". On the average, one residue class will be removed (this is a very basic case of the ")#link("https://en.wikipedia.org/wiki/Chebotarev%27s_density_theorem")[#text("Chebotarev density theorem")]#text("), so this sieving system is “one-dimensional on the average”. Roughly speaking, our arguments apply to any other set of numbers arising from a sieving system that is one-dimensional on average. (One can consider other dimensions also, but unfortunately our methods seem to give results that are worse than a trivial bound when the dimension is less than or greater than one.)")

#text("The standard “Erdős-Rankin” method for constructing long gaps between primes proceeds by trying to line up some residue classes modulo small primes ")#mi("{p}")#text(" so that they collectively occupy a long interval. A key tool in doing so are the smooth number estimates of de Bruijn and others, which among other things assert that if one removes from an interval such as ")#mi("{[1,x]}")#text(" all the residue classes ")#mi("{0}")#text(" mod ")#mi("{p}")#text(" for ")#mi("{p}")#text(" between ")#mi("{x^{1/u}}")#text(" and ")#mi("{x}")#text(" for some fixed ")#mi("{u>1}")#text(", then the set of survivors has exceptionally small density (roughly of the order of ")#mi("{u^{-u}}")#text(", with the precise density given by the ")#link("https://en.wikipedia.org/wiki/Dickman_function")[#text("Dickman function")]#text("), in marked contrast to the situation in which one randomly removes one residue class for each such prime ")#mi("{p}")#text(", in which the density is more like ")#mi("{1/u}")#text(". One generally exploits this phenomenon to sieve out almost all the elements of a long interval using some of the primes available, and then using the remaining primes to cover up the remaining elements that have not already been sifted out. In the more recent work on this problem, advanced combinatorial tools such as hypergraph covering lemmas are used for the latter task.")

#text("In the case of ")#mi("{{\\mathcal P}_2}")#text(", there does not appear to be any analogue of smooth numbers, in the sense that there is no obvious way to arrange the residue classes so that they have significantly fewer survivors than a random arrangement. Instead we adopt the following semi-random strategy to cover an interval ")#mi("{[1,y]}")#text(" by residue classes. Firstly, we randomly remove residue classes for primes ")#mi("{p}")#text(" up to some intermediate threshold ")#mi("{z}")#text(" (smaller than ")#mi("{y}")#text(" by a logarithmic factor), leaving behind a preliminary sifted set ")#mi("{S_{[2,z]}}")#text(". Then, for each prime ")#mi("{p}")#text(" between ")#mi("{z}")#text(" and another intermediate threshold ")#mi("{x/2}")#text(", we remove a residue class mod ")#mi("{p}")#text(" that maximises (or nearly maximises) its intersection with ")#mi("{S_{[2,z]}}")#text(". This ends up reducing the number of survivors to be significantly below what one would achieve if one selects residue classes randomly, particularly if one also uses the hypergraph covering lemma from ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("our previous paper")]#text(". Finally, we cover each the remaining survivors by a residue class from a remaining available prime.")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-492903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("Can this 2-steps removal strategy be generalized into 3-steps removal strategy (by introducing another intermediate threshold ")#mi("w")#text(" between ")#mi("z")#text(" and ")#mi("x/2")#text(")?")#linebreak()#text(" This seems to lead to a general multisteps removal strategy (based on increasing sequence of intermediate thresholds ")#mi("z_1 < z_2 < ... < x/2")#text(" whose number is not necessarily fixed, but may slowly increasing with ")#mi("x")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-492918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("Our initial selection strategy was indeed of this form, but we realised later that it was unnecessarily complicated, and that a two-step procedure actually gave comparable bounds. (Strictly speaking it is a three-step process, there is a standard “final cleanup” phase in which one uses the primes between ")#mi("x/2")#text(" to ")#mi("x")#text(" to eliminate the few elements that survive all the previous sieving steps, but nothing particularly interesting or innovative happens in this final phase.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-492935")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2018")])]

#text("infinitely adjacent -> infinitely many adjacent [??]")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-492995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("Conjecture: For any positive integer, n ≥ 2, there are at least two prime numbers between n^2 and (n+1)^2.")

#text("We can show that")

#text("π( (n+1)^2 ) – π (n^2 ) > π (.5*n ) ≥ 2 when n≥ 6.")

#text("Here’s a proof:")

#text("According to the Prime Number Theorem, we have")

#text("π( (n+1)^2 ) = (n+1)^2/log((n+1)^2) +/- error;")

#text("π( n^2 ) = n^2/log(n^2) +/- error;")

#text("π( .5×n ) = .5×n/log(.5×n) +/- error")

#text("= .5×n/log(n) +/- error")

#text("Therefore,")

#text("π( (n+1)^2 ) – π( n^2 ) = 2n/log(n^2) +/-error = n/log(n) +/- error.")

#text("Hence, π( (n+1)^2 ) – π( n^2 ) > π( .5×n ).")

#text("Thus, for n≥ 6 the conjecture is affirmed.")

#text("Moreover, the conjecture is easily affirmed for n≥2.")

#link("https://www.quora.com/Can-we-disprove-that-for-any-positive-integer-n-there-are-at-least-two-prime-numbers-between-n-2-and-n-1-2/answer/David-Cole-146")[#text("https://www.quora.com/Can-we-disprove-that-for-any-positive-integer-n-there-are-at-least-two-prime-numbers-between-n-2-and-n-1-2/answer/David-Cole-146")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Landau’s Fourth Problem: Are there infinitely many primes of the form, (2n)^2+1, where n is a positive integer?")

#text("The answer for Landau’s Fourth Problem is affirmative!")

#text("Relevant Reference Link:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2020/01/27/louis-nirenberg/")[#text("Louis Nirenberg")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493044")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("May I ask a non-mathematician question: How does a mathematician collaboration work when then collaborators are not at the same university? I imagine it quite difficult sharing ideas between 5 people just via e-mail and sometimes via skype meeting? In contrast to other areas of science, I imagine that in mathematics discussions about the ideas are more difficult (which is why in average math papers there are less authors than on physics papers). Do you also use (hidden) wordpress discussions as for the polymath projects? (Maybe your answer could give some hints for improving the efficiency of my collaborations)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Well in this case, the four of us were physically present together at the MSRI program, so we definitely met face to face for core of the project. But then the writing up process was done almost entirely by email. More generally, I think collaborations in mathematics nowadays typically involve a short period of meeting physically (for say a week) to try to work on the core aspect of the problem (e.g. solving what one believes to be the most difficult step or most crucial case) and then working everything else out online using more or less off-the-shelf tools (email, Skype, dropbox, subversion, git, etc..). In a few cases I have also used private blogs, wikis, discussion groups, and even at one point a Facebook page.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493114")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("In your set, P_2, have you considered the possibility, b – a ≥ 2a, for infinitely many adjacent elements of that set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493122")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("In that case the theorem is trivially true (")#mi("2a")#text(" is much larger than ")#mi("\\log a \\log^c a")#text(" for large ")#mi("a")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Yes! You’re correct. But a gap of size 2a for b – a is much too big. There are primes galore in such gaps between adjacent elements, a and b, if they exist in P_2. I believe max(b – a) = Ω × a where 0 < Ω < 0.2 (or much less for large a).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-493151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2018")])]

#text("For large a, the parameter, Ω, is constrained according to the distribution of primes or according to the great Prime Number Theorem (PNT).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/454e1bd18a8ce95bd29509f17f6e7dca87858b56e4c109ee720a8199d1f7c234-80b5898c683f01c57c2ca04a0525513cf878a423a87f9ac8affd70a5646bc503.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Cureg Saccuan")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-507115")[#strong[#text("John Cureg Saccuan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2018")])]

#text("Title: DNA Of Prime Numbers & Saccuan’s Factorization Method")

#text("Noted:")#linebreak()#text(" Saccuan’s factorization method (Improvement of Quadratic sieve and application of Legendre’s conjecture)")

#text("P=w^2+m")#linebreak()#text(" P=pq")#linebreak()#text(" p=GCD[P,x^2+m] or q=GCD[P,x^2+m]")

#text("Where:")#linebreak()#text(" w=Floor[P^.5]")#linebreak()#text(" m=P-w^2 or Mod(P,w^2)")#linebreak()#text(" Range: x={0,1…w or 4*w}")

#text("Overview:")

#text("Theorem:")#linebreak()#text(" There are many infinite natural Integers in the form of P=w^2+m")

#text("Legendre’s conjecture:")#linebreak()#text(" Does there always exist at least one prime between consecutive perfect squares?")

#text("w^2 (w+1)^2")

#text("Counterexample:")

#text("16=4^2+0")#linebreak()#text(" 17=4^2+1(Prime)")#linebreak()#text(" 18=4^2+2")#linebreak()#text(" 19=4^2+3")#linebreak()#text(" 20=4^2+4")#linebreak()#text(" 21=4^2+5")#linebreak()#text(" 22=4^2+6")#linebreak()#text(" 23=4^2+7(Prime)")#linebreak()#text(" 24=4^2+8")#linebreak()#text(" 25=(4+1)^2+0")

#text("Saccuan’s factorization method")

#text("Example:")

#text("P=21 then w=4 and m=5")#linebreak()#text(" x=0;GCD[21,0^2+5]=1")#linebreak()#text(" x=1;GCD[21,1^2+5]=3")#linebreak()#text(" x=2;GCD[21,2^2+5]=3")#linebreak()#text(" x=3;GCD[21,3^2+5]=7")#linebreak()#text(" x=4;GCD[21,4^2+5]=21")#linebreak()#text(" x=5;GCD[21,5^2+5]=3")#linebreak()#text(" x=6;GCD[21,6^2+5]=1")#linebreak()#text(" x=7;GCD[21,7^2+5]=3")#linebreak()#text(" x=8;GCD[21,8^2+5]=3")#linebreak()#text(" *")#linebreak()#text(" *")#linebreak()#text(" *")#linebreak()#text(" *")#linebreak()#text(" x=infinity")

#link("https://www.dropbox.com/sh/shq0l3eg42rfy9h/AAC7SetZQPY68GUYriLql4Gua?dl=0")[#text("https://www.dropbox.com/sh/shq0l3eg42rfy9h/AAC7SetZQPY68GUYriLql4Gua?dl=0")]

#text("Objective:Please help me to proof that I’m correct in my method. I want to add this in Wikipedia, new type of factoring algorithms at Integer factorization section. but i need first to verify by other mathematician.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-693042")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2026")])]

#text("It seems that the iterated logarithm frequently appears in number theory. Also in probability theory, there are also results like the law of the iterated logarithm. What is so special about a function of the iterated logarithm?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-693090")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("I am ")#link("https://claude.ai/share/928a1f05-37aa-4ce2-8400-2d20ec5d2d93")[#text("outsourcing this question to an AI")]#text(".")

#text("The double logarithm is less mysterious than it might initially appear, and is mostly attributable to stacking together two separate logarithmic effects. In the case of the law of the iterated logarithm, it comes from stacking together the dyadic sparsification trick (which adds one log) with gaussian tail behavior (which adds another log). In the case of e.g., Mertens’ theorem ")#mi("\\sum_{p \\leq x} \\frac{1}{p} = \\log\\log x + O(1)")#text(", it morally comes from refining the harmonic series (which diverges by one log) by the prime number theorem (which adds another log).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-693098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("Your remarks have completely cleared up my question. Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-693249")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2026")])]

#text("Prof. Tao,")

#text("You said that The double logarithm is less mysterious than it might initially appear, ")#emph[#text("and is mostly attributable to stacking together two separate logarithmic effects")]#text(".")

#text("Is the appearance of the double logarithm in the Erdős–Kac theorem and the Hardy–Ramanujan theorem also due to this reason? Could you elaborate on what the two separate logarithmic effects are in these two theorem? I’ve been puzzled by these two theorems for a long time.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/02/21/long-gaps-in-sieved-set/#comment-693250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2026")])]

#text("The double logarithm here comes from ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ second theorem")]#text(" ")#mi("\\sum_{p \\leq x} \\frac{1}{p} \\sim \\log\\log x")#text(", which morally speaking comes from stacking together the single logarithm from the divergence ")#mi("\\sum_{n \\leq x} \\frac{1}{n} \\sim \\log x")#text(" of the harmonic series with the additional logarithm ")#mi("\\pi(x) \\sim \\frac{x}{\\log x}")#text(" coming from the prime number theorem. (The stacking here is easiest to see by using ")#link("https://en.wikipedia.org/wiki/Cauchy_condensation_test")[#text("Cauchy condensation")]#text(".)")
]
]
]
]
]
