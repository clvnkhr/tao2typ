// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/
// Converted to Typst by tao2typ: "2026-10-14T10:56:38.178280+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Maryam Mirzakhani New Frontiers Prize", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Maryam Mirzakhani New Frontiers Prize")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 December 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/")[#text("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short post to announce that nominations are now open for the ")#link("https://breakthroughprize.org/News/56")[#text("Maryam Mirzakhani New Frontiers Prize")]#text(", which is a newly announced annual $50,000 award from the ")#link("https://breakthroughprize.org/")[#text("Breakthrough Prize Foundation")]#text(" presented to early-career, women mathematicians who have completed their PhDs within the past two years, and recognizes outstanding research achievement. (I will be serving on the prize committee.) Nominations for this (and other breakthrough prizes) can be made at ")#link("https://breakthroughprize.org/index.php?controller=Panel&action=nominations&p=3")[#text("this page")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2019")])]

#text("Is 2 years long enough for important work to propagate thru the community enough to be recognized for a prize like this? Does it mean emphasizing flashy results over quieter ones that can still be deep?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532172")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")])]

#text("I agree that the 2 year out of PhD requirement diminishes the impact of this prize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c82c7cc2844ea4a09fa035f10a6d14a236e1bdaec124e491b130d7bb2a13e22c-13298fcdbd489cb1a482040282300bfe874a934e450e343005409044fa8a885f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532637")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2019")])]

#text("It is more of a merely glorified postdoc that encourages women ‘The prize may be shared by two or more individuals’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")])]

#text("I think this prize is intended to boost the career of young, promising, female mathematicians, at a time when they are being considered for faculty positions. It makes the hiring much easier to justify because Terry implicitly endorses it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532227")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2019")])]

#text("This sort of makes sense, except that “excellent young female mathematicians” is not a demographic that has any trouble finding jobs! I think it makes much more sense to look out for “average young female mathematicians” and cater opportunities towards them, but I do not know how to accomplish that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fd451b459b109a7682320629e06b514263ed82218aae8102294ab8fe79f0b6b-e8d66606bcd5a70328b9ef2a032413be63354bbe522f313167e228014b69fdc6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Claudia")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532270")[#strong[#text("Claudia")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2019")])]

#text("Sigh. How did I know right after seeing “Maryam Mirzakhani” and “prize” that it would be something just for girls. I’m a female grad student in math now and just pray to god that if I ever become famous, people will view me just as a mathematician and not a girl mathematician. I wish we could all just stop focusing on gender and only care about merit. Sad to see Tao contributing to the sexism.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2019")])]

#text("I’ve thought of this sort of thing as an effort to partly undo the effects of centuries of sexism that continues to the present day. And math is a creative discipline, not like the high jump where you can measure merit with a ruler. So it’s important to bring a wide range of perspectives into the field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50bdf7aa9fe8ed7f2f7667e035baa7073e8bd94dfe75f96e2fec24ade665819f-b085053f71ad58a6187c5cb4fe1a6aa7a7cc23043ee3cb33976abb1c74f30d2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raja")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532440")[#strong[#text("Raja")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2019")])]

#text("“I’m a female grad student in math now….”")

#text("No, you’re not.")

#text("Sad to see men coming out of the woodwork to whine about this prize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00e0f8f8618b9364ec9724f3d9ad0f99338d8176247e9f3091c3ec012d9ce26e-6c078d955982314a7eb262fef6958ae50b77537cc61f8973ad583fc89683345f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wilhelm")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532442")[#strong[#text("Wilhelm")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2019")])]

#text("“I’m a female grad student in math now…”")

#text("No, you’re not.")

#text("Tao is focused on merit. That’s why awarding women with talent, who will have overcome several institutional disadvantages and biases (from people like you) means awarding people with MORE merit.")

#text("So telling these knee-jerk, semi-hysterical reactions to Tao trying to do the right thing and FIX some of the problems that others created with their cowardice and biases.")

#text("Sad to see YOU focusing on perpetuation of the problems. Telling…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b7f93a769af8bae7165c15f49f1b40137e3de971013690e48ea1f9cd6004e5f-4a98e9ecd67204bc76bbf35f2daba958a085024e260ee58b7f36171ec7a762c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kevin citron")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532406")[#strong[#text("kevin citron")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")])]

#text("ah yes. more reverse sexism")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wilhelm")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532439")[#strong[#text("Wilhelm")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2019")])]

#text("Oh, yes. Another. Eternal. Male. Victim.")

#text("Have you considered testicular implants?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532642")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2019")])]

#text("If men are going around punching women, is the right thing to do punish the men or have women start punching men? Two wrongs don’t make a right. Stop with these sexist prizes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0d2cd49f6dfb23eb46c446a705a356be7924c59908034a12d2c0729718d182-d62118ff4d7169e8e7c3a15b725e3d6898714cf7c4172266c4db1b1f31e250c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2019/12/10/maryam-mirzakhani-new-frontiers-prize/#comment-532746")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("It’s disheartening to see such a renowned mathematician participate in this nonsense. The only reasonable explanation is that he is forced to do so (or is trying to avoid future trouble). But then it is even more disheartening.")
]
