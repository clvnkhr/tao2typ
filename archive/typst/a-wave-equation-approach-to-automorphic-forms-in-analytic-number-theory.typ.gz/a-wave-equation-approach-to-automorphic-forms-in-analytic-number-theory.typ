// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/
// Converted to Typst by tao2typ: "2026-10-14T15:19:32.185964+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A wave equation approach to automorphic forms in analytic number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A wave equation approach to automorphic forms in analytic number theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 August 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/")[#text("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://en.wikipedia.org/wiki/Poincar%C3%A9_half-plane_model")[#text("Poincaré upper half-plane")]#text(" ")#mi("{{\\mathbf H} := \\{ z: \\text{Im}(z) > 0 \\}}")#text(" (with a boundary consisting of the real line ")#mi("{{\\bf R}}")#text(" together with the point at infinity ")#mi("{\\infty}")#text(") carries an action of the projective special linear group")

#align(center)[#tao-fit-display[#mitex("\\text{PSL}_2({\\bf R}) := \\{ \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}: a,b,c,d \\in {\\bf R}: ad-bc = 1 \\} / \\{\\pm 1\\}")]]

#text("via fractional linear transformations: ")#metadata(none) <tao-06e922f7efd9cee29270>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} z := \\frac{az+b}{cz+d}.")]]

#text("Here and in the rest of the post we will abuse notation by identifying elements ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" of the special linear group ")#mi("{\\text{SL}_2({\\bf R})}")#text(" with their equivalence class ")#mi("{\\{ \\pm \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\}}")#text(" in ")#mi("{\\text{PSL}_2({\\bf R})}")#text("; this will occasionally create or remove a factor of two in our formulae, but otherwise has very little effect, though one has to check that various definitions and expressions (such as ")#link(<tao-06e922f7efd9cee29270>)[#text("(1)")]#text(") are unaffected if one replaces a matrix ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" by its negation ")#mi("{\\begin{pmatrix} -a & -b \\\\ -c & -d \\end{pmatrix}}")#text(". In particular, we recommend that the reader ignore the signs ")#mi("{\\pm}")#text(" that appear from time to time in the discussion below.")

#text("As the action of ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" on ")#mi("{{\\mathbf H}}")#text(" is transitive, and any given point in ")#mi("{{\\mathbf H}}")#text(" (e.g. ")#mi("{i}")#text(") has a stabiliser isomorphic to the projective rotation group ")#mi("{\\text{PSO}_2({\\bf R})}")#text(", we can view the Poincaré upper half-plane ")#mi("{{\\mathbf H}}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" for ")#mi("{\\text{PSL}_2({\\bf R})}")#text(", and more specifically the quotient space of ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" of a maximal compact subgroup ")#mi("{\\text{PSO}_2({\\bf R})}")#text(". In fact, we can make the half-plane a ")#link("https://en.wikipedia.org/wiki/Symmetric_space")[#text("symmetric space")]#text(" for ")#mi("{\\text{PSL}_2({\\bf R})}")#text(", by endowing ")#mi("{{\\mathbf H}}")#text(" with the ")#link("https://en.wikipedia.org/wiki/Riemannian_manifold#Riemannian_metrics")[#text("Riemannian metric")]

#align(center)[#tao-fit-display[#mitex("dg^2 := \\frac{dx^2 + dy^2}{y^2}")]]

#text("(using Cartesian coordinates ")#mi("{z=x+iy}")#text("), which is invariant with respect to the ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" action. Like any other Riemannian metric, the metric on ")#mi("{{\\mathbf H}}")#text(" generates a number of other important geometric objects on ")#mi("{{\\mathbf H}}")#text(", such as the ")#link("https://en.wikipedia.org/wiki/Riemannian_manifold#Riemannian_manifolds_as_metric_spaces_2")[#text("distance function")]#text(" ")#mi("{d(z,w)}")#text(" which can be computed to be given by the formula ")#metadata(none) <tao-bcae0416621b3db43d8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("2(\\cosh(d(z_1,z_2))-1) = \\frac{\\left|z_1-z_2\\right|^2}{\\text{Im}(z_1) \\text{Im}(z_2)},", block: true)]]

#text("the ")#link("https://en.wikipedia.org/wiki/Volume#Volume_in_differential_geometry")[#text("volume measure")]#text(" ")#mi("{\\mu = \\mu_{\\mathbf H}}")#text(", which can be computed to be")

#align(center)[#tao-fit-display[#mitex("d\\mu = \\frac{dx dy}{y^2},")]]

#text("and the ")#link("https://en.wikipedia.org/wiki/Laplace%E2%80%93Beltrami_operator")[#text("Laplace-Beltrami operator")]#text(", which can be computed to be ")#mi("{\\Delta = y^2 (\\frac{\\partial^2}{\\partial x^2} + \\frac{\\partial^2}{\\partial y^2})}")#text(" (here we use the negative definite sign convention for ")#mi("{\\Delta}")#text("). As the metric ")#mi("{dg}")#text(" was ")#mi("{\\text{PSL}_2({\\bf R})}")#text("-invariant, all of these quantities arising from the metric are similarly ")#mi("{\\text{PSL}_2({\\bf R})}")#text("-invariant in the appropriate sense.")

#text("The ")#link("https://en.wikipedia.org/wiki/Gaussian_curvature")[#text("Gauss curvature")]#text(" of the Poincaré half-plane can be computed to be the constant ")#mi("{-1}")#text(", thus ")#mi("{{\\mathbf H}}")#text(" is a model for two-dimensional ")#link("https://en.wikipedia.org/wiki/Hyperbolic_geometry")[#text("hyperbolic geometry")]#text(", in much the same way that the unit sphere ")#mi("{S^2}")#text(" in ")#mi("{{\\bf R}^3}")#text(" is a model for two-dimensional ")#link("https://en.wikipedia.org/wiki/Spherical_geometry")[#text("spherical geometry")]#text(" (or ")#mi("{{\\bf R}^2}")#text(" is a model for two-dimensional ")#link("https://en.wikipedia.org/wiki/Euclidean_geometry")[#text("Euclidean geometry")]#text("). (Indeed, ")#mi("{{\\mathbf H}}")#text(" is isomorphic (via projection to a null hyperplane) to the upper unit hyperboloid ")#tao-math("{\\{ (x,t) \\in {\\bf R}^{2+1}: t = \\sqrt{1+\\left|x\\right|^2}\\}}", block: false)#text(" in the ")#link("https://en.wikipedia.org/wiki/Minkowski_space")[#text("Minkowski spacetime")]#text(" ")#mi("{{\\bf R}^{2+1}}")#text(", which is the direct analogue of the unit sphere in Euclidean spacetime ")#mi("{{\\bf R}^3}")#text(" or the plane ")#mi("{{\\bf R}^2}")#text(" in Galilean spacetime ")#mi("{{\\bf R}^2 \\times {\\bf R}}")#text(".)")

#text("One can inject arithmetic into this geometric structure by passing from the Lie group ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" to the ")#link("https://en.wikipedia.org/wiki/Modular_group")[#text("full modular group")]

#align(center)[#tao-fit-display[#mitex("\\text{PSL}_2({\\bf Z}) := \\{ \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}: a,b,c,d \\in {\\bf Z}: ad-bc = 1 \\} / \\{\\pm 1\\}")]]

#text("or ")#link("https://en.wikipedia.org/wiki/Congruence_subgroup")[#text("congruence subgroups")]#text(" such as ")#metadata(none) <tao-7298126971d246bb3e6c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Gamma_0(q) := \\{ \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\in \\text{PSL}_2({\\bf Z}): c = 0\\ (q) \\} / \\{ \\pm 1 \\}")]]

#text("for natural number ")#mi("{q}")#text(", or to the discrete stabiliser ")#mi("{\\Gamma_\\infty}")#text(" of the point at infinity: ")#metadata(none) <tao-d8d63468eb2a24c10e43>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Gamma_\\infty := \\{ \\pm \\begin{pmatrix} 1 & b \\\\ 0 & 1 \\end{pmatrix}: b \\in {\\bf Z} \\} / \\{\\pm 1\\}.")]]

#text("These are discrete subgroups of ")#mi("{\\text{PSL}_2({\\bf R})}")#text(", nested by the subgroup inclusions")

#align(center)[#tao-fit-display[#mitex("\\Gamma_\\infty \\leq \\Gamma_0(q) \\leq \\Gamma_0(1)=\\text{PSL}_2({\\bf Z}) \\leq \\text{PSL}_2({\\bf R}).")]]

#text("There are many further discrete subgroups of ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" (known collectively as ")#link("https://en.wikipedia.org/wiki/Fuchsian_group")[#text("Fuchsian groups")]#text(") that one could consider, but we will focus attention on these three groups in this post.")

#text("Any discrete subgroup ")#mi("{\\Gamma}")#text(" of ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" generates a quotient space ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(", which in general will be a non-compact two-dimensional ")#link("https://en.wikipedia.org/wiki/Orbifold")[#text("orbifold")]#text(". One can understand such a quotient space by working with a ")#link("https://en.wikipedia.org/wiki/Fundamental_domain")[#text("fundamental domain")]#text(" ")#mi("{\\text{Fund}( \\Gamma \\backslash {\\mathbf H})}")#text(" – a set consisting of a single representative of each of the orbits ")#mi("{\\Gamma z}")#text(" of ")#mi("{\\Gamma}")#text(" in ")#mi("{{\\mathbf H}}")#text(". This fundamental domain is by no means uniquely defined, but if the fundamental domain is chosen with some reasonable amount of regularity, one can view ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(" as the fundamental domain with the boundaries glued together in an appropriate sense. Among other things, fundamental domains can be used to induce a volume measure ")#mi("{\\mu = \\mu_{\\Gamma \\backslash {\\mathbf H}}}")#text(" on ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(" from the volume measure ")#mi("{\\mu = \\mu_{\\mathbf H}}")#text(" on ")#mi("{{\\mathbf H}}")#text(" (restricted to a fundamental domain). By abuse of notation we will refer to both measures simply as ")#mi("{\\mu}")#text(" when there is no chance of confusion.")

#text("For instance, a fundamental domain for ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(" is given (up to null sets) by the strip ")#tao-math("{\\{ z \\in {\\mathbf H}: \\left|\\text{Re}(z)\\right| < \\frac{1}{2} \\}}", block: false)#text(", with ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(" identifiable with the cylinder formed by gluing together the two sides of the strip. A fundamental domain for ")#mi("{\\text{PSL}_2({\\bf Z}) \\backslash {\\mathbf H}}")#text(" is famously given (again up to null sets) by an upper portion ")#tao-math("{\\{ z \\in {\\mathbf H}: \\left|\\text{Re}(z)\\right| < \\frac{1}{2}; \\left|z\\right| > 1 \\}}", block: false)#text(", with the left and right sides again glued to each other, and the left and right halves of the circular boundary glued to itself. A fundamental domain for ")#mi("{\\Gamma_0(q) \\backslash {\\mathbf H}}")#text(" can be formed by gluing together")

#align(center)[#tao-fit-display[#mitex("[\\text{PSL}_2({\\bf Z}) : \\Gamma_0(q)] = q \\prod_{p|q} (1 + \\frac{1}{p}) = q^{1+o(1)}")]]

#text("copies of a fundamental domain for ")#mi("{\\text{PSL}_2({\\bf Z}) \\backslash {\\mathbf H}}")#text(" in a rather complicated but interesting fashion.")

#text("While fundamental domains can be a convenient choice of coordinates to work with for some computations (as well as for drawing appropriate pictures), it is geometrically more natural to avoid working explicitly on such domains, and instead work directly on the quotient spaces ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(". In order to analyse functions ")#mi("{f: \\Gamma \\backslash {\\mathbf H} \\rightarrow {\\bf C}}")#text(" on such orbifolds, it is convenient to lift such functions back up to ")#mi("{{\\mathbf H}}")#text(" and identify them with functions ")#mi("{f: {\\mathbf H} \\rightarrow {\\bf C}}")#text(" which are ")#emph[#mi("{\\Gamma}")#text("-automorphic")]#text(" in the sense that ")#mi("{f( \\gamma z ) = f(z)}")#text(" for all ")#mi("{z \\in {\\mathbf H}}")#text(" and ")#mi("{\\gamma \\in \\Gamma}")#text(". Such functions will be referred to as ")#link("https://en.wikipedia.org/wiki/Automorphic_form")[#mi("{\\Gamma}")#text("-automorphic forms")]#text(", or ")#emph[#text("automorphic forms")]#text(" for short (we always implicitly assume all such functions to be measurable). (Strictly speaking, these are the automorphic forms with trivial ")#link("https://en.wikipedia.org/wiki/Factor_of_automorphy")[#text("factor of automorphy")]#text("; one can certainly consider other factors of automorphy, particularly when working with ")#link("https://en.wikipedia.org/wiki/Modular_form")[#text("holomorphic modular forms")]#text(", which corresponds to sections of a more non-trivial line bundle over ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(" than the trivial bundle ")#mi("{(\\Gamma \\backslash {\\mathbf H}) \\times {\\bf C}}")#text(" that is implicitly present when analysing scalar functions ")#mi("{f: {\\mathbf H} \\rightarrow {\\bf C}}")#text(". However, we will not discuss this (important) more general situation here.)")

#text("An important way to create a ")#mi("{\\Gamma}")#text("-automorphic form is to start with a non-automorphic function ")#mi("{f: {\\mathbf H} \\rightarrow {\\bf C}}")#text(" obeying suitable decay conditions (e.g. bounded with compact support will suffice) and form the ")#link("https://en.wikipedia.org/wiki/Poincar%C3%A9_series_(modular_form)")[#text("Poincaré series")]#text(" ")#mi("{P_\\Gamma[f]: {\\mathbf H} \\rightarrow {\\bf C}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("P_{\\Gamma}[f](z) = \\sum_{\\gamma \\in \\Gamma} f(\\gamma z),")]]

#text("which is clearly ")#mi("{\\Gamma}")#text("-automorphic. (One could equivalently write ")#mi("{f(\\gamma^{-1} z)}")#text(" in place of ")#mi("{f(\\gamma z)}")#text(" here; there are good argument for both conventions, but I have ultimately decided to use the ")#mi("{f(\\gamma z)}")#text(" convention, which makes explicit computations a little neater at the cost of making the group actions work in the opposite order.) Thus we naturally see sums over ")#mi("{\\Gamma}")#text(" associated with ")#mi("{\\Gamma}")#text("-automorphic forms. A little more generally, given a subgroup ")#mi("{\\Gamma_\\infty}")#text(" of ")#mi("{\\Gamma}")#text(" and a ")#mi("{\\Gamma_\\infty}")#text("-automorphic function ")#mi("{f: {\\mathbf H} \\rightarrow {\\bf C}}")#text(" of suitable decay, we can form a relative Poincaré series ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma}[f]: {\\mathbf H} \\rightarrow {\\bf C}}")#text(" by")

#align(center)[#tao-fit-display[#mitex("P_{\\Gamma_\\infty \\backslash \\Gamma}[f](z) = \\sum_{\\gamma \\in \\text{Fund}(\\Gamma_\\infty \\backslash \\Gamma)} f(\\gamma z)")]]

#text("where ")#mi("{\\text{Fund}(\\Gamma_\\infty \\backslash \\Gamma)}")#text(" is any fundamental domain for ")#mi("{\\Gamma_\\infty \\backslash \\Gamma}")#text(", that is to say a subset of ")#mi("{\\Gamma}")#text(" consisting of exactly one representative for each right coset of ")#mi("{\\Gamma_\\infty}")#text(". As ")#mi("{f}")#text(" is ")#mi("{\\Gamma_\\infty}")#text("-automorphic, we see (if ")#mi("{f}")#text(" has suitable decay) that ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma}[f]}")#text(" does not depend on the precise choice of fundamental domain, and is ")#mi("{\\Gamma}")#text("-automorphic. These operations are all compatible with each other, for instance ")#mi("{P_\\Gamma = P_{\\Gamma_\\infty \\backslash \\Gamma} \\circ P_{\\Gamma_\\infty}}")#text(". A key example of Poincaré series are the ")#link("https://en.wikipedia.org/wiki/Real_analytic_Eisenstein_series")[#text("Eisenstein series")]#text(", although there are of course many other Poincaré series one can consider by varying the test function ")#mi("{f}")#text(".")

#text("For future reference we record the basic but fundamental ")#emph[#text("unfolding identities")]#text(" ")#metadata(none) <tao-d91319367a2676d69798>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\int_{\\Gamma \\backslash {\\mathbf H}} P_\\Gamma[f] g\\ d\\mu_{\\Gamma \\backslash {\\mathbf H}} = \\int_{\\mathbf H} f g\\ d\\mu_{\\mathbf H}")]]

#text("for any function ")#mi("{f: {\\mathbf H} \\rightarrow {\\bf C}}")#text(" with sufficient decay, and any ")#mi("{\\Gamma}")#text("-automorphic function ")#mi("{g}")#text(" of reasonable growth (e.g. ")#mi("{f}")#text(" bounded and compact support, and ")#mi("{g}")#text(" bounded, will suffice). Note that ")#mi("{g}")#text(" is viewed as a function on ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(" on the left-hand side, and as a ")#mi("{\\Gamma}")#text("-automorphic function on ")#mi("{{\\mathbf H}}")#text(" on the right-hand side. More generally, one has ")#metadata(none) <tao-a4ce5044ac10430d475b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_{\\Gamma \\backslash {\\mathbf H}} P_{\\Gamma_\\infty \\backslash \\Gamma}[f] g\\ d\\mu_{\\Gamma \\backslash {\\mathbf H}} = \\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} f g\\ d\\mu_{\\Gamma_\\infty \\backslash {\\mathbf H}}")]]

#text("whenever ")#mi("{\\Gamma_\\infty \\leq \\Gamma}")#text(" are discrete subgroups of ")#mi("{\\text{PSL}_2({\\bf R})}")#text(", ")#mi("{f}")#text(" is a ")#mi("{\\Gamma_\\infty}")#text("-automorphic function with sufficient decay on ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", and ")#mi("{g}")#text(" is a ")#mi("{\\Gamma}")#text("-automorphic (and thus also ")#mi("{\\Gamma_\\infty}")#text("-automorphic) function of reasonable growth. These identities will allow us to move fairly freely between the three domains ")#mi("{{\\mathbf H}}")#text(", ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", and ")#mi("{\\Gamma \\backslash {\\mathbf H}}")#text(" in our analysis.")

#text("When computing various statistics of a Poincaré series ")#mi("{P_\\Gamma[f]}")#text(", such as its values ")#mi("{P_\\Gamma[f](z)}")#text(" at special points ")#mi("{z}")#text(", or the ")#mi("{L^2}")#text(" quantity ")#tao-math("{\\int_{\\Gamma \\backslash {\\mathbf H}} \\left|P_\\Gamma[f]\\right|^2\\ d\\mu}", block: false)#text(", expressions of interest to analytic number theory naturally emerge. We list three basic examples of this below, discussed somewhat informally in order to highlight the main ideas rather than the technical details.")

#text("The first example we will give concerns the problem of estimating the sum ")#metadata(none) <tao-3a2f9831dcd1d323649f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\tau(n+1),")]]

#text("where ")#mi("{\\tau(n) := \\sum_{d|n} 1}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(". This can be rewritten (by factoring ")#mi("{n=bc}")#text(" and ")#mi("{n+1=ad}")#text(") as ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{ a,b,c,d \\in {\\bf N}: ad-bc = 1} 1_{bc \\leq x}")]]

#text("which is basically a sum over the full modular group ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(". At this point we will “cheat” a little by moving to the related, but different, sum ")#metadata(none) <tao-8ce88e6477323ba9f5ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{a,b,c,d \\in {\\bf Z}: ad-bc = 1} 1_{a^2+b^2+c^2+d^2 \\leq x}.")]]

#text("This sum is not exactly the same as ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(8)")]#text(", but will be a little easier to handle, and it is plausible that the methods used to handle this sum can be modified to handle ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(8)")]#text(". Observe from ")#link(<tao-bcae0416621b3db43d8c>)[#text("(2)")]#text(" and some calculation that the distance between ")#mi("{i}")#text(" and ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} i = \\frac{ai+b}{ci+d}}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("2(\\cosh(d(i,\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} i))-1) = a^2+b^2+c^2+d^2 - 2")]]

#text("and so one can express the above sum as")

#align(center)[#tao-fit-display[#mitex("2 \\sum_{\\gamma \\in \\text{PSL}_2({\\bf Z})} 1_{d(i,\\gamma i) \\leq \\text{cosh}^{-1}(x/2)}")]]

#text("(the factor of ")#mi("{2}")#text(" coming from the quotient by ")#mi("{\\{\\pm 1\\}}")#text(" in the projective special linear group); one can express this as ")#mi("{P_\\Gamma[f](i)}")#text(", where ")#mi("{\\Gamma = \\text{PSL}_2({\\bf Z})}")#text(" and ")#mi("{f}")#text(" is the indicator function of the ball ")#mi("{B(i, \\text{cosh}^{-1}(x/2))}")#text(". Thus we see that expressions such as ")#link(<tao-3a2f9831dcd1d323649f>)[#text("(7)")]#text(" are related to evaluations of Poincaré series. (In practice, it is much better to use smoothed out versions of indicator functions in order to obtain good control on sums such as ")#link(<tao-3a2f9831dcd1d323649f>)[#text("(7)")]#text(" or ")#link(<tao-8ce88e6477323ba9f5ea>)[#text("(9)")]#text(", but we gloss over this technical detail here.)")

#text("The second example concerns the relative ")#metadata(none) <tao-e40d16db6ea0c7b0cca1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{n \\leq x} \\tau(n^2+1)")]]

#text("of the sum ")#link(<tao-3a2f9831dcd1d323649f>)[#text("(7)")]#text(". Note from multiplicativity that ")#link(<tao-3a2f9831dcd1d323649f>)[#text("(7)")]#text(" can be written as ")#mi("{\\sum_{n \\leq x} \\tau(n^2+n)}")#text(", which is superficially very similar to ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(10)")]#text(", but with the key difference that the polynomial ")#mi("{n^2+1}")#text(" is irreducible over the integers.")

#text("As with ")#link(<tao-3a2f9831dcd1d323649f>)[#text("(7)")]#text(", we may expand ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{A,B,C \\in {\\bf N}: B^2 - AC = -1} 1_{B \\leq x}.")]]

#text("At first glance this does not look like a sum over a modular group, but one can manipulate this expression into such a form in one of two (closely related) ways. First, observe that any factorisation ")#mi("{B + i = (a-bi) (c+di)}")#text(" of ")#mi("{B+i}")#text(" into ")#link("https://en.wikipedia.org/wiki/Gaussian_integer")[#text("Gaussian integers")]#text(" ")#mi("{a-bi, c+di}")#text(" gives rise (upon taking norms) to an identity of the form ")#mi("{B^2 - AC = -1}")#text(", where ")#mi("{A = a^2+b^2}")#text(" and ")#mi("{C = c^2+d^2}")#text(". Conversely, by using the unique factorisation of the Gaussian integers, every identity of the form ")#mi("{B^2-AC=-1}")#text(" gives rise to a factorisation of the form ")#mi("{B+i = (a-bi) (c+di)}")#text(", essentially uniquely up to units. Now note that ")#mi("{(a-bi)(c+di)}")#text(" is of the form ")#mi("{B+i}")#text(" if and only if ")#mi("{ad-bc=1}")#text(", in which case ")#mi("{B = ac+bd}")#text(". Thus we can essentially write the above sum as something like ")#metadata(none) <tao-72b90a0d25a6e8f71d5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sum_{a,b,c,d: ad-bc = 1} 1_{\\left|ac+bd\\right| \\leq x}", block: true)]]

#text("and one the modular group ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(" is now manifest. An equivalent way to see these manipulations is as follows. A triple ")#mi("{A,B,C}")#text(" of natural numbers with ")#mi("{B^2-AC=1}")#text(" gives rise to a positive quadratic form ")#mi("{Ax^2+2Bxy+Cy^2}")#text(" of normalised discriminant ")#mi("{B^2-AC}")#text(" equal to ")#mi("{-1}")#text(" with integer coefficients (it is natural here to allow ")#mi("{B}")#text(" to take integer values rather than just natural number values by essentially doubling the sum). The group ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(" acts on the space of such quadratic forms in a natural fashion (by composing the quadratic form with the inverse ")#mi("{\\begin{pmatrix} d & -b \\\\ -c & a \\end{pmatrix}}")#text(" of an element ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" of ")#mi("{\\text{SL}_2({\\bf Z})}")#text("). Because the discriminant ")#mi("{-1}")#text(" has ")#link("https://en.wikipedia.org/wiki/Binary_quadratic_form")[#text("class number one")]#text(" (this fact is equivalent to the unique factorisation of the gaussian integers, as discussed in ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("this previous post")]#text("), every form ")#mi("{Ax^2 + 2Bxy + Cy^2}")#text(" in this space is equivalent (under the action of some element of ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(") with the standard quadratic form ")#mi("{x^2+y^2}")#text(". In other words, one has")

#align(center)[#tao-fit-display[#mitex("Ax^2 + 2Bxy + Cy^2 = (dx-by)^2 + (-cx+ay)^2")]]

#text("which (up to a harmless sign) is exactly the representation ")#mi("{B = ac+bd}")#text(", ")#mi("{A = c^2+d^2}")#text(", ")#mi("{C = a^2+b^2}")#text(" introduced earlier, and leads to the same reformulation of the sum ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(10)")]#text(" in terms of expressions like ")#link(<tao-72b90a0d25a6e8f71d5f>)[#text("(11)")]#text(". Similar considerations also apply if the quadratic polynomial ")#mi("{n^2+1}")#text(" is replaced by another quadratic, although one has to account for the fact that the class number may now exceed one (so that unique factorisation in the associated quadratic ring of integers breaks down), and in the positive discriminant case the fact that the group of units might be infinite presents another significant technical problem.")

#text("Note that ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} i = \\frac{ai+b}{ci+d}}")#text(" has real part ")#mi("{\\frac{ac+bd}{c^2+d^2}}")#text(" and imaginary part ")#mi("{\\frac{1}{c^2+d^2}}")#text(". Thus ")#link(<tao-72b90a0d25a6e8f71d5f>)[#text("(11)")]#text(" is (up to a factor of two) the Poincaré series ")#mi("{P_\\Gamma[f](i)}")#text(" as in the preceding example, except that ")#mi("{f}")#text(" is now the indicator of the sector ")#tao-math("{\\{ z: \\left|\\text{Re} z\\right| \\leq x \\left|\\text{Im} z\\right| \\}}", block: false)#text(".")

#text("Sums involving subgroups of the full modular group, such as ")#mi("{\\Gamma_0(q)}")#text(", often arise when imposing congruence conditions on sums such as ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(10)")]#text(", for instance when trying to estimate the expression ")#mi("{\\sum_{n \\leq x: q|n} \\tau(n^2+1)}")#text(" when ")#mi("{q}")#text(" and ")#mi("{x}")#text(" are large. As before, one then soon arrives at the problem of evaluating a Poincaré series at one or more special points, where the series is now over ")#mi("{\\Gamma_0(q)}")#text(" rather than ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(".")

#text("The third and final example concerns averages of Kloosterman sums ")#metadata(none) <tao-cb46ca0f3dad890f293b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("S(m,n;c) := \\sum_{x \\in ({\\bf Z}/c{\\bf Z})^\\times} e( \\frac{mx + n\\overline{x}}{c} )")]]

#text("where ")#mi("{e(\\theta) := e^{2p\\i i\\theta}}")#text(" and ")#mi("{\\overline{x}}")#text(" is the inverse of ")#mi("{x}")#text(" in the multiplicative group ")#mi("{({\\bf Z}/c{\\bf Z})^\\times}")#text(". It turns out that the ")#mi("{L^2}")#text(" norms of Poincaré series ")#mi("{P_\\Gamma[f]}")#text(" or ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma}[f]}")#text(" are closely tied to such averages. Consider for instance the quantity ")#metadata(none) <tao-4cf6829aa93728e8f3c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f]\\right|^2\\ d\\mu_{\\Gamma \\backslash {\\mathbf H}}", block: true)]]

#text("where ")#mi("{q}")#text(" is a natural number and ")#mi("{f}")#text(" is a ")#mi("{\\Gamma_\\infty}")#text("-automorphic form that is of the form")

#align(center)[#tao-fit-display[#mitex("f(x+iy) = F(my) e(m x)")]]

#text("for some integer ")#mi("{m}")#text(" and some test function ")#mi("{f: (0,+\\infty) \\rightarrow {\\bf C}}")#text(", which for sake of discussion we will take to be smooth and compactly supported. Using the unfolding formula ")#link(<tao-a4ce5044ac10430d475b>)[#text("(6)")]#text(", we may rewrite ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\overline{f} P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f]\\ d\\mu_{\\Gamma_\\infty \\backslash {\\mathbf H}}.")]]

#text("To compute this, we use the double coset decomposition")

#align(center)[#tao-fit-display[#mitex("\\Gamma_0(q) = \\Gamma_\\infty \\cup \\bigcup_{c \\in {\\mathbf N}: q|c} \\bigcup_{1 \\leq d \\leq c: (d,c)=1} \\Gamma_\\infty \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\Gamma_\\infty,")]]

#text("where for each ")#mi("{c,d}")#text(", ")#mi("{a,b}")#text(" are arbitrarily chosen integers such that ")#mi("{ad-bc=1}")#text(". To see this decomposition, observe that every element ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" in ")#mi("{\\Gamma_0(q)}")#text(" outside of ")#mi("{\\Gamma_\\infty}")#text(" can be assumed to have ")#mi("{c>0}")#text(" by applying a sign ")#mi("{\\pm}")#text(", and then using the row and column operations coming from left and right multiplication by ")#mi("{\\Gamma_\\infty}")#text(" (that is, shifting the top row by an integer multiple of the bottom row, and shifting the right column by an integer multiple of the left column) one can place ")#mi("{d}")#text(" in the interval ")#mi("{[1,c]}")#text(" and ")#mi("{(a,b)}")#text(" to be any specified integer pair with ")#mi("{ad-bc=1}")#text(". From this we see that")

#align(center)[#tao-fit-display[#mitex("P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f] = f + \\sum_{c \\in {\\mathbf N}: q|c} \\sum_{1 \\leq d \\leq c: (d,c)=1} P_{\\Gamma_\\infty}[ f( \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\cdot ) ]")]]

#text("and so from further use of the unfolding formula ")#link(<tao-d91319367a2676d69798>)[#text("(5)")]#text(" we may expand ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|f\\right|^2\\ d\\mu_{\\Gamma_\\infty \\backslash {\\mathbf H}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ \\sum_{c \\in {\\mathbf N}} \\sum_{1 \\leq d \\leq c: (d,c)=1} \\int_{\\mathbf H} \\overline{f}(z) f( \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} z)\\ d\\mu_{\\mathbf H}.")]]

#text("The first integral is just ")#tao-math("{m \\int_0^\\infty \\left|F(y)\\right|^2 \\frac{dy}{y^2}}", block: false)#text(". The second expression is more interesting. We have")

#tao-aligned(keep: true)[


#tao-math("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} z  & = \\frac{az+b}{cz+d} = \\frac{a}{c} - \\frac{1}{c(cz+d)}", block: true)



#tao-math(" & = \\frac{a}{c} - \\frac{cx+d}{c((cx+d)^2+c^2y^2)} + \\frac{iy}{(cx+d)^2 + c^2y^2}", block: true)
]

#text("so we can write")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbf H} \\overline{f}(z) f( \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} z)\\ d\\mu_{\\mathbf H}")]]

#text("as")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\int_{\\bf R} \\overline{F}(my) F(\\frac{imy}{(cx+d)^2 + c^2y^2}) e( -mx + \\frac{ma}{c} - m \\frac{cx+d}{c((cx+d)^2+c^2y^2)} )")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dx dy}{y^2}")]]

#text("which on shifting ")#mi("{x}")#text(" by ")#mi("{d/c}")#text(" simplifies a little to")

#align(center)[#tao-fit-display[#mitex("e( \\frac{ma}{c} + \\frac{md}{c} ) \\int_0^\\infty \\int_{\\bf R} F(my) \\bar{F}(\\frac{imy}{c^2(x^2 + y^2)}) e(- mx - m \\frac{x}{c^2(x^2+y^2)} )")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dx dy}{y^2}")]]

#text("and then on scaling ")#mi("{x,y}")#text(" by ")#mi("{m}")#text(" simplifies a little further to")

#align(center)[#tao-fit-display[#mitex("e( \\frac{ma}{c} + \\frac{md}{c} ) \\int_0^\\infty \\int_{\\bf R} F(y) \\bar{F}(\\frac{m^2}{c^2} \\frac{iy}{x^2 + y^2}) e(- x - \\frac{m^2}{c^2} \\frac{x}{x^2+y^2} )\\ \\frac{dx dy}{y^2}.")]]

#text("Note that as ")#mi("{ad-bc=1}")#text(", we have ")#mi("{a = \\overline{d}}")#text(" modulo ")#mi("{c}")#text(". Comparing the above calculations with ")#link(<tao-cb46ca0f3dad890f293b>)[#text("(12)")]#text(", we can thus write ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" as ")#metadata(none) <tao-2792e2efcb433e305f19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("m (\\int_0^\\infty \\left|F(y)\\right|^2 \\frac{dy}{y^2} + \\sum_{q|c} \\frac{S(m,m;c)}{c} V(\\frac{m}{c}))", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("V(u) := \\frac{1}{u} \\int_0^\\infty \\int_{\\bf R} F(y) \\bar{F}(u^2 \\frac{y}{x^2 + y^2}) e(- x - u^2 \\frac{x}{x^2+y^2} )\\ \\frac{dx dy}{y^2}")]]

#text("is a certain integral involving ")#mi("{F}")#text(" and a parameter ")#mi("{u}")#text(", but which does not depend explicitly on parameters such as ")#mi("{m,c,d}")#text(". Thus we have indeed expressed the ")#mi("{L^2}")#text(" expression ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" in terms of Kloosterman sums. It is possible to invert this analysis and express varius weighted sums of Kloosterman sums in terms of ")#mi("{L^2}")#text(" expressions (possibly involving inner products instead of norms) of Poincaré series, but we will not do so here; see Chapter 16 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(" for further details.")

#text("Traditionally, automorphic forms have been analysed using the spectral theory of the Laplace-Beltrami operator ")#mi("{-\\Delta}")#text(" on spaces such as ")#mi("{\\Gamma\\backslash {\\mathbf H}}")#text(" or ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", so that a Poincaré series such as ")#mi("{P_\\Gamma[f]}")#text(" might be expanded out using inner products of ")#mi("{P_\\Gamma[f]}")#text(" (or, by the unfolding identities, ")#mi("{f}")#text(") with various generalised eigenfunctions of ")#mi("{-\\Delta}")#text(" (such as cuspidal eigenforms, or Eisenstein series). With this approach, special functions, and specifically ")#link("https://en.wikipedia.org/wiki/Bessel_function#Modified_Bessel_functions:_I.CE.B1.2C_K.CE.B1")[#text("the modified Bessel functions ")#mi("{K_{it}}")#text(" of the second kind")]#text(", play a prominent role, basically because the ")#mi("{\\Gamma_\\infty}")#text("-automorphic functions")

#align(center)[#tao-fit-display[#mitex("x+iy \\mapsto y^{1/2} K_{it}(2\\pi |m| y) e(mx)")]]

#text("for ")#mi("{t \\in {\\bf R}}")#text(" and ")#mi("{m \\in {\\bf Z}}")#text(" non-zero are generalised eigenfunctions of ")#mi("{-\\Delta}")#text(" (with eigenvalue ")#mi("{\\frac{1}{4}+t^2}")#text("), and are almost square-integrable on ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(" (the ")#mi("{L^2}")#text(" norm diverges only logarithmically at one end ")#mi("{y \\rightarrow 0^+}")#text(" of the cylinder ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", while decaying exponentially fast at the other end ")#mi("{y \\rightarrow +\\infty}")#text(").")

#text("However, as discussed in ")#link("https://terrytao.wordpress.com/2011/12/20/the-spectral-theorem-and-its-converses-for-unbounded-symmetric-operators/")[#text("this previous post")]#text(", the spectral theory of an essentially self-adjoint operator such as ")#mi("{-\\Delta}")#text(" is basically equivalent to the theory of various solution operators associated to partial differential equations involving that operator, such as the Helmholtz equation ")#mi("{(-\\Delta + k^2) u = f}")#text(", the heat equation ")#mi("{\\partial_t u = \\Delta u}")#text(", the Schrödinger equation ")#mi("{i\\partial_t u + \\Delta u = 0}")#text(", or the wave equation ")#mi("{\\partial_{tt} u = \\Delta u}")#text(". Thus, one can hope to rephrase many arguments that involve spectral data of ")#mi("{-\\Delta}")#text(" into arguments that instead involve resolvents ")#mi("{(-\\Delta + k^2)^{-1}}")#text(", heat kernels ")#mi("{e^{t\\Delta}}")#text(", Schrödinger propagators ")#mi("{e^{it\\Delta}}")#text(", or wave propagators ")#mi("{e^{\\pm it\\sqrt{-\\Delta}}}")#text(", or involve the PDE more directly (e.g. applying integration by parts and energy methods to solutions of such PDE). This is certainly done to some extent in the existing literature; resolvents and heat kernels, for instance, are often utilised. In this post, I would like to explore the possibility of reformulating spectral arguments instead using the inhomogeneous wave equation")

#align(center)[#tao-fit-display[#mitex("\\partial_{tt} u - \\Delta u = F.")]]

#text("Actually it will be a bit more convenient to normalise the Laplacian by ")#mi("{\\frac{1}{4}}")#text(", and look instead at the ")#emph[#text("automorphic wave equation")]#text(" ")#metadata(none) <tao-999e3bbc8148d63317b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\partial_{tt} u + (-\\Delta - \\frac{1}{4}) u = F.")]]

#text("This equation somewhat resembles a “")#link("https://en.wikipedia.org/wiki/Klein%E2%80%93Gordon_equation")[#text("Klein-Gordon")]#text("” type equation, except that the mass is imaginary! This would lead to pathological behaviour were it not for the negative curvature, which in principle creates a spectral gap of ")#mi("{\\frac{1}{4}}")#text(" that cancels out this factor.")

#text("The point is that the wave equation approach gives access to some nice PDE techniques, such as energy methods, Sobolev inequalities and finite speed of propagation, which are somewhat submerged in the spectral framework. The wave equation also interacts well with Poincaré series; if for instance ")#mi("{u}")#text(" and ")#mi("{F}")#text(" are ")#mi("{\\Gamma_\\infty}")#text("-automorphic solutions to ")#link(<tao-999e3bbc8148d63317b8>)[#text("(15)")]#text(" obeying suitable decay conditions, then their Poincaré series ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma}[u]}")#text(" and ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma}[F]}")#text(" will be ")#mi("{\\Gamma}")#text("-automorphic solutions to the same equation ")#link(<tao-999e3bbc8148d63317b8>)[#text("(15)")]#text(", basically because the Laplace-Beltrami operator commutes with translations. Because of these facts, it is possible to replicate several standard spectral theory arguments in the wave equation framework, without having to deal directly with things like the asymptotics of modified Bessel functions. The wave equation approach to automorphic theory was introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=320781")[#text("by Faddeev and Pavlov")]#text(" (using the Lax-Phillips scattering theory), and developed further by ")#link("http://www.ams.org/mathscinet-getitem?mr=562288")[#text("by Lax and Phillips")]#text(", to recover many spectral facts about the Laplacian on modular curves, such as the Weyl law and the Selberg trace formula. Here, I will illustrate this by deriving three basic applications of automorphic methods in a wave equation framework, namely")

#list(
[#text("Using the Weil bound on Kloosterman sums to derive Selberg’s 3/16 theorem on the least non-trivial eigenvalue for ")#mi("{-\\Delta}")#text(" on ")#mi("{\\Gamma_0(q) \\backslash {\\mathbf H}}")#text(" (discussed previously ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("here")]#text(");")],
[#text("Conversely, showing that Selberg’s eigenvalue conjecture (improving Selberg’s ")#mi("{3/16}")#text(" bound to the optimal ")#mi("{1/4}")#text(") implies an optimal bound on (smoothed) sums of Kloosterman sums; and")],
[#text("Using the same bound to obtain pointwise bounds on Poincaré series similar to the ones discussed above. (Actually, the argument here does not use the wave equation, instead it just uses the Sobolev inequality.)")]
)

#text("This post originated from an attempt to finally learn this part of analytic number theory properly, and to see if I could use a PDE-based perspective to understand it better. Ultimately, this is not that dramatic a depature from the standard approach to this subject, but I found it useful to think of things in this fashion, probably due to my existing background in PDE.")

#text("I thank Bill Duke and Ben Green for helpful discussions. My primary reference for this theory was Chapters 15, 16, and 21 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(".")

#metadata(none) <tao-9886b585af4e9269162e>

#heading(level: 1)[#strong[#text(" — 1. Selberg’s ")#mi("{3/16}")#text(" theorem — ")]]

#text("We begin with a proof of the following celebrated result of Selberg:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{q \\geq 1}")#text(" be a natural number. Then every eigenvalue of ")#mi("{-\\Delta}")#text(" on ")#mi("{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" (the mean zero functions on ")#mi("{\\Gamma_0(q) \\backslash {\\mathbf H}}")#text(") is at least ")#mi("{3/16}")#text(".")
]

#text("One can show that ")#mi("{-\\Delta}")#text(" has only pure point spectrum below ")#mi("{1/4}")#text(" on ")#mi("{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" (see ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("this previous blog post")]#text(" for more discussion). Thus, this theorem shows that the spectrum of ")#mi("{-\\Delta}")#text(" on ")#mi("{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" is contained in ")#mi("{[-3/16,+\\infty)}")#text(".")

#text("We now prove this theorem. Suppose this were not the case, then we have a non-zero eigenfunction ")#mi("{\\phi}")#text(" of ")#mi("{-\\Delta}")#text(" in ")#mi("{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" with eigenvalue ")#mi("{\\frac{1}{4} - \\delta^2}")#text(" for some ")#mi("{\\delta > \\frac{1}{4}}")#text("; we may assume ")#mi("{\\phi}")#text(" to be real-valued, and by elliptic regularity it is smooth (on ")#mi("{{\\mathbf H}}")#text("). If it is constant in the horizontal variable, thus ")#mi("{\\phi(x+iy) = \\phi(y)}")#text(", then by the ")#mi("{\\Gamma_0(q)}")#text("-automorphic nature of ")#mi("{\\phi}")#text(" it is easy to see that ")#mi("{\\phi}")#text(" is globally constant, contradicting the fact that it is mean zero but not identically zero. Thus it is not identically constant in the horizontal variable. By Fourier analysis on the cylinder ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", one can then find a ")#mi("{\\Gamma_\\infty}")#text("-automorphic function ")#mi("{f_0}")#text(" of the form ")#mi("{f_0(x+iy) = F_0(my) e(mx)}")#text(" for some non-zero integer ")#mi("{m}")#text(" which has a non-zero inner product with ")#mi("{\\phi}")#text(" on ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", where ")#mi("{F_0: (0,+\\infty) \\rightarrow {\\bf C}}")#text(" is a smooth compactly supported function.")

#text("Now we evolve ")#mi("{f_0}")#text(" by the wave equation ")#metadata(none) <tao-0cf79f07176351d883d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\partial_{tt} f - \\Delta f - \\frac{1}{4} f = 0")]]

#text("to obtain a smooth function ")#mi("{f: {\\bf R} \\times {\\mathbf H} \\rightarrow {\\bf C}}")#text(" such that ")#mi("{f(0,x) = f_0(x)}")#text(" and ")#mi("{\\partial_t f(0,x) = 0}")#text("; the existence (and uniqueness) of such a solution to this initial value problem can be established by standard wave equation methods (e.g. parametrices and energy estimates), or by the spectral theory of the Laplacian. (One can also solve for ")#mi("{f}")#text(" explicitly in terms of modified Bessel functions, but we will not need to do so here, which is one of the main points of using the wave equation method.) Since the initial data ")#mi("{f_0}")#text(" obeyed the translation symmetry ")#mi("{f_0(z + x) = f_0(z) e(mx)}")#text(" for all ")#mi("{z \\in {\\mathbf H}}")#text(" and ")#mi("{x \\in {\\bf R}}")#text(", we see (from the uniqueness theory and translation invariance of the wave equation) that ")#mi("{f}")#text(" also obeys this symmetry; in particular ")#mi("{f(t)}")#text(" is ")#mi("{\\Gamma_\\infty}")#text("-automorphic for all times ")#mi("{t}")#text(". By finite speed of propagation, ")#mi("{f(t)}")#text(" remains compactly supported in ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(" for all time ")#mi("{t}")#text(", in fact for positive time it will lie in the strip ")#mi("{\\{ z: e^{-t} \\ll \\text{Im} z \\ll e^t \\}}")#text(", where we allow the implied constants to depend on the initial data ")#mi("{f_0}")#text(".")

#text("Taking the inner product of ")#mi("{f}")#text(" with the eigenfunction ")#mi("{\\phi}")#text(" on ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", differentiating under the integral sign, and integrating by parts, we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_{tt} \\langle f, \\phi \\rangle_{L^2(\\Gamma_\\infty \\backslash {\\mathbf H})} + \\delta^2 \\langle f, \\phi \\rangle_{L^2(\\Gamma_\\infty \\backslash {\\mathbf H})} = 0.")]]

#text("Since ")#mi("{\\langle f, \\phi \\rangle_{\\Gamma \\backslash {\\mathbf H}}}")#text(" is initially non-zero with zero velocity, we conclude from solving the ODE that ")#mi("{\\langle f(t), \\phi \\rangle_{\\Gamma_\\infty \\backslash {\\mathbf H}}}")#text(" is a non-zero multiple of ")#mi("{\\cosh(\\delta t)}")#text(". In particular, it grows like ")#mi("{e^{\\delta t}}")#text(" as ")#mi("{t \\rightarrow +\\infty}")#text(". Using the unfolding identity ")#link(<tao-a4ce5044ac10430d475b>)[#text("(6)")]#text(" to write")

#align(center)[#tao-fit-display[#mitex("\\langle f(t), \\phi \\rangle_{L^2(\\Gamma_\\infty \\backslash {\\mathbf H})} = \\langle P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(t)], \\phi \\rangle_{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})}")]]

#text("and then using the Cauchy-Schwarz inequality, we conclude that ")#metadata(none) <tao-8c6fb1e9e37a1aea1d30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left| P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(t)] \\right|^2\\ d\\mu_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\gg e^{2\\delta t}", block: true)]]

#text("as ")#mi("{t \\rightarrow +\\infty}")#text(", where we allow implied constants to depend on ")#mi("{f, q, \\phi}")#text(".")

#text("We complement this lower bound with slightly crude upper bound in which we are willing to lose some powers of ")#mi("{t}")#text(". We have already seen that ")#mi("{f(t)}")#text(" is supported in the strip ")#mi("{\\{ z: e^{-t} \\ll \\text{Im} z \\ll e^t \\}}")#text(". Compactly supported solutions to ")#link(<tao-0cf79f07176351d883d3>)[#text("(16)")]#text(" on the cylinder ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(" conserve the energy")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|\\partial_t f\\right|^2 + y^2(\\left|\\partial_x f\\right|^2 + \\left|\\partial_y f\\right|^2 - \\frac{1}{4} \\left|f\\right|^2) \\frac{ dx dy}{y^2}.", block: true)]]

#text("In particular, this quantity is ")#mi("{O(1)}")#text(" for all time (recall we allow implied constants to depend on ")#mi("{f,q,\\phi}")#text("). From ")#link("https://en.wikipedia.org/wiki/Hardy%27s_inequality")[#text("Hardy’s inequality")]#text(", the quantity")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|\\partial_y f\\right|^2 - \\frac{1}{4} \\left|f\\right|^2\\ dx dy", block: true)]]

#text("is non-negative. Discarding this term and using ")#mi("{\\partial_x f = 2\\pi i my}")#text(", and using the fact that ")#mi("{m}")#text(" is non-zero, we arrive at the bounds")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|f\\right|^2\\ dx dy \\ll 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|\\partial_t f\\right|^2\\ \\frac{dx dy}{y^2} \\ll 1.", block: true)]]

#text("(We allow implied constants to depend on ")#mi("{m,f,q,\\phi}")#text(", but not on ")#mi("{t}")#text(".) From the fundamental theorem of calculus and Minkowski’s inequality in ")#mi("{L^2}")#text(", the latter inequality implies that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|f\\right|^2\\ \\frac{dx dy}{y^2} \\ll t^2", block: true)]]

#text("for ")#mi("{t \\geq 1}")#text(", which on combining with the former inequality gives")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|f\\right|^2 (1 + y^{-2})\\ dx dy \\ll t^2.", block: true)]]

#text("The function ")#mi("{\\Delta f}")#text(" also obeys the wave equation ")#link(<tao-0cf79f07176351d883d3>)[#text("(16)")]#text(", so a similar argument gives")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_\\infty \\backslash {\\mathbf H}} \\left|\\Delta f\\right|^2 (1+y^{-2})\\ dx dy \\ll t^2.", block: true)]]

#text("Applying a Sobolev inequality on unit squares (for ")#mi("{y \\geq 1}")#text(") or on squares of length comparable to ")#mi("{y}")#text(" (for ")#mi("{y < 1}")#text(") we conclude the pointwise estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|f(t,x+iy)\\right| \\ll t", block: true)]]

#text("for ")#mi("{y \\geq 1}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left|f(t,x+iy)\\right| \\ll t y^{1/2}", block: true)]]

#text("for ")#mi("{y < 1}")#text(". In particular, we write ")#mi("{f(t,x+iy) = F(t,my) e(m,x)}")#text(", we have the somewhat crude estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|F(t,y)\\right| \\ll t^{O(1)} y^{1/2}", block: true)]]

#text("for all ")#mi("{y > 0}")#text(" and ")#mi("{t \\geq 1}")#text(". (One can do better than this, particularly for large ")#mi("{y}")#text(", but this bound will suffice for us.)")

#text("By repeating the analysis of ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" at the start of this post, we see that the quantity ")#metadata(none) <tao-b831b33e0c05b45e15bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left| P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(t)] \\right|^2\\ d\\mu_{\\Gamma_0(q) \\backslash {\\mathbf H}}", block: true)]]

#text("can be expressed as")

#align(center)[#tao-fit-display[#tao-math("m (\\int_0^\\infty \\left|F(t,y)\\right|^2 \\frac{dy}{y^2} + \\sum_{q|c} \\frac{S(m,m;c)}{c} V(t,\\frac{m}{c}))", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("V(t,u) := \\frac{1}{u} \\int_0^\\infty \\int_{\\bf R} F(t,y) \\bar{F}(t,u^2 \\frac{y}{x^2 + y^2}) e(- x - u^2 \\frac{x}{x^2+y^2} )\\ \\frac{dx dy}{y^2}.")]]

#text("Since ")#mi("{F(t,y)}")#text(" is supported on ")#mi("{\\{ e^{-t} \\ll y \\ll e^t \\}}")#text(" and is bounded by ")#mi("{O( t^{O(1)} y^{1/2} )}")#text(", the integral ")#tao-math("{\\int_0^\\infty \\left|F(t,y)\\right|^2 \\frac{dy}{y^2}}", block: false)#text(" is ")#mi("{O(t^{O(1)})}")#text(" for ")#mi("{t \\geq 1}")#text(". We also see that ")#mi("{V(t,u)}")#text(" vanishes unless ")#mi("{u \\gg e^{-t}}")#text(" (otherwise ")#mi("{y}")#text(" and ")#mi("{u^2 \\frac{y}{x^2+y^2} \\geq \\frac{u^2}{y}}")#text(" cannot simultaneously be ")#mi("{\\gg e^{-t}}")#text(", and for such values of ")#mi("{u}")#text(", we have the triangle inequality bound")

#align(center)[#tao-fit-display[#mitex("V(t,u) \\ll \\frac{t^{O(1)}}{u} \\int_{e^{-t} \\ll y \\ll e^t} \\int_{x \\ll e^t u} y^{1/2} (u^2 \\frac{y}{x^2+y^2})^{1/2}\\ \\frac{dx dy}{y^2}.")]]

#text("Evaluating the ")#mi("{x}")#text(" integral and then the ")#mi("{y}")#text(" integral, we arrive at")

#align(center)[#tao-fit-display[#mitex("V(t,u) \\ll t^{O(1)} \\log(2+u)")]]

#text("and so we can bound ")#link(<tao-b831b33e0c05b45e15bb>)[#text("(18)")]#text(" (ignoring any potential cancellation in ")#mi("{c}")#text(") by")

#align(center)[#tao-fit-display[#tao-math("\\ll t^{O(1)} ( 1 + \\sum_{c \\ll e^t} \\frac{\\left|S(m,m;c)\\right|}{c} ).", block: true)]]

#text("Now we use the Weil bound for Kloosterman sums, which gives")

#align(center)[#tao-fit-display[#tao-math("\\left|S(m,m;c)\\right| \\ll c^{1/2 + o(1)}", block: true)]]

#text("(see e.g. ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("this previous post")]#text(" for a discussion of this bound) to arrive at the bound")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left| P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(t)] \\right|^2\\ d\\mu_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\ll t^{O(1)} e^{t/2}", block: true)]]

#text("as ")#mi("{t \\rightarrow \\infty}")#text(". Comparing this with ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(17)")]#text(" we obtain a contradiction as ")#mi("{t \\rightarrow \\infty}")#text(" since we have ")#mi("{\\delta > \\frac{1}{4}}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" ")#metadata(none) <tao-aac28e6b9f98104b92f5>#text(" It was conjectured by Linnik that")

#align(center)[#tao-fit-display[#mitex("\\sum_{c \\leq x} \\frac{S(m,n;c)}{c} \\ll x^{o(1)}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" for any fixed ")#mi("{m,n}")#text("; this, when combined with a more refined analysis of the above type, implies the Selberg eigenvalue conjecture that all eigenvalues of ")#mi("{-\\Delta}")#text(" on ")#mi("{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" are at least ")#mi("{1/4}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Consequences of Selberg’s conjecture — ")]]

#text("In the previous section we saw how bounds on Kloosterman sums gave rise to lower bounds on eigenvalues of the Laplacian. It turns out that this implication is reversible. The simplest case (at least from the perspective of wave equation methods) is when Selberg’s eigenvalue conjecture is true, so that the Laplacian on ")#mi("{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" has spectrum in ")#mi("{[\\frac{1}{4},\\infty)}")#text(". Equivalently, one has the inequality")

#align(center)[#tao-fit-display[#mitex("\\langle -\\Delta f, f \\rangle_{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0} \\geq \\frac{1}{4} \\langle f, f \\rangle_{L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")]]

#text("for all ")#mi("{f \\in L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(" (interpreting derivatives in a distributional sense if necessary). Integrating by parts, this shows that ")#metadata(none) <tao-248fb276f60f01c8aab4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|\\nabla f\\right|^2 - \\frac{1}{4} \\left|f\\right|^2\\ d\\mu \\geq 0", block: true)]]

#text("for all ")#mi("{f \\in L^2(\\Gamma_0(q) \\backslash {\\mathbf H})_0}")#text(", where the gradient ")#mi("{\\nabla f}")#text(" and its magnitude ")#tao-math("{\\left|\\nabla f\\right|}", block: false)#text(" are computed using the Riemannian metric in ")#mi("{\\Gamma_0(q) \\backslash {\\mathbf H}}")#text(".")

#text("Now suppose one has a smooth, compactly supported in space solution ")#mi("{f: {\\bf R} \\times \\Gamma_0(q) \\backslash {\\mathbf H} \\rightarrow {\\bf R}}")#text(" to the inhomogeneous wave equation")

#align(center)[#tao-fit-display[#mitex("\\partial_{tt} f - \\Delta f - \\frac{1}{4} f = g")]]

#text("for some forcing term ")#mi("{g: {\\bf R} \\times \\Gamma_0(q) \\backslash {\\mathbf H} \\rightarrow {\\bf R}}")#text(" which is also smooth and compactly supported in space. We assume that ")#mi("{f(t)}")#text(" has mean zero for all ")#mi("{t}")#text(". Introducing the energy")

#align(center)[#tao-fit-display[#tao-math("E[f(t)] := \\frac{1}{2}\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|\\partial_t f\\right|^2 + \\left|\\nabla f\\right|^2 - \\frac{1}{4} \\left|f\\right|^2\\ d\\mu,", block: true)]]

#text("which is non-negative thanks to ")#link(<tao-248fb276f60f01c8aab4>)[#text("(19)")]#text(" and integrating by parts, we obtain the energy identity")

#align(center)[#tao-fit-display[#mitex("\\partial_t E[f(t)] = \\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} (\\partial_t f) g\\ d\\mu")]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E[f(t)] \\ll E[f(t)]^{1/2} (\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|g\\right|^2\\ d\\mu)^{1/2}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E[f(t)]^{1/2} \\ll (\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|g\\right|^2\\ d\\mu)^{1/2}", block: true)]]

#text("(in a distributional sense at least), giving rise to the energy inequality")

#align(center)[#tao-fit-display[#tao-math("E[f(t)]^{1/2} \\ll E[f(0)]^{1/2} + \\int_0^t (\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|g(t^{\\prime})\\right|^2\\ d\\mu)^{1/2}\\ dt^{\\prime}.", block: true)]]

#text("We can lift this inequality to the cylinder ")#mi("{\\Gamma_\\infty \\backslash {\\mathbf H}}")#text(", concluding that for any smooth, compactly supported in space solution ")#mi("{f:{\\bf R} \\times (\\Gamma_\\infty \\backslash {\\mathbf H}) \\rightarrow {\\bf R}}")#text(" to the inhomogeneous equation ")#metadata(none) <tao-184c926681179fdf7098>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\partial_{tt} f - \\Delta f - \\frac{1}{4} f = g")]]

#text("for some forcing term ")#mi("{g: {\\bf R} \\times \\Gamma_\\infty \\backslash {\\mathbf H} \\rightarrow {\\bf R}}")#text(" which is also smooth and compactly supported in space, with ")#mi("{f}")#text(" mean zero for all time, we have the energy inequality")

#tao-aligned(keep: true)[


#tao-math("E[P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(t)]]^{1/2}  & \\ll E[P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(0)]]^{1/2}", block: true)



#tao-math(" & + \\int_0^t (\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[g(t^{\\prime})]\\right|^2\\ d\\mu)^{1/2}\\ dt^{\\prime}.", block: true)
]

#text("One can use this inequality to analyse the ")#mi("{L^2}")#text(" norm of Poincaré series by testing on various functions ")#mi("{f}")#text(" (and working out ")#mi("{g}")#text(" using ")#link(<tao-184c926681179fdf7098>)[#text("(20)")]#text("). Suppose for instance that ")#mi("{m}")#text(" is a fixed natural number, and ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a smooth compactly supported function. We consider the traveling wave ")#mi("{f:{\\bf R} \\times \\Gamma_\\infty \\backslash {\\mathbf H} \\rightarrow {\\bf R}}")#text(" given by the formula")

#align(center)[#tao-fit-display[#mitex("f(t,x+iy) := y^{1/2} \\Psi( - \\log y ) \\Psi( t + \\log y ) e(mx)")]]

#text("where ")#mi("{\\Psi(u) = \\int_{-\\infty}^u \\psi(v)\\ dv}")#text(" is the primitive of ")#mi("{\\psi}")#text("; the point is that this is an approximate solution to the homogeneous wave equation, particularly at small values of ")#mi("{y}")#text(". Clearly ")#mi("{f(t)}")#text(" is compactly supported with mean zero for ")#mi("{t \\geq 0}")#text(", in the region ")#mi("{\\{ x+iy: e^{-t} \\ll y \\ll 1 \\}}")#text(" (we allow implied constants to depend on ")#mi("{\\psi,m}")#text(" but not on ")#mi("{q}")#text("). In the region ")#mi("{y \\sim 1}")#text(", ")#mi("{f}")#text(" and its first derivatives are ")#mi("{O(1)}")#text(", giving a contribution of ")#mi("{O(1)}")#text(" to the energy ")#mi("{E[P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(t)]]}")#text(" (note that the shifts of the region ")#mi("{\\{ 0 \\leq x \\leq 1; y \\sim 1\\}}")#text(" by ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(" have bounded overlap). In particular we have")

#align(center)[#tao-fit-display[#mitex("E[P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f(0)]] \\ll 1")]]

#text("and thus by the energy inequality (using only the ")#tao-math("{\\left|\\partial_t f\\right|^2}", block: false)#text(" portion of the energy)")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[\\partial_t f]\\right|^2 \\ll 1 + \\int_0^t (\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[g(t^{\\prime})]\\right|^2\\ d\\mu)^{1/2}\\ dt^{\\prime}", block: true)]]

#text("for ")#mi("{t \\geq 0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("g := \\partial_{tt} f - \\Delta f - \\frac{1}{4} f.")]]

#text("Clearly ")#mi("{g}")#text(" is supported on the region ")#mi("{\\{ x+iy: e^{-t} \\ll y \\ll 1 \\}}")#text(". For ")#mi("{y = O(1)}")#text(", one can compute that ")#mi("{g=O(1)}")#text(", giving a contribution of ")#mi("{O(t)}")#text(" to the right-hand side. When ")#mi("{y}")#text(" is much less than ")#mi("{1}")#text(" but much larger than ")#mi("{e^{-t}}")#text(", we have ")#mi("{f(x+iy) = y^{1/2} e(mx)}")#text(", which after some calculation yields ")#mi("{g(x+iy) = 4\\pi^2 m^2 y^{5/2} e(mx)}")#text(". As this decays so quickly as ")#mi("{y \\rightarrow 0}")#text(", one can compute (using for instance the expansion ")#link(<tao-2792e2efcb433e305f19>)[#text("(14)")]#text(" of ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" and crude estimates, ignoring all cancellation) that this contributes a total of ")#mi("{O(t)}")#text(" to the right-hand side also. Finally one has to deal with the region ")#mi("{y \\sim e^{-t}}")#text(", but ")#mi("{y}")#text(" is much less than ")#mi("{1}")#text(". Here, ")#mi("{\\partial_t f}")#text(" is equal to ")#mi("{y^{1/2} \\psi( t + \\log y ) e(mx)}")#text(", and ")#mi("{f}")#text(" is equal to ")#mi("{y^{1/2} \\Psi(t + \\log y) e(mx)}")#text(", which after some computation makes ")#mi("{g}")#text(" equal to ")#mi("{4\\pi^2 m^2 y^{5/2} \\Psi(t + \\log y) e(mx)}")#text(". Again, one can compute the contribution of this term to the energy inequality to be ")#mi("{O(t)}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[y^{1/2} \\psi(t+\\log y) e(mx)]\\right|^2 \\ll 1+t.", block: true)]]

#text("Applying the expansion ")#link(<tao-2792e2efcb433e305f19>)[#text("(14)")]#text(" of ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(", we conclude that ")#metadata(none) <tao-e2ade56f4a5dc45dd1a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_{q|c} \\frac{S(m,m;c)}{c} V(\\frac{m}{c})) \\ll 1+t")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("V(u) := \\int_0^\\infty \\int_{\\bf R} \\frac{y}{\\sqrt{x^2+y^2}} \\psi(t + \\log y) \\psi(t + \\log u^2 \\frac{y}{x^2 + y^2})")]]

#align(center)[#tao-fit-display[#mitex("e(- x - u^2 \\frac{x}{x^2+y^2} )\\ \\frac{dx dy}{y^2}")]]

#text("The expression ")#mi("{V(u)}")#text(" is only non-zero when ")#mi("{u \\gg e^{-t}}")#text(", and the integrand is only non-zero when ")#mi("{y \\sim e^{-t}}")#text(" and ")#mi("{x \\sim u}")#text(", which makes the phase ")#mi("{-x - u^2 \\frac{x}{x^2+y^2}}")#text(" of size ")#mi("{O(u)}")#text(". For ")#mi("{u}")#text(" much smaller than ")#mi("{1}")#text(", the phase is thus largely irrelevant and the quantity ")#mi("{V(u)}")#text(" is roughly comparable to ")#mi("{1}")#text(" for ")#mi("{u \\gg e^{-t}}")#text(". As such, the bound ")#link(<tao-e2ade56f4a5dc45dd1a6>)[#text("(21)")]#text(" can be viewed as a smoothed out version of the estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{q|c: c \\ll e^t} \\frac{S(m,m;c)}{c} \\ll 1+t")]]

#text("which is basically Linnik’s conjecture, mentioned in Remark ")#link(<tao-aac28e6b9f98104b92f5>)[#text("2")]#text(". One can make this connection between Selberg’s eigenvalue conjecture and Linnik’s conjecture more precise: see Section 16.6 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(", which goes through modified Bessel functions rather than through wave equation methods.")

#heading(level: 1)[#strong[#text(" — 3. Pointwise bounds on Poincaré series — ")]]

#text("The formula ")#link(<tao-2792e2efcb433e305f19>)[#text("(14)")]#text(" for ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(" allows one to compute ")#mi("{L^2}")#text(" norms of Poincaré series. By using Sobolev embedding, one can then obtain pointwise control on such Poincaré series, as long as one stays away from the cusps. For instance, suppose we are interested in evaluating a Poincaré series ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[f]}")#text(" at a point of the form ")#mi("{z = \\gamma i}")#text(" for some ")#mi("{\\gamma \\in \\text{PSL}_2({\\bf Z})}")#text(". From the Sobolev inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f(i)\\right|^2 \\ll \\int_{B(i,1)} \\left|f\\right|^2 + \\left|\\Delta f\\right|^2\\ d\\mu_{\\mathbf H}", block: true)]]

#text("for any smooth function ")#mi("{f}")#text(", and thus by translation")

#align(center)[#tao-fit-display[#tao-math("\\left|f(\\gamma i)\\right|^2 \\ll \\int_{B(\\gamma i,1)} \\left|f\\right|^2 + \\left|\\Delta f\\right|^2\\ d\\mu_{\\mathbf H}.", block: true)]]

#text("The ball ")#mi("{B(i,1)}")#text(" meets only boundedly many translates of the standard fundamental domain of ")#mi("{\\text{PSL}_2({\\bf Z}) \\backslash {\\mathbf H}}")#text(", and hence ")#mi("{B(\\gamma i,1)}")#text(" does too. Since ")#mi("{\\Gamma_0(q)}")#text(" is a subgroup of ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(", we conclude that ")#mi("{B(\\gamma i,1)}")#text(" meets only boundedly many translates of a fundamental domain for ")#mi("{\\Gamma_0(q) \\backslash {\\mathbf H}}")#text(". In particular, we obtain the Sobolev inequality ")#metadata(none) <tao-503126878d17fcd6bde7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left|f(\\gamma i)\\right|^2 \\ll \\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|f\\right|^2 + \\left|\\Delta f\\right|^2\\ d\\mu_{\\Gamma_0(q) \\backslash \\mathbf H}", block: true)]]

#text("for any smooth ")#mi("{\\Gamma_0(q)}")#text("-automorphic function ")#mi("{f}")#text(". This estimate is unfortunately a little inefficient when ")#mi("{q}")#text(" is large, since the ball ")#mi("{B(\\gamma i,1)}")#text(" has area comparable to one, whereas the quotient space ")#mi("{\\Gamma_0(q) \\backslash {\\mathbf H}}")#text(" has area roughly comparable to ")#mi("{q}")#text(", so that one is conceding quite a bit by replacing the ball by the quotient space. Nevertheless this estimate is still useful enough to give some good results. We illustrate this by proving the estimate ")#metadata(none) <tao-97e38e1b2d7735fb875c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{n: q|n} \\sum_{\\nu \\in {\\bf Z}/n{\\bf Z}: \\nu^2 + 1 = 0 \\text{ mod } n} e( \\frac{m \\nu}{n} ) g( \\frac{n}{X} ) \\ll X^{1/2+o(1)} + q^{-1/2} X^{3/4+o(1)}")]]

#text("for ")#mi("{1 \\leq q,m \\leq X}")#text(" with ")#mi("{m}")#text(" coprime to ")#mi("{q}")#text(", where ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a fixed smooth function supported in, say, ")#mi("{[1,2]}")#text(" (and implied constants are allowed to depend on ")#mi("{g}")#text("), and the asymptotic notation is with regard to the limit ")#mi("{x \\rightarrow \\infty}")#text(". This type of estimate (appearing for instance (in a stronger form) in ")#link("http://www.ams.org/mathscinet-getitem?mr=1324141")[#text("this paper of Duke, Friedlander, and Iwaniec")]#text("; see also Proposition 21.10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(".) establishes some equidistribution of the square roots ")#mi("{\\{\\nu \\in {\\bf Z}/n{\\bf Z}: \\nu^2 + 1 = 0 \\}}")#text(" as ")#mi("{n}")#text(" varies (while staying comparable to ")#mi("{x}")#text("). For comparison, crude estimates (ignoring the cancellation in the phase ")#mi("{e(\\frac{h \\nu}{n})}")#text(") give a bound of ")#mi("{O( x^{1+o(1)} / q )}")#text(", so the bound ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(23)")]#text(" is non-trivial whenever ")#mi("{q}")#text(" is significantly smaller than ")#mi("{x^{1/2}}")#text(". Estimates such as ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(23)")]#text(" are also useful for getting good error terms in the asymptotics for the expression ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(10)")]#text(", as was first done ")#link("http://www.ams.org/mathscinet-getitem?mr=153648")[#text("by Hooley")]#text(".")

#text("One can write ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(23)")]#text(" in terms of Poincaré series much as was done for ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(10)")]#text(". Using the fact that the discriminant ")#mi("{-1}")#text(" has class number one as before, we see that for every positive ")#mi("{n}")#text(" and ")#mi("{\\nu \\in {\\bf Z}/n{\\bf Z}}")#text(" with ")#mi("{\\nu^2 + 1 = 0 \\text{ mod } n}")#text(", we can find an element ")#mi("{\\gamma = \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}}")#text(" of ")#mi("{\\text{PSL}_2({\\bf Z})}")#text(" such that ")#mi("{\\gamma i = \\frac{ai+b}{ci+d}}")#text(" has imaginary part ")#mi("{\\frac{1}{n}}")#text(" and real part ")#mi("{\\frac{\\nu}{n}}")#text(" modulo one (thus, ")#mi("{n = c^2+d^2}")#text(" and ")#mi("{\\nu = ac + bd \\text{ mod } n}")#text("); this element ")#mi("{\\gamma}")#text(" is unique up to left translation by ")#mi("{\\Gamma_\\infty}")#text(". We can thus write the left-hand side of ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(23)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\gamma \\in \\text{Fund}( \\Gamma_\\infty \\backslash \\text{PSL}_2({\\bf Z})): q|c^2+d^2} F( \\gamma i )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(x+iy) = e( mx ) g( \\frac{1}{Xy} )")]]

#text("and ")#mi("{c,d}")#text(" are the bottom two entries of the matrix ")#mi("{\\gamma}")#text(" (determined up to sign). The condition ")#mi("{q | c^2+d^2}")#text(" implies (since ")#mi("{c,d}")#text(" must be coprime) that ")#mi("{c,d}")#text(" are coprime to ")#mi("{q}")#text(" with ")#mi("{c/d = \\delta \\text{ mod } q}")#text(" for some ")#mi("{\\delta}")#text(" with ")#mi("{\\delta^2+1=0 \\text{ mod } q}")#text("; conversely, if ")#mi("{c,d}")#text(" obey such a condition then ")#mi("{q|c^2+d^2}")#text(". The number of such ")#mi("{\\delta}")#text(" is at most ")#mi("{X^{o(1)}}")#text(". Thus it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\gamma \\in \\text{Fund}( \\Gamma_\\infty \\backslash \\text{PSL}_2({\\bf Z})): c/d = \\delta \\text{ mod } q} F( \\gamma i ) \\ll X^{1/2+o(1)} + q^{-1/2} X^{3/4+o(1)}")]]

#text("for each such ")#mi("{\\delta}")#text(".")

#text("The constraint ")#mi("{c/d = \\delta \\text{ mod } q}")#text(" constrains ")#mi("{\\gamma}")#text(" to a single right coset of ")#mi("{\\Gamma_0(q)}")#text(". Thus the left-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\gamma^{\\prime} \\in \\text{Fund}( \\Gamma_\\infty \\backslash \\Gamma_0(q))} F( \\gamma^{\\prime} \\gamma i )")]]

#text("which is just ")#mi("{P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[F](\\gamma i)}")#text(". Applying ")#link(<tao-503126878d17fcd6bde7>)[#text("(22)")]#text(" (and interchanging the Poincaré series and the Laplacian), it thus suffices to show that ")#metadata(none) <tao-3bfc269594ef649228e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[F]\\right|^2\\ d\\mu_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\ll X^{1+o(1)} + q^{-1} X^{3/2+o(1)}", block: true)]]

#text("and ")#metadata(none) <tao-fb04dcb6970e4c3d1873>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\int_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\left|P_{\\Gamma_\\infty \\backslash \\Gamma_0(q)}[\\Delta F]\\right|^2\\ d\\mu_{\\Gamma_0(q) \\backslash {\\mathbf H}} \\ll X^{1+o(1)} + q^{-1} X^{3/2+o(1)}.", block: true)]]

#text("We can compute")

#align(center)[#tao-fit-display[#mitex("\\Delta F(x+iy) = e(mx) \\tilde g( \\frac{1}{Xy} )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde g(u) = 2 u g^{\\prime}(u) + u^2 g^{\\prime\\prime}(u) - \\frac{4\\pi^2 m^2}{X^2} u^{-2} g(u).")]]

#text("By hypothesis, the coefficient ")#mi("{\\frac{4\\pi^2 m^2}{X^2}}")#text(" is bounded, and so ")#mi("{\\tilde g}")#text(" has all derivatives bounded while remaining supported in ")#mi("{[1,2]}")#text(". Because of this, the arguments used to establish ")#link(<tao-3bfc269594ef649228e9>)[#text("(24)")]#text(" can be adapted without difficulty to establish ")#link(<tao-fb04dcb6970e4c3d1873>)[#text("(25)")]#text(".")

#text("Using the expansion ")#link(<tao-2792e2efcb433e305f19>)[#text("(14)")]#text(" of ")#link(<tao-4cf6829aa93728e8f3c9>)[#text("(13)")]#text(", we can write the left-hand side of ")#link(<tao-3bfc269594ef649228e9>)[#text("(24)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("m (\\int_0^\\infty \\left|\\tilde g( \\frac{m}{Xy})\\right|^2 \\frac{dy}{y^2} + \\sum_{q|c} \\frac{S(m,m;c)}{c} V(\\frac{m}{c}))", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("V(u) := \\frac{1}{u} \\int_0^\\infty \\int_{\\bf R} \\tilde g( \\frac{m}{Xy} ) \\tilde g(\\frac{m (x^2+y^2)}{X u^2 y}) e(- x - u^2 \\frac{x}{x^2+y^2} )\\ \\frac{dx dy}{y^2}.")]]

#text("The first term can be computed to give a contribution of ")#mi("{O(X)}")#text(", so it suffices to show that ")#metadata(none) <tao-f4bf9f7fcbedaba0392f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{q|c} \\frac{S(m,m;c)}{c} V(\\frac{m}{c}) \\ll m^{-1} q^{-1} X^{3/2+o(1)}.")]]

#text("The quantity ")#mi("{V(u)}")#text(" is vanishing unless ")#mi("{u \\gg m/X}")#text(". In that case, the integrand vanishes unless ")#mi("{y \\sim m/X}")#text(" and ")#mi("{x = O(u)}")#text(", so by the triangle inequality we have ")#mi("{V(u) \\ll X/m}")#text(". So the left-hand side of ")#link(<tao-f4bf9f7fcbedaba0392f>)[#text("(26)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\frac{X}{m} \\sum_{q|c: c \\ll X} \\frac{\\left|S(m,m;c)\\right|}{c}.", block: true)]]

#text("By the Weil bound for Kloosterman sums, we have ")#tao-math("{\\left|S(m,m;c)\\right| \\ll X^{o(1)} (m,c)^{1/2} c^{1/2}}", block: false)#text(", so on factoring out ")#mi("{q}")#text(" from ")#mi("{c}")#text(" we can bound the previous expression by")

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\frac{X^{1+o(1)}}{m} q^{-1/2} \\sum_{c: c \\ll X/q} (m,c)^{1/2} c^{-1/2}", block: true)



#tao-math(" & \\ll \\frac{X^{1+o(1)}}{m} q^{-1/2} \\sum_{d|m} \\sum_{c: c \\ll X/q; d|c} d^{1/2} c^{-1/2}", block: true)



#tao-math(" & \\ll \\frac{X^{1+o(1)}}{m} q^{-1/2} \\sum_{d|m} d^{1/2} (\\frac{X}{qd})^{1/2}", block: true)



#tao-math(" & \\ll \\frac{X^{1+o(1)}}{m} q^{-1/2} X^{o(1)} \\frac{X^{1/2}}{q^{1/2}}", block: true)
]

#text("and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" By using improvements to Selberg’s 3/16 theorem (such as ")#link("http://www.ams.org/mathscinet-getitem?mr=1937203")[#text("the result of Kim and Sarnak")]#text(" improving this fraction to ")#mi("{\\frac{975}{4096}}")#text(") one can improve the second term in the right-hand side of ")#link(<tao-97e38e1b2d7735fb875c>)[#text("(23)")]#text(" slightly.")
]

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b24f64a216946f595854696297e5d05c40d08af89fe00bed34c5637cf590a02-818fe79e329ac73205d37288b757662d20e11838e944d54954356be6a2c94785.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asaf")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458182")[#strong[#text("Asaf")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2015")])]

#text("Dear Prof. Tao,")

#text("Do you feel/think that there are genuine advantages using those PDE approaches over the usual representation-theoretical approach? For obvious one con, you don’t clearly ”see” Hecke operators here.")

#text("For example, if I’m not mistaken, (17) is equivalent to some main-term analysis of the fundamental solution (see Iwaniec’s book about spectral methods where he treats the automorphic Green’s function in full detail).")

#text("P.S. I believe the first systematic treatment of that kind of analysis involved with PDEs was done in the Lax-Phillips book.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2015")])]

#text("A great question! All the PDE arguments here are “L^2-based” and as such can be easily converted to their representation-theoretic counterparts through the spectral theorem. (Indeed, the way I found these arguments was starting with the traditional arguments and rewriting them in terms of wave propagators.) The main (but minor) benefits when doing so is that one does not need to work with asymptotics of modified Bessel functions, and also one does not need to pay all that much attention to the distinction between the continuous and pure point components of the spectrum. But this was never the deepest part of the theory.")

#text("My (somewhat vague) hope is that there are more advanced L^p PDE methods for p not equal to 2 that are easier to see in terms of PDE such as the wave equation than they would be in terms of eigenfunctions. For instance, for the wave equation there are Strichartz estimates and Morawetz estimates, which give non-trivial L^p estimates for such solutions on domains such as hyperbolic space. Unfortunately when passing to modular curves it seems that such estimates are nontrivial only for short times t, which is not the regime of interest in analytic number theory (this is part of a much more general problem that the wave equation on compact or nearly compact manifolds is notoriously difficult to control for long times).")

#text("To me, perhaps the main benefit is psychological; I feel very comfortable with the wave equation, but did not previously have much intuition for cusp forms, Eisenstein series, or the modified Bessel function, and so I find automorphic forms methods much more approachable now.")

#text("p.s. I can’t believe I missed the connection to the Lax-Phillips scattering theory, which of course uses the exact same wave equation! I’ve modified the post accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lqpman")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458210")[#strong[#text("lqpman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2015")])]

#text("Actually, the application of scattering theory of the wave equation in hyperbolic space to the theory of automorphic forms was originally due to Faddeev and Pavlov in 1972, after a remark due to Gel’fand in his 1962 ICM talk. The book by Lax and Phillips “Scattering Theory for Automorphic Functions” (Princeton, 1976) was to a great extent motivated by this work.")

#emph[#text("[Thanks for the reference – I’ve adjusted the text accordingly – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458187")[#strong[#text("Spectra of Modular Surfaces I | Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2015")]

#text("[…] 回到对的讨论。我们将另辟新章讨论作为算术量子混沌系统的及其高能渐进。在低能端，数论学家感兴趣的主要是第一特征值估计： (Selberg 1/4猜想)，即大于0的离散谱完全落在连续谱中。 (Selberg 1/4猜想，几何分析形式)满足，梯度估计 成立。 不难证明1/4是最优的：时，的尖点谱在中趋于稠密。事实上，对于不可约2维偶Galois表示，若相应的Artin L-函数是整函数(即满足Artin猜想)，则通过Langlands对应原理，它给出上的Maass尖点形式，是的导子。 对于，通过简单的推理即可得到强得多的下界，例如 (Vignéras). 对于一般的，Selberg证明了，对这个结果感兴趣的读者不妨参考陶哲轩的博文。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2015")])]

#text("The remark below theorem 1 (that the spectrum should be contained in ")#mi("[-3/16, +\\infty)")#text(") is not sufficiently clear.")

#emph[#text("[Sign error corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lqpman")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458250")[#strong[#text("lqpman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2015")])]

#text("Dear Prof. Tao,")

#text("there is a reference with no links to a previous post of yours in the beginning of the paragraph just before the inhomogeneous wave equation, i.e. the formula preceding the automorphic wave equation (15).")

#text("I’d also like to remark that the real (time) line times the Poincaré half-plane ")#mi("\\mathbf{H}")#text(" is (a piece of) the three-dimensional anti-de Sitter space-time with scalar curvature -2, hence equation (15) in ")#mi("\\mathbf{H}")#text(" is the conformally coupled wave equation in this space-time. This raises the following question: according to the classification of the self-adjoint extensions of the spatial part of the Klein-Gordon operator in anti-de Sitter space-time (see e.g. the paper by A. Ishibashi and R. M. Wald, Class. Quantum Grav. 21 (2003) 2981-3013), one should have a 1-parameter family of boundary conditions at conformal infinity (corresponding to the time line times the boundary of the upper half-plane) for conformal coupling and mass zero, due to the fact that ")#mi("-\\Delta-\\frac{1}{4}")#text(" has deficiency indices (1,1). Which boundary condition is the one chosen in the above analysis?")

#text("Finally, does this choice of boundary conditions affect the decay of solutions of the automorphic wave equation? It is known, for instance, that solutions of the conformally coupled wave equation in anti-de Sitter space-time with Dirichlet boundary conditions at conformal infinity do not decay at all for large times since the solutions are always refocused back after dispersing for a while.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458252")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2015")])]

#text("Thanks for pointing out the missing link, which I’ve now put in.")

#text("I’ve not thought about self-adjoint extensions of hyperbolic operators such as the Klein-Gordon operator or d’Lambertian before; I’m not sure it is directly relevant for the above analysis as we are not trying to deploy a functional calculus for d’Lambertian or Klein-Gordon operators such as ")#mi("-\\partial_{tt} + \\Delta + \\frac{1}{4}")#text(", but are instead trying to use a functional calculus for the automorphic Laplacian ")#mi("-\\Delta - \\frac{1}{4}")#text(". In particular, solutions to the automorphic wave equation would probably not lie in the domain for the Klein-Gordon operator, much as solutions to the Poisson equation ")#mi("\\Delta u = 0")#text(" usually do not lie in the domain of the Laplacian. Nevertheless there should clearly be some relationship between the two functional calculi, but I would have to think further to discern the precise link. Note also that conformal compactification does not seem to play well with ")#mi("\\Gamma")#text("-automorphy for various discrete groups, for instance there doesn’t appear to be a good conformal compactification of the partially periodic spacetime ")#mi("{\\bf R} \\times (\\Gamma_\\infty \\backslash {\\mathbf H})")#text(", so these sorts of techniques may not be so relevant for the number theory applications (though they are presumably useful for understanding the automorphic wave equation on hyperbolic space when not restricting to ")#mi("\\Gamma")#text("-automorphic solutions).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lqpman")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458256")[#strong[#text("lqpman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2015")])]

#text("Actually, I was referring to self-adjoint extensions of the “spatial” part ")#mi("-\\Delta-\\frac{1}{4}")#text(". It is this operator on ")#mi("\\mathbf{H}")#text(" (with domain ")#mi("C^\\infty_c(\\mathbf{H})")#text(", I had forgotten to mention) which has deficiency indices (1,1), according to the paper of Ishibashi and Wald I have cited above. Sorry for not being sufficiently clear before.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2015")])]

#text("Hmm, when I calculate the wave equation for anti de Sitter space I seem to get a different wave equation than (15). If I take the coordinates ")#mi("(t,x,y)")#text(" with ")#mi("y>0")#text(" and metric ")#mi("ds^2 = \\frac{1}{y^2} ( - dt^2 + dx^2 + dy^2 )")#text(", I seem to get a d’Lambertian of ")#mi("y^2 (-\\partial_{tt} + \\partial_{xx} + \\partial_{yy} - \\frac{1}{y} \\partial_y )")#text(" whereas the differential operator for (15) is ")#mi("-\\partial_{tt} + y^2 (\\partial_{xx} + \\partial_{yy})")#text(". I may have made a sign error or two but I doubt that the two operators are closely related.")

#text("One can use standard energy methods to show that the equation (15) is globally hyperbolic, with the Cauchy problem being well posed in ")#mi("C^\\infty_c({\\bf H}) \\times C^\\infty_c({\\bf H})")#text(", so there should be a unique self-adjoint extension (zero deficiency indices) for this operator.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lqpman")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458270")[#strong[#text("lqpman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2015")])]

#text("Oops, you’re right. I forgot the factor ")#mi("\\frac{1}{y^2}")#text(" multiplying ")#mi("\\partial_{tt}")#text(". This factor changes everything, since anti-de Sitter space-time is not globally hyperbolic.")

#text("OK, this sort of answers my question by invalidation. A bit embarrassing, but I learned something. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2015")])]

#text("I believe the relevant spacetime for (15) is the spacetime ")#mi("{\\bf R} \\times {\\bf H}")#text(" with metric ")#mi("ds^2 = -dt^2 + \\frac{1}{y^2} (dx^2 + dy^2)")#text(", which differs from the anti de Sitter metric by not having the ")#mi("\\frac{1}{y^2}")#text(" factor multiplying the ")#mi("dt^2")#text(" term.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lqpman")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458272")[#strong[#text("lqpman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2015")])]

#text("Indeed. Which is, of course, globally hyperbolic since it is ultra-static and the spatial factor ")#mi("\\mathbf{H}")#text(" is a complete Riemannian manifold.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458299")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2015")])]

#text("Why do automorphic forms relate to special relativity?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aac9233c8817779fd1770dff1f3a8b64aac8beb1eb6c689b9af9f64f8a843cf3-1537ec7eaab624683d03b826afa1788ed8c7201e073cb26d0db6406354098fb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wilde")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458368")[#strong[#text("Wilde")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2015")])]

#text("‘which (up to a harmless sign) is exatly the representation . . . ‘")

#text("Typo here.")

#text("Mr Tao: I’ve got an unrelated question for you and would be grateful to you if you answered it. Have you ever perused string-theory papers and been able to understand moderately or extremely well what they’re discussing, or, because those are papers in theoretical physics, are they speaking a totally different language than the mathematical one you know?")

#emph[#text("[Corrected, thanks. I’ve looked at some QFT papers, and intend to learn that material in depth at some point (there are a number of treatments of these topics from a mathematical perspective), but have not read any of the string theory literature (other than popular expositions, of course). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a93e1c356f7caad1a44a06aab64855d231a99fab0e53b26eb2ec844eb413fe3-981208cbf55441021ddc36ced26b542b1f8a1297e6d716b2a51e1eea3255b949.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hashtag")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458378")[#strong[#text("hashtag")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2015")])]

#text("I found two relevant references: One is a talk by Terence Tao in March 2015 on “Can the Navier-Stokes Equations Blow Up in Finite Time?” (")#link("https://www.youtube.com/watch?v=DgmuGqeRTto")[#text("https://www.youtube.com/watch?v=DgmuGqeRTto")]#text("“), which is a wonderful summary of all these ideas – understandable for non-experts as me :-)")

#text("Another one is a NYT article from July 2015: ")#link("http://www.nytimes.com/2015/07/26/magazine/the-singular-mind-of-terry-tao.html?_r=1")[#text("http://www.nytimes.com/2015/07/26/magazine/the-singular-mind-of-terry-tao.html?_r=1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Quas")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-458395")[#strong[#text("Anthony Quas")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2015")])]

#text("I guess (line 3) that the projective speciexetal groups are the projective special groups? (you do write PSL one line later, but the word “speciexetal” sounded almost mathematical enough that this could have been a class of groups I was unaware of).")

#emph[#text("[Corrected, thanks – no idea where that typo came from, though. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-467210")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2016")]

#text("For a long time I confused the Schrödinger equation, the heat equation and the wave equation. Since in the textbook they all use Fourier series.")

#text("Harmonic analysis seems intimately tied to the eigenfunctions of the Laplacian ")#mi("\\Delta")#text(". In the case of a circle or sphere or many symmetric spaces these well-understood (ahem… on Wikipedia). I assumed analysis on ")#mi("\\mathbb{H}/SL(2,\\mathbb{Z})")#text(" should play out identically and indeed you augment Fourier analysis on the line to Harmonic Analysis on the fundamental domain in some kind of way but the result is very complicated.")

#text("Can you develop representation theory or harmonic from other PDE?")#linebreak()#text(" I am not sure there’s even any point to asking this question until I re-read my analysis textbooks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic computation of correlations of the divisor function | What's new")]], [#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-472021")[#strong[#text("Heuristic computation of correlations of the divisor function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("[…] on error terms. A more modern approach proceeds using automorphic form methods, as discussed in this previous post. A third approach, which unfortunately is only heuristic at the current level of technology, is to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/08/15/a-wave-equation-approach-to-automorphic-forms-in-analytic-number-theory/#comment-512997")[#strong[#text("Adeles and Automorphic Forms – Tlapohuayotl")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")]

#text("[…] group, the actions, but it is cool how this is related to hyperbolic equations and pde. There is a post on Terry Tao’s blog on this and how a background in PDE can overlap with this aspect of […]")
]
