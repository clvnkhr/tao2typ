// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:19:41.099022+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A quick application of the closed graph theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A quick application of the closed graph theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 April 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/")[#text("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In functional analysis, it is common to endow various (infinite-dimensional) vector spaces with a variety of topologies. For instance, a normed vector space can be given the ")#link("https://en.wikipedia.org/wiki/Strong_topology")[#text("strong topology")]#text(" as well as the ")#link("https://en.wikipedia.org/wiki/Weak_topology")[#text("weak topology")]#text("; if the vector space has a predual, it also has a ")#link("https://en.wikipedia.org/wiki/Weak_topology#The_weak-.2A_topology")[#text("weak-* topology")]#text(". Similarly, spaces of operators have a number of useful topologies on them, including the ")#link("https://en.wikipedia.org/wiki/Operator_norm")[#text("operator norm topology")]#text(", ")#link("https://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong operator topology")]#text(", and the ")#link("https://en.wikipedia.org/wiki/Weak_operator_topology")[#text("weak operator topology")]#text(". For function spaces, one can use topologies associated to various modes of convergence, such as uniform convergence, pointwise convergence, locally uniform convergence, or convergence in the sense of distributions. (A small minority of such modes are not topologisable, though, the most common of which is pointwise almost everywhere convergence; see Exercise 8 of ")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("this previous post")]#text(").")

#text("Some of these topologies are much stronger than others (in that they contain many more open sets, or equivalently that they have many fewer convergent sequences and nets). However, even the weakest topologies used in analysis (e.g. convergence in distributions) tend to be Hausdorff, since this at least ensures the uniqueness of limits of sequences and nets, which is a fundamentally useful feature for analysis. On the other hand, some Hausdorff topologies used are “better” than others in that many more analysis tools are available for those topologies. In particular, topologies that come from Banach space norms are particularly valued, as such topologies (and their attendant norm and metric structures) grant access to many convenient additional results such as the ")#link("https://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(", the ")#link("https://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(", the ")#link("https://en.wikipedia.org/wiki/Open_mapping_theorem_(functional_analysis)")[#text("open mapping theorem")]#text(", and the ")#link("https://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem")]#text(".")

#text("Of course, most topologies placed on a vector space will not come from Banach space norms. For instance, if one takes the space ")#mi("{C_0({\\bf R})}")#text(" of continuous functions on ")#mi("{{\\bf R}}")#text(" that converge to zero at infinity, the topology of uniform convergence comes from a Banach space norm on this space (namely, the uniform norm ")#mi("{\\| \\|_{L^\\infty}}")#text("), but the topology of pointwise convergence does not; and indeed all the other usual modes of convergence one could use here (e.g. ")#mi("{L^1}")#text(" convergence, locally uniform convergence, convergence in measure, etc.) do not arise from Banach space norms.")

#text("I recently realised (while teaching ")#link("https://ccle.ucla.edu/course/view/16S-MATH245C-1")[#text("a graduate class in real analysis")]#text(") that the closed graph theorem provides a quick explanation for why Banach space topologies are so rare:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-9f584196e7fe6de85d38>#text(" Let ")#mi("{V = (V, {\\mathcal F})}")#text(" be a Hausdorff topological vector space. Then, up to equivalence of norms, there is at most one norm ")#mi("{\\| \\|}")#text(" one can place on ")#mi("{V}")#text(" so that ")#mi("{(V,\\| \\|)}")#text(" is a Banach space whose topology is at least as strong as ")#mi("{{\\mathcal F}}")#text(". In particular, there is at most one topology stronger than ")#mi("{{\\mathcal F}}")#text(" that comes from a Banach space norm.")
]

#emph[#text("Proof:")]#text(" Suppose one had two norms ")#mi("{\\| \\|_1, \\| \\|_2}")#text(" on ")#mi("{V}")#text(" such that ")#mi("{(V, \\| \\|_1)}")#text(" and ")#mi("{(V, \\| \\|_2)}")#text(" were both Banach spaces with topologies stronger than ")#mi("{{\\mathcal F}}")#text(". Now consider the graph of the identity function ")#mi("{\\text{id}: V \\rightarrow V}")#text(" from the Banach space ")#mi("{(V, \\| \\|_1)}")#text(" to the Banach space ")#mi("{(V, \\| \\|_2)}")#text(". This graph is closed; indeed, if ")#mi("{(x_n,x_n)}")#text(" is a sequence in this graph that converged in the product topology to ")#mi("{(x,y)}")#text(", then ")#mi("{x_n}")#text(" converges to ")#mi("{x}")#text(" in ")#mi("{\\| \\|_1}")#text(" norm and hence in ")#mi("{{\\mathcal F}}")#text(", and similarly ")#mi("{x_n}")#text(" converges to ")#mi("{y}")#text(" in ")#mi("{\\| \\|_2}")#text(" norm and hence in ")#mi("{{\\mathcal F}}")#text(". But limits are unique in the Hausdorff topology ")#mi("{{\\mathcal F}}")#text(", so ")#mi("{x=y}")#text(". Applying the closed graph theorem (see also ")#link("https://terrytao.wordpress.com/tag/closed-graph-theorem/")[#text("previous discussions")]#text(" on this theorem), we see that the identity map is continuous from ")#mi("{(V, \\| \\|_1)}")#text(" to ")#mi("{(V, \\| \\|_2)}")#text("; similarly for the inverse. Thus the norms ")#mi("{\\| \\|_1, \\| \\|_2}")#text(" are equivalent as claimed. ")#mi("\\Box")

#text("By using various generalisations of the closed graph theorem, one can generalise the above proposition to ")#link("https://en.wikipedia.org/wiki/Fr%C3%A9chet_space")[#text("Fréchet spaces")]#text(", or even to ")#link("https://en.wikipedia.org/wiki/F-space")[#text("F-spaces")]#text(". The proposition can fail if one drops the requirement that the norms be stronger than a specified Hausdorff topology; indeed, if ")#mi("{V}")#text(" is infinite dimensional, one can use a ")#link("https://en.wikipedia.org/wiki/Basis_(linear_algebra)#Hamel_basis")[#text("Hamel basis")]#text(" of ")#mi("{V}")#text(" to construct a linear bijection on ")#mi("{V}")#text(" that is unbounded with respect to a given Banach space norm ")#mi("{\\| \\|}")#text(", and which can then be used to give an inequivalent Banach space structure on ")#mi("{V}")#text(".")

#text("One can interpret Proposition ")#link(<tao-9f584196e7fe6de85d38>)[#text("1")]#text(" as follows: once one equips a vector space with some “weak” (but still Hausdorff) topology, there is a ")#emph[#text("canonical")]#text(" choice of “strong” topology one can place on that space that is stronger than the “weak” topology but arises from a Banach space structure (or at least a Fréchet or F-space structure), provided that at least one such structure exists. In the case of function spaces, one can usually use the topology of convergence in distribution as the “weak” Hausdorff topology for this purpose, since this topology is weaker than almost all of the other topologies used in analysis. This helps justify the common practice of describing a Banach or Fréchet function space just by giving the set of functions that belong to that space (e.g. ")#mi("{{\\mathcal S}({\\bf R}^n)}")#text(" is the space of ")#link("https://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz functions")]#text(" on ")#mi("{{\\bf R}^n}")#text(") without bothering to specify the precise topology to serve as the “strong” topology, since it is usually understood that one is using the canonical such topology (e.g. the Fréchet space structure on ")#mi("{{\\mathcal S}({\\bf R}^n)}")#text(" given by the usual Schwartz space seminorms).")

#text("Of course, there are still some topological vector spaces which have no “strong topology” arising from a Banach space at all. Consider for instance the space ")#mi("{c_c({\\bf N})}")#text(" of finitely supported sequences. A weak, but still Hausdorff, topology to place on this space is the topology of pointwise convergence. But there is no norm ")#mi("{\\| \\|}")#text(" stronger than this topology that makes this space a Banach space. For, if there were, then letting ")#mi("{e_1,e_2,e_3,\\dots}")#text(" be the standard basis of ")#mi("{c_c({\\bf N})}")#text(", the series ")#tao-math("{\\sum_{n=1}^\\infty 2^{-n} e_n / \\left\\| e_n \\right\\|}", block: false)#text(" would have to converge in ")#mi("{\\| \\|}")#text(", and hence pointwise, to an element of ")#mi("{c_c({\\bf N})}")#text(", but the only available pointwise limit for this series lies outside of ")#mi("{c_c({\\bf N})}")#text(". But I do not know if there is an easily checkable criterion to test whether a given vector space (equipped with a Hausdorff “weak” toplogy) can be equipped with a stronger Banach space (or Fréchet space or ")#mi("{F}")#text("-space) topology.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2016")])]

#text("Is it possible to extend proposition 1 from Banach spaces to (some class of) metric spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2016")])]

#text("Well, completeness is not enough; the one-point compactification ")#mi("{\\bf R} \\cup \\{\\infty\\}")#text(" of the real line is a complete metric space, but if one strengthens the topology by isolating the point at infinity (creating the disjoint union of ")#mi("{\\bf R}")#text(" and ")#mi("\\infty")#text(", separated by some positive distance, and using some suitably normalised metric on the ")#mi("{\\bf R}")#text(" part) one obtains a different complete metric space.")

#text("On the other hand, if one strengthens the topology on a compact Hausdorff space, one has to destroy compactness in order to change the topology (because continuous bijections from one compact Hausdorff space to another are homeomorphisms). But this certainly doesn’t mean that every Hausdorff space has a unique compact strengthening, so this isn’t really of a form analogous to Proposition 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467866")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2016")])]

#text("I find the question at the end about an easily checkable criterion intriguing, in part because “easily checkable” is so subjective. If there si a stronger Banach space topology on a topological vector space V, in most cases it may be too hard to explicitly write it down. However if no such structure exists, it is not obvious how to rule it out. Thus it might be helpful to find a dual criterion where the existence of some explicit object that V has no stronger Banach space structure.")

#text("Certainly one such obstruction is the existence of a stronger F-space topology on V that is not a Banach space topology. It seems hard to simplify that condition, so we should focus our efforts on the remaining case, which is ruling out the existence of a stronger F-space structure on V. However everything I’m about to say makes just as much sense, and may be clearer, when “F-space” is replaced with “Banach space”.")

#text("One such obstruction comes from the closed graph theorem. If there is a morphism from an F-space to V whose graph is closed but which is not continuous, then V has no stronger F-space stucture.")

#text("Another obstruction generalizes your argument in the last paragraph. If there is a sequence of vectors in V such that for any sequence of positive weights, the partial sums of the vectors times the weights do not converge, then V is not a weaker topology on an F-space.")

#text("These obstructions seem quite different, in that the first obstruction punishes V for being too close to an F-space, and the second one punishes V for being very far from an F-space. In particular I expect that the first obstruction does not apply to the space of finitely supported sequences with the pointwise convergence topology. I don’t know whether there is any case where the first obstruction applies and not the second, but I suspect so. If there is, then perhaps a better obstruction could be made by trying to combine the two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3dafc6395cf35a9043f0bcbde4fa151ec62c73296e67a95f28620f47e6c7379-0057cee36edc41ab903abfca2a737dab590fcf0f009990842792145b9fba09c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abdelmalek Abdesselam")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467867")[#strong[#text("Abdelmalek Abdesselam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2016")])]

#text("Great post as always! It might be good to mention here the related notion of “normal space of distributions” introduced by Schwartz for his general theory of kernels. Also, another place where the closed graph theorem makes a perhaps surprising (at least to me the first time I saw it) appearance is that distribution valued random variables with finite moments of all orders are such the multilinear forms given by the moments are automatically continuous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467877")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2016")])]

#text("I think this is also Exercice 2 of section 3 of chapter I of Bourbaki, Espaces Vectoriels Topologiques, p. 28 in the French version.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c9f8dd8267e4c12bd12fa09529c334980c1a0cd164315371babd43604ec7c2a-d2bcda6fa9abdcf51462199b8d744fc3433ba9f5e9266421f45ee83abc2f0d7c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miroslav Chlebik")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467882")[#strong[#text("Miroslav Chlebik")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("Concerning the question of whether “there is an easily checkable criterion to test whether a given vector space (equipped with a Hausdorff “weak” toplogy) can be equipped with a stronger Banach” the results of the following paper are relevant,")#linebreak()#text(" ")#link("http://projecteuclid.org/download/pdf_1/euclid.mmj/1028998069")[#text("http://projecteuclid.org/download/pdf_1/euclid.mmj/1028998069")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467888")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("A small remark: Proposition 1 is in fact ")#emph[#text("logically equivalent")]#text(" to the closed graph theorem. Indeed, if ")#mi("T: X \\to Y")#text(" is a closed linear map between Banach spaces, then ")#tao-math("(x,Tx) \\mapsto \\left\\|x\\right\\|_X + \\left\\|Tx\\right\\|_Y", block: false)#text(" is a Banach space norm on the graph ")#mi("\\{ (x,Tx): x \\in X \\}")#text(" which is stronger than the Banach space norm ")#tao-math("(x,Tx) \\mapsto \\left\\|x\\right\\|_X", block: false)#text(". By Proposition 1, these norms must be equivalent, and hence ")#mi("T")#text(" is bounded and thus continuous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Wengenroth")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467902")[#strong[#text("Jochen Wengenroth")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2016")])]

#text("Are there any situations where the existence of a stronger Banach space topology comes as a surprise or is difficult to check?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9fe37471f7a934331c4386edf57b5e65a3052f8c3f71b87ae875149b94be71b-20c43104ab6bcb2bd1fdac2268f5abe6c570abc709b9f0b4116fc5b9f2464213.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467924")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2016")])]

#text("I think the following paper can “reduce” your question to looking for a stronger topology which is uniformly homeomorphic to a Banach space with nontrivial type. (")#link("http://www.ams.org/mathscinet/search/publdoc.html?amp=&loc=refcit&refcit=178322&vfpref=html&r=2&mx-pid=2301967")[#text("http://www.ams.org/mathscinet/search/publdoc.html?amp=&loc=refcit&refcit=178322&vfpref=html&r=2&mx-pid=2301967")]#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43835ecb1fd45c3fbe248f6b588378c600cc7b5c75a9990b405c793d4b7d3831-05a9630a6f62839b5632b7a62071c6145cfecfd41a2cbcad19af495010b3f34b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jürgen Voigt")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467927")[#strong[#text("Jürgen Voigt")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2016")])]

#text("I do not think that there is a uniform answer to the (somewhat vague) question for an `easily checkable criterion’ posed at the end. This is because I have the impression that the reason for the non-existence of such a topology may be that the space is too small, or else that it is too large, and for these two alternative cases there `must’ be different reasonings.")

#text("For instance, my answer for the non-existence of an F-space topology on c_c would be that infinite dimensional F-spaces cannot have countable dimension. (This is a standard exercise in basic courses on FA, for Banach spaces, as an application of Baire’s catagory theorem. And the proof works in the same way for F-spaces.) The same proof works for the proof that C_c(\\R) (or C_c^\\infty(\\R)) cannot carry an F-space topology stronger than the topology of pointwise convergence. These examples are cases where the space is ‘too small’.")

#text("For the case that the space is too large the method has been indicated – to my taste – by Will Sawin in his comment given above. To expand this, let us look at the question why \\R^\\N, with product topology, cannot carry a stronger Banach space topology: in this case, the product topology is a Fr\\’echet space topology which is easily seen not to be defined by a norm. So, the closed graph theorem gives the negative answer. (However, I do not see an immediate answer to the question whether \\R^\\R, with product topology, carries a stronger F-space topology, although I have the feeling that the answer is negative.)")

#text("After this discussion, I think that I have given some answer to the question. First decide whether the space is too small or too large. In the first case, use Baire catagory. In the second case find a topology on the space which allows the application of a closed graph theorem and which is not Banach, Fr\\’echet or F-space, respectively.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Wengenroth")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-467929")[#strong[#text("Jochen Wengenroth")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2016")])]

#mi("\\mathbb R^{\\mathbb R}")#text(" is ultrabornological and thus is qualifies as a domain in the closed graph theorem. Hence there is no stronger Banach (or Frechet) topology on it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d587262dad00c6c77867cdb951c666e0555ecd03468374b3a3dd0c6ae3d1c244-15a7f95e2cfb8e4948af2c6acbfd12915e1ec333a7eeb704b10c48fc7a1b6513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Arendt")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-468006")[#strong[#text("Wolfgang Arendt")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2016")])]

#text("An inequivalent complete norm as mentioned right after Proposition1 can be constructed in few lines as follows:")

#text("If E is an infinite dimensional Banach space, then there exists a discontinuous linear functional φ: E → R. Take u ∈ E such that φ(u) = 1. Then Sx := x − 2φ(x)u defines a linear, discontinuous map S : E → E, and")#linebreak()#text(" S o S = Id. Thus |||x||| := ||Sx|| defines a complete norm on E which is not equivalent to the given norm || · ||")

#text("This is taken from first lines of the introduction to the article W.Arendt, R. Nittka: Equivalent complete norms and positivity. Arch. Math. 92 (2009), 414–427,")

#text("where it is also shown that on each Banach space there is always in infinite number of mutually non-equivalent complete norms. They might all be useless, of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a283b14b2c37e872797c71469959cdda04647917fdd93bedf4bc8d418f553cac-bee5fb84d727b57471ffca6ab743f7fb8e5588cf870ca5a277b1750c6dc245fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Steif")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-468547")[#strong[#text("Jeff Steif")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Proposition 1 is very related to a lunch discussion I had today")#linebreak()#text(" (without knowing about this post at that time).")

#text("Question: Let V be a vector space provided with two inequivalent Banach norms. Terence explained how to do this using Hamel bases.")#linebreak()#text(" Is it possible that (V, first norm) and (V, 2nd norm) are isomorphic as")#linebreak()#text(" Banach spaces? Never? Always? Sometimes? We know of course that the identity map does not provide for us an isomorphism.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-468559")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("The linear bijection used in my construction shows that the two Banach spaces constructed there are indeed isomorphic. On the other hand, one can take two nonisomorphic Banach spaces of the same linear dimension (e.g. ")#mi("L^p({\\bf R})")#text(" and ")#mi("L^q({\\bf R})")#text(" for some ")#mi("1 < p < q < \\infty")#text(" and use Hamel bases and the axiom of choice to construct a linear bijection between them to create two Banach space norms on the same space that are not isomorphic.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a283b14b2c37e872797c71469959cdda04647917fdd93bedf4bc8d418f553cac-bee5fb84d727b57471ffca6ab743f7fb8e5588cf870ca5a277b1750c6dc245fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Steif")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-468564")[#strong[#text("Jeff Steif")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Completely agree. Just got up, realised this in the middle of the night and was going to correct/remove the question. Apologies for the trivial post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ed9732e4b8b3509ad13381ebfc93cfab11595df593fb001c7a76218c3a06a6-f65d67da753b3ef2d4fbf5fedcee96869fb233db04b9ea79e86858b40a792a55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luiz Botelho -Físico Matemático de Altas energias e Turbulencia estocástica.")]], [#link("https://terrytao.wordpress.com/2016/04/22/a-quick-application-of-the-closed-graph-theorem/#comment-468700")[#strong[#text("Luiz Botelho -Físico Matemático de Altas energias e Turbulencia estocástica.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("Terence")#linebreak()#text(" Just a simple curious remark on how “rare” are Complete normed structures Topologies on Vector Spaces :Every Banach Space is isometrically isomorphic to a closed subspace of a space of continuous function defined on a Compact Hausdorff Space .If one introduces a continuous multiplicative structure , making it a Banach Algebra and if it is self adjoint , one has the Gelfand Theorem that the whole Banach Space is isometrically isomorphic to a space of continuous function on a Hausdorff Compact Space (defined as the Maximal ideal space of the Algebraic structure endowed with the Gelfand Topology ).This line may be useful to pursue !!.")
]
