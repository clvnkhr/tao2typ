// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/
// Converted to Typst by tao2typ: "2026-10-14T07:11:20.013029+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Upper and lower bounds for the density Hales-Jewett problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Upper and lower bounds for the density Hales-Jewett problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/")[#text("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is a continuation of several threads from Tim Gowers’ massively collaborative mathematics project, “")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/")[#text("A combinatorial approach to density Hales-Jewett")]#text("“, which I discussed in my ")#link("https://terrytao.wordpress.com/2009/02/01/a-massively-collaborative-mathematical-project/")[#text("previous post")]#text(".")

#text("For any positive integer n, let ")#mi("{}[3]^n")#text(" be the set of strings of length n consisting of 1s, 2s, and 3s, and define a combinatorial line to be a triple of such strings arising by taking a string in ")#mi("\\{1,2,3,x\\}^n")#text(" with at least one wildcard x, and substituting x=1, x=2, x=3 in that string (e.g. xx1x3 would give the combinatorial line ")#mi("\\{11113, 22123, 33133\\}")#text("). Call a set ")#mi("A \\subset [3]^n")#text(" of strings ")#emph[#text("line-free")]#text(" if it contains no combinatorial lines, and let ")#mi("c_n")#text(" be the size of the largest set A which is line-free. We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Density Hales-Jewett theorem (k=3)")]#text(": ")#mi("c_n = o(3^n)")#text(", i.e. ")#mi("\\lim_{n \\to \\infty} c_n/3^n = 0")#text(".")
]

#text("This theorem implies several other important results, most notably Roth’s theorem on length three progressions (in an arbitrary abelian group!) and also the corners theorem of Ajtai and Szemeredi (again in an arbitrary abelian group).")

#text("Here are some of the questions we are initially exploring in this thread (and which I will comment further on below the fold):")

#enum(start: 1, 
[#text("What are the best upper and lower bounds for ")#mi("c_n")#text(" for small n? Currently we know ")#mi("c_0=1, c_1=2, c_2=6, c_3=18, c_4=52")#text(", with some partial results for higher n. We also have some relationships between different ")#mi("c_n")#text(".")],
[#text("What do extremal or near-extremal sets (i.e. line-free sets with cardinality close to ")#mi("c_n")#text(") look like?")],
[#text("What are some good constructions of line-free sets that lead to asymptotic lower bounds on ")#mi("c_n")#text("? The best asymptotic lower bound we have currently is ")#mi("c_n \\geq 3^{n - O( \\sqrt{\\log n} )}")#text(".")],
[#text("Can these methods extend to other related problems, such as the Moser cube problem or the capset problem?")],
[#text("How feasible is it to extend the existing combinatorial proofs of Roth’s theorem (or the corners theorem), in particular the arguments of Szemeredi, to the Density Hales-Jewett theorem?")]
)

#text("But I imagine that further threads might develop in the course of the discussion.")

#text("As with the rest of the project, this is supposed to be an open collaboration: please feel free to pose a question or a comment, even if (or especially if) it is just barely non-trivial. (For more on the “rules of the game”, see ")#link("http://gowers.wordpress.com/2009/02/01/questions-of-procedure/")[#text("this post")]#text(".)")

#metadata(none) <tao-ed6b50afbd9872a28f9c>

#heading(level: 1)[#text("— I. ")#mi("c_n")#text(" for small n —")]

#text("Because the Cartesian product of two line-free sets is line-free, we have a lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("c_{n+m} \\geq c_n c_m")]]

#text("for all ")#mi("n,m \\geq 1")#text(", although this seems to be an inferior bound in practice.")

#text("There is a trivial bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("c_{n+1} \\leq 3 c_n")]]

#text("which comes from the observation that any line-free subset of ")#mi("{}[3]^{n+1}")#text(" can be split into three slices, each of which is essentially a line-free subset of ")#mi("{}[3]^n")#text(". In particular, since ")#mi("c_1 = 2")#text(", we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("c_n \\leq 2 \\times 3^{n-1}")]]

#text("for ")#mi("n \\geq 1")#text(".")

#text("If we identify ")#mi("{}[3] = \\{1,2,3\\}")#text(" with ")#mi("{\\Bbb Z}/3{\\Bbb Z}")#text(" and consider the set")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("D_n := \\{ (x_1,\\ldots,x_n) \\in {\\Bbb Z}/3{\\Bbb Z}: x_1+\\ldots+x_n \\neq 0 \\text{ mod } 3 \\},")]]

#text("thus ")#tao-math("\\left|D_n\\right| = 2 \\times 3^{n-1}", block: false)#text(". Observe that a combinatorial line with a,b,c,k 1s, 2s, 3s, and wildcards respectively lies in ")#mi("D_n")#text(" if and only if k is a multiple of 3, and a is not equal to b mod 3. In particular, ")#mi("D_n")#text(" is line-free for ")#mi("n = 1,2,3")#text(", thus matching the upper bound (3) and concluding that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("c_1 = 2; c_2 = 6; c_3 = 18.")]]

#text("For n=4, the only combinatorial lines remaining in ")#mi("D_4")#text(" are ")#mi("1xxx, 2xxx")#text(" and their permutations. Thus (as observed in ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1776")[#text("Neylon.83")]#text(") the set ")#mi("D_4 \\backslash \\{1111, 2222\\}")#text(" is line-free, leading to the lower bound ")#mi("c_4 \\geq 52")#text(".")

#text("This bound was complemented with the lower bound ")#mi("c_4 \\leq 52")#text(" in ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1790")[#text("Jakobsen.90")]#text(". Thus ")#mi("c_4 = 52")#text(".")

#text("For ")#mi("c_5")#text(", the best lower bound currently is ")#mi("c_5 \\geq 145")#text(" (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1776")[#text("Neylon.83")]#text(") and ")#mi("c_5 \\leq 3c_4 = 156")#text(".")

#text("No attempt at getting reasonable bounds for ")#mi("c_6, c_7")#text(", etc. appears in the previous threads.")

#strong[#text("Question I.A:")]#text(" Can we improve the upper and lower bounds on ")#mi("c_5, c_6, c_7")#text("?")

#strong[#text("Question I.B:")]#text(" Is there some reasonably efficient way to automate this process?")

#strong[#text("Question I.C:")]#text(" What do the extremal line-free sets (sets of size close to ")#mi("c_n")#text(") look like?")

#text("At some point we should submit this sequence to the OEIS.")

#heading(level: 1)[#text("— II. Lower bounds on ")#mi("c_n")#text(" for large n —")]

#text("For any integers a,b,c adding up to n, let ")#mi("\\Gamma_{a,b,c} \\subset [3]^n")#text(" be the set of all strings with a 1s, b 2s, and c 3s. Observe that if ")#mi("B")#text(" is any set of triples (a,b,c) that avoids equilateral triangles ")#mi("(a+r,b,c), (a,b+r,c), (a,b,c+r)")#text(" for ")#mi("r > 0")#text(", then the set ")#mi("\\Gamma_B := \\bigcup_{(a,b,c) \\in B} \\Gamma_{a,b,c}")#text(" is line-free. In particular, if we choose B to be the set of all triples ")#mi("(a,b,c)")#text(" such that a+2b lies in a set free of length three arithmetic progressions (e.g. a Behrend set), then ")#mi("\\Gamma_B")#text(" is line-free. This seems to give a lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("c_n \\geq 3^{n - O(\\sqrt{\\log n})}.")]]

#strong[#text("Question II.A:")]#text(" Using the ")#link("http://arxiv.org/abs/0801.4310")[#text("Elkin bound")]#text(" on Behrend sets, what is the precise lower bound one gets? (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1715")[#text("Solymosi.46.5")]#text(" notes that we should restrict the Behrend set to scale ")#mi("\\sqrt{n}")#text(" rather than n).")

#strong[#text("Question II.B:")]#text(" What does one get for higher k than 3? Presumably one would use the O’Bryant bound (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1842")[#text("O’Bryant.126")]#text(").")

#strong[#text("Question II.C:")]#text(" Do the examples from Section I extend to give competitive lower bounds for large n?")

#strong[#text("Question II.D:")]#text(" Are there better ways to avoid triangles or corners in two dimensions than simply lifting up the Behrend example from one dimension?")

#heading(level: 1)[#text("— III. Miscellanous facts about ")#mi("c_n")#text(" —")]

#text("Using the colouring Hales-Jewett theorem, one can show that for every m, one has ")#mi("c_n < 3^{n-m} c_m")#text(" for sufficiently large m, improving (2) very slightly; see (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1779")[#text("Tao.85")]#text(").")

#strong[#text("Question III.A:")]#text(" Anything else we can say about the ")#mi("c_n")#text("? For instance, is there a relation to Hales-Jewett numbers HJ(3,r) (defined as the first n such that every r-colouring of ")#mi("{}[3]^n")#text(" contains a monochromatic combinatorial line?)")

#text("Note: as pointed out in ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1713")[#text("Gasarch.45.5")]#text(", ")#link("http://www.math.ucsd.edu/~etressle/hj32.pdf")[#text("Hindman and Tressler")]#text(" have recently established that ")#mi("HJ(3,2)=4")#text(", ")#mi("HJ(3,3) > 6")#text(", and ")#mi("HJ(4,2) > 6")#text(".")

#heading(level: 1)[#text("— IV. Related problems —")]

#text("Let ")#mi("c^{\\prime}_n")#text(" denote the largest subset of ")#mi("{}[3]^n")#text(" which does not contain any geometric line (which is the same as a combinatorial line, but has a second wildcard y which goes from 3 to 1 whilst x goes from 1 to 3, e.g. xx2yy gives the geometric line ")#mi("11233, 22222, 33211")#text("). The Moser cube problem is to understand the behaviour of ")#mi("c^{\\prime}_n")#text(". The first few values are (see ")#link("http://www.research.att.com/~njas/sequences/A003142")[#text("OEIS A003142")]#text("):")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("c^{\\prime}_0 = 1; c^{\\prime}_1 = 2; c^{\\prime}_2 = 6; c^{\\prime}_3 = 16; c^{\\prime}_4 = 43.")]]

#text("It is clear that ")#mi("c^{\\prime}_n \\leq c_n")#text(".")

#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1707")[#text("Elsholtz.43")]#text(" proposed modifying the construction of (6) to give a similar lower bound on ")#mi("c^{\\prime}_n")#text(", but a difficulty was found in ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1719")[#text("Solymosi.48")]#text(". Currently, the best known asymptotic bounds for ")#mi("c^{\\prime}_n")#text(" are")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("3^n / \\sqrt{n} \\ll c^{\\prime}_n \\ll o(3^n)")]]

#strong[#text("Question IV.A")]#text(". Can we improve the lower bound in (8)?")

#strong[#text("Question IV.B.")]#text(" Can we get good bounds on ")#mi("c^{\\prime}_5, c^{\\prime}_6")#text("?")

#text("Define ")#mi("c^{\\prime\\prime}_n")#text(" to be the largest cardinality of a subset of ")#mi("{}[3]^n")#text(" which contains no algebraic lines, defined as a triple ")#mi("\\{ x, x+r, x+2r\\}")#text(" where ")#mi("x, r \\in ({\\Bbb Z}/3{\\Bbb Z})^n \\equiv [3]^n")#text("; such sets are known as capsets. Clearly ")#mi("c^{\\prime\\prime}_n \\leq c^{\\prime}_n \\leq c_n")#text(". As noted ")#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")[#text("my previous blog post")]#text(", the best asymptotic bounds are")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(2.2174\\ldots)^n \\leq c^{\\prime\\prime}_n \\ll 3^n/n")]]

#strong[#text("Question IV.C. ")]#text(" Can we improve on these bounds in any way?")

#strong[#text("Question IV.D.")]#text(" What are the first few values of ")#mi("c^{\\prime\\prime}_n")#text("? Brute force calculation reveals ")#mi("c^{\\prime\\prime}_0 = 1, c^{\\prime\\prime}_1 = 2, c^{\\prime\\prime}_2 = 4")#text(". (Presumably this sequence is also in the OEIS.)")

#text("[")#emph[#text("Update")]#text(", Feb 7: I will now maintain a running table of the current “world records” for ")#mi("c_n, c^{\\prime}_n, c^{\\prime\\prime}_n")#text(" for small n, formed by combining all the bounds already mentioned in this post and comments.]")

#text("[")#emph[#text("Update")]#text(", Feb 8: A more complete (and up-to-date) spreadsheet can now be found ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")[#text("here")]#text(".]")

#table(columns: 4, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("n")],
table.cell(colspan: 1, rowspan: 1)[#mi("c_n")],
table.cell(colspan: 1, rowspan: 1)[#mi("c^{\\prime}_n")],
table.cell(colspan: 1, rowspan: 1)[#mi("c^{\\prime\\prime}_n")],
table.cell(colspan: 1, rowspan: 1)[#text("0")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("1")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("2")],
table.cell(colspan: 1, rowspan: 1)[#text("6")],
table.cell(colspan: 1, rowspan: 1)[#text("6")],
table.cell(colspan: 1, rowspan: 1)[#text("4")],
table.cell(colspan: 1, rowspan: 1)[#text("3")],
table.cell(colspan: 1, rowspan: 1)[#text("18")],
table.cell(colspan: 1, rowspan: 1)[#text("16")],
table.cell(colspan: 1, rowspan: 1)[#link("http://www.math.rutgers.edu/~maclagan/papers/set.pdf")[#text("9")]],
table.cell(colspan: 1, rowspan: 1)[#text("4")],
table.cell(colspan: 1, rowspan: 1)[#text("52")],
table.cell(colspan: 1, rowspan: 1)[#text("43")],
table.cell(colspan: 1, rowspan: 1)[#link("http://www.math.rutgers.edu/~maclagan/papers/set.pdf")[#text("20")]],
table.cell(colspan: 1, rowspan: 1)[#text("5")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35537")[#text("150")]#text(",")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35681")[#text("154")]#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("96")#text(",")#text("129")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#link("http://www.math.rutgers.edu/~maclagan/papers/set.pdf")[#text("45")]],
table.cell(colspan: 1, rowspan: 1)[#text("6")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35537")[#text("450")]#text(",")#text("462")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("258")#text(",")#text("387")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#link("http://www.springerlink.com/content/h003577g11112308/")[#text("112")]#link("http://www.math.rutgers.edu/~maclagan/papers/set.pdf")[#text("http://www.math.rutgers.edu/~maclagan/papers/set.pdf")]],
table.cell(colspan: 1, rowspan: 1)[#text("7")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35585")[#text("1302")]#text(",")#text("1386")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("688")#text(",")#text("1161")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("http://www.springerlink.com/content/m55136x765161240/")[#text("236")]#text(",")#text("292")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("8")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35585")[#text("3780")]#text(",")#text("4158")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("1849")#text(",")#text("3483")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("472")#text(",")#text("773")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("9")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35495")[#text("11340")]#text(",")#text("12474")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("4128")#text(",")#text("10449")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("1008")#text(",")#text("2075")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("10")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35604")[#text("32864")]#text(",")#text("37422")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("11094")#text(",")#text("31347")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("2240")#text(",")#text("5632")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("11")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("95964")#text(",")#text("112266")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("29584")#text(",")#text("94041")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("5040")#text(",")#text("15425")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("12")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35597")[#text("287892")]#text(",")#text("336798")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("79507")#text(",")#text("282123")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("12544")#text(",")#text("42569")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("13")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35604")[#text("837850")]#text(",")#text("1010394")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("175504")#text(",")#text("846369")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("26432")#text(",")#text("118237")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("14")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("2458950")#text(",")#text("3031182")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("477042")#text(",")#text("2539107")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("52864")#text(",")#text("330222")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("15")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/#comment-35593")[#text("7376850")]#text(",")#text("9093946")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("1272112")#text(",")#text("7617321")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#text("[")#text("112896")#text(",")#text("926687")#text("]")],
table.cell(colspan: 1, rowspan: 1)[#mi("\\to \\infty")],
table.cell(colspan: 1, rowspan: 1)[#mi("{}[3^{n-O(\\sqrt{\\log n})}, o(3^n)]")],
table.cell(colspan: 1, rowspan: 1)[#mi("{}[\\Omega(\\frac{3^n}{\\sqrt{n}}), o(3^n)]")],
table.cell(colspan: 1, rowspan: 1)[#mi("{}[(2.21\\ldots)^n, O(\\frac{3^n}{n})]")]
)

#list(
[#text("green")#text(" – obtained via the inequality (1)")],
[#text("orange")#text(" – obtained via the inequality (2)")],
[#text("lavender")#text(" – uses ")#link("http://www.mathi.uni-heidelberg.de/~yves/Papers/ABound.pdf")[#text("the inequality")]#text(" ")#mi("c^{\\prime\\prime}_n \\leq (3c^{\\prime\\prime}_{n-1}+1)/(1 + c^{\\prime\\prime}_{n-1}/3^{n-1})")]
)

#heading(level: 1)[#text("— V. Szemeredi’s proof of Roth’s theorem —")]

#text("Szemeredi provided a short proof of Roth’s theorem by purely combinatorial means, and also famously proved the full case of Szemeredi’s theorem by much more intricate combinatorial argument. Both arguments are based on the density increment method. In the setting of ")#mi("{}[3]^n")#text(", the density increment method revolves around the critical density ")#mi("\\alpha = \\lim_{n \\to \\infty} c_n / 3^n")#text(", which exists by (2); the density Hales-Jewett theorem is precisely the statement that ")#mi("\\alpha")#text(" vanishes, so suppose for contradiction that ")#mi("\\alpha")#text(" is positive.")

#text("Then one can find a line-free set ")#mi("A \\subset [3]^n")#text(" of density ")#mi("\\alpha + o_{n \\to \\infty}(1)")#text(" such that A has density at most ")#mi("\\alpha + o_{m \\to \\infty}(1)")#text(" for every m-dimensional subspace of ")#mi("{}[3]^n")#text(" (and one can complement this lower bound with an upper bound for “most” subspaces, see ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1803")[#text("Tao.100")]#text("). One can also regularise the density on other sets than subspaces, see ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1834")[#text("Tao.121")]#text("). So, basically, the moment one gets a significant density increment on a non-trivial subspace, one is done (see ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1833")[#text("Tao.120")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1835")[#text("O’Donnell.122")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1843")[#text("Tao.127")]#text(").")

#text("Szemeredi’s proof of Roth’s theorem proceeds by first showing that a dense set A contains a large cube Q, and thus (if it is free of algebraic lines) must completely avoid the set ")#mi("2.Q - A")#text(". This set contains (most of) lots of parallel subspaces and so squeezes A to have higher density on some other subspace, closing the argument. (See ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1781")[#text("Tao.86")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1831")[#text("Tao.118")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1854")[#text("Tao.131")]#text(")")

#strong[#text("Question V.A")]#text(": Is there some way to adapt this argument to density Hales-Jewett, or at least to the corners problem? The sparsity of lines is a serious difficulty, see ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1831")[#text("Tao.118")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1859")[#text("Solymosi.135")]#text(".")

#text("One can at least generate lots of cubes inside A without difficulty (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1806")[#text("Tao.102")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1859")[#text("Solymosi.135")]#text("), lots of combinatorial lines with two elements inside A (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1853")[#text("Tao.130")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1856")[#text("Bukh.132")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1857")[#text("O’Donnell.133")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1859")[#text("Solymosi.135")]#text("), and many unorganised subspaces in the complement of A (")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1831")[#text("Tao.118")]#text(", ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1859")[#text("Solymosi.135")]#text("), but this does not seem to be enough as yet.")

#strong[#text("Question V.B:")]#text(" What about using the techniques from Szemeredi’s big paper on Szemeredi’s theorem? (The immediate issue is that there is a key point where one needs to regularise a graph, and the relevant graph in HJ or even for corners is far too sparse; I’ll try to clarify this at some point.)")

#heading(level: 1)[#text("— A note on comments —")]

#text("As in the first thread, please number your comments (starting with 200, then 201, etc.) and provide a title, to assist with following the comments. (Presumably, in future projects of this type, we will use a platform that allows for comment threading; see ")#link("http://gowers.wordpress.com/2009/02/04/quick-question/")[#text("this post")]#text(" for further discussion.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (101)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35662")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("241. Upper bound for ")#mi("c_5 < 156")

#text("This proof is along the lines of Sune.90")#linebreak()#text(" Sune shows there is just one way to place 18 points in a cube,")#linebreak()#text(" and that at most 52 points fit in ")#mi("3^4")

#text("Suppose 156 points may be chosen in ")#mi("3^5")#text(".")#linebreak()#text(" There must be 52 points in each slice of ")#mi("3^4")

#text("Divide ")#mi("3^5")#text(" into nine cubes. There are 17 or 18 points in each cube, and one cube in each row and column has 18 points. For example")

#text("17, 17, 18")#linebreak()#text(" 18, 17, 17")#linebreak()#text(" 17, 18, 17")

#text("Cut the cubes further, into squares. The 18-point cubes must cut into three six-point slices x y and z, but the 17-point squares have more variation")

#text("pqr, stu, xyz")#linebreak()#text(" xyz, abc, def")#linebreak()#text(" ghk, xyz, lmn")

#text("Take the three cubes in the top row, and slice them along a different axis so they are psx, qty and ruz.")#linebreak()#text(" One of these cubes has 18 points, and so is xyz; so r=x and u=y.")

#text("Similar logic in second column gives u=x and c=y. So there is a contradiction.")

#text("There are four other ways to place the 17-point and 18-point cubes, but they all lead to contradictions.")

#text("So 156 points can’t be placed in ")#mi("3^5")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("242. ")#mi("c_5 < 156")

#text("Michael: Nice! I’ve updated the spreadsheet and the table accordingly. Computing ")#mi("c_5")#text(" exactly may well be within reach now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35672")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("3^5. ")#mi("c_5 < 155")

#text("The same proof works for 155 points, except for the case")

#text("17 17 18")#linebreak()#text(" 17 17 17")#linebreak()#text(" 18 17 17")

#text("and permutations of that. I can assume that, when sliced along")#linebreak()#text(" any axis, each cube has at least 17 points.")

#text("Cut the cubes into slices as in Michael.240.")#linebreak()#text(" Some of the slices must be x,y or z, as shown there")

#text("pqx rsy xyz")#linebreak()#text(" tuy abc yde")#linebreak()#text(" xyz yfg zhk")

#text("When the pqx cube is cut into squares along any of its three axes,")#linebreak()#text(" it has an x slice in third position. That forces the placement of")#linebreak()#text(" thirteen points in the cube, and needs four points to be")#linebreak()#text(" placed in the remaining 2x2x2 sub-cube. It turns out that pqx is either")#linebreak()#text(" yz’x or y’zx, where z’ is a z slice with one point removed.")

#text("If pqx = yz’x when sliced along one axis, then it is yz’x when sliced")#linebreak()#text(" along all three axes. Then the cube paz, from reslicing the diagonal,")#linebreak()#text(" is yaz along all three axes, which is impossible.")

#text("So pqx = y’zx when sliced along each axis, and rsy=tuy=zx’y")

#text("For the same reasons, zhk = zxy’")

#text("So cube qbh = zbx along all three axes, which is impossible.")

#text("I think this contradiction completes the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35674")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("244. ")#mi("c_5 < 155")

#text("In 243., I made an error in the paragraph that begins “If pqx = yz’x”.")#linebreak()#text(" I just need the fact that a can’t have five points if yaz has no lines.")#linebreak()#text(" Also, at the end, b can’t have five points if zbx has no lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35681")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("245. ")#mi("c_5 < 155")

#text("Recall that there is just one pattern to fit 18 points in a cube;")#linebreak()#text(" the three square slices of this pattern (along any axis) are x, y and z.")

#text("To fit 17 points in a cube, the only way is to remove one point from")#linebreak()#text(" either xyz, yzx or zxy.")

#text("This makes the proof in 243. easier because the slices are formed")#linebreak()#text(" by removing points from")

#text("yzx zxy xyz")#linebreak()#text(" zxy xyz yzx")#linebreak()#text(" xyz yzx zxy")

#text("Now the major diagonal of the cube is yyy, and six points must be removed from that. Four of the off-diagonal cubes must also lose points. That leaves 152 points, which contradicts the 155 points we started with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("246. ")#mi("c_5 < 155")

#text("Great! I’ve updated the table again (I see that the spreadsheet was already updated, excellent).")

#text("It would be interesting to see what the 150 lower bound example looks like in xyz notation, this may clarify what needs to be done to narrow the upper and lower bounds further.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35689")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("247. Let us look at the set of 150")#linebreak()#text(" points which form the lower")#linebreak()#text(" bound for c_5")#linebreak()#text(" It would consist of all points whose sum is not zero mod 3 with")#linebreak()#text(" all points with 5 coordinates equal to 1 or or all 5 points equal to 2 removed")#linebreak()#text(" combined with removal of all points")#linebreak()#text(" with one coordinate equal to 3 and the rest equal to")#linebreak()#text(" 1 and the removal of all points with one coordinate")#linebreak()#text(" equal to 3 and the rest equal to 2")

#text("This gives the following")#linebreak()#text(" 17 17 18")#linebreak()#text(" 18 14 17")#linebreak()#text(" 14 18 17")

#text("which gives let u equal x with one point removed")#linebreak()#text(" v = y with one point removed")#linebreak()#text(" and t =z with one point removed")#linebreak()#text(" uyz xvz xyz")#linebreak()#text(" xyz ??? xvz")#linebreak()#text(" ??? xyz uyz")#linebreak()#text(" Note we have chosen three coordinates to be within")#linebreak()#text(" the cube and two other to determine")#linebreak()#text(" the position of the cube within the square")#linebreak()#text(" coordinates go from")#linebreak()#text(" one to three from left to right")#linebreak()#text(" and one to three upwards")#linebreak()#text(" xyz are squares determined")#linebreak()#text(" by one of the coordinates of the")#linebreak()#text(" cube. x (or any letter in the leftmost position)")#linebreak()#text(" corresponds to the")#linebreak()#text(" the square with coordinate equal")#linebreak()#text(" to one the letters in the next two positions correspond")#linebreak()#text(" to the squares with the coordinate equal to 2 and 3.")#linebreak()#text(" The question marks are for the cubes with 14 points. Are there problems with")#linebreak()#text(" having all the cubes having a value that is close to 18?")#linebreak()#text(" Is there a set of points having no combinatorial lines")#linebreak()#text(" with 5 coordinates varying from 1 to 3 such")#linebreak()#text(" that all of the cubes have value 17 or 18?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("248. Conventions for xyz notation")

#text("I think it will be helpful to fix the conventions for the xyz notation. If we use Cartesian coordinates")

#text("13 23 33")#linebreak()#text(" 12 22 32")#linebreak()#text(" 11 21 31")

#text("to parameterise ")#mi("{}[3]^2")#text(", then (if I understand Michael’s posts correctly), x is the six-element set")

#text("* _ *")#linebreak()#text(" * * _")#linebreak()#text(" _ * *")

#text("(where * denotes elements of x and _ denotes non-elements), y is the six-element set")

#text("_ * *")#linebreak()#text(" * _ *")#linebreak()#text(" * * _")

#text("and z is the six-element set")

#text("* * _")#linebreak()#text(" _ * *")#linebreak()#text(" * _ *")

#text("and xyz is the unique 18-element line-free set in ")#mi("{}[3]^3")#text(" (with the convention that abc is the set whose first slice is a, second slice is b, and third slice is c).")

#text("Michael, does this match your conventions?")

#text("Also, when you say “to fit 17 points on the cube, the only way is to remove one point from xyz, yzx, or zxy”, are there some restrictions on what point one can remove? Clearly one can remove any point one wishes from xyz, but there seems to be more constraints for yzx and zxy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("249. A hyper-optimistic conjecture from 400-499")

#text("Over at the ")#link("http://gowers.wordpress.com/2009/02/08/dhj-quasirandomness-and-obstructions-to-uniformity")[#text("400-499 thread")]#text(", ")#link("http://gowers.wordpress.com/2009/02/08/dhj-quasirandomness-and-obstructions-to-uniformity/#comment-2114")[#text("Gil Kalai.455")]#text(" and ")#link("http://gowers.wordpress.com/2009/02/08/dhj-quasirandomness-and-obstructions-to-uniformity/#comment-2119")[#text("Tim Gowers.459")]#text(" have proposed a “hyper-optimistic” conjecture, and asked whether it could be falsified using the examples from this thread. Let me rephrase it as follows. Given a set ")#mi("A \\subset {}[3]^n")#text(", define the ")#emph[#text("weighted size")]#text(" ")#mi("\\mu(A)")#text(" of A by the formula")

#tao-math("\\mu(A) := \\sum_{a+b+c=n} \\left|A \\cap \\Gamma_{a,b,c}\\right|/\\left|\\Gamma_{a,b,c}\\right|", block: false)

#text("thus each slice ")#mi("\\Gamma_{a,b,c}")#text(" has weighted size 1 (and we have been referring to ")#mi("\\mu")#text(" as “slices-equal measure” for this reason), and the whole cube ")#mi("{}[3]^n")#text(" has weighted size equal to the ")#mi("(n+1)^{th}")#text(" triangular number, ")#mi("\\frac{(n+1)(n+2)}{2}")#text(".")

#text("Example: in ")#mi("{}[3]^2")#text(", the diagonal points 11, 22, 33 each have weighted size 1, whereas the other six off-diagonal points have weighted size 1/2. The total weighted size of ")#mi("{}[3]^2")#text(" is 6.")

#text("Let ")#mi("c^\\mu_n")#text(" be the largest ")#emph[#text("weighted")]#text(" size of a line-free set. For instance, ")#mi("c^\\mu_0 = 1")#text(", ")#mi("c^\\mu_1 = 2")#text(", and ")#mi("c^\\mu_2 = 4")#text(".")

#text("As in the unweighted case, every time we find a subset B of the grid ")#mi("\\Delta_n := \\{ (a,b,c): a+b+c=n\\}")#text(" without equilateral triangles, it gives a line-free set ")#mi("\\Gamma_B := \\bigcup_{(a,b,c) \\in B} \\Gamma_{a,b,c}")#text(". The weighted size of this set is precisely the cardinality of B. Thus we have the lower bound ")#mi("c^\\mu_n \\geq \\overline{c}^\\mu_n")#text(", where ")#mi("\\overline{c}^\\mu_n")#text(" is the largest size of equilateral triangles in ")#mi("\\Delta_n")#text(".")

#strong[#text("Hyper-optimistic conjecture:")]#text(" We in fact have ")#mi("c^\\mu_n = \\overline{c}^\\mu_n")#text(". In other words, to get the optimal weighted size for a line-free set, one should take a set which is a union of slices ")#mi("\\Gamma_{a,b,c}")#text(".")

#text("This conjecture, if true, will imply the DHJ theorem (see the 400-499 discussion for details). Note also that all our best lower bounds for the unweighted problem to date have been unions of slices. Also, the k=2 analogue of the conjecture is true, and is known as the ")#link("http://en.wikipedia.org/wiki/Lubell-Yamamoto-Meshalkin_inequality")[#text("LYM inequality")]#text(" (in fact, for k=2 we have ")#mi("c^\\mu_n = \\overline{c}^\\mu_n = 1")#text(" for all n).")

#text("If the conjecture is false, then perhaps this will be visible by computing upper and lower bounds for ")#mi("c^\\mu_n, \\overline{c}^\\mu_n")#text(" for small n. By hand I can check that ")#mi("\\overline{c}^\\mu_n = c^\\mu_n")#text(" for n=0,1,2… but perhaps with all the above progress we can also get good bounds for n=3,4,5?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35694")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("250. A hyper-optimistic conjecture")

#text("Could someone clarify the definition of ")#mi("\\bar c_n^\\mu")#text("?")

#text("As far as generalizations of LYM go, let ")#tao-math("d_{abc} = \\left|A\\cap \\Gamma_{a,b,c}\\right|", block: false)#text(", and suppose ")#tao-math("\\sum_{a+b+c=n} d_{abc}/\\left|\\Gamma_{a,b,c}\\right| \\le f(n)", block: false)#text(" for all line-free ")#mi("A")#text(". Then Michael’s examples seem to suggest ")#mi("f(n)")#text(" grows quickly – as opposed to ")#mi("f(n) = 1")#text(" in LYM – so, intuitively, how do we hope for something like LYM?")

#text("I don’t think this is exactly what’s needed, but we do have ")#mi("\\sum_{a+b+c=n} d_{abc}p_{abc} \\le 2")#text(" where ")#mi("p_{abc} = (2^a+2^b+2^c-3)/(4^n-3^n)")#text(" is the percent of lines passing through any single element of ")#mi("\\Gamma_{a,b,c}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("251. A hyper-optimistic conjecture")

#text("One can define ")#mi("\\overline{c}^\\mu_n")#text(" in two equivalent ways. One of them is that it is the largest weighted size ")#mi("\\mu(A)")#text(" of a line-free set ")#mi("A \\subset [3]^n")#text(" which is the union of slices ")#mi("\\Gamma_{a,b,c}")#text(". (This is in contrast to ")#mi("c^\\mu_n")#text(", which is the largest weighted size of ")#emph[#text("any")]#text(" line-free set, not necessarily the union of slices.)")

#text("Another equivalent definition is that ")#mi("\\overline{c}^\\mu_n")#text(" is the largest subset of the triangular grid ")#mi("\\Delta_n := \\{ (a,b,c) \\in {\\Bbb Z}_+^3: a+b+c=n \\}")#text(" which contain no equilateral triangles. For instance, by deleting the two points (0,0,2) and (1,1,0) from ")#mi("\\Delta_3")#text(" one removes all triangles, whereas removing one point is not enough, and so ")#mi("\\overline{c}^\\mu_2 = 4")#text(".")

#text("As for your second question, I don’t think we have yet a strategy for this, but one could imagine some sort of extremal combinatorics argument by showing that a line-free set which is not a union of slices can be “improved” to increase its weighted size, without losing the line-free property. Showing this rigorously, though, would be, well, hyper-optimistic.")

#text("(Incidentally, what you call f(n) would be what I would call an upper bound for ")#mi("c^\\mu_n")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35705")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("252. Hyper-optimist conjecture")

#text("Am I understanding this right?")

#text("Minimal deletion for ")#mi("\\Delta_3")#text(" removes (0,3,0) (0,2,1) (2,1,0) (1,0,2), leaving 6 points. So ")#mi("\\overline{c}^\\mu_3=6")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35707")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("253.")

#text("Well, that certainly makes the set triangle-free, so ")#mi("\\overline{c}^\\mu_3 \\geq 6")#text(". If you know that you cannot make ")#mi("\\Delta_3")#text(" triangle-free by removing only three points, then yes, ")#mi("\\overline{c}^\\mu_3")#text(" would equal 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35709")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("254. Proof ")#mi("\\Delta_3")#text(" cannot be triangle free removing only 3 points")

#text("Yes, with only three removals each of these (non-overlapping) triangles must have one removal:")#linebreak()#text(" set A: (0,3,0) (0,2,1) (1,2,0)")#linebreak()#text(" set B: (0,1,2) (0,0,3) (1,0,2)")#linebreak()#text(" set C: (2,1,0) (2,0,1) (3,0,0)")

#text("Consider choices from set A:")#linebreak()#text(" (0,3,0) leaves triangle (0,2,1) (1,2,0) (1,1,1)")#linebreak()#text(" (0,2,1) forces a second removal at (2,1,0) [otherwise there is triangle at (1,2,0) (1,1,1) (2,1,0)] but then none of the choices for third removal work")#linebreak()#text(" (1,2,0) is symmetrical with (0,2,1)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35712")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("255.")

#text("Krystal.247: I think my 245 shows that, if all the cubes")#linebreak()#text(" have 17 or 18 points, then you have to delete ten points from")#linebreak()#text(" a full 9×18 pattern of xs, ys and zs. That leaves 152 points,")#linebreak()#text(" which is less than 9*17. So at least one cube has to have")#linebreak()#text(" 16 or fewer points.")

#text("Another pattern of 150 points is this: Take the 450 points")#linebreak()#text(" in ")#mi("{}[3]^6")#text(" which are ")#mi("(1,2,3), (0,2,4)")#text(" and permutations,")#linebreak()#text(" then select the 150 whose final coordinate is 1. That gives")#linebreak()#text(" this many points in each cube:")

#text("17 18 17")#linebreak()#text(" 17 17 18")#linebreak()#text(" 12 17 17")

#text("Terry.248: Yes, that matches what I meant by x,y and z;")#linebreak()#text(" yzx and zxy have a full line on the cube’s major diagonal")#linebreak()#text(" so you have to remove one of those three points to leave")#linebreak()#text(" a valid seventeen points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35718")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("256. Hyper-optimist conjecture")

#text("The ")#mi("\\overline{c}^\\mu_3")#text(" case was originally proposed as a puzzle by Kobon Fujimura (who is best known for <a href=”")#link("http://mathworld.wolfram.com/KobonTriangle.html")[#text("Kobon Triangles")]#text(").")

#text("I have been searching the recreational mathematics literature for any other mention of our problem but I haven’t found a reference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35721")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("(Meta) Coin puzzles")

#text("Fujimura’s version of ")#mi("\\overline{c}^\\mu_3")#text(" is simply given a pyramid of 10 coins, what is the smallest number you need to remove so there are no equilateral triangles?")

#text("The most common type of coin puzzle (which goes back to ")#link("http://en.wikipedia.org/wiki/Henry_Dudeney")[#text("Dudeney")]#text(") involves changing one configuration of coins into another with a certain number of moves. For example, invert a pyramid of 10 coins in the smallest number of moves.")

#link("http://arxiv.org/PS_cache/cs/pdf/0204/0204002v1.pdf")[#text("This article")]#text(" from the (highly recommended book) ")#link("http://books.google.com/books?id=cYB-ra2T8i4C")[#emph[#text("Games of No Chance")]]#text(" analyzes this type of puzzle in detail.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35728")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("257. ")#mi("\\overline{c}^\\mu_n")

#mi("\\overline{c}^\\mu_4=9")#text(":")#linebreak()#text(" The set of all (a,b,c) in ")#mi("\\Delta_4")#text(" with exactly one of a,b,c =0, has 9 elements and doesn’t contain any equilateral triangles.")

#text("Let ")#mi("S\\subset \\Delta_4")#text(" be a set without equilateral triangles. If ")#mi("(0,0,4)\\in S")#text(", there can only be one of (0,x,4-x) and (x,0,4-x) in S for x=1,2,3,4. Thus there can only be 5 elements in S with a=0 or b=0. The set of element with a,b>0 is isomorph to ")#mi("\\Delta_2")#text(", so S can at most have 4 elements in this set. So ")#tao-math("\\left|S\\right|\\leq 4+5=9", block: false)#text(". Similar if S contain (0,4,0) or (4,0,0). So if ")#tao-math("\\left|S\\right| >9", block: false)#text(" S doesn’t contain any of these. Also, S can’t contain all of (0,1,3), (0,3,1), (2,1,1). Similar for (3,0,1), (1,0,3),(1,2,1) and (1,3,0), (3,1,0), (1,1,2). So now we have found 6 elements not in S, but ")#tao-math("\\left|\\Delta_4\\right|=15", block: false)#text(", so ")#mi("S\\leq 15-6=9")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35733")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("258. ")#mi("\\overline{c}^\\mu_n")

#mi("\\overline{c}^\\mu_5=12")#text(":")#linebreak()#text(" The set of all (a,b,c) in ")#mi("\\Delta_5")#text(" with exactly one of a,b,c=0 has 12 elements and doesn’t contain any equilateral triangles.")

#text("Let ")#mi("S\\subset \\Delta_5")#text(" be a set without equilateral triangles. If ")#mi("(0,0,5)\\in S")#text(", there can only be one of (0,x,5-x) and (x,0,5-x) in S for x=1,2,3,4,5. Thus there can only be 6 elements in S with a=0 or b=0. The set of element with a,b>0 is isomorph to ")#mi("\\Delta_3")#text(", so S can at most have 6 elements in this set. So ")#tao-math("\\left|S\\right|\\leq 6+6=12", block: false)#text(". Similar if S contain (0,5,0) or (5,0,0). So if ")#tao-math("\\left|S\\right| >12", block: false)#text(" S doesn’t contain any of these. S can only contain 2 point in each of the following equilateral triangles:")#linebreak()#text(" (3,1,1),(0,4,1),(0,1,4)")#linebreak()#text(" (4,1,0),(1,4,0),(1,1,3)")#linebreak()#text(" (4,0,1),(1,3,1),(1,0,4)")#linebreak()#text(" (1,2,2),(0,3,2),(0,2,3)")#linebreak()#text(" (3,2,0),(2,3,0),(2,2,1)")#linebreak()#text(" (3,0,2),(2,1,2),(2,0,3)")#linebreak()#text(" So now we have found 9 elements not in S, but ")#tao-math("\\left|\\Delta_5\\right|=21", block: false)#text(", so ")#mi("S\\leq 21-9=12")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35737")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("259 About the constant c”(n): the value of c”(6)=112 has been proved by")#linebreak()#text(" Aaron Potechin: Maximal caps in AG (6, 3)")#linebreak()#text(" Journal Designs, Codes and Cryptography, Volume 46, Number 3 / March, 2008")#linebreak()#text(" ")#link("http://www.springerlink.com/content/h003577g11112308/")[#text("http://www.springerlink.com/content/h003577g11112308/")]

#text("This gives a new set of slightly improved upper bounds: for n=7 to 15 as follows:")

#text("{7, 292}, {8, 773}, {9, 2075}, {10, 5632}, {11, 15425},")#linebreak()#text(" {12, 42569}, {13, 118237}, {14, 330222}, {15, 926687}")

#text("A discussion of the problem on caps, with plenty of references, can also")#linebreak()#text(" be found in:")#linebreak()#text(" Yves Edel, Christian Elsholtz, Alfred Geroldinger, Silke Kubertin, Laurence Rackham: Zero-sum problems in finite abelian groups and affine caps.")#linebreak()#text(" Quarterly Journal of Mathematics 58 (2007), 159-186.")#linebreak()#text(" ")#link("http://qjmath.oxfordjournals.org/cgi/content/abstract/58/2/159")[#text("http://qjmath.oxfordjournals.org/cgi/content/abstract/58/2/159")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35739")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("260. ")#mi("\\overline{c}^\\mu_n")

#text("Sune, could you give your explicit list for removals from ")#mi("\\overline{c}^\\mu_4")#text("? I am unable to reproduce a triangle-free configuration from your description.")

#text("For example, (4,0,0) (0,4,0) (0,0,4) (2,1,1) (1,1,2) (1,2,1) leaves the triangle (2,2,0) (0,2,2) (2,0,2).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("260. Updates to spreadsheet")

#text("I’ve updated the spreadsheet to take into account the above developments (in particular, adding entries for upper and lower bounds for ")#mi("c^\\mu_n")#text(" and ")#mi("\\overline{c}^\\mu_n")#text(". I’m using the trivial bounds")

#mi("\\overline{c}^\\mu_n \\leq \\overline{c}^\\mu_{n+1} \\leq \\overline{c}^\\mu_n + n+1")

#text("and")

#tao-math("\\overline{c}^\\mu_n \\leq c^\\mu_n \\leq \\left|\\Delta_n\\right| = \\frac{(n+1)(n+2)}{2}", block: false)

#text("but clearly we should be able to do better than these bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35743")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("261. Lower bound for ")#mi("\\overline{c}^\\mu_n")

#text("One easy lower bound is to note that one can always go triangle free by removing (n,0,0), the triangle (n-2,1,1) (0,n-1,1) (0,1,n-1), and all points on the edges of and inside the same triangle.")

#text("For example, with ")#mi("\\overline{c}^\\mu_4")#text(" remove (0,4,0), (1,2,1), (2,1,1), (1,1,2), (3,0,1), (2,0,2), and (1,0,3).")

#text("Therefore a lower bound would be ")#mi("\\frac{(n+1)(n+2)}{2}-1-\\frac{(n-1)(n)}{2}")#text(". (That is, the triangular number of n+1 with (n,0,0) removed and then the triangular number of n-1 removed, referring to the triangle (n-2,1,1) (0,n-1,1) (0,1,n-1).)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35749")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("262. Three solutions for ")#mi("c_4")

#text("There are exactly three solutions for 52 points in ")#mi("{}[3]^4")#linebreak()#text(" I use recent notation from ")#mi("c_5")#text(", x, y and z defined in Terry.248")

#text("x’ is x with one point removed; that point in ")#mi("{}[3]^4")#text(" is either 2222 or 3333. Likewise for y’ and z’")

#text("All three solutions are made from full $latex Gamma_{abc}")#linebreak()#text(" Each row is a different solution.")

#text("xyz yz’x zxy’")#linebreak()#text(" y’zx zx’y xyz")#linebreak()#text(" z’xy xyz yzx’")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35751")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("263. Finishing the calculations")

#text("I guess that’s what I get for typing and running — the bound at 261 is just 2n.")

#text("Also, 254 the proof can be much, much simpler: just note (3,0,0) or something symmetrical has to be removed, leaving 3 triangles which do not intersect, so 3 more removals are required.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35754")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("264. Lower bound for ")#mi("\\overline{c}^\\mu_n")

#text("Another lower bound is 3(n-1), as you keep most of all three sides of the triangle. Remove the corners and the inner triangle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35755")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("265. Lower bound for \\overline{c}^mu_n")

#text("Michael, I have a counterexample for that at 260.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35756")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("266. Wiki")

#text("We’ve started up a wiki for the polymath project at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")]

#text("I’ve put in a page for the proofs of the best bounds for c_n for small n at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")]

#text("The last few sections still need some work. Of course, everyone is invited to contribute. (For lengthy new computations, it may be best to put the details on the wiki and announce an abridged version here.)")

#text("At some point I’ll try to do something similar for ")#mi("\\overline{c}^\\mu_n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35759")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("266. Lower bound for ")#mi("\\overline{c}^\\mu_4")

#text("You can fit nine points in a 15-point triangle (n=4),")#linebreak()#text(" (013,022,031,103,202,301,130,220,310)")#linebreak()#text(" but the best result for ")#mi("c_4")#text(" only uses seven points.")#linebreak()#text(" (022,112,121,202,220,310,301)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35761")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("267. Lower bound for ")#mi("\\overline{c}^\\mu_n")

#text("Jason,")

#text("The triangle made up by (2,2,0),(2,0,2) and (0,2,2) is upside down.")#linebreak()#text(" It has a constant r=-2, so doesn’t apply to HJ sequences, which")#linebreak()#text(" use r as a number of columns.")

#text("I think you were right the first time, in 254., to do the long-winded proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("268. Wiki")

#text("Here is a page for ")#mi("\\overline{c}^\\mu_n")#text(", the computation of which I have dubbed “Fujimura’s problem”:")

#link("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")]

#text("Again, some cleanup is required to convert the blog comments into wiki format and to integrate the text smoothly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35766")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("269. Upper limit for ")#mi("\\overline{c}^\\mu_n")

#text("From looking at triangles in the lowest two rows, we have")

#mi("c_n \\leq c_{n-2} + \\frac{3n+2}{2}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35767")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("270. Hyper-optimistic")

#text("My point in 266. was, does that contradict the hyper-optimistic conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35774")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("271. Upper limit for Fujimura ( ")#mi("\\overline{c}^\\mu_n")#text(" )")

#text("There are ")#mi("\\binom{n+2}{3}")#text(" triangles, and each point is in n of them, so you must remove at least (n+2)(n+1)/6 points to remove all triangles.")#linebreak()#text(" So an upper limit for ")#mi("\\overline{c}^\\mu_n")#text(" is (n+1)(n+2)/3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("272. Hyper-optimistic")

#text("Dear Michael, it’s not clear yet whether this example violates the hyper-optimistic one, because the extremiser for the ")#mi("c_4")#text(" problem is not going to be the extremiser for the ")#mi("c^\\mu_4")#text(" problem. Indeed, the ")#mi("c_4")#text(" example, involving only seven of the slices, will have a weighted size of 7, whereas the ")#mi("\\overline{c}^\\mu_4")#text(" example has a weighted size of 9. To contradict the conjecture we would need to find a line-free set in ")#mi("{}[3]^4")#text(" with a weighted size exceeding 9.")

#text("Incidentally, I found the lower bound ")#mi("\\overline{c}^\\mu_{n+1} \\geq \\overline{c}^\\mu_n + 2")#text(" for ")#mi("n \\geq 2")#text(", since one can always take an extremiser in ")#mi("\\Delta_n")#text(", add a new edge to the triangular grid and put two points on it so that the triangle these two points generate doesn’t have the third point in the extremiser.")

#text("Given how this thread is filling up, I will probably start a fresh thread in a day or so. The wiki is very helpful in this regard, it reduces the extent to which I will have to summarise all the progress…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35783")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("272. When r<0")

#text("re: Peake.267, yes, I see now. I don’t remember r ever being defined as positive so I never thought about the case. (2,0,2) (2,2,0) (0,2,2) would be 1133, 1122, and 2233 which form no combinatorial lines.")

#text("That does bring the interesting question of: is there anything important about this problem relating to the cases of r<0? They might affect the “subcubes” from O’Donnell.422 which seem to be working with “partial” combinatorial lines. Calling the points a, b and c: a and b form a partial combinatorial line, b and c do, and a and c do, but a, b, and c do not form a line together. I believe this situation may be unique for the r<0 case.")

#text("Also, it means there are two variants of Fujimura, and while r<0 doesn’t apply to our problem it might be worth looking into as a side project (or at least noting it as a separate case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35784")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("273.")

#text("Michael.219: “This method gives a lower bound for c_99 that is bigger than 3^98.” and")#linebreak()#text(" Terry.467: “We also have an example of a subset of ")#mi("{}[3]^{99}")#text(" of density ")#mi(">1/3")#text(" that still has no combinatorial line.”")

#text("Then why is c_96/3^96=0.006155058319549. Shouldn’t it be >1/3?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35785")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("273b")

#text("The number I mentioned is L98 in the spreadsheet: Lower bound for ")#mi("c_96/3^96")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35790")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("The two examples we have for a lower bound for c_5 being 150 have cubes with 14 and 12 points is there an example with all cubes 16 or higher")#linebreak()#text(" and total 150 or higher? Or failing that all cubes 15 or higher and total 150 or higher?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35793")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("275. ")#mi("c_5=154")#text(": an example")

#text("Inspired by the previous discussion, I think I’ve found an example showing that ")#mi("c_5=154")#text(", I’d be grateful if someone could check it.")

#text("I’m using slightly different notations: instead of cartesian coordinates I’m using left-to-right ordering of words recursively to make visualisation easy. Namely, when ")#mi("n")#text(" is even increase upwards, when ")#mi("n")#text(" is odd increase righwards. In this way we can deal with 2-dimensional patterns only. For example ")#mi("{}[3]^3")#text(" looks like this:")#linebreak()#text(" 131 132 133 231 232 233 331 332 333")#linebreak()#text(" 121 122 123 221 222 223 321 322 323")#linebreak()#text(" 111 112 113 211 212 213 311 312 313")

#text("Given those notations here is what I think is a 154-element line-free pattern in ")#mi("{}[3]^5")#text(":")

#link("http://thomas1111.wordpress.com/files/2009/02/hj5a.png")[#image("../assets/049fa715f7e087193600dd1d74e8a011f71e14bb3f7449dc6346326389d17958-1d1b473bc86108a03fbc82aa30027d27f0d0f16356154b7ce4449fb57e343434.png", width: 90%)]

#text("The bottom-left black element is 11111 (not in the set), and so on. The two lone red elements are removed (Michael’s idea, here these are 12222 and 13333), then I found that removing the 6 other red elements leads to a line-free set (note that these 6 red elements are all on a super-diagonal). Total is thus ")#mi("(9\\times 6 -2)+(9\\times 6 -3)+(9\\times 6 -3)=52+51+51=154")#text(". This would also fit with the OEIS sequence A052979 mentionned above.")

#text("I’ve built the example recursively by matching lower conditions starting from the bottom left ")#mi("3\\times 3")#text(" square, first killing straight lines then diagonals, then doing the same with the other ")#mi("3\\times 3")#text(" squares from ")#mi("{}[3]^4")#text(". In fact there is still some freedom in the pattern: the two squares I’ve circled with blue could have any of the 3 elementary ")#mi("3\\times 3")#text(" patterns, but here I’ve chosen the most symmetric ones.")

#text("It seems that this construction is fairly topological and systematic, it may well be possible to get an explicit recursive formulation, and thus a formula for estimating ")#mi("c_n")#text(". I’ll try to come back to it if indeed the example is correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("276: ")#mi("c_5 = 154")

#text("Dear Thomas,")

#text("It unfortunately seems to me that the bottom row of the middle ")#mi("{}[3]^4")#text(" contains some horizontal lines (e.g. the three centres of the three ")#mi("{}[3]^2")#text("‘s in this bottom row). There are also some lines on the top row and on the left and right columns of this middle ")#mi("{}[3]^4")#text(".")

#text("(If you write each of the ")#mi("{}[3]^2")#text("‘s in xyz notation, one sees the problem; there are a bunch of rows and columns which only have two of the three patterns x, y, z and so let some lines slip in. The ")#mi("{}[3]^2")#text("‘s with three red squares in them are the intersection of two of the x, y, z and can kill more lines, but unfortunately this doesn’t cover all the possible lines.)")

#text("But it could be that some permutation of this sort of strategy could work… it may provide the first good example we have which is not based off of the ")#mi("D_n")#text(" set.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounds for the first few density Hales-Jewett numbers, and related quantities « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35798")[#strong[#text("Bounds for the first few density Hales-Jewett numbers, and related quantities « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("[…] 2009 in math.CO | Tags: polymath1 | by Terence Tao This thread is a continuation of the previous thread here on the polymath1 project. Currently, activity is focusing on the following […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("277. Thread moving")

#text("As this thread is beginning to get quite long, I am moving it to a new thread, starting at 700:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/02/13/bounds-for-the-first-few-density-hales-jewett-numbers-and-related-quantities/")[#text("Bounds for the first few density Hales-Jewett numbers, and related quantities")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-35804")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("277. lower bound of ")#mi("c_n")

#text("I tried a pattern of points based on Terry.39’s suggestion. It seems to give asymptotic results similar to what he thought.")

#text("First define a sequence, of all positive numbers which, in base 3, do not contain a 1. Add 1 to all multiples of 3 in this sequence. This sequence does not contain a length-3 arithmetic progression.")

#text("It starts 1,2,7,8,19,20,25,26,55, …")

#text("Second, list all the (abc) triples for which the larger two differ by a number")#linebreak()#text(" from the sequence, excluding the case when the smaller two differ by 1, but then including the case when (a,b,c) is a permutation of N/3+(-1,0,1)")

#text("This had numerical asymptotics for ")#mi("\\log(c_n/3^n)")#text(" close to")#linebreak()#text(" $latex 1.2-\\sqrt(\\log(n)) between n=1000 and n=10000")

#text("Sune.273: Sorry, I haven’t written all the numbers in yet for my pattern – I am only up to 70, so another formula is used to give lower bounds after that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-36015")[#strong[#text("A quick review of the polymath project « What Is Research?")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")]

#text("[…] By this time, Gowers’ blog was receiving hundreds of comments, mostly comments by Gowers himself, but also including comments from distinguished mathematicians such as Terence Tao. Tao has his own blog, and he published a post giving the background of the Hales-Jewett theorem and a later post with some of his own ideas about the problem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-37312")[#strong[#text("An Open Discussion and Polls: Around Roth’s Theorem « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")]

#text("[…] (as a little spin off to the polymath1 project, (look especially here and here)) if you have any thoughts about where the truth is for these problems, or about how to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-38133")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("278. Edel?")

#text("Just to remark that the upper bound for ")#mi("c_n^{\\prime\\prime}")#text(", ascribed in 228. to Edel, is actually present in Meshulam’s paper, in the most explicit form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-38716")[#strong[#text("Around the Cap-Set problem (B) « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")]

#text("[…] An affine line are three vectors so that for every . A cap set is a subset of without an affine line. The cap set problem asks for the maximum size of a cap set. For information on the cap set problem itself look here. For questions regarding density of sets avoiding other types of lines look here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-40079")[#strong[#text("The Polynomial Hirsch Conjecture: A proposal for Polymath3 « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")]

#text("[…] the idea of attempting a “polymath”-style open collaboration (see here, here and here) aiming to have some progress for these conjectures. (The Hirsch conjecture and the polynomial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-2/#comment-44556")[#strong[#text("Michael Nielsen » Introduction to the Polymath Project and “Density Hales-Jewett and Moser Numbers”")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")]

#text("[…] evolved. Four days after Gowers opened his blog up for discussion, Terence Tao used his blog to start a discussion aimed at understanding the behaviour of for small . This discussion rapidly gained momentum, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35488")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2009")])]

#text("200. Bounds for ")#mi("c^{\\prime\\prime}_n")

#text("Regarding the capset problem, ")#link("http://www.math.rutgers.edu/~maclagan/papers/set.pdf")[#text("here")]#text(" is a review of known values up to ")#mi("c^{\\prime\\prime}_5 = 45")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35495")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("201. Lower bounds for ")#mi("c_n")

#text("Following Jason Dyer’s suggestion, I empirically found a few more lower bounds for ")#mi("c_n")#text(" using a greedy algorithm on a bipartite graph representing combinatorial lines in ")#mi("{[3]}^n")#text(". Starting with ")#mi("n=3")#text(", they are: 18, 50, 140, 420, 1155, 3346, 11340, 32676.")

#text("The greedy algorithm fails to reach an optimal result beginning with ")#mi("c_4")#text(", which has known value 52 (as noted above).")

#text("It was also interesting to observe that the resulting graph was in some sense very skewed – a few points are in many more lines than most of the points. More specifically, if ")#mi("x\\in \\Gamma_{a,b,c}")#text(", then ")#mi("x")#text(" is in ")#mi("2^a + 2^b + 2^c - 3")#text(" combinatorial lines. Intuitively, most points are in the central ")#mi("\\Gamma")#text(" slices, which are the least connected, and these slices “mostly” don’t share lines, hinting at why we need very dense sets to hit every line.")

#text("The source code – it’s in python – is available here:")#linebreak()#text(" ")#link("http://thetangentspace.com/wiki/Hales-Jewett_Theorem")[#text("http://thetangentspace.com/wiki/Hales-Jewett_Theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35499")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("202. Lower bounds for ")#mi("c_n")

#text("I made a mistake in my argument that ")#mi("145 \\le c_5")#text(" in comment 83 on the original post. In that argument, if you remove the indicated points with ")#mi("a=0, b=1")#text(" to block the ")#mi("0,1-")#text("lines in ")#mi("D_n")#text(", the remaining set will still include the line ")#mi("01\\ast\\ast\\ast")#text(", for example. Sorry about the mistake.")

#text("We still know, at least, that ")#mi("140 \\le c_5 \\le 156=3c_4")#text(", using the last post and ")#mi("c_4=52")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35506")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("203. Greedy algorithm")

#text("Tyler, my Python is rusty, but I am correct in assuming the code does not randomize the choice of a node to remove when there’s a tie? If that’s the case, that would be the next step.")

#text("Also, this brings up something related to ")#strong[#text("Question I.B")]#text(":")

#strong[#text("Question I.B.1")]#text(" In what exact circumstances does the greedy algorithm fail; is there some larger structural concern besides corners and triangles?")

#strong[#text("Question I.B.2")]#text(" Would it be possible to automate the program to avoid those circumstances?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35521")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("204. Algorithms")

#text("Jason: Yes, that code is not randomized. I guess you might get better numbers by randomizing a bit, or by trying to improve on a first guess answer through some kind of residual graph technique.")

#text("Another thought is that we can find a blocking set of minimal size as a hypergraph transversal problem. I’m a little confused about how hard this problem is. In [Lund, Yannakakis], they apparently show the problem as being NP-hard to approximate:")#linebreak()#text(" ")#link("http://portal.acm.org/citation.cfm?doid=185675.306789")[#text("http://portal.acm.org/citation.cfm?doid=185675.306789")]

#text("On the other hand, a quick scholar.google search brings up several papers that claim to have efficient algorithms. It probably helps that we have a 3-uniform hypergraph.")

#text("If finding a minimal hypergraph transversal is feasible, that might help a lot toward question I.B. If the algorithm is simple enough, it might help generate more bounds for ")#mi("c_n")#text(". Since it explicitly finds minimal blocking sets, it is also finding the sets considered in question I.C.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35526")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("205. Algorithms")

#text("The problem with any NP-complete results is they seem to be on general cases. Even when restricting to 3-uniform hypergraphs, our graph is a lot more symmetrical than an arbitrary one. Surely there’s something about that we can exploit?")

#text("Mathematically describing those symmetries might be an interesting exercise (although perhaps someone already has in the original 150+ comment thread).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("206. Algorithms")

#text("One possible way to exploit symmetries is to work in (a,b,c) space rather than the cube ")#mi("{}[3]^n")#text(". Indeed, note that the set of all ")#mi("(a,b,c)")#text(" with ")#mi("a+b+c=n")#text(" forms a triangular lattice of length ")#mi("n+1")#text(", and that each triple (a,b,c) comes with a “weight” ")#mi("\\frac{n!}{a! b! c!}")#text(", which is the number of strings in ")#mi("{}[3]^n")#text(" with a 1s, b 2s, and c 3s.")

#text("Now pick some subset B of this lattice which contains no equilateral triangles ")#mi("(a+r,b,c), (a,b+r,c), (a,b,c+r)")#text(". Then the set ")#mi("\\Gamma_B := \\bigcup_{(a,b,c) \\in B} \\Gamma_{(a,b,c)}")#text(" has no combinatorial lines, and has cardinality equal to the total weight of all the elements of B. So one now has a two-dimensional problem: maximise the total weight of a subset of the triangular lattice with no equilateral triangles.")

#text("The best bounds for ")#mi("c_n")#text(" for ")#mi("n \\leq 4")#text(" all take this form. For instance, the ")#mi("c_4=52")#text(" example takes B to be the entire triangle except for ")#mi("(0,0,4), (1,1,2), (0,3,1), (3,0,1), (0,4,0), (0,0,4)")#text(". It looks feasible to search for optimal Bs for the next few ns. Note that the set ")#mi("D_n")#text(" in the main post corresponds to excluding those ")#mi("(a,b,c)")#text(" for which ")#mi("a=b \\text{ mod } 3")#text("; after excluding those, the only equilateral triangles remaining are those whose length is a multiple of 3 and so the hypergraph splits into disconnected components based on the residues of a,b,c mod 3, which should simplify things significantly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35537")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("207. Lower bounds for ")#mi("c_n")

#text("The algorithm in Tao.206 is very effective. I has found the following _without_ useing a computer:")

#text("For ")#mi("c_5")#text(" take ")#mi("D_5")#text(" and remove ")#mi("(0,4,1), (0,5,0), (4,0,1), (5,0,0)")#text(". This gives a set without triangles and with 150 elements. Thus ")#mi("c_5\\geq 150")#text(", and this bound cannot be improved using the algoritm in 206.")

#text("For ")#mi("c_6")#text(" take ")#mi("D_6")#text(" and remove the permutations of ")#mi("(0,1,5)")#text(". This gives ")#mi("c_6\\geq 450")#text(", and agian, this cannot be improved using the algorithm in 206.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35540")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("208. proof theoretic analysis")

#text("Could it be interesting to try to prove there is NO combinatorial proof of the theorem, sort of like Kirby and Paris proved there is no PA proof of Goodstein’s theorem? I’m guessing “combinatorial proof” means one codeable in primitive recursive arithmetic, whose proof theoretic ordinal is omega**omega. So we’d try to use the Hales-Jewett theorem to prove some kind of well-ordering on those point collections, which has order type larger than omega**omega, which most interesting orderings probably would have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35548")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("209. Lower bound for ")#mi("c_n")

#text("Correction to 207: When I said that the bound could not be improved using the algorithm from Tao.206 I assume that triples with ")#mi("a=b \\text{ mod } 3")#text(" had to be left out of the set. I don’t know if it can be improved without this assumption.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35550")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("210. Algorithms")

#text("The idea in Tao.206 can only prove lower bound for ")#mi("c_n")#text(". But perhaps it can be modified to prove the values of some ")#mi("c_n")#text(":")

#text("Let ")#mi("A\\subset \\Gamma_{a+r,b,c}, B\\subset \\Gamma_{a,b+r,c}, C\\subset \\Gamma_{a,b,c+r}")#text(". Now we want some inequality in ")#tao-math("\\left|A\\right|, \\left|B\\right|,\\left|C\\right|, a, b, c, r", block: false)#text(" that holds for every ")#mi("A,B,C")#text(" without combinatorial lines. More on this later.")

#text("Now, instead of giving each triple ")#mi("(a,b,c)")#text(" with ")#mi("a+b+c=n")#text(" the weight ")#mi("\\frac{n!}{a! b! c!}")#text(", we give it an integer weight between 0 and ")#mi("\\frac{n!}{a! b! c!}")#text(". Instead of looking for subsets of the triangular lattice with no equilateral triangles, we look for weightings where the weights of the points in each equilateral triangle obey the above inequality.")

#text("One example of such an inequality could be: ")#tao-math("\\left|A\\right|+\\left|B\\right|+\\left|C\\right|\\leq", block: false)#text(" the sum of the two greatest of ")#mi("\\frac{n!}{(a+r)! b! c!}, \\frac{n!}{a! (b+r)! c!}, \\frac{n!}{a! b! (c+r)!}")#text(". I don’t think this inequality is strong enough, because we want to “remove” more than 1/3 of the total weight, but perhaps we can find some stronger inequalities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35551")[#strong[#text("DHJ — the triangle-removal approach « Gowers’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")]

#text("[…] of the ensuing discussion that are most directly related to this initial proposal. Two other posts, one hosted by Terence Tao on his blog, and the other here, take up alternative approaches that emerged during the discussion. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35554")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("211. Sequence for ")#mi("c_n")

#text("Sune.207 leaves ")#link("http://www.research.att.com/~njas/sequences/A052979")[#text("this sequence")]#text(" as the last one standing in the OEIS.")

#text("At our current rate of progress I suspect we can at least get an exact value for ")#mi("c_5")#text(", so I’d say wait a bit longer on sending our sequence in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35556")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("212. Algorithms")

#text("Here’s a summary of the different possible algorithm tracks.")

#text("1. Randomize the greedy algorithm, then run multiple times to see if any better lower bounds come out. If this doesn’t get any result that improves over Tao.206, that suggests that Tao.206 is optimal.")

#text("2. Implement Tao.206 with the dihedral group. As Sune.207 discovered this can be done well even by hand, so it might also be worth it to generate some graphics of lattices with the weights put in to let people try to solve as a puzzle — if anything in this project could be done by a non-expert, this is it.")

#text("3. Implement Tao.206 without the dihedral group. If no improvement is found then it would be worthwhile to attempt a proof that the dihedral group can *always* be removed.")

#text("4. Write a brute force confirmation algorithm that will leave no question once a ")#mi("c_n")#text(" is found that it’s exact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("213. Upper and lower bounds")

#text("I added a table to the main post to reflect the progress so far on ")#mi("c_n, c^{\\prime}_n, c^{\\prime\\prime}_n")#text(" for n up to 7. (I may expand the table up to n=10 or so at some later point.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35563")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("(Meta) Quick fix: you put 1115 when it’s 1155 for ")#mi("c_7")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35564")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("214. Upper and lower bounds.")

#text("Shouldn’t the upper bound for ")#mi("c_5")#text(" be 156? And I think the next upper bounds should be higher too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Thanks for the corrections! I decided to go ahead and extend the table to n=10, though I am sure some of the bounds here could be optimised further.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35571")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("215. Algorithm / Idea for bounding the ")#tao-math("\\left|A\\right|,\\left|B\\right|,\\left|C\\right|", block: false)#text(" in 210")

#text("This is almost a copy of 340:")

#text("In 331 Gowers gives a proof that if ")#mi("\\mathcal{A}")#text(" is a antichain, ")#tao-math("\\sum_{A\\in\\mathcal{A}}\\frac{1}{\\binom n{\\left|A\\right|}}\\leq 1", block: false)#text(". Using the same idea it is possible to show that if ")#mi("\\mathcal{A}")#text(" is a family, that intersects every chain ")#mi("\\emptyset=A_0\\subset A_1\\subset A_2\\subset\\dots\\subset A_n=[n]")#text(", then ")#tao-math("\\sum_{A\\in\\mathcal{A}}\\frac{1}{\\binom n{\\left|A\\right|}}\\geq 1", block: false)#text(". Notice that when the elements of ")#mi("\\mathcal{A}")#text(" is only allowed to have one of two given sizes, these two theorems are equivalent. The later theorem seems to be easier to generalize to the k=3 case, and it might be useful, at least in the 200-thread.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35572")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("216. Algorithm.")

#text("This is almost the same as I suggested in 215, but simpler and weaker:")

#text("The chance that a random line with a 1s, b 2s, b 3s, and r wildcard intersects ")#mi("A\\subset \\Gamma_{a+r,b,c}")#text(" is ")#tao-math("\\frac{\\left|A\\right|}{\\binom n{a+r,b,c}}", block: false)#text(". Using this and the similar for b and c we get")#linebreak()#text(" ")#tao-math("\\frac{\\left|A\\right|}{\\binom n{a+r,b,c}}+\\frac{\\left|B\\right|}{\\binom n{a,b+r,c}}+\\frac{\\left|C\\right|}{\\binom n{a,b,c+r}}\\leq 2", block: false)#text(", if ")#mi("A\\cup B\\cup C")#text(" doesn’t contain any lines. Still, I don’t think this inequality is strong enough. I think something stronger is true when A, B and C all are non-empty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35573")[#strong[#text("Frankl-Rodl’s Theorem and Variations on the Cap Set Problem: A Recent Research Project with Roy Meshulam (A) « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")]

#text("[…] to the density Hales-Jewett project discussed over Gowers’s blog (and even more to this thread at Tao’s blog), I decided to go ahead with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35585")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("217. Lower bounds for c_n")#linebreak()#text(" Following Jakobsen.207 who used Tao.206")#linebreak()#text(" I got a lower bound for c_7 of 1302: Remove {016,106,052,502,151,511,160,610} from D_7.")#linebreak()#text(" and a lower bound for c_8 of 3780: Remove {017,107,026,206,125,215,071,701,161,611,080,800,260,620} from D_8")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35593")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("218. Lower bounds for c_n")

#text("It is curious that the current lower bounds for c_2, c_5 and c_8 are respectively one-third of the current lower bounds for c_3, c_6 and c_9.")

#text("I have a lower bound for c_12: 287892, built from (abc) = (A02,705,423,165,462) and permutations, with A=10);")

#text("and a lower bound for c_15 of 7376850, built from (abc) = (40B,13B,708,168,735,465,762) and permutations, with B=11.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("219. Lower bounds for ")#mi("c_n")

#text("Hi Michael! I propagated your lower bounds back in n using (2), and they seem to give quite good bounds. Certainly our accuracy for ")#mi("c_n")#text(" is much superior to what we currently have for ")#mi("c^{\\prime}_n")#text(" or ")#mi("c^{\\prime\\prime}_n")#text(".")

#text("I also like the suggestion in Jakobsen.210 to try to understand the ways in which a line-free set can intersect ")#mi("\\Gamma_{a+r,b,c}, \\Gamma_{a,b+r,c}, \\Gamma_{a,b,c+r}")#text(". A test problem that might be susceptible to brute force attack is the following: consider the set ")#mi("S := \\Gamma_{1,1,2} \\cup \\Gamma_{1,2,1} \\cup \\Gamma_{2,1,1} \\subset [3]^4")#text(". This is the union of three groups of 12 vertices, and it contains 24 triangles, each of which meets each of the three groups in exactly one vertex, with each vertex belonging to two triangles. Now let ")#mi("A \\cup B \\cup C")#text(" be a line-free subset of S, where ")#mi("A \\subset \\Gamma_{1,1,2}")#text(", ")#mi("B \\subset \\Gamma_{1,2,1}")#text(", ")#mi("C \\subset \\Gamma_{2,1,1}")#text(". The question is: what constraints are there on the triple ")#tao-math("(\\left|A\\right|, \\left|B\\right|, \\left|C\\right|)", block: false)#text("? A simple double counting argument shows that ")#tao-math("\\left|A\\right| + \\left|B\\right| + \\left|C\\right| \\leq 24", block: false)#text(" (this is already alluded to in 210). And it is easy to see that ")#tao-math("(\\left|A\\right|, \\left|B\\right|, \\left|C\\right|)", block: false)#text(" can attain the values ")#mi("(12, 12, 0), (12, 0, 12), (0, 12, 12)")#text(". But are these the only ways that ")#tao-math("\\left|A\\right| + \\left|B\\right| + \\left|C\\right|", block: false)#text(" can be as large as 24? If so, this suggests that the most efficient way to build line-free sets is to zero out some of the ")#mi("\\Gamma_{a,b,c}")#text(" and pile all the vertices into the rest – in short, to perform the type of strategy we are already doing from 206 onwards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35597")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("219. Lower bounds for c_n")

#text("I wish to correct the triples for c_12 in my previous post (see below).")

#text("I have found a way to automate construction of lower bounds,")#linebreak()#text(" when n is a multiple of 3.")

#text("The current lower bounds for c_{3m} are built like this,")#linebreak()#text(" written in terms of Tao.206’s (a,b,c):")#linebreak()#text(" c_3 from (012) and permutations")#linebreak()#text(" c_6 from (123,024) and perms")#linebreak()#text(" c_9 from (234,135,045) and perms")#linebreak()#text(" c_12 from (345,246,156,02A,057) and perms (A=10)")#linebreak()#text(" c_15 from (456,357,267,13B,168,04B,078) and perms (B=11)")#linebreak()#text(" To get the triples in each row, add 1 to the triples in the previous row; then include new triples that have a zero.")

#text("This method gives a lower bound for c_99 that is bigger than 3^98.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35599")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("220. Lower bounds for ")#mi("c_n")

#text("Hi Terry. An answer to your test question is that")#linebreak()#text(" you can keep 8 from each group of 12: Remove those, such as 0201,")#linebreak()#text(" whose doubled digits are in positions 1 and 3, or")#linebreak()#text(" positions 2 and 4. This removes all lines because the")#linebreak()#text(" wild-card digit has to match the digit two positions away")#linebreak()#text(" once in each line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35600")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("221. Algorithm / Upper bounds.")

#text("One way to show that the idea in 210 can _not_ work would be the following:")#linebreak()#text(" Find a weighting w, such that for every a,b,c and r, ")#mi("a+b+c+r=n")#text(", there exist sets ")#mi("A\\subset \\Gamma_{a+r,b,c}, B\\subset \\Gamma_{a,b+r,c}, C\\subset \\Gamma_{a,b,c+r}")#text(" with ")#tao-math("\\left|A\\right|=w((a+r,b,c)), \\left|B\\right|=w((a,b+r,c)), \\left|C\\right|=w((a,b,c+r))", block: false)#text(" and no lines in ")#mi("A\\cup B\\cup C")#text(", but with ")#mi("\\sum_{a+b+c=n} w(a,b,c) > c_n")#text(".")

#text("I don’t know if such a weighting exist, but in the k=2 case (Sperners theorem) it does: Let ")#mi("w(a,b)=\\frac{1}{3}\\binom n{a,b}")#text(" if ")#mi("n/3 < a < n/2")#text(" and 0 otherwise. Now for a given a, b and r we can choose a set A, of elements x with ")#mi("x_1=2")#text(" and a set B, of elements x with ")#mi("x_1=1")#text(". These set are big enough, and don’t contain any lines. And the sum of the weight function is almost ")#mi("\\frac{2^n}{3} > \\binom n{n/2}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35603")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("222. Alogrithm/ Upper bounds")

#text("The obvious generalization to the k=3 case works: Let ")#mi("w(a,b,c)=\\frac{1}{4}\\binom n{a,b,c}")#text(" if ")#mi("a,b,c \\geq n/4")#text(". Now we can choose a set A with elements x, such that ")#mi("x_1=3")#text(" and a set C with elements x, such that ")#mi("x_1=1")#text(" and a set B. Now ")#mi("A\\cup B\\cup C")#text(" don’t contain any lines.")

#text("This weight gives a density of almost ¼. So the idea in 210 won’t work for large n. Still, I think it might be interesting to look at the questions Tao asked in 219 for general a, b, c and r.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35604")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("223. Lower bounds of ")#mi("c_n")

#text("There is a connection between ")#mi("c_4")#text(", ")#mi("c_5")#text(" and ")#mi("c_6")#text(":")#linebreak()#text(" Of the 450 length-six sequences defined in Peake.219,")#linebreak()#text(" 150 begin with a 1….., and 52 begin with 12…..")

#text("The same thing applies with the current lower bounds of c_7, c_8 and c_9")

#text("It also gives lower bounds of 32864 for c_10, and 837850 for c_13")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("224. Lower bounds for ")#mi("c_n")

#text("@Peake.219: This is quite interesting. I wonder if it is possible to extract an asymptotic for the lower bound obtained by this method as ")#mi("n \\to \\infty")#text(" (i.e. Question II.C). It is also interesting to see that ")#mi("c_n/3^n")#text(" is really decaying very slowly as ")#mi("n \\to \\infty")#text(".")

#text("It may be time to set up some sort of communal spreadsheet for all this data – I’ll have a look into this.")

#text("@Jakobsen.220: Ah well, it was worth a shot. (Note, by the way, that the bound ")#tao-math("\\left|A\\right|+\\left|B\\right|+\\left|C\\right| \\leq 24", block: false)#text(" in 219 implies the sharp bound ")#mi("c_4 \\leq 52")#text(", since a line-free set must omit at least one element from ")#mi("\\Gamma_{0,0,4} \\cup \\Gamma_{1,0,3} \\cup \\Gamma_{0,1,3}")#text(" and similarly for cyclic permutations; so a better understanding of when equality occurs in ")#tao-math("\\left|A\\right|+\\left|B\\right|+\\left|C\\right|=24", block: false)#text(" would lead to a classification of when one has the maximal cardinality of ")#mi("c_4=52")#text(", which should assist with the upper bound for ")#mi("c_5")#text(" as with Jakobsen.90). [")#emph[#text("Update")]#text(", Feb 8: I made an arithmetic error here, this inequality is not enough by itself to get to 52; one also needs to figure out how to relate ")#mi("\\Gamma_{2,0,0}")#text(", etc. into the mix. But the general point may still be valid.]")

#text("In light of the discussion in Gowers’ threads, it seems that the Kruskal-Katona theorem,")

#link("http://en.wikipedia.org/wiki/Kruskal%E2%80%93Katona_theorem")[#text("http://en.wikipedia.org/wiki/Kruskal%E2%80%93Katona_theorem")]

#text("is likely to be relevant here, at least for large n.")

#text("@Peake.223: Hmm. Does this mean that all of our optimal counterexamples are in fact nested (e.g. is the ")#mi("c_6")#text(" example a slice of the ")#mi("c_7")#text(" example?) This may be a transient phenomenon, but still an interesting one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35607")[#strong[#text("DHJ — quasirandomness and obstructions to uniformity « Gowers’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")]

#text("[…] after the post entitled A combinatorial approach to density Hales-Jewett. The other two are Upper and lower bounds for the density Hales-Jewett problem , hosted by Terence Tao on his blog, and DHJ — the triangle-removal approach, which is on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35608")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("225. Spreadsheet")

#text("OK, I _think_ I’ve set up a collaborative spreadsheet at")

#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")[#text("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")]

#text("to track the current data we have for ")#mi("c_n, c^{\\prime}_n, c^{\\prime\\prime}_n")#text(". It should be editable to anyone with a google account. It should automatically propagate the bounds (1), (2) to any new bound entered. (I also have a backup copy in case something goes wrong.) One should presumably be able to program the computations in 219 into here too. Please feel free to contribute to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35614")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("226. ")#mi("c^{\\prime\\prime}_n")

#text("Just a quick note: ")#mi("c^{\\prime\\prime}_n")#text(" is *not* in the OEIS.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35617")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("227. This has perhaps already been pointed out, but there is at most one entry in the Encyclopedia of Integer Sequences consistent with what is already known about ")#mi("c_n")#text(". That is ")#text("A052979")#text(". It matches ")#mi("c_n")#text(" exactly where we already know the value, and matches the (current) bounds for at least the first fifteen entries.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35618")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("227. Spreadsheet")

#text("Hi, I looked at the spreadsheet, but can’t edit it.")#linebreak()#text(" I logged into Google, but the Edit menu is grayed out.")#linebreak()#text(" Does anyone else have this problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao22")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35619")[#strong[#text("Terence Tao22")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("228. Edel")

#text("I’ve added the lower bound ")#mi("c^{\\prime\\prime}_6 \\geq 236")#text(" from this ")#link("http://www.springerlink.com/content/m55136x765161240/")[#text("paper of Edel")]#text(". In ")#link("http://www.mathi.uni-heidelberg.de/~yves/Papers/ABound.pdf")[#text("this other paper of Edel")]#text(", an inequality is obtained which in our notation reads")

#mi("\\displaystyle c^{\\prime\\prime}_n \\leq \\frac{3c^{\\prime\\prime}_{n-1} + 1}{1 + c^{\\prime\\prime}_{n-1}/3^{n-1}}")

#text("for ")#mi("n \\geq 3")#text(", and which thus slightly improves on (2) for this problem. I’ve updated the spreadsheet and the table accordingly.")

#text("Michael.227: oops, I didn’t set the permissions properly. I think it should be OK now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KS Chua")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35620")[#strong[#text("KS Chua")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("229 : ")#mi("c_n")#text(" via optimization")

#text("For HJ2, there is a well known method for expressing ")#mi("c_n")#text(" as the maximization of a quadratic polynomial over a box ")#mi("D_n=[0,1]^{2^n}")#text(" so that one can apply a continuous optimization method.")

#text("Let ")#mi("G")#text(" be a graph with vertex set given by all subsets of ")#mi("{}[n]")#text(" and let ")#mi("(I,J) \\in E_2")#text(" be an edge if and only if it defines a line. Then ")#mi("c_n")#text(" is the size of a maximal independent set in ")#mi("G")#text(".")

#text("Let ")#mi("x")#text(" be a variable vector of length ")#mi("2^n")#text(", ")#mi("x_{i_1...i_n},i_j \\in \\{0,1\\}")#text(" which we think")#linebreak()#text(" of as ")#mi("x_I, I \\subset [n]")#text(" where ")#mi("I=\\{j: i_j=1\\}")#text(" indexing the subset of ")#mi("{}[n]")#text(". The known quadratic programming problem defining ")#mi("c_n")#text(" is")

#mi("c_n[2]=\\max_{x \\in [0,1]^{2^n}} \\left( \\sum_{J} x_J -\\sum_{ (I,J) \\in E_2} x_I x_J \\right).")

#text("It just occurs to me that a similar result appears to hold for ")#mi("k=3")#text(" and in fact for all ")#mi("k")#text(". For HJ3, let ")#mi("G")#text(" be the 3-hypergraph with vertex set as before and set ")#mi("(I,J,K) \\in E_3")#text(" to be a 3-edge if and only if it is a line. ")#mi("c_n")#text(" is then the size of a maximal independent set as before.")#linebreak()#text(" Let")

#mi("f(x)= \\sum_I x_I-\\sum_{(I,J,K) \\in E_3} x_Ix_Jx_K.")

#text("The following then holds,")

#mi("c_n=\\max_{x \\in \\{0,1\\}^{2^n}}f(x)=\\max_{x \\in D_n}f(x)")

#text("To check the first equality, if ")#mi("V")#text(" is an independent set in ")#mi("G")#text(" of size ")#mi("k")#text(", set ")#mi("x_J=1")#text(" for ")#mi("J \\in V")#text(", and zero otherwise. Then ")#mi("f(x)=k")#text(" because ")#mi("V")#text(" is independent. So ")#mi("c_n \\le  \\max_{x \\in \\{0,1\\}^{2^n}} f(x)")#text(". Conversely, if for some ")#mi("x \\in \\{0,1\\}^{2^n}, f(x)=k,")#text(" and if there are triplets ")#mi("x_I=x_J=x_K=1")#text(" with ")#mi("(I,J,K) \\in E_3")#text(", we change ")#mi("x_I")#text(" to 0. This reduces ")#mi("\\sum x_I")#text(" by 1 but also reduce the second term of ")#mi("f(x)")#text(" by at least one. So repeating we can find an ")#mi("x \\in \\{0,1\\}^{2^n}")#text(" with ")#mi("f(x) \\ge k")#text(" and ")#mi("x_Ix_Jx_K=0")#text(" if ")#mi("(I,J,K) \\in E_3")#text(", i.e. an independent set of size ")#mi("\\ge k")#text(". So ")#mi("c_n \\ge \\max_{x \\in \\{0,1\\}^{2^n}} f(x)")#text(". The 2nd equality follows from the maximum principle since ")#mi("f")#text(" is a square free polynomial.")

#text("So an algorithm which can always determine the maximum of a quadratic polynomial in a box will be able to determine ")#mi("c_n")#text(" but the problem is ")#mi("NP")#text(" hard. Maybe one can try to find ")#mi("c_n")#text(" this way using quadratic programming for small ")#mi("n")#text(".")

#text("The same should hold for any ")#mi("k>1")#text(" with")#linebreak()#text(" ")#mi("f(x)= \\sum_I x_I-\\sum_{(I_1,...,I_k) \\in E_k} x_{I_1}...x_{I_k}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35624")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("A052979 is within the current bounds for c_n for the first 27 entries of")#linebreak()#text(" the spreadsheet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35625")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("The sequence c_n’ matches the sequence A027994 for the first")#linebreak()#text(" five values and lies between the upper and lower bounds")#linebreak()#text(" of c_n’ as calculated in the spreadsheet for the next 23 values,")#linebreak()#text(" it matches the sequence A027068 for the first five values")#linebreak()#text(" and lies within the bounds of the next 22 values.")

#text("These are the only two sequences in the OEIS which could")#linebreak()#text(" possibly be equal to c_n’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35629")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("232. Can one modify Behrend construction to give lower bound on ")#mi("c_n^{\\prime}")#text("?")

#text("In a geometric line, the number of 1’s ,2’s and 3’s is ")#mi("(a+t_1,b,c+t_2)")#text(", ")#mi("(a,b+t_1+t_2,c)")#text(" and ")#mi("(a+t_2,b,c+t_1)")#text(" respectively, where ")#mi("t_1")#text(" and ")#mi("t_2")#text(" denote the number of wildcards of the two types. In other words, if ")#mi("(a,b,c)")#text(" and ")#mi("(a^{\\prime},b^{\\prime},c^{\\prime})")#text(" are the first two signatures, then the third is ")#mi("(a^{\\prime}+c-c^{\\prime},b,c^{\\prime}+a-a^{\\prime})")#text(". This is similar to when Behrend works: if one point is determined by the other two in a linear manner. Here “linear manner” is somewhat crooked, and I do not see how to apply Behrend, or any of the standard heuristics.")

#text("Hence, question: how large is the largest subset of ")#mi("\\{0,\\dotsc,M\\}^3")#text(" not containing a configuration of the above form?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35630")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("232. Lower bounds of ")#mi("c_n")

#text("I have added some more lower bounds to Terry.225’s spreadsheet.")#linebreak()#text(" The sets of (abc) that I have used are the following for N a multiple of 3.")#linebreak()#text(" I think that they are triangle-free.")

#text("For N=3M-1, restrict the first digit of a 3M sequence to be 1;")#linebreak()#text(" For N=3M-2, restrict the first two digits of a 3M sequence to be 12.")

#text("For N<21, ignore any triple with a negative entry.")

#text("For N=6M:")

#text("(2x, 2x+2, N-4x-2) and permutations (x=0..M-4)")#linebreak()#text(" (2x, 2x+5, N-4x-5) and perms (x=0..M-4)")#linebreak()#text(" (2x, 3M-x-4, 3M+x+4) and perms (x=0..M-4)")#linebreak()#text(" (2x, 3M-x-1, 3M+x+1) and perms (x=0..M-4)")

#text("(2x+1, 2x+5, N-4x-6) and perms (x=0..M-5)")#linebreak()#text(" (2x+1, 2x+8, N-4x-9) and perms (x=0..M-5)")#linebreak()#text(" (2x+1, 3M-x-1, 3M-x) and perms (x=0..M-5)")#linebreak()#text(" (2x+1, 3M-x-4, 3M-x+3) and perms (x=0..M-5)")

#text("(N/3-7, N/3-3, N/3+10) and perms")#linebreak()#text(" (N/3-7, N/3, N/3+7) and perms")#linebreak()#text(" (N/3-7, N/3+3, N/3+4) and perms")#linebreak()#text(" (N/3-6, N/3-4, N/3+10) and perms")#linebreak()#text(" (N/3-6, N/3-1, N/3+7) and perms")#linebreak()#text(" (N/3-6, N/3+2, N/3+4) and perms")#linebreak()#text(" (N/3-5, N/3-1, N/3+6) and perms")#linebreak()#text(" (N/3-5, N/3+2, N/3+3) and perms")#linebreak()#text(" (N/3-4, N/3-2, N/3+6) and perms")#linebreak()#text(" (N/3-4, N/3+1, N/3+3) and perms")#linebreak()#text(" (N/3-3, N/3+1, N/3+2) and perms")#linebreak()#text(" (N/3-2, N/3, N/3+2) and perms")#linebreak()#text(" (N/3-1, N/3, N/3+1) and perms")

#text("For N=6M+3:")

#text("(2x, 2x+4, N-4x-4) and perms, x=0..M-3")#linebreak()#text(" (2x, 2x+7, N-4x-7) and perms, x=0..M-3")#linebreak()#text(" (2x, 3M+1-x, 3M+2-x) and perms, x=0..M-3")#linebreak()#text(" (2x, 3M-2-x, 3M+5-x) and perms, x=0..M-3")

#text("(2x+1, 2x+3, N-4x-4) and perms, x=0..M-4")#linebreak()#text(" (2x+1, 2x+6, N-4x-7) and perms, x=0..M-4")#linebreak()#text(" (2x+1, 3M-x, 3M-x+2) and perms, x=0..M-4")#linebreak()#text(" (2x+1, 3M-x-3, 3M-x+5) and perms, x=0..M-4")

#text("(N/3-7, N/3-3, N/3+10) and perms")#linebreak()#text(" (N/3-7, N/3, N/3+7) and perms")#linebreak()#text(" (N/3-7, N/3+3, N/3+4) and perms")#linebreak()#text(" (N/3-6, N/3-4, N/3+10) and perms")#linebreak()#text(" (N/3-6, N/3-1, N/3+7) and perms")#linebreak()#text(" (N/3-6, N/3+2, N/3+4) and perms")#linebreak()#text(" (N/3-5, N/3-1, N/3+6) and perms")#linebreak()#text(" (N/3-5, N/3+2, N/3+3) and perms")#linebreak()#text(" (N/3-4, N/3-2, N/3+6) and perms")#linebreak()#text(" (N/3-4, N/3+1, N/3+3) and perms")#linebreak()#text(" (N/3-3, N/3+1, N/3+2) and perms")#linebreak()#text(" (N/3-2, N/3, N/3+2) and perms")#linebreak()#text(" (N/3-1, N/3, N/3+1) and perms")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c2972a003ecdf05d0c37f49ff1961df825af84432da289cf9facc8f8d01edc-41cbd69b4fb643e5a5ea51773a8300be73b0ff64682f8315d3b3875a85b7e88e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35631")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Even if we are tentatively happy about the bounds (like (6)) based on AP free sets for k=3. Regarding problem II.b for higher k’s it looks we should be able to do much better (than just replacing Behrend by the examples for larger k).")

#text("At least this is suggested by the way our bound changes between the k=2 case and the k=3 case.")

#text("E.g we can try something like this: map words of length n in an alphabet of 4 letters to words in 3 letters. Say with one letter a representing 1 or 2 letter b representing 2 or 3 and letter c representing 3 or 4.")

#text("Then try to find a large set of letters in a b and c whose preimage will automatically exclude a combinatorial line of length 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35634")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("(Meta)")

#text("Kirstal, Terry’s original post already specified ")#link("http://www.research.att.com/~njas/sequences/A003142")[#text("this sequence")]#text(" is ")#mi("c^{\\prime}_n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35635")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("234. ")#mi("c_n")#text(" via optimization")

#text("Regarding Chua.229, shouldn’t that be ")#mi("3^n")#text(" rather than ")#mi("2^n")#text(" in the k=3 version of the algorithm? (Otherwise I’m confused how the indexing works.)")

#text("It looks like this could be the best algorithm to get exact values of ")#mi("c_n")#text(", although the algorithm is elaborate enough I would be worried about the integrity of the code. Is there at least some implementation for k=2 out there already?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-624237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2021")])]

#text("facciamo una prova")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35636")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("235.")

#text("I want to just add that if we restrict the triple ")#mi("(a,b,c)")#text(" to lie in a Cartesian product ")#mi("A\\times A\\times A")#text(", then “crookedness” disappears and we end up with system of three linear equations in nine variables, whose solutions we want to avoid in ")#mi("A")#text(". For the next few hours I will not have the time to try adapting Behrend to this setting though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35648")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("236. Restriction to Cartesian products is too rough of a proposal. It does not even work for corners. Indeed the points ")#mi("(x,y), (x+r,y), (x,y+r)")#text(" have four distinct coordinates among them, ")#mi("x_1=x_2, x_2=x+r, y_1=y, y_2=y+r")#text(". They are linked by the equation ")#mi("x_2-x_1=y_2-y_1")#text(". The largest set avoiding solutions to this equation has size $\\sqrt{n}(1+o(1))$ (this equation usually goes by the name of Sidon equation, and is extremely well-studied).")

#text("Similarly, straightforward implementation of my proposal in 235 gives the equation ")#mi("y_2-x_2=y_3-x_1=y_1-x_3")#text(" where ")#mi("x_1=a, x_2=a^{\\prime}, y_1=c, y_2=c^{\\prime}, x_3=a^{\\prime}+c-c^{\\prime}, y_3=c^{\\prime}+a-a^{\\prime}")#text(". Pigeonhole principle tells us that the largest solution-free set is of size ")#mi("O(\\sqrt{n})")#text(".")

#text("The question remains: is there a Behrend-type construction?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("237.")

#text("Boris, this was discussed a little bit in 43, 48 of the original thread. The basic problem is the ")#mi("t_1=t_2")#text(" case (in the notation of your 232) when two of the points on the crooked line coincide. It basically means that one cannot have more than one point on any line ")#mi("c-a = const")#text(". Conversely, any configuration with this property will be free of crooked lines, which I guess is what leads to the known ")#mi("3^n/O(\\sqrt{n})")#text(" lower bound.")

#text("A subproblem may be to work out whether one can find denser sets on the set ")#mi("\\bigcup_{c-a=const} \\Gamma_{a,b,c}")#text(" that are free of geometric lines than just a single ")#mi("\\Gamma_{a,b,c}")#text(", and have a better density than ")#mi("1/\\sqrt{n}")#text(" asymptotically. If so, then we can glue together such sets as ")#mi("const")#text(" ranges over a Behrend set and get a competitive example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35652")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("238. Lower bounds of ")#mi("c_n")

#text("The pattern I described in My.232 has a slight error")#linebreak()#text(" when N=6M+3, as x ranges from 0 to M-4, not M-3.")

#text("This pattern, for N a multiple of 3, leaves no room for any more points – any new point would complete a line.")

#text("I don’t know the asymptotic for this pattern’s value of c_n/3^n, but")#linebreak()#text(" 2.7 sqrt(log(n)/n) is a good fit when n is between 4000 and 10000")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KS Chua")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35655")[#strong[#text("KS Chua")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("239. ")#mi("c_n")#text(" by optimization.")

#text("Sorry I made a mistake in 229. The box should be ")#mi("{}[0,1]^{3^n}")#linebreak()#text(" for ")#mi("k=3")#text(" instead of ")#mi("2^n")#text(" as Jason Dyer noted. Also for")#linebreak()#text(" ")#mi("k>2")#text(" it is no longer a QP problem and one needs a general")#linebreak()#text(" optimization routine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2009/02/05/upper-and-lower-bounds-for-the-density-hales-jewett-problem/comment-page-1/#comment-35660")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("240. Algorithms")

#text("I think finding a minimum-sized hypergraph transversal in NP-hard, even for 3-uniform hypergraphs.")

#text("We can reduce 3-SAT to this problem. We are given a boolean expression ")#mi("\\phi_1\\wedge\\phi_2\\wedge\\ldots\\wedge \\phi_k")#text(" where each ")#mi("\\phi_i")#text(" is the OR of 3 terms, each term either a boolean value from ")#mi("(x_i)_{i=1}^m")#text(", or the negation thereof. Form a hypergraph with vertices ")#mi("x_1, \\neg x_1, x_2, \\neg x_2, \\ldots")#text(", and each ")#mi("\\phi_i")#text(" as a hyperedge. Add a dummy node ")#mi("x_j^{\\prime}")#text(", and a hyperedge ")#mi("(x_j, \\neg x_j, x_j^{\\prime})")#text(" for each boolean value. These last hyperedges ensure there is no smaller solution than the one corresponding to a satisfying boolean assignment, if one exists. It’s not hard to check that a minimum transversal is size ")#mi("m")#text(" (the number of boolean values) iff there is a satisfying assignment; this completes the reduction.")

#text("What does this mean for us? If we want a polynomial time algorithm (in the size of the graph), we have to use more of the structure than just the fact that every line has 3 points, assuming ")#mi("NP\\not\\subset P")#text(". Also recall that the size of our graph itself is already exponential in n.")
]
