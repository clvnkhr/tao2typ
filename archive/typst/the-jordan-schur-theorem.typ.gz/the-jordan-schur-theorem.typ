// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:13.937622+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Jordan-Schur theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Jordan-Schur theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/")[#text("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Jordan’s theorem is a basic theorem in the theory of finite linear groups, and can be formulated as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Jordan’s theorem)")]#text(" ")#metadata(none) <tao-f422f1dba3be35b17f4e>#text(" Let ")#mi("{G}")#text(" be a finite subgroup of the general linear group ")#mi("{GL_d({\\bf C})}")#text(". Then there is an abelian subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" of index ")#mi("{[G:G^{\\prime}] \\leq C_d}")#text(", where ")#mi("{C_d}")#text(" depends only on ")#mi("{d}")#text(".")
]

#text("Informally, Jordan’s theorem asserts that finite linear groups over the complex numbers are almost abelian. The theorem can be extended to other fields of characteristic zero, and also to fields of positive characteristic so long as the characteristic does not divide the order of ")#mi("{G}")#text(", but we will not consider these generalisations here. A proof of this theorem can be found for instance in ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("these lecture notes of mine")]#text(".")

#text("I recently learned (from ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/#comment-89257")[#text("this comment")]#text(" of Kevin Ventullo) that the finiteness hypothesis on the group ")#mi("{G}")#text(" in this theorem can be relaxed to the significantly weaker condition of ")#link("http://en.wikipedia.org/wiki/Periodic_group")[#text("periodicity")]#text(". Recall that a group ")#mi("{G}")#text(" is periodic if all elements are of finite order. Jordan’s theorem with “finite” replaced by “periodic” is known as the ")#link("http://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("Jordan-Schur theorem")]#text(".")

#text("The Jordan-Schur theorem can be quickly deduced from Jordan’s theorem, and the following result of Schur:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Schur’s theorem)")]#text(" ")#metadata(none) <tao-1c88620b9ce1900b127d>#text(" Every finitely generated periodic subgroup of a general linear group ")#mi("{GL_d({\\bf C})}")#text(" is finite. (Equivalently, every periodic linear group is ")#link("http://en.wikipedia.org/wiki/Locally_finite_group")[#text("locally finite")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The question of whether ")#emph[#text("all")]#text(" finitely generated periodic subgroups (not necessarily linear in nature) were finite was known as the ")#link("http://en.wikipedia.org/wiki/Burnside's_problem")[#text("Burnside problem")]#text("; the answer was shown to be negative ")#link("http://www.ams.org/mathscinet-getitem?mr=0161852")[#text("by Golod and Shafarevich")]#text(" in 1964.")
]

#text("Let us see how Jordan’s theorem and Schur’s theorem combine via a compactness argument to form the Jordan-Schur theorem. Let ")#mi("{G}")#text(" be a periodic subgroup of ")#mi("{GL_d({\\bf C})}")#text(". Then for every finite subset ")#mi("{S}")#text(" of ")#mi("{G}")#text(", the group ")#mi("{G_S}")#text(" generated by ")#mi("{S}")#text(" is finite by Theorem ")#link(<tao-1c88620b9ce1900b127d>)[#text("2")]#text(". Applying Jordan’s theorem, ")#mi("{G_S}")#text(" contains an abelian subgroup ")#mi("{G^{\\prime}_S}")#text(" of index at most ")#mi("{C_d}")#text(".")

#text("In particular, given any finite number ")#mi("{S_1,\\ldots,S_m}")#text(" of finite subsets of ")#mi("{G}")#text(", we can find abelian subgroups ")#mi("{G^{\\prime}_{S_1},\\ldots,G^{\\prime}_{S_m}}")#text(" of ")#mi("{G_{S_1},\\ldots,G_{S_m}}")#text(" respectively such that each ")#mi("{G^{\\prime}_{S_j}}")#text(" has index at most ")#mi("{C_d}")#text(" in ")#mi("{G_{S_j}}")#text(". We claim that we may furthermore impose the compatibility condition ")#mi("{G^{\\prime}_{S_i} = G^{\\prime}_{S_j} \\cap G_{S_i}}")#text(" whenever ")#mi("{S_i \\subset S_j}")#text(". To see this, we set ")#mi("{S := S_1 \\cup \\ldots \\cup S_m}")#text(", locate an abelian subgroup ")#mi("{G^{\\prime}_S}")#text(" of ")#mi("{G_S}")#text(" of index at most ")#mi("{C_d}")#text(", and then set ")#mi("{G^{\\prime}_{S_i} := G^{\\prime}_S \\cap G_{S_i}}")#text(". As ")#mi("{G_S}")#text(" is covered by at most ")#mi("{C_d}")#text(" cosets of ")#mi("{G^{\\prime}_S}")#text(", we see that ")#mi("{G_{S_i}}")#text(" is covered by at most ")#mi("{C_d}")#text(" cosets of ")#mi("{G^{\\prime}_{S_i}}")#text(", and the claim follows.")

#text("Note that for each ")#mi("{S}")#text(", the set of possible ")#mi("{G^{\\prime}_S}")#text(" is finite, and so the product space of all configurations ")#mi("{(G^{\\prime}_S)_{S \\subset G}}")#text(", as ")#mi("{S}")#text(" ranges over finite subsets of ")#mi("{G}")#text(", is compact by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(". Using the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(", we may thus locate a subgroup ")#mi("{G^{\\prime}_S}")#text(" of ")#mi("{G_S}")#text(" of index at most ")#mi("{C_d}")#text(" for ")#emph[#text("all")]#text(" finite subsets ")#mi("{S}")#text(" of ")#mi("{G}")#text(", obeying the compatibility condition ")#mi("{G^{\\prime}_T = G^{\\prime}_S \\cap G_T}")#text(" whenever ")#mi("{T \\subset S}")#text(". If we then set ")#mi("{G^{\\prime} := \\bigcup_S G^{\\prime}_S}")#text(", where ")#mi("{S}")#text(" ranges over all finite subsets of ")#mi("{G}")#text(", we then easily verify that ")#mi("{G^{\\prime}}")#text(" is abelian and has index at most ")#mi("{C_d}")#text(" in ")#mi("{G}")#text(", as required.")

#text("Below I record a proof of Schur’s theorem, which I extracted from ")#link("http://www.ams.org/mathscinet-getitem?mr=335656")[#text("this book of Wehrfritz")]#text(". This was primarily an exercise for my own benefit, but perhaps it may be of interest to some other readers.")

#metadata(none) <tao-a1754606ef0b27b6dbdb>

#heading(level: 1)[#strong[#text(" — 1. Proofs — ")]]

#text("We begin with a lemma of Burnside. Given a vector space ")#mi("{V}")#text(", let ")#mi("{End(V)}")#text(" denote the ring of linear transformations from ")#mi("{V}")#text(" to itself.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-674b48545109f62afc7c>#text(" Let ")#mi("{V}")#text(" be a finite-dimensional complex vector space, and let ")#mi("{A}")#text(" be a complex algebra with identity in ")#mi("{End(V)}")#text(", i.e. a linear subspace of ")#mi("{End(V)}")#text(" that is closed under multiplication and contains the identity operator. Then either ")#mi("{A = End(V)}")#text(", or there exists some proper subspace ")#mi("{\\{0\\} \\subsetneq W \\subsetneq V}")#text(" which is ")#mi("{A}")#text("-invariant, i.e. ")#mi("{a W \\subset W}")#text(" for all ")#mi("{a \\in A}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose that no such proper ")#mi("{A}")#text("-invariant subspace ")#mi("{W}")#text(" exists. Then for any non-zero ")#mi("{v \\in V}")#text(", the vector space ")#mi("{Av}")#text(" must equal all of ")#mi("{V}")#text(", since it is a non-trivial ")#mi("{A}")#text("-invariant subspace. By duality, this implies that for any non-zero dual vector ")#mi("{u \\in V^*}")#text(", the vector space ")#mi("{A^* u}")#text(" must equal all of ")#mi("{V^*}")#text(".")

#text("Let ")#mi("{u, v}")#text(" be linearly independent elements of ")#mi("{V}")#text(". We claim that there exists an element ")#mi("{a}")#text(" of ")#mi("{A}")#text(" such that ")#mi("{au \\neq 0}")#text(" and ")#mi("{av = 0}")#text(". Suppose that this is not the case; then by the Hahn-Banach theorem, there exists ")#mi("{t \\in End(V)}")#text(" such that ")#mi("{au = tav}")#text(" for all ")#mi("{a \\in A}")#text(". In particular, setting ")#mi("{a=1}")#text(" we obtain ")#mi("{u=tv}")#text(", and thus ")#mi("{atv=tav}")#text(". Replacing ")#mi("{a}")#text(" by ")#mi("{ab}")#text(" for some ")#mi("{b \\in A}")#text(", we conclude that ")#mi("{tabv = abtv = atbv}")#text(", thus ")#mi("{ta-at}")#text(" annihilates all of ")#mi("{Av}")#text(". Since ")#mi("{Av = V}")#text(", we conclude that ")#mi("{at=ta}")#text(", thus ")#mi("{A}")#text(" lies in the centraliser of ")#mi("{t}")#text(". But since ")#mi("{u=tv}")#text(" and ")#mi("{u,v}")#text(" are linearly independent, ")#mi("{t}")#text(" is not a multiple of the identity, and thus by the spectral theorem, ")#mi("{t}")#text(" has at least one proper eigenspace. But this eigenspace is fixed by ")#mi("{A}")#text(", a contradiction.")

#text("Thus we can find ")#mi("{a \\in A}")#text(" such that ")#mi("{au \\neq 0}")#text(" and ")#mi("{av=0}")#text(" for any linearly independent ")#mi("{u,v}")#text(". Iterating this, we see that for any non-zero ")#mi("{u \\in V}")#text(" and any ")#mi("{0 \\leq k \\leq \\text{dim}(V)-1}")#text(", we can find ")#mi("{a \\in A}")#text(" of corank at least ")#mi("{k}")#text(" that does not annihilate ")#mi("{u}")#text(". In particular, ")#mi("{A}")#text(" contains a rank one transformation. Since ")#mi("{Av = V}")#text(" and ")#mi("{A^* u = V^*}")#text(" for all ")#mi("{v \\in V}")#text(" and ")#mi("{u \\in V^*}")#text(", this implies that ")#mi("{A}")#text(" contains ")#emph[#text("all")]#text(" rank one transformations, and hence contains all of ")#mi("{End(V)}")#text(" by linearity. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Burnside’s theorem)")]#text(" ")#metadata(none) <tao-859facc5a4c9b80ac2ee>#text(" Let ")#mi("{V}")#text(" be a complex vector space of some finite dimension ")#mi("{d}")#text(", and let ")#mi("{G}")#text(" be a subgroup of ")#mi("{GL(V)}")#text(" where every element has order at most ")#mi("{r}")#text(". Then ")#mi("{G}")#text(" is finite with cardinality ")#mi("{O_{d,r}(1)}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on dimension, assuming the claim has already been proven for smaller values of ")#mi("{d}")#text(". Let ")#mi("{A \\subset End(V)}")#text(" be the complex algebra generated by ")#mi("{G}")#text(" (or equivalently, the complex linear span of ")#mi("{G}")#text("). Suppose first that there is a proper ")#mi("{A}")#text("-invariant subspace ")#mi("{W}")#text(". Then ")#mi("{G}")#text(" projects down to ")#mi("{GL(W)}")#text(" and to ")#mi("{GL(V/W)}")#text(", and by induction hypothesis both of these projections are finite with cardinality ")#mi("{O_{d,r}(1)}")#text(". Thus there exists a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" of index ")#mi("{O_{d,r}(1)}")#text(" whose projections to ")#mi("{GL(W)}")#text(" and ")#mi("{GL(V/W)}")#text(" are trivial; in particular, all elements of ")#mi("{G^{\\prime}}")#text(" are unipotent. But as the complex numbers have zero characteristic, the only unipotent element of finite order is the identity, and so ")#mi("{G^{\\prime}}")#text(" is trivial, and the claim follows.")

#text("Hence we may assume that ")#mi("{V}")#text(" has no proper ")#mi("{A}")#text("-invariant subspace. By Lemma ")#link(<tao-674b48545109f62afc7c>)[#text("3")]#text(", ")#mi("{A}")#text(" must be all of ")#mi("{GL(V)}")#text(". In particular, one can find ")#mi("{d^2}")#text(" linearly independent elements ")#mi("{g_1,\\ldots,g_{d^2}}")#text(" of ")#mi("{G}")#text(".")

#text("For any ")#mi("{g \\in G}")#text(", the element ")#mi("{g g_i}")#text(" has order at most ")#mi("{r}")#text(", and thus all the eigenvalues of ")#mi("{g g_i}")#text(" are roots of unity of order at most ")#mi("{r}")#text(". This means that there are at most ")#mi("{O_{r,d}(1)}")#text(" possible values of the trace ")#mi("{\\text{tr}(gg_i)}")#text(", which is a linear functional of ")#mi("{g}")#text(". Letting ")#mi("{g_i}")#text(" vary among the basis ")#mi("{g_1,\\ldots,g_{d^2}}")#text(" of ")#mi("{End(V)}")#text(", we conclude that there are at most ")#mi("{O_{r,d}(1)}")#text(" possible values of ")#mi("{g}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The question of whether any finite group with ")#mi("{m}")#text(" generators in which all elements of order at most ")#mi("{r}")#text(" is necessarily of order ")#mi("{O_{m,r}(1)}")#text(" is known as the ")#emph[#text("restricted Burnside problem")]#text(", and was famously ")#link("http://www.ams.org/mathscinet-getitem?mr=1044047")[#text("solved affirmatively by Zelmanov")]#text(" in 1990. (Note however that for certain values of ")#mi("{m}")#text(" and ")#mi("{r}")#text(" it is possible for the group to be infinite. Also, while any finite group is trivially embedded in some linear group, one does not have any obvious control on the dimension of that group in terms of ")#mi("{m}")#text(" and ")#mi("{r}")#text(", so one cannot immediately solve this problem just from Corollary ")#link(<tao-859facc5a4c9b80ac2ee>)[#text("4")]#text(".)")
]

#text("To prove Schur’s theorem (Theorem ")#link(<tao-1c88620b9ce1900b127d>)[#text("2")]#text("), it thus suffices to establish the following proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" ")#metadata(none) <tao-e925260155c960671fc1>#text(" Let ")#mi("{k}")#text(" be a finitely generated extension of the field of rationals ")#mi("{{\\bf Q}}")#text(". Then every periodic element of ")#mi("{GL_d(k)}")#text(" has order at most ")#mi("{O_{d,k}(1)}")#text(".")
]

#text("Indeed, to obtain Schur’s theorem, one applies Proposition ")#link(<tao-e925260155c960671fc1>)[#text("5")]#text(" with ")#mi("{k}")#text(" equal to the field generated by the coefficients of the generators of the finitely generated periodic group ")#mi("{G}")#text(", and then applies Corollary ")#link(<tao-859facc5a4c9b80ac2ee>)[#text("4")]#text(".")

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{k}")#text(" is a finite extension of ")#mi("{{\\bf Q}}")#text(". If ")#mi("{a \\in GL_d(k)}")#text(" has period ")#mi("{n}")#text(", then the field generated by the eigenvalues of ")#mi("{a}")#text(" contains a primitive ")#mi("{n^{th}}")#text(" root of unity, and thus contains the cyclotomic field of that order. On the other hand, this field has degree ")#mi("{O_{d}(1)}")#text(" over ")#mi("{k}")#text(", and thus has degree ")#mi("{O_{d,k}(1)}")#text(" over the rationals. Thus ")#mi("{n = O_{d,k}(1)}")#text(", and the claim follows. Note that the bound on ")#mi("{n}")#text(" depends only on the degree of ")#mi("{k}")#text(", and not on ")#mi("{k}")#text(" itself.")

#text("Now we extend from the finite degree case to the finitely generated case. (The argument I came up with here, based on obtaining a “Freiman isomorphism” from the finitely generated setting to the finite degree setting, was somewhat crude; no doubt there is a more elegant “abstract nonsense” way to proceed here.) By using a ")#link("http://en.wikipedia.org/wiki/Transcendence_degree")[#text("transcendence basis")]#text(", one can write ")#mi("{k}")#text(" as a finite extension of ")#mi("{{\\bf Q}(z_1,\\ldots,z_m)}")#text(" for some algebraically independent ")#mi("{z_1,\\ldots,z_m}")#text(" over ")#mi("{{\\bf Q}}")#text(". By the primitive element theorem, one can then write ")#mi("{k = {\\bf Q}(z_1,\\ldots,z_m)(\\alpha)}")#text(" where ")#mi("{\\alpha}")#text(" is algebraic over ")#mi("{{\\bf Q}(z_1,\\ldots,z_m)}")#text(" of some degree ")#mi("{D}")#text(".")

#text("Now suppose we have an element ")#mi("{a \\in GL_d(k)}")#text(" of period ")#mi("{n}")#text(", thus ")#mi("{a,\\ldots,a^{n-1} \\neq 1}")#text(" and ")#mi("{a^n = 1}")#text(". Let ")#mi("{R}")#text(" be the ring in ")#mi("{k}")#text(" generated by the coefficients of ")#mi("{a}")#text(". We can create a ring homomorphism ")#mi("{\\phi: R \\rightarrow \\bar{k}}")#text(" to a finite extension ")#mi("{\\bar{k}}")#text(" of the rationals by mapping each ")#mi("{z_i}")#text(" to a rational number ")#mi("{q_i}")#text(", and then replace ")#mi("{\\alpha}")#text(" with a root of the polynomial formed by replacing ")#mi("{z_i}")#text(" with ")#mi("{q_i}")#text(" in the minimal polynomial of ")#mi("{\\alpha}")#text(". As long as one chooses ")#mi("{(q_1,\\ldots,q_m)}")#text(" generically (i.e. outside of a codimension one subset of ")#mi("{{\\bf Q}^m}")#text("), this operation is well-defined on ")#mi("{R}")#text(" (in that no division by zero issues arise in any of the coefficients of ")#mi("{a}")#text("). Furthermore, generically one has ")#mi("{\\phi(a),\\ldots,\\phi(a)^{n-1} \\neq 1}")#text(" and ")#mi("{\\phi(a)^n=1}")#text(", thus ")#mi("{\\phi{a}}")#text(" has period ")#mi("{n}")#text(". Furthermore, the degree of ")#mi("{\\bar{k}}")#text(" over ")#mi("{{\\bf Q}}")#text(" is at most the degree ")#mi("{D}")#text(" of ")#mi("{\\alpha}")#text(" over ")#mi("{{\\bf Q}(z_1,\\ldots,z_m)}")#text(" and is thus bounded uniformly in ")#mi("{q_1,\\ldots,q_m}")#text(". The claim now follows from the finite extension case. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-89656")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("I’m a bit happy to see you link to the Wikipedia article for the Jordan-Schur theorem, since I wrote that article. (“Hooray! I’m useful!”)")

#text("It is interesting to note how many different proofs of Jordan-Schur there are.")

#text("For example, the classical proof (found in for example Curtis and Reiner) first shows that any periodic subgroup is isomorphic to a subgroup of unitary matrices. Then, they produce various inequalities for unitary matrices involving the Frobenius norm, and use them to explicitly construct tje Jordan-Schur subgroup based on a unitary representation of the group")

#text("Quick sketch of basic steps (without proofs)")

#text("Lemma 1: If A and B are unitary matrices, and C = ABA^-1B^-1, and A commutes with C, and ||I-B||< 2 then B and A commute.")

#text("Lemma 2: If A and B are unitary matrices and C = ABA^-1B^-1 then |I-C|<=2|I-A||I-B|.")

#text("Then, using that, you can show that if one has a periodic group of unitary matrices G, with elements A and B, and A and B are near enough to the identity (say |I-A| and |I-B|<2) then A and B must in fact commute. To see consider the sequence B_i defined by B_0=B, and set B_i to be commutator of A and B_{i-1}. Note that by Theorem 2, A and B generate a finite group, but it is easy to see from Lemma 2 that |I-B_i| has to be eventually 0.")

#text("Now, we set our Jordan-Schur group to be the subgroup generated by things within 2 of the identity. A straightforward calculation now gets an explicit upper bound on the number of possible distinct coset representatives (consider the matrices as points in 2n^2 dimensions in Euclidean space, draw a small sphere around each of them and make a volume estimate).")

#text("This gives an explicit construction but a not great actual bound.")

#text("If one wants to improve this the main thing seems to be improving Lemma 2 (the best way seems to be by noting that one can actually assume that at least one of the eigenvalues of |I-A| must be fairly large and that allows one to improve the inequality). How much one can improve the inequality in 2 seems to be potentially of independent interest.")

#text("Note also that there's a pair of papers by Michael Collins that gives essentially the exact bound in for all n. His proof makes heavy use of the classification of finite simple groups and seems to be non-constructive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1af1467332c044b32fef284f74a15e5e0b92a5ab33bd6559de953169e35dba6-7016c2facdd4edbda653da370c7176b83d8130e5c4de046415caa5df1c3f6c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Zelinsky")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-89661")[#strong[#text("Joshua Zelinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("Sorry, I missed an important detail. After one has that B_i is eventually the identity for some i, one then uses Lemma 2 and inducts backwards to conclude that in fact A and B had to originally commute.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-89726")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2011")])]

#text("Dear Joshua (and many others),")

#text("Wikipedia (particularly the mathematics and physics portions) is a wonder, and makes me (almost) proud to be a human being.")

#text("Your efforts are appreciated, never fear!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d741f0600c069f3fa9b5534400eaf24912d1e1cfcb81f43dc0d8b78a44624ac5-ee6f08d15e6a312aba535b0baa497558039343097db3bb36ef9fac90361295a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-90596")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2011")])]

#text("Terry, I think you are slightly misstating the restricted Burnside problem. Free Burnside groups of exponent r with r large enough are infinite by Adian-Novikov. The restricted problem says that among all finite m-generated groups of exponent r there is a unique largest one.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d741f0600c069f3fa9b5534400eaf24912d1e1cfcb81f43dc0d8b78a44624ac5-ee6f08d15e6a312aba535b0baa497558039343097db3bb36ef9fac90361295a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-90765")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("Terry, you might want to remove the not necessarily linear since a finite group is automatically linear. Alternatively, the restricted Burnside problem can be phrased as saying that an m-generated residually finite group of exponent r is finite with order bounded by a constant depending on r and m. Then you can keep the not necessarily linear.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d741f0600c069f3fa9b5534400eaf24912d1e1cfcb81f43dc0d8b78a44624ac5-ee6f08d15e6a312aba535b0baa497558039343097db3bb36ef9fac90361295a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-90766")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("BTW, it is interesting to note that it is also true that any periodic linear semigroup is locally finite. This was proved by McNaughton and Zalcstein in 1975. The case of an irreducible linear semigroup is handled exactly as for groups (just replace semigroup by group in your proof and note that the eigenvalues of a periodic matrix are roots of unity or zero). The key difficulty is reducing to the semisimple case because it is not enough to look at the inverse image of the identity when you project to the diagonal blocks. For this reason, there are several different proofs in the literature of the semigroup case. The semigroup result has applications to automata theory in computer science.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42914e935f5b250f48f0258c94afd2d695dd898375dce6cce0a2a2669e7904c9-c519203f4f73f1e7ee6eb63ab0f124c063b5231aaa322f9f802462da3e90b232.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian")]], [#link("https://terrytao.wordpress.com/2011/10/05/the-jordan-schur-theorem/#comment-96194")[#strong[#text("Florian")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("Nice post!")

#text("Here’s a different way to finish off Prop. 5 that occurred to me when I read the above. It uses the ")#mi("p")#text("-adic numbers, but only in a very mild way, namely that ")#mi("\\mathbb{Q}_p")#text(" is uncountable and that the cyclotomic extension ")#mi("\\mathbb{Q}_p(\\zeta_{p^r})")#text(" has degree ")#mi("\\varphi(p^r)")#text(".")

#text("Any field ")#mi("k")#text(" that is finitely generated over ")#mi("\\mathbb Q")#text(" embeds in ")#mi("\\overline{\\mathbb{Q}}_p")#text(" for any prime number ")#mi("p")#text(" (using a transcendence basis). Fix one embedding for each prime ")#mi("p")#text(".")#linebreak()#text(" As ")#mi("k")#text(" is finitely generated, the compositum ")#mi("k\\cdot \\mathbb{Q}_p")#text(" is a finite extension of ")#mi("\\mathbb{Q}_p")#text(", and we can even choose the embeddings so that ")#mi("[k\\cdot \\mathbb{Q}_p : \\mathbb{Q}_p]")#text(" is bounded independent of ")#mi("p")#text(". (E.g., by sending the elements ")#mi("z_i")#text(" above to ")#mi("\\mathbb{Q}_p")#text(".)")

#text("Now the fact above together with the first part of your argument shows that if ")#mi("GL_d(k)")#text(" has an element of order ")#mi("p^r")#text(", then ")#mi("\\varphi(p^r) = O_{d, k}(1)")#text(", and we can conclude as before.")

#text("Finally, the number-theoretic fact has an elementary proof: the minimal polynomial of ")#mi("\\zeta_{p^r}-1")#text(" over ")#mi("\\mathbb Q")#text(" is irreducible by Eisenstein’s criterion applied with the prime ")#mi("p")#text(". The same criterion applies in the PID ")#mi("\\mathbb Z_p")#text(".")
]
