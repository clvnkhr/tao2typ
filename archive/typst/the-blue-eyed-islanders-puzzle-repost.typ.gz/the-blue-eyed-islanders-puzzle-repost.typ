// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/
// Converted to Typst by tao2typ: "2026-10-14T09:10:06.178388+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The blue-eyed islanders puzzle – repost", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The blue-eyed islanders puzzle – repost")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 April 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")[#text("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a (lightly edited) repost of an ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("old blog post of mine")]#text(", which had attracted over 400 comments, and as such was becoming difficult to load; I request that people wishing to comment on that puzzle use this fresh post instead. -T] ")]

#text("This is one of my favorite logic puzzles, because of the presence of two highly plausible, but contradictory, solutions to the puzzle. Resolving this apparent contradiction requires very clear thinking about the nature of knowledge; but I won’t spoil the resolution here, and will simply describe the logic puzzle and its two putative solutions. (Readers, though, are welcome to discuss solutions in the comments.)")

#heading(level: 1)[#text("— The logic puzzle —")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("There is an island upon which a tribe resides. The tribe consists of 1000 people, with various eye colours. Yet, their religion forbids them to know their own eye color, or even to discuss the topic; thus, each resident can (and does) see the eye colors of all other residents, but has no way of discovering his or her own (there are no reflective surfaces). If a tribesperson does discover his or her own eye color, then their religion compels them to commit ritual suicide at noon the following day in the village square for all to witness. All the tribespeople are highly logical and devout, and they all know that each other is also highly logical and devout (and they all know that they all know that each other is highly logical and devout, and so forth).")

#text("Of the 1000 islanders, it turns out that 100 of them have blue eyes and 900 of them have brown eyes, although the islanders are not initially aware of these statistics (each of them can of course only see 999 of the 1000 tribespeople).")

#text("One day, a blue-eyed foreigner visits to the island and wins the complete trust of the tribe.")

#text("One evening, he addresses the entire tribe to thank them for their hospitality.")

#text("However, not knowing the customs, the foreigner makes the mistake of mentioning eye color in his address, remarking “how unusual it is to see another blue-eyed person like myself in this region of the world”.")

#text("What effect, if anything, does this ")#emph[#text("faux pas")]#text(" have on the tribe?")
]

#strong[#text("Note 1")]#text(": For the purposes of this logic puzzle, “highly logical” means that any conclusion that can logically deduced from the information and observations available to an islander, will automatically be known to that islander.")

#strong[#text("Note 2:")]#text(" Bear in mind that this is a ")#emph[#text("logic")]#text(" puzzle, rather than a description of a real-world scenario. The puzzle is not to determine whether the scenario is plausible (indeed, it is extremely implausible) or whether one can find a legalistic loophole in the wording of the scenario that allows for some sort of degenerate solution; instead, the puzzle is to determine (holding to the spirit of the puzzle, and not just to the letter) which of the solutions given below (if any) are correct, and if one solution is valid, to correctly explain why the other solution is invalid. (One could also resolve the logic puzzle by showing that the assumptions of the puzzle are logically inconsistent or not well-defined. However, merely demonstrating that the assumptions of the puzzle are ")#emph[#text("highly unlikely")]#text(", as opposed to ")#emph[#text("logically impossible to satisfy")]#text(", is not sufficient to resolve the puzzle.)")

#strong[#text("Note 3")]#text(": An essentially equivalent version of the logic puzzle is ")#link("http://xkcd.com/blue_eyes.html")[#text("also given at the xkcd web site")]#text(". Many other versions of this puzzle can be found in many places; I myself heard of the puzzle as a child, though I don’t recall the precise source.")

#text("Below the fold are the two putative solutions to the logic puzzle. If you have not seen the puzzle before, I recommend you try to solve it first before reading either solution.")

#metadata(none) <tao-10fbcfff80e99f8cc484>

#heading(level: 1)[#text("— Solution 1 —")]

#text("The foreigner has no effect, because his comments do not tell the tribe anything that they do not already know (everyone in the tribe can already see that there are several blue-eyed people in their tribe).")

#heading(level: 1)[#text("— Solution 2 —")]

#text("100 days after the address, all the blue eyed people commit suicide. This is proven as a special case of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition.")]#text(" Suppose that the tribe had n blue-eyed people for some positive integer n. Then n days after the traveller’s address, all n blue-eyed people commit suicide.")
]

#strong[#text("Proof:")]#text(" We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her, and thus commits suicide on the next day. Now suppose inductively that n is larger than 1. Each blue-eyed person will reason as follows: “If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island, and so they will all commit suicide n-1 days after the traveler’s address”. But when n-1 days pass, none of the blue-eyed people do so (because at that stage they have no evidence that they themselves are blue-eyed). After nobody commits suicide on the ")#mi("(n-1)^{st}")#text(" day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the ")#mi("n^{th}")#text(" day. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("As the above two solutions give contradictory conclusions, at most one of them is correct. Which one (if any) is the correct solution, and what is the precise reason that the other solution is invalid?")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (480)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484767")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("So, this is a continuation from my post above. it is LONG. Sorry about that.")

#text("Suppose there are 14 people. All of whom are super intelligent and logical, as in all the other versions of this puzzle.")

#text("When they were put on the island (all at the same time) they were told the rules (again, all at the same time), namely that they can leave only if and when they discover their own eye-color, and that a boat would come there every morning to give them the opportunity to leave. (Plus all the usual stipulations about not discussing eye color, etc, as in all the other versions of this puzzle.)")

#text("Suppose 6 of them are blue-eyed: A, B, C, D, E, F, and 8 are brown-eyed: G, H, I, J, K, L, M, N.")

#text("(And below I will use “green” as the color each may imagine him/her self to be)")

#text("Blue A sees 5 blues (B, C, D, E, F) and 8 browns.")

#text("Blue A thinks:")#linebreak()#text(" “If I am green, then B sees 1 green (A) and 4 blues (C, D, E, F ). (And 8 browns)”")

#text("Blue A also thinks:")#linebreak()#text(" “If I am green, and if B also thinks s/he (i.e., B) is green, then B thinks that C sees 2 greens (A, B) and 3 blues (D, E, F ). (And 8 browns)”")

#text("Blue A also thinks:")#linebreak()#text(" “If I am green, and if B also thinks s/he (i.e., B) is green, and if B also thinks that C thinks s/he (i.e., C) is green, then B thinks that C thinks that D sees 3 greens (A, B, C), and 2 blues (E, F). (And 8 browns)”")

#text("Blue A also thinks:")#linebreak()#text(" “If I am green, and if B also thinks s/he (i.e., B) is green, and if B also thinks that C thinks s/he (i.e., C) is green, and if B also thinks that C thinks that D thinks s/he (i.e., D) is green, then B thinks that C thinks that D thinks that E sees 4 greens (A, B, C, D), and 1 blue (F). (And 8 browns)”")

#text("Blue A also thinks:")#linebreak()#text(" “If I am green, and if B also thinks s/he (i.e., B) is green, and if B also thinks that C thinks s/he (i.e., C) is green, and if B also thinks that C thinks that D thinks s/he (i.e., D) is green, and if B also thinks that C thinks that D thinks that E thinks that s/he (i.e., E) is green, then B also thinks that C thinks that D thinks that E thinks that F sees 5 greens (A, B, C, D, E), and no blues. (And 8 browns)”")

#text("So, yes, I agree that this kind of induction results in a hypothetical situation where someone sees NO blue eyes at all.")

#text("What happens now?")

#text("Scenario 1:")#linebreak()#text(" Although they all know that there are blue-eyed people on the island, and although they also know that everyone else on the island knows that every (real, non-hypothetical) person on the island knows there are blue-eyed people on the island, they nevertheless do not leave because no one has announced that there are blue-eyed people among them.")#linebreak()#text(" Thus every morning when the boat arrives they all look longingly at the boat operator and think “I wish that boat operator would say out loud that there is at least one blue-eyed person here. Then we could start the induction at n=1 and on day 6 we could all leave the island.”")#linebreak()#text(" But the boat operator sails away without saying anything. So they all sigh and sit and wait for the next day’s boat visit. And again the boat operator says nothing. And silently they all lament the fact that the boat operator does not announce what they already know. And so they all sit on the island and grow old and die there.")

#text("Scenario 2:")#linebreak()#text(" When they were first dropped off on the island and had the rules explained to them, they all (being super intelligent and logical) immediately imagined the possibility of Scenario 1 and thought: “If we are going to hope that the boat operator will one day make the statement that there are blue-eyed people here (something we all know anyway) we could end up on this island forever.”")

#text("So they reasoned as follows:")

#text("“Because we are all intelligent, and we know that everyone else is equally intelligent, we are just going to do without that statement.”")

#text("(***Readers, please don’t give up here, but please continue reading, since this is the crucial argument coming up***)")

#text("“In fact,” they continue to reason, “because we all know that saying the statement out loud does not tell any of us anything we don’t already know, we are going to act AS IF that statement had been made. So yes, we WILL start the induction at n=1, but we will ASSUME that the statement had already been spoken out loud.")

#text("And why, one may ask, can they confidently assume that? Here is their reasoning:")

#text("“After all, if saying that statement out loud does not tell us anything we don’t already know, how does it change the situation? Well, it allows us to consider the hypothetical situation where n=1. It is as if that hypothetical n=1 “hears” the statement and says “aha, that must be me” and leaves the island on day 1.")#linebreak()#text(" But we know that that is only an imaginary situation, that the hypothetical n=1 does not actually “hear” the statement, and so we can go ahead and consider that hypothetical situation without actually HEARING the words spoken out loud. We don’t need to hear the words, since we KNOW what they would be, and the rest takes place in our minds anyway.")

#text("So they start the induction at day 1, and at day 6 they all leave the island.")#linebreak()#text(" The remaining 8 brown-eyed people then use the same reasoning and also leave, 8 days after the blue-eyed ones left.")

#text("If anyone cares to comment I would be particularly grateful if you could address the issue of “hearing” the words spoken out loud, since what I am trying to decide is whether in most solutions of this puzzle one might be incorrectly conflating the “hearing” of words, with the “thinking” of them in a situation where they (the words) only benefit a hypothetical situation (i.e., a situation where they cannot be heard anyway).")

#text("And as I said earlier, I do not necessarily think I am right, I am working through this. I am also not a mathematician (but often wish I was when I see what fascinating things are discussed on a blog like this, for example!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484771")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("Ok, now all you need to do is go through the “Blue A thinks…” steps where the final step results in Blue A knowing for a fact he has blue eyes. (Why don’t you reduce the blue eyes to just 4 individuals…that would be easier. If it works for 4, we can assume it will work for 6.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484775")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("NMKS, your logic is flawed here. Look at the two premises of your first IF/AND step. Both premises must be true for your argument to have a chance of being valid. However if the first is true the second cannot be true. If the second is true then the first cannot be true.")

#text("Please do the “Blue A thinks” routine as you did earlier, and post the step by step results. Just use 3…A, B and C. If it works for 3 it will work for any number greater than 3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f665a5eba9e8993a5ba22b7bfce046ceda4adcd5e41efdfc63eebe3335571a1-fbb19e2950a07aa09b9ac7ff7f2100b4e62b24bb2071fe94bf61d3612b85d0d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of drph1il")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-652364")[#strong[#text("drph1il")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2022")])]

#text("The statement gives information that they don’t already know. The statement gives the information: “everyone knows that everyone knows that everyone knows that … everyone knows that there are at least 1 blue eyed person”.")

#text("If they could just hallucinate any statement, then everyone would go to the boat on day 1 and say “I have [red|turquoise|…|golden|purple] eyes” dreaming of one of the statements “there’s at least one person with [red|turquoise|…|golden|purple] eyes”.")

#text("If they are instead given the statement: “one can only have blue or brown eyes” it doesn’t help. If they heard that statement and didn’t see anyone with blue eyes they would not go. Likewise, people would think “what if b thinks that c thinks that d … that f sees 0 blues” and realize that the person would not do any action if they saw 0 blues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2025")])]

#text("I like this forumation a lot, but I don’t believe it’s correct. Let’s “spice up” the problem by saying when you get on the boat, the captain asks you eye color and kills you if you are wrong (in private to avoid giving the remaining islanders any information).")

#text("Supposed there are two people that show up on the island:")

#text("Neither has blue eyes:")#linebreak()#text("– They see no blue eyes")#linebreak()#text("– They are not able to pose the hypothetical that the oracle spoke on day 1 that someone has blue eyes")#linebreak()#text("– No one ever leaves the island")#linebreak()#text("(correct outcome)")

#text("One or has blue eyes:")#linebreak()#text("– Blue eyed person sees no blue eyes and cannot stipulate that the oracle spoke on day 1 that someone has blue eyes")#linebreak()#text("– Other person sees blue eyes and stipulates that the oracle spoke on day 1, saying someone has blye eyes")#linebreak()#text("– At this point, neither one knows their eye color.")#linebreak()#text("– Boat comes and leaves on day 1")#linebreak()#text("– Non-blue-eyed person sees the blue eyed person not leave, but does not know a) their own eye color or b) what the blue-eyed person is willing to stipulate that the oracle said, which would require knowledge of the blueness of their own eyes. They therefore cannot conclude anything about the blue-eyed person’s refusal to leave")#linebreak()#text("– Blue eyed person sees a non-blue-eyed person not leave and can conclude nothing from this.")#linebreak()#text("– No information is gained by either party when the boat leaves")#linebreak()#text("– No one ever leaves the island")#linebreak()#text("(incorrect outcome)")

#text("The outcome for 2 blue-eyes is similar because once again, although each person knows what the hypothetical oracle would say (since they both see blue eyes), neither one knows whether the other one has this knowledge (since they cannot know what the other one sees). The critical knowledge the oracle provides is not that someone has blue eyes, but that everyone knows (that everyone else knows) that someone has blue eyes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484773")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("Actually, I think it works for 3 blue-eyed people (but no fewer).")

#text("One blue-eyed person on the island. The blue-eyed person sees NO blue-eyed people. Nothing can happen without an announcement.")

#text("Two blue-eyed people on the island. Each of them sees 1 blue-eyed person, but does not know that that blue-eyed person can see a blue-eyed person. Nothing can happen without an announcement.")

#text("Three blue-eyed people on the island. Each of them sees 2 blue-eyed people, but the difference is that now each one also knows that each of those 2 can see at least 1 blue-eyed person. At this point (and with more blue-eyed people) it is no longer necessary to hear the announcement read out loud. Because in the real situation the people know all they need to know by looking around, while the more deeply nested levels are hypothetical, and only take place in each person’s mind. And it is not necessary to hear something said out loud in order for things to take place in the mind, as long as the real, non-hypothetical, levels are satisfied by the information taken in by looking.")

#text("So they can now go ahead and use induction, arguing as follows:")

#text("If there was just one blue, AND that blue knew about the existence of blues, s/he would leave on day 1.")

#text("If there were 2 blues, AND they knew about the existence of blues, they would leave on day 2.")

#text("If there were 3 blues, AND they knew about the existence of blues, which they do, they would leave on day 3.")

#text("And indeed, because no one left on day 2, each one realizes s/he must also be a blue, and all 3 leave on day 3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484776")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("NMKS, your logic is flawed here. Look at the two premises of your first step. Each premise must be true for your argument to be valid. However if the first is true the second cannot be true. If the second is true then the first cannot be true.")

#text("Please do the “Blue A thinks” routine as you did earlier, and post the step by step results. Just use 3…A, B and C. If it works for 3 it will work for any number greater than 3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484777")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("Thanks. I will do that tomorrow. Meanwhile it’s not quite clear to me what you mean by “Look at the two premises of your first IF/AND step. Both premises must be true for your argument to have a chance of being valid. However if the first is true the second cannot be true. If the second is true then the first cannot be true.”")#linebreak()#text(" Are you referring to “If there was just one blue, AND that blue knew about the existence of blues, s/he would leave on day 1.”")#linebreak()#text(" If so, I probably did not express it well, but it is just another way of saying what all the versions of this puzzle say: that if there was just one blue, and that blue did NOT know about the existence of blues (e.g. because no outsider had made the statement) then that one blue could NOT leave. I’m just removing both negatives: if that one blue KNEW about the existence of blues (e.g. because an outsider HAD made the statement) then he/she COULD leave.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484787")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("You are saying that for your scenario to work, a single blue eyed person must also know that a blue eyed person existed. However, by doing so you have introduced an impossibility into the beginning of your chain of events. For a single to know that he would have to be told.")

#text("Another aspect of this is that in your scenario you accept that three can leave only if two do not leave…and you accept that two can only leave if one does not leave. However, one could never leave because he could never know a blue eyed even existed. In your scenario the one blue eyed knows that a blue eyed exists only because you say he knows…not because the conditions of your scenario allow him to know.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484796")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("Thank you. You replied: “you have introduced an impossibility into the beginning of your chain of events. For a single to know that he would have to be told.”")

#text("My reply to that: The single blue-eyed scenario is hypothetical. The single blue-eyed person is hypothetical. How can a hypothetical person be “told” anything? How can a hypothetical person hear?")

#text("The nested process takes place in the minds of the islanders, and they know without actually having to HEAR the announcement, and can apply their knowledge to the hypothetical situations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484804")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("NMKS: I think you will determine that the nesting process you refer to will not give you a solution to the puzzle you have created. I think you will arrive at that determination when you attempt to go through the “Blue A thinks” process for the 3 blue eyed islanders….A, B and C.")

#text("Just as an aside regarding your two questions… “How can a hypothetical person be told anything? How can a hypothetical person hear?” The answer is.. “The exact same way you have your hypothetical islanders give knowledge to the hypothetical people in the hypothetical situations you say the islanders create to solve the puzzle.”")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484797")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("nmks: What you say is not quite right I’m afraid. The case of three blues is no different in principle from two blues (or even one blue).")

#text("In the case where there are 3 blues, (a) everyone knows that there are at least 2 blues (since everyone can see at least that many), and (b) everyone knows that everyone knows that there is at least one blue (since even a blue can see 2 blues, so knows that everyone knows there is at least one blue (since s/he knows that everyone can see at least that many)).")

#text("But it is NOT true that (c) everyone knows that everyone knows that everyone knows that there are some blues. For each blue (call him ‘A’) knows only that everyone knows that there is at least one blue: A knows this because he can see that everyone – even one of the blues he can see – can see at least one blue. Call the blues A can see ‘B’ and ‘C’: then A can see that B can see C and also that C can see B, so A knows that everyone knows there is at least one blue. But A doesn’t know that everyone knows that everyone knows that there is a blue – even though this is actually true – since he (A) has no reason to suppose for example that B knows that everyone knows there is a blue (for as far as A knows, he (A) might be a brown, in which case B, who doesn’t know that _he_ (B) is blue, also could not know C could know there was a blue).")

#text("(c) becomes true only when there is a public announcement _witnessed_ _by_ _all_ that there are some blues, and (c) becomes true then not because of the content of the announcement (which everyone already knows), but because of the fact of the announcement being witnessed by everyone, and by the fact that the witnessing is itself simultaneously witnessed by everyone present, and so on indefinitely (this is the crucial point).")

#text("And that is why the announcement is necessary for the required chain of inferences to be made (eventually) by each blue that s/he _is_ in fact a blue. It cannot get off the ground without it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484798")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("Thanks, leopold. Our latest posts happened almost at the same time, so you may not have seen my reply to David Ricketts immediately before your post. My reply there contains a question which I would love to see answered.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484799")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("nmks: Ii you mean the question about how a hypothetical person can be told anything and so on, I would say that the islanders are all reasoning about one another’s reasoning, asking themselves what the others could infer from what has happened or not happened. That is really all that is going on. I wonder whether you aren’t taking the idea of a hypothetical person too literally. Anyway no such thing figures in the original problem so I am not sure where it comes from (maybe someone has used the term to explain something, but I am not going to go back over the whole thread to find out where this might be!)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484826")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("NMKS: On Tuesday you said you would go through the “Blue A thinks” exercise on Wednesday. Did you decide not to do it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484830")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("Sorry, David; I found I didn’t have time to sit down and do the systematic calculation, so I just posted a few quick, additional thoughts. Will do the calculation this afternoon.")#linebreak()#text(" Meanwhile, another quick thought. A reply to your reply to my question about hypothetical:")#linebreak()#text(" Your reply:")#linebreak()#text(" Just as an aside regarding your two questions… “How can a hypothetical person be told anything? How can a hypothetical person hear?” The answer is.. “The exact same way you have your hypothetical islanders give knowledge to the hypothetical people in the hypothetical situations you say the islanders create to solve the puzzle.”")#linebreak()#text(" My reply to that:")#linebreak()#text(" Yes, the whole thing is hypothetical, but, within that, I am distinguishing between the “real” situation, which is an island with 3 blue-eyed people, and the “hypothetical” situation where those 3 blue-eyed people start imagining scenarios where there are just 1 blue-eyed person, or just 2 blue-eyed people.")

#text("Okay. back later today.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484836")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("Okay. Back again. I found that I had started writing it up for 4 blue-eyed people, not 3, so I will continue that rather than make changes. As you said, if it works for 3 it works for 4, and therefore vice versa.")

#text("Without the “announcement” that there is at least one blue-eyed person on the island:")

#text("If A thinks A is green, then A thinks that B sees 1 green (A) and 2 blues (C, D).")

#text("If A thinks A is green, and if A also thinks that B thinks B is green, then A thinks that B thinks that C sees 2 greens (A, B) and 1 blue (D).")

#text("If A thinks A is green, and if A also thinks that B thinks B is green, and if A also thinks that B thinks that C thinks C is green, then A thinks that B thinks that C thinks that D sees 3 greens (A, B, C) and zero blues.")

#text("Conclusion: without an “announcement,” it is possible for every blue to imagine a situation where another blue may think that someone does not see any blues. Hence the induction (starting with “1 blue-eyed person”) cannot begin and no one can leave the island.")

#text("HOWEVER, I put the word “announcement” in quotation marks because what I’m trying to get at, is that information can be taken in in different ways. In this case, the fact that everyone has seen, and everyone knows that everyone else has seen, the same information, is no different from everyone having heard it. So the announcement is visual instead of aural. But it is still an “announcement.”")#linebreak()#text(" (The reason the same argument will not work for fewer than 3 blue-eyed people is because in that scenario a “visual announcement” would not provide sufficient information. Everyone has to see not only 1 blue-eyed person, but everyone has to see that everyone else can see one 1-blue-eyed person. From there, they can proceed to apply that information to their mental induction process, that will get them off the island.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484838")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("NMKS: You just say they can figure it out. You do not actually demonstrate it. You say: “From there, they can proceed to apply that information to their mental induction process, that will get them off the island.” However, they cannot use the same mental induction process that was used with the aural announcement because that process was built on a base step of a single blue eyed person knowing he was the only one to exist due to the aural announcement. I was not able to solve the puzzle using the “visual announcement” method you presented. Perhaps you can. Please use your “visual announcement” and go through the “Blue A thinks” mental induction routine. Describe each step of A’s reasoning with the final step causing him to determine (know) he definitely has blue eyes. It would be easier if you just use 3 blue eyed people.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484840")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("David Ricketts: Reformulating the “If A thinks A is green, and if A also thinks that B thinks B is green etc” series would be of no use, because I am not saying that that is how A figures out that he/she has blue eyes. How he/she figures it out is by considering the situations if there were only 1 blue-eyed person, then if there were only 2, then if there were only 3. And that part is the same as what hundreds of other writers have already explained many times. I am not arguing with that part of the argument at all.")

#text("The part I am arguing with is that the islanders have to “hear” the information before the induction can begin, and I am hoping to show that SEEING it, as long as everyone also sees that everyone else sees it, is the same as hearing it.")

#text("Because: the only people that “hear” it are the ones that are on the island in the REAL situation (by that I mean the situation with 4 blue-eyed people on the island (or whatever number we decided to work with for this puzzle). Each one then takes this information and applies it IN THEIR MIND to hypothetical situations in which there are fewer than 4 blue-eyed people on the island.")

#text("That is what I am am trying to get it: They apply it IN THEIR MINDS. The “people” in the hypothetical situations – that is, situations that are created in the minds of the people in the “real situation” – did not hear anything. Only the people in the “real” situation heard it.")

#text("So how does that differ from those same “real” people SEEING it (as long as they also see that everyone else sees it) and similarly applying it in their minds to the same hypothetical situations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484842")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("Ok, it appears to me that you recognize that “hearing” provides a solution and “seeing” does not provide a solution. Your question seems to seek the reason why that’s the case. Unfortunately, the answer goes into the world of mathematics.")

#text("This puzzle is not solved by “inductive reasoning”(IR). It is solved by “mathematical induction”(MI) reasoning, which is actually a form of “deductive reasoning”(DR). IR only suggests a proof. DR and MI actually provide a proof. MI requires that a statement can be proved correct for the first of any set of natural numbers and then using induction it can also be true for the following numbers of the set. In your case the blue eyes are a set of 4. MI requires a proof for the first number of your set, which is 1. “Hearing” allows a proof for 1 whereas “seeing” does not. By hearing it the base case of “1” is established so that the inductive portion of MI can then be applied for any number of islanders greater than 1 to determine exactly how many there are and who they are. When there are enough blue eyed persons (3) for everyone to be able to think..”ok, we all know that blue eyed people exist”, there is nothing about that knowledge which allows a proof for the first person in the set. Therefore, MI cannot be used with the “seeing announcement”.")

#text("If this did not help you understand why the “seeing announcement” will not work but the “hearing announcement” will work to solve the puzzle, I suggest you search “mathematical induction” in wikipedia. Perhaps that explanation would explain it better than I have done.")

#link("https://en.wikipedia.org/wiki/Mathematical_induction")[#text("https://en.wikipedia.org/wiki/Mathematical_induction")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484855")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("Thank you, David Ricketts, for your explanations and patience. I will read the link re Mathematical Induction, look up the other kinds of induction, and also look around at what other online discussions are saying about this puzzle. I will no doubt return to it some time in the near future.")#linebreak()#text(" I have been trying on and off for several months now to find an explanation of why the statement has to be “heard.” When I first found out about the puzzle I was quickly convinced by the standard reasoning where one needs someone to say it out loud, but later, as I tried to imagine it as as a real-life situation, I started to have doubts. I wonder if this has ever been tried in practice, as an experiment, e.g., where people can leave a room instead of an island, using colored stickers, or hats, instead of eye-color, and giving everyone a starting time as well as periodic opportunities to leave the room (say every minute instead of every day).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-484887")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2017")])]

#text("nmks: you asked “how does [HEARING] differ from those same “real” people SEEING it (as long as they also see that everyone else sees it) and similarly applying it in their minds to the same hypothetical situations?” The answer lies in your parenthesis “(as long as they also see that everyone else sees it)”. The first thing to note is that “see[ing] that everyone else sees it”, is not sufficient for all the required deductions to go through. They need to be able, not only to “see that everyone else sees it” but also to see that everyone else sees that everyone else sees it, and furthermore to see that everyone else sees that everyone else sees that everyone else sees it, and so on, all the way up to 100 (if that is the number of blue-eyed islanders) nested iterations of “everyone sees that”.")

#text("Now SEEING (say) 99 blue-eyed islanders does not allow this; but HEARING (or rather WITNESSING) a public announcement in which everyone is informed of something they already know: that there is at least one blue, does allow it. And that is because the announcement is public, which allows each blue-eyed islander to deduce not only that there is at least one blue (which he knew anyway), but also that everyone knows that there is at least one blue (which he knew too, before the announcement), but also that everyone knows that everyone knows that there is at least one blue (indeed, he knew that too, before the announcement), but also…., and so on, ….. right up to (finally) that everyone knows that everyone knows that every one knows that everyone knows that … [with 100 occurrences of “everyone knows that”, and THIS he did NOT know before the announcement.")

#text("I think that even in the relatively simple case of just TWO blue-eyed islanders, you can already see that HEARING a public announcement whose content is something you already knew by looking gives you more information than merely SEEING.")

#text("(If there is exactly one blue eyed islander, he cannot see any others. Hearing that there is (at least) one allows him to deduce that there is one, and it is he. So already in this case HEARING gives you more information than SEEING, but you might well be sceptical that this very trivial case has any relevance for cases where there are more blues)")

#text("If there are exactly two blues, each one can see one blue, so he already knows there is at least one. But he doesn’t know that this other one knows there is at least one (since he doesn’t know that this other one can see one). Hearing that there is (at least) one doesn’t on the face of it tell him anything he didn’t already know, but when he hears this information, he also (and this is the key observation) witnesses that everyone else hears it, and now knows it, and this means that now he does know that the other one knows that there is at least one. There is no way he would be able to deduce this in the absence of a public announcement.")

#text("It is an instructive exercise to do this for the case of 3 blues. I wouldn’t try to do it for more than that though: if the point hasn’t been grasped by then, it will only become more obscure as you add more blues into the mix.")

#text("Remember that all the islanders are supposed to be perfect reasoners. That is essential for the puzzle to work, so trying it out “in practice” as you suggest would probably not be very illuminating (well, it might illuminate human psychology of course, but not the logic of what is going on here…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485004")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2017")])]

#text("Thanks, leopold. I am going to hibernate for a while because I have a few extremely busy few weeks coming up. David Ricketts had provided a link to an article re Mathematical Induction (as opposed to other inductions) that I will read and ponder when I get a bit more time. As of now I am still unconvinced that hearing the announcement results in a different outcome from seeing it (as long as everyone sees that everyone else sees the same). But maybe I’ll change my mind after reading the mathematical induction articles. May be it has something to do with real and unreal situations. (I know math has all kinds of mysterious (to an non-math person) concepts, such as imaginary numbers, which I’m sure have their uses, and this puzzle may fall into one of those categories. I may be thinking too much in terms of real-life situations.)")

#text("Meanwhile, if you wish, maybe you would like to consider the following two (real-life) scenarios, and say which one is more likely to happen, given that all the people are highly intelligent, logical, and all want to leave the island. And knowing that when they were all put on the island. they had the rules explained to them, in a public announcement, (all at the same time), namely that they can only leave when they know their eye color..")

#text("Scenario 1:")#linebreak()#text(" Every morning when the boat arrives they all look longingly at the boat operator and think “I wish that boat operator would just say out loud that there is at least one blue-eyed person here. Then we could start the induction by considering n=1, n=2, etc. and eventually get off this island.”")#linebreak()#text(" But the boat operator sails away without saying anything. Same thing every day. And so they all sit on the island and grow old and die there.")

#text("Scenario 2:")#linebreak()#text(" As soon as they were put on the island they all looked at everyone else’s eyes, summed up the situation, and thought: if we wait around for someone to tell us what we already know we could end up sitting here forever. Since the only thing missing is a public statement that there are blue-eyed people here, we will proceed as if that statement had been spoken. So we can start the induction by considering n=1, n=2, etc., starting the next morning (which will be the first time the boat returns) and eventually we will get off this island.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485021")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("NMKS: Your comment to Leopold got me thinking some more about the difference between hearing and seeing under your scenario.")

#text("Upon hearing the rules explained but not being told that a blue eyed person exists, they all know it is logical for every one of them to think that he himself might not have blue eyes. Once they are told by the outsider that a blue eyed person exists it is no longer logical for everyone to think that they “ALL” might think they don’t have blue eyes.")

#text("The difference I describe above is critical for the Mathematical Induction process to be used to allow them to leave the island.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd355f89eabe8e858afc8ffffdea8eabd57b3c42ab01963ef718ec454d0b333e-ffc26dfc1f80edc741e217bb2245f5a5ddc1a8d9de2d2d79760ef95bbe73fff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darby L")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-633117")[#strong[#text("Darby L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2021")])]

#text("The second scenario makes the most sense, not just to me, but presumably the perfect logicians on the island. If an announcement were made, it would be during the countdown period that had already begun, and it would be ignored. After that, the outsider would find no one to speak to. The only way the announcement would be helpful is if the islanders had been there without the knowledge or desire to leave. It seems that they could even arrive at different times, and as soon as an individual learns of the rules, and counts the others (who are surely in on the rules, they can count to that number of days (if everyone is perfectly accurate). Even if they pad the count with 10% extra days, they can be fairly sure that everyone will leave when enough time has passed. (In My Estimation)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd355f89eabe8e858afc8ffffdea8eabd57b3c42ab01963ef718ec454d0b333e-ffc26dfc1f80edc741e217bb2245f5a5ddc1a8d9de2d2d79760ef95bbe73fff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darby L")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-633118")[#strong[#text("Darby L")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2021")])]

#text("Sorry about mixing up the various versions of this, but hopefully the logic fits this “negative” version, even though I doubt they would be putting in the same effort for a payoff of death.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485031")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("Only have time for a quick note. My whole argument hinges on one thing: that the islanders will ALL think: “Since the only thing missing is a public statement that there are blue-eyed people here, we will proceed as if that statement had been spoken.” Maybe that seems illogical and maybe in a purely theoretical system that would not happen (as I might find out after reading more) But (meanwhile) wouldn’t it? The premise in the original puzzle was that everyone is logical and knows that everyone else is logical and knows that everyone else will come up with the most logical solution.Would not this be the most logical solution in this case?")

#text("This is why I prefer to deal with the version where the people want to leave the island, rather than the one where they commit ritual suicide. Because although the reasoning SHOULD be the same, I think it may somehow be different for the problem-solver if they think about how to find a way out of a bad situation (how not to get stuck on the island), rather than if they think about how a bad situation may arise (ritual suicide). Purely psychological; not affecting the logic within the problem, but MAYBE affecting the way a problem-solver might approach the problem, or at least be willing to consider other possibilities. Don’t know…")

#text("(Note that I am NOT introducing the kind of situations that one finds some people proposing whenever someone posts a logical problem, the kind that all amount to ignoring, or changing the original parameters. (I mean things like “but what if someone talks in their sleep about eye color” or such…) No. I think I’ve learned enough about logic problems to know that I must stick to the original parameters.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485036")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("NMKS: You asked if it would be logical for them to think.. “Since the only thing missing is a public statement that there are blue-eyed people here, we will proceed as if that statement had been spoken.” Yes, I think they would think that. Next, it would be logical, I think, for them to all think…”OK…now how do we all proceed to a solution.” I believe you would say..”They all start counting days.” However, why are they counting days? The answer would be they are waiting to see if other blue eyed people they can see “do something” or “don’t do something”. Seeing the “something that is done” or seeing the “something that is not done” on a certain day during the counting process will tell each of the blue eyed people in an instant that they do have blue eyes. Unfortunately, since they were not told that a blue eyed person existed it was NOT EVEN POSSIBLE for the end of day 1 to have any meaning…therefore, day 2 could never have any meaning because day 1 could not have any meaning…nor day 3…nor day 4…etc. They would of course figure this out at the beginning and therefore not even begin the counting process because they would all know that their counting of days could never have any meaning to them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485038")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("David Ricketts: you seem to agree now that the people would think: “Since the only thing missing is a public statement that there are blue-eyed people here, we will proceed as if that statement had been spoken.” But that, I think, was the only hurdle, because “proceeding as if the statement had been spoken” means accepting that in the hypothetical situation where n=1, that solitary “1” would know about the existence of blue-eyed people (just as if the statement had been spoken.)")

#text("(Another thing I find interesting, though unrelated to the paragraph above, is that we are dealing with a third situation, not proposed by the original poster. Prof Tao had originally mentioned 2 possible outcomes, one where all commit suicide, the other where nothing happens. But I am suggesting, and we are discussing, a situation where something DOES happen, but without the announcement.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485042")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("Yes, I do agree it would be logical to think that because as you set the scenario… (1.) they all want to leave the island and (2.) an offer had been made to all of them at the same time by the boat operator. However, that’s where it ends because they would all quickly conclude they could not figure out an answer based on their common knowledge and they would then not even start the counting process.")

#text("You say that was the only hurdle…that is not correct…the other hurdle is to actually figure out who does and who does not have blue eyes. This is something you have never explained which is why I asked you long ago to go through the “Blue A thinks” process to show the “seeing” solution in detail…but you never did it. You say you believe they can figure it out by “seeing” as well as by “hearing”. If they can, you should be able to show it.")

#text("I know I am being presumptuous but I believe you have tried to figure out a “seeing” solution and failed in your attempt. It defies reason to believe you have not tried. I suspect you have accepted that “seeing” does not work. I think your only difficulty at this time is that you have not been able to figure out why it does not work…because it seems to you that it should work.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485044")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("(Don’t know why my last comment showed up as anonymous) Anyway, To proceed “as if the statement had been spoken” means to accept that in the hypothetical situation where there is only 1 blue-eyed person, that solitary blue-eyed person would know about the existence of blue-eyed people (just as he/she would if the statement had been spoken). I think that part should be clear.")

#text("In which case, if there are 4 blue-eyed people:")

#text("Every blue-eyed person will reason that if there was only 1 blue-eyed person on the island, and that person knew of the existence of blue-eyed people on the island (because of the “as if” ) that one blue-eyed person would leave when the boat arrives on day 1. But no one leaves on Day 1. Well, no-one expected anyone to leave on day 1 anyway, since they all know that n=1 is only a hypothetical situation.")

#text("Similarly with the next day: Everyone knows that if there were only 2 blue-eyed people, those 2 would leave on Day 2. (But again, no-one expects anyone to leave on day 2, since they all know that n=2 is also only a hypothetical situation.)")

#text("Third day. This is different because all the blue-eyed people can see 3 blue-eyed people. They know that if those 3 are the only blue-eyed people, they (those 3) will leave on Day 3. If they don’t leave on day 3, every blue-eyed person will think: they did not leave means they must be able to see another blue-eyed person. But who? I can only see 3 blues and lots of browns. Aha, I must be the other blue-eyed person. And so all 4 leave on Day 4.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485045")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("NMKS: Yes, each of them can see the other 3 blue eyed people(BEP)…however, none of them knows that the others can see 3 BEP. Take “A” for example, he knows he can see 3 BEP but he knows he might not have blue eyes. If that’s the case then he knows the other 3 BEP’s can only see 2 BEP.")

#text("This is where the flaw in your reasoning shows up. You stated…”no-one expects anyone to leave on day 2, since they all know that n=2 is also only a hypothetical situation”. n=2 is hypothetical to them “individually” but n=2 is not hypothetical “collectively”. Blue A knows n=2 is a hypothetical for him but he also knows he might not have blue eyes so Blue A knows that for Blue B n=2 is a real possibility, not a hypothetical possibility. In A’s mind n=2 is a real possibility for C and D as well. For each one of them n=2 is a real possibility for the other 3. So, collectively n=2 is not hypothetical.")

#text("Again, I recommend you go through the “Blue A thinks” routine from beginning to end with the end being Blue A knowing for a fact that he has blue eyes. Solve it for Blue A and you solve it for all of them since they will all be thinking the same thing from their own perspective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-485046")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("Thanks. I really have to leave this for a few weeks as I don’t have time at the moment to work through that again.")#linebreak()#text(" I also first need to read up about Mathematical Induction, because there is something that I am missing. See, you wrote: “but I believe you have tried to figure out a “seeing” solution and failed in your attempt…I suspect you have accepted that “seeing” does not work. I think your only difficulty at this time is that you have not been able to figure out why it does not work…because it seems to you that it should work.”")#linebreak()#text(" That’s not quite the way it is because at this point I think it might work.")

#text("What I don’t understand is how you imagine the information getting transferred to the hypothetical situations. If the hypothetical situations (where n is less than 4) take place in the people’s minds (which obviously they do) then it should not make a difference whether the people doing those mental calculations came upon the information by seeing it or by hearing it (as long as they saw that everyone else saw). They apply the information that they know (and know that everyone knows) to the hypothetical situations (those nested situations where everyone knows that everyone knows that everyone knows that everyone knows….)")

#text("But I’ll stop here. I must read those articles you mentioned and catch up on other work before returning to this blog.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7550131d7ae9a1fb21c1d6961c9740f4ff4e5dd8420e57103000bd5a728911ff-c76459d9ffe266c6fd9addaf3788da242c4f49c4add79861db3e462f28319126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Buzzard")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492002")[#strong[#text("Kevin Buzzard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Terry — I asked this question to my 1st year undergraduate students in their “introduction to proof” course at Imperial College. As an optional part of that course the students can choose to answer the questions in Lean, some formal proof verification software. My student Chris Hughes formalised the question and then proved the formalised version in Lean. His proof is here: ")#link("https://github.com/kbuzzard/xena/blob/21122ecb4ec9bb2a9d80a3a986b7c3d0fc3f089c/M1F/2017-18/Example_Sheet_05/blue_eyed_islander#L2")[#text("https://github.com/kbuzzard/xena/blob/21122ecb4ec9bb2a9d80a3a986b7c3d0fc3f089c/M1F/2017-18/Example_Sheet_05/blue_eyed_islander#L2")]

#text("Kevin")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63aa2e47949db7c1d37b4be50673e4c3a31afee3c160167e537747188b5b01ea-e375e21113b6e26d7f8b775acc1d2d5ea26e0e5b9e52965204827107a7a43f1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492013")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Kevin, thank you so much for re-opening this discussion. I posted my thoughts on the blue-eyed puzzle here a couple of times and have received some replies and had nice discussions, but this is an opportunity to post again and see if anyone else will reply. I am sorry, I cannot understand the mathematical symbols that many people use, including those is your post, so mine is in plain English. And the premise of the puzzle is slightly different, though should not alter the reasoning. Okay, here goes:")

#text("An island (which we’ll call Island A) has 100 blue-eyed people and 1000 brown-eyed people. That means some of them see 99 blues and 1000 browns, and some see 100 blues and 999 browns. They are forbidden to discuss eye-color.")

#text("They all want to get off the island. They all know that everyone else also wants to get off the island. But they have no means of doing so.")

#text("One day a boatman arrives and says they can get off the island if and when they correctly name their own eye color. He says the boat will come back at the same time every morning starting tomorrow (which will count as Day One, i.e., the first day when someone could leave). Each time the boat arrives they will have a chance to say their eye color and leave the island if they are correct. (If they get it wrong they stay on the island forever).")#linebreak()#text(" However, he does NOT say anything else about eye color, and, in fact, never does, on any of his visits.")

#text("Now, many people in this discussion group (and other groups) have argued that an announcement such as “I see someone with blue eyes” is necessary before anyone can guess their eye color. Which means that, because the boatman did not make such a statement (and in fact never does), the islanders will remain on the island forever. Every time the boat arrives they think “Oh I wish that boatman would just say something like “I see someone with blue eyes,” which we already know anyway, so that we can start leaving.” But, because he never does, they never leave.")

#text("Now, suppose the boatman HAD said that he sees someone with blue eyes. What would happen? The same people, in this discussion group, argue that the whole process, (as discussed by MANY people already, so I don’t have to repeat it here) will begin, and on day 100 all 100 blue-eyed people will leave the island. (I am NOT going into the fate of the brown-eyed people in this discussion. One thing at a time. The fact is that those who think an announcement is necessary, argue that if such an announcement is made, all 100 blues would leave on day 100)")

#text("Are we agreed this far? If yes, I can proceed.")

#text("Imagine an identical situation on a different island, which we’ll call Island B. The islanders here are also all perfectly logical and know that everyone else is too, and also know that everyone wants to get off the island. Meaning, they all know that if the boatman had said “I see someone with blue eyes,” the blues would all leave on day 100")

#text("So each islander on Island B thinks (and knows that everyone else also thinks this because they are all logical and all want to get off the island) “If all is needed for us to start leaving the island is for that boatman to announce that someone has blue eyes, which we all already know, then we will simply act AS IF he had said it.” And on day 100 all the blue-eyed islanders leave.")

#text("Why am I not bothering with the usual argument that goes something like “but until the announcement is made, they don’t know that everyone else knows that everyone else knows that everyone else knows, etc, etc, etc, right down to one solitary islander, i.e., n=1”? Because those are hypothetical situations, and hypothetical islanders will not hear the statement anyway, because hypothetical people cannot hear. The only ones that hear the boatman’s statement are the real islanders, and they already know the content of the statement without it being spoken.")

#text("Now, MAYBE such hypothetical scenarios are necessary in the realm of computer programming or whatever, I don’t know because I am not a computer specialist, or a mathematician, or a scientist. And maybe that’s the kind of situation that is implied by the statement “all the islanders are logical.” In which case I take everything back. But, looking at the problem as presented, and taking “logical” in its everyday use, I still say the boatman’s announcement is not needed for the islanders to get off the island.")

#text("(Note that although I say I take the term “logical” in its everyday sense, I am still adhering to all the parameters of the original puzzle, i.e., I am not introducing any “derailers” that one sees now and then, such as “but couldn’t they build their own boat,” or anything of the sort.)")

#text("Comments would be much appreciated. But please not the kind that start “imagine if n=1” etc, because I have taken that into account. And I know that in situation n =1, or n =2, or maybe even n =3, this does not work, but I am discussing the original given situation where there are 100 blues and 1000 browns. All I am saying that if the process works when the boatman speaks, it also works when the boatman does not speak, because the only people that hear the boatman’s words are the real people, not the hypothetical people, and they already know they information that he conveys. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492019")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("@nmks,")

#text("(1) There are ways to formalize “perfectly logical” so that the people on Island B do not think it is logical to act as if, contrary to reality, the boatman had made the announcement of blue eyes.")

#text("(2) There are ways to formalize “perfectly logical” so that they do pretend they all heard a public announcement.")

#text("(3) There are ways to formalize “perfectly logical” so that no (consistent) islander could have this property while simultaneously knowing they have this property.")

#text("I’m personally in the camp of (3).")

#text("If we allow that the islanders are only “perfectly logical” in a very limited sphere of knowledge and logic, I’m in camp (1). Apparently, this is the type of situation that Kevin’s student Chris was able to formalize in Lean.")

#text("I find it hard to picture a world where it is *logical*, rather than merely *practical*, to pretend something happened in order to achieve an end. But that’s the thing about these puzzles; they allow room for interpretation! If you interpret that sort of behavior as logical, then indeed the islanders might leave after 100 days with or without the announcement. However, they might also just leave immediately; depending on your conception of “perfect logic”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63aa2e47949db7c1d37b4be50673e4c3a31afee3c160167e537747188b5b01ea-e375e21113b6e26d7f8b775acc1d2d5ea26e0e5b9e52965204827107a7a43f1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492030")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Pace Nieslen, thank you! I think this is the explanation I have been waiting for. It seems that it’s not my reasoning that’s at fault, but the fact that we are using “logical” in different ways. See, to me, as a lay person, i.e., not a mathematician, the meaning would be closer to the adjective “practical” that you mentioned above.")

#text("That is also why I changed the premise from the islanders having to commit suicide if they know their eye color, to them wanting to leave the island but only being able to to do so if they know their eye color. I realize that this is a tricky distinction because, of course, if a sequence of events if inevitable, the islanders would find it, regardless of their fate. I changed it because I thought it might prompt some people on this group to see it from my perspective. But I began to suspect that the reason for all the disagreements was in my understanding of the term “logical” because surely so many mathematicians would know what they are talking about!!! (as I said, maybe in computer programming or whatever, such hypothetical situations are acceptable and necessary)")

#text("I hope a few others might chime on on this. I would be interested to read some more comments. But, as for myself, I feel I can now put this problem to rest. My reasoning was fine within my use of the term “logical” which is not the same use that mathematicians/logicians use (no puns intended). Thank you for pointing this out so clearly. (This problem had been in my head for ages – I had even envisaged testing the hypothesis by having people at a dinner table with colored dots on their forehead and not being able to start eating until they guess their color.")

#text("I may later on ponder the last part of your post – namely would they all leave at once, or wait 100 days. I can see there’s something there that requires thinking through, but I will do that later. For now, I’m perfectly at ease. What a great feeling! Thank you again!!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492025")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Nmks: They are forbidden to ever say anything about eye color, therefore they would never be able to tell the boatman their eye color. Let’s assume you modify your scenario to eliminate that problem. They all immediately know they are lacking sufficient information to ever determine their own eye color. However, they all know that over 90% of the islanders have brown eyes. Therefore, they each immediately tell the boatman that they have brown eyes. 1000 brown eyed people leave the island and 100 blue eyed people stay forever.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492031")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("David Ricketts, Yes, they could do that. But it would not help the blue ones and they also badly want to leave the island. I just replied to another poster that I am now very happy because I understand where the problem was. I mean, if everyone on this discussion group was on an island and wanted to leave, I’m sure we would all use my reasoning. That’s “logical” in the sense of “practical.” But apparently it’s not the way the term is used by many specialists, Your previous replies (a few months earlier) had got me thinking that the problem (i.e. problem of why we couldn’t agree) must lie somewhere in realm of what the term “logical” means to different people. So thank you, too, and everyone else who had replied to me in the past. It was a combination of the information gleaned from everyone’s posts that has resolved this problem for me. Best wishes to all! Math is great!!! (spoken by a non-mathematician!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492033")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("David Ricketts, Yes, they could do that. But it would not help the blue ones and they also badly want to leave the island. I just replied to another poster that I am now very happy because I understand where the problem was. I mean, if everyone on this discussion group was on an island and wanted to leave, I’m sure we would all use my reasoning. That’s “logical” in the sense of “practical.” But apparently it’s not the way the term is used by many specialists, Your previous replies (a few months earlier) had got me thinking that the problem (i.e. problem of why we couldn’t agree) must lie somewhere in realm of what the term “logical” means to different people. So thank you, too, and everyone else who had replied to me in the past. It was a combination of the information gleaned from everyone’s posts that has resolved this problem for me. Best wishes to all! Math is great!!! (spoken by a non-mathematician!)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492036")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Nmks: From my own “practical” point of view I think what I said would actually happen. Practically, each individual knows he only has three options that make any sense at all since under your scenario there is no way to determine their own eye color using any kind of mathematical “logic”. 1. Do nothing in which case he does not leave but still has a chance to leave if a future opportunity ever arises. 2. Tell the boatman he has blue eyes and hopes he is correct. 3. Tell the boatman he has brown eyes and hopes he is correct. I think they would all pick number 3. Since they don’t know another opportunity will ever come but everyone does know there is a very high probability they have brown eyes. (P.S.-I’m glad you got an answer that helped you.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf3ea8f43e6d18518581a8b0c70a25ad0fcf69115605f9be4fd41a6d352085bc-5cfe1eb9188e0239fbe63102247d260aff986ee0cfa34e6d83051adae6c10f4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Recent student successes | Xena")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492004")[#strong[#text("Recent student successes | Xena")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("[…] problem! The question is here (M1F sheet 5) (question 6) (and also on Terry Tao’s blog here), and Chris’ solution is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7550131d7ae9a1fb21c1d6961c9740f4ff4e5dd8420e57103000bd5a728911ff-c76459d9ffe266c6fd9addaf3788da242c4f49c4add79861db3e462f28319126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xenaproject")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-492146")[#strong[#text("xenaproject")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("Hi. Let me just make one comment about this discussion. When solving a mathematics problem using formal proof verification software, there is a very clear division of the task into two sub-tasks. The first sub-task is to change the mathematics problem into a computer programming problem written in the language of the software. And then the second sub-task is to write more code in the language of the software, which solves the computer programming problem.")

#text("For many maths problems of the kind which we give to undergraduates, doing the first sub-task is typically very easy. The computer program already has stuff like “the complex numbers”, and so if the original problem is, for example, to prove that the complex conjugate of a+b equals the sum of the complex conjugate of a and the complex conjugate of b, there is a completely unambiguous translation of this into the computer programming language, and the nice thing about modern proof verification software is that the translation of the problem *actually looks like mathematics still* — it literally becomes the statement “forall a b : complex_numbers, complex_conjugate(a+b)=complex_conjugate(a)+complex_conjugate(b)”. Actually it looks even better than that nowadays, because the software I’m using allows unicode, so e.g. instead of complex_numbers we really write a blackboard bold C.")

#text("However the islander question is more logically complicated, and so one has to really consider whether the translation into the computer programming problem actually correctly conveys the ideas which are either explicit or perhaps even implicit in the original LaTeX human-readable problem.")

#text("I believe that Terry’s comments on the problem in his post do an extremely good job of clarifying any ambiguities in this particular problem. However I am prepared to accept that in this particular instance some people may still believe that there is still a certain amount of subjectivity involved.")

#text("As for the computer code however, it runs, so I believe it.")

#text("Kevin")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/701e0dd365a2159758c78de9a68128dcfbfadeb2dd786bb7700f29cfac019738-9523a40212de360ab6ff5c8f5227a7c3c39f091522f2f53eddadc4cd5beb0126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ade...")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493697")[#strong[#text("Ade...")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("From my point of view, concerning the blue-island puzzle, I think nobody will commit suicide. They cannot because the foreigner was the only one that discussed eye color and mentioned his one eye color. He did not mention anybody in particular who had the same eye color as his. After the foreigner’s comment they can only have the idea that some people have blue eyes–even though they already know that–and cannot discuss about it neither can they know theirs. If anybody thus commits suicide, it means somebody, one way, has broken the religious law because I will ask the person,” how did you know your eye color?”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493711")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("Ade… All the blue eyed islanders can, and will, determine that they have blue eyes. They will all determine it at the same moment without any word being spoken by any person. Therefore, they will all commit suicide at the same time because their religion requires it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("I quote you, “They will all determine it at the same moment without any word being spoken by any person. ” How? When? The only way they can know is if they run some numbers with the data they have–the 100 blue and 900 brown which I think they could have done before the visitor announced the presence of blue-eyed people. Hence, it is their choice to run the numbers on the data. The puzzle doesn’t state that they are curious to know their")#linebreak()#text(" Eye color. Hence, we can’t say whether they will do the calculations or not. Besides if they all start to commit suicide after the foreigner’s address, and they are curious to know their eye colors , they might not be as devout as we think because they would have known their eye colors before the visitor came.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/701e0dd365a2159758c78de9a68128dcfbfadeb2dd786bb7700f29cfac019738-9523a40212de360ab6ff5c8f5227a7c3c39f091522f2f53eddadc4cd5beb0126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ade...")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493717")[#strong[#text("Ade...")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("The reply above was written by Ade…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493719")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("The rules of the game says they are all devout and perfectly logical. The moment the visitor says he sees a blue eyed islander, the clock starts for all the islanders. Before the visitor spoke they never had a moment in time where the clock would start for all of them. To figure out who has blue eyes the common start date of the clock is all they needed. Being devout, the blue eyed islanders all commit suicide as required by their religion on the day they all figure out their eye color. The rest of the islanders live happily ever after…after the appropriate time of grief, of course.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687597")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("This is the correct answer. The induction doesn’t make sense. Both the blue eyed and brown eyed people will be thinking the same thing on the n-1 day. The only way they can determine their eye color is if the visitor tells them exactly how many blue eyes there are (or brown).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47a2402d4ac011045684bf63f88b31ca350512f04adf715ab7806235babd30e-bca7637b9db40922a68cb31a4df5495bb8e60ab5076d3ddcc36f7545ec031727.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of manuelshanghai")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493720")[#strong[#text("manuelshanghai")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2018")])]

#text("Solution 1 is correct. This is because a tribesperson is assumed to have no way of discovering his or her own eyecolor. As a consequence, it can never come to such a ritual suicide caused by eye color discovery.")

#text("I remind that, among others, the following assumptions are made in the puzzle:")

#text("a) “[…] each resident can (and does) see the eye colors of all other residents, but has no way of discovering his or her own (there are no reflective surfaces).”")#linebreak()#text(" b) “If a tribesperson does discover his or her own eye color, then[…]”")

#text("Assumption b) does not contradict to a) but, a) makes b) irrelevant. Solution 2 is wrong because it contratics to a) if the mentioned suicide in solution 2 is caused by those island people discovering their eyecolor(If they commit suicide for other reasons, then maybe solution 1 and 2 are not necessarily disjoint -but this kind of argument is maybe already of legalistic type and seems not to be in the interest of the puzzle presenter).")

#text("——")#linebreak()#text(" People might answer that the bracket “(there are no reflective surfaces)” means that a) only prohibits discovering by checking in a mirror-like surface. However, I see such discussions as to be not in the spirit of the puzzle because then a lot of opinion based interpretations or “legal” arguments arise. For example one could then reply “if somebody tells you such a fact, you still need to see it in order to know that it is really true and the guy didn’t lie to you or has a color weakness” etc. etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493726")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2018")])]

#text("a) was true until the visitor interjected his comments. His comments made a) no longer true because he started a clock ticking….and since all the islanders are perfectly logical, through the use of mathematical induction, the knowledge of their eye color was forced upon all the blue eyed islanders…and they all died.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-493729")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2018")])]

#text("David Ricketts is absolutely correct. And for newcomers to this problem – if you scroll up, there are numerous discussions, many of which describe the induction process in minute detail. Very interesting reading, with arguments both pro and con.")

#text("But, for another take on this problem, with a slightly altered scenario (namely that instead of ritual suicide, the islanders get a chance to leave the island (which they all want to do) if/when they discover their eye color) see my posts (e.g. by nmks on 2 February, 2018 at 10:46 am. In that one I do not explain the induction process, since that has been done so many times, but I go on from there with my other arguments). Part of my reason for changing it from ritual suicide to getting off the island is that the latter scenario gives the islanders an incentive for calculating their eye-color and also has well-defined sign posts (time posts?) each day during which they could leave (the boatman arriving). Sometimes this helps to visualize the whole thing.")

#text("My argument was that they would leave the island without the eye-color announcement as long as they had another announcement to start the clock ticking (again, this version gives the problem such a concrete sign post, whereas simply “living on the island” does not).")#linebreak()#text(" However, as David Rickets and Pace Nielsen and others have explained to me, it won’t work in the world of mathematics, – the flaw in my argument being my interpretation of the term Logical, which they use in a mathematical sense whereas I used it more in the sense of intelligent and practical. (And fair enough, I’m not a scientist, but I can see that when using math to design a machine, or computer app, etc, one needs that kind of logic that extends even into hypothetical situations.)")

#text("In my island solution, I just skipped those hypothetical situations. Acting AS IF the boatman HAD mentioned eye color, is not as crazy as it sounds. It is just fast forwarding over the first few days (like in chess where there are standard openings, people might decide to skip the first few moves of a standard opening and begin at, say, move 6 or whatever)")

#text("So glad this problem has been reopened…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ade87fdaf4689851e3562320b5723127ffddd416f16fea66294c6be18ab4edc-b73798ca457abf795f3df0efa2aeb636e7ca9b09dcdb5c7eb11fbe7ebcc39112.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hongbo Li")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-497167")[#strong[#text("Hongbo Li")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("If I just change the situation a bit by adding one more assumption: people will do anything to survive only with the exception for being compelled to commit suicide by the religion. This is not a terrible assumption and it will completely alter the outcome: exactly one blue eyed tribe person will die (by suicide or homicide).")

#text("Reason:")

#text("If there are only one blue eyed person, it is automatically true because he will always die one way or the other.")

#text("If there are two blue eyed people, people will kill one of them (the other one will be able to live because it suffices to killing only one blue eyed. Killing more than one is unnecessary). The surviving blue eyed person will never know his own eye color. So is the same for the other brown eyed people.")

#text("If there are three blued eye people, which is a more interesting case. People still only need to kill one of them. The two surviving blue eyed people (let’s say, Alice and Bob) will be waiting for each other to commit suicide, but none of them will commit suicide. By symmetry, if they should commit suicide, they should do it at the same time. But they can’t do it at the same time because they have to wait for each other’s action to have enough information to know their own eye color.")

#text("This pattern should be able to turn into a prove with some minor effort.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687598")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("The induction will fail. It works for n=1 because then the statement informs the sole blued person what their eye color is. For n=2, they each see one person with blue eyes, and nothing ever happens.")

#text("If they know the exact number of blue eyes, then the moment they’re told that they can deduce if they’re blue / brown.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-691972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2026")])]

#text("It actually works for n = 2, the blue eye will hope that the other blue eye die on day 2; when it didn’t happen, they both know that they were wrong, so they will both die on the next day.")

#text("For n ≥ 3 however, the induction fails, because everyone already knows that the other blue eye at least sees blue eye, there is no new information, and there is no one seeing only 1 blue eye(which the induction assumes)")

#text("There is possibly new information only when someone tells them there are more blue eyes than they actually see, or what they hope that the other blue eye is seeing (so hoping that the others will die the next day lol)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d45327b2efe8922ac8816be687f8e863f2c7129b85819092247101cbb3a742-a9a1a2fc527bbaf6f520026f25fc0d07c9faccc16845ac3cb1511b57fa1ec525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geepee")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-501740")[#strong[#text("geepee")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2018")])]

#text("Both the answers are correct, and they are correct contingent on a single fact- the discovery of ‘n’! Till the time n is unknown, solution 1 holds and the moment n gets ‘discovered’, solution 2 comes in action. Talk about ignorance being bliss!!")#linebreak()#text(" Various shades of solutions are possible on the basis ‘legalistic’ arguments like eye color is spectrum or boolean and I actually could see most of them getting disproved if one were to focus on one trait of the individuals and the population as a whole- individuals are highly logical and the population is existing. This sets pretty rigourous boundaries for the solution.")#linebreak()#text(" What I love is that this serves almost like a mythological/ religious allegory for the pitfalls of discrimination.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf3ea8f43e6d18518581a8b0c70a25ad0fcf69115605f9be4fd41a6d352085bc-5cfe1eb9188e0239fbe63102247d260aff986ee0cfa34e6d83051adae6c10f4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blue-eyed islanders (guest post) | Xena")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-507394")[#strong[#text("Blue-eyed islanders (guest post) | Xena")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2018")])]

#text("[…] thought it was cute, but then forgot about it. Richard Thomas then ran into it in an old post on Terry Tao’s blog and suggested I put it onto an M1F example sheet. I did this, and knocked up a solution. Rohan […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5cf4d00fed5c4600442344b9b88357cb479286ba1b9356884ce9032614eded4-621964d1059a04057241095ac3f3b2e7c8e203adfe375a6e722c95582abf9b71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LANG JIANG")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-591248")[#strong[#text("LANG JIANG")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2020")])]

#text("The proof has mistake of conceptual shift, it’s impossible to prove the N+1 day conclusion by recursion. Because if N>2 is True, then N=1 will NEVER be true, so the basis of recursion (N=1) is NOT true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-624016")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2021")])]

#text("There is a concrete difference in what the people from the island know after the information.")

#text("Person 1 knows, that person 2 knows,… that person 99 knows, that person 100 knows that there is at least one person 100 knows that there is at least one person with blue eyes. Without the information from the foreigner, person 1 knows, that person 2 knows, that… person 99 knows that there is at least one person with blue eyes but nothing more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e954c08466a03472e81076ea44ff958ac1888b126e9d7f17c70cff1b0518981d-89ad189b3d8541c9735753ca8fef3e695a6d9a980fb6a56dfef1737a3f268f86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tommaso Monni")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-624154")[#strong[#text("Tommaso Monni")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2021")])]

#text("I think Solution 1 is incorrect. Indeed, it tells that the foreigner give an information the islanders already know: false as they do not know that there are only two colors until the foreigner speaks (to tell them there is a blue color). In other words, the foreigner information has an effect because it tells there is a color while before saying so the islanders could think (each of them alone could think) they have a different color with respect to what they see, a third color which is just the not-blue, not-brown color which should be thought as different for each of them.")

#text("I would add, sharing a thought that probably goes beyond the spirit of the puzzle that each of these third colors cannot even be compared with those seen.")

#text("It cannot be compared with those they see, starting an exclusion process, because this would mean again that they have information on the full (!) possible eye colors and this in turns would call for many other physical assumptions and probabilistic considerations, supporting Islander reasoning such as “I choose at random on a virtual uncountable set of colors, the set which is the bounded interval of the physical light frequency”; even though they would be allowed to do so, then a reasoning like ” I choose uniformly at random” will lead to zero chance of choosing a color that may relfects the fact that, in fact, one cannot even name (pronounce) that color (I could not until I for example pronounce an infinitely long word on a finite alphabet).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40604a5ca2968a2cd04b4a5db926c7f18a8597f27c89beb2def14e5fc18107c7-167b74881f5e16d2ca5666f0786509091b26f9c9e96f0041d800f83cce729987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonidas")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-624534")[#strong[#text("Leonidas")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2021")])]

#text("This crazy religious devotion makes the tribe’s fate purely unstable since they can only stay as long as nothing is mentioned publicly about the eye colors. It’s true that only an evident statement is made with no real information but this is still something said and this is still enough to ruin the house of cards. The triggering effect is not linked to the information transmitted (since there is no real information contents in this speech) it is linked to the condition that the whole tribe is there and they all hear this innocent sentence the same way and at the same time. (If only one were missing the effect would not come.) It is very easy to mislead the inattantive reader that nothing has happenned saying that the information is not new to anyone. Yes the informsation itself is not new but no one ever before declared this not at all new information in front of the whole community. This is the newness in the story – this is very new and this misfortunate condition is actually paving the direct road to the self extermination of these stupid believers. (A joke is coming to my mind. Uncle Joe leaves the factory – where he works – with a wheel barrow which is covered by a canvas sheet every day. Looking under the canvas the guard at the gate checks the wheel barrow all the time but it is always empty. He doesn’t understand what’s happening and one day finally he decides to talk about his confusion to Joe in a private manner. Joe i have the feeling that you are cheating us. I will not report it to anybody but tell me at last what you are stealing from this place day by day! And Joe replies: wheel barrow – my sweety – wheel barrow. I write this joke since something simillar happens in it as in the puzzle. The sentence said itself is empty but the fact that it’s rolling out causes a damage still. Proporly speaking quite a big damage in case of our tribe – more than the wheel barrows mean to the company.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David B Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-624535")[#strong[#text("David B Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2021")])]

#text("Correct…For the first time in the tribe’s history every member of the tribe has a starting time to begin counting days.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-636591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2021")])]

#text("Only solution 1 is plausible, given that the islanders are truly perfect logicians.")

#text("They would realize that no new information was given either about eye color or about knowledge of any persons on the island, and that everyone else also realizes this. Therefore there can be no possible change to the equilibrium state.")

#text("Any counterarguments to this simple line of reasoning?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b336f213ec97886d3f3424a99e2f5faa8af515879908efa8dec461ede60edcc-13828a309a8bfeedcab770659e294c6c0ebe4db774381f06e50457d164ffc559.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-636595")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2021")])]

#text("The visitor gave them all a time to start counting days. They never had that until then. For them, that was “new information”. That was all they needed to figure out who had blue eyes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40604a5ca2968a2cd04b4a5db926c7f18a8597f27c89beb2def14e5fc18107c7-167b74881f5e16d2ca5666f0786509091b26f9c9e96f0041d800f83cce729987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matavovszky György")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-636599")[#strong[#text("Matavovszky György")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2021")])]

#text("Absolutely right!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("No, there’s no counter, you are correct. People are confusing themselves from the n=1 case but we cant induce from that.")

#text("When n=1 then the sole blue eyed person realizes they’re the only one and leave/die. *importantly* in this case his statement does provide information.")

#text("When n=2 both the blue and brown eyed people all see at least 1 blue eyed person and hence the travelers statement has no effect on the group (it has no new information).")

#text("Induction would need to proceed from n=2 and whence nothing happens for general n (including n=total population).")

#text("The key is they need to know exactly how many blue eyes there are (assuming only 2 eye colors) and the instant they know that they can act.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-688803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2025")])]

#text("Things happen at n=2 though. A sees blue eyed B. But A doesn’t know whether B sees blue eyed A, he could be seeing brown eyed A. And in this case the statement would lead to B killing himself the next day. When he doesn’t do that, A will conclude he has blue eyes as will B by similar reasoning.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-672563")[#strong[#text("Why Study Logic? | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")]

#text("[…] in material here) thought we had written about this puzzle on this blog, but it turns out to be a memory from Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-685846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2024")])]

#text("The solution is that Argument 1 is flawed.")

#strong[#text("Case N=1:")]#text(" Not everyone can know that there are blue-eyed people. It is immediately obvious that the blue-eyed person cannot see that there are other blue-eyed people, so the foreigner does provide new information to this person.")

#strong[#text("Case N=2:")]#text(" Everyone can see that there are blue-eyed people – brown-eyed people can see the two blue-eyed people, and the blue-eyed people can see each other.")

#list(
[#text("But not everyone knows that everyone else knows that there are blue-eyed people. One of the blue-eyed people will look at the other and not know whether the other person knows whether there are blue-eyed people. So the foreigner provides new information, since now this person knows their observed blue-eyed person knows that there are blue-eyed people.")]
)

#strong[#text("Case N=3:")]#text(" Everyone can see that there are blue-eye people, as per the N=2 case.")

#list(
[#text("Furthermore, everyone knows that everyone else knows that there are blue-eyed people. One of the blue-eyed people will look at the other two, and know that both of them can see each other and thus know for sure there is at least one blue-eyed person.")],
[#text("But this person doesn’t know whether a given one of the two blue-eyed people they see, knows that the other blue-eyed person knows that there are blue-eyed people. So the foreigner provides new information, since now this person knows the given observed blue-eyed person knows that the other blue-eyed person knows that there are blue-eyed people.")]
)

#strong[#text("General case N: ")]#text("The foreigner provides information that, up to N blue-eyed people, allows for everyone to know that everyone else knows that everyone else knows that …. there are blue-eyed people.")

#strong[#text("Conclusion:")]#text(" The ‘no new information’ claim applied only to the first layer of knowledge, namely, that each individual already knows there are blue-eyed people. But the claim does not address the knowledge of others’ knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-685919")[#strong[#text("蓝眼岛民困惑 - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2024")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687428")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("I’m coming to this late so not sure if I’ll get any bites but I’m trying to wrap my head around this and I have a particular question I would love to get answered related to common knowledge. Let’s say that there are six people A,B,C,D,E & F, all with blue eyes. All of them can see that the other five are blue-eyed, so they know that there are at least five blue-eyed people, but from my understanding, this is mutual knowledge.")

#text("So what’s common knowledge? A knows that B can see (just as A can) that C,D,E & F are all blue-eyed, so it is common knowledge between A & B that C,D,E & F are all blue-eyed. B & C can both see that D,E,F and A are all blue-eyed and so on. So, they don’t all know the same sets of blue-eyed people but they all know that at least four people are blue-eyed. So, isn’t it common knowledge that there are at least four blue-eyed people?")

#text("In general this would translate to common knowledge being that there are at least k-2 blue-eyed people when there are k blue-eyed people and k > 3. But this doesn’t line up with the correct answer. So what am I missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("We want to model what the different persons knows about blue-eyedness, but also what they know that others know about blue-eyedness (“meta-knowledge”), and what they know that others know about meta-knowledge (“meta-meta-knowledge”, and so on.")

#text("A knows that B, C, D, E and F has blue eyes.")#linebreak()#text("A “meta-knows” that B knows that C, D, E and F has blue eyes. This means that A meta-knows that B knows about (a least) 4 blue eyed persons.")#linebreak()#text("A meta-meta-knows that B thinks a similar meta-knowledge about A. (“B knows that I can see (at least) 4 blue eyed persons. B doesn’t know that I actually see 5 blue eyed persons, because B doesn’t know he has blue eyes.”)")#linebreak()#text("This is the level you stopped at.")

#text("What can A meta-meta-know about B’s meta-knowledge about C? B meta-knows that C can see at least 4 blue eyed persons. A doesn’t know that B meta-knows that, because A ")#strong[#text("does not know")]#text(" about their own blue eyes. All that blue can see is that “B should know that C sees at least three blue eyed persons: D, E and F”.")

#text("In short: everyone knows about 5 blue eyed persons. That is not common knowledge though: everyone just knows that everyone else knows about (at least) 4 blue eyed persons. That in turn is also not common knowledge: everyone knows that everyone else knows that everyone else knows about (at least) 3 blue eyed persons. And so on.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96a84b2e41c7bf0936d2382f777633d753f43bc3393bccbb4b2ac3f3955991b4-513e814e514c9a3a29c0f6d08605b7511c07e8d54155ea86f39abba286210da8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-687644")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("It seems to me that there is a problem of the blue-eyed persons being separated. The announcement of the guest that he has seen other blue-eyes person appears to function as the starting point. Afterwards each blue eyed person starts counting blue-eyed persons and days and apparently everyone sees everyone and everyone knows that everyone has seen everyone else. Why has that not happened earlier? Me thinks that some universally known knowledge gaps via separation must have happened.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f60341da2831ea5e0e11dae68f9e021dd26a98aee2a92952cfeede0c8a80963c-06be1c09583ecc79960c7275c464df107b9c9321ffc86e6b5d6e9726678b0cc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lucasnbr")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-688358")[#strong[#text("lucasnbr")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2025")])]

#text("Why are the blue-eyed people assuming the induction step to be true if they are not the ones proving the theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-688851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2025")])]

#text("For 1 or 2 blue-eyed people, the announcement actually conveys new factual information. For 3 or more blue-eyed people, the announcement is purely a trigger (everyone knows that everyone knows that there are blue-eyed islanders). In any case, the rules of the tribe translate the sentence “one of you is blue-eyed” into the command “if you see N blue-eyed people, commit suicide after N+1 nights” (this also applies to brown-eyed members). The announcement simply allows the inductive chain (the “program” if you will) to start.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3f9d0e97780026b04dcc54d834def9d6ddb633ad6a3af20a528f468ec094386-ab961ba78cd1be6a09a36899d5c6c6d2bb319513ff1ada4742411f4ca74e7189.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brown-eyed Islander")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-689008")[#strong[#text("Brown-eyed Islander")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2025")])]

#text("Solution 1 is correct, I guess?")

#text("The problem of solution 2 (from induction) is that for n = 3 or greater (where n is the actual number of people with blue-eyes), the traveler will only give new information if the claim is “I saw at least n -1 people with blue-eyes”; any claim below this number is not new information, so it should change nothing, thus everyone is safe :D")

#text("Let me elaborate this a little bit more:")

#text("For n = 3, people with blue eyes (for simplicity let’s call them Z) will see 2 other Z; so if they put themselves in Z’s shoes, they will know that Z will see at least one other Z; thus the traveler’s claim that there is at least one Z is nothing new.")

#text("A trivial case is if the traveler claim that “there is at least 3 Z”; the 3 poor Z will unfortunately die as they only see 2 Z, so the 3rd Z must be themselves :(")

#text("The tricky part is when he traveler claim that there is at least (n – 1 =)2 Z; at first sight to the Z, this is no new information, each one of them is seeing 2 other Z already; however, they know that if they themselves are not a Z, that means the other 2 Z is seeing only (n – 2 =)1 Z; the traveler’s claim would be new information to them (and kills them of course)")

#text("Therefore, the Z would all expect this new information to kill the other (n – 1 =)2 Z they saw; if this does not happen, that means that the assumption that themselves is not a Z is wrong, so they shall all die the next day :(")

#text("This is a very interesting paradox which our common sense contradicts with inductive reasoning.")

#text("I first heard this paradox from my friend during the high schools; we did came up with similar conclusions, but were troubled by the fact that it simply didn’t make any sense.")

#text("After so many years this memory is still in my mind; hopefully one day we could truly solve this puzzle!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3f9d0e97780026b04dcc54d834def9d6ddb633ad6a3af20a528f468ec094386-ab961ba78cd1be6a09a36899d5c6c6d2bb319513ff1ada4742411f4ca74e7189.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brown-eyed Islander")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-689013")[#strong[#text("Brown-eyed Islander")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2025")])]

#text("Just thought of a simpler explanation")

#text("When you as one of the islander, observed that there are N blue-eyed islanders, then the only number those blue-eyed islanders will observe is either N or N-1")

#text("It is impossible for any one to observe N-2, N-3, N-4…1, 0; so we cannot use a hypothesis (that there is an islander who observe 0) which had been proven impossible, to do induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3f9d0e97780026b04dcc54d834def9d6ddb633ad6a3af20a528f468ec094386-ab961ba78cd1be6a09a36899d5c6c6d2bb319513ff1ada4742411f4ca74e7189.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brown-eyed Islander")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-689014")[#strong[#text("Brown-eyed Islander")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2025")])]

#text("Another wise man answer is that, if all the islanders are highly logical, they would realize that it is the action of “observation” that could lead to their demise; so the best to survive is to not observe at all!")

#text("Therefore, no matter what color the eyes of the others, just don’t bother and you will be fine :D")

#text("Therefore whatever the foreigner say, nothing will happen because no body ever cares lol.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-5/#comment-693962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2026")])]

#text("I think the key inside is that the induction inducts on two variables at once. Assume the announcement is on a common day t. If there are n blue eyed people on the island then they will all die on day t+n.")

#text("We induct on this statement. If t is not given e. g. all of them forget when the foreigner was there, this process couldn’t take place cuz there is no start time. The same problem arises at the beginning: Because they don’t know when they all realized this statement and when this timed process starts, the induction is not possible, as a common t is not given.")

#text("In that sense the foreigner just starts the clock to a bomb. The bomb could have always exploded, but it was never started.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d83c939bbc5aecd3be423515a5696b00668f2d8feb9bd63e32efee1f98ce3aa-f27d559bf6843af50f74a276cc5ea59dd8b460114323d022c46c8530de73b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218529")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2013")])]

#text("Thanks to everyone to responding to my Christmas Cracker post, I can see now that the game cannot be stopped! Thank you Lenoxus for refining my understanding of common knowledge and distinguishing it from mutual knowledge. One or two things bother me, and I will re-post again soon. Firstly I think I was completely wrong with the idea of “minimum known” I’m not sure it really is possible for anyone to form an idea of a minimum number that everyone knows everyone knows. I think if you could that would stop the game. It may be that this concept is just inappropriate to the puzzle. On another point, one way to view the puzzle is as a counting game: two islanders must wait one day for “decision”, if someone else wishes to join, the group must wait 2 days, if another wishes to join, they must wait 3. The game is constructed such that it is a counting game of this kind and it is logical to follow the pattern. I’m still not convinced about nested hypotheses, mainly because they involve people who everyone knows everyone knows cannot exist (I think!), but as these hypotheses about others follow logically from the induction argument, I don’t see how they can be eliminated.")#linebreak()#text(" I’ll definitely read the walk through before I post again. Amazing puzzle that is much more than it seems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218671")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2013")])]

#text("Hello everyone, I’ve been delayed in responding by a big project but that’s finally over, yay!")

#text("I was going to say more about the nesting, but I can’t think of any new ways to frame it. So let’s just stick with the separate question of whether there’s a maximum number of blue-eyed people who would leave, such that a larger number of blues would stay.")

#text("For the record, I had been under the impression that you, John Graeme, thought that four blues would in fact leave on Day 4 (where Day 0 is the day of the announcement). Maybe I was wrong and you actually think the maximum is three, but for now I’m going to stick with four. You wrote:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If I see 4 blue eyed islanders, I still know that there is a minimum known to all of 2 blue eyes and can see that the process will not get started because nobody can be waiting to see what the other does (see table below).")
]

#text("Are you now saying that if you see 4 blue-eyed islanders, they will never leave? But what if you have brown eyes, and those four are the only blues? This would mean there are exactly four blues, and earlier you said that it does work with four. Does it only work with four if there isn’t a brown-eyed person watching them?")

#text("Now, maybe I’ve been misreading you all along and you think the maximum is three.")

#text("In that case, let’s suppose you (on the island and not know your own eye color) see exactly three blues. The simple question is:")

#strong[#text("Will those three blues leave on Day 3?")]

#text("Will they or won’t they? And if you can’t answer becaue you don’t have enough information, then what information would you need to be able to answer?")

#text("Notice that you don’t actually have to worry about nesting here. The inductive “counting argument” stands completely on its own; the nesting is just the deeper explanation for ")#emph[#text("why")]#text(" it works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816a69910182fc3ee898573d022e5c75658ac1c893a37ddeb5fdfbdb5ac54876-d12f51ee3d5c1dcf4f3ad46c014a47c1af66f01026fa4cac86590b5baef63b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218772")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2013")])]

#text("Lenoxus, it was because of the above inconsistency that I admitted I was wrong, in the post above. Thanks for tidying that up in any case. By the way, do you believe that the nesting, extended hypotheses argument suggests that the islanders are in genuine ignorance of whether there are any blue-eyes on the island, or is it the conclusion of logical processes that they are bound to follow? I also wanted to add that if you are or are thinking of become a teacher, you certainly have the patience for it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218778")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2013")])]

#text("Darn it, I had either skipped past or misunderstood when you said “The game cannot be stopped!”. Thanks for the compliment, anyway!")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("By the way, do you believe that the nesting, extended hypotheses argument suggests that the islanders are in genuine ignorance of whether there are any blue-eyes on the island, or is it the conclusion of logical processes that they are bound to follow?")
]

#text("Well, if interpreted literally this is not the case, of course. If there are just two or more blue-eyed people, than everyone knows there are blue-eyes. However, if you meant “everyone knows” as a shorthand for “[everyone knows] x infinity”, then yes. No matter how many blue-eyed people we add, it cannot become common knowledge (in the strict logical sense) that blue-eyes exist.")

#text("However, the logical process never comes into ")#emph[#text("conflict")]#text(" with any islander’s knowledge, which would indeed be paradoxical, irrational even. It’s not like an islander is saying “On the one hand, I see 99 blue-eyed people, but on the other hand, logic compels me to reject this evidence.” Rather, the direct observation and the logical process go hand-in-hand.")

#text("================")

#text("I think I can give another simple counting argument to establish this as well. Consider the following three premises:")

#text("P1. If there are exactly N blue-eyed people, than each of them will see exactly N-1 blue-eyed people.")

#text("P2. Any individual islander can always consider the possibility that he does not have blue eyes.")

#text("P3. Any individual islander is capable of considering P1, P2, and P3. (Note the infinite recursion in this one!)")

#text("All we must now do is iterate the above premises. Suppose there are 100 blues. By P1, they each see 99 blues. By P2, they can each consider themselves to not have blue eyes, making the total 99. By P3, each of those (hypothetical) 99 would repeat the process. By P1, each of those 99 would see 98. By P2, each of those (meta-hypothetical) 98 blues may consider himself non-blue-eyed. By P3, a set of 98 blues would consider all three propositions. And so on.")

#text("There is no point at which P1, or P2, or P3 becomes false until we reach 0 blue-eyed people, who are of course not capable of seeing anyone or making deductions (because there of 0 of them).")

#text("================")

#text("We can also try to demonstrate the absence of the common knowledge by another “counting argument.” In this context, “relevant common knowledge” will mean Nth-order knowledge, where N is the number of blue-eyed people. (So if there’s just one blue-eyed person and he knows he has blue eyes, then that’s relevant common knowledge. If there are 15 and [everyone knows]x15 that someone has blue eyes, then that’s relevant common knowledge.)")

#text("Consider a set of islanders who have relevant common knowledge of blue eyes. We can remove any one of the islanders. If we do so, we must also remove a single “everyone knows” from our description of the situation. We can do this safely because ")#emph[#text("the islander we removed knew that the remaining part of the sentence was true")]#text(".")

#text("A sidenote: consider a simple situation: “Jared knows that the ball is in the box” is true. If we remove Jared, then “the balll is in the box” must remain true, because Jared didn’t just ")#emph[#text("think")]#text(" it, he ")#emph[#text("knew")]#text(" it.")

#text("For an island with 100 people, if it is true that [everyone knows x 100] that someone has blue eyes, then any one person knows that [everyone knows x 99] that someone has blue eyes. We can remove a person, and it will now be the case that [everyone knows x 99] that someone has blue eyes.")

#text("Perhaps you now see where I am going with this. After you have removed one person and one “everyone knows”, the process is repeatable. The number of “everyone knows” and the number of people started out the same, and if you repeat the act of removing one of each, then they will both decrease at the same rate and the same time until both reach 1.")

#text("What’s special about 1? Well, in a sense, nothing really. But at that point, we are in a situation where there is a lone-blue eyed person, and also “everyone knows” knows (meaning simply that he knows) that someone still on the island has blue eyes. Yet there is no apparent way for him to know this. (No visitor has showed up in this example.)")

#text("What’s my point in all this? To put it simply: This demonstrates that ")#emph[#text("if")]#text(" it is necessarily the case that 100 blue-eyed people would have common knowledge that blue eyes exist, without any outside information having been given, then it follows that 1 blue-eyed person would also have this knowledge. However, it is false that 1 blue-eyed person must have this knowledge. Therefore, by modus tollens, it is false that 100 blue-eyed people necessarily would have that common knowledge.")

#text("================")

#text("One objection I can foresee people making to this is that the situation with nested thinking is different from my Jared example, because that example didn’t involve Jared thinking about other people thinking about himself, so subtracting Jared really would make an important difference. However, in actuality, the common knowledge situation doesn’t involve that either! Sometimes we say “everyone” when a better term would be “everyone else”.")

#text("Consider the situation with just 4 blues. It may or may not be the case that: ")#emph[#text("Each of the four knows that each of the other three knows that each of the other two knows that the other one knows that blue eyes exist.")]#text(" That’s just the more complicated, detailed way of saying that “[Everyone knows x 4] that blue eyes exist.” And with that example, it should be clear that we can do the elimination thing. Remove any one person, and now it is true that “Each of the other three knows that each of the other two knows that the other one knows that blue eyes exist.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbea2f8f3cb0e71ad5c281e3f9ec68acab000f1443f6f9cc950e96868e6d5dc7-981a21c4376b8d0c2318c4628739457bab678543d8ba7ab8c2c383c327fb941a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218810")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2013")])]

#text("“[everyone knows] x infinity” Is that possible? To say “I know what I know” is tortological – the same applies with “everyone knows that everyone knows that everyone knows” (ie x3)….we can’t keep knowing what we know forever..surely?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218841")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2013")])]

#text("To say “I know what I know” is tautological, but to say “I know that I know” is not. In the case of exactly two blue eyed islanders, everyone knows that there are blue eyes, but everyone does NOT know that everyone knows that there are blue eyes. In particular neither of the blued-eyes islanders know that everyone knows there are blue eyes, since neither knows that the other one can see any.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbea2f8f3cb0e71ad5c281e3f9ec68acab000f1443f6f9cc950e96868e6d5dc7-981a21c4376b8d0c2318c4628739457bab678543d8ba7ab8c2c383c327fb941a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218813")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2013")])]

#text("Further to the above, you must mean in a chain of nested hypotheses, i.e. “everyone knows the next person knows” ad infinitum…the next person of course being everyone else ad infinitum, as you point out.")#linebreak()#text(" Just to be clear though, are you saying that it is NOT possible for the group to be aware (eks eks) that there is any number of blue-eyed islanders? If you can answer that, I can then make full sense of the above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218867")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2013")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Just to be clear though, are you saying that it is NOT possible for the group to be aware (eks eks) that there is any number of blue-eyed islanders?")
]

#text("Short answer: Yes. (if the “eks eks” are included in the question).")

#text("In general, with N blue-eyed people: Everyone knows there are (at least) N-1 blues. Everyone knows that everyone (else) knows there are N-2 blues. Everyone knows that everyone knows that everyone knows there are N-3 blues. And so on, until we reach N-N blues, or zero.")

#text("At that point, we have reached a trivial truth. For any set of N thoroughly logical people whose intelligence and logic is itself common knowledge, it must be true that everyone knows (times N) that at least zero blue-eyed people are among them, in the same way that at least zero of them have red hair, at least zero of them have pet elephants, and so forth.")

#text("I’m going to repeat something I said earlier, which resembled some of my other statements closely but was not identical.")

#emph[#text("Try filling in this sentence: A knows that B knows that C knows that D knows that E can see that ___ has blue eyes.")]

#text("Can the letter A, B, C, D, or E be put in there? If so, why? If not, why not?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816a69910182fc3ee898573d022e5c75658ac1c893a37ddeb5fdfbdb5ac54876-d12f51ee3d5c1dcf4f3ad46c014a47c1af66f01026fa4cac86590b5baef63b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218868")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2013")])]

#text("Lenoxus, thanks for your help, and good luck with your projects.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-218951")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2013")])]

#text("You’re welcome and thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816a69910182fc3ee898573d022e5c75658ac1c893a37ddeb5fdfbdb5ac54876-d12f51ee3d5c1dcf4f3ad46c014a47c1af66f01026fa4cac86590b5baef63b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-220354")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2013")])]

#text("Just thinking about this puzzle again, does anyone have an explanation for the following.")#linebreak()#text(" If all islanders hypothesise in a series of nested hypotheses that their neighbour is looking at a blue eyed person, and wondering if they know they have blue eyes etc etc, this must mean all reason that at the end of the line (islander 100 if there are 100 blue eyed islanders) there is a blue eyed person the penultimate islander is looking at (No. 99). So this must mean all acknowledge there is at least one blue eyed islander. That islander can’t be looking back at anyone else without blue eyes as this would involve the problem Lenoxus pointed out above, A looking at B looking at C looking back at A, apparently not possible.")#linebreak()#text(" The existence of one blue would make the foreigner’s announcement redundant, but would also cause problems for eg three islanders who know it is not common knowledge there is one blue ie a problem crossing from the basic induction reasoning to the extended hypotheses. Any answers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bd8f18925db3c55616fa864410872244c0d76277de4b01d6aabeb3b1a1836b3-b8d18431d57f32de665fd51473a690c8522fd203a97d79af439a76847cca76a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-223558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2013")])]

#text("Here is a more difficult puzzle like this one!!")

#link("http://e-riddles.blogspot.gr/2013/04/neil-armstrong-landed-on-moon.html")[#text("http://e-riddles.blogspot.gr/2013/04/neil-armstrong-landed-on-moon.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e73fed4e684a824ec96dabac7420026737731f6db75a2d0e864a2c45c6d9b34c-eebd9719e853f06d88befb582079c9f2ea7c554818b4a365cb2c91da243da077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-231370")[#strong[#text("Luis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("If they were logical why wouldn’t they just remove their eyes and not have to commit suicide since they now have no eye color lol but seriously if they arnt allowed to say if someone is right or wrong then the only person creating the suicides would be the traveler so who ever he told would then kill them selves I mean like I could one day say my eyes are blue then the next day say they are brown.. Only person to say my color is the traveler … And when would they have come up with this rule I think this test is dumb")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e73fed4e684a824ec96dabac7420026737731f6db75a2d0e864a2c45c6d9b34c-eebd9719e853f06d88befb582079c9f2ea7c554818b4a365cb2c91da243da077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-231372")[#strong[#text("Luis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("also I will ad that most likely he addresses everyone once he states that they would all assume they were the ones with blue eyes and kill them selves after of course they force the traveler into suicide…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5bf30fcacf9c83af880f2915353f52f7ea9d6febd3762d7b178a788a7385828-4f8967ee01e931e56015ee657b8348008875aa22d1b5cb3b65b4c438ed7b022e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emery")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-232191")[#strong[#text("Emery")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2013")])]

#link("https://github.com/em/blue-eyes")[#text("https://github.com/em/blue-eyes")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-232197")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2013")])]

#text("Your variant doesn’t work, because the base case can’t hold up.")

#text("Suppose you are the sole blue-eyed person and everyone else is brown-eyed. How can you logically prove that you must be blue-eyed? No matter how many days go by, the situation from your perspective would be the same as being the sole green-eyed (or purple-eyed, red-eyed, etc) person.")

#text("Now suppose you are one of exactly two blue-eyed people. How would you prove it this time? You can’t, because for all you can tell, you are still the sole [something]-eyed person. We’ve already established that if there ")#emph[#text("were")]#text(" just one, then s/he would have no reason to ever leave. Hence, you can’t learn anything from him/her ")#emph[#text("not")]#text(" leaving.")

#text("By extension, there is no number of people, for any eye color, that is sufficient for a given person to logically prove their own eye color. Some additional piece of information needs to be given. It also has to be given publically, so that it becomes common knowledge (which it wasn’t before).")

#text("So what if anything is wrong with your original chain of logic? I would put it this way: You are making something “special” out of “everyone knows that everyone knows X.” That might be called two layers of knowledge. Here’s the thing: ")#strong[#text("There is nothing special about two layers")]#text(". It’s ")#emph[#text("different")]#text(" from three layers, or “everyone knows everyone knows everyone knows X.” And these are each different from four layers, etc.")

#text("The only thing special about a two-layered situation is that that is usually where the human brain wants to stop. But it’s not where these islanders stop. These islanders can think up to any number of layers. In order for all the blues to die, they require a number of layers equal to the number of blues. So if there were just one blue, then he would die once it became true that “everyone knows” at least one blue exists (because “everyone” would include him). But it wouldn’t be enough in the case of two blues, because each of those two blues wouldn’t know ")#emph[#text("that the other blue knows it")]#text(". And so on.")

#text("A public announcement immediately makes it the case that “everyone knows x infinity” that blue eyes exist. It wasn’t the case before.")

#text("To repeat and clarify, you said this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If [Everyone knows that everyone sees all other blue eyes] were always true, then they would be dead already.")
]

#text("But that’s not the case and here’s why. Suppose you are on the island with exactly six other people, of whom three have blue eyes and three have brown. So it is correct to say that everyone sees at least two blues, meaning everyone knows that everyone sees at least one blue, or “everyone knows that everyone sees all other blue eyes”. Three nights go by without suicide. What color are your eyes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5bf30fcacf9c83af880f2915353f52f7ea9d6febd3762d7b178a788a7385828-4f8967ee01e931e56015ee657b8348008875aa22d1b5cb3b65b4c438ed7b022e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emery")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-232299")[#strong[#text("Emery")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2013")])]

#text("What I’d really like to do is demonstrate the blue eyes algorithm in Javascript. I would like nothing more than to show it to the original specs of the puzzle. But I’m really not getting what you are saying.")

#text("If you don’t mind helping me. I’d like to go one step at a time.")

#text("The biggest thing I don’t understand is where these “layers” come from. I think what you’re saying is the algorithm would need recursion. But I don’t see how that’s necessary.")

#text("It think what you’re saying that if we have islanders A, B and C.")#linebreak()#text(" A needs to know:")#linebreak()#text(" does A know there are blue eyes")#linebreak()#text(" does B know there are blue eyes")#linebreak()#text(" does A know that B knows there are blue eyes")#linebreak()#text(" does B know that A knows there are blue eyes")

#text("But all of that compounds simply to “does everybody know there are blue eyes and does everybody know that this is common knowledge”.")

#text("Are you sure you aren’t making it more complicated that in needs to be and in doing so obscuring an illogical state transition?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5bf30fcacf9c83af880f2915353f52f7ea9d6febd3762d7b178a788a7385828-4f8967ee01e931e56015ee657b8348008875aa22d1b5cb3b65b4c438ed7b022e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emery")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-232300")[#strong[#text("Emery")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2013")])]

#text("I forgot to add")#linebreak()#text(" does A know that C knows there are blue eyes")#linebreak()#text(" does B know that C knows there are blue eyes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-232305")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2013")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The biggest thing I don’t understand is where these “layers” come from. I think what you’re saying is the algorithm would need recursion.")
]

#text("It generally would. However, one can also prove the puzzle without recourse to recursion; it’s just that recursion is the “whole story.”")

#text("Here’s an attempt to prove, without using (as much) recursion, why it works once a public statement “At least one person has blue eyes” is made.")

#text("1) If there were just 1 blue-eyed person, he would die on Day 1.")

#text("2) If there are in fact 2 blue-eyed people, they will die on Day 2. Why? Because each one observes just 1 blue and thinks: “Either there is just one blue, or there is not and I am also blue. In the former case, that blue will die on Day 1. In the latter case, I am also blue. So if no deaths happen on Day 1, that means I will kill myself on Day 2.”")

#text("3) We’ve just proven that if there are exactly 2 blues, they ")#emph[#text("will")]#text(" die two days after the announcement. So suppose there were 3. They would know that either there are 2 blues or 3, and if there are 2 then those 2 will die on Day 3. Hence, after no deaths happen on Day 2, the 3 blues kill themselves on Day 3.")

#text("4) In general, if we know that N blues (for some particular N, such as 2) would kill themselves on Day N, then N+1 blues, upon seeing the N blues ")#emph[#text("not")]#text(" killing themselves, will deduce that there are not N blues, meaning there must be N+1 including oneself, and so the N+1 blues kill themselves on Day N+1.")

#text("5) Hence, in general, all X blues will kill themselves X days after a public announcement like “At least one of you has blue eyes.”")

#text("This same train of logic can be flipped around for the situation where no announcement is made. In that case, there’s no reason for 1 blue to die. If 1 wouldn’t die, then 2 blues wouldn’t draw any conclusions from seeing the other one not die. So 2 are “safe.” And if 2 are safe, then 3 are safe as well, because they have no reason to draw a conclusion from 2 not dying. In general, if N blues would have no reason to kill themselves, then neither would N+1.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("But all of that compounds simply to “does everybody know there are blue eyes and does everybody know that this is common knowledge”.")
]

#text("You’ve read the Wikipedia page about “common knowledge”. Do you understand the difference between that and “mutual knowledge”? If something is common knowledge, that means that “Everyone knows that everyone know that [times ")#emph[#text("any number")]#text(" of repetitions] X is true.” So if something is common knowledge (for a particular group), then it must also be the case that everyone knows it is common knowledge.")

#text("Suppose there are three blue-eyed people, and no visitor. Is it common knowledge that blue eyes exist? It would seem so, but no, it is not. A does not know if B knows if C can see anyone with blue eyes. Whose eyes woud this hypothetical C be seeing? Not A’s, because A doesn’t know if his own eyes are blue, and not C, because A knows that C can’t see his own eyes, and not B, because A knows that B can’t see his own eyes.")

#text("There is no minimum of blues for which the existence of blue eyes can become true common knowledge. That’s because what ")#emph[#text("is")]#text(" common knowledge is that no one knows her own eye color. Each person accounts for their own ignorance, and accounts for the next person accounting for his own ignorance, and accounts for the next person accounting for the next person accounting for her own ignorance, and so so on.")

#text("Since you began with a link, I probably shouldn’t have written all the above and should instead have linked to ")#link("http://forums.xkcd.com/viewtopic.php?f=3&t=80149")[#text("this page")]#text(" where I discuss the problem and common related arguments. Warning: that page is pretty long. I guess I really like writing about it…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5bf30fcacf9c83af880f2915353f52f7ea9d6febd3762d7b178a788a7385828-4f8967ee01e931e56015ee657b8348008875aa22d1b5cb3b65b4c438ed7b022e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emery")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-232301")[#strong[#text("Emery")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2013")])]

#text("And you are right, my variant does not take into account n=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a97a73c74e33b9dfea9d831c7c9eeb8a53917d9fb380350f58069327dadfcc82-fac6b7db182b184a2316a4cbcb4927d0e71d8420d106036bf62c998a2036aa6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ann")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-238107")[#strong[#text("Ann")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("I am sorry that I have translated this puzzle into Chinese but I haven’t got your permission. I beg your forgiveness…")

#text("My English is not very well, and if there is something offensive, please forgive me and tell me, and I will delete the post as fast as I can.")

#text("Here is the website:")#linebreak()#text(" ")#link("http://www.douban.com/group/topic/41131932/?start=0")[#text("http://www.douban.com/group/topic/41131932/?start=0")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-245322")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("An alternative telling — that for some folks may be more fun (and easier to remember) — is to eliminate the foreigner, and instead assume that ")#emph[#text("the islanders love to tell scary stories")]#text(".")

#text("We specify that the following scary story is told upon every island ")#emph[#text("“A trusted foreigner comes and says ‘I see a blue eyed person.'”")]

#text("The puzzle question is, ")#emph[#text("“Why does everyone, on every island, experience this story as genuinely frightening?”")]#text(" In other words “Why is this story’s scariness ")#emph[#text("universal")]#text("?”")

#text("On islands where everyone is brown-eyed, the story is universally scary for the obvious-to-islanders reason, that anyone hearing that story would have to ")#emph[#text("kill themselves that very day")]#text(". Scary for everyone!")

#text("On islands with exactly one blue-eyed person, that person experiences the story as scary for the same reason as the persons on the all-brown-eye islands. The remaining brown-eyed people experience the story as scary too, but they reason differently: “This story is scary (to me who sees exactly one blue-eyed person) because, if I heard that story, and no-one on my island killed themselves that same day, then I would have to kill myself on the second day!” And so, again, the story is scary for everyone, both the brown-eyed majority and the single blue-eyed listener!")

#text("By induction, ")#emph[#text("the story is scary to everyone on every island")]#text(", regardless of the number of brown-eyed and blue-eyed people. Because no-one can imagine hearing this story without saying to themselves “If ever I heard this story, in real-life from a trusted foreigner, then either many of my friends would have to kill themselves, or after awhile I would have to kill myself!”")

#strong[#text("Summary")]#text(" This puzzle could alternatively called “The universal scary-story puzzle” because it amounts to asking “Why is this story scary to every islander?”")

#text("Perhaps unconsciously, this “scariness” helps make the puzzle attractive even to us in the real world … because it vividly shows us the scary power of mathematical narratives.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-245329")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#strong[#text("Remark")]#text(" It contributes greatly to the story’s scariness, that every islander is allowed (by custom) to say “Wow! That is a SCARY story!” … and yet paradoxically, every islander is strictly forbidden (by custom) to share with ")#emph[#text("anyone")]#text(" their personal understanding of why the story is scary.")

#strong[#text("Remark")]#text(" The social isolation that is implicit in the scary foreigner story is itself terrifying … and this another reason why the scary foreigner puzzle is fascinating on many levels.")

#strong[#text("Possibly the Most Scary Islander Realization")]#text(" “Each of my friends, and even I myself, possesses the unilateral power to wreak terrifying destruction upon our peaceful island … simply by telling a true mathematical story.”")

#text("Because there are elements of reality in this conclusion, the Blue-eyed Islanders Puzzle surely ranks among the most scary mathematical puzzles ever posed!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/657734eceabd372863b90399b552429fb2d9305da1b6987b2bfd513e95645ddc-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kai Kaufmann")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-246776")[#strong[#text("Kai Kaufmann")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("I invite readers to try out ")#link("http://www.facebook.com/ThePanopticonPuzzle")[#text("http://www.facebook.com/ThePanopticonPuzzle")]#text(" that is of complexity O(N^3) and not just O(N) like the “blue eyed islanders puzzle”, thus being a serious contender for xkcd’s title of ‘hardest logic puzzle in the world’. The first person after me to solve one of its’ two parts will receive a prize of $1500, respectively $150.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/155c8fb30297da4a83cadfa5be09c51a133a0600b1607091176c27932e3efcdb-4e792f19233ace682acbd2fc7511f42fdf3295366b0e07298057dec50ed3a84b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drew")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-249669")[#strong[#text("Drew")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("It seems the key ingredients to this puzzle are that")#linebreak()#text(" a) all islanders hear the outsider speak simultaneously")#linebreak()#text(" b) there is a set, timed procedure for the consequential action.")#linebreak()#text(" Interesting example of how speaking out in public what everybody already knows can lead to trouble.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5247606cb0f3251f1a1d013b748f5817bcd2c94d3d7b569360a46d5b687033d5-fd0ef25fd501c18acd183870ccc45ad950a4006e90e8716ee678b60a7c4c34c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucca")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-253714")[#strong[#text("Lucca")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("What prevents the brown-eyed people from thinking they have blue eyes like the actual blue-eyed do, and thus killing themselves?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4648e7b30f22f14a77290654cab72b3827a4f124a6ef3fe6ee0dd2adc128afd5-3b91baad3d366f92a150d3ed01a5cf8e7a6f504937f68300c97da458abdd21ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ConfusedMe")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-256671")[#strong[#text("ConfusedMe")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2013")])]

#text("If there is 4 blue eyed people in a circle that does not know their own eye color they everyone know this:")

#text("* That there is 4 people total.")

#text("* That everyone can see what one person see minus themselves.")

#text("* If one person sees 3 blue eyed people, Then one of those blue eyed persons see at least 2 blue eyed people and one of those 2 blue eyed people see atleast 2 other blue eyed people.")

#text("* everyone knows that everyone knows this times infite")

#text("Now that everyone one knows there is atleast 2 blue eyed people, they begin to wonder why the two people have not left during the night. It has to be three, but the three doesn’t leave either, it has to be four all leave forth night.")

#text("Guru/stranger is useless?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fed10418617e684a171cb6b07e44c4abfbb3de42fdeba52767591526634b0f0-be2dd0c1067d0554ebae497f5404860aff4260e5d0fc6a7a98296998672f85eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-358217")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2014")])]

#text("One more try.")#linebreak()#text(" There are n blue-eyed people in the tribe.")#linebreak()#text(" After any number of days nothing happens because nobody knows their own eye colour.")#linebreak()#text(" Then the traveller announces to everybody that there is at least one blue-eyed person in the tribe.")#linebreak()#text(" Proposition. Suppose that the tribe had n blue-eyed people for some positive integer n. Then n days after the traveller’s address, all n blue-eyed people commit suicide.")#linebreak()#text(" For the inductive argument we need to prove:")#linebreak()#text(" 1) that it is true for n=1,")#linebreak()#text(" which is the case")#linebreak()#text(" 2) that if it is true for n-1 then that implies it is true for n")#linebreak()#text(" Looking at the second part:")#linebreak()#text(" if there are exactly n blue-eyed people then they each from the start")#linebreak()#text(" see n-1 people with blue eyes")#linebreak()#text(" and")#linebreak()#text(" know that there are either n-1 or n blue-eyed people in the tribe.")#linebreak()#text(" After n-1 days:")#linebreak()#text(" the n-1 have not committed suicide because they do not know their eye colour at that time.")#linebreak()#text(" Now if it is true that if there were only n-1 persons in the tribe with blue eyes, then those n-1 would know that their own eyes were blue,")#linebreak()#text(" then that implies that if the n-1 don’t know that their eyes are blue then there are n persons in the tribe with blue eyes, and those n can deduce that their own eye colour is blue.")#linebreak()#text(" But there is another reason why the n-1 might not know their eye colour at that time;")#linebreak()#text(" if what the traveller said doesn’t make it a logical necessity that they have blue eyes.")#linebreak()#text(" In that case still nobody knows their own eye colour and life continues as before.")

#text("Considering exactly how many blue-eyed people are on the island when the traveller speaks:")

#text("If there is only 1 blue-eyed person when the traveller speaks:")#linebreak()#text(" he or she will see no-one else with blue eyes and so know that they are the one referred to and commit suicide the next day.")

#text("If there are 2 with blue eyes when the traveller speaks:")#linebreak()#text(" initially each will see 1 with blue eyes and will not know his or her own eye colour")#linebreak()#text(" so will know that the traveller has spoken with n=1 or n=2")#linebreak()#text(" if when n=1")#linebreak()#text(" then the 1 person will know immediately that his or her eyes are blue and commit suicide the next day.")#linebreak()#text(" if he or she doesn’t commit suicide then both of them know at that point that n=2 and their eyes are blue and commit suicide the next day.")

#text("If there are 3 with blue eyes when the traveller speaks:")#linebreak()#text(" initially each will see 2 with blue eyes and will not know his or her own eye colour")#linebreak()#text(" so will know that the traveller has spoken with n=2 or n=3")#linebreak()#text(" if when n=2 (*)")#linebreak()#text(" initially each will see 1 with blue eyes and will not know his or her own eye colour")#linebreak()#text(" so will know that the traveller has spoken with n=1 or n=2")#linebreak()#text(" if when n=1")#linebreak()#text(" this contradicts the previous knowledge of all three that the traveller spoke with n=2 or n=3,")#linebreak()#text(" so n is not 1 and nothing further can be deduced from the hypothesis (*) that n=2,")#linebreak()#text(" in particular not that if there were 2 then they would know after one day that their eyes were blue and commit suicide the next day.")#linebreak()#text(" So the fact that the proposition is true for n=2 does not imply that it is true for n=3, which causes the induction argument to fail.")

#text("Or then again I could be wrong :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db7b73931fdcc60e65b664bdd672f194e8398023889dfba06023964680905938-bb44e5d036e5ce94fc8995705919263d1a1160adf6641deb25d5e08388e06856.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZeReoN")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-452817")[#strong[#text("ZeReoN")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2015")])]

#text("If I might explain how n=3 works:")

#text("To try and simplify, take the following scaled down experiment.")

#text("4 people (A, B, C and D) sitting in a square, each can see the other 3, but naturally not their own eye colour.")

#text("Same rules apply: If anyone deduces their own eye colour is blue, they have to ring the bell. They CAN ONLY ring it at the start of every hour, and they’ll leave the room.")

#text("Here are the assumptions that need to be given for this to proceed:")

#text("1. All players (A, B, C and D) are equally logical and able to think independently.")#linebreak()#text(" 2. No communication is done and nobody looks at the blue eye guy strangely.")#linebreak()#text(" 3. Everyone can see each other for EVERY SINGLE SECOND of well, the time they’re sitting down there. Nobody’s going to toilet or something in the middle.")

#text("At T=0 hours, blindfolds from all of them are removed, and a 3rd party’s voice echoes over the speaker, saying “One or more people in this room have blue eyes.”")

#text("The clock starts.")

#text("(——————————-Start of n=1 scenario, Sceario 1————————)")

#text("This works for when n=1, since assuming A is the blue eye guy (abbreviated henceforth as BEG), this is what he sees:")

#text("A: “B, C and D all have brown eyes. But the 3rd party mentioned one or more, so assuming it is 1, AND THAT there are 4 guys here, I know 3 of them have brown eyes, so the one with blue eyes must be me. I’ll go and ring the bell at T=1 hours.”")

#text("Thus when n=1, the removal of n BEG’s at T=n hours holds true.")

#text("(————————————–End of n=1 scenario, Start of n=2 scenario, Scenario 2——————-)")

#text("T=0, the first few seconds after the announcement. A and B both have blue eyes.")

#text("A: “I see that B has blue eyes. I assume that I have brown eyes. Therefore, the annoucement didn’t tell me anything new I didn’t know already, since he said ‘there are one or more.’ Best case that I’m assuming is ‘one’, which is that BEG I see right in front of me, B. So he will ring the bell at T=1 and nothing will happen.”")

#text("T=1, nobody rings the bell, because neither A nor B have figured out their own eye colours. The announcement said n=1 or n>1, so both (A & B) assume that it has to be n=1 between T=0 and T=1, so they both expect the other BEG they see to ring the bell at T=1.")

#text("Between T=1 and T=2,")

#text("A: “Well shucks. Assuming B was perfectly logical AND followed this train of thought, he would have pressed the bell at T=1. If he didn’t and I didn’t, that means we both were wrong that n=1, and thus n must be >1. So I see C and D that are brown. n>1 could mean that n=2, 3 or 4. But since I see 1 pair of blue eyes and 2 pairs of brown eyes, and there are 4 people total in this room, that means that it can’t be 3 or 4 blue eye pairs, since 4 pairs of eyes – 2 pairs of brown = 2 pairs of blue. It can’t be 1 pair of blue as I’ve already realized, so I must be the other blue eye and I’ll ring at T=2 since I can’t ring in between T=1 and T=2.")

#text("T=2, A and B both go ahead and press the bell and leave the room.")#linebreak()#text(" Similarly, it still holds true that after T hours, n blue eye people will leave the room where T=n. In this case, it took 2 hours for 2 blue eye people to leave the room.")#linebreak()#text(" (————————————–End of n=2, Scenario 2 has been proven.—————————)")

#text("(—————–Start of n=3, Scenario 3——————————————-)")#linebreak()#text(" Now for n=3 (A, B and C are blue, D is brown eyed), which I don’t get.")

#text("_________________________T=0, blindfolds off and announcement has been made a few seconds ago.")

#text("A: “I see 3 other people in this room. Including me, that’s 4 guys. 4 pairs of eyes. I see two other BEGs and 1 brown eye dude, Mr. D. The announcement said there are ONE or MORE blue eye dudes in this room. Well obviously it can’t be one, I clearly see 2 dudes (B and C) with blue eyes in this room. It’s not wrong, but perhaps the guy was going for the ‘more’ part rather than the ‘one’ part.")

#text("My first task is to figure out if I’m blue or not. The only way I can know is to subtract the number of brown guys from the total number of guys in this room. That will leave me with the number of blue eye guys, since there aren’t any hidden eyes anywhere.")

#text("Hypothesis (1): Assuming I am brown. I see D is brown too. B and C are clearly blue. So 4-2 brown guys (me and D) = 2 blue guys (B and C). This is consistent with the n=1 or n>1 statement that the 3rd party said when T=0. How can I prove or disprove this hypothesis?")

#text("Hypothesis (2): Assuming I am blue. I see D is brown. So 4-1 brown means that there must be 3 blue guys (me, B and C). This is also consistent with the n=1 or n>1 statement that the 3rd party said when T=0. How can I prove or disprove this hypothesis?")

#text("Working from the first (1) hypothesis (I, A, am brown) that there are only two blue guys (neither of which are me) in the room and taking into account the assumption that B and C would be highly logical like me, they (B and C) would see only one other blue eye guy, because I (am assuming) I have brown eyes.")#linebreak()#text(" So they will be waiting for the other guy to ring the bell at T=1, based on their own assumption that they are brown, and the other person they are seeing is the only blue guy, in which case n=1.")#linebreak()#text(" When that doesn’t happen, then they’ll have to revise their assessment that n=1, and figure out that n=2, and as they see only one other blue eye guy in front of them, they must be the other blue eye guy. Both B and C will arrive at this conclusion independently, and by T=2, both would have rung the bell.")

#text("To make it simpler, putting myself (A) in B’s shoes, he will think as such FROM T=0:")#linebreak()#text(" (————-Start of A during T=0 to T=1 pretending he (A) is brown, imagining what B will see—————-)")#linebreak()#text(" B: “I have only two assumptions, n=1 or n=2. n cannot be 3 or more, because I clearly count 4 fleshy bodies (including myself) in this room. Mr A and Mr D both have brown eyes. Therefore if I am brown, n must be 1 (4-3=1). If I am blue, n must be 2 (4-2=2).")

#text("Let me run a scenario of 1 blue guy. *Snipping from Scenario 1 above where n=1*: Logically speaking, NETT result when n=1 will result in that one dude there Mr C ringing the bell at T=1.")

#text("Let me run a scenario of 2 blue guys.*Snipping from Scenario 2 above where n=2* Logically speaking, NETT result when n=2 is me and Mr C. ringing the bell at T=2.")

#text("I (B) reached this conclusion in Scenario 3 before T=1, because I’m awesome at thinking :)")

#text("So when T=1, Mr C should ring the bell. If he doesn’t, then the n=1 hypothesis is false.")#linebreak()#text(" If that is false, that means n=2 is correct (aka Scenario 2) (//which, from A’s point of view, is correct as he’s imagining (A) himself to be brown. So B and C will be Blue//), and as I (B) see A and D being brown, that means I must be blue. So I will ring the bell later when T=2. But I cannot ring the bell at T=1 because I cannot confirm whether n=1 hypothesis is correct unless Mr C FAILS TO ring the bell.")

#text("(—-End of A’s imagination between T=0 and T=1 of what B is thinking, but A continues thinking—)")

#text("From B’s POV/train of thoughts, he cannot tell if n=1 (in which I, A, am brown) or n=2 (in which I also am brown, seeing that I CAN SEE C is blue) unless C acts at T=1. The same Scenario 1 will happen for C, and as a result, neither of them will act at T=1, which will disprove their theories that n=1 and the only logical theory left is n=2, so it will lead to them ringing the bell at T=2.")

#text("But working from Hypothesis (2), in which n=3 and I am blue, there would be no movements at T=2 because all 3 of us are trying to find out whether the n=2 theory (Scenario 2/Hypothesis 1) is true. Obviously since we both see 2 greens, Scenario 1 where n=1 is definitely wrong. Since the n=2/Scenario 2/Hypothesis 1 theory can only be disproved at T=2 and not a second before, there will not be any movements before T=2.")

#text("The INACTION of other players in the room to press the bell to signal they’re blue serves to disprove the hypothesEs in the various minds that are running at the same time. It’s sort of like ‘I don’t know what’s correct, whether I’m blue or brown, unless X happens. Oh there we go, X happens. I’m not brown, so I’l probably blue (assuming that there are only 2 colours of eyes, which is assumed in the original question.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46b40b0d9e12b73b5d58a61ae909a74bf8447c7371ca0d4bd6c8c5600b032df5-fb144f4657904d0494ceac981ee657445e96700a54667bd722df53c70e2ff0a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sean")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-375227")[#strong[#text("sean")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2014")])]

#text("lots of variables to consider")#linebreak()#text(" deaf people")#linebreak()#text(" babies with blue eyes")#linebreak()#text(" blind people")#linebreak()#text(" people who dont try to find out eye color")#linebreak()#text(" people who dont follow religion")#linebreak()#text(" blue eyed people who die without commiting suicide")#linebreak()#text(" more statements from outsider")#linebreak()#text(" more…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-376510")[#strong[#text("My Math Diary")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")]

#text("[…] to fundamental group, hanging pictures and homology groupBlue eyed islanders problem: SE, SE2, Terry Tao, [An interesting moral dilemma: the traveler can save 99 lives after his faux pas, by naming a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3b6b42b4cc6bf300740180198865ebcb804695852b77e31d9dda8b463b0023e-12d7459c097e1cb02b206b6604744216cf1de0fb350c5b4510ef6b2d962a8eeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J Ryan")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-405087")[#strong[#text("J Ryan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2014")])]

#text("You only have to commit suidice if you know your own eye color. No islander will ever have a way of confirming their own eye color, regardless of the visitor’s comment which does not provide any new information. Each islander, blue or non blue eyed, is an individual. The Nons can identify 100 Blues. The Blues can identify 99 Blues. Nobody can identify their own color. And remember, nobody can discuss eye color. Everybody assumes that the lack of suicide on the 100th day automatically reveals the presence of the 100th (and final) Blue. In fact, the only thing it reveals is that the Blues don’t know they are Blues, and nothing more. The lack of suicide doesn’t confirm to any of them that they are a Blue because each Blue can still logically assume that they are a Non.")

#text("To illustrate, assume you are one of the Blues. You hear the visitor’s announcement. You didn’t learn anything because you can count 99 Blues and logically determine that he is talking about those individuals and not you. Each Blue will individually draw this conclusion without having any way of identifying themself as a Blue. As each day passes, each Blue will think to themself, “I hope none of those Blues ever find out they are a Blue.” This was true even before the visitor came and made the announcement. You knew there were 99 Blues before the announcement was made. Even if you want to use that as the starting point… when that 100th day passes and you see that none of the 99 Blues committed suicide, you are instantly relieved that they didn’t learn their own eye color. Nothing about the lack of suicide allows you to logically conclude that you are a Blue as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dc20f2059fb2687830f8674f13ab159010e59119237b433e936471ee7769162-b9b6e72300a5fa84c81ecc19eb92d94af4575a7a483853a801a930e2783cd77c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr.Bombay")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-420366")[#strong[#text("Dr.Bombay")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")])]

#text("Wrong.")#linebreak()#text(" I thought this was solved already, as the solution is pretty straightforward, but since false answers keep appearing, let me try to explain:")

#text("Let us say,for simplification,that there are 4 blue eyed people(BEPs), A,B,C,D.")

#text("A thinks there are 3 BEPs.")#linebreak()#text(" A thinks that B thinks that there are 2 BEPs.")#linebreak()#text(" A thinks that B thinks that C thinks that there is only 1 BEP.")#linebreak()#text(" A things that B thinks that C thinks that D thinks there is zero BEPs.")

#text("The traveler inserts this new information (for A!!!):")#linebreak()#text(" ‘How will B act when he sees how C acts when he sees of D acts when he learns that there is more than zero BEPs”")

#text("D did not commit suicide.")

#text("A thinks that B thinks that “this invalidates C’s hypothesis of D; D sees more than 0 BEPs. C should kill himself.”")#linebreak()#text(" But C doesn’t.")

#text("A thinks that this invalidates B’s hypothesis of C: C sees more than one BEP: B should kill himself.")#linebreak()#text(" But B doesn’t.")

#text("This invalidates A’s hypothesis of B. B sees more than two BEPS. That extra BEP is A. Therefore, A must kill himself.")

#text("And as everyone reasons as A, all BEP will kill themselves on the 4th day,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29fef7f3189a62ac5f8cdc133d976f63a833d2a29cf188c0c2c833670dd10602-23e5835acd1f0c9830c6a857c36f2c47cc9ab073c87f53b8474742d9448a1e03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-427947")[#strong[#text("Zach")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2014")])]

#text("That doesn’t make any sense. A would think C and D also thought there were 2 BEP. A knows C and D can see B and D or B and C respectively.")

#text("The key is that A would expect B,C, and D to kill themselves on day 3. When they don’t then A would know that B,C, and D all thought there were 3 BEP, and thus that A was a BEP.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb878407c463a366b685926c26cee06cfc51c2d84c81470c08a38757f3a73dad-76fb606aec82b337773894a490f6f6a35df36e4b7d4e636c3ca87a605ae7d25d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernardo Galvão-Sousa")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-439745")[#strong[#text("Bernardo Galvão-Sousa")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("I just came upon this post and I already knew this logic puzzle.")

#text("But I have another question to add, especially with your formulation.")

#text("Since the islanders only ever see blue or brown eyes, if they all assumed that there are no other eye colors, what happens after the foreigner’s comment?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5232d1e3640a9411d3721a010824054ae511ba8551c49c8bfba1e8e5d08893bd-d7d5d34baf30ac54c8bb27d7245519d553c540f28c81060bb7ce67e4e024f94b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john riley")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-440962")[#strong[#text("john riley")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2014")])]

#text("Suppose we have n robots of which 0<p<n are blue. Suppose further that their sole raison d'etre is to use logic to discover their colour and stop. They reason as follows:")

#text("I assume I am not blue.")

#text("1. If I see 0 blue I stop.")#linebreak()#text(" 1. If I see 1 blue I stay. 2. If I see 1 blue I stop.")#linebreak()#text(" 1. If I see 2 blue I stay. 2. If I see 2 blue I stay. 3. If I see 2 blue I stop.")#linebreak()#text(" ……………………………………………………………………………………………")

#text("1. If see p-1 blue I stay. 2. ……………………….. P. If I see p-1 blue I stop.")

#text("Thus all the blue robots stop after p steps. If the remaining n-p robots are the same colour they stop immediately.")

#text("If we assume, on the other hand, that the islanders are sufficiently human not to be forced by their natures to apply remorseless logic at all times to their own destruction, there is no reason why they should ever give any thought to it. If fact they clearly never have, otherwise their little life would have lasted 100 days, give or take.")

#text("The visitor is a blue-eyed red herring.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79d906400029066e4d6cdc6bd54b7ba818fa8f00e9b775e921c503864ef92a53-e52ae66f23aaa19b5763975618d1a31cb14d85216cdcfb1fb19cdd8bfec8b0c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rosani")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-452344")[#strong[#text("Rosani")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("Okay, Seems like the foreigner dude saw only one blue-eyed person and that person knowing that there are 99 people with blue-eyes (adding the fact that he doesn’t want to die alone) he will then point (or tell them that they are blue-eyed).which means all blue-eyed will discover the colour of their eyes….and that way brown-eyed people can discover the colour of their eyes and kill themselves…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8d1f99c335375a1f4db76cf149e8764f8b9214ac6bf19026a386964ccec1153-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jafar Safavi")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-454156")[#strong[#text("Jafar Safavi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("2nd arguement is wrong! as I see it, the foreigner makes a public speech and does not tell the number of blue eyed people. the only way a blue eyed could know about his eye color is to know that someone else sees 100 blues, while he sees 99, which shows that he is blue. so if foreigner does not mention numbers, nothing changes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f998aca79369a336913168f6d2282b766786320fe0fb6ce2d46dca148b8a90b2-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jafar Safavi")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-454157")[#strong[#text("Jafar Safavi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("and by the way, if there was only one blue, then the foreigner would have made the blue eyed to suicide. but this does not work when there are 2 blue eyed people. because then every body including blue eyed already know that there are other blue eyed people there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c086025fe72bb96066959e912e888026bdcc2af5205dc92d89cb0629ec3708d4-2b0f443bb3a6d35788e7287248765608bbe9a3c897ab95e33e5d91c196a14350.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Laws")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-457308")[#strong[#text("Ken Laws")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2015")])]

#text("I have to disagree with the consensus that has been reached in this forum. (And, alas, with the Wikipedia entry on Common Knowledge, and what I perceive to be the consensus among logicians, and even with Peter Winkler’s wonderfully succinct Dot-Town Suicides explanation at ")#link("https://math.dartmouth.edu/~pw/solutions.pdf")[#text("https://math.dartmouth.edu/~pw/solutions.pdf")]#text(". I’m going way out on a limb here.) If I am right, the 100 blues on the island would all commit suicide after the 3rd day rather than the 100th day, under certain reasonably motivated assumptions.")

#text("I recently took up the Green-Eyed Dragons problem, after a lapse of many years from my first exposure. That led me back to xkcd’s equivalent Blue Eyes puzzle, and then to the version presented here. There are currently 1361 posts in the Blue Eyes discussion (")#link("http://forums.xkcd.com/viewtopic.php?f=3&t=3")[#text("http://forums.xkcd.com/viewtopic.php?f=3&t=3")]#text("), which I have not yet studied. This forum seems more approachable.")

#text("John Graeme was very close to the truth in his March 2013 arguments (though his conclusion that no blues would die if there were four or more on the island is a matter of culture and policy rather than mathematical necessity). Lenoxus and leopold were trying to win him to their own line of reasoning, and unfortunately succeeded. John folded too easily. Now I would like to take up his cause. The arguments below are my own, not derived specifically from anyone else’s.")

#text("I’m going to avoid any proof by induction. It’s not that I disagree with the approach, or that I object to basing such induction on counterfactuals. It’s just that I haven’t seen a valid proof of the inductive necessity for this problem. Let there be K blues on the island. (And let’s ignore the brown-eyed natives. They are irrelevant.) It’s true that induction works for K=2 and 3 given K=1. It also works for K=5 and above, starting from K=4. However, K=4 is a special case that must be considered individually.")

#text("I believe there was general agreement among John Graeme, Lenoxus, leopold, and others that with K=4, each blue (or non-blue, for that matter) can see at least three blues, and knows each of those three can see at least two blues and would reason that each of those two could see at least one blue.")

#text("Let me belabor that point. From our omniscient perspective, let us arbitrarily label one of the blues A. By arbitrarily, I mean that anything we prove using this label applies (“by symmetry”) equally to any other blue. We know that A can see (or knows of) three other blues as specific individuals with blue eyes. Let’s postulate that A thinks of them as B, C, and D, again in arbitrary order. (It would not work to let A label B and then have B label C, as we couldn’t all agree on who was C and whether C might be identical to A.)")

#text("With this labeling, we can agree that A (who does not know if he is a blue) can see three blues: B, C, and D. He knows that B can see at least two blues: C and D. And he knows that even if B imagined himself — B — to be a non-blue, B would know that C could see at least one other blue (D) and D could see at least one other blue (C). A knows that C and D would reason similarly about B, so B, C, and D must each know that there is at least one blue on the island. A also knows there is at least one blue (since he can see three of them), so all four know it. By symmetry, each blue knows there is at least one blue on the island.")

#text("Now for the crux of the argument: Is this mutual knowledge also common knowledge? As leopold wrote of the K=4 case on 3/3/13, “everyone knows that everyone knows there is at least 1 blue. But [he claims] none of the blues knows that everyone knows that everyone knows that everyone knows there is at least 1 blue, since none of them can be sure that any of the others can be sure that any of the others can be sure that the other blue(s) can see any others.”")

#text("I don’t agree, or even follow where that comes from. I make two assertions. First, I believe the existence of at least one blue is common knowledge. More generally, if there are K blues on the island, every blue sees K-1, knows that every blue sees at least K-2, and knows (as common knowledge) that every blue can see at least K-3 blues. (None of them knows the exact value of K, of course, or whether they themselves are blues, but they know this reasoning is true for whatever value of K is true.)")

#text("The argument I have presented above is one that any competent logician could construct. If even one of the blues could be inattentive or misinformed or slow witted, we could not know that they actually know what they “should” know. But that is not the case here. According to the Feb. 15 amendment to the puzzle, “any conclusion that can [be] logically deduced from the information and observations available to an islander, will automatically be known to that islander.” (This doesn’t state that the deductions are instantaneous, but it was intended. Otherwise these logicians could be as slow-witted as rock trolls.) Given their logical skill, every islander would understand and accept that the knowledge of at least K-3 blues is common knowledge.")

#text("(My omniscient K-based notation can be avoided, and possibly the logic chains are even simpler. Suppose a blue sees 99 blues. [We don’t care what non-blues see or know, but we do care what blues may or may not know.] He knows that if he is a blue, every blue sees 99; if he is a non-blue, every blue sees 98. K (the number of blues on the island) is at least 99, but some blues may only know that it is at least 98. If an arbitrary blue sees N blues, he knows that each blue sees at least N-1 and thus each knows K is at least N-1. No blue could see fewer than N=K-1 blues, so all know that all see at least K-2 blues and thus each knows the true K to be at least K-2. I believe this to be common knowledge, since every inhabitant can prove it and knows that every other can also prove it. I will use these formulas later, for the case of K=3. In that case each blue sees two blues and knows each can see at least one. Each also knows that K is at least 1, and also knows that all blues know this.)")

#text("I haven’t presented a formal proof that these lower limits are common knowledge, as far as I know. (I’m a computer scientist, not a mathematician.) But imagine yourself to be one of the stipulated 100 blues. You see 99 others; you know each of them sees at least 98; and you know that all know none could possibly see fewer than 97. You know that each of the others could — and therefore does — make the same inference. You can’t imagine anyone seeing at least 98 blues and thinking that there might be fewer. Yet there are those on this forum who have argued that you and the others must believe there could be one of you who could believe there is one of you who could believe … that there is no blue on the island. This is absurd. (And if Mathematics says it must be true, Mathematics is an ass.) It is something logic students have come to believe because it makes their elegant proof by induction work, even though it is inherently unbelievable.")

#text("But suppose I am wrong, and someone can prove me so. Then I offer my second assertion, that it doesn’t matter. We can agree that every blue knows that every blue can see at least K-3 blues (as at least mutual knowledge). I claim that is sufficient, whether or not it is common knowledge.")

#text("As a warm-up, consider the case of K=1. A can see no blue. A realizes that he is the blue mentioned by the foreigner and kills himself after the first day.")

#text("If K=2, A can see one blue: B. A reasons that if he himself is not a blue, B must see no blue. In which case [A reasons], B will realize that he himself is the blue mentioned by the foreigner. If A’s assumption is true, B will kill himself after the first day. When he does not, A realizes that he himself is a blue and kills himself after the second day. By symmetry, B also kills himself after that second day. [I raise some questions about this proof, in the “options” section below, but later set them aside.]")

#text("If K=3, A can see two blues: B and C. A reasons that if he himself is not a blue, B must see only one blue: C. In that case [A knows], B would reason that if he is not himself a blue, C sees no blue. In which case [A reasons that B reasons], C will realize that he himself is the blue mentioned by the foreigner. If the assumptions are true, C will kill himself after the first day. When he does not [A knows], B will realize that he himself is a blue and will kill himself after the second day. And when that doesn’t happen, A realizes that he himself is a blue and kills himself after the third day. By symmetry, all of the other blues kill themselves after that third day.")

#text("Now consider the case of K=4. A can see three blues: B, C, and D. He knows that each of those can see at least two blues, and all know that every blue can see at least one other. (This is the “K-3 minimum,” although no blue knows the value of K — or needs to.) A reasons that if he himself is not a blue, B must see only two blues: C and D. In that case [A knows], B would reason that if he is not himself a blue, C sees only one blue: D. In which case [A reasons that B reasons], C might then reason that if he is not himself a blue, D sees no blues. But that is not possible because C knows (whether common knowledge or not, as A knows that B knows that C knows) that D can see at least one blue. So [A knows B realizes], C must know that C and D are both blue. (And, by symmetry, D would also know this.) If the assumptions are true, both C and D will kill themselves after the first day. When they do not [A knows], B will realize that he is a blue and will kill himself after the second day. And when that doesn’t happen, A realizes that he is a blue and kills himself after the third day. By symmetry, all of the other blues do the same on that third day. [Third day, not fourth!]")

#text("This is the same kind of reasoning as for K=1, 2, and 3, except that knowledge of the K-3 minimum is stronger than the common-knowledge minimum provided by the blue-eyed foreigner. If each blue can see at least one other blue, there must be at least two blues. This cuts short the reasoning chain by one step and therefore all four blues die after day three rather than day four. (This is true for K greater than 4 as well: all of the blues die on the third day, regardless of their number. The reasoning chain only goes three deep before the minimum of K-3 blues cuts it off.)")

#text("Notice that there was no inductive hand-waving in this proof; no “and so forth” saying that case K=4 works just like (or depends upon) cases K=2 and 3. I am, however, leaving it to the reader to prove — by induction or by parameterizing on K and/or N — that K=5 and above follow the same pattern as K=4.")

#text("I will give you the K=5 case: A can see four blues: B, C, D, and E. He knows that each of those can see at least three blues, and all know that every blue can see at least two others. A reasons that if he himself is not a blue, B must see only three blues: C, D, and E. In that case [A knows], B would reason that if he is not himself a blue, C sees only two blues: D and E. In which case [A reasons that B reasons], C might then reason that if he is not himself a blue, D sees only one blue: E. But that is not possible because C knows (whether common knowledge or not) that D can see at least two blues. So [A knows B realizes], C must know that C, D, and E are all blue. (And, by symmetry, D and E would also know this.) If the assumptions are true, C, D, and E will kill themselves after the first day. When they do not [A knows], B will realize that he is a blue and will kill himself after the second day. And when that doesn’t happen, A realizes that he is a blue and kills himself after the third day. By symmetry, all of the other blues do the same on that third day. [Third day, not fifth!]")

#text("A problem with these solutions should now be obvious. Notice that the foreigner’s pronouncement wasn’t necessary to create the reasoning chain for K=4 and above (Actually, for K=3 and above, as I will show here.) Populations of fewer than three blues are stable in the absence of the foreigner’s comment, because the K-3 limit is less than zero and so conveys no extra information. For K=4 and above, the inference chain and “countdown” are self-triggering because all blues know that there are at least K-3 blues (even though they don’t know K). For K=3, that rule says each blue knows that each blue can see at least zero blues, which is ambiguous. (There might be one blue or none.) I invoke my previous proof that any islander who sees two blues [as here] knows there are at least two blues, all knowing (in common, I believe) that each sees at least one blue and that K is at least 1. Hence the K=3 case is also self-triggering.")

#text("Self-triggering is a problem for two reasons: because it makes the populations unstable so that we can’t know when “Day 1” occurred, and because the reasoners themselves can’t be sure that all reasoners are using the same “Day 1.”")

#text("Most of these puzzles include a statement about the island populations having been as they are since time immemorial. (Green-eyed dragons “have been living in blissful ignorance throughout the ages and haven’t seen a human for many centuries.” xkcd’s blue-eyed islanders have (or will) exist for “endless years,” presumably endless in the past.) That doesn’t mean the native population never changes, but we are meant to believe that the countdown chain has never previously been triggered (which could end that population forever, and would certainly mess with our thought experiment). Such an endless past isn’t stipulated in our particular version of the puzzle, though.")

#text("In the absence of the stipulation, it is possible that all of the blues in excess of two arrived in the recent past (or joined the community via initiation ceremony). On that day, or as soon as each was known to have made eye contact with the others, the countdown chain would be triggered. That would become “Day 1” and the blues would all commit suicide on the third day. It would not matter how many there were (if at least three) or whether a foreigner made an ill-advised remark at any time within those three days. From the foreigner’s perspective, the deaths would be entirely unpredictable — and definitely not his fault.")

#text("This is technically problematic even for the puzzles that do include a “time immemorial” stipulation, unless it extends infinitely far into the past. If there was a day of creation for the blue population, however far back, it would have triggered the countdown immediately. No more than two blues could be present on the oracular day, unless newly arrived. Thus such puzzles contain a logical contradiction if the number of blues is any value greater than two.")

#text("Let’s ignore that quibble, though, and postulate that no such line of thought is to be pursued. (This has to do with the culture of puzzle construction and intent-cognizant solution, which sometimes overrides mathematical rigor.) We then see the foreigner arrive at the island in its stated condition, with the countdown logic chain applicable — as is obvious to all perfect logicians — but not yet triggered. What does that imply for K=3 and above?")

#text("I see four possibilities (or options, if we puzzle solvers are to choose one), depending on the islanders’ policy for initiating this countdown chain. (Of course they could also follow a meta-policy, such as a rule that switches between these policies.)")

#text("First, self-protection. The islanders knew the foreigner could be a threat, so they may have agreed — explicitly or implicitly — that no statement about eye color by the foreigner could be considered reliable. Then the countdown chain is not triggered even for K=1 or 2. Whatever has been keeping it from triggering for K=3 and above continues to do so. (Perhaps this is also by mutual agreement.) The blues have already passed up an infinite number of opportunities to trigger those inferences, so why not one more? No blues commit suicide on the following days. We however, as recreational puzzle solvers, may take issue with this option. “Nothing happens” is an interesting result, and was difficult to figure out, but it didn’t derive from the problem statement and isn’t the conventional pattern for puzzles with oracular pronouncements. It’s more of a “lateral thinking” solution, and seems to violate the spirit in which the puzzle was offered.")

#text("Second, no synchronization policy. Synchronization to a specific “Day 1” isn’t logically necessary as presented. We have accepted (or postulated) that this was true in the past, and it could be true even in the face of oracular pronouncements. If any blue can’t be certain that all blues are following the same countdown chain (with synchronized days), the chain of inferences breaks (even for K=2). Reasoners wouldn’t know for certain that each is going to treat the foreigner’s announcement as a synchronizing event, so they can’t make any additional inferences from successive days without suicides. Either they always decide such reasoning is futile (and no one dies), or an indeterminate number accept the foreigner’s trigger cue, with unpredictable results and a loss of insight into other reasoners’ knowledge and thought processes. This can’t be what the puzzle author intended.")

#text("Third, “lazy inference.” Each blue realizes immediately that the stranger has imparted no new information, so no other chains of inference are triggered. This was John Graeme’s choice. It would prevent triggering in the K=3 case, but so what? That one wasn’t given to us as a “given.” As I noted above, though, the answer that “nothing happens” didn’t derive from the problem statement and isn’t very satisfying. Also, see the argument below that the foreigner can trigger a synchronization event even if imparting no information (for a logician’s usual concept of information).")

#text("Fourth, “spreadsheet updating.” This seems the most satisfactory option. No one mentioned eye color in the past, so the countdown chain was never triggered. Today the foreigner mentioned eye color, so — even though no new information was given — all reasoners update their beliefs concerning eye color. In doing so they discover that they could have come to the same conclusion previously, based on their common knowledge, had they just all thought about it on the same day. This seemingly violates the stipulation that “any conclusion that can [be] logically deduced from the information and observations available to an islander, will automatically be known to that islander,” but we can argue that these conclusions couldn’t be deduced prior to anyone mentioning eye color. Synchronization, or agreement on a “Day 1,” is a necessary precursor for K=3 and above, and synchronization was lacking.")

#text("OK, let’s go with that one. It’s reasonable and it gives the same result as the K=1 and 2 cases as analyzed above (though by a different mechanism, so further proof by induction is suspect). Fans of the Green-Eyed Dragons puzzle (")#link("http://io9.com/can-you-solve-the-hardest-logic-puzzle-in-the-world-1642492269")[#text("http://io9.com/can-you-solve-the-hardest-logic-puzzle-in-the-world-1642492269")]#text(") can now answer the question posed there: “What information did the foreigner impart?” It was not knowledge that there is at least one GED, nor even the common knowledge of at least one GED. It was the knowledge that “Today is to be considered Day 1 by all reasoners.” This is what triggers the countdown and the mass exodus of the GEDs (after Day 3, not after Day 100).")

#text("So now we have our answer: the 100 blues on the island all commit suicide after three days. Each blue sees 99 blues, knows that each of those sees at least 98, and knows that all agree there must be at least 97. The foreigner provides a synchronization event (because we insist it must be so, for a good puzzle), and the countdown begins. Because the known minimum is 97, the reasoning chain is limited to depth three and [I assert] common knowledge is present or is not required. The non-blues on the island don’t know that they are not blues, so they are also participating in these counts and deductions. However, the deaths of the blues always occurs one day before any non-blue would be forced to conclude that he is a blue. (Nothing in the puzzle statement can prove any other eye color, so no non-blue could ever learn his own color. And all are perfect logicians, so none could possibly be fooled into believing he is a blue, since such a proof is necessarily false.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-457310")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2015")])]

#text("I’d like to go over this with you one post at a time, if you’re up for it. Rather than address your reasoning directly (that could get very complex very fast), I’ll propose various hypotheticals to deal with some of your conclusions. I’ll start by focusing on this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Populations of fewer than three blues are stable in the absence of the foreigner’s comment, because the K-3 limit is less than zero and so conveys no extra information. For K=4 and above, the inference chain and “countdown” are self-triggering because all blues know that there are at least K-3 blues (even though they don’t know K).")
]

#text("Suppose you are an islander, and therefore don’t know your own eye color. You and six others spontaneously come into existence at the same time, so we can consider there to be a “day zero” before any visitor arrives to say anything about eye color. We’ll simplify things by assuming that you only have to kill yourself if you determine your eyes are blue; brown-eyed people are permanently safe.")

#strong[#text("You see that three of the other islanders have blue eyes, and the other three have brown.")]

#text("What will happen if your eyes are in fact brown? What will happen if your eyes are in fact blue?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8f3dab1f4121e1a127d0e10cf8842c2ee178c9b1ba40ac3a794c9b302147347-8e3fe2a6200d1e8f13b4a9cce22be6470e59e012421f64a0dd081eb8a791d253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Laws")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-457409")[#strong[#text("Ken Laws")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2015")])]

#text("And thus I was enlightened.")

#text("Hi, Lenoxus! Thanks for taking me seriously (if only to show me the way).")

#text("Good test case. I’ve worked it out as rigorously as I can, and found that my previous reasoning had flaws. I had reasoned only about what blues must know, and hadn’t considered it important to reason about what non-blues in the same circumstances know. No islander can know which is his own situation, so both lines of thought are important.")

#text("Had I been a mathematician using symbolic methods, most likely I would have seen that correct reasoning by a blue necessarily includes the non-blue line of reasoning. I thought I had covered that, but it was one level too deep for my intuitive approach. One more instance of a proof that was suspect because it didn’t use LaTeX. (I was good at LaTeX, 25 years ago…)")

#text("Anyway, here’s my full analysis for anyone who wants to slog through it.")

#text("What all can see and know immediately:")

#text("If my eyes are brown (though I don’t know it): K=3, though none of us knows it. I can see three blues. Each blue sees two blues and knows that every blue sees at least one blue. All blues know (as common knowledge, since it’s tautological) that every blue can see at least no blues.")

#text("My “non-omniscient N” reasoning only states what a blue can see and know. If I assume [wrongly] that I am a blue, K=4 and each blue (including myself) sees three blues and knows that every blue sees at least two blues, and knows (as common knowledge?) that every blue can see at least one blue. But if I assume I am not a blue, that reasoning doesn’t apply. I don’t know which is the true case, so I can only assert that every blue can see at least no blue")

#text("I’d love to rescue my “proof,” so I’ll try my “non-omniscient N” reasoning for an arbitrary blue “B” that I can see. B sees two blues and knows that K is at least 2. B also knows that C and D can each see at least one blue, and that they know K is at least 1. C and D would be reasoning similarly, so all know that K is at least 2 and that each other blue knows K is at least 1. But that is not common knowledge! B can’t know if he is a blue, so he can’t know if C and D each see only one blue and thus know only that all blues see at least none.")

#text("Oops, I got that wrong in my original post. My argument required that each blue know K is at least three (or that he himself is a blue, or that each other blue sees at least two blues), which is not possible without an omniscient viewpoint. My assertion that the K=3 case is self-triggering was wrong. Each blue does know that K is at least 1, but can’t prove that each other blue knows K is at least 1. What I didn’t allow for is that it matters what brown-eyed reasoners think in these situations, since any given reasoner can’t know which case is correct.")

#text("My K=3 argument has now fallen apart, but I will soldier on to see what happens for the K=4 case (and to correct my previous post, lest it confuse anyone else).")

#text("If my eyes are blue (though I don’t know it): K=4, though none of us knows it. Each blue (including myself) sees three blues and knows that every blue sees at least two blues, and knows (as common knowledge?) that every blue can see at least one blue. Each blue knows that there are at least three blues on the island, and that every blue knows there is at least one.")

#text("[Note the question mark above. My assertion, in my original post, was that each reasoner can prove this K-3 minimum in the general case, and each knows the others must do so, so it becomes common knowledge. That result would remain true even though “I” am not an arbitrarily chosen “A” as in the proof. But is the result just mutual knowledge? And does that matter?]")

#text("I [as an islander] don’t know which case is true. I do know that at least the above K=3 minimums hold: each blue (including myself, if blue) sees at least two blues and knows that every blue sees at least one blue. All blues know (of course) that every blue can see at least no blues. I also know that the higher K=4 minimums above will apply if it is every proven that the K=4 case is true, or apply hypothetically if I were to assume that my eyes are blue.")

#text("What I can infer from events:")

#text("If I were to assume that I am a blue, arriving at a contradiction would not establish my eye color. In the following I therefore always assume that I am not a blue, and likewise for the hypothetical reasoning of blues that I can see. (Given my previous gaff, though, I’m a bit unsure that avoiding all “I am blue” assumptions is fully rigorous. Use of symbolic logic to cover all cases would be preferable.)")

#text("If my eyes are brown (though I don’t know it): This is the K=3 case, and I’ve already caved on this one. Nothing happens without a trusted oracular pronouncement.")

#text("B sees only two blues: C and D. B reasons that if he is not himself a blue, C sees only one blue: D. In which case [B reasons], C would reason that if he is not himself a blue, D sees no blues. B knows that can’t be true of D, because he knows D can see at least one blue; however, B doesn’t know if C knows that D can see at least one blue. But if a [trusted] foreigner says there is at least one blue, C knows that D would learn his own eye color and commit suicide after this first day. When that doesn’t happen, C would knows his assumption is false and commit suicide after the second day — as would D, by symmetry. When they do not, B realizes that he is a blue and kills himself after the third day; C and D do the same (again, by symmetry).")

#text("Meanwhile, I would be following similar reasoning: If I assume [correctly] that I am not a blue, B must see only two blues: C and D. B would reason that if he is not himself a blue, C sees only one blue: D. In which case [B would reason], C might then reason that if he is not himself a blue, D sees no blues. But if a [trusted] foreigner says there is at least one blue, C knows that D would learn his own eye color and commit suicide after this first day. When that doesn’t happen [B reasons], C would knows his assumption is false and commit suicide after the second day — as would D, by symmetry. When they do not, B would realize that he is a blue and kill himself after the third day; C and D would do the same (again, by symmetry). This in fact happens, and I am not forced to renounce my assumption. My eye color remains unknown.")

#text("If my eyes are blue (though I don’t know it): This is the K=4 case. The usual inductive proof holds, unless there is a source of common knowledge (or deep-enough knowledge) other than a trusted oracle. The result can also be shown non-inductively. In detail:")

#text("Assuming [falsely] that I am not a blue, B must see only two blues: C and D. B would reason that if he is not himself a blue, C sees only one blue: D. In which case [B would reason], C might then reason that if he is not himself a blue, D sees no blues. If all know there is at least one blue — or if C necessarily knows that D knows it — C knows that D would learn his own eye color and commit suicide after this first day. When that doesn’t happen, C would knows his assumption is false and commit suicide after the second day — as would D, by symmetry. When they do not, B would realize that he is a blue and kill himself after the third day; C and D would do the same (again, by symmetry). When they do not, I realize that I am a blue and kill myself after the fourth day; all other blues do likewise.")

#text("If an oracular common knowledge was required, there is nothing special about the case K=4.")

#text("Is it certain that C knows that D knows there is at least one blue, even in the absence of an oracle? [That would make this case self-triggering, and cut short the reasoning depth.] C is one of the three blues that I can see, chosen arbitrarily and given that name by me. I know that C can see at least two blues (B and D), and that C would know that D can see at least one blue (B). B, however, cannot be certain of this and is in fact hypothesizing that he is not a blue, that C can see only one blue, and that D can see no blues.")

#text("Let me dispense with a couple of misleading paths: D can actually see three blues, in this K=4 case, and so can any blue. That is not sufficient to tell anyone their own eye color, which can only be done through an asymmetric “countdown chain” of refuted assumptions. Suppose that chain were triggered by C knowing that D knows there is at least one blue, without reference to B’s assumption. Then C sees two blues (B and D), and knows D can see at least B. Likewise D sees B and C, and knows C can see at least B. Neither can prove his own eye color, and neither commits suicide. Other blues can’t draw any inferences from that, so nothing happens.")

#text("Is it sufficient that B [assuming himself non-blue] knows that C [assuming himself non-blue] knows that D knows there is at least one blue? Only if I am also assuming myself non-blue, since otherwise D could believe that I am the one. No, the chain has to go all the way down, to four levels.")

#text("My original claim was that if there are K blues on the island, every blue sees K-1, knows that every blue sees at least K-2, and knows each of those blues can see at least K-3 blues. Each can prove this to be true, and knows that each other blue can prove it. I asserted that this abstract formula is common knowledge, even though K is not known to any of the blues.")

#text("Alas (for my argument), that doesn’t create a useful lower limit. To do so, each blue would have to know K, or that he is a blue. The formula states what must be true (and knowable from an omniscient viewpoint), but not what an islander could know to be true of other islanders’ knowledge.")

#text("In our current case, K=4 and so each blue sees three, knows that each can see at least two, and knows that each of those can see at least one. This is true in reality, but not true (or not applicable) under my necessary test assumption that I am not a blue (and thus K=3 and there might be a blue who sees no other blue). It that case I know that B knows that C knows there is at least one blue, but I can’t know that D knows it in the absence of an oracular pronouncement.")

#text("Summary:")

#text("I could keep pushing this around, trying to find some error in my current thinking that would re-establish my previous argument, but I don’t believe I would succeed. The case of 100 blues still doesn’t feel right to me, but that’s the whole point of such puzzles.")

#text("To summarize, I recant my previous heresy and accept the usual proof by induction. There is nothing special or self-triggering about the K=3 or K=4 cases. A trusted oracle (or foreigner) is required, and will trigger a mass suicide after 100 days. There is nothing unstable about the island culture in the absence of an oracle, and my discussion of various policies and options is irrelevant and hereby withdrawn. Mathematics is not an ass, and I apologize to her. I leave the field with head held reasonably high, though still uncertain of my own eye color.")

#text("Somewhere in Hell there is an island with 100 blue-eyed logicians…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-457470")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2015")])]

#text("I’m gratified to read this. You clearly put a lot of thought into the problem both before and after my comment. Your last sentence made me chuckle. Cheers!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TET1968")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-460113")[#strong[#text("TET1968")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("I offer a permutation to the puzzle just for amusement value…. “One of the islanders is blind. We do not know his/her eye color.This person knows there are 1000 total islanders.” How does this influence events?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-464603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2015")])]

#text("There is a brilliant and hysterically funny dramatization of this puzzle here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://slatestarcodex.com/2015/10/15/it-was-you-who-made-my-blue-eyes-blue/")[#text("It Was You Who Made My Blue Eyes Blue")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08aeba788eb42c114f65790d7fddbc181f0fa13aba4164eccaf91c91fb2b0ae0-4d723fa9360663c0cc993f4e4e22f1b48354befe47fca574959ca9e695661019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Donis")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-464611")[#strong[#text("Peter Donis")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2015")])]

#text("@terrytao: “once the foreigner speaks in full view of all the islanders, it becomes common knowledge that there is at least one blue-eyed islander”")

#text("Wasn’t this already common knowledge? As long as there are 3 or more blue-eyed islanders, each islander can see at least two other people with blue eyes, and therefore each islander knows that each islander can see at least one other person with blue eyes. It seems like there is an implicit assumption that every islander knows that every islander knows what every islander can see, so every islander should know that every islander knows that there is at least one blue-eyed islander. And this should iterate indefinitely; every islander knows that every islander knows that every islander knows that there is at least one blue-eyed islander, etc. (In other words, the number of islanders that every islander knows has blue eyes does not continue to decrease as we add levels of “every islander knows”; it “bottoms out” at N – 2, where N is the number of blue-eyed islanders.)")

#text("In other words, shouldn’t the general rule be that, if there are N blue-eyed islanders, every islander knows (and knows that every islander knows, etc., indefinitely) that there are at least N – 2 blue-eyed islanders (i.e., this is common knowledge)? Thus, the foreigner can only convey new information, and therefore create new common knowledge, by observing that there are at least N – 1 blue-eyed islanders. (So in the case under discussion, he would have to observe that there are at least 99 blue-eyed islanders.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08aeba788eb42c114f65790d7fddbc181f0fa13aba4164eccaf91c91fb2b0ae0-4d723fa9360663c0cc993f4e4e22f1b48354befe47fca574959ca9e695661019.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Donis")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-464647")[#strong[#text("Peter Donis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2016")])]

#text("“Wasn’t this already common knowledge?”")

#text("Never mind, I see what I was missing. Start with the case of 3 blue-eyed islanders. Call them A, B, and C. A can see that B and C have blue eyes, so A knows that B and C can each see at least one person with blue eyes. But A does *not* know, for example, that B knows that C can see at least one person with blue eyes–for if A, hypothetically, does not have blue eyes, then B can see only one person, C, with blue eyes, and in that hypothetical case, B would not know that C can see someone with blue eyes, since B does not know his own eye color.")

#text("So in the case N = 3, we see that the common knowledge does not iterate indefinitely; it fails at two levels of indirection (A does not know that B knows that C knows…). For the case N = 4, it would fail at 3 levels of indirection (A does not know that B knows that C knows that D knows…); and for N blue-eyed islanders, the common knowledge fails at N – 1 levels of indirection–i.e., common knowledge of at least one blue-eyed islander is only present up to N – 2 levels of indirection.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c56017e24c6c803ea88a4c45416cb18559f84558e709d2a8551eadea60f855f-3cf566509021b049e996c14d8cfc4425b505dbecb7bc1ba05b8e724ceefe23e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mike pazda")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-464661")[#strong[#text("mike pazda")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2016")])]

#text("Little does A know what little B knows. If A knew what what little B knew then A would know a little.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-464654")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2016")])]

#text("communication complexity Professor Tao do you work on this as well?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b07f7f19542ae19c58d40c0d176dd5215505733162a348d40780f8b0c1c2e6f-da116256694eab6478de4d4449e3de24012bc7f09eeb5144c4001a96363fc9f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-467679")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2016")])]

#text("It is obvious that the second argument is flawed. If we follow this argument we are led to conclude that the natives will consider in their “logical” argument that there exist the possibility that only one native has blue eyes. However, all of them know that this possibility does not exist.")

#text("In more precise words, the recurrent argument does not apply to a set of n individuals because the analysis for the set of n-1 individuals cannot be isolated from the knowledge they have about the additional individual.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America | What's new")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-469270")[#strong[#text("It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("[…] example of the distinction comes from the blue-eyed islander puzzle, discussed previously here, here and here on the blog. (By the way, I would ask that any commentary about that puzzle be directed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-470130")[#strong[#text("Theory of Mind, Common Knowledge and Aumann’s Theorem | Mathematics in everyday life")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2016")]

#text("[…] (also mentioned in the lecture above), consider the Muddy Children puzzle, or the more dramatic Blue Eyed Islander Puzzle. The second link leads to Terry Tao’s blog where he writes in more depth about the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfyuanche")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-470400")[#strong[#text("xfyuanche")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("I learned the blue-eyed islanders puzzle from the Tao’s recent article about Trump. I think this puzzle is very interesting and leads us to think a technical and a little philosophic question: The islanders, and furthermore ourselves, should use mutual knowledge or common knowledge (disregarding mutual knowledge meanwhile) in the day-life reasoning? If you analyze the puzzle on the ground of mutual knowledge, then you find solution 1: the islanders will not suicide. As contrast, if you analyze the puzzle based on the common knowledge, then you get the solution 2: the islander will all suicide. The fundamental reason for different results is just simple: the foreigner only brings extra common knowledge information, but no any new mutual knowledge information, to the island.")

#text("Let me give a clear description of the two different derivations and the corresponding different results.")

#text("Case 1: The islanders are all common-knowledge thinkers, which means that they always use common knowledge (disregarding mutual knowledge meanwhile) as their starting point of logical deduction. After the foreigner leaves, if you are one of the 100 blue-eyed persons, what will you think? You will assume you were not bue-eyed and there are only 99 blue-eyed persons you have seen, then you want to see what will happens in this case. What will happens? Each of the 99 blue-eyed persons will assume himself were not blue-eyed and there are only 98 blue-eyed persons. And so forth, until they will see what happens when there were only 1 blue-eyed person. (Note: the repeated change-place- thought comes from the ignorance of the common knowledge.) OK. Let’s do the judgement. Because of the blue-eye information provided by the foreigner, if there is only 1 blue-eyed person, the person can rapidly realize this fact and suicides in the first day. If they find that no one suicides in the first day, it triggers the two blue-eye assumption and the two persons must suicide in the second day. And so forth, until all the blue-eyed person suicide.")

#text("Case 2: The islanders are all mutual-knowledge thinkers, which means that they always use mutual knowledge as their starting point of logical deduction. Since each blue-eyed person will see 99 blue-eyed person, the only reasonable assumption each of them will make is that there are 100 or 99 blue-eyed persons in the island. They will never assume that what happens when there were only 1 ,2 or 3 blue-eyed persons in the island, because such assumptions are obviously rejected by their known fact (all in all they have see 99 blue-eyed person, so there must be n>>2). If the islander still assume only a few of blue-eyed persons and use the reasoning chain like Case 1, now it will causes a obvious paradox. (We all know that the reasoning based on incorrect premise usually leads to ridiculous results, like building a delicate castle using floppy sands.) The islander starts to use the logic of Case 1 to judge whether or not n=1, whether or not n=2, whether or not n=3 ( it must go step by step rigorously, any questionable step will invalidate the next step)…..….But, meanwhile, inside himself, he clearly knows that n cannot be 1, cannot be 2, cannot be 3. (As we said above, they have known n>>2). How ridiculous! The islander will refuse this logic and they will say: why we must depend on the logic to tell us wherther or not n is 2, in the case we have known that n cannot be 2?")

#text("In conclusion, the ending of the islanders depend on that they are mutual-knowledge thinkers or common-knowledge thinkers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfyuanche")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-470403")[#strong[#text("xfyuanche")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("My addional remarks. The property of the above reasoning based on common knowledge (disregarding mutual knowledge meanwhile) is that how others think is far more important than the obvious facts or say mutual knowledge. In contrast, the property of the reasoning based on mutual knowledge is that the obvious facts are more important than how others think—-I don’t need to judge whether or not n=2 according to how the others think, because n obviously cannnot be 2!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franky_GTH")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-470831")[#strong[#text("Franky_GTH")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2016")])]

#text("I cannot make sense of the mutual-thinking logics. To me sounds like an attempt to oversimplify the case.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-470406")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("I think it is obvious that there are zero suicides provided the islanders are devout and do not speak among themselves regarding eye color. I think we can borrow from Schrodinger to understand why this is so.")

#text("Each tribal member is in a superposition of all possible eye color states as regards measurements made on his or her own system/person. Meanwhile, individuals are able to measure/observe other systems, but (legally) cannot perturb those system by adding information as with, for example, “Hey girl, you have blue eyes. And now you must die.” Telling a person about their eye color would be considered a form of einselection, or environmentally induced superselection, resulting with self-knowledge and the requisite suicide.")

#text("A stranger who is in possession of an awareness of his own state is obviously not in a superposition; this person enters the village and claims that, like many of the islanders, he *too* has blue eyes. This visitor has added no information to the islanders self-knowledge sufficient to collapse the eye color superposition, as the statement is merely a way of reinforcing what everyone already can *legally* observe. The highly logical islanders would see this faux pas as a *test of faith* in the sense that it invites conversation among tribe members regarding eye color; if these conversations do not happen and no measurement devices exist that would allow an observation of one’s own eye color, there would be no *logical* way to certify personal ownership of *any* eye color and hence no logical/religious requirement to commit suicide.")

#text("Any given islander obviously knows the total population of the island and also knows the eye colors of anyone they can observe. They know that there are 1000 total islanders. They know they can observe 900 brown eyed people and 99 blue eyed people, or 899 brown eyed people and 100 blue eyed people; this is as close as they can *possibly* get to an accurate census of eye color without knowing their own eye color and hence existing in an a priori “mode of violation” as respects the articles of their religious code. The available census information is *not* sufficient to collapse an individual superposition of possible eye colors without injecting additional information.")

#text("I would argue that in the absence of a measurement device (mirror), the most *illogical* action would be suicide, as it would be based on a bias, prejudice or a “best guess.” I would state that there is no “purely logical” method by which any islander can arrive at a knowledge of their own eye color, and thus no suicides should occur.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-470408")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("I see the error in my response…..")

#text("There are two sets of information, external and internal. The external information can be thought of as a list of all islanders and the associated eye colors (of course, this is a private list, not shared, and is 999 rows deep for each member, as it does not include their eye color). The internal information is simply a list of all possible eye colors that a person may possess, all of which are equally probable as far as the self-referencing islander is concerned. [This will become problematic from a religious point of view, as I explain below.]")

#text("When the visitor announces the presence of a blue eyed person this triggers an awareness that corresponds with the creation of a counter. Any given brown eyed person knows there are *at least* 100 or *at most* 101 blue eyed people, as the observer has no self-knowledge. The blue eyed people know they can see 99 blue eyed people and also that they are unaware of their own eye color, so that there are at least 99 or at most 100 blue eyed people.")

#text("Blue eyed people know in advance that it will take at least 99 days before a decision can be made, as they can see that there are 99 people with blue eyes, and the only way to discern their own eye color is if other blue eyed people also count 99 (rather than 98) sets of blue eyes. Brown eyed people know in advance that it will take at least 100 days before a decision can be made based on the same logic. At the expiration of 99 days, on the 100th day at noon, all 100 blue eyed commit suicide, as each of them becomes aware they are the 100th member of that set. Since they kill themselves, the other 900 now know they *do not* have blue eyes.")

#text("I assume that the religion is tolerant of islanders in the event they become aware of what eye color they do not possess? Is self-flagellation the appropriate response in that case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-471110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2016")])]

#text("I’m baffled by the number of people who, over the years, concluded that the collective suicide answer is the right solution to the puzzle… when the whole argument is on a wrong assumption.")#linebreak()#text(" The proof given supposes that the (n-1) individuals act as if there were only (n-1) people, i.e. the (n-1) people observed by the logician cannot observe the logician himself.")

#text("The real situations are as depicted below.")

#text("If n=1 then:")#linebreak()#text(" that person sees that either n=0 or n=1")#linebreak()#text(" that person is told that 10")

#text("Then they acquire the information n>0 and they conclude : then Z")#linebreak()#text(" But this is wrong, it could be Z, indeed, but it could also be A or B or C or …")

#text("The only cases where people can deduce the color of their own eyes are the cases where they can legitimately think that another person WILL ACT as if the case n=1 were possible.")#linebreak()#text(" When n>3 : they all know that everybody knows that the case n=1 is impossible, and so that nobody will act as if it were the case.")

#text("“But a dude with a Nobel prize said so”")#linebreak()#text(" No he didn’t. Go read the article he got the nobel for, and you’ll see that it requires individuals to share their “posteriors” (the information they deduced) and revise it, then share again until they agree. In the blue islanders puzzle, the individuals do not share their posteriors,")#linebreak()#text(" Indeed, instead of saying “I know that n is equal to X”, by not suiciding they say “I know that n is not equal to X” wiich contains less information than the previous.")#linebreak()#text(" The conclusion of that paper : we cannot agree to disagree, and not we cannot agree to agree that we ignore.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-471117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2016")])]

#text("I add that the collective suicide is only possible if by convention in the tribe 0 divided by 0 equals 1. Go read the conditional probability formula and write down your chains of hypothesis and you’ll see that you divided by 0 to find the collective suicide answer.")#linebreak()#text(" Don’t even try to use the argument of “it’s a limit because the recursion is infinite”. It’s bullshit and you know it because n is an integer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ViaLunaris")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-471725")[#strong[#text("ViaLunaris")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2016")])]

#text("I’ll admit I wouldn’t know how to parse the answer in terms of conditional probability, but I’ll run through the induction proof as best I can – and in the interest of foresight, if you still believe it’s incorrect, I’ll leave a series of questions to figure out what you believe the answer to be, and then rely on proof by contradiction instead.")

#text("Using induction to prove the statement: “after the foreigner speaks, if there are exactly X blue-eyed islanders, they commit suicide on day X”")

#text("Base case – if there is 1 blue-eyed islander, he will commit suicide on day 1 after the foreigner speaks (and thereby makes him aware)")

#text("Inductive step – assume that the statement holds true for a specific N: “after the foreigner speaks, if there are exactly N blue-eyed islanders, they commit suicide on day N”, and now prove for N+1")

#text("So in the case of N+1, I will choose the perspective of a random islander from this group, who then observes N blue-eyed islanders. Since the statement holds true for specific N, he expects them to commit suicide on day N. When this does not happen, the logical conclusion is that there are not N blue-eyed islanders, and seeing nobody else, he will conclude that he is also, and will commit suicde the next day, along with the rest (by symmetry – no other blue-eyed islander should have a different thought process)")

#text("Thus if it is true that “after the foreigner speaks, if there are exactly N blue-eyed islanders, they commit suicide on day N”, it is true for (N+1) – combined with the base case, I have proven it for all natural numbers.")

#text("————————————————————————————-")

#text("Now maybe that still didn’t convince you, so I’d like to ask a couple of questions then about your conclusions (when n > 3, nobody will act after the statement)")

#text("Do you agree that the presence of any non-blue eyed islander does not affect the conclusion? (if there are 2 blue-eyed, they will commit suicide on day 2 regardless of 0-1,000 brown-eyed, and if there are 4 blue-eyed, they will not commit suicde on day 4 regardless of the 0-1,000 brown-eyed)")

#text("By your statement about n>3, I’m going to assume that you believe with n=3, that they collectively suicide on day 3, but nothing happens at n = 4. (if you believe that n = 3 still nothing happens, but n = 2 means suicide, just subtract 1 from everything I’m about to say)")

#text("Let’s simplify for this problem by establishing a clear day 1 with a statement as well.")

#text("On day 1, you and 3 blue-eyed people spontaenously pop onto the island together, along with a booming voice that says “amongst you, there is at least one pair of blue eyes”.")

#text("You observe, that after 3 days pass, they have not yet commited suicide. Do you know what your eye colour is?")

#text("If you say you don’t, I’ll tell you that your eyes were actually brown, and somehow, your previously conclusion about collective suicide on day 3 was wrong, because there were 3 blue-eyed and they did not commit suicide on day 3.")

#text("If you say you do, then I’ll tell you that your eyes are blue and that the statement about non-collective suicide on day 4 is wrong because you have figured out your eye colour and will suicide along with the rest on day 4 (by symmetry). [[side note, if you say that you know your eye colour and it isn’t blue, then you’ve contradicted case n=3 yourself]]")

#text("This can be done for any “breakpoint” where you believe that they will suicide at X but not X+1 – I’m willing to elaborate once I see how you’ve thought this part through.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724f06e83e79c7683d48d634b68e70d65c84060912e304393486109b9ac8f8b0-66bc7dab65ecf613e140d222b0690b490a81d73a4849ae08d047828da0912813.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-478267")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2017")])]

#text("Its very easy, the foreigner says nothing new to the tribe, The blue eyed all see 99 blue eyed persons and 900 brown eyed. The brown eyed all see 100 blue eyed and 899 brown eyed. No one knows his own color. The only way for they to know would be the case of there existing only one blue eyed person, who seeing no other blue eyed would know his color, when he commits siucide, the rest would know he was the only blue eyed and they would know their color and commit suicide next noon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91d9efd3007cf232b136ce32937e55ed37f8fd37bc5cd9e093e951490cc02438-69e8af2cdedd1e30f8f50b962dfbe79dc2a73a367182c263520e1afbe2680b0a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wrichik Basu")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-479396")[#strong[#text("Wrichik Basu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("{Usual caveat : I’m sorry if this has been proposed and refuted before but a quick run through the thread didn’t seem to suggest that is the case.}")

#text("Regardless of whether solution 2 to the question i.e. all n BEP leave after n days of the announcement is valid or not, I think the proposed inductive proof is no good at all. Let us consider a rival solution and see if we can come up with an identical inductive proof for it.")

#text("Proposition. Suppose that the tribe had n blue-eyed people for some positive integer n. Then n^2 days after the traveller’s address, all n blue-eyed people commit suicide.")

#text("We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her, and thus commits suicide on the next day. Now suppose inductively that n is larger than 1. Each blue-eyed person will reason as follows: “If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island, and so they will all commit suicide (n-1)^2 days after the traveler’s address”. But when (n-1)^2 days pass, none of the blue-eyed people do so (because at that stage they have no evidence that they themselves are blue-eyed). After nobody commits suicide on the (n-1)^{2th} day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the n^{2th} day.")

#text("Any strictly increasing function f(n) that satisfies f(1) = 1 (and possibly, f(0) = 0) can be shown to be the solution using this inductive proof.")

#text("Of course, this does not disprove solution 2, but I think this disqualifies the inductive proof offered in support of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91d9efd3007cf232b136ce32937e55ed37f8fd37bc5cd9e093e951490cc02438-69e8af2cdedd1e30f8f50b962dfbe79dc2a73a367182c263520e1afbe2680b0a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wrichik Basu")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-479398")[#strong[#text("Wrichik Basu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("Nope, not a valid argument. “After nobody commits suicide on the (n-1)^{2th} day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the n^{2th} day.” is wrong – they would commit suicide on (n-1)^2 + 1 days.")

#text("My bad.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484126")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2017")])]

#text("I have not read all the hundreds of posts on this topic, so I apologize in advance for any duplication. I posted some comments/questions about the blue-eyed islanders a few months ago, but under a different, related, thread, and one person responded. I am reposting it here (since I see there has been some recent activity here) in the hope of getting some more comments.")

#text("It seems the debate is about which of two solutions is correct. 1. that the visitor to the island imparts no new information and thus nothing happens, and 2. that the visitor’s announcement starts the induction process. My question is: might there be a third solution, namely that the induction process DOES indeed take place, but the visitor’s announcement about eye-color is not needed for that to happen. In fact, I think the induction process would start happening the moment the people are told of the conditions of residing on the island, namely that if they discover their eye color they must commit suicide (or in other versions of this puzzle, leave the island)")

#text("To describe my reasoning, I will use the version where, instead of committing ritual suicide, the islanders can leave the island once they know their own eye color. (The only reason I want to use this version is because I find it easier to describe a situation that all the islanders want, rather than one they don’t want.) Everything else stays the same, i.e. 100 blue-eyed people and 1000 brown-eyed (I don’t want to complicate it by bringing in other colors).")

#text("So, let’s say the islanders all WANT to leave the island, but when they were first put on the island, they were all told, at the same time, that they can leave only if and when they know their own eye color. And there’s a boat that arrives and leaves every day at mid-day, in case any of them should find themselves in that happy situation.")

#text("Since there are 100 blue-eyed people and 1000 brown-eyed people, everyone knows that everyone else knows that there are many blue-eyed and brown-eyed people there.")

#text("So, is it really necessary to have someone say out loud “I see someone with blue eyes”? Whom would that statement benefit? The hypothetical solitary blue-eyed person who, without the statement, could not leave? But hypothetical people cannot hear anyway. So it is only for the benefit of the mental calculation, for each person to be able to start their induction process by reasoning “if I was the only blue eyed person I would never know it until someone made the statement.” But then they could further reason “but that is a hypothetical situation, and so I will assume that in that hypothetical situation someone has already made the statement, so that we can get past that step.”")

#text("In other words, they could act AS IF that statement had been spoken, i.e. they could ASSUME that blue eyes on the island is common knowledge. And they can be confident every other islander will be making the same assumption because they all know that everyone is perfectly logical.")

#text("I mean, they all want to get off the island. Would they really sit around for years thinking “oh I do wish that the boat operator who comes here every day would just announce that there is at least one blue-eyed person here (which we all already know anyway) so we can all start getting off this island!”?")

#text("Finally, I wonder if anyone has tested this puzzle? For example, a dinner party, with colored stickers on everyone’s forehead, and an opportunity (say when a bell is rung, every couple of minutes) to start eating if they know their sticker color…")

#text("I would like to know if my reasoning is flawed, and if so where. (I am not a mathematician, so I can’t read the formulas and symbols I sometimes see with the various explanations.)")

#text("Thank you in advance for any comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484139")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Hmmm, I am wondering – in the version I described above, there is a slight, but maybe crucial, difference from the original puzzle.")

#text("I said that the people were all put on the island and someone announced to them that they can leave if and when they discover their own eye color.")

#text("In the original puzzle, on the other hand, the people already live on the island, so presumably they learn about their religion at different times (since new people are being born). So they do not have a synchronization point as to when to start the induction, which is what the visitor gives them.")

#text("Now, if they had NOT grown up with the knowledge that ritual suicide must happen once they know their own color, then it would be enough for the visitor to say something like “by the way, this newly-discovered ancient sacred scroll here says you must commit ritual suicide if and when you now your eye-color.” (Again, this is treated as a logic puzzle, not realism, so it is to be taken for granted that they will do as prescribed in the scroll). So in that situation, the foreigner would not need to say “I see someone with blue eyes” since that part they can work out as per my revised version reasoning in previous post. Anyone agree/disagree? Again, thanks in advance for any comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("nmks-Assume the scroll is read and everyone starts counting.")

#text("Scenarios…")

#text("A. 1 person on the island (blue)…he has no clue about his color…no one dies")

#text("B. 2 people(both blue)- each sees one person with blue but each has no clue about his own color…no one dies")

#text("C. 2 people(one blue one green)- neither one has a clue about his own color…no one dies")

#text("D. 3 people(one blue two green)-the blue sees two green and each green sees one blue and one green but the blue has no clue about his own color…same for the greens….no one dies")

#text("E. 3 people(two blue one green)- the green sees two blue but has no clue…the two blues each see a blue and a green but they have no knowledge to let them figure out their own color…no one dies")

#text("F. 3 people(all three blue)-each sees two people with blue so everyone knows that everyone knows at least one person has blue. (BTW-this not a requirement for any solution) However, each one knows they might have a different color from the two blue they see so each one has no clue to what his own color is.")

#text("In all scenarios no one could determine their color. The counting they were doing was not relevant. What’s the missing clue? It is the lack of being told that at least one person has blue eyes. Inject that clue starting in the first scenario and it is easy to see how the blue eyed people determine their eye color. Let’s look at F. with the clue added in to F.")

#text("New F. 3 people(all three blue)-No one kills himself after Day #1 since each person sees two blue eyed people. Each person says to himself…”I sure hope the other two kill themselves tomorrow because that means each of them sees just one blue eyed person and that would mean I don’t have blue eyes. However, if they don’t kill themselves tomorrow that means each of them sees two blue eyed people and that would mean I have blue eyes also.” Day #2 no one kills himself so Day #3 all three die.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484162")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Thanks for replying! I am very glad to have a chance to discuss this.")

#text("But I am starting to move from my original thinking that the induction process would take place anyway, even if the visitor did not mention eye color as long as s/he explained the rules, to thinking that it would NOT take place even if the visitor DID mention eye color.")

#text("Because when the visitor says “there is at least one blue eyed person here” everyone replies “yes, thanks, we already know that.” The only person to whom this would be new information would be the hypothetical solitary person. And I am seriously beginning to question if one can bring that hypothetical solitary person into the equation. Because that means that after the visitor’s announcement everyone would have to think, “aha, now that (non-existent) hypothetical solitary person has heard the announcement and therefore the induction can begin.” But a non-existent hypothetical person has not heard anything!")

#text("Not saying this is correct, but this is the line I am now working through in my mind… What a fascinating puzzle, though!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2017")])]

#text("If you are thinking the induction process would not take place with the mention of eye color, please explain where and how you disagree with my conclusions in the scenarios I gave you.")

#text("Also, I fail to see the purpose of the hypothetical person.. Please explain how the hypothetical person adds knowledge to every tribe member. What that knowledge is. How that knowledge helps to create a solution.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484192")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2017")])]

#text("Please forget the second paragraph above…I failed to remember that you decided the hypothetical would not be of consequence.")#linebreak()#text(" -Dave")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d0d8b161c3711128e56f3dfd9b4225a425156bd605c9b6f869c27023bba4cc-2292f7b7dce34bba203d89fb6e61feb9c82472fb2aef24f629d6ab05894e8fb2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stickerstransfers")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484166")[#strong[#text("stickerstransfers")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Hence we have new information and no contradiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484381")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2017")])]

#text("Thank you for the responses. I don’t actually disagree with anyone – that’s the thing, I’m still trying to work out if I agree or disagree…Not only if the induction will take place or not, but the third possibility: namely that the induction can begin even without the visitor’s announcement (as long as the rules about finding out their eye color were explained to everyone at the same time)..")

#text("The induction as described above is very clearly presented and sounds logical. And yet.. I wonder if one can really base everything on a hypothetical situation where there is just one blue eyed person when everyone knows there are at least 99 of them..Because that’s what is happening in all the nested scenarios – one always ends up with that hypothetical situation where there is just one blue-eyed islander, and because he/she has not heard the announcement nothing can happen.")

#text("Since it is easier (at least for me) to imagine scenarios where the outcome is something the islanders want (like being able to leave the island) rather than something they would wish to avoid (like ritual suicide) I will go back to the scenario I proposed a few posts earlier – where instead of ritual suicide the goal is to get off the island, and when the people were put on the island they were told (all at once) that they can leave only if/when they know their eye color. And a boat comes and goes every day to give them the chance to leave if they can.")

#text("Since they are all logical people and know that everyone else is logical too, would they really sit around for years thinking “oh I do wish that the boat operator who comes here every day would just hurry up and announce that there is at least one blue-eyed person here (which we all already know anyway) so we can start getting off this island!”?")

#text("Why not just ASSUME (i.e., ACT AS IF) the boat operator had made the announcement. Being logical they would know that everyone would think so too. (They could still start with the one person scenario for the purpose of calculating WHEN they can leave, but those calculations can begin as soon as they are told the rules about leaving. THAT would then be the clock starter, and not the announcement about eye color, since the color they could work out as long as they make the assumption mentioned above.)")

#text("If someone could explain to me where the fault is in this argument that would be great.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484439")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2017")])]

#text("OK, nmks…time for you to figure some things out.")

#text("Here’s the situation…the island has 10 individuals…")#linebreak()#text(" Person 1 has blue eyes")#linebreak()#text(" Persons 2 and 3 have green eyes")#linebreak()#text(" Persons 4, 5, and 6 have brown eyes")#linebreak()#text(" Persons 7, 8, 9 and 10 have gray eyes")

#text("The situation you proposed now takes place.")

#text("Tell me how any of them figures out his eye color. Describe the thought process. Remember, each individual knows they themselves could have any possible color, including pink, orange, purple, black, etc.")

#text("Doing this should answer your question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484661")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2017")])]

#text("nmks: you ask why the induction could not begin even without the visitor’s announcement, since that announcement does not apparently give anyone any information that they did not have already.")

#text("In fact it does provide new information, but the new information it provides is not that there are some blue-eyed people (which as you say everyone knows already). It is (because it is announced publicly) that everybody then knows that there are some blue-eyed people, AND that everybody then knows that everybody knows that there are some blue-eyed people, AND that everybody then knows that everybody knows that everybody knows that there are some blue-eyed people, AND that (and so on, indefinitely).")

#text("You may ask “Since there are 100 blue-eyed people, surely it is common knowledge already not only that there are some blue-eyed people, but also that everybody knows that there are some blue-eyed people, and indeed that everybody knows that everybody knows that there are some blue-eyed people, and so on”. That is true. But _this_ “and so on” (unlike the one post-announcement) does NOT go on indefinitely, but only up to a hundred iterations of “everybody knows that”.")

#text("It is perhaps easier to persuade oneself of this if one reduces the 100 to a smaller number like say 3. If there are exactly three blue-eyed people, then before the announcement everyone already knows that there are some blue-eyed people, and everyone also already knows that everyone knows that there are some blue-eyed people (since even the blue-eyed can see that everyone – including the blue-eyed – can see one). But it is NOT true that everyone already knows that everyone knows that everyone knows that there are some blue-eyed people, since a blue-eyed person – although s/he can see that everyone (even the blue-eyed) can see another blue-eyed person, is not in a position to know that everyone can know that that blue-eyed person can also see one.")

#text("Even with 3 blue-eyed people the sense of this nested “knows that everyone knows that everyone knows that…” is difficult to keep track of. With 100 it is clearly impossible for the human mind. But this is where the induction proof comes in: it shows that if it is true for N, then it is also true for N+1. But it has to get started somewhere. N=3 is perhaps already complex enough that the point is clearer than for N=1 or N=2 (and hopefully not too complex that the point gets lost again…)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484512")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2017")])]

#text("Thanks, David Ricketts. But the puzzle you provided above for me to try and solve is very different from the one I was discussing. One of my points is that the same reasoning might not necessarily work for every situation. In the one you just proposed, there would be no way to discover the eye color. I was discussing the situation, where, as given in Terence Tao’s original post, there are 100 blue-eyed people and 900 brown-eyed people.")#linebreak()#text(" I changed the outcome from ritual suicide to permission to leave the island (although that should not alter the reasoning, it MIGHT (and I’m only saying MIGHT) influence the thinking of the puzzle solvers. But that’s a separate issue…)")#linebreak()#text(" Thus, the islanders know they can leave only if they discover their eye-color. They all want to leave. They have a starting point for beginning their calculations (they day they were all informed about the rules.) The only thing missing is the statement by an outsider that there is at least one blue-eyed person.")#linebreak()#text(" And I think I have already explained my reasoning for that situation. (Can’t do more now; have a busy stretch coming up; but can return to it in a few days.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ricketts")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484530")[#strong[#text("David Ricketts")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2017")])]

#text("Ok, nmks…I will change the situation I proposed above to be just like yours, but with less people.")

#text("3 blue eyed people")#linebreak()#text(" 5 brown eyed people")#linebreak()#text(" (Everyone can see only two colors and there are more browns than blues….just like the 100/900 situation.)")

#text("Now use your proposed changes and try to figure out how any of them can determine their eye color. (Remember, however, even though only two eye colors exist….just like in the original posting each individual does not know that fact, because each individual knows that they might be the only person with a color other than blue or brown.) If you are successful, please share the logic they used to be able to determine their eye color.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4737a7ac31ed5ffe48082de84fa88a96f225ab931aeede863b79d3e3de5076-e24a1b7f06ad02bc8214d367f72bf94f30973c9e010ca17d0d97ececd279412d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nmks")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-4/#comment-484766")[#strong[#text("nmks")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("Thank you, leopold and David Ricketts. I have further thought about this and have reduced the number of blue-eyed islanders from 100 to 6 (I wanted more that 3 as I do find problems with just 3). But taking it up from 3 to 6 showed me that the same reasoning does indeed continue, namely, one will always get to the situation where one can imagine a situation where no-one sees any blue-eyed people.")

#text("And yet, I knew that from the start…")#linebreak()#text(" What I am trying to do is find a possible flaw in this apparently very clear and logical situation. Because if I cannot find such a flaw, then I will accept it as correct. But I do keep finding, if not a real flaw, then at least a stumbling block. And (to my mind) the possible flaw (if there is one) lies not in the induction process, but in the fact that one is conflating the “hearing” of words, with the “thinking” of them in a situation where they (the words) only benefit a hypothetical situation (i.e., a situation where they cannot be heard anyway).")

#text("To explain what I mean I have written out a complete induction for 6 blue-eyed people, followed by 2 possible consequence scenarios. I will post this immediately after posting this post, so as not to make it overly long.")

#text("I must explain that I am not a mathematician. I am not familiar with the notation (symbols) that some arguments use, gosh, I don’t even know if I am using n=1 correctly (which I did for the first time, in the upcoming post). I just love puzzles, and I try to solve them by visualizing the situations. And I admire the wealth of intellectual material that mathematicians deal with, which to me is most fascinating. Thank you for the opportunity to discuss this puzzle!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e0c785b68a9336d0542562e678e98c5f8edfc3524f7dffe852dd2b9954792c-de6beda173ba3c965f81e6eb5d7f304feba647110225ed61db53c24d3456650d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoshuaR")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-65908")[#strong[#text("JoshuaR")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("No new information is given. All islanders already know there is at least one blue-eyed person on the island.")

#text("But they need the foreigner and if you look at this problem BACKWARDS from what others have explained, you realize a key difference.")

#text("I am blue. I do not know this. I look around and see 99. Suppose I am not blue. Then a blue person sees 98. Now that person doesn’t know he is blue. Since I don’t know that I am blue, and to his mind he doesn’t know that he is blue, I might assume that HE would think that there might only be 97 blues, if I am not blue. And so on and so on until we get to the “he might think that he might think that he might think… that he is the only blue or that there are no blues.” And so he cannot kill himself until someone states for certain there is at least one blue.")

#text("In real terms, each individual will guess there are 99-100 or 100-101 blues, but none will know where they stand on that totem pole. If one guessed he were on the high end, say a brown saw 100 blues, then he might guess he is number 101, or that there are 100 only. But if he puts himself in #100s shoes, he will say, “if I am brown, #100 will think to himself that he is either #100 or not blue.” And so on. It all matters what they can guess that another knows.")

#text("As soon as the foreigner comes in, when you get to “he might think that he might think… that he is blue,” the countdown starts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e0c785b68a9336d0542562e678e98c5f8edfc3524f7dffe852dd2b9954792c-de6beda173ba3c965f81e6eb5d7f304feba647110225ed61db53c24d3456650d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoshuaR")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-65910")[#strong[#text("JoshuaR")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2011")])]

#text("No new information is given. All islanders already know there is at least one blue-eyed person on the island.")

#text("But they need the foreigner and if you look at this problem BACKWARDS from what others have explained, you realize a key difference.")

#text("I am blue. I do not know this. I look around and see 99. Suppose I am not blue. Then a blue person sees 98. Now that person doesn’t know he is blue. Since I don’t know that I am blue, and to his mind he doesn’t know that he is blue, I might assume that HE would think that there might only be 97 blues, if I am not blue. And so on and so on until we get to the “he might think that he might think that he might think… that he is the only blue or that there are no blues.” And so he cannot kill himself until someone states for certain there is at least one blue.")

#text("In real terms, each individual will guess there are 99-100 or 100-101 blues, but none will know where they stand on that totem pole. If one guessed he were on the high end, say a brown saw 100 blues, then he might guess he is number 101, or that there are 100 only. But if he puts himself in #100s shoes, he will say, “if I am brown, #100 will think to himself that he is either #100 or not blue.” And so on. It all matters what they can guess that another knows.")

#text("As soon as the foreigner comes in, when you get to “he might think that he might think… that he is blue,” the countdown starts.")

#text("…")

#text("Edited because I forgot to say, but of course within minutes of reading the induction solution starting from 1, I was sure that was simple and that was it… until I really started to think about it the other way, that the foreigner didn’t really add new information, that it didn’t matter what would happen IF there were only 1 blue because that situation is impossible because there are certainly at minimum 99 blues to every person on the island… But then if you look at it in such a way as to say, “I know this but he may not know that if I am in fact this…” you realize that the induction method does indeed work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e63cebd18542e5afcdb37ab1487a887c06556879cb8e412ed68048c62f26f53-0263246dbf2e7128f94a59053bd0b066c1026a1c8f18cfe5d9ab069318ec61f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-69706")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2011")])]

#text("All blue eyed people see 99 other blue eyed people and that everyone else (900) are brown eyed. So they all know only 2 alternatives exist: 99 and 100 are the only alternatives. They also know everyone of the blue eyed people know of at least 98 are logical and honest so day one equal to 98.")

#text("Day 2 then is 99 and no one dies. On day 3 (set to 100 blue eyes) the whole village commits suicide under the mistaken (for 900 of them) belief they have blue eyes.")

#text("The reason is that the brown eyed people had different information then blue eyed people they would set the alternatives at 100 or 101. So day 1 was set as 99, day 2 was 100 and day 3 included them.")

#text("Even when everyone else showed up at noon (they would assume the brown eyed people had figured out they were brown eyed) based on all blue eyed people (themselves included) lining up in the square.")

#text("So the Foreigner doomed 900 people to commit suicide by flawed logic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e63cebd18542e5afcdb37ab1487a887c06556879cb8e412ed68048c62f26f53-0263246dbf2e7128f94a59053bd0b066c1026a1c8f18cfe5d9ab069318ec61f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-69743")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2011")])]

#text("I have an additional clarification before someone else brings it up. The logic of the 100 days of waiting. Each other person could only see -1 blue eyed people. This math works but does not make sense logically. Each blue eyed person knows that there are at least 99 people and at most 100.")

#text("Even if the other people only see 98 no one can see <98. This is common to the whole group so there is no need to start at 0 as no one can see less than 98 blues. I does not matter what the subjective count is or what someone else might think they think someone else thinks.")

#text("The absolute (objective) answer can only be 99 or 100 for everyone. All 999 other people see at least (98- blue eyes for blue eyed people and 99 for brown eyed people) if I am not blue eyed.")

#text("They see 99 and 100 if I am blue eyed.")

#text("So we start at the largest impossible answer of 97. We all know no one will kill themselves now as no one can see just 97 blue eyes. So at the next noon (Day 1) we advance to 98, Day 2 is 99, Day 3 is 100. No one dies on day one or two so I go kill myself on day 3.")

#text("What I don’t know (if I have blue eyes) is that the brown eyed people started at 98 because they know that everyone must see at least 99. They know the absolute (objective) answer is 100 or 101. For them Day 1 is 99, day 2 is 100 and now on day 3 they think the answer is 101 blue eyed people (including themselves) so everyone dies on day 3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-120217")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")])]

#text("I don’t think this argument works: I think that the blue-eyed people really do kill themselves on day 100. The problem depends delicately on what each person knows, what each person knows each other person knows, what each person knows each other person knows each other person knows, and so forth.")

#text("Imagine for instance that Adam is a blue-eyed person. Adam sees 99 (other) blue-eyed people, and therefore knows that there are exactly 99 or 100 blue-eyed people in total. Adam may then reason as follows: “Suppose there are 99 blue-eyed people. Consider one of the blue-eyed people I see, Bob say. Bob sees 98 other blue-eyed people, and therefore knows that there are either 98 or 99 blue-eyed people in total. Bob may then reason as follows: ‘Suppose there are 98 blue-eyed people. Consider one of the blue-eyed people I see, Carla say. Carla sees 97 other blue-eyed people, and therefore knows that there are either 97 or 98 blue-eyed people in total.'”")

#text("Reasoning like this can get you all the way down from 100 to 1. The point is: each person may know himself that there are 99 or 100 blue-eyed people, but each other person only knows that each other person knows there are at least 98 blue-eyed people, and worse each person knows only that each person knows only that there are at least 97 blue-eyed people, and so on.")

#text("I hope that made sense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca9dff4ba8f94ffff2bb20540930d271a5d7b02a02be80253ceb10a9b7ca0476-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale Dikes")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-105743")[#strong[#text("Yale Dikes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("figured out a solution that works; it uses only one inductive point at a time, a stable one, that is shared by all members of the party. And gets the blues gone in two days if they are equal to or less than the size of the other group. The …others may take longer, the others being the larger party. Either the next day, or after the others leave switch to the higher commonly viewed number.")

#text("Take 100 bs and 101 gs.")

#text("The method goes as follows The {b’s}* will see 99 the {G’s} will see 100 b’s but {G’s} will know that the b’s see 99 blues ( as the b’s they see can’t see themselves), they don’t know their own color, The {g’s} will likewise know that all the b’s they see will only have a shared view of 99 of the commonly viewed bs . The {b’s} will see 101 g’s and know they only have a shared view of 100. The lower number, call it lower commonly viewed number , is used by both as the starting point to avoid the inductive latter ; thus the starting point for both is 99. ( trigger point for both 98 blues or 98 greens) . It is not met. All stay. Day two: number goes to 100, b’s all see 99, and leave. Day three, either greens know there are two values and leave or the number is raised to to 101 and they leave.")

#text("The method goes as follows The {b’s}* will see 99 the {G’s} will see 100 b’s but {G’s} will know that the b’s see 99 blues ( as the b’s they see can’t see themselves), they don’t know their own color, The {g’s} will likewise know that all the b’s they see will only have a shared view of 99 of the commonly viewed bs . The {b’s} will see 101 g’s and know they only have a shared view of 100. The lower number, call it lower commonly viewed number , is used by both as the starting point to avoid the inductive latter ; thus the starting point for both is 99. ( trigger point for both 98 blues or 98 greens) . It is not met. All stay. Day two: number goes to 100, b’s all see 99, and leave. Day three, either greens know there are two values and leave or the number is raised to to 101 and they leave.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a64d12a81c970c1cc356d4a849351507f5d3c55982a5d8e8c24f7cd8ad34ab3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale Dikes")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-105746")[#strong[#text("Yale Dikes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("There are some, like suicide guy above, who think distribution like 99/ 100 create a problem for the inductive method used to solve the problem. Essentially, if there is a distribution of 99 blues and 100 browns poor browns all see 99 and what do they do?")

#text("They wait.")

#text("Remember the starting point, 98 leave iff 97) . no blue or brown leaves. Then 99 (leave iff 98). The blues leave. The hapless browns are spared. Than they leave via elimination if they know there are only two values, or by raising the induction point to 100 the next day. They never have to face the choice the apparent paradox purports.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a64d12a81c970c1cc356d4a849351507f5d3c55982a5d8e8c24f7cd8ad34ab3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale Dikes")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-105822")[#strong[#text("Yale Dikes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("Damn, screwed up with an illegitimate move. The induction points are different I inadvertently scewed it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a64d12a81c970c1cc356d4a849351507f5d3c55982a5d8e8c24f7cd8ad34ab3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale Dikes")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-105827")[#strong[#text("Yale Dikes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("Same applies to Henry where the number that a brown eyes will see is 100 meaning the possiblities would be 100 or 101, and the same reasoning would generate the number of off 99, and he would illegitimately want to leave with the blues on day 3.")

#text("Shhez. That the trick. Finding a stable induction point ( for blues and greens) other than 1. It seems that the traditional way might be the only way to accomplish this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a64d12a81c970c1cc356d4a849351507f5d3c55982a5d8e8c24f7cd8ad34ab3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale Dikes")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-105830")[#strong[#text("Yale Dikes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("Same applies to Henry’s solution : For green’s the possibilties are 100 or 101, so his method will generate 99 for them, not the 98 it does for blues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a64d12a81c970c1cc356d4a849351507f5d3c55982a5d8e8c24f7cd8ad34ab3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale Dikes")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-105831")[#strong[#text("Yale Dikes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2011")])]

#text("The only stable induction point seems to be 1. Even though they all know there is more that they all know , they can’t use it to pick a unique number. That’s the rub.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blue Eyes: The Hardest Logic Puzzle in the World « Guzman's Weblog")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-108321")[#strong[#text("Blue Eyes: The Hardest Logic Puzzle in the World « Guzman's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2011")])]

#text("[…] Tao’s The blue-eyed islanders puzzle – repost Share this:TwitterFacebookLike this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72dfe3b392c2c835eae5c4f0ba72f7387e025e94fb48ae74e245e2e60ec73de2-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ho")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-118182")[#strong[#text("David Ho")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2011")])]

#text("Hello prof Tao,")

#text("I really enjoyed going through your Diversions page. I have tried several puzzles and solved them. I thought the blue-eyed islanders puzzle wasn’t very difficult. The easiest way for me to solve these is to try simpler cases and induct upwards. So, I just thought of a room of 4 people, 3 with brown eyes and 1 with blue. Then I tried with 2 brown eyed people and 2 blue eyed people. It was easy to induct upwards from there.")

#text("The one puzzle that has me a bit unsure is the white/black sand mixture problem. I have sent you an email about it because the solution wasn’t listed on your webpage. I have also scoured Google and haven’t found a reasonable answer. I’ve even posted it on a puzzle forum and it has caused some controversy. I approached it several different ways and examined each conclusion. First, I tried using an exaggerated approach to make the solution more obvious. So, instead of one teaspoon, I transferred the whole bucket of white sand into black and mixed. This obviously leads to an equal mixture of impurities. I then tried a simplified model using small cubes as sand particles. This assumed even distribution in the mixture. In this case, I had to make some pretty big leaps in logic by making some assumptions that might not necessarily happen in the real world. Finally, I tried to solve it using algebraic techniques. This was a bit tricky, for me anyways, on the second transfer of mixed sand. It seems that the mixtures are still equal.")

#text("So, will you tell me if I’m right? Is the sand mixture equal in impurities? I can finally sleep at night once I know the right answer. :-) Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3928f4e5782e91633a2cdafd9d684306772b7a1c02b33ac77e33a3f0463c6be5-d95c3f076ac0b8a78d966bb9d98feabe32a37e0c004b84a124439b380c3aeec3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ho")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-120136")[#strong[#text("David Ho")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2012")])]

#text("Nevermind. I figured it out. The solution should look something like this:")

#text("Let X,Y = white sand, black sand bucket, and t = teaspoon and 0 <= t <= 1. So, removing one teaspoon from Y to X:")

#text("Y-tY ; X + tY")

#text("Removing a teaspoon from X + tY to Y – tY we eventually get:")

#text("t/(t+1) * X + t/(t+1) * Y in one bucket and 1/(t+1) * Y + t/(t+1) * X in the other. What this shows is that the amount of impurity X in one bucket is equal to the amount of impurity Y in the other and vice versa. This solution also shows that by taking no teaspoon (t=0) the results collapse to what we expect: X in one bucket with no Y and vice versa. It also shows that if we take t=1 (mixing the entire bucket into another and then splitting it back), we have a completely equal mixture in both buckets as expected; i.e., 0.5X + 0.5Y and vice versa.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-120215")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")])]

#text("A zero-algebra way of seeing this solution is to observe that each bucket has the same starting as ending volume. Therefore the amount of black sand in the white sand bucket must be the same as the amount of white sand in the black sand bucket.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42f61d57a590d82e6fb3b3438733ff6f92b48bfc0df753fa0649de3970661c01-5c591634cc0bfe2c7c43ae1464b7f675c67eaf6ee806e4dedba57777363af7ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tessa")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-122411")[#strong[#text("Tessa")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2012")])]

#text("Take in account that I am young; ")#linebreak()#text(" If the foreigner said his statement directly to an islander, the islander would think he had blue eyes and therefore kill himself. But, if no one knows what color eyes they have after the one dies, they can’t very well kill themselves. So, if one islander told another that they have blue eyes, each would kill himself for knowing and sharing that information. And it seems that in the end they either all would die, or they all would live. ")#linebreak()#text(" Now if the islander said his statement not directly towards one islander, no one would kill themselves unless another told them what color eyes the other had, resulting in more than one islanders dying. ")#linebreak()#text(" And then there’s the chance the islanders didn’t speak the foreigner’s language (whatever that might be, if not English), then the islanders would move on about their lives. But how would an islander know what color another’s eyes were if they didn’t understand the foreigner? ")#linebreak()#text(" Ultimately, there could be any number of outcomes to this puzzle, and I could carry with those but I’d probably end up confusing myself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb49a5a98c160369d5742e743e3cfe488519dea63103dfd32f8455c58a1c32ed-58f4fc188a96af351d5cf5dd4c1ec38fce9298c59abed1503d918c3fcc869328.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyrocomp")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-123393")[#strong[#text("Tyrocomp")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2012")])]

#text("OK, I’ve been racking my brain about this for a few days, and I actually think the first solution is correct. The inductive solution seems to assume that even if n>2 that the islanders will induct based on someone following the reasoning of n=1. I don’t think this happens except in the (rather obvious) cases of n=1 and n=2.")

#text("Take the case of 100 BEP, each of them numbered BEP1, BEP2 and so on.")

#text("BEP1 thinks there could be 99 BEP’s (because that is what he sees) and he assumes that he is not a BEP. He then thinks from the perspective of BEP2. BEP2 would then think that there are 98 BEP’s because BEP1 is not a BEP, and in BEP2’s thoughts neither is he.")

#text("Then we move onto BEP3. The problem is, from anybody’s perspective (and while we are in this little world BEP1 has created in his head) BEP3 sees 98 BEP’s. He doesn’t automatically assume that there are 97 BEP’s In BEP1’s world, It is a fact that there are 99 BEP’s visible, and any of those 99 are going to see 98 BEP’s.")

#text("The inductive solution seems to say")#linebreak()#text(" 1. BEP1 assumes he is not blue eyed, and sees 99 others")#linebreak()#text(" 2. Given the above BEP2 assumes he is not blue eyed, and sees 98 others")#linebreak()#text(" 3. Given the above BEP3 assumes he is not blue eyed and sees 97 others")

#text("This is not true. 3 contradicts what BEP1 will assume is a patently known fact by all BEP’s, and therefore you cannot continue the induction process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e67a2b3df965651da7c8840f8efe7bac5d74a2b5184a8ed900651ceaaf7c4e8f-9bf5ebcb90a9a5948d45c0158db01a12de4388f334928150ef18214e6b5d12a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aadil Aman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-123728")[#strong[#text("Aadil Aman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2012")])]

#text("In this post I saw that People are confused for the third color say “green”. Even if there exist a third color, Say the foreigner realizes later that he did a mistake.")

#text("But if he will say, “Ah! I am sorry. That was my mistake I wanted to say that Its good to see a green eyed person on this island!”")

#text("Saying this, he will be responsible for everyone’s death as Everyone will think that he/she is a green eyed person! So the the next day all the people will commit suicide and the story will end!")

#text("One more thing, this problem has a kind of “Circular” Logic, as the persons may think the same way or the persons may think in a different way, So their is an Ambiguity here!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cce80f7116988a1b42c91ea1f55239b6f0983496d4b06f7a3142d5fdc48c4c79-6f9026bc3f22e3e3ece7aaaef088185204ea200e74eb353b31041e3508b0f963.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of X. Ying")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-123941")[#strong[#text("X. Ying")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2012")])]

#text("The key point of this story is about Common Knowledge. The backward induction is based on Common Knowledge. The foreigner tells every body that these is at least one blue eye in this tribe. This becomes a Common Knowledge in this island. So backward induction works. Solution 2 is correct. Each person watching doesn’t get a Common Knowledge but a 99 level mutual knowledge in this case. This knowledge is not sufficient to support 100 level backward induction. So solution 1 is wrong.")

#text("The more details please see my blog. But you must know chinese.:-)")#linebreak()#text(" ")#link("http://blog.wenxuecity.com/myblog/49240/201201/19041.html")[#text("http://blog.wenxuecity.com/myblog/49240/201201/19041.html")]#linebreak()#text(" ")#link("http://blog.wenxuecity.com/myblog/49240/201201/19044.html")[#text("http://blog.wenxuecity.com/myblog/49240/201201/19044.html")]#linebreak()#text(" ")#link("http://blog.wenxuecity.com/myblog/49240/201201/19052.html")[#text("http://blog.wenxuecity.com/myblog/49240/201201/19052.html")]

#text("Otherewise you can read following article. But you must know mathematics.")#linebreak()#text(" ")#link("http://plato.stanford.edu/entries/common-knowledge/")[#text("http://plato.stanford.edu/entries/common-knowledge/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb49a5a98c160369d5742e743e3cfe488519dea63103dfd32f8455c58a1c32ed-58f4fc188a96af351d5cf5dd4c1ec38fce9298c59abed1503d918c3fcc869328.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyrocomp")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-124518")[#strong[#text("Tyrocomp")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2012")])]

#text("Well, then why wasn’t it common knowledge before? Whats the difference between the following scenarios?")

#text("1. I hear a foreigner say there is at least 1 blue eyed person. Everybody heard this. Therefore this is now common knowledge")#linebreak()#text(" 2. I see 99 blue eyed people. Each of them sees at least 98 blue eyed people, and I know that. Everybody knows that that N=98 or 99. Since 98 and 99 are greater than 1, it is now common knowledge tha there is at least 1 blue eyed person.")

#text("In both cases, I know that all other members of the island possess the same knowledge – that there is at least 1 blue eyed person (in the second place the common knowledge is actually a step further in that there are at least 98 blue eyed people).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee89f7be5db84c69427e542c843fce8ef950081c46c1d97f90c35d66fd32a12f-aebd9da958af9f6d8842f374a0daafcf96130da3c271896c6306f8689019624d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Cipra")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-124610")[#strong[#text("Barry Cipra")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2012")])]

#text("Tyrocomp, this difference is most easily explained by starting with 3 people, say Alice, Bob, and me. If I see that Alice and Bob both have blue eyes, then I know there’s at least one blue-eyed person, and, as you pointed out, I know that Alice and Bob also know that there’s at least one blue-eyed person (because they see each other’s blue eyes). I also know that Alice and Bob both know that I know there’s at least one blue-eyed person (because Alice knows I can see Bob’s blue eyes, and Bob knows I can see Alice’s). What I *don’t* know is that Alice knows that Bob knows there’s at least one blue-eyed person, and vice versa. That’s because for all I know my eyes are brown, in which case Alice, not knowing her own eye color, wouldn’t know whether Bob sees anyone with blue eyes (and likewise for Bob). But if an outsider makes a public announcement, then I *do* know that Alice and Bob both know that the other one knows there’s at least one pair of blue eyes, and the logical process can go from there.")

#text("In sum, for 3 people, the outsider’s announcement ensures that everyone knows that everyone knows that everyone knows there’s at least one blue-eyed person. For 4 people, the announcement adds one more level of the “everyone knows that” phrase. In general, if you have N blue-eyed people, then you need N levels of “everyone knows that” nesting in order for the logic to play out, but without the outsider’s announcement, you’ve only got N-1 levels.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian.Biermann@gmx.de")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-128132")[#strong[#text("Florian.Biermann@gmx.de")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("Was the argument expressed by Nicole Krieger above finally refuted? I agree with her that the inductive argument is problematic here. It assumes that IF there was just one blue-eyed person on the island (n = 1), the visitor’s statement would make that person commit suicide on day one. That is definitely true. However, with n = 100, everybody knows that n is at least 99 (because everybody can see 99 blue eyed people). As n >= 99 is mutual knowledge, from the fact that nobody committed suicide on day one no islander can deduce anything, because only under COUNTERFACTUAL circumstances, i.e. if n = 1, somebody would have committed suicide on day one. This means that with n >= 99 being mutual knowledge, under no possible state of the world somebody would have killed himself on day 1. Now we apply induction: Nobody will kill himself on day 1 under any possible state of the world, therefore the fact that day one passed without anyone committing suicide does not give any additional information to a villager who is unsure whether the state is n = 1 or n = 2, even if such a villager would exist. In particular, it does not tell him that n = 2 is the true state of the world. This goes on for 98 days. So with n >= 99 being mutual knowledge, it is impossible that under any possible state of the world somebody would have committed suicide until day 98. So the fact that indeed nobody has committed suicide until day 98 does not give any information to any villager about the true state of the world. Now day 99 begins. As a villager, I just know that the n = 99 or n = 100. The fact that 98 days have passed without anyone committing suicide does not add to my knowledge. Hence as a villager, I do not commit suicide at day 99, regardless what is the true state of the world. Now day 100 begins. Again, under no possible state of the world, somebody would have killed himself up to day 99. So again, I can deduce nothing from the fact that 99 days have passed without anyone committing suicide and I am again left with the two possible states of the world n = 99 and n = 100, prescribing me to stay alive.")#linebreak()#text(" One cannot start an inductive argument with a basis which is known to be NOT TRUE. “Assume n = 1…” WAIT! n CANNOT be 1 if we assume n >= 99 to be mutual knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6a83605942f82fb4b464e6af6cef525006f87ce5a898310008efedae6987613-58d42e666122a4d6e6229e14c5feb5d249a7abfae6590940fed1ae9a5baf13c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bert")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-128224")[#strong[#text("bert")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("There’s one thing that bugs me here, and any help understanding this is appreciated.")

#text("When thinking of this as a kind of game, the strategy of committing suicide on the n-th day if you see n-1 people with blue eyes, that is clearly a correct and working strategy for the players to collectively solve the question of who has blue eyes. It’s also the fastest and simplest stratey.")

#text("What the foreigner brings to the table is that he gets all the players to agree on two things: when to start counting days, and the eye color they will try to figure out. He’s not so much giving any information about who has which eye color, he’s just starting the game.")

#text("If there are 1 or 2 islanders with blue eyes, it’s clear to me that the conclusion is inevitable and that they will know for sure. But for 3 or more players, it gets fuzzy for me. I can see how they can solve the puzzle if they all use this strategy, but I don’t see how they know that this is the strategy that everyone must be using, or that everyone agrees to even play the game at all?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6a83605942f82fb4b464e6af6cef525006f87ce5a898310008efedae6987613-58d42e666122a4d6e6229e14c5feb5d249a7abfae6590940fed1ae9a5baf13c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bert")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-128225")[#strong[#text("bert")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("Something feels wrong to me about the proof by induction, but I can’t quite put my finger on it (probably because there is nothing wrong with it). It seems like it’s inducing over two things simultaneously, the number of blue eyed islanders, and the number of days. It’s as if we skip from day n-1 with n-1 blue eyed islanders, to day n with n blue eyed islanders, without considering day n-1,n-2,.. with n blue eyed islanders?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/872158bbbfb5598bbe31d642ba056143c36da2fb85fdb9198ac0195e2dc0f91a-dbc5eb709c3446bb1092b5fe9b9aaaae7914f0fb112f7e444e2cddce3bcbb2a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahno")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-133549")[#strong[#text("Ahno")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2012")])]

#text("Wow, a way to kill all logical bastards on the island indifferently to their eye color. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/872158bbbfb5598bbe31d642ba056143c36da2fb85fdb9198ac0195e2dc0f91a-dbc5eb709c3446bb1092b5fe9b9aaaae7914f0fb112f7e444e2cddce3bcbb2a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahno")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-133800")[#strong[#text("Ahno")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2012")])]

#text("Also actually I only see one mess in this solution and that is adding days as variable. Because someone thinking of something is not time related thing. That is why there probably be an avalanche effect at some random point of time.")

#text("By the way if try to resolve this “information poisoning” case when there are up to 4 blue-eyed (B) and up to 3 brown-eyed (R) islanders it’s funny and shows how the logic works in intuitive way:")

#text("1x B: I see no one else B but me -> suicide;")

#text("2x B: If he didn’t kill himself then I am B too -> double suicide;")

#text("3x B: If there were only 2 of them they should kill themselves from previous logic but they are not then it’s 3 of us -> mass suicide;")

#text("4x B:")#linebreak()#text(" 1 step:")#linebreak()#text(" 1,2,3,4 B: oh there are 3 or 4 blue eyed, wait and see;")#linebreak()#text(" 2 step:")#linebreak()#text(" Random B: no one takes action then there are not 3 but 4 blue eyed because it’s evident for those 3 if its actually 3 B from previous logic -> own suicide -> those 3 see evident thing -> mass suicide")

#text("etc >_<")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eeb97fd5e2310367f6c5c8cbe908b60e03ac564cf030a153955aa76fa931bc74-5ae3428390e9375d09a3e4d9fec20918e03971a4adce544e11c2c46d185de359.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JO")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-137708")[#strong[#text("JO")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2012")])]

#text("Ok, I just came upon this puzzle yesterday and read most of the comments above.")

#text("From what I can see there is a problem with the puzzle to begin with.")

#text("First of all If there are 4 or more people with blue eyes to begin with they won’t need some one to tell them that at least one person has blue eyes. they will have figured it out on their own and commited suicide long before someone told them. This puzzle only seems to work with 3 or less blue eyed people.")

#text("Br = Brown eyes. His point of view doesn’t matter.")

#text("(Bl) = Blue eyer point of veiw. He/she doesn’t know if he is blue or brown.")

#text("‘Bl’ = (Bl) know that at least one other person’s point of view is what matters, because all the others you know have blue eyes and each of them are thinking of the other blue eyers assuming the (Bl) thinks that he/she has brown eyes.")

#text("Bl = all the other blue eyers.")

#text("Beyond this it doesn’t matter, because you know for a fact that all the other blue eyers are thinking only one of two things 1. (Bl) has blue eyes or 2. (Bl) has brown eyes.")

#text("1 blue eyer needs some one to tell them that their is one to figure it out. System is stable before the statement is made.")

#text("Br / (Bl)")

#text("2 blue eyers need some one to tell them that their is at least one of them to figure it out, because they can only see one of them and figure that he/she doesn’t know it.")#linebreak()#text(" System is stable before the statement is made.")

#text("Br / (Bl) / ‘Bl’")

#text("3 blue eyers need some one to tell them that their is at least one of them because even seeing two other can figure on each one not knowing about themselves and knowing one other doesn’t know, but can at least see one. Which each may think that the others think their is only one, assuming that him/herself is not blue eyed.")#linebreak()#text(" System is stable before the statement is made.")

#text("Br / (Bl) / ‘Bl’ / Bl")

#text("4 Blue eyers don’t need anybody to tell them. they already know. Each one sees that their are 3 others and know that at each one of them doesn’t know his/her own, but can see at least 2 others. It is known by all that all the others know that their are blue eyed people.")#linebreak()#text(" System is unstable before statement is made. they all commit suicide from the get go.")

#text("Br / (Bl) / ‘Bl’ / Bl / Bl")

#text("5 on up is all the same. Just more blue eyers that can see each other.")

#text("I tried to explain this best I could. Let me know what you think.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-145061")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2012")])]

#text("Obviously, prior to the visitor’s statement, the deduction process won’t work with just 1 blue-eyed person and 199 browns. That one blue will never know if her eyes are brown, blue, green, or other.")

#text("Because of this, it doesn’t work with 2 blues and 198 browns, either. This is because ")#emph[#text("from the perspective of each of those 2 blues, it is exactly the same as if the other blue was the only blue")]#text(". This is the key thing to grok.")

#text("Now, if it doesn’t work with 2, then it won’t work with 3 — because ")#emph[#text("from the perspective of each of those 3, it is exactly the same as if the other 2 blues were the only blues")]#text(". Those 3 have no way of knowing themselves to be blue and not brown. From their point of view, it’s the same as in the previous paragraph.")

#text("If it doesn’t work with 3, then it won’t work with 4 — because ")#emph[#text("from the perspective of each of those 4, it is exactly the same as if the other 3 blues were the only 3 blues")]#text(". How would the 4 blues know that they were 4 in total? Why wouldn’t they each think “I might be one of 197 browns”?")

#text("If it doesn’t work with 4, it won’t work with 5 — for the same reasons as above.")

#text("At no point can anyone deduce their own eye color, because ")#emph[#text("they have no reason to expect anyone else to deduce their own color based on people not leaving")]#text(", which is what the whole puzzle is all about.")

#text("Once we add the visitor’s statement, however, it all works.")

#text("A lone blue would have to leave on Day 1. (She knows that there are either zero or one blues, but the visitor’s statement excluded the zero, so therefore there is 1 blue — himself.)")

#text("Because a lone blue would have left on Day 1, then 2 blues (if there are exactly 2) would deduce that there ")#emph[#text("must")]#text(" be 2 blues, and leave on Day 2.")

#text("If there are 3 blues, then they, each knowing that the other 2 “ought to” have left on Day 2, will leave on Day 3.")

#text("If there are 4 blues, then they will each see the situation the same as if there were only 3, and will thus “expect” those 3 to leave on Day 3. When that doesn’t happen, they conclude the only other possibility — that there are 4 blues and not 3 — and leave on Day 4.")

#text("Etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-200664")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2012")])]

#text("Looking over this again I feel like adding a simpler rebuttal. Let’s say you and 3 other people pop into existence on this island, none of you knowing your eye color. You see that the 3 others are all blue-eyed. What color are your eyes? Obviously you don’t know.")

#text("Day 1 goes by with no one dying. Day 2 is likewise uneventful. Nothing happens on Day 3. So it will soon be Day 4. Now what color are your eyes?")

#text("Did you say “blue”? Because you’re wrong. Your eyes were in fact brown. And surely you can see that this revelation doesn’t lead to a contradiction. If your eyes were brown, then those 3 ")#emph[#text("would")]#text(" remain alive, because the situation with just 3 blues is stable.")

#text("But that means that you ")#emph[#text("shouldn’t")]#text(" have concluded your eye color from no one dying on Day 3. Which in turn means that if your eyes had actually been blue, you shouldn’t have concluded it either. (Otherwise you would be psycic!) This means none of the other 3 would decide to leave (all of the islanders have to think symmetircally.)")

#text("This proves that the situation is stable with 4 blues; they each have no way of knowing if there are just 3 or not.")

#text("Well, by the same method, we prove that any number (before a visitor speaks) is stable. 5 is stable because 4 is stable: the 5 don’t somehow draw a conclusion from 4 people not killing themselves. Because 5 is stable, 6 is stable. And so forth.")

#text("This may seem counter-intuititve. When you think about it, it’s not: ")#strong[#text("it makes complete sense")]#strong[#text(". Asking “How many blue-eyed people does it take for blue eyes to become common knowledge?” is the same thing as asking “How many people have to stare at my eyes before I can see what color my eyes are?” Adding more people doesn’t somehow overcome the fact that each person is still blind to his own eye color.")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-144870")[#strong[#text("Does P contain languages decided solely by incomprehensible TMs? | MoVn - Linux Ubuntu Center")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")]

#text("[…] obstructs my own understanding of a broad class of problems that includes Terry Tao’s Blue-Eyed Islanders Puzzle, Dick Lipton and Ken Regan’s Urn-Choice Game, and their hybridization in the context of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af4a559c8416f056ffeccc2d02ee6278d287ecb4636412b9381c8d18dbee25c5-a94a5ae7c3faedeeaee5ea855b9184655087dc29c46c0c984146b80b56851a2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zarko")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-146197")[#strong[#text("Zarko")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2012")])]

#text("I m sorry for my english but I feel like I should say something here. I am not sure if anyone realized that in this sequence of hypothesis in hypothesis we eventually must come to the problem of just two blue eyed people which can not be solved if there is no information about at least one blue person.")#linebreak()#text(" You see, p1 sees p2 and thinks: if I am non-blue then p2 can not conclude anything because he does not know that there is at least one blue person. But if guru says something then it is made possible for him to conclude if I am non-blue that he IS blue! But even now, he concludes nothing. So this must be because I am blue. Oh my god, but still, this puzzle puzzles me. Is it really possible to do all this? You can now think of possibility of 3, p1, p2 and p3 and still see that it is possible to come to conclusion of own blueness because you can speculate that if you are non-blue than they can solve the two-blue problem. It is obviously solvable. When everyone sees that no one has resolved 2 blue problem, they now know that they are dealing with, in fact, 3 blue problem, but it all rests on guru because he puts")#linebreak()#text(" blue person in a position to speculate about the knowledge of his friend.")#linebreak()#text(" But what makes me so frustrated is that for large number such as 100 I can not see through this line of reasoning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cba82ec92e2d0747dff85d399399c661d9b80015efd4073244017aefc543f67-5549f146834e799a9102e89df490cdffb4b2c1997d8412553a9a6b1fa338f355.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kamal")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-157287")[#strong[#text("Kamal")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2012")])]

#text("Also see at:")

#link("http://www.ritambhara.in/blue-eyed-islanders-puzzle/")[#text("http://www.ritambhara.in/blue-eyed-islanders-puzzle/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-161458")[#strong[#text("dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2012")])]

#text("In order to relieve the gloomy spirit of this problem as heretofore posed, I would like to suggest that these unfortunate people, living on their peculiar island, are all members of an obscure tribal group known as “mathematicians.” Each inhabitant must always wears a shirt bearing, on its front, a large, ornate red letter M, while on the back of each shirt is printed a positive integer. (Details of exactly how this is all to be managed are left an an exercise for the reader).")

#text("Since a serious earthquake struck their nation some years ago, all N tribespeople have worn medically necessary neck braces, and so can look at all the others’ numbers but not at their own.")

#text("If any islander can prove that his or her integer is prime, that person will be given a unique and much coveted trophy, and will march in a grand torchlight procession that evening, to be seen by all.")

#text("Prizes may be claimed any day at noon. In case of ties, the winners are to have their likenesses carved onto the island’s central feature, Volcan Gushmore, in lieu of holding the trophy.")

#text("It goes without saying that each islander is highly and equally competent, and will never miss a proof if one can be obtained.")

#text("Naturally no one will ever talk about anyone else’s number for fear that the information will somehow get back to that person. And of course no one will reveal the existence of his or her proof until the designated hour, for fear of somehow losing priority.")

#text("As everyone on the island already knows, several shirts (0 < n < N) bear prime numbers, though n is not yet known with certainty by anyone.")

#text("Months and years go by, but no one produces a proof. One day a famous member of the tribe, who hails from a different part of the archipelago, arrives for a visit to the island and lets slip that at least one person's integer is a prime.")

#text("After the Great One's embarrassing gaffe (\"I misspoke\"), when, if ever, will anyone step forward with a valid proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-173120")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2012")]

#strong[#text("What are the best puzzles you have ever seen?…")]

#text("As far as sources of puzzles go, I second Project Euler (although “puzzles” may not be the best word.) As far as individual puzzles go, my favourite, is the infamous blue-eyed people problem, which I dedicated about an hour one afternoon to wrapping …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97513d8b8425e0330dc195bfb6fc841727696ec12a8e24f61e025eeadc53f545-84fa8cc80609d489c3b98baf81048e1cca0a9d99af3b0c30e182a5f89a1fc7f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack Snoeyink")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-189025")[#strong[#text("Jack Snoeyink")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2012")])]

#text("Ok, I thought I believed the induction proof until I tried to write the proof myself and realized that n is being used for both the number of islanders and the number of days. You don’t actually change the number of islanders, so it seems to me that induction can be properly done only on what is common knowledge on day d, where day 1 is the day of the announcement.")

#text("Proposition: given an island with n>1 blue-eyed islanders,on day d>=1, if no-one has committed suicide, then everyone knows that everyone knows there are at least d blue-eyed islanders.")

#text("Let’s prove this by induction on d.")#linebreak()#text(" Base: d=1. The announcement says so.")#linebreak()#text(" Ind step: for day d>1,")#linebreak()#text(" Ind hyp: we may assume that if no-one suicided before day d-1, then on day d-1 everyone knows that everyone knows there are at least d-1 blue-eyed islanders.")#linebreak()#text(" Now consider day d, and assume that no-one has committed suicide.")#linebreak()#text(" By the IH, on the previous day everyone knew there were at least d-1 blues.")#linebreak()#text(" Anyone who saw only d-2 would therefore deduce their eye color; since there were no suicides, everyone concludes that everyone sees at least d-1 blues. And since d>1, everyone sees some blue-eyed islander that they know sees at least d-1 blues, so now everyone now knows that there are at least d blues. (Note that here is where we use the observer information. This would not work if we did d=0 as a base case and d=1 in the IH.)")#linebreak()#text(" This completes the proof by induction on the day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-189563")[#strong[#text("Ralph Dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2012")])]

#text("The problem with this puzzle is that, although every islander knows all the facts (except his/her own eye color), no islander knows the beliefs of other islanders. When n>1, any prediction by an islander about future actions of other islanders must take into account what each other islander believes, including what each believes about the beliefs of the others. But there is no way to know which basic theory other islanders might believe: the “nothing has changed” interpretation or the “clock is now ticking” interpretation.")

#text("Each islander must act independently, based on his/her belief about the beliefs of others. Since there is no way to determine the beliefs of others, there is no deterministic solution to the puzzle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-194578")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("That’s an odd, and broad, assertion. Consider a simple case. A, B, and C all have brown eyes. Does A think that B thinks that C has brown eyes, or does say think “I cannot possibly infer someone else’s beliefs”? If the latter, then yes, the puzzle is unsolvable, but that A would think this is an assertion requiring justification.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-195312")[#strong[#text("Ralph Dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2012")])]

#text("Lenoxus, you are right. I overstated my point about not being able to know the beliefs of others. In your example, I think we can safely assume that A knows that B knows that C has brown eyes.")

#text("But In the puzzle as stated, it seems to me that each islander would be free to hold one of two different theories after the visitor’s speech.")

#text("One valid theory is that as a result of the visitor’s revelation, nothing has changed, and therefore no new action can possibly be required.")

#text("The other valid theory is that the visitor’s words have started a new clock ticking at t = 0, as though from the beginning of the world.")

#text("I see no logical or mathematical way for any islander to figure out which theory any other islander will adopt. But without such knowledge, it is not possible to solve the puzzle.")

#text("With respect to the induction proposed below the problem, starting from n=1 is not valid. Why not? Because prior knowledge in the n=1 case does not match prior knowledge in the originally posed (n=100) situation: a single blue-eyed islander does NOT already know (before the visitor speaks) that there is at least one blue-eyed person on the island.")

#text("But n=2 is not a valid case, either. For if islander A (with blue eyes) is looking at one other islander named B (also with blue eyes), A cannot be certain that that B sees any blue-eyed person.")

#text("Surprisingly, in order for everyone to be certain (prior to the visitor) that everyone else already knows (prior to the visitor) that there is at least one blue-eyed islander, the situation must include at least three blue-eyed islanders.")

#text("—- ADDITIONAL THOUGHTS —-")#linebreak()#text(" At least one reason this puzzle is so confusing is that the stated initial situation is a “garden-of-eden” configuration. That is, there is no way to arrive at the given situation (n=100, with full knowledge of all others’ state of mind) from any other preceding situation, because all the blue-eyed islanders would already have committed suicide. The given initial state can be posited, but it cannot be reached.")

#text("This is similar to a chess position that cannot occur after the first move of any valid game. It is possible to begin playing in such a situation, but it is not possible to play into one. In fact, the standard “move 0” setup for chess is just such a position.")

#text("Fortunately, in playing chess, we do not have to reason about what each piece knows about what all the other pieces know!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-195529")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2012")])]

#text("It’s important to understand that there’s nothing inherently special about “Everyone knows that everyone knows X”, or tertiary reasoning. That’s merely where the human brain starts to have trouble. Again, I repeat: There is NOTHING SPECIAL ABOUT THREE ISLANDERS. Let’s start from simple cases.")

#text("You agree that if there is only one blue-eyed islander, than one day after hearing the statement “At least one of you has blue eyes,” he would leave the island (I prefer this as a less violent alternative to suicide). Furthermore, at no point would he leave before this. If no one says anything, then from his perspective, it is just as possible that there are zero blue-eyed people.")

#text("Now suppose that instead of one, there are two “blues”. Prior to an outsider’s statement, will either of them have any reason to leave? No. And here’s an easy way to think of it: The situation with two blues is exactly like one blue, if we take the perspective of one of those blues. Neither of them can think something like “If I were that guy, I would see that my eyes are blue, therefore my eyes are blue.” That would be nonsense. In general, there is no basis on which either blue can deduce his eye color.")

#text("Now, let’s take the perspective of one of the browns on the island with two blues. How many blues does this brown think might exist? Well, either two (not including himself) or three (including himself). Will he ever leave (assuming no new outside information)? No. He has no idea if his eyes are blue, brown, green or purple.")

#text("I’ve just shown that on an island with three blues, no one will leave. Why not? Because each of those blues can figure that his eyes might be brown (or green, etc). Furthermore, they each know that if only two blues exist, no one will leave, so they ")#emph[#text("can’t deduce anything from no one leaving")]#text(".")

#text("We can extend this process indefinitely. First take the perspective of a brown-eyed person seeing X blues. Then change his eye color to blue. Then shift perspective to another brown-eyed person seeing X + 1 blues. Repeat. At no point can anyone here deduce his own eye color. When you think about it, that makes complete sense — such a deduction would be made out of thin air.")

#text("So how does a visitor’s statement change anything? Well, let’s go back to the base case. Our lone blue-eyed person realizes that the visitor can only be talking about him, so he leaves the next day. What if there were two? Well, each of those two blues considers two possibilities:")

#text("A. My eyes are not blue. If so, then there is only one blue-eyed person on this island. If there is only one blue, then he will leave on Day 1.")

#text("B. My eyes are blue. In that case, statement A is false, which means that no one will leave on Day 1.")

#text("Each blue now has a logical method to determine whether or not his eyes are blue: Wait to see if the other blue leaves on Day 1. “If that doesn’t happen,” each blue thinks, “it means my eyes are blue, so I will leave on Day 2.” It has now been demonstrated that if there are exactly two blues, then they will both leave on day two.")

#text("Ah, but we can extend this, easily. Suppose there are exactly three blues. From each of their perspectives, they have no way of knowing whether the number of blues is two or three. But they know that if the number is two, then a specific event must occur: those two blues will leave on Day 2. That’s an event that either will or won’t happen. If there are only two blues, then it will happen. If there aren’t, then it won’t. “But if there aren’t exactly two blues,” each of the three thinks to himself, “then there must be three, and that means I am another blue.” So after Day 2 goes by with no one leaving, all three blues deduce their color and leave on Day 3. Therefore, no matter what, if there are exactly 3 blues, then they will all leave on Day 3.")

#text("I hope it’s now clear how to generalize this. Once you have a rule that K blues leave on Day K, then it logically follows that K+1 blues (each seeing that the K blues he observes have ")#emph[#text("not")]#text(" left on Day K) leave on Day K+1. Thus, because 1 blue would leave on Day 1, 100 blues would leave on Day 100.")

#text("Thoughts?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-196178")[#strong[#text("Ralph Dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2012")])]

#text("I am thinking about this a lot. No clarity yet. Sometimes these things take me a long time. Thank you for your dialog to date. I will reply substantively as soon as I am able.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom_glabst")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-196473")[#strong[#text("tom_glabst")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2012")])]

#text("That’s exactly the way I finally managed to understand the puzzle. The induction basis simply changes from “N=1: Nothing happens” to “N=1: The blue-eyed is gone the next day”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197381")[#strong[#text("Ralph Dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("Lenoxus, your exposition is clear and convincing and clear. I am persuaded that you are correct. My difficulty is with the statement of the problem. What is the real message conveyed by the revelation that “there is at least one blue” in a situation where, assuming n>>1, each islander has already seen more than one blue with his own (whatever-colored) eyes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197452")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("Ralph asks “What is the real message conveyed by the revelation that ‘there is at least one blue’…?”")

#text("It’s important to realize that if there were no rule that the islanders had to leave the day they found out their eye color then the message would not change anything. It is the combination of this rule and the foreigner’s statement that makes the problem interesting. Essentially the “leave that day” rule makes the islanders an induction proving machine where each day they prove that there is at least one more blue eyed islander than what they proved the day before. However, until the foreigner speaks, no one had proven any starting point to the satisfaction of every islander (do we start at n=0 or n=1?) and it is the *synchronization* of the revelation that starts the *time-dependent* induction machine.")

#text("People leave when they have proof that the number of blue-eyed people is greater than the number that they observe. If the foreigner had said “I’m surprised to find 100 blue-eyed people here” then all the blue-eyed islanders would leave the next day (day 1), since they only see 99. If the foreigner had said “I’m surprised to find 80 blue-eyed people here” then all the blue-eyed people would leave on day 21 because it takes 20 days for the induction proving machine to go from 80 to 100 and then they leave the next day.")

#text("Of course, it doesn’t take a foreigner. If one of the islanders has said to the whole island “I’m sick of looking at these blue-eyed people” that would trigger the induction machine, too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197537")[#strong[#text("Ralph Dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("I think I am finally getting this.")

#text("1) One lone blue thinks there are (maybe) no blues, until he learns there is one, and so leaves.")

#text("2) In a group of two, each one thinks there is (maybe) only 1 blue, and also thinks “the 1 blue thinks there are maybe 0 blues, and now he has learned there is one, and so will leave tomorrow”")

#text("3) In a group of three, each thinks maybe there are only 2, and thinks that in that group of 2 each one thinks there is maybe only one blue and that that one blue thinks there are maybe none, until …")

#text("4) In a group of 4, each one thinks there might be only 3, and also thinks that in the group of 3 each thinks there might be only 2, who think that there might only be one, until…")

#text("Is that the basic picture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197573")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Yes, Ralph, I think you’ve got it. Another way to answer the question is this: It’s not the ")#emph[#text("content")]#text(" of the visitor’s statement which provides information – it’s simply the ")#emph[#text("fact")]#text(" that he said it publicly. If he had told each islander in private that he can see at least one blue-eyed person on the island, then no suicides would occur.")

#text("Imagine I’m in a room with three people. Alice has a laptop, Bob has a newspaper, and I’m browsing the Web on my cell phone. I’m looking at the weather reports, and I can see Alice and Bob in front of me also looking at the weather — but they can’t see each other’s reading matter, or mine.")

#text("Alice announces, “Seems like it’s going to snow tomorrow.” Did I learn anything? Yes — I learned that ")#emph[#text("now")]#text(", Bob knows that Alice knows it will snow. I also learned that Alice knows that I know it will know, and that Bob knows I know Alice knows I know it will snow, for any number of such combinations. (Well, not quite — most people, including me, stop bothering thinking about this after three layers or so. But these logical islanders are different from normal humans in that key respect.)")

#text("I would like to add something to Jeremy’s point about one of the blues himself mentioning that he sees blue-eyed people. In that case, what would happen is that the other 99 blues would leave/die on Day 99, and the blue who made the statement would never leave/die. This is because that blue could not possibly have been talking about himself, and all the other blues would know this.")

#text("If it’s still not clear, simplify it to just two blues and consider what would happen. (If there were only one blue and he said it, then he would be lying. Everyone else would think he was talking about them, and they would all leave the next day!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197672")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("OK, Lenoxus, I agree with you about what happens if a blue-eyed islander says there are blue-eyed islanders, but if a brown-eyed islander said it then it would be the same result as when the foreigner said it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-500575")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("I think I finally got to the gist of it, that someone can believe that one of the 99 they see believes another sees 98 that could believe another sees 97 that could believe another sees 96 etc. …")#linebreak()#text(" And thus knowing that others people will think about this possibility, EVEN THOUGH yoiu know each of them sees at least 98 other blue eyed people, they could counterintuitively reach the conclusion there must be someone who can believe, who can believe, who can believe… that in theory there is none. And thus in a sense the foreigner does introduce “new information” by the public statement, that the “virtual person” is gone for everyone and everyone else knows this, so the minimum estimate for even virtual conjectural people is one.")

#text("This all in theory, of course.")

#text("It’s absolutely baffling. I guess logic does generate aberrations.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20ce898167fc228e023f16238a1d81db07428a15c22ffa205757f794984cca6f-aac98d9d5e914f63405241ed28979c16c3b424c1af87968a08b3ee93f226a074.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Dratman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197628")[#strong[#text("Ralph Dratman")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Lenoxus, thank you for your very helpful messages. Does this problem fall within a particular range of your interests?")

#text("Another thought: It occurs to me that if “blue eyes” were replaced by, let us say, “poor ethics,” or “lax conscience,” the puzzle might actually mirror some real-world situations in which people have difficulty with self-evaluation. For example…")

#text("Mr. Alf: “Someone here has been using extremely bad judgement.”")#linebreak()#text(" —")#linebreak()#text(" Bet: “Whew, I’m sure glad Alf isn’t talking about me! Unless… ”")#linebreak()#text(" Gam: “Those stupid guys are messing up again.”")#linebreak()#text(" Del: “I was on vacation when that happened!”")#linebreak()#text(" Eps: “Good thing I play golf with Alf’s boss.”")#linebreak()#text(" —")#linebreak()#text(" Corporate policy: If you realize you have violated our rules , causing significant harm to the company, you must resign within 24 hours.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197717")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("If enough similarities to the islander puzzle are established, then yes, all four “bad workers” would leave four days later. However, the honor system might not be followed by them all, especially since bad judgment is itself a reason someone might not bother to resign. Furthermore, the logic of the original puzzle itself rests on each participant being a perfect logician who knows that the others know that the others are perfect logicians, ad infinitum. Most real humans have trouble thinking more than three layers deep on this (and really intelligent animals ")#link("http://en.wikipedia.org/wiki/Theory_of_mind#Non-human_theory_of_mind")[#text("tend not to get past one")]#text(", maybe two).")

#text("It only takes a bit of uncertainty for the puzzle to fall apart. For example, suppose Bet, Gam, Del, and Eps ")#emph[#text("are")]#text(" all perfect logicians, but the last three don’t know that Bet is — they think she’s only able to consider these problems at two levels deep, “I know that she knows” but no further. In that situation, none of them would ever resign, because they wouldn’t infer anything from Bet not resigning on Day 3.")

#text("Anyway, I do have an interest in puzzles like these. There are two others that come to mind which I particularly like. One is the ")#link("http://en.wikipedia.org/wiki/Prisoners_and_hats_puzzle")[#text("prisoners and hats puzzle")]#text(" and the other is called the ")#link("http://en.wikipedia.org/wiki/Pirate_game")[#text("pirate game")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-194040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("One difficulty with understanding the proof of this problem is that the induction step works upwards from 1 to 2 to 3… It may (or may not!) be clearer if the induction is explained the other way round.")

#text("Assume that there are exactly 3 blue-eyed people: B1, B2, and B3, part of a larger tribe including brown-eyed people.")

#text("B1 sees 2 blue-eyed people (B3 and B4) and as far as he knows there are only two blue-eyed people.")

#text("So B1 is certain that either B1 has blue eyes or B2 will see only one blue-eyed person: B4")

#text("So B1 is certain that either B1 has blue eyes, or (B2 is certain that either B2 has blue eyes or that there is only one blue eyed person, B3). Of course B1 knows that B2 will be wrong to think there is only one blue-eyed person, nevertheless he sees no logical reason why B2 might not think this.")

#text("So B1 is certain that either B1 has blue eyes or (B2 is certain that either B2 has blue eyes or (B3 is certain that either B3 has blue eyes or there are no blue-eyed people)).")

#text("This is where the foreigner comes in and changes things. We then know that one possibility is removed. We are then left with:")

#text("B1 is certain that either B1 has blue eyes or (B2 is certain that either B2 has blue eyes or (B3 is certain that B3 has blue eyes, and so will suicide the next day)).")

#text("When B3 does not suicide the next day, then after one day we are left with:")

#text("B1 is certain that either B1 has blue eyes or (B2 is certain that B2 has blue eyes and will suicide the next day)).")

#text("When B2 does not suicide the next day, then we are left with:")

#text("B1 is certain that B1 has blue eyes and will suicide the next day.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-194266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Arrgh. Edits to Paragraphs 3 & 4")

#text("Paragraph 3: B1 sees 2 blue-eyed people (B2 and B3) and as far as he knows there are only two blue-eyed people.")

#text("Paragraph 4: So B1 is certain that either B1 has blue eyes or B2 will see only one blue-eyed person: B3")

#text("The trick with all of this is that, if 1, 2 and 3 are each logical with imperfect information, then the statement “1 thinks (2 thinks (3 thinks X))” does not imply “1 thinks (3 thinks X)”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom_glabst")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-195252")[#strong[#text("tom_glabst")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2012")])]

#text("That is the best logic puzzle I’ve ever heard of, and it just gave me some restless hours. I’ve finally understood the solution, and the way I managed to understand, after reading all this posts about common knowledge, was to think about the common knowledge of the induction proof.")

#text("Before the visitor held his address, the induction start was obviously different: With number of blue-eyed persons N=1, the blue-eyed can’t know that there are any blue-eyeds, and everybody knows that. So N=1 is stable.")

#text("Since people came up with the N=3 case, I will do the induction step as well:")#linebreak()#text(" Suppose the case N=k is stable, and the k+1^th blue-eyed enters the island or whatever (of course, every constuction of this universe is very artificial). Now we are in case N=k+1. It is common knowledge that N<=k is stable, and all the blue eyed people think it is at least possible they are in case N=k. So they won't kill themselves and the case N=k+1 is stable as well.")

#text("Once the islander made his statement, the other chain of induction (the one mentioned in the question) becomes true. And so, after N days, everybody with blue eyes has to commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean G")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-196318")[#strong[#text("Sean G")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2012")])]

#text("After telling many people this puzzle, I find one of the clearest ways to explain why “Solution 1” is fallacious is as follows:")

#text("Let S_1 be the assertion that there is at least one blue eyed islander.")

#text("For every positive integer n, let S_{n+1} be the assertion that every islander knows S_n. This is well defined as the islanders are perfect logicians.")

#text("Now whilst every islander certainly already knows the truth of S_1 simply by observation, they do NOT know every S_k. In fact, the largest k for which every islander knows S_k is one less than the number of blue eyed islanders.")

#text("However, the public nature of the foreigners address instantly makes every monk aware of every S_k. Hence we have new information and no contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197446")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("No, Sean, every islander already knows every S_k before the foreigner speaks because, as I said above:")

#text("It has to be known to these logical people that whatever the real number of blue-eyed people is (let’s call it N), blue-eyed people see N-1 blue-eyed people and the rest see N blue-eyed people. So it is Common Knowledge that everyone has first-hand evidence of at least N-1 blue-eyed people.")

#text("Read my post above for details, but since these people are perfect logicians, they can thus be assured not only of every S_k but of of every Si_k for 0 < i < N-1 where Si_1 is the assertion that there are at least i blue eyed islanders.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197566")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("I think this is all correct, except that that’s not “common knowledge”, merely nth-order mutual knowledge. For it to be common knowledge, it has to be assured for every Si_k for any i. Once the visitor speaks, the information becomes common knowledge.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197687")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Lenoxus, you seem to have misunderstood my use of “i”. In my formulation, “i” is the minimum number of blue-eyed islanders asserted. Where your S_1 was the assertion that there is at least one blue eyed islander, that would be my Si_1 where i=1. So it is not true and will never be true that everyone is assured of every Si_k for any i because there are only 100 blue-eyed islanders and no one will ever be assured of Si_1 for i > 100.")

#text("Using the logic of my post from 5 May, 2012 at 3:40 pm you can see how every islander can conclude that no islander can conclude there are fewer than 98 blue-eyed islanders. Si_k is known for all k where i <= 98. That includes your S_k being known for all k. There is no possible world where an islander can conclude another islander thinks there are fewer than 98 blue-eyed islanders because every islander is assured from first-hand knowledge that every other islander sees at least 98 blue-eyed islanders. No islander can imagine a world where an islander sees only 97 blue-eyed islanders thus every islander can reason about every other islander that they know there are at least 98 islanders. Si_k, i=98 is known for all k.")

#text("The thing is, no islanders will take action until Si_k is true for all k when i=100. Even when Si_k is true for all k with i=99, blue-eyed islanders can assume that every blue-eyed islander sees 98 blue-eyed islanders and every non-blue-eyed islander sees 99 and thus everyone can conclude that they might have not have blue eyes.")

#text("What is not common knowledge is the precise number of blue-eyed islanders. Everyone is uncertain about the precise number until the combination of the foreigner's statement and the islanders' behavior establishes that it must be at least 100 and then those 100 leave. It is the combination of Si_k, i=99 being established for all k plus the lack of action on the day that that is established (day 98) that establishes Si_k, i=100 for all k on day 99 which leads to all of the blue-eyed islanders leaving on day 100 (which finally makes the precise number of blue-eyed islanders common knowledge).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197702")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Ah, I see my error; I hadn’t realized you were discussing alternative situations with different numbers of blues; oops. You’re correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197972")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2012")])]

#text("Wait. Looking at this again I don’t think you’re using “common knowledge” correctly. Until the visitor speaks, there is no number of blue-eyed people whose existence is common knowledge, not even 1. For example, consider the actual number of blues to be 3. Then the following statement is false: “Everyone knows that everyone knows that everyone knows that at least one blue-eyed person exists.” And because that’s false, it’s not common knowledge. (For 100 blues, the number of “everyone knows” can be truthfully extended to 99, but not 100.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-199646")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("Wow, is this tricky. OK, Lenoxus, Terry, you are right and I was wrong. I had reasoned that shortly along the chain of reasoning there could be an end to the descent of the agreed upon minimum number of blue-eyed people, but now I see there is not. I had to completely work through an example to see it, but I did and I did. Here it is:")

#text("Imagine the case where there are 4 blue-eyed islanders: X, Y, Z, and A. X sees 3 blue-eyed islanders and considers the possibility that there really are only 3 blue-eyed islanders. X considers what Y thinks in this case. Here, X thinks Y sees 2 blue-eyed people and considers Y reasons as X does. Well, Y would have to consider that he does not have blue eyes so Z and A only see 1 blue-eyed person.")

#text("Now Y wonders what Z, who in X’s imagination of Y’s imagination maybe only sees 1 blue-eyed person, thinks about the other blue-eyed person A. Well of course Z has to conclude that A may not see any other blue-eyed people.")

#text("I had thought that since X knows that Y and Z and A all see the same number of blue-eyed people that was good enough and somehow we could limit the decline of blue-eyed islanders in imaginary worlds, but now I acknowledge that it is not because X cannot tell Y anything relevant. X knows that Y’s consideration of the possibility that Y does not have blue eyes is false, but there is no way to communicate that to Y, so just because it is false doesn’t mean X can be assured Y doesn’t believe it. When X imagines Y he (X) has to imagine the possibility that his (X’s) eye color is not blue and he (X) has to go on to imagine that Y imagines the possibility that Y imagines Y’s eyes are not blue and so on, and with every step of the chain the island loses a blue-eyed islander until finally there are none for A to see. X is wrong and has no way to know it and has to consider that everyone else cannot know whether they are right or wrong and must consider the world where they are wrong as equally plausible as the world where they are right.")

#text("This is, after all, what we all instinctually know for the case where there was only one blue-eyed islander to begin with. We consider the world where that person is wrong and doesn’t know it as reasonable for him to believe.")

#text("So while X knows that A sees at least 3 blue-eyed islanders, X doesn’t know that Y knows that Z knows that A knows there are any blue-eyed islanders. It is therefore not common knowledge that there is a blue-eyed islander.")

#text("Another way to look at it is that no one knows or has evidence of their own eye color and therefore every islander has to consider a reasonable belief in a possible world where every blue-eyed islander is completely wrong about their eye color. In this world there are no blue-eyed islanders. When the foreigner rules that world out, then the induction can begin, because anyone witnessing a world where there are no blue-eyed people would now know that they must have blue eyes. A world where every blue-eyed islander is wrong is no longer consistent with the evidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-217530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2013")])]

#text("I dont know why you gave up on this, it was correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-217597")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2013")])]

#text("Here’s what’s incorrect: That for certain numbers of blue-eyed islanders, it is true that A knows B knows C knows… that at least one person has blue eyes, for any extension of the chain A-B-C-D-E… etc. In fact, that’s not true.")

#text("If there is just 1 blue, he doesn’t know if anyone has blue eyes. If there are 2, then A knows B has blue eyes, but A doesn’t know whether B knows if anyone has blue eyes. With 3 people, A does know that B can see C’s blue eyes, but A doesn’t know if B knows if C knows if anyone has blue eyes. And so forth.")

#text("With 100 blues, it’s true that [each blue knows that]x99 someone has blue eyes, but false that [each blue knows that]x100 someone has blue eyes.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197447")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("No, Sean, every islander already knows every S_k before the foreigner speaks because, as I said above:")

#text("It has to be known to these logical people that whatever the real number of blue-eyed people is (let’s call it N), blue-eyed people see N-1 blue-eyed people and the rest see N blue-eyed people. So it is Common Knowledge that everyone has first-hand evidence of at least N-1 blue-eyed people.")

#text("Read my post above for details, but since these people are perfect logicians, they can thus be assured not only of every S_k but of of every Si_k for 0 < i < N-1 where Si_1 is the assertion that there are at least i blue eyed islanders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-197939")[#strong[#text("Leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2012")])]

#text("No, Sean_G has it exactly right. If N is the number of blue-eyed islanders, every islander knows every S_k for each k < N, but not every islander knows S_N.")

#text("For example if N were 2, everyone would know S_1 ie that there is at least one blue-eyed islander (because everyone could see at least one), but not everyone would know that everyone knows S_1 (the two blue-eyed islanders would not know that the other one knew this). That is, not everyone would know S_2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02ec516a7f95230100e6fe6b2d7ddf0cc93d90065bf68a3d28ee18795d092e2c-0aa1746d3e13ae0c00067e0196e7d4496ee987cba6fc2adacb92e734bdc884f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henning")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-209815")[#strong[#text("Henning")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2012")])]

#text("Here is a possible reasoning why the actual visit and utterance of the foreigner is important (I’d like to know whether that makes any sense):")

#text("Let us call X the day where the islanders first all met up in a group, thus making sure that everybody knows for certain, from that day, the eye color of all the other islanders (while they were not sure of that before).")

#text("Now it first appears that it suffices for the islanders, with their power of logical reasoning, to simply *suppose* that a visitor would come to their island and state that at least one of them has blue eyes; at X+100 all blue-eyed islanders would commit suicide.")

#text("However, it would clearly not work with n=1. But perhaps one can start the induction with n=2? Well, you cannot, because after the first day the two blue-eyed tribes people wouldn’t know if their companion did not commit suicide because of their own blue-eyedness, or because they did not know of the existence of a blue-eyed islander (as they now can only suppose such an existence, but not be certain of it).")

#text("Interestingly, in that scenario the islanders still have all the information needed to actually commit suicide after 100 days: Each of them just determines how many islanders they can see to have the minority color (blue), and resolve to commit suicide after that many days+1.")

#text("Can the islanders supose that they all actually resolve to do this – after all, that would be suicide?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02ec516a7f95230100e6fe6b2d7ddf0cc93d90065bf68a3d28ee18795d092e2c-0aa1746d3e13ae0c00067e0196e7d4496ee987cba6fc2adacb92e734bdc884f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henning")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-209818")[#strong[#text("Henning")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2012")])]

#text("Perhaps the real question is: In the scenario above, can you start the induction with n=3? (Because then, everyone can be sure that a supposed visitor could make this statement).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-209883")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2012")])]

#text("Okay, let’s consider that situation. You’re on the island and you don’t know your eye color. There is a collectively-agreed-upon Day Zero. You see exactly two people with blue eyes. Day 1 goes by and no one dies, Day 2 goes by and no one dies. So, do you now know your eye color?")

#text("Be careful. If you say “No”, then I’ll tell you your eyes were blue. This means that with three blues, they won’t be able to deduce their eye color.")

#text("But if you say “Yes”, I’ll inform you that your eyes were in fact green. Is this revelation — that you have green eyes — inconsistent with your observations of no one dying on Day 1 or Day 2?")

#text("If you answer ")#emph[#text("that")]#text(" with “Yes, it’s inconsistent”, then you’re saying that three is not the minimum for the induction to start, but rather, two is. And we can repeat the whole thing again. Why would two people die on Day 2? All they each know is that the other one didn’t die on Day 1, which is in turn perfectly consistent with there being only one blue altogether. (aA lone blue will not deduce his eye color out of thin air and kill himself ASAP; by that logic, each islander, seeing no one with green eyes, may as well deduce his own eyes to be green and kill himself for ")#emph[#text("that")]#text(" reason. The same with purple eyes, or any other color you can name.)")

#text("So with this, it can be proven that no number of blues is sufficient to “by itself” cause all the induction. A shorter way of putting this is: Apart from a visitor’s statement, an islander’s only input of information is observing people die or not die. If there is no reason for X blues to die on Day X, then X+1 blues ")#emph[#text("will not deduce anything from no one dying")]#text(", and thus X+1 blues won’t die on Day X+1.")

#text("It’s true that each of three blues can imagine a visitor making that statement, but they don’t know that the other two know that the other ones can imagine it. Any system you might devise for three blues deducing their eye color needs to ")#emph[#text("not")]#text(" cause a brown-eyed person, observing exactly two blues, to falsely conclude that his eyes are blue. And because the islanders are perfectly logical, they would all know this risk of any such system, so they would not apply it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02ec516a7f95230100e6fe6b2d7ddf0cc93d90065bf68a3d28ee18795d092e2c-0aa1746d3e13ae0c00067e0196e7d4496ee987cba6fc2adacb92e734bdc884f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henning")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-209921")[#strong[#text("Henning")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2012")])]

#text("Yes, I agree with this; thanks for the detailed explanation. I particularly like the part about the inconsistency. The actual information provided by the visitor is indeed important.")

#text("(Does this also prove that there is no possible line of reasoning, at all, that the islanders could apply to lead up to the simple recipe “I see 99 blue-eyed people, so I feel compelled to kill myself on day 100”?)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61378beead3238760a570ec5ea63616e587e3adc847a982e6191688fb1cc5a1f-323927d46ecb78aa4fa108bfc998439494d20c9b129a2e1841084db47839a243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oleksandr Rybak")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-211923")[#strong[#text("Oleksandr Rybak")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("The foreigner actually ADDED some new information to the tribe’s knowledge. Consider a simpler example with 2 blue-eyed people, say Andrew and Bob. Of course, Andrew knew from the beginning, that there are some blue-eyed people in the tribe (for example, Bob). But Andrew DIDN’T KNOW, if Bob knows, that there are some blue-eyed people!!! And after the foreigner’s speech Andrew HAS BEGUN to know, that Bob knows about the blue-eyed people in the tribe. So Andrew HAS BECOME TO BE ABLE to make some inductional meanings like “if Bob didn’t determine his eye colour at the first day, then I am blue-eyed, otherwise Bob would immediately know about the fact, that he is the unique blue-eyed in the tribe”.")#linebreak()#text(" Analogous meanings are correct for the case of 100 people. For example, after the speech of the foreigner the following fact has come true: blue-eyed man 1 knows, that blue-eyed man 2 knows, …, that blue-eyed man 100 knows, that there are blue-eyed people in the tribe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4906f8e4cceff0f6ba0bee3f5d6efb822c8df348075a35c1f88eb2972e615765-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Mossburg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-216069")[#strong[#text("Geoff Mossburg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("My problem with the second argument is this: “After nobody commits suicide on the (n-1)^{st} day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the n^{th} day.” Why would that be so, and why would it only be true of the people with blue eyes? If nobody commits suicide, it only logically implies that no one who has blue eyes realized they have blue eyes, but because there are many eye colors, the thinker would not have any reason to assume that this must mean they have blue eyes. However, even if I’m wrong about this, wouldn’t any-color eyed people be thinking the same thing as the blue eyed people, because they wouldn’t know what eye color they have either? Would they also commit suicide (ie: The entire tribe)? Possibly, but I would think that once people of any-colored eyes saw that non-blue eyed people were killing themselves, they would logically deduce that there is a flaw in the argument… Which leads to another problem of their supposedly perfect logic, but I think that’s beyond the scope of this conversation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-216126")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("I find that one of the best ways to grasp the problem is to test various “strategies” as thought experiments, starting from very low numbers of islanders. Imagine that the islanders are robots executing identical code which has been designed to derive one’s own eye color, and that the only input of information is which other robots have “died” and on which day. If a given series of instructions works in any circumstances, then the islanders will use it.")

#text("Suppose that for some possible Method Z in a particular situation, we find that ")#emph[#text("if")]#text(" all islanders followed Method Z, then some of them would make the wrong deduction. Well, the perfectly logical islanders can imagine this outcome, and therefore know not to use Method Z in the first place.")

#text("That’s why this is incorrect:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I would think that once people of any-colored eyes saw that non-blue eyed people were killing themselves, they would logically deduce that there is a flaw in the argument…")
]

#text("Ordinary humans could well make wrong deductions from true premises, but not these islanders. Indeed, if even a single ordinary human were substituted for an islander, the whole thing would break down; it relies on the islanders (A) being perfectly logical and (B) knowing that all the islanders know that A and B are true. (note the recursion!) So we can safely say no islander will make a wrong deduction. Further, ")#emph[#text("if")]#text(" any islander sees a non-blue kill himself, she will just assume that he discovered his color by other means (and she will be correct).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-216130")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("So the question remains: Why does the problem work out the way it does?")

#text("Suppose there were exactly one blue and no one else. He would have no reason to know his eye color until after a visitor arrives and speaks, saying he sees “at least one” blue. Then the islander immediately knows that he is blue, and leaves (a less violent alternative to killing himself) at the next noon.")

#text("Now suppose there were two blues. Initially, they have no reason to know their own color. Along comes the visitor. After the visitor speaks, each blue considers two possibilities: “Either (A) I am blue-eyed, or (B) I’m not. If B is true, then that blue I see must realize he is blue, and will leave at the next noon, or Day 1.” On Day 1, that doesn’t happen. Each islander then thinks “B must be false, meaning A is true, meaning that I am blue.” On Day 2, the two blues leave.")

#text("Let’s add a third person. Each of them considers the possibility that he is not blue (brown-, or green-, or orange-eyed), in which case it would be just like the former paragraph. Each thinks “If I am not blue, then the two blues I see will leave on Day 2.” Then that doesn’t happen. This means that “I am not blue” is false, and therefore “I am blue” is true. So on Day 3, each of the three blues leaves.")

#text("This continues indefinitely. Suppose it is true that for some particular N (such as 1, or 4, or 15) that a set of exactly N blues would leave on Day N. (Not for all numbers, just at least one. For example, it is true that for some number N that there are N states in the USA. Since it’s true if N==50, then it’s not false.)")

#text("Further suppose there are really N+1 blues.")

#text("Each of them observes only N blues and figures that there might be only N blues, in which case those N will kill themselves on Day N. When that doesn’t happen, it means there are not exactly N blues, which means there are exactly N+1, including oneself, which means you know that you are blue, and you will leave on Day N+1. In short, ")#emph[#text("if")]#text(" N blues would leave on Day N, ")#emph[#text("then")]#text(" N+1 would leave on Day N+1. This means that if it works for N==1, it works for N==2. If it works for N==2, it works for N==3. And so forth, up to 100 and beyond.")

#text("One reason that no non-blue-eyed person would have to leave is that they keep a different count of the number of blues, as discussed above. Until the day comes when all the blues do go (leaving the rest of the islanders behind), each islander, blue or otherwise, is continually considering the possibility that he is blue. He knows that ")#emph[#text("if")]#emph[#text(" he is not blue, ")]#emph[#text("then")]#text(" he will observe the N blues he sees leaving on Day N. Once that ")#emph[#text("does")]#text(" happen, he will know that he is not blue.")

#text("If you think you have a system whereby a non-blue would correctly deduce their eye color, then try “testing” it as a thought problem. (Consider that each individual brown has no way of knowing his eyes aren’t green, or orange, or purple.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7128c689bab1a66e0846fc5cecf7df0eed046d7c44d29b2e4bfbac4bb8e91e00-80485c9146cf90ff803dec9caf31ffda3c462e24b696598af92336a940b35704.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-216682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2013")])]

#text("The problem with the logic is that we ignore time. What we do is pretty much apply some kind of “logical” algorithm recursively and that algorithm while applied to the past implies knowledge of present.")#linebreak()#text(" Suppose there are 2 Blue eyed and 2 brown eyed people at time T0 and someone says there is one blue eyed them we say, okay if at time T-1 there were only one blue eyed and he knew that that there is at least one blue eyed, than he could see other 3 brown eyed and deduce that he is the blue eyed and would kill himself. Whats the problem with this logic: problem is that at time T-1 we assume that blue eyed person knows something that is known only at time T0.")#linebreak()#text(" In mathematical finance it is called information filtration, when you backtest your algorithm you cant imply knowledge of present ( because you are in the past). It is the same as predicting future. Whole “logical” yada yada proof here ignores existence of time and the fact that you can’t predict future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9a3deeacdef6a4b89333d620b7e196776ab556d4650f5835027102da0d4fff1-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irakli Machabeli")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-216683")[#strong[#text("Irakli Machabeli")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2013")])]

#text("The problem with the logic is that we ignore time. What we do is pretty much apply some kind of “logical” algorithm recursively and that algorithm while applied to the past implies knowledge of present.")#linebreak()#text(" Suppose there are 2 Blue eyed and 2 brown eyed people at time T0 and someone says there is one blue eyed them we say, okay if at time T-1 there were only one blue eyed and he knew that that there is at least one blue eyed, than he could see other 3 brown eyed and deduce that he is the blue eyed and would kill himself. Whats the problem with this logic: problem is that at time T-1 we assume that blue eyed person knows something that is known only at time T0.")#linebreak()#text(" In mathematical finance it is called information filtration, when you backtest your algorithm you cant imply knowledge of present ( because you are in the past). It is the same as predicting future. Whole “logical” yada yada proof here ignores existence of time and the fact that you can’t predict future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/770d015102e1c17d03160d92ceb12e9a18f1e5dc7952d2ab04d6d0f12d0e35e9-5a3d3d0b4d32babd99ca3f18cf71071105af3fe5b30c03e5bb9ca06b89bc7510.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-217073")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2013")])]

#text("Dear Prof. Tao")

#text("Are there any applications of this sort of logic, in, say, mathematics? When solving some math problem, would the reasoning required to solve this problem ever be useful (when looking at a problem which isn’t related to this blue eyed islander problem in an obvious way)?")

#text("I think I solved it in the same way that everyone else did (by “induction”, you might say). Could one do this in another way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c00dc22e79bcec33792a2967a07d97df7bcb1a59f1fe30d479f85caaa1538ef8-bd755dccfbc6d7c5c72bd72a47c5d9c6fa4bc719c12278cdc1d31f6e61fed795.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jorriss")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-217834")[#strong[#text("Jorriss")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("I do not understand why the Guru is necessary.")

#text("Suppose there are three people who have never seen eachother, they bump into eachother and see eachothers eyes for the first time (yet they still know the rules). Suppose we know they all have blue eyes.")

#text("Take one of the people, call him A. A does not know if he has blue or brown eyes. From A’s perspective, if his eyes are brown then B and C (the other two people) will see one person with brown eyes and one with blue. Suppose you are B. From A’s perspective, B sees one person with blue eyes and and one person with brown. So if C does not leave the island, the next day, B knows his eyes are blue. Then, if neither leave after 2 days, A knows his assumption was wrong and his eyes are blue after all, and they all leave on day 3.")

#text("I understand the induction proof I believe, but I do not see why the guru is necessary. Certainly he is sufficient for starting the problem but I see them as leaving regardless – regardless of the fact the guru gave new knowledge (common knowledge).")

#text("Can someone please clarify why I am misguided?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c00dc22e79bcec33792a2967a07d97df7bcb1a59f1fe30d479f85caaa1538ef8-bd755dccfbc6d7c5c72bd72a47c5d9c6fa4bc719c12278cdc1d31f6e61fed795.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jorriss")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-217840")[#strong[#text("Jorriss")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("I do not see how to delete comments.")

#text("I finally understand why the guru’s comment is necessary. That may of been one of the most confusing problems I have come across. I’ve spent hours thinking about it, I don’t know why it suddenly clicked despite the fact I had already gone through the same scenario so many times.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca9a9774a74ff47115176b2146e81e6374ee7f3d0f8f41016e988e9c0f50d507-93f05af6ab662840b07d6644659f2fa4e4079114825e3b70e266edb3771a30b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218062")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2013")])]

#text("Don’t stop at 3 or 4 islanders. Look at what happens with 5: A knows that B (every other islander) can see that D has sight of both C and E. i.e. everyone knows that everyone knows there are at lease two blue eyed islanders. If there are at least two, then nobody is sitting waiting for the other to leave the island. This defeats the induction argument at the lower end. At the higher end, say 100 islanders, we are told that each islander holds a hypothesis containing the hypothesis of each the other: “nested hypotheses” But even nested hypotheses cannot be protected from the truth: if you are standing infront of the Eiffel Tower with 7 friends, you might be hypothesising all sorts of things about what Jim thinks about Karen thinks about John etc – but in no part of any hypothesis, nested or otherwise, will anyone believe they are in fact standing in front of the Statue of Liberty. So the idea that everyone is waiting on a hypothetical individual they know definitely does not exist is not possible – unless they subscribe to epistemic modal logic – which as far as I can tell has grown out of this and the other Christmas cracker puzzles – and really just amounts to a way of using the questioning to count themselves. i.e count to as many number days as you see blue eyed islanders and then leave – there’s no other information coming in, as so many others have intuitively known.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218201")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("With the Eiffel tower, there’s a huge difference — the tower’s “thoughts” are no concern to anyone; no one in that situation cares if the tower knows it’s a tower. Replace that tower with a single blue-eyed person, and you agree that blue eyes would not be common knowledge to the group. To put it simply: There is no number of people staring at my eyes which can cause me to know my eye color. This fact is itself common knowledge, so no one will think anyone else thinks ")#emph[#text("anyone else thinks")]#text(" anyone else knows my eye color.")

#text("You argue that 5 is a crucial point where things change. Let’s consider that situation. You are on the island and see exactly 4 blue-eyed people. Do you think it is common knowledge that at least 1 person is blue-eyed?")

#text("If you say yes, I’ll inform you that your eyes are brown, which means you must have been wrong, since it’s not the case that 4 blues would have that common knowledge. (Remember the definition of common knowledge: it’s that A knows B knows C knows D knows… X, for ")#emph[#text("any number of levels")]#text(", not just two or three.)")

#text("If you say no, I’ll inform you that your eyes are blue. This means that even though there were 5 of you, you couldn’t be sure of blue eyes being common knowledge.")

#text("A simpler way to explain it is: Each islander has a significant blind spot: His own eye color. When considering the mental state of another islander, he must consider that islander’s lack of knowing his own eye color. The unknowns accumulate, resulting in “nested ignorance”. Every islander you add will still not know his own eye color, so it’s not possible to add islanders “until” blue eyes become common knowledge.")

#text("If there are at least two, then nobody is sitting waiting for the other to leave the island.")

#text("This is correct, and it’s actually quite simple to extend this: If there are N + 1 blues, then ")#emph[#text("nobody is waiting for the other N blues to leave")]#text(". Think about it: If 2 blues would not have any reason to leave, then a 3rd blue, who only sees 2 blues, ")#emph[#text("will not learn anything from them not leaving")]#text(", and therefore 3 blues ")#emph[#text("have no reason to leave either")]#text(". So this establishes that 3 blues would not leave. If there’s a 4th blue, then each blue sees only 3 blues, and therefore ")#emph[#text("learns nothing from those 3 not leaving")]#text(". And so on.")

#text("When you contradict this, you’re saying that there’s an upper-bound number of blues which would not leave, but if you added one more blue, they would. But that additional blue (who is isomorphic to all the other blues, of course) can only see a number of blues who ")#emph[#text("wouldn’t")]#text(" leave, so he can’t learn anything from them not leaving.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d83c939bbc5aecd3be423515a5696b00668f2d8feb9bd63e32efee1f98ce3aa-f27d559bf6843af50f74a276cc5ea59dd8b460114323d022c46c8530de73b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218211")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("My response as follows, answers*")#linebreak()#text(" With the Eiffel tower, there’s a huge difference — the tower’s “thoughts” are no concern to anyone; no one in that situation cares if the tower knows it’s a tower. Replace that tower with a single blue-eyed person, and you agree that blue eyes would not be common knowledge to the group.")#linebreak()#text(" *No, absolutely, that doesn’t happen until five, when it is known there is a minimum of two.")#linebreak()#text(" To put it simply: There is no number of people staring at my eyes which can cause me to know my eye color.")#linebreak()#text(" *No, but looking at the others when there are more than five tells you there are enough for nobody to wonder if one person might be thinking they are the only one The lack of self knowledge you state here is implicit in the puzzle proposition.")#linebreak()#text(" This fact is itself common knowledge, so no one will think anyone else thinks anyone else thinks anyone else knows my eye color.")#linebreak()#text(" *Everyone who isn’t you knows they and everyone else knows your eye colour.The opposite to what you have written.")#linebreak()#text(" You argue that 5 is a crucial point where things change. Let’s consider that situation. You are on the island and see exactly 4 blue-eyed people. Do you think it is common knowledge that at least 1 person is blue-eyed?")#linebreak()#text(" *No, two.")#linebreak()#text(" If you say yes, I’ll inform you that your eyes are brown, which means you must have been wrong, since it’s not the case that 4 blues would have that common knowledge. (Remember the definition of common knowledge: it’s that A knows B knows C knows D knows… X, for any number of levels, not just two or three.)")#linebreak()#text(" *My proposition is that the “common knowledge” is that there is a minimum number of blue eyed people known to the group. I am not relying on this version of common knowledge which seems to require knowing exact numbers. Obviously quite impossible when you don’t know your own eye colour.")#linebreak()#text(" If you say no, I’ll inform you that your eyes are blue. This means that even though there were 5 of you, you couldn’t be sure of blue eyes being common knowledge.")#linebreak()#text(" *Again, all you’re really saying is that you require exact numbers to be known. I don’t.")#linebreak()#text(" A simpler way to explain it is: Each islander has a significant blind spot: His own eye color. When considering the mental state of another islander, he must consider that islander’s lack of knowing his own eye color. The unknowns accumulate, resulting in “nested ignorance”. Every islander you add will still not know his own eye color, so it’s not possible to add islanders “until” blue eyes become common knowledge.")#linebreak()#text(" *You must choose between this and my objections to nested concepts, which I find to fly in face of what must be known to all and a high minded logical conceit that does not in fact work.")#linebreak()#text(" If there are at least two, then nobody is sitting waiting for the other to leave the island.")#linebreak()#text(" This is correct, and it’s actually quite simple to extend this: If there are N + 1 blues, then nobody is waiting for the other N blues to leave. Think about it: If 2 blues would not have any reason to leave, then a 3rd blue, who only sees 2 blues, will not learn anything from them not leaving, and therefore 3 blues have no reason to leave either. So this establishes that 3 blues would not leave. If there’s a 4th blue, then each blue sees only 3 blues, and therefore learns nothing from those 3 not leaving. And so on.")#linebreak()#text(" *That’s my point, yes.")#linebreak()#text(" When you contradict this, you’re saying that there’s an upper-bound number of blues which would not leave, but if you added one more blue, they would. But that additional blue (who is isomorphic to all the other blues, of course) can only see a number of blues who wouldn’t leave, so he can’t learn anything from them not leaving.")#linebreak()#text(" *I don’t see that I said this, about adding blue eyed people. I agree it wouldn’t really change anything. Particularly if he doesn’t know his own eye colour.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218219")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("(A useful trick I forgot to use in my last post is the blockquote tag.)")

#text("I am not relying on this version of common knowledge which seems to require knowing exact numbers.")

#text("Ah, I should clarify. ")#link("http://en.wikipedia.org/wiki/Common_knowledge_(logic)")[#text("Common knowledge")]#text(" does not require knowledge of specific amounts. It is enough to know about minimums and maximums, such as “There are at least two people with blue eyes.” For P to be common knowledge for a given group of people, each of them has to know that each other person knows that each other person knows… repeated ")#strong[#text("forever")]#text(", that P is true. P could be “At least one of us has blue eyes.”")

#text("Everyone who isn’t you knows they and everyone else knows your eye colour.The opposite to what you have written.")

#text("Yes, but now you’ve subtracted me from the group of people being considered. It’s true that a group of blue-eyed people looking at blue-eyed ")#emph[#text("outsider")]#emph[#text(" will have common knowledge that that person has blue eyes. However, once we consider the group as a whole ")]#emph[#text("with that person included")]#text(", then there is not such common knowledge. This isn’t magic or nonsense, it’s a matter of making logically correct statements, like the difference between “Everyone except Jake knows about the stain on Jake’s shirt”, which may be true, and “Everyone (including Jake) knows about the stain on Jake’s shirt”, which may be false. This problem is just more complicated because of all the nesting, the “Everyone knows that everyone knows” stuff.")

#text("================================")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("You must choose between this and my objections to nested concepts, which I find to fly in face of what must be known to all and a high minded logical conceit that does not in fact work.")
]

#text("That may be the entire issue. If you reject the existence or relevance of nested thinking in general, then you will reject it here, of course. You are free to do so, though you can’t turn around and say that it’s false that blue eyes are not common knowledge with 100 blues. Common knowledge relies on nested thinking by definition; otherwise it is merely ")#link("http://en.wikipedia.org/wiki/Mutual_knowledge_(logic)")[#text("mutual knowledge")]#text(". If you object to nested concepts, you can’t say the islanders ")#emph[#text("do")]#text(" have an all-the-way-nested concept of someone having blue eyes.")

#text("The simple truth is that humans almost never think more than “two layers deep” here, three at the most, like “She thinks that he knows that I like chamber music”. I certainly don’t think any levels past that, there’s no need to. But these hypothetical islanders ")#emph[#text("do")]#text(" think at any number of levels. (You are free to reject this very premise.)")

#text("================================")

#text("Anyway, you do accept that no one would leave/die until a visitor said something, yes? So there’s not much left to disagree over. The islanders don’t leave until a visitor says “At least one of you has blue eyes,” after which all N blue-eyed people leave on Day N. This can be explained in terms of nested logic, but it doesn’t have to be. All we have to do is establish this:")

#text("1. If, for some particular number X, it is true and known that X blues would leave on Day X, then a group of X+1 blues, upon seeing the other X blues not leaving on Day X, would leave the next day: Day X+1.")

#text("2. After the visitor speaks, a single blue would conclude his eye color, and leave on Day 1.")

#text("(Repeated reading of Point 1 establishes that 100 blues would leave on Day 100.)")

#text("3. If, for some particular number Q, it is true that Q blues would ")#emph[#text("not")]#text(" leave on or before Day Q, then a group of Q+1 blues would not conclude anything from seeing the other Q blues not leaving, and therefore Q+1 blues would not leave on Day Q+1.")

#text("4. Before a visitor speaks, a lone blue would not have reason to conclude his eye color, and would not leave on any day.")

#text("================================")

#text("Going back a bit:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("No, but looking at the others when there are more than five tells you there are enough for nobody to wonder if one person might be thinking they are the only one")
]

#text("This is true. But it’s only two levels deep, which is enough with two blues but not three or more. One of the best demonstrattions of the situation is ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/”")[#text("this picture here")]#text(". The basic idea can be extended to more than three people, and the question marks can never “go away” (For example, it’s not possible that while B ")#emph[#text("doesn’t")]#text(" know his own eye color, D thinks C ")#emph[#text("thinks")]#text(" B knows his own eye color.) When you get all the way to the middle, every blue is “thinking” that innermost thought bubble, so all the ignorance has accumulated.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39bbeb3a8cb6e118987d64abf02ae61338c9c8d31f77b271030a443018fb078a-ee25dbf4193b08f7f11ed865cbcdaab3925f4047562b238b329b6ed8d02363bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irakli Machabeli")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218202")[#strong[#text("Irakli Machabeli")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("Easiest case to show what’s wrong with the solution offered here and all other solutions like on wikipedia etc is to consider case of 4 blue eyed people.")

#text("Proposition 0: If there are 4 blue eyed people than everyone sees other 3 and also all of them can conclude(even without knowing their own eye color) that all of them know(not a typo) that there are at least 2 blue eyed people on the island. So if blue eyed people are A,B,C & D than A can say that B knows that C knows that D knows that A knows that there are at least 2 blue eyed, B can make similar assumption etc.")

#text("This would be enough for a pure mathematical proof, since if all of them know that all of them know that there are at least 2 blue eyed people than visitors anouncement that there is one blue eyed among them does not introduce new knowledge.")

#text("Let’s find out what’s wrong with the proof:")

#text("General argument for any kid of proof: If proof/solution assumes something that is impossible or contradicts to initial conditions than every conclusion based on such an assumption is useless.")

#text("All solutions I’ve seen so far include some variations of :")

#text("Suggestion A: Suppose/if there was only person (same as suppose n=1)")#linebreak()#text(" Suggestion B: Suppose/If there was only one blue eyed person")

#text("Clearly if there are 4 blue eyed person we can’t suggest that there is only one person on the island so Suggestion A is clearly wrong and all proof based on such a suggestion are wrong. This also invalidates all recursive proofs that assume that n=1 / day one . One can abstract from the concrete example and say suppose n=1/day one, but than you can’t imply the knowledge that on day one you knew that there is one blue eyed person.")

#text("Now what’s wrong with the suggestion B? remember proposition 0. Everybody knows that all of them know that there are at least 2 blue eyed people on the island. But suggestion B says suppose there is only one blue eyed person. This Suggestion is also wrong since we know that there are at least two of them. So, all profs/conclusions based on suggestion B are also wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816a69910182fc3ee898573d022e5c75658ac1c893a37ddeb5fdfbdb5ac54876-d12f51ee3d5c1dcf4f3ad46c014a47c1af66f01026fa4cac86590b5baef63b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218216")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("It is not true that with 4 everyone knows there are at least 2 blue eyed people: A does not know his own eye colour and looks at B. He knows B may be wondering if he himself has blue eyes. So it’s possible for A that B believes they both, A and B are not blue eyed. In addition to this, A thinks”If it’s possible in B’s world that neither of us have blue eyes, he must look at C and wonder if he also doesn’t know if he has blue eyes”. That makes a possible 3 without blue eyes. At 5, A knows B has sight of C,D and E – so knows B is aware that C (or D) is looking at a minimum of two.")#linebreak()#text(" Also, my proof isn’t like the rest. I’ve checked.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218222")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2013")])]

#text("Now I can’t tell what you’re trying to say. Remember to distinguish between the knowledge at the different layers.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("It is not true that with 4 everyone knows there are at least 2 blue eyed people: A does not know his own eye colour and looks at B. He knows B may be wondering if he himself has blue eyes.")
]

#text("The basic assertion “There are at least 2 blue eyed people” is distinct from “Everyone knows that everyone knows that everyone knows there are two blue-eyed people.” In fact, if there are really 4 blues, then each of them personally observes 3 blues, and hence each of the knows there are 3 blues. It is not common knowledge that there are 3 blues but it is mutual knowledge.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("At 5, A knows B has sight of C,D and E – so knows B is aware that C (or D) is looking at a minimum of two.")
]

#text("Yes, this is true. For all A knows that B knows that C knows, C may be seeing 2, or 3, or 4, or 5 blue-eyed people. But there’s another layer we can consider: A knows that B knows that C knows that D can see at least ___ blue-eyed people/person. How would you fill in the blank?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39bbeb3a8cb6e118987d64abf02ae61338c9c8d31f77b271030a443018fb078a-ee25dbf4193b08f7f11ed865cbcdaab3925f4047562b238b329b6ed8d02363bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irakli Machabeli")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218335")[#strong[#text("Irakli Machabeli")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Forget about layers. If i’m a logical person and I know that everybody knows that there are at least 2 blue eyed than I can not make an assumption that someone might think there is only one(as long as that someone is also logical)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218355")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Take a look at ")#link("http://www.mediafire.com/view/?gy5m3fqpd7ok99k")[#text("the diagram")]#text(" I linked to elsewhere here. See if you understand with it and agree with its idea.")

#text("You said:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("If i’m a logical person and I know that everybody knows that there are at least 2 blue eyed than I can not make an assumption that someone might think there is only one(as long as that someone is also logical)")
]

#text("Yes, this is correct. But from your point of view, someone might think that someone might think there is only one. That’s a ")#emph[#text("different statement")]#text(", just like “My mother’s mother” and “my mother’s mother’s mother” are two different people. If we added another hundred generations there, it would be difficult to keep track of the difference, but this doesn’t mean the difference doesn’t exist, or even that it’s a “small” difference. My [mother’s x98] mother is not “almost” my [mother’s x 99] mother, any more than I am almost my mother.")

#text("Suppose there are four blues, A, B, C, and D. Consider the following statement, which may or may not be true: “A knows B knows C knows that D knows someone has blue eyes.” The question must be asked: ")#emph[#text("Exactly how does D know this")]#text("?")

#text("The answer may seem obvious: He just looks around! But this is a ")#emph[#text("hypothetical")]#text(" D, not the real one. The real Mark Zuckerberg knows his computer password, but this doesn’t mean I know it. And even if I did know it, that wouldn’t mean that my cousin knows that I know it, and so forth.")

#text("So if this hypothetical D knows that someone has blue eyes by “looking around”, exactly which other islander is he looking at? Remember the statement, “A knows B knows C knows D sees someone with blue eyes.”")

#text("It can’t be C, or B, or A, because we are ")#emph[#text("inside each of their heads")]#text(", recursively. It’s impossible for A to think that B thinks that C thinks that D can see B’s blue eyes. That would require A to think that B knows that C can see B’s blue eyes! And it likewise can’t work for C’s blue eyes, or A’s blue eyes, or D’s blue eyes.")

#text("So there is no way for knowledge to be common, by the strict logical definition of ")#text("common knowledge")#text(". Hence, the statement cannot have been correct.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/816a69910182fc3ee898573d022e5c75658ac1c893a37ddeb5fdfbdb5ac54876-d12f51ee3d5c1dcf4f3ad46c014a47c1af66f01026fa4cac86590b5baef63b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218328")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Thanks for replying to my post. Your answers were to the point and I have a better understanding of your point of view. A few statements for clarity’s sake:")#linebreak()#text(" I am satisfied that we mean the same thing by common knowledge.")#linebreak()#text(" I agree with nested hypotheses, but not as applied to this puzzle.")#linebreak()#text(" I fully accept the premise that the islanders think at every possible level, and no part of my argument rejects this or any kind of recursive thinking if it is logical.")#linebreak()#text(" I don’t think anyone would leave at all when the foreigner makes his announcement unless there are four or fewer islanders.")#linebreak()#text(" I couldn’t access you picture, it seems to have gone. Let me know if it is still there and if so if you know how I can see it.")#linebreak()#text(" I agree with your last point about mutual knowledge with four people, (all see 3 blues) and distinguish it from common knowledge (with 4, all know there is at least one, and wait on his reaction after the first night, all leave after 3 days).")#linebreak()#text(" I will address your last question, as I believe it goes to heart of the way in which the puzzle is perceived. You asked, I think meaning a five person scenario:")#linebreak()#text(" “Yes, this is true. For all A knows that B knows that C knows, C may be seeing 2, or 3, or 4, or 5 blue-eyed people. But there’s another layer we can consider: A knows that B knows that C knows that D can see at least ___ blue-eyed people/person. How would you fill in the blank?”")#linebreak()#text(" The answer is one and that person is E. But I would ask you: A knows that B knows that C knows that E can see at least___blue-eyed people/person. How would you fill in the blank?” Would the answer also be one? And would that person not be D?")#linebreak()#text(" A asks him/herself both these questions and decides that B, who after all is everyone else on the island, knows that C (every other apart from B) knows both D and E have blue eyes.")#linebreak()#text(" This cuts to the question if interchangeability and whose thoughts exactly signify the thoughts of everyone. The complexity comes from the fact that we as non-islanders must get inside the head of any islander – say A. Although for us A is every person on the island, the puzzle is about what A “The Observer” makes of every other person on the island, B. There are effectively 2 viewers who are “out of the game”, testing our null hypotheses- us and A. B is the “everyman” in the puzzle. B’s knowledge can only be formulated with reference to himself and all identical others. This is because all others are the same. For B everybody else thinks the same as each other and is interchangeable, and cannot have different levels of knowledge. So B the everyman cannot imagine a situation in which C knows that D and E have blue eyes but D cannot see both C and E. Or that all 3 cannot see each other.")#linebreak()#text(" What this means is that you cannot create a single chain such as the one above in which A knows that B knows that C knows that D knows etc without asking the same question interchanging all the letters. Ultimately A will conclude that B knows that that C knows all the other letters of the alphabet have blue eyes, as after all permutations have been considered all letters will have ended up at the end at some point (which incidentally doesn’t require a foreigner to point out).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218333")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Whoops, you’re right, I didn’t link correctly to that image. Here’s its url: ")#link("http://www.mediafire.com/view/?gy5m3fqpd7ok99k#")[#text("http://www.mediafire.com/view/?gy5m3fqpd7ok99k#")]

#text("Next, I’ll address this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I don’t think anyone would leave at all when the foreigner makes his announcement unless there are four or fewer islanders.")
]

#text("To be precise, do you mean “four or fewer ")#strong[#text("blue-eyed")]#text(" islanders”?")

#text("If so, that does sound reasonable, but there’s a simple counterargument. Suppose you are on the island, not knowing your own eye color. You see exactly four blue-eyed people. The visitor makes his announcement. Days 1, 2, and 3 go by without anyone leaving. Ask yourself the following two questions:")

#text("1) If my eyes are ")#emph[#text("not")]#text(" blue (meaning there are exactly four blue-eyed people) what will happen (or not happen) on Day 4?")

#text("2) If my eyes ")#emph[#text("are")]#text(" blue, what will happen (or not happen) on Day 4?")

#text("Meanwhile…")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I would ask you: A knows that B knows that C knows that E can see at least___blue-eyed people/person. How would you fill in the blank?” Would the answer also be one? And would that person not be D?")
]

#text("Yes to both. But these letters are really just stand-ins for “any other person not previously mentioned in this train of thought.” It’s just that it would be complicated to have words for “any one person” and “any one person besides that person” and “any one person besides the previous two people” and so forth.")

#text("I’d like you to consider the following scenario: Yolanda has blue eyes and Zoe sees Yolanda. Does this mean that Yolanda knows that Zoe knows that Yolanda has blue eyes? Of course not.")

#text("That example seems silly, but it’s easy to fall into a similar trap when we add more people, because of how complex it gets. For example: “William knows that Xavier knows that Yolanda knows that Zoe knows that ___ has blue eyes.” Whose name can we insert there? The answer is: None of those four (it’s kind of a trick question). Do you see why?")

#text("You say:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Ultimately A will conclude that B knows that that C knows all the other letters of the alphabet have blue eyes, as after all permutations have been considered all letters will have ended up at the end at some point (which incidentally doesn’t require a foreigner to point out).")
]

#text("But this sounds like you’re “inserting a name” in my William-Zoe example, which I just suggested cannot be done.")

#text("Take another look at the picture (I hope it works this time!) and tell me what you think.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d83c939bbc5aecd3be423515a5696b00668f2d8feb9bd63e32efee1f98ce3aa-f27d559bf6843af50f74a276cc5ea59dd8b460114323d022c46c8530de73b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218378")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2013")])]

#text("Thanks for the picture, I agree with what is represented here. I appreciate that if it were extended to 100 islanders, all 100 would end up possibly not blue in a thought cloud in the middle. But draw it out for 5, ABCDE. Look at E. Is it credible that E might imagine that everyone in the group does not have blue eyes – when A – whose thoughts these are – knows that E can see B,C and D, who he sees have blue eyes? In order to come up with a grand theory a scientific enquiry may require sub-theories or hypotheses. The grand hypothesis depends on these sub-hypotheses or nested hypotheses. If one of these sub-hypotheses conflicted with another or the main hypothesis, this would be a cause for alarm. As applied to the puzzle, there does not seem to be any consideration of whether the nested hypotheses conflict with one another, as in the above example, where A knows for a fact E cannot possibly be wondering if everyone else does not have blue eyes. And he knows that B also knows this. The nested hypotheses are applied in a way that obscures knowledge from certain hypothetical islanders, knowledge that is not in fact obscured.")#linebreak()#text(" I appreciate what you say about the interchangeability of names and am slightly confused as this is my point entirely. My answer about D seeing E to your question was in essence rhetorical, as the question particularises the islanders to make them seem like different people. By switching the letters I was showing that you cannot particularise in this way. But if for the sake of argument we do name particular islanders with letters (without them knowing-if that matters) how would you dispute my conclusion that A knows B knows C is aware of 2 blues, D and E? And if all islanders are interchangeable, doesn’t that mean all 5 know there are at least 2 blues?")#linebreak()#text(" Yes, I did mean 4 blue eyed islanders. Everyone leaves after 3 days i.e. on Day 4. If I did not have blue eyes, they would have left on day 3. So in answer to your question, if I don’t have blue eyes, I am alone on day 4. Not sure where you are going with that one. That’s the basis for the simple induction argument with which I disagree.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d83c939bbc5aecd3be423515a5696b00668f2d8feb9bd63e32efee1f98ce3aa-f27d559bf6843af50f74a276cc5ea59dd8b460114323d022c46c8530de73b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218381")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Apologies, I slipped and “everyone knows”. Final question in paragraph 3 should read:")#linebreak()#text(" And if all islanders are interchangeable, doesn’t that mean all 5 know everyone knows there are at least 2 blues?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218416")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("The “interchangeability” of the actual islanders does not imply an interchangeability of the ")#emph[#text("hypothetical")]#text(" islanders, and this is crucial.")

#text("Compare the statements “A knows that B sees that C has blue eyes” and “A knows that C sees that B has blue eyes.” The two Bs here are ")#emph[#text("very different")]#text(", because one of them is in-C’s-mind-in-A’s-mind, and the other is directly-in-A’s-mind.")

#text("If we switch these two B’s around, then we are allowing people’s thoughts to “cross” as if they were mind-readers, or something stranger still: Two people recursively imagining each other! (Even that was too weird for ")#emph[#link("http://www.imdb.com/title/tt1375666/")[#text("Inception")]]#text(".)")

#text("Is it credible that E might imagine that everyone in the group does not have blue eyes – when A – whose thoughts these are – knows that E can see B,C and D, who he sees have blue eyes?")

#text("E is different from the E in D’s mind. Further, the E in D’s mind is different from the E in C’s conception of D’s mind. This, in turn, is different from the E in B’s idea of C’s conception of D’s mind.")

#text("Does A know that E can see B’s blue eyes? Yes. Does A know that E can see C’s blue eyes, and that E can see D’s blue eyes? Yes to both.")

#text("But the “innermost” E (the one who is being pictured by ")#strong[#text("an imaginary D")]#text(" who is ")#emph[#text("in turn")]#text(" being imagined by ")#strong[#text("a fictional C")]#text(" who is ")#emph[#text("in turn")]#text(" being by ")#strong[#text("a hypothetical B")]#text(" who is ")#emph[#text("in turn")]#text(" being conceptualized by ")#strong[#text("the real A")]#text(" — whew!) does not necessarily see anyone with blue eyes.")

#text("Try filling in this sentence: ")#emph[#text("A knows that B knows that C knows that D knows that E can see that ___ has blue eyes.")]

#text("Do you see why the blank can’t be filled in with A? Or why it can’t be filled with E? Well, for similar reasons, it can’t be filed with B, or C, or D. This would require B (or C, or D) to be able to ")#emph[#text("look at his own blue eyes")]#text(", or to be imagined by A as being capable of doing so.")

#text("================")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Everyone leaves after 3 days i.e. on Day 4. If I did not have blue eyes, they would have left on day 3.")
]

#text("Remember, I didn’t say there were four blues total and you see three of them. I said that ")#emph[#text("you see")]#text(" four blues. If your eyes are blue (which I didn’t tell you — maybe they are and maybe not), then there are five blues, not four.")

#text("So let’s try this again. You agree that if there are exactly four blues, they will leave on Day 4. You are on the island and see four blues.")

#text("Maybe your eyes are not blue. In that case, the four blues you see will leave on Day 4, right?")

#text("Maybe your eyes are blue. In that case, would the four blues you see leave on Day 4? No, there’s no reason for them to.")

#text("You now have a simple way to test the two competing hypotheses, exactly one of which must be true.")

#emph[#text("Hypothesis Alpha: There are four blues.")]#text(" If this is true, then they will leave on Day 4.")

#emph[#text("Hypothesis Beta: There are five blues.")]#text(" If Hypothesis Alpha is false, then Hypothesis Two is true.")

#text("Is there a way to tell if Alpha is false? Yes. If no one leaves on Day 4, then Alpha is false. This means Beta is true. This means there are five blues total. This means that you have blue eyes.")

#text("To summarize: If you see exactly four blues, and they don’t leave on Day 4, then you have blue eyes.")

#text("Furthermore, if you do have blue eyes, then each of the blues you see will be able to make the exact same deduction. Hence, on Day 5, you won’t leave alone — all five blues, including you, will leave together. (Again, that’s if that you do have blue eyes. If you don’t, then the four blues you observe will leave on Day 4.)")

#text("Do you disagree?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218417")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Oops! this should have been:")

#text("Hypothesis Beta: There are five blues. If Hypothesis Alpha is false, then Hypothesis Two ")#strong[#text("Beta")]#text(" is true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218418")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("I don’t think that naming the islanders is helpful.")

#text("If exactly 5 (or indeed more than 5) islanders are blues")

#text("* everybody knows that at least 4 are blues (by inspection)")#linebreak()#text(" * everybody knows that everybody knows that at least 3 are blues")#linebreak()#text(" * everybody knows that everybody knows that everybody knows that at least 2 are blues")#linebreak()#text(" * everybody knows that everybody knows that everybody knows that everybody knows that at least one is blue")

#text("but it is NOT true eg that")

#text("*everybody knows that everybody knows that at least 4 are blues.")

#text("Why is this, despite its being true that everybody knows that at least 4 are blues? Because although each blue can directly observe 4 blues, she can directly observe each of those 4 blues observing just 3 blues, not 4. Namely the other 3 blues, but not she herself, since although in fact she is a blue SHE DOES NOT KNOW THIS. Thus although she does know that everybody knows that at least 3 are blues, she does not know that everybody knows that there are at least 4 blues.")

#text("And similarly further down the nesting, until we can see eg that it is NOT true that everybody knows that everybody knows that everybody knows that everybody knows that everybody knows that anyone at all is blue. In fact no blue at all knows this, even though it IS true that everyone knows (because they can directly see) that there are at least 4 blues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218419")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Or in summary: Lenoxus is right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d83c939bbc5aecd3be423515a5696b00668f2d8feb9bd63e32efee1f98ce3aa-f27d559bf6843af50f74a276cc5ea59dd8b460114323d022c46c8530de73b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218456")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("In response to the two posts above:")#linebreak()#text(" Lenoxus, your post is in two parts. Firstly you are stating that it is not possible for the islanders to look at each other. That’s right and that’s why we name the islanders by letters, so we don’t make silly mistakes like that. I never suggested you should have islanders look at themselves, and my refutation of the solution is based on the limits of what is seen, see the table below.")#linebreak()#text(" Switching B with C in the example you gave is another way of looking at the same situation, that is all. A must have thoughts about what B thinks about C as well as what C thinks about B. When I switched the letters around I was showing this, and any islander thinking hypothetically about the islanders is free to do this. They won’t just be locked into one “hypothetical chain” where A imagines what B is thinking about C is thinking about D etc without also seeing that E isn’t just thought about, but also thinks about the others.")#linebreak()#text(" I feel sorry for the “innermost E”. He doesn’t really exist, he can’t see what is right in front of him and the islanders, when thinking about him, and stroking their chins, wonder if the poor soul sees nobody with blue eyes, and all because of the mean things other people are thinking about him.")#linebreak()#text(" But perhaps you are saying that of course he does not exist in this way, he is just a hypothetical being that is a logical consequence of the necessary thoughts others have about him? But my assertion is that a hypothesis which involves an impossibility is no hypothesis at all, nested or otherwise. This way of thinking in a chain of thought processes is really just taking yourself down a road where each person is thought about only by one other, and only thinks about one other, which all know cannot be true.")#linebreak()#text(" Or put another way: at base, what is your justification for extending the hypotheses in this way, when it makes no real sense in the real world? What kind of hypotheses are these? How are you protecting them from reality?")#linebreak()#text(" The second part of your post:")#linebreak()#text(" You put me right on the four blue eyes question, clearly about 5 islanders. But I have argued that the puzzle does not work with 5 blue eyed islanders and this situation there are only four. If I see 4 blue eyed islanders, I still know that there is a minimum known to all of 2 blue eyes and can see that the process will not get started because nobody can be waiting to see what the other does (see table below).")#linebreak()#text(" The difference here is that for one of the blue eyed people I am looking at, they know they are in at most a four person game, and they will wait to see how the others react to the minimum known of one. So it’s only me without blue eyes that is unable to act. Anyone who is looking at four blue-eyed people or more will be in the same position.")

#text("Leopold, this chart may help me to explain. I think your second line of “knows” should have been, “everybody knows that their neighbour knows” or “Everybody knows that someone knows”, or as below, “everybody knows that one other knows”")#linebreak()#text(" A is No. of blue-eyed islanders")#linebreak()#text(" B is No. of blue-eyed islanders known on basis of mutual knowledge")#linebreak()#text(" C is No. of islanders everyone knows one other knows have blue eyes (eg A knows B knows C&D are beps)")#linebreak()#text(" D is Common knowledge – everyone knows everyone knows this number have blue eyes.")#linebreak()#text(" A B C D")#linebreak()#text(" 1 0 0 0")#linebreak()#text(" 2 1 0 0")#linebreak()#text(" 3 2 1 0")#linebreak()#text(" 4 3 2 1")#linebreak()#text(" 5 4 3 2")#linebreak()#text(" 6 5 4 3")

#text("This information “lag” means that it is not until 4 islanders is it common knowledge that there is one blue eyed islander. And given the demands of the puzzle, even if everyone knows everyone knows there is one blue islander, this is not enough to spoil the game. Everyone waits to see if they leave on the first day. So not until 5 islanders does everyone know that everyone knows there are 2 blues – and there is no point waiting to see if someone leaves on the first day. There is no possibility, remote or otherwise, that someone might realise they are the only one – everyone knows nothing will happen after the first day – nothing will happen ever.")#linebreak()#text(" This is why it is easy to believe that the induction argument must work, if you only look at 3 or 4 islanders.")#linebreak()#text(" Clearly with larger numbers the solution as offered with 3 or 4 islanders becomes counter intuitive, and people rely on “nested hypotheses” – which really just means that they believe the induction solution must work forever, no arguments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d83c939bbc5aecd3be423515a5696b00668f2d8feb9bd63e32efee1f98ce3aa-f27d559bf6843af50f74a276cc5ea59dd8b460114323d022c46c8530de73b451.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Graeme")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218459")[#strong[#text("John Graeme")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2013")])]

#text("Correction")#linebreak()#text(" “Firstly you are stating that it is not possible for the islanders to look at each other.” ( I mean themselves)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218483")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2013")])]

#text("First of all, kudos to Lenoxus for answering all these posts and doing a fine job of it!")

#text("I encourage John Graeme and everyone else to read my walk through of an islander in the 4 blues world posted above, dated 4 December 2012: ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-199646")[#text("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-199646")]

#text("In it you will see exactly how an islander constructs a possible world where one islander sees no blue-eyed people. As for the situation where there are 5 blue-eyed islanders, well, for the blue eyed islanders, they have to consider the possible world where there are 4 blue-eyed islanders (since that’s all they can see), so they consider exactly the situation I described. Thus, by induction, you can see how this is extended to any number of blue-eyed islanders.")

#text("The key tripping point in thinking about this puzzle is that the islanders have to consider the possibility of a counter-factual world, because they are lacking the information to be certain of the facts. They are ignorant of their own eye color and no amount of looking at other people will tell them their own eye color. So when they look at other people and wonder what they see, they have to consider all possibilities for their own eye color, even though in reality their own eye color is fixed.")

#text("Another way of at least starting to see the problem is to realize that although everyone knows there are some blue-eyed islanders, no one is sure exactly how many there are. Brown-eyed islanders are sure everyone sees 99 blue-eyed islanders, whereas blue-eyed islanders are only sure everyone sees 98. No one can deduce their own eye-color until there is mutual knowledge of the exact number of blue-eyed islanders (not just some lower bound), because only then would people seeing fewer than the correct number know that their own eyes must be blue.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218464")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2013")])]

#text("JohnGraeme. When you say “This information “lag” means that it is not until 4 islanders is it common knowledge that there is one blue eyed islander” I’m unsure what you mean by ‘common knowledge’.")

#text("If you simply mean knowledge that they all have, then with 4 blues it is already common knowledge that there are at least 3 blues.")

#text("If you mean knowledge which they all have, and which they all know that they all have, and which they all know they all know they all have and so on ad infinitum (this is the logicians’ sense of common knowledge BTW), then there is no common knowledge that there are any blues at all, however many blues there in fact are.")

#text("Do you see why this is so? Appreciating this is quite important to understanding what is going on here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8caa50f6443ee94d1c59cac637c81a9e2e18adc380dbc56ac16f0c0832bf481f-a742a7ec975cf5e5b88cd14ffff85919e8ce3f96f41612f4c18d5ffedfee8586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of leopold")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-3/#comment-218493")[#strong[#text("leopold")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2013")])]

#text("The following might help, if taken slowly….")

#text("If there are exactly 2 blues, everyone knows (because they can see) there is at least 1 blue. But neither of the blues knows that everyone knows there is at least 1 blue, since neither of them can be sure that the other blue can see any others.")

#text("If there are exactly 3 blues, everyone knows (because they can see) there are at least 2 blues. And this time each blue can see that everyone can see at least 1 blue (and each brown can see that everyone can see at least 2) so everyone knows that everyone knows there is at least 1 blue. But none of the blues knows that everyone knows that everyone knows there is at least 1 blue, since none of them can be sure that either of the others can be sure that the other blue(s) can see any others.")

#text("If there are exactly 4 blues, everyone knows (because they can see) there are at least 3 blues. And this time each blue can see that everyone can see at least 2 blues (and each brown can see that everyone can see at least 3). And therefore each blue can see that everyone can see that everyone can see at least 1 blue (and each brown can see that everyone can see that everyone can see at least 2) so everyone knows that everyone knows there is at least 1 blue. But none of the blues knows that everyone knows that everyone knows that everyone knows there is at least 1 blue, since none of them can be sure that any of the others can be sure that any of the others can be sure that the other blue(s) can see any others.")

#text("Similarly for 5,6,etc etc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51666")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Did anybody tell the tribe that there can be only 2 eye colours?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51670")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("A hypothesis:")#linebreak()#text(" The tourist taught them that their island is closer to India, than Sweden.")#linebreak()#text(" And I personally never seen blue-eyed Indian.")#linebreak()#text(" And that changed one subtle assumption.")

#text("Is it right way of thinking?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51671")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("the outcome is like in the answer, but for different reason")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51672")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("like in the answer 2, I meant")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3577e0971731694200697a346bb2e95eae2bc5d3018d4957ce9004dc35ae695-2be40796d4d1cbd65f416835854cb2ed3b96e5086494be0c8f34889842c52e00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lkozma")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51675")[#strong[#text("lkozma")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Solution 2 is correct, Solution 1 is wrong because there is always transfer of information in the stranger’s speech.")

#text("Suppose there was only 1 blue-eyed person:")

#text("[before]: Not everyone knows there exist blue eyed people")#linebreak()#text(" (the blue eyed person doesn’t know it)")#linebreak()#text(" [after]: Everyone knows there exist blue eyed people.")

#text("Suppose there are 2 blue-eyed persons:")

#text("[before]: Everyone knows there are blue eyed persons.")#linebreak()#text(" Not everyone knows that everyone knows that there are blue eyed persons")#linebreak()#text(" (the 2 blue eyed don’t know).")#linebreak()#text(" If Alice and Bob are blue eyed, Alice knows Bob is blue eyed,")#linebreak()#text(" but thinks that Bob thinks nobody has blue eyes.")#linebreak()#text(" [after]: Everyone knows and knows that everyone knows etc.")

#text("Suppose there are 3 blue-eyed persons:")

#text("[before]: Everyone knows there are blue eyed people.")#linebreak()#text(" Everyone knows everyone knows there are blue eyed people.")#linebreak()#text(" Not everyone knows everyone knows everyone knows there are blue eyed people.")#linebreak()#text(" This last statement changes after the speech.")

#text("Similarly for any n:")

#text("[before]: (everyone knows)*(n-1) there are blue eyed people.")#linebreak()#text(" [after]: everyone knows everything.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51677")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("No, not always.")#linebreak()#text(" If I say that your nickname is lkozma, the amount of information transfered is zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3577e0971731694200697a346bb2e95eae2bc5d3018d4957ce9004dc35ae695-2be40796d4d1cbd65f416835854cb2ed3b96e5086494be0c8f34889842c52e00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lkozma")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51676")[#strong[#text("lkozma")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Incidentally, this is why dictatorships don’t allow gatherings of people (or free broadcast media). Everyone knows the regime is bad but not everyone knows that everyone knows etc. When the whole hierarchy collapses, revolutions break out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d90321f1f7d3f5ce0f172fb8381d95cf2ce91975b63598a84d4fc73f7b701-0287d2feeeaab0b35d497434bb793f5c735ccf872111d44a2ab7d25679188831.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Whittaker")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51678")[#strong[#text("Peter Whittaker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("The puzzle can be understood by thinking about it in terms of quantum mechanics and colllapsing wave functions, with the collapse leading to an event. In this case, the wave function describes eye colour, and the event is suicide. Sure, it’s silly, but that’s not important; the event could be self-exile, putting on a t-shirt that announces one’s eye colour, etc.")

#text("Every islander knows the colour of every other islander’s eyes, but not their own. This means that each islander’s “eye colour information wave function” is not yet collapsed.")

#text("In other words, from their own perspective, each islander doesn’t even have an eye colour! They’re not “blue” or “brown” or “green”, or anything else: Each individual’s colour is “?”.")

#text("Every islander has exactly the same knowledge as all the other islanders – they all have the same information. No one acts, because no one has sufficient information to act – they each know their eye colour to be “?”. New information is required to collapse that function, to pin “?” to a specific colour.")

#text("The stranger’s pronouncement is the new information that causes functions to start collapsing. But they don’t collapse right away unless there is only one blue-eyed person on the island.")

#text("If there is 1 person, they know their eye colour to be blue, and so they act on that information.")

#text("If there are 2 or more people, and one has blue eyes, that person immediately knows their own eye colour, and they act.")

#text("If there are 2 or more people, and two have blue eyes, each one continues to know their own colour as “?” until the next day, when the other does not act. This tells each of the two blue-eyed people that the other blue-eyed person knew of a blue-eyed person and didn’t act – in other words, the other blue-eyed person didn’t have enough information to act, because they could not know their own eye colour until the time for the action passed.")

#text("Once the time passes for the “other guy” to act – to kill himself – the observer who has blue eyes and doesn’t know it now knows there is at least one other person with blue eyes, and by looking at everyone else now knows that it must be himself.")

#text("So the next day, they both act.")

#text("With three blue-eyed, it takes two days of non-action observed by someone who sees two blue-eyed people for that person to realize their must be one more person with blue eyes, and that it must be them.")

#text("Just keeping days for each person with blue-eyes.")

#text("The stranger’s words are the trigger that starts wave functions collapsing, but it is only sufficient information in the special case where only one person has blue eyes.")

#text("When more than one person has blue eyes, additional information is required for each blue-eyed person to realize their own eye colour, and that additional information is the continued non-action on the part of all of the other blue-eyed people.")

#text("Once all the blue-eyed people take their collective action, the island returns to the state wherein everyone’s knowledge of their eye colour is “?”. They may all see brown, but they don’t have enough information to make any conclusions about their personal eye colour.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51681")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("No. Incorrect.")#linebreak()#text(" A priori, probability of having blue or brown eyes is 1/2.")#linebreak()#text(" Now imagine we have three islanders, each has blue eyes,")#linebreak()#text(" then would think [even after the tourist mentioned he saw blue eyes in the crowd] “Ah, Ok, yeah I know we have people with blue eyes, but everybody still believes that he or she may have any of the colors, so nobody still really sure about colors, therefore no suicides”.")

#text("But after the tourist speech, probability of having blue eyes is not 1/2 anymore.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d90321f1f7d3f5ce0f172fb8381d95cf2ce91975b63598a84d4fc73f7b701-0287d2feeeaab0b35d497434bb793f5c735ccf872111d44a2ab7d25679188831.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Whittaker")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51682")[#strong[#text("Peter Whittaker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Your a priori probability is wrong. It is a) not a priori at all, but based on a particular known probability distribution, and b) irrelevant and c) irrelevant – it is irrelevant for two reasons.")

#text("It is irrelevant because b) no one takes action on probability on this island, but on certainty – they only act when they know something, and because c) blue and brown aren’t the only possibilities: I could see one person with blue and 999 with brown, and see that person with blue kill themselves tomorrow at noon, and I still would not know that my eyes were green.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d90321f1f7d3f5ce0f172fb8381d95cf2ce91975b63598a84d4fc73f7b701-0287d2feeeaab0b35d497434bb793f5c735ccf872111d44a2ab7d25679188831.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Whittaker")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51684")[#strong[#text("Peter Whittaker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("A more general statement of the puzzle….")

#text("The puzzle can be stated generally as follows:")

#text("There exists a system S in which there are N agents.")

#text("Each agent has a property, P, which has a value, Pv.")

#text("Discussion of P is forbidden. (Call this rule R1 for later reference.)")

#text("If an agent should discover their Pv, they must take an action, A, after time T.")

#text("Each agent can see that there are N values of P, that is, Pv1, Pv2, Pv3… PvN")

#text("Each agent is ignorant of their Pv, and has no reason to believe it is the same as any observed Pv. This means that there may – or may not – be N+1 values of P, that is, the Pv1, Pv2, Pv3… PvN observed values and their own PvN+1, which may or may be the same as one of the Pv1, Pv2, Pv3… PvN observed values.")

#text("Given these conditions, there is insufficient information for any agent to know their Pv, so no agent takes action A. As far as they are each concerned, the value of their property is Pv?")

#text("An outsider arrives, one not bound by rule R1 or one capable of breaking rule R1.")

#text("The outsider announces that they see the value PvX. The outsider does not indicate how many agents have PvX, merely that some do.")

#text("Any agent that cannot see any PvX immediately knows they are the only one with PvX. They are therefore compelled to take action A after time T.")

#text("Any agent A that sees one and only one other agent with PvX expects that other agent to take A after T.")

#text("When T passes and the other agent does not act, the agent expecting A must conclude that they themself also have PvX, because the only thing that would stop the other agent from acting is uncertainty about their own Pv, and they would only be uncertain if they also saw one other with PvX and were expecting that one other to act. Therefore, each must conclude that there are exactly two agents with value PvX, the one they can observe, and themself.")

#text("Therefore, after a second time T, they both take A.")

#text("Add another agent with PvX, and repeat with three agents with PvX: After the first time T, each agent with PvX expects nothing, because they can observe two agents with PvX and they know neither has enough information to act. After a second time T, each agent with PvX expects the other two to act, but they do not, which means there must be one more agent with PvX, one that each agent cannot observe – themself.")

#text("Therefore, after a third time T, all three take A.")

#text("Add another agent with PvX, and repeat….")

#text("The reason for dramatic action A (suicide, self-exile), etc., is simply to restore the system S to its initial state: the agents who know their Pv must be removed from the system to return all agents to the original level of ignorance, of uncertainty.")

#text("Once all agents with PvX are removed, the original description of S, above, applies with N reduced by 1. The exact number of agents in S, the exact number of agents removed by A after the outsider’s disturbance, and the exact value of N are all irrelevant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb72b85607f611d2ef92e260c335158d90c3910dff9f659671b291f1464f0b4-33705d7f4391899fa93043effc9f25941e004d244e7504e359ef6146d733a473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UK")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51912")[#strong[#text("UK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2011")])]

#text("Thanks! I couldnt figure out the solution for quite some time because I couldnt formulate the problem rigorously in my mind. But your reformulation helped me see the solution clearly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6e5381d9183bfb4a8b1c9a355872bab57ce3ed4149e93614b267d70e42d6988-27812e2a1ee6d67b88f0479b9d56d15a5207d4731e3a396510664aafa328e762.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JPP")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51693")[#strong[#text("JPP")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("(Sorry if I’m making a dumb comment or saying something someone already said).")

#text("This problem reminds me something I read as a child:")#linebreak()#text(" “James Bond is captured. On Sunday, his gaolers tell him that he will be put to death a morning at dawn. The precise day will no be revealed in advance so that the visit of the executioner will be a complete surprise for him. But in any case, he’ll be dead on the next Sunday at dusk.” The paradox is now the following: Commander Bond can think “If I’m still alive on Saturday (after dawn), I’m doomed to be killed the next day. But this wouldn’t come as a surprise so this hypothesis is absurd and they can’t kill me on Sunday. So if I’m alive on Friday, I’ll be killed on Saturday, but this wouldn’t come as a surprise and so on.” By this brilliant induction, our glorious spy safely concludes that the gaolers can’t logically kill him and he will escape this pickle, as usual. The visit of the executioner on Wednesday then comes as a complete (and rather unpleasant) surprise. How to solve this paradox?")

#text("I have an odd feeling that this problem and the blue-eyed islander one are kind of related. Am I wrong? What can you say about Bond’s one?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d90321f1f7d3f5ce0f172fb8381d95cf2ce91975b63598a84d4fc73f7b701-0287d2feeeaab0b35d497434bb793f5c735ccf872111d44a2ab7d25679188831.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Whittaker")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51698")[#strong[#text("Peter Whittaker")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Is the problem with the Bond puzzle the layering of hypotheticals? IF I’m alive on Friday, I won’t be killed Saturday, and IF I’m alive….")

#text("But IF he is killed Monday, then the whole thing falls apart. I don’t see a contradiction, I just see a conclusion reached on shaky conjecture.")

#text("The blue eyed problem is framed in such a way (very strict rules known and followed by all) that there is no conjecture, no probability, just fact, solid information, the others did not commit the act, therefore… and conclusions drawn from that information.")

#text("Think of it another way: Bond is reasoning based on potential future events and what those might mean. The islanders are based on past events and what those must mean, given that the rules are always followed. The past events are the stranger’s announcement and the fact that each morning an unexpected number of people have not committed the act.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51721")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Ah, yes, the ")#link("http://en.wikipedia.org/wiki/Unexpected_hanging_paradox")[#text("unexpected hanging paradox")]#text(". There are some similarities between the two puzzles, in that one has to work with chains of higher-order knowledge statements (Bond-on-Monday knows that if he is not killed on Monday, then Bond-on-Tuesday knows that …), though now the deductive chain is working backwards in time rather than forwards.")

#text("To me, though, the resolution of the unexpected hanging paradox is the fact that once there are two or more days involved, there is an implicit assumption that Bond knows the consistency of his own knowledge (or more precisely, of the consistency of his future knowledge). For instance, suppose that the execution is either at Monday-dawn or Tuesday-dawn, and consider the state of Bond’s knowledge at Sunday-dusk (just before Monday-dawn) and Monday-dusk (between Monday-dawn and Tuesday-dawn). Let me abbreviate these states of knowledge as Bond-Sunday and Bond-Monday respectively.")

#text("Bond-Sunday knows that if there is no execution at Monday-dawn, then Bond-Monday will know the following facts:")

#text("1. There was no execution at Monday-dawn.")#linebreak()#text(" 2. Bond-Monday knows that there was no execution at Monday-dawn.")#linebreak()#text(" 3. The execution is either at Monday-dawn or Tuesday-dawn.")#linebreak()#text(" 4. Bond-Monday knows that the execution is either at Monday-dawn or Tuesday-dawn.")#linebreak()#text(" 5. On the date of the execution, Bond will be completely surprised by the event.")

#text("These five facts are inconsistent with each other, and hence Bond-Monday’s knowledge would be inconsistent. However, in order for Bond-Sunday to then deduce (via ")#emph[#text("reductio ad absurdum")]#text(") that there is an execution at Monday-dawn, he must first know that Bond-Monday’s knowledge is consistent. But this itself will lead to an inconsistency in Bond-Sunday’s knowledge, by similar arguments to above (and so forth back in time, if we consider more than two days).")

#text("So we see that the unexpected hanging paradox is in fact closely related to ")#link("http://en.wikipedia.org/wiki/Godel%27s_incompleteness_theorem#Second_incompleteness_theorem")[#text("Godel’s second incompleteness theorem")]#text(", which roughly speaking prevents any reasonable and consistent formal system from knowing its own consistency. This connection is discussed in detail in ")#link("http://www.ams.org/notices/201011/rtx101101454p.pdf")[#text("this recent Notices article of Kritchman and Raz")]#text(".")

#text("Note that the blue-eyed islander puzzle is unaffected by this issue, because at no point does any islander need to know that any other islander’s knowledge is consistent (or any iteration thereof). Instead, they need to know that the other islander’s knowledge is ")#emph[#text("logical")]#text(" (i.e. closed under the rules of deductive logic), which is a different property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51722")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("But does your post mean that solution is already given?")#linebreak()#text(" I am still dissatisfied with it then, I see it relies on the intention of tribespeople to know about their eye-color. It is unclear, if when they are given an opportunity to figure out their own eye-color they want it to be pursued.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51883")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("“Note that the blue-eyed islander puzzle is unaffected by this issue, because at no point does any islander need to know that any other islander’s knowledge is consistent (or any iteration thereof).”")

#text("So, just to see if I got this: we, the puzzle solvers, may assume that the people in the puzzle are consistent to come to our solution, but the people in the puzzle itself cannot make such an assumption.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51884")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("Or to put it another way:")

#text("Suppose that in the puzzle there are exactly two eye-colors: blue and brown, and all the islanders know this fact (and know the others know this fact, etc…)")

#text("When all the blue-eyed islanders kill themselves, does it necessarily follow that the brown-eyed islanders must kill themselves the next day? For if they do not have to assume that their fellow islanders have consistent knowledge, then could they not conclude that it is possible that those blue-eyed islanders killed themselves early because of their inconsistent knowledge?")

#text("(Note: I’m also not sure that knowledge acts like an axiomatic system in all the relevant ways to speak of formal consistency…)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aca66e0364126a6fd82f1adddcdebade2d87f77f1bd420a6dd34171dc4cf4b07-acefbb9aba827c6bfeee02a932475f03b55dfa47e17627b9aaae79fee0e9fa1c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexey-Voropaev")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52251")[#strong[#text("Alexey-Voropaev")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2011")])]

#text("Would you please answer also:")#linebreak()#text(" Is this issue related somehow with Theorem of Poincaré about three bodies?")#linebreak()#text(" Sorry for my English : (")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51705")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Answer 1 is right.")#linebreak()#text(" [it is wrong only in degenerate cases of 1 2 or 3 people]")#linebreak()#text(" The religion prevents them from discussing the topic.")#linebreak()#text(" Cases with than 4(?) or so people require implicit communication through observing the events of suicide. But as it is mentioned above any communication is prohibited,and the lack of suicide has no disambiguative power.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51797")[#strong[#text("Big Red Bits » Reasoning about Knowledge")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2011")]

#text("[…] to Petra in Jordan together with Vasilis Syrgkanis and in the road we kept discussing about the Blue-Eyed Islanders Puzzle, posted by Terry Tao on his blog. It is a nice puzzle because it allows us to reflect on how to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of moonshadow")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51802")[#strong[#text("moonshadow")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2011")])]

#text("One free thinker in the bunch would realize that there is money to be made in starting a new religion. He would renounce the existing religion based on a revelation from “God”. He, or more likely She, would have “visions” to guide the people to a realization that they should not only know their eye color but embrase it. For a nominal fee they would meet each week and hear the Prophet speak. They would go out to their friends and share the good news that they did not have to die. They could know the color of their own eyes and live!!! PRAISE THE PROPHET!!!!!!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fab902e4d97ea9450319014d0f9406bef86e32d05083ab288955970c3d7c7430-e6270d0664b30d00782b08dd65c92c0430e06a33f496d738b3375bc5ececeeef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51826")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2011")])]

#text("I keep seeing comments, here, on xkcd, on the wikipedia page, that say “imagine if there was x islanders” but there’s not, there are 1000, and it is common knowledge that there are 1000, and comments like, “imagine there are 2 (or 3 or 4) blue eyed people, but all the islanders KNOW there are NOT 2 or 3 or 4, they all KNOW that there are EITHER 99 OR 100 OR 101 (That is every one of them sees either 900 or 899 brown eyed people and 99 or 100 blue eyed people, and each knows that they may have blue eyes). I cannot understand how they begin their induction before day 99, as they all know that no one is going to commit suicide on day 1 or 2 or 3 etc because there is no way to infer their own eye color on any of those days. on day 99, there is no preceding case, is has NOT been demonstrated that there is NOT 98 blue eyed people on the island by the lack of suicides, that fact was already established, and KNOWN TO ALL.")

#text("smart people seem to believe that induction is possible and that solution 2 is correct, but I have not seen any explanation that isn’t manifestly “hand-waving”. Is anyone aware of a PEDAGOGICALLY SOUND explanation of this puzzle?")

#text("Also the common knowledge page on Wikipedia pulls the same trick with the knowledge that the foreigner adds; they say “imagine the number of tribesmen is n” BUT ITS NOT! its 1000! does anyone know of a PEDAGOGICALLY SOUND that is without hand-waving or appeal to “multi-modal logic” that can explain why induction should be possible in a case where is is already KNOWN that there are more than 50 people on the island who have blue eyes?")

#text("I am deeply suspicious of people who assert wildly unintuitive things about seemingly simple scenarios and then to prove them have to resort to talking about theoretical frameworks only a tiny percentage of the worlds population could possibly be familiar with.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b6d2738fd95964ee6b7a2680189a74a84e3f3e00783cae535ff20449c86247-d8819d6ae4cc57e98dcda46a23e92676a4d19e789232fb522264504569d8c7ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tollens")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51861")[#strong[#text("Tollens")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2011")])]

#text("“on day 99, there is no preceding case, is has NOT been demonstrated that there is NOT 98 blue eyed people on the island by the lack of suicides, that fact was already established, and KNOWN TO ALL.”")

#text("Here is the last step in the induction: If no one commits suicide on day 99 then there were could not have been 99 blue eyed people (this was not known beforehand). Hence there must be 100 blue eyed people and on day 100 all the blue eyed people commit suicide.")

#text("I suggest reading Lkozma’s comment which makes the solution much more intuitive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51862")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2011")])]

#text("I am impressed by the longevity of the enthusiasm on this puzzle. I guess I should check back once a while for new interesting comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cd5da446610563df0d0aa6ad067e2d69246e3a820b68568e51a5e917f7a468c-6d7fc3419117763d6ee62863464362cfe836d48c068fc65696f3e3bacd135b50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of megatron")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51882")[#strong[#text("megatron")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("Hi,")#linebreak()#text(" From an engineering point of view (EE or CS), let’s imagine the island/w the islanders is the system under test. The foreign visitor is the external excitation signal.")

#text("Say the purpose is to input a signal (foreigner’s action) to kill every blue eyed islander.")

#text("solution 1: the foreigner can point to each blue eyed islander and tell him/her that he/she is blue-eyed")

#text("solution 2: the foreigner can count and say that there are 100 blue-eyed islanders")

#text("In addition, if the input signal is deceiving, for example, the foreigner says that there are 99 blue-eyed islander. the blue eyed islander will count 99. and the brown eyed count 100 and knows that it’s a false claim. so nobody dies.")

#text("But what if the foreigner says 101 blue eyed. then blue eyed won’t die. but all brown eyed will die next day, thinking that they are blue-eyed.")

#text("To kill 100 blue-eyed islander, all these takes precise counting, which it’s computationally expensive.")

#text("what is amazing for me is that for such a system, there exists simple “algorithms” to achieve the goal:")

#text("1. foreigner just say: “how unusual it is to see another blue-eyed person …”")

#text("or")

#text("2. (deceiving information) foreigner just say: it’s amazing to see a red-eyed person (which kills every islander)")

#text("Can some theorists generalize this phenomena?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3f88c180e169b2801797a45bbb217e8242fe80caf0af271e0098007507ac86c-8a0efae7c01aef2c4105f41b3a4008845af4c28418de9d5412d21c766057623a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Varjabedian")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51900")[#strong[#text("Varjabedian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("Dear prof. Tao,")

#text("The foreigner gives a starting day to apply solution 2, for me that’s the information missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dd5c3eed86b3bda6ea8a76239e23d10baebfe05bc5228f74c067cf664f8d232-96f7bc2b11c1ef986d3fae2327b48cbc887f68d7d694d4284b25c0b4cf89feb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AnusInFabula")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-51952")[#strong[#text("AnusInFabula")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2011")])]

#text("I think there is two possible way:")

#text("1)")

#text("If every islander knows the statistics he can count the number of islander which")#linebreak()#text(" have blue and brown eyes and than understand wich one is his own eye colour and suicide him.")#linebreak()#text(" The tribe could not exists.")

#text("2)")

#text("If every islander doesn’t know the statistics the foreigner’s assertion does not influence in any way the life of islanders cause we have this logic-scheme:")

#text("A islander’s reality: there are over 800 people blue-eyed in this place")#linebreak()#text(" B foreigner’s assertion: there are some person blue-eyed in this place")

#text("Deduce with assumption A,B that my eye colour is X has not logical reasons, cause A is equivalent B.")

#text("If someone commits suicide for this is the same case if i know that (Exists x€R such that x=1) come somebody and tell me (Exists x€R such that x=1) i deduce y=1.")#linebreak()#text(" There’s no way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4fb9d17b1a472ac220daddd61607ab9129e30cbddde0b42bf2b1dd9bd968167-5e879dc9957f9985d42bd0655cc68031c05f7f24c10c7b94c49afe8bfde0ad43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ajay Ravi")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52001")[#strong[#text("Ajay Ravi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2011")])]

#text("Here’s the proof similar to solution 2 which clearly shows that traveller announcing the presence of blue-eyed person provides new information that forces all n blue-eyed people to commit suicide.")#linebreak()#text(" The proof is structured into numbered propositions, with proposition N=n providing the proof for n blue-eyed people:")

#text("Proposition 1: if n=1 AND traveller announced there is a blue-eyed person, then the blue eyed person commites suidicde after 1 day")#linebreak()#text(" Proof: the blue-eyed person realises he is the only one with blue eyes and commites suicide the next day.")

#text("Proposition 2: if n=2 AND traveller announced there is a blue-eyed person then the blue eyed people commit suidicde after 2 days.")#linebreak()#text(" Proof:")#linebreak()#text(" All blue-eyed persons reason in this way:")#linebreak()#text(" if I am not blue-eyed then there is 1 blue-eyed person on the island, and since traveller announced there is a blue-eyed person, the lone blue-eyed person will apply Proposition 1 to commit suicide after 1 day.")#linebreak()#text(" Therefore if there is no suicide after 1 day, I must also be blue and I will have to commit suicide after 2 days.")

#text("Proposition 3: if n=3 AND traveller announced there is a blue-eyed person then the blue eyed people commit suicide after 3 days.")#linebreak()#text(" proof:")#linebreak()#text(" All blue-eyed persons reason in this way:")#linebreak()#text(" if I am not blue-eyed then there are 2 blue-eyed people on the island, and since traveller announced there is a blue-eyed person, the 2 blue-eyed people will apply Proposition 2 to commit suicide after 2 days.")#linebreak()#text(" Therefore if there are no suicides after 2 days, I must also be blue and I will have to commit suicide after 3 days")#linebreak()#text(" …")

#text("proposition N: if n=N AND traveller announced there is a blue-eyed person then the blue eyed people commit suicide after N days.")#linebreak()#text(" proof:")#linebreak()#text(" All blue-eyed persons reason in this way:")#linebreak()#text(" if I am not blue-eyed then there are N-1 blue-eyed people on the island, and since traveller announced there is a blue-eyed person, the N-1 blue-eyed people will apply proposition N-1 to commit suicide after N-1 days.")#linebreak()#text(" Therefore if there are no suicides after N-1 days, I must also be blue and I will have to commit suicide after N days")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88f707bd6ac440604bc24cd1297f3629e7320c30dc455ee789eb50b542f07e82-38f275a8eed6c78af8c5dfb99fa299c19105f6587f9542d39d8d698fa53a2453.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ETzortzakis")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52068")[#strong[#text("ETzortzakis")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2011")])]

#text("Solution 1 is wrong!")#linebreak()#text(" proof:if there are n blue eyed persons(BEPs) A_1,A_2,…,A_n")#linebreak()#text(" -for n=1 it’s obvious that traveler’s statement adds new info.Then starts what we call 1-sub game,which is A_1 realizing his own eye color and committing suicide on the same day.")#linebreak()#text(" -for n=2 then traveler’s statement again adds new info,")#linebreak()#text(" indeed A_1 knows that there is at least one BEP but he doesn’t know that A_2 has this knowledge.But now(after foreigner’s remark),he knows that A_2 also knows this.So now A_1 is thinking that if his own eye color is brown then A_2 plays the 1-sub game which will conclude with A_2 committing suicide on the 1st day.So if on the 2nd day A_2 is alive then no 1-sub game ever happen so he realizes that his own eye color is blue and thus commits suicide on the 2nd day.Symmetrically A_2 does the same.")#linebreak()#text(" -n=3 A_1 knows that there is at least one BEP.")#linebreak()#text(" A_1 knows that A_2 and A_3 know that there is at least one BEP.")#linebreak()#text(" BUT A_1 doesn’t know if A_2 knows that A_3 is aware of the fact that there is at least one BEP!")#linebreak()#text(" We can see clearly now where Solution 1 fails,the comment gives the tribe meta-knowledge(or meta-meta-knowledge) aka knowledge on others knowledge.So A_1 is thinking if i have brown eyes then the other 2 with their new knowledge play a 2-sub game so they will commit suicide on the 2nd day,else i am BEP and we all commit suicide on the 3rd day.")#linebreak()#text(" The rest of the induction is clear from n=3,")#linebreak()#text(" this faux pas gives A_1 the knowledge that A_2 has the knowledge that…that A_n-1 has the knowledge that A_n has the knowledge that there is at least one BEP in the tribe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/267489cb4da45f92f73b95a4bbefa224e2cb3665b67fb007e55db49351cc1a97-4d82c6a38b96b6117c0d1c8722f0364cbde3143ac5408f6c849e8d6a29ea3794.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dale")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52114")[#strong[#text("Dale")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2011")])]

#text("Most blue-eyed people will not know how many blue-eyed people are on the island. (Do you know how many blue-eyed people live in your neighborhood?) Being highly logical, when they recognize the iteration, they will have ggod reason not to know the number. Some will committ suicide on the 100th day (they had counted), but everyone else (brown or blue eyed) will continue to not count the number of blue-eyed people.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-199929")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("This answer makes sense, except that if all the islanders are aware of the possibility of other islanders not counting, then no one will ever commit suicide.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/267489cb4da45f92f73b95a4bbefa224e2cb3665b67fb007e55db49351cc1a97-4d82c6a38b96b6117c0d1c8722f0364cbde3143ac5408f6c849e8d6a29ea3794.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dale")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52116")[#strong[#text("Dale")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2011")])]

#text("Actually, we could call this the “Sargent Schulz” solution (for fans of Hogan’s Heroes)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd10ef67d3a7fddfecb35755840f17f23e2a845ca446a3cc018aedace42cc1f4-17408624abbde0788dea5e97339ed55959747760dd4bad46d8d65cfb768e6712.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G. Siamantas")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52119")[#strong[#text("G. Siamantas")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2011")])]

#text("The first solution seems to be the correct one.")

#text("The second solution requires that at least one of the n-1 blue eyed islanders know his/her eye color, that it is not true.")

#text("This easily demonstrated when n=2.")#linebreak()#text(" Both blue eyed residents don’t know their eye color, their decisions are mutually exclusive.")

#text("After the first day they will both wait indefinetely because they both know that they don’t know their eye colors.")

#text("If one of them knew that the other knows his eye color only then he would commit suicide the other day.")

#text("The only guy that will be probably forced to commit suicide will be the traveller because he talks too much…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ad69a81f2e7e9eed6fb883d7474198af76ddf246340ee56751f6029b3551f84-44d4328ba31f9bb923df37174e6201ed38b8737fca894e43d1e257efc2c2b64b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of al")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52134")[#strong[#text("al")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2011")])]

#text("I was struggling with why the foreigner triggers everything, until I read the Wikipedia article on common knowledge and the light dawned.")

#text("As far as any single islander knows, all the other islanders are blind (or otherwise ignorant of the eye colours of other people).")

#text("On the day the foreigner makes his speech, each islander discovers that every islander knows that at least one islander has blue eyes. After the first non-suicide day, each islander discovers that every other islander knows that at least two islanders have blue eyes and so on and so on.")

#text("Without this knowledge of what the other islanders know, then each islander cannot assume that all the blue-eyed islanders would kill themselves on the right day.")

#text("PS Many of Nicole Krieger’s comments are amusing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd10ef67d3a7fddfecb35755840f17f23e2a845ca446a3cc018aedace42cc1f4-17408624abbde0788dea5e97339ed55959747760dd4bad46d8d65cfb768e6712.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G. Siamantas")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52267")[#strong[#text("G. Siamantas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("In this variant of the muddy children puzzle the information provided by the traveller does not add any more information to the knowledge that every blue eyed tribesman has. They all already know that there are 99 other blue eyed islanders. The solution to THIS puzzle is proposition 1.")

#text("The only way that the words of the traveller can trigger a sequence of suicides in the islander community is if they have in mind the solution of other versions of this puzzle, as most people does in these comments.")

#text("In order for proposition 2 to be true there should be added in the description of the puzzle the element of synchronicity in the islander’s thoughts, i.e. all the islanders reason in complete synchronization. This is NOT stated in the given puzzle description. This is usually given in the descriptions of other variants of the puzzle.")

#text("A general comment on all variants of the puzzle: in order for the solution to be the suicide of all islanders or for all children to say that they have mud in their foreheads etc. All islanders, children etc must think inductively on n (in mathematical terms) and this is normally not the case in normal people’s thinking.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ad69a81f2e7e9eed6fb883d7474198af76ddf246340ee56751f6029b3551f84-44d4328ba31f9bb923df37174e6201ed38b8737fca894e43d1e257efc2c2b64b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of al")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52280")[#strong[#text("al")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("I would say this is covered by “all the islanders are highly logical” and Note 1 and Note 2.")

#text("There are millions of possible caveats you could exploit to avoid conclusion 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d663b4008f7e16c11d39dfed7ccd0b6e6394ae9fd3588060f97a18e39d1cc55-36c240a2172ca4624e1b0d091ca9080093d665b2ac27afbde942946da190bbf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hugo")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-54727")[#strong[#text("hugo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2011")])]

#text("The foreigner does not act as a trigger, we just assume he will cause the same thinking in all the tribepeople, wich is to count. And they all assume in their world they will all do it.")

#text("So thats the fact they “know” everybody will start to think that makes each one of them to star worring about themselves.")

#text("Im sorry for my bad english, im portuguese")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80af0bf62acbccdf91276dfcbd20547ba8f50e01874ed6b36f43e39be21fcd0f-5a0d7784733b186ba2c2f8572d242f704196ef3bbb6386f3738e0bad90ccc3e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jqanderson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52307")[#strong[#text("jqanderson")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2011")])]

#text("Has anyone mentioned that this is game theory 101? The answer hinges on the concept of common knowledge, and there are a number of ways to formalize it. Ask your econ professor or consult any graduate-level game theory handbook for precise statements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9bd5109b46e768c06024be4c8c45bd091cfee47b24d18f03c8f4c33210c5006-c9e5c4c05ac7ded601fc411783c09c85b4653992c8797cbf988ebc9cce2f3f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phanindra")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52364")[#strong[#text("Phanindra")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2011")])]

#text("I think this puzzle can be solved if one understands the “depth” of knowledge. Here is my go at a solution:")

#text("Let 1) “k” denote the string “knows that”")#linebreak()#text(" 2) “e” denote the string “there is a blue eyed person in the tribe”")#linebreak()#text(" to avoid writing the phrases repeatedly.")

#text("I looked at a much simpler case to start off with. Assume that there are only three people in the tribe all of them blue")#linebreak()#text(" eyed. Name them a,b,c.")

#text("At the beginning of time (in this problem) one can say that the following are true:")

#text("1) d k e")#linebreak()#text(" 2) d k (f k e)")

#text("where d belongs to {a,b,c} and f belongs to {a,b,c}. However, at the next level of “depth”, the following statements are")#linebreak()#text(" false:")

#text("1) d k (f k (g k e))")

#text("where d belongs to {a,b,c}, f belongs to {a,b,c} and g belongs to {a,b,c}.")

#text("Note that if any of the above false statements become true somehow (here, with the passage of time and observing whether")#linebreak()#text(" people are comitting suicides or not) then it could be shown that d knows his/her eye colour (where d belongs to {a,b,c}).")

#text("The words of the traveller make these statements true at the beginning of day three. Even though at the first day his words")#linebreak()#text(" do not help the tribe at all, they become handy after sometime. Unfortunately, at the height of their knowledge, they choose")#linebreak()#text(" to kill themsevles !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9bd5109b46e768c06024be4c8c45bd091cfee47b24d18f03c8f4c33210c5006-c9e5c4c05ac7ded601fc411783c09c85b4653992c8797cbf988ebc9cce2f3f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phanindra")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52366")[#strong[#text("Phanindra")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2011")])]

#text("A minor mistake in the above: for the false statements, d != f != g. Some of the rest are trivial and the others are not that important.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d65b07fd556fd42fccebf149978bb3d669189acf7d63498909277ce648c343f7-4e6860c9543b1b54834be8223e7bb10b4a21e482c3b2ca3a11e06fd8822b25ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FV")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52492")[#strong[#text("FV")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2011")])]

#text("1. If everybody knew that there are only two colors they would know immediately about Solution 2, i.e. that eventually they would know their eye colors, so they could commit suicide immediately if they felt like it.")

#text("2. Nicole Krieger mentioned a possibility of evil foreigner with grey eyes. Another possibility is of an islander too scared to commit suicide, in which case the following day everybody would have to commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d65b07fd556fd42fccebf149978bb3d669189acf7d63498909277ce648c343f7-4e6860c9543b1b54834be8223e7bb10b4a21e482c3b2ca3a11e06fd8822b25ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FV")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52494")[#strong[#text("FV")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2011")])]

#text("3. Of course, as someone mentioned above, if they knew that there are “exactly two colors” then by the same Solution 2 they would all commit suicide even without the foreigner.")

#text("However, what if they all knew that there are “at most two colors”? Then the first induction step would not work since the only blue eyed person would not have killed himself since he could assume that he also has brown eyes. However, in the case of “at most two colors” and 100/900 breakdown they know immediately that there are “exactly two colors”. Isn’t that paradoxical?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d65b07fd556fd42fccebf149978bb3d669189acf7d63498909277ce648c343f7-4e6860c9543b1b54834be8223e7bb10b4a21e482c3b2ca3a11e06fd8822b25ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FV")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52498")[#strong[#text("FV")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2011")])]

#text("Oh, I see! Announcing whether there are “at most two colors” or “exactly two colors” reveals different “common” information, even though to each individual it is exactly the same! Nice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94ee65534a56c14b8d8f30ceffdb33d3883da8fbbc25f477913275ad9ea92aca-200a37f1454515b0fda3dd897773182a2eed3cf618f6ab46306eda34eba4e90c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SJO")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52502")[#strong[#text("SJO")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2011")])]

#text("Actually, all the islanders will completely know the statistics of the population. In a large population of 1000 people, excluding themselves, everyone can compute a distribution based on their observations, and those distributions would be identical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/662ea35793551f759aa14e5cae6a9c875b291a6608ea9ce64645fa8460944787-6af895346d1d680f1e1753c7612ebc5a387f79a47ea4f3c49720ce86a6a35a53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tad Boniecki")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52605")[#strong[#text("Tad Boniecki")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2011")])]

#text("Please put me out of my agony! I have read through the blue eyes puzzle a few times, as well as the answers on the Net. It doesn’t make sense to me. The solutions start with the case where there is one blue-eyed islander, who then leaves on hearing the blue eyes statement. They then move on to the case of two blue-eyed islanders hearing the same statement.")

#text("The problem is that the announcement that there is an islander with blue eyes is made *only once*, so it cannot be used in 100 separate cases. Sure, if there were only one blue-eyed islander then he would leave on hearing the statement, but we start with 100 blue-eyed islanders, not one. I think the inductive logic fails because it assumes that the statement about someone having blue eyes is made every day.")

#text("Come to think of it, even if the statement about blue eyes were to be made every day, that still would not help. The solution is only valid if we can get from the case of 100 to 99 blue-eyed islanders.")

#text("Let’s strip the puzzle back to essentials. Suppose the scenario is that there are only two islanders, both with blue eyes, and that the outside person says, “I see someone with eyes.” Can we get from two islanders to one in this simplest version of the puzzle? I think not, because the statement about there being a blue-eyed person is never made to just one islander. Because it is never said to just one islander, we cannot work back to this case from the case where there are two islanders.")

#text("Another problem is that the announcement of there being a blue-eyed islander does not tell anyone anything. Every one of the islanders can already see a blue-eyed islander, so apart from saying it out loud, the statement can have no effect, as no information is being given. If each islander thought this thought, rather than hearing it said out loud, then it would have the same effect. If the inductive proof were valid then all the islanders would have left 100 days after arriving at the island, whether or not anyone made the statement out loud.")

#text("In conclusion, the statement, “There is a blue-eyed person” can *only *have an effect if there is just one blue-eyed person to hear it. This never happens, as the statement is only made once to the initial group of 100. So, theorem one is false because the case of one person hearing the statement never happens.")

#text("Thanks")

#text("Tad")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52634")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2011")])]

#text("The key point here is that the “real” world in the puzzle – i.e. the world of what actually ")#strong[#text("is")]#text(" true in the puzzle (i.e. the world in which there are 100 blue-eyed islanders) – is not the only world that one has to analyse; various “purely hypothetical” worlds, in which there are other numbers of blue-eyed islanders, also influence the behaviour of the islanders. The reason for this is that while ")#strong[#text("you")]#text(" know that such worlds are purely hypothetical, the ")#strong[#text("islanders")]#text(" do not, and so must also take those worlds into consideration. (More subtly, there are worlds which each islander knows are purely hypothetical, but they do not know that the ")#strong[#text("other")]#text(" islanders know to be hypothetical – such as the world in which there are only 98 blue-eyed islanders instead of 100. Somewhat surprisingly, these worlds need to be taken into consideration also. And so forth.)")

#text("A familiar everyday example of this phenomenon (at least at the first-order level) comes from the game of poker. A player may, in reality, hold a lousy hand, but may be able to successfully bluff other players into thinking that he or she in fact holds a very high-ranking hand. The hypothetical world in which this player holds a good hand is not the real world, ")#emph[#text("but the other players do not know that fact")]#text(" – and as a consequence, this bluff can significantly alter their behaviour. Higher order versions of this phenomenon can occur when a bluffing player has to try to gauge if another player has “bought” his or her bluff and has a genuinely strong hand, or does not believe the bluff and is counterbluffing. Only one of these alternatives can be the truth, but the mere ")#emph[#text("possibility")]#text(" of the other alternative can still cause a real change in the player’s behaviour.")

#text("In a similar way, in an island in which there are two blue-eyed islanders, the hypothetical world in which there is only one blue-eyed islander is a possible world to each of the two blue-eyed islanders, and can only be ruled out one day after the foreigner speaks.")

#text("In an island in which there are three blue-eyed islanders, the hypothetical world in which there is only two blue-eyed islanders is a possible world to each of the three blue-eyed islanders, and can only be ruled out two days after the foreigner speaks. And so forth.")

#text("The only hypothetical worlds which can be completely eliminated from one’s analysis are those worlds that are ")#link("http://en.wikipedia.org/wiki/Common_knowledge")[#text("commonly known")]#text(" to not be possible. In particular, once the foreigner speaks in full view of all the islanders, it becomes common knowledge that there is at least one blue-eyed islander, and so the world in which there are no blue-eyed islanders can be ruled out completely from that point onwards.")

#text("To understand the puzzle properly, one has to “get inside the head” of an islander, and see things from the islander’s point of view, taking into account that the islander may not know everything that you, as an external observer, know. (In particular, hypothetical worlds which you know to be impossible, can become possible once one adopts an islander’s perspective.) Furthermore, one has to iterate this process, getting inside the head of an islander as he or she in turn gets inside the head of another islander, and so forth. (In fact, this process has to be iterated 100 times in order to fully resolve this particular puzzle!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-143070")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("The hypothetical worlds part is where it seems the logical argument parts ways with the real world.")

#text("It has to be known to these logical people that whatever the real number of blue-eyed people is (let’s call it N), blue-eyed people see N-1 blue-eyed people and the rest see N blue-eyed people. So it is Common Knowledge that everyone has first-hand evidence of at least N-1 blue-eyed people.")

#text("That this is Common Knowledge follows as a consequence of the GIVEN that all the islanders are completely logical AND THAT THAT IS COMMON KNOWLEDGE, that they can all see everyone else’s eye color, and are ignorant only of their own eye color.")

#text("So every tribe member can be absolutely sure that whatever number n of blue-eyed people they see, no other tribe member could possibly conclude there are fewer than n-1 blue-eyed people, and this, too, would be Common Knowledge. Furthermore, since n >= N-1, no other tribe member could possibly conclude any other tribe member concludes there are less than N-2 blue-eyed people.")

#text("Stated differently, ever tribe member is certain that their first-hand evidence of n blue-eyed people requires the world to be such that N >= n, and everyone else has first hand evidence of at least n-1 blue-eyed people and N-1 blue-eyed people. Thus even though I may conclude that another islander thinks there is one fewer blue-eyed person than I do, I cannot transitively think that that islander thinks that another islander would think there could be even one fewer. This is because I know the world is such that if I am seeing N-1 blue-eyed people, I have blue eyes and no one else is seeing fewer blue-eyed people and alternatively, if I am seeing all N blue-eyed people, I do not have blue eyes so no other person would not suspect I see fewer blue-eyed people than they do.")

#text("So it must be Common Knowledge that there are at least N-2 blue-eyed people. That is, it is Common Knowledge that every islander will, from first-hand observation and reasoning, conclude the lower bound of every other islanders estimate is >= N-2.")

#text("The key here is that it is Common Knowledge that any islander would have first-hand knowledge of at least N-1 people with blue-eyes. (Or perhaps the key is that the blue-eyed islanders are interchangeable.) In a hypothetical world with 3 blue-eyed islanders, there is no hypothetical world with no blue-eyed islanders. All the blue eyed islanders see 2 other blue-eyed islanders and cannot imagine a world where a blue-eyed islander does not see a blue-eyed islander (and of course all the rest see 3 blue-eyed islanders), so it is not a possibility for any islander to conclude there are no blue-eyed islanders.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-143072")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2012")])]

#text("Of course, knowing that there are at least n-1 or N-2 blue-eyed people doesn’t tell me whether or not I have blue eyes. I will only know I have blue eyes when I know N > n. I will only know that when I know the n blue-eyed people I see also think that N > n. So what the foreigner does is start the clock ticking. Today we know n > 0. Tomorrow, when nobody does anything, we know n > 1, and the next day we know n > 2, and so on. In our world with 100 blue-eyed islanders, everyone knows that everyone knows there are at least 98 and everyone can see there are at least 99, but only on day 100 do those people who see 99 know that they are one of the 100 blue-eyed people and not a non-blue-eyed person amongst 99 blue-eyed people.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-500569")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("but I already know n > 0, n > 1, n > 2 and so on. These worlds do not even exist on the hypothetical level, I kinow every other person sees at least 98 other blue-eyed islanders, so nobody can believe n < 98")#linebreak()#text(" This is where the puzzle fails to me, there is no reason to expect on day one, two, three, etc. that anyone would kill themselves, so the count never starts,.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/662ea35793551f759aa14e5cae6a9c875b291a6608ea9ce64645fa8460944787-6af895346d1d680f1e1753c7612ebc5a387f79a47ea4f3c49720ce86a6a35a53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tad Boniecki")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52719")[#strong[#text("Tad Boniecki")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2011")])]

#text("Sorry to be a nuisance, but I am as confused as before. You wrote about hypothetical worlds and that the islanders have to take these into account. Fine. But I still don’t see how the saying out loud of “I see blue eyes” can have any effect, given that each of the islanders can think this without the benefit of outside help. Each islander also knows that every other islander knows this, and so on.")

#text("Secondly, I can’t follow the proof of the case where n=1 because the statement about blue eyes is only made once, to 1000 islanders, never to just one or two. It cannot be hypothesised because it simply does not happen within the framework of the puzzle.")

#text("What am I missing??")#linebreak()#text(" Thanks")

#text("Tad")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("You are getting close to the key point in the puzzle, which is that the “and so on” in your first paragraph is actually false. (This is easiest to see in the case when there are 2 blue-eyed islanders.)")

#text("In the inductive argument, n is the number of blue-eyed islanders, not the number of islanders in total, which is indeed commonly known to be 1000. In contrast, n, while actually equal to 100, is not commonly known to equal 100, and can hypothetically be anything from 0 to 1000 once one works in a sufficiently highly nested knowledge framework.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-197453")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("No, see above. The islanders can employ other logic to prove that no islander can hypothesize n < 98.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d65b07fd556fd42fccebf149978bb3d669189acf7d63498909277ce648c343f7-4e6860c9543b1b54834be8223e7bb10b4a21e482c3b2ca3a11e06fd8822b25ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FV")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52744")[#strong[#text("FV")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("Tad,")

#text("The point is that by saying “I see blue eyes” he does reveal information they previously did not know, it’s just not an obvious information. Suppose that there are two blue-eyed people, A and B and a lot of browned eyed people. Each of them knows that there is a blue-eyed person. But A does not know whether B knows that there is a blue-eyed person. When A looks at B, he thinks: “Well, I and everyone else except B knows that there is a blue eyed person. But does B know that there is a blue-eyed person? I don’t know… It really depends on whether I have blue eyes or not.” After the foreigner’s announcement A thinks “Now B knows for sure that someone has blue eyes. If I have blue eyes then B will think it’s me and not kill himself on the first day. But if I have not blue eyes, B will know that it must be him and kill himself on the first day.” So the foreigner reveals information, not about what each of them already knows about other’s eye color, but about what each of them knows about what others know.")

#text("Try the same with three blue eyed people – A, B and C. A knows that B knows that someone else has blue eyes, namely, C. But when A looks at B and thinks: “Does B know that C knows that someone else has blue eyes?”, the answer is that A is not sure since it depends on his eye color, but foreigner’s announcement changes this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3577e0971731694200697a346bb2e95eae2bc5d3018d4957ce9004dc35ae695-2be40796d4d1cbd65f416835854cb2ed3b96e5086494be0c8f34889842c52e00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lkozma")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52747")[#strong[#text("lkozma")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("You can also check my first comment above, where I explained what is the information transmitted by the foreigner’s speech:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")[#text("The blue-eyed islanders puzzle – repost")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d65b07fd556fd42fccebf149978bb3d669189acf7d63498909277ce648c343f7-4e6860c9543b1b54834be8223e7bb10b4a21e482c3b2ca3a11e06fd8822b25ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FV")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52746")[#strong[#text("FV")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("Dear Terry,")

#text("Wouldn’t it be fun to have an undergraduate class (or even graduate class for law majors!) consisting completely of logic puzzles like this one? This one alone would take at least one class. Is there a good book with 20-30 different logic puzzles such that each would fill one class? Could you make a list of as many non-trivial puzzles as you know, and ask others to contribute. Also, it would be fun to think of ways of using these types of puzzles to force others to reveal information they are hiding, i.e. logic based interrogation techniques! Better than water-boarding! If you find this idea interesting, I can not think of a better way to turn it into a collaborative project than your blog! Thanks, Terry!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd707dc2f3a4e58290784e0102849bb2bbaceca1307785c0953e37f5e4331a88-b4d2a485796d42c7c39defe25c7f42e791b65619401c5d9a3faf21b9a033ab9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farzin")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52755")[#strong[#text("farzin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("I think the problem is in the nature of the question when n=1 and n>1.")

#text("These problems are different when n=1 and n>1 since when n=1 everybody knows there exists blue and brown colours except the blue eyed guy but when n>1 every body knows that two colours exist so the information in the problem is not same when n=1 and n>1. I think the induction logic does not work here since we have two different type of problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd707dc2f3a4e58290784e0102849bb2bbaceca1307785c0953e37f5e4331a88-b4d2a485796d42c7c39defe25c7f42e791b65619401c5d9a3faf21b9a033ab9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farzin")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52759")[#strong[#text("farzin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2011")])]

#text("In other words, the information provided by the foreigner changes the problem if n=1 or n=2 since if n>2 everybody already knows that blue and brown exist. Therefore the right induction for n>2 is that for n=1 every body knows blue and brown exist and so on.")

#text("At the end by the solution 2 we see that based on the assumptions of the problem it is not possible to have a community of people with blue eyes for n>2 even without having a foreigner!!!.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94060cb714f6a33ad106d5888175e0fc5c254e59fe7e1279bee60f3042ac58c3-ceccb022a69d96e97b310d87417736e0a44f85c20318def6ea890e19223eccd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gcy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52776")[#strong[#text("gcy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2011")])]

#text("Approaching the problem by recursive postulation (for the lack of a better word) – modeling a possible scenario within a possible scenario, and so on – is more sensible than inducting on 1, 2, 3,…, n-1, n, though both are essentially the same.")

#text("But the former approach may be more convenient to help resolve the above paradox, because it allows the information ‘there is at least one blue eye’ to perpetuate across all scenarios hypothesized by the islanders, in the manner of ‘A thinks B thinks C… an so on’ – let’s just call that 1st, 2nd, 3rd, … k-th order postulation. Whereas in reality, every islander can casually conclude that everyone else must see at least one blue-eyed (which is of equivalent logic to the foreigner’s statement) – this observation is bound to the ‘reality framework’ for which it is based on, and does not prevail when an islander ‘gets inside the head of another’ to postulate an alternate scenario, and so on. Without the foreigner’s information, this exercise will not yield a definite outcome because at the 99th-order postulation, the possibility that n=0 (there can be no blue-eyed) cannot be eliminated (by the way, every postulation is verifiable by dichotomy logic – if not k-1 islanders, it must be k – such that it provides new information back up the postulation chain).")

#text("Hence, the islanders will not be able to figure out anything unless the given the foreigner’s statement as the ‘baseline truth’, such that the thought experiments can lead to a definite conclusion on the 99th / 100-th day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/025f147e1377a818475c9d838b492fcee9faaf54852736440dd4da070824e180-201e02d1afd97b8c19d3d18716392bf186fa7d6f4298fc3a2a255c2d52bc70f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52798")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2011")])]

#text("Terry’s explanations are fantastic on a mathematical level and also on a language level. The hypothetical worlds situation is explained beautifully. Indeed I do agree with outcome 2 and when I “saw the light” I felt smarter! The “sufficiently highly nested knowledge framework” is also a nice phrase.")

#text("Is there, though, a similarly nice and intuitive way of describing why the blue eyed guys would not kill themselves earlier?")

#text("I know that some poster earlier talked about 100 days being an upper bound. Is it easy to explain why 100 would also be a lower bound or do we not have enough information?")

#text("Also, can we apply the following straightforward argument or is it too “hand wavy”? Argument: Because of symmetry the blue eyed people must all commit suicide at the same time.")

#text("From then, could we then rule out the possibility of this happening on any day before the 100th day? Thus making 100 a lower bound also.")

#text("Finally, can you keep posting interesting problems like this on a regularly? I imagine after solving/ understanding 10-20 problems like this, we might feel better able to tackle problems in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-127075")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")])]

#text("Here’s an answer to why they cannot die any sooner than Day 100.")

#text("Suppose that each of the blue-eyes thinks “Well, I see 99 blues, so there are either 99 or 100. Since this is a version of the puzzle where we are “trying” to deduce our own color as soon as possible, then I will commit to killing myself on Day 2 if and only if no one has done so on Day 1, that is, tomorrow.”")

#text("The problem is that if there really were only 99 blues, then they would each have to think something like the same thing: “I see 98, so I will kill myself on Day 2 if no one does on Day 1.” The 100 blues would have already known this about the hypothetical 99 blues. Therefore, they would have to modify their “strategy” accordingly: “If there are really 99 blues, then they will wait to see if the 98 that they each see kill themselves on Day 1. When that doesn’t happen, those 99 blues will kill themselves on Day 2. And IF that doesn’t happen, then I’ll know there are 100 blues total, and we’ll all kill ourselves on Day 3.”")

#text("But it can’t possibly stop there! Why, exactly, would a hypothetical 98 blues kill themselves immediately on Day 1? There can’t be any particular reason. The hypothetical 99 know that a hypothetical 98 would ")#emph[#text("also")]#text(" wait a day, so these 99 wouldn’t kill themselves until Day 3 at the earliest. Except, of course, that this in turn relies on a hypothetical 97 blues immediately deducing their own color from the foreigner’s statement and killing themselves on Day 1…")

#text("As I hope you can tell, this just keeps going and going. It stops once we reach a hypothetical single blue-eyed islander. Unlike all the various combinations of hypothetical islanders before him, this guy ")#emph[#text("would")]#text(" kill himself on Day 1. So the rest of the islanders’ thought process must build up from there.")

#text("On Day 1, it becomes common knowledge that there is more than 1 blue, on Day 2 that there are more than 2, and so forth. On Day 99, each of the 100 blues sees that the other 99 did not kill themselves, and so all 100 prepare to do so the next day.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-500570")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("“But it can’t possibly stop there! Why, exactly, would a hypothetical 98 blues kill themselves immediately on Day 1? There can’t be any particular reason. The hypothetical 99 know that a hypothetical 98 would also wait a day, so these 99 wouldn’t kill themselves until Day 3 at the earliest. Except, of course, that this in turn relies on a hypothetical 97 blues immediately deducing their own color from the foreigner’s statement and killing themselves on Day 1… ”")#linebreak()#text(" Cannot happen as each islander knows that each other islander can see 98. There can be no hypothetical 97 if I already see 99 people that can see eachother.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/662ea35793551f759aa14e5cae6a9c875b291a6608ea9ce64645fa8460944787-6af895346d1d680f1e1753c7612ebc5a387f79a47ea4f3c49720ce86a6a35a53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tad Boniecki")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52799")[#strong[#text("Tad Boniecki")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2011")])]

#text("I have finally understood the answer. Enlightenment came when I read the clear explanation on wikipedia:")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29#Example")[#text("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29#Example")]#linebreak()#text(" This may help other people.")

#text("Tad")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Epistemic logic, temporal epistemic logic, and the blue-eyed islander puzzle lower bound « What’s new")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52869")[#strong[#text("Epistemic logic, temporal epistemic logic, and the blue-eyed islander puzzle lower bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2011")])]

#text("[…] recently reposted my favourite logic puzzle, namely the blue-eyed islander puzzle. I am fond of this puzzle because […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d1f501d824ff150876644bd70372ddc22f959cbab6b08a9c05cafa591a037ac-4c3ff4d5493927e929c9762033c6c6c6bc2ff557f5b0da12887d1dcceabd849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oskari")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52879")[#strong[#text("Oskari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2011")])]

#text("I’m absolutely bewildered by this puzzle, not because it would be hard to solve, but because of the use of deductive reasoning in absolutely wron realm of things. This is a question of inferring the properties of your model of the world from the observations you make. The link between the model world (a world described by random variables) and the real world is the observations we make of the real world. This cloudy hazy curtain of observations always separates the two. Deductive logics is completely confined in the model world, and can be used ONLY to narrow down the support of the random variables of the model world (based on previously assumed knowledge of the world).")

#text("The solution 1 is correct, with only one exception of n=1 (in which case they all kill themselves by the day two).")#linebreak()#text(" The reasoning is as follows:")#linebreak()#text(" Villagers state of knowledge of his eye’s colour is a random variable with support: Colour=[blue,brown]. Before the new observation provided by the foreigner, the state of blue eyed villager’s random variable “colour”=[(n-1)/N,(N-N-1)/N], where n is the number blue eyed villagers and N is the total number of villagers. Should there be any “observation” that will have only one solution (giving 100% of the probability mass two either of the two states), the person will kill himself. This “elimination” of possible states (or narrowing the support) can be done with deductive reasoning.")#linebreak()#text(" When the foreigner provides the new observation, the only two states of the random variable “colour” of interest in this puzzle are: colour=[1,0] or colour=[0,1].")#linebreak()#text(" If n=1, then the blue eyed person concludes with deductive reasoning that the only random variable state that fits the observation is colour=[1,0], and therefore he kills himself. And after that the rest conclude, they must have brown eyes, so they kill themselfs as well.")#linebreak()#text(" If n>1, then deductive reasoning is not able to eliminate (give zero probability) to either state, and therefore will not cause any consequences. The end of story. If you want to calculate the probabilities, use the bayes theory, which also gives you the way to join the information from two or more observations:")#linebreak()#text(" p(colour|observations) = p(observations|colour)*p(colour)/p(observations).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d1f501d824ff150876644bd70372ddc22f959cbab6b08a9c05cafa591a037ac-4c3ff4d5493927e929c9762033c6c6c6bc2ff557f5b0da12887d1dcceabd849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oskari")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52881")[#strong[#text("Oskari")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2011")])]

#text("I see Terence has talked about bayes before:")#linebreak()#text(" ")#link("https://profiles.google.com/114134834346472219368/posts/G5DnA8EL7D3/In-classical-logic-one-can-represent-ones#114134834346472219368/posts/G5DnA8EL7D3")[#text("https://profiles.google.com/114134834346472219368/posts/G5DnA8EL7D3/In-classical-logic-one-can-represent-ones#114134834346472219368/posts/G5DnA8EL7D3")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-52932")[#strong[#text("A small segue of subject | Great & Amazing Content Site")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2011")]

#text("[…] if we discard the blue-eyed men on the island, and look at real human markets, we would expect to see a collective rationality not finite, but […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53135")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2011")])]

#text("Consider the modified scenario, where the foreigner instead remarks: “There are *exactly* two distinct eye-colours on this island.” What happens then? If I’m not mistaken, on day 100 all the blue-eyed islanders kill themselves, and then the following day everyone else kills themselves.")

#text("On the other hand, if the foreigner says: “There are *at most* two distinct eye-colours on this island”, then everyone learns they have either blue or brown eyes, but without the tragic ending.. how odd!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2011")])]

#text("If the foreigner says “there are exactly two distinct eye colours”, but does not name what they are, then nobody commits suicide (assuming there are no other sources of information, of course), because the fact that the two eye colours are blue and brown is not common knowledge. (For instance, if there are two blue-eyed islanders A, B and two brown-eyed islanders C, D, then A knows that B knows that there are two eye colours, but it is not the case that A knows that B knows what those two eye colours are, and that one of them is brown, but it is not the case that A knows that B knows what the other eye colour is.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53148")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2011")])]

#text("Ah, quite right.. well that’s even more odd, because in this case the islanders are actually learning something new about their own eye colours directly from the foreigner (that their eyes are either blue or brown).. in the original scenario where he remarks that someone has blue eyes, the islanders learn nothing about their own eyes directly from him. But you’re right, even the n=1 part of the induction no longer works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46b04e1650d7b43335b1dd3c5319394fdf7359dc872c7a590ad1126bb73145b5-122d3e59ec0c4279a25bfca641ea6e66e3b1c77ecbd09e55459470f26362a891.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo Cantos")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53999")[#strong[#text("Marcelo Cantos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("But does this uncertainty extend to a larger population? Surely each islander among the 1000 can readily infer that everyone sees at least brown and blue eyes, and that everyone else has made the same inference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-122936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2012")])]

#text("Right, in the modified puzzle when")#linebreak()#text(" the foreigner says “there are exactly two distinct eye colours”, but does not name what they are, then nobody commits suicide – even in the formerly “fool proof” cases of n=0 and n=1 (of blue-eyed and 900 brown-eyed). It is also interesting to note that if, in the original puzzle, “because of some accident,” e.g. pre-suicide overdrinking, the 100 blue eyed will not commit suicide on the 100th day, the next 101th day, all 900 brown-eyed must commit suicide – because the inductive nested logical calculations are done by everybody (and the brown-eyed people all think that there 100 blue-eyed people, for sure, – but maybe 101 ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46b04e1650d7b43335b1dd3c5319394fdf7359dc872c7a590ad1126bb73145b5-122d3e59ec0c4279a25bfca641ea6e66e3b1c77ecbd09e55459470f26362a891.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo Cantos")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-54000")[#strong[#text("Marcelo Cantos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("I don’t follow the second scenario. Everyone already knows that there are at least two eye-colours (and that everyone else knows this too, and that everyone knows that everyone knows, …). With this knowledge, the assertion that there are at most two colours is identical to the assertion that there are exactly two colours.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06ac8d98395c70153c3b3c44ab2a9eb0aaf4e5a34105d1b9f1a8d80c928c32f9-be5dbc250158c47740c6e904122ef3182e5f36a69cb2a8c01e84a3b803d19a99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dimitris stathopoulos")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53144")[#strong[#text("dimitris stathopoulos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2011")])]

#text("day 1: nobody dies because nobody knows his/her eye colour")#linebreak()#text(" day 2: each person count the other 99 or 100 (depending on his eye colour) blue eyed persons")#linebreak()#text(" day 3: you cant say to the other the colour of eyes he has so you ask how many he found with blue eyes")#linebreak()#text(" day 4: those who found 99 realise that they have blue eyes and they commit suicide!")#linebreak()#text(" THE END!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06ac8d98395c70153c3b3c44ab2a9eb0aaf4e5a34105d1b9f1a8d80c928c32f9-be5dbc250158c47740c6e904122ef3182e5f36a69cb2a8c01e84a3b803d19a99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dimitris stathopoulos")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53145")[#strong[#text("dimitris stathopoulos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2011")])]

#text("also:")#linebreak()#text(" those who found 100 also die because the know that they have brown eyes!")#linebreak()#text(" funny")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2011")])]

#text("I will use the xkcd example where people get to leave on a nightly ferry.")

#text("Guru says “there’s at least one person with blue eyes”")

#text("With this, I don’t see any flaws in the following logic:")

#text("For 1 blue-eyed person (A):")#linebreak()#text(" A leaves the instant the 1st Ferry arrives, because he only sees one other person (the Guru) who clearly does not have blue eyes.")#linebreak()#text(" —")#linebreak()#text(" For 2 blue-eyed people:")#linebreak()#text(" There’s 2 possibilities for A in A’s mind. A has blue eyes or non-blue eyes.")

#text("If A has non-blue eyes, B will leave on the first ferry.")

#text("B DOESN’T leave on the first ferry.")

#text("A knows the other possibility must be true, that A has blue eyes. They both leave on the 2nd ferry.")#linebreak()#text(" —")#linebreak()#text(" For 3 blue-eyed people:")#linebreak()#text(" There’s 2 possibilities for A again and as always… A has blue eyes or non-blue eyes.")

#text("If A has non-blue eyes, A might as well be a brown-eyed person. B and C would ignore A and behave as though B and C are the only blue eyed people. We agreed that 2 blue eyed people leave on the 2nd ferry. The 2nd ferry comes by and no one leaves. A must have blue eyes.")

#text("They all leave on the 3rd ferry.")#linebreak()#text(" —")#linebreak()#text(" For 4 blue-eyed people:")#linebreak()#text(" A has non-blue eyes or blue eyes.")

#text("If A has non-blue eyes, A might as well be a brown-eyed person. B, C, and D would ignore A and behave as though B, C, and D are the only blue eyed people. we agreed that 3 blue eyed people leave on the 3rd ferry. The 3rd ferry comes by and no one leaves. A must have blue eyes.")

#text("They all leave on the 4th ferry.")#linebreak()#text(" —")

#text("I don’t see how this could possibly be wrong.")

#text("Now we try the other way…")

#text("Suppose there is no Guru:")

#text("For 1 blue-eyed person:")#linebreak()#text(" No way of discerning own eye color.")#linebreak()#text(" —")#linebreak()#text(" For 2 blue-eyed people:")

#text("Yes, both people know that there is at least one blue-eyed person, but A doesn’t know B knows, and B doesn’t know A knows.")

#text("For all A knows, A has non-blue eyes, and it is as though B is alone on the island.")#linebreak()#text(" —")#linebreak()#text(" For 3 blue-eyed people:")

#text("For all A knows, A has non-blue eyes.")#linebreak()#text(" If this is the case, this is what B’s vision would look like:")

#text("A = non-blue (worst case)")#linebreak()#text(" B = (I don’t know because I’m A pretending I’m B)")#linebreak()#text(" C = blue")

#text("Now have A’s theoretical B pretend he’s C:")

#text("A = non-blue (worst case)")#linebreak()#text(" B = non-blue (worst case)")#linebreak()#text(" C = (I don’t know because I’m A pretending I’m B pretending I’m C)")

#text("As far as A knows, B has no way of knowing whether or not C knows anyone has blue eyes.")#linebreak()#text(" A can’t know if B knows C knows.")#linebreak()#text(" —")#linebreak()#text(" For 4 blue-eyed people:")

#text("For all A knows, A has non-blue eyes.")#linebreak()#text(" If this is the case, here’s B’s vision:")

#text("A = non-blue")#linebreak()#text(" B = (idk)")#linebreak()#text(" C = blue")#linebreak()#text(" D = blue")

#text("Now have A’s B pretend he’s C.")

#text("A = non-blue")#linebreak()#text(" B = non-blue")#linebreak()#text(" C = (idk)")#linebreak()#text(" D = blue")

#text("Now have A’s B’s C pretend he’s D.")

#text("A = non-blue")#linebreak()#text(" B = non-blue")#linebreak()#text(" C = non-blue")#linebreak()#text(" D = (idk)")

#text("A’s B’s C can’t count on D.")

#text("I like this idea… but why do you need 3rd order knowledge? Isn’t the below actually true?")

#text("A=non-blue")#linebreak()#text(" B=(idk)")#linebreak()#text(" C=blue")#linebreak()#text(" D=blue")

#text("A knows B knows C knows (C at least sees D)")#linebreak()#text(" A knows B knows A knows (A sees both C and D)")#linebreak()#text(" A knows B knows D knows (D at least sees C)")

#text("A can comfortably obtain that Everyone knows everyone knows everyone knows that there is at least one blue-eyed person. Isn’t that enough?")

#text("Are my inductions without the Guru wrong? Could someone explain why you need 3rd order knowledge or show me my error in the 4 blue-eyed people no Guru step?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b532a55a00da2692d1bad497dc81b83c67981143cb87e7c41f17486157d7c44-c1e3139a67ccb9edb2912a651e91820cd738d8ebdf46196b5d0326fd5c3c56fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen Wei")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53559")[#strong[#text("Chen Wei")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2011")])]

#text("the visitor’s words is meaningless, because everyone already knew that at least one native people are blue-eyed. So, what’s the fuction of the visitor’s announcement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61efa4b0c9cb932e9c27b2cb61584f0b378674cd5384152059cc92469feca966-476465ff05306b77ee73e1f3494f792cfb8e13d86fe9011f909f94d390188e1a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cocacola1123")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53598")[#strong[#text("cocacola1123")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2011")])]

#text("I have some opinions about this puzzle, I am not sure it’s right, just for discussion:")#linebreak()#text(" 1. The 2 solutions are all right. Because it is unreasonable that the foreigner trigger this incident. Actually I believe a reasonable trigger (beginning condition) is as follow: the islanders immediately reach a common knowledge that “all islanders know that at least 98 blue eyes are exist”. (brown eyes will make the common knowledge 99, but it is contained in the condition of “at least 98”, however, such difference make the brown eyes wait for all blue eyes commit suicide, then they will die one day later)")#linebreak()#text(" 2. 1st day, no one died, so the common knowledge rises to 99;")#linebreak()#text(" 2nd day, no one died, so the common knowledge rises to 100;")#linebreak()#text(" 3rd day, all blue eye commit suicide;")#linebreak()#text(" 4th day, all brown eye commit suicide;")#linebreak()#text(" 3. Conclusion: there is m brown, n blue. In 3rd day , min(m, n) will commit suicide. In 4th day , max(m, n) will commit suicide. If m=n, they all commit suicide in 3rd day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2011")])]

#text("As a nudge for people who are skeptical that the foreigner has introduced information to the system, consider that the situation would be different (and no villagers would die) if the foreigner made his comment individually to each villager.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-53829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2011")])]

#text("That is, individually and privately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/576c5fba7ec90118832be00b34b93ec4feb52c4080ee178d4bc3867f4208efc2-89f9fafb25c8dc394d5d0b021431bd270288f9a44dadbf119ba7f2b160a157a2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Winston W. L. Ho")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-54088")[#strong[#text("Winston W. L. Ho")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2011")])]

#text("Shang1 nao3 jing1 ah! (crack my brain) The person who came up with this puzzle is a genius. My understanding to hopefully ‘unify’ the two solutions goes like this:")#linebreak()#text(" We can use a simplification (offered by Jim ")#link("http://higherlogics.blogspot.com/2008/02/blue-eyed-islander-puzzle-analysis.html")[#text("http://higherlogics.blogspot.com/2008/02/blue-eyed-islander-puzzle-analysis.html")]#text(" ) of considering a small group of 4 people wearing hats. N people wear blue hats and 4-N people wear brown hats. Every minute, if anybody deduces the color of the hat he is wearing, he has to declare it. At a certain point in time, an outsider pops in and says ‘I see at least 1 blue hat.’")#linebreak()#text(" If N=2, the statement that the outsider said has already been known by all the four people, long before the outsider came. So how did the people deduce the color of their hats? Why didn’t they do so earlier?")#linebreak()#text(" The answer I think is because the outsider provided the origin time. This allows the people to deduce the color of their own hat based on counting each passing minute. The declaration has to occur at fixed time instants.")#linebreak()#text(" I don’t understand the mathematics of the wikipedia entry on common knowledge, but I offer my simple common sense explanation. How does this relate to the common knowledge?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef856a8de5fca56a03f4bd57cdc8b705e21cb06ee5beb2497e3863fe7077de92-91e3d176d71153ffc80fed605a8f8770d47cc99addd60e41caa9bbcd25d0259d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jlflorez")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-2/#comment-58948")[#strong[#text("jlflorez")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("My opinion is that foreigner statement break the uncertainty when one guy is seeing that nobody has blue eyes, then he is the BEP, and by induction you reach the ritual suicide in the day n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8298b5b9d992fab1b544e50b3638509fe60b69384cf1b4c5c01191d7b416f4b-a5bea21460d3c426376e261997bb07ee61cbad53e21fdc8822775c36a9c812ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xamuel")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51399")[#strong[#text("Xamuel")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Another variation of this is the Muddy Children Puzzle, which Fagin, Halpern, Moses and Vardi chose for the introduction or first chapter (can’t remember which) of their book “Reasoning About Knowledge”.")

#text("You forgot to mention one thing: you seem to be implicitly assuming the islanders aren’t deaf… oh, and they all know that they’re all not deaf, and so on… or at the very least, that the deaf ones can read lips…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51401")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Yes, this is the type of “legalistic loophole” I mention in Note 2. With these sorts of logic puzzles, there is always the implied assumption of “idealised conditions” (no deafness, colour-blindness, or other physical disabilities, no pirates to come and randomly abduct half the population on Day 17, no unexpected breakdown of causality or other laws of physics, and so forth). It is a trivial matter to “break” the logic puzzle using non-idealised conditions, but this is not the most interesting aspect to the puzzle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568904bbdbfff9b3742fbe47b336892c45c6c7d26334287c3d8295cb9e00aab6-b95ec6a1bde380a059e9fb40357901a4894a1a1d0e60c45d1db3630a500473fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Doscher")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-427667")[#strong[#text("Christian Doscher")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2014")])]

#text("Solution seems to suffice.To pursure #2 seems pathological! The individuals are not able to understand anything about themselves from comment made. It seems clear no one could know any thing new. Is this how math is used on Wall Street? Or how does this effect real world situations? Meaning what to we do with this info? In order to know if I should pursue this understanding #2 process. Math is not my field, but is there any schools of thougth that don’t agree with # 2’s validity ie an argument against it that you’ve heard of by any one that is considered valid too?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51402")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Wouldn’t the brown-eyed people then kill themselves, too, once they saw that all the blue-eyed people were dead? Wouldn’t they also know that all the blue-eyed people would kill themselves, and so once they were gone wouldn’t they figure out they had brown eyes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dcb728f76a2b42b7134b3f895967225a2657e0a9b41ebba221d5f8cdc7f104f-e06c04b89e539119a3a97a76fe624d1e6cc3df5d072d0d1daa40d0a4337d03d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amic")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51404")[#strong[#text("Amic")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("No, because each one could consider to be the only one to have green eyes for example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51405")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("It’s not a boolean?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-52250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2011")])]

#text("If it were boolean, then there would be no need of a foreigner, they would all commit suicide on their own.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-427498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("This sound interesting. Could you explain the all committing suicide on their own?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09594084cbbfc6dc1ce6f8901ffc2ee57b2b24f483606271bb21813185180487-9c0b970af6fd8fac7939d9d8d742f7d6fde5a25ea776b21654acf57cb75e96d3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51407")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("There is nothing that says there are necessarily only two eye colors. Therefore, none of the brown-eyed people would necessarily know that they didn’t have, say, green eyes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67062e85e9ce2b8f4f750ed6e4bd9d8a909dc9b8d30998a6e0018473348e7074-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Mossburg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-216070")[#strong[#text("Geoff Mossburg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("True, and also there is no reason given why the brown eyed people (and green eyed people, etc) wouldn’t come to the same conclusion as the blue eyed people in the first place. ie: The implication of the second argument is that only the blue eyed people drew a conclusion that they were blue eyed, but there is no logical reason given for this to be exclusive to the blue eyed people.The inductive reasoning for n>1 forgets to take into account eye colors other than blue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e19deb94c0afa74c7ae5c00b93f6632fe2e500b171c81d7349ddb17d58b040a-f9d67d0a7b22d8ae414a59c26e8a137b7d7e4eca354a5d3ba965e1af2234d933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Binoy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-552013")[#strong[#text("Binoy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("But wouldn’t it be logical to assume, that considering an island with brown and blue eyes (you are able to see the 999 other pairs of eyes and the foreigner’s), that if you had a different colour of eyes, the foreigner would be more interested in you than a colour which he already owns? Just saying ….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e19deb94c0afa74c7ae5c00b93f6632fe2e500b171c81d7349ddb17d58b040a-f9d67d0a7b22d8ae414a59c26e8a137b7d7e4eca354a5d3ba965e1af2234d933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Binoy")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-552018")[#strong[#text("Binoy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2020")])]

#text("Actually, solution 1 makes more sense… Considering that the knowledge of the colour of their eyes is something they don’t seek and also because I know that there is someone else with blue eyes that I can see (every islander knows that it’s not possible for the owner of blue eyes to know that they have blue eyes.) As such, seeing someone with blue eyes alive the next day would mean to them that they are unaware about it whereas the other blue eyed person is expecting someone else to die. The number of blue eyed people in the island is nowhere disclosed and the islanders have least interest in it. They’d rather just ignore the words of the foreigner and continue to live on. I would say that only in cases where the blue eyed population is so low as to induce suspicions, for eg: 1 amongst 1000 and that comment would result in a lot of stres")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/324c5517b6707fe04ff78de4e22845e08fd39fac240d9dee74a69437baea4a69-3b260798b61ebb04fb32a8ee41e8e6c20b890bef03f0bb26af3f77423c94848e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bretbenesh")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51409")[#strong[#text("bretbenesh")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Nicole: the brown-eyed people would definitely commit suicide if they knew that there were only two possible eye-colors: blue and brown (effectively, “blue” and “not blue”). However, each of the brown-eyed people would think: “All of the blue-eyed people just killed themselves; all of the remaining people have brown eyes, but it is possible that I have brown eyes OR green eyes (but definitely not blue eyes). ” EVERY brown-eyed person will think this, so none of them will commit suicide since they still have at least two possibilities for their eye color.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/324c5517b6707fe04ff78de4e22845e08fd39fac240d9dee74a69437baea4a69-3b260798b61ebb04fb32a8ee41e8e6c20b890bef03f0bb26af3f77423c94848e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bretbenesh")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51411")[#strong[#text("bretbenesh")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Sorry for the redundancy—Greg’s and Amic’s answers did not show up until I posted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51415")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Or hazel or violet or whatever.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4eaf635100162e218c0677f413e3046808e6b93a5ef901ce547694ce3f59d68-d7e01f32516f18081856c443d860e095c8fc1dc1b6b543e3a04c8a480a5d1018.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51431")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("You’re correct: the brown eyed individuals would, in fact, also kill themselves at a later date. After all the blue-eyed individuals had killed them selves on day 100 (when the traveler makes his comment on day 0), there would be left exactly 900 brown-eyed people. The same exact logic that applied to the blue-eyed people now applies to the brown-eyed people. Any brown-eyed individual, looking around, would see 899 brown-eyed people. When these people didn’t commit suicide on day 899, he would have to conclude that he also had brown eyes. Therefore, the remaining population would commit suicide on day 900. The brown eyed individuals do not need to assume that there are only two eye colors for this to occur. Indeed, each population of individuals with a unique eye color will kill themselves off working from smaller populations (rarest eye color) up through larger populations (more common eye colors) for any number of colors. And again, as others have pointed out, this gradual genocide would happen without any interference from the traveler (i.e. if he had never shown up). We simply take this as a convenient date to start thinking about this thought experiment. This is the correct manner through which the two different scenarios should be reconciled.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51485")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("There is an error in this argument when you imply that there is no need for there to be only two eye colors. Suppose for ease that there are 3 people on the island: one has blue eyes, one has brown, and one green. Then at first, none knows their own eye color. But as soon as the unfortunately honest traveler says there is a blue-eyed man, the blue-eyed man will kill himself.")

#text("Yet now the brown and green eyed men will still have no idea what their eye colors are. The brown-eyed man sees the other green, but does not know whether there are brown-eyed people on the island (or any other color, for that matter). Similarly, the green-eyed man does not know if there are any green-eyed men on the island. If the traveler were to come back and say, I see green eyes, then that color would also eventually kill itself. Finally, I note that this generalizes to larger numbers without error.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c56017e24c6c803ea88a4c45416cb18559f84558e709d2a8551eadea60f855f-3cf566509021b049e996c14d8cfc4425b505dbecb7bc1ba05b8e724ceefe23e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mike")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-446738")[#strong[#text("mike")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("Agreed.. the brown eys guys all kill themselves on day 900. On day 899 each is uncertain as to their own eye colour, but when the 899 DONT kil themselves on day 899 they all realize they own eye colour is the reason and kill themselves .. exactly the same logic as the blue eyes.. QED")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3f388a3b6d3739e5a53dea22fa9a52f66f821be3d367fdce0279fb00ed03c30-e4f3939b75bd1f34d91c887379ac1a3ddbab5e618702666aaddc335e6c7f5638.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brandon")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-453848")[#strong[#text("Brandon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2015")])]

#text("The difference between the blue and brown case is that when the foreigner says there is someone with blue eyes, everyone knows there is a blue-eyed person, and everyone knows that everyone knows there is a blue-eyed person, and everyone knows that everyone knows that everyone knows… etc.")

#text("But say there were only 3 brown eyed people on the island, P1, P2, and P3. Everyone knows there is a brown eyed person (they can each see two of them), and everyone knows that everyone knows there is a brown eyed person (P1 knows that P2 can also see P3). However, here’s the tricky part: P1 does NOT know the previous sentence (“everyone knows that everyone knows there is a brown eyed person”). P1 cannot conclude that P2 knows that P3 knows that there is a brown-eyed person: For all P1 knows, he has green eyes, in which case P2 sees 1 green, 1 brown, and so in P1’s mind, P2 cannot conclude that P3 sees a brown-eyed person.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-500552")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("“The difference between the blue and brown case is that when the foreigner says there is someone with blue eyes, everyone knows there is a blue-eyed person, and everyone knows that everyone knows there is a blue-eyed person, and everyone knows that everyone knows that everyone knows… etc.”")#linebreak()#text(" Didn’t they all know that in advance as per them SEEING other blue-eyed persons? Each islander sees at least one blue-eyed person. Presumably they know that each other of them can see it too. The foreigner’s statement carries no further information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d79ccec0aa1d87486f26b7f2728b1f5b839dc8726ead7f1a40443abdcd14707-1aae4aeacc06b355fa8f6f0e64c628c81b37edf78c5a6af13671a477b8c9abb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DAVID RICKETTS")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-500630")[#strong[#text("DAVID RICKETTS")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("Note to Infinito1x1: The foreigner’s statement gives everyone at the same time a point in time for everyone to begin counting days.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2255f9851f77bde11c2903701907294cf6515e060ef39557d71ce393d9bace1d-3333a111458073ade9d12a41ae5ab057afbe779ddfa5f0dd34874096f3d6362f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of galoalvarez1980")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-567692")[#strong[#text("galoalvarez1980")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2020")])]

#text("To me there is no such thing day 0, so all the blue eyed individuals would commit suicide on day 101.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51403")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("… and why would the brown-eyed people not also be thinking the same thing the blue-eyed ones were, and kill themselves by accident thinking they were the other blue-eyed person? Wouldn’t they be subject to the same train of thought?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("No, because each non-blue-eyed person counts the full set of blue-eyed people, while each blue-eyed counts one less.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51410")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("So the blue eyed people are killing themselves a day earlier than the brown-eyed person would have, that makes sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67062e85e9ce2b8f4f750ed6e4bd9d8a909dc9b8d30998a6e0018473348e7074-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Mossburg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-216071")[#strong[#text("Geoff Mossburg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("How can you assume that? Because each non-blue-eyed person has no way of knowing if they are blue-eyed (just as each blue-eyed person would), they are all dealing with the same n-1 set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-216120")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Yes, the degree of ignorance of one’s own eye color is equal for all islanders, brown or blue. But this doesn’t somehow mean they each observe the same number of blue-eyed people! Suppose there are two blues and five browns. In this case, each of the browns observes exactly two blues and each of the blues observes exactly one blue. Meanwhile, each of the browns observes exactly four browns, while each of the blues observes five.")

#text("In general, even before any visitor spoke, everyone already knew that, as a rule, all X-eyed people must each see one fewer X-eyed person than all non-X-eyed people see. (If your eyes are not X, then you must be seeing all the X-eyed people, but if they are X, then you are seeing all the X-eyed people minus one person, yourself.)")

#text("Of course, this fact by itself is not enough to figure out your own eye color, because you don’t know if you are seeing the lower or higher of the two estimates! The whole problem is built around that uncertainty and its ultimate elimination by the combination of two things: the visitor’s remark, and the separation of time into collectively-agreed-upon periodic intervals (days).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-446737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("The brown eyed people all kill themselves on day 900")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-249650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2013")])]

#text("n=1 case only works with the information that there is a blue eyed person on the island. That info is not at hand in other cases.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d77f1e53260cc0b7ca7e5ac49aa39b8627d6290d26f9c93decf949838c67ab6d-221ffb645d2c9f0a98ae5a0d4ff39caf9fd44c580b0795cd48ec752343dc58c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of X9")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51406")[#strong[#text("X9")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("For a better example use this explanation; in a prison a crazy ruler has set up a riddle- he has trapped all prisoners (all of them smart logicians) in boxes. The boxes are located in a circle. Each box is soundproof. From a window in the box each prisoner can see the color of all boxes but not of his own box. There is no way of communication between boxes as the windows are constructed in such a way that you can see out but not in. There is a one-way speaker system in all boxes. In every cell an explanation is given; guess or deduct the correct color of your own for freedom or the wrong color for extermination. Also the rules of the game are explained on a wall poster in each cell. One day a new box is added and the information is given over the speaker system that the arriver can see another blue box (like himself) etc. In such a way the puzzle can be constructed in a way that is both correct to normal life and understandable in real-life logic. There also must be a way for the prisoners to know if other prisoners have made a logic assumption.")

#text("The answer will depend a bit on how the puzzle is constructed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d77f1e53260cc0b7ca7e5ac49aa39b8627d6290d26f9c93decf949838c67ab6d-221ffb645d2c9f0a98ae5a0d4ff39caf9fd44c580b0795cd48ec752343dc58c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of X9")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51420")[#strong[#text("X9")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("To better understand; reduce the number of prisoners to 10 (this will not effect the outcome). As easily seen, if the puzzle is corrected in a certain way, the individual prisoner will know his color by the last day (given knowledge they all think the same way and to the rules of logic deduction).")

#text("You can also reduce the number of prisoners to 5 or 3. Remember to include the option of any color. The color of the speaker/guru (if used) will not be relevant if the wording is not ‘same color as my own’. In such a way the outcome of puzzle will depend on how it is constructed (it can be constructed in a solvable way an also to be unsolvable only by a slight variation in word use). Good luck.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09594084cbbfc6dc1ce6f8901ffc2ee57b2b24f483606271bb21813185180487-9c0b970af6fd8fac7939d9d8d742f7d6fde5a25ea776b21654acf57cb75e96d3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51412")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("It might be worth pointing out that the announcement, in the n=2 case, does add new information (I am ignoring the n=1 case since it seems to have some special structure).")

#text("When n=2, each blue-eyed person knows that there is at least 1 other, but they do not know whether the other knows that there is at least 1 other. The announcement, being public knowledge, then ensures that it is commonly known that there is at least one person with blue eyes. That is, the announcement does add new information when n=2, contrary to the first proposed solution.")

#text("How this scales to larger n is still unclear to me, however.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51414")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("For n = 3, the third guy will think that the other two will figure it out in 2 days and then kill themselves, and this is exactly what the other two will think. But then after two days when they find out that the other two have not killed themselves, they’ll figure out that there has to be a third person with blue eyes, and voila! It scales exactly this way for all higher n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09594084cbbfc6dc1ce6f8901ffc2ee57b2b24f483606271bb21813185180487-9c0b970af6fd8fac7939d9d8d742f7d6fde5a25ea776b21654acf57cb75e96d3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51422")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("While I trust the induction, it is still slightly questionable to me. In the n > 2 cases, the announcement adds no new information it would seem. Everyone sees that there is someone with blue eyes, and everyone sees that everyone sees that there is someone with blue eyes, etc. So the information that was new in n=2 is no longer new in any n > 2. Would this mean that any situation where n > 2 is inherently unstable (and should have already collapsed)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51425")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("True!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09594084cbbfc6dc1ce6f8901ffc2ee57b2b24f483606271bb21813185180487-9c0b970af6fd8fac7939d9d8d742f7d6fde5a25ea776b21654acf57cb75e96d3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51433")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Given my correction to myself, I now don’t think that the situation is inherently unstable, but that there is new information provided by the announcement that was not previously present. Thus, the inductive proof is the correct solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09594084cbbfc6dc1ce6f8901ffc2ee57b2b24f483606271bb21813185180487-9c0b970af6fd8fac7939d9d8d742f7d6fde5a25ea776b21654acf57cb75e96d3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51430")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Ah, I found a problem with what I wrote. If n=3, it is indeed the case that everyone sees that there is a blue-eyed person, and everyone sees that everyone sees that there is a blue-eyed person, but this does not entail that everyone knows that everyone sees that everyone sees a blue-eyed person.")

#text("For, each of the blue-eyed people is left with two hypotheticals: “If I have blue eyes, then everyone knows that everyone sees that everyone sees a blue-eyed person”, but also “If I have non-blue eyes, then I don’t know that everyone knows that everyone sees a blue-eyed person” (this second one is due to the fact that one of the two visible blue-eyed people would see only one other blue-eyed person and things would be back in the n=2 case).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51435")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("True, again! So the traveller does act as a trigger.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4031826f9c663acff0b9323ac09bdfaaaf301dc1cb5ec913a319c095b048ad68-7acdc8ecc04605b891172698554b2c62f84b975278d1bb8a60dd36d6ed21bff3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lukasz")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51453")[#strong[#text("Lukasz")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("When considering what everyone thinks as a whole it’s a little confusing for me, I prefer to see it from recursive point of view of just one of them, even though it amounts to the same thing.")

#text("If n=2, person 2 is looking at person 1 and thinking (a) “If I’m not blue, then person 1 will kill himself today, otherwise I’m blue and we’ll both kill ourselves tomorrow”.")

#text("If n=3, person 3 is looking at person 2 and thinking (b) “If I’m not blue, then person 2 is thinking (a) and they will die tomorrow. If I am blue then person 2 is thinking (b) and we’ll all have to kill ourselves in two days”.")

#text("If n=4, person 4 is looking at person 3 and thinking (c) “If I’m not blue, then person 3 is thinking (b) and they will die in two days. If I am blue then Person 3 is thinking (c) and we’ll all have to kill ourselves in three days”.")

#text("Of course for n=3, not just person 3 is thinking (c) but all people 1 to 3, but we only need to consider 1 of them. Same idea for n=3.")

#text("… and death by induction it shall be.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51413")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("No. After n days, since all the blue-eyed people would have killed themselves, the brown eyes people will know that *all* the blue-eyed people are dead (since they all know that the blue-eyed people were highly logical, and wouldn’t kill themselves unless they were absolutely sure of their eye colours.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51418")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("This one was for Nicole.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e779fb38fbd7267b933451e64b4c318ee2b7d2f7ef237e22992c7a09a6ab22d-839e62a92c3e96c39abd32bf93980574ae59e8f22ffd44f58712c61c898bfa90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("The first solution is correct. The foreigner never says how many people he saw with blue eyes, and none of the islanders are aware of the statistic of how many people have blue eyes. So they would not know n people should have blue eyes, and would not necessarily deduce their eye color when they count n-1 blue eyes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51421")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("In my opinion, the second one is correct. They won’t do anything instantaneously after the announcement. But, from the point of view of a blue-eyed person (say), it’ll be clear that 99 days are enough for the other 99 blue-eyed people (that he can see) to figure out their own eye-colors. After 99 days, when he sees all of 99 blue-eyed people still alive, he’ll figure out that he has blue eyes too.")

#text("This is assuming, of course, that they still remember the announcement after 99 days. (Note 2.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67062e85e9ce2b8f4f750ed6e4bd9d8a909dc9b8d30998a6e0018473348e7074-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Mossburg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-216073")[#strong[#text("Geoff Mossburg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2013")])]

#text("Why would they think this after 99 days if they have no statistic letting them know how many blue-eyed people there are? Maybe after 999 days.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d534baa6174b07d11f53d8e887eeebe5cf4223fc4bd300d06d3b62d5f47728cb-f3f9f5d5871b1d0870cb3051bec7c5cda414e01d978419b521431d08a804ee89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DLS")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51480")[#strong[#text("DLS")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("If n=2, the statement “Everybody knows that someone has blue eyes” is initially true. If n=3, the statement “Everybody knows that everybody knows that someone has blue eyes” is true (but this is not true if n=2). More generally, the statement “(everybody knows that)^k someone has blue eyes” is true for k=n-1 and not for k=n. However, after the public announcement, the statement is true for all n. This is essentially equivalent to the induction but captures exactly the knowledge that is conveyed by the speech.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51556")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("Exactly, so the moment they began existing would be the start of the process, well before the visitor shows up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-127078")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2012")])]

#text("It can’t, because prior to the input of outside information, there is no reason whatsoever for a lone blue-eyed person to kill himself. Once the visitor speaks, there is such a reason, and the process starts.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-500553")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("If you can see other blue-eyed people and count them outright, there is no reason at all to expect n=1 when you can see at least 99.")#linebreak()#text(" If you can’t know who has blue yes or not by looking at them, there is no reason to kill yourself at n=1, since you will never assume it is yourself.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d663b4008f7e16c11d39dfed7ccd0b6e6394ae9fd3588060f97a18e39d1cc55-36c240a2172ca4624e1b0d091ca9080093d665b2ac27afbde942946da190bbf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hugo")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-54725")[#strong[#text("hugo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2011")])]

#text("This is the subject that we should be talking about, because after all it is the interesting part")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51419")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("I’ve got to say, I’m not sure I would describe people who killed themselves when they know their eye color as “highly logical”!")

#text("This is a very tragic puzzle…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51423")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("It’s a sacred ritual for the tribes people. For many of the atheists, the belief in God is absolutely absurd, irrational and illogical, yet Albert Einstein was a firm theist. Humans are fascinating creatures.")

#text("This makes me sound like ET, not DT. :P")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("No he wasn’t. He believed in Spinozas god at most, a god who wound up the universe at the beginning of time and then let it run, not any kind of personal god, the kind most atheists would call silly. Even Dawkins has grudgingly admitted a case can be made for Einsteins and Spinozas god.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51510")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("Hehe. Yeah, I know now. What I posted was because of some stupid thing a youtube video had led me to believe. I am reading “The World As I See It” by Einstein, and what you say is indeed correct.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38ed438b2070836252669307683cc47617912535fa414e3358d8ec0bff67577b-a22e50bca9e614015185c5e85c97e72b9f7a1778da385f0376cb84d5faa1c3fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stas")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51458")[#strong[#text("Stas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("It’s better to replace people with robots/cyborgs/androids who are programmed to be behave as described.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f80866e58c6b6b7a21dcb55e0b3273f56ee04adc55b2f3084acc57d1578ca80-0515460a3b350668403644166129dd0ccea170b476f29ab8014442b6397ba75a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Kunjwal")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51424")[#strong[#text("Ravi Kunjwal")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("I don’t think any logical conclusion in the nature of solution 2 follows: solution 2 assumes a knowledge of n, the number of blue-eyed folks in the tribe. any individual in the tribe knows (or can, in principle, know):")

#text("1) there are 1000 people in the tribe, including him,")

#text("2) if this individual is blue-eyed he knows that of the other 999 folks")

#text("– 99 are blue-eyed and 900 are brown-eyed,")

#text("and if he is brown-eyed, he knows that")

#text("– 100 are blue-eyed and 899 are brown-eyed")

#text("3) Of course, this individual doesn’t know his own eye-colour.")

#text("4) So when the foreigner makes a reference to “another blue-eyed person”, it could mean any of the other 99 or 100 folks.")

#text("5) But then each individual in the tribe reasons in exactly this fashion. Not one of them has any a priori information about his own eye-colour.")

#text("Life will go on as usual – the foreigner hasn’t really told them anything new. Each one of them already knows that there is at least one “another blue-eyed person”.")

#text("The induction that solution 2 proposes assumes a priori knowledge of the number of blue-eyed guys. Of course, if there were only one blue-eyed guy, he would have to commit suicide, since he knows there is no other blue-eyed guy in the tribe. If there are at least 2 blue-eyed guys, neither of them would have to commit suicide after two days. Each of them only knows that there is at least one blue-eyed guy and at most two, but there is no way to decide what the total number of blue-eyed guys is. Similarly if there are n blue-eyed guys, each of them knows that there are at least n-1 blue-eyed guys and at most n, but there is no way to decide which, unlike when n=1, where it is clearly established that the blue-eyed guy is blue-eyed because no one else is. The argument by induction is fallacious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51428")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Read Greg’s reply above. He raises an excellent point. The situation seems like it’s always unstable. So if the other had not been trying to figure out their eye colours before the announcement, life will go on as usual. Otherwise, they would have killed each other a long time ago.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51426")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Wait a second, back up. The whole n=1 situation never occurs to begin with, because everyone already knows for a fact that n is either 99 or 100. So no one is sitting around thinking “What if it is just me and some other person”. So the induction falls apart because we know that situation is impossible from the start.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51429")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("I think the induction is alright. n = 1 is just a case to begin with, but we see that even for higher n, it would stand.")

#text("n = 1 – Easy")#linebreak()#text(" n = 2 – B1 thinks B2 will kill himself tonight, and B2 will think the same thing about B1. When the next day they see each other again, they’ll figure out that n has to be greater than 1. But everyone else they see is brown-eyed! So they kill themselves.")#linebreak()#text(" Similarly for higher n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51469")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("But we know that the n=1 case doesn’t exist to begin with. Everyone knows there are at least 98 other people with blue eyes. So n=1 through 97 are impossible, and you can’t base anything on it to begin with.")

#text("This is causing quite a debate in our household now, with my husband being in favor of the tragedy.")

#text("What would really be evil is if some guy came to the village and said, “How nice to see another grey-eyed person”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51489")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("I was thinking of this possibility myself! Then everyone dies. The power of a (grey) lie.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-199589")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("A late reply, because this point is commonly raised. Yes, the case N=1 does not “exist” here at all. But the point is that we can logically prove the following two statements:")

#text("1. If exactly 1 blue-eyed islander existed, he would die exactly 1 day after the announcement.")

#text("2. If it is provable that an island with exactly N blue-eyed people would see those N people dying on Day N, then it follows that N+1 blue-eyed people would die on Day N+1.")

#text("The second statement may cause disagreement, but it can’t be argued that ")#emph[#text("if")]#text(" both statements are true, then the situation works out for any number of blue-eyed islanders (assuming they can count to any finite number). After all, 100 can be expressed as N + 1 + 1 + 1… (to 99 1s), where N is also 1.")

#text("What proves statement 2 is quite simple.")

#text("A. Suppose that the islanders know that for ")#emph[#text("some particular")]#text(" N (such as N=2), it is true that N blues would kill themselves on Day N.")

#text("B. Suppose further that the actual number of blues is really N+1.")

#text("C. Each of those N + 1 blues would observe exactly N blues.")

#text("D. They would know that the total number must be either N or N+1.")

#text("E. They would know that if it were N, those N would die on Day N. (Restatement of premise A).")

#text("F. Therefore, if that doesn’t happen, there are not exactly N blues.")

#text("G. If there are not exactly N blues, then there are N + 1.")

#text("H. Once N+1 blues conclude that the exact number of blues is N+1, they will each realize they must be “the one blue I can’t see”.")

#text("I. The N+1 blues, having observed that N blues did not die on Day N, will kill themselves the following day, Day N+1.")

#text("This proves that if it works for a given N, it works for N +1. We can then treat N+1 as a “new” N, and repeat the deductive process as many times as needed.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-500557")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("You woudn’t because at N=3 people have no reason to think anyone else will kill themselves, since they both see blue eyed people and see they can see blue eyed people.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be689f21c1d57ba5c1609f643f30dcea1b2db04461da53e2ccfe504ead2dcca1-dcfd41d2e9c2e68c5a6ea9bb1b893cfb8e1e0289d60496eeeeac5b3efdc77de6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of infinito1x1")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-500556")[#strong[#text("infinito1x1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2018")])]

#text("“n = 2 – B1 thinks B2 will kill himself tonight, and B2 will think the same thing about B1.”")#linebreak()#text(" Maybe at N2 but not at N3, since each person knows there ae another two guys that can see eachother having blue eyes, so they have NO Reason to conclude any of them will kill themselves at all, since they have no reason to deduct either they have blue eyes or how many in total do. They all know they can see at least two blue-eyes people that can see eachother and then have no reason to conclude THEY themselves are blue-eyed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c073934c451dbec263aa6524d5041b0462e404e5dba039f587dc7c10c887324c-34f2f9a8e04816a2692166b075f714e3dc823c0afc9b8b1e4a5e0b5baea2e4e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-513012")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")])]

#text("Hi I struggled with this, but came to accept the deduction.")

#text("3 guys, with blue eyes. They all know, that if the 2 that they themselves see, saw only each other, they would have killed themselves. When these two don’t, the third guy knows they see a third guy that he doesn’t. This works the same from any of their points of views. “I’m seeing two people, and they are each seeing two people. If they are seeing someone alse blue eyed and I’m not, it must be me”.")#linebreak()#text(" I hope you can see that in N3 it works.")

#text("In N4 now, “if the three people I’m seeing were all, case N3 would have materialised, and they’d be dead”.")#linebreak()#text(" In N2 – every B expects the other to kill himself(if N1)")#linebreak()#text(" In N3 – every B expects two other Bs to kill themselves after realising they were in N2")#linebreak()#text(" In N100 – every B expects 99 other Bs to die after realising they are in N99")

#text("Oh, look at it this way:")#linebreak()#text(" Time is very important here! It directly communicates how many others you are seeing. If everyone waits for 99 days, it’s because they see 99 people! They all hope for 99 to kill themselves after 98 days (for the number thay were seeng) after realising they were the 99th.")#linebreak()#text(" So it’s only the marginal day that ever matters, it’s like an agreement “we commit suicide the day after the number of blue eyed people we see”. The non blue eyed survive because they always see one more!")#linebreak()#text(" I would love to hear back from you if this helped 😊")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51427")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Oh, I see Ravi just came to the same conclusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d77f1e53260cc0b7ca7e5ac49aa39b8627d6290d26f9c93decf949838c67ab6d-221ffb645d2c9f0a98ae5a0d4ff39caf9fd44c580b0795cd48ec752343dc58c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of X9")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51432")[#strong[#text("X9")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Ok, here’s the correct (or best) version;")

#text("In a room there are 10 Fields Medal winners. All are fully functioning and none has caught Alzheimer’s yet. They all were hats of different colors but can not tell the color of their own hat. Communication leads to disqualification in the contest and there is a prize of 1million$ for first correct answer (no, Grigory Perelman is not competing). Every two minutes a bell rings that indicates possibility for an answer. At first no one makes an attempt of answering but then Randall Munroe shows up (as surprise guest) wearing a green hat stating- ‘one of your hats is blue’ etc.")

#text("Here comes the questions; for what distribution of hat colors will the problem be solved (and in what time)? And for what distributions will it not be solved? Again good luck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d11933e2f2cf9ad6a41b4151cd5b8d19da2789598308e0887ec835bc2feecf8-8127916497ad541035f555aa1ee5fbdfb4b9030239c49422806c54d8d9c4f298.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Filipe")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51434")[#strong[#text("Filipe")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Dear Prof. Tao,")

#text("If your conclusion, it will mean the suicide of the entire tribe. If all blue-eyed people suicide themselves on the 100th day after the speech, then the rest of the islanders will know they are brown-eyed, so they are forced to commit suicide the day after.")

#text("Greetings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51436")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Let BEP = blue-eyed person. My conclusion is that solution 2 is flawed.")

#text("The mere number of BEPs in the system does not determine whether they commit suicide or not on a given day. This also depends on what their knowledge is on the particular day. Your proposition in solution 2 therefore needs to be more explicit, e.g., as follows.")#linebreak()#text(" If there are n BEPs who know, on day n that there are n BEPs, they commit suicide on day n.")

#text("Now let us go through your proof. Case trivial for n=1. Assume it is true for n-1 and consider n. A BEP x knows that there are at least n-1 BEPs. x also knows that another BEP (y) knows that there are at least n-2 BEPs – x can be sure of only those BEPs that both him and y can see. So x conjectures “if there are at least n-1 BEPs and on day n-1, all know that there are n-1 BEPs, they would commit suicide.” After n-1 days. no one commits suicide. At this stage all that x can conclude is that *either* the another BEP y does not know that there are n-1 BEPs *or* that there are indeed n BEPs in the system. Your proof skips the former case. I don’t see how x can conclude that y does know that there are n-1 BEPs in the system.")

#text("You are implicitly assuming that because a BEP x knows that there are at least n-1 BEPs in the system, that all other BEPs also know that there are n-1 BEPs in the system. This “symmetry” argument is valid for an external observer, not for the BEP x.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09594084cbbfc6dc1ce6f8901ffc2ee57b2b24f483606271bb21813185180487-9c0b970af6fd8fac7939d9d8d742f7d6fde5a25ea776b21654acf57cb75e96d3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51439")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("But doesn’t BEP y know, being the logical BEP that s/he is, that since no one killed themselves after n-2 days, that there must be at least n-1 BEPs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51442")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Let us see what information BEP x has about BEP y’s knowledge. BEP x knows that BEP y knows there are at least n-2 BEPs in the system. Now if these n-2 did not commit suicide, then BEP x knows that BEP y knows that either these n-2 BEPs do not know that there there are n-2 BEPs or (BEP x knows that BEP y knows) that there are indeed n-1 BEPs.")

#text("Again we run into the same problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51445")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Greg, see Prof Tao’s latest buzz.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51484")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("I take this back. I have not used the foreigner’s intervention. The above argument can be extended further to eventually come to a stage where no BEP can be sure that everyone knows that there is at least one BEP.")

#text("Austin’s comment here: ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-51447")[#text("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-51447")]#linebreak()#text(" shows that the foreigner’s comment supplies every BEP with this information. Thus the induction goes through.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51438")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("After the announcement, for:")

#text("n = 1")#linebreak()#text(" Trivial")

#text("n = 2")#linebreak()#text(" – B1 and B2 both know that N(BEP)>= 1")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/420a2ed1879f158a241d4cc6edeb28763b08e1ee55686d34f228e40e29a3452b-14190677cd954e547da6d419db6f0c9ee9e0bc0ab6752ed819143102a7db2fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51440")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("– If the equality was to hold, that is, if there was only one BEP, B1 or B2 would know. But after one day when they are both alive, they figure that there has to be one more.")#linebreak()#text(" – Since they can see that everyone else has brown eyes, it’s easy to figure out that it is them")

#text("n = 3")#linebreak()#text(" – From B3’s point of view, if n = 2, then B1 and B2 would be dead by day 3")#linebreak()#text(" – Since they are not, there has to be one more BEP, and since he can see that everyone else is Brown, he figures out that it is him.")

#text("n = 4")#linebreak()#text(" – From B4’s point of view, if n = 3,……")

#text("This can be extended for any n, I guess. So the induction seems to be correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51470")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Except they aren’t all neatly numbered BEP 1 through 100. There is no one in the tribe who will think, “Hey, there’s only one person I can see with blue eyes so if he doesn’t kill himself, I’d better,” because they can ALL see 99 blue eyes, and they know that those people all see at least 98 people.")

#text("So if we arbitrarily assign one guy number 2, he can see that BEP1 has blue eyes, but he also sees BEP3, BEP4, BEP5 through BEP 99 all have blue eyes, too. And he knows number one can see those guys.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51443")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("But Bi does not know that Bj knows that N(BEP) >=1. Bi only knows that Bj knows that N(BEP) >=0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ebba1723dd969f927d291988c79f7254f66c6cbcd3518339e969620b9e8e1a-84fc98bead1eaa1265cfe6cd9fdc9ac24bcc4f9132b396dee305d9363a4c833d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51452")[#strong[#text("Hao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("(I’m slowly coming around to the second solution)")

#text("But to answer your (implied) question: “But Bi does not know that Bj knows that N(BEP) >=1. Bi only knows that Bj knows that N(BEP) >=0.”")

#text("That is precisely the point. The information given by the foreigner now informs Bi that Bj knows that N(BEP) >= 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51483")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Thanks. That’s right.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4e285ed574f264c86eea7d4fb5ba18f559c335aed51327721c9e1134b5fc601-531a3d0b38b3913da79dd1502eb89c40181ec3243ef52d31a1f0bd59d33342c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Literalman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51441")[#strong[#text("Literalman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Consider two slightly different propositions:")

#text("P1. Suppose that the tribe had n blue-eyed people for some positive integer n. Then n days after the traveller’s address, all n blue-eyed people commit suicide. (This is the original proposition).")

#text("P2. Suppose that the tribe had n blue-eyed people for some positive integer n. Then no longer than n days after the traveller’s address, all n blue-eyed people will have committed suicide.")

#text("Isn’t the supplied proof a proof of P2 rather than P1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51444")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Yes, this is a good point! It is in fact a moderately challenging exercise to show that, assuming a “blank slate” initial state in which the islanders initially know nothing about eye colour beyond what they can see from direct observation (and making the idealised assumption that there are no other causes of death or incapacitation among the islanders), that one can strengthen the proof of P2 to a proof of P1. (The key here is to introduce the concept of a possible world from modal logic; basically, if one can imagine a self-consistent world in which X is false but which is compatible with all current knowledge about the world, then one cannot know for certain that X is true.)")

#text("[This illustrates the more general principle, by the way, that lower bounds are often substantially harder to establish than upper bounds, when it comes to estimating the time at which a certain piece of knowledge becomes available.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4e285ed574f264c86eea7d4fb5ba18f559c335aed51327721c9e1134b5fc601-531a3d0b38b3913da79dd1502eb89c40181ec3243ef52d31a1f0bd59d33342c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Literalman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51554")[#strong[#text("Literalman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("Sometimes, though, it’s the upper bounds that are difficult. For instance, it would be mass murder if you were to have been the visitor to the island and said: “if RH is true, then I see at least one BEP”. But what would the moral standing for you to say: “if P=NP, then I see at least one BEP”. Of course, that would be far reckless than “if P!=NP, then I see at least one BEP” :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4e285ed574f264c86eea7d4fb5ba18f559c335aed51327721c9e1134b5fc601-531a3d0b38b3913da79dd1502eb89c40181ec3243ef52d31a1f0bd59d33342c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Literalman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51559")[#strong[#text("Literalman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("Oops…meant to write that it would be more reckless to say “if P!=NP, then I see at least one BEP”!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4311c5db086f89615351f4ffe1743fbe198890e09b42de6cd4130eb0edd9bd2-6ee0af59120128670a2e8c3ed7523195f89d8c64d4c6e2221dbbadf6442da214.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quoting a comment from 2010 clarifying the P1 vs P2 question")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51770")[#strong[#text("Quoting a comment from 2010 clarifying the P1 vs P2 question")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")])]

#text("[from 24 June 2010 of the old thread. Reposting because the link-to-comment URL provided by WordPress doesn’t actually point to that comment and it would be difficult to locate the content otherwise.]")

#text("“The induction argument gives an upper bound for the number of days by which those with blue eyes can determine their eye color. However, it does not explicitly rule out the possibility of more efficient reasoning that reaches the same conclusion on an earlier day.")

#text("Formalizing the argument in (e.g.) modal logic would bound the reasoning power of the islanders and thus permit solid conclusions about what deductions CANNOT happen within N days, for each N. But this would require a completeness proof, i.e., a clear and convincing argument that whatever logical formalism is used correctly captures all possible “information” and “conclusions” available to the logicians on the island.")#linebreak()#text(" Possibly Aumann’s approach is clearly general enough to encompass this, but again, it may contain hidden assumptions as to what the islanders can and cannot reason about.")

#text("To see the difficulty, think about what if the visitor had made a higher-order statement such as “in the first draft of my speech, there were comments that, had I made them, would have certainly caused suicides within 100 days; but luckily, I noticed this in time to strike the comments from the speech I am now making!”. One needs a way of capturing not only the logic that the islanders can perform in a given logical system but a way of seeing that the system analyzed is as strong as possible. ”")

#text("[the proof of completeness would be closely related to the “possible world” semantics that Terry mentioned. I don’t know how it would work for higher order modal logics or if these are in fact complete. Aumann refers to Robert Aumann’s paper on “agreeing to disagree” where he establishes a semantics for reasoning about common knowledge.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7550131d7ae9a1fb21c1d6961c9740f4ff4e5dd8420e57103000bd5a728911ff-c76459d9ffe266c6fd9addaf3788da242c4f49c4add79861db3e462f28319126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xenaproject")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-492148")[#strong[#text("xenaproject")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("My student Chris Hughes noticed this issue when formalising this question in Lean, a formal proof verification system. He felt that when formalising the problem he has to say quite precisely how people were allowed to deduce new information as time went on, and he was not sure that his formalisation covered every possible scenario. He then proved by induction that the blue-eyed islanders would kill themselves *by* (but not necessarily on) day 100, and then he had to work much harder to prove that they would survive for that long **in his formalisation of the problem**.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ebba1723dd969f927d291988c79f7254f66c6cbcd3518339e969620b9e8e1a-84fc98bead1eaa1265cfe6cd9fdc9ac24bcc4f9132b396dee305d9363a4c833d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51446")[#strong[#text("Hao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("I will reword the proposition slightly: “Suppose that the tribe has EXACTLY n blue-eyed people for some positive integer n. Then n days after the traveller’s address, all n blue-eyed people commit suicide.”")

#text("The proposition is true for n = 1 (base case).")#linebreak()#text(" For induction, we need to show that proposition being true for (n=i) implies the proposition being true for (n=i+1). However, if the proposition is true for (n=i), it cannot be true for (n=i+1), because the tribe has a constant number of blue-eyed people.")

#text("The alternative form of the proposition without “exactly” (Suppose that the tribe has at least n blue-eyed people for some positive integer n. Then n days after the traveller’s address, all n blue-eyed people commit suicide.) fails because it isn’t true for n=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e81895dc8e94123aa09402dff172586a1fa3436d9897ece23b267bac23a65977-f853c5062d9a251aab993476d2bb80d05cbf349a3b31cae92019a5e88e0a1eb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Austin")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51447")[#strong[#text("Austin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Here is the precise reason Solution 1 is wrong.")

#text("The foreigner’s faux pas DOES tell each tribesman something he did not know: namely, that everybody knows that everybody knows that everybody knows that (…) that everybody knows that someone has blue eyes.")

#text("That statement should include 99 repetitions of the phrase “that everybody knows”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e81895dc8e94123aa09402dff172586a1fa3436d9897ece23b267bac23a65977-f853c5062d9a251aab993476d2bb80d05cbf349a3b31cae92019a5e88e0a1eb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Austin")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51448")[#strong[#text("Austin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("(In fact, the foreigner doesn’t just make this statement known to everyone — he makes it true!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e81895dc8e94123aa09402dff172586a1fa3436d9897ece23b267bac23a65977-f853c5062d9a251aab993476d2bb80d05cbf349a3b31cae92019a5e88e0a1eb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Austin")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51449")[#strong[#text("Austin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("No, I take my second comment back (I stand by the first).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dac95bcff7013d5512fbc8af56700cbdaaf200608c2d05093a0fae89dd3c7205-63a227c28fe67c4e070337f741d2321f0b21a1c9902a9c988d600b94d0894e74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51451")[#strong[#text("Manuel")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("That’s exact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6df35e99bc4f33f9a5a914622651acb4ce1ce8ca7c3d4defac6fa6cca93db750-718a252ccd16565f33eec0587ed0a5cca34ba82ee7ab1e14cbe70e8a3dc642e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51454")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("99 instances (98 repetitions), yes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51486")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Shouldn’t it be infinitely many repetitions? The repetitions count the “levels of knowing”, in other words, knowing an increasing hierarchy of things. I don’t think the number of repetitions should depend on the number of BEP.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-52642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2011")])]

#text("The number of levels of knowing does depend on the number of BEPs. Consider n=1: brown eyed person B knows that there exists a blue eyed person (person A), but he does not know if everyone knows it: in fact, the blue eyed person does not know, but if B were blue eyed, then A would know that there existed a blue eyed person. Now n=2: BrEP1 knows that there is a BEP, and knows that everyone knows, but cannot deduce whether everyone knows that everyone knows that everyone knows, since he does not know his own eye color.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47d5c69d29b66fd3a1a778d648747c9bb6e8c4f0725b0ce1d22f858fe2ef1229-23e4762dee579d79ee766c8f389cceee8fe6155c335cc87100d79b6dfe9bb027.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Sextistics")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51450")[#strong[#text("Dr. Sextistics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("This sounds a lot like Curry’s Paradox.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rebelJinnee")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51455")[#strong[#text("rebelJinnee")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Question: have the islanders been co-existing more than 100 days before the stranger’s arrival on the island?")#linebreak()#text(" =========================")

#text("Additional information for solution 2:")

#text("— from a brown-eyed person’s perspective —")

#text("How does a brown-eyed person reason when n is 2?")#linebreak()#text(" S/he sees that there are n blue-eyed persons and reasons as follows")

#text("“If I am brown-eyed, then there are n blue-eyed people on this island, and so they will all commit suicide n days after the traveler’s address; if no such suicides take place on the nth day, then I must be blue-eyed (n + 1 blue-eyed persons) and must therefore commit suicide on the n+1th day”")#linebreak()#text(" Or more succintly, reasoned a brown-eyed person,")#linebreak()#text(" “I know I am blue-eyed if no suicides take place on the nth day”")

#text("— from a blue-eyed person’s perspective —")

#text("A blue-eyed person will arrive at the conclusion that h/er eye color is blue when no suicides take place on the n-1th day.")#linebreak()#text(" example: let n = 2 and b1 & b2 be the 2 blue-eyed persons.")#linebreak()#text(" b1 sees b2’s blue eyes and reasons: “b2 didn’t commit suicide after 1 day because b2 saw a blue-eyed person and that blue-eyed person must be me (b1) since I can see everyone’s eye color is brown except for b2’s” (if b2 didn’t see another blue-eyed person, b2 would have committed suicide")#linebreak()#text(" on n-1th day after the foreigner’s revelation)..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rebelJinnee")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51456")[#strong[#text("rebelJinnee")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Another way of looking at solution 2:")

#text("———————— from an islander’s perspective ————————")

#text("Let I be one of the 1000 islanders (not the foreigner).")

#text("If I sees m blue-eyed persons, I will wait until the mth day to see if suicides")#linebreak()#text(" take place: if they do, I lives; otherwise, I commits suicide on the m+1th day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/140d3f6c9518c62f161c6bb20e5607a0014114e85a42110fe14f866907f11501-b369885225bbc264053d931d696979713be8f60191fd2d1aeb63b48d72d78e40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DSchwab")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51457")[#strong[#text("DSchwab")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Terry,")

#text("Isn’t it possible for the islanders to avoid the outcome of solution 2 by simply agreeing not to commit suicide for the subsequent 1000 days? (Or any number > 100, but every islander knows the total population, so that’s a natural choice.) This way they erase the trigger, there is no information gained when there are no suicides on day 99, and nobody learns their eye color. (Presumably they had to do this following the invention of their religion or they’d have had the same issue and would be dead already.) I suppose you could argue that this is “talking about” the eye color issue, but perhaps a logical actor with a desire to live would develop this strategy independently and assume that all others have as well. Also, note that this only works if there is more than one blue eyed person.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46b04e1650d7b43335b1dd3c5319394fdf7359dc872c7a590ad1126bb73145b5-122d3e59ec0c4279a25bfca641ea6e66e3b1c77ecbd09e55459470f26362a891.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo Cantos")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-54005")[#strong[#text("Marcelo Cantos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("That’s against their religion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff683e403600893e97e2053cfb59fa763fb7080cd8e5b70348b4f9b96e5e9368-b656edfdf9621c33df2c4a975c51e40540531fef6297209b9fe64e84d1385d33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of keith")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51459")[#strong[#text("keith")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("I feel the validity of the proposition, during the process of induction, has not been proved right yet. Therefore people there could not know this proposition itself, which means they could not know “and so they will all commit suicide n-1 days after the traveler’s address”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7316de9ae1cd575ab5bb413982635608633b98831c79d33d909b0dccc8c93801-2a153a02029e920dafa2068cc330495371df925fe843ebc4e53d3b1660e0b297.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Brown Kramer")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51460")[#strong[#text("Josh Brown Kramer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("There is a very general version of this puzzle in “Mathematical Mind Benders” by Peter Winkler. There are only two eye colors, and the visitor can say ANYTHING nontrivial about the number of blue eyes, TRUE or FALSE, and everyone still ends up dead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14edd5f7267cad5b81aebd6cae64f060134e6e888e644b615be92d7ecf275e76-d55cd207e74ed585b6d214f13743e0aaa1a5f6791d5058560f59d46723868b24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deniz")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51463")[#strong[#text("Deniz")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("On the 100th day, if blue-eyed people fail to commit suicide, the next day, all brown-eyed people will commit suicide, thinking they’re blue eyed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5f1ea9aaf5770236e5ea9a5f2edba7f270e5b6e181f68fe9b321031f83faeb3-2eae4d578f52a51141d7ff70241081f397b487b6d76809b7338bfd9146da07ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peli Grietzer")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51464")[#strong[#text("Peli Grietzer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Unless I’m confused, I think the following demonstrates the significance of the foreigner’s announcement:")

#text("In a simplified case with three blue eyed islanders (let’s call them B1, B2, B3), prior to the foreigner’s anouncement B1 believe that if B1 does not have blue eyes then there are only two blue eyed islanders, one of whom is B2 who (in that scenario) believes that if B2 does not have blue eyes then there is only one blue eyed islander, B3, who (in that scenario) believes that if B3 does not have blue eyes then there are *no* blue eyed islanders. Thus, B1 believes that if B1 does not have blue eyes, then B2 believes that if B2 does not have blue eyes then B3 will commit suicide *upon learning from the foreigner that there is at least one blue eyed islander*. Now, on the morning of the second day after the announcement B1 can reason: if B1 does not have blue eyes and B3 did not commit suicide on the first day, then B2 now learns that B3 knows of a blue eyed islander that’s not B3 and (in that scenario) B2 will conclude that B2 has blue eyes and commit suicide at noon. When noon of the second day comes and B2 does not commit suicide, B1 learns that B1 has blue eyes. B1 then commits suicide. (The same applies to B2 and B3.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7bd129d9c2fa31d8b8a2487eb05d30f650ac777db10eea48e060c86054533d5-b357f2729df7716e7b5efd2a1f7fc2c2f7be44199bfcd4a50fe2a6c07f96856c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51472")[#strong[#text("Stijn")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("The fact that the visitor discusses the topic introduces a starting point, where everyone will reflect on the problem at the same time. This starts the induction process. Broaching the topic was taboo; the visitor changes this and by doing so synchronises the population.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc1887d4cacd2d60568271147d4dbab585d75c7fd10eb2e3aa04ec5df149ea47-170c09a0035cea557949b6a0d2feabc8bd6f42d5cea5f260608734b0f5935cec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bryce")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51474")[#strong[#text("Bryce")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Putting in the perspective of what an islander knows helps show the induction for me:")

#text("If I am an islander and I see n blue eyed people there are two cases:")

#text("I am also blue eyed, therefore the n blue eyed people I see also see n blue eyed people.")

#text("I am not blue eyed, therefore the n blue eyed people I see only see n-1 blue eyed people.")

#text("Expanding on the “I am not blue eyed” case:")

#text("The n blue eyed people see n-1 blue eyed people, so they know that there is either n blue eyed people, or there is n-1 blue eyed people who see n-2 blue eyed people.")

#text("So, this means this is a proof by contradiction with induction, which is why I’ve had so much trouble making intuitive sense of it, even though I completely believe the induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f80866e58c6b6b7a21dcb55e0b3273f56ee04adc55b2f3084acc57d1578ca80-0515460a3b350668403644166129dd0ccea170b476f29ab8014442b6397ba75a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Kunjwal")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51475")[#strong[#text("Ravi Kunjwal")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Ok, I retract my earlier comment. Solution 2 works. If, say, N=2, then each blue-eyed guy waits for one day, secure in the knowledge that there is at least one other blue-eyed guy who must kill himself if he is the only one blue-eyed, because he knows the fact that there is at least one blue-eyed guy in the tribe. But the other guy doesn’t. The only reason the other blue-eyed guy won’t kill himself, the first guy reasons, is because he knows at least one other guy who has blue eyes. Now all the other tribesmen have brown eyes, the other guy has blue eyes, so he himself must be blue-eyed to explain why the other blue-eyed guy did not kill himself. The other blue-eyed guy reasons exactly like this. Both of them kill themselves on the 2nd day.")

#text("The fact that everyone knows that everyone else knows there is at least one blue-eyed guy (“common knowledge”) is the key to see why the argument by induction works. At first glance, it wasn’t clear to me why it worked. After reading the wiki article on “common knowledge” it became clear that I was ignoring the fact that the blue-eyed guys – being logical – would reason why the other blue-eyed guys did not commit suicide, taking into account the fact that they share “common knowledge” – that everyone knows that there is at least one other blue-eyed guy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51488")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Yes indeed. See my comment to my comment here: ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-51484")[#text("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-51484")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81bef7ff5921b71e3dc79bff9fc605a80f6370c194b0b25d5b2323b50005fc25-14a6bb848bde07e68d459c1e859dd0c5809bb53d17046a2172fe4be884662cc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akashnil Dutta")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51478")[#strong[#text("Akashnil Dutta")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Solution 2 is correct.")

#text("Proof:")

#text("Whatever be the thought process of each person, his actions is defined by an algorithm f of the following form:")

#text("f:O->A where O is the set of all observations till some day and A is the set of actions, {commit suicide today, don’t}. A sample element of O would be “The address by the foreigner was made 3 days ago, and I see no suicides till now, I have always seen the following eye colors, 100 blue, 899 brown” etc.")

#text("Now each person, being completely logical, will make the following analysis:")

#text("Since everyone is completely logical, everyone follows a logical algorithm. Let the set of all logical algorithms be F*")

#text("any F in F* should have the following property P:")#linebreak()#text(" For all x in O, F(x)=suicide iff the following statement is true: “If everyone follows some algorithm in F* (not necessarily same), there is a unique eye color possible for the person committing suicide (or not) for which x is a consistent observation”.")

#text("Now, consider the first day. It is clear that F(x)=suicide iff x does not include a blue.")#linebreak()#text(" Inductively, if x is a second-day observation, F(x) can also be completely determined for all possible second-day observations and so forth. Hence indeed F is unique, and F* has only one element.")

#text("Now, everyone being completely logical will conclude that there exists this unique algorithm satisfying property P and act according to it.")

#text("At first glance, it may appear that the algorithm given is solution 1 (never commit suicide in any cases), also satisfies P. But, on closer look, it is not a complete algorithm, it does not say what should be the action corresponding to “no blue eyes seen on day of address by foreigner”. Nor can it be extended to include trivial cases of n=1 to satisfy P completely, because there exist an unique F satisfying P, as proved earlier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f561afd3051bf53c04daba66d6d1357e1dd010925e7c6c8fb75a078914ee92f-0d5daa750df2ef867bf949507442f03ef229ca1771f11330558cc554049ccf1f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of n00b")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51479")[#strong[#text("n00b")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Solution 2 looks ok, but I am not able to understand how the foreigner’s comment can act as trigger?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51487")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Wouldn’t they have all committed suicide before the guy even shows up?")

#text("The guy plants the idea “Everyone else knows there is a blue eyed person, and they know that everybody else knows that, too”, but isn’t the idea already in everyone’s head before he even shows up?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff783f669b34ae7b9a2c63d9f1cd4bfcc77a4944a17bbb00ab5a672e4683906-86eb7013d6869036d137b4496ba551fef9ddbed2a044a0c83aa045fc3f115886.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51491")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("No. No BEP knows that every BEP knows that there is at least one BEP. The foreigner’s comment provides this information. See Austin’s comment and my comments aboves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51522")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("Yes they do, because they see that Alice sees at least 98 BEPS, Bob sees at least 98 BEPS, Carol sees at least 98 BEPS, Dan sees at least 98 BEPS… they know that every blue eyed person knows that there are at least 98 BEPS… not just 1!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ankur")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51525")[#strong[#text("Ankur")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("But they don’t know that Alice knows that Bob sees 98 BEPs.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fab902e4d97ea9450319014d0f9406bef86e32d05083ab288955970c3d7c7430-e6270d0664b30d00782b08dd65c92c0430e06a33f496d738b3375bc5ececeeef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51823")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2011")])]

#text("yes they do. Or rather they know that Alice knows that Bob sees at least 97 BEP, that is to say they (lets call them Sharon) know that Alice does not know her own eye color but that she can see some number of BEP’s greater than 1 and that the forigner could have been talking about any one of those persons. ALL the islanders already know that there are at least 99 and no more than 100 BEP’s on the island, the forigner does not add any new information by stating that there is at lesat one. No one seems to address this issue directly in these comments, they just jump on the induction train, but that is the whole problem, the islanders already know that there ISN’T some n of BEP’s where n is an integer, there is some n where n is either 99 or 100, and you cant get there from here.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51490")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Though I’m still optimistic… I mean, say I’m the 100th person. I assume I’m brown eyed, look around and think, “Alice thinks there are only 98 people, and that Bob thinks there are only 97 people and that Bob thinks Carol thinks there are only 96 people. But I know that Bob doesn’t think there are only 97 people, because I can see that Alice has blue eyes, so I know he thinks that there are 98 people with blue eyes, and that Carol also thinks that, so there for NO ONE thinks there are only 2 people, thus I have no idea what color my eyes are”.")

#text("Hopefully the visitor is a missionary who has come to convert them to some religion not involving ritual suicide. Though of course the idea that knowledge=death is hardly exclusive to the suicidal eye color tribe.")

#text("Also, I think we can eliminate other eye colors as a possibility, because in a tribe of 1000 they must be so inbred that any other recessive eyecolors would have shown up a bit more often.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("“It is probably the n=3 case (three blue-eyed people) which causes the first major conceptual difficulty, in which common knowledge separates from both first-order and second-order knowledge. As pointed out above, in this case the three blue-eyed people all know that there is at least one blue-eyed person, and they know that everyone else knows this also… but they don’t know that everyone else knows that everyone else knows this, until the foreigner speaks. The remarkable thing about the puzzle, to me, is how such a subtle and seemingly academic change in the knowledge environment eventually propagates to have a concrete and dramatic effect.” By Tao, Feb 8,2008.")

#text("Why “they don’t know that everyone else knows that everyone else knows this”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4e285ed574f264c86eea7d4fb5ba18f559c335aed51327721c9e1134b5fc601-531a3d0b38b3913da79dd1502eb89c40181ec3243ef52d31a1f0bd59d33342c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Literalman")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51495")[#strong[#text("Literalman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Re: Why “they don’t know that everyone else knows that everyone else knows this”?")

#text("Answer: they don’t know that everyone else knows … that everyone else knows until he speaks because it’s not true until he speaks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96fd40d11ae5a50977c6fc6e265bd84ef72523945ad8707d32d35bb160569bff-40b4d1b77d584ccbfa54a4abc537483093714fb235e4e17f8fd02b2842ceb709.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole Krieger")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51521")[#strong[#text("Nicole Krieger")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("It is true, they can see 99 blue eyed folks and they know that everyone else sees at least 98 blue-eyed folks and that the other people all know that the other people can see more than 1 blue-eyed person. The thought is already in their mind.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51498")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Consider the logic necessary for 3 blue-eyed people: one blue might suppose that he does not have blue eyes (I will refer to this as the exterior supposition). Then he might look at a second blue guy, and think – what if he supposes that he does not have blue eyes (the interior supposition)? Then the second blue guy might, in this hypothetical (recall that this is all the first guy’s thought process), ask about the 3rd blue guy – the 3rd guy would be the only one with blue eyes. So on the second day, when the 2nd guy sees the 3rd alive, his thought process would lead to a contradiction, so now he knows that he has blue eyes. On the third day, the first guy’s thought process lead to a contradiction, and so he knows that he has blue eyes.")

#text("This is symmetric, and so all three blues arrive at the same conclusion and are dead by the 4th day. So it is necessary that ‘they know that everyone else knows that everyone else knows’ that someone has blue eyes. Otherwise, there is nothing wrong with that last person (in the hypothetical) to assume he actually has brown eyes too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a190795d80e8c530d4a698e6be06bac867e32eed945b944b9cc603f8f83754-717d77f039a97e939bab0746ac8ac93e3d6f29dd80ba56d28d6bf76de4a9939f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of none")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51496")[#strong[#text("none")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“highly logical” means that any conclusion that can logically deduced from the information and observations available to an islander, will automatically be known to that islander.")
]

#text("You mean I can show an islander some source code and ask whether the program halts, and if the answer is “yes” they can tell me that right away, but if it’s “no” then they might have to say “I don’t know”? Of course that’s illogical all by itself, for well-known reasons ;-).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7550131d7ae9a1fb21c1d6961c9740f4ff4e5dd8420e57103000bd5a728911ff-c76459d9ffe266c6fd9addaf3788da242c4f49c4add79861db3e462f28319126.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xenaproject")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-492149")[#strong[#text("xenaproject")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2018")])]

#text("This is an interesting point! When Chris Hughes formalised the problem in Lean, he used only constructive mathematics rather than classical logic. In particular the Islanders were not able to use the truth of any fact which was true but not provable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51497")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("The problem here occurs in the form “If X, then Y”.")

#text("If Y is an unprovable statement, there is no statement X in that system such that X is equivalent to the implication (X → Y).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51499")[#strong[#text("Blue Eyes and Brown Eyes « mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")]

#text("[…] bring it up now because it has raised a lot of ruckus at Terry Tao’s blog. It doesn’t seem so peculiar to me, but the literally hundreds of comments at Terry’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51514")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("I didn’t read all of the above, just a few. Apologies to anyone who already")#linebreak()#text(" said what I said. Isn’t the answer that nothng would happen in that scenario.")#linebreak()#text(" The fault seems to be in the induction hypothesis. If there")#linebreak()#text(" were 3 islanders to start with, there are two potential scenarios.")#linebreak()#text(" Two or three of them have blue eyes, in which case the outsider tells none")#linebreak()#text(" of them anything they didn’t know before-they all knew there")#linebreak()#text(" was at least one blue-eyed islander.")

#text("Or only one of them has blue eyes. In that case, the outsider has told")#linebreak()#text(" the person with blue eyes something he didn’t know before, but has")#linebreak()#text(" not told the other two anything new. In this (catastrophic) scenario,")#linebreak()#text(" the blue eyed person will commit suicide. As to what happens")#linebreak()#text(" the following day, I’m not sure the problem is so well-defined.")#linebreak()#text(" If they all know that there are only two possible colours,")#linebreak()#text(" then the other two should commit suicide (at least if their")#linebreak()#text(" brains are wired the same way as mine)- they should be")#linebreak()#text(" able to figure out that if only one person has disappeared,")#linebreak()#text(" the rest of them have non-blue eyes. So if they know there")#linebreak()#text(" is only one other colour available, they can figure out their")#linebreak()#text(" own eye colour, and then must kill themselves.")#linebreak()#text(" But as the problem is stated, it is not clear to me that they have")#linebreak()#text(" any reason to know there is only one colour than blue")#linebreak()#text(" available. A given islander might have green eyes for all he knows.")

#text("So, back to the original question. Nothing happens. The reuslt generalizes:")#linebreak()#text(" if there are n islanders, and only one is blue eyed, he will kill himself.")#linebreak()#text(" If there is more than one blue eyed islander, no one will")#linebreak()#text(" kill themselves. The start of the “induction” is atypical and misleading, and")#linebreak()#text(" this is why the second argument is fallacious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b88821198befda666950a42d9d2a87e1ba9ceefee1dc4d1e4702f46fe56b4fa1-5ba760f14efbc551ca829bcacf153efc4f204dbef0a9f8f34557baf9ad22ef3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boobs")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51516")[#strong[#text("boobs")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("The starting point is impossible. The scenario of solution 2 would have been played out already (when the law was first declared), killing everyone. Since the starting point is false, you can assign any truth value to situation 1 and 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51523")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("I don’t follow what you mean. Just because the law")#linebreak()#text(" is declared, that didn’t tell anybody for sure what colour their")#linebreak()#text(" own eyes were. Only when extra information comes from")#linebreak()#text(" an outsider is there the possibility that anyone knows")#linebreak()#text(" for sure what colour their own eyes are. And then")#linebreak()#text(" a person can only know for sure that (s)he has blue eyes")#linebreak()#text(" if there is no-one else visible to them who has blue eyes,")#linebreak()#text(" and the outsider has told them that there is someone")#linebreak()#text(" somewhere with blue eyes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51527")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("In my original post, I should have said “nothing happens which was")#linebreak()#text(" not going to happen anyway”, and left everything else out.")#linebreak()#text(" The blue-eyed islanders will all eventually commit suicide, but not necessarily on day 100 after the foreigner’s announcement.")#linebreak()#text(" But maybe the problem is slightly ill-posed.")#linebreak()#text(" The islanders need to have a common starting point from")#linebreak()#text(" which they start counting. Once they have that, they will all")#linebreak()#text(" commit suicide, given that composition of the tribe.")#linebreak()#text(" It may be the intention of the poser of the question to mean")#linebreak()#text(" that the foreigner has now given them a point from")#linebreak()#text(" which to start counting in common which they did not have")#linebreak()#text(" before, in which case the foreigner becomes an agent of the")#linebreak()#text(" collective suicide. But if, like “boobs”, one inteprets the passing of the")#linebreak()#text(" law as a common point from which to start counting,")#linebreak()#text(" then one knows that 99 or less days have passed since")#linebreak()#text(" that time, or else there would be no blue-eyed islanders")#linebreak()#text(" left at that point in any case. But then the pronouncement")#linebreak()#text(" by the foreigner has made no difference to what would")#linebreak()#text(" happen. Maybe this is why the problem is slighly thorny.")#linebreak()#text(" If the foreigner has given anything to the islanders they")#linebreak()#text(" didn’t have before, it is a common frame of reference to")#linebreak()#text(" start counting. Once they have that, then they are doomed.")#linebreak()#text(" But is it really clear that they couldn’t have had a common point")#linebreak()#text(" from which to start counting before the foregner arrived?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51533")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("Even if there were only two people on the island, both with blue eyes, the additional information from the traveller is necessary for them to kill themselves.")

#text("Otherwise, at every point they look around and wonder – hmm, I wonder what eye color I have? They have no certainty of any fact to what they think others think they know.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51534")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("I see what you are saying, and you may (finally) have straightened me out about this. Given the information from the outsider, Person 2 thinks:”If my eyes are not blue, then Person 1 must kill his/her self. But person 1 did not kill his/her self on day 1, therefore my eyes must also be blue.”")#linebreak()#text(" So, if there is only one blue eyed person on the island at the beginning,")#linebreak()#text(" that person gets new information from the foreigner, which")#linebreak()#text(" they must act on. But the fact that no-one acts on day 1 tells")#linebreak()#text(" everybody that there are at least two blue eyed people.")#linebreak()#text(" But then if there are exactly two blue eyed people, they must")#linebreak()#text(" both act on day 2, as they both initially know there are")#linebreak()#text(" either one or two blue-eyed people, and after day one, they know")#linebreak()#text(" it must be two , etc. So the induction argument is correct after all.")#linebreak()#text(" I hope this is the end of it for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51535")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("@Geoff Robinson 9 April 2011 at 2:14")

#text("Exactly right!")

#text("-David Lowry")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/617389d1815d3e9c4e84ca739ca0b21c747114aa89df478e0ac9462ef3fe4cd3-09ae9d97b778f04bb1dc650ff486c29a54d885eb55f15e2fc4d16c3710587d54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob Blake")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51519")[#strong[#text("Rob Blake")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("Assume that each islander realizes the trap the foreigner has placed them in. Assume further that at least one of them is altruistic enough to value the life of his tribe more than himself. He goes to the village center at high noon to commit suicide despite not knowing his eye color. The other tribesman cannot perfectly know why the martyr has committed suicide. Perhaps he knows his eye color, perhaps he does not. Does this break the induction?")

#text("If more than two people decide to adopt this martyr strategy, only the first to arrive at the town’s center need go through with the ritual. The second can simply watch, secretly relieved that they will be able to live another day.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lenoxus")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-199612")[#strong[#text("Lenoxus")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("It’s too bad this is so thumbed down, because it’s basically correct. If N blue-eyed people die on or before Day N, then no one else has to die.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10f3af7edada5142aa5868d089a4b316d3bfa2ec1af4464846597f3ec6748fd3-5f28ddd2c4d2b8886b42b73d8306c2bf572d897a158a21a96b7b08e078faccd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sper")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51532")[#strong[#text("Sper")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("@ Rob Blake: Your comment seems to disregard the second note.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/407a6ea9d20f51d66e19ce220898b5da95f48a5dca0100b8e8224496d8f3e355-0b63cd214dba92ceee81806d1311186579f46fc2c2ce461917a45f30b27a63f3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fun with common knowledge « The Leisure of the Theory Class")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51548")[#strong[#text("Fun with common knowledge « The Leisure of the Theory Class")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")])]

#text("[…] another game theory puzzle, one that is always fun to come across, especially on Terence Tao’s blog. In the version I know the islanders are less devoted to their religion and more jealous of their […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ff41d3b707fef89614acf856972e6068774ab2641c5d31ff7ae43bc1871c0f1-52f5e8a84c11f89fdd547f9d85c12a4bbfd901cf1634f98fe1ebd14c6985bf27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MCF")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51563")[#strong[#text("MCF")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("Online LaTeX Equation Editor:")

#link("http://www.codecogs.com/latex/eqneditor.php")[#text("http://www.codecogs.com/latex/eqneditor.php")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57d55985f832ffd015cb5b432b4755380dc84d4937d2531e656e26e838384674-681bf6cfbee578a616f8cf98af6b6c841ebe06116dbbeb8b282a315b694567fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason T. Miller")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51565")[#strong[#text("Jason T. Miller")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("The second solution seems mostly correct, at least “in the spirit of things.”")

#text("The first solution, on the other hand, is a complete non-starter, because the proposition “the traveller’s comments do not tell the tribe anything that they do not already know” does not follow _at all_ from the fact that “everyone in the tribe can already see that there are several blue-eyed people in their tribe.”")

#text("First, if the “the tribe” were a hive mind, they’d all have offed themselves at the first opportunity upon accepting their hokey religion. So we instead consider")

#text("Proposition A: “For all tribespeople P, there does not exist a fact F such that (a) P does not know the truth value of F before the traveller begins his comments, and (b) P knows the truth value of F immediately after the same.”")

#text("This certainly lacks the “intuitive appeal” of the original formulation, but it seems like a “safer” expression of the idea that P “learns something” from the traveller’s speech. Note also that, by “knows,” I mean “could potentially infer from known data.” The circularity in this statement is quite intentional — the puzzle should clearly not be approached as an epistemology exam, the point is that tribespeople, religious as they may be, do not, by hypothesis, “believe” things. Instead, they are in possession of a certain collection of “true facts” at any given time, and any claims as to their actions must follow deductively from these “facts” and “the rules.”")

#text("Suppose, then, that proposition A is true, let P be a tribesperson, and assume no facts exist satisfying both (a) and (b) for P. First, this means P is indubitably prescient, at least with respect to the traveller’s comments, otherwise he’ll necessarily learn _something_, at the very least that (a) and (b) hold for no facts other than the fact that (a) and (b) hold for no other facts. If this sounds confusing, it should, but it seems to follow quite directly from any reasonable interpretation of “high logicality.”")

#text("In other words, anything P knows immediately afterwards, he knew beforehand, so he cannot _possibly_ learn anything between “immediately before” and “immediately after.” Modulo formalization, this seems to be the only way to exclude various sorts of “higher-order knowledge” without forbidding the very sorts of conclusions we _must_ allow tribespeople to draw from traveller’s comments for a sensible, nontrivial interpretation of the puzzle.")

#text("Since this must be true of all tribespeople, the traveller’s actual comments seem to be largely superfluous. But this is not the case, whence _indubitable_ prescience: everyone must, in fact, know that what they know is/was/will be the case, i.e., that they will learn nothing, including that they have learned nothing, that they know they cannot possibly learn anything.")

#text("And so on. Yet somehow, solution 1 obtains this from the fact that “everyone in the tribe can already see that there are several blue-eyed people in their tribe.” Yet I can only think of a one-word “proof”: obvious.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51588")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("While I understand the logical structure, and apparent inevitability,")#linebreak()#text(" of solution two, I have some issues with the language of the problem.")#linebreak()#text(" The second solution effectively credits all the islanders with the")#linebreak()#text(" ability to extrapolate back to a scenario when one islander would")#linebreak()#text(" have had no choice, and then reconstruct the logically inevitable consequences of that initial lack of choice. I suppose my question is : “is it entirely clear from the pharasing of the problem that this the only logical choice available to them? Do they have to extrapolate back all the way to a time when there is no choice?”")#linebreak()#text(" I would find the following tightening of the first solution")#linebreak()#text(" a little more difficult to refute: “Nothing happens. Each islander is logical")#linebreak()#text(" enough to realise that their own eye colour might be unique on the island,")#linebreak()#text(" and, as things stand at that time, the traveller has given none of them any reason to change that belief”. One can dress up the language further by saying that each islander thinks :”It is indeed fortunate that that traveller did not have the same colour eyes as me, or I would have had no choice but to kill myself. As it stands, I don’t need to do anything, and my 999 logically")#linebreak()#text(" minded friends will see that for themselves too”. One could say that some of the islanders are opting to do nothing on the basis of a false premise, but")#linebreak()#text(" they don’t know for sure that it’s false, and no one has given them any reason to revise that premise.")#linebreak()#text(" Try this with 6 islanders, three brown eyed, and three blue eyed,")#linebreak()#text(" at the time of the time of the traveller’s arrival. Each one thinks")#linebreak()#text(" “My eye colour could be unique here for all I know, and as far as")#linebreak()#text(" anyone else knows, their eye colour could be unique on the island too.")#linebreak()#text(" I happen to know that they are all mistaken in that belief, but they")#linebreak()#text(" do not know that, and nothing the traveller says has corrected their")#linebreak()#text(" belief.” Where then is the need to start extrapolating backwards?")#linebreak()#text(" Each islander knows only that if their eye-colour is unique among")#linebreak()#text(" islanders, it is neither blue nor brown, because each can see at")#linebreak()#text(" least two blue eyed people and at least two brown-eyed people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/281be7783b19061b80e828fa45ca23355bb5518325c611454ba44608a4f9ddad-52ac3d6b087dfc8934e954aa09cbe92d14718bba808607fefd43c23239dd8124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51589")[#strong[#text("Matthew")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("It is a brilliant puzzle and solution;")

#text("i’m not trying to disprove the puzzle, because in good faith it holds; but, I would like to point out something obvious anyway; it’s an island, so they are next to the ocean and water is reflective")

#text("also, one cannot live without water")

#text("/that is all\\")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/281be7783b19061b80e828fa45ca23355bb5518325c611454ba44608a4f9ddad-52ac3d6b087dfc8934e954aa09cbe92d14718bba808607fefd43c23239dd8124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51591")[#strong[#text("Matthew")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#link("http://en.wikipedia.org/wiki/Common_knowledge_(logic)#Example")[#text("http://en.wikipedia.org/wiki/Common_knowledge_(logic)#Example")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/281be7783b19061b80e828fa45ca23355bb5518325c611454ba44608a4f9ddad-52ac3d6b087dfc8934e954aa09cbe92d14718bba808607fefd43c23239dd8124.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51593")[#strong[#text("Matthew")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#link("http://boards.4chan.org/sci/res/2868576#2869058")[#text("http://boards.4chan.org/sci/res/2868576#2869058")]

#text("“Anyway, the reason they kill themselves despite having already known at least one other blue-eyed person exists there is because the mentioning of their eye colour itself is the issue. Regarding the group as a whole, he has declared the existence of a blue eyed person, something that has never actually happened before in their tribe. It is forbidden to mention and therefore all of the blue-eyed tribespeople are condemned at once.”")

#text("a nice moralistic summation, logic aside.")

#text("also, remind me not to join that religion (I’ll be the visitor if I must)")

#text("too much thinking all around; sleeping time")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/006ec46738f9a38b61f4a25e2f9cd3033d0756aed175b00d80eb67bc5d8706e4-b84f3f4f31460aa2e3fa0d033cd3997e5eba7d6e4f97af6fd8b2a0b6a0a5903e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51611")[#strong[#text("Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("There are two relevant things (knowledge) that result from the outsider’s statement:")

#text("1) the color blue is special in the islanders’ thoughts")#linebreak()#text(" 2) the islanders all start considering it at the same time.")

#text("Thing 2 is the indirect and hard to spot thing. (Stijn mentioned it above.) It effectively synchronizes the islanders’ thoughts. The structure of the problem suggests that one label the days with the inductive index n, and the outsider’s faux pas forces every islander to count n=1 on the same day.")

#text("Thing 1 is necessary as well, otherwise the islanders wouldn’t know to which eye color they should relate the counter n. But once the outsider says “blue”, all islanders know there are either 99, 100, or 101 blue-eyed islanders.")

#text("Having both things, the islanders can relate the passage of n suicide-free days to the number of blue-eyed islanders, and the proof by induction applies.")

#text("Had the synchronization not occurred, then no knowledge could be gained from the passage of days. This would be the case for an outsider simply saying the same thing but only to individuals and on different days. This would also describe the state of the tribe before the faux pas.")

#text("Had the eye color not been mentioned, the islanders wouldn’t know which color to count, and there would be nothing to which the passage of days would relate. It’s contrived, but imagine some sort of mass amnesia affecting all islanders. If they all regain their cultural memories on the same day, and they know it, then their counters would synchronize. But there is no danger, because there is no color for them to count.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a5fc7b0e8da67487df210f6ae7f6a092c7b43b58c9c2de503459253c5995d92-84686fe7d7dead39b74910e946054ab341d8618ac94e256e79cc636500ea6c7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pseudonym")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51664")[#strong[#text("Pseudonym")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("The knowledge which is imparted by the foreigner’s statement is subtle, but important. What the islanders don’t know prior to the statement is what the other islanders do and don’t know about each others’ knowledge.")

#text("Everyone on the island knows that there is at least one person with blue eyes. Everyone on the island knows that everyone knows that there is at least one person with blue eyes. Everyone on the island knows that everyone knows that everyone knows that there is at least one person with blue eyes…")

#text("…and so on, ")#emph[#text("but only up to a point")]#text(". Everyone knows up to 99 levels of knowledge about knowledge, ")#emph[#text("but no further")]#text(". By telling everyone that there is at least one blue eyed person on the island, this pushes the bound of knowledge about knowledge as far as you need to go, because everyone heard that statement, and everyone knows that everyone heard that statement, and so on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51665")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("I find this puzzle really uncomfortable. I think I now realise why at a personal level, which may not apply for others: for me, I think it is that the")#linebreak()#text(" problem highlights the difference between “reasonable” behaviour,")#linebreak()#text(" and “strictly logical” behaviour, and the sometimes blurred boundaries")#linebreak()#text(" between them in “normal” experience (ignoring the question of whether")#linebreak()#text(" committing suicide for those reasons is reasonable).")#linebreak()#text(" The following verbalization enabled me to reconcile some of the issues for myself. Assuming that the island was in equilibrium beforehand, the traveller’s announcement has made a difference, but it can be seen as a negative one. Before the announcement, they are logically entitled to be certain that no other islander knows their own eye colour. After the announcement, they are not. Once the")#linebreak()#text(" equilibrium is broken, there is only one way for it to be restored:")#linebreak()#text(" each blue eyed-islander must commit suicide, and then the")#linebreak()#text(" population that remains will be back in equilibrium ( but with one")#linebreak()#text(" less eye-colour).")#linebreak()#text(" Continuing this perspective, each islander might as well regard")#linebreak()#text(" the blue-eyed population (s)he can see as a single organism")#linebreak()#text(" (which is, I suppose, what the second solution effectively does).")#linebreak()#text(" I also found it helpful to think in terms of minutes, rather than days")#linebreak()#text(" (though I know it makes no logical difference). Suppose that")#linebreak()#text(" the rule is that each islander must commit public suicide within")#linebreak()#text(" one minute of discovering their own eye colour, and suppose further")#linebreak()#text(" that each islander has an alarm clock (better be digital!).")#linebreak()#text(" Each islander can then think: ” I can treat the blue-eyed population")#linebreak()#text(" I see as a single entity- I just need to recalibrate what I mean by")#linebreak()#text(" a minute. I see n blue eyed people, so I can treat n “old” minutes")#linebreak()#text(" as one “new” minute. Then I will effectively be in the situation of")#linebreak()#text(" deciding whether there are one or two blue-eyed islanders.")#linebreak()#text(" I’ll set my alarm one “new” minute ahead. If the blue-eyed population")#linebreak()#text(" I see has not disappeared when the alarm goes off, then I’m")#linebreak()#text(" in the “two blue eyed islander situation”, and must commit suicide myself.”")#linebreak()#text(" (If the islander can see no blue-eyed population to start with,")#linebreak()#text(" they must commit suicide anyway, given the announcement).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51717")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("I really hope that this is my last comment on this problem. I am sure")#linebreak()#text(" that I am not alone in that hope. One flippant")#linebreak()#text(" remark is that to find the purely logical solution to the question, it")#linebreak()#text(" helps to “become part of the problem, not part of the solution”")#linebreak()#text(" (where have I heard that before?). Imagine that through some quirk of")#linebreak()#text(" fate you have forgotten your own eye colour, and been sent to the island")#linebreak()#text(" to recuperate. Then credit the other islanders with being able to reason")#linebreak()#text(" the same way you can.")#linebreak()#text(" Another (perhaps obvious to many) comment is that, once one moves away from the “idealized” problem, there is a quantitative element to the distinction between what is reasonable and what is logical. Everyone would ( I think) agree that if there was only one blue-eyed islander, then it would be both unreasonable and illogical for that islander not to act on the information")#linebreak()#text(" imparted by the traveller. However, suppose that, instead of an island,")#linebreak()#text(" you translate the problem to a city of 300000 inhabitants, of whom")#linebreak()#text(" 100000 are blue-eyed. It might be illogical for all the islanders to")#linebreak()#text(" ignore the traveller’s announcement, but it would be entirely unreasonable")#linebreak()#text(" for any of them to bother to start counting days (assuming they had")#linebreak()#text(" anything like a normal human lifespan) , since in any case any one of them would die before they could ascertain their own eye colour")#linebreak()#text(" (I know this contravenes note two, and I know that if you start to go down this route, you have to start modelling for the fact that some of the population will die of natural causes in the meantime, etc, which would")#linebreak()#text(" probably become intractibly difficult. However, it does illustrate a point).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0659608088505c5677b170e90421ced9737d171bcc32239f19e7827190c1c2af-1c6b711b76dee7b55df940736e4bea27e3d4acbcdae408a51933f027cf071ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilkhom")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51725")[#strong[#text("Ilkhom")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Agree. This is becoming a question of policy – do they really want to know something, if they are going to die after learning it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51730")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Going down this line of thinking ruins the logical appeal of the puzzle. It seems to give people enough trouble without layering additional levels of difficulty on top of the problem.")

#text("David")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508ae2ed45486efb59de4206a318c9eb3ecf5483a3c7973f3bd27e16cf46be04-8f53d07981235c4b0b59e392b68cf9ec7445aeeeeeb84fa1b007b28806a52014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Geoff Robinson")]], [#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/comment-page-1/#comment-51748")[#strong[#text("Geoff Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")])]

#text("If you were responding to my comment you are certainly right. I do")#linebreak()#text(" understand that one is looking at a totally different problem, but I was")#linebreak()#text(" trying to reconcile the (for me) counterintuitive nature of the logical answer")#linebreak()#text(" by analysing the difference between what is reasonable and what is absolutely logical. One thing the comments on this post show is that different people’s intuition is telling them very different things. For the")#linebreak()#text(" mathematician (or mathematics student) it should perhaps not be")#linebreak()#text(" too difficult to adopt the maxim ” forget intuition, and trust rigorous")#linebreak()#text(" logical argument”. On the other hand, when trying to use mathematics")#linebreak()#text(" and isolating the essential properties of the situation you are trying to model, it is important to understand the limitations imposed on the")#linebreak()#text(" model you are using by the “simplifying” assumptions made, and perhaps")#linebreak()#text(" be prepared to amend the mathematical model to better reflect the")#linebreak()#text(" problem you are using it for.")
]
]
]
]
]
