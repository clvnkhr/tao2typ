// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/
// Converted to Typst by tao2typ: "2026-10-14T09:24:34.803733+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hilbert’s fifth problem and related topics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hilbert’s fifth problem and related topics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 March 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/")[#text("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I recently finished the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/03/hilbert-book.pdf")[#text("first draft")]#text(" of the the first of ")#link("https://terrytao.wordpress.com/books/")[#text("my books")]#text(", entitled “")#link("https://terrytao.wordpress.com/books/hilberts-fifth-problem-and-related-topics/")[#text("Hilbert’s fifth problem and related topics")]#text("“, based on ")#link("http://en.wordpress.com/tag/254a-hilberts-fifth-problem")[#text("the lecture notes")]#text(" for ")#link("http://www.math.ucla.edu/~tao/254a.1.11f/")[#text("my graduate course of the same name")]#text(". The PDF of this draft is available ")#link("https://terrytao.wordpress.com/wp-content/uploads/2012/03/hilbert-book.pdf")[#text("here")]#text(". As always, comments and corrections are welcome.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be8dafb93e7496a43164fb4490b3468f767e0d2d5b2ac2a2ccc69742dd1eb2-d5a7857f9565cf74448d063927edeb061bdad27a7f5017ac12ee264c59a72e96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Ehlers Nyholm Thomsen")]], [#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/#comment-135476")[#strong[#text("Adam Ehlers Nyholm Thomsen")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2012")])]

#text("I know this is sort of besides the point, but as a minor correction: Your link to the 2011 blog posts is to the 2010 archive… I am looking forward to reading the draft.")

#emph[#text("[Link removed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f2f9ab466744e557351444dce5a81cc5d98707be66fa338b96dcffeadd3556d-2845dd980d37e972238350eda0b6522e9d5833044dcc4d04ca8f4552be49f7de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/#comment-135552")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2012")])]

#text("Terrance, you are such an amazing writer who can astonishingly bring an abstruse topic such as Hilbert’s fifth problem into such a friendly light, even for people like me. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Why Read the Heroes? « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/#comment-137027")[#strong[#text("Why Read the Heroes? « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2012")])]

#text("[…] Tao saved the consistency of Peano Arithmetic as described here after winning a Fields Medal in 2006, see The Black Scholes Equation and Hilbert’s Fifth Problem and related topics. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21693cd7f2b10021ea643d3931e0b6778904e97d2acb8b7b673761965350539b-6ef14631a8b9368510a5dc2caaf5e92066c08889d66d7b945f9025d88d4321dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On Tao’s talk and the 3-dimensional Hilbert-Smith conjecture « Area 777")]], [#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/#comment-141871")[#strong[#text("On Tao’s talk and the 3-dimensional Hilbert-Smith conjecture « Area 777")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2012")])]

#text("[…] Since there’s no point for me to write 2nd-handed blog post while people can just read his own posts on this, I’ll just record a few points I personally found interesting (as a complete outsider), […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/#comment-141931")[#strong[#text("John Parton、3维流形的拓扑和网络时代的数学 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")]

#text("[…] 为说明这个新范式的确促进了数学的进步，或许再次引用John-Pardon的例子是合适的：陶哲轩今年探讨的主题是Hilbert第5问题，他对Hilbert-Smith猜想的讨论直接影响了Pardon. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/03/27/hilberts-fifth-problem-and-related-topics/#comment-416359")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2014")])]

#text("The book has now been ")#link("http://www.ams.org/bookstore-getitem/item=gsm-153")[#text("published by the AMS")]#text(".")
]
