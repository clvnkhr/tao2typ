// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/
// Converted to Typst by tao2typ: "2026-10-14T07:09:53.527821+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, notes 3: L^p spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, notes 3: L^p spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("Now that we have reviewed the foundations of measure theory, let us now put it to work to set up the basic theory of one of the fundamental families of ")#link("http://en.wikipedia.org/wiki/Function_space")[#text("function spaces")]#text(" in analysis, namely the ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("L^p")#text(" spaces")]#text(" (also known as ")#emph[#text("Lebesgue spaces")]#text("). These spaces serve as important model examples for the general theory of ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological")]#text(" and ")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector spaces")]#text(", which we will discuss a little bit in this lecture and then in much greater detail in later lectures. (See also my ")#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/")[#text("previous blog post")]#text(" on function spaces.)")

#text("Just as scalar quantities live in the space of real or complex numbers, and vector quantities live in ")#link("http://en.wikipedia.org/wiki/Vector_space")[#text("vector spaces")]#text(", functions ")#mi("f: X \\to {\\Bbb C}")#text(" (or other objects closely related to functions, such as measures) live in ")#emph[#text("function spaces")]#text(". Like other spaces in mathematics (e.g. vector spaces, metric spaces, topological spaces, etc.) a function space ")#mi("V")#text(" is not just mere sets of objects (in this case, the objects are functions), but they also come with various important ")#emph[#text("structures")]#text(" that allow one to do some useful ")#emph[#text("operations")]#text(" inside these spaces, and from one space to another. For example, function spaces tend to have several (though usually not ")#emph[#text("all")]#text(") of the following types of structures, which are usually related to each other by various compatibility conditions:")

#enum(start: 1, 
[#strong[#text("Vector space structure.")]#text(" One can often add two functions ")#mi("f, g")#text(" in a function space ")#mi("V")#text(", and expect to get another function ")#mi("f+g")#text(" in that space ")#mi("V")#text("; similarly, one can multiply a function ")#mi("f")#text(" in ")#mi("V")#text(" by a scalar ")#mi("c")#text(" and get another function ")#mi("cf")#text(" in ")#mi("V")#text(". Usually, these operations obey the axioms of a ")#link("http://en.wikipedia.org/wiki/Vector_space")[#text("vector space")]#text(", though it is important to caution that the ")#link("http://en.wikipedia.org/wiki/Dimension_(vector_space)")[#text("dimension")]#text(" of a function space is typically infinite. (In some cases, the space of scalars is a more complicated ring than the real or complex field, in which case we need the notion of a ")#link("http://en.wikipedia.org/wiki/Module_(mathematics)")[#text("module")]#text(" rather than a vector space, but we will not use this more general notion in this course.) Virtually all of the function spaces we shall encounter in this course will be vector spaces. Because the field of scalars is real or complex, vector spaces also come with the notion of ")#link("http://en.wikipedia.org/wiki/Convex_set")[#emph[#text("convexity")]]#text(", which turns out to be crucial in many aspects of analysis. As a consequence (and in marked contrast to algebra or number theory), much of the theory in real analysis does not seem to extend to other fields of scalars (in particular, real analysis fails spectacularly in the finite characteristic setting).")],
[#strong[#text("Algebra structure.")]#text(" Sometimes (though not always), we also wish to multiply two functions ")#mi("f")#text(", ")#mi("g")#text(" in ")#mi("V")#text(" and get another function ")#mi("fg")#text(" in ")#mi("V")#text("; when combined with the vector space structure and assuming some compatibility conditions (e.g. the ")#link("http://en.wikipedia.org/wiki/Distributive_law")[#text("distributive law")]#text("), this makes ")#mi("V")#text(" an ")#link("http://en.wikipedia.org/wiki/Module_(mathematics)")[#text("algebra")]#text(". This multiplication operation is often just pointwise multiplication, but there are other important multiplication operations on function spaces too, such as ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(". (One sometimes sees other algebraic structures than multiplication appear in function spaces, most notably ")#link("http://en.wikipedia.org/wiki/Derivation_(abstract_algebra)")[#text("derivations")]#text(", but again we will not encounter those in this course. Another common algebraic operation for function spaces is ")#emph[#text("conjugation")]#text(" or ")#emph[#text("adjoint")]#text(", leading to the notion of a ")#link("http://en.wikipedia.org/wiki/Star-algebra")[#text("*-algebra")]#text(".)")],
[#strong[#text("Norm structure.")]#text(" We often want to distinguish “large” functions in ")#mi("V")#text(" from “small” ones, especially in analysis, in which “small” terms in an expression are routinely discarded or deemed to be acceptable errors. One way to do this is to assign a ")#emph[#text("magnitude")]#text(" or ")#link("http://en.wikipedia.org/wiki/Norm_(mathematics)")[#emph[#text("norm")]]#text(" ")#tao-math("\\left\\|f\\right\\|_V", block: false)#text(" to each function that measures its size. Unlike the situation with scalars, where there is basically a single notion of magnitude, functions have a wide variety of useful notions of size, each measuring a different aspect (or combination of aspects) of the function, such as height, width, oscillation, regularity, decay, and so forth. Typically, each such norm gives rise to a separate function space (although sometimes it is useful to consider a single function space with multiple norms on it). We usually require the norm to be compatible with the vector space structure (and algebra structure, if present), for instance by demanding that the ")#link("http://en.wikipedia.org/wiki/Triangle_inequality")[#text("triangle inequality")]#text(" hold.")],
[#strong[#text("Metric structure.")]#text(" We also want to tell whether two functions f, g in a function space V are “near together” or “far apart”. A typical way to do this is to impose a ")#link("http://en.wikipedia.org/wiki/Metric_(mathematics)")[#text("metric")]#text(" ")#mi("d: V \\times V \\to {\\Bbb R}^+")#text(" on the space ")#mi("V")#text(". If both a norm ")#mi("\\| \\|_V")#text(" and a vector space structure are available, there is an obvious way to do this: define the distance between two functions ")#mi("f, g")#text(" in ")#mi("V")#text(" to be ")#tao-math("d( f, g ) := \\left\\|f-g\\right\\|_V", block: false)#text(". (This will be the only type of metric on function spaces encountered in this course. But there are some nonlinear function spaces of importance in nonlinear analysis (e.g. spaces of maps from one manifold to another) which have no vector space structure or norm, but still have a metric.) It is often important to know if the vector space is ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("complete")]#text(" with respect to the given metric; this allows one to take limits of ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy sequences")]#text(", and (with a norm and vector space structure) sum ")#link("http://en.wikipedia.org/wiki/Absolute_convergence")[#text("absolutely convergent")]#text(" series, as well as use some useful results from point set topology such as the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(". All of these operations are of course vital in analysis. [")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("Compactness")]#text(" would be an even better property than completeness to have, but function spaces unfortunately tend be non-compact in various rather nasty ways, although there are useful partial substitutes for compactness that are available, see e.g. ")#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/")[#text("this blog post of mine")]#text(".]")],
[#strong[#text("Topological structure.")]#text(" It is often important to know when a sequence (or, occasionally, ")#link("http://en.wikipedia.org/wiki/Net_(mathematics)")[#text("nets")]#text(") of functions ")#mi("f_n")#text(" in ")#mi("V")#text(" “converges” in some sense to a limit ")#mi("f")#text(" (which, hopefully, is still in ")#mi("V")#text("); there are often many distinct modes of convergence (e.g. ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("pointwise convergence")]#text(", ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#text("uniform convergence")]#text(", etc.) that one wishes to carefully distinguish from each other. Also, in order to apply various powerful topological theorems (or to justify various formal operations involving limits, suprema, etc.), it is important to know when certain subsets of ")#mi("V")#text(" enjoy key topological properties (most notably ")#emph[#text("compactness")]#text(" and ")#link("http://en.wikipedia.org/wiki/Connected_space")[#emph[#text("connectedness")]]#text("), and to know which operations on ")#mi("V")#text(" are ")#link("http://en.wikipedia.org/wiki/Continuous_function")[#text("continuous")]#text(". For all of this, one needs a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topology")]#text(" on ")#mi("V")#text(". If one already has a metric, then one of course has a topology generated by the open balls of that metric; but there are many important topologies on function spaces in analysis that do not arise from metrics. We also often require the topology to be compatible with the other structures on the function space; for instance, we usually require the vector space operations of addition and scalar multiplication to be continuous. In some cases, the topology on ")#mi("V")#text(" extends to some natural superspace ")#mi("W")#text(" of more general functions that contain ")#mi("V")#text("; in such cases, it is often important to know whether ")#mi("V")#text(" is ")#link("http://en.wikipedia.org/wiki/Closed_set")[#text("closed")]#text(" in ")#mi("W")#text(", so that limits of sequences in ")#mi("V")#text(" stay in ")#mi("V")#text(".")],
[#strong[#text("Functional structures.")]#text(" Since numbers are easier to understand and deal with than functions, it is not surprising that we often study functions f in a function space V by first applying some ")#link("http://en.wikipedia.org/wiki/Functional_(mathematics)")[#text("functional")]#text(" ")#mi("\\lambda: V \\to {\\Bbb C}")#text(" to V to identify some key numerical quantity ")#mi("\\lambda(f)")#text(" associated to f. ")#emph[#text("Norms")]#text(" ")#tao-math("f \\mapsto \\left\\|f\\right\\|_V", block: false)#text(" are of course one important example of a functional; ")#emph[#text("integration")]#text(" ")#mi("f \\mapsto \\int_X f\\ d\\mu")#text(" provides another; and ")#emph[#text("evaluation")]#text(" ")#mi("f \\mapsto f(x)")#text(" at a point x provides a third important class. (Note, though, that while evaluation is the fundamental feature of a function in set theory, it is often a quite minor operation in analysis; indeed, in many function spaces, evaluation is not even defined at all, for instance because the functions in the space are only defined almost everywhere!) An ")#link("http://en.wikipedia.org/wiki/Inner_product_space")[#emph[#text("inner product")]]#text(" ")#mi("\\langle,\\rangle")#text(" on ")#mi("V")#text(" (see below) also provides a large family ")#mi("f \\mapsto \\langle f, g \\rangle")#text(" of useful functionals. It is of particular interest to study functionals that are compatible with the vector space structure (i.e. are ")#link("http://en.wikipedia.org/wiki/Linear_functional")[#text("linear")]#text(") and with the topological structure (i.e. are ")#emph[#text("continuous")]#text("); this will give rise to the important notion of ")#link("http://en.wikipedia.org/wiki/Dual_vector_space")[#text("duality")]#text(" on function spaces.")],
[#strong[#text("Inner product structure.")]#text(" One often would like to pair a function f in a function space V with another object g (which is often, though not always, another function in the same function space V) and obtain a number ")#mi("\\langle f, g \\rangle")#text(", that typically measures the amount of “interaction” or “correlation” between f and g. Typical examples include inner products arising from integration, such as ")#mi("\\langle f, g\\rangle := \\int_X f \\overline{g}\\ d\\mu")#text("; integration itself can also be viewed as a pairing, ")#mi("\\langle f, \\mu \\rangle := \\int_X f\\ d\\mu")#text(". Of course, we usually require such inner products to be compatible with the other structures present on the space (e.g., to be compatible with the vector space structure, we usually require the inner product to be ")#link("http://en.wikipedia.org/wiki/Bilinear_form")[#text("bilinear")]#text(" or ")#link("http://en.wikipedia.org/wiki/Sesquilinear")[#text("sesquilinear")]#text("). Inner products, when available, are incredibly useful in understanding the metric and norm geometry of a space, due to such fundamental facts as the ")#link("http://en.wikipedia.org/wiki/Cauchy-Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Parallelogram_law")[#text("parallelogram law")]#text(". They also give rise to the important notion of ")#link("http://en.wikipedia.org/wiki/Orthogonality")[#emph[#text("orthogonality")]]#text(" between functions.")],
[#strong[#text("Group actions.")]#text(" We often expect our function spaces to enjoy various ")#emph[#text("symmetries")]#text("; we might wish to rotate, reflect, translate, modulate, or dilate our functions and expect to preserve most of the structure of the space when doing so. In modern mathematics, symmetries are usually encoded by ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("group actions")]#text(" (or actions of other group-like objects, such as ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroups")]#text(" or ")#link("http://en.wikipedia.org/wiki/Groupoid")[#text("groupoids")]#text("; one also often upgrades groups to more structured objects such as ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text("). As usual, we typically require the group action to preserve the other structures present on the space, e.g. one often restricts attention to group actions that are linear (to preserve the vector space structure), continuous (to preserve topological structure), ")#link("http://en.wikipedia.org/wiki/Unitary_transformation")[#text("unitary")]#text(" (to preserve inner product structure), ")#link("http://en.wikipedia.org/wiki/Isometry")[#text("isometric")]#text(" (to preserve metric structure), and so forth. Besides giving us useful symmetries to ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("spend")]#text(", the presence of such group actions allows one to apply the powerful techniques of ")#link("http://en.wikipedia.org/wiki/Representation_theory")[#text("representation theory")]#text(", ")#link("http://en.wikipedia.org/wiki/Fourier_analysis")[#text("Fourier analysis")]#text(", and ergodic theory. However, as this is a foundational real analysis class, we will not discuss these important topics much here (and in fact will not deal with group actions much at all).")],
[#strong[#text("Order structure.")]#text(" In some cases, we want to utilise the notion of a function f being “non-negative”, or “dominating” another function g. One might also want to take the “max” or “supremum” of two or more functions in a function space V, or split a function into “positive” and “negative” components. Such order structures interact with the other structures on a space in many useful ways (e.g. via the ")#link("http://en.wikipedia.org/wiki/Stone-weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text("). Much like convexity, order structure is specific to the real line and is another reason why much of real analysis breaks down over other fields. (The complex plane is of course an extension of the real line and so is able to exploit the order structure of that line, usually by treating the real and imaginary components separately.)")]
)

#text("There are of course many ways to combine various flavours of these structures together, and there are entire subfields of mathematics that are devoted to studying particularly common and useful ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("categories")]#text(" of such combinations (e.g. ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector spaces")]#text(", ")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector spaces")]#text(", ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach spaces")]#text(", ")#link("http://en.wikipedia.org/wiki/Banach_algebra")[#text("Banach algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/Banach_algebra")[#text("von Neumann algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#text("C^* algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/Frechet_space")[#text("Frechet spaces")]#text(", ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert spaces")]#text(", ")#link("http://en.wikipedia.org/wiki/Group_algebra")[#text("group algebras")]#text(", etc.). The study of these sorts of spaces is known collectively as ")#link("http://en.wikipedia.org/wiki/Functional_analysis")[#emph[#text("functional analysis")]]#text(". We will study some (but certainly not all) of these combinations in an abstract and general setting later in this course, but to begin with we will focus on the ")#mi("L^p")#text(" spaces, which are very good model examples for many of the above general classes of spaces, and also of importance in many applications of analysis (such as probability or PDE).")

#heading(level: 1)[#metadata(none) <tao-52d3e3957a6c42e7c791>#text("— ")#mi("L^p")#text(" spaces —")]

#text("In this post, ")#mi("(X, {\\mathcal X}, \\mu)")#text(" will be a fixed measure space; notions such as “measurable”, “measure”, “almost everywhere”, etc. will always be with respect to this space, unless otherwise specified. Similarly, unless otherwise specified, all subsets of X mentioned are restricted to be measurable, as are all scalar functions on X.")

#text("For sake of concreteness, we shall select the field of scalars to be the complex numbers ")#mi("{\\Bbb C}")#text(". The theory of real Lebesgue spaces is virtually identical to that of complex Lebesgue spaces, and the former can largely be deduced from the latter as a special case.")

#text("We already have the notion of an ")#emph[#text("absolutely integrable function")]#text(" on X, which is a function ")#mi("f: X \\to {\\Bbb C}")#text(" such that ")#mi("\\int_X |f|\\ d\\mu")#text(" is finite. More generally, given any exponent ")#mi("0 < p < \\infty")#text(", we can define a ")#emph[#mi("p^{th}")#text("-power integrable function")]#text(" to be a function ")#mi("f: X \\to {\\Bbb C}")#text(" such that ")#tao-math("\\int_X \\left|f\\right|^p\\ d\\mu", block: false)#text(" is finite. (Besides p=1, the case of most interest is the case of ")#emph[#text("square-integrable functions")]#text(", when ")#mi("p=2")#text(". We will also extend this notion later to ")#mi("p=\\infty")#text(", which is also an important special case.)")

#strong[#text("Remark 1.")]#text(" One can also extend these notions to functions that take values in the extended complex plane ")#mi("{\\Bbb C} \\cup \\{\\infty\\}")#text(", but one easily observes that ")#mi("p^{th}")#text(" power integrable functions must be finite almost everywhere, and so there is essentially no increase in generality afforded by extending the range in this manner. ")#mi("\\diamond")

#text("Following the “Lebesgue philosophy” that one should ignore whatever is going on on a set of measure zero, let us declare two measurable functions to be ")#emph[#text("equivalent")]#text(" if they agree almost everywhere. This is easily checked to be an ")#link("http://en.wikipedia.org/wiki/Equivalence_relation")[#text("equivalence relation")]#text(", which does not affect the property of being ")#mi("p^{th}")#text("-power integrable. Thus, we can define the ")#emph[#text("Lebesgue space")]#text(" ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(" to be the space of ")#mi("p^{th}")#text("-power integrable functions, ")#link("http://en.wikipedia.org/wiki/Quotient_space")[#text("quotiented")]#text(" out by this equivalence relation. Thus, strictly speaking, a typical element of ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(" is not actually a specific function f, but is instead an equivalence class [f], consisting of all functions equivalent to a single function f. However, we shall abuse notation and speak loosely of a function f “belonging” to ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(", where it is understood that f is only defined up to equivalence, or more imprecisely is “defined almost everywhere”. For the purposes of integration, this equivalence is quite harmless, but this convention does mean that we can no longer evaluate a function f in ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(" at a single point x if that point x has zero measure. It takes a little bit of getting used to the idea of a function that cannot actually be evaluated at any specific point, but with some practice you will find that it will not cause any significant conceptual difficulty. [One could also take a more abstract view, dispensing with the set X altogether and defining the Lebesgue space ")#mi("L^p({\\mathcal X},\\mu)")#text(" on abstract measure spaces ")#mi("({\\mathcal X},\\mu)")#text(", but we will not do so here. Another way to think about elements of ")#mi("L^p")#text(" is that they are functions which are “unreliable” on an unknown set of measure zero, but remain “reliable” almost everywhere.]")

#strong[#text("Exercise 0.")]#text(" If ")#mi("(X,{\\mathcal X},\\mu)")#text(" is a measure space, and ")#mi("\\overline{\\mathcal X}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Complete_measure")[#text("completion")]#text(" of ")#mi("{\\mathcal X}")#text(", show that the spaces ")#mi("L^p(X, {\\mathcal X},\\mu)")#text(" and ")#mi("L^p(X, \\overline{\\mathcal X}, \\mu)")#text(" are isomorphic using the obvious candidate for the isomorphism. Because of this, when dealing with ")#mi("L^p")#text(" spaces, we will usually not be too concerned with whether the underlying measure space is complete. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Depending on which of the three structures ")#mi("X, {\\mathcal X}, \\mu")#text(" of the measure space one wishes to emphasise, the space ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(" is often abbreviated ")#mi("L^p(X)")#text(", ")#mi("L^p({\\mathcal X})")#text(", ")#mi("L^p(X,\\mu)")#text(", or even just ")#mi("L^p")#text(". Since for this discussion the measure space ")#mi("(X,{\\mathcal X},\\mu)")#text(" will be fixed, we shall usually use the ")#mi("L^p")#text(" abbreviation in this post. When the space X is discrete (i.e. ")#mi("{\\mathcal X}=2^X")#text(") and ")#mi("\\mu")#text(" is counting measure, then ")#mi("L^p(X,{\\mathcal X},\\mu)")#text(" is usually abbreviated ")#mi("\\ell^p(X)")#text(" or just ")#mi("\\ell^p")#text(" (and the almost everywhere equivqlence relation trivialises and can thus be completely ignored). ")#mi("\\diamond")

#text("At present, the Lebesgue spaces ")#mi("L^p")#text(" are just sets. We now begin to place several of the structures mentioned in the introduction to upgrade these sets to richer spaces.")

#text("We begin with vector space structure. Fix ")#mi("0 < p < \\infty")#text(", and let ")#mi("f, g \\in L^p")#text(" be two ")#mi("p^{th}")#text("-power integrable functions. From the crude pointwise (or more precisely, “pointwise almost everywhere”) inequality")

#tao-aligned(keep: true)[


#tao-math("\\left|f(x) + g(x)\\right|^p  & \\leq (2 \\max(\\left|f(x)\\right|,\\left|g(x)\\right|))^p", block: true)



#tao-math(" & = 2^p \\max( \\left|f(x)\\right|^p, \\left|g(x)\\right|^p ) \\leq 2^p (\\left|f(x)\\right|^p + \\left|g(x)\\right|^p)", block: true, numbering: n => [#text("(1)")])
]

#text("we see that the sum of two ")#mi("p^{th}")#text("-power integrable functions is also ")#mi("p^{th}")#text("-power integrable. It is also easy to see that any scalar multiple of a ")#mi("p^{th}")#text("-power integrable function is also ")#mi("p^{th}")#text("-power integrable. These operations respect almost everywhere equivalence, and so ")#mi("L^p")#text(" becomes a (complex) vector space.")

#text("Next, we set up the norm structure. If ")#mi("f \\in L^p")#text(", we define the ")#emph[#mi("L^p")#text(" norm")]#text(" ")#tao-math("\\left\\|f\\right\\|_{L^p}", block: false)#text(" of f to be the number")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\|f\\right\\|_{L^p} := (\\int_X \\left|f\\right|^p\\ d\\mu)^{1/p};", block: true)]]

#text("this is a finite non-negative number by definition of ")#mi("L^p")#text("; in particular, we have the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\|\\left|f\\right|^r \\right\\|_{L^p} = \\left\\|f\\right\\|_{L^{pr}}^r", block: true)]]

#text("for all ")#mi("0 < p,r < \\infty")#text(".")

#text("The ")#mi("L^p")#text(" norm has the following three basic properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1. ")]#text("Let ")#mi("0 < p < \\infty")#text(" and ")#mi("f, g \\in L^p")#text(".")

#enum(start: 1, 
[#text("(Non-degeneracy) ")#tao-math("\\left\\|f\\right\\|_{L^p} = 0", block: false)#text(" if and only if f = 0.")],
[#text("(Homogeneity) ")#tao-math("\\left\\| cf \\right\\|_{L^p} = \\left|c\\right| \\left\\|f\\right\\|_{L^p}", block: false)#text(" for all complex numbers c.")],
[#text("((Quasi-)triangle inequality) We have ")#tao-math("\\left\\|f+g\\right\\|_{L^p} \\leq C ( \\left\\|f\\right\\|_{L^p} + \\left\\|g\\right\\|_{L^p} )", block: false)#text(" for some constant C depending on p. If ")#mi("p \\geq 1")#text(", then we can take C=1 (this fact is also known as ")#link("http://en.wikipedia.org/wiki/Minkowski_inequality")[#text("Minkowski’s inequality")]#text(").")]
)
]

#strong[#text("Proof. ")]#text("The claims 1, 2 are obvious. (Note how important it is that we equate functions that vanish almost everywhere in order to get 1.) The quasi-triangle inequality follows from a variant of the estimates in (1) and is left as an exercise. For the triangle inequality, we have to be more efficient than the crude estimate (1). By the non-degeneracy property we may take ")#tao-math("\\left\\|f\\right\\|_{L^p}", block: false)#text(" and ")#tao-math("\\left\\|g\\right\\|_{L^p}", block: false)#text(" to be non-zero. Using the homogeneity, we can normalise ")#tao-math("\\left\\|f\\right\\|_{L^p}+\\left\\|g\\right\\|_{L^p}", block: false)#text(" to equal 1, thus (by homogeneity again) we can write ")#mi("f = (1-\\theta) F")#text(" and ")#mi("g = \\theta G")#text(" for some ")#mi("0 < \\theta < 1")#text(" and ")#mi("F, G \\in L^p")#text(" with ")#tao-math("\\left\\|F\\right\\|_{L^p}=\\left\\|G\\right\\|_{L^p}=1", block: false)#text(". Our task is now to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_X \\left| (1-\\theta) F(x) + \\theta G(x)\\right|^p\\ d\\mu \\leq 1.", block: true)]]

#text("But observe that for ")#mi("1 \\leq p < \\infty")#text(", the function ")#tao-math("x \\mapsto \\left|x\\right|^p", block: false)#text(" is ")#link("http://en.wikipedia.org/wiki/Convex_function")[#text("convex")]#text(" on ")#mi("{\\Bbb C}")#text(", and in particular that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|(1-\\theta) F(x) + \\theta G(x)\\right|^p \\leq (1-\\theta) \\left|F(x)\\right|^p + \\theta \\left|G(x)\\right|^p.", block: true)]]

#text("(If one wishes, one can use the complex triangle inequality to first reduce to the case when F, G are non-negative, in which case one only needs convexity on ")#mi("{}[0,+\\infty)")#text(" rather than all of ")#mi("{\\Bbb C}")#text(".) The claim (4) then follows from (5) and the normalisations of F, G. ")#mi("\\Box")

#strong[#text("Exercise 1.")]#text(" Let ")#mi("0 < p \\leq 1")#text(" and ")#mi("f, g \\in L^p")#text(".")

#enum(start: 1, 
[#text("Establish the variant ")#tao-math("\\left\\|f+g\\right\\|_{L^p}^p \\leq \\left\\|f\\right\\|_{L^p}^p + \\left\\|g\\right\\|_{L^p}^p", block: false)#text(" of the triangle inequality.")],
[#text("If furthermore f and g are non-negative (almost everywhere), establish also the reverse triangle inequality ")#tao-math("\\left\\|f+g\\right\\|_{L^p} \\geq \\left\\|f\\right\\|_{L^p} + \\left\\|g\\right\\|_{L^p}", block: false)#text(".")],
[#text("Show that the best constant C in the quasi-triangle inequal")],
[#text("ity is ")#mi("2^{\\frac{1}{p}-1}")#text(". In particular, the triangle inequality is false for ")#mi("p < 1")#text(". ")#mi("\\diamond")],
[#text("Now suppose instead that ")#mi("1 < p < \\infty")#text(" or ")#mi("0 < p < 1")#text(". If ")#mi("f, g \\in L^p")#text(" are nonnegative and such that ")#tao-math("\\left\\|f+g\\right\\|_{L^p} = \\left\\|f\\right\\|_{L^p} + \\left\\|g\\right\\|_{L^p}", block: false)#text(", show that one of the functions f, g is a non-negative scalar multiple of the other (up to equivalence, of course). What happens when p=1?")]
)

#text("A vector space V with a function ")#mi("\\| \\|: V \\to [0,+\\infty)")#text(" obeying the non-degeneracy, homogeneity, and (quasi-)triangle inequality is known as a (")#link("http://en.wikipedia.org/wiki/Quasinorm")[#text("quasi")]#text("-)")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector space")]#text(", and the function ")#tao-math("f \\mapsto \\left\\|f\\right\\|", block: false)#text(" is then known as a ")#emph[#text("(quasi-)norm")]#text("; thus ")#mi("L^p")#text(" is a normed vector space for ")#mi("1 \\leq p < \\infty")#text(" but only a quasi-normed vector space for ")#mi("0 < p < 1")#text(". A function ")#mi("\\| \\|: V \\to [0,+\\infty)")#text(" obeying the homogeneity and triangle inequality, but not necessarily the non-degeneracy property, is known as a ")#link("http://en.wikipedia.org/wiki/Seminorm")[#text("seminorm")]#text("; thus for instance the ")#mi("L^p")#text(" norms for ")#mi("1 \\leq p < \\infty")#text(" would have been seminorms if we did not equate functions that agreed almost everywhere. (Conversely, given a seminormed vector space ")#mi("(V,\\|\\|)")#text(", one can convert it into a normed vector space by quotienting out the subspace ")#tao-math("\\{ f \\in V: \\left\\|f\\right\\| = 0 \\}", block: false)#text("; we leave the details as an exercise for the reader.)")

#strong[#text("Exercise 2. ")]#text("Let ")#mi("\\| \\|: V \\to [0,+\\infty)")#text(" be a function on a vector space which obeys the non-degeneracy and homogeneity properties. Show that ")#mi("\\| \\|")#text(" is a norm if and only if the closed unit ball ")#tao-math("\\{ x: \\left\\|x\\right\\| \\leq 1 \\}", block: false)#text(" is ")#link("http://en.wikipedia.org/wiki/Convex_set")[#text("convex")]#text("; show that the same equivalence also holds for the open unit ball. This emphasises the geometric nature of the triangle inequality. ")#mi("\\diamond")

#strong[#text("Exercise 3. ")]#text(" If ")#mi("f \\in L^p")#text(" for some ")#mi("0 < p < \\infty")#text(", show that the ")#link("http://en.wikipedia.org/wiki/Support_(mathematics)")[#text("support")]#text(" ")#mi("\\{ x \\in X: f(x) \\neq 0 \\}")#text(" of f (which is defined only up to sets of measure zero) is a ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#mi("\\sigma")#text("-finite")]#text(" set. (Because of this, we can often reduce from the non-")#mi("\\sigma")#text("-finite case to the ")#mi("\\sigma")#text("-finite case in many, though not all, questions concerning ")#mi("L^p")#text(" spaces.) ")#mi("\\diamond")

#text("We now are able to define ")#mi("L^p")#text(" norms and spaces in the limit ")#mi("p=\\infty")#text(". We say that a function ")#mi("f: X \\to {\\Bbb C}")#text(" is ")#emph[#text("essentially bounded")]#text(" if there exists an M such that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for almost every x, and define ")#tao-math("\\left\\|f\\right\\|_{L^\\infty}", block: false)#text(" to be the least M that serves as such a bound. We let ")#mi("L^\\infty")#text(" denote the space of essentially bounded functions, quotiented out by equivalence, and given the norm ")#mi("\\| \\cdot \\|_{L^\\infty}")#text(". It is not hard to see that this is also a normed vector space. Observe that a sequence ")#mi("f_n \\in L^\\infty")#text(" converges to a limit ")#mi("f \\in L^\\infty")#text(" if and only if ")#mi("f_n")#text(" converges ")#emph[#text("essentially uniformly")]#text(" to f, i.e. it converges uniformly to f outside of a set of measure zero. (Compare with ")#link("http://en.wikipedia.org/wiki/Egorov%27s_theorem")[#text("Egorov’s theorem")]#text(" (Theorem 3.6 from ")#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("Notes 0")]#text("), which equates pointwise convergence with uniform convergence outside of a set of arbitrarily small emasure.)")

#text("Now we explain why we call this norm the ")#mi("L^\\infty")#text(" norm:")

#strong[#text("Example 1.")]#text(" Let f be a (generalised) ")#emph[#text("step function")]#text(", thus ")#mi("f = A 1_E")#text(" for some amplitude ")#mi("{A > 0}")#text(" and some set E; let us assume that E has positive finite measure. Then ")#tao-math("\\left\\|f\\right\\|_{L^p} = A \\mu(E)^{1/p}", block: false)#text(" for all ")#mi("0 < p < \\infty")#text(", and also ")#tao-math("\\left\\|f\\right\\|_{L^\\infty} = A", block: false)#text(". Thus in this case, at least, the ")#mi("L^\\infty")#text(" norm is the limit of the ")#mi("L^p")#text(" norms. This example illustrates also that the ")#mi("L^p")#text(" norms behave like combinations of the “height” A of a function, and the “width” ")#mi("\\mu(E)")#text(" of such a function, though of course the concepts of height and width are not formally defined for functions that are not step functions. ")#mi("\\diamond")

#strong[#text("Exercise 4.")]

#enum(start: 1, 
[#text("If ")#mi("f \\in L^\\infty \\cap L^{p_0}")#text(" for some ")#mi("0 < p_0 < \\infty")#text(", show that ")#tao-math("\\left\\|f\\right\\|_{L^p} \\to \\left\\|f\\right\\|_{L^\\infty}", block: false)#text(" as ")#mi("p \\to \\infty")#text(". (Hint: use the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(".)")],
[#text("If ")#mi("f \\not \\in L^\\infty")#text(", show that ")#tao-math("\\left\\|f\\right\\|_{L^p} \\to \\infty", block: false)#text(" as ")#mi("p \\to \\infty")#text(". ")#mi("\\diamond")]
)

#text("Once one has a vector space structure and a (quasi-)norm structure, we immediately get a (quasi-)metric structure:")

#strong[#text("Exercise 5.")]#text(" Let ")#mi("(V, \\| \\|)")#text(" be a normed vector space. Show that the function ")#mi("d: V \\times V \\to [0,+\\infty)")#text(" defined by ")#tao-math("d(f,g) := \\left\\|f-g\\right\\|", block: false)#text(" is a ")#link("http://en.wikipedia.org/wiki/Metric_(mathematics)")[#text("metric")]#text(" on V which is ")#emph[#text("translation-invariant")]#text(" (thus ")#mi("d(f+h,g+h)=d(f,g)")#text(" for all ")#mi("f,g \\in V")#text(") and ")#emph[#text("homogeneous")]#text(" (thus ")#tao-math("d(cf, cg) = \\left|c\\right| d(f,g)", block: false)#text(" for all ")#mi("f,g \\in V")#text(" and scalars c). Conversely, show that every translation-invariant homogeneous metric on V arises from precisely one norm in this manner. Establish a similar claim relating ")#link("http://en.wikipedia.org/wiki/Quasinorm")[#text("quasi-norms")]#text(" with ")#emph[#text("quasi-metrics")]#text(" (which are defined as metrics, but with the triangle inequality replaced by a quasi-triangle inequality; note that the term “quasi-metric” is occasionally used to denote ")#link("http://en.wikipedia.org/wiki/Quasinorm")[#text("a slightly different concept")]#text("), or between seminorms and ")#emph[#text("semimetrics")]#text(" (which are defined as metrics, but where distinct points are allowed to have a zero separation; these are also known as ")#link("http://en.wikipedia.org/wiki/Pseudometric_space")[#text("pseudometrics")]#text(", with “")#link("http://en.wikipedia.org/wiki/Semimetric")[#text("semimetric")]#text("” used to denote something else). ")#mi("\\diamond")

#text("One can check (exercise!) that the quasi-metric balls ")#tao-math("B(f,r) := \\{ g \\in L^p: \\left\\|f-g\\right\\|_{L^p} < r \\}", block: false)#text(" form a ")#link("http://en.wikipedia.org/wiki/Base_(topology)")[#text("base")]#text(" for a topology on ")#mi("L^p")#text(". (This is easy for ")#mi("p \\geq 1")#text(" because of the triangle inequality; for ")#mi("p < 1")#text(" use the inequality ")#tao-math("\\left\\|f+g\\right\\|_{L^p}^p \\leq \\left\\|f\\right\\|_{L^p}^p + \\left\\|g\\right\\|_{L^p}^p", block: false)#text(".) In particular, a sequence of functions ")#mi("f_n \\in L^p")#text(" converges to a limit ")#mi("f \\in L^p")#text(" if ")#tao-math("\\left\\|f_n-f\\right\\|_{L^p} \\to 0", block: false)#text(" as ")#mi("n \\to \\infty")#text(". We refer to this type of convergence as ")#emph[#text("convergence in ")#mi("L^p")#text(" norm")]#text(", or ")#emph[#link("http://en.wikipedia.org/wiki/Strong_topology")[#text("strong")]#text(" convergence in ")#mi("L^p")]#text(" (we will discuss other modes of convergence in later lectures). As is usual in (quasi-)metric spaces (or more generally for ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff spaces")]#text("), the limit, if it exists, is unique. (This is however not the case for topological structures induced by seminorms or semimetrics, though we can solve this problem by quotienting out the degenerate elements as discussed earlier.)")

#text("Recall that any series ")#mi("\\sum_{n=1}^\\infty a_n")#text(" of scalars is convergent if it is absolutely convergent (i.e. if ")#tao-math("\\sum_{n=1}^\\infty \\left|a_n\\right| < \\infty", block: false)#text(". This fact turns out to be closely related to the fact that the field of scalars ")#mi("{\\Bbb C}")#text(" is ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("complete")]#text(". This can be seen from the following result:")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("(V, \\| \\|)")#text(" be a normed vector space (and hence also a metric space and a topological space). Show that the following are equivalent:")

#enum(start: 1, 
[#text("V is a complete metric space (i.e. every Cauchy sequence converges).")],
[#text("Every sequence ")#mi("f_n \\in V")#text(" which is absolutely convergent (i.e. ")#tao-math("\\sum_{n=1}^\\infty \\left\\|f_n\\right\\| < \\infty", block: false)#text("), is also conditionally convergent (i.e. ")#mi("\\sum_{n=1}^N f_n")#text(" converges to a limit as ")#mi("N \\to \\infty")#text(". ")#mi("\\diamond")]
)

#strong[#text("Remark 3.")]#text(" The situation is more complicated for complete quasi-normed vector spaces; not every absolutely convergent series is conditionally convergent. On the other hand, if ")#tao-math("\\left\\|f_n\\right\\|", block: false)#text(" decays faster than a sufficiently large negative power of n, one recovers conditional convergence; see these ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/summability.dvi")[#text("old notes of mine")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" Let X be a topological space, and let BC(X) be the space of bounded continuous functions on X; this is a vector space. We can place the uniform norm ")#tao-math("\\left\\|f\\right\\|_u := \\sup_{x \\in X} \\left|f(x)\\right|", block: false)#text(" on this space; this makes BC(X) into a normed vector space. It is not hard to verify that this space is complete, and so every absolutely convergent series in BC(X) is conditionally convergent. This fact is better known as the ")#link("http://en.wikipedia.org/wiki/Weierstrass_M-test")[#text("Weierstrass M-test")]#text(". ")#mi("\\diamond")

#text("A space obeying the properties in Exercise 4 (i.e. a complete normed vector space) is known as a ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach space")]#text(". We will study Banach spaces in more detail later in this course. For now, we give one of the fundamental examples of Banach spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text(" ")#mi("L^p")#text(" is a Banach space for every ")#mi("1 \\leq p \\leq \\infty")#text(".")
]

#strong[#text("Proof.")]#text(" By Exercise 6, it suffices to show that any series ")#mi("\\sum_{n=1}^\\infty f_n")#text(" of functions in ")#mi("L^p")#text(" which is absolutely convergent, is also conditionally convergent. This is easy in the case ")#mi("p=\\infty")#text(" and is left as an exercise. In the case ")#mi("1 \\leq p < \\infty")#text(", we write ")#tao-math("M := \\sum_{n=1}^\\infty \\left\\|f_n\\right\\|_{L^p}", block: false)#text(", which is a finite quantity by hypothesis. By the triangle inequality, we have ")#tao-math("\\left\\| \\sum_{n=1}^N \\left|f_n\\right| \\right\\|_{L^p} \\leq M", block: false)#text(" for all N. By monotone convergence, we conclude ")#tao-math("\\left\\| \\sum_{n=1}^\\infty \\left|f_n\\right| \\right\\|_{L^p} \\leq M", block: false)#text(". In particular, ")#mi("\\sum_{n=1}^\\infty f_n(x)")#text(" is absolutely convergent for almost every x. Write the limit of this series as ")#mi("F(x)")#text(". By dominated convergence, we see that ")#mi("\\sum_{n=1}^N f_n(x)")#text(" converges in ")#mi("L^p")#text(" norm to F, and we are done. ")#mi("\\Box")

#text("An important fact is that functions in ")#mi("L^p")#text(" can be approximated by simple functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text(" If ")#mi("0 < p < \\infty")#text(", then the space of simple functions with finite measure support is a dense subspace of ")#mi("L^p")#text(".")
]

#text("(The concept of a non-trivial dense subspace is one which only comes up in infinite dimensions, and is hard to visualise directly. Very roughly speaking, the infinite number of degrees of freedom in an infinite dimensional space gives a subspace an infinite number of “opportunities” to come as close as one desires to any given point in that space, which is what allows such spaces to be dense.)")

#strong[#text("Proof. ")]#text(" The only non-trivial thing to show is the density. An application of the monotone convergence theorem shows that the space of bounded ")#mi("L^p")#text(" functions are dense in ")#mi("L^p")#text(". Another application of monotone convergence (and Exercise 3) then shows that the space bounded ")#mi("L^p")#text(" functions of finite measure support are dense in the space of bounded ")#mi("L^p")#text(" functions. Finally, by discretising the range of bounded ")#mi("L^p")#text(" functions, we see that the space of simple functions with finite measure support is dense in the space of bounded ")#mi("L^p")#text(" functions with finite support. ")#mi("\\Box")

#strong[#text("Remark 5.")]#text(" Since not every function in ")#mi("L^p")#text(" is a simple function with finite measure support, we thus see that the space of simple functions with finite measure support with the ")#mi("L^p")#text(" norm is an example of a normed vector space which is not complete. ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Show that the space of simple functions (not necessarily with finite measure support) is a dense subspace of ")#mi("L^\\infty")#text(". Is the same true if one reinstates the finite measure support restriction? ")#mi("\\diamond")

#strong[#text("Exercise 7a.")]#text(" Suppose that ")#mi("\\mu")#text(" is ")#mi("\\sigma")#text("-finite and ")#mi("{\\mathcal X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Separable_sigma_algebra")[#text("separable")]#text(" (i.e. countably generated). Show that ")#mi("L^p")#text(" is ")#link("http://en.wikipedia.org/wiki/Separable_space")[#text("separable")]#text(" (i.e. has a countable dense subset) for all ")#mi("1 \\leq p < \\infty")#text(". Give a counterexample that shows that ")#mi("L^\\infty")#text(" need not be separable. (Hint: take the integers with counting measure.) ")#mi("\\diamond")

#text("Next, we turn to algebra properties of ")#mi("L^p")#text(" spaces. The key fact here is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" (")#link("http://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder’s inequality")]#text(") Let ")#mi("f \\in L^p")#text(" and ")#mi("g \\in L^q")#text(" for some ")#mi("0 < p,q \\leq \\infty")#text(". Then ")#mi("fg \\in L^r")#text(" and ")#tao-math("\\left\\|fg\\right\\|_{L^r} \\leq \\left\\|f\\right\\|_{L^p} \\left\\|g\\right\\|_{L^q}", block: false)#text(", where the exponent r is defined by the formula ")#mi("\\frac{1}{r} = \\frac{1}{p} + \\frac{1}{q}")#text(".")
]

#strong[#text("Proof.")]#text(" This will be a variant of the proof of the triangle inequality in Lemma 1, again relying ultimately on ")#link("http://en.wikipedia.org/wiki/Convex_function")[#text("convexity")]#text(". The claim is easy when ")#mi("p=\\infty")#text(" or ")#mi("q=\\infty")#text(" and is left as an exercise for the reader in this case, so we assume ")#mi("p, q < \\infty")#text(". Raising f and g to the power r using (2) we may assume r=1, which makes ")#mi("1 < p, q < \\infty")#text(" ")#emph[#text("dual exponents")]#text(" in the sense that ")#mi("\\frac{1}{p}+\\frac{1}{q}=1")#text(". The claim is obvious if either ")#tao-math("\\left\\|f\\right\\|_{L^p}", block: false)#text(" or ")#tao-math("\\left\\|g\\right\\|_{L^q}", block: false)#text(" are zero, so we may assume they are non-zero; by homogeneity we may then normalise ")#tao-math("\\left\\|f\\right\\|_{L^p}=\\left\\|g\\right\\|_{L^q} = 1", block: false)#text(". Our task is now to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_X |fg|\\ d\\mu \\leq 1.")]]

#text("Here, we use the convexity of the exponential function ")#mi("t \\mapsto e^t")#text(" on ")#mi("{}[0,+\\infty)")#text(", which implies the convexity of the function ")#tao-math("t \\mapsto \\left|f(x)\\right|^{p(1-t)} \\left|g(x)\\right|^{qt}", block: false)#text(" for ")#mi("t \\in [0,1]")#text(" for any x. In particular we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|f(x) g(x)\\right| \\leq \\frac{1}{p} \\left|f(x)\\right|^p + \\frac{1}{q} \\left|g(x)\\right|^q", block: true)]]

#text("and the claim (6) follows from the normalisations on p, q, f, g. ")#mi("\\Box")

#strong[#text("Remark 6.")]#text(" For a different proof of this inequality (based on the tensor power trick), see Example 1 of ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("this blog post of mine")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 7.")]#text(" One can also use Hölder’s inequality to prove the triangle inequality for ")#mi("L^p")#text(", ")#mi("1 \\leq p < \\infty")#text(" (i.e. ")#link("http://en.wikipedia.org/wiki/Minkowski_inequality")[#text("Minkowski’s inequality")]#text("). From the complex triangle inequality ")#tao-math("\\left|f+g\\right| \\leq \\left|f\\right| + \\left|g\\right|", block: false)#text(", it suffices to check the case when f, g are non-negative. In this case we have the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|f+g\\right\\|_{L^p}^p = \\left\\| f \\left|f+g\\right|^{p-1} \\right\\|_{L^1} + \\left\\| g \\left|f+g\\right|^{p-1} \\right\\|_{L^1}", block: true)]]

#text("while Hölder’s inequality gives ")#tao-math("\\left\\| f \\left|f+g\\right|^{p-1} \\right\\|_{L^1} \\leq \\left\\|f\\right\\|_{L^p} \\left\\|f+g\\right\\|_{L^p}^{p-1}", block: false)#text(" and ")#tao-math("\\left\\| g \\left|f+g\\right|^{p-1} \\right\\|_{L^1} \\leq \\left\\|g\\right\\|_{L^p} \\left\\|f+g\\right\\|_{L^p}^{p-1}", block: false)#text(". The claim then follows from some algebra (and checking the degenerate cases separately, e.g. when ")#tao-math("\\left\\|f+g\\right\\|_{L^p}=0", block: false)#text("). ")#mi("\\diamond")

#strong[#text("Remark 8.")]#text(" The proofs of Hölder’s inequality and Minkowski’s inequality both relied on ")#link("http://en.wikipedia.org/wiki/Convex_function")[#text("convexity")]#text(" of various functions in ")#mi("{\\Bbb C}")#text(" or ")#mi("{}[0,+\\infty)")#text(". One way to emphasise this is to deduce both inequalities from ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(", which is an inequality which manifestly exploits this convexity. We will not take this approach here, but see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=1817225")[#text("book of Lieb and Loss")]#text(" for a discussion. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" It is instructive to test Hölder’s inequality (and also Exercises 8-12 below) in the special case when f, g are generalised step functions, say ")#mi("f = A 1_E")#text(" and ")#mi("g = B 1_F")#text(" with A, B non-zero. The inequality then simplifies to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\mu( E \\cap F )^{1/r} \\leq \\mu( E )^{1/p} \\mu( F )^{1/q}")]]

#text("which can be easily deduced from the hypothesis ")#mi("\\frac{1}{p} + \\frac{1}{q} = \\frac{1}{r}")#text(" and the trivial inequalities ")#mi("\\mu(E \\cap F) \\leq \\mu(E)")#text(" and ")#mi("\\mu(E \\cap F) \\leq \\mu(F)")#text(". One then easily sees (when p,q are finite) that equality in (8) only holds if ")#mi("\\mu(E \\cap F) = \\mu(E) = \\mu(F)")#text(", or in other words if E and F agree almost everywhere. Note the above computations also explain why the condition ")#mi("\\frac{1}{p}+\\frac{1}{q}=\\frac{1}{r}")#text(" is necessary. ")#mi("\\diamond")

#strong[#text("Exercise 8.")]#text(" Let ")#mi("0 < p,q < \\infty")#text(", and let ")#mi("f \\in L^p, g \\in L^q")#text(" be such that Hölder’s inequality is obeyed with equality. Show that of the functions ")#tao-math("\\left|f\\right|^p, \\left|g\\right|^q", block: false)#text(", one of them is a scalar multiple of the other (up to equivalence, of course). What happens if p or q is infinite? ")#mi("\\diamond")

#text("An important corollary of Hölder’s inequality is the ")#link("http://en.wikipedia.org/wiki/Cauchy-Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|\\int_X f(x) \\overline{g(x)}\\ d\\mu\\right| \\leq \\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2}", block: true)]]

#text("which can of course be proven by many other means.")

#strong[#text("Exercise 9.")]#text(" If ")#mi("f \\in L^p")#text(" for some ")#mi("0 < p \\leq \\infty")#text(", and is also supported on a set E of finite measure, show that ")#mi("f \\in L^q")#text(" for all ")#mi("0 < q \\leq p")#text(", with ")#tao-math("\\left\\|f\\right\\|_{L^q} \\leq \\mu(E)^{\\frac{1}{q}-\\frac{1}{p}} \\left\\|f\\right\\|_{L^p}", block: false)#text(". When does equality occur? ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" If ")#mi("f \\in L^p")#text(" for some ")#mi("0 < p < \\infty")#text(", and every set of positive measure in X has measure at least m, show that ")#mi("f \\in L^q")#text(" for all ")#mi("p < q \\leq \\infty")#text(", with ")#tao-math("\\left\\|f\\right\\|_{L^q} \\leq m^{\\frac{1}{q}-\\frac{1}{p}} \\left\\|f\\right\\|_{L^p}", block: false)#text(". When does equality occur? (This result is especially useful for the ")#mi("\\ell^p")#text(" spaces, in which ")#mi("\\mu")#text(" is counting measure and m can be taken to be 1.) ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" If ")#mi("f \\in L^{p_0} \\cap L^{p_1}")#text(" for some ")#mi("0 < p_0 < p_1 \\leq \\infty")#text(", show that ")#mi("f \\in L^p")#text(" for all ")#mi("p_0 \\leq p \\leq p_1")#text(", and that ")#tao-math("\\left\\|f\\right\\|_{L^p} \\leq \\left\\|f\\right\\|_{L^{p_0}}^{1-\\theta} \\left\\|f\\right\\|_{L^{p_1}}^{\\theta}", block: false)#text(", where ")#mi("0 < \\theta < 1")#text(" is such that ")#mi("\\frac{1}{p} = \\frac{1-\\theta}{p_0} + \\frac{\\theta}{p_1}")#text(". Another way of saying this is that the function ")#tao-math("\\frac{1}{p} \\mapsto \\log \\left\\| f\\right\\|_{L^p}", block: false)#text(" is convex. When does equality occur? This convexity is a prototypical example of interpolation, about which we shall say more in a later lecture. ")#mi("\\diamond")

#strong[#text("Exercise 12.")]#text(" If ")#mi("f \\in L^{p_0}")#text(" for some ")#mi("0 < p_0 \\leq \\infty")#text(", and its support ")#mi("E := \\{ x \\in X: f(x) \\neq 0 \\}")#text(" has finite measure, show that ")#mi("f \\in L^p")#text(" for all ")#mi("0 < p < p_0")#text(", and that ")#tao-math("\\left\\|f\\right\\|_{L^p}^p \\to \\mu(E)", block: false)#text(" as ")#mi("p \\to 0")#text(". (Because of this, the measure of the support of f is sometimes known as the ")#emph[#mi("L^0")#text(" norm")]#text(" of f, or more precisely the ")#mi("L^0")#text(" norm raised to the power 0.) ")#mi("\\diamond")

#heading(level: 1)[#text("— Linear functionals on ")#mi("L^p")#text(" —")]

#text("Given an exponent ")#mi("1 \\leq p \\leq \\infty")#text(", define the dual exponent ")#mi("1 \\leq p^{\\prime} \\leq \\infty")#text(" by the formula ")#mi("\\frac{1}{p} + \\frac{1}{p^{\\prime}} = 1")#text(" (thus ")#mi("p^{\\prime} = p/(p-1)")#text(" for ")#mi("1 < p < \\infty")#text(", while 1 and ")#mi("\\infty")#text(" are duals of each other). From Hölder’s inequality, we see that for any ")#mi("g \\in L^{p^{\\prime}}")#text(", the functional ")#mi("\\lambda_g: L^p \\to {\\Bbb C}")#text(" defined by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\lambda_g(f) := \\int_X f \\overline{g}\\ d\\mu")]]

#text("is well-defined on ")#mi("L^p")#text("; the functional is also clearly linear. Furthermore, Hölder’s inequality also tells us that this functional is continuous.")

#text("A deep and important fact about ")#mi("L^p")#text(" spaces is that, in most cases, the converse is true: the recipe (10) is the ")#emph[#text("only")]#text(" way to create continuous linear functionals on ")#mi("L^p")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" Let ")#mi("1 \\leq p < \\infty")#text(", and assume ")#mi("\\mu")#text(" is ")#mi("\\sigma")#text("-finite. Let ")#mi("\\lambda: L^p \\to {\\Bbb C}")#text(" be a continuous linear functional. Then there exists a unique ")#mi("g \\in L^{p^{\\prime}}")#text(" such that ")#mi("\\lambda = \\lambda_g")#text(".")
]

#text("This result should be compared with the Radon-Nikodym theorem (Corollary 1 from ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem")[#text("Notes 1")]#text("). Both theorems start with an abstract function ")#mi("\\mu: {\\mathcal X} \\to {\\Bbb R}")#text(" or ")#mi("\\lambda: L^p \\to {\\Bbb C}")#text(", and create a function out of it. Indeed, we shall see shortly that the two theorems are essentially equivalent to each other. We will develop Theorem 1 further in later lectures, once we introduce the notion of a ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("dual space")]#text(".")

#text("To prove Theorem 1, we first need a simple and useful lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Continuity is equivalent to boundedness for linear operators) Let ")#mi("T: X \\to Y")#text(" be a linear transformation from one normed vector space ")#mi("(X, \\| \\|_X)")#text(" to another ")#mi("(Y, \\| \\|_Y)")#text(". Then the following are equivalent:")

#enum(start: 1, 
[#text("T is continuous.")],
[#text("T is continuous at 0.")],
[#text("There exists a constant C such that ")#tao-math("\\left\\|Tx\\right\\|_Y \\leq C \\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("x \\in X")#text(".")]
)
]

#strong[#text("Proof.")]#text(" It is clear that 1 implies 2, and that 3 implies 2. Next, from linearity we have ")#mi("Tx = Tx_0 + T(x-x_0)")#text(" for any ")#mi("x,x_0 \\in X")#text(", which (together with the continuity of addition, which follows from the triangle inequality) shows that continuity of T at 0 implies continuity of T at any ")#mi("x_0")#text(", so that 2 implies 1. The only remaining task is to show that 1 implies 3. By continuity, the inverse image of the unit ball in Y must be an open neighbourhood of 0 in X, thus there exists some radius ")#mi("r > 0")#text(" such that ")#tao-math("\\left\\|Tx\\right\\|_Y < 1", block: false)#text(" whenever ")#tao-math("\\left\\|x\\right\\|_X < r", block: false)#text(". The claim then follows (with ")#mi("C :=1/r")#text(") by homogeneity. (Alternatively, one can deduce 3 from 2 by contradiction. If 3 failed, then there exists a sequence ")#mi("x_n")#text(" of non-zero elements of X such that ")#tao-math("\\left\\|Tx_n\\right\\|_Y / \\left\\|x_n\\right\\|_X", block: false)#text(" goes to infinity. By homogeneity, we can arrange matters so that ")#tao-math("\\left\\|x_n\\right\\|_X", block: false)#text(" goes to zero, but ")#tao-math("\\left\\|Tx_n\\right\\|_Y", block: false)#text(" stays away from zero, thus contradicting continuity at 0.) ")#mi("\\Box")

#strong[#text("Proof of Theorem 1.")]#text(" The uniqueness claim is similar to the uniqueness claim in the Radon-Nikodym theorem (Exercise 2 from ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("Notes 1")]#text(") and is left as an exercise to the reader; the hard part is establishing existence.")

#text("Let us first consider the case when ")#mi("\\mu")#text(" is finite. The linear functional ")#mi("\\lambda: L^p \\to {\\Bbb C}")#text(" induces a functional ")#mi("\\nu: {\\mathcal X} \\to {\\Bbb C}")#text(" on sets E by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\nu(E) := \\lambda(1_E).")]]

#text("Since ")#mi("\\lambda")#text(" is linear, ")#mi("\\nu")#text(" is finitely additive (and sends the empty set to zero). Also, if ")#mi("E_1,E_2,\\ldots")#text(" are a sequence of disjoint sets, then ")#mi("1_{\\bigcup_{n=1}^N E_n}")#text(" converges in ")#mi("L^p")#text(" to ")#mi("1_{\\bigcup_{n=1}^\\infty E_n}")#text(" as ")#mi("n \\to \\infty")#text(" (by the dominated convergence theorem and the finiteness of ")#mi("\\mu")#text("), and thus (by continuity of ")#mi("\\lambda")#text(" and finite additivity of ")#mi("\\nu")#text("), ")#mi("\\nu")#text(" is countably additive as well. Finally, from (11) we also see that ")#mi("\\nu(E)=0")#text(" whenever ")#mi("\\mu(E)=0")#text(", thus ")#mi("\\nu")#text(" is absolutely continuous with respect to ")#mi("\\mu")#text(" (in the sense that its real and imaginary parts are). Applying the Radon-Nikodym theorem (Corollary 1 from ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem")[#text("Notes 1")]#text(") to both the real and imaginary components of ")#mi("\\nu")#text(", we conclude that ")#mi("\\nu = \\mu_g")#text(" for some ")#mi("g \\in L^1")#text("; thus by (11) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\lambda(1_E) = \\lambda_g(1_E)")]]

#text("for all measurable E. By linearity, this implies that ")#mi("\\lambda")#text(" and ")#mi("\\lambda_g")#text(" agree on simple functions. Taking uniform limits (using Exercise 7) and using continuity (and the finite measure of ")#mi("\\mu")#text(") we conclude that ")#mi("\\lambda")#text(" and ")#mi("\\lambda_g")#text(" agree on all bounded functions. Taking monotone limits (working on the positive and negative supports of the real and imaginary parts of g separately) we conclude that ")#mi("\\lambda")#text(" and ")#mi("\\lambda_g")#text(" agree on all functions in ")#mi("L^p")#text(", and in particular that ")#mi("\\int_X f \\overline{g}\\ d\\mu")#text(" is absolutely convergent for all ")#mi("f \\in L^p")#text(".")

#text("To finish the theorem in this case, we need to establish that g lies in ")#mi("L^{p^{\\prime}}")#text(". By taking real and imaginary parts we may assume without loss of generality that g is real; by splitting into the regions where g is positive and negative we may assume that g is non-negative.")

#text("We already know that ")#mi("\\lambda_g = \\lambda")#text(" is a continuous functional from ")#mi("L^p")#text(" to ")#mi("{\\Bbb C}")#text(". By Lemma 2, this implies a bound of the form ")#tao-math("\\left|\\lambda_g(f)\\right| \\leq C \\left\\|f\\right\\|_{L^p}", block: false)#text(" for some ")#mi("C > 0")#text(".")

#text("Suppose first that ")#mi("p > 1")#text(". Heuristically, we would like to test this inequality with ")#mi("f := g^{p^{\\prime}-1}")#text(", since we formally have ")#tao-math("\\lambda_g(f) = \\left\\|g\\right\\|_{L^{p^{\\prime}}}^{p^{\\prime}}", block: false)#text(" and ")#tao-math("\\left\\|f\\right\\|_{L^p} = \\left\\|g\\right\\|_{L^{p^{\\prime}}}^{p^{\\prime}-1}", block: false)#text(". (Not coincidentally, this is also the choice that would make Hölder’s inequality an equality, see Exercise 8.) Cancelling the ")#tao-math("\\left\\|g\\right\\|_{L^{p^{\\prime}}}", block: false)#text(" factors would then give the desired finiteness of ")#tao-math("\\left\\|g\\right\\|_{L^{p^{\\prime}}}", block: false)#text(".")

#text("We can’t quite make that argument work, because it is circular: it assumes ")#tao-math("\\left\\|g\\right\\|_{L^{p^{\\prime}}}", block: false)#text(" is finite in order to show that ")#tao-math("\\left\\|g\\right\\|_{L^{p^{\\prime}}}", block: false)#text(" is finite! But this can be easily remedied. We test the inequality with ")#mi("f_N := \\min(g,N)^{p^{\\prime}-1}")#text(" for some large N; this lies in ")#mi("L^p")#text(". We have ")#tao-math("\\lambda_g(f_N) \\geq \\left\\|\\min(g,N)\\right\\|_{L^{p^{\\prime}}}^{p^{\\prime}}", block: false)#text(" and ")#tao-math("\\left\\|f_N\\right\\|_{L^p} = \\left\\|\\min(g,N)\\right\\|_{L^{p^{\\prime}}}^{p^{\\prime}-1}", block: false)#text(", and hence ")#tao-math("\\left\\| \\min(g,N)\\right\\|_{L^{p^{\\prime}}} \\leq C", block: false)#text(" for all N. Letting N go to infinity and using monotone convergence, we obtain the claim.")

#text("In the p=1 case, we instead use ")#mi("f := 1_{g>N}")#text(" as the test functions, to conclude that g is bounded almost everywhere by N; we leave the details to the reader.")

#text("This handles the case when ")#mi("\\mu")#text(" is finite. When ")#mi("\\mu")#text(" is ")#mi("\\sigma")#text("-finite, we can write X as the union of an increasing sequence ")#mi("E_n")#text(" of sets of finite measure. On each such set, the above arguments let us write ")#mi("\\lambda = \\lambda_{g_n}")#text(" for some ")#mi("g_n \\in L^{p^{\\prime}}(E_n)")#text(". The uniqueness arguments tell us that the ")#mi("g_n")#text(" are all compatible with each other, in particular if ")#mi("n < m")#text(", then ")#mi("g_n")#text(" and ")#mi("g_m")#text(" agree on ")#mi("E_n")#text(". Thus all the ")#mi("g_n")#text(" are in fact restrictions of a single function g to ")#mi("E_n")#text(". The previous arguments also tell us that the ")#mi("L^{p^{\\prime}}")#text(" norm of ")#mi("g_n")#text(" is bounded by the same constant C uniformly in n, so by monotone convergence, g has bounded ")#mi("L^{p^{\\prime}}")#text(" norm also, and we are done. ")#mi("\\Box")

#strong[#text("Remark 9.")]#text(" When ")#mi("1 < p < \\infty")#text(", the hypothesis that ")#mi("\\mu")#text(" is ")#mi("\\sigma")#text("-finite can be dropped, but not when ")#mi("p=1")#text("; see e.g. Section 6.2 of Folland for further discussion. In these lectures, though, we will be content with working in the ")#mi("\\sigma")#text("-finite setting. On the other hand, the claim fails when ")#mi("p=\\infty")#text(" (except when X is finite); we will see this in later lectures, when we discuss the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 10.")]#text(" We have seen how the Lebesgue-Radon-Nikodym theorem can be used to establish Theorem 1. The converse is also true: Theorem 1 can be used to deduce the Lebesgue-Radon-Nikodym theorem (a fact essentially observed by von Neumann). For simplicity, let us restrict attention to the unsigned finite case, thus ")#mi("\\mu")#text(" and ")#mi("m")#text(" are unsigned and finite. This implies that the sum ")#mi("\\mu+m")#text(" is also unsigned and finite. We observe that the linear functional ")#mi("\\lambda: f \\mapsto \\int_X f\\ d\\mu")#text(" is continuous on ")#mi("L^1(\\mu+m)")#text(", hence by Theorem 1 there must exist a function ")#mi("g \\in L^\\infty(\\mu+m)")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_X f\\ d\\mu =\\int_X f \\overline{g}\\ d(\\mu+m)")]]

#text("for all ")#mi("f \\in L^1(\\mu+m)")#text(". It is easy to see that g must be real and non-negative, and also at most 1 almost everywhere. If E is the set where g=1, we see by setting ")#mi("f=1_E")#text(" in (13) that E has m-measure zero, and so ")#mi("\\mu\\downharpoonright_E")#text(" is singular. Outside of E, we see from (13) and some rearrangement that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\int_{X \\backslash E} (1-g) f\\ d\\mu = \\int_X f g\\ dm")]]

#text("and one then easily verifies that ")#mi("\\mu")#text(" agrees with ")#mi("m_{\\frac{g}{1-g}}")#text(" outside of E’. This gives the desired Lebesgue-Radon-Nikodym decomposition ")#mi("\\mu = m_{\\frac{g}{1-g}} + \\mu\\downharpoonright_E")#text(".")#linebreak()#text(" ")#mi("\\diamond")

#strong[#text("Remark 11.")]#text(" The argument used in Remark 10 also shows that the Radon-Nikodym theorem implies the Lebesgue-Radon-Nikodym theorem. ")#mi("\\diamond")

#text("In a later set of notes, we will give an alternate proof of Theorem 1, which relies on the geometry of ")#mi("L^p")#text(" spaces rather than on the Radon-Nikodym theorem, and can thus be viewed as giving an independent proof of that theorem.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (144)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-479029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("In 247a notes 1 Problem 5.3 “Show that the triangle inequality is sharp if and only if ")#mi("f,g")#text("” are parallel, thus either ")#mi("f=0")#text(", ")#mi("g=0,")#text(" or ")#mi("f=cg")#text(" for some real positive $c$. ”")

#text("Must ")#mi("c")#text(" here be a constant? (What does “parallel” mean here?)")

#text("Suppose ")#mi("f(x)=x^2g(x)")#text(". Isn’t it true that")

#tao-math("\\displaystyle \\left\\|f+g\\right\\|_{L^1([0,1])}=\\left\\|f\\right\\|_{L^1([0,1])}+\\left\\|g\\right\\|_{L^1([0,1])}?", block: false)

#emph[#text("[Problem 5.3 in those notes should have the additional constraint ")#mi("1 < p < \\infty")#text(". Parallel here is in the sense of parallel vectors in a vector space. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-479357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("For Exercise 4(1), I can only show that")

#tao-math("\\displaystyle \\limsup_{p\\to\\infty}\\left\\|f\\right\\|_p\\leq\\left\\|f\\right\\|_\\infty", block: false)

#text("since ")#tao-math("\\left|f\\right|\\leq\\left\\|f\\right\\|_\\infty", block: false)#text(" a.e.")

#text("How should I do the other direction?")

#text("—–")#linebreak()#text(" Would you elaborate how is one supposed to use the monotone convergence theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-488847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2017")])]

#text("Do you have a hint for Exercise 1(4)? I have no idea how to get information out of")#linebreak()#text(" ")#tao-math("\\left\\|f+g\\right\\|=\\left\\|f\\right\\|+\\left\\|g\\right\\|", block: false)#linebreak()#text(" when ")#tao-math("\\left\\|f\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|g\\right\\|", block: false)#text(" are both positive.")

#text("I have worked on the triangle inequality in the Euclidean spaces ")#mi("{\\bf R}^d")#text(" (corresponding to counting measure on the space with finite cardinality I think). I find that the cases ")#mi("d>3")#text(" have been difficult for me: one cannot make a geometric argument…")

#emph[#text("[Hint: review your solution to Exercise 1(2). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-488900")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("Since for ")#mi("0<p<1")#text(", the function ")#tao-math("x\\mapsto \\left|x\\right|^p", block: false)#text(" is concave, one has the reverse inequality in (4) and (5) in the proof of lemma 1 so that one can conclude the reverse inequality for ")#mi("L^p")#text(" (")#mi("0<p<1")#text(") for all ")#mi("f,g")#text(", which is obviously not true. What goes wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-488902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("“reverse inequality” should be “reverse triangle inequality” above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-488926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2017")])]

#text("The function ")#tao-math("x \\mapsto \\left|x\\right|^p", block: false)#text(" is not concave at zero. However, as long as one avoids zero, one does get a reverse triangle inequality: see part 2 of Exercise 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vi")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-677640")[#strong[#text("Vi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2023")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Taking your hint for Exercise 1(4), I see that proving the proportionality boils down to proving that the inequality ")#mi("(w_1 a + w_2 b)^p \\geq w_1 a^p + w_2 b^p \\,\\, w_1 + w_2 =1")#text(" is sharp iff ")#mi("a = b")#text(". Is there an elementary way to prove this equality condition? Can you please give a hint (Does holders inequality help?) thanks")

#emph[#text("[This is equivalent to the ")#link("https://en.wikipedia.org/wiki/Strictly_convex")[#text("strict convexity")]#text(" of the function ")#mi("x \\mapsto x^p")#text(" – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-488906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2017")])]

#text("For Exercise 1(3), one can exploit ")#mi("\\frac{a^p+b^p}{2}\\leq(\\frac{a+b}{2})^p")#text(" to get the constant ")#mi("2^{\\frac1p-1}")#text(". But how can one show that this the “best” constant?")

#emph[#text("[Hint: think about when equality occurs in the inequality you mentioned. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-488971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2017")])]

#text("Do you have a hint for Exercise 10? I tried the “simplest” case first but I don’t see how to go on after writing down the definition:")#linebreak()#text(" how to get ")#tao-math("\\left\\|f\\right\\|_\\infty\\leqslant m^{-1/p}\\left\\|f\\right\\|_p", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-489222")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2017")])]

#text("You might find the general problem solving strategies in ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" to be of assistance. In particular, strategy 3 may help: try first the situation of an indicator function, then a simple function, to get an idea of how to solve the general case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-489007")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2017")])]

#text("Suppose ")#mi("0<p\\leq q\\leq \\infty")#text(". In your 274a notes, it is said that if ")#mi("f")#text(" is bounded above by a constant ")#mi("M")#text(", then")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_q\\leq\\left\\|f\\right\\|_p^{p/q}M^{1-p/q}", block: false)#linebreak()#text(" which could be done by the log-convexity at the ")#mi("\\infty")#text(" exponent, while if ")#mi("f")#text(" is bounded below by ")#mi("M")#text(" on its support, then one has the reverse inequality")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_p\\leq\\left\\|f\\right\\|_q^{q/p}M^{1-q/p}", block: false)

#text("How do you prove the second one?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-489049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("I have just asked a stupid question. Found that the second one follows from the pointwise estimate:")#linebreak()#text(" ")#mi("\\frac{f(x)}{M}\\geq 1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-509458")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("[…] to achieve a normalisation , which can be convenient for some proofs of this inequality (see this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-551115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Can one prove that ")#mi("\\ell^p(\\mathbf{N})")#text(" (")#mi("0<p<\\infty")#text(") is separable without invoking Exercise 7a?")

#text("What can one say about separability in general for arbitrary ")#mi("L^p")#text(" (")#mi("0<p<\\infty")#text(") spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-551126")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2020")])]

#text("Separability of Lebesgue spaces is closely related to ")#link("https://en.wikipedia.org/wiki/%CE%A3-algebra#Separable_%CF%83-algebras")[#text("separability")]#text(" of the underlying sigma-algebra.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-551299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2020")])]

#text("In your PCM article of harmonic analysis:")

#emph[#linebreak()#text(" … ")#mi("L^\\infty")#text(" control eliminates all the spiky functions and ")#mi("L^1")#text(" control eliminates most of the broad functions, and the remaining functions end up being well behaved in the intermediate norm ")#mi("L^2")#text(".")#linebreak()#text(" ")]

#text("So the “control of two ‘extreme’ norms automatically implies further control on ‘intermediate’ norms… ”")

#text("Why in the log convexity inequality")

#tao-math("\\displaystyle \\left\\|f\\right\\|_2\\leq \\left\\|f\\right\\|_p^{1-\\theta}\\left\\|f\\right\\|_{q}^{\\theta}", block: false)

#text("one needs the “extra” constraint that")

#mi("\\displaystyle \\frac{1}{2} = \\frac{1-\\theta}{p}+\\frac{\\theta}{q}\\quad?")

#text("instead of just for all ")#mi("p")#text(" and ")#mi("q")#text(" with ")#mi("p<2<q")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-551321")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2020")])]

#text("The constraint ")#mi("\\frac{1}{2} = \\frac{1-\\theta}{p} + \\frac{\\theta}{q}")#text(" can be viewed as determining the exact exponent of ")#mi("\\theta")#text(" that makes the inequality true; it is mandated for instance by dimensional analysis or scale invariance considerations (as discussed for instance in my recent lecture notes ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-553471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("So the ")#mi("L^p")#text(" norm of a function says something about the “width” and “height” of the function. What is the intuition of the ")#emph[#text("weak")]#text(" ")#mi("L^p")#text(" norm? In other words, intuitively, what “information” one gains if one can control the weak ")#mi("L^p")#text(" norm of a function ")#mi("f")#text(":")

#mi("\\displaystyle [f]_p = (\\sup_{a>0}a^p\\lambda_f(a))^{1/p}\\quad ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-553485")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("For a function which mostly exists at a single scale, with a single width and height, the strong and weak ")#mi("L^p")#text(" norms are basically equivalent (as are all the other Lorentz norms ")#mi("L^{p,q}")#text(" at this exponent). The distinction between the strong and weak norms only becomes apparent when considering functions that exist at multiple scales. For instance consider the function")

#mi("\\displaystyle f(x) = \\sum_{i=1}^n N_i^{-1/p} 1_{[N_i, 2N_i]}")

#text("on ")#mi("{\\bf R}")#text(", where ")#mi("1 < N_1 < N_2 < \\dots < N_n")#text(" are widely separated scales (the exact choice is not important for this example so long as ")#mi("N_{i+1} \\geq 2N_i")#text(" for each ")#mi("1 \\leq i < n")#text("). Each individual term ")#mi("N_i^{-1/p} 1_{[N_i,2N_i]}")#text(" in this expression has both strong and weak ")#mi("L^p")#text(" norm equal to 1, as befits a function of height ")#mi("N_i^{-1/p}")#text(" and width ")#mi("N_i")#text("; but the sum ")#mi("f")#text(" has a strong ")#mi("L^p")#text(" norm of ")#mi("n^{1/p}")#text(" and a weak ")#mi("L^p")#text(" norm comparable to 1. (More generally, the ")#mi("L^{p,q}")#text(" norm is comparable to ")#mi("n^{1/q}")#text(" in this example.)")

#text("To put it another way: up to logarithmic corrections, all the ")#mi("L^{p,q}")#text(" norms can be thought of as “")#mi("\\mathrm{height} \\times \\mathrm{width}^{1/p}")#text("''. If one wishes to take logarithmic corrections into account (but are possibly willing to ignore double logarithmic corrections), one can think of the ")#mi("L^{p,q}")#text(" norm as basically being the worst value of “")#mi("\\mathrm{height} \\times \\mathrm{width}^{1/p}")#text("'' present in the function, times the number of scales where this worst value is attained raised to the power ")#mi("1/q")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-553516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2020")])]

#text("I have seen the term “scales” (of a function) mentioned quite a few times in some of your articles. But I don’t really follow what it means. It seems to be a loose term, but it was used in various rigorous arguments. (For instance, it is the theme of this article: ")#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/")[#text("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/")]#text(") Would you elaborate on what it really means? For instance, is the function ")#mi("f=100\\cdot 1_{[0,1]}")#text(" considered as “large scale while ")#mi("f=0.001\\cdot 1_{[0,1]}")#text(" as “small scale”? Does it also have anything to do with the (size) support of the function?")

#text("Going back to the example you gave in the comment, besides “small” and “big” scales, you also seem to tell the difference between “single” scale vs “multiple” scales. What does that mean? (Can such terms be defined in a mathematical way?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-553751")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("Informally, a scale is an order of magnitude of length (or some other physically or geometrically meaningful quantity). For instance, the Earth is essentially flat at human scales (~1m), essentially a ball at global scales (~10^7 m), and essentially a point at astronomical scales (e.g., 1AU or larger); at the opposite extreme, the Earth becomes a discrete lattice-like object at molecular scales (~1 Å) and a very weird sea of quantum foam at the Planck scale. All of these scales are meaningful, but if one wants to study the Earth as a whole, it is the global scale (~10^7 m) that is the most relevant.")

#text("A step function ")#mi("f = A 1_{[0,N]}")#text(" would have a significant presence at one amplitude scale ")#mi("A")#text(" and one length scale ")#mi("N")#text("; a sum of two functions ")#mi("f= A_1 1_{[0,N_1]} + A_2 1_{[1,N_2]}")#text(" with two very different amplitudes ")#mi("A_1,A_2")#text(" and two different widths ")#mi("N_1,N_2")#text(" would exist at two amplitude scales and two length scales. For functions that are normalised to be of roughly unit size in ")#mi("L^p")#text(" or weak ")#mi("L^p")#text(", the amplitude ")#mi("A")#text(" and width ")#mi("W")#text(" become constrained to each other by the relation ")#mi("A W^{1/p} \\approx 1")#text(" (at least for the “dominant” scale components of the function), so there is really only one degree of freedom in scale in this context. (For more complicated norms, such as mixed norms or Sobolev norms, there can be multiple independent notions of scale, for instance there can be a frequency scale in addition to a spatial scale that are partially connected to each other by the uncertainty principle but which can otherwise vary independently.) Whether one considers ")#mi("100")#text(", ")#mi("1")#text(", and ")#mi("0.001")#text(" to be distinct scales depends on your point of view; for real world applications a change of two or three orders of magnitude can make a lot of difference, but in many problems in analysis we ignore the effect of absolute constants and all such scales would be considered equivalent in the asymptotic regime.")

#text("It’s possible to make the notion of scale more rigorous if one works in the formalism of nonstandard analysis (which among other things allows one to mathematically define the concept of “order of magnitude” in a completely rigorous fashion), but at your current level of understanding I recommend keeping these notions of scale as informal concepts rather than attempt to assign precise rigorous meaning to them.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-598521")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("I also have no idea about how to use the Monotone convergence theorem to deduce the result? Should we construct a sequence of functions monotone in p, or use another method? Would you elaborate how is one supposed to use the monotone convergence theorem?")#linebreak()#text(" Thanks very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-598524")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Sorry I forgot to refer to the exercise. It is Exercise 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-598637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("You can use the monotone convergence theorem to approximate ")#mi("f")#text(" by a bounded function with finite measure support, and reduce to verifying the claim for the latter classes of function; a further application of monotone convergence (or rounding arguments) can then be used to reduce to the case of simple functions with finite measure support, which can be checked by direct calculation. (It is also possible for this particular exercise to skip some of these steps and obtain a shorter ")#emph[#text("ad hoc")]#text(" proof that avoids explicit mention of monotone convergence, but this technique of using convergence theorems to reduce to simpler classes of functions is broadly applicable.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-598674")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Thank you! I succeed to verify the claim when ")#mi("f")#text(" is a simple function by direct calculation. Then I followed the simple approximation lemma which express a measurable function as a limit of a sequence of increasing simple functions ")#mi("\\{f_n\\}")#text(", then I tried to use the monotone convergence theorem. But there is still a gap which I cannot fill it, and I think it is the key step: How to verify the two limits are interchangeable?")#linebreak()#text(" ")#tao-math("\\lim_{p\\to \\infty}\\lim_{n\\to \\infty}\\left|\\left|f_n\\right|\\right|_p=\\lim_{n\\to \\infty}\\lim_{n\\to \\infty}\\left|\\left|f_n\\right|\\right|_p", block: false)

#emph[#text("[As indicated in the preceding reply, this is easiest to establish in the special case when ")#mi("f")#text(" (and hence ")#mi("f_n")#text(") are bounded and have finite measure support, as Holder’s inequality will give enough quantitative continuity to interchange limits. A further approximation argument is then needed to recover the general case. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-598676")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Sorry, again one typo: the first “n” in the right-hand side should be “p”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#emph[#text(" as Holder’s inequality will give enough quantitative continuity to interchange limits.")]

#text("I don’t understand why Holder’s inequality is needed or how it may be useful anywhere. Can you please elaborate?")

#text("If one has already established for a class of function ")#mi("\\{f_n\\}")#text(" so that")#linebreak()#text(" ")#tao-math("\\left\\|f_n\\right\\|_p\\to \\left\\|f_n\\right\\|_\\infty", block: false)#text(" as ")#mi("p\\to\\infty")#text(", and this class of function is such that it approximates ")#mi("f")#text(" in ")#mi("L^p")#text(" and also ")#mi("L^\\infty")#text(", then to pass to the limit to establish the result for ")#mi("f")#text(", one can use (can one?)")

#tao-math("\\displaystyle \\left\\|f\\right\\|_p-\\left\\|f\\right\\|_\\infty \\le \\left|\\left\\|f\\right\\|_p-\\left\\|f_n\\right\\|_p\\right|+\\left|\\left\\|f_n\\right\\|_p-\\left\\|f_n\\right\\|_\\infty\\right| +\\left|\\left\\|f_n\\right\\|_\\infty-\\left\\|f\\right\\|_{\\infty}\\right|", block: false)

#text("where the first and third terms are estimated by the approximation property of the class and the second term is controlled by the established result for ")#mi("f_n")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641814")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("It seems that the inequality above is too long to parse:")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_p-\\left\\|f\\right\\|_\\infty \\le  \\big{\\left|\\left\\|f\\right\\|_p-\\left\\|f_n\\right\\|_p\\right|} +\\big{\\left|\\left\\|f_n\\right\\|_p-\\left\\|f_n\\right\\|_\\infty\\right|}", block: false)#linebreak()#text(" ")#tao-math("+\\left|\\left\\|f_n\\right\\|_\\infty-\\left\\|f\\right\\|_{\\infty}\\right|", block: false)
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vi")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-677842")[#strong[#text("Vi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2023")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Why do we need the special case of “finite measure support”. Shouldn’t any simple function ")#mi("\\phi \\leq f")#text(" where ")#mi("f \\in L_p")#text(" necessarily have finite measure support (otherwise ")#tao-math("\\left|\\left|\\phi\\right|\\right|_{p}", block: false)#text(" would blow up?). Can you please clarify?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-677865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2023")])]

#mi("\\phi\\leq f")#text(" doesn’t mean ")#tao-math("\\left|\\left|\\phi\\right|\\right|_{L^p}", block: false)#text(" is finite. It just means the magnitude of ")#mi("\\phi")#text(" is less than the magnitude of ")#mi("f")#text(". If it doesn’t have finite support, then ")#tao-math("\\left|\\left|\\phi\\right|\\right|_{L^p}", block: false)#text(" could be infinite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-678071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("Is the explanation above wrong?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-599570")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("This problem is interesting and impressive to me.")#linebreak()#text(" Using Holder inequality for continuity (in which sense?) and interchanging limits seems novel to me, I tried again and again and still cannot figure it out. Any more hints or comments?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-599583")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("Really eager to know the rigorous process dealing with the interchange of the limit ~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-599587")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("It is very kind of you to spend no effort replying our doubts. Also, I think the changing of limits should use the condition ")#mi("f \\in L^p")#text(". I think I may be exhausted, and discussed on this problem (Exercise 4) with many of my classmates but they still did not figure it out the key step of the feasibility of interchanging the limits.")#linebreak()#text(" Wish Mr. Tao to give a reply.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-599589")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2020")])]

#text("Sorry, I mean “")#mi("f \\in L^{p_0}")#text("“")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641812")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("I am confused by the comment:")

#emph[#linebreak()#text(" You can use the monotone convergence theorem to approximate f by a bounded function with finite measure support, and reduce to verifying the claim for the latter classes of function; a further application of monotone convergence (or rounding arguments) can then be used to reduce to the case of simple functions with finite measure support, which can be checked by direct calculation.")#linebreak()#text(" ")]

#text("How can one first show that ")#mi("f\\in L^p")#text(" for all ")#mi("p\\ge p_0")#text(" or sufficiently large ")#mi("p")#text(" so that it makes sense to talk about the limit of")#linebreak()#text(" ")#tao-math("\\left\\|f\\right\\|_{L^p}", block: false)#text(" as ")#mi("p\\to\\infty")#text("? Or one need not show this at all?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641815")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("Is this argument also applied to Part 2 of Exercise 4?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-607536")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("In the proof of Proposition 2, I think we should use the dominated convergence theorem instead of the monotone convergence theorem, since the monotone convergence does not guarantee the passing of the limit in the absolute function.")

#emph[#text("[One can use either, if one first works with non-negative ")#mi("L^p")#text(" functions – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-624895")[#strong[#text("How to show that $|f|_{L^p} to |f|_{L^infty}$ as $p to infty$ if $f in L^infty cap L^{p_0}$ for some $0 < p_0 < infty$? ~ Mathematics ~ mathubs.com")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2021")]

#text("[…] This problem is from Terrence Tao’s blog: Exercise 4 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-635190")[#strong[#text("How to understand \"It takes a little bit of getting used to the idea...\"? - English Vision")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2021")]

#text("[…] The following sentence is from a mathematical lecture note here: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641593")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2022")])]

#text("Different structures are listed for the ")#mi("L^p")#text(" spaces at the beginning of the post.")

#text("When you use the word “subspace” in various places of the post, e.g., Proposition 2, Exercise 7, are you assuming ")#emph[#text("all")]#text(" the sub-structures in the list? Or just some of them, for instance, a “linear” subspace in the category of vector spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641596")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2022")])]

#text("By default, subspaces here refer to linear subspaces, and most of the structures listed (e.g., metric, topology, norm, inner product) are inherited by such linear subspaces in the usual fashion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641595")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2022")])]

#text("In Exercise 4.2, which strategies in ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" can one use?")

#text("A density argument seems not possible due to the form of the statement. If one tries the contrapositive, and assume")#linebreak()#text(" ")#tao-math("\\limsup_p \\left\\|f\\right\\|_p=L<\\infty", block: false)#text(", then one wants to show that ")#mi("f\\in L^\\infty")#text(". This is easy for simple functions. How can one upgrade this to functions with finite measure support? In order to apply a density, one ends up with the need of assuming that ")#tao-math("\\left\\|f\\right\\|_\\infty", block: false)#text(" is finite if one wants to proceed with an estimate that works for Exercise 4.1 when \"passing to the limit\":")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|\\left\\|f\\right\\|_p-\\left\\|f\\right\\|_\\infty\\right|\\le \\left\\|f-f_n\\right\\|_p + \\left|\\left\\|f_n\\right\\|_p-\\left\\|f_n\\right\\|_\\infty \\right|+\\left\\|f_n-f\\right\\|_\\infty", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641635")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("In the proof of Theorem 1:")#linebreak()#text(" ")#emph[#linebreak()#text(" … Finally, from (11) we also see that … , thus ")#mi("\\nu")#text(" is absolutely continuous with respect to ")#mi("\\mu")#text(".")#linebreak()#text(" ")]

#text("Is the notion of “absolutely continuous” defined for “complex measures” yet somewhere in the previous sets of notes? It seems that this is where a “complex measure” is (implicitly) used the first time.")

#text("Without “complex measures”, this may be simply changed to")

#text("… *both the real and imaginary parts of* ")#mi("\\nu")#text(" is absolutely continuous with respect to ")#mi("\\mu")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641641")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("In Remark 10, when Theorem 1 is used to deduce the Lebesgue-Radon-Nikodym theorem, can one consider ")#mi("\\lambda")#text(" as a functional on ")#mi("L^p")#text(" with other values of ")#mi("p")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-641734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("Well, since we are assuming finite measure, ")#mi("L^p")#text(" is a subspace of ")#mi("L^1")#text(" for ")#mi("p>1")#text(" thanks to Holder’s inequality, so the answer to your question is “yes”. For instance in some texts the ")#mi("L^2")#text(" duality theorem of Riesz is used to establish the Radon-Nikodym theorem in this fashion (I believe Rudin does so, but this is from memory and I do not have a copy physically at hand to check this).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0bdf148cca93750101dc23265ed54be609c0be0d7f445643de26cecb411039-97a60200c98e2df985a9bc6487d5cd3b9bd3d9215ce1ff05752f6f6388dc9443.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YM")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-678070")[#strong[#text("YM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2023")])]

#text("I think your remark 10 (which uses general $L^p$ duality?) essentially does the same thing that Rudin does (who also credits von Neumann)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-649519")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2022")])]

#text("Do all the inequalities about Lp-norms hold if one replaces big Lp by little lp-norm? It seems fine as Lp space includes lp space. But I would like to confirm.")

#emph[#text("[Yes; see Remark 2. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-671790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2023")])]

#text("You seem to use the label “Lemma 1” twice for two different theorems.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b488df94717a94de73656e78f48c2637cf97a3d7c6ce7400d1d37a6fe76a84a7-eff86ee9a4f347d3383f5ac80499c7f10f3a5c1106cef5b23be9cc9a6568adf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mayoorathy Vishagan")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-677411")[#strong[#text("Mayoorathy Vishagan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2023")])]

#text("Dear Prof. Tao")#linebreak()#text(" I am not able to progress with part 5 of exercise . Should we show this first to simple functions and use some kind of convergence argument? Can you give a hint? thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b488df94717a94de73656e78f48c2637cf97a3d7c6ce7400d1d37a6fe76a84a7-eff86ee9a4f347d3383f5ac80499c7f10f3a5c1106cef5b23be9cc9a6568adf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mayoorathy Vishagan")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-677413")[#strong[#text("Mayoorathy Vishagan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2023")])]

#text("Sorry it is exercise1 part 4")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-678008")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2023")])]

#text("For ex: 8, the statement “scalar multiple of the other” is only true when ")#mi("f, g")#text(" are non-negative right?")

#emph[#text("[Correction added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-678580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2023")])]

#text("In theorem 1, to prove ")#mi("g \\in L_p^{\\prime}")#text(", I see for example how we can use the test function ")#tao-math("g_N = min(\\left|g\\right|, N) \\bar{sgn g}", block: false)#text(" to prove the result along the same lines as you state.")

#text("I am not however able to follow your line of thought “By taking real and imaginary parts we may assume without loss of generality that g is real ….”. Do you mean taking real & imaginary parts of $g$? How does that reduce it to the real and then positive case?")

#emph[#text("[One takes the real and imaginary parts of ")#mi("\\lambda")#text(" to obtain the real and imaginary parts of ")#mi("g")#text(", then puts those parts back together to reconstruct the complex ")#mi("g")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-681815")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")])]

#text("can you provide the solution to exercise 7a?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-682748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2024")])]

#text("In the definition of the infinity norm:")

#text("We say that a function ")#mi("f: X \\to {\\Bbb C}")#text(" is essentially bounded if there exists an M such that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for almost every x, and define ")#tao-math("\\left\\|f\\right\\|_{L^\\infty}", block: false)#text(" to be the least ")#mi("M")#text(" that serves as such a bound.")

#text("is there an example where one can only use the “infimum” (so that the “least” M does not exist) instead of the “minimum” of the ")#mi("M")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-682750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2024")])]

#text("By ")#mi("f^{-1}(S)")#text(" we mean the preimage of ")#mi("S")#text(".")

#text("Every value larger than ")#mi("M")#text(" works as such a bound by assumption. ")#mi("M+1>M")#text(",")

#mi("\\displaystyle \\mu(f^{-1}([M+1,+\\infty)))=0")

#mi("\\displaystyle \\mu(f^{-1}([M+\\frac1 2,M+1)))=0")

#mi("\\displaystyle \\forall n.\\mu([M+\\frac1 {2^{n+1}},M+\\frac1 {2^n}))=0")

#text("Lastly, countable additivity implies")

#mi("\\mu((M,+\\infty))=0")

#text("As easy as usual, ")#mi("M")#text(" serves as such a bound, be the least as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-682755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2024")])]

#text("If the least M doesn’t exist, then f is not essentially bounded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-682759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2024")])]

#text("and ")#tao-math("\\left\\|f\\right\\|_\\infty=+\\infty", block: false)#text(".")

#text("Set ")#mi("F=||\\circ f")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-685097")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2024")])]

#text("I solved exercise 7a here ")#link("https://math.stackexchange.com/questions/4923301/a-very-complete-proof-on-the-separability-of-lp/4925427?noredirect=1#comment10522682_4925427")[#text("https://math.stackexchange.com/questions/4923301/a-very-complete-proof-on-the-separability-of-lp/4925427?noredirect=1#comment10522682_4925427")]

#text("But it seems that the hypothesis of sigma finiteness is not necessary. it’s possible?")

#emph[#text("[Yes, the exercise remains true without the sigma-finiteness hypothesis. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688050")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("Exercise 1 (5) – Shouldn’t the degenerate case ")#mi("f=0 a.e")#text(" be handled separately? It seems obvious, but since it wasn’t mentioned, I wasn’t sure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688062")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2025")])]

#text("The case ")#mi("f=0")#text("(equivalently ")#mi("g = 0")#text("), corresponds to ")#mi("1-\\theta=0")#text("(equivalently ")#mi("\\theta=0")#text("), in equation (5), giving another equality condition for Jensen’s inequality (am I right?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2025")])]

#text("These cases are covered as part of “one of the functions is a non-negative scalar multiple of the other”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2025")])]

#text("My reading from the end of #5 of the compatibility conditions; Topological Structure:")

#text("“Sometimes you need to be certain that what happens in Vegas, stays in Vegas, like, doesn’t get spread around the World.” ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f5e75dd5d1b84462a93fda2757d25279ed40d7abfe639eb97c2d3c4360bac0-20128771c050417854a2a39358afc5479821fc71248c3788ac63054a269a920d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Ktitarev")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688347")[#strong[#text("Tim Ktitarev")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("One could also take a more abstract view, dispensing with the set X altogether and defining the Lebesgue space")

#text("on abstract measure spaces")

#text(", but we will not do so here.")
]

#text("Could you give a reference for this concept? Is this related to the notion of measure algebras where we say that measurable sets are equivalent if their symmetric difference has measure zero?")

#text("Thanks, Tim")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688353")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2025")])]

#text("Yes, this is the measure algebra approach. See for instance ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2025")])]

#text("Prof. Tao, I saw you mentioned the term algebra structure —— Is there a connection between algebraic structure and algebra structure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-688901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2025")])]

#text("An ")#link("https://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(" is a specific type of ")#link("https://en.wikipedia.org/wiki/Algebraic_structure")[#text("algebraic structure")]#text(" one can place on a set. Other familiar examples of algebraic structure include group structure, ring structure, and field structure; in linear algebra, vector field structure plays a particularly prominent role.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2026")])]

#text("The descriptions of the various mathematical structures given at the beginning are very enlightening. In that spirit, how should the structure of σ-algebra be explained?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2026")])]

#text("I would simply call this a measurable structure; it has some similarities with topological structure, but the two are not identical.")

#text("If you are familiar with Lean, you may gain some insight from seeing how these structures are actually developed in Mathlib (and which ones inherit structure from others), which has been carefully designed to capture the essence of these mathematical constructs. For instance, sigma-algebras are modeled through the ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/MeasureTheory/MeasurableSpace/Defs.html#MeasurableSpace")[#text("MeasurableSpace")]#text(" class, topological structure is modeled through the ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Topology/Defs/Basic.html#TopologicalSpace")[#text("TopologicalSpace")]#text(" class, normed spaces are modeled by a ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Analysis/Normed/Module/Basic.html#NormedSpace")[#text("NormedSpace")]#text(" class extending the ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/Module/Defs.html#Module")[#text("Module")]#text("class, and so forth.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2026")])]

#text("Prof. Tao,")

#text("In Proposition 3, why would the definition of Hölder’s inequality requires the exponents r to satisfy this formula 1/r = 1/p+1/q? To me, this is a bit bizzard and I don’t know the reason to do so.")

#emph[#text("[See some previous discussion at ")#link("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/")[#text("https://terrytao.wordpress.com/2008/12/27/tricks-wiki-use-basic-examples-to-calibrate-exponents/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2026")])]

#text("Prof. Tao, I don’t know what you mean by integration itself ∫f dμ can also be viewed as a pairing——what does d(·) (like dμ, dF(x), dx, and so forth) means from this perspective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692496")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2026")])]

#text("In the notation of Lebesgue integration, the “")#mi("d")#text("” symbol is part of the integration notation ")#mi("\\int \\dots d \\dots")#text("; neither component ")#mi("\\int")#text(", ")#mi("d")#text(" of this notation has a separate meaning (much like the individual components ")#mi("\\langle")#text(", ")#mi(",")#text(", ")#mi("\\rangle")#text(" of the inner product notation ")#mi("\\langle \\dots, \\dots \\rangle")#text(", on their own, do not have any intrinsic meaning in mathematical notation if not grouped together). [Such discontinuous constructions also occur to some extent in natural languages such as English: for instance “either … or …”, though in this case the words “either” and “or” do have some independent meaning. A well known example in French is “ne … pas”, where it is much less common to see either word used independently of the other.]")

#text("In the superficially similar, but subtly different, language of integration of differential forms, the “")#mi("d")#text("” symbol does have an interpretation as an ")#link("https://en.wikipedia.org/wiki/Exterior_derivative")[#text("exterior derivative")]#text(" (for instance, ")#mi("dx")#text(" becomes the differential of the coordinate function ")#mi("x \\mapsto x")#text("), but this notation, while deliberately designed to resemble the measure-theoretic notion of integration, is technically a distinct notion. See for instance ")#link("https://terrytao.wordpress.com/2007/12/25/pcm-article-differential-forms/")[#text("my PCM article")]#text(" on this topic.")

#text("There is also the Lebesgue-Stieltjes derivative that turns a cumulative distribution function ")#mi("F")#text(" into a measure ")#mi("dF")#text(", though somewhat confusingly the ")#mi("d")#text(" is not repeated when using that measure in an integral notation, thus we use ")#mi("\\int g\\ dF")#text(" to denote the Lebesgue-Stieltjes integral rather than ")#mi("\\int g\\ d(dF)")#text(". This is related to the preference for inserting a “")#mi("d")#text("” when multiplying a measure by a function, for instance if one wants to express the statement that a measure ")#mi("\\nu")#text(" is equal to a measure ")#mi("\\mu")#text(" multiplied by a function ")#mi("f")#text(", we write ")#mi("d\\nu = fd\\mu")#text(" rather than ")#mi("\\nu = \\mu")#text(". With this usage one could view ")#mi("d")#text(" as a purely linguistic marker that indicates that the object immediately following the ")#mi("d")#text(" is to be interpreted as a measure. [Such structural particles also occur in some natural languages, such as Japanese or Chinese, but are rare in English, although the infinitival use of “to” comes somewhat close.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692668")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2026")])]

#text("It seems that most analysis textbooks, in most cases, only consider the case where the exponent p defining the L^p space satisfies 1 ≤p < ∞ , including these notes here. My question is-what additional structures or properties do L^p spaces with 1 ≤ p < ∞ possess compared to those with 0 ＜ p < 1 that make analysts prefer this “convention”?")

#text("Also, even within the range 1 ≤p < ∞ , the cases p = 1, 2, ∞ seem to be the most common, while cases like p = 3, 4, 5, and so forth are relatively rare-Why is that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692677")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2026")])]

#text("I am ")#link("https://claude.ai/share/0daf7153-b852-4a00-bbb7-e9e2686c5b9a")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2026")])]

#text("Just looking at the statements of Hölder’s inequality and Minkowski’s inequality, it may not seem apparent that they are connected to convexity, yet their ")#emph[#text("proofs")]#text(" all rely on convexity. Does this ultimately come down to the fact that L^p spaces have the structure of convexity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-692766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2026")])]

#text("I am ")#link("https://claude.ai/share/13ad4ed3-dd25-41ca-a646-90aae5e4feb5")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-693139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2026")])]

#text("Dear Prof. Tao,")

#text("In Remark 10, you mentioned that another proof of the Lebesgue-Radon-Nikodym Theorem was essentially observed by von Neumann. Could you elaborate on what the idea observed by von Neumann was?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-693150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2026")])]

#text("I am ")#link("https://claude.ai/share/bb188db7-12d7-426d-94df-c4ff0c6dd4f0")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34831")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("Dear Professor Tao:")

#text("This post doesn’t appear in the “254B, Real Analysis” page. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34920")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Dear Professor Tao:")

#text("I am considering (4) of exercise 1. I think the scalar between f and g should be real, am I right？ ")#emph[#text("[Yes – and it should be non-negative, too. Thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34927")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Dear Professor Tao:")

#text("In Exercise #3 I think you need ")#mi("f \\in L^{p_0}(E) \\cap L^{\\infty}(E)")#text(" where ")#mi("m(E) < \\infty")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Folz")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34928")[#strong[#text("Matthew Folz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("It is not necessary. We can get one inequality by using Holder’s inequality to control the ")#mi("L^p")#text(" (")#mi("p_0<p<\\infty")#text(") norm of f by the ")#mi("L^{p_0}")#text(" and ")#mi("L^\\infty")#text(" norms, and then letting p go to infinity (perhaps you were trying to use the estimate in Exercise 8 here instead?). For the reverse inequality, if ")#mi("f\\geq t")#text(" on a set of measure ")#mi("A_t")#text(", then Chebyshev’s inequality shows that the ")#mi("L^p")#text(" norm of f is at least ")#mi("tm(A_t)^{1/p}")#text(". Letting p go to infinity gives the other inequality we need.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Folz")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34929")[#strong[#text("Matthew Folz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("(strictly speaking, the aforementioned inequalities are not quite ‘reverses’, one of them has a ‘liminf’ and the other has a ‘limsup’, but since the liminf of a sequence is always smaller than the limsup, things work out fine)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34961")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2009")])]

#text("Dear Professor Tao:")

#text("Here is a correction ( if I am right):")

#text("In the fourth paragraph after (12), I think f should be ")#mi("q^{p^{\\prime}-1}")#text(". Then ")#tao-math("\\lambda_g(f) = \\left\\|g\\right\\|_{L^{p^{\\prime}}}^p", block: false)#text(" and ")#tao-math("\\left\\|f\\right\\|_{L^p} = \\left\\|g\\right\\|_{L^{p^{\\prime}}}^{p-1}", block: false)#text(" should be ")#tao-math("\\lambda_g(f) = \\left\\|g\\right\\|_{L^{p^{\\prime}}}^{p^{\\prime}}", block: false)#text(" and ")#tao-math("\\left\\|f\\right\\|_{L^p} = \\left\\|g\\right\\|_{L^{p^{\\prime}}}^{p^{\\prime}-1}", block: false)#text(" (with p modified to p’)")

#text("The same problem happens in the fifth paragraph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-34962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2009")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, notes 5: Hilbert spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-35075")[#strong[#text("254A, notes 5: Hilbert spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2009")])]

#text("[…] 6. From Proposition 1 from Notes 3, (real or complex) is a Hilbert space for any measure space . In particular, and are Hilbert […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-35269")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] of a continuous linear transformation between two normed vector spaces X, Y. By Lemma 1 from Notes 3, any such linear transformation is bounded, in the sense that there exists a constant C such that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-35401")[#strong[#text("245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("[…] and quantitative properties of linear transformations between Banach spaces. (Lemma 1 of Notes 3 already gives a prototypical such equivalence between a qualitative property (continuity) and a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-35896")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第三节的内容是大家都很熟悉的L^P空间。开始两页作者站在一个很高的观点上谈了有关一般的数学对象的研究方法的内容，我很喜欢。但是初学者还是略去先不要看了。L^P空间中避免不了不等式。除了复习了几个以前见过的之外，我在学习中注意了不等式取等号时刻的意义。另外，伪-范数（pseudometrics）以及近似范数（quasi-norms）的概念也挺有意思的。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ERIC")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-36727")[#strong[#text("ERIC")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("Dear Prof. Tao,")

#text("is the following right? ” f is not in ")#mi("L^\\infty")#text(" means that for every ")#mi("M>0")#text(", there exists a set E with positive measure s.t. $f(x) $ is greater than M for all $x \\in E.$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-36729")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("Dear Eric,")

#text("One needs to replace f(x) by |f(x)| (or assume that f is non-negative), but other than that, your statement is correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 1: Interpolation of L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-37579")[#strong[#text("245C, Notes 1: Interpolation of L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("[…] real or complex spaces; for sake of concretness we work with complex spaces. Then for , recall (see 245B Notes 3) that is the space of all functions whose […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254C, Notes 2: The Fourier transform « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-37980")[#strong[#text("254C, Notes 2: The Fourier transform « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("[…] with . (Unfortunately, is not always -finite, and so the standard duality theorem from Notes 3 of 245B does not directly apply. However, one can get around this using Exercise […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul J")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-41456")[#strong[#text("Paul J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2009")])]

#text("Hello,")

#text("I have got some problems with proving quasi-triangle inequality from Lemma 1. Could anyone give me same hint?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seminar „Funktionalanalysis“ « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-43306")[#strong[#text("Seminar „Funktionalanalysis“ « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("[…] Räume (T. Tao, Spaces, Blognotes zur Vorlesung 245B) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-45388")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2010")])]

#text("A couple of typos:")

#text("1. Before “In the ")#mi("p = 1")#text(" case…” paragraph in the proof of dual of ")#mi("L^p")#text(" theorem, one should have ")#mi("\\lambda_g(f_N) \\ge ...")#text(" instead of ")#mi("\\lambda_g(f) \\ge ...")#text(".")#linebreak()#text(" 2. In Remark 10 between the two displays ")#mi("m = 1")#text(" should be ")#mi("g = 1")#text(". Also, after the last display in this remark ")#mi("E^{\\prime}")#text(" should be ")#mi("E")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-47161")[#strong[#text("245A, Notes 2: The Lebesgue integral « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("[…] is complete in various ways; we will formalise this properly only in the next quarter when we study spaces, but the convergence theorems mentioned above already hint at this completeness. A related fact, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 4: Modes of convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-47371")[#strong[#text("245A, Notes 4: Modes of convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("[…] whenever and . This is a sequence of indicator functions of intervals of decreasing length, marching across the unit interval over and over again. Then converges to zero in measure and in norm, but not pointwise almost everywhere (and hence also not pointwise, not almost uniformly, nor in norm, nor uniformly). Remark 2 The norm of a measurable function is defined to the infimum of all the quantities that are essential upper bounds for in the sense that for almost every . Then converges to in norm if and only if as . The and norms are part of the larger family of norms, which we will study in more detail in 245B. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quantum probability")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-48094")[#strong[#text("quantum probability")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2010")])]

#text("Oh … so THIS is why people are interested in Lp norms.")

#text("Is there another post that contrasts Lpspaces with other possible metrizations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-48941")[#strong[#text("245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("[…] is complete in various ways; we will formalise this properly only in the next quarter when we study spaces, but the convergence theorems mentioned above already hint at this completeness. A related fact, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/515ffc52b75890a0c3a33be711fdd621e5e83b3b096db74956bb1a7b2956c17f-30d9e70954aedc2521cfd048a5281954e22c25369e82e0f7d77e9a3208d381a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mcknight0219")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-49092")[#strong[#text("mcknight0219")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2010")])]

#text("Hi, Prof Tao")

#text("In the last two line of proof for Proposition 2 there is a typo, ‘finit emeasure’ should be ‘finite measure’.")

#text("Qiang")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-49695")[#strong[#text("Lecture Notes on Topology: 1 « Mcknight0219's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2011")]

#text("[…] vector space, space,…). A very good and abstract illustration of this conception can be found here. In the following, I will stick to contents of lecture notes. Definition 1.2: The discrete topology […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-50700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2011")])]

#text("With Holder’s inequality, one can estimate any integral of the form ")#tao-math("\\left\\|fg\\right\\|_{L^r}", block: false)#text(" with assumption that ")#mi("f\\in L^p")#text(" and ")#mi("g\\in L^q")#text(". However, if one likes bound it below, it seems to be unhelpful. For instance, if one wants to find ")#mi("g")#text(", such that for any ")#mi("f\\in L^p")#text(", ")#tao-math("\\int \\left|fg\\right|^p<\\infty", block: false)#text(", Holder may not help, even just for finding a smaller group of ")#mi("g")#text(". For a more concrete example, find all ")#mi("g(t)=\\frac{1}{t^2+t-\\lambda}")#text(" such that ")#tao-math("\\int_{[0,1]} \\left|gf\\right|^pdt<\\infty", block: false)#text(" where ")#mi("f\\in L^p")#text(". Maybe another kind of estimation is needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-50786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2011")])]

#text("In the case of ")#mi("f:{\\bf R}\\to{\\bf R}")#text(", one can talk about the range and the kernel of the function ")#mi("f")#text(". However, if ")#mi("f\\in L^p")#text(", ")#mi("f")#text(" is a equivalent class instead of a “function”. Is it still possible to define the counterpart of the concepts in ")#mi("L^p")#text(", say, “range” and “kernel”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-50788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2011")])]

#link("http://en.wikipedia.org/wiki/Essential_range")[#text("http://en.wikipedia.org/wiki/Essential_range")]

#link("http://en.wikipedia.org/wiki/Support_(mathematics)")[#text("http://en.wikipedia.org/wiki/Support_(mathematics)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-99727")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("I am always not confident in using the ")#mi("L^p")#text(" space. Since its element is not a function at all but a “equivalent class”. Every time I read something like “")#mi("f\\in L^p")#text("“, I convert it into ")#mi("[f]\\in L^p")#text(". This is really strange. It seems that what we actually care about is the “property” that ")#tao-math("\\int_X\\left|f\\right|^p d\\mu<\\infty", block: false)#text(". The \"equivalent class\" is only used for forming a Banach space. Am I right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-99734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("Well, yes, but most of the point of introducing L^p spaces in the first place is in order to exploit the properties of a Banach space. For instance, if one has ")#tao-math("\\left\\|f-g\\right\\|_{L^p}=0", block: false)#text(", one would like to conclude that ")#mi("f=g")#text(" (because this is what normally happens in a Banach space), but because of the equivalence class in the way, one can only conclude that ")#mi("f")#text(" is equal to ")#mi("g")#text(" ")#emph[#text("almost everywhere")]#text(".")

#text("As mentioned in the lecture notes, L^p spaces adhere to the “Lebesgue philosophy” of analysis, in which one considers sets of measure zero to be negligible, and in particular allows functions to be uncontrolled on such sets; this is in order to take full advantage of the powerful tools of measure theory, integration theory, and function space theory. As such, analysis using Lebesgue methods (such as L^p spaces, the Lebesgue integral, etc.) tends to only give almost everywhere control of one’s functions, rather than everywhere control. If one has sufficient regularity (e.g. continuity is usually enough), one can upgrade almost everywhere control to everywhere control, but it is important to keep in mind (particularly in subjects such as ergodic theory) that this upgrade is not automatic in the absence of such regularity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-99800")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("Ok. ")#tao-math("\\left\\|f-g\\right\\|_{L^p}", block: false)#text(" can be read as either ")#tao-math("\\left\\|[f]-[g]\\right\\|_{L^p}", block: false)#text(" or ")#tao-math("\\left\\|[f-g]\\right\\|_{L^p}", block: false)#text(", where ")#mi("[f]")#text(" is the equivalent class. I am always wondering if it is necessarily to do so.")

#text("What’s more, I don’t know how to completely accept the philosophy of Lebesgue. Since this “almost everywhere” issue, I cannot specify the value of ")#mi("f")#text(" from a equivalent class “anywhere”! In this sense, one cannot control the function at all, instead of “almost everywhere”.")

#text("I don’t quite understand the word “control” you used in the answer, though I have seen it in lots of places. It seems to be a common jargon in mathematics. Does mean the integration of the function? But the “everywhere control” means, I think, specifying the value of the function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-99887")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")])]

#text("The Lebesgue philosophy is analogous to the “noise-tolerant” philosophy in modern signal progressing. If one is receiving a signal (e.g. a television signal) from a noisy source (e.g. a television station in the presence of electrical interference), then any individual component of that signal (e.g. a pixel of the television image) may be corrupted. But as long as the total number of corrupted data points is negligible, one can still get a good enough idea of the image to do things like distinguish foreground from background, compute the area of an object, or the mean intensity, etc. This is similar to how one can measure a set or integrate a function even in the presence of a measure zero “noise” which renders any specific point of the set or function value “unreliable”.")

#text("“Control” is a loose term which can mean exact specification of a function and its values, but can also mean estimation of the values to within some error tolerance, or some convergence rate of those values to some limit. Basically, control is the ability to acquire useful information on an object from the given hypotheses.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-109003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("As I understand from your comment, if “control” means exact specification and its values, then in the sense of L^p space, one cannot control the function “anywhere”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-112530")[#strong[#text("How to understand \"It takes a little bit of getting used to the idea…\"? | web technical support")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2011")]

#text("[…] The following sentence is from a mathematical lecture note here: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-116379")[#strong[#text("How to understand “It takes a little bit of getting used to the idea…”? | Q&A System")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2011")]

#text("[…] The following sentence is from a mathematical lecture note here: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa29d0a8b630caa34762b7efe09e683ade3edca48014f866367768ae6519f540-407dd4390d4f4fc808cd90908fa8bd1ecaf89534ba516cf4d7e5339c29a14a51.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nn")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-125195")[#strong[#text("nn")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2012")])]

#text("can anyone help with second part of exercise 7.a I want to guess what the completion would be in the case of simple functions with finite support measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nn")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-125197")[#strong[#text("nn")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2012")])]

#text("I meant exercise 7. sorry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-146340")[#strong[#text("[T]he point of introducing L^p spaces in the first... • see things differently")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2012")]

#text("[…] exists + addition exists + everything’s included = it’s a Banach space) (Source: terrytao.wordpress.com) View the discussion […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfa768cee49f2266afe9b49ceddbe864fd161f1069fe799c17247e36a548e993-449c9ddd8fad72f14e33db7986208c37114e768526bd006692db895df2754406.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.W.")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-318958")[#strong[#text("J.W.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2014")])]

#text("Regarding Exercise 1, part (4)")

#text("I feel in the ")#mi("0<p<1")#text(" case, we need the additional hypothesis that ")#mi("f,g")#text(" are non-negative a.e.")

#text("Consider the case when ")#mi("p = 1/2")#text(". Then, if I'm not doing something very stupid, ")#mi("f = 1_{[0,1]}, g = -1_{[ \\sqrt {2})/2, 1 + (\\sqrt {2} /2)]}")#text(" provides a counterexample.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f9e823fc85ab1b3b8ec1912f506f009a6927774efbbaf57cf2ee37df0fa4e45-72e73bd236d95ed762477505fef9abf8434b09edbbd4c6519e7e5a07a6832851.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Filanto")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-430399")[#strong[#text("Filanto")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2014")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Is there some nice way of what $L^p$ norms really measure, i.e. what property of a function reflects in big $L^{100}$ norm? For the sake of simplicity let’s just assume we are considering domain $[0,1]$ with Lebesgue measure. It seems from the definition that higher the $p$ the more emphasis should be on big values/spikes. Is this the right way to think about it? Could you give me some reference where I can find some discussion on this sort of questions (on heuristic/philosophical level)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-430415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2014")])]

#text("The ")#mi("L^p")#text(" norm of a function ")#mi("f")#text(" behaves like the “amplitude” of the function times the ")#mi("p^{th}")#text(" root of the “width” of the function; see Example 1 in the post. In particular, as you say, a big ")#mi("L^{100}")#text(" norm can be easily caused by a narrow spike, but not easily caused by a broad flat bump, whereas for low ")#mi("L^p")#text(" (quasi-)norms like ")#mi("L^{1/100}")#text(", the situation is reversed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-465919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("If one considers the vector-valued ")#mi("L^p")#text(" space, say ")#mi("L^p([0,T];X)")#text(" where ")#mi("X")#text(" is a Banach space and ")#mi("[0,T]\\subset{\\bf R}")#text(", does one still have the similar results as in this note? For example, can the dual of ")#mi("L^p([0,T];X)")#text(" be identified as ")#mi("L^q([0,T];X)")#text("?")

#text("How much in general would fail?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-465924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2016")])]

#text("I’ll restrict attention to separable spaces in order to not have to deal with subtleties regarding the definition of vector-valued measurability. The dual of ")#mi("L^p([0,T];X)")#text(" always contains ")#mi("L^{p^{\\prime}}([0,T],X^*)")#text(" (after some canonical identifications), but can be larger if ")#mi("X")#text(" is not reflexive. Things can get rather subtle in the non-reflexive case, the main issue being whether a version of the Radon-Nikodym theorem holds for X-valued measures. One can search the literature on the “Radon-Nikodym property” (and also on duals of Bochner spaces) for more details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-466372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2016")])]

#text("Dear Prof. Tao,")

#text("In (3), $f^r$ should be replaced by $|f|^r$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous2")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468518")[#strong[#text("Anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("Do you have good references in mind for discussion of the space ")#mi("L^p(\\partial\\Omega)")#text(" where ")#mi("\\Omega")#text(" is some bounded open subset in ")#mi("\\mathbb{R}^d")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("In Exercise 0 what kind of isomorphism are you referring to? Do you mean isometry of metric spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468830")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("Isomorphism of normed vector spaces. Thus, the isomorphism must be invertible, linear and norm-preserving.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2016")])]

#text("Another proof for Proposition 1 when ")#mi("1<p<\\infty")#text(" is using the theorem that ")#mi("X^*")#text(" is a Banach space for any normed vector space ")#mi("X")#text(". Are these two proofs essentially connected?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("In Proposition 1, when ")#mi("p=\\infty")#text(". Let")#linebreak()#text(" ")#mi("\\displaystyle f(x):=\\sum_{n=1}^\\infty f_n(x)")#linebreak()#text(" How can one show that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|g_N-f\\right\\|_{L^\\infty}\\to 0", block: false)#linebreak()#text(" where ")#mi("g_N=\\sum_{n=1}^Nf_n")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("Would you elaborate in the proof of Proposition 3, why the convexity of the exponential function ")#mi("t \\mapsto e^t")#text(" on ")#mi("[0,+\\infty)")#text(" implies the convexity of the function ")#tao-math("t \\mapsto \\left|f(x)\\right|^{p(1-t)} \\left|g(x)\\right|^{qt}", block: false)#text(" for ")#mi("t \\in [0,1]")#text(" for any ")#mi("x")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("Convexity means")#linebreak()#text(" ")#mi("\\displaystyle F(\\lambda t_1+(1-\\lambda)t_2)\\leq \\lambda F(t_1)+(1-\\lambda)F(t_2)")#linebreak()#text(" where ")#mi("F")#text(" denotes the map ")#tao-math("t \\mapsto \\left|f(x)\\right|^{p(1-t)} \\left|g(x)\\right|^{qt}", block: false)#text(". Would you also elaborate why this implies (7)?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-468928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2016")])]

#text("I think one does not need the convexity of the map")#linebreak()#text(" ")#tao-math("\\displaystyle t\\mapsto \\left|f(x)\\right|^{p(1-t)}\\left|g(x)\\right|^{qt}.", block: false)#linebreak()#text(" By convexity of the exponential function,")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|f(x)\\right|^{p(1-t)}\\left|g(x)\\right|^{qt}=\\exp[(1-t)p\\log\\left|f(x)\\right|+tq\\log\\left|g(x)\\right|]\\\\ \\leq (1-t)\\left|f(x)\\right|^p+t\\left|g(x)\\right|^q", block: false)#linebreak()#text(" for all ")#mi("t\\in[0,1]")#text(". Now we can choose ")#mi("t=1/q")#text(" to get (7).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-469633")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("I was able to prove exercise 10 by showing that essentially, $f$ takes only countably many values and then reducing the problem to the case of counting measure, where it follows from the usual norm inequalities for $\\mathbb{R}^n$.")#linebreak()#text(" Is there might be a more elegant way that actually uses Hölder’s inequality? It doesn’t seem to work as nicely as Ex. 9.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-472334")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2016")])]

#text("sorry, i typed many words. but only some sentences appear correctly, and i dont know why.")#linebreak()#text(" my question is that in Proposition 2 “dense” is used, but what topology is it referring to. i think by using quasi-triangle inequality exercise 7a is valid for p<1. why open balls on quasi-metric spaces as stated form a base for a topology? (see paragraph just before exercise 6).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-472337")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2016")])]

#text("Hmm, you’re right, there is a subtlety here. The open balls of a quasimetric or quasinorm need not be a base, but any quasinorm ")#mi("\\| \\|")#text(" will have an equivalent quasinorm ")#mi("\\| \\|^{\\prime}")#text(" for which the open balls will indeed be a base. For isntance one can take ")#tao-math("\\left\\|x\\right\\|^{\\prime} := \\lim \\sup_{y \\to x} \\left\\|y\\right\\| := \\inf_{\\varepsilon > 0} \\sup_{\\left\\|y-x\\right\\| \\leq \\varepsilon} \\left\\|y\\right\\|", block: false)#text(". One can also check that the ")#mi("L^p")#text(" quasinorm balls already form a base. The main feature of the topology that is relevant here is that sequential convergence works as expected: ")#mi("f_n")#text(" converges to ")#mi("f")#text(" in the ")#mi("L^p")#text(" topology if and only if ")#tao-math("\\left\\|f_n-f\\right\\|_{L^p} \\to 0", block: false)#text(".")

#text("(p.s. you have to use &lt; and &gt; in place of < and > if you want to avoid your text being interpreted as HTML.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-473356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("I’ve seen a lot about the concept periodic ")#mi("L^p")#text(" space when reading papers (including yours on the topics of Navier-Stokes equations), but I’m always confused about what it really is. Let ")#mi("\\mathbb{T}")#text(" be the quotient space ")#mi("\\mathbb{R}/\\mathbb{Z}")#text(". What exactly is the Lebesgue measure on ")#mi("\\mathbb{T}")#text("? How different is the space ")#mi("L^p(\\mathbb{T})")#text(" from ")#mi("L^p([0,1])")#text("? If they are the same, then why on earth people need a new concept?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-473362")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Yes, one can define the Lebesgue measure on ")#mi("{\\bf T}")#text(" by identifying that space with one of its fundamental domains, such as ")#mi("[0,1)")#text(". The spaces ")#mi("{\\bf T}")#text(" and ")#mi("[0,1)")#text(" are thus isomorphic as measure spaces, and so ")#mi("L^p({\\bf T})")#text(" and ")#mi("L^p([0,1))")#text(" are isomorphic as normed vector spaces. However, ")#mi("{\\bf T}")#text(" and ")#mi("[0,1)")#text(" differ in other respects if one considers other structures than the measurable structure. For instance, from the point of view of topological structure ")#mi("{\\bf T}")#text(" is compact and not simply connected, while ")#mi("[0,1)")#text(" is non-compact and simply connected. The differential structure is also different, for instance the identity function ")#mi("x \\mapsto x")#text(" on ")#mi("[0,1)")#text(" is smooth using the differential structure of ")#mi("[0,1)")#text(", but is not even continuous if one replaces the domain with ")#mi("{\\bf T}")#text(". In particular, PDE on ")#mi("[0,1)")#text(" and on ")#mi("{\\bf T}")#text(" are quite different.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-473365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#emph[#text("For instance, from the point of view of topological structure ")#mi("{\\bf T}")#text(" is compact and not simply connected, while ")#mi("[0,1)")#text(" is non-compact and simply connected. ")]

#text("Since the singleton ")#mi("\\{1\\}")#text(" is of Lebesgue measure ")#mi("0")#text(", isn’t it true that ")#mi("L^p([0,1))")#text(" is also the same (measure space isomorphic) as ")#mi("L^p([0,1])")#text(" or ")#mi("L^p((0,1))")#text(" or $L^p((0,1])$?")

#text("Can I conclude that in the setting of measure spaces, there is no difference among these spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-473379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Yes, if one only cares about the measurable structure, then ")#mi("[0,1)")#text(", ")#mi("[0,1]")#text(", and ")#mi("{\\bf T}")#text(" are isomorphic (up to null sets), and if one only cares about the normed vector space structure, ")#mi("L^p([0,1))")#text(", ")#mi("L^p([0,1])")#text(", and ")#mi("L^p({\\bf T})")#text(" are all isomorphic. However, for applications to PDE one usually needs more structure than just the measurable or normed vector space structure (in particular, one needs differential structure), and then the three domains are all inequivalent (for instance the Sobolev spaces on the three domains behave differently).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-478464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2017")])]

#text("I have seen Sobolev spaces on torus ")#mi("{\\bf T}^d")#text(" used a lot in PDE literatures. I really want to know more about the fundamentals as the materials developed in this note and those in the 245C notes on Sobolev spaces. However “periodic Sobolev spaces” are seldom discussed in books I have read before (or just slightly mentioned). Is it too trivial for experts? Would you point me to some references to this topic?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-478467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2017")])]

#text("In general, do you have a handy definition for ")#mi("L^p({\\bf T}^d)")#text("? Folland uses this notation in the chapter of Fourier Analysis which is far ")#emph[#text("before")]#text(" the chapter where he introduces Hausdorff measures. As your last comment said, one might also care about the differential structure of ")#mi("{\\bf T}^d")#text(". So, again, how do people usually define ")#mi("L^p({\\bf T}^d)")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-473375")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Why is the identity function on ")#mi("{\\bf T}")#text(" not continuous? Would you elaborate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-473378")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("If one takes the identity function ")#mi("id: [0,1) \\to [0,1)")#text(" and composes it with the identification ")#mi("\\iota: {\\bf T} \\to [0,1)")#text(", the resulting map ")#mi("id \\circ \\iota: {\\bf T} \\to [0,1)")#text(" is not continuous.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-478868")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2017")])]

#text("The ")#mi("L^p")#text(" norm of a step function ")#mi("c1_E")#text(" is given by ")#tao-math("\\left|c\\right|\\mu(E)^{1/p}", block: false)#text(". Hence the Holder’s inequality for step functions is really")

#mi("\\displaystyle \\mu(E\\cap F)^{1/r}\\leq \\mu(E)^{1/p}\\mu(F)^{1/q}.")

#text("Does this suggest in general Holder’s inequality says nothing about the height of the functions f and g?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-478953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")])]

#text("In Example 1, is it possible to prove (without using Hölder) for simple functions that")

#tao-math("\\displaystyle \\left\\|f\\right\\|_p\\to\\left\\|f\\right\\|_\\infty", block: false)

#text("as ")#mi("p\\to\\infty")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-478964")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2017")])]

#text("Once one establish this for simple functions, can one use a “density argument” mentioned in 245a notes to deduce the case for general ")#mi("L^p")#text(" functions? (I have never seen in reference people do that before and it could be somehow circular though.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-1/#comment-479026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("In the 247a notes 1 Example 5.2, it is said that")

#text("The function ")#tao-math("\\left|x\\right|^{-\\alpha}", block: false)#text(" does not lie in any ")#mi("L^p({\\bf R}^d)")#text(", although it only fails “logarithmically” to lie in ")#mi("L^{d/\\alpha}")#text(".")

#text("Would you elaborate what “it only fails ‘logarithmically’ to lie in ")#mi("L^{d/\\alpha}")#text("” mean?")

#emph[#text("[Truncated ")#mi("L^p")#text(" norms such as ")#tao-math("\\int_{\\varepsilon \\leq \\left|x\\right| \\leq 1/\\varepsilon} (\\left|x\\right|^{-\\alpha})^p\\ dx", block: false)#text(" exhibit a logarithmic divergence as ")#mi("\\varepsilon \\to 0")#text(" if ")#mi("p = d/\\alpha")#text(", but have a power type divergence otherwise. -T.]")]
]
