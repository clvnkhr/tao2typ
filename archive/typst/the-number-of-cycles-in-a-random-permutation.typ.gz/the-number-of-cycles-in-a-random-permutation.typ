// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/
// Converted to Typst by tao2typ: "2026-10-14T16:36:43.136113+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The number of cycles in a random permutation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The number of cycles in a random permutation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/")[#text("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{n}")#text(" be a natural number, and let ")#mi("{\\sigma: \\{1,\\ldots,n\\} \\rightarrow \\{1,\\ldots,n\\}}")#text(" be a permutation of ")#mi("{\\{1,\\ldots,n\\}}")#text(", drawn uniformly at random. Using the ")#link("http://en.wikipedia.org/wiki/Cycle_decomposition_(group_theory)")[#text("cycle decomposition")]#text(", one can view ")#mi("{\\sigma}")#text(" as the disjoint union of cycles of varying lengths (from ")#mi("{1}")#text(" to ")#mi("{n}")#text("). For each ")#mi("{1 \\leq k \\leq n}")#text(", let ")#mi("{C_k}")#text(" denote the number of cycles of ")#mi("{\\sigma}")#text(" of length ")#mi("{k}")#text("; thus the ")#mi("{C_k}")#text(" are natural number-valued random variables with the constraint ")#metadata(none) <tao-cf50252908e527ebc5ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{k=1}^n k C_k = n.")]]

#text("We let ")#mi("{C := \\sum_{k=1}^n C_k}")#text(" be the number of cycles (of arbitrary length); this is another natural number-valued random variable, of size at most ")#mi("{n}")#text(".")

#text("I recently had need to understand the distribution of the random variables ")#mi("{C_k}")#text(" and ")#mi("{C}")#text(". As it turns out this is an extremely classical subject, but as an exercise I worked out what I needed using a quite tedious computation involving ")#link("http://en.wikipedia.org/wiki/Generating_functions")[#text("generating functions")]#text(" that I will not reproduce here. But the resulting identities I got were so nice, that they strongly suggested the existence of elementary ")#link("http://en.wikipedia.org/wiki/Bijective_proof")[#text("bijective")]#text(" (or “double counting”) proofs, in which the identities are proven with a minimum of computation, by interpreting each side of the identity as the cardinality (or probability) of the same quantity (or event), viewed in two different ways. I then found these bijective proofs, which I found to be rather cute; again, these are all extremely classical (closely related, for instance, to ")#link("http://en.wikipedia.org/wiki/Stirling_numbers_of_the_first_kind")[#text("Stirling numbers of the first kind")]#text("), but I thought some readers might be interested in trying to find these proofs themselves as an exercise (and I also wanted a place to write the identities down so I could retrieve them later), so I have listed the identities I found below.")

#enum(start: 1, 
[#text("For any ")#mi("{1 \\leq k \\leq n}")#text(", one has ")#mi("{{\\bf E} C_k = \\frac{1}{k}}")#text(". In particular, ")#mi("{{\\bf E} C = 1 + \\frac{1}{2} + \\ldots + \\frac{1}{n} = \\log n + O(1)}")#text(".")],
[#text("More generally, for any ")#mi("{1 \\leq k \\leq n}")#text(" and ")#mi("{j \\geq 1}")#text(" with ")#mi("{jk \\leq n}")#text(", one has ")#mi("{{\\bf E} \\binom{C_k}{j} = \\frac{1}{k^j j!}}")#text(".")],
[#text("More generally still, for any ")#mi("{1 \\leq k_1 < \\ldots < k_r \\leq n}")#text(" and ")#mi("{j_1,\\ldots,j_r \\geq 1}")#text(" with ")#mi("{\\sum_{i=1}^r j_i k_i \\leq n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\prod_{i=1}^r \\binom{C_{k_i}}{j_i} = \\prod_{i=1}^r \\frac{1}{k_i^{j_i} j_i!}.")]]],
[#text("In particular, we have ")#emph[#text("Cauchy’s formula")]#text(": if ")#mi("{\\sum_{k=1}^n j_k k = n}")#text(", then the probability that ")#mi("{C_k = j_k}")#text(" for all ")#mi("{k=1,\\ldots,n}")#text(" is precisely ")#mi("{\\prod_{k=1}^n \\frac{1}{k^{j_k} j_k!}}")#text(". (This in particular leads to a reasonably tractable formula for the joint generating function of the ")#mi("{C_k}")#text(", which is what I initially used to compute everything that I needed, before finding the slicker bijective proofs.)")],
[#text("For fixed ")#mi("{k}")#text(", ")#mi("{C_k}")#text(" converges in distribution as ")#mi("{n \\rightarrow \\infty}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson distribution")]#text(" of intensity ")#mi("{\\frac{1}{k}}")#text(".")],
[#text("More generally, for fixed ")#mi("{1 \\leq k_1 < \\ldots < k_r}")#text(", ")#mi("{C_{k_1},\\ldots,C_{k_r}}")#text(" converge in joint distribution to ")#mi("{r}")#text(" independent Poisson distributions of intensity ")#mi("{\\frac{1}{k_1},\\ldots,\\frac{1}{k_r}}")#text(" respectively. (A more precise version of this claim can be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=1175278")[#text("this paper of Arratia and Tavaré")]#text(".)")],
[#text("One has ")#mi("{{\\bf E} 2^C = n+1}")#text(".")],
[#text("More generally, one has ")#mi("{{\\bf E} m^C = \\binom{n+m-1}{n}}")#text(" for all natural numbers ")#mi("{m}")#text(".")]
)

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Martin")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-109238")[#strong[#text("Greg Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2011")])]

#text("Terry – are the distributions of the lengths of the longest cycle and shortest cycle also known?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-109243")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2011")])]

#link("http://www.ams.org/mathscinet-getitem?mr=195117")[#text("This paper of Lloyd and Shepp")]#text(" seems to answer such questions fairly definitively, though the answers are somewhat messy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-109241")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2011")])]

#text("For what it’s worth, the joint generating function of the ")#mi("C_k")#text(" can be computed using Polya’s enumeration theorem, and it also has an elegant explanation in terms of combinatorial species (see my blog posts ")#link("http://qchu.wordpress.com/2009/06/21/gila-v-the-polya-enumeration-theorem-and-applications/")[#text("here")]#text(" and ")#link("http://qchu.wordpress.com/2009/06/24/gila-vi-the-cycle-index-polynomials-of-the-symmetric-groups/")[#text("here")]#text(" for details).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-109250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2011")])]

#text("Typo in the first paragraph. ‘brandom’ should be ‘random’. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-109545")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2011")])]

#text("There is a play (!) on this kind of thing by our friend Andrew Granville and his sister.")

#link("http://www.maa.org/mathtourist/mathtourist_01_06_10.html")[#text("http://www.maa.org/mathtourist/mathtourist_01_06_10.html")]

#text("I recall the accompanying music, which was in 29 time, making me feel rather queasy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad3f3a79ef213c98c05db1ab441cb92661583507ac1a7a5e31f4beaa785f1e3b-bd0c7862157994459c7704585bcfde3a1c363765d691789fd896ca4a5396e667.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Martin")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-109911")[#strong[#text("Greg Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")])]

#text("29 time?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-110595")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2011")])]

#text("Yes, as in 29 beats to the bar. So far as I recall.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-110200")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2011")])]

#text("The play was supposed to come out as a comics, but I don’t know what happened to that project…")

#text("More mathematically, the book of Arratia, Barbour and Tavaré, “Logarithmic combinatorial structures” (see ")#link("http://www.ems-ph.org/books/book.php?proj_nr=15")[#text("http://www.ems-ph.org/books/book.php?proj_nr=15")]#text(" ) contains many generalizations, treated in a uniform manner.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9097e083cced46c2c3150c755e561632bd3c176b9823bd617b0748f6e88c4897-74f03a19db63b30292fa2dcbd33666a20503dc39df4a119fe4701b6a340b101b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay Beder")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-519528")[#strong[#text("Jay Beder")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2019")])]

#text("The graphic novel has come out: Prime Suspects, by Andrew Granville and Jennifer Granville, with illustrations by Robert J. Lewis, Princeton U. Press. There are extensive endnotes by A Granville and others. Granville mentions the log N result, though without any explanation. (BTW, Tao, Green and Ziegler are among the characters in the novel.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lam. S.")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-110752")[#strong[#text("Lam. S.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("Flajolet and Knuth studied a similar problem in the graph theory context:")

#link("http://hal.inria.fr/docs/00/07/56/66/PDF/RR-0888.pdf")[#text("Click to access RR-0888.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A central limit theorem for the determinant of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-110948")[#strong[#text("A central limit theorem for the determinant of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("[…] complicated (and uses facts about the distribution of cycles in random permutations, mentioned in this previous post), but one can compute that is comparable to for GUE and for GOE. (The discrepancy here comes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/283f24a5657e6886b8389cdc58bf3dc5783247193650825af453332d1bb43cc9-9daaad08d559ba4d25fa22ae495931908a70c1ef76c7f40c270e6cabfb5262ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kate")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-111306")[#strong[#text("kate")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2011")])]

#text("Love your blog. Hardcore math I see.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e93f9dc07f75cedd8e720078553215326946db058a739d5e834b99c52b4ce677-f78eee69ac0adf472ac64bc97aec049fa77a28ec3f689a723fc1df540e71d862.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Slipper.Mystery")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-112381")[#strong[#text("Slipper.Mystery")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2011")])]

#text("One word puzzle that employs a property of random permutations, specifically the (relatively low) probability of large cycles, is the ")#link("http://en.wikipedia.org/wiki/Random_permutation_statistics#One_hundred_prisoners")[#text("100 prisoners")]#text(". This wikipedia entry (not among those you’ve linked) contains other useful identities.")

#text("See also")#linebreak()#text(" ")#link("http://lewko.wordpress.com/2009/09/02/condemned-prisoners-and-random-permutations/")[#text("condemned prisoners")]#text(" from someone who liked your reprise of the blue-eyed islanders.")

#text("The problem also shows up in this")#linebreak()#text(" ")#link("http://www.math.dartmouth.edu/~pw/solutions.pdf")[#text("tribute")]#text(" to Martin Gardner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john mangual")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-113254")[#strong[#text("john mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("I wonder what application you have in mind. There are lots of permutation group actions whose orbit structure we might be interested in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07bcadb82684c3d6eef15336ed0cab99d299c12e33d8bb78dcb374f999bd9ac5-eb40dee2e15d999412aa00adb143fec4e0baf26e1ef624dfb6de0cf33605c0ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjunath Krishnapur")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-121025")[#strong[#text("Manjunath Krishnapur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2012")])]

#text("The chinese restaurant construction of a uniform random permutation probably yields all these in the cleanest way – for example, the number of cycles has the same distribution as a sum of independent Bernoullis with parameters 1, 1/2, 1/ 3,…,1/n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/909dfcdc196763a2c7a8816e74702af709a9bd942ab1bf80783b05c9d26a47b0-a7f81d3a161b6b0bcb0bf83d3bde88c83f8226d4a612a889eaf559b6be695b8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vineet George")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-210859")[#strong[#text("Vineet George")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2012")])]

#text("I have done extensive research on combination and permutation and found consistent and uniform result. This result which I have found is written on a book known as Junction (an art of counting combination and permutation). To view one of the result of my research work then log on to the site ")#link("https://sites.google.com/site/junctionslpresentation/home")[#text("https://sites.google.com/site/junctionslpresentation/home")]

#text("also see: ")#link("https://sites.google.com/site/junctionslpresentation/proof-for-advance-permutation")[#text("https://sites.google.com/site/junctionslpresentation/proof-for-advance-permutation")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Poisson-Dirichlet process, and large prime factors of a random number | What's new")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-245979")[#strong[#text("The Poisson-Dirichlet process, and large prime factors of a random number | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2013")])]

#text("[…] Again, we prove this proposition below the fold. Now we turn to the second way (a topic, incidentally, that was briefly touched upon in this previous blog post): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16233697727ff89c9656848907f71fda3b132a9743345868386a9dfd6d693c22-10fc8e2c742ab52f4a3f93eb61f2eb824b67d7c72e319ec3ed3cae356d130d04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-404237")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2014")])]

#text("While I prepare for TA session for probability class, I found that the first one ")#mi("{\\bf E} C_k=1/k")#text(" has a probabilistic proof:")#linebreak()#text(" Let ")#mi("A_i")#text(" be the event that ")#mi("i")#text(" is contained in a ")#mi("k")#text("-cycle. ")#mi("1\\leq i \\leq n")#text(".")#linebreak()#text(" Then ")#mi("kC_k= \\sum 1_{A_i}")#text(" where ")#mi("1_A")#text(" is the indicator function.")#linebreak()#text(" ")#mi("{\\bf E} kC_k=  k {\\bf E} C_k = \\sum P(A_i) = \\sum 1/n = 1")#text(" follows from combinatorial counting argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-504951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2018")])]

#text("Why is P(A_i) = 1/n?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-514243")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2019")])]

#text("For a permutation, you can rearrange its cycles, such that each cycle has its minimal at the end, and the minimal elements of the cycles are in increasing order.")#linebreak()#text(" For example, the permutation (125)(37) (in S_7) should be written as (251)(73)(4)(6).")#linebreak()#text(" Note that you can read that expression without the parentheses (i.e. the only way to get the order 2517346 is (251)(73)(4)(6) ), in the following way: the first cycle should end at “1”. the second cycle should end at the minimal element after the first cycle, and so on.")#linebreak()#text(" Hence, we have a bijection between permutations and orders of the numbers 1…n, so you can choose an uniform order.")#linebreak()#text(" But now, the length of the cycle of 1 is k, iff 1 is in the kth place in our order, and the probability for that is clearly 1/n, so P(A_1)=1/n . (and the same is true for any i)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cycles of a random permutation, and irreducible factors of a random polynomial | What's new")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-457344")[#strong[#text("Cycles of a random permutation, and irreducible factors of a random polynomial | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2015")])]

#text("[…] (Prime number theorem for permutations) A randomly selected permutation of will be a cycle with probability exactly . (This was noted in this previous blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc40e40ce0cb742533c8c909bf0fd86922eab19384d38ad3473e1e672c388b36-238c7e1d13573b6a39f39d6bc61a67eaa22f17caf198535cab6db455b2c07f41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-470135")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2016")])]

#text("I think #8 holds in general for complex z as an application of Stirling number of first kind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Counting objects up to isomorphism: groupoid cardinality | What's new")]], [#link("https://terrytao.wordpress.com/2011/11/23/the-number-of-cycles-in-a-random-permutation/#comment-479821")[#strong[#text("Counting objects up to isomorphism: groupoid cardinality | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("[…] a cardinality that converges in distribution to the Poisson distribution of rate (as discussed in this previous post), thus we see that the fixed points of a large random permutation asymptotically are distributed […]")
]
