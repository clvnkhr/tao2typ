// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:37:54.232868+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Biases between consecutive primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Biases between consecutive primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 March 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/")[#text("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("There is a very nice ")#link("http://arxiv.org/abs/1603.03720")[#text("recent paper by Lemke Oliver and Soundararajan")]#text(" (complete with a ")#link("https://www.quantamagazine.org/20160313-mathematicians-discover-prime-conspiracy/")[#text("popular science article about it")]#text(" by the consistently excellent Erica Klarreich for Quanta) about a surprising (but now satisfactorily explained) bias in the distribution of pairs of consecutive primes ")#mi("{p_n, p_{n+1}}")#text(" when reduced to a small modulus ")#mi("{q}")#text(".")

#text("This phenomenon is superficially similar to the more well known ")#link("https://en.wikipedia.org/wiki/Chebyshev%27s_bias")[#text("Chebyshev bias")]#text(" concerning the reduction of a single prime ")#mi("{p_n}")#text(" to a small modulus ")#mi("{q}")#text(", but is in fact a rather different (and much stronger) bias than the Chebyshev bias, and seems to arise from a completely different source. The Chebyshev bias asserts, roughly speaking, that a randomly selected prime ")#mi("{p}")#text(" of a large magnitude ")#mi("{x}")#text(" will typically (though not always) be slightly more likely to be a quadratic non-residue modulo ")#mi("{q}")#text(" than a quadratic residue, but the bias is small (the difference in probabilities is only about ")#mi("{O(1/\\sqrt{x})}")#text(" for typical choices of ")#mi("{x}")#text("), and certainly consistent with known or conjectured positive results such as ")#link("https://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem")]#text(" or the ")#link("https://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text(". The reason for the Chebyshev bias can be traced back to the ")#link("https://en.wikipedia.org/wiki/Explicit_formulae_(L-function)")[#text("von Mangoldt explicit formula")]#text(" which relates the distribution of the von Mangoldt function ")#mi("{\\Lambda}")#text(" modulo ")#mi("{q}")#text(" with the zeroes of the ")#mi("{L}")#text("-functions with period ")#mi("{q}")#text(". This formula predicts (assuming some standard conjectures like GRH) that the von Mangoldt function ")#mi("{\\Lambda}")#text(" is quite unbiased modulo ")#mi("{q}")#text(". The von Mangoldt function is ")#emph[#text("mostly")]#text(" concentrated in the primes, but it also has a medium-sized contribution coming from ")#emph[#text("squares")]#text(" of primes, which are of course all located in the quadratic residues modulo ")#mi("{q}")#text(". (Cubes and higher powers of primes also make a small contribution, but these are quite negligible asymptotically.) To balance everything out, the contribution of the primes must then exhibit a small preference towards quadratic non-residues, and this is the Chebyshev bias. (See ")#link("http://www.ams.org/mathscinet-getitem?mr=1329368")[#text("this article of Rubinstein and Sarnak")]#text(" for a more technical discussion of the Chebyshev bias, and ")#link("http://www.ams.org/mathscinet-getitem?mr=2202918")[#text("this survey of Granville and Martin")]#text(" for an accessible introduction. The story of the Chebyshev bias is also related to ")#link("https://en.wikipedia.org/wiki/Skewes%27_number")[#text("Skewes’ number")]#text(", once considered the largest explicit constant to naturally appear in a mathematical argument.)")

#text("The paper of Lemke Oliver and Soundararajan considers instead the distribution of the pairs ")#mi("{(p_n \\text{ mod } q, p_{n+1} \\text{ mod } q)}")#text(" for small ")#mi("{q}")#text(" and for large consecutive primes ")#mi("{p_n, p_{n+1}}")#text(", say drawn at random from the primes comparable to some large ")#mi("{x}")#text(". For sake of discussion let us just take ")#mi("{q=3}")#text(". Then all primes ")#mi("{p_n}")#text(" larger than ")#mi("{3}")#text(" are either ")#mi("{1 \\text{ mod } 3}")#text(" or ")#mi("{2 \\text{ mod } 3}")#text("; Chebyshev’s bias gives a very slight preference to the latter (of order ")#mi("{O(1/\\sqrt{x})}")#text(", as discussed above), but apart from this, we expect the primes to be more or less equally distributed in both classes. For instance, assuming GRH, the probability that ")#mi("{p_n}")#text(" lands in ")#mi("{1 \\text{ mod } 3}")#text(" would be ")#mi("{1/2 + O( x^{-1/2+o(1)} )}")#text(", and similarly for ")#mi("{2 \\text{ mod } 3}")#text(".")

#text("In view of this, one would expect that up to errors of ")#mi("{O(x^{-1/2+o(1)})}")#text(" or so, the pair ")#mi("{(p_n \\text{ mod } 3, p_{n+1} \\text{ mod } 3)}")#text(" should be equally distributed amongst the four options ")#mi("{(1 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(", ")#mi("{(1 \\text{ mod } 3, 2 \\text{ mod } 3)}")#text(", ")#mi("{(2 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(", ")#mi("{(2 \\text{ mod } 3, 2 \\text{ mod } 3)}")#text(", thus for instance the probability that this pair is ")#mi("{(1 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(" would naively be expected to be ")#mi("{1/4 + O(x^{-1/2+o(1)})}")#text(", and similarly for the other three tuples. These assertions are not yet proven (although some non-trivial upper and lower bounds for such probabilities can be obtained from ")#link("http://arxiv.org/abs/1405.2593")[#text("recent work of Maynard")]#text(").")

#text("However, Lemke Oliver and Soundararajan argue (backed by both plausible heuristic arguments (based ultimately on the ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy-Littlewood prime tuples conjecture")]#text("), as well as substantial numerical evidence) that there is a significant bias away from the tuples ")#mi("{(1 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(" and ")#mi("{(2 \\text{ mod } 3, 2 \\text{ mod } 3)}")#text(" – informally, adjacent primes don’t like being in the same residue class! For instance, they predict that the probability of attaining ")#mi("{(1 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(" is in fact")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{4} - \\frac{1}{8} \\frac{\\log\\log x}{\\log x} + O( \\frac{1}{\\log x} )")]]

#text("with similar predictions for the other three pairs (in fact they give a somewhat more precise prediction than this). The magnitude of this bias, being comparable to ")#mi("{\\log\\log x / \\log x}")#text(", is significantly stronger than the Chebyshev bias of ")#mi("{O(1/\\sqrt{x})}")#text(".")

#text("One consequence of this prediction is that the prime gaps ")#mi("{p_{n+1}-p_n}")#text(" are slightly less likely to be divisible by ")#mi("{3}")#text(" than naive random models of the primes would predict. Indeed, if the four options ")#mi("{(1 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(", ")#mi("{(1 \\text{ mod } 3, 2 \\text{ mod } 3)}")#text(", ")#mi("{(2 \\text{ mod } 3, 1 \\text{ mod } 3)}")#text(", ")#mi("{(2 \\text{ mod } 3, 2 \\text{ mod } 3)}")#text(" all occurred with equal probability ")#mi("{1/4}")#text(", then ")#mi("{p_{n+1}-p_n}")#text(" should equal ")#mi("{0 \\text{ mod } 3}")#text(" with probability ")#mi("{1/2}")#text(", and ")#mi("{1 \\text{ mod } 3}")#text(" and ")#mi("{2 \\text{ mod } 3}")#text(" with probability ")#mi("{1/4}")#text(" each (as would be the case when taking the difference of two random numbers drawn from those integers not divisible by ")#mi("{3}")#text("); but the Lemke Oliver-Soundararajan bias predicts that the probability of ")#mi("{p_{n+1}-p_n}")#text(" being divisible by three should be slightly lower, being approximately ")#mi("{1/2 - \\frac{1}{4} \\frac{\\log\\log x}{\\log x}}")#text(".")

#text("Below the fold we will give a somewhat informal justification of (a simplified version of) this phenomenon, based on the Lemke Oliver-Soundararajan calculation using the prime tuples conjecture.")

#metadata(none) <tao-1ba65376e17cf3a47297>

#text("To explain the Lemke Oliver-Soundararajan bias, it is convenient to relax the requirement that the primes ")#mi("{p_{n+1}-p_n}")#text(" are consecutive, and just look at small prime differences ")#mi("{p^{\\prime\\prime}-p^{\\prime}}")#text(" between primes ")#mi("{p^{\\prime},p^{\\prime\\prime} \\sim x}")#text(" that are somewhat close (in the sense that ")#mi("{p^{\\prime\\prime}-p^{\\prime}}")#text(" is of size ")#mi("{O(\\log x)}")#text(", which corresponds by the prime number theorem to the mean spacing between primes), but not necessarily consecutive. (This relaxation changes some of the constants in the Lemke Oliver-Soundarajaran analysis, basically by eliminating the need to invoke the inclusion-exclusion principle, but does not affect the qualitative nature of the bias.) The naive Cramér random model for the primes (discussed for instance in ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this post")]#text(") suggests, as a first approximation, that for any ")#mi("{h = O(\\log x)}")#text(", the number of prime differences ")#mi("{p^{\\prime\\prime}-p^{\\prime} = h}")#text(" that are equal to ")#mi("{h}")#text(" with ")#mi("{p^{\\prime},p^{\\prime\\prime} \\sim x}")#text(" should be on the order of ")#mi("{\\frac{x}{\\log^2 x}}")#text(". Of course, this naive model is well known to require some adjustment: most obviously, prime differences ")#mi("{p^{\\prime\\prime}-p^{\\prime}}")#text(" are almost always even, so the number of solutions to ")#mi("{p^{\\prime\\prime}-p^{\\prime}=h}")#text(" is close to zero when ")#mi("{h}")#text(" is odd. A little less obviously, values of ")#mi("{h}")#text(", such as ")#mi("{6}")#text(", which are multiples of three should (all other things being equal) be twice as likely to be prime differences as values of ")#mi("{h}")#text(" (such as ")#mi("{2}")#text(") which are not; that is to say, one expects about twice as many “")#link("https://en.wikipedia.org/wiki/Sexy_prime")[#text("sexy primes")]#text("” as “")#link("https://en.wikipedia.org/wiki/Twin_prime")[#text("twin primes")]#text("“. This is ultimately because the lower prime ")#mi("{p^{\\prime}}")#text(" in a sexy prime pair ")#mi("{p^{\\prime\\prime}-p^{\\prime}=6}")#text(" can lie in either of the two residue classes ")#mi("{1 \\text{ mod } 3}")#text(", ")#mi("{2 \\text{ mod } 3}")#text(", but the lower prime ")#mi("{p^{\\prime}}")#text(" in a twin prime pair ")#mi("{p^{\\prime\\prime}-p^{\\prime}=2}")#text(" can only lie in the residue class ")#mi("{2 \\text{ mod } 3}")#text(" (after excluding the first twin prime pair ")#mi("{(3,5)}")#text(").")

#text("The Lemke Oliver-Soundararajan bias pushes back against this phenomenon slightly; roughly speaking, it says that a typical number ")#mi("{h=O(\\log x)}")#text(" that is a multiple of ")#mi("{3}")#text(" is only about ")#mi("{2 - c \\frac{\\log \\log x}{\\log x}}")#text(" times as likely to be a prime difference as a typical number ")#mi("{h}")#text(" that is a non-multiple of ")#mi("{3}")#text(", for some absolute constant ")#mi("{c>0}")#text(" (which can be computed explicitly from their work, but I will not do so here).")

#text("This bias can be established assuming the ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy-Littlewood prime tuples conjecture")]#text(" (with a sufficiently good error term). This conjecture asserts, roughly speaking, that the number of solutions to ")#mi("{p^{\\prime\\prime}-p^{\\prime} = h}")#text(" with ")#mi("{p^{\\prime},p^{\\prime\\prime} \\sim x}")#text(" and some given even ")#mi("{0 < h \\ll \\log x}")#text(" is proportional to ")#mi("{f(h) \\frac{x}{\\log^2 x}}")#text(", where ")#mi("{f(h)}")#text(" is the quantity ")#metadata(none) <tao-600e40bf505b637d788a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(h) := \\prod_{p>2: p|h} \\frac{p-1}{p-2}.")]]

#text("The proportionality constant depends on the implicit constants in the relation ")#mi("{p^{\\prime},p^{\\prime\\prime} \\sim x}")#text(", and also involves the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]

#align(center)[#tao-fit-display[#mitex("\\Pi_2 := \\prod_{p > 2} (1 - \\frac{1}{(p-1)^2}) = 0.66016\\dots;")]]

#text("it will not play an important role though in our analysis, so we omit it. The reason for the ")#mi("{\\frac{p-1}{p-2}}")#text(" factor can be explained from the following simple calculation: if ")#mi("{p}")#text(" is an odd prime, and we select two numbers ")#mi("{p^{\\prime}, p^{\\prime\\prime}}")#text(" independently at random that are coprime to ")#mi("{p}")#text(" (and equally likely to be in each of the ")#mi("{p-1}")#text(" primitive residue classes mod ")#mi("{p}")#text("), then the probability that ")#mi("{p^{\\prime}-p^{\\prime\\prime} = 0 \\text{ mod } p}")#text(" can be calculated to be ")#mi("{\\frac{p-1}{p-2}}")#text(" times as large as the probability that ")#mi("{p^{\\prime}-p^{\\prime\\prime} = h \\text{ mod } p}")#text(" for any given ")#mi("{h}")#text(" not divisible by ")#mi("{p}")#text(". For instance, if ")#mi("{p=3}")#text(", then ")#mi("{p^{\\prime}-p^{\\prime\\prime}}")#text(" is twice as likely to equal ")#mi("{0 \\text{ mod } 3}")#text(" as it is equal ")#mi("{2 \\text{ mod } 3}")#text(", as we have already observed before.")

#text("Naively, one would expect the quantity ")#mi("{f(h)}")#text(" to be about twice as large when ")#mi("{h}")#text(" is a multiple of three than when ")#mi("{h}")#text(" is not a multiple of ")#mi("{3}")#text(", due to the ")#mi("{p=3}")#text(" factor of ")#mi("{\\frac{p-1}{p-2} = 2}")#text(" in ")#link(<tao-600e40bf505b637d788a>)[#text("(1)")]#text(". However, it turns out that when restricting to the range ")#mi("{h = O(\\log x)}")#text(", the average value of ")#mi("{f(h)}")#text(" for ")#mi("{h}")#text(" a multiple of ")#mi("{3}")#text(" is only about ")#mi("{2 - c \\frac{\\log \\log x}{\\log x}}")#text(" as large as the average value of ")#mi("{f(h)}")#text(" for ")#mi("{h}")#text(" not a multiple of ")#mi("{3}")#text(".")

#text("If we strip out the ")#mi("{p=3}")#text(" term in ")#link(<tao-600e40bf505b637d788a>)[#text("(1)")]#text(", creating a new function")

#align(center)[#tao-fit-display[#mitex("f_3(h) := \\prod_{p>3: p|h} \\frac{p-1}{p-2}")]]

#text("then the previous bias turns out to be a consequence of an asymptotic roughly of the form ")#metadata(none) <tao-b737ca7ee563ae80e457>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{h \\leq H} f_3(h) = c_1 H - c_2 \\log H + O(1)")]]

#text("for some absolute constants ")#mi("{c_1,c_2 > 0}")#text(" and all ")#mi("{H > 1}")#text(". (Actually, to avoid some artificial boundary issues one should replace the restriction ")#mi("{1_{h \\leq H}}")#text(" with a smoother weight such as ")#mi("{e^{-h/H}}")#text(", but we will ignore this technicality for sake of discussion.) Indeed, assuming the asymptotic ")#link(<tao-b737ca7ee563ae80e457>)[#text("(2)")]#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{h \\leq \\log x: h = 0 \\text{ mod } 3} f_3(h)  & = \\sum_{h \\leq \\frac{1}{3} \\log x} f_3(3h)", block: true)



#tao-math(" & = \\sum_{h \\leq \\frac{1}{3} \\log x} f_3(h)", block: true)



#tao-math(" & = \\frac{1}{3} c_1 \\log x ( 1 - 3\\frac{c_2}{c_1} \\frac{\\log\\log x}{\\log x} + O( \\frac{1}{\\log x} ) )", block: true)
]

#text("whereas")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\leq \\log x} f_3(h) = c_1 \\log x ( 1 - \\frac{c_2}{c_1} \\frac{\\log\\log x}{\\log x} + O( \\frac{1}{\\log x} ) )")]]

#text("so we see that ")#mi("{f_3}")#text(" has a slightly lower mean (by a factor of about ")#mi("{1 - 2 \\frac{c_2}{c_1} \\frac{\\log\\log x}{\\log x}}")#text(") on the multiples of ")#mi("{3}")#text(" than in general, which implies the corresponding claim about ")#mi("{f}")#text(". We thus see that the Lemke Oliver-Soundarajan bias can be traced to the lower order term ")#mi("{-c_2 \\log H}")#text(" in ")#link(<tao-b737ca7ee563ae80e457>)[#text("(2)")]#text(".")

#text("In the paper of Lemke Oliver and Soundararajan, the asymptotic ")#link(<tao-b737ca7ee563ae80e457>)[#text("(2)")]#text(" (smoothed out as discussed above) is obtained from standard complex methods, based on an analysis of the Dirichlet series")

#align(center)[#tao-fit-display[#mitex("\\sum_h \\frac{f_3(h)}{h^s} = \\prod_{p>3} (1 + \\frac{p-1}{p-2} \\frac{1}{p^s}).")]]

#text("As it turns out, this Dirichlet series has poles at both ")#mi("{s=1}")#text(" and ")#mi("{s=0}")#text(" (it contains a factor of ")#mi("{\\zeta(s) \\zeta(1+s)}")#text("), contributing to the ")#mi("{c_1 H}")#text(" and ")#mi("{-c_2 \\log H}")#text(" terms respectively. One can also establish ")#link(<tao-b737ca7ee563ae80e457>)[#text("(2)")]#text(" (with smoothing) using elementary number theory methods (as in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this previous post")]#text("); we sketch the argument as follows. We can factor ")#mi("{f_3}")#text(" as a Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("f_3(h) = \\sum_{d|h} g(d)")]]

#text("where ")#mi("{g(d)}")#text(" vanishes unless ")#mi("{d}")#text(" is the product of distinct primes greater than or equal to ")#mi("{3}")#text(", in which case")

#align(center)[#tao-fit-display[#mitex("g(d) = \\prod_{p|d} \\frac{1}{p-2}")]]

#text("(with the convention ")#mi("{g(1)=1}")#text("). Then we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\leq H} f_3(h) = \\sum_{d \\leq H} g(d) \\sum_{m \\leq H/d} 1.")]]

#text("Morally speaking, ")#mi("{\\sum_{m \\leq H/d} 1}")#text(" behaves like ")#mi("{\\frac{H}{d} - \\frac{1}{2}}")#text("; we can use pseudorandomness heuristics to argue that the fluctuation around this main term give a lower order contribution (and one can argue this rigorously when using smoother weights like ")#mi("{e^{-h/H}}")#text("). The term ")#mi("{-1/2}")#text(" can be interpreted as ")#mi("{\\zeta(0)=1+1+\\dots}")#text(", as per ")#link("https://terrytao.wordpress.com/2010/04/10/the-euler-maclaurin-formula-bernoulli-numbers-the-zeta-function-and-real-variable-analytic-continuation/")[#text("this previous post")]#text(". Assuming this approximation, we obtain the approximation")

#align(center)[#tao-fit-display[#mitex("\\sum_{h \\leq H} f_3(h) \\approx H \\sum_{d \\leq H} \\frac{g(d)}{d} - \\frac{1}{2} \\sum_{d \\leq H} g(d).")]]

#text("The sequence ")#mi("{g(d)}")#text(" behaves somewhat like ")#mi("{1/d}")#text(". As such, one expects (and can calculate) ")#mi("{\\sum_{d \\leq H} \\frac{g(d)}{d}}")#text(" to have an asymptotic of the form ")#mi("{c_1 + O(1/H)}")#text(", while ")#mi("{\\sum_{d \\leq H} g(d)}")#text(" has an asymptotic of the form ")#mi("{2 c_2 \\log H + O(1)}")#text(" for some explicit constants ")#mi("{c_1,c_2>0}")#text(", which gives ")#link(<tao-b737ca7ee563ae80e457>)[#text("(2)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One way of thinking about ")#link(<tao-b737ca7ee563ae80e457>)[#text("(2)")]#text(" is that the function ")#mi("{f_3(h)}")#text(" behaves on the average like ")#mi("{c_1 - \\frac{c_2}{h}}")#text(". The bulk of the bias effect is then coming from small values ")#mi("{h=o(\\log x)}")#text(" of ")#mi("{h}")#text(", that is from prime gaps that are significantly smaller than average; one should not see the bias effect if one restricts to prime gaps of the typical size of ")#mi("{\\asymp \\log x}")#text(". This is consistent with the general philosophy that one does not expect to see “long-range” correlations between the primes.")
]

#heading(level: 1)[#text("Comments (80)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466953")[#strong[#text("Biases between consecutive primes – jiangose")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/")[#text("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50101617f113259147b1041a47d39e63dccd2d5f753bdf8101ebbfe4c634f0dd-0ce7dd429a3d392893a36d9737f6e8f99e43ebbc3e159f2616ee969c988b74fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asvin")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466955")[#strong[#text("Asvin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")])]

#text("I am not sure if the following question makes complete sense but do we expect a function field analogue for this phenomenon?")

#text("Consecutive primes no longer makes sense but perhaps one can ask what fraction of primes with degree < d+2 are in the same residue class or something along these lines?")

#text("Perhaps this is easier to prove?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466966")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("Yes, I think something along these lines can be proven, particularly if one works with differences of irreducible polynomials rather than trying to come up with a good notion of “consecutive” irreducible polynomials. In particular, the analysis given in this blog post, when translated to a finite field setting, seems to indicate that a low degree polynomial ")#mi("h(t)")#text(" is a little bit less likely than naively expected to be the difference of two high degree irreducible polynomials ")#mi("p^{\\prime}(t), p^{\\prime\\prime}(t)")#text(" if ")#mi("h(t)")#text(" is divisible by a very small polynomial ")#mi("q(t)")#text(" (where “naively expected” means what one would expect if ")#mi("p^{\\prime}, p^{\\prime\\prime}")#text(" were random polynomials chosen to be coprime to ")#mi("q")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466956")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")])]

#text("The word “adjustement” should be adjusted to “adjustment”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")])]

#text("It seems that in the ninth row below (2), the coefficient 3 in the RHS is not needed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466958")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("Is there any influence of this bias on the spacing between zeta zeros on the critical line?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("Interesting question. The Lemke Oliver-Soundararajan bias can be explained in terms of the prime tuples conjecture, which can also be used to explain (at least part of) the GUE hypothesis for spacings between zeroes (as per the work of Goldston and Montgomery on the pair correlation conjecture), so I would presume that this bias is consistent with the GUE hypothesis, for which we have quite a bit of numerical evidence and other supporting data.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466963")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("Since this bias is implied by the prime tuples conjecture, does this means that the remainder term in the prime tuple conjecture is unbiased?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("The remainder term in the prime tuples conjecture is conjectured to be only ")#mi("O(x^{-1/2+o(1)})")#text(" the size of the main term, and so should not have any appreciable influence on the Lemke Oliver-Soundararajan bias, which is significantly larger (of size about ")#mi("O( \\log\\log x / \\log x )")#text(" of the main term). In particular, this remainder term could be heavily biased or significantly larger than expected and still it would not have a visible effect on the Lemke Oliver-Soundararajan bias (see also the remarks at the top of page 7 of their paper).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b4f0e30f63f7189218b824623e6c7ed5e0cbadcc33cc46634a49bea164c04f4-dffbb4b09df50b3b4927d0203b805c41bc0fff8839c30c8308ef7f5d6a89272c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael D. Moffitt")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466975")[#strong[#text("Michael D. Moffitt")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2016")])]

#text("I had thought Richard Brent proved something along these lines back in 1974 (“The Distribution of Small Gaps Between Successive Primes”).")

#text("Theorems aside, this result seems to hold trivially – maybe I am missing something? For instance, the pop science article implies that one would expect the last digit of a successive prime to be randomly distributed. Why would anyone assume this? If p is prime, surely p + 6 has a greater chance of being prime than p + 10 (since p + 10 has the chance of landing on a multiple of 3, whereas p + 6 cannot).")

#text("Is there something more to this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Sahay")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466979")[#strong[#text("Anurag Sahay")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("Yes. The bias that you’d expect from this phenomenon is not as large as the actual observed bias.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b4f0e30f63f7189218b824623e6c7ed5e0cbadcc33cc46634a49bea164c04f4-dffbb4b09df50b3b4927d0203b805c41bc0fff8839c30c8308ef7f5d6a89272c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael D. Moffitt")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466981")[#strong[#text("Michael D. Moffitt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("Ah, ok. In the paper, the authors purport an expectation that one should expect *equally* occurring residue pairs. I don’t see how that can be reconciled with the known distribution of prime gaps … especially in Base 10, it appears that the “p + 6” peak explains away a majority of the differences in occurrence.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b4f0e30f63f7189218b824623e6c7ed5e0cbadcc33cc46634a49bea164c04f4-dffbb4b09df50b3b4927d0203b805c41bc0fff8839c30c8308ef7f5d6a89272c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael D. Moffitt")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466980")[#strong[#text("Michael D. Moffitt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("I should have phrased my question this way: given that the distribution of prime gaps is well-known to be highly multimodal (with peaks at 6 & 12, dips at 8, etc.), wouldn’t it have taken a miracle for all pairwise residues to occur at identical frequencies in the first place? I would never have expected a uniform distribution to begin with.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467006")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("The precise phrase used by the authors (at the bottom of page 1) is “")#strong[#text("roughly")]#text(" equally often”. (The modifier “roughly” makes a crucial distinction, analogous to the distinction between the ")#link("https://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Gambler%27s_fallacy")[#text("gambler’s fallacy")]#text(".) The surprise is not that there exist some biases in the distribution, but that the quantitative magnitude of the bias is so large. As mentioned in the post, the Chebyshev bias, for instance, only explains about ")#mi("O( x^{-1/2})")#text(" of the bias, and irregularities in small prime gaps such as ")#mi("p, p+6")#text(", or the simple fact that after a given residue class (such as ")#mi("7 \\text{ mod } 10")#text("), one has to wait longer for the next appearance of that class than any other class, can explain a further ")#mi("O( 1/\\log x )")#text(" of the gap, but what was unexpected was that the bias was even larger than that, being proportional to ")#mi("\\log\\log x /\\log x")#text(". This indicates that there are some systematic biases in prime gaps at moderately large scales, which in my blog post is captured by the terms involving the factor ")#mi("c_2")#text(". This can be compared with the ")#link("http://www.ams.org/mathscinet-getitem?mr=409385")[#text("classical computation")]#text(" of Gallagher on the average behaviour of prime gaps, which in the language of the blog post roughly corresponds to the asymptotic ")#mi("\\sum_{h \\leq H} f_3(h) = c_1 H + o(H)")#text(". The surprise is then the extra ")#mi("- c_2 \\log H")#text(" term appearing in the finer asymptotic in (2).")

#text("One way to think about the Lemke Oliver-Soundararajan bias is the following. The Cramer type models suggest that the distribution of the prime differences ")#mi("p^{\\prime} - p^{\\prime\\prime} \\text{ mod } q")#text(" should be distributed according to the difference between two randomly selected residue classes coprime to ")#mi("q")#text(". On the other hand, the diagonal case ")#mi("p^{\\prime}=p^{\\prime\\prime}")#text(" gives a somewhat large contribution to the ")#mi("0 \\text{ mod } q")#text(" difference. To balance this, the other prime differences should have some additional slight bias away from ")#mi("0 \\text{ mod } q")#text(". This bias is indeed slight – prime differences of magnitude ")#mi("\\sim h")#text(" will exhibit a bias of about ")#mi("-1/h")#text(" due to this redistribution – but after summing over all ")#mi("h = O(\\log x)")#text(", this creates the additional ")#mi("\\log\\log x")#text(" increase in bias over the effects of size ")#mi("O(1/\\log x)")#text(" coming from more readily apparent bias effects. To put it another way, there is a form of the gambler’s fallacy that is actually valid for the distribution of primes in residue classes!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9245322427ab4ec6631f23eb3fa112e3f7b8b289bc7c7543fa6ae3f245bd352b-aef3f641c80171a0dc95fc48495c0631cdebf25b00de378e160055b36a1a0403.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("Sorry Terry, but I just don’t buy the “roughly equal” premise either – it’s a straw man argument. If I were a classically trained mathematician (which I’m not), I’d base my initial expectations on the known, *observed* distribution of consecutive primes, not Cramer’s bogus random model. The “Jumping Champions” paper from 1999 plots a nice distribution up to N = 100000.")

#text("p(gap=2): 10.25%")#linebreak()#text(" p(gap=4): 10.21%")#linebreak()#text(" p(gap=6): 16.25%")#linebreak()#text(" p(gap=8): 7.07%")#linebreak()#text(" …")

#text("The transition probabilities between residue classes of any distance (in any base!) can be computed directly from these. For mod 3, the gaps that retain residue classes occur at sizes of 6, 12, etc. All the others lead to external transfers:")

#text("p(same_residue) = p(gap=6) + p(gap=12) + … = 0.42")#linebreak()#text(" p(diff_residue) = p(gap=2) + p(gap=4) + … = 0.58")

#text("There’s your bias factor right there – *by inspection*, one would expect transitions to a different residue class almost 50% more often, and that’s exactly what we see. So, I simply don’t understand why this suddenly comes as a surprise to the math elites.")

#text("Perhaps number theorists never bothered to read these decades-old papers? If so, I think that’s the real news here. If I were to write a headline for this breakthrough, it would be “Theoretical Mathematicians Discover Computers.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467065")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("It seems like you’re focusing on “small numbers”. The numerical evidence can be explained via these gaps, but what about for very large n? The distribution of the gaps is different. For example, the most common gap should be around log n. If n is much larger, then your common gaps are not 2, 4, 6, 8, but numbers near log n. As Tao already pointed out, the frequency of certain gaps explains part of the bias, but the bias is even larger than what would come from just looking at the gaps.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9245322427ab4ec6631f23eb3fa112e3f7b8b289bc7c7543fa6ae3f245bd352b-aef3f641c80171a0dc95fc48495c0631cdebf25b00de378e160055b36a1a0403.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("You’ve got it wrong. The *average* gap size is log(n), but the *most common* gap size is 6 … all the way up to 10^35 (please read the 1999 Jumping Champions paper). Small gaps dominate the distribution for a long, long time!")

#text("My claim is that you can *exactly* predict the bias just by counting up the gap frequencies. Try it for yourself! Write a program that keeps track of the gap sizes (feel free to go as high as you want) and then add up the gap sizes that are multiples of 6. You will see the bias term right there, plain as day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467067")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("The 9:38am poster is correct. Small gaps such as 6 may be the most frequently occurring gap for some time, but even this gap only actually occurs about ")#mi("O(1/\\log n)")#text(" of the time, and these small gaps only explain at most ")#mi("O( 1/\\log n )")#text(" of the bias effect at most. As I said previously, the surprise is not that the bias effect exists at all, but that it is larger than the ")#mi("O(1/\\log n)")#text(" effect caused by individual prime gap sizes such as 6, instead being of size ")#mi("O( \\log \\log n / \\log n )")#text(". It is this extra ")#mi("\\log \\log n")#text(" factor which was not predicted in any of the previous numerical work on the problem (indeed, it would be difficult to see this term even for ")#mi("n")#text(" as large as ")#mi("10^{35}")#text("), and in my opinion this is the most interesting aspect of the Lemke Oliver-Soundararajan work. (Interestingly, if one works with the conjectural “jumping champion”, which is usually the primorial close to ")#mi("\\log n")#text(", one gets an effect of size about ")#mi("O( \\log \\log \\log n / \\log n )")#text(", but in the wrong direction – the jumping champion tends to be divisible by all small primes and so would presumably bias the prime gaps to ")#emph[#text("favour")]#text(" being divisible by such primes, rather than away from it. So the Lemke Oliver-Soundararajan effect is actually strong enough to ")#emph[#text("counteract")]#text(" the effect of jumping champions!)")

#text("Incidentally, there are many other examples in the analytic number theory literature in which numerical evidence ended up being misleading due to an inability to see contributions of order ")#mi("\\log \\log n")#text(" or slower. Examples include ")#link("https://en.wikipedia.org/wiki/Mertens_conjecture")[#text("Mertens’ conjecture")]#text(" (known to fail before about ")#mi("\\exp(10^{40})")#text(" or so), the conjecture ")#mi("\\pi(x) \\leq \\text{li}(x)")#text(" (known to fail at or before ")#link("https://en.wikipedia.org/wiki/Skewes%27_number")[#text("Skewes’ number")]#text("), and the ")#link("https://en.wikipedia.org/wiki/Second_Hardy%E2%80%93Littlewood_conjecture")[#text("second Hardy-Littlewood conjecture")]#text(" (suspected to fail before ")#mi("10^{1178}")#text("). On the other hand, all numerical evidence available still points to these conjectures being true; it is only theoretical calculations that can discern the true asymptotic behaviour (though in some cases the results are conditional on standard conjectures such as the Riemann hypothesis or the prime tuples conjecture). As such, we’ve learned not to rely solely on numerical evidence, even if it involves a superficially impressive number of data points (e.g. ")#mi("10^{35}")#text("); far more convincing would be a combination of numerical evidence and theoretical results showing that the numerically observed phenomenon can be derived from, or is at least consistent with, existing theorems and standard heuristic models and conjectures such as the Riemann hypothesis, the prime tuples conjecture, or the Cramer model (which are in turn supported not only by numerics, but by a vast array of theoretical partial results and other evidence).")

#emph[#text("[EDIT: the effect of the jumping champion is in fact ")#mi("O( \\log\\log\\log n/\\log n)")#text(", not ")#mi("O( \\log\\log n/\\log n)")#text(" as previously claimed. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("It is not clear why the “jumping champion” effect is missing in conjecture 1.1 in the paper (which has a smaller second order term of size ")#mi("O(1/ \\log x)")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2016")])]

#text("It smooths out. It is true that technically, the existence of jumping champions (or more generally, the unbounded nature of ")#mi("f_3(h)")#text(" makes the estimate (2) false as stated, but if one uses the smooth weight of ")#mi("e^{-h/H}")#text(" (which corresponds to the actual distribution of prime gaps, which is conjecturally exponential with mean ")#mi("H = \\log x")#text("). Unlike rough sums, a smooth sum can have error terms that are smaller than the size of an individual term. For instance, ")#mi("\\sum_h e^{-h/H}= \\frac{1}{e^{1/H}-1} = H - \\frac{1}{2} + O(\\frac{1}{H})")#text(" has error terms that can be made smaller than any given power of ")#mi("H")#text(" by suitable Taylor expansion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2016")])]

#text("It seems that the summands in the above example should be ")#mi("e^{-h/H}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466983")[#strong[#text("¿Sorpresa sobre los números primos? | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")]

#text("[…] Para entender mi sorpresa, te recomiendo leer a Alvy (@Alvy), “Descubierto un extraño comportamiento de los números primos que se «repelen»”, Microsiervos, 14 Mar 2016. Luego pasar a su fuente, Erica Klarreich, “Mathematicians Discover Prime Conspiracy,” Quanta Magazine, 13 Mar 2016. Para luego leer las cuatro primeras páginas (el resto no merece la pena) de Robert J. Lemke Oliver, Kannan Soundararajan, “Unexpected biases in the distribution of consecutive primes,” arXiv:1603.03720 [math.NT]. Y, finalmente, disfrutar con el genial Terry Tao, “Biases between consecutive primes,” What’s new, 14 Mar 2016. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-466989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("For fixed small modulus ")#mi("q")#text(" and moderately large ")#mi("H")#text(", is there any known efficient method to evaluate the number of such pairs of consecutive primes (in two given residue classed mod ")#mi("q")#text(") in ")#mi("[x, x+H]")#text(" for large x? (this may help in extending the range of the tables in the paper),")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467002")[#strong[#text("Number Theory News | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")]

#text("[…] more details, there’s an excellent blog post from Terry Tao. This might be a good time to point out that people sometimes complain about the quality of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fde0676455d8e524e39020afbe2fcb930a65feaf1a0afa8d5d929e9e3fd6851-76b68ed859d779a6b5a1a90e0bf6deed7f91652e7643b64e1fa4173a1684b074.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ανακαλύφθηκε μια «περίεργη» ιδιότητα των πρώτων αριθμών | physicsgg")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467004")[#strong[#text("Ανακαλύφθηκε μια «περίεργη» ιδιότητα των πρώτων αριθμών | physicsgg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("[…] Prime Conspiracy« 2. ")#link("http://www.nature.com")[#text("http://www.nature.com")]#text(": «Peculiar pattern found in ‘random’ prime numbers» 3. terrytao.wordpress.com: «Biases between consecutive […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/328c278ba769e882468008ea638079952ddc169bada819beacd250ed1fedcdc4-e8ecff6003c854f2c600231f176c49c4d9defd3f3d0bf1d8f7a6aa95a36005dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geometriclanglander")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467012")[#strong[#text("geometriclanglander")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("Simply wonderful. I wonder whether it provides an alternative vantage point when considering pair-correlation-esque random matrix analogies…")

#text("Unfortunately the comments are being overrun by a crank…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2016")])]

#text("The excessive comments (14 in all) have now been removed as per the “spam” policy of my blog: ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9245322427ab4ec6631f23eb3fa112e3f7b8b289bc7c7543fa6ae3f245bd352b-aef3f641c80171a0dc95fc48495c0631cdebf25b00de378e160055b36a1a0403.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("Get a load of this: in the original version of the paper (at ")#link("http://arxiv.org/pdf/1603.03720v1.pdf")[#text("http://arxiv.org/pdf/1603.03720v1.pdf")]#text("), they omitted a key reference to Ash et al. 2010. Why is that reference important? Because *they* are the ones that disclose this anti-pattern.")

#text("Now for the kicker: Soundararajan (one of the authors) was a reviewer for that paper! Look the the acknowledgements section:")

#link("https://www2.bc.edu/~ashav/Papers/ABGS-PrimePairsFinal.pdf")[#text("Click to access ABGS-PrimePairsFinal.pdf")]

#text("Terry, I’m curious if it’s typical for mathematicians to be this snakey.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467027")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2016")])]

#text("I think ")#link("https://en.wikipedia.org/wiki/Hanlon%27s_razor")[#text("Hanlon’s razor")]#text(" applies here. We try our best to collect the relevant references for a given paper, but the literature is vast, and sometimes papers slip through the cracks, though nowadays one often gets notified of a missing reference once we put a preprint up on the arXiv, or during the refereeing process. The 2011 paper of Ash et al. you mention, for instance, had ")#link("http://www.ams.org/mathscinet-getitem?mr=2859898")[#text("zero citations in MathSciNet")]#text(" (though this will of course change when the current paper is published), so it may have been missed by the authors during their search of the literature. (This sort of thing happens quite often; just a few days ago, for instance, I updated ")#link("http://arxiv.org/abs/1603.03068")[#text("my most")]#text(" ")#link("http://arxiv.org/abs/1603.03071")[#text("recent preprints")]#text(" on the arXiv to add some references that Van and I missed, and were only pointed out to us after we released our first version of the preprints.)")

#text("It may be in a few years that semantic search tools become available that allow one to find the relevant literature more systematically (beyond the current method of relying on some ")#emph[#text("ad hoc")]#text(" mix of literature searches, citation searches, consulting with other experts, one’s own memory, and use of general-purpose search engines like Google), but we’re not quite there yet.")

#text("Looking at the paper of Ash et al., it seems that Sound was credited for “help”, but was not a referee (and in mathematics, referees are generally anonymous and not disclosed to the authors). My guess is that the authors asked Sound a mathematical question related to their paper in the course of their research, but he might not have read or even seen the final version of the paper. (I myself get a couple such queries each week, and would probably not recall any specific such query dating back from 2010 or so unless I went back through my email archives to locate it.)")

#text("In any event, the Ash et al. paper is focusing on a slightly different aspect of the statistics of residue classes of consecutive primes, namely a certain conjectural “antidiagonal symmetry” predicted by their heuristics (and which is also predicted by the Lemke Oliver-Soundararajan computations, which are based on a slightly different heuristic model). They tentatively raise the possibility of a bias away from equal residue classes in the final section of their paper, but it is not strongly emphasised. According to their own paper as well as the Quanta article, the proximate inspiration for Lemke Oliver and Soundararajan was instead a lecture by Tadashi Tokieda on biases regarding the first occurrence of various patterns in coin tosses.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467049")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2016")])]

#text("From the paper:")

#text("<< We give two other amusing consequences of Conjecture 1.1. The famous biases π(x) <")#linebreak()#text(" li(x), or π(x; 3, 1) < π(x; 3, 2), or π(x; 4, 1) < π(x; 4, 3) are known to be false infinitely")#linebreak()#text(" often. However we conjecture that the robust biases in pairs of consecutive primes (mod 3)")#linebreak()#text(" or (mod 4) may hold always and from the very start!")

#text("Conjecture 1.3: Let q = 3 or 4, and let a be either 1 (mod q) or −1 (mod q). Then for all")#linebreak()#text(" x ≥ 5, we have π(x; q,(a, -a)) > π(x; q,(a, a)). >>")

#text("Is it possible to envision a direct proof of Conjecture 1.3, without proving the much tougher Conjecture 1.1? How might one go about such a proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2016")])]

#text("This conjecture looks well beyond the reach of current methods. For instance I think it is not currently known (though it is almost certainly true) that π(x; 4,(1, 3)) is >>π(x) (though, perversely, thanks to recent work of Maynard, we can prove this claim for the quantity π(x; 4,(1, 1)), which is supposed to be smaller!).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467051")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2016")])]

#text("I have a question: can this bias be expressed interestingly in terms of n rather than x? I ask because I just had a look at the phenomenon empirically, using the following very lazy Mathematica code:")

#text("k = 1000000;")#linebreak()#text(" w = 10000;")#linebreak()#text(" p1 = Table[Mod[Prime[n + 1] – Prime[n], 3], {n, 1, k + w}];")#linebreak()#text(" Show[Plot[0.5 – 0.25*Log[Log[n]]/Log[n], {n, 30, k},")#linebreak()#text(" PlotStyle -> Red, PlotRange -> Full],")#linebreak()#text(" ListPlot[Table[")#linebreak()#text(" Count[p1[[m – w ;; m + w]], 0]/(2 w + 1), {m, w + 1, k}]],")#linebreak()#text(" PlotRange -> {{1, k}, {0.4, 0.44}}]")

#text("which shows in red the expected probability of p_{n+1}-p_n being divisible by 3 according to this result, and in blue the proportion of the primes p_n-5000 through p_n+5000 for which p_{n+1}-p_n is in fact divisible by 3 – but, plotted with the x-axis scaled according to n rather than x. It’s no surprise that the error term is now O(1) rather than O(1/log x), but I’m wondering whether the actual value of that error term, which seems to hold pretty steady at about -0.017, can be derived from reasoning analogous to that of Lemke Oliver and Soundararajan.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467053")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2016")])]

#text("Asymptotically, the prime number theorem tells us that ")#mi("p_n \\approx n \\log n")#text(", so the relationship between ")#mi("x")#text(" and ")#mi("n")#text(" is approximately ")#mi("x \\approx n \\log n")#text(", which implies that ")#mi("\\log x \\approx \\log n")#text(" and ")#mi("\\log \\log x \\approx \\log\\log n")#text(". So, up to lower order terms, the size of the Lemke Oliver-Soundararajan bias should look about the same asymptotically whether viewed in terms of n or of x.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("It seems that the relatively large size of these biases (between consecutive primes) can be used to construct an explicit(!) statistical test to distinguish (almost surely!) the sequence of primes from any random sequence of “primes” constructed using standard probabilistic models for primes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467104")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2016")])]

#text("Can you clarify what you mean a bit further, this seems like an interesting idea.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2016")])]

#text("Based on conjecture 1.1 in the paper, choose ")#mi("a=(a_1, ... , a_r)")#text(" and ")#mi("q")#text(" such that ")#mi("c_1(q;a) \\neq 0")#text(" and define")#linebreak()#text(" ")#mi("c_1(x;q,a) := (\\phi(q)^r \\pi(x;q,a) / li(x) -1) \\log x / \\log \\log x")

#text("By conjecture 1.1, ")#mi("c_1(x;q,a)")#text(" tends (as ")#mi("x \\to \\infty")#text(") to the nonzero(!) limit ")#mi("c_1(q;a)")#text(" for the sequence of primes, while it seems to tend almost surely (as having only the Chebyshev bias) to zero(!) for any sequence of “primes” constructed by standard probabilistic models for the primes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("It seems that such a test works even when a positive fraction (not 1) of the “primes” are primes!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21142316488f0c7afddbb243e6a509ef1d1642628a9f5ef6996b764dee5af841-4eed840c674617f4da6095ab1017156c47a2143cc2d663552e30ae8b9c3aa22c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467068")[#strong[#text("Alastair")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("I’m trying to understand intuitively what’s going on, in particular why the function ")#mi("f_3(h)")#text(" is slightly smaller on average on the multiples of 3. This function is large precisely when ")#mi("h")#text(" has lots of small prime factors, not counting 3. If ")#mi("h")#text(" is divisible by 3 then, since the 3 doesn’t count, we’re effectively looking at a number of size ")#mi("h/3")#text(" so we should expect slightly fewer prime factors and hence a slightly smaller ")#mi("f_3(h)")#text(". The average number of prime factors only changes from ")#mi("\\log\\log h")#text(" to ")#mi("\\log\\log (h/3)=\\log(\\log h-\\log 3)=\\log\\log h-O(1/\\log h)")#text(", which really doesn’t seem like very much although perhaps its enough to see why there’s a bias. I suspect that such crude heuristics, only looking at the average number of prime factors, aren’t powerful enough to predict the precise quantitative form of the bias.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("The way I think of it is as follows: given a random number between ")#mi("1")#text(" and ")#mi("H")#text(", the probability of being divisible by ")#mi("p")#text(" is not quite ")#mi("1/p")#text(", but is slightly less – it is ")#mi("\\lfloor H/p \\rfloor / H")#text(", which is roughly ")#mi("(H/p - 1/2)/H = \\frac{1}{p} - \\frac{1}{2H}")#text(" on the average. (The term ")#mi("-\\frac{1}{2}")#text(" here can also be interpreted as ")#mi("\\zeta(0)=1+1+1+\\dots")#text(", analogous to the more infamous ")#mi("-\\frac{1}{12} = \\zeta(1) = 1 + 2 + 3 + \\dots")#text(".) On the other hand, the probability that a random multiple of 3 between ")#mi("1")#text(" and ")#mi("H")#text(" is divisible by ")#mi("p")#text(" is slightly lower, about ")#mi("\\frac{1}{p} - \\frac{1}{2(H/3)}")#text(". More generally, given any ")#mi("d \\leq H")#text(" coprime to 3, the probability that a random number from ")#mi("1")#text(" to ")#mi("H")#text(" is divisible by ")#mi("d")#text(" goes down by a slight amount (proportional to ")#mi("1/H")#text(") if we condition to multiples of 3. This is what biases the function ")#mi("f_3(h) = \\sum_{d|h} g(d)")#text(" downward by about ")#mi("\\log H/H")#text(" on average if we restrict ")#mi("h")#text(" to be a multiple of 3.")

#text("Another way of thinking about it is that ")#mi("0")#text(" is divisible by ")#mi("d")#text(", so this leaves slightly fewer multiples of ")#mi("d")#text(" remaining for the non-zero numbers; when restricting to the multiples of three, the biasing effect of ")#mi("0")#text(" is larger, because it is a larger proportion of the total population of numbers available.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467077")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("To me the most surprising thing about this discovery of Lemke Oliver and Soundararajan is that it wasn’t made earlier, perhaps even by an amateur number theorist who was good at computing. (")#emph[#text("Explaining")]#text(" the effect requires expertise, but ")#emph[#text("discovering")]#text(" it seems much easier.)")

#text("So, why wasn’t it discovered sooner? My guess is that a whole ")#emph[#text("class")]#text(" of questions has been insufficiently studied, of which this is the simplest. Unfortunately, I’m not quite sure what this class is.")

#text("I imagine this class includes simple variants like “if the nth prime equals a mod m and the (n+1)st prime equals b mod m, what is the probability that the (n+2)nd equals c mod m, given that n < N?\"")

#text("But maybe someone who knows more number theory can better delineate this class of questions people forgot to ask, and find some of the more interesting questions in this class.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2016")])]

#text("There were at least two papers in experimental number theory that noticed some manifestation of the Lemke Oliver-Soundararajan bias on a qualitative level: ")#link("http://www.ams.org/mathscinet-getitem?mr=2859898")[#text("a 2011 paper of Ash, Beltis, Gross, and Sinott")]#text(", and a ")#link("http://www.ams.org/mathscinet-getitem?mr=1878428")[#text("2002 paper of Ko")]#text(". But I think the difficult task was to separate this bias from previously known biases in the distribution of the primes, such as the Chebyshev bias discussed in the blog post, or biases arising from the prime tuples conjecture (which, for instance, predicts that a prime gap of 6 is twice as likely to occur as a prime gap of 2). To realise that this particular bias is significantly stronger than what can be easily explained from these previously identified biases seems to require a certain amount of theoretical mathematical training.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467174")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2016")])]

#text("The paper by Lemke Oliver and Soundararajan starts with some striking facts like this: of the first hundred million primes, 25.000401% end in 7 in base ten. That’s very close to 1/4, which seems to make sense… but if one of these primes ends in 7, the probability that the next one ends in 7 is just 17.757%!")

#text("This is the sort of thing that an amateur with good computer skills could probably notice. I had thought this was a new observation. I’ll have to look at those other papers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467196")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2016")])]

#text("The first hundred million primes occupy about 12% of the numbers up to 2 billion that end in 1, 3, 7, or 9 (discarding the tiny primes 2 and 5). If they were distributed randomly amongst this set, the probability that a prime ")#mi("p")#text(" ending in 7 would be followed next by another prime ending in 7 would be about ")#mi("0.12 (1-0.12)^3 / (1 - (1-0.12)^4) \\approx 0.20")#text(", which is already significantly less than 25%, basically because the next numbers after ")#mi("p")#text(" that end in 9, 1, or 3 get to “go first” and have a chance of being prime before the next number ")#mi("p+10")#text(" ending in 7 needs to be tested. An amateur who observes the somewhat stronger 17% bias without doing something like the above quantitative calculation (or at least benchmarking the prime number statistics against a suitable random model) may end up ascribing the bulk of the bias to this effect (which, according to the Quanta article, is what Sound and Lemke Oliver did also, before working out the theoretical calculations more carefully).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467240")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2016")])]

#text("Aside – that formula looks tweakable to compute each player’s likelihood of winning a round robin “Bernoulli trial” contest involving n players of different skill levels.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/383f1f3c2fb9b60ef938d88b4d482ae5c556ffda4314d2e56ef5101f707092cf-66529046f683adee783f64d0aaa7a5e045a38df06f3c4bf30e889e49d3da4b51.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julie")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-475285")[#strong[#text("Julie")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2016")])]

#text("Your reasoning is not correct. It is a mistake to considerate the sequence 1, 3, 7, 9 … as an order to calculate the probability for the next prime.")#linebreak()#text(" You have to reject all multiples of 2, 3 and 5 before doing a theoretical calculation.")

#text("If you take 11, 41, 71… Next odd which will have a chance to be a prime will be 13, 43, 93")#linebreak()#text(" But if you take 31, 61, 91… the next odd which will have a real chance to be prime will be 37, 67, 97")#linebreak()#text(" So ais last digit is 1, the first number you have to considerate is 3 or 7.")

#text("Write numbers from 1 to 30 by excluding all miltiples of 2, 3 and 5. You’ll obtain this order for the last digit")

#text("1-7-1-3-7-9-3-9")

#text("So for each 7 (or any last digit) you have 2 possible ranks for the next 7.")#linebreak()#text(" First 7: 3rd and 8th")#linebreak()#text(" Second 7: 5th and 8th")

#text("Now i do the same quantitative calculation than you:")

#text("1 hundred million primes, 2 billion numbers, about 19% are prime")

#mi("a_3\\approx0.19(1-0.19)^2/(1-(1-0.19)^8)\\approx0.15")#linebreak()#text(" ")#mi("a_5\\approx0.19(1-0.19)^4/(1-(1-0.19)^8)\\approx0.10")#linebreak()#text(" ")#mi("a_8\\approx0.19(1-0.19)^7/(1-(1-0.19)^8)\\approx0.05")

#mi("(a_3+a_8+a_5+a_8)/2\\approx0.18")

#text("If we calculate each probality, we obtain:")

#text("(1, 1)≈ 18.9%")#linebreak()#text(" (1, 3)≈ 29.5%")#linebreak()#text(" (1, 7)≈ 30.5%")#linebreak()#text(" (1, 9)≈ 21.1%")

#text("(3, 1)≈ 24%")#linebreak()#text(" (3, 3)≈ 18.1%")#linebreak()#text(" (3, 7)≈ 27.4%")#linebreak()#text(" (3, 9)≈ 30.5%")

#text("(7, 1)≈ 25.2%")#linebreak()#text(" (7, 3)≈ 27.1%")#linebreak()#text(" (7, 7)≈ 18.1%")#linebreak()#text(" (7, 9)≈ 29.5%")

#text("(9, 1)≈ 31.9%")#linebreak()#text(" (9, 3)≈ 25.2%")#linebreak()#text(" (9, 7)≈ 24%")#linebreak()#text(" (9, 9)≈ 18.9%")

#text("Same approximate calculation in base 3 with the first million primes:")

#text("π(x; 3,(1, 1)) ≈ 219311")#linebreak()#text(" π(x; 3,(1, 2)) ≈ 280619")#linebreak()#text(" π(x; 3,(2, 1)) ≈ 280619")#linebreak()#text(" π(x; 3,(2, 2)) ≈ 219311")

#text("If we compare to numerical data, i think we can ascribe the bulk of the bias to this effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-480129")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("Well, this analysis is not correct either – one has to reject multiples of 7 also. Then 11, then 13… but then it does indeed seem that this sequence of not-quite-correct predictions does converge fairly rapidly to the numerical data. In fact, this is basically the analysis that Lemke Oliver and Soundararajan actually do (they rely on the Hardy-Littlewood prime tuple conjecture, which roughly speaking asserts that the above sequence of not-quite-correct analyses do converge rapidly to the true statistics).")

#text("As mentioned before, though, the real surprise is that the cumulative bias effect of taking into account the rejection of multiples of 7, 11, 13, etc. is a little bit larger (by a factor of ")#mi("\\log\\log x")#text(" or so) from the effect of taking into account just a bounded number of primes such as 2, 3, 5. This ")#mi("\\log\\log x")#text(" amplification of the bias is not really visible at numerically computable ranges such as ")#mi("x \\sim 10^9")#text(", but would eventually become significant for far larger values of ")#mi("x")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467083")[#strong[#text("Prime Numbers Conspiracy | Financial Cryptography, Bitcoin, Crypto Currencies, Cryptanalysis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2016")]

#text("[…] used in Quanta Magazine paper about this. We stress that this bias though very substantial is now apparently satisfactorily explained ny […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db136c30ee8c96a62c254ce0a9fccbef6ecb5a34982e598e8d49c9fcd9873d8-a13bb64911bd70f977e3a79693ed2712fad1a05904f5184a34a4ac8613257c80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Carmon")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467143")[#strong[#text("Dan Carmon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("In this analysis you relaxed the consecutive-prime condition to a close-prime condition. A bias is still exhibited, but how much is lost in the transition?")

#text("The loss is perhaps not immediately clear when considering distributions of two consecutive / close primes, as both methods predict that the main term in the bias for (a,b) would be determined by whether a and b are congruent modulo q, or not.")

#text("However, when considering distributions of triples, this does not seem to be the case (at least as far as I understand it). When discussing close primes, it seems you should not be able to distinguish their order, so the main term for the biases for triplets of residues modulo 3 being (1,2,1), (1,1,2) and (2,1,1) should all be the same. However, Lemke Oliver-Soundararajan’s paper predicts that these distributions for consecutive primes should have quite different main terms – specifically, the adjacent 1’s should repel more forcefully than the distant 1’s (which do contribute to the secondary ")#mi("\\frac{1}{\\log(x)}")#text(" term, but not to the main ")#mi("\\frac{\\log\\log(x)}{\\log(x)}")#text(" term.)")

#text("Do you have further thoughts on this? Am I wrong in the assertion that the close-primes analysis cannot distinguish between (1,2,1) and (2,1,1)?")

#text("Another way to phrase this question, perhaps simpler to model – the analysis of Lemke Oliver-Soundararajan predicts that the distribution of ")#mi("(p_n,p_{n+2})")#text(" modulo 3 should be biased against (1,1) and (2,2), but this bias should be significantly smaller than the bias of the distribution of ")#mi("(p_n,p_{n+1})")#text(", only exhibiting ")#mi("\\frac{1}{\\log(x)}")#text(" bias rather than the ")#mi("\\frac{\\log\\log(x)}{\\log(x)}")#text(" bias. Is this the behaviour predicted by a close-primes model for ")#mi("(p_n,p_{n+2})")#text(", or would that model again predict a bias with a large order of magnitude?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("I haven’t gone through the details of the Lemke Oliver-Soundararajan inclusion-exclusion analysis, but my guess is this: when looking at prime differences rather than prime gaps, one sees that most of the bias is coming from smallish size prime differences ")#mi("h")#text(" – where ")#mi("h")#text(" is much larger than 1, but much less than the average gap size ")#mi("\\log x")#text(" (as this is where the bulk of the ")#mi("\\log\\log x")#text(" factor coming from summing the harmonic series ")#mi("\\sum_{h \\lesssim \\log x} \\frac{1}{h}")#text(" will come from). Now, such smallish prime differences are quite unlikely to have a third prime between them (as a first approximation, the probability of such an intervening prime should be roughly ")#mi("h / \\log x")#text("). So the Lemke Oliver-Soundarajan effect should be significantly attenuated when trying to control the event that ")#mi("p_n")#text(" and ")#mi("p_{n+2}")#text(" have the same residue class, as it is quite unlikely that these two primes are so close together that the bulk of that effect applies. However, the event that (say) ")#mi("p_{n+1}")#text(" and ")#mi("p_{n+2}")#text(" have the same residue class is not subject to this repulsion effect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db136c30ee8c96a62c254ce0a9fccbef6ecb5a34982e598e8d49c9fcd9873d8-a13bb64911bd70f977e3a79693ed2712fad1a05904f5184a34a4ac8613257c80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Carmon")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467208")[#strong[#text("Dan Carmon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2016")])]

#text("Thank you for the great answer! My understanding is that the main contribution to the bias for prime differences therefore actually arises solely (up to lower order terms) from differences that are actually prime gaps: Differences which are not much smaller than ")#mi("\\log x")#text(", as well as differences which are much smaller than ")#mi("\\log x")#text(" but are not prime gaps, both contribute only to the ")#mi("\\frac{1}{\\log x}")#text(" term, at the most. For the first family the contribution is small due to the size of the differences, while for the second family the contribution is small due to the rarity of such differences.")

#text("It seems plausible to me that smallish prime differences which are not primes gaps are responsible for the part of ")#mi("c_2(q;\\bold{a})")#text(" in Lemke Oliver-Soundararajan’s conjecture which resembles the main ")#mi("c_1(q;\\bold{a})")#text(" part, namely ")#mi("\\frac{\\phi(q)}{2}\\sum_{j=1}^{r-2} \\frac{1}{j}\\left(\\frac{r-1-j}{\\phi(q)} - \\#\\{i : a_i \\equiv a_{i+j+1} \\pmod q\\}\\right)")#text(". Does this seem reasonable?")

#text("Have you explored the Lemke Oliver-Soundararajan paper further since? Specifically, are you able to determine that the bias that arises in their computations is similarly dominated by the contribution of smallish primes gaps?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/667cdd1fbd1aaea98ebd2d9d176306e4a0cc8ab7b9631c5fbc3be65395560e4c-2d9f18c8e6e3c38fb9f18cbac9889882027826673378db4559d2c096022d52f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A. Mehta")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467145")[#strong[#text("A. Mehta")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("Thanks for the interesting and insightful analysis as always, Terence.")

#text("One question: a previous poster mentioned the 1974 paper by RP Brent that predicts gap sizes between consecutive primes — which, although not cited by the authors, employs Hardy-Littlewood and seems highly relevant either way. Should we expect a different magnitude of bias to be produced by that model?")

#text("The reason I ask is because the predicted distribution in that paper (shown in Table 2 for small AND large gap sizes) appears to exhibit a FAR greater systematic bias than what you suggest. To be specific: you say that we should expect gap multiples of 6 roughly twice as often as those that aren’t (in the absence of the Lemke Oliver-Soundararajan bias) … but the model in that 1974 paper tells a very different story, predicting a substantially stronger bias _against_ 6k sizes across ALL gap magnitudes, and for fairly large primes (not just the first million as the new authors use to demonstrate the bias in base 3). Given the incredible structure of these known harmonics, I was surprised to read the quotes from Granville and Ono in the Quanta article.")

#text("The new O(log log x / log x) term is fantastic, and I think the focused study on small modulo is warranted. But, I tend to agree with previous posters that the asymptotic behavior of consecutive primes was much better understood in the 20th century than most folks seem to realize. Personally, I have a hunch this bias has indeed been observed by many in the past, but was likely understood intuitively as a natural consequence of previously published phenomena.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467148")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("To be more precise: the prime tuples conjecture would (naively) predict, that all other things being equal, multiples of 3 would be twice as likely to be a ")#emph[#text("prime difference")]#text(" than a non-multiple of 3 (though, as discussed in the post, there is a slight correction to this as pointed out by Lemke Oliver and Soundararajan). The situation with prime ")#emph[#text("gaps")]#text(" is slightly different, because there is a bias against long gaps (more chance of having an intervening prime between the gap) that is not present in the case of differences, which is for instance why the entry for r=3 (corresponding to gaps of length 6) in Table 2 is significantly less than twice the entry for r=1 (corresponding to gaps of length 2). The inclusion-exclusion terms here give contributions of relative size ")#mi("O(1/\\log x)")#text(", which are sizeable in the ranges considered in the Brent paper (in which ")#mi("10^6 \\leq x \\leq 10^9")#text("). But the main term in the absence of inclusion exclusion (in the notation of the paper, the k=1 term) still exhibits the behaviour I mentioned (for instance note that the r=3, k=1 term of Table 1 is exactly twice that of r=1, k=1).")

#text("It is true though that the numerical evidence in ranges such as ")#mi("x \\sim 10^6")#text(" or ")#mi("x \\sim 10^9")#text(" is not really dominated by the main term ")#mi("\\log\\log x / \\log x")#text(" of the Lemke Oliver-Soundararajan bias, but is instead probably being driven more by the ")#mi("O(1/\\log x)")#text(" contributions. So it is perhaps somewhat serendipitous that the numerical evidence at this range still pointed in the direction of a bias, which caused the authors to investigate the situation theoretically and discern an asymptotic bias that was even stronger than what the numerical data suggested. (This is in contrast with some examples I listed in a previous comment (Mertens conjecture, second Hardy-Littlewood conjecture, and the story of Skewes’ number) in which the asymptotic ")#mi("\\log\\log x")#text("-type behaviour ran contrary to the small-scale numerical evidence).) It seems that numerical data can suggest a rough first approximation to the asymptotic truth, but one needs theory to get a more accurate picture once one is motivated by the initial numerics to study the situation more carefully (particularly when the strength of the effects involved are only logarithmic or double logarithmic in size).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/667cdd1fbd1aaea98ebd2d9d176306e4a0cc8ab7b9631c5fbc3be65395560e4c-2d9f18c8e6e3c38fb9f18cbac9889882027826673378db4559d2c096022d52f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A. Mehta")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467155")[#strong[#text("A. Mehta")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("Many thanks – this question has been bugging me for a week, and your explanation here makes things immensely more clear.")

#text("I should pay to have access to this kind of expert analysis!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("As described in page 4 of the paper, the remainder term in conjecture 1.1 ")#mi("O((\\log x) ^{-7/4})")#text(" is expected to be given as a sum involving zeros of L-functions. Does it means that this remainder term is oscilatory, or perhaps it still has an inherent bias of the same size?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467152")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2016")])]

#text("From the same page of that paper, it seems that the authors do indeed expect such terms to be oscillatory, but that there are additional non-oscillatory terms (i.e. a further bias) of size about ")#mi("(\\log\\log x/\\log x)^2")#text(", and they hope to investigate this further in future work. So it seems there is going to be even more to this story than we know so far…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2016")])]

#text("In conjecture (1.1) it is clear that")#linebreak()#text(" ")#mi("c_1(q;a) \\leq (r-1)/2")#linebreak()#text(" with equality if and only if ")#mi("a_1, ... , a_r")#text(" are distinct ")#mi("(mod q)")#text(".")#linebreak()#text(" Therefore ")#mi("\\max_{a} c_1(q;a) = (q-1)/2")#text(" is attained for ")#mi("r=q")#text(".")#linebreak()#text(" Showing the coefficient ")#mi("c_1(q;a)")#text(" to be unbounded!")

#text("This motivates the question: is it possible to extend conjecture 1.1 to the case where ")#mi("q=q(x)")#text(" is an unbounded (sufficiently slowly) growing function of ")#mi("x")#text("? (allowing the bias to grow faster(!) then ")#mi("\\log \\log x / \\log x")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2016")])]

#text("Similarly, ")#mi("c_1(q;a) \\geq (r-1)(1-\\phi (q))/2")#linebreak()#text(" with equality iff ")#mi("a_1 = ... = a_r")#text(" (mod ")#mi("q")#text(").")#linebreak()#text(" Hence ")#mi("\\min_a c_1(q;a) = -(q-1)(\\phi(q) -1)/2")#linebreak()#text(" is attained for ")#mi("r=q")#text(" and is also unbounded!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467233")[#strong[#text("Biases between consecutive primes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/")[#text("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca7196e2edb547e0d1a2d8994ca54e1897c15588660505da9aa2d99d9e625cab-3a7cbc79ae399c591653b59991297b6b45961c59174b40958f9eb06a64d7413c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jiangose")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467254")[#strong[#text("jiangose")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2016")])]

#text("Reblogged this on ")#link("https://jiangose.wordpress.com/2016/03/26/biases-between-consecutive-primes-2/")[#text("jiangose")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467255")[#strong[#text("Bias In The Primes | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2016")]

#text("[…] by Scientific American, by Nature, by the New Scientist, and by Quanta Magazine. Terry Tao also posted about it, and he explicates the gist in a wonderful […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467261")[#strong[#text("My fun interaction with prime numbers this week | Mike's Math Page")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2016")]

#text("[…] Terry Tao’s blog post about the new result […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467399")[#strong[#text("Links for March 2016 - foreXiv")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2016")]

#text("[…] the prime k-tuples conjecture, for which twin primes (cf. Yitang Zhang) are a special case. See Terrance Tao for detailed commentary. (H/t Peter […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467446")[#strong[#text("number theory news/ highlights: prime bias, Diffie-Hellman, Zhang-Tao, Wiles, Riemann | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2016")]

#text("[…] 5. Biases between consecutive primes | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-467512")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2016")])]

#text(":!: :idea: :cool: :D <3 :star: these are groundbreaking and even near breakthrough results, and as not widely noted, empirical/ experimental approaches played a key role. think that much more may be possible from those who adopt a flexible attitude. recent new compilation, more on")

#link("https://vzn1.wordpress.com/2015/12/29/select-refs-and-big-tribute-to-empirical-cs-math/")[#text("empirical/ experimental CS/ math highlights")]

#text("as a start on possible new empirical/ experimental attacks on the primes, what would a proof of the infinity of primes look like? some ideas on that in this post, hope to hear from others on it also")

#link("https://vzn1.wordpress.com/2016/04/01/number-theory-news-highlights-prime-bias-diffie-hellman-zhang-tao-wiles-riemann/")[#text("number theory news/ highlights: prime bias, Diffie-Hellman, Zhang-Tao, Wiles, Riemann")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76a4d267a703dd6243c8c52fa15f7e22e1decb84c1eb1b63546cf2d457cad48f-2203dfda60afbd57b5a9ba4d29c8b59ddb5201648b9430d1c77331d6bf6ba84b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BOUGRINE Lahoucine")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-469084")[#strong[#text("BOUGRINE Lahoucine")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2016")])]

#text("Bonjour, Hello!")#linebreak()#text(" My question is : why mathematical scientists underestimate amateur researchers? Am asking such a question bescause it’s been more then two months that I am trying to publish a new method to find easily all primes but no one helped me. I have contacted mathematical scientists, scientific journals, and even some of my former teachers, no one believes me. I haven’t received answer yet. Could you please help me on that? Thank you in advance M.TAO")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70bbf482cafc23648e554e330f48a3c1e9a5545a146b50bff112d807103ff7ea-3c3ce8cebb9731c430f7227df7ba13aef560cf960dab53477c022a62613894c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of myzinsky")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-476145")[#strong[#text("myzinsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2017")])]

#text("explain it to me i’m listening :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-477581")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("we can consider the set of the 3 successive integers e1, e2, e3 as a reversible structure.")#linebreak()#text(" The metric is always of 1 but starting from both sides e1 and e3 (reversible), we do not have to manipulate time so it is ok.")#linebreak()#text(" So, starting from e1 and e3, we have a metric of 1. Thus, e2 will have the number 2 because metric starts from 0. But I think the number don’t exist, I would prefer to say that e2 has now a metric of 2 regarding e3-e1.")#linebreak()#text(" By multiplicating, we have an infinity of even number e2 (we generate all the even numbers according to the decimal system : 0,2,4,6,8).")#linebreak()#text(" There is a separation (extension) of 1 between e1 and e2 and between e2 and e3 (substraction and addition) : e1 and e3 will be uneven number like 1,3,5,7,9 (decimal system).")#linebreak()#text(" Euclide demonstrate the infinity of prime numbers.")#linebreak()#text(" Demonstration of twin prime numbers? No idea at all.")#linebreak()#text(" But maybe we have to take into account that we don’t generate new numbers but that we extend space metric in a discrete way. So it is a linear bubble that growth,and only 1 and the number itself respect the discrete metrics.")

#text("In informatics : a programming language can be low level or high level : I have really the impression of being very very low level : it is frustrating.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-477582")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("Actually, I realize I conflate distance and numbers. In my head, i get mixed up. Sorry.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b5ad9e4a535bc6f42379278c9eb0cf092793b36e59322e1b9485fc1885cb44f-621b2fdc16402c9bf26c47fca8e62ec5635bc421cc3659068f2bfb6f5dce1637.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teoria Universal (@TeoriaUniversal)")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-489080")[#strong[#text("Teoria Universal (@TeoriaUniversal)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2017")])]

#text("I regret to tell you that they are all wrong, the prime numbers have astonishing almost military distribution and")

#text("I regret to inform you that I already have the equation that everyone is looking for.")

#text("As you can imagine, I can say that: In the first 40,000 Natural Numbers there are 5,556 Prime Numbers, of which if the ordemanos in which digit ends, we can see the following.")

#text("Finished at 1 => 1.137")#linebreak()#text(" Finished at 3 => 1,147")#linebreak()#text(" Finished at 7 => 1.135")#linebreak()#text(" Finished at 9 => 1.135")#linebreak()#text(" plus 2 and 5 => 2")#linebreak()#text(" + ————————")#linebreak()#text(" 4.556.- NP in The first 40,000 Natural Numbers.")

#text("The Prime Numbers do not attract or repel each other, it only depends on the section analyzed and the average frequency in which the next one will appear.")#linebreak()#text(" As the principle is known, the frequency is smaller and for much larger numbers they move away.")

#text("THE solution is where nobody is looking for it.")

#text("“The trees do not let see the forest.”")

#text("I have an equation that I have called f (mx) that shows all NPs and applies to several behaviors.")

#text("If you dedicate yourself to finding answers, “There is always the possibility that you will find a result that will shake the world”.")

#text("There are the bases to develop a whole theory that will change many concepts, I share the idea that behind the NP are hidden many answers that govern the Universe.")

#text("Alvaro Unda")#linebreak()#text(" Cod.Post 1780000")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dea4d164a18f5fd7b8573181090f208335a7eebe1f2e76aa579c45ec4dfb9cee-aab91af758fcad6c8b83072bdeb5dc0c077e0b67d96368a332ec4e213cdf6aa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignacio Villanueva")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-498009")[#strong[#text("Ignacio Villanueva")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("dear prof. Tao,")#linebreak()#text(" I have a question related to the Chebyshev bias: is there something known about how likely is it for number (not necessarily prime) p to be a quadratic residue mod q, with q prime? I am interested in the asymptotic behaviour as q grows to infinity.")

#text("best,")

#text("Ignacio")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-498053")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("The quadratic residues mod q are a set of ")#mi("\\frac{q-1}{2}")#text(" residues mod q, so the density of this set is ")#mi("\\frac{q-1}{2q}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9c277cc5a50f2883909f48d0e5315fa73aeccaf2cc8b441b9e8dcfb8a6e9e1-52650114c687216a5947fa2aa40782b4f80d40012c7b55d380e0611a2f3ce414.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of emini_guy")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-502281")[#strong[#text("emini_guy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2018")])]

#text("Another bias in the distribution of primes, that could have been discovered decades ago, was revealed recently: ")#link("https://arxiv.org/abs/1807.00406")[#text("https://arxiv.org/abs/1807.00406")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-502285")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2018")])]

#text("Perhaps this bias can also be explained by a relatively simple probabilistic argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-502344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2018")])]

#text("This seems likely. The prime tuples conjecture (generalised to linear forms) predicts, among other things, that the likelihood of ")#mi("n-1,n+1")#text(" simultaneously being prime increases when ")#mi("n")#text(" is divisible by small primes, and squarefree numbers are slightly less likely to be divisible by small primes than non-squarefree numbers.")

#text("For instance, a general ")#mi("n")#text(" has a 40% chance of having one of ")#mi("n-1,n+1")#text(" divisible by 5, whereas a multiple of 5 has no such possibility; thus, all other things being equal, one would expect a multiple of 5 to have a ")#mi("\\frac{1}{1-0.4} = 1.66\\dots")#text(" higher chance of being the midpoint of a twin prime pair than a random number (conversely, a non-multiple of 5 would be expected to have ")#mi("\\frac{0.5}{1-0.4} = 0.833\\dots")#text(" times the chance). Meanwhile, a typical number has a 1/5 chance of being divisible by 5, whereas a squarefree number has only a 4/24 chance of being divisible by 5 since the ")#mi("0 \\text{ mod } 25")#text(" residue class is excluded. This effect alone would reduce the probability of a squarefree number being the midpoint of a prime pair by ")#mi("(1/5 - 4/24) * (\\frac{1}{1-0.4} - \\frac{0.5}{1-0.4}) = 1/36")#text(" compared to that of a typical number, and this may already explain the bulk of the effect observed in this preprint.")

#text("More generally, one can compare these sorts of numerically observed phenomena in the primes against the ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("modified Cramer model")]#text(". Here, what we are doing (combined with the restriction to multiples of 6 that is already in the preprint) is basically replacing “prime” by “integer not divisible by 2, 3, or 5” (the Cramer model requires us to actually take a random subset of this set, but for the purposes of computing ratios, the effect of further random sampling basically cancels itself out). It might be instructive to run the same numerical experiments in the preprint with such modified notions of prime (and attendant notions of twin prime, etc.) and see if one gets essentially the same statistics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-502356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2018")])]

#text("small typo: “0.86…” above should be “0.83…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-502393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2018")])]

#text("Thanks for the occasional elementary example:-) I see from your argument that the 1/36 probability reduction applies to numbers which aren’t squares of 5, but how do you know that it also applies to the subset of those numbers which are totally squarefree?")

#text("On 2nd thought there seem to be several independence assumptions in this argument, one of which (“all other things equal…”) is explicit. How do you know that they’re justified?")

#text("Typo: 0.86… -> 0.83…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-502444")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2018")])]

#text("A number is squarefree if and only if it is simultaneously not divisible by ")#mi("3^2")#text(", by ")#mi("5^2")#text(", by ")#mi("7^2")#text(", etc.. Any fixed number of these conditions will be asymptotically independent, thanks to the Chinese remainder theorem. (More generally, it is a quite reliable heuristic that local conditions at different primes should behave independently of each other; cf. Section 3 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")]#text(" .) To deal with all of the congruence conditions at once requires some sieve theory (and perhaps also some quantitative control on the error term in the prime tuples conjecture), however one would expect that this would be relatively straightforward since ")#mi("\\sum_p \\frac{1}{p^2} < \\infty")#text(" and so this is almost a finite sieve (the effect of small primes dominate that of large primes).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2074f177e0fe0b4b28b74b4517d4152bc960959bf1b804352acda86b2be4fd63-7a2401b4796f9848d0569bb41b0f32e90911a8a456a8d7fa2111368d7d58bc6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ES")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-623246")[#strong[#text("ES")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2021")])]

#text("I was wondering what happens with the bias if one considers things like $\\sum_{n\\leq H} f_3(n) f_3(n+1)$. Do you think the bias will persist? In this case it would give $c_1^2 H-2 c_1 c_2 \\log H+O(1)$ but the secondary term could turn out to be of order $\\log^2 H$ instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/deb5d452e6f269420f4fe89118a4e4866a84d6557242a08225ceff2ba1811011-6926b997129d2d06d9c6b623c3d69b498be4d2fa9034845cae68ccf819012a36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florian Neubauer")]], [#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-658215")[#strong[#text("Florian Neubauer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2022")])]

#text("If we use the Sieve of Eratosthenes and stop sieving after 3, all of the remaining consecutive prime candidates fall in alternating residue classes (mod 3). If we stop sieving after 5, there are still 3 consecutive prime candidates falling in alternating classes for 2 successors that fall in the same class as their precursors. Can’t we simply use the argument that multiples of 5 have the highest frequency of all multiples of primes >3, and hence the multiples of primes larger 5 will never be able to remove this bias towards alternating residue classes entirely?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/03/14/biases-between-consecutive-primes/#comment-680932")[#strong[#text("https://www.researchgate.net/publication/232697474_Highly_biased_prime_number_ra - Homework Plug")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2023")]

#text("[…] Biases between consecutive primes […]")
]
