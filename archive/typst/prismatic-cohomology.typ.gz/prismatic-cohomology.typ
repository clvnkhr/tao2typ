// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/
// Converted to Typst by tao2typ: "2026-10-14T15:20:15.121920+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Prismatic cohomology", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Prismatic cohomology")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 March 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/")[#text("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Last week, we had Peter Scholze give an interesting ")#link("https://www.math.ucla.edu/dls/peter-scholze")[#text("distinguished lecture series here at UCLA on “Prismatic Cohomology”")]#text(", which is a new type of cohomology theory worked out by Scholze and Bhargav Bhatt. (Video of the talks will be available shortly; for now we have some notes ")#link("https://ucla.box.com/s/ia3aoxnzvj0e0cmq6gkadu7h0w1jt8cl")[#text("taken")]#text(" by ")#link("https://ucla.box.com/s/hzlmjdvdzlr4duuhlcneaiazvrw3avvg")[#text("two")]#text(" ")#link("https://ucla.box.com/s/9aee7nciobbez3uow7ofydy9oput02xa")[#text("note")]#text("–")#link("https://ucla.box.com/s/06457t612lqfgif46z0c5djdupft0yrc")[#text("takers ")]#text("in the audience on that web page.) My understanding of this (speaking as someone that is rather far removed from this area) is that it is progress towards the “")#link("https://en.wikipedia.org/wiki/Motivic_cohomology")[#text("motivic")]#text("” dream of being able to define cohomology ")#mi("{H^i(X/\\overline{A}, A)}")#text(" for varieties ")#mi("{X}")#text(" (or similar objects) defined over arbitrary commutative rings ")#mi("{\\overline{A}}")#text(", and with coefficients in another arbitrary commutative ring ")#mi("{A}")#text(". Currently, we have various flavours of cohomology that only work for certain types of domain rings ")#mi("{\\overline{A}}")#text(" and coefficient rings ")#mi("{A}")#text(":")

#list(
[#link("https://en.wikipedia.org/wiki/Cohomology#Singular_cohomology")[#text("Singular cohomology")]#text(", which roughly speaking works when the domain ring ")#mi("{\\overline{A}}")#text(" is a characteristic zero field such as ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(", but can allow for arbitrary coefficients ")#mi("{A}")#text(";")],
[#link("https://en.wikipedia.org/wiki/De_Rham_cohomology")[#text("de Rham cohomology")]#text(", which roughly speaking works as long as the coefficient ring ")#mi("{A}")#text(" is the same as the domain ring ")#mi("{\\overline{A}}")#text(" (or a homomorphic image thereof), as one can only talk about ")#mi("{A}")#text("-valued differential forms if the underlying space is also defined over ")#mi("{A}")#text(";")],
[#link("https://en.wikipedia.org/wiki/%C3%89tale_cohomology")[#mi("{\\ell}")#text("-adic cohomology")]#text(", which is a remarkably powerful application of étale cohomology, but only works well when the coefficient ring ")#mi("{A = {\\bf Z}_\\ell}")#text(" is localised around a prime ")#mi("{\\ell}")#text(" that is different from the characteristic ")#mi("{p}")#text(" of the domain ring ")#mi("{\\overline{A}}")#text("; and")],
[#link("https://en.wikipedia.org/wiki/Crystalline_cohomology")[#text("Crystalline cohomology")]#text(", in which the domain ring is a field ")#mi("{k}")#text(" of some finite characteristic ")#mi("{p}")#text(", but the coefficient ring ")#mi("{A}")#text(" can be a slight deformation of ")#mi("{k}")#text(", such as the ring of ")#link("https://en.wikipedia.org/wiki/Witt_vector")[#text("Witt vectors")]#text(" of ")#mi("{k}")#text(".")]
)

#text("There are various relationships between the cohomology theories, for instance de Rham cohomology coincides with singular cohomology for smooth varieties in the limiting case ")#mi("{A=\\overline{A} = {\\bf R}}")#text(". The following picture Scholze drew in his first lecture captures these sorts of relationships nicely:")

#image("../assets/4f63bc96a46369a3b31e4059adf6f60c562fd2a5bd1e50b99a8816b3d5fb8000-737d39bbb399ec653135076a8b6d7f520e05e59148b1752d5d4c67683a786763.jpg", width: 90%, alt: "20190312_145136")

#text("The new prismatic cohomology of Bhatt and Scholze unifies many of these cohomologies in the “neighbourhood” of the point ")#mi("{(p,p)}")#text(" in the above diagram, in which the domain ring ")#mi("{\\overline{A}}")#text(" and the coefficient ring ")#mi("{A}")#text(" are both thought of as being “close to characteristic ")#mi("{p}")#text("” in some sense, so that the dilates ")#mi("{pA, pA^{\\prime}}")#text(" of these rings is either zero, or “small”. For instance, the ")#mi("{p}")#text("-adic ring ")#mi("{{\\bf Z}_p}")#text(" is technically of characteristic ")#mi("{0}")#text(", but ")#mi("{p {\\bf Z}_p}")#text(" is a “small” ideal of ")#mi("{{\\bf Z}_p}")#text(" (it consists of those elements of ")#mi("{{\\bf Z}_p}")#text(" of ")#mi("{p}")#text("-adic valuation at most ")#mi("{1/p}")#text("), so one can think of ")#mi("{{\\bf Z}_p}")#text(" as being “close to characteristic ")#mi("{p}")#text("” in some sense. Scholze drew a “zoomed in” version of the previous diagram to informally describe the types of rings ")#mi("{A,A^{\\prime}}")#text(" for which prismatic cohomology is effective:")

#image("../assets/df171fa616d4e0bd71dab5dd08b07185c0bdf6cdd4f9fabaaf7f4c22ddcb4a2d-fe0826c0fe7d55014c3aad396bfd0ceff2d7172d9e918ae3d93215b93ee693b5.jpg", width: 90%, alt: "20190312_145157")

#text("To define prismatic cohomology rings ")#mi("{H^i_\\Delta(X/\\overline{A}, A)}")#text(" one needs a “prism”: a ring homomorphism from ")#mi("{A}")#text(" to ")#mi("{\\overline{A}}")#text(" equipped with a “Frobenius-like” endomorphism ")#mi("{\\phi: A \\to A}")#text(" on ")#mi("{A}")#text(" obeying some axioms. By tuning these homomorphisms one can recover existing cohomology theories like crystalline or de Rham cohomology as special cases of prismatic cohomology. These specialisations are analogous to how a prism splits white light into various individual colours, giving rise to the terminology “prismatic”, and depicted by this further diagram of Scholze:")

#image("../assets/9f6f87b715973f16ae2fe381fa811af8f8d1019de57c8527bd9f7441a7f95b95-863eb0e1634f6846390faed2ba3c957c42c3b323db451974ff2bc2cebff4b8ba.jpg", width: 90%, alt: "20190313_152011")

#text("(And yes, Peter confirmed that he and Bhargav were inspired by the ")#link("https://en.wikipedia.org/wiki/The_Dark_Side_of_the_Moon")[#text("Dark Side of the Moon")]#text(" album cover in selecting the terminology.)")

#text("There was an abstract definition of prismatic cohomology (as being the essentially unique cohomology arising from prisms that obeyed certain natural axioms), but there was also a more concrete way to view them in terms of coordinates, as a “")#link("https://en.wikipedia.org/wiki/Q-analog")[#mi("{q}")#text("-deformation")]#text("” of de Rham cohomology. Whereas in de Rham cohomology one worked with derivative operators ")#mi("{d}")#text(" that for instance applied to monomials ")#mi("{t^n}")#text(" by the usual formula")

#align(center)[#tao-fit-display[#mitex("d(t^n) = n t^{n-1} dt,")]]

#text("prismatic cohomology in coordinates can be computed using a “")#mi("{q}")#text("-derivative” operator ")#mi("{d_q}")#text(" that for instance applies to monomials ")#mi("{t^n}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("d_q (t^n) = [n]_q t^{n-1} d_q t")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("[n]_q = \\frac{q^n-1}{q-1} = 1 + q + \\dots + q^{n-1}")]]

#text("is the “")#mi("{q}")#text("-analogue” of ")#mi("{n}")#text(" (a polynomial in ")#mi("{q}")#text(" that equals ")#mi("{n}")#text(" in the limit ")#mi("{q=1}")#text("). (The ")#mi("{q}")#text("-analogues become more complicated for more general forms than these.) In this more concrete setting, the fact that prismatic cohomology is independent of the choice of coordinates apparently becomes quite a non-trivial theorem.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cb494461e4227fc760398a7b4f79d876e3d5159331759c9de724d7026bc1a64-f16b27a8814218c3040363c4e9cad3c0155e128c287aa4b5b3d4df51fd50a291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Grieser")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-513984")[#strong[#text("Daniel Grieser")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Thanks, nice post, just one thing: the name is Scholze, not Schölze (no Umlaut here).")

#text("Best, Daniel")

#text(">")

#emph[#text("[Corrected, thanks. No idea why I thought there was an umlaut, especially given that I know how to pronounce his name… -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45d69324d072dcff896a920de165e26211011f7338950ea3e7d4c69bbbc8c61b-5483f653b0272fb6aa2cd5c483b781c5a292976085916899acd79545dfbc9581.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-513988")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Still a couple of extra umlauts, just above the second and third images.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-513989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Nice post! Two things that didn’t read right:")

#text("“and with coefficients in another arbitrary commutative rings”")

#text("“which a remarkably powerful application of étale cohomology”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-513998")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Some minor quibbles:")

#text("The ")#mi("\\ell")#text("-adic cohomology has (unsurprisingly) coefficients in the ")#mi("\\ell")#text("-adic numbers ")#mi("\\mathbb Z_\\ell")#text(", which are not really of characteristic ")#mi("\\ell")#text(". Instead, as you note later, it is a slight deformation of ")#mi("\\mathbb F_\\ell")#text(", and it is “close to characteristic ")#mi("\\ell")#text("“. This seems worth mentioning – I would say “works well when ")#mi("A")#text(" is the ")#mi("\\ell")#text("-adic numbers for ")#mi("\\ell")#text(" different form the characteristic of ")#mi("\\overline{A}")#text("“.")

#text("All these cohomology theories, if they work over a ring ")#mi("A")#text(", also work over any ring ")#mi("B")#text(" that admits a map from ")#mi("A")#text(", because we can tensor over ")#mi("A")#text(" with ")#mi("B")#text(". So de Rham cohomology works over any ring which admits a map from ")#mi("\\overline{A}")#text(", etc. I am not sure whether this is worth mentioning.")

#text("The formula for the ")#mi("q")#text("-derivative of ")#mi("t^n")#text(" should have ")#mi("t^{n-1}")#text(", not ")#mi("t^{n-q}")#text(".")

#text("And this one is just for fun:")

#text("Peter Woit pointed out in Bhargav Bhatt’s Eilenberg’s lectures on prismatic cohomology that this diagram of a prism does not accurately reflect the behavior of light in a prism (Some of the light is deflected in the wrong direction as it enters the prism).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55d63f3ea2bcaacf7c49be5f7ed92ccc477a0992d5327e8dfd54e0ca9b88dcb3-7783d4d5aaaf0877dc4eb4a574f28c1c95b211341624036d7ef2e8527f72aa57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Woit")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514020")[#strong[#text("Peter Woit")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2019")])]

#text("Will,")#linebreak()#text(" I don’t remember that, I strongly suspect you’re giving me undeserved credit for someone else’s astute observation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514047")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2019")])]

#text("You’re probably right as I am pretty bad at names, faces, and generally distinguishing one human being from another. I apologize for giving you more credit than you deserve.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6391faad04b399e5bf004402d4be95f4078cb9850cc8981370428be3ae9adf2-b45a6e9faf5075e5636f940fcfd52b92ca5d8c7d900951de260a6865bc6171b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marni Dee Sheppeard")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514036")[#strong[#text("Marni Dee Sheppeard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2019")])]

#text("I would really be very interested to know where they got these ideas from. I have been working on ‘motivic quantum gravity’ for many years, as a category theorist physicist. Last year I spent some months in Los Angeles working with Michael Rios and other people associated to UCLA. (But as a target of abuse, I am now homeless again.) Michael and I were/are both very well aware that the axioms for cohomology underpin quantum gravity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2019")])]

#text("As far as I can tell, the original paper is that of Bhatt, Scholze, and Morrow in ")#link("https://arxiv.org/abs/1602.03148")[#text("https://arxiv.org/abs/1602.03148")]#text(" . At that stage they did not have a good name for their cohomology theory and called it something like a “q-deformation of de Rham cohomology”. But they conjectured that there was a ")#link("https://en.wikipedia.org/wiki/Grothendieck_topology")[#text("site")]#text("-theoretic foundation of this cohomology theory (see Remark 1.11 and footnote 10 of that paper), and when Bhatt and Scholze found that site, it resembled the shape of a prism geometrically, leading to their dubbing of it the “prismatic site”, and the renaming of their theory as “prismatic cohomology”. As mentioned in the post, this nomenclature was also influenced by the famous Pink Floyd album cover.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6391faad04b399e5bf004402d4be95f4078cb9850cc8981370428be3ae9adf2-b45a6e9faf5075e5636f940fcfd52b92ca5d8c7d900951de260a6865bc6171b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marni Dee Sheppeard")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514072")[#strong[#text("Marni Dee Sheppeard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2019")])]

#text("Thank you. What I am actually wondering about is the unit axioms in higher dimensional categories (notably tricategories a la Gordon, Power, Street). If we can make sense of the associahedra (in the physical axioms) then the next task is to understand the prisms and other topes that show up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20791c979dd38d1d9e56a114259a0451e2a85ab73ae6826baa8cac3a31f7f341-f8d8a0e405496e47b1bc849f1b27e72d61f7b7b8d4dfef591d1efdd94d4359ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2019")])]

#text("Marni: There is no actual mathematical connection between Bhatt-Scholze’s work and whatever “motivic quantum gravity” is. You’re latching onto accidental similarities between terminology and using them to insinuate something nefarious. In my experience, Peter Scholze has always been remarkably generous with his ideas and is always careful to give ample credit to other people.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6391faad04b399e5bf004402d4be95f4078cb9850cc8981370428be3ae9adf2-b45a6e9faf5075e5636f940fcfd52b92ca5d8c7d900951de260a6865bc6171b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marni Dee Sheppeard")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514120")[#strong[#text("Marni Dee Sheppeard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2019")])]

#text("Anonymous coward, no. I am not stupidly latching onto anything. Motivic quantum gravity has q deformations at its heart, starting with fusion categories for quantum computation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20791c979dd38d1d9e56a114259a0451e2a85ab73ae6826baa8cac3a31f7f341-f8d8a0e405496e47b1bc849f1b27e72d61f7b7b8d4dfef591d1efdd94d4359ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous (but not a coward)")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514122")[#strong[#text("Anonymous (but not a coward)")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2019")])]

#text("Marni: Scholze’s work has nothing to do quantum gravity or quantum computation or fusion categories (or other such related things), but rather with subtle arithmetic and topological properties of schemes. And I didn’t use the word “stupid” when describing you. Please don’t put words in my mouth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6391faad04b399e5bf004402d4be95f4078cb9850cc8981370428be3ae9adf2-b45a6e9faf5075e5636f940fcfd52b92ca5d8c7d900951de260a6865bc6171b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marni Dee Sheppeard")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514127")[#strong[#text("Marni Dee Sheppeard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2019")])]

#text("I never said Scholze had a history of working on quantum gravity, because he clearly does not. However, many people who work on motivic math phys (eg. Brown, me) are quite convinced that it has a lot to do with quantum field theory, and probably also quantum gravity. My comments might well draw Scholze’s attention to a wide literature with which he was not previously familiar, in which case they are worthwhile. (And insulting people without proving any expertise of your own is a cowardly act – every time).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6391faad04b399e5bf004402d4be95f4078cb9850cc8981370428be3ae9adf2-b45a6e9faf5075e5636f940fcfd52b92ca5d8c7d900951de260a6865bc6171b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marni Dee Sheppeard")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514038")[#strong[#text("Marni Dee Sheppeard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2019")])]

#text("Moreover, Michael is well known at UCLA for wearing Pink Floyd T-shirts while talking about (our) theory of quantum gravity. He also used the prism on arxiv papers last year.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514210")[#strong[#text("Some Quick Items | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2019")]

#text("[…] Peter Scholze’s lecture series at UCLA on Prismatic Cohomology, discussed by Terry Tao here. In related news, this week at MSRI there’s an interesting workshop on Derived Algebraic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514344")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2019")])]

#text("Hang on, “dark side of the moon”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514528")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2019")])]

#text("Also, given that the moon is a sphere, it seems to be a bit of a stretch to talk about a “side” in this context.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514531")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2019")])]

#text("The word “moon” appears also in the mathematical “moonshine theory” connecting between groups, modular forms and string theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b20a688689e989dbcae9dd8474326389b34861e013a8e33cb60032bc45b30af-9250c6095df32786190754ccf9a9e406e4e95fb86e8ab8f7ad19c3328dc8be70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ricardo Menares Valencia")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-514614")[#strong[#text("Ricardo Menares Valencia")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2019")])]

#text("Tank you very much for this post!")

#text("A minor comment: pZ_p is not a subring of Z_p, because pZ_p is not a ring (it has no unit). Rather, it is a maximal ideal such that the quotient Z_p/pZ_p is a field of characteristic p. In this kind of situations, people usually talk about “mixed characteristic” (the characteristic of the residue field is different form the characteristic of the ring).")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-518925")[#strong[#text("Martin Lotz (@mlotzo)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2019")]

#text("A minor technical comment: you should clean your blackboards :-) Nice summary though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-556512")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Is there any reason why Scholze’s lectures are not downloadable from the UCLA DLS website? It is hosted on box.com and there is no button to download. But there is one for all other DLS lecturers on box.com.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/#comment-619060")[#strong[#text("课程视频区 – Langlands Program")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2021")]

#text("[…] A great preview of those lectures was given by Tao’s blog ")#link("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/")[#text("https://terrytao.wordpress.com/2019/03/19/prismatic-cohomology/")]#text(". 一个很不错的笔记见 […]")
]
