// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/
// Converted to Typst by tao2typ: "2026-10-14T15:18:36.205121+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Ingrid Daubechies) Planning for the World Digital Mathematical Library", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Ingrid Daubechies) Planning for the World Digital Mathematical Library")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 May 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/")[#text("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("[")#emph[#text("This guest post is authored by ")#link("http://en.wikipedia.org/wiki/Ingrid_Daubechies")[#text("Ingrid Daubechies")]#text(", who is the current president of the ")#link("http://en.wikipedia.org/wiki/International_Mathematical_Union")[#text("International Mathematical Union")]#text(", and (as she describes below) is heavily involved in planning for a next-generation digital mathematical library that can go beyond the current network of preprint servers (such as the arXiv), journal web pages, article databases (such as MathSciNet), individual author web pages, and general web search engines to create a more integrated and useful mathematical resource. I have lightly edited the post for this blog, mostly by adding additional hyperlinks. – T.")]#text("]")

#text("This guest blog entry concerns the many roles a ")#link("http://www.mathunion.org/WDML/")[#text("World Digital Mathematical Library")]#text(" (WDML) could play for the mathematical community worldwide. We seek input to help sketch how a WDML could be so much more than just a huge collection of digitally available mathematical documents. If this is of interest to you, please read on!")

#text("The “we” seeking input are the ")#link("http://www.mathunion.org/ceic")[#text("Committee on Electronic Information and Communication")]#text(" (CEIC) of the ")#link("http://www.mathunion.org/")[#text("International Mathematical Union")]#text(" (IMU), and a special committee of the ")#link("http://www.nationalacademies.org/nrc/")[#text("US National Research Council")]#text(" (NRC), charged by the ")#link("http://www.sloan.org/")[#text("Sloan Foundation")]#text(" to look into this matter. In the US, mathematicians may know the Sloan Foundation best for the prestigious early-career fellowships it awards annually, but the foundation plays a prominent role in other disciplines as well. For instance, the ")#link("http://www.sdss.org")[#text("Sloan Digital Sky Survey")]#text(" (SDSS) has had a profound impact on astronomy, serving researchers in many more ways than even its ambitious original setup foresaw. The report being commissioned by the Sloan Foundation from the NRC study group could possibly be the basis for an equally ambitious program funded by the Sloan Foundation for a WDML with the potential to change the practice of mathematical research as profoundly as the SDSS did in astronomy. But to get there, we must formulate a vision that, like the original SDSS proposal, imagines at least some of those impacts. The members of the NRC committee are extremely knowledgeable, and have been picked judiciously so as to span collectively a wide range of expertise and connections. As president of the IMU, I was asked to co-chair this committee, together with ")#link("http://www.cni.org/about-cni/staff/clifford-a-lynch")[#text("Clifford Lynch")]#text(", of the ")#link("http://www.cni.org/")[#text("Coalition for Networked Information")]#text("; ")#link("http://www.math.umn.edu/~olver/")[#text("Peter Olver")]#text(", chair of the IMU’s CEIC, is also a member of the committee. But each of us is at least a quarter century older than the originators of ")#link("http://en.wikipedia.org/wiki/MathOverflow")[#text("MathOverflow")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Arxiv")[#text("ArXiv")]#text(" when they started. We need you, internet-savvy, imaginative, social-networking, young mathematicians to help us formulate the vision that may inspire the creation of a truly revolutionary WDML!")

#text("Some history first. Several years ago, an international initiative was started to create a World Digital Mathematical Library. The ")#link("http://www.mathunion.org/WDML/dml/index.shtml")[#text("website for this library")]#text(", hosted by the IMU, is now mostly a “ghost” website — nothing has been posted there for the last seven years. [It does provide useful links, however, to many sites that continue to be updated, such as the ")#link("http://www.emis.de/journals/short_index.html")[#text("European Mathematical Information Service")]#text(", which in turn links to many interesting journals, books and other websites featuring electronically available mathematical publications. So it is still worth exploring …] Many of the efforts towards building (parts of) the WDML as originally envisaged have had to grapple with business interests, copyright agreements, search obstructions, metadata secrecy, … and many an enterprising, idealistic effort has been slowly ground down by this. We are still dealing with these frustrations — as witnessed by, e.g., ")#link("http://thecostofknowledge.com/")[#text("the CostofKnowledge initiative")]#text(". They are real, important issues, and will need to be addressed.")

#text("The charge of the NRC committee, however, is to NOT focus on issues of copyright or open-access or who bears the cost of publishing, but instead on what could/can be done with documents that are (or once they are) freely electronically accessible, apart from simply finding and downloading them. Earlier this year, ")#link("http://mathoverflow.net/questions/122125/math-annotate-platform")[#text("I posted a question about one possible use on MathOverflow")]#text(" and ")#link("http://publishing.mathforge.org/discussion/163/math-annotate-platform/#Item_0")[#text("then on MathForge")]#text(", about the possibility to “enrich” a paper by annotations from readers, which other readers could wish to consult (or not). These posts elicited some very useful comments. But this was but one way in which a WDML could be more than just an opportunity to find and download papers. Surely there are many more, that you, bloggers and blog-readers, can imagine, suggest, sketch. This is an opportunity: can we — no, YOU! — formulate an ambitious setup that would capture the imagination of sufficiently many of us, that would be workable and that would really make a difference?")

#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("Sounds like a great idea, but hasn’t something like this been tried and been pretty successful? It’s called the internet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228394")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("The internet has certainly been transformative, but there are still many tasks which should in principle be easy to do using the internet, but aren’t. A simple example is automatic bibliography management. When I write a paper, many of the references are to papers that at the time only exist in preprint form (e.g. on the arXiv). Ideally there should be a way to assign a standard identifier to such papers that can be used in citations in such a way that when the publication status of that paper changes, one’s bibliography can be automatically (or semi-automatically) updated to reflect this. As far as I am aware, such updating can only be done manually at present. This would not be such a great inconvenience were it not for the fact that it makes citation searches somewhat less useful than they could be (one might only be able to locate papers that cite the published version of an article, rather than a preprint of that article, for instance).")

#text("In a similar vein, a digital library could offer the ability to “subscribe” to a given paper or manuscript (using some standard identifier) and be notified whenever there are errata or other updates to that paper, citations, related work, and so forth. Some publishers offer some version of this service already but it is very spotty (in large part because there is no standard format for citations and other metadata that are uniform across all publishers). More ambitiously, one could imagine in the future a more semantic subscription service (“Notify me of all new research papers on universality for random matrices!”); one can do something like this with current internet tools but there is certainly potential for improvement here, and having a standard repository for all mathematical research papers (or at least the metadata for such papers) that can coordinate information from many sources (e.g. journals, MathSciNet, institutional libraries, the arXiv, etc.) could be very helpful in this regard.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10a3c27d435ba0a999caf7f95fd0492eb701ee91a4de248306ab327882d9894b-e34837229ad4729c465e9acb152842237ae2f4e4542ab5583a003d2d15390853.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228395")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("I’ve seen something like this for author identification (")#link("http://orcid.org")[#text("http://orcid.org")]#text(") (although I think Elsevier is behind it).")

#text("Also Google scholar offers a fairly good notification service similar to what you mention.")

#text("But I agree, much more could be done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228435")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("There could be a role for the publisher in updating the status of a document. For one thing, the publisher has authority over what is actually published. One can imagine an online digital library with accounts for authors and publishers (or editors). They would be “subjects” as in “capable of doing actions”. The “objects” would then be the papers. I suppose publication status would be metadata for a paper or document. Errata would be perhaps a second kind of “object”: Research Article, Letter to the Editor, Book Review, Erratae, Expository Article, Book, … For a unique identifier, it could be based on permanent, unchanging data about the paper: author(s), title (maybe), and UTC time and date of creation of Version 1, perhaps.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10a3c27d435ba0a999caf7f95fd0492eb701ee91a4de248306ab327882d9894b-e34837229ad4729c465e9acb152842237ae2f4e4542ab5583a003d2d15390853.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228390")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("So of the outside links are wrong, such as the Mathoverflow one. They link back to your site. ")#emph[#text("[Fixed now, hopefully – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10a3c27d435ba0a999caf7f95fd0492eb701ee91a4de248306ab327882d9894b-e34837229ad4729c465e9acb152842237ae2f4e4542ab5583a003d2d15390853.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228391")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("Nevermind. They seem fixed now (or it was a problem on my end).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10a3c27d435ba0a999caf7f95fd0492eb701ee91a4de248306ab327882d9894b-e34837229ad4729c465e9acb152842237ae2f4e4542ab5583a003d2d15390853.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228399")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("(I assume this post is an invitation to share our ideas in the comment section of your blog…)")

#text("The main idea I have is that we should continue to push the bounds of metadata. Here are some ideas (crazy and not).")

#text("(1) Comments and reviews. Comments on papers can be really helpful, especially if there are checks and balances like in mathoverflow to prevent bullying or spam. People can ask questions about a proof that doesn’t make sense or how paper x is related to paper y.")

#text("(2) Correction of metadata: Users may notice that “the system” confused paper x with paper y when they are different (or vice versa). Old data may be spelled wrong, or other typos. It would be good if users could correct those mistakes (again with a system to prevent spam).")

#text("(3) Erratums: I see no reason why a published paper should have a bad mistake in it and that shouldn’t be made known in a clear place. Ideally, the paper should be changed (even if it is a note at the front or the end saying there is a critical error in Theorem 4, it is corrected in paper y). Other options are erratum databases. Also it shouldn’t take the author or editor to point out a mistake. This is where comments and reviews are helpful.")

#text("(4) Annotations: Why write *about* theorem 4 when you can write *on* theorem 4.")

#text("(5) Auto translations of a paper: Something like Google translate, but a bit better with math terminology and that doesn’t mess up formulas.")

#text("(6) Online reading groups for a paper: People interested in paper X can form an online discussion group about it. (Similar to the discussion of the P – NP paper two summers ago on the polymath wiki.)")

#text("(7) Paper homepage: A homepage for each paper that contains links to all the relevant versions and metadata, even if is on another site or behind a paywall. (Similar to what the journals do for articles and what Amazon, Google, and Worldcat do for books.)")

#text("(8) Allow people to make lists of papers on a subject: Similar to Amazon book lists.")

#text("(9) Better connection with LaTeX. Making Biliographies is too hard.")

#text("(10) Integration with reference managers: Zotero, Papers, Mendeley, etc.")

#text("(11) And more…")

#text("Also, anything behind paywall is much less useful. MathSciNet has an RSS service, but it is of little use because of it is behind a firewall so it can’t be used by Google Reader or similar web RSS readers. (Note, Elsevier is criticized for making their data available to Google, but then hiding it behind a paywall. I on the other hand like this. At least I know it is there, even if I don’t have access to it.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228511")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("“(10) Integration with reference managers: Zotero, Papers, Mendeley, etc.”")

#text("[Slightly off topic] I am a newby of Zotero, and I just noticed that arxiv pdf files seem not to contain metadata (which are used by the software for a first level of indexing).")

#text("Probably the first (rough) step to obtain better integration with reference managers would be to reject pdf files lacking metadata ;)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10a3c27d435ba0a999caf7f95fd0492eb701ee91a4de248306ab327882d9894b-e34837229ad4729c465e9acb152842237ae2f4e4542ab5583a003d2d15390853.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Rute")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228552")[#strong[#text("Jason Rute")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("I’m not sure what metadata you are referring to, but Zotero lets you extract metadata from the arxiv webpage. There is even a standard for this called COINS (or something like that). (I guess you have to be using a browser plugin for this to work. Firefox is best.)")

#text("Back on topic. It would be good for the metadata to be machine readable (like an api, or at least the open source COINS standard mentioned above).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228625")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("“I’m not sure what metadata you are referring to, but Zotero lets you extract metadata from the arxiv webpage.”")

#text("You are right! Indeed, metadata can be retrieved by the browser, but they are not normally contained in the .pdf file (whence I tried to extract them).")

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228408")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("Here’s some things that don’t affect me per se, but will probably become important in coming years for certain subfields.")

#text("Machine-readable formats, such as standards like xml, mathml. Even pdfs from publishers who claim to use PDF/A standard are often not, and the fonts used are often some strange custom/in-house glyphs (I learned this from Peter Murray-Rust, who works in data-mining). A number of new journals (they seem to all be in life sciences) are web-native. For example, see this article from PeerJ:")

#link("https://peerj.com/articles/71/")[#text("https://peerj.com/articles/71/")]

#text("and compare it to the ‘article of the future’ offerings that Elsevier offered (pseudo frame-based layout is incredibly 90s), and the even worse mess they make of trying to present mathematics articles in html/xml.")

#text("Some lobbying of the major browser manufacturers to fully support MathML wouldn’t go astray, but I don’t know if this is in-scope.")

#text("Imagine the sorts of ‘moonshine moments’ we could have if instead of relying on memory or word-of-mouth we could plug in some formula, and find it in a paper from a venue we would have never considered. I’m thinking Borwein-style experimental mathematics here, augmented by being able to search the literature for complicated mathematical expressions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228419")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("For any human revolutionary idea the pioneer creator would certainly encounter fierce resistance. This is not new in the history of Mathematics, starting from the crisis of Irrational number by scarifying the life of Hippasus, the madness suffered by Cantor")#linebreak()#text(" on Infinite numbers from attack by his own professor Kroneckor…")

#text("However, a smart creator of idea knows how to circumvent the obstacles . Look at Steve Jobs with his digital music iTune revolution. He managed to bypass copyright issues, created a new music economy with a win-win solution for both music companies and consumers.")

#text("Digital books by Google “Project Gutenberg” to digitize all human books have made little progress because of the copyright issues. Larry Page should learn the lesson from Steve Jobs.")

#text("Will the World Digital Math Library (WDML) face the same resistance as “Project Gutenberg”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228442")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("With respect to unique identifiers for papers, I suggested including author names and the title of the paper. I think we need to go beyond ASCII, as Math Reviews does already. A name can be imagined as a string of glyphs. Unfortunately, there are several character sets containing the glyph “Latin Upper Case L”, i.e. “L”. I see that p-adic in article titles has an italic Lower Case Latin P. Ideally, with recognized standards (Unicode, LaTex), it should be feasible and easy to write a title as a string of “glyph names” uniquely.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228448")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("I think that enabling comments and reports on published articles would be a great idea. It should be possible to rate reports, so to build a rating of users.")

#text("Two more ideas:")#linebreak()#text(" (1) index the articles also with the institution of the author: in this way institutions could use the WDML as a preprint server;")#linebreak()#text(" (2) provide statistical data about downloads.")

#text("About both these points, I think these could be “premium features” (i.e. behind some paywall). The access to the articles should stay free, and the costs of the servers could be (partially) paid selling some piece of information (which are the most downloaded articles, the rating of downloads, which are the articles published by researchers of a particular institution and so on).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228455")[#strong[#text("A digital mathematical library for the whole world | regularize")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")]

#text("[…] post is “Planning for the World Digital Mathematical Library” and, in a nutshell, Ingrid Daubechies present the plans of the IMU to build a new online […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MMORPGames at the knowledge frontier | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228465")[#strong[#text("MMORPGames at the knowledge frontier | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("[…] could be initially hosted for almost nothing, we could ask for sponsors. We could join efforts with established international organisms which intend to pursue somehow similar projects. The more difficult part will be the tuning of interactions, so that the game starts to have more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228471")[#strong[#text("Thursday Highlights | Pseudo-Polymath")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")]

#text("[…] About the WDML. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228472")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e257v3")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")]

#text("[…] About the WDML. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228485")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("A big failing of the current system is that the quality of a paper is to expected to be reliably judged by the authors before submitting. For younger faculty, or those approaching a borderline or politicized promotion decision, or those in deteriorating health, many non-math factors can encroach.")

#text("There’s really no need to link an article permanently to a journal except for that journal’s reputation. I’m sure you can imagine, for example, promoting a paper from sigma to pi after some years, although it wasn’t clear initially how good the paper was. The Graham/Chung/Wilson paper on quasirandom groups, for example, initially seemed rather pedestrian, but in hindsight it contains the germ that grew in Gowers’ sun, and flowered further in the last 15 years.")

#text("Another related suggestion: I would like to be able to “vouch” for papers. I put a lot of work into reading papers (often clearly more than the official referee), and I would love to be able to record somewhere that I did so and found typos x,y,z, but the results are correct.")

#text("Another related suggestion: A growing body of math has computer verified proofs. We should be able to link these machine proofs to the article where the theorem has a human-readable proof. The two things complement each other, and are typically years separated in their creation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228486")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("Also, it would be gratifying to know that someone else would vouch for the correctness of my work :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("The biggest hole in current theoretical physics is that it is limited to mathematics that does not allow for the calculation of fundamental physical constants. The problem is highlighted by the page of the Kavli Institute for Theoretical Physics at UCSB titled “What is the role of theory in science?”. It says, “What is actually meant in terms of the role of theory in science—and the KITP mission–is the “idea proven,” with the degree of confidence quantified.” Since fundamental math is “unproven” in respect to its use in calculating fundamental constants, in practice the concept is ignored by KITP and other institutions for “Theoretical Physics”. What is needed is an “Institute for Hypothetical Physics” ;-).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a26dc4b9e3491e0262a0ddd407bfdc5c9eab1b8ea6bd08e88c98b7cac3419a8-f727b05b801e7c3cb34ce133abf8f2fc1992dc0e899e93371980a72b63058fe5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hippo")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228592")[#strong[#text("Hippo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("A few ideas:")#linebreak()#text(" 1. An article browser with tabs, where one can just click on the references inside the documents, and that paper would automatically open up in a new tab, without having to go through additional verification. This could be done for multiple platforms, including ereaders (kindle, ipad, etc).")

#text("2. An automatic bibliography tool, integrated into the latex environment, that would give a short name to the articles (combination of title and authors, like google scholar’s bibtex citation tool does), and these could be referred to a command like \\citewdml{article name}. Then latex could just fetch the newest versions from the WDML database, when making the bbl file, at each bibtex compilation, and there would be no need for a bib file.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228695")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("I think citations are technically bracketed abreveations used within the document that point to items in the bibliography, at the end of an article, chapter or book. For articles that were published, but never as arXiv pre-prints, say articles from 1995 or before that, the full bibliographic data might not be available on arXiv ; if they became available at the WDML (or at least a bibliographic database with their bibliographic data), that might be useful. I’d like to be able to have a hyper-link from an entry for article B in the bibliography of article A to the homepage of article B. Sometimes, I find I had better consult article B before continuing my reading of article A.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc635af44324cef620fb3854a3ae41e4ca48ad142c26a3e27e68f2b9a5ab40db-ad0252eead8fcf3c27d69b3892151d5ab58850a4271f15ec7cda71284b0e20ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Daly")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228603")[#strong[#text("Tim Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("The collision of Mathematics and Computers has had the effect of making")#linebreak()#text(" many algorithms available both commercially (Mathematica, Maple) and")#linebreak()#text(" as open source (Axiom, Sage). There is a huge gap between the NIST")#linebreak()#text(" Handbook of Mathematical Functions and the actual implementation of")#linebreak()#text(" those functions.")

#text("I believe that we need to show actual implementation details as almost")#linebreak()#text(" all practical applications will be electronic. However this is a complex")#linebreak()#text(" problem because there are many specific details that need to be explained,")#linebreak()#text(" such as instability.")

#text("Knuth suggested that “literate programs” would make it possible to have")#linebreak()#text(" human-to-human communication of algorithms while showing actual")#linebreak()#text(" executable code.")

#text("I would advocate strongly for an effort to provide literate programs which")#linebreak()#text(" explain and include implementations of Mathematical Functions.")

#text("Tim Daly")#linebreak()#text(" ")#link("mailto:daly@axiom-developer.org")[#text("daly@axiom-developer.org")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20fbcb69386bc7c6301f7c284ec7f730c502232b460f9d8e222b31e8f2c45f5d-d05957d0a1775f744371c9f023b11a6fb0d5c86de8fe599f84197638407fdd3c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228642")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("Hi Terence and others")#linebreak()#text(" I think there needs to be at least a “mathbook” similar to facebook, so that authors can immediately upload their work , and somehow feel reassured that their work will not get stolen and that they can prove easily that their own work is their own work etc This is the major missing piece that I see and should be available before submitting to a journal. eg A person should be able to put paper A on mathbook within 5 minutes of a proposed miraculous discovery say, even if its right or wrong, and feel assured that it is all legal and bound to them. The closest thing to mathbook seems to be arxiv, but you can get hesitant there as you need a report number from an institution when submitting etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228655")[#strong[#text("World Digital Mathematical Library | Peter Cameron's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] tired of my carping. So it is nice to report something positive for a change. This is inspired by a guest post on Terry Tao’s blog, by Ingrid Daubechies, president of the International Mathematical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53c7f55c60afa8233a26eec368ba35174583897c05701b2803cd8fb05ec7f01b-14f08ad529e338878a6f4db159b1910bf98eb14d663b128b1469587da01e9c71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Schwabhäuser")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228677")[#strong[#text("Thomas Schwabhäuser")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("I had similar thoughts when I was reading Hofstadter’s book Gödel, Escher, Bach a really long time ago. I started to dream of an integrated workspace for mathematical research on my computer which was my motivation to study mathematics later because I knew I was really far away from the theory that is needed to realise something like this. After more than 20 years I know my dream was not realistic but even without additional background in computer science I would also know that the technical conditions have changed, probably even more than most people’s mathematical knowledge could have changed in the same time.")

#text("The best approximation to my dream that I could find is Sage, ")#link("http://www.sagemath.org/")[#text("http://www.sagemath.org/")]#linebreak()#text(" It made at once clear that my dream’s original version to base the integrated workspace on the foundations of logic would not be practical. But my dream definitely included the option to define theories and analyse implications between them. Sage has the potential to become a central place for mathematical research and offers the option to exchange WDML contents for free without any loss that might be due to conversion between different standards or bad quality of printouts.")

#text("However, there are natural questions of security as I do not think that many researchers are in favour of storing all their draft worksheets on a central server that is not administered by themselves. On the other hand this question is insignificant because it is easy to prepare your worksheet on a local Sage server and only upload the final results to a central database. In order to really use a public central Sage server as “official” WDML we would like to find many papers there that have been published in the past. I think it is allowed to write down in your diary what you read in a Journal and likewise there should be no problems if you do this in your private worksheets on a central Sage server. However, I am not the right person to ask whether this allows for a Sage server to become an official WDML.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/112694a366c1f6b193951b68314bc3d4757a69db709c3ddf11067886db443027-62f9bcf01e580e4cb982052f472101a81f613b128dc9e8a9319459548196458f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228678")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("Many times you read a paper and you see: “by (11), (17), (18) and (23), we have…”. It would be great if you could click on (11) etc. and it would show the text around those formulae in another small window, so you don’t have to go back and forth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229214")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")])]

#text("This is possible, and done by Compositio for references. See the TeX.SE question for more information: ")#link("http://tex.stackexchange.com/questions/15356/")[#text("http://tex.stackexchange.com/questions/15356/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-228862")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")])]

#text("Terry, Ingrid")

#text("On a more mundane note, OSTP is seeking an Outstanding “Open Science” Champion of Change. One can nominate organization, people, etc all this before May 14th.")

#link("http://www.whitehouse.gov/blog/2013/05/07/seeking-outstanding-open-science-champions-change")[#text("http://www.whitehouse.gov/blog/2013/05/07/seeking-outstanding-open-science-champions-change")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5586ee2244327a0afd2490efe761a1aa85e91d423d676a40ded66d5b7d35956-c319f5f23fecba79da2df99e0af9dad6f8926cf625d2a5753138d06e5573f561.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manoj")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229080")[#strong[#text("Manoj")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2013")])]

#text("I haven’t read all the other discussions, so apologies if I am repeating something someone has already said. My own idea is that a math paper is never really “done.” Instead it should be a living entity. I imagine a math paper put up on a wiki by the original author. Then different authors suggest edits to the paper, or add comments and reviews. The original poster still keeps “ownership” of the paper, and gets to decide which of the new edits to integrate into the paper. They can choose whether to share ownership with some user who wants to do an extensive rewrite.")

#text("When a new reader comes to the wiki to read the paper, and runs across a difficult paragraph, they can look at alternative explanations and comments local to that paragraph even if those have not been integrated into the text by the original author. If they like a particular alternative explanation, they can vote it up, so it shows at the top of the list of explanations. Reputation points can also be used as on reddit or mathoverflow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229255")[#strong[#text("test | badbitbad")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/")[#text("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")])]

#text("From a strictly technical point of view I would love to see 3 major extensions:")

#text("1. A web-sever engine that does direct to web rendering from LaTeX, supporting as much of TeX/LaTeX as possible. Perhaps this can be tackled with a point size to pixel translation engine. WordPress is nice but LaTeX on the web can be so much more.")

#text("2. An overlay extension to LaTeX to allow for reader annotations, that is tied into the server engine so that you could toggle selected annotations on and off. This could be just an additional package; maybe it could work by \\including{} the original document (to be annotated) in an annotations document — hmmm would that make recursive annotations Turing complete?")

#text("3. TeX/LaTeX rendering plugins available in every web browser.")

#text("Along a more meta-topic: in keeping with Marshall MacLuhan’s theory of communication the value of any web service is not in the content it provides, for that is the role of the users, but rather is in establishing and maintaining context for the users and their content. This is done through the explicit construction of symbols and actions used to create, navigate, and digest the information. When developers create web-applications they are actually creating a new, and often rich, grammars and syntaxes composed of both symbols and behaviours, whose re-combinations are governed by strict algorithms maintained on the servers. The most valuable web applications strike a balance between the expressiveness of their language constructs, and the ability to filter unwanted, or noisy communication. That is the web applications establish and maintain a context that the users find appropriate for the content being conveyed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229924")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2013")])]

#text("I am not sure I understand what you are talking about, but maybe writeLaTeX would interest you: ")#link("https://www.writelatex.com/")[#text("https://www.writelatex.com/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f28d5d37b3a0f3fe81d5f01b1c2d6f3f9f707172720c901de22d46e10af9527c-472c85474a41f9b4626e6c74432d521a2a1f66955a0936ef5b4f9be017e35110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aaronsheldon")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229344")[#strong[#text("aaronsheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")])]

#text("Sorry that last anonymous was from me.")

#text("I have on more extension:")

#text("4. A personal LaTeX scratch pad connected with each document, that would function as fluidly as writing on notepad in hand, while reading an article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f28d5d37b3a0f3fe81d5f01b1c2d6f3f9f707172720c901de22d46e10af9527c-472c85474a41f9b4626e6c74432d521a2a1f66955a0936ef5b4f9be017e35110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aaronsheldon")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229345")[#strong[#text("aaronsheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")])]

#text("Sorry again,")

#text("Back to the meta-topic: one more point I would like to make is to contrast a math web application with, say, youtube. With a service like youtube the context is explicitly about communicating with others, often in a very superficial manner, hence the simplicity of the structure of the comment threads. In comparison a math web application would be as much about enhancing the internal dialogue we undergo when we interpret, comprehend, and verify the content, as it is about expressing information within the mathematics community. Thus for a math web application to be truly successful it must do more than enhance the conversation between mathematicians, it must enhance the conversations individual mathematicians have with themselves.")

#text("I apologize for the spammy nature of the comments, I should really write these ideas down somewhere more appropriate \\joke{a bathroom stall, maybe?}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f28d5d37b3a0f3fe81d5f01b1c2d6f3f9f707172720c901de22d46e10af9527c-472c85474a41f9b4626e6c74432d521a2a1f66955a0936ef5b4f9be017e35110.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aaronsheldon")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229349")[#strong[#text("aaronsheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2013")])]

#text("David Roberts: Thank you that is exactly right. Why can’t we search by equations? That would be amazing! To index a library by the formula in it. Something like regular expressions for mathematical formula, with a nice comprehension of variable substitution/abstraction")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-231100")[#strong[#text("Petr Sojka (@PetrSojka)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2013")]

#text("In the European Digital Mathematics Library you actually _can_ search by formulae: try ")#link("https://eudml.org/search")[#text("https://eudml.org/search")]#linebreak()#text(" Fulltext are math OCRed, formulae normalized and stored in MathML and indexed. The technology behind (MIaS, Math Indexer and Searcher, ")#link("https://mir.fi.muni.cz/mias/")[#text("https://mir.fi.muni.cz/mias/")]#text(") has been tested on arXiv papers with 3 billions of formulae indexed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liquidity Trap, Number Theory News, and WDML | Pink Iguana")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229400")[#strong[#text("Liquidity Trap, Number Theory News, and WDML | Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2013")])]

#text("[…] Ingrid Daubechies, What’s new, Planning for the World Digital Math Library, here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-229496")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2013")])]

#text("I propose a ")#link("http://chorasimilarity.wordpress.com/2013/05/09/mmorpgames-at-the-knowledge-frontier/")[#text("game")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f57986bd0ae92e80acb27248ed0be7a4f22ebd501ad8f03b1464d5ac096e392-4d8a89d7adf7f0a15283fe3249f9dd097d0570c9903ecadea5b9a9dcd45f8c6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-230265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2013")])]

#text("There is an open-sourced (GPLv3) PDF to HTML converter, pdf2htmlEX, which can display PURE HTML academic paper elegantly in web-browser without any plug-in. This might be useful for online publishing, since html is the nature language on the internet, and we can do more on html, like social-reading/comments/sharing/ect. The demos can be found on")#linebreak()#text(" ")#link("http://coolwanglu.github.io/pdf2htmlEX/")[#text("http://coolwanglu.github.io/pdf2htmlEX/")]#linebreak()#text(" ")#link("https://github.com/coolwanglu/pdf2htmlEX/blob/master/README.md")[#text("https://github.com/coolwanglu/pdf2htmlEX/blob/master/README.md")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2b9d468bf4a9822e7891c805b90e2599a9060d8a2fa19f2dd57051c56b3625e-a7ad38d1b6428d8cdc9ea3dc1c2a077591a2284137eee212b2c682005f22e691.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Trott")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-230424")[#strong[#text("Michael Trott")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2013")])]

#text("The comments show that a future digital mathematics library will have many different facets.")

#text("A small group of people at Wolfram|Alpha has over the last year worked on some exploratory aspect of a digital math library.")#linebreak()#text(" The goal was to make the main results of a sample set of papers from the continued fraction literature easily searchable and return concise results.")

#text("For more details, see our recent blog:")

#link("http://blog.wolframalpha.com/2013/05/16/computational-knowledge-of-continued-fractions/")[#text("http://blog.wolframalpha.com/2013/05/16/computational-knowledge-of-continued-fractions/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33aefab722595b92bcb58102590551223e11b3120997632d143dd93a143bb03c-df262391de00ad0d3c24a47e39a2ccf3994c09568182e85beba4b622c88f29d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thierry Bouche")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-231105")[#strong[#text("Thierry Bouche")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2013")])]

#text("What about EuDML as a teaser to showcase few innovative things (accessibility, math search, bibtex export, reference matching — in fact most of what people are thinking about here, etc.) while delivering an actual service?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d649a8ddfbf63d386d40726f8ced42a0e8f21e1144917d7389b93618b67c9ee5-b25560eaa9e997444721b5bbd2d04dbf884fee03f0cdd5783b6d14e1ebd239a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Strangelove")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-234403")[#strong[#text("Dr. Strangelove")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("There is a very basic requirement about such a World Digital Mathematics Library which is may however the hardest to fulfill:")

#text("The servers must not be located in the U.S. (or fellow U.K., or China, or Russia etc.).")

#text("Even more general: The service must be run as independent from influence and supervision of the big brother organizations like NSA as possible.")

#text("Else, we would face soon the situation that the essence of mathematical heritage is at the free disposal of a bureaucracy that will cut off the world from the core of research if they consider it useful for the “sake of homeland security” (which may be already the case if some cryptographic results are published which they think may harm their surveillance infrastructure).")

#text("Given their genuine interest in math research, they may even force the WDML to design interfaces which install spy software to every mathematician, just to be sure about all ongoing research. (Ok, maybe they just spy foreign mathematicians this way, and of course everything is under democratic control since the house and the court gave them carte blanche. And maybe the American Mathematical Society is happy about this because this could lead to even more NSA grants.)")

#text("Dear fellows, many of the ideas above about social network features etc. sound very nice and comfortable, but please dont’t forget about the reality:")

#text("This is a world where mathematical knowledge means power. Not for the mathematician who is merely the armourer who can easily be killed by a sword forged by himself, but for the big players out there who are able and willing to use power without any qualms. This is not science fiction, we know that they did it, they do it now and they will continue on large scale.")

#text("So don’t even think about creating such unique information pools of core science if you have no idea how to protect this. To my knowledge, this is beyond today’s technical options. But we should at least try. The first requirement would be to have the servers and development located at several mirrored places outside U.S.-U.K./China/Russia. Let us do the development and maintenance without any organization which has ties to agencies like NSA. Let us use mandatory encryption.")

#text("Unfortunately, it may quickly turn out that we have to do this without Sloane funds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07a480da5f6f2a82b944027e5d65724d92cd08e03b01c6181d37f24f3cf6f00e-b6e975d855ccb19d4897c4617721907d1bc20853f9c327d5e247cefbd4a113e3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Alpha: Day 1 with Wolfram | riemannian hunger")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-237027")[#strong[#text("The Alpha: Day 1 with Wolfram | riemannian hunger")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("[…] Perhaps we’re not as far from recognizing Terence Tao’s (and also Ingrid Daubechies’) vision of universal mathematical access. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe20e72fc2b4a3037fbcc9ebe062732c9b2deae78e58024b5eec864928b9b329-0d4221ab0a3d4db014b5ca5089f805893a3763ad91834db24f3aab5a517aae62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Corneli")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-246791")[#strong[#text("Joe Corneli")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2013")])]

#text("Although I’m late to this discussion I thought I should mention a recent related proposal I’m working on at Wikimedia: ")#link("https://meta.wikimedia.org/wiki/Grants:IdeaLab/PlanetMath_Books_Project")[#text("https://meta.wikimedia.org/wiki/Grants:IdeaLab/PlanetMath_Books_Project")]

#text("Summary:")

#text("The purpose of this project is to make it easy to produce mathematical textbooks from pre-existing, freely available material.")

#text("PlanetMath is a free/open mathematics community that uses the same license as Wikipedia. It is best known for its encyclopedia, and cutting edge in-browser interaction and rendering of mathematics content. In recent years, PlanetMath’s software system has been entirely rebuilt, with a new focus on free/open problem sets, course outlines, and textbooks. We plan to reuse existing material from PlanetMath, Wikipedia, and math.stackexchange.com, along with other free/open and public domain sources, to expand our collection of mathematical learning materials. PlanetMath’s special-purpose software make it an ideal place to assemble content — and publish “downstream”, e.g. to Wikibooks. This kind of content exchange has a precedent in the earlier PlanetMath Exchange, which brought hundreds of articles from PlanetMath to Wikipedia. If we can do something similar with books, it will be a big step forward for Open Educational Resources, and the Wikimedia movement.")

#text("An IEG grant would support the technical work that will make this possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-520456")[#strong[#text("Mathematics Open Community Reviews")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/")[#text("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17b4c903b7012abe80bae4277e58914ac41e4b78dd6d23e68bb521a2686af323-1cd26d8e844405cb37def45a4e6edffa609711504108919ca3d7cc8fb65d49d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sékioz de Niafre")]], [#link("https://terrytao.wordpress.com/2013/05/08/planning-for-the-world-digital-mathematical-library/#comment-643575")[#strong[#text("Sékioz de Niafre")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2022")])]

#text("I recently remembered this in relation to OpenAI “Solving (Some) Formal Math Olympiad Problems !!” (K-10 level), particularly Problem 4 about Schur’s inequality, and “Eigenvectors from eigenvalues: A survey of a basic identity in linear algebra”, particularly this: “In many cases, the identity was not highlighted as a relation between eigenvectors and eigenvalues, but was instead introduced in passing as a tool to establish some other application; also, the form of the identity and the notation used varied widely from appearance to appearance, making it difficult to search for occurrences of the identity by standard search engines.”")#linebreak()#text(" ¿Could AI help to accomplish the WDML’s goals and prevent historical overlooks like that?")
]
