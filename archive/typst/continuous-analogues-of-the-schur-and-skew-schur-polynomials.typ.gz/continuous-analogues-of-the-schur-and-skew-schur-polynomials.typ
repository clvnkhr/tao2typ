// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/
// Converted to Typst by tao2typ: "2026-10-14T15:19:55.626803+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Continuous analogues of the Schur and skew Schur polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Continuous analogues of the Schur and skew Schur polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 September 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")[#text("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Fix a non-negative integer ")#mi("{k}")#text(". Define an ")#link("https://en.wikipedia.org/wiki/Partition_(number_theory)")[#text("(weak) integer partition")]#text(" of length ")#mi("{k}")#text(" to be a tuple ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_k)}")#text(" of non-increasing non-negative integers ")#mi("{\\lambda_1 \\geq \\dots \\geq \\lambda_k \\geq 0}")#text(". (Here our partitions are “weak” in the sense that we allow some parts of the partition to be zero. Henceforth we will omit the modifier “weak”, as we will not need to consider the more usual notion of “strong” partitions.) To each such partition ")#mi("{\\lambda}")#text(", one can associate a ")#link("https://en.wikipedia.org/wiki/Young_tableau#Diagrams")[#text("Young diagram")]#text(" consisting of ")#mi("{k}")#text(" left-justified rows of boxes, with the ")#mi("{i^{th}}")#text(" row containing ")#mi("{\\lambda_i}")#text(" boxes. A ")#link("https://en.wikipedia.org/wiki/Young_tableau")[#text("semi-standard Young tableau")]#text(" (or ")#emph[#text("Young tableau")]#text(" for short) ")#mi("{T}")#text(" of shape ")#mi("{\\lambda}")#text(" is a filling of these boxes by integers in ")#mi("{\\{1,\\dots,k\\}}")#text(" that is weakly increasing along rows (moving rightwards) and strictly increasing along columns (moving downwards). The collection of such tableaux will be denoted ")#mi("{{\\mathcal T}_\\lambda}")#text(". The ")#emph[#text("weight")]#text(" ")#tao-math("{\\left|T\\right|}", block: false)#text(" of a tableau ")#mi("{T}")#text(" is the tuple ")#mi("{(n_1,\\dots,n_k)}")#text(", where ")#mi("{n_i}")#text(" is the number of occurrences of the integer ")#mi("{i}")#text(" in the tableau. For instance, if ")#mi("{k=3}")#text(" and ")#mi("{\\lambda = (6,4,2)}")#text(", an example of a Young tableau of shape ")#mi("{\\lambda}")#text(" would be")

#align(center)[#align(center)[#box[#table(
columns: (auto, auto, auto, auto, auto, auto, ),
rows: 3,
align: (center, center, center, center, center, center,),
inset: (x: 0.2em, y: 0.1em), stroke: none,
table.cell(x: 0, y: 0, [#mi("\\displaystyle  1")]),
table.cell(x: 1, y: 0, [#mi("\\displaystyle  1")]),
table.cell(x: 2, y: 0, [#mi("\\displaystyle  1")]),
table.cell(x: 3, y: 0, [#mi("\\displaystyle  2")]),
table.cell(x: 4, y: 0, [#mi("\\displaystyle  3")]),
table.cell(x: 5, y: 0, [#mi("\\displaystyle  3")]),
table.vline(x: 0, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 1, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 2, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 3, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 4, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 5, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 6, start: 0, end: 1, stroke: 0.4pt),
table.cell(x: 0, y: 1, [#mi("\\displaystyle  2")]),
table.cell(x: 1, y: 1, [#mi("\\displaystyle  2")]),
table.cell(x: 2, y: 1, [#mi("\\displaystyle  2")]),
table.cell(x: 3, y: 1, [#mi("\\displaystyle  3")]),
table.vline(x: 0, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 1, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 2, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 3, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 4, start: 1, end: 2, stroke: 0.4pt),
table.cell(x: 0, y: 2, [#mi("\\displaystyle  3")]),
table.cell(x: 1, y: 2, [#mi("\\displaystyle  3")]),
table.vline(x: 0, start: 2, end: 3, stroke: 0.4pt),
table.vline(x: 1, start: 2, end: 3, stroke: 0.4pt),
table.vline(x: 2, start: 2, end: 3, stroke: 0.4pt),
table.hline(y: 0, start: 0, end: 6, stroke: 0.4pt),
table.hline(y: 1, start: 0, end: 6, stroke: 0.4pt),
table.hline(y: 2, start: 0, end: 4, stroke: 0.4pt),
table.hline(y: 3, start: 0, end: 2, stroke: 0.4pt),
)]]]

#text("The weight here would be ")#tao-math("{\\left|T\\right| = (3,4,5)}", block: false)#text(".")

#text("To each partition ")#mi("{\\lambda}")#text(" one can associate the ")#link("https://en.wikipedia.org/wiki/Schur_polynomial")[#text("Schur polynomial")]#text(" ")#mi("{s_\\lambda(u_1,\\dots,u_k)}")#text(" on ")#mi("{k}")#text(" variables ")#mi("{u = (u_1,\\dots,u_k)}")#text(", which we will define as")

#align(center)[#tao-fit-display[#tao-math("s_\\lambda(u) := \\sum_{T \\in {\\mathcal T}_\\lambda} u^{\\left|T\\right|}", block: true)]]

#text("using the multinomial convention")

#align(center)[#tao-fit-display[#mitex("(u_1,\\dots,u_k)^{(n_1,\\dots,n_k)} := u_1^{n_1} \\dots u_k^{n_k}.")]]

#text("Thus for instance the Young tableau ")#mi("{T}")#text(" given above would contribute a term ")#mi("{u_1^3 u_2^4 u_3^5}")#text(" to the Schur polynomial ")#mi("{s_{(6,4,2)}(u_1,u_2,u_3)}")#text(". In the case of partitions of the form ")#mi("{(n,0,\\dots,0)}")#text(", the Schur polynomial ")#mi("{s_{(n,0,\\dots,0)}}")#text(" is just the ")#link("https://en.wikipedia.org/wiki/Complete_homogeneous_symmetric_polynomial")[#text("complete homogeneous symmetric polynomial")]#text(" ")#mi("{h_n}")#text(" of degree ")#mi("{n}")#text(" on ")#mi("{k}")#text(" variables:")

#align(center)[#tao-fit-display[#mitex("s_{(n,0,\\dots,0)}(u_1,\\dots,u_k) := \\sum_{n_1,\\dots,n_k \\geq 0: n_1+\\dots+n_k = n} u_1^{n_1} \\dots u_k^{n_k},")]]

#text("thus for instance")

#align(center)[#tao-fit-display[#mitex("s_{(3,0)}(u_1,u_2) = u_1^3 + u_1^2 u_2 + u_1 u_2^2 + u_2^3.")]]

#text("Schur polyomials are ubiquitous in the algebraic combinatorics of “type ")#mi("{A}")#text(" objects” such as the symmetric group ")#mi("{S_k}")#text(", the general linear group ")#mi("{GL_k}")#text(", or the unitary group ")#mi("{U_k}")#text(". For instance, one can view ")#mi("{s_\\lambda}")#text(" as the character of an irreducible polynomial representation of ")#mi("{GL_k({\\bf C})}")#text(" associated with the partition ")#mi("{\\lambda}")#text(". However, we will not focus on these interpretations of Schur polynomials in this post.")

#text("This definition of Schur polynomials allows for a way to describe the polynomials recursively. If ")#mi("{k > 1}")#text(" and ")#mi("{T}")#text(" is a Young tableau of shape ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_k)}")#text(", taking values in ")#mi("{\\{1,\\dots,k\\}}")#text(", one can form a sub-tableau ")#mi("{T^{\\prime}}")#text(" of some shape ")#mi("{\\lambda^{\\prime} = (\\lambda^{\\prime}_1,\\dots,\\lambda^{\\prime}_{k-1})}")#text(" by removing all the appearances of ")#mi("{k}")#text(" (which, among other things, necessarily deletes the ")#mi("{k^{th}}")#text(" row). For instance, with ")#mi("{T}")#text(" as in the previous example, the sub-tableau ")#mi("{T^{\\prime}}")#text(" would be")

#align(center)[#align(center)[#box[#table(
columns: (auto, auto, auto, auto, ),
rows: 2,
align: (center, center, center, center,),
inset: (x: 0.2em, y: 0.1em), stroke: none,
table.cell(x: 0, y: 0, [#mi("\\displaystyle  1")]),
table.cell(x: 1, y: 0, [#mi("\\displaystyle  1")]),
table.cell(x: 2, y: 0, [#mi("\\displaystyle  1")]),
table.cell(x: 3, y: 0, [#mi("\\displaystyle  2")]),
table.vline(x: 0, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 1, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 2, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 3, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 4, start: 0, end: 1, stroke: 0.4pt),
table.cell(x: 0, y: 1, [#mi("\\displaystyle  2")]),
table.cell(x: 1, y: 1, [#mi("\\displaystyle  2")]),
table.cell(x: 2, y: 1, [#mi("\\displaystyle  2")]),
table.vline(x: 0, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 1, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 2, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 3, start: 1, end: 2, stroke: 0.4pt),
table.hline(y: 0, start: 0, end: 4, stroke: 0.4pt),
table.hline(y: 1, start: 0, end: 4, stroke: 0.4pt),
table.hline(y: 2, start: 0, end: 3, stroke: 0.4pt),
)]]]

#text("and the reduced partition ")#mi("{\\lambda^{\\prime}}")#text(" in this case is ")#mi("{(4,3)}")#text(". As Young tableaux are required to be strictly increasing down columns, we can see that the reduced partition ")#mi("{\\lambda^{\\prime}}")#text(" must ")#emph[#text("intersperse")]#text(" the original partition ")#mi("{\\lambda}")#text(" in the sense that ")#metadata(none) <tao-f7fdd21f0781ad4e8652>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lambda_{i+1} \\leq \\lambda^{\\prime}_i \\leq \\lambda_i")]]

#text(" for all ")#mi("{1 \\leq i \\leq k-1}")#text("; we denote this interspersion relation as ")#mi("{\\lambda^{\\prime} \\prec \\lambda}")#text(" (though we caution that this is ")#emph[#text("not")]#text(" intended to be a partial ordering). In the converse direction, if ")#mi("{\\lambda^{\\prime} \\prec \\lambda}")#text(" and ")#mi("{T^{\\prime}}")#text(" is a Young tableau with shape ")#mi("{\\lambda^{\\prime}}")#text(" with entries in ")#mi("{\\{1,\\dots,k-1\\}}")#text(", one can form a Young tableau ")#mi("{T}")#text(" with shape ")#mi("{\\lambda}")#text(" and entries in ")#mi("{\\{1,\\dots,k\\}}")#text(" by appending to ")#mi("{T^{\\prime}}")#text(" an entry of ")#mi("{k}")#text(" in all the boxes that appear in the ")#mi("{\\lambda}")#text(" shape but not the ")#mi("{\\lambda^{\\prime}}")#text(" shape. This one-to-one correspondence leads to the recursion ")#metadata(none) <tao-b7a5a17594a1fd4b9a35>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("s_\\lambda(u) = \\sum_{\\lambda^{\\prime} \\prec \\lambda} s_{\\lambda^{\\prime}}(u^{\\prime}) u_k^{\\left|\\lambda\\right| - \\left|\\lambda^{\\prime}\\right|}", block: true)]]

#text(" where ")#mi("{u = (u_1,\\dots,u_k)}")#text(", ")#mi("{u^{\\prime} = (u_1,\\dots,u_{k-1})}")#text(", and the size ")#tao-math("{\\left|\\lambda\\right|}", block: false)#text(" of a partition ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_k)}")#text(" is defined as ")#tao-math("{\\left|\\lambda\\right| := \\lambda_1 + \\dots + \\lambda_k}", block: false)#text(".")

#text("One can use this recursion ")#link(<tao-b7a5a17594a1fd4b9a35>)[#text("(2)")]#text(" to prove some further standard identities for Schur polynomials, such as the determinant identity ")#metadata(none) <tao-afac70e63187b00e8fc5>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("s_\\lambda(u) V(u) = \\det( u_i^{\\lambda_j+k-j} )_{1 \\leq i,j \\leq k}")]]

#text(" for ")#mi("{u=(u_1,\\dots,u_k)}")#text(", where ")#mi("{V(u)}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Vandermonde_matrix")[#text("Vandermonde determinant")]#text(" ")#metadata(none) <tao-970b1897af0abab6127d>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("V(u) := \\prod_{1 \\leq i < j \\leq k} (u_i - u_j),")]]

#text(" or the Jacobi-Trudi identity ")#metadata(none) <tao-4d6d9ac0752cd209cc3e>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("s_\\lambda(u) = \\det( h_{\\lambda_j - j + i}(u) )_{1 \\leq i,j \\leq k},")]]

#text(" with the convention that ")#mi("{h_d(u) = 0}")#text(" if ")#mi("{d}")#text(" is negative. Thus for instance")

#align(center)[#tao-fit-display[#mitex("s_{(1,1,0,\\dots,0)}(u) = h_1^2(u) - h_0(u) h_2(u) = \\sum_{1 \\leq i < j \\leq k} u_i u_j.")]]

#text("We review the (standard) derivation of these identities via ")#link(<tao-b7a5a17594a1fd4b9a35>)[#text("(2)")]#text(" below the fold. Among other things, these identities show that the Schur polynomials are symmetric, which is not immediately obvious from their definition.")

#text("One can also iterate ")#link(<tao-b7a5a17594a1fd4b9a35>)[#text("(2)")]#text(" to write ")#metadata(none) <tao-c922505f5fc0614bc253>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("s_\\lambda(u) = \\sum_{() = \\lambda^0 \\prec \\lambda^1 \\prec \\dots \\prec \\lambda^k = \\lambda} \\prod_{j=1}^k u_j^{\\left|\\lambda^j\\right| - \\left|\\lambda^{j-1}\\right|}", block: true)]]

#text(" where the sum is over all tuples ")#mi("{\\lambda^1,\\dots,\\lambda^k}")#text(", where each ")#mi("{\\lambda^j}")#text(" is a partition of length ")#mi("{j}")#text(" that intersperses the next partition ")#mi("{\\lambda^{j+1}}")#text(", with ")#mi("{\\lambda^k}")#text(" set equal to ")#mi("{\\lambda}")#text(". We will call such a tuple an ")#emph[#text("integral Gelfand-Tsetlin pattern")]#text(" based at ")#mi("{\\lambda}")#text(".")

#text("One can generalise ")#link(<tao-c922505f5fc0614bc253>)[#text("(6)")]#text(" by introducing the ")#link("https://en.wikipedia.org/wiki/Schur_polynomial#Skew_Schur_functions")[#text("skew Schur functions")]#text(" ")#metadata(none) <tao-d72ac18951688d0596cf>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("s_{\\lambda/\\mu}(u) := \\sum_{\\mu = \\lambda^i \\prec \\dots \\prec \\lambda^k = \\lambda} \\prod_{j=i+1}^k u_j^{\\left|\\lambda^j\\right| - \\left|\\lambda^{j-1}\\right|}", block: true)]]

#text(" for ")#mi("{u = (u_{i+1},\\dots,u_k)}")#text(", whenever ")#mi("{\\lambda}")#text(" is a partition of length ")#mi("{k}")#text(" and ")#mi("{\\mu}")#text(" a partition of length ")#mi("{i}")#text(" for some ")#mi("{0 \\leq i \\leq k}")#text(", thus the Schur polynomial ")#mi("{s_\\lambda}")#text(" is also the skew Schur polynomial ")#mi("{s_{\\lambda /()}}")#text(" with ")#mi("{i=0}")#text(". (One could relabel the variables here to be something like ")#mi("{(u_1,\\dots,u_{k-i})}")#text(" instead, but this labeling seems slightly more natural, particularly in view of identities such as ")#link(<tao-3086cf468ccca87cc784>)[#text("(8)")]#text(" below.)")

#text("By construction, we have the decomposition ")#metadata(none) <tao-3086cf468ccca87cc784>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("s_{\\lambda/\\nu}(u_{i+1},\\dots,u_k) = \\sum_\\mu s_{\\mu/\\nu}(u_{i+1},\\dots,u_j) s_{\\lambda/\\mu}(u_{j+1},\\dots,u_k)")]]

#text(" whenever ")#mi("{0 \\leq i \\leq j \\leq k}")#text(", and ")#mi("{\\nu, \\mu, \\lambda}")#text(" are partitions of lengths ")#mi("{i,j,k}")#text(" respectively. This gives another recursive way to understand Schur polynomials and skew Schur polynomials. For instance, one can use it to establish the generalised Jacobi-Trudi identity ")#metadata(none) <tao-8f2aefaf801aab020a67>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("s_{\\lambda/\\mu}(u) = \\det( h_{\\lambda_j - j - \\mu_i + i}(u) )_{1 \\leq i,j \\leq k},")]]

#text(" with the convention that ")#mi("{\\mu_i = 0}")#text(" for ")#mi("{i}")#text(" larger than the length of ")#mi("{\\mu}")#text("; we do this below the fold.")

#text("The Schur polynomials (and skew Schur polynomials) are “discretised” (or “quantised”) in the sense that their parameters ")#mi("{\\lambda, \\mu}")#text(" are required to be integer-valued, and their definition similarly involves summation over a discrete set. It turns out that there are “continuous” (or “classical”) analogues of these functions, in which the parameters ")#mi("{\\lambda,\\mu}")#text(" now take real values rather than integers, and are defined via integration rather than summation. One can view these continuous analogues as a “semiclassical limit” of their discrete counterparts, in a manner that can be made precise using the machinery of ")#link("https://en.wikipedia.org/wiki/Geometric_quantization")[#text("geometric quantisation")]#text(", but we will not do so here.")

#text("The continuous analogues can be defined as follows. Define a ")#emph[#text("real partition")]#text(" of length ")#mi("{k}")#text(" to be a tuple ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_k)}")#text(" where ")#mi("{\\lambda_1 \\geq \\dots \\geq \\lambda_k \\geq 0}")#text(" are now real numbers. We can define the relation ")#mi("{\\lambda^{\\prime} \\prec \\lambda}")#text(" of interspersion between a length ")#mi("{k-1}")#text(" real partition ")#mi("{\\lambda^{\\prime} = (\\lambda^{\\prime}_1,\\dots,\\lambda^{\\prime}_{k-1})}")#text(" and a length ")#mi("{k}")#text(" real partition ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_{k})}")#text(" precisely as before, by requiring that the inequalities ")#link(<tao-f7fdd21f0781ad4e8652>)[#text("(1)")]#text(" hold for all ")#mi("{1 \\leq i \\leq k-1}")#text(". We can then define the continuous Schur functions ")#mi("{S_\\lambda(x)}")#text(" for ")#mi("{x = (x_1,\\dots,x_k) \\in {\\bf R}^k}")#text(" recursively by defining")

#align(center)[#tao-fit-display[#mitex("S_{()}() = 1")]]

#text("and ")#metadata(none) <tao-3eda67d4ff702a1896a2>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("S_\\lambda(x) = \\int_{\\lambda^{\\prime} \\prec \\lambda} S_{\\lambda^{\\prime}}(x^{\\prime}) \\exp( (\\left|\\lambda\\right| - \\left|\\lambda^{\\prime}\\right|) x_k )", block: true)]]

#text(" for ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\lambda}")#text(" of length ")#mi("{k}")#text(", where ")#mi("{x^{\\prime} := (x_1,\\dots,x_{k-1})}")#text(" and the integral is with respect to ")#mi("{k-1}")#text("-dimensional Lebesgue measure, and ")#tao-math("{\\left|\\lambda\\right| = \\lambda_1 + \\dots + \\lambda_k}", block: false)#text(" as before. Thus for instance")

#align(center)[#tao-fit-display[#mitex("S_{(\\lambda_1)}(x_1) = \\exp( \\lambda_1 x_1 )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{(\\lambda_1,\\lambda_2)}(x_1,x_2) = \\int_{\\lambda_2}^{\\lambda_1} \\exp( \\lambda^{\\prime}_1 x_1 + (\\lambda_1+\\lambda_2-\\lambda^{\\prime}_1) x_2 )\\ d\\lambda^{\\prime}_1.")]]

#text("More generally, we can define the continuous skew Schur functions ")#mi("{S_{\\lambda/\\mu}(x)}")#text(" for ")#mi("{\\lambda}")#text(" of length ")#mi("{k}")#text(", ")#mi("{\\mu}")#text(" of length ")#mi("{j \\leq k}")#text(", and ")#mi("{x = (x_{j+1},\\dots,x_k) \\in {\\bf R}^{k-j}}")#text(" recursively by defining")

#align(center)[#tao-fit-display[#mitex("S_{\\mu/\\mu}() = 1")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("S_{\\lambda/\\mu}(x) = \\int_{\\lambda^{\\prime} \\prec \\lambda} S_{\\lambda^{\\prime}/\\mu}(x^{\\prime}) \\exp( (\\left|\\lambda\\right| - \\left|\\lambda^{\\prime}\\right|) x_k )", block: true)]]

#text("for ")#mi("{k > j}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#mitex("S_{(\\lambda_1,\\lambda_2,\\lambda_3)/(\\mu_1,\\mu_2)}(x_3) = 1_{\\lambda_3 \\leq \\mu_2 \\leq \\lambda_2 \\leq \\mu_1 \\leq \\lambda_1} \\exp( x_3 (\\lambda_1+\\lambda_2+\\lambda_3 - \\mu_1 - \\mu_2 ))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{(\\lambda_1,\\lambda_2,\\lambda_3)/(\\mu_1)}(x_2, x_3) = \\int_{\\lambda_2 \\leq \\lambda^{\\prime}_2 \\leq \\lambda_2, \\mu_1} \\int_{\\mu_1, \\lambda_2 \\leq \\lambda^{\\prime}_1 \\leq \\lambda_1}")]]

#align(center)[#tao-fit-display[#mitex("\\exp( x_2 (\\lambda^{\\prime}_1+\\lambda^{\\prime}_2 - \\mu_1) + x_3 (\\lambda_1+\\lambda_2+\\lambda_3 - \\lambda^{\\prime}_1 - \\lambda^{\\prime}_2))\\ d\\lambda^{\\prime}_1 d\\lambda^{\\prime}_2.")]]

#text("By expanding out the recursion, one obtains the analogue")

#align(center)[#tao-fit-display[#tao-math("S_\\lambda(x) = \\int_{\\lambda^1 \\prec \\dots \\prec \\lambda^k = \\lambda} \\exp( \\sum_{j=1}^k x_j (\\left|\\lambda^j\\right| - \\left|\\lambda^{j-1}\\right|))\\ d\\lambda^1 \\dots d\\lambda^{k-1},", block: true)]]

#text("of ")#link(<tao-c922505f5fc0614bc253>)[#text("(6)")]#text(", and more generally one has")

#align(center)[#tao-fit-display[#tao-math("S_{\\lambda/\\mu}(x) = \\int_{\\mu = \\lambda^i \\prec \\dots \\prec \\lambda^k = \\lambda} \\exp( \\sum_{j=i+1}^k x_j (\\left|\\lambda^j\\right| - \\left|\\lambda^{j-1}\\right|))\\ d\\lambda^{i+1} \\dots d\\lambda^{k-1}.", block: true)]]

#text("We will call the tuples ")#mi("{(\\lambda^1,\\dots,\\lambda^k)}")#text(" in the first integral ")#emph[#text("real Gelfand-Tsetlin patterns")]#text(" based at ")#mi("{\\lambda}")#text(". The analogue of ")#link(<tao-3086cf468ccca87cc784>)[#text("(8)")]#text(" is then")

#align(center)[#tao-fit-display[#mitex("S_{\\lambda/\\nu}(x_{i+1},\\dots,x_k) = \\int S_{\\mu/\\nu}(x_{i+1},\\dots,x_j) S_{\\lambda/\\mu}(x_{j+1},\\dots,x_k)\\ d\\mu")]]

#text("where the integral is over all real partitions ")#mi("{\\mu}")#text(" of length ")#mi("{j}")#text(", with Lebesgue measure.")

#text("By approximating various integrals by their Riemann sums, one can relate the continuous Schur functions to their discrete counterparts by the limiting formula ")#metadata(none) <tao-55ea09e5715d0a8d9d94>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("N^{-k(k-1)/2} s_{\\lfloor N \\lambda \\rfloor}( \\exp[ x/N ] ) \\rightarrow S_\\lambda(x)")]]

#text(" as ")#mi("{N \\rightarrow \\infty}")#text(" for any length ")#mi("{k}")#text(" real partition ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_k)}")#text(" and any ")#mi("{x = (x_1,\\dots,x_k) \\in {\\bf R}^k}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\lfloor N \\lambda \\rfloor := ( \\lfloor N \\lambda_1 \\rfloor, \\dots, \\lfloor N \\lambda_k \\rfloor )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\exp[x/N] := (\\exp(x_1/N), \\dots, \\exp(x_k/N)).")]]

#text("More generally, one has")

#align(center)[#tao-fit-display[#mitex("N^{j(j-1)/2-k(k-1)/2} s_{\\lfloor N \\lambda \\rfloor / \\lfloor N \\mu \\rfloor}( \\exp[ x/N ] ) \\rightarrow S_{\\lambda/\\mu}(x)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(" for any length ")#mi("{k}")#text(" real partition ")#mi("{\\lambda}")#text(", any length ")#mi("{j}")#text(" real partition ")#mi("{\\mu}")#text(" with ")#mi("{0 \\leq j \\leq k}")#text(", and any ")#mi("{x = (x_{j+1},\\dots,x_k) \\in {\\bf R}^{k-j}}")#text(".")

#text("As a consequence of these limiting formulae, one expects all of the discrete identities above to have continuous counterparts. This is indeed the case; below the fold we shall prove the discrete and continuous identities in parallel. These are not new results by any means, but I was not able to locate a good place in the literature where they are explicitly written down, so I thought I would try to do so here (primarily for my own internal reference, but perhaps the calculations will be worthwhile to some others also).")

#metadata(none) <tao-d894224f9d31f9747ff7>

#heading(level: 1)[#strong[#text(" — 1. Proofs of identities — ")]]

#text("We first prove the determinant identity ")#link(<tao-afac70e63187b00e8fc5>)[#text("(3)")]#text(", by induction on ")#mi("{k}")#text(". The case ")#mi("{k=0}")#text(" is trivial (one could also use ")#mi("{k=1}")#text(" as the base case if desired); now suppose ")#mi("{k \\geq 1}")#text(" and the claim has already been proven for ")#mi("{k-1}")#text(". Writing ")#mi("{u = (u^{\\prime},u_k)}")#text(" with ")#mi("{u^{\\prime} = (u_1,\\dots,u_{k-1})}")#text(", we have from ")#link(<tao-970b1897af0abab6127d>)[#text("(4)")]#text(" that ")#metadata(none) <tao-09513ba78b1c2cbeae78>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("V(u) = V(u^{\\prime}) \\prod_{i=1}^{k-1} (u_i - u_k)")]]

#text(" so by ")#link(<tao-b7a5a17594a1fd4b9a35>)[#text("(2)")]#text(" it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\lambda^{\\prime} \\prec \\lambda} \\det( u_i^{\\lambda^{\\prime}_j+k-1-j} )_{1 \\leq i,j \\leq k-1} u_k^{\\left|\\lambda\\right| - \\left|\\lambda^{\\prime}\\right|} \\prod_{i=1}^{k-1} (u_i - u_k) = \\det( u_i^{\\lambda_j+k-j} )_{1 \\leq i,j \\leq k}.", block: true)]]

#text("By continuity we may assume ")#mi("{u_k}")#text(" is non-zero. Both sides are homogeneous in ")#mi("{u}")#text(" of degree ")#tao-math("{\\left|\\lambda\\right|+k(k-1)/2}", block: false)#text(", so without loss of generality we may normalise ")#mi("{u_k=1}")#text(", thus we need to show ")#metadata(none) <tao-4ebde790877e2f92305c>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{\\lambda^{\\prime} \\prec \\lambda} \\det( u_i^{\\lambda^{\\prime}_j+k-1-j} )_{1 \\leq i,j \\leq k-1} \\prod_{i=1}^{k-1} (u_i - 1) = \\det( u_i^{\\lambda_j+k-j} )_{1 \\leq i,j \\leq k}")]]

#text(" where the bottom row of the matrix on the right-hand side consists entirely of ")#mi("{1}")#text("‘s.")

#text("The sum ")#mi("{\\sum_{\\lambda^{\\prime} \\prec \\lambda}}")#text(" can be factored into ")#mi("{k-1}")#text(" sums ")#mi("{\\sum_{\\lambda_{j+1} \\leq \\lambda^{\\prime}_j \\leq \\lambda_j}}")#text(" for ")#mi("{j=1,\\dots,k-1}")#text(". By the multilinearity of the determinant, the left-hand side of ")#link(<tao-4ebde790877e2f92305c>)[#text("(13)")]#text(" may thus be written as")

#align(center)[#tao-fit-display[#mitex("\\det( (u_i-1) \\sum_{\\lambda_{j+1} \\leq \\lambda^{\\prime}_j \\leq \\lambda_j} u_i^{\\lambda^{\\prime}_j+k-1-j} )_{1 \\leq i,j \\leq k-1}.")]]

#text("This telescopes to")

#align(center)[#tao-fit-display[#mitex("\\det( u_i^{\\lambda_{j+1}+k-(j+1)} - u_i^{\\lambda_j+k-j} )_{1 \\leq i,j \\leq k-1}.")]]

#text("By multilinearity, this expands out to an alternating sum of ")#mi("{2^{k-1}}")#text(" terms, however all but ")#mi("{k}")#text(" of these terms will vanish due to having two columns identical. The ")#mi("{k}")#text(" terms that survive are of the form")

#align(center)[#tao-fit-display[#mitex("(-1)^{a-1} \\det( u_i^{\\lambda_j+k-j} )_{1 \\leq i \\leq k-1; j \\in \\{1,\\dots,k\\} \\backslash \\{a\\}}")]]

#text("for ")#mi("{a=1,\\dots,k}")#text(" (where we enumerate ")#mi("{\\{1,\\dots,k\\} \\backslash \\{a\\}}")#text(" in increasing order); but this sums to ")#mi("{\\det( u_i^{\\lambda_j+k-j} )_{1 \\leq i,j \\leq k}}")#text(" after performing cofactor expansion on the bottom row of the latter determinant. This proves ")#link(<tao-afac70e63187b00e8fc5>)[#text("(3)")]#text(".")

#text("The continuous analogue of ")#link(<tao-afac70e63187b00e8fc5>)[#text("(3)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("S_\\lambda(x) V(x) = \\det( \\exp( x_i \\lambda_j ) )_{1 \\leq i,j \\leq k}")]]

#text("and can either be proven from ")#link(<tao-afac70e63187b00e8fc5>)[#text("(3)")]#text(" and ")#link(<tao-55ea09e5715d0a8d9d94>)[#text("(11)")]#text(", or by mimicking the proof of ")#link(<tao-afac70e63187b00e8fc5>)[#text("(3)")]#text(" (replacing sums by integrals). We do the latter, leaving the former as an exercise for the reader. (This identity is also discussed at ")#link("https://mathoverflow.net/questions/277655/reference-for-exponential-vandermonde-determinant-identity")[#text("this MathOverflow question")]#text(" of mine, where it was noted that it essentially appears in ")#link("https://arxiv.org/abs/hep-th/9209083")[#text("this paper of Shatashvili")]#text("; Apoorva Khare and I also used it in ")#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/")[#text("this recent paper")]#text(".) Again we induct on ")#mi("{k}")#text("; the ")#mi("{k=0}")#text(" case is trivial, so suppose ")#mi("{k \\geq 1}")#text(" and the claim has already been proven for ")#mi("{k-1}")#text(". Since")

#align(center)[#tao-fit-display[#tao-math("S_\\lambda(x) = \\int_{\\lambda^{\\prime} \\prec \\lambda} S_{\\lambda^{\\prime}}(x^{\\prime}) \\exp( x_k (\\left|\\lambda\\right| - \\left|\\lambda^{\\prime}\\right|) )\\ d\\lambda^{\\prime}", block: true)]]

#text("it will suffice by ")#link(<tao-3eda67d4ff702a1896a2>)[#text("(10)")]#text(" and ")#link(<tao-09513ba78b1c2cbeae78>)[#text("(12)")]#text(" to prove that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\lambda^{\\prime} \\prec \\lambda} \\det( \\exp( x_i \\lambda^{\\prime}_j ) )_{1 \\leq i,j \\leq k-1} \\exp( x_k (\\left|\\lambda\\right| - \\left|\\lambda^{\\prime}\\right|)) \\prod_{i=1}^{k-1} (x_k - x_i)\\ d\\lambda^{\\prime}", block: true)]]

#align(center)[#tao-fit-display[#mitex("= \\det( \\exp( x_i \\lambda_j ) )_{1 \\leq i,j \\leq k}.")]]

#text("If we shift all of the ")#mi("{x_i}")#text(" by the same shift ")#mi("{h}")#text(", both sides of this identity multiply by ")#tao-math("{\\exp( h \\left|\\lambda\\right| )}", block: false)#text(", so we may normalise ")#mi("{x_k=0}")#text(". Our task is now to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\lambda^{\\prime} \\prec \\lambda} \\det( \\exp( x_i \\lambda^{\\prime}_j ) )_{1 \\leq i,j \\leq k-1} \\prod_{i=1}^{k-1} (- x_i)\\ d\\lambda^{\\prime}")]]

#metadata(none) <tao-05806fafe637250ec09d>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("= \\det( \\exp( x_i \\lambda_j ) )_{1 \\leq i,j \\leq k},")]]

#text(" where the matrix on the right-hand side has a bottom row consisting entirely of ")#mi("{1}")#text("s.")

#text("The integral ")#mi("{\\int_{\\lambda^{\\prime} \\prec \\lambda}\\ d\\lambda^{\\prime}}")#text(" can be factored into ")#mi("{k-1}")#text(" integrals ")#mi("{\\int_{\\lambda_{j+1}}^{\\lambda_j}\\ d\\lambda^{\\prime}_j}")#text(" for ")#mi("{j=1,\\dots,k-1}")#text(". By the multilinearity of the determinant, the left-hand side of ")#link(<tao-05806fafe637250ec09d>)[#text("(14)")]#text(" may thus be written as")

#align(center)[#tao-fit-display[#mitex("\\det( -x_i \\int_{\\lambda_{j+1}}^{\\lambda_j} \\exp( x_i \\lambda^{\\prime}_j )\\ d\\lambda^{\\prime}_j )_{1 \\leq i,j \\leq k-1}.")]]

#text("By the fundamental theorem of calculus, this evaluates to")

#align(center)[#tao-fit-display[#mitex("\\det( \\exp( x_i \\lambda_j ) - \\exp( x_i \\lambda_{j+1} ) )_{1 \\leq i,j \\leq k-1}.")]]

#text("Again, this expands to ")#mi("{2^{k-1}}")#text(" terms, all but ")#mi("{k}")#text(" of which vanish, and the remaining ")#mi("{k}")#text(" terms form the cofactor expansion of the right-hand side of ")#link(<tao-05806fafe637250ec09d>)[#text("(14)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Comparing ")#link(<tao-4ebde790877e2f92305c>)[#text("(13)")]#text(" with ")#link(<tao-05806fafe637250ec09d>)[#text("(14)")]#text(" we obtain a relation between the discrete and continuous Schur functions, namely that")

#align(center)[#tao-fit-display[#mitex("s_\\lambda(\\exp[x]) V(\\exp[x]) = S_{(\\lambda_1+k-1,\\dots,\\lambda_k)}(x) V(x)")]]

#text("for any integer partition ")#mi("{\\lambda}")#text(" and any ")#mi("{x \\in {\\bf R}^k}")#text(". One can use this identity to obtain an alternate proof of the limiting relation ")#link(<tao-55ea09e5715d0a8d9d94>)[#text("(11)")]#text(".")
]

#text("Now we turn to ")#link(<tao-4d6d9ac0752cd209cc3e>)[#text("(5)")]#text(", which can be proven by a similar argument to ")#link(<tao-afac70e63187b00e8fc5>)[#text("(3)")]#text(". Again, the base case ")#mi("{k=0}")#text(" (or ")#mi("{k=1}")#text(", if one prefers) is trivial, so suppose ")#mi("{k \\geq 1}")#text(" and the claim has already been proven for ")#mi("{k-1}")#text(". By ")#link(<tao-b7a5a17594a1fd4b9a35>)[#text("(2)")]#text(" it will suffice to show that ")#metadata(none) <tao-634768dae1474506e4bf>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\sum_{\\lambda^{\\prime} \\prec \\lambda} \\det( h_{\\lambda^{\\prime}_j - j + i}(u^{\\prime}) )_{1 \\leq i,j \\leq k-1} u_k^{\\left|\\lambda\\right|-\\left|\\lambda^{\\prime}\\right|} = \\det( h_{\\lambda_j - j + i}(u) )_{1 \\leq i,j \\leq k}.", block: true)]]

#text(" Both sides are homogeneous of degree ")#tao-math("{\\left|\\lambda\\right|}", block: false)#text(", so as before we may normalise ")#mi("{u_k=1}")#text(". Factoring the left-hand side summation into ")#mi("{k-1}")#text(" summations and using multilinearity as before, the left-hand side may be written as")

#align(center)[#tao-fit-display[#mitex("\\det( \\sum_{\\lambda_{j+1} \\leq \\lambda^{\\prime}_j \\leq \\lambda_j} h_{\\lambda^{\\prime}_j - j + i}(u^{\\prime}) )_{1 \\leq i,j \\leq k-1}.")]]

#text("Now one observes the identities")

#align(center)[#tao-fit-display[#mitex("h_{\\lambda_j - j + i}(u) = \\sum_{\\lambda^{\\prime}_j \\leq \\lambda_j} h_{\\lambda^{\\prime}_j - j + i}(u^{\\prime})")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("h_{\\lambda_{j+1} - (j+1) + i}(u) = \\sum_{\\lambda^{\\prime}_j < \\lambda_{j+1}} h_{\\lambda^{\\prime}_j - j + i}(u^{\\prime})")]]

#text("(where ")#mi("{\\lambda^{\\prime}_j}")#text(" is understood to range over the integers), hence on subtracting")

#align(center)[#tao-fit-display[#mitex("h_{\\lambda_j - j+i}(u) - h_{\\lambda_{j+1} - (j+1) + i}(u) = \\sum_{\\lambda_{j+1} \\leq \\lambda^{\\prime}_j \\leq \\lambda_j} h_{\\lambda^{\\prime}_j - j + i}(u^{\\prime})")]]

#text("and so the above determinant may be written as")

#align(center)[#tao-fit-display[#mitex("\\det( h_{\\lambda_j - j+i}(u) - h_{\\lambda_{j+1} - (j+1) + i}(u) )_{1 \\leq i,j \\leq k-1}.")]]

#text("Again, this expands into ")#mi("{2^{k-1}}")#text(" terms, all but ")#mi("{k}")#text(" of which vanish, and which can be collected by cofactor expansion to become the determinant of the ")#mi("{k \\times k}")#text(" matrix whose top ")#mi("{k-1}")#text(" rows are ")#mi("{(h_{\\lambda_j - j+i}(u))_{1 \\leq i \\leq k-1; 1 \\leq j \\leq k}}")#text(", and whose bottom row ")#mi("{(1)_{1 \\leq j \\leq k}}")#text(" consists entirely of ")#mi("{1}")#text("s.")

#text("Now we use the identity")

#align(center)[#tao-fit-display[#tao-math("1 = \\sum_{S \\subset \\{1,\\dots,k-1\\}} (-1)^{\\left|S\\right|} h_{d-\\left|S\\right|}(u) \\prod_{i \\in S} u_i", block: true)]]

#text("for any ")#mi("{d \\geq 0}")#text(". To verify this identity, we observe that the ")#mi("{u^n}")#text(" coefficient of the right-hand side is equal to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{S \\subset \\{1 \\leq i \\leq k-1: n_i \\neq 0\\}} (-1)^{\\left|S\\right|}", block: true)]]

#text("if ")#tao-math("{\\left|n\\right| \\leq d}", block: false)#text(", and zero otherwise; but from the binomial theorem we see that this coefficient is ")#mi("{1}")#text(" when ")#mi("{n=0}")#text(" and ")#mi("{0}")#text(" otherwise, giving the claim. Using this identity with ")#mi("{d = \\lambda_j - j + k}")#text(", we can write the bottom row ")#mi("{(1)_{1 \\leq j \\leq k}}")#text(" as the sum of ")#mi("{(h_{\\lambda_j-j+k}(u))}")#text(" plus a linear combination of ")#mi("{(h_{\\lambda_j-j+i}(u))}")#text(" for ")#mi("{i=1,\\dots,k-1}")#text(", so after some row operations we conclude ")#link(<tao-634768dae1474506e4bf>)[#text("(15)")]#text(". The generalised Jacobi-Trudi identity ")#link(<tao-8f2aefaf801aab020a67>)[#text("(9)")]#text(" is proven similarly (keeping ")#mi("{\\mu}")#text(" fixed, and inducting on the length of ")#mi("{\\lambda}")#text("); we leave this to the interested reader.")

#text("The continuous analogue of the Jacobi-Trudi identity ")#link(<tao-4d6d9ac0752cd209cc3e>)[#text("(5)")]#text(" is a little less intuitive. The analogue of the complete homogeneous polynomials")

#align(center)[#tao-fit-display[#mitex("h_n(u_1,\\dots,u_k) = \\sum_{n_1+\\dots+n_k=n: n_1,\\dots,n_k \\geq 0} u_1^{n_1} \\dots u_k^{n_k}")]]

#text("for ")#mi("{n \\geq 0}")#text(" an integer, will be the functions")

#align(center)[#tao-fit-display[#mitex("H_t(x_1,\\dots,x_k) := \\int_{t_1+\\dots+t_k=t: t_1,\\dots,t_k \\geq 0} \\exp( t_1 x_1 + \\dots + t_k x_k)\\ dt_1 \\dots dt_{k-1}")]]

#text("for ")#mi("{t \\geq 0}")#text(" a real number. Thus for example ")#mi("{H_t(x) = \\frac{\\exp(tx) - 1}{x}}")#text(" when ")#mi("{k=1}")#text(" and ")#mi("{t \\geq 0}")#text(". By rescaling one may write")

#align(center)[#tao-fit-display[#mitex("H_t(x_1,\\dots,x_k)")]]

#align(center)[#tao-fit-display[#mitex("= t^{k-1} \\int_{t_1+\\dots+t_k=1: t_1,\\dots,t_k \\geq 0} \\exp( t_1 t x_1 + \\dots + t_k t x_k)\\ dt_1 \\dots dt_{k-1},")]]

#text("at which point it is clear that these expressions are smooth in ")#mi("{t}")#text(" for any ")#mi("{t \\geq 0}")#text(", so we may form derivatives ")#mi("{H^{(j)}_t(x) = \\frac{d^j}{dt^j} H_t(x)}")#text(" for any non-negative integer ")#mi("{j}")#text(" and any ")#mi("{t \\geq 0}")#text("; here our differentiation will always be in the ")#mi("{t}")#text(" variable rather than the ")#mi("{x}")#text(" variables. The analogue of ")#link(<tao-4d6d9ac0752cd209cc3e>)[#text("(5)")]#text(" is then ")#metadata(none) <tao-9148a951ce9200b16d4b>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("S_\\lambda(x) = \\det( H^{(i-1)}_{\\lambda_j}(x) )_{1 \\leq i,j \\leq k},")]]

#text(" thus for instance")

#align(center)[#tao-fit-display[#mitex("S_{(\\lambda_1)}(x_1) = H_{\\lambda_1}(x_1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{(\\lambda_1,\\lambda_2)}(x_1,x_2) = H_{\\lambda_1}(x_1,x_2) H^{(1)}_{\\lambda_2}(x_1,x_2) - H_{\\lambda_2}(x_1,x_2) H^{(1)}_{\\lambda_1}(x_1,x_2)")]]

#text("and so forth.")

#text("As before, we may prove ")#link(<tao-9148a951ce9200b16d4b>)[#text("(16)")]#text(" by induction on ")#mi("{k}")#text(". The cases ")#mi("{k=0,1}")#text(" are easy, so let us suppose ")#mi("{k \\geq 2}")#text(" and that the claim already holds for ")#mi("{k-1}")#text(" (actually the inductive argument will also work for ")#mi("{k=1}")#text(" if one pays careful attention to the conventions). By ")#link(<tao-3eda67d4ff702a1896a2>)[#text("(10)")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\lambda^{\\prime} \\prec \\lambda} \\det( H^{(i-1)}_{\\lambda^{\\prime}_j}(x^{\\prime}) )_{1 \\leq i,j \\leq k-1} \\exp(x_k (\\left|\\lambda\\right|-\\left|\\lambda^{\\prime}\\right|))\\ d\\lambda^{\\prime}", block: true)]]

#metadata(none) <tao-e46b872ecbe3732bf16e>



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("= \\det( H^{(i-1)}_{\\lambda_j}(x) )_{1 \\leq i,j \\leq k}")]]

#text(" whenever ")#mi("{x = (x_1,\\dots,x_k) \\in {\\bf R}^k}")#text(", ")#mi("{\\lambda}")#text(" is a real partition of length ")#mi("{k}")#text(", and ")#mi("{x^{\\prime} := (x_1,\\dots,x_{k-1})}")#text(". Shifting all the ")#mi("{x_j}")#text(" by ")#mi("{h}")#text(" will multiply each ")#mi("{H_t(x)}")#text(" by ")#mi("{\\exp( ht)}")#text(", and (after some application of the Leibniz rule and row operations) can be seen to multiply both sides here by ")#tao-math("{\\exp(h\\left|\\lambda\\right|)}", block: false)#text("; thus we may normalise ")#mi("{x_k=0}")#text(". We can then factor the integral and use multilinearity of the determinant to write the left-hand side of ")#link(<tao-e46b872ecbe3732bf16e>)[#text("(17)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\det( \\int_{\\lambda_{j+1}}^{\\lambda_j} H^{(i-1)}_{\\lambda^{\\prime}_j}(x^{\\prime})\\ d\\lambda^{\\prime}_j )_{1 \\leq i,j \\leq k-1}.")]]

#text("From construction we see that")

#align(center)[#tao-fit-display[#mitex("H_t(x) = \\int_0^t H_{t^{\\prime}}(x^{\\prime})\\ dt^{\\prime}")]]

#text("for any ")#mi("{t \\geq 0}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("H_{t_1}(x) - H_{t_2}(x) = \\int_{t_1}^{t_2} H_t(x^{\\prime})\\ dt")]]

#text("for any ")#mi("{t_2 \\geq t_1 \\geq 0}")#text("; actually with the convention that ")#mi("{H_t = 0}")#text(" for negative ")#mi("{t}")#text(", this identity holds for all ")#mi("{t_2 \\geq t_1}")#text(". Shifting ")#mi("{t_1,t_2,t}")#text(" by ")#mi("{h}")#text(" and then differentiating repeatedly at ")#mi("{h=0}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("H^{(i-1)}_{t_1}(x) - H^{(i-1)}_{t_2}(x) = \\int_{t_1}^{t_2} H^{(i-1)}_t(x^{\\prime})\\ dt")]]

#text("for any natural number ")#mi("{i}")#text(". Thus we can rewrite the preceding determinant as")

#align(center)[#tao-fit-display[#mitex("\\det( H^{(i-1)}_{\\lambda_j}(x) - H^{(i-1)}_{\\lambda_{j+1}}(x) )_{1 \\leq i,j \\leq k-1}.")]]

#text("Performing the now familiar maneuvre of expanding out into ")#mi("{2^{k-1}}")#text(" terms, observing that all but ")#mi("{k}")#text(" of them vanish, and interpretating the surviving terms as cofactors, this is the determinant of the ")#mi("{k \\times k}")#text(" matrix whose top ")#mi("{k-1}")#text(" rows are ")#mi("{( H^{(i-1)}_{\\lambda_j}(x))_{1 \\leq i \\leq k-1; 1 \\leq j \\leq k}}")#text(", and whose bottom row is ")#mi("{(1)_{1 \\leq j \\leq k}}")#text(".")

#text("Next, we observe from definition that")

#align(center)[#tao-fit-display[#mitex("H_t(x_1,\\dots,x_k) = \\int_0^t H_{t^{\\prime}}(x_2,\\dots,x_k) \\exp( (t-t^{\\prime}) x_1 )\\ dt^{\\prime}")]]

#text("for any ")#mi("{t \\geq 0}")#text(" and ")#mi("{(x_1,\\dots,x_k) \\in {\\bf R}^k}")#text(", and hence by the fundamental theorem of calculus")

#align(center)[#tao-fit-display[#mitex("(\\frac{d}{dt} - x_1) H_t(x_1,\\dots,x_k) = H_t(x_2,\\dots,x_k).")]]

#text("Iterating this identity we conclude that")

#align(center)[#tao-fit-display[#mitex("(\\frac{d}{dt}-x_{k-1}) \\dots (\\frac{d}{dt}-x_1) H_t(x_1,\\dots,x_k) = H_t(x_k)")]]

#text("and in particular when ")#mi("{x_k=0}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("(\\frac{d}{dt}-x_{k-1}) \\dots (\\frac{d}{dt}-x_1) H_t(x) = 1.")]]

#text("Thus we can write ")#mi("{1}")#text(" as ")#mi("{H^{(k-1)}_t(x)}")#text(" plus a linear combination of the ")#mi("{H^{(i-1)}_t(x)}")#text(" for ")#mi("{i=1,\\dots,k-1}")#text(", where the coefficients are independent of ")#mi("{t}")#text(". This allows us to write the bottom row ")#mi("{(1)_{1 \\leq j \\leq k}}")#text(" as ")#mi("{(H^{(k-1)}_{\\lambda_j}(x))_{1 \\leq j \\leq k}}")#text(" plus a linear combination of the ")#mi("{(H^{(i-1)}_{\\lambda_j}(x))_{1 \\leq j \\leq k}}")#text(" for ")#mi("{i=1,\\dots,k}")#text(", and ")#link(<tao-e46b872ecbe3732bf16e>)[#text("(17)")]#text(" follows.")

#text("A similar argument gives the more general Jacobi-Trudi identity")

#align(center)[#tao-fit-display[#mitex("S_{\\lambda/\\mu}(x) = \\det( ( H_{\\lambda_j-\\mu_i}(x) )_{1 \\leq j \\leq k; 1 \\leq i \\leq k^{\\prime}}, (H^{(i-1)}_{\\lambda_j}(x))_{1 \\leq j \\leq k; 1 \\leq i \\leq k-k^{\\prime}} ),")]]

#text("whenever ")#mi("{\\lambda}")#text(" is a real partition of length ")#mi("{k}")#text(", ")#mi("{\\mu}")#text(" is a real partition of length ")#mi("{0 \\leq k^{\\prime} \\leq k}")#text(", ")#mi("{x \\in {\\bf R}^k}")#text(", and one adopts the convention that ")#mi("{H_t}")#text(" (and its first ")#mi("{k-1}")#text(" derivatives) vanish for ")#mi("{t < 0}")#text(". Thus for instance")

#tao-aligned(keep: true)[


#tao-math("S_{(\\lambda_1,\\lambda_2)/(\\mu_1)}(x_2)  & = \\det \\begin{pmatrix} H_{\\lambda_1-\\mu_1}(x_2) & H_{\\lambda_1}(x_2) \\\\ H_{\\lambda_2 - \\mu_1}(x_2) & H_{\\lambda_2}(x_2) \\end{pmatrix},", block: true)



#tao-math("S_{(\\lambda_1,\\lambda_2,\\lambda_3)/(\\mu_1)}(x_2,x_3)  & = \\det \\begin{pmatrix} H_{\\lambda_1-\\mu_1}(x_2,x_3) & H_{\\lambda_1}(x_2,x_3) & H^{(1)}_{\\lambda_1}(x_2,x_3) \\\\ H_{\\lambda_2 - \\mu_1}(x_2,x_3) & H_{\\lambda_2}(x_2,x_3) & H^{(1)}_{\\lambda_2}(x_2,x_3) \\\\ H_{\\lambda_3 - \\mu_1}(x_2,x_3) & H_{\\lambda_3}(x_2,x_3) & H^{(1)}_{\\lambda_3}(x_2,x_3) \\end{pmatrix},", block: true)
]

#text("and so forth.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" If ")#mi("{\\lambda,\\mu}")#text(" are real partitions of length ")#mi("{k}")#text(" with positive entries, and ")#mi("{k^{\\prime} \\geq k}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\det( H_{\\lambda_i-\\mu_j}(x))_{1 \\leq i,j \\leq k} = \\lim_{\\nu \\rightarrow 0} \\frac{1}{V(\\nu)} S_{(\\lambda,\\nu)/\\mu}(x)")]]

#text("for any ")#mi("{x \\in {\\bf R}^{k^{\\prime}}}")#text(", where ")#mi("{\\nu}")#text(" ranges over real partitions of length ")#mi("{k^{\\prime}-k}")#text(" with distinct entries, and ")#mi("{(\\lambda,\\nu)}")#text(" is the length ")#mi("{k^{\\prime}}")#text(" partition formed by concatenating ")#mi("{\\lambda}")#text(" and ")#mi("{\\nu}")#text(" (this will also be a partition if ")#mi("{\\nu}")#text(" is sufficiently small).")
]

#text("(")#emph[#text("Sep 14:")]#text(" updated with several suggestions and corrections supplied by Darij Grinberg.)")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/512fe37b9e03f3fe88e5d6008893bca0dbeab7e1cb9b63a3284f0563525b9113-7664f4a17cee975b55badddca5324d28e7a9b5fd8c781e28e3fd12a9d4dd18f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-485916")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2017")])]

#text("Is this related to representation theory of ")#mi("S_n")#text(" where ")#mi("n\\in\\Bbb R")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-485922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2017")])]

#text("The way I think of it is that the Schur polynomials on ")#mi("k")#text(" variables describe the representation theory (or quantum theory) of ")#mi("GL_k")#text(" (or the irreducible representations thereof), and the continuous Schur functions on ")#mi("k")#text(" variables describe the symplectic geometry (or classical theory) of ")#mi("GL_k")#text(" (or of the coadjoint orbits thereof). In both cases the number of variables remains fixed. On the representation theory side, the symmetric group ")#mi("S_k")#text(" is connected to the ")#mi("GL_k")#text(" theory by ")#link("https://en.wikipedia.org/wiki/Schur%E2%80%93Weyl_duality")[#text("Schur-Weyl duality")]#text(". I’m not completely sure what the corresponding symplectic connection is (maybe it is just that the symmetric group is the Weyl group of the general linear group?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a861b523fdb5071ea2d4a76fc38e1e600a3ba2bd97dce963341b3770c82a2e-f09146c65c3fa56f5cfde78a2d6c10c19270ab040979ff9bf0dfd539cba72163.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486268")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2017")])]

#text("In fact Schur-Weyl connects S_n to GL_k where n is not equal to k. Instead n is analogous to the sum of the lambdas. So if there existed re-variable symmetric groups they might be relevant with fixed k and real-valued lambda, as the letter a suggested. But I don’t think it is possible to define these groups.")

#text("In particular this might not be very related to the Weyl group, as that works only when n=k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2017")])]

#text("Good point! I carelessly assumed that there had to be a connection between Schur-Weyl duality and the Weyl group due to the appearance of Weyl’s name in both, but I should have looked into this a bit more carefully.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j.c.")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-485938")[#strong[#text("j.c.")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")])]

#text("Is there any sensible way to take ")#mi("k\\rightarrow\\infty")#text("? I have in mind (very vaguely) the limit shapes for random Young diagrams.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486110")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2017")])]

#text("Good question! I think there should be something on the continuous side, namely finding the limiting shape of a Gelfand-Tsetlin pattern chosen uniformly at random in the limit ")#mi("k \\to \\infty")#text(", assuming the distribution of the base ")#mi("\\lambda_1, \\dots, \\lambda_k")#text(" converges to a limit. This shape should be consistent with the free convolution that shows up in the limiting distribution of sums of random Hermitian matrices with spectrum converging to a given limit. Curiously I could not find any literature on this though – there is certainly literature on random standard Young tableau or random Young shapes with the Plancherel distribution, but this isn’t quite the right setup for what is needed here. I might think about it further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8dae2130c19f0c2ede1cb1e109d015e72678bdf5b2c01c1d1a9519bdfaf081f-d7aff46eae90246e4ba326de0b0c968bea0d9a9955593aa0fcfee379fde1b32f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadim Gorin")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486905")[#strong[#text("Vadim Gorin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2017")])]

#text("On the discrete side, the uniformly random GT-patterns with fixed top row (or base) as k->\\infty are studied in details in arXiv:1202.3901, arXiv:1206.5123, arXiv:1311.5780, arXiv:1604.01110 by two different approaches. The results in the continuous setting can be obtained from the discrete ones by a degeneration (all the methods also survive in this degeneration). There was also one earlier result directly in the continuous setting, which appeared before it was understood that the analysis for the discrete is possible, see arXiv:1105.1272")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce038d3dbe37deaa5277dd780a13b0e4bae4c8cc08a6ad0f5ddeaade6bbfc11c-a8da28b66abeb71cbccf1afa520bb7cbaaf5dc3ce7519baf04046884fa89333b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea petrache")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-485960")[#strong[#text("mircea petrache")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2017")])]

#text("This is pretty fun to learn! ..One typo perhaps: I have the impression that ")#mi("s_{(3,0,0)}")#text(" appearing above, would it rather be a ")#mi("s_{(3,0)}")#text("?")

#text("..Also I was wondering: can one go on with this process of generalization beyond the reals?")

#text("E.g. one could take the ")#mi("\\lambda_i")#text(" to be elements of a (perhaps rooted) metric tree.")

#text("Then there is still an ordering available on a fixed tree, and so one would seem to be able to formulate all the statements at least.. Maybe also the formulas could then generalize to that case too, in versions parameterized by the tree has chosen (a special case of which is ")#mi("\\mathbb R")#text("), which then gets basically the role of enriching the combinatorics..")

#emph[#text("[Corrected, thanks. There are certainly a large number of variants and generalisations of Young tableaux and their associated polynomials, but I do not know of such a generalisation involving a metric tree. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486005")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2017")])]

#text("Quick typo: “The sum {\\sum_{\\lambda’ \\prec \\lambda}} can be split into {k-1} sums {\\int_{\\lambda_{j+1} \\leq \\lambda’_j \\leq \\lambda_j}}” is probably not meant to have an integral sign.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5988881c1c6ab42755fc11bc34151c16f5601a826cd81b053bfc31019c18d062-81aa104a36309a4b20028b78c673ec17500916583ba3029e7666d933e4fca584.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Betea")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486026")[#strong[#text("Dan Betea")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2017")])]

#text("I have always wondered if this limit is the one performed to get from certain discrete to certain continuous statistical mechanical models. For example, taking the arctic circle theorem for boxed plane partitions (tilings of a hexagon) or the Aztec diamond as input — the important part here is both models can be written as Schur processes as well as sequences of non-intersecting lattice paths — plus this limit, can one simply rederive the arctic circle theorem for non-intersecting Dyson brownian bridges (the watermelon process)? Johansson surely did something similar already in disguise, but it’s probably not very explicit.")

#text("The advantage is on the discrete Schur side, all that is needed for the arctic circle theorems, besides the steepest descent analysis to obtain the arctic circle, are the branching rule (7) and the Cauchy identity.")

#text("One can go further: on the discrete side there is Borodin’s cylindric Schur process (")#link("https://arxiv.org/abs/math/0601019")[#text("https://arxiv.org/abs/math/0601019")]#text("), while on the continuous Johansson’s GUE in finite temperature, in its cylindric non-intersecting Ornstein–Uhlenbeck version in this recent note of Le Doussal–Majumdar–Schehr (")#link("https://arxiv.org/abs/1702.06931")[#text("https://arxiv.org/abs/1702.06931")]#text("). Both papers can be viewed as applications of Wick’s lemma in finite temperature, one for a discrete, the other for a continuous, model.")

#text("I suspect from the S functions to non-intersecting Brownian motions one has to perform an extra diffusive limit (don’t know if that’s the right term, haven’t thought about it).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7abaa006d0a32ff4f0cc554d1db0105b8a4564507de3c0e8f2b38eb6232f4137-0a78232433239c8ec0be0269406775288ef9eba97368c2f3cd021c405c0e9e56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amaury")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486240")[#strong[#text("Amaury")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2017")])]

#text("Such a rescaling is done for the symplectic Schur functions by Bisi and Zygouras in ")#link("https://arxiv.org/abs/1703.07337")[#text("https://arxiv.org/abs/1703.07337")]#text(", in e.g. theorem 4.2 (following O’Connell-Seppalainen-Zygouras for the classical Schur case). The functions are called $ s^{\\mathrm{cont}}_\\lambda(x) $ for “continuum” version of the Schur functions. The analogue of the HCIZ integral (in the GT form) are given, for Whittaker functions, by identities of Stade and Ishii. Such a rescaling is called there “$0$-temperature limit, in the context of the log-Gamma polymer, so, no, this is not really the limit performed to go from discrete to continuous statistical mechanics models, more to stay on the same model but replace the classical $ (+, \\cdot) $ algebra by the max+ algebra (the tropical version of the statistical model). One stays on the same discrete grid, but the log-gamma partition function becomes the last passage percolation time (see proposition 4.1).")

#text("For a nice review on these continuous Schur functions and their links with stochastic integrable models, see the survey by O’Connell ")#link("https://arxiv.org/pdf/1201.4849.pdf")[#text("https://arxiv.org/pdf/1201.4849.pdf")]#text(" (it is named $ J_\\lambda(x) $ here).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486123")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2017")])]

#text("Some of the xi’s between formula 10 and 11 should be exp xi’s.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/563fc415e61a3bc0b1e2432bc02876ae64af4eb65ac2b28d4fd965645fd1bd1c-2b857b97ebc4abc7e7c637f1d86d4ea461ea13294f1fa6cef496488eb34d9e0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KKK")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486155")[#strong[#text("KKK")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("The boxes can be moved closer together by using tabular:")

#box[#table(
columns: (auto, auto, auto, auto, auto, auto, ),
rows: 3,
align: (center, center, center, center, center, center,),
inset: (x: 0.2em, y: 0.1em), stroke: none,
table.cell(x: 0, y: 0, [#mi("1")]),
table.cell(x: 1, y: 0, [#mi("1")]),
table.cell(x: 2, y: 0, [#mi("1")]),
table.cell(x: 3, y: 0, [#mi("2")]),
table.cell(x: 4, y: 0, [#mi("3")]),
table.cell(x: 5, y: 0, [#mi("3")]),
table.vline(x: 0, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 1, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 2, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 3, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 4, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 5, start: 0, end: 1, stroke: 0.4pt),
table.vline(x: 6, start: 0, end: 1, stroke: 0.4pt),
table.cell(x: 0, y: 1, [#mi("2")]),
table.cell(x: 1, y: 1, [#mi("2")]),
table.cell(x: 2, y: 1, [#mi("2")]),
table.cell(x: 3, y: 1, [#mi("3")]),
table.vline(x: 0, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 1, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 2, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 3, start: 1, end: 2, stroke: 0.4pt),
table.vline(x: 4, start: 1, end: 2, stroke: 0.4pt),
table.cell(x: 0, y: 2, [#mi("1")]),
table.cell(x: 1, y: 2, [#mi("2")]),
table.vline(x: 0, start: 2, end: 3, stroke: 0.4pt),
table.vline(x: 1, start: 2, end: 3, stroke: 0.4pt),
table.vline(x: 2, start: 2, end: 3, stroke: 0.4pt),
table.hline(y: 0, start: 0, end: 6, stroke: 0.4pt),
table.hline(y: 1, start: 0, end: 6, stroke: 0.4pt),
table.hline(y: 2, start: 0, end: 4, stroke: 0.4pt),
table.hline(y: 3, start: 0, end: 2, stroke: 0.4pt),
)]

#emph[#text("[That worked, thanks! -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bd28237e11d981e5ddb5bc8b9c73b3e87af02a2d86d8749f32e42f1545f38ac-670cf65d67100fa741e76fe3e9d35d11f55354013a39896f93ff77796b2ed5ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lol")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486162")[#strong[#text("lol")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2017")])]

#text("Professor Tao takes advice from the KKK tsk tsk :P.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486310")[#strong[#text("Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2017")])]

#text("[…] to the space of measures is the high-dimensional limit of a Gelfand-Tsetlin pattern (discussed in this previous post), if the pattern is randomly generated amongst all matrices with spectrum asymptotic to as . For […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An update to “On the sign patterns of entrywise positivity preservers in fixed dimension” | What's new")]], [#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/#comment-486787")[#strong[#text("An update to “On the sign patterns of entrywise positivity preservers in fixed dimension” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2017")])]

#text("[…] of Schur polynomials into skew-Schur polynomials (as was done in this previous post). […]")
]
