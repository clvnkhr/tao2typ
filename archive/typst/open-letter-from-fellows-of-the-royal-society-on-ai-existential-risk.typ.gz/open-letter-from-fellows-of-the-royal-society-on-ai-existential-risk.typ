// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/
// Converted to Typst by tao2typ: "2026-10-17T11:01:29.706088+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open letter from Fellows of the Royal Society on AI existential risk", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open letter from Fellows of the Royal Society on AI existential risk")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/")[#text("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-17 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(". I support the letter, and am also a (corresponding) Fellow, but I have worked in various collaborations with the AI industry and so was not eligible to be a signatory. — T.]")]

#text("The rapid development of AI is of enormous public interest right now, with the possible existential risk to humanity being reported by mainstream news organisations. However, the discussion is often tempered with questions such as `haven’t we heard this before?’ or `isn’t this just hype from the AI companies or a desire to protect their interests?’. As widely reported in this blog and elsewhere, we as mathematicians (perhaps more than other scientists) can see independently, and very clearly, that we should be very worried about the speed of development. We should make this point loudly. 42 mathematician Fellows of the Royal Society have today written to the president of the society, Sir Paul Nurse, to make this point.")

#text("The open letter may be read ")#link("https://docs.google.com/document/d/1-xOkPeHmDEdRigT2YcP2nLfTB56yOn4FFbBfVUIXCUE/edit?usp=sharing")[#text("here")]#text(" and mathematicians are encouraged to support it by signing ")#link("https://docs.google.com/document/d/1N6ThWhupvmH0ofSnaxqnLEMfSTQX5cTLyTMYG27ID-w/edit")[#text("the letter")]#text(", which can be done ")#link("https://docs.google.com/forms/u/0/d/e/1FAIpQLSdua7W-CG7HoIHfqTNv4djbp78j0YeDHGCDr6WTCMCeFjhPEQ/formResponse")[#text("at this link")]#text(".")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695401")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Just to say the form for signing the letter is here ")#link("https://tinyurl.com/2fbxmn9b")[#text(" ")]#link("https://tinyurl.com/2fbxmn9b")[#text("https://tinyurl.com/2fbxmn9b")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695411")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Terry, please don’t go down the x-risk rabbit hole, it is one of regulatory capture and shirking human responsibility, while throwing out wildly fabricated figures like “10%.” – your friend Talia")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695459")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Obviously any sort of P(doom) people give is going to be some sort of guess.")

#text("Personally I would put existential risk from artificial intelligence in the 1-5% range. I think there is a lot of work being done on AI safety and so on, and I think the Yudkowskyan scenario is quite unlikely. I think thought that malicious humans using AI to make the next pandemic is a much bigger risk. As Talia said, human responsibility. Talia makes a good point about regulatory capture. We don’t want a world where OAI and Anthropic are the only ones with compute because the government says it’s too dangerous for the public. It’s very important that mathematicians have access to compute so we can also do great math with AI and it’s not all done in the labs.")

#text("I also think that AI companies are really thinking a lot about this and putting safeguards in. At some point Claude was censoring all discussions of biology, and Dario said he’d rather be mocked on twitter than responsible for the next pandemic. So I think it will be OK in terms of existential risk.")

#text("Personally I’m pretty worried about some kind of ban on open-source AI because it’s allegedly too dangerous, so then to get compute to do math you need to beg an AI lab. This would be really bad for mathematicians, and bad for the world in general because we wouldn’t get to experience the benefits of AI.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695419")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I like to read mathematics and I am nowhere related to mathematics field in general.")

#text("From what I have seen through what’s new is that there is a sense of worry with AI and what role will mathematicians have if the models become capable of solving problems that have stumbled humans.")

#text("I don’t think we can stop this certainity from happening, we can delay it by slowing down AI progress but there will be one day when all of this worry turns into a reality. What then?")

#text("I don’t think it will matter if LLMs get capable enough of actually producing a real proof, for me I will still follow the titans that go toe to toe with machines, for me I will still want to go to an actual lecture by a human, for me I would still like to lookup solutions by a human. Because for me to get better, I must look up to a role model I like and try to copy amateurishly what they do.")

#text("I cannot relate to LLMs the way I can relate to humans. The robots can break a 4 minute mile but no human would do it without another human being attempting it.")

#text("You see, a cheetah runs faster than usain bolt but I follow usain bolt because for me he is a human who elevated what it means to be a human.")

#text("To all mathematicians and the ones pursuing, you all are that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df56d1ad62ba6399488318cf9e17e81f7757115aec104b7a1967a6b394679d6a-7db593af461ff1694f0fbd9e392bc9e50b1070c0e042ef6f0705adf32a058f97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wondrous2a8948de8e")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695423")[#strong[#text("wondrous2a8948de8e")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Terry, it took me a while to work out that “the letter at this link” is actually two hyperlinks, not one, and the second is where people can sign on. (I suspect this is what the first comment poster is responding to). Could you separate/clarify the links somehow? Thank you 🙂")

#emph[#text("[Done – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695426")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("There are pieces of this I agree with, but how on Earth is a specific probability like 10% being thrown around for human extinction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e538b54b05bab640a1838fde54c62899e83d475d9464e54d274669ccce737839-4922a4ce94f13349460b5d4de4baca47b370a1fd947db38624b81d018c727793.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695452")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Just to comment that the letter does not say this; it merely reports someone else having said it, and asserts that `such statements must not be dismissed as hype’.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695481")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("And there’s people who say the probability is much lower. I say they should not be dismissed as hype.")

#text("If the letter doesn’t support the claim it reports, then it’s just dueling hearsay.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695485")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("But people fabricating weirdly specific figures like “10%” is genuinely hype")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/247478b2c87ac6e136c693c1195a7af4723084d1772fc870dbe6ea0fe48dd3a7-7fd3c32cfe537288b664ffb8e940f5effba6f6d84910175804a6ae48a84716ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elie520")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695494")[#strong[#text("elie520")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("The same way a random person would be ok betting 11:1 that the 100th decimal of pi is 0, even though it is not a random event. It’s an personnal estimation of a risk you’re willing to take w.r.t. your model of the world.")

#text("I’m not saying the probability of the 100th decimal of pi being 0 IS 10%, it does not make sense (the answer is definitive and known), but I’m saying that without further clue, it’s a respectable guess.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695444")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Such probabilities are not meant to be a prediction, even though we have no idea what the actual numbers are one might still use percentages to express one’s confidence about the outcome, so these statements are likely to be just a way to say whether one think the risk is zero, vanishingly small, concerning given the stakes, etc all the way up to almost certain. That we don’t know precisely how likely it is (given that it also depends on hard to predict parameters like whether international regulation will happen, whether we will have a medium-scale disaster (https:// ")#link("http://www.youtube.com/watch?v=mhyD8MuW65M")[#text("http://www.youtube.com/watch?v=mhyD8MuW65M")]#text(") that will push politicians to act before it’s too late, etc.), shouldn’t prevent us from asserting levels of confidence in certain outcomes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1a9fe8710b4c27675deac31b21284211734b809e327bd74df596085a4badcc0-64e82a8f9e8359f7a05a2b62807a79f18e2052d757d62a8eec7cb749673d2697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grigori Avramidi")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695464")[#strong[#text("Grigori Avramidi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("Thanks for writing this. It closely mirrors my own experience in the last few months (going from ”wow”, to ”holy shit”, to ”doesn’t everyone else see this, too”) and is the first time in a while that I have not been depressed by the response of the math community to the ai developments. It is nice to feel like I am not insane (or at least, not insane all by myself) for once.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695492")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("this is hype from the AI companies and/or unsubstantiated fear. OpenAI and Anthropic employees are simply cultists who are so brainwashed into believing AI models are more powerful than they really are that they say this nonsense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695493")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("THANK GOD for FINALLY speaking up about this!!! I’ve been raising concerns for a long time on you blog and others, and faced way too much backlashfrom people not able to take a moment to actually comprehend the situation.")

#text("Your words matter, as respected mathematicians, since most of the intelligentsia (best supporters of AI race…) look up to you, as representatives of our community!!")

#text("I was really depresed for a few months by the hyperfocus of mathematicians on mathematics/education/credit, you gave my hope back ❤")

#text("We need to fight the emergence of species literally more capable than us in the world we built for it, there is no outsmarting superior intelligence.")

#text("ALl the best.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695497")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("As Talia said, this is about regulatory capture and propaganda that is trying to sell the idea that these models are more powerful than they really are. Recall that GPT-2 was initially claimed to be too powerful to release, and then it was released. In addition, there seems to be a cult-like mentality among AI company employees. If the companies actually wanted to slow themselves down, they would. No regulation (of their competitors out of existence) needed.")

#text("AI may cause job losses, but that is because it will be used for the interests of the large corporations and the 1%. In order to avoid this, we need to nationalize the AI companies, as Bernie Sanders is proposing, and in general, unionize at all companies as much as possible.")

#text("A historical example is the Luddites, who fought back against their bosses trying to automate them away with powered looms. Their name became a derogatory term due to propaganda, but far from being anti-technology, they simply wanted the technology to be used in their interests.")#linebreak()#text("See Ted Chiang, “Will AI become the New McKinsey?” ")#linebreak()#text("archived version here: ")#link("https://archive.is/lWCM0")[#text("https://archive.is/lWCM0")]

#text("We have been here before.")

#text("Lastly, AI stealing a mathematician’s idea and combining it with existing literature to solve a Millennium problem is not exactly a 5-alarm fire, all it says is that math is underfunded and we need to organize against corporate interests. Again, this was already true. ")#linebreak()#text("To quote Tao also, “AI companies should compete to be the first to have their models generate a real insight, not just to solve a problem.”")

#text("Daniel Litt provides some good ways forward here: ")#link("https://proofsandprompts.com/2026/09/14/a-beginning-for-mathematics/")[#text("https://proofsandprompts.com/2026/09/14/a-beginning-for-mathematics/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a9217c58d99f4ccae4124369977efffc4277da6d20c55fb1bcf5d305b4dfa02-7fe64538532cd5b90c1f6b7fe8347bd36cd3c751555fd90d91cdc0c15ea9b226.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gerymate")]], [#link("https://terrytao.wordpress.com/2026/09/16/open-letter-from-fellows-of-the-royal-society-on-ai-existential-risk/comment-page-1/#comment-695653")[#strong[#text("gerymate")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I have a hypothesis that software engineers and mathematicians might be way more involved in predicting a high P(doom), based on some subconscious processes that sense the forthcoming radical price drop of our work. Current AI capability gains are largely coming from reinforcement learning (RL) and compute performance improvements. However, RL requires that a large set of problems can be generated and verified in an automated way. Very large parts of mathematics and software engineering are like that, but most other professions are not. In these domains the really talented experts and creatives will be able to produce enormous amount of output compared to current measures; thus the work of a significant portion of the workforce will become worthless. For example there are roughly 40M SWEs around the world, all enjoying extra high wages and living standards compared to, say, truck drivers or high school teachers. This will just end for 35M. Similar prognosis may be set for a large portion of mathematicians. But this won’t happen to physicists, chemists and biologists, or any domains where RL doesn’t fit.So my hypothesis is that the tens of millions of today’s highly intelligent, but not exceptional talent in mathematics and SWE have an intrinsic feeling about soon losing privilege, and some just misinterpret that as “P(doom) must be very large…”")
]
