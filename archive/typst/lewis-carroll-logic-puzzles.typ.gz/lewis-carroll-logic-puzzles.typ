// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/
// Converted to Typst by tao2typ: "2026-10-14T09:25:27.147462+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lewis Carroll logic puzzles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lewis Carroll logic puzzles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 April 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/")[#text("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I had another long plane flight recently, so I decided to try making another game, to explore exactly what types of mathematical reasoning might be amenable to gamification. I decided to start with one of the simplest types of logical argument (and one of the few that avoids the disjunction problem mentioned in the ")#link("https://terrytao.wordpress.com/2012/04/18/new-version-of-algebra-game/")[#text("previous post")]#text("), namely the Aristotelian logic of ")#link("http://en.wikipedia.org/wiki/Syllogism")[#text("syllogistic reasoning")]#text(", most famously exemplified by the classic syllogism:")

#list(
[#text("Major premise: All men are mortal.")],
[#text("Minor premise: Socrates is a man.")],
[#text("Conclusion: Socrates is a mortal.")]
)

#text("There is a classic collection of logic puzzles of Lewis Carroll (from his book on symbolic logic), in which he presents a set of premises and asks to derive a conclusion using all of the premises. Here are four examples of such sets:")

#list(
[#text("Babies are illogical;")],
[#text("Nobody is despised who can manage a crocodile;")],
[#text("Illogical persons are despised.")]
)

#list(
[#text("My saucepans are the only things that I have that are made of tin;")],
[#text("I find all your presents very useful;")],
[#text("None of my saucepans are of the slightest use.")]
)

#list(
[#text("No potatoes of mine, that are new, have been boiled;")],
[#text("All of my potatoes in this dish are fit to eat;")],
[#text("No unboiled potatoes of mine are fit to eat.")]
)

#list(
[#text("No ducks waltz;")],
[#text("No officers ever decline to waltz;")],
[#text("All my poultry are ducks.")]
)

#text("After a certain amount of effort, I was able to gamify the solution process to these sort of puzzles ")#link("http://scratch.mit.edu/projects/teorth/2486639")[#text("in a Scratch game")]#text(", although I am not fully satisfied with the results (in part due to the inherent technical limitations of the Scratch software, but also because I have not yet found a smooth user interface for this process). In order to not have to build a natural language parser, I modified Lewis Carroll’s sentences somewhat in order to be machine-readable. Here is a typical screenshot:")

#link("http://scratch.mit.edu/projects/teorth/2486639")[#image("../assets/17216dfe24239898777dc4b38b7ca82d7b1d9f4fa3059e6327f7fad23f1dd17e-c15d124e6726a5fa82b016d6bb1001b51510be0e65767b6d0adcfca0162352e8.jpg", width: 90%)]

#text("Unfortunately, the gameplay is somewhat clunkier than in ")#link("http://scratch.mit.edu/projects/teorth/2477436")[#text("the algebra game")]#text(", basically because one needs three or four clicks and a keyboard press in order to make a move, whereas in the algebra game each click corresponded to one move. This is in part due to Scratch not having an easy way to have drag-and-drop or right-click commands, but even with a fully featured GUI, I am unsure how to make an interface that would make the process of performing a deduction easy; one may need a “smart” interface that is able to guess some possible intended moves from a minimal amount of input from the user, and then suggest these choices (somewhat similarly to the “auto-complete” feature in a search box). This would require more effort than I could expend on a plane trip, though (as well as the use of a more powerful language than Scratch).")

#text("There are of course several existing proof assistants one could try to use as a model (")#link("http://en.wikipedia.org/wiki/Coq")[#text("Coq")]#text(", ")#link("http://en.wikipedia.org/wiki/Isabelle_(theorem_prover)")[#text("Isabelle")]#text(", etc.), but my impression is that the syntax for such assistants would only be easily mastered by someone who already is quite experienced with computer languages as well as proof writing, which would defeat the purpose of the games I have in mind. But perhaps it is possible to create a proof assistant for a very restricted logic (such as one without disjunction) that can be easily used by non-experts…")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3876e36d8bf54c779f3c1e92c9b1c772b4eb51235441fccf428a0bedfac6c04d-36188731545c09c1dde61524a206e237dcfee203eae6ef85141c5329c5e29452.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrik")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-139656")[#strong[#text("Ulrik")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2012")])]

#text("I know that natural deduction proofs in the implication-only fragment have been gamified: ")#link("http://www.winterdrache.de/freeware/domino/index.html")[#text("http://www.winterdrache.de/freeware/domino/index.html")]#linebreak()#text(" More connectives can probably be handled by extra pieces, but the nice thing about this game is that implication-only formulas have very succinct graphical representations, so it might not work so well for more complicated formulas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-139698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2012")])]

#text("Good morning all")#linebreak()#text(" I think that we have innate logic who is not always right. Sometimes interpretation is false")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1591e09fbd9a85846f220bb6d8e79994a786338d1e7b286f98aab35c55a1c4ec-9aaafbb09532832c5eae30444cfa150c55fc0f8ffd5b1824f29ce4ceec32993d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangeeta")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-139712")[#strong[#text("Sangeeta")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2012")])]

#text("Maths is a root of life n it is my heart touching subject.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-140002")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2012")])]

#text("I use ‘ordinal fractions’ for solving such problems. The ‘first half’ is an ordinal fraction because ‘first’ is an ordinal and ‘half’ is a fraction. The ‘first half’ is called 1, the ‘second half’ is called 2, and ‘both halfs’ is called 0 meaning ‘no condition on the halfs’. Digit 0 is wild-card character. The first fourth is 11, the second fourth is 12, the third fourth is 21, and the fourth fourth is 22. The odd fourths is 01 and the even fourths is 02. You may pad zeroes to the right: 0=00, 1=10, 2=20. If two ordinal fractions are unequal they satisfy one of the four inequalities: ,><,. For example 10>11, 10<20, 1001. Identify the concepts by ordinal fractions such that the logical relations between concepts are mirrored by arithmetic relations between ordinal fractions. ‘immortal’=100, ‘man’=110, ‘Socrates’=111. ‘All men are mortal’: 110<100. 'Socrates is a man': 111<110. Conclusion: 111<100: 'Socrates is a mortal'.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-140004")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2012")])]

#text("My text above is corrupted, as unequality signs are omitted. ‘The four inequalities are LT, GT, LTGT, GTLT. For example 10 GT 11, 10 LT 00, 10 GTLT 20, 10 LTGT 01. ‘")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-140018")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2012")])]

#text("And of course ‘immortal’=100 should read ‘mortal’=100.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/103228f3b115a98dfdec691a59201bf7acbd272526237388c89cdb0b05232465-592cb343c8a10f813ca25193ab4ba123918a7cf22160feb9771589bbf324cc5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mk")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-140065")[#strong[#text("mk")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2012")])]

#text("I’ve often thought that the endoporeutic game invented by Charles Sanders Peirce might be a promising way to gamify certain parts of logic. It’s played by two players, a proposer and a skeptic and represents a diagrammatic form of reasoning. It’s sort of an early version/predecessor of model theory they say, and encompasses propositional logic I believe. I had read about it here ")#link("http://www.jfsowa.com/peirce/ms514.htm")[#text("http://www.jfsowa.com/peirce/ms514.htm")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-140383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2012")])]

#text("I hate to nitpick your post, but I believe the correct term is Aristotelian. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d10259e569f7948fb426f219171f06e13dc570f262d4c1ae121b4b024a8b1608-030659b4e829203ccdf0062ebabb0491445396a52c856fea3b1d5e19b723499e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OMF")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-141109")[#strong[#text("OMF")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2012")])]

#text("Someone’s caught the coding bug!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2530e5f5796f4051523b358a1b45b9419aa81f0ea00d365a65ee9122007cc47f-6fa1beb84426ba452f9d1cbfaca73f0ab1f2d17d982ed63816fecbe630410bbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MH")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-141284")[#strong[#text("MH")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2012")])]

#text("Question on a related note: What examples of mathematics do you think can be novel-ified or movie-ified for a general audience? Stephen Hawking was told that each equation he put in his book would halve the size of its readership. In general, I think this is accurate. But I recall a quote elsewhere on your site (paraphrasing) “once mastered, you don’t see numbers, you see meanings.”")

#text("It seems to me (a layman) that there ought be ways to convey the value, joy and sheer ingenuity of parts of mathematics via analogous meanings and concepts, without recourse to the foreign language of mathematical notation or only so much of it as may be casually translated. Perhaps I am naive to think this. Perhaps the ability to so translate requires a genius all of its own?I realize that rigor, among other things, may be lost in translation–but for a general audience, maybe an “almost explanation” is useful to their understanding the proper explanation, in a similar way to “almost primes” being useful in the study of primes? (I trust I won’t get shot for making this analogy).")

#text("If you’ve time, what are your thoughts?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b1bd6be15bb879d475259c8ac6dcb365679f8909535f18f46d8e7cfef9750b0-e22415995383b15a4ac77686cef99083753fce9fd54898429df67e2aa533bde9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Artigiani Genova (@FabbroGenova)")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-156496")[#strong[#text("Artigiani Genova (@FabbroGenova)")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2012")])]

#text("All babies are despised.")#linebreak()#text(" That would be a great name for an emo rock band :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1db0a6b2ea929f7d07d92ce49d27a62492ad6193118bb4ae8c527c6f8c6fe0cc-60c854a54125896cd4c67f6e17198bba1c389e616a027a3e6e3494f24f2ef8d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hybrid Education: The Evidence Grows (reblog) « Pathfinder")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-159366")[#strong[#text("Hybrid Education: The Evidence Grows (reblog) « Pathfinder")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2012")])]

#text("[…] drawn outside the circle but within the square. Using games such as the one proposed by Terry Tao is probably an excellent way to teach thislogic. Logic, of course, can be elucidated by other […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b01a9c265deaab28686a3e7d3f4ed17e149664ecf66e9e95ee2022f5f318d45-9b668d29594aa67189bff8c57a305a0db28013c11d7ef5eeecc7b0c172874fd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elisa")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-450448")[#strong[#text("Elisa")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2015")])]

#text("Just love this! <3")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36d169c0ea93a713f6b763596989000652b19fca9bf7613701a5916c992ed090-ce240a28f94bd0df249bc2d5d86e845d3b530c95882f4d04872c1c5d47097b33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Author Spotlight: A Study and Some Personal Experience of Lewis Carroll – before the second sleep")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-483145")[#strong[#text("Author Spotlight: A Study and Some Personal Experience of Lewis Carroll – before the second sleep")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2017")])]

#text("[…] Two links to explore Carroll’s puzzles on logic may be found here and here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d8dafaf044209396b225535a416ec3d8170a8af072163084ec8b5211279aeef-bbece9fb25a0e3b40c0ed5f9e947d36e280cef70213de17889c9486b335d68d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boolean Arithmetic « Polytropy")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-497748")[#strong[#text("Boolean Arithmetic « Polytropy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("[…] example, from Terence Tao’s blog, is attributed to Lewis Carroll. By the first and third premisses, babies are despised; by the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gamifying propositional logic: QED, an interactive textbook | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-503387")[#strong[#text("Gamifying propositional logic: QED, an interactive textbook | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2018")])]

#text("[…] which could be gamified in a similar fashion. Shortly after my first blog posts on this topic, I experimented with a similar gamification of Lewis Carroll’s classic list of logic puzzles, but the results were […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-643448")[#strong[#text("The Scotfree | Think of a Number. How Do Math Magicians Know What It Is?")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2022")]

#text("[…] Here’s a simple example that might astonish a child in your life and even inspire a fascination with math. It was used for this purpose by Lewis Carroll, the author of Alice’s Adventures in Wonderland. Carroll was an Oxford mathematician and avid puzzler, whose math puzzles have entertained many mathematicians, including the famous Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-643449")[#strong[#text("Think of a Number. How Do Math Magicians Know What It Is? - newsonetop.com")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2022")]

#text("[…] Here’s a simple example that might astonish a child in your life and even inspire a fascination with math. It was used for this purpose by Lewis Carroll, the author of Alice’s Adventures in Wonderland. Carroll was an Oxford mathematician and avid puzzler, whose math puzzles have entertained many mathematicians, including the famous Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-643451")[#strong[#text("Think of a Number. How Do Math Magicians Know What It Is? – EDUTV NEWS")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2022")]

#text("[…] Here’s a simple example that might astonish a child in your life and even inspire a fascination with math. It was used for this purpose by Lewis Carroll, the author of Alice’s Adventures in Wonderland. Carroll was an Oxford mathematician and avid puzzler, whose math puzzles have entertained many mathematicians, including the famous Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-643519")[#strong[#text("Quanta Magazine")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2022")]

#text("[…] Here’s a simple example that might astonish a child in your life and even inspire a fascination with math. It was used for this purpose by Lewis Carroll, the author of Alice’s Adventures in Wonderland. Carroll was an Oxford mathematician and avid puzzler, whose math puzzles have entertained many mathematicians, including the famous Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-643732")[#strong[#text("How Do Math Magicians Know Your Number? - Jeff Cassman")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2022")]

#text("[…] Here’s a simple example that might astonish a child in your life and even inspire a fascination with math. It was used for this purpose by Lewis Carroll, the author of Alice’s Adventures in Wonderland. Carroll was an Oxford mathematician and avid puzzler, whose math puzzles have entertained many mathematicians, including the famous Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/21/lewis-carroll-logic-puzzles/#comment-643999")[#strong[#text("How Do Math Magicians Know Your Number? – Quanta Magazine – My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2022")]

#text("[…] and avid puzzler, whose math puzzles have entertained many mathematicians, including the famous Terence Tao.This magic trick is designed for a child who can do multiplication reliably (get an assistant to […]")
]
