// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:19:30.770602+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/")[#text("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Note: this post is of a particularly technical nature, in particular presuming familiarity with nilsequences, nilsystems, characteristic factors, etc., and is primarily intended for experts.")

#text("As mentioned in ")#link("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/")[#text("the previous post")]#text(", Ben Green, Tamar Ziegler, and myself ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("proved the following")]#text(" inverse theorem for the Gowers norms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Inverse theorem for Gowers norms)")]#text(" ")#metadata(none) <tao-6bf99799d0ef91be6c25>#text(" Let ")#mi("{N \\geq 1}")#text(" and ")#mi("{s \\geq 1}")#text(" be integers, and let ")#mi("{\\delta > 0}")#text(". Suppose that ")#mi("{f: {\\bf Z} \\rightarrow [-1,1]}")#text(" is a function supported on ")#mi("{[N] := \\{1,\\dots,N\\}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{s+2}} \\sum_{n,h_1,\\dots,h_{s+1}} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(n+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}) \\geq \\delta.")]]

#text("Then there exists a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{\\leq s}")#text(" and complexity ")#mi("{O_{s,\\delta}(1)}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_n f(n) F(g(n) \\Gamma) \\gg_{s,\\delta} 1.")]]
]

#text("This result was conjectured earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("by Ben Green and myself")]#text("; this conjecture was strongly motivated by an analogous inverse theorem in ergodic theory ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("by Host and Kra")]#text(", which we formulate here in a form designed to resemble Theorem ")#link(<tao-6bf99799d0ef91be6c25>)[#text("1")]#text(" as closely as possible:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Inverse theorem for Gowers-Host-Kra seminorms)")]#text(" ")#metadata(none) <tao-e9e029f4af326c8ea8d4>#text(" Let ")#mi("{s \\geq 1}")#text(" be an integer, and let ")#mi("{(X, T)}")#text(" be an ergodic, countably generated measure-preserving system. Suppose that one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N^{s+1}} \\sum_{h_1,\\dots,h_{s+1} \\in [N]} \\int_X \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(T^{\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}}x)\\ d\\mu(x)")]]

#align(center)[#tao-fit-display[#mitex("> 0")]]

#text("for all non-zero ")#mi("{f \\in L^\\infty(X)}")#text(" (all ")#mi("{L^p}")#text(" spaces are real-valued in this post). Then ")#mi("{(X,T)}")#text(" is an inverse limit (in the category of measure-preserving systems, up to almost everywhere equivalence) of ergodic degree ")#mi("{\\leq s}")#text(" nilsystems, that is to say systems of the form ")#mi("{(G/\\Gamma, x \\mapsto gx)}")#text(" for some degree ")#mi("{\\leq s}")#text(" filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" and a group element ")#mi("{g \\in G}")#text(" that acts ergodically on ")#mi("{G/\\Gamma}")#text(".")
]

#text("It is a natural question to ask if there is any logical relationship between the two theorems. In the finite field category, one can deduce the combinatorial inverse theorem from the ergodic inverse theorem by a variant of the Furstenberg correspondence principle, as worked out ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("by Tamar Ziegler and myself")]#text(", however in the current context of ")#mi("{{\\bf Z}}")#text("-actions, the connection is less clear.")

#text("One can split Theorem ")#link(<tao-e9e029f4af326c8ea8d4>)[#text("2")]#text(" into two components:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Weak inverse theorem for Gowers-Host-Kra seminorms)")]#text(" ")#metadata(none) <tao-34c6044a910108add049>#text(" Let ")#mi("{s \\geq 1}")#text(" be an integer, and let ")#mi("{(X, T)}")#text(" be an ergodic, countably generated measure-preserving system. Suppose that one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N^{s+1}} \\sum_{h_1,\\dots,h_{s+1} \\in [N]} \\int_X \\prod_{\\omega \\in \\{0,1\\}^{s+1}} T^{\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}} f\\ d\\mu")]]

#align(center)[#tao-fit-display[#mitex("> 0")]]

#text("for all non-zero ")#mi("{f \\in L^\\infty(X)}")#text(", where ")#mi("{T^h f := f \\circ T^h}")#text(". Then ")#mi("{(X,T)}")#text(" is a ")#emph[#text("factor")]#text(" of an inverse limit of ergodic degree ")#mi("{\\leq s}")#text(" nilsystems.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Pro-nilsystems closed under factors)")]#text(" ")#metadata(none) <tao-1e7dc6d6c16565406afd>#text(" Let ")#mi("{s \\geq 1}")#text(" be an integer. Then any factor of an inverse limit of ergodic degree ")#mi("{\\leq s}")#text(" nilsystems, is again an inverse limit of ergodic degree ")#mi("{\\leq s}")#text(" nilsystems.")
]

#text("Indeed, it is clear that Theorem ")#link(<tao-e9e029f4af326c8ea8d4>)[#text("2")]#text(" implies both Theorem ")#link(<tao-34c6044a910108add049>)[#text("3")]#text(" and Theorem ")#link(<tao-1e7dc6d6c16565406afd>)[#text("4")]#text(", and conversely that the two latter theorems jointly imply the former. Theorem ")#link(<tao-1e7dc6d6c16565406afd>)[#text("4")]#text(" is, in principle, purely a fact about nilsystems, and should have an independent proof, but this is not known; the only known proofs go through the full machinery needed to prove Theorem ")#link(<tao-e9e029f4af326c8ea8d4>)[#text("2")]#text(" (or the closely related theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("of Ziegler")]#text("). (However, the fact that a factor of a nilsystem is again a nilsystem was established previously ")#link("http://www.ams.org/mathscinet-getitem?mr=320277")[#text("by Parry")]#text(".)")

#text("The purpose of this post is to record a partial implication in reverse direction to the correspondence principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" Theorem ")#link(<tao-6bf99799d0ef91be6c25>)[#text("1")]#text(" implies Theorem ")#link(<tao-34c6044a910108add049>)[#text("3")]#text(".")
]

#text("As mentioned at the start of the post, a fair amount of familiarity with the area is presumed here, and some routine steps will be presented with only a fairly brief explanation.")

#metadata(none) <tao-833e91e92d489025164e>

#text("To show that ")#mi("{(X,T)}")#text(" is a factor of another system ")#mi("{(Y,S)}")#text(" up to almost everywhere equivalence, it suffices to obtain a unital algebra homomorphism from ")#mi("{L^\\infty(X)}")#text(" to ")#mi("{L^\\infty(Y)}")#text(" that intertwines ")#mi("{T}")#text(" with ")#mi("{S}")#text(", and which is measure-preserving (or more precisely, integral-preserving). On the other hand, by hypothesis, ")#mi("{L^\\infty(X)}")#text(" is generated (as a von Neumann algebra) by the dual functions")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f := \\lim_{N \\rightarrow \\infty} {\\mathcal D}_N f")]]

#text("for ")#mi("{f \\in L^\\infty(X)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_N f := \\frac{1}{N^{s+1}} \\sum_{h_1,\\dots,h_{s+1} \\in [N]} \\prod_{\\omega \\in \\{0,1\\}^{s+1} \\backslash \\{0\\}} T^{\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}}f;")]]

#text("indeed we may restrict ")#mi("{f}")#text(" to a countable sequence ")#mi("{f_n}")#text(" that is dense in ")#mi("{L^\\infty(X)}")#text(" in the ")#mi("{L^2}")#text(" (say) topology, together with their shifts. To obtain such a factor representation, it thus suffices to find a “model” ")#mi("{\\tilde f_n \\in L^\\infty(Y)}")#text(" associated to each dual function ")#mi("{{\\mathcal D} f_n}")#text(" in such a fashion that ")#metadata(none) <tao-dac206a35f708cbb08fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_Y P( T^{h_1} \\tilde f_{n_1}, \\dots, T^{h_d} \\tilde f_{n_d} ) = \\int_X P( T^{h_1} {\\mathcal D} f_{n_1}, \\dots, T^{h_d} {\\mathcal D} f_{n_d} )")]]



#text(" for all ")#mi("{n_1,\\dots,n_d}")#text(" and ")#mi("{h_1,\\dots,h_d}")#text(", and all polynomials ")#mi("{P}")#text(". Of course it suffices to do so for those polynomials with rational coefficients (so now there are only a countable number of constraints to consider).")

#text("We may normalise all the ")#mi("{f_n}")#text(" to take values in ")#mi("{[-1,1]}")#text(". For any ")#mi("{n,m}")#text(", we can find a scale ")#mi("{N_{n,m} \\geq m}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| {\\mathcal D} f_n - {\\mathcal D}_{N_{n,m}} f_n \\right\\|_{L^2(X)} \\leq 2^{-100(n+m)}.", block: true)]]

#text("If we then define the exceptional set")

#align(center)[#tao-fit-display[#tao-math("E_{n,m} := \\{ x: \\left|{\\mathcal D} f_n(x) - {\\mathcal D}_{N_{n,m}} f_n(x)\\right| \\geq 2^{-(n+m)} \\}", block: true)]]

#text("then ")#mi("{E_{n,m}}")#text(" has measure at most ")#mi("{2^{-10(n+m)}}")#text(" (say), and so the function ")#mi("{\\sum_{n,m} 2^{9(n+m)} 1_{E_{n,m}}}")#text(" is absolutely integrable. By the maximal ergodic theorem, we thus see that for almost every ")#mi("{x}")#text(", there exists a finite ")#mi("{C_x}")#text(" such that ")#metadata(none) <tao-9d9dd5b2e12297561347>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\{ h \\in [H]: T^h x \\in E_{n,m} \\}\\right| \\leq C_x 2^{-8(n+m)} H", block: true)]]



#text(" for all ")#mi("{n,m}")#text(" and all ")#mi("{H \\geq 1}")#text(". Informally, we thus have the approximation")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f_n(T^h x ) = {\\mathcal D}_{N_{n,m}} f_n(T^h x) + O( 2^{-(n+m)} )")]]

#text("for “most” ")#mi("{h,n,m}")#text(".")

#text("Next, we observe from the Cauchy-Schwarz-Gowers inequality that for almost every ")#mi("{x \\in X}")#text(", the dual function ")#mi("{h \\mapsto {\\mathcal D}_{N_{n,m}} f_n(T^h x)}")#text(" is anti-uniform in the sense that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{h \\in [N_{n,m}]} {\\mathcal D}_{N_{n,m}} f_n(T^h x) g(h) \\ll_s \\left\\|g\\right\\|_{U^{s+1}[N_{n,m}]}", block: true)]]

#text("for any function ")#mi("{g: [N_{n,m}] \\rightarrow [-1,1]}")#text(". By the usual structure theorems (e.g. Theorem 1.2 of ")#link("https://arxiv.org/abs/1002.2028")[#text("this paper of Ben Green and myself")]#text(") this shows that for almost every ")#mi("{x \\in X}")#text(" and every ")#mi("{k \\geq 1}")#text(", there exists a degree ")#mi("{\\leq s}")#text(" nilsequence ")#mi("{h \\mapsto F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k} )}")#text(" of complexity ")#mi("{O_{s,k,n}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{h \\in [N_{n,m}]} \\left| {\\mathcal D}_{N_{n,m}} f_n(T^h x) - F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k}) \\right|^2 \\ll 2^{-100(n+k)}", block: true)]]

#text("(say). (Sketch of proof: standard structure theorems give a decomposition of the form")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}_{N_{n,m}} f_n(T^h x) = f_{str} + f_{sml} + f_{unf}")]]

#text("where ")#mi("{f_{str}}")#text(" is a nilsequence as above, ")#mi("{f_{sml}}")#text(" is small in ")#mi("{L^2}")#text(" norm, and ")#mi("{f_{unf}}")#text(" is very small in ")#mi("{U^{s+1}[N]}")#text(" norm; ")#mi("{f_{unf}}")#text(" has small inner product with ")#mi("{{\\mathcal D}_{N_{n,m}} f_n(T^h x)}")#text(", ")#mi("{f_{str}}")#text(", and ")#mi("{f_{sml}}")#text(", and thus with ")#mi("{f_{unf}}")#text(" itself, and so ")#mi("{f_{sml}}")#text(" and ")#mi("{f_{unf}}")#text(" are both small in ")#mi("{L^2}")#text(", giving the claim.)")

#text("For each ")#mi("{n,m,k}")#text(", let ")#mi("{E^{\\prime}_{n,m,k}}")#text(" denote the set of all ")#mi("{x}")#text(" such that there exists a degree ")#mi("{\\leq s}")#text(" nilsequence ")#mi("{h \\mapsto F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k} )}")#text(" (depending on ")#mi("{x,n,m,k}")#text(") of complexity ")#mi("{O_{s,k,n}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq H \\leq 2^{-10k} N_{n,m}} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D}_{N_{n,m}} f_n(T^h x) - F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k}) \\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\geq 2^{-10(n+k)}.")]]

#text("From the Hardy-Littlewood maximal inequality (and the measure-preserving nature of ")#mi("{T}")#text(") we see that ")#mi("{E^{\\prime}_{n,m,k}}")#text(" has measure ")#mi("{O( 2^{-10(n+k)} )}")#text(". This implies that the functions")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{M} \\sum_{m=1}^M \\sum_{n=1}^\\infty \\sum_{k=1}^\\infty 2^{5(n+k)} 1_{E^{\\prime}_{n,m,k}}")]]

#text("are uniformly bounded in ")#mi("{L^1}")#text(" as ")#mi("{M \\rightarrow \\infty}")#text(", which by Fatou’s lemma implies that")

#align(center)[#tao-fit-display[#mitex("\\liminf_{M \\rightarrow \\infty} \\frac{1}{M} \\sum_{m=1}^M \\sum_{n=1}^\\infty \\sum_{k=1}^\\infty 2^{5(n+k)} 1_{E^{\\prime}_{n,m,k}}")]]

#text("is also absolutely integrable. In particular, for almost every ")#mi("{x}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\liminf_{M \\rightarrow \\infty} \\frac{1}{M} \\sum_{m=1}^M \\sum_{n=1}^\\infty \\sum_{k=1}^\\infty 2^{5(n+k)} 1_{E^{\\prime}_{n,m,k}} < C^{\\prime}_x")]]

#text("for some finite ")#mi("{C^{\\prime}_x}")#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\sum_{k=1}^\\infty 2^{5(n+k)} 1_{E^{\\prime}_{n,m,k}} \\leq C^{\\prime}_x")]]

#text("for an infinite sequence of ")#mi("{m}")#text(" (the exact choice of sequence depends on ")#mi("{x}")#text("); in particular, there is a ")#mi("{K_x}")#text(" such that for all ")#mi("{m}")#text(" in this sequence, one has")

#align(center)[#tao-fit-display[#mitex("x \\not \\in E^{\\prime}_{n,m,k}")]]

#text("for all ")#mi("{n}")#text(" and all ")#mi("{k \\geq K_x}")#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq H \\leq 2^{-10k} N_{n,m}} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D}_{N_{n,m}} f_n(T^h x) - F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k}) \\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq 2^{-10(n+k)}")]]

#text("for all ")#mi("{m}")#text(" in this sequence, all ")#mi("{n}")#text(", and all ")#mi("{k \\geq K_x}")#text("; combining with ")#link(<tao-9d9dd5b2e12297561347>)[#text("(2)")]#text(" we see (for almost every ")#mi("{x}")#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq H \\leq 2^{-10k} N_{n,m}} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D} f_n(T^h x) - F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k}) \\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll 2^{-10(n+k)} + 2^{-(n+m)}")]]

#text("and thus for all ")#mi("{n}")#text(", all ")#mi("{k \\geq K_x}")#text(", and all ")#mi("{H \\geq 1}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{m \\rightarrow \\infty} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D} f_n(T^h x) - F_{n,m,k}( g_{n,m,k}(h) \\Gamma_{n,m,k}) \\right|^2 \\ll 2^{-10(n+k)}", block: true)]]

#text("where the limit is along the sequence.")

#text("For given ")#mi("{n, k}")#text(", there are only finitely many possibilities for the nilmanifold ")#mi("{G_{n,m,k}/\\Gamma_{n,m,k}}")#text(", so by the usual diagonalisation argument we may pass to a subsequence of ")#mi("{m}")#text(" and assume that ")#mi("{G_{n,m,k}/\\Gamma_{n,m,k} = G_{n,k}/\\Gamma_{n,k}}")#text(" does not depend on ")#mi("{m}")#text(" for any ")#mi("{n,k}")#text(". By Arzela-Ascoli we may similarly assume that the Lipschitz function ")#mi("{F_{n,m,k}}")#text(" converges uniformly to ")#mi("{F_{n,k}}")#text(", so we now have")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{m \\rightarrow \\infty} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D} f_n(T^h x) - F_{n,k}( g_{n,m,k}(h) \\Gamma_{n,k}) \\right|^2 \\ll 2^{-10(n+k)}", block: true)]]

#text("along the remaining subsequence for all ")#mi("{n}")#text(", all ")#mi("{k \\geq K_x}")#text(", and all ")#mi("{H \\geq 1}")#text(".")

#text("By repeatedly breaking the coefficients of the polynomial sequence ")#mi("{g_{n,m,k}}")#text(" into fractional parts and integer parts, and absorbing the latter in ")#mi("{\\Gamma_{n,k}}")#text(", we may assume that these coefficients are bounded. Thus, by Bolzano-Weierstrass and refining the sequence of ")#mi("{m}")#text(" further, we may assume that ")#mi("{g_{n,m,k}}")#text(" converges locally uniformly in ")#mi("{h}")#text(" as ")#mi("{m}")#text(" goes to infinity to a polynomial sequence ")#mi("{g_{n,k}}")#text(", for every ")#mi("{n,k}")#text(". We thus have (for almost every ")#mi("{x}")#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D} f_n(T^h x) - F_{n,k}( g_{n,k}(h) \\Gamma_{n,k}) \\right|^2 \\ll 2^{-10(n+k)}", block: true)]]

#text("for all ")#mi("{n}")#text(", all ")#mi("{k \\geq K_x}")#text(", and all ")#mi("{H \\geq 1}")#text(". Henceforth we shall cease to keep control of the complexity of ")#mi("{F_{n,k}}")#text(" or ")#mi("{G_{n,k}/\\Gamma_{n,k}}")#text(".")

#text("We can lift the polynomial sequence up to a linear sequence (enlarging ")#mi("{G_{n,k}}")#text(" as necessary), thus ")#metadata(none) <tao-c6b86732f049a32eed5a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\limsup_{H \\rightarrow \\infty} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D} f_n(T^h x) - F_{n,k}( g_{n,k}^h \\Gamma_{n,k}) \\right|^2 \\ll 2^{-10(n+k)}", block: true)]]



#text(" for all ")#mi("{n}")#text(", all ")#mi("{k \\geq K_x}")#text(", and some ")#mi("{g_{n,k} \\in G_{n,k}}")#text(". By replacing various nilsystems with Cartesian powers, we may assume that the nilsystems ")#mi("{(G_{n,k}/\\Gamma_{n,k}, x \\mapsto g_{n,k} x)}")#text(" are increasing in ")#mi("{n}")#text(" and ")#mi("{k}")#text(" in the sense that the nilsystem for ")#mi("{n,k}")#text(" is a factor of that for ")#mi("{n,k+1}")#text(" or ")#mi("{n+1,k}")#text(", with the origin mapping to the origin. Then, by restricting to the orbit of the origin, we may assume that all the nilsystems are ergodic (and thus also uniquely ergodic, by the special properties of nilsystems). The nilsystems then have an ergodic inverse limit ")#mi("{(Y,S)}")#text(" with an origin ")#mi("{0}")#text(", and each function ")#mi("{F_{n,k}}")#text(" lifts up to a continuous function ")#mi("{\\tilde f_{n,k}}")#text(" on ")#mi("{Y}")#text(", with ")#mi("{F_{n,k}(g_{n,k}^h \\Gamma_{n,k}) = \\tilde f_{n,k}(S^h 0)}")#text(". Thus ")#metadata(none) <tao-e4b6c93723700d7b345d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\limsup_{H \\rightarrow \\infty} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| {\\mathcal D} f_n(T^h x) - \\tilde f_{n,k}(S^h 0) \\right|^2 \\ll 2^{-10(n+k)}", block: true)]]





#text("From the triangle inequality we see in particular that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{H \\rightarrow \\infty} \\frac{1}{H} {\\bf E}_{h \\in [H]} \\left| \\tilde f_{n,k^{\\prime}}(S^h 0) - \\tilde f_{n,k}(S^h 0) \\right|^2 \\ll 2^{-10(n+k)}", block: true)]]

#text("for all ")#mi("{n}")#text(" and all ")#mi("{K_x \\leq k \\leq k^{\\prime}}")#text(", which by unique ergodicity of the nilsystems implies that")

#align(center)[#tao-fit-display[#tao-math("\\int_Y \\left| \\tilde f_{n,k^{\\prime}} - \\tilde f_{n,k} \\right|^2 \\ll 2^{-10(n+k)}.", block: true)]]

#text("Thus the sequence ")#mi("{\\tilde f_{n,k}}")#text(" is Cauchy in ")#mi("{L^2}")#text(" and tends to a some limit ")#mi("{\\tilde f_n \\in L^\\infty(Y)}")#text(".")

#text("If ")#mi("{x}")#text(" is generic for ")#mi("{{\\mathcal D} f_n}")#text(" (which is true for almost every ")#mi("{x}")#text("), we conclude from ")#link(<tao-e4b6c93723700d7b345d>)[#text("(4)")]#text(" and unique ergodicity of nilsystems that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\int_X {\\mathcal D} f_n - \\int_Y \\tilde f_{n,k} \\right| \\ll 2^{-(n+k)}", block: true)]]

#text("for ")#mi("{k \\geq K_x}")#text(", which on taking limits as ")#mi("{k \\rightarrow \\infty}")#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\int_X {\\mathcal D} f_n = \\int_Y \\tilde f_{n}.")]]

#text("A similar argument gives ")#link(<tao-dac206a35f708cbb08fe>)[#text("(1)")]#text(" for almost every ")#mi("{x}")#text(", for each choice of ")#mi("{n_1,\\dots,n_d,h_1,\\dots,h_d,P}")#text(". Since one only needs to verify a countable number of these conditions, we can find an ")#mi("{x}")#text(" for which all the ")#link(<tao-dac206a35f708cbb08fe>)[#text("(1)")]#text(" hold simultaneously, and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" In order to use the combinatorial inverse theorem to prove the full ergodic inverse theorem (and not just the weak version), it appears that one needs an “algorithmic” or “measurable” version of the combinatorial inverse theorem, in which the nilsequence produced by the inverse theorem can be generated in a suitable “algorithmic” sense from the original function ")#mi("{f}")#text(". In the setting of the inverse ")#mi("{U^3}")#text(" theorem over finite fields, a result in this direction was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2933298")[#text("by Tulsiani and Wolf")]#text(" (building upon a well-known paper ")#link("http://www.ams.org/mathscinet-getitem?mr=1010042")[#text("of Goldreich and Levin")]#text(" handling the ")#mi("{U^2}")#text(" case). It is thus reasonable to expect that a similarly algorithmic version of the combinatorial inverse conjecture is true for higher Gowers uniformity norms, though this has not yet been achieved in the literature to my knowledge.")
]

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23a379b4ce787bc06ec78fc7b7a1dbbea11231010b4977750a9c124aa2a9cd31-018aef932fc678377d8a0259b46dfa70eae90ee971f648edea199ad085404e77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice Nivat")]], [#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/#comment-457639")[#strong[#text("Maurice Nivat")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("do you have any thing to say about the décomposition of a set of integers A into the Minkowski sum of two other sets B and C, non trivial if card B and card C aree both at least equal to 2 I raised the question on research gate can the décomposability of A be checked in poly time, either polynoial in card A or plynomiel in l(A)= maxA-minA? regards Maurie Nivat")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version | What's new")]], [#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/#comment-457654")[#strong[#text("Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2015")])]

#text("[…] mentioned in the previous two posts, Ben Green, Tamar Ziegler, and myself proved the following inverse theorem for the Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Schlafly")]], [#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/#comment-457695")[#strong[#text("Schlafly")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2015")])]

#text("You are in the NY Times, Terry! Please make a separate post for that, so your loyal fans can comment on it without polluting your discussion of nilsequences and more important topics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/147a2f8bd6fae9fc53ce5142f42c33d941e8607cef725e1757a5c95918c697f7-f7cee8696adc4308a1ecdf87113a479b5dadbd615277b3de970183301681a402.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gregdreads")]], [#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/#comment-459844")[#strong[#text("gregdreads")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("A little math is nice but damn!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/#comment-467301")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] the ergodic arguments in many respects (though the two settings are still not equivalent, see this previous blog post for some comparisons between the two settings). Unfortunately the arguments are still rather […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eee5267e0ba94bf52835d85e35950babf3a9bc2925be3f394e65f1ca8a7d23f-f6d8a62917d807f87f4a78a57126f587cfd8879423a147201f1d5af57a6711c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Siming Tu")]], [#link("https://terrytao.wordpress.com/2015/07/23/deducing-a-weak-ergodic-inverse-theorem-from-a-combinatorial-inverse-theorem/#comment-689540")[#strong[#text("Siming Tu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#text("Dear Prof Professor Tao,")

#text("8-9 lines below equation 2, you say that “e.g. Theorem 1.2 of this paper of Ben Green and myself”, here it seems that a hyperlink is missing to indiacte which paper it is.")

#emph[#text("[Link added, thanks – T.]")]
]
