// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/
// Converted to Typst by tao2typ: "2026-10-14T09:06:27.955223+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 February 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/")[#text("https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1101.5707")[#text("The Wigner-Dyson-Mehta bulk universality conjecture for Wigner matrices")]#text("“, submitted to the ")#link("http://www.pnas.org/")[#text("Proceedings of the National Academy of Sciences")]#text(". This short note concerns the convergence of the ")#mi("{k}")#text("-point correlation functions of Wigner matrices in the bulk to the Dyson ")#mi("{k}")#text("-point functions, a statement conjectured by Wigner, Dyson, and Mehta. Thanks to the results of Erdös, Peche, Ramirez, Schlein, Vu, Yau, and myself, this conjecture has now been established for all Wigner matrices (assuming a finite moment condition on the entries), but only if one uses a quite weak notion of convergence, namely ")#emph[#text("averaged vague convergence")]#text(" in which one averages in the energy parameter ")#mi("{u}")#text(". The main purpose of this note is to observe that by combining together existing results in the literature, one can improve the convergence to ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague convergence")]#text(" (which is the natural notion of convergence in the discrete setting); and furthermore, if one assumes some regularity and decay conditions on the coefficient distribution, one can improve the convergence further to ")#emph[#text("local ")#mi("{L^1}")#text(" convergence")]#text(".")

#text("More precisely, let ")#mi("{M_n}")#text(" be an ")#mi("{n \\times n}")#text(" ")#emph[#text("Wigner matrix")]#text(" – a random Hermitian matrix whose off-diagonal elements ")#mi("{\\frac{1}{\\sqrt{n}} \\zeta_{ij}}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(" are iid with mean zero and variance ")#mi("{1/n}")#text(" (and whose diagonal elements also obey similar hypotheses, which we omit here). For simplicity, we also assume that the real and imaginary parts of ")#mi("{\\zeta_{ij}}")#text(" are also iid (as is the case for instance for the ")#link("http://en.wikipedia.org/wiki/Gaussian_unitary_ensemble")[#text("Gaussian Unitary Ensemble (GUE)")]#text("). The eigenvalues ")#mi("{\\lambda_1(M_n) \\leq \\ldots \\leq \\lambda_n(M_n)}")#text(" of such a matrix are known to be asymptotically distributed accordingly to the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircular distribution")]#text(" ")#mi("{\\rho_{sc}(u)\\ du}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\rho_{sc}(u) := \\frac{1}{2\\pi} (4-u^2)_+^{1/2}.")]]

#text("In particular, this suggests that at any energy level ")#mi("{u}")#text(" in the bulk ")#mi("{(-2,2)}")#text(" of the spectrum, the average eigenvalue spacing should be about ")#mi("{\\frac{1}{n \\rho_{sc}(u)}}")#text(". It is then natural to introduce the normalised ")#mi("{k}")#text("-point correlation function")

#align(center)[#tao-fit-display[#mitex("\\rho_{n,u}^{(k)}(t_1,\\ldots,t_k) := \\lim_{\\epsilon \\rightarrow 0} \\frac{1}{\\epsilon^k} {\\bf P} E_\\epsilon")]]

#text("for any distinct reals ")#mi("{t_1,\\ldots,t_k}")#text(" and ")#mi("{k \\geq 1}")#text(", where ")#mi("{E_\\epsilon}")#text(" is the event that there is an eigenvalue in each of the intervals ")#mi("{[u + \\frac{t_i}{n \\rho_{sc}(u)}, u + \\frac{t_i+\\epsilon}{n \\rho_{sc}(u)}]}")#text(" for each ")#mi("{1 \\leq i \\leq k}")#text(". (This definition is valid when the Wigner ensemble is continuous; for discrete ensembles, one can define ")#mi("{\\rho_{n,u}^{(k)}}")#text(" instead in a distributional sense.)")

#text("The ")#emph[#text("Wigner-Dyson-Mehta conjecture")]#text(" asserts that ")#mi("{\\rho_{n,u}^{(k)}}")#text(" converges (in various senses) as ")#mi("{n \\rightarrow \\infty}")#text(" to the Dyson ")#mi("{k}")#text("-point function")

#align(center)[#tao-fit-display[#mitex("\\rho_{Dyson}^{(k)}(t_1,\\ldots,t_k) := \\text{det}( K( t_i,t_j) )_{1 \\leq i,j \\leq k}")]]

#text("where ")#mi("{K(t,t^{\\prime}):=\\frac{\\sin \\pi(t-t^{\\prime})}{\\pi(t-t^{\\prime})}}")#text(" is the Dyson sine kernel. This conjecture was verified first for the GUE (with a quite strong notion of convergence, namely local uniform convergence) by Dyson, using an explicit formula for ")#mi("{\\rho_{n,u}^{(k)}}")#text(" in the GUE case due to Gaudin and Mehta. Later results of ")#link("http://www.ams.org/mathscinet-getitem?mr=1810949")[#text("Johansson")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2639734")[#text("Erdos-Ramirez-Schlein-Yau")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2662426")[#text("Erdos-Peche-Ramirez-Schlein-Yau")]#text(", and ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("Vu and myself")]#text(", extended these results to increasingly wider ranges of Wigner matrices, but in the context of either ")#emph[#text("weak")]#text(" convergence (which means that ")#metadata(none) <tao-9adf009b9ea42792e73e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_{{\\bf R}^k} \\rho_{n,u}^{(k)}(t) F(t)\\ dt \\rightarrow \\int_{{\\bf R}^k} \\rho_{Dyson}^{(k)}(t) F(t)\\ dt")]]

#text("for any ")#mi("{L^\\infty}")#text(", compactly supported function ")#mi("{F}")#text("), or the slightly weaker notion of ")#emph[#text("vague convergence")]#text(" (which is the same as weak convergence, except that the function ")#mi("{F}")#text(" is also required to be continuous).")

#text("In ")#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")[#text("a joint paper of Erdos, Ramirez, Schlein, Vu, Yau, and myself")]#text(", we established the Wigner-Dyson-Mehta conjecture for all Wigner matrices (assuming only an exponential decay condition on the entries), but using a quite weak notion of convergence, namely ")#emph[#text("averaged vague convergence")]#text(", which allows for averaging in the energy parameter. Specifically, we showed that")

#align(center)[#tao-fit-display[#mitex("\\lim_{b \\rightarrow 0} \\lim_{n \\rightarrow \\infty} \\frac{1}{2b} \\int_{u-b}^{u+b} \\int_{{\\bf R}^k} \\rho_{n,u^{\\prime}}^{(k)}(t) F(t)\\ dt = \\int_{{\\bf R}^k} \\rho_{Dyson}^{(k)}(t) F(t)\\ dt.")]]

#text("Subsequently, ")#link("http://arxiv.org/abs/0907.5605")[#text("Erdos, Schlein, and Yau introduced")]#text(" the powerful ")#emph[#text("local relaxation flow method")]#text(", which achieved a simpler proof of the same result which also generalised to other ensembles beyond the Wigner case. However, for technical reasons, this method was restricted to establishing averaged vague convergence only.")

#text("In the current paper, we show that by combining the ")#link("https://terrytao.wordpress.com/2009/06/26/bulk-universality-for-wigner-hermitian-matrices-with-subexponential-decay/")[#text("argument of Erdos, Ramirez, Schlein, Vu, Yau, and myself")]#text(" with some more recent technical results, namely the relaxation of the exponential decay condition in the four moment theorem to a finite moment condition (established ")#link("https://terrytao.wordpress.com/2009/12/09/random-covariance-matrices-universality-of-local-statistics-of-eigenvalues/")[#text("by Vu and myself")]#text(") and a ")#link("http://arxiv.org/abs/1007.4652")[#text("strong eigenvalue localisation bound of Erdos, Yau, and Yin")]#text(", one can upgrade the averaged vague convergence to vague convergence, and handle all Wigner matrices that assume a finite moment condition. Vague convergence is the most natural notion of convergence for discrete random matrix ensembles; for such ensembles, the correlation function is a discrete measure, and so one does not expect convergence to a continuous limit in any stronger sense than the vague sense. Also, by carefully inspecting the earlier argument of ")#link("http://www.ams.org/mathscinet-getitem?mr=2662426")[#text("Erdos, Peche, Ramirez, Schlein, and Yau")]#text(", we were able to establish convergence in the stronger local ")#mi("{L^1}")#text(" sense once one assumed some regularity and positivity condition on the underlying coefficient distribution. These are somewhat modest and technical improvements over previous work on the Wigner-Dyson-Mehta conjecture, but they help to clarify and organise the profusion of results in this area, which are now reaching a fairly definitive form.")

#text("It may well be possible to go beyond local ")#mi("{L^1}")#text(" convergence in the case of smooth ensembles, for instance establishing local uniform convergence; this was recently accomplished in the ")#mi("{k=1}")#text(" case by ")#link("http://arxiv.org/abs/1011.5594")[#text("Maltsev and Schlein")]#text(". Indeed one may optimistically expect to even have convergence in the local smooth topology, which would basically be the strongest convergence one could hope for.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/073f9bbbbfc973add29dc03530be757e3b91031342edaf9c95d8effd9bfc9a72-51b4dbf63f6ce9c2b77035301f937121792ff9bf75dd75903bf5151da10c29b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/#comment-50006")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("Typos: There are some problems with the rendering of the accent on Erdos’ name. It seems to be throwing out references with him as an author, or perhaps that is some other problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a0b2269b04c25cf604572838e7661d4f55b0c09932a313a7b630241db91b29d-9c15eff15c87588a0b2f38d7cbf1917154c8aea120d7abe360f9a56d92fcb51c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olivier Rival")]], [#link("https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/#comment-50009")[#strong[#text("Olivier Rival")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("Just a few minor corrections to a great post:")#linebreak()#text(" – Erdős’ name is mangled by LaTeX everytime it appears")#linebreak()#text(" – the right-hand side on the last two formulae of this post should not depend on “n”")#linebreak()#text(" Thank you for the work you put into writing this blog. It’s absolutely fascinating.")

#emph[#text("[Corrected, thanks, though I had to sacrifice the accent for technical reasons – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8b535ba19730c35a11a54e0f6a172b8257b3231d3f6bcb585012a98f16a4c7-b074f52a1020db534fef6621b105be8a1ffe96a2efd905bdf88cb80e35925a68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehud Schreiber")]], [#link("https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/#comment-50013")[#strong[#text("Ehud Schreiber")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2011")])]

#text("Hi,")

#text("another slight correction (according to my understanding) at the beginning of the second paragraph – the \\zeta’s have variance one, not the elements (divided by \\sqrt{n}).")

#text("Thanks for the post and for the work itself!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2011/02/01/the-wigner-dyson-mehta-bulk-universality-conjecture-for-wigner-matrices/#comment-50121")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2011")])]

#text("Professor Tau,")

#text("Just aften the statement of the Wigner-Dyson-Mehta conjecture, I think there is a hyperref typo: It says “\\href{Erdos-Ramirez-Schlein-Yau}, Erdos-Peche-Ramirez-Schlein-Yau” in the blog post.")

#emph[#text("[Corrected, thanks – T.]")]
]
