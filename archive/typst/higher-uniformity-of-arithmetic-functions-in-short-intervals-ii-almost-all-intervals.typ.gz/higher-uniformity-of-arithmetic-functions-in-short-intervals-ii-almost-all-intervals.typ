// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/
// Converted to Typst by tao2typ: "2026-10-14T15:21:02.591589+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Higher uniformity of arithmetic functions in short intervals II. Almost all intervals", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Higher uniformity of arithmetic functions in short intervals II. Almost all intervals")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 November 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/")[#text("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://users.utu.fi/ksmato/")[#text("Kaisa Matomäki")]#text(", ")#link("https://www.math.northwestern.edu/people/faculty/maksym-radziwill.html")[#text("Maksym Radziwill")]#text(", ")#link("https://www.ms.uky.edu/~xsh228/")[#text("Fernando Xuancheng Shao")]#text(", ")#link("https://sites.google.com/view/joniteravainen/")[#text("Joni Teräväinen")]#text(", and myself have (finally) uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2411.05770")[#text("Higher uniformity of arithmetic functions in short intervals II. Almost all intervals")]#text("“. This is a sequel to ")#link("https://terrytao.wordpress.com/2022/04/10/higher-uniformity-of-arithmetic-functions-in-short-intervals-i-all-intervals/")[#text("our previous paper")]#text(" from 2022. In that paper, discorrelation estimates such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq x+H} (\\Lambda(n) - \\Lambda^\\sharp(n)) \\bar{F}(g(n)\\Gamma) = o(H)")]]

#text("were established, where ")#mi("{\\Lambda}")#text(" is the von Mangoldt function, ")#mi("{\\Lambda^\\sharp}")#text(" was some suitable approximant to that function, ")#mi("{F(g(n)\\Gamma)}")#text(" was a nilsequence, and ")#mi("{[x,x+H]}")#text(" was a reasonably short interval in the sense that ")#mi("{H \\sim x^{\\theta+\\varepsilon}}")#text(" for some ")#mi("{0 < \\theta < 1}")#text(" and some small ")#mi("{\\varepsilon>0}")#text(". In that paper, we were able to obtain non-trivial estimates for ")#mi("{\\theta}")#text(" as small as ")#mi("{5/8}")#text(", and for some other functions such as divisor functions ")#mi("{d_k}")#text(" for small values of ")#mi("{k}")#text(", we could lower ")#mi("{\\theta}")#text(" somewhat to values such as ")#mi("{3/5}")#text(", ")#mi("{5/9}")#text(", ")#mi("{1/3}")#text(" of ")#mi("{\\theta}")#text(". This had a number of analytic number theory consequences, for instance in obtaining asymptotics for additive patterns in primes in such intervals. However, there were multiple obstructions to lowering ")#mi("{\\theta}")#text(" much further. Even for the model problem when ")#mi("{F(g(n)\\Gamma) = 1}")#text(", that is to say the study of primes in short intervals, until recently the best value of ")#mi("{\\theta}")#text(" available was ")#mi("{7/12}")#text(", although this was very recently improved to ")#mi("{17/30}")#text(" ")#link("https://arxiv.org/abs/2405.20552")[#text("by Guth and Maynard")]#text(".")

#text("However, the situation is better when one is willing to consider estimates that are valid for ")#emph[#text("almost all")]#text(" intervals, rather than all intervals, so that one now studies local higher order uniformity estimates of the form")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{2X} \\sup_{F,g} \\left| \\sum_{x \\leq n \\leq x+H} (\\Lambda(n) - \\Lambda^\\sharp(n)) \\bar{F}(g(n)\\Gamma)\\right|\\ dx = o(XH)", block: true)]]

#text("where ")#mi("{H = X^{\\theta+\\varepsilon}}")#text(" and the supremum is over all nilsequences of a certain Lipschitz constant on a fixed nilmanifold ")#mi("{G/\\Gamma}")#text(". This generalizes local Fourier uniformity estimates of the form")

#align(center)[#tao-fit-display[#tao-math("\\int_X^{2X} \\sup_{\\alpha} \\left| \\sum_{x \\leq n \\leq x+H} (\\Lambda(n) - \\Lambda^\\sharp(n)) e(-\\alpha n)\\right|\\ dx = o(XH).", block: true)]]

#text("There is particular interest in such estimates in the case of the Möbius function ")#mi("{\\mu(n)}")#text(" (where, as per the Möbius pseudorandomness conjecture, the approximant ")#mi("{\\mu^\\sharp}")#text(" should be taken to be zero, at least in the absence of a Siegel zero). This is because if one could get estimates of this form for any ")#mi("{H}")#text(" that grows sufficiently slowly in ")#mi("{X}")#text(" (in particular ")#mi("{H = \\log^{o(1)} X}")#text("), this would imply the (logarithmically averaged) Chowla conjecture, as I ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("showed in a previous paper")]#text(".")

#text("While one can lower ")#mi("{\\theta}")#text(" somewhat, there are still barriers. For instance, in the model case ")#mi("{F \\equiv 1}")#text(", that is to say prime number theorems in almost all short intervals, until very recently the best value of ")#mi("{\\theta}")#text(" was ")#mi("{1/6}")#text(", recently lowered to ")#mi("{2/15}")#text(" by Guth and Maynard (and can be lowered all the way to zero on the ")#link("https://www.aimath.org/WWN/rh/articles/html/25a/")[#text("Density Hypothesis")]#text("). Nevertheless, we are able to get some improvements at higher orders:")

#list(
[#text("For the von Mangoldt function, we can get ")#mi("{\\theta}")#text(" as low as ")#mi("{1/3}")#text(", with an arbitrary logarithmic saving ")#mi("{\\log^{-A} X}")#text(" in the error terms; for divisor functions, one can even get power savings in this regime.")],
[#text("For the Möbius function, we can get ")#mi("{\\theta=0}")#text(", recovering ")#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")[#text("our previous result with Tamar Ziegler")]#text(", but now with ")#mi("{\\log^{-A} X}")#text(" type savings in the exceptional set (though not in the pointwise bound outside of the set).")],
[#text("We can now also get comparable results for the divisor function.")]
)

#text("As sample applications, we can obtain Hardy-Littlewood conjecture asymptotics for arithmetic progressions of almost all given steps ")#mi("{h \\sim X^{1/3+\\varepsilon}}")#text(", and divisor correlation estimates on arithmetic progressions for almost all ")#mi("{h \\sim X^\\varepsilon}")#text(".")

#text("Our proofs are rather long, but broadly follow the “contagion” ")#link("https://arxiv.org/abs/2102.05564")[#text("strategy of Walsh")]#text(", generalized from the Fourier setting to the higher order setting. Firstly, by standard Heath–Brown type decompositions, and previous results, it suffices to control “Type II” discorrelations such as")

#align(center)[#tao-fit-display[#tao-math("\\sup_{F,g} \\left| \\sum_{x \\leq n \\leq x+H} \\alpha*\\beta(n) \\bar{F}(g(n)\\Gamma)\\right|", block: true)]]

#text("for almost all ")#mi("{x}")#text(", and some suitable functions ")#mi("{\\alpha,\\beta}")#text(" supported on medium scales. So the bad case is when for most ")#mi("{x}")#text(", one has a discorrelation")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x \\leq n \\leq x+H} \\alpha*\\beta(n) \\bar{F_x}(g_x(n)\\Gamma)\\right| \\gg H", block: true)]]

#text("for some nilsequence ")#mi("{F_x(g_x(n) \\Gamma)}")#text(" that depends on ")#mi("{x}")#text(".")

#text("The main issue is the dependency of the polynomial ")#mi("{g_x}")#text(" on ")#mi("{x}")#text(". By using a “nilsequence large sieve” introduced in our previous paper, and removing degenerate cases, we can show a functional relationship amongst the ")#mi("{g_x}")#text(" that is very roughly of the form")

#align(center)[#tao-fit-display[#mitex("g_x(an) \\approx g_{x^{\\prime}}(a^{\\prime}n)")]]

#text("whenever ")#mi("{n \\sim x/a \\sim x^{\\prime}/a^{\\prime}}")#text(" (and I am being extremely vague as to what the relation “")#mi("{\\approx}")#text("” means here). By a higher order (and quantitatively stronger) version of Walsh’s contagion analysis (which is ultimately to do with separation properties of Farey sequences), we can show that this implies that these polynomials ")#mi("{g_x(n)}")#text(" (which exert influence over intervals ")#mi("{[x,x+H]}")#text(") can “infect” longer intervals ")#mi("{[x^{\\prime}, x^{\\prime}+Ha]}")#text(" with some new polynomials ")#mi("{\\tilde g_{x^{\\prime}}(n)}")#text(" and various ")#mi("{x^{\\prime} \\sim Xa}")#text(", which are related to many of the previous polynomials by a relationship that looks very roughly like")

#align(center)[#tao-fit-display[#mitex("g_x(n) \\approx \\tilde g_{ax}(an).")]]

#text("This can be viewed as a rather complicated generalization of the following vaguely “cohomological”-looking observation: if one has some real numbers ")#mi("{\\alpha_i}")#text(" and some primes ")#mi("{p_i}")#text(" with ")#mi("{p_j \\alpha_i \\approx p_i \\alpha_j}")#text(" for all ")#mi("{i,j}")#text(", then one should have ")#mi("{\\alpha_i \\approx p_i \\alpha}")#text(" for some ")#mi("{\\alpha}")#text(", where I am being vague here about what ")#mi("{\\approx}")#text(" means (and why it might be useful to have primes). By iterating this sort of contagion relationship, one can eventually get the ")#mi("{g_x(n)}")#text(" to behave like an Archimedean character ")#mi("{n^{iT}}")#text(" for some ")#mi("{T}")#text(" that is not too large (polynomial size in ")#mi("{X}")#text("), and then one can use relatively standard (but technically a bit lengthy) “major arc” techiques based on various integral estimates for zeta and ")#mi("{L}")#text(" functions to conclude.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("Possible typo in reference [4]: Should “Ueber” be “Über”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("Strangely enough, ")#link("https://eudml.org/doc/148853")[#text("this was Hilbert’s actual title")]#text(" in his 1892 paper. It is possible that German spelling standards have changed slightly over the last century and a quarter. (The title could also have been an artefact of the typesetting technology of the era.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2024")])]

#text("From wikipedia (")#link("https://de.wikipedia.org/wiki/%C3%9C")[#text("https://de.wikipedia.org/wiki/%C3%9C")]#text(")")

#text("In the umlaut meaning, the Ü was first written as UE. This later evolved into a U with a small E above it (Uͤ /uͤ). Over time, this E was stylized into two dots.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0322db82681118e17ae9bdcac4c0740bf923d6f5d3c476b49a784f9ecd683e86-766891e0f0dc0b0334832a7b7ef9ea609566505454447f69eb5e47de0ac7de95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Budha Gautama sidarta")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686763")[#strong[#text("Budha Gautama sidarta")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2024")])]

#text("Is mathematics discovered or created?Platonism (discovery) argues that mathematical entities exist independently of human minds, in an abstract “Platonic realm.” Mathematicians, therefore, discover these concepts, rather than invent them. G.H. Hardy supported this view, noting that the beauty of certain formulas suggests a preexisting mathematical reality.Formalism and Constructivism (creation), on the other hand, claim that mathematics is a human invention. Concepts are created, with rules and axioms established to form a logical system. David Hilbert saw mathematics as a symbolic system without inherent external reality, while Constructivism adds that only concepts we can construct and verify have true validity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686839")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2024")])]

#text("I am very curious about your estimation of how difficult it would be to formalize works in this specific area of research. I read that the formalization of PFR was achieved so quickly because the field of combinatorics is well-developed in Lean. How does this compare to analytic number theory? How reliant is this field on other deep results in the literature? As far as I understand, PFR was largely self-contained. Is this also true for this result, or would it require reliance on many other complex results from the literature? Thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686841")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2024")])]

#text("Right now we have a project to ")#link("https://github.com/AlexKontorovich/PrimeNumberTheoremAnd")[#text("formalize the prime number theorem (PNT) in Lean")]#text(", as well as generalizations such as the prime number theorem in arithmetic progressions and the Chebotarev density theorem. We did manage to formalize the PNT, and are well on our way to formalizing the PNT in arithmetic progressions, but one stumbling block has been the ability to manipulate asymptotic estimates in the way that analysts are used to doing (e.g., combining together multiple O() or o() error terms into a single term, etc.). We can do it with the current Mathlib framework, but it is quite tedious; in particular, the “easy” parts of the PNT in which one converts from, say, control of the von Mangoldt function to control of the prime counting function, has turned out to be one of the more difficult steps in the argument to formalize. This is an issue that remains something of an open problem to resolve in the future. One possibility is to eschew asymptotic notation altogether and work with completely explicit estimates, which are avoided in human-readable proofs due to their fragility to arithmetic errors, but in the fully verified framework of Lean, this is not an issue.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c2e5a74e5c44819e3b488cefed88cd751e6b44d155c1c343b34325ebe09a24a-5c706ec675da98f0cd1ece0be9de0b52bae041828a45b794bc813d29b91ec933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit shingare")]], [#link("https://terrytao.wordpress.com/2024/11/11/higher-uniformity-of-arithmetic-functions-in-short-intervals-ii-almost-all-intervals/#comment-686973")[#strong[#text("Sumit shingare")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2024")])]

#text("Dear Professor Tao,")

#text("In a recent lecture, you mentioned that we might be just one breakthrough away from resolving all the logarithmically averaged versions of the Chowla and Sarnak conjectures. If such a breakthrough happens, how much closer do you think it would bring us to proving the full Chowla conjecture or even the Twin Prime Conjecture?")

#text("Additionally, do you believe the tools and techniques you and your collaborators have been developing will eventually play a role in tackling these conjectures directly, or do you think completely different methods will be required?")

#text("Your decades-long dedication to the study of primes is truly inspiring. I deeply appreciate your work and wish you all the best as you continue your groundbreaking research.")

#text("Sincerely,")

#text("Sumit")
]
