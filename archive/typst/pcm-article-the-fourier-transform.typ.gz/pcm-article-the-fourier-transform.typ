// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/
// Converted to Typst by tao2typ: "2026-10-19T13:43:28.990100+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: The Fourier transform", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: The Fourier transform")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/")[#text("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-19 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" by uploading my ")#link("http://www.math.ucla.edu/~tao/preprints/fourier.pdf")[#text("article on the Fourier transform")]#text(". Here, I chose to describe this transform as a means of decomposing general functions into more symmetric functions (such as sinusoids or plane waves), and to discuss a little bit how this transform is connected to differential operators such as the Laplacian. (This is of course only one of the many different uses of the Fourier transform, but again, with only five pages to work with, it’s hard to do justice to every single application. For instance, the connections with additive combinatorics are not covered at all.)")

#text("On the ")#link("http://pcm.tandtproductions.com/")[#text("official web site")]#text(" of the Companion (which you can access with the user name “Guest” and password “PCM”), there is a more polished version of the same article, after it had gone through a few rounds of the editing process.")

#text("I’ll also point out ")#link("http://www.ma.utexas.edu/users/benzvi/")[#text("David Ben-Zvi")]#text("‘s Companion article on “")#link("http://www.math.utexas.edu/users/benzvi/math/pcm0178.pdf")[#text("moduli spaces")]#text("“. This concept is deceptively simple – a space whose points are themselves spaces, or “representatives” or “equivalence classes” of such spaces – but it leads to the “correct” way of thinking about many geometric and algebraic objects, and more importantly about ")#emph[#text("families")]#text(" of such objects, without drowning in a mess of coordinate charts and formulae which serve to obscure the underlying geometry.")

#text("[")#emph[#text("Update")]#text(", Oct 21: categories fixed.]")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12430")[#strong[#text("Fourier transforms « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")]

#text("[…] The Princeton Companion to Mathematics article on Fourier transforms, written by Terence Tao, is available at Tao’s site; his way of defining the transforms is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a student")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12507")[#strong[#text("a student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2007")])]

#text("A typo in the Fourier paper – the ‘n’ is missing from “e^-inθ” in the definition of the Fourier coefficent, in the first equation on page 2.")

#text("Feel free to delete this comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32e47f968bce0347e828399fe4058359695f4ef5b42061a1d4bed44cdee655a7-42fe4a93f51198f781aaf0dd5e3092819cb9b26974e3e0b7fc743f11063f52b2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12525")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2007")])]

#text("I was excited to see this topic because non Abelian Fourier transforms have ")#link("http://kea-monad.blogspot.com/2007/10/m-theory-lesson-108.html")[#text("recently been put forward")]#text(" as an expalantion for the Koide lepton mass formulas. I’d love to see more on the subject from the mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jasper")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12580")[#strong[#text("jasper")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2007")])]

#text("this post hasn’t yet been tagged “companion”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2007")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8d1c2ec78a5174da93eea303845ee681eb6e5507b7024919c56e6a2bdb1367d-a132d6e9d7ab8da5da7bcbe34959f00f8c5d17ce6c89bdef743331442d4b007b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12617")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("Dear Terence,")#linebreak()#text(" shouldn’t pi have exponent 2 in the right hand side of the second equation on page 3 (where you calculate the Laplacian of a plane wave) ?")#linebreak()#text(" If it were indeed so, this exponent should also be restored further down in the text.")

#text("Sincere greetings,")#linebreak()#text(" Attila.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3948c22798e2632c39acdcd2036dd86c420c70658eef3dc0b2edf2b9423e6b0b-0b5da07b38d6f022723acd140c3a610919f38899ff51fd3e4d3542cc704ae10e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12665")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("This question is probably beyond the scope of your PCM article, but I am trying to understand the relation of degrees of freedom, dimensions and constraints.")

#text("Consider your phrases in this post:")#linebreak()#text(" “… (such as sinusoids or plane waves) …” and “… additive combinatorics …”.")

#text("The sinusoid is often displayed on an oscilloscope.")#linebreak()#text(" The sinusoid implies movement, usually from 0 to x*PI, sometimes vice versa.")#linebreak()#text(" The sinusoid has a period of 2*PI with period time T not specified.")

#text("Question:")#linebreak()#text(" Could motion be one degree of freedom [dof] dynamically, with two, three, one or zero constraints of space static [in the usual x,y,z axes] resulting in three, four, two or one dimensions [D]?")

#text("The sinusoid would be combinatoric (1+2)!/(1!2!) with:")#linebreak()#text(" one dof, 2 constraints, 3 D [?] in a 3 axes [x,y,z] graph with motion implied.")

#text("The helix would be combinatoric (1+3)!/(1!3!) with:")#linebreak()#text(" one dof, 3 constraints, 4 D [?] in a 2 axes [x,y] graph with motion implied.")

#text("The line would be combinatoric (1+1)!/(1!1!) with:")#linebreak()#text(" one dof, 1 constraints, 2 D [?] in a 1 axis [x] graph bidirectional with motion implied.")

#text("The line would be combinatoric (1+0)!/(1!0!) with:")#linebreak()#text(" one dof, 0 constraints, 1 D [?] in a 1 axis [x] graph unidirectional with motion implied.")

#text("Note that the helix is referred to as “zitterbewegung” or “oscillating motion” by Davis Hestenes [physics emeritus ASU-US], ‘The Kinematic Origin of Complex Wave Functions’.")

#link("http://modelingnts.la.asu.edu/pdf/Kinematic.pdf")[#text("Click to access Kinematic.pdf")]

#text("I am also using [correctly?] the “amplitwist” concept of Tristan Needham, ‘Visual Complex Analysis’ with the amplitude at zero in two and one D above.")

#link("http://www.usfca.edu/vca/")[#text("http://www.usfca.edu/vca/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a student")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12671")[#strong[#text("a student")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2007")])]

#text("On the first page where you define the harmonic function of order j there is missing an “f”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2007")])]

#text("Thanks again for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2007")])]

#text("Dear Doug,")

#text("The ancient Greeks believed that human health was determined by the balance of four fluids or humours (blood, yellow bile, black bile, and phlegm). They then spent a lot of effort investigating analogies and connections with other quadruplets, such as their four elements (earth, air, fire, and water), the four seasons, and so forth. Unfortunately, their theory was totally incorrect – science cannot be based on superficial similarities, but must instead work with precise theories and controlled experiments.")

#text("The situation is similar in mathematics: seeing a chance numerical relationship, an interesting shape, or the use of similar terminology, in two different parts of mathematics, is unfortunately too superficial of an observation to lead to anything of consequence unless backed up by rigorous partial results, extensive numerics, or other substantial pieces of mathematical evidence. Your interest in mathematics is admirable, but I am afraid that you will have to first learn how to think rigorously (with precise definitions, and being able to construct valid proofs and arguments) before these sorts of fuzzy speculations and vague questions can be meaningfully addressed. If you have the opportunity, I would recommend taking some higher maths classes, particularly those which emphasise proofs and rigour.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3948c22798e2632c39acdcd2036dd86c420c70658eef3dc0b2edf2b9423e6b0b-0b5da07b38d6f022723acd140c3a610919f38899ff51fd3e4d3542cc704ae10e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-12831")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2007")])]

#text("I am rather disappointed in the list of mathematicians at PCM, TOC, V, although I do realize that it is difficult to be all inclusive.")#linebreak()#text(" ")#link("http://pcm.tandtproductions.com/toc.php?sectionId=5")[#text("http://pcm.tandtproductions.com/toc.php?sectionId=5")]

#text("Some of the missing are:")#linebreak()#text(" Applied mathematicians:")#linebreak()#text(" Caspar Wessel [surveyor]")#linebreak()#text(" CP Steinmetz [IEEE]")#linebreak()#text(" Nobel laureates, physics and economics:")#linebreak()#text(" PAM Dirac")#linebreak()#text(" John Nash")#linebreak()#text(" Reinhard Selten")#linebreak()#text(" John Harsanyi")#linebreak()#text(" and a number of Fields, Nevanlinna and Gauss awardees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c425c42d515340f75fc8b628fd758ca60df7f7a75234ebadfe0d954c2c9989-046854db9fdb036b5bed3fdd8b2209acc1a044e756d7c81a9777d9370d3e49bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katestange")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-21766")[#strong[#text("katestange")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("Small typo in the article: I believe you are missing a subscript ‘j’ in an inline equation a couple lines after the displayed equations in the second column of the first page.")

#text("‘and that $f_j(\\omega z) = \\omega^j f(z)$ for every $z$’")

#text("should read")

#text("‘and that $f_j(\\omega z) = \\omega^j f_j(z)$ for every $z$’")

#text("This is in the proof version currently on the PCM website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-21867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-37174")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2009")])]

#text("I am wondering if the property of Fourier Transform, that the Fourier Transform of kth derivative of f is the Fourier transform of f multiplied by the transform variable raised to the power of k, remains true for the case of the Sobolev derivative instead of an ordinary derivative. Anybody who can let me know, please do.")

#text("Best,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-37271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Yes, the weak derivative (and its fractional powers) used (among other things) in the construction of Sobolev spaces enjoys the same algebraic relationship with the Fourier transform as the ordinary derivative (provided, of course, that the Fourier transform is taken in an appropriately weak sense also, e.g. in the sense of distributions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/19/pcm-article-the-fourier-transform/comment-page-1/#comment-556029")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("The link to the “official web site” seems to be broken now.")

#emph[#text("[It appears to be defunct now that the book is published. -T]")]
]
