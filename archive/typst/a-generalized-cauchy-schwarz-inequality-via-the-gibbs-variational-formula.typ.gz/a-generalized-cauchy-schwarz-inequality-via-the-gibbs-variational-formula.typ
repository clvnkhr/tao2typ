// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/
// Converted to Typst by tao2typ: "2026-10-14T15:20:58.153031+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A generalized Cauchy-Schwarz inequality via the Gibbs variational formula", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A generalized Cauchy-Schwarz inequality via the Gibbs variational formula")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 December 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/")[#text("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{S}")#text(" be a non-empty finite set. If ")#mi("{X}")#text(" is a random variable taking values in ")#mi("{S}")#text(", the Shannon entropy ")#mi("{H[X]}")#text(" of ")#mi("{X}")#text(" is defined as")

#align(center)[#tao-fit-display[#mitex("H[X] = -\\sum_{s \\in S} {\\bf P}[X = s] \\log {\\bf P}[X = s].")]]

#text("There is a nice variational formula that lets one compute logs of sums of exponentials in terms of this entropy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Gibbs variational formula)")]#text(" ")#metadata(none) <tao-c0bc2a1f1e0fc424d6c6>#text(" Let ")#mi("{f: S \\rightarrow {\\bf R}}")#text(" be a function. Then")

#metadata(none) <tao-2995ff81d719dc2131e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\log \\sum_{s \\in S} \\exp(f(s)) = \\sup_X {\\bf E} f(X) + {\\bf H}[X].")]]
]

#emph[#text("Proof:")]#text(" Note that shifting ")#mi("{f}")#text(" by a constant affects both sides of ")#link(<tao-2995ff81d719dc2131e0>)[#text("(1)")]#text(" the same way, so we may normalize ")#mi("{\\sum_{s \\in S} \\exp(f(s)) = 1}")#text(". Then ")#mi("{\\exp(f(s))}")#text(" is now the probability distribution of some random variable ")#mi("{Y}")#text(", and the inequality can be rewritten as")

#align(center)[#tao-fit-display[#mitex("0 = \\sup_X \\sum_{s \\in S} {\\bf P}[X = s] \\log {\\bf P}[Y = s] -\\sum_{s \\in S} {\\bf P}[X = s] \\log {\\bf P}[X = s].")]]

#text("But this is precisely the ")#link("https://en.wikipedia.org/wiki/Gibbs%27_inequality")[#text("Gibbs inequality")]#text(". (The expression inside the supremum can also be written as ")#mi("{-D_{KL}(X||Y)}")#text(", where ")#mi("{D_{KL}}")#text(" denotes ")#link("https://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence")[#text("Kullback-Leibler divergence")]#text(". One can also interpret this inequality as a special case of ")#link("https://en.wikipedia.org/wiki/Convex_conjugate#Fenchel's_inequality")[#text("the Fenchel–Young inequality")]#text(" relating the conjugate convex functions ")#mi("{x \\mapsto e^x}")#text(" and ")#mi("{y \\mapsto y \\log y - y}")#text(".) ")#mi("\\Box")

#text("In this note I would like to use this variational formula (which is also known as the Donsker-Varadhan variational formula) to give another proof of the following ")#link("https://zbmath.org/1043.05011")[#text("inequality of Carbery")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Generalized Cauchy-Schwarz inequality)")]#text(" Let ")#mi("{n \\geq 0}")#text(", let ")#mi("{S, T_1,\\dots,T_n}")#text(" be finite non-empty sets, and let ")#mi("{\\pi_i: S \\rightarrow T_i}")#text(" be functions for each ")#mi("{i=1,\\dots,n}")#text(". Let ")#mi("{K: S \\rightarrow {\\bf R}^+}")#text(" and ")#mi("{f_i: T_i \\rightarrow {\\bf R}^+}")#text(" be positive functions for each ")#mi("{i=1,\\dots,n}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{s \\in S} K(s) \\prod_{i=1}^n f_i(\\pi_i(s)) \\leq Q \\prod_{i=1}^n (\\sum_{t_i \\in T_i} f_i(t_i)^{n+1})^{1/(n+1)}")]]

#text("where ")#mi("{Q}")#text(" is the quantity")

#align(center)[#tao-fit-display[#mitex("Q := (\\sum_{(s_0,\\dots,s_n) \\in \\Omega_n} K(s_0) \\dots K(s_n))^{1/(n+1)}")]]

#text("where ")#mi("{\\Omega_n}")#text(" is the set of all tuples ")#mi("{(s_0,\\dots,s_n) \\in S^{n+1}}")#text(" such that ")#mi("{\\pi_i(s_{i-1}) = \\pi_i(s_i)}")#text(" for ")#mi("{i=1,\\dots,n}")#text(".")
]

#text("Thus for instance, the identity is trivial for ")#mi("{n=0}")#text(". When ")#mi("{n=1}")#text(", the inequality reads")

#align(center)[#tao-fit-display[#mitex("\\sum_{s \\in S} K(s) f_1(\\pi_1(s)) \\leq (\\sum_{s_0,s_1 \\in S: \\pi_1(s_0)=\\pi_1(s_1)} K(s_0) K(s_1))^{1/2}")]]

#align(center)[#tao-fit-display[#mitex("( \\sum_{t_1 \\in T_1} f_1(t_1)^2)^{1/2},")]]

#text("which is easily proven by Cauchy-Schwarz, while for ")#mi("{n=2}")#text(" the inequality reads")

#align(center)[#tao-fit-display[#mitex("\\sum_{s \\in S} K(s) f_1(\\pi_1(s)) f_2(\\pi_2(s))")]]

#align(center)[#tao-fit-display[#mitex("\\leq (\\sum_{s_0,s_1, s_2 \\in S: \\pi_1(s_0)=\\pi_1(s_1); \\pi_2(s_1)=\\pi_2(s_2)} K(s_0) K(s_1) K(s_2))^{1/3}")]]

#align(center)[#tao-fit-display[#mitex("(\\sum_{t_1 \\in T_1} f_1(t_1)^3)^{1/3} (\\sum_{t_2 \\in T_2} f_2(t_2)^3)^{1/3}")]]

#text("which can also be proven by elementary means. However even for ")#mi("{n=3}")#text(", the existing proofs require the “tensor power trick” in order to reduce to the case when the ")#mi("{f_i}")#text(" are step functions (in which case the inequality can be proven elementarily, as discussed in the above paper of Carbery).")

#text("We now prove this inequality. We write ")#mi("{K(s) = \\exp(k(s))}")#text(" and ")#mi("{f_i(t_i) = \\exp(g_i(t_i))}")#text(" for some functions ")#mi("{k: S \\rightarrow {\\bf R}}")#text(" and ")#mi("{g_i: T_i \\rightarrow {\\bf R}}")#text(". If we take logarithms in the inequality to be proven and apply Lemma ")#link(<tao-c0bc2a1f1e0fc424d6c6>)[#text("1")]#text(", the inequality becomes")

#align(center)[#tao-fit-display[#mitex("\\sup_X {\\bf E} k(X) + \\sum_{i=1}^n g_i(\\pi_i(X)) + {\\bf H}[X]")]]

#tao-aligned(keep: true)[


#tao-math(" & \\leq \\frac{1}{n+1} \\sup_{(X_0,\\dots,X_n)} {\\bf E} k(X_0)+\\dots+k(X_n) + {\\bf H}[X_0,\\dots,X_n]", block: true)



#tao-math(" & + \\frac{1}{n+1} \\sum_{i=1}^n \\sup_{Y_i} (n+1) {\\bf E} g_i(Y_i) + {\\bf H}[Y_i]", block: true)
]

#text("where ")#mi("{X}")#text(" ranges over random variables taking values in ")#mi("{S}")#text(", ")#mi("{X_0,\\dots,X_n}")#text(" range over tuples of random variables taking values in ")#mi("{\\Omega_n}")#text(", and ")#mi("{Y_i}")#text(" range over random variables taking values in ")#mi("{T_i}")#text(". Comparing the suprema, the claim now reduces to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Conditional expectation computation)")]#text(" Let ")#mi("{X}")#text(" be an ")#mi("{S}")#text("-valued random variable. Then there exists a ")#mi("{\\Omega_n}")#text("-valued random variable ")#mi("{(X_0,\\dots,X_n)}")#text(", where each ")#mi("{X_i}")#text(" has the same distribution as ")#mi("{X}")#text(", and")

#tao-aligned(keep: true)[


#tao-math("{\\bf H}[X_0,\\dots,X_n]  & = (n+1) {\\bf H}[X]", block: true)



#tao-math(" & - {\\bf H}[\\pi_1(X)] - \\dots - {\\bf H}[\\pi_n(X)].", block: true)
]
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{n}")#text(". When ")#mi("{n=0}")#text(" we just take ")#mi("{X_0 = X}")#text(". Now suppose that ")#mi("{n \\geq 1}")#text(", and the claim has already been proven for ")#mi("{n-1}")#text(", thus one has already obtained a tuple ")#mi("{(X_0,\\dots,X_{n-1}) \\in \\Omega_{n-1}}")#text(" with each ")#mi("{X_0,\\dots,X_{n-1}}")#text(" having the same distribution as ")#mi("{X}")#text(", and")

#align(center)[#tao-fit-display[#mitex("{\\bf H}[X_0,\\dots,X_{n-1}] = n {\\bf H}[X] - {\\bf H}[\\pi_1(X)] - \\dots - {\\bf H}[\\pi_{n-1}(X)].")]]

#text("By hypothesis, ")#mi("{\\pi_n(X_{n-1})}")#text(" has the same distribution as ")#mi("{\\pi_n(X)}")#text(". For each value ")#mi("{t_n}")#text(" attained by ")#mi("{\\pi_n(X)}")#text(", we can take conditionally independent copies of ")#mi("{(X_0,\\dots,X_{n-1})}")#text(" and ")#mi("{X}")#text(" conditioned to the events ")#mi("{\\pi_n(X_{n-1}) = t_n}")#text(" and ")#mi("{\\pi_n(X) = t_n}")#text(" respectively, and then concatenate them to form a tuple ")#mi("{(X_0,\\dots,X_n)}")#text(" in ")#mi("{\\Omega_n}")#text(", with ")#mi("{X_n}")#text(" a further copy of ")#mi("{X}")#text(" that is conditionally independent of ")#mi("{(X_0,\\dots,X_{n-1})}")#text(" relative to ")#mi("{\\pi_n(X_{n-1}) = \\pi_n(X)}")#text(". One can the use the ")#link("https://en.wikipedia.org/wiki/Conditional_entropy#Chain_rule")[#text("entropy chain rul")]#text("e to compute")

#tao-aligned(keep: true)[


#tao-math("{\\bf H}[X_0,\\dots,X_n]  & = {\\bf H}[\\pi_n(X_n)] + {\\bf H}[X_0,\\dots,X_n| \\pi_n(X_n)]", block: true)



#tao-math(" & = {\\bf H}[\\pi_n(X_n)] + {\\bf H}[X_0,\\dots,X_{n-1}| \\pi_n(X_n)] + {\\bf H}[X_n| \\pi_n(X_n)]", block: true)



#tao-math(" & = {\\bf H}[\\pi_n(X)] + {\\bf H}[X_0,\\dots,X_{n-1}| \\pi_n(X_{n-1})] + {\\bf H}[X_n| \\pi_n(X_n)]", block: true)



#tao-math(" & = {\\bf H}[\\pi_n(X)] + ({\\bf H}[X_0,\\dots,X_{n-1}] - {\\bf H}[\\pi_n(X_{n-1})])", block: true)



#tao-math(" & + ({\\bf H}[X_n] - {\\bf H}[\\pi_n(X_n)])", block: true)



#tao-math(" & ={\\bf H}[X_0,\\dots,X_{n-1}] + {\\bf H}[X_n] - {\\bf H}[\\pi_n(X_n)]", block: true)
]

#text("and the claim now follows from the induction hypothesis. ")#mi("\\Box")

#text("With a little more effort, one can replace ")#mi("{S}")#text(" by a more general measure space (and use differential entropy in place of Shannon entropy), to recover Carbery’s inequality in full generality; we leave the details to the interested reader.")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2023")])]

#text("Thanks Prof Tao for this useful information. A new inequality might be the key to solving some difficult problems. Dr. Hayes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682468")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2023")])]

#text("“Kullback-Leibler divergence” is the correct spelling.")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2023")])]

#text("Note: The comment software does not appear to allow for any identification of the commenter, but just prints the disembodied comment and attributes it to “Anonymous”.")

#text("I hope this can be fixed soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682481")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("It won’t be fixed. It’s the new feature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682483")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2023")])]

#text("Who the f*ck is Anonymous????? … Terry Tao you might as well rename your blog to that of your gutless faceless proof-reader who persists in correcting every single tiny little unimportant spelling mistake for the simple reason of totally dominating this world renowned blog with his petulant presence … my name is Jenda Vondra and I’m from Australia and we Aussies can only take so much crap!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682891")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("What the heck bro 😭")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("We’re going to need a bigger number.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("Yes, much bigger.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682630")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2023")])]

#text("even bigger than that")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85fec62161e04c2ae3b028b5eccf6ff083ede62b26d23968a23e4789869f23bf-0ca208eb6faafa70367604d809ad364a6359d20b904df7c950b7bf3d3c2fa5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Carbery")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682471")[#strong[#text("Tony Carbery")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("Thanks Terry, it’s great to see this inequality in a wider context!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("Now I remember where I saw this trick before – it appears in ")#link("https://arxiv.org/abs/0710.0870")[#text("this paper of Carlen and Cordero-Erasquin")]#text(" in which they demonstrate using the Gibbs variational formula that the Brascamp-Lieb inequality is equivalent to an entropy version of that inequality. As the above example demonstrates, this equivalence extends to a more general class of inequalities than the classical Brascamp-Lieb inequalities (in that paper, for instance, they also note that it applies to spherical analogues of that inequality).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("Is this apropos of anything? Does it have anything to do with the proof of PFR, beyond “this is an inequality about entropy that should be more widely known”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("Why does it have to be apropos of anything?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2023")])]

#text("In ")#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/terrytao.wordpress.com/a-sl#comment-682462")[#text("this comment")]#text(", Prof. Tao read a paper about this inequality and decided to write a blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682605")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2023")])]

#text("“… the inequality can be rewritten as …”")

#text("Surely, at this point, we have an equation, rather than an inequality? That’s what the “=” sign means usually. Unless, of course, it has a different meaning in the calc. of variations …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43cdfb93f8d5f11dfcd5a6a26c345bd6d8de56d4d1c6b32ceb0650b9119f3fa6-89e903884737e1cf38f9e87ad9710adc7e0bfddfad0ab2f8271a352b3c50b4d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Alvarado")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682661")[#strong[#text("Jose Alvarado")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2023")])]

#text("Thank you, Prof. Tao, for sharing this interesting approach.")

#text("I apologize if the validity of the following comment seems obvious, but it appears that we can deduce (from the proof of Lemma 3) a similar lemma with extra flexibility. The statement is as follows:")

#text("“")#mi("\\text{Let } X \\in \\mathcal{X} \\text{ and } Y \\in \\mathcal{Y} \\text{ be two random variables. Given two functions } f: \\mathcal{X} \\to \\mathcal{T} \\text{ and } g: \\mathcal{Y} \\to \\mathcal{T}. \\text{ Then, there exists a random variable } (X^{\\prime},Y^{\\prime}) \\in \\Omega := \\{(x,y) \\in \\mathcal{X} \\times \\mathcal{Y} : f(x) = g(y)\\} \\text{ such that } X^{\\prime} \\text{ is a copy of } X, Y^{\\prime} \\text{ is a copy of } Y, \\text{ and}")#linebreak()#text(" ")#mi("\\mathbf{H}[X^{\\prime},Y^{\\prime}] = \\mathbf{H}[X^{\\prime}] + \\mathbf{H}[Y^{\\prime}] - \\mathbf{H}[g(Y^{\\prime})].")#text(" ”")

#text("Does that make sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682670")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2023")])]

#text("I think one may need a hypothesis that ")#mi("f(X)")#text(" and ")#mi("g(Y)")#text(" have the same distribution in order to reach this conclusion. (For instance, if ")#mi("f(X)")#text(" and ")#mi("g(Y)")#text(" take completely disjoint values, then ")#mi("\\Omega")#text(" is empty and the claim cannot hold.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43cdfb93f8d5f11dfcd5a6a26c345bd6d8de56d4d1c6b32ceb0650b9119f3fa6-89e903884737e1cf38f9e87ad9710adc7e0bfddfad0ab2f8271a352b3c50b4d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoseDAlvarado")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682671")[#strong[#text("JoseDAlvarado")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2023")])]

#text("Oops… Of course, you are right! It is imperative to add a hypothesis concerning the random variables ")#mi("f(X)")#text(" and ")#mi("g(Y)")#text(". Thanks for the clarification :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eb72580c7206e504ea9ed77ce69622a20efb40588fcf99e74253c48b20ef0d8-9b9120d739500d03a3c91700645efc5ba23ba265876d9aab6841dd214d7a0e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Malkoun")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682763")[#strong[#text("Joseph Malkoun")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2024")])]

#text("I have a small comment. If you have, say, only 2 real random variables, say ")#mi("X")#text(" and ")#mi("Y")#text(", and you have ")#mi("N")#text(" data points ")#mi("(x_i, y_i)")#text(" in the ")#mi("xy")#text("-plane, for ")#mi("i = 1, \\ldots, n")#text(", one can, say, form the ")#mi("2 \\times N")#text(" matrix ")#mi("A")#text(" containing ")#mi("(x_i, y_i)")#text(" as its ")#mi("i")#text("-th column. In order to talk about the sample covariance matrix of ")#mi("X")#text(" and ")#mi("Y")#text(", one could of course follow the probability definition, but it also can be viewed geometrically in 2 steps: removing the mean value of ")#mi("X")#text(" from ")#mi("X")#text(", for example, corresponds to orthogonal projection onto the orthogonal complement of ")#mi("(1, \\ldots, 1)")#text(" (")#mi("N")#text(" components) in ")#mi("\\mathbb{R}^N")#text(". The covariance matrix is then the Gram matrix of the orthogonal projections (as in my previous sentence) of the 2 rows of ")#mi("A")#text(".")

#text("Thus, in some sense, the language of probability is dual to the language of geometry. It is a bit like deciding whether to look at ")#mi("A")#text(" as ")#mi("N")#text(" points in ")#mi("\\mathbb{R}^2")#text(", or as ")#mi("2")#text(" points in ")#mi("\\mathbb{R}^N")#text(", which are of course dual points of view.")

#text("My remark is trivial, and of course known, but I wonder if it can be, or perhaps has been already made into a systematic transform/duality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682831")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2024")])]

#text("This looks a bit like reflection-positivity, maybe just because that uses Cauchy-Schwarz. Is there a quantum analogue, if you replace expectations with respect to measures by states, and replace random variables by self adjoint operators?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684498")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2024")])]

#text("Yes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("Sir please explain the sphere emersion , I kindly request to you, thanking you sir with huge respect")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-682890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("Our of context but, how would the Gibbs variational formula work for measure theoretic entropy? I don’t see it anywhere properly defined anyway except this blog")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684443")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2024")])]

#text("Hey big bro you have to contribute to mathstackexchange the poor kids are trying to learn")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2024")])]

#text("Lmao yes nationalize math education")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb67f6012863715a0f02baa4e096ec3188bd15cde79a5c841b3f157252e5ceff-a51421a23636883eeee42b249e3cdf17d7e50c8609c01523670f2dea5419c305.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T Retsu")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684444")[#strong[#text("T Retsu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2024")])]

#text("In the proof of Lemma 1, the inequality can be rewritten as:")

#mi("\\displaystyle0=\\sup_X\\sum_{s\\in S}\\textbf{P}[X=s]\\textbf{P}[Y=s]-\\sum_{s\\in S}\\textbf{P}[X=s]\\mathrm{log}\\textbf{P}[X=s]")#text(".")

#text("There isn’t any ")#mi("\\mathrm{log}")#text(" in the ")#mi("\\textbf{E}")#text(".")

#emph[#text("[Actually, the identity was correct as originally written: note that ")#mi("\\textbf{P}[Y=s]")#text(" is equal to ")#mi("\\exp(f(s))")#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2024")])]

#text("Many thanks for the answer. It is correct. Lemma 1 is proven.")

#text("A question about the terminology:")

#text("convex conjugate")

#text("instead of “conjugate convex”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2024")])]

#text("Dear prof. Tao,")#linebreak()#text(" Do you know in what regards these generalized inequalities could be lifted to infinite (perhaps uncountable sets S)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2024")])]

#text("Thank you Prof Tao for working on cybersecurity for the federal government, I can’t wait to see your new work on lie algebra and prime numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/10/a-generalized-cauchy-schwarz-inequality-via-the-gibbs-variational-formula/#comment-684715")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2024")])]

#text("“working for the federal government” aka being a slave of the state")
]
]
