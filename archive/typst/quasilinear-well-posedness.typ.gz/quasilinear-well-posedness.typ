// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/
// Converted to Typst by tao2typ: "2026-10-14T08:54:49.901330+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quasilinear well-posedness", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quasilinear well-posedness")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/")[#text("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("When solving the initial value problem to an ")#link("http://en.wikipedia.org/wiki/Ordinary_differential_equation")[#text("ordinary differential equation")]#text(", such as ")#metadata(none) <tao-ac1b5c0961a7269b6a05>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t u = F(u); \\quad u(0) = u_0,")]]

#text("where ")#mi("{u: {\\bf R} \\rightarrow V}")#text(" is the unknown solution (taking values in some finite-dimensional vector space ")#mi("{V}")#text("), ")#mi("{u_0 \\in V}")#text(" is the initial datum, and ")#mi("{F: V \\rightarrow V}")#text(" is some nonlinear function (which we will take to be smooth for sake of argument), then one can construct a solution locally in time via the ")#link("http://en.wikipedia.org/wiki/Fixed_point_iteration")[#text("Picard iteration method")]#text(". There are two basic ideas. The first is to use the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" to rewrite the initial value problem ")#link(<tao-ac1b5c0961a7269b6a05>)[#text("(1)")]#text(" as the problem of solving an ")#link("http://en.wikipedia.org/wiki/Integral_equation")[#text("integral equation")]#text(", ")#metadata(none) <tao-1a20f6d5510e063e9244>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("u(t) = u_0 + \\int_0^t F(u(s))\\ ds.")]]

#text("The second idea is to solve this integral equation by the ")#link("http://en.wikipedia.org/wiki/Contraction_mapping_theorem")[#text("contraction mapping theorem")]#text(", showing that the integral operator ")#mi("{{\\mathcal N}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("{\\mathcal N}(u) (t) := u_0 + \\int_0^t F(u(s))\\ ds")]]

#text("is a contraction on a suitable complete metric space (e.g. a closed ball in the function space ")#mi("{C^0([0,T]; V)}")#text("), and thus has a unique fixed point in this space. This method works as long as one only seeks to construct ")#emph[#text("local")]#text(" solutions (for time ")#mi("{t}")#text(" in ")#mi("{[0,T]}")#text(" for sufficiently small ")#mi("{T>0}")#text("), but the solutions constructed have a number of very good properties, including")

#list(
[#strong[#text("Existence")]#text(": A solution ")#mi("{u}")#text(" exists in the space ")#mi("{C^0([0,T];V)}")#text(" (and even in ")#mi("{C^\\infty([0,T];V)}")#text(") for ")#mi("{T}")#text(" sufficiently small.")],
[#strong[#text("Uniqueness")]#text(": There is at most one solution ")#mi("{u}")#text(" to the initial value problem in the space ")#mi("{C^0([0,T];V)}")#text(" (or in smoother spaces, such as ")#mi("{C^\\infty([0,T];V)}")#text("). (For solutions in the weaker space ")#mi("{C^0([0,T];V)}")#text(" we use the integral formulation ")#link(<tao-1a20f6d5510e063e9244>)[#text("(2)")]#text(" to define the solution concept.)")],
[#strong[#text("Lipschitz continuous dependence on the data")]#text(": If ")#mi("{u_0^{(n)}}")#text(" is a sequence of initial data converging to ")#mi("{u_0}")#text(", then the associated solutions ")#mi("{u^{(n)}}")#text(" converge uniformly to ")#mi("{u}")#text(" on ")#mi("{[0,T]}")#text(" (possibly after shrinking ")#mi("{T}")#text(" slightly). In fact we have the Lipschitz bound ")#tao-math("{\\left\\| u^{(n)}(t) - u(t) \\right\\|_V \\leq C \\left\\| u^{(n)}_0 - u_0 \\right\\|_V}", block: false)#text(" for ")#mi("{n}")#text(" large enough and ")#mi("{t \\in [0,T]}")#text(", where ")#mi("{C}")#text(" is an absolute constant.")]
)

#text("This package of properties is referred to as ")#emph[#text("(Lipschitz) wellposedness")]#text(".")

#text("This method extends to certain ")#link("http://en.wikipedia.org/wiki/Partial_differential_equation")[#text("partial differential equations")]#text(", particularly those of a ")#emph[#text("semilinear")]#text(" nature (linear except for lower order nonlinear terms). For instance, if trying to solve an initial value problem of the form")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + Lu = F(u); \\quad u(0,x) = u_0(x),")]]

#text("where now ")#mi("{u: {\\bf R} \\rightarrow V}")#text(" takes values in a function space ")#mi("{V}")#text(" (e.g. a Sobolev space ")#mi("{H^k({\\bf R}^d)}")#text("), ")#mi("{u_0 \\in V}")#text(" is an initial datum, ")#mi("{L}")#text(" is some (differential) operator (")#emph[#text("independent")]#text(" of ")#mi("{u}")#text(") that is (densely) defined on ")#mi("{V}")#text(", and ")#mi("{F}")#text(" is a nonlinearity which is also (densely) defined on ")#mi("{V}")#text(", then (formally, at least) one can solve this problem by using ")#link("http://en.wikipedia.org/wiki/Duhamel's_integral")[#text("Duhamel’s formula")]#text(" to convert the problem to that of solving an integral equation")

#align(center)[#tao-fit-display[#mitex("u(t) = e^{-tL} u_0 + \\int_0^t e^{-(t-s)L} F(u(s))\\ ds")]]

#text("and one can then hope to show that the associated nonlinear integral operator")

#align(center)[#tao-fit-display[#mitex("u \\mapsto e^{-tL} u_0 + \\int_0^t e^{-(t-s)L} F(u(s))\\ ds")]]

#text("is a contraction in a subset of a suitably chosen function space.")

#text("This method turns out to work surprisingly well for many semilinear partial differential equations, and in particular for semilinear parabolic, semilinear dispersive, and semilinear wave equations. As in the ODE case, when the method works, it usually gives the entire package of Lipschitz well-posedness: existence, uniqueness, and Lipschitz continuous dependence on the initial data, for short times at least.")

#text("However, when one moves from semilinear initial value problems to ")#emph[#text("quasilinear")]#text(" initial value problems such as")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + L_u u = F(u); \\quad u(0,x) = u_0(x)")]]

#text("in which the top order operator ")#mi("{L_u}")#text(" now depends on the solution ")#mi("{u}")#text(" itself, then the nature of well-posedness changes; one can still hope to obtain (local) existence and uniqueness, and even continuous dependence on the data, but one usually is forced to give up Lipschitz continuous dependence at the highest available regularity (though one can often recover it at lower regularities). As a consequence, the Picard iteration method is not directly suitable for constructing solutions to such equations.")

#text("One can already see this phenomenon with a very simple equation, namely the one-dimensional constant-velocity ")#emph[#text("transport equation")]#text(" ")#metadata(none) <tao-6694ea8075001f6628da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t u + c \\partial_x u = 0; \\quad u(0,x) = u_0(x)")]]

#text("where we consider ")#mi("{c = c_0}")#text(" as part of the initial data. (If one wishes, one could view this equation as a rather trivial example of a system.")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + c \\partial_x u  & = 0; \\quad \\partial_t c = 0", block: true)



#tao-math("u(0,x)  & = u_0(x); \\quad c(0) = c_0,", block: true)
]

#text("to emphasis this viewpoint, but this would be somewhat idiosyncratic.) One can solve this equation explicitly of course to get the solution")

#align(center)[#tao-fit-display[#mitex("u(t,x) = u_0(x-ct).")]]

#text("In particular, if we look at the solution just at time ")#mi("{t=1}")#text(" for simplicity, we have")

#align(center)[#tao-fit-display[#mitex("u(1,x) = u_0(x-c).")]]

#text("Now let us see how this solution ")#mi("{u(1,x)}")#text(" depends on the parameter ")#mi("{c}")#text(". One can ask whether this dependence is Lipschitz in ")#mi("{c}")#text(", in some function space ")#mi("{V}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u_0(\\cdot - c) - u_0(\\cdot - c^{\\prime}) \\right\\|_V \\leq A \\left|c-c^{\\prime}\\right|", block: true)]]

#text("for some finite ")#mi("{A}")#text(". But using the Newton approximation")

#align(center)[#tao-fit-display[#mitex("u_0(\\cdot - c) - u_0(\\cdot - c^{\\prime}) \\approx (c-c^{\\prime}) \\partial_x u_0(\\cdot - c)")]]

#text("we see that we should only expect such a bound when ")#mi("{\\partial_x u_0}")#text(" (and its translates) lie in ")#mi("{V}")#text(". Thus, we see a ")#emph[#text("loss of derivatives")]#text(" phenomenon with regard to Lipschitz well-posedness; if the initial data ")#mi("{u_0}")#text(" is in some regularity space, say ")#mi("{C^3}")#text(", then one only obtains Lipschitz dependence on ")#mi("{c}")#text(" in a lower regularity space such as ")#mi("{C^2}")#text(".")

#text("We have just seen that if all one knows about the initial data ")#mi("{u_0}")#text(" is that it is bounded in a function space ")#mi("{V}")#text(", then one usually cannot hope to make the dependence of ")#mi("{u}")#text(" on the velocity parameter ")#mi("{c}")#text(" Lipschitz continuous. Indeed, one cannot even make it continuous uniformly in ")#mi("{V}")#text(". Given two values of ")#mi("{c}")#text(" that are close together, e.g. ")#mi("{c = 0}")#text(" and ")#mi("{c=\\epsilon}")#text(", and a reasonable function space ")#mi("{V}")#text(" (e.g. a Sobolev space ")#mi("{H^k}")#text(", or a classical regularity space ")#mi("{C^k}")#text(") one can easily cook up a function ")#mi("{u_0}")#text(" that is bounded in ")#mi("{V}")#text(" but whose two solutions ")#mi("{u_0(\\cdot)}")#text(" and ")#mi("{u_0(\\cdot-\\epsilon)}")#text(" separate in the ")#mi("{V}")#text(" norm at time ")#mi("{1}")#text(", simply by choosing ")#mi("{u_0}")#text(" to be supported on an interval of width ")#mi("{\\epsilon}")#text(".")

#text("(Part of the problem here is that using a subtractive method ")#tao-math("{\\left\\|u-v\\right\\|_V}", block: false)#text(" to determine the distance between two solutions ")#mi("{u, v}")#text(" is not a physically natural operation when transport mechanisms are present that could cause the key features of ")#mi("{u, v}")#text(" (such as singularities) to be situated in slightly different locations. In such cases, the correct notion of distance may need to take transport into account, e.g. by using metrics of ")#link("http://en.wikipedia.org/wiki/Wasserstein_metric")[#text("Wasserstein")]#text(" type.)")

#text("On the other hand, one still has ")#emph[#text("non-uniform")]#text(" continuous dependence on the initial parameters: if ")#mi("{u_0}")#text(" lies in some reasonable function space ")#mi("{V}")#text(", then the map ")#mi("{c \\mapsto u_0(\\cdot-c)}")#text(" is continuous in the ")#mi("{V}")#text(" topology, even if it is not uniformly continuous with respect to ")#mi("{v_0}")#text(". (More succinctly: translation is a continuous but not uniformly continuous operation in most function spaces.) The reason for this is that we already have established this continuity in the case when ")#mi("{u_0}")#text(" is so smooth that an additional derivative of ")#mi("{u_0}")#text(" lies in ")#mi("{V}")#text("; and such smooth functions tend to be dense in the original space ")#mi("{V}")#text(", so the general case can then be established by a limiting argument, approximating a general function in ")#mi("{V}")#text(" by a smoother function. We then see that the non-uniformity ultimately comes from the fact that a given function in ")#mi("{V}")#text(" may be arbitrarily rough (or concentrated at an arbitrarily fine scale), and so the ability to approximate such a function by a smooth one can be arbitrarily poor.")

#text("In many quasilinear PDE, one often encounters qualitatively similar phenomena. Namely, one often has local well-posedness in sufficiently smooth function spaces ")#mi("{V}")#text(" (so that if the initial data lies in ")#mi("{V}")#text(", then for short times one has existence, uniqueness, and continuous dependence on the data in the ")#mi("{V}")#text(" topology), but Lipschitz or uniform continuity in the ")#mi("{V}")#text(" topology is usually false. However, if the data (and solution) is known to be in a high-regularity function space ")#mi("{V}")#text(", one can often recover Lipschitz or uniform continuity in a lower-regularity topology.")

#text("Because the continuous dependence on the data in quasilinear equations is necessarily non-uniform, the arguments needed to establish this dependence can be remarkably delicate. As with the simple example of the transport equation, the key is to approximate a rough solution by a smooth solution first, by smoothing out the data (this is the non-uniform step, as it depends on the physical scale (or wavelength) that the data features are located). But for quasilinear equations, keeping the rough and smooth solution together can require a little juggling of function space norms, in particular playing the low-frequency nature of the smooth solution against the high-frequency nature of the residual between the rough and smooth solutions.")

#text("Below the fold I will illustrate this phenomenon with one of the simplest quasilinear equations, namely the initial value problem for the ")#link("http://en.wikipedia.org/wiki/Burgers%27_equation")[#text("inviscid Burgers’ equation")]#text(" ")#metadata(none) <tao-123067cba2d3fb594e6f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_t u + u u_x = 0; \\quad u(0,x) = u_0(x)")]]

#text("which is a modification of the transport equation ")#link(<tao-6694ea8075001f6628da>)[#text("(3)")]#text(" in which the velocity ")#mi("{c}")#text(" is no longer a parameter, but now depends (and is, in this case, actually ")#emph[#text("equal")]#text(" to) the solution. To avoid technicalities we will work only with the classical function spaces ")#mi("{C^k}")#text(" of ")#mi("{k}")#text(" times continuously differentiable functions, though one can certainly work with other spaces (such as Sobolev spaces) by exploiting the ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Sobolev embedding theorem")]#text(". To avoid having to distinguish continuity from uniform continuity, we shall work in a compact domain by assuming periodicity in space, thus for instance restricting ")#mi("{x}")#text(" to the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(".")

#text("This discussion is inspired by ")#link("http://front.math.ucdavis.edu/math.AP/0411455")[#text("this survey article of Nikolay Tzvetkov")]#text(", which further explores the distinction between well-posedness and ill-posedness in both semilinear and quasilinear settings.")

#metadata(none) <tao-5a95f22dfbe777886474>

#heading(level: 1)[#strong[#text(" — 1. A priori estimates — ")]]

#text("To avoid technicalities let us make the ")#emph[#text("a priori")]#text(" assumption that all solutions of interest are smooth.")

#text("The Burgers equation is a pure transport equation: it moves the solution ")#mi("{u}")#text(" around, but does not increase or decrease its values. As a consequence we obtain an ")#emph[#text("a priori")]#text(" estimate for the ")#mi("{C^0}")#text(" norm:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{C^0} \\leq \\left\\|u(0)\\right\\|_{C^0}.", block: true)]]

#text("To deal with the ")#mi("{C^1}")#text(" norm, we perform the standard trick of ")#emph[#text("differentiating the equation")]#text(", obtaining")

#align(center)[#tao-fit-display[#mitex("\\partial_t u_x + u u_{xx} + u_x^2 = 0")]]

#text("which we rewrite as a forced transport equation")

#align(center)[#tao-fit-display[#mitex("(\\partial_t + u \\partial_x) u_x = - u_x^2.")]]

#text("Inspecting what this equation does at local maxima in space, one is led (formally, at least) to the differential inequality")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\left\\| u_x \\right\\|_{C^0} \\leq \\left\\|u_x\\right\\|_{C^0}^2", block: true)]]

#text("which leads to an ")#emph[#text("a priori")]#text(" estimate of the form ")#metadata(none) <tao-6222b7daea4bf2cbbe5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|u(t)\\right\\|_{C^1} \\leq C \\left\\|u(0)\\right\\|_{C^1}", block: true)]]

#text("for some absolute constant ")#mi("{C}")#text(", if ")#mi("{t}")#text(" is sufficiently small depending on ")#tao-math("{\\left\\|u(0)\\right\\|_{C^1}}", block: false)#text(". More generally, the same arguments give")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u(t)\\right\\|_{C^k} \\leq C_k \\left\\|u(0)\\right\\|_{C^k}", block: true)]]

#text("for ")#mi("{k=1,2,3,\\ldots}")#text(", where ")#mi("{C_k}")#text(" depends only on ")#mi("{k}")#text(", and ")#mi("{t}")#text(" is sufficiently small depending on ")#tao-math("{\\left\\|u(0)\\right\\|_{C^k}}", block: false)#text(". (Actually, if one works a little more carefully, one only needs ")#mi("{t}")#text(" sufficiently small depending on ")#tao-math("{\\left\\|u(0)\\right\\|_{C^1}}", block: false)#text(".)")

#text("The ")#emph[#text("a priori")]#text(" estimates are not quite enough by themselves to establish local existence of solutions in the indicated function spaces, but in practice, once one has ")#emph[#text("a priori")]#text(" estimates, one can usually work a little bit harder to then establish existence, for instance by using a compactness, viscosity, or penalty method. We will not discuss this topic here.")

#heading(level: 1)[#strong[#text(" — 2. Lipschitz continuity at low regularity — ")]]

#text("Now let us consider two solutions ")#mi("{u, v}")#text(" to Burgers’ equation from two different initial data, thus ")#metadata(none) <tao-bb82030dbc2bcaba32a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\partial_t u + u u_x = 0; \\quad u(0) = u_0")]]

#text("and ")#metadata(none) <tao-6ca202c88e549dff68c0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t v + v v_x = 0; \\quad v(0) = v_0.")]]

#text("We want to say that if ")#mi("{u_0}")#text(" and ")#mi("{v_0}")#text(" are close in some sense, then ")#mi("{u}")#text(" and ")#mi("{v}")#text(" will stay close at later times. For this, the standard trick is to look at the difference ")#mi("{w := v-u}")#text(" of the two solutions. Subtracting ")#link(<tao-bb82030dbc2bcaba32a9>)[#text("(6)")]#text(" from ")#link(<tao-6ca202c88e549dff68c0>)[#text("(7)")]#text(" we obtain the ")#emph[#text("difference")]#text(" equation for ")#mi("{w}")#text(": ")#metadata(none) <tao-6ecb803edcfd1f03f230>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\partial_t w + v w_x + w u_x = 0; \\quad w(0) = w_0 := v_0 - u_0.")]]

#text("We can view the evolution equation in ")#link(<tao-6ecb803edcfd1f03f230>)[#text("(8)")]#text(" as a forced transport equation:")

#align(center)[#tao-fit-display[#mitex("(\\partial_t + v \\partial_x) w = - w u_x.")]]

#text("This leads to a bound for how the ")#mi("{C^0}")#text(" norm of ")#mi("{w}")#text(" grows:")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\left\\|w\\right\\|_{C^0} \\leq \\left\\| w u_x \\right\\|_{C^0} \\leq \\left\\|w\\right\\|_{C^0} \\left\\|u\\right\\|_{C^1}.", block: true)]]

#text("Applying ")#link("http://en.wikipedia.org/wiki/Gronwall%27s_inequality")[#text("Gronwall’s inequality")]#text(", one obtains the ")#emph[#text("a priori")]#text(" inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|w(t)\\right\\|_{C^0} \\leq \\left\\|w_0\\right\\|_{C^0} \\exp( \\int_0^t \\left\\|u(s)\\right\\|_{C^1}\\ ds )", block: true)]]

#text("and hence by ")#link(<tao-6222b7daea4bf2cbbe5c>)[#text("(5)")]#text(" we have ")#metadata(none) <tao-c37bda557a9ccfd8ebf4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| u(t) - v(t) \\right\\|_{C^0} \\leq \\left\\|u_0 - v_0 \\right\\|_{C^0} \\exp( C \\left\\|u_0\\right\\|_{C^1} )", block: true)]]

#text("if ")#mi("{t}")#text(" is sufficiently small (depending on the ")#mi("{C^1}")#text(" norm of ")#mi("{u_0}")#text("). Thus we see that we have Lipschitz dependence in the ")#mi("{C^0}")#text(" topology… but only if at least one of the two solutions ")#mi("{u, v}")#text(" already had one higher derivative of regularity, so that it was in ")#mi("{C^1}")#text(" instead.")

#text("More generally, by using the trick of differentiating the equation, one can obtain an ")#emph[#text("a priori")]#text(" inequality of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) - v(t) \\right\\|_{C^k} \\leq \\left\\|u_0 - v_0 \\right\\|_{C^k} \\exp( C_k \\left\\|u_0\\right\\|_{C^{k+1}} )", block: true)]]

#text("for some ")#mi("{C_k}")#text(" depending only on ")#mi("{k}")#text(", for ")#mi("{t}")#text(" sufficiently small depending on ")#tao-math("{\\left\\|u_0\\right\\|_{C^{k+1}}}", block: false)#text(". Once again, to get Lipschitz continuity at some regularity ")#mi("{C^k}")#text(", one must first assume one higher degree ")#mi("{C^{k+1}}")#text(" of regularity on one of the solutions.")

#text("This loss of derivatives is unfortunate, but this is at least good enough to recover uniqueness: setting ")#mi("{u_0=v_0}")#text(" in, say, ")#link(<tao-c37bda557a9ccfd8ebf4>)[#text("(9)")]#text(" we obtain uniqueness of ")#mi("{C^1}")#text(" solutions (locally in time, at least), thanks to the trivial fact that two ")#mi("{C^1}")#text(" functions that agree in ")#mi("{C^0}")#text(" norm automatically agree in ")#mi("{C^1}")#text(" norm also. (One can then boost local uniqueness to global uniqueness by a continuity argument.)")

#heading(level: 1)[#strong[#text(" — 3. Non-uniform continuity at high regularity — ")]]

#text("Let ")#mi("{u^{(n)}_0}")#text(" be a sequence of ")#mi("{C^1}")#text(" data converging in the ")#mi("{C^1}")#text(" topology to a limit ")#mi("{u_0 \\in C^1}")#text(". As ")#mi("{u_0}")#text(" and ")#mi("{u^{(n)}_0}")#text(" are then uniformly bounded in ")#mi("{C^1}")#text(", existence theory then gives us ")#mi("{C^1}")#text(" solutions ")#mi("{u^{(n)}}")#text(", ")#mi("{u}")#text(" to the associated initial value problems ")#metadata(none) <tao-7cdc2a8784bd3d9de70c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\partial_t u + u u_x = 0; \\quad u(0) = u_0")]]

#text("and ")#metadata(none) <tao-b94a6d8ddcea7358e2b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\partial_t u^{(n)} + u^{(n)} u^{(n)}_x = 0; \\quad u^{(n)}(0) = u^{(n)}_0")]]

#text("for all ")#mi("{t}")#text(" in some uniform time interval ")#mi("{[0,T]}")#text(".")

#text("From ")#link(<tao-6222b7daea4bf2cbbe5c>)[#text("(5)")]#text(" we know that the ")#mi("{u^{(n)}}")#text(" and ")#mi("{u}")#text(" are uniformly bounded in ")#mi("{C^1}")#text(" norm (for ")#mi("{T}")#text(" small enough). From the Lipschitz continuity ")#link(<tao-c37bda557a9ccfd8ebf4>)[#text("(9)")]#text(" we know that ")#mi("{u^{(n)}}")#text(" converges to ")#mi("{u}")#text(" in ")#mi("{C^0}")#text(" norm. But does ")#mi("{u^{(n)}}")#text(" converge to ")#mi("{u}")#text(" in the ")#mi("{C^1}")#text(" norm?")

#text("The answer is yes, but the proof is remarkably delicate. A direct attempt to control the difference between ")#mi("{u^{(n)}}")#text(" and ")#mi("{u}")#text(" in ")#mi("{C^1}")#text(", following the lines of the previous argument, requires something to be bounded in ")#mi("{C^2}")#text(". But we only have ")#mi("{u^{(n)}}")#text(" and ")#mi("{u}")#text(" bounded in ")#mi("{C^1}")#text(".")

#text("However, note that in the arguments of the previous section, we don’t need ")#emph[#text("both")]#text(" solutions to be in ")#mi("{C^2}")#text("; it’s enough for just ")#emph[#text("one")]#text(" solution to be in ")#mi("{C^2}")#text(". Now, while neither ")#mi("{u^{(n)}}")#text(" nor ")#mi("{u}")#text(" are bounded in ")#mi("{C^2}")#text(" yet, what we can do is to introduce a ")#emph[#text("third")]#text(" solution ")#mi("{v}")#text(", which is ")#emph[#text("regularised")]#text(" to lie in ")#mi("{C^2}")#text(" and not just in ")#mi("{C^1}")#text(", while still being initially close to ")#mi("{u_0}")#text(" and hence to ")#mi("{u^{(n)}_0}")#text(" in ")#mi("{C^1}")#text(" norm. The hope is then to show that ")#mi("{u}")#text(" and ")#mi("{u^{(n)}}")#text(" are both close to ")#mi("{v}")#text(" in ")#mi("{C^1}")#text(", which by the triangle inequality will make ")#mi("{u}")#text(" and ")#mi("{u^{(n)}}")#text(" close to each other.")

#text("Unfortunately, in order to get the regularised solution ")#mi("{v}")#text(" close to ")#mi("{u_0}")#text(" initially, the ")#mi("{C^2}")#text(" norm of ")#mi("{v(0)}")#text(" (and hence of ")#mi("{v}")#text(") may have to be quite large. But we can compensate for this by making the ")#emph[#mi("{C^0}")]#text(" distance between ")#mi("{v(0)}")#text(" and ")#mi("{u_0}")#text(" quite small. The two effects turn out to basically cancel each other and allow one to proceed.")

#text("Let’s see how this is done. (The argument here originates from ")#link("http://www.ams.org/mathscinet-getitem?mr=385355")[#text("this paper of Bona and Smith")]#text(".) Consider a solution ")#mi("{v}")#text(" which is initially close to ")#mi("{u_0}")#text(" in ")#mi("{C^1}")#text(" norm (and ")#emph[#text("very")]#text(" close in ")#mi("{C^0}")#text(" norm), and also has finite (but potentially large) ")#mi("{C^2}")#text(" norm; we will quantify these statements more precisely later.")

#text("Once again, we set ")#mi("{w = v-u}")#text(" and ")#mi("{w_0 = v_0-u_0}")#text(", giving a difference equation which we now write as ")#metadata(none) <tao-28dfca8e47ff32141372>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\partial_t w + u w_x + w v_x = 0; \\quad w(0) = w_0")]]

#text("in order to take advantage of the higher regularity of ")#mi("{v}")#text(". For the ")#mi("{C^0}")#text(" norm, we have ")#metadata(none) <tao-762036e1ef0cea7232ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\|w(t)\\right\\|_{C^0} = O( \\left\\|w_0\\right\\|_{C^0} )", block: true)]]

#text("for ")#mi("{t}")#text(" sufficiently small, thanks ")#link(<tao-c37bda557a9ccfd8ebf4>)[#text("(9)")]#text(" and the uniform ")#mi("{C^1}")#text(" bounds. For the ")#mi("{C^1}")#text(" norm, we first differentiate ")#link(<tao-28dfca8e47ff32141372>)[#text("(12)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("(\\partial_t + u \\partial_x) w_x = - u_x w_x - w_x v_x - w v_{xx}")]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\left\\| w_x \\right\\|_{C^0} \\leq \\left\\| u_x w_x \\right\\|_{C^0} + \\left\\| w_x v_x\\right\\|_{C^0} + \\left\\| w v_{xx} \\right\\|_{C^0}.", block: true)]]

#text("The first two terms on the RHS are ")#tao-math("{O( \\left\\|w_x\\right\\|_{C^0} )}", block: false)#text(" thanks to the uniform ")#mi("{C^1}")#text(" bounds. The third term is ")#tao-math("{O( \\left\\|w_0\\right\\|_{C^0} \\left\\|v_0\\right\\|_{C^2} )}", block: false)#text(" by ")#link(<tao-762036e1ef0cea7232ac>)[#text("(13)")]#text(" and ")#emph[#text("a priori")]#text(" ")#mi("{C^2}")#text(" estimates (here we use the fact that the time of existence for ")#mi("{C^2}")#text(" bounds can be controlled by the ")#mi("{C^1}")#text(" norm). Using Gronwall’s inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| w_x(t) \\right\\|_{C^0} \\ll \\left\\|\\partial_x w_0\\right\\|_{C^0} + \\left\\|w_0\\right\\|_{C^0} \\left\\|v_0 \\right\\|_{C^2}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v(t)-u(t)\\right\\|_{C^1} \\ll \\left\\| v_0 - u_0 \\right\\|_{C^1} + \\left\\| v_0-u_0\\right\\|_{C^0} \\left\\| v_0 \\right\\|_{C^2}.", block: true)]]

#text("Similarly one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v(t)-u^{(n)}(t)\\right\\|_{C^1} \\ll \\left\\| v_0 - u^{(n)}_0 \\right\\|_{C^1} + \\left\\| v_0-u^{(n)}_0\\right\\|_{C^0} \\left\\| v_0 \\right\\|_{C^2},", block: true)]]

#text("and so by the triangle inequality we have ")#metadata(none) <tao-ad32c46b0443e6bf1020>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\|u^{(n)}(t)-u(t)\\right\\|_{C^1} \\ll \\left\\| v_0 - u_0 \\right\\|_{C^1} + \\left\\| v_0-u_0\\right\\|_{C^0} \\left\\| v_0 \\right\\|_{C^2}", block: true)]]

#text("for ")#mi("{n}")#text(" sufficiently large.")

#text("Note how the ")#mi("{C^2}")#text(" norm in the second term is balanced by the ")#mi("{C^0}")#text(" norm. We can exploit this balance as follows. Let ")#mi("{\\epsilon > 0}")#text(" be a small quantity, and let ")#mi("{v_0 := u_0 * P_\\epsilon}")#text(", where ")#mi("{P_\\epsilon = \\frac{1}{\\epsilon} P( \\frac{x}{\\epsilon})}")#text(" is a suitable approximation to the identity. A little bit of integration by parts using the ")#mi("{C^1}")#text(" bound on ")#mi("{u_0}")#text(" then gives the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0-u_0 \\right\\|_{C^0} \\ll \\epsilon", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0-u_0 \\right\\|_{C^1} \\ll 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0\\right\\|_{C^2} \\ll \\frac{1}{\\epsilon}.", block: true)]]

#text("This is not quite enough to get anything useful out of ")#link(<tao-ad32c46b0443e6bf1020>)[#text("(14)")]#text(". But to do better, we can use the fact that ")#mi("{\\partial_x u_0}")#text(", being uniformly continuous, has some ")#link("http://en.wikipedia.org/wiki/Modulus_of_continuity")[#text("modulus of continuity")]#text(", thus one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_x u_0(\\cdot+t) - \\partial_x u_0(\\cdot) \\right\\|_{C^0} = o(1)", block: true)]]

#text("as ")#mi("{t \\rightarrow 0}")#text(". Using this, one can soon get the improved estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0-u_0 \\right\\|_{C^0} = o(\\epsilon)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v_0-u_0 \\right\\|_{C^1} = o(1)", block: true)]]

#text("as ")#mi("{\\epsilon \\rightarrow 0}")#text(". Applying ")#link(<tao-ad32c46b0443e6bf1020>)[#text("(14)")]#text(", we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u^{(n)}(t)-u(t)\\right\\|_{C^1} \\ll o(1)", block: true)]]

#text("for ")#mi("{n}")#text(" sufficiently large, and the continuity claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("Dear Prof. Tao,")

#text("If ")#mi("u: \\mathbb{R} \\rightarrow V")#text(" and V is a finite dimensional vector space, how do we define the derivative of u with respect to t?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("Derivatives of vector-valued functions can be defined in the same way as that of scalar-valued functions, e.g. as limits of Newton quotients ")#mi("(u(t+dt)-u(t))/dt")#text(". One can also take the derivative of each component.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43702")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("but in that case do not we need at least a norm? is it a vector space or a norm space?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43703")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("You can put a norm on any finite dimensional space by choosing a basis and taking the Euclidean norm w.r.t. that basis. So defined norm will be equivalent to any other norm.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43697")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("Dear Prof. Tao,")

#text("It often happens when one deals with, say, quasilinear wave equations, that we have equivalence between the energy norm given by the principal symbol of the linearized operator at a certain background field and the one given at the zero section, usually the Minkowski metric. When this happens, one can employ, for instance, a commutator trick and recover the loss of derivatives for higher energy estimates. Do the same ideas apply in the examples you’ve discussed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("One can certainly use commutator estimates to perform the a priori estimates, and obtain higher derivative control on individual solutions with no loss of regularity. Combining this with a penalisation, regularisation, or viscosity method, this is usually enough to get existence and uniqueness. However, when the time comes to do the continuous dependence on the data, which requires one to study differences of solutions rather than solutions themselves, then commutator estimates are not sufficient by themselves to recover all the derivatives needed to close the argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43698")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("Dear Prof. Tao,")

#text("Thanks for the so nice post!")

#text("I didn’t quite understand the estimate immediately above (5), is it because ")#mi("\\partial_x u_x=0")#text(" at the maxima? I am also a little worry about exchange the operations ")#mi("\\partial_t")#text(" and ")#mi("||\\cdot||")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43701")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2010")])]

#text("Yes, this is correct. To rigorously justify the derivative of the supremum norm, it is best to work from first principles (i.e. using Newton quotients). (It is also convenient to interpret the derivative in the sense of forward difference quotients only.) Alternatively one can use a comparison or barrier method, solving the associated ODE and using that ODE solution (possibly adding an epsilon drift to gain a bit of room, cf. the standard proof of the maximum principle) as a barrier for the sup norm of the PDE solution via a continuity argument.")

#text("Alternatively, as one is dealing here with forced transport equations, one can also use the more elementary method of characteristics (or equivalently, change to Lagrangian coordinates) to achieve the same result.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43758")[#strong[#text("2010 Feb notes « 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2010")]

#text("[…] 2, 2010 作者为 曾经话说要如何 7. loss of one order regularity, see Tao’s for space , and my trial for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43768")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2010")])]

#text("Terry, in the third to last equation, to get the C^2 norm of v_0 to be o(epsilon), don’t you need that P is a symmetric mollifier? Maybe it is easier to just leave it in O(epsilon) since it looks like it is enough to close anyway.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43769")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2010")])]

#text("Ack. I meant 1/epsilon in both cases above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43770")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2010")])]

#text("Fair enough; I’ve removed the estimate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bk")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43921")[#strong[#text("bk")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("Dear Terry,")#linebreak()#text(" I have a silly confusion.")#linebreak()#text(" Isn’t there a gap between the estimate (14) and the two above it?")#linebreak()#text(" Seemingly it is not necessarily true that ")#tao-math("\\left|\\left|u_0-u_0^n\\right|\\right|_{C^0}= o(\\epsilon)", block: false)#text(". Right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bk")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-43922")[#strong[#text("bk")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("Instead of saying a gap there, maybe I should say ‘a gap in the reasoning below (14)’ by which I mean when you need ")#mi("o(\\epsilon)")#text(" estimate in (14), actually you need it for both of the formula above(14). Am I right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-463695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2015")])]

#text("I only know some undergraduate level PDE and the theory about weak solutions. My question might be stupid.")

#text("I’ve seen in literatures (including your textbook in PDE) again and again the term “priori estimate”. Would you explain what it really means (the explanation in Wikipedia is rather unsatisfying)? What would be counted as a “non” priori estimate? How is a priori estimate usually used?")

#emph[#text("The a priori estimates are not quite enough by themselves to establish local existence of solutions in the indicated function spaces, but in practice, once one has a priori estimates, one can usually work a little bit harder to then establish existence…")]

#text("Why an estimate can be used to establish existence of solutions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-463738")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")])]

#text("An ")#emph[#text("a priori")]#text(" estimate is an estimate that applies to all solutions to a given PDE (with given initial conditions, and with some minimal level of regularity on the solution). In particular, one does not need to establish existence or uniqueness of the solution to obtain the estimate (although the ")#emph[#text("a priori")]#text(" estimate is vacuous in content if solutions don’t actually exist). This can be compared with ")#emph[#text("a posteriori")]#text(" estimates that apply to solutions that are constructed by a particular method (e.g. fixed point iteration) and rely on the actual construction of the solution.")

#text("Possession of an ")#emph[#text("a priori")]#text(" estimate does not immediately guarantee existence of solutions, however one can often use or modify such estimates to construct solutions. For instance, one could use some compactness method to first generate a weak solution, and apply the ")#emph[#text("a priori")]#text(" estimate to the weak solution to upgrade it to a strong solution (but one has to be careful here to ensure that the arguments used to establish the a priori bound can rigorously be applied to weak solutions). Alternatively, one could construct some sequence of approximate solutions (e.g. by an iteration scheme, a discretisation scheme, or adding a viscosity or other penalty term to the equation to make it easier to establish existence of solutions), and extend the ")#emph[#text("a priori")]#text(" bound to the approximating solutions, and then extract a limit (for instance, one can sometimes modify the proof of an ")#emph[#text("a priori")]#text(" bound to also establish some convergence properties of a given sequence of approximating solutions, particularly if this sequence was constructed by an iteration scheme).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-463744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")])]

#text("Is it possible to use the idea of small perturbation of the PDE for the NS PDE by using a relativistic version of it (so that the velocities can’t exceed the speed of light c – so it seems easier to prove the existence of regular and bounded relativistic solutions) and then letting ")#mi("c \\to \\infty")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-463745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2015")])]

#text("One can certainly create approximate solutions by this method (or by a number of other methods, e.g. introducing hyperdissipation). However, the challenge is to obtain ")#emph[#text("a priori")]#text(" estimates for these solutions that are uniform in the parameter c, otherwise one gets no control on what happens in the limit ")#mi("c \\to \\infty")#text(", and this is basically at least as hard as the problem of getting ")#emph[#text("a priori")]#text(" estimates for the Navier-Stokes equation itself, for which we have the supercriticality problem. See also my comments on Strategy 3.1 in ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Local well-posedness for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/#comment-505787")[#strong[#text("254A, Notes 3: Local well-posedness for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("[…] is not expected to be uniformly continuous on this ball, let alone Lipschitz continuous. See this previous blog post for some more […]")
]
