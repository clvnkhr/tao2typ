// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/12/29/jean-bourgain/
// Converted to Typst by tao2typ: "2026-10-14T15:20:13.866466+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Jean Bourgain", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Jean Bourgain")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 December 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")[#text("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have just learned that ")#link("https://en.wikipedia.org/wiki/Jean_Bourgain")[#text("Jean Bourgain")]#text(" ")#link("https://fr.metrotime.be/2018/12/29/news/deces-du-mathematicien-jean-bourgain/")[#text("passed away last week")]#text(" in Belgium, aged 64, after a prolonged battle with cancer. He and Eli Stein were the two mathematicians who most influenced my early career; it is something of a shock to find out that they are now both gone, having died within a few days of each other.")

#text("Like Eli, Jean remained highly active mathematically, even after his cancer diagnosis. Here is a video profile of him by National Geographic, on the occasion of his 2017 Breakthrough Prize in Mathematics, doing a surprisingly good job of describing in lay terms the sort of mathematical work he did:")

#text("When I was a graduate student in Princeton, Tom Wolff came and gave a course on recent progress on the restriction and Kakeya conjectures, starting from the breakthrough work of Jean Bourgain in a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1097257")[#text("now famous 1991 paper in Geom. Func. Anal.")]#text(". I struggled with that paper for many months; it was by far the most difficult paper I had to read as a graduate student, as Jean would focus on the most essential components of an argument, treating more secondary details (such as rigorously formalising the uncertainty principle) in very brief sentences. This image of my own annotated photocopy of this article may help convey some of the frustration I had when first going through it:")

#image("../assets/7c4b03fdcbc2d8124125e6fdf5ec598ef8b15f04eedcf96c88b26532150a53e8-b594503ba9518ea1599449238f0b9a966aa0646200f9cd3cd7292f98f66b82b5.jpg", width: 90%)

#text("Eventually, though, and with the help of Eli Stein and Tom Wolff, I managed to decode the steps which had mystified me – and my impression of the paper reversed completely. I began to realise that Jean had a certain collection of tools, heuristics, and principles that he regarded as “basic”, such as dyadic decomposition and the uncertainty principle, and by working “modulo” these tools (that is, by regarding any step consisting solely of application of these tools as trivial), one could proceed much more rapidly and efficiently. By reading through Jean’s papers, I was able to add these tools to my own “basic” toolkit, which then became a fundamental starting point for much of my own research. Indeed, a large fraction of my early work could be summarised as “take one of Jean’s papers, understand the techniques used there, and try to improve upon the final results a bit”. In time, I started looking forward to reading the latest paper of Jean. I remember being particularly impressed by his ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1626257")[#text("1999 JAMS paper on global solutions of the energy-critical nonlinear Schrodinger equation for spherically symmetric data.")]#text(" It’s hard to describe (especially in lay terms) the experience of reading through (and finally absorbing) the sections of this paper one by one; the best analogy I can come up with would be watching an expert video game player nimbly navigate his or her way through increasingly difficult levels of some video game, with the end of each level (or section) culminating in a fight with a huge “boss” that was eventually dispatched using an array of special weapons that the player happened to have at hand. (I would eventually end up spending two years with four other coauthors trying to remove that spherical symmetry assumption; ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2415387")[#text("we did finally succeed")]#text(", but it was and still is one of the most difficult projects I have been involved in.)")

#text("While I was a graduate student at Princeton, Jean worked at the Institute for Advanced Study which was just a mile away. But I never actually had the courage to set up an appointment with him (which, back then, would be more likely done in person or by phone rather than by email). I remember once actually walking to the Institute and standing outside his office door, wondering if I dared knock on it to introduce myself. (In the end I lost my nerve and walked back to the University.)")

#text("I think eventually Tom Wolff introduced the two of us to each other during one of Jean’s visits to Tom at Caltech (though I had previously seen Jean give a number of lectures at various places). I had heard that in his younger years Jean had quite the competitive streak; however, when I met him, he was extremely generous with his ideas, and he had a way of condensing even the most difficult arguments to a few extremely information-dense sentences that captured the essence of the matter, which I invariably found to be particularly insightful (once I had finally managed to understand it). He still retained a certain amount of cocky self-confidence though. I remember posing to him (some time in early 2002, I think) a problem Tom Wolff had once shared with me about trying to prove what is now known as a sum-product estimate for subsets of a finite field of prime order, and telling him that Nets Katz and I would be able to use this estimate for several applications to Kakeya-type problems. His initial reaction was to say that this estimate should easily follow from a Fourier analytic method, and promised me a proof the following morning. The next day he came up to me and admitted that the problem was more interesting than he had initially expected, and that he would continue to think about it. That was all I heard from him for several months; but one day I received a two-page fax from Jean with a beautiful hand-written proof of the sum-product estimate, which eventually became ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2053599")[#text("our joint paper")]#text(" with Nets on the subject (and the only paper I ended up writing with Jean). Sadly, the actual fax itself has been lost despite several attempts from various parties to retrieve a copy, but a LaTeX version of the fax, typed up by Jean’s tireless assistant Elly Gustafsson, can be seen ")#link("https://terrytao.wordpress.com/wp-content/uploads/2018/12/JeanFaxTao.pdf")[#text("here")]#text(".")

#text("About three years ago, Jean was diagnosed with cancer and began a fairly aggressive treatment. Nevertheless he remained extraordinarily productive mathematically, authoring over thirty papers in the last three years, including such breakthrough results as his ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3548534")[#text("solution of the Vinogradov conjecture with Guth and Demeter")]#text(", or his short ")#link("https://arxiv.org/abs/1609.05744")[#text("note on the Schrodinger maximal function")]#text(" and ")#link("https://arxiv.org/abs/1708.04639")[#text("his paper with Mirek, Stein, and Wróbel")]#text(" on dimension-free estimates for the Hardy-Littlewood maximal function, both of which made progress on problems that had been stuck for over a decade. In May of 2016 I helped organise, and then attended, a ")#link("https://www.math.ias.edu/bourgain16")[#text("conference at the IAS celebrating Jean’s work and impact")]#text("; by then Jean was not able to easily travel to attend, but he gave a superb special lecture, not announced on the original schedule, via videoconference that was certainly one of the highlights of the meeting. (UPDATE: a video of his talk is ")#link("https://www.youtube.com/watch?v=lKzGb70yx80")[#text("available here")]#text(". Thanks to Brad Rodgers for the link.)")

#text("I last met Jean in person in November of 2016, at the award ceremony for his Breakthrough Prize, though we had some email and phone conversations after that date. Here he is with me and Richard Taylor at that event (demonstrating, among other things, that he wears a tuxedo much better than I do):")

#image("../assets/ef152ce1675e13b4182cba0ad9b6e2b5096505358b15749f8a5aac10a89d9fb8-e03eadfc3ab7f1ec59d8a35c1432a0fc6ed03ae711f2b956fb5249af9b25571b.jpg", width: 90%)

#text("Jean was a truly remarkable person and mathematician. Certainly the world of analysis is poorer with his passing.")

#text("[UPDATE, Dec 31: Here is the initial ")#link("https://www.ias.edu/news/2018/bourgain-obituary-notice")[#text("IAS obituary notice for Jean")]#text(".]")

#text("[UPDATE, Jan 3: See also ")#link("https://mathoverflow.net/questions/319893/jean-bourgains-relatively-lesser-known-significant-contributions")[#text("this MathOverflow question “Jean Bourgain’s Relatively Lesser Known Significant Contributions”")]#text(".]")

#heading(level: 1)[#text("Comments (51)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc5ff249339fccfe6a90f64282930eaaca7b0eb8cbc82bfabf936691c9971742-2b8cbb7eee158dba51104b1ff1b1554848139c9441ee4917aca9c1099b31a961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean Bourgain – Hacker News Robot")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509790")[#strong[#text("Jean Bourgain – Hacker News Robot")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")[#text("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")]#text(" […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f49a4f9b349155f1736089e87bad6f33bad57343a4c4a24c8f819afbee89eb6c-6f3cef861023bdda10fd10b24b8761e9209267a8c0776e670ac77571f5890a30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rahul kumar")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510376")[#strong[#text("rahul kumar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("i have a lot to talk with you, i’m a computer science engineer final year and i wanted to study b.sc or m.sc maths because i make formulas but i’m not eligible to write exams , and the salary of a mathematician is very low compared to that of IT sector , but i’m a self taught mathematician, i’ ve been teaching myself maths since i was in 7th class , now i’m 20 years and lost in life but no matter what , maths is something that i couldn’t bring myself to quit and i’m an indian and not ramanujan but ramanujan’s formulas are my inspiration")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f35a2c2e04b812c27d901e9773072d861a2f880bdca36c84cccda50d87f558e-61bfb6dcf8dce9387d2ac9a844e7f71ad10265b48583e11a70216cfae158cedd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek Sharma")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-511105")[#strong[#text("Vivek Sharma")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2019")])]

#text("If you are serious, contact me @VivekNSharma87 on twitter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da342d8dd6da91065c00dbd159d5444180b51017206b6c4c357c3bfd41926bb1-0ae8d57c1afed2c7e31070be76ea01bbfd7875fe85ef2eaff5934f6199d07cbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-520176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Come on! This is an obituary, not the platform to ask for advice unrelated to Jean Bourgain or his work! At least, read the damn title of the post and understand that it’s about someone’s demise before writing about how you are lost in life.")

#text("Oh, and since I am being rude, I will take this opportunity to be ruder:")#linebreak()#text(" Mathematics is hard. One cannot usually learn mathematics in isolation these days without reading textbooks and having access to some teachers. And even if you end up getting a PhD, there is a scramble for Post Doctoral fellowships. Guess what? Only the best get the tenure track positions and some of it also involves positions opening up at the right time at the right place. Now, after all these things, if you have managed to get a position, you are 35 years old and have had no stable relationships because you never stopped moving from one university to another for positions! (This is a generalisation but I does hold a grain of truth in it)")

#text("Lastly, go to University and learn mathematics with some professors. They will guide you and help you get a problem you can actually work on. Maybe, with some guidance and formal training you might actually be good. However, using Dr. Bourgain’s obituary for this is in poor taste.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c22bbed9734dd42b325bed410c80e6cffc211b95426cdf6c77929b4ffa9a892f-f8ec1cbe2cdd653cb56b5ba31231f99d4ac18fc9f966613bda1eda2eff92aa8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509792")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("Very sad news.")

#text("Terry’s stories and analogies ring so true for my experiences with Bourgain’s papers! (His working ‘modulo tools’; printing papers of his and littering them with handwritten “????”‘s; the boss fight / speedrun analogy; the unique typesetting arising from passing his handwriting through Elly Gustafsson’s LaTeXing…)")

#text("I spent close to 5 years understanding one 6-page paper of his (“On the distribution of the Fourier spectrum of Boolean functions”), and also close to 10 years understanding a 10-page paper of his (the k-SAT sharp threshold ‘appendix’). If anyone’s up for a challenge, I’m pretty sure no one on earth fully understands the second half of his paper “Influences of variables and threshold intervals under group symmetries” with Kalai (including Gil :)")

#text("One anecdote I always tell comes from when I was a postdoc at IAS for a year. I spent about 6 months working on a new conjecture in Fourier analysis of Boolean functions, something Jean was a great expert on. I was far too nervous to ask him about the problem, but Avi Wigderson eventually persuaded me to make an appointment with him. With trepidation, I knocked and entered his office, then launched into an explanation of the open problem at the board. When I finished, Jean paused, and said… “Interesting. … … Seems hard.” Happiest day of my mathematical life — Jean Bourgain thought my problem was neither boring nor trivial! I should add that he was very friendly throughout the subsequent meeting.")

#text("This mathoverflow page also has some funny comments about reading Bourgain’s papers:")#linebreak()#text(" ")#link("https://mathoverflow.net/questions/121751/inequality-on-trigonometric-polynomials")[#text("https://mathoverflow.net/questions/121751/inequality-on-trigonometric-polynomials")]#linebreak()#text(" I like Fedja’s remark, after explaining how to fill in details for a very tricky step: “Of course, to Jean such things are as obvious as 2×2+1=5 (he writes 10 instead of 5 just out of the traditional analyst’s habit to have a 100% security margin in the constants).”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Roger Heath-Brown also had a similar comment in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1253227")[#text("this MathSciNet review")]#text(" of one of Jean’s papers:")

#emph[#text("The reviewer found the paper rather hard to read, and indeed had to seek assistance at one point. Readers are advised not to take some of the assertions made in the course of the proofs too literally, and, in particular, to abandon any preconceived notion as to the meaning of the symbol “")#mi("\\sim")#text("“.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510111")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")])]

#text("It is always sad and a loss to the community for the great mathematicians to pass. But I can’t help indulging in a little Yorkshire oneupmanship at this time, if you’ll forgive me, to lighten the mood…")

#text(">I spent close to 5 years understanding one 6-page paper of his")

#text("That’s nothing! In my field, people have spent several *decades* trying to implement the ideas in a 5-page letter of Grothendieck from 1975: ")#link("https://webusers.imj-prg.fr/~leila.schneps/grothendieckcircle/Letters/breen1.html")[#text("https://webusers.imj-prg.fr/~leila.schneps/grothendieckcircle/Letters/breen1.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")])]

#text("Grothendieck (like Ramanujan) was not an “ordinary genius”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509795")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2018")])]

#text("A sincere homage. In the same spirit: I think the issue with some of Jean’s papers is precisely that, while giving full details on some secondary matters, he elided over some essential steps that were standard *to him*. I learned quickly to always read his papers with a friend – it’s much easier than doing it solo.")

#text("He was always kind to me, and I regret that I never got the opportunity to collaborate with him. (I often wondered how one should go about it…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a82b5be7ea69fd9025cd4c5aa74fda42da270d26ac100050a228a1aa8cf9f6c-d2678ac9c628d4c56ba43dc015dd6af5da18a92eccc3f6bd321ad7e8e3465d9a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francesco Vaccarino")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509796")[#strong[#text("Francesco Vaccarino")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Your post is very touching, thanks for sharing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509797")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Dear Terry,")

#text("Have you ever considered writing a blog post on “Bourgain’s toolbox” summarizing the kinds of techniques used continually (without explanation) in his papers? I think such an outline would be a great help, especially for people more distant from the field, who would not normally find themselves grappling directly with one of his papers, but would benefit nonetheless from knowing the kinds of tools that came second-nature to him. And a case study of one of his papers would probably help many an analysis student struggling to become familiar with the area as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509800")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#link("https://en.wikiquote.org/wiki/Euclid")[#text("Euclid famously said")]#text(" (to Ptomely I) that there is no royal road to geometry. I feel the same is true for all other fields of mathematics, including analysis; trying to memorise a list of tricks without the context of actually applying them to a problem would be akin to trying to learn martial arts solely from watching martial arts films, without actually doing physical training. I myself have encouraged my own graduate students to fight their way through at least one paper of Bourgain (assuming of course that there is a relevant paper of Jean’s in their field of research, which is quite often the case in my experience); I’m not sure that one can get anything approaching the value of that exercise from more passive modes of learning.")

#text("That said, I did ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("write a blog post")]#text(" dedicated to one of Bourgain’s basic tools mentioned above, namely the uncertainty principle. And in ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("the post on my recent paper with Brad Rodgers")]#text(", I discuss another handy trick of Bourgain’s in which one uses the pigeonhole principle to locate a good scale at which boundary effects are negligible. I also collected some analysis problem solving strategies (aimed at the early graduate level, rather than at the Bourgain level) in ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("this post")]#text(". Finally, my blog has a category for ")#link("https://terrytao.wordpress.com/category/expository/tricks/")[#text("posts on tricks")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509801")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("I do think Rex’s request is reasonable (though some background would have to be assumed on the part of the audience). As for context, of course it would be a collection of techniques with examples, mostly from Jean’s papers. It would probably be best for such a hypothetical monograph to be collective, though – I can’t think of anyone who might not run out of steam, and, as I said, it’s much easier to read such papers with a friend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("It seems that a comprehensive list of tricks (e.g. the “tensor power trick”) and general ideas on how to approach (or “how to solve it”) new problems (e.g. “epsilon of room”) should also appear in a comprehensive Wikipedia article.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Tim Gowers’ ")#link("http://www.tricki.org/")[#text("tricki")]#text(" was an attempt at doing more or less exactly this. It turned out to be somewhat less successful than hoped, though; I think the main bottleneck is our current lack of proper semantic search technology. (Indeed, the best semantic search devices in mathematics are still the brains of a mathematician and the colleagues that he or she talks to, although sometimes with a PolyMath type project one can at least crowdsource some of this search.)")

#text("As for the tricks of Jean in particular, there is certainly scholarly and historical value in an annotated version of his collected works, although this would be a massive enterprise (particularly in Jean’s case, as he had over 500 publications), and would likely sit on a shelf gathering dust for most potential owners of these works. A monograph focusing in particular on Jean’s “bag of tricks” would still be a substantial amount of work to get done properly, and might perhaps be slightly more widely read, but I think its very existence would propagate at least two incorrect implicit assumptions: firstly, that Bourgain’s original papers are just too scary to be worth even trying to read directly; and secondly, the fact that a trick originated from Jean Bourgain (as opposed to any other mathematician) is more important than the mathematical content of the trick itself.")

#text("I think that ultimately the best way to acquire these tools is to constantly be exposed to interesting new mathematics, whether it is through reading a challenging paper from an expert, or listening to a talk on a topic outside your own specialty, or by working (particularly with collaborators) on a problem outside of your own comfort zone. Bourgain is not the only author whose writings happen to be particularly worth investing the effort to properly read; I for instance found reading Szemeredi’s work or Perelman’s work to be a broadly similar experience, and I am sure that there are several other mathematicians with this property also.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Maybe a stupid idea: assuming that everyone who reads a paper (especially those important ones in a certain field) would have an annotated version of the work, either “mentally” or “physically”, is possible in the future to have an “annotated” version of arXiv/MathSciNet which accumulates readers’ (useful) annotation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509912")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("This idea has been discussed in the past, but experience with other internet forums that allow unrestricted comments shows that there are numerous potential downsides (spam, brigading, flame wars, slander, off-topic or otherwise non-constructive comments, etc.) to opening up such an annotation system, particularly if it is attached to any “official” site such as MathSciNet or the arXiv; in particular a large amount of expert human moderation resources would probably be needed, which these institutions do not really have available.")

#text("On the other hand, less formal platforms might work. I’ve run ")#link("https://terrytao.wordpress.com/?s=reading+seminar")[#text("a few reading seminars")]#text(" on this blog for instance. Even if the blog platform isn’t quite a perfect fit for a crowdsourced annotation project, it seems to be “")#link("https://en.wikipedia.org/wiki/Principle_of_good_enough")[#text("good enough")]#text("“; a fancier dedicated platform might in principle be superior, but if it is even slightly more difficult to use than a blog (e.g., if one has to download and install specialised software, or one has to register an account) it might end up with far fewer participants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#link("https://mathoverflow.net/a/101871")[#text("https://mathoverflow.net/a/101871")]

#emph[#text("Incidentally, I found the reading of Jean’s papers as a graduate student to be simultaneously extremely frustrating and extremely rewarding. Decoding an offhand remark or a mysterious step in his paper was often as instructive (and as time-consuming) as reading several pages of arguments by some other authors. (But his papers do become much easier to read once one has internalised enough of his “box of tools”…)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510052")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text(">A monograph focusing in particular on Jean’s “bag of tricks” would still >be a substantial amount of work to get done properly, and might perhaps >be slightly more widely read, but I think its very existence would >propagate at least two incorrect implicit assumptions: firstly, that >Bourgain’s original papers are just too scary to be worth even trying to >read directly; and secondly, the fact that a trick originated from Jean >Bourgain (as opposed to any other mathematician) is more important >than the mathematical content of the trick itself.")

#text("Anything worthwhile takes work – and, again, we would be talking about a (massively?) collective effort. I do think the two misgivings you express help us narrow down things a little. I think that in many cases what is needed is some sort of informal guidance or notes to the original paper, rather than an expository paper effectively replacing a series of papers (though expository papers also have their place). As I implied, reading the original papers with a friend is much easier than and at least as rewarding as doing it alone – and not everybody has the privilege of having a friend who is also interested.")

#text("As for the fact that techniques do not derive their worth from originating with Bourgain – sure, and, for that matter, I imagine that almost all of the techniques he considered standard originated elsewhere. It would be understood that focusing on Bourgain’s toolkit would be in part a matter of practicality (to help people reading his papers) and in part a literary conceit of sorts.")

#text("Whether matters develop solely online or not, I am ready to venture that the result would be a posthumous Festschrift (of sorts) that would be far more valuable than most other Festschrifts. Of course, we could not avoid the implication that")

#text("a) Jean’s papers are not particularly well-written,")#linebreak()#text(" b) he could have made them very readable (far more than much other work in the same league) with a little effort,")

#text("but that is now not just common knowledge but mutual knowledge, so there is no harm in it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510092")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text("I think there are two distinct possible projects being discussed here: (1) a project to annotate some key papers of Bourgain in order to assist people interested in reading these papers, and (2) a collection of “Bourgain tricks” intended for people who would are not intending to read any papers of Jean’s.")

#text("Regarding (1), it occurs to me that there actually is an ongoing online effort to discuss unclear steps in key papers of many leading mathematicians including Jean: it has been happening organically over at MathOverflow. For instance, just by searching for “Bourgain” on that site and inspecting the various results, ")#link("https://mathoverflow.net/questions/140095/inequalities-in-paper-by-jean-bourgain")[#text("I")]#text(" ")#link("https://mathoverflow.net/questions/101859/a-fourier-analytic-inequality-used-by-jean-bourgain")[#text("found")]#text(" ")#link("https://mathoverflow.net/questions/229658/decoupling-in-mixed-norm-spaces")[#text("a")]#text(" ")#link("https://mathoverflow.net/questions/229658/decoupling-in-mixed-norm-spaces")[#text("half")]#text(" ")#link("https://mathoverflow.net/questions/232638/the-fourier-transform-of-a-function-supported-on-b-1-is-essentially-constant-o")[#text("dozen")]#text(" ")#link("https://mathoverflow.net/questions/121751/inequality-on-trigonometric-polynomials")[#text("posts")]#text(" ")#link("https://mathoverflow.net/questions/248450/weyl-type-lemma")[#text("that")]#text(" were each devoted to explaining one such step in a Bourgain paper. Basically, MathOverflow is serving as a collective version of the “friend to read papers with” that you were referring to. It seems that the most efficient way to achieve (1) is to build upon this existing effort. For instance one could imagine some web site where one enters in a given paper (either by name, or by arXiv number, or MR number, or DOI, etc.) and the web site then conducts a search of various sites to find all MathOverflow posts, blog posts, other preprints or articles that cite or mention that article. (There are already some web sites that try to do something like this, but not targeted towards mathematics, and not focusing particularly on Q&A sites like MathOverflow.) This sort of “discussion portal” for papers would, in the long run, scale much better than trying to manually annotate each key paper of each key mathematician separately.")

#text("Regarding (2): as I said before, it is an order of magnitude more difficult to internalise a mathematical trick if one does not have an immediate need for doing so (e.g., to understand a key step in a paper one is reading). Consider for instance the passage in Jean’s paper in my post that I was struggling with as a graduate student. Here, Jean is using the uncertainty principle to be able to essentially treat a certain frequency-localised function as being morally constant on that scale. It was only through my efforts to understand this and other similar steps in Jean’s work that I was able to get to the point where I could use the uncertainty principle myself as freely as Jean was doing there. Many years later, I did pour quite a bit of effort into ")#link("https://terrytao.wordpress.com/2010/06/25/the-uncertainty-principle/")[#text("writing a blog post to to try to describe how to use this principle")]#text(", with plenty of examples provided. However, while I am still glad that I wrote the article, I think it was less successful than I had hoped. Unless someone is already at the point where they need to understand the uncertainty principle for an immediate application – such as deciphering a line in one of Jean’s articles – they are unlikely to invest the time needed to deeply read this sort of article. (Perhaps that post might be more slightly widely read if I rebranded it as “this ")#link("https://en.wikipedia.org/wiki/One_weird_trick_advertisements")[#text("one weird trick")]#text(" of Bourgain”, but even so, I wonder how many of the readers here who profess to want to understand his toolbox will actually go ahead and carefully go through that post to actually acquire one of his tools.) It is true that if such an article was available to me at the time that I was first going through Jean’s paper, I would perhaps have had an easier time of achieving the immediate goal of understanding that one step that paper; but I am not sure that it would have necessarily been the better way of achieving the longer term goal of acquiring and truly internalising the use of tools such as the uncertainty principle (or of the other longer term goal of becoming more effective at reading difficult papers).")

#text("Of course, this doesn’t mean that one ought to struggle unassisted through a challenging key paper in one’s field. In addition to consulting colleagues and resources such as MathOverflow, I have also often found it useful to concurrently look at followup (or precursor) work, either by the same author or by other authors, as they may provide a slightly different angle (or more detail) on a key step that can break one’s mental impasse at that point. Lecture notes (particularly those with plenty of exercises) tend to be particularly valuable in this regard. For instance, many of the steps in the paper of Jean I mentioned in my post ended up being turned into exercises in ")#link("http://front.math.ucdavis.edu/math.CA/0311181")[#text("my lecture notes on restriction theorems")]#text("; as just one example, the annotation at the bottom of the image where I realised that Jean was using an equivalence between restriction theory on the sphere and restriction theory on the annulus became Problem 2.2 in those notes. I have found that getting graduate students to go through such lecture notes and doing the exercises is more effective than either letting them go through the original papers with minimal assistance, or by providing them with general descriptions of the techniques used such as in my uncertainty principle post. The key difference seems to be that by having concrete exercises to solve, there is enough of a motivation and focus to actually absorb the tricks that are being used at that point. Currently, I am writing lecture notes for various topics in fluid equations (such as the work of Onsager’s conjecture), and I have also been trying to convert any particularly neat tricks that I encountered while researching these notes into suitable exercises for the course.")

#text("By the way, I disagree with you that Jean’s papers were not well written; his later papers in particular did make increasingly strenuous efforts to become more accessible (for instance, his ")#link("https://arxiv.org/abs/1403.5335")[#text("2014 breakthrough with Demeter on decoupling theorems")]#text(" even comes with ")#link("https://arxiv.org/abs/1604.06032")[#text("a detailed study guide")]#text(", which my own graduate students have found to be useful). And once one internalises his toolbox, they are actually quite a pleasure to read, being incredibly efficient in reaching their desired objectives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510057")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text("I think the naive interpretation of Euclid’s remark is a bit misleading. There may not be a royal road, but there certainly are paved roads (this blog), dirt roads (Bourgain’s papers), and no roads at all (research). I’m guessing people who build dirt roads usually do so because it takes the least time/effort, not because there is any intrinsic value in making people struggle to follow their path.")

#text("Of course, you don’t get anywhere without some form of exercise. But I think a lot of energy gets wasted unnecessarily when working from an unsuitable exposition; I mean here that certain explanations are geared toward experts, and others towards students. Bourgain’s expositions are undoubtedly for experts. And as Harald said, reading those papers is often easier with a friend.")

#text("For those not lucky enough to have a friend available, a guide to Bourgain’s tools could serve as a substitute companion. Not perfect by any means, but better than nothing. When I was learning analysis, I often used this blog in the same way, and benefited enormously from it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510179")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")])]

#text("I agree both in wishing mainly for (1) (though I believe that more than a mere collection of links will be needed) and on the importance of exercises. My remark on the implications of an effort of exegesis was off-hand, and meant no more than a milder version of what you have already said. (I never hated Jean Bourgain!) I do think that some expository articles on techniques would belong in a collective effort, and that they might be more widely read as part of one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510181")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")])]

#text("… not to mention that the very existence of such an attempt at collective exegesis would be the best tribute to somebody’s work (both the results and the papers themselves) that there could be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-512981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")])]

#text("Are there any (e)journals that publish expository papers or annotated notes of “important” papers? This may probably avoid the downsides of internet forums that allow unrestricted comments.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81cc45fb6e0c7e3445264f684b4c9c4746d708fdf5d991cba3f00ffcd4c21be0-4df9ceeeec4092d8fc4eff1bf2c916cb9d4e3093ddb56e3630a970cf9f8f7061.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chandan Sinha")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509798")[#strong[#text("Chandan Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("His work would continue to revolutionize the field of analysis. May he rest in piece.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509811")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("11")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509839")[#strong[#text("Mais ne vous reveillez pas | Since it is not ...")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")]

#text("[…] had deeper involvement with his work will be able to offer more fitting tributes. A start is the blog post of Terry Tao which I mentioned at the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c782d91962f13d6ae33560021440a8bbdc9438222c95ccfe8287495b2457848d-c82bf917232766b40bc39887abfa8b7048dfa2a96c415fce2e8dea72eb3fba11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reddjmichael")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509846")[#strong[#text("reddjmichael")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Inspiring and well and lovingly written")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509943")[#strong[#text("Complexity Year in Review 2018 – Site Title")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")]

#text("[…] posters Vijay Vazirani, Samir Khuller and Robert Kleinberg, and anonymous. We remember Jean Bourgain, George H. W. Bush, Babak Farzad, Stephen Hawking, Ker-I Ko and Stan Lee. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-509997")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2018")])]

#text("What’s in that upper left bent corner in the photo? Another level of frustration?")

#emph[#text("[A staple, which was connecting this page to the preceding pages of the paper and thus had to be folded back to leave this page exposed. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")])]

#text("Every time I tried to read a paper of J. Bourgain, I gave up (too little amount of detail). Does there exist well-written papers of J. Bourgain, i.e. readable for a medium mathematician?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2019")])]

#text("One can for instance start with the ")#link("https://terrytao.files.wordpress.com/2018/12/JeanFaxTao.pdf")[#text("two page argument of Jean")]#text(" I linked to in the main post, which has the advantage of having also been written up in a blend of Jean’s writing styles with mine and Nets’ in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2053599")[#text("the published version")]#text(", so one can read the two arguments concurrently to resolve any ambiguities (there are numerous subsequent surveys of the sum-product phenomenon that one can also refer to). Another Bourgain paper which is rather short and elegant is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=868898")[#text("his paper on high-dimensional maximal functions")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Silverman Silverman")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510357")[#strong[#text("Robert Silverman Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("I find it interesting that no one has commented on the Dec 26’th death of Peter Swinnerton-Dyer………It has been a very bad month.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510090")[#strong[#text("Terrance Tao remembering Jean Bourgain – thinkorswim_tech")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")[#text("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")]#text(" — Read on terrytao.wordpress.com/2018/12/29/jean-bourgain/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")])]

#text("A very insightful piece on the work of math researchers. I only tried to read one math paper but I noticed an abrupt increase in difficulty compared to a uni course. I read that Jean Bourgain once declared math “hard labour”, involving a lot of “suffering” but that the reward of discovery made it all worth it. In Belgium he has been nicknamed the Eddy Merckx of mathematics by the few who knew about his achievements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510156")[#strong[#text("Jean | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2019")]

#text("[…] can read about Jean Bourgain in Terry Tao’s beautiful obituary post. I was also moved by Svetlana Jitomirskaya’s beautiful facebook post. Some of Jean’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510312")[#strong[#text("Mathematical Obituaries, December 2018 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")]

#text("[…] Jean Bourgain obituary, at Terry Tao’s blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84ca5816cc11edbb52f1cb291e26c060f5ae1e4b100ff42cb7f727a1bf32cc68-4ac59231fffa8d40383cb4f4141838b9e0eadb9289c6bf8d87893740803f48a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonimous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510343")[#strong[#text("Anonimous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("Maybe it is a relevant comparison. Kolmogorov himself did not describe his papers as more important or less important. He said during a celebration of his anniversary, that some of them have found the response from other mathematicians, and others did not. It might happen that some potentially useful tricks were left outside of custom made toolboxes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-511092")[#strong[#text("Jean Bourgain 1954–2018 and Michael Atiyah 1929–2019 | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2019")]

#text("[…] Among many sources, note this seminar sponsored by Fan Chung and links from Tao’s own memorial post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joas165")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-511323")[#strong[#text("joas165")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2019")])]

#text("I appreciate that Bourgain and Stein are both holding drinks in their pictures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5e540c8a0b6992d4da14227177a37980f06940b8ab24c0c2b5826d10cdcefda-3e84130cccfd40cb651c16cbb5b2c5dd7920a074dba3e25483be7f5f97703097.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-511451")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2019")])]

#text("Can you provide the picture of your annotated version in better resolution? I’d like to read the passage where you annotated that you hate him ;)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-511510")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2019")])]

#text("Obviously, that annotation regarded only Bourgain’s writing style.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d03c1aad038fd6f81b4f33b0484bb853765aa97610f305fffa44976f92b5c8e-8d259b0ff6b841eaeb8c567676769da38191569b2ae424c2184ad17ea595e705.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sususuqina")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-512350")[#strong[#text("sususuqina")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")])]

#text("I can’t read the rest of your blog, but the text of this article is very similar to reading your book Terence Tao teaches you to learn mathematics”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/322d65c30f650c065b4e1cca9f1b62f6037c1772e473bd64af50026e1fe5f559-096ab511dfdedb6ac66970668d3fb538bf99fb1bc23f7a6f532e8518f7b75e01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of idpnsd")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-521937")[#strong[#text("idpnsd")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("“I began to realise that Jean had a certain collection of tools, heuristics, and principles that he regarded as “basic”, such as dyadic decomposition and the uncertainty principle, and by working “modulo” these tools (that is, by regarding any step consisting solely of application of these tools as trivial), one could proceed much more rapidly and efficiently.”")

#text("Sadly, Uncertainty Principle (UP) has two fundamentally flawed assumptions. If you look at Heisenberg’s own proof given in his own book, you will find the following two assumptions. (1) It assumes that the position and momentum are related by Fourier Transform (FT). (2) The Fourier Transform uses infinity which does not exists in nature.")

#text("Clearly assumption (1) cannot be justified by any experimental data. Position and momentum are two independent variables of motion of a particle. If you assume (1) then you will naturally get the result of UP, because it is a simple manipulation of FT.")

#text("Moreover infinity cannot be approximated by any finite number, however large it may be. Replacing infinity by a finite number will change the characteristics of FT. In particular, it will eliminate uncertainty. For more details you can take a look at the exact copy of the original proof in the QM chapter in the free book on Soul Theory at the blog site ")#link("https://theoryofsouls.wordpress.com/")[#text("https://theoryofsouls.wordpress.com/")]#text(" or look at the original reference mentioned there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5dba8f2327dc251ca254d8e0da04e23d821ba9b9d82c55bfe5611048e82ce9d-abd129eaded0c37cd0cfd24e489167557b25bec131fc963a56bc3ad9be81ea2f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Aschbacher and the sociology of mathematical proof w.r.t. the classification theorem for finite simple groups – Julia Wolffe's Notes")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-537716")[#strong[#text("Michael Aschbacher and the sociology of mathematical proof w.r.t. the classification theorem for finite simple groups – Julia Wolffe's Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2020")])]

#text("[…] These quotes remind me of yet another monster mind — the late Jean Bourgain. This obituary by Terry Tao relates some of his experiences as a grad student struggling greatly with Bourgain’s papers, an experience common to most: ")#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")[#text("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-547424")[#strong[#text("Kelman, Kindler, Lifshitz, Minzer, and Safra: Towards the Entropy-Influence Conjecture | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")]

#text("[…] Ryan O’Donnel wrote about Bourgain and some of his contributions to the analysis of Boolean […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-642326")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2022")])]

#text("Could you elaborate a bit on the handwritten remark “Sobolev norms!” of the picture? What does he actually mean by “usual way” of formalizing that argument?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-684604")[#strong[#text("让·布尔盖恩（2018年） - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2024")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-689125")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2025")])]

#text("What is the motivation of Jean Bourgain doing Harmonic analysis or Fourier Analysis from his childhood? It would be excellent if he has a similar story as yours.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-693482")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2026")])]

#text("This is a follow-up to a ")#link("https://terrytao.wordpress.com/2018/12/29/jean-bourgain/#comment-510092")[#text("previous comment")]#text(".")

#text("I find it much more pleasant, and at least less discouraging, to read a difficult paper now that AI assistance is readily available. Resources such as Gowers’s Tricki and MathOverflow can now be supplemented, and sometimes partly replaced, by direct AI queries and tools such as your recent paper diagram visualizer.")

#text("Have recent developments in AI significantly changed how you supervise graduate students—for instance, how you guide them through difficult papers, decide what they should work out for themselves, and help them internalize techniques rather than merely obtain explanations?")
]
