// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/
// Converted to Typst by tao2typ: "2026-10-14T15:16:46.701055+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In previous lectures, we have established (modulo some technical details) two significant components of the proof of the Poincaré conjecture: finite time extinction of Ricci flow with surgery (Theorem 4 of ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text("), and a ")#mi("\\kappa")#text("-noncollapsing of Ricci flows with surgery (which, except for the surgery part, is Theorem 2 of ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text("). Now we come to the heart of the entire argument: the topological and geometric control of the high curvature regions of a Ricci flow, which is absolutely essential in order for one to define surgery on these regions in order to move the flow past singularities. This control is intimately tied to the study of a special type of Ricci flow, the ")#emph[#mi("\\kappa")#text("-solutions")]#text(" to the Ricci flow equation; we will be able to use compactness arguments (as well as the ")#mi("\\kappa")#text("-noncollapsing results already obtained) to deduce control of high curvature regions of arbitrary Ricci flows from similar control of ")#mi("\\kappa")#text("-solutions. A secondary compactness argument lets us obtain that control of ")#mi("\\kappa")#text("-solutions from control of an even more special type of solution, the ")#emph[#text("gradient shrinking solitons")]#text(" that we already encountered in ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(".")

#text("[Even once one has this control of high curvature regions, the proof of the Poincaré conjecture is still not finished; there is significant work required to properly define the surgery procedure, and then one has to show that the surgeries do not accumulate in time, and also do not disrupt the various monotonicity formulae that we are using to deduce finite time extinction, ")#mi("\\kappa")#text("-noncollapsing, etc. But the control of high curvature regions is arguably the largest single task one has to establish in the entire proof.]")

#text("The next few lectures will be devoted to the analysis of ")#mi("\\kappa")#text("-solutions, culminating in Perelman’s topological and geometric classification (or near-classification) of such solutions (which in particular leads to the ")#emph[#text("canonical neighbourhood theorem")]#text(" for these solutions, which we will briefly discuss below). In this lecture we shall formally define the notion of a ")#mi("\\kappa")#text("-solution, and indicate informally why control of such solutions should lead to control of high curvature regions of Ricci flows. We’ll also outline the various types of results that we will prove about ")#mi("\\kappa")#text("-solutions.")

#text("Our treatment here is based primarily on the ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("book of Morgan and Tian")]#text(".")

#metadata(none) <tao-af563c4926069fedd806>

#heading(level: 1)[#text("— Definition of a ")#mi("\\kappa")#text("-solution —")]

#text("We fix a small number ")#mi("\\kappa > 0")#text(" (basically the parameter that comes out of the non-collapsing theorem). Here is the formal definition of a ")#mi("\\kappa")#text("-solution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1. ")]#text(" (")#mi("\\kappa")#text("-solutions) A ")#emph[#mi("\\kappa")#text("-solution")]#text(" is a Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" which is")

#enum(start: 1, 
[#emph[#text("Ancient")]#text(", in the sense that t ranges on the interval ")#mi("(-\\infty,0]")#text(";")],
[#emph[#text("Complete and connected")]#text(" (i.e. (M,g(t)) is complete and connected for every t);")],
[#emph[#text("Non-negative Riemann curvature")]#text(", i.e. ")#mi("\\text{Riem}: \\bigwedge^2 TM \\to \\bigwedge^2 TM")#text(" is positive semidefinite at all points in spacetime;")],
[#emph[#text("Bounded curvature")]#text(", thus ")#tao-math("\\sup_{(t,x) \\in (-\\infty,0] \\times M} \\left|\\text{Riem}\\right|_g < +\\infty", block: false)#text(";")],
[#emph[#mi("\\kappa")#text("-noncollapsed")]#text(" (see Definition 1 of ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(") at every point ")#mi("(t_0,x_0)")#text(" in spacetime and at every scale ")#mi("r_0 > 0")#text(";")],
[#emph[#text("Non-flat")]#text(", i.e. the curvature is non-zero at at least one point in spacetime.")]
)
]

#text("This laundry list of properties arises because they are the properties that we are able to directly establish on limits of rescaled Ricci flows; see below.")

#strong[#text("Remark 1. ")]#text(" If a d-dimensional Riemann manifold is both flat (thus ")#mi("\\text{Riem}=0")#text(") and non-collapsed at every scale, then (by Cheeger’s lemma, Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(") its injectivity radius is infinite, and by normal coordinates the manifold is isometric to Euclidean space ")#mi("{\\Bbb R}^d")#text(". Thus the non-flat condition is only excluding the ")#emph[#text("trivial Ricci flow")]#text(" ")#mi("M = {\\Bbb R}^d")#text(" with the standard (and static) metric. The non-flat condition tells us that the (scalar, say) curvature is positive in at least one point of spacetime, but we will shortly be able to use the strong maximum principle to conclude in fact that the curvature is positive everywhere. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" In three dimensions, the condition of non-negative RIemann curvature is equivalent to that of non-negative sectional curvature; see the discussion in ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("Lecture 0")]#text(". In any dimension, the conditions of non-negative bounded Riemann curvature imply that R and ")#mi("\\text{Ric}")#text(" are non-negative, and that ")#tao-math("\\left|\\text{Riem}\\right|_g, \\left|\\text{Ric}\\right|_g = O(R)", block: false)#text(" and ")#mi("R = O_d(1)")#text(". Thus as far as magnitude is concerned, the Riemann and Ricci curvatures of ")#mi("\\kappa")#text("-solutions are controlled by the scalar curvature. ")#mi("\\diamond")

#text("Now we discuss examples (and non-examples) of ")#mi("\\kappa")#text("-solutions.")

#strong[#text("Example 1.")]#text(" Every gradient shrinking soliton or gradient steady soliton (M,g) (see ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(") gives an ancient flow. This flow will be a ")#mi("\\kappa")#text("-solution for sufficiently small ")#mi("\\kappa")#text(" if the Einstein manifold (M,g) is complete, connected, non-collapsed at every scale, and is not Euclidean space. For instance, the round sphere ")#mi("S^d")#text(" with the standard metric is a gradient shrinking solution and will generate a ")#mi("\\kappa")#text("-solution for any ")#mi("d \\geq 2")#text(" and sufficiently small ")#mi("\\kappa > 0")#text(", which we will refer to as the ")#emph[#text("shrinking round sphere")]#text(" ")#mi("\\kappa")#text("-solution. ")#mi("\\diamond")

#strong[#text("Exercse 1.")]#text(" Show that the Cartesian product of two ")#mi("\\kappa")#text("-solutions is again a ")#mi("\\kappa")#text("-solution (with a smaller value of ")#mi("\\kappa")#text("), as is the Cartesian product of a ")#mi("\\kappa")#text("-solution. Thus for instance the product ")#mi("S^2 \\times {\\Bbb R}")#text(" of the shrinking round 2-sphere and the Euclidean line is a ")#mi("\\kappa")#text("-solution, which we refer to as the ")#emph[#text("shrinking round 3-cylinder")]#text(" ")#mi("S^2 \\times {\\Bbb R}")#text(". ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" In one dimension, there are no ")#mi("\\kappa")#text("-solutions, as every manifold is flat; in particular, the 1-sphere (i.e. a circle) is ")#emph[#text("not")]#text(" a ")#mi("\\kappa")#text("-solution (it is flat and also collapsed at large scales). In two dimensions, the shrinking round 2-sphere ")#mi("S^2")#text(" is ")#mi("\\kappa")#text("-solution, as discussed above. We can quotient this by the obvious ")#mi("{\\Bbb Z}/2")#text(" action to also get a shrinking round projective plane ")#mi("\\Bbb{RP}^2")#text(" as a ")#mi("\\kappa")#text("-solution. But we shall show in later lectures that if we restrict attention to oriented manifolds, then the shrinking round 2-sphere is the only 2-dimensional ")#mi("\\kappa")#text("-solutions; this result is due to Hamilton, see e.g. Chapter 5 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061425")[#text("Chow-Knopf")]#text(". For instance, the 2-cylinder ")#mi("S^1 \\times {\\Bbb R}")#text(" is not a ")#mi("\\kappa")#text("-solution (it is both flat and collapsed at large scales). The cigar soliton (Example 3 from ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text(") also fails to be a ")#mi("\\kappa")#text("-solution due to it being collapsed at large scales. ")#mi("\\diamond")#strong[#linebreak()#text(" ")]

#strong[#text("Example 3.")]#text(" In three dimensions, we begin to get significantly more variety amongst ")#mi("\\kappa")#text("-solutions. We have the round shrinking 3-sphere ")#mi("S^3")#text(", but also all the quotients ")#mi("S^3/\\Gamma")#text(" of such round spheres by free finite group actions (including the projective space ")#mi("{\\Bbb RP}^3")#text(", but with many other examples. We refer to these examples as ")#emph[#text("round shrinking 3-spherical space forms")]#text(". We have also seen the shrinking round cylinder ")#mi("S^2 \\times {\\Bbb R}")#text("; there are also finite quotients of this example such as shrinking round projective cylinder ")#mi("\\Bbb{RP}^2 \\times {\\Bbb R}")#text(", or the quotient of the cylinder by the orientation-preserving free involution ")#mi("(\\omega,z) \\mapsto (-\\omega,-z)")#text(". We refer to these examples as the ")#emph[#text("unoriented and oriented quotients of the shrinking round 3-cylinder")]#text(" respectively. The oriented quotient can be viewed as a half-cylinder ")#mi("S^2 \\times [1,+\\infty)")#text(" capped off with a punctured ")#mi("\\Bbb{RP}^3")#text(" (and the whole manifold is in fact homeomorphic to a punctured ")#mi("\\Bbb{RP}^3")#text("). ")#mi("\\diamond")

#strong[#text("Example 4. ")]#text("One can also imagine perturbations of the shrinking solutions mentioned above. For instance, one could imagine non-round versions of the shrinking ")#mi("S^2")#text(" or shrinking ")#mi("{\\Bbb RP}^3")#text(" example, in which the manifold has sectional curvature which is still positive but not constant. We shall informally refer to such solutions as ")#emph[#text("C-components")]#text(" (we will define this term formally later, and explain the role of the parameter C). Similarly one could imagine variants of the oriented quotient of the shrinking round cylinder, which are approximately round half-cylinders ")#mi("S^2 \\times [1,+\\infty)")#text(" capped off with what is topologically either a punctured ")#mi("\\Bbb{RP}^3")#text(" or punctured ")#mi("S^3")#text(" (i.e. with something homeomorphic to a ball); a 3-dimensional variant of a cigar soliton would fall into this category (such solitons have been constructed ")#link("http://arxiv.org/abs/math/0407453")[#text("by Bryant")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1417944")[#text("by Cao")]#text("). We informally refer to such solutions as ")#mi("C")#text("-capped strong ")#mi("\\varepsilon")#text("-tubes (we will define this term precisely later). One can also consider ")#emph[#text("doubly ")#mi("C")#text("-capped strong ")#mi("\\varepsilon")#text("-tubes")]#text(", in which an approximately round finite cylinder ")#mi("S^2 \\times [-T,T]")#text(" is capped off at both ends by either a punctured ")#mi("\\Bbb{RP}^3")#text(" or punctured ")#mi("S^3")#text("; such manifolds then become homeomorphic to either ")#mi("S^3")#text(" or ")#mi("{\\Bbb RP}^3")#text(". (Note we need to cap off any ends that show up in order to keep the manifold M complete.) ")#mi("\\diamond")

#text("An important theorem of Perelman shows that these examples of ")#mi("\\kappa")#text("-solutions are in fact the only ones:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Perelman classification theorem, imprecise version) Every 3-dimensional ")#mi("\\kappa")#text("-solution takes on one of the following forms at time zero (after isometry and rescaling, if necessary):")

#enum(start: 1, 
[#text("A shrinking round 3-sphere ")#mi("S^3")#text(" (or shrinking round spherical space form ")#mi("S^3/\\Gamma")#text(");")],
[#text("A shrinking round 3-cylinder ")#mi("S^2 \\times {\\Bbb R}")#text(", the quotient ")#mi("\\Bbb{RP}^2 \\times {\\Bbb R}")#text(", or one of its quotients (either oriented or unoriented);")],
[#text("A C-component;")],
[#text("A C-capped strong ")#mi("\\varepsilon")#text("-tube;")],
[#text("A doubly C-capped strong ")#mi("\\varepsilon")#text("-tube.")]
)
]

#text("We will make this theorem more precise in later lectures (or if you are impatient, you can read Chapter 9 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(").")

#strong[#text("Remark 3.")]#text(" At very large scales, Theorem 1 implies that an ancient solution at time zero either looks 0-dimensional (because the manifold was compact, as in the case of a sphere, spherical space form, C-component, or doubly C-capped strong ")#mi("\\varepsilon")#text("-tube) or 1-dimensional, resembling a line (in the case of the cylinder) or half-line (for C-capped strong ")#mi("\\varepsilon")#text("-tube). Oversimplifying somewhat, this 0- or 1-dimensionality of the three-dimensional ")#mi("\\kappa")#text("-solutions is the main reason why surgery is even possible; if Ricci flow singularities could look 2-dimensional (such as ")#mi("S^1 \\times {\\Bbb R}^2")#text(", or as the product of the cigar soliton and a line) or 3-dimensional (as in ")#mi("{\\Bbb R}^3")#text(") then it is not clear at all how to define a surgery procedure to excise the singularity. The point is that all the potential candidates for singularity that look 2-dimensional or 3-dimensional at large scales (after rescaling) are either flat or collapsed (or do not have bounded nonnegative curvature), and so are not ")#mi("\\kappa")#text("-solutions. The unoriented quotiented cylinder ")#mi("\\Bbb{RP}^2 \\times {\\Bbb R}")#text(" also causes difficulties with surgery (despite being only one-dimensional at large scales), because it is hard to cap off such a cylinder in a manner which is well-behaved with respect to Ricci flow; however if we assume that the original manifold M contains no embedded copy of ")#mi("\\Bbb{RP}^2 \\times {\\Bbb R}")#text(" (which is for instance the case if the manifold is oriented, and in particular if it is simply connected) then this case does not occur. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" In four and higher dimensions, things look much worse; consider for instance the product of a shrinking round ")#mi("S^2")#text(" with the trivial plane ")#mi("{\\Bbb R}^2")#text(". This is a ")#mi("\\kappa")#text("-solution but has a two-dimensional large-scale structure, and so there is no obvious way to remove singularities of this shape by surgery. It may be that in order to have analogues of Perelman’s theory in higher dimensions one has to make much stronger topological or geometric assumptions on the manifold. Note however that four-dimensional Ricci flows with surgery were already considered ")#link("http://www.ams.org/mathscinet-getitem?mr=862046")[#text("by Hamilton")]#text(" (with a rather different definition of surgery, however).")

#text("The classification theorem lets one understand the geometry of neighbourhoods of any given point in a ")#mi("\\kappa")#text("-solution. Let us make the following imprecise definitions (which, again, will be made precise in later lectures):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2. ")]#text(" (Canonical neighbourhoods, informal version) Let (M,g) be a complete connected 3-manifold, let x be a point in M, and let U be an open neighbourhood of x. We normalise the scalar curvature at x to be 1.")

#enum(start: 1, 
[#text("We say that U is an ")#emph[#mi("\\varepsilon")#text("-neck")]#text(" if it is close (in a smooth topology) to a round cylinder ")#mi("S^2 \\times (-R,R)")#text(", with x well in the middle of of this cylinder;")],
[#text("We say that U is a ")#emph[#text("C-component")]#text(" if U is diffeomorphic to ")#mi("S^3")#text(" or ")#mi("\\Bbb{RP}^3")#text(" (in particular, it must be all of M) with sectional curvatures bounded above and below by positive constants, and with diameter comparable to 1.")],
[#text("We say that U is ")#emph[#mi("\\varepsilon")#text("-round")]#text(" if it is close (in a smooth topology) to a round sphere ")#mi("S^3")#text(" or spherical space form ")#mi("S^3/\\Gamma")#text(" (i.e. it is close to a constant curvature manifold).")],
[#text("We say that U is a ")#emph[#mi("(C,\\varepsilon)")#text("-cap")]#text(" if it consists of an ")#mi("\\varepsilon")#text("-neck together with a cap at one end, where the cap is homeomorphic to either an open 3-ball or a punctured ")#mi("{\\Bbb RP}^3")#text(" and obeys similar bounds as a C-component, and that x is contained inside the cap. (For technical reasons one also needs some derivative bounds on curvature, but we omit them here.)")],
[#text("We say that U is a ")#emph[#text("canonical neighbourhood")]#text(" of x if it is one of the above four types.")]
)

#text("When the scalar curvature is some other positive number than 1, we can generalise the above definition by rescaling the metric to have curvature 1.")
]

#text("Using Theorem 1 (and defining all terms precisely), one can easily show the following important statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(" (Canonical neighbourhood theorem for ")#mi("\\kappa")#text("-solitons, informal version) Every point in a 3-dimensional ")#mi("\\kappa")#text("-solution that does not contain an embedded copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle is contained in a canonical neighbourhood.")
]

#text("The next few lectures will be devoted to establishing precise versions of Theorem 1, Definition 2, and Corollary 1.")

#heading(level: 1)[#text("— High curvature regions of Ricci flows —")]

#text("Corollary 1 is an assertion about ")#mi("\\kappa")#text("-solutions only, but it implies an important property about more general Ricci flows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Canonical neighbourhood for Ricci flows, informal version) Let ")#mi("t \\mapsto (M,g)")#text(" be a Ricci flow of compact 3-manifolds on a time interval ")#mi("{}[0,T)")#text(", without any embedded copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle. Then every point ")#mi("(t,x) \\in [0,T) \\times M")#text(" with sufficiently large scalar curvature is contained in a canonical neighbourhood.")
]

#text("(Actually, as with many other components of this proof, we actually need a generalisation of this result for Ricci flow with surgery, but we will address this (non-trivial) complication later.)")

#text("The importance of this theorem lies in the fact that all the singular regions that need surgery will have large scalar curvature, and Theorem 2 provides the crucial topological and geometric control in order to perform surgery on these regions. (This is a significant oversimplification, as one has to also study certain “horns” that appear at the singular time in order to find a particularly good place to perform surgery, but we will postpone discussion of this major additional issue later in this course.)")

#text("Theorem 2 is deduced from Corollary 1 and a significant number of additional arguments. The strategy is to use a compactness-and-contradiction argument. As a very crude first approximation, the proof goes as follows:")

#enum(start: 1, 
[#text("Suppose for contradiction that Theorem 2 failed. Then one could find a sequence ")#mi("(t_n,x_n) \\in [0,T) \\times M")#text(" of points with ")#mi("R(t_n,x_n) \\to +\\infty")#text(" which were not contained in canonical neighbourhoods.")],
[#text("M, being compact, has finitely many components; by restricting attention to a subsequence of points if necessary, we can take M to be connected.")],
[#text("On any compact time interval ")#mi("{}[0,t] \\times M")#text(", the scalar curvature is necessarily bounded, and thus ")#mi("t_n \\to T")#text(". As a consequence, if we define the rescaled Ricci flows ")#mi("g^{(n)}(t) = \\frac{1}{L_n^2} g( t_n + L_n^2 t )")#text(", where ")#mi("L_n := R(t_n,x_n)^{-1/2}")#text(" is the natural length scale associated to the scalar curvature at ")#mi("(t_n,x_n)")#text(", then these flows will become increasingly ancient. Note that in the limit (which we will not define rigorously yet, but think of a ")#link("http://en.wikipedia.org/wiki/Gromov-Hausdorff_limit#Pointed_Gromov.E2.80.93Hausdorff_convergence")[#text("pointed Gromov-Hausdorff limit")]#text(" for now), the increasingly large manifolds ")#mi("(M,g^{(n)}(t))")#text(" may cease to be compact, but will remain complete.")],
[#text("Because of the Hamilton-Ivey pinching phenomenon (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("), we expect the rescaled flows ")#mi("t \\mapsto (M, g^{(n)}(t))")#text(" to have non-negative Ricci curvature in the limit (and hence non-negative Riemann curvature also, as we are in three dimensions).")],
[#text("If we can pick the points ")#mi("(t_n,x_n)")#text(" suitably (so that the scalar curvature ")#mi("R(t_n,x_n)")#text(" is larger than or comparable to the scalar curvatures at other nearby points), then we should be able to ensure that the rescaled flows ")#mi("t \\mapsto (M, g^{(n)}(t))")#text(" have bounded curvature in the limit.")],
[#text("Since ")#mi("\\kappa")#text("-noncollapsing is invariant under rescaling, the non-collapsing theorem (Theorem 2 of ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(") should ensure that the rescaled flows remain ")#mi("\\kappa")#text("-noncollapsed in the limit.")],
[#text("Since the rescaled scalar curvature at the base point ")#mi("x_n")#text(" of ")#mi("(M,g^{(n)})")#text(" is equal to 1 by construction, any limiting flow will be non-flat.")],
[#text("Various compactness theorems (of Gromov, Hamilton, and Perelman) exploiting the non-collapsed, bounded curvature, and parabolic nature of the rescaled Ricci flows now allows one to extract a limiting flow ")#mi("(M^{(\\infty)}, g^{(\\infty)})")#text(". This limit is initially in a fairly weak sense, but one can use parabolic theory to upgrade the convergence to quite a strong (and smooth) convergence. In particular, the limit of the Ricci flows will remain a Ricci flow.")],
[#text("Applying 2-8, we see that the limiting flow ")#mi("(M^{(\\infty)}, g^{(\\infty)})")#text(" is a ")#mi("\\kappa")#text("-solution.")],
[#text("Applying Corollary 1, we conclude that every point in the limiting flow lies inside a canonical neighbourhood. Using the strong nature of the convergence (and the scale-invariant nature of canonical neighbourhoods), we deduce that the points ")#mi("(t_n,x_n)")#text(" also lie in canonical neighbourhoods for sufficiently large n, a contradiction.")]
)

#text("There are some non-trivial technical difficulties in executing the above scheme, especially in Step 5 and Step 8. Step 8 will require some compactness theorems for ")#mi("\\kappa")#text("-solutions which we will deduce in later lectures. For Step 5, the problem is that the points ")#mi("(t_n,x_n)")#text(" that we are trying to place inside canonical neighbourhoods have large curvature, but they may be adjacent to other points of significantly higher curvature, so that the limiting flow ")#mi("(M^{(\\infty)}, g^{(\\infty)})")#text(" ends up having unbounded curvature. To get around this, Perelman established Theorem 2 by a downwards induction argument on the curvature, first establishing the result for extremely high curvature, then for slightly less extreme curvature, and so forth. The point is that with such an induction hypothesis, any potentially bad adjacent points of really high curvature will be safely tucked away in a canonical neighbourhood of high curvature, which in turn is connected to another canonical neighbourhood of high curvature, and so forth; some basic topological and geometric analysis then eventually lets us conclude that this bad point must in fact be quite far from the base point ")#mi("(t_n,x_n)")#text(" (much further away than the natural length scale ")#mi("L_n")#text(", in particular), so that it does not show up in the limiting flow ")#mi("(M^{(\\infty)}, g^{(\\infty)})")#text(". We will discuss these issues in more detail in later lectures.")

#heading(level: 1)[#text("— Benchmarks in controlling ")#mi("\\kappa")#text("-solutions —")]

#text("As mentioned earlier, the next few lectures will be focused on controlling ")#mi("\\kappa")#text("-solutions. It turns out that the various properties in Definition 1 interact very well with each other, and give remarkably precise control on these solutions. In this section we state (without proofs) some of the results we will establish concerning such solutions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Consequences of Hamilton’s Harnack inequality) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a ")#mi("\\kappa")#text("-solution. Then ")#mi("R(t,x)")#text(" is a non-decreasing function of time. Furthermore, for any ")#mi("(t_0,x_0) \\in (-\\infty,0] \\times M")#text(", we have the pointwise inequalities")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\nabla l_{(t_0,x_0)}\\right|^2 + R \\leq \\frac{3 l_{(t_0,x_0)}}{\\tau}", block: true)]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("-2 \\frac{l_{(t_0,x_0)}}{\\tau} \\leq \\frac{\\partial l_{(t_0,x_0)}}{\\partial \\tau} \\leq \\frac{l_{(t_0,x_0)}}{\\tau}")]]

#text("on ")#mi("(-\\infty,t_0) \\times M")#text(", where of course ")#mi("\\tau := t_0 - t")#text(" is the backwards time variable.")
]

#text("These inequalities follow from an important ")#link("http://www.ams.org/mathscinet-getitem?mr=1198607")[#text("Harnack inequality of Hamilton")]#text(" (also related to earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=834612")[#text("work of Li and Yau")]#text(") that we will discuss in the next lecture. These results rely primarily on the ancient and non-negatively curved nature of ")#mi("\\kappa")#text("-solutions, as well as the Ricci flow equation ")#mi("\\dot g = -2 \\text{Ric}")#text(" of course.")

#text("Now one can handle the two-dimensional case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("(Classification of 2-dimensional ")#mi("\\kappa")#text("-solutions) The only two-dimensional ")#mi("\\kappa")#text("-solutions are the round shrinking 2-spheres.")
]

#text("This proposition relies on first studying a certain asymptotic limit of the ")#mi("\\kappa")#text("-solution, known as the asymptotic soliton, to be defined later. One shows that this asymptotic limit is a round shrinking 2-sphere, which implies that the original ")#mi("\\kappa")#text("-solution is asymptotically a round shrinking 2-sphere. One can then invoke Hamilton’s rounding theorem to finish the claim.")

#text("Turning now to three dimensions, the first important result that the curvature R decays slower at infinity than what scaling naively predicts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" (Asymptotic curvature) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a 3-dimensional ")#mi("\\kappa")#text(" solution which is not compact. Then for any time ")#mi("t \\in (-\\infty,0)")#text(" and any base point ")#mi("p \\in M")#text(", we have ")#mi("\\limsup_{x \\to \\infty} R(t,x) d_{g(t)}(x,p)^2 = +\\infty")#text(".")
]

#text("The proof of Proposition 3 is based on another compactness-and-contradiction argument which also heavily exploits some splitting theorems in Riemannian geometry, as well as the ")#link("http://en.wikipedia.org/wiki/Soul_theorem")[#text("soul theorem")]#text(".")

#text("The increasing curvature at infinity can be used to show that the volume does not grow as fast at infinity as scaling predicts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4.")]#text(" (Asymptotic volume collapse) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a 3-dimensional ")#mi("\\kappa")#text(" solution which is not compact. Then for any time ")#mi("t \\in (-\\infty,0)")#text(" and any base point ")#mi("p \\in M")#text(", we have ")#mi("\\limsup_{r \\to +\\infty} \\text{Vol}_{g(t)}( B_{g(t)})(p,r) ) / r^3 = 0")#text(".")
]

#text("Note that Proposition 4 does not contradict the non-collapsed nature of the flow, since one does not expect bounded normalised curvature at extremely large scales. Proposition 4 morally follows from Bishop-Gromov comparison geometry theory, but its proof in fact uses yet another compactness-and-contradiction argument combined with splitting theory.")

#text("An important variant of Proposition 4 and Proposition 3 (and yet another compactness-and-contradiction argument) states that on any ball ")#mi("B_{g(0)}(p,r)")#text(" at time zero on which the volume is large (e.g. larger than ")#mi("\\nu r^3")#text(" for some ")#mi("\\nu > 0")#text("), one has bounded normalised curvature, thus ")#mi("R = O_\\nu( 1 / r^2 )")#text(" on this ball. This fact helps us deduce")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (Perelman compactness theorem, informal version) The space of all pointed ")#mi("\\kappa")#text("-solutions (allowing ")#mi("\\kappa > 0")#text(" to range over the positive real numbers) is compact (in a suitable topology) after normalising the scalar curvature at the base point to be 1.")
]

#text("One corollary of this compactness is that there is in fact a universal ")#mi("\\kappa_0 > 0")#text(" such that every ")#mi("\\kappa")#text("-solution is a ")#mi("\\kappa_0")#text("-solution. (Indeed, the proof of this universality is one of the key steps in the proof of the above theorem.) This theorem is proven by establishing some uniform curvature bounds on ")#mi("\\kappa")#text("-solutions which come from the previous volume analysis.")

#text("The proof of Theorem 1 (and thus Corollary 1) follows from this compactness once one can classify the asymptotic solitons mentioned earlier. This task in turn requires many of the techniques already mentioned, together with some variational analysis of the gradient curves of the potential function f that controls the geometry of the soliton.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6b562d38b96cf657178c57a00162656d21e0796cee1bce089d46b095f465503-d73df4ba1958da133c15dd70e43bf60c592fbcc31fbc6cecb8ede2f08b8ef88a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton Fonarev")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29826")[#strong[#text("Anton Fonarev")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("Dear prof. Tao,")

#text("I mentioned a small misprint. There’s no closing bracket in Theorem 3 after ")#mi("\\kappa > 0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29828")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29881")[#strong[#text("This past two weeks… « It’s Equal, but It’s Different…")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2008")]

#text("[…] 285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume, 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume, 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29890")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] The classical proofs of the parabolic Harnack inequality do not give particularly sharp bounds on the constant . Such sharp bounds were obtained by Li and Yau, especially in the case of the scalar heat equation (1) in the case of static manifolds of non-negative Ricci curvature, using Bochner-type identities and the scalar maximum principle. In fact, a stronger differential version of (3) was obtained which implied (3) by an integration along spacetime curves (closely analogous to the -geodesics considered in earlier lectures). These bounds were particularly strong in the case of ancient solutions (in which one can send ). Subsequently, Hamilton applied his tensor-valued maximum principle together with some remarkably delicate tensor algebra manipulations to obtain Harnack inequalities of Li-Yau type for solutions to the Ricci flow (2) with bounded non-negative Riemannian curvature. In particular, this inequality applies to the -solutions introduced in the previous lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4f80cbb5722abb3492de3f863665f43b8d09e525eda1a8ffd4bda968ea98fe2-748546092a4debe1b2b6fe7773ad1c23571f1f3dfd749e5412f24773326b0ea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain Maillot")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29898")[#strong[#text("Sylvain Maillot")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("Another minor correction: in Example 2, you should delete the words")#linebreak()#text(" “shrinking round” before ")#mi("S^1\\times \\mathbb{R}")#text(" : this manifold")#linebreak()#text(" is flat, so it does not shrink by Ricci flow (and I wouldn’t call it “round”.)")

#text("A more serious point: I am surprised to see five cases in the classification of")#linebreak()#text(" ")#mi("\\kappa")#text("-solutions (Theorem 1), since in Perelman there are only four.")#linebreak()#text(" What is exactly the difference between case 3 “C-component” and case 5")#linebreak()#text(" “doubly ")#mi("C")#text("-capped strong ")#mi("\\varepsilon")#text("-tube” ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("Dear Sylvain: Thanks again for the corrections!")

#text("Regarding Theorem 1, I am basing this on Theorem 9.93 of Morgan-Tian (though I am grouping the cases a little differently). As I understand it, a C-component and a doubly C-capped strong epsilon-tube are topologically the same, but geometrically rather different; in the former the sectional curvature is bounded above and below everywhere, whereas in the latter the sectional curvature can be very small in the epsilon-tube component of the manifold (in planes parallel to the direction of the tube, of course). Also, if we normalise the maximal curvature to be 1, then C-components need to have diameter comparable to 1, but doubly C-capped epsilon-tubes can have arbitrarily large diameter.")

#text("Perhaps the key difference here between Morgan-Tian and Perelman is that in Morgan-Tian one tries to classify the global structure of kappa-solutions, even though for applications it is only the local structure (i.e. the canonical neighbourhoods) which is of importance. Thus, for instance, if one takes a doubly C-capped strong epsilon-tube, the canonical neighbourhood of any given point in such an object would be either an epsilon-neck, epsilon-cap, or a closed manifold in Perelman’s notation, depending on whether the tube is long or short and whether the point lies in the middle of the manifold or near one of the ends.")

#text("[In Morgan-Tian, the relevant canonical neighbourhood theorem is Corollary 9.94; the definition of canonical neighbourhoods on page 232 (and reproduced here as Definition 2) has exactly four cases and matches up with the corresponding notion in Perelman’s second paper.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4f80cbb5722abb3492de3f863665f43b8d09e525eda1a8ffd4bda968ea98fe2-748546092a4debe1b2b6fe7773ad1c23571f1f3dfd749e5412f24773326b0ea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain Maillot")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-29924")[#strong[#text("Sylvain Maillot")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2008")])]

#text("OK. In fact, if you take a ")#mi("\\kappa")#text("-solution which is a ")#mi("C")#text("-component at time zero and look into its past, then you will see a doubly capped neck, where the neck part becomes longer and longer as time goes to negative infinity.")

#text("This means that you can merge those two cases if you add time-shifting in your equivalence relation (in addition to isometry and rescaling). I would say that your statement is more a classification of time-zero slices of ")#mi("\\kappa")#text("-solutions than a classification of ")#mi("\\kappa")#text("-solutions strictly speaking.")

#text("Well, all this is irrelevant to the Poincare conjecture anyway…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-30184")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] 2 June, 2008 in 285G – poincare conjecture, math.DG by Terence Tao Tags: compactness and contradiction, geometric limits, gradient shrinking solitons, kappa-solutions, necks Having classified all asymptotic gradient shrinking solitons in three and fewer dimensions in the previous lecture, we now use this classification, combined with extensive use of compactness and contradiction arguments, as well as the comparison geometry of complete Riemannian manifolds of non-negative curvature, to understand the structure of -solutions in these dimensions, with the aim being to state and prove precise versions of Theorem 1 and Corollary 1 from Lecture 12. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/#comment-30213")[#strong[#text("285G, Lecture 18: The structure of high-curvature regions of Ricci flow « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2008")])]

#text("[…] now use them to describe the structure of high curvature regions of Ricci flow, as promised back in Lecture 12, in particular controlling their geometry and topology to the extent that surgery will be applied, […]")
]
