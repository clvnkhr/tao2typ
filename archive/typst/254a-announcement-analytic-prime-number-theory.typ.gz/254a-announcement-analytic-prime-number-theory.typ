// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/
// Converted to Typst by tao2typ: "2026-11-13T14:47:03.192950+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A announcement: Analytic prime number theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A announcement: Analytic prime number theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 November 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the winter quarter (starting January 5) I will be teaching a graduate topics course entitled “")#link("https://ccle.ucla.edu/course/view/15W-MATH254A-1")[#text("An introduction to analytic prime number theory")]#text("“. As the name suggests, this is a course covering many of the analytic number theory techniques used to study the distribution of the prime numbers ")#mi("{{\\mathcal P} = \\{2,3,5,7,11,\\dots\\}}")#text(". I will list the topics I intend to cover in this course below the fold. As with my previous courses, I will place lecture notes online on my blog in advance of the physical lectures.")

#text("The type of results about primes that one aspires to prove here is well captured by ")#link("http://en.wikipedia.org/wiki/Landau's_problems")[#text("Landau’s classical list of problems")]#text(":")

#enum(start: 1, 
[#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("Even Goldbach conjecture")]#text(": every even number ")#mi("{N}")#text(" greater than two is expressible as the sum of two primes.")],
[#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("Twin prime conjecture")]#text(": there are infinitely many pairs ")#mi("{n,n+2}")#text(" which are simultaneously prime.")],
[#link("http://en.wikipedia.org/wiki/Legendre%27s_conjecture")[#text("Legendre’s conjecture")]#text(": for every natural number ")#mi("{N}")#text(", there is a prime between ")#mi("{N^2}")#text(" and ")#mi("{(N+1)^2}")#text(".")],
[#text("There are infinitely many primes of the form ")#mi("{n^2+1}")#text(".")]
)

#text("All four of Landau’s problems remain open, but we have convincing heuristic evidence that they are all true, and in each of the four cases we have some highly non-trivial partial results, some of which will be covered in this course. We also now have some understanding of the barriers we are facing to fully resolving each of these problems, such as the parity problem; this will also be discussed in the course.")

#text("One of the main reasons that the prime numbers ")#mi("{{\\mathcal P}}")#text(" are so difficult to deal with rigorously is that they have very little usable algebraic or geometric structure that we know how to exploit; for instance, we do not have any useful ")#link("http://en.wikipedia.org/wiki/Formula_for_primes")[#text("prime generating functions")]#text(". One of course can create ")#emph[#text("non-useful")]#text(" functions of this form, such as the ordered parameterisation ")#mi("{n \\mapsto p_n}")#text(" that maps each natural number ")#mi("{n}")#text(" to the ")#mi("{n^{th}}")#text(" prime ")#mi("{p_n}")#text(", or one could invoke ")#link("http://en.wikipedia.org/wiki/Formula_for_primes#Formula_based_on_a_system_of_Diophantine_equations")[#text("Matiyasevich’s theorem")]#text(" to produce a polynomial of many variables whose only positive values are prime, but these sorts of functions have no usable structure to exploit (for instance, they give no insight into any of the Landau problems listed above; see also Remark ")#link(<tao-00b64810555cb5d5e027>)[#text("2")]#text(" below). The various ")#link("http://en.wikipedia.org/wiki/Primality_test")[#text("primality tests")]#text(" in the literature, while useful for practical applications (e.g. cryptography) involving primes, have also proven to be of little utility for these sorts of problems; again, see Remark ")#link(<tao-00b64810555cb5d5e027>)[#text("2")]#text(". In fact, in order to make plausible heuristic predictions about the primes, it is best to take almost the opposite point of view to the structured viewpoint, using as a starting point the belief that the primes exhibit strong ")#link("http://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandomness")]#text(" properties that are largely incompatible with the presence of rigid algebraic or geometric structure. We will discuss such heuristics later in this course.")

#text("It may be in the future that some usable structure to the primes (or related objects) will eventually be located (this is for instance one of the motivations in developing a rigorous theory of the “")#link("http://en.wikipedia.org/wiki/Field_with_one_element")[#text("field with one element")]#text("“, although this theory is far from being fully realised at present). For now, though, analytic and combinatorial methods have proven to be the most effective way forward, as they can often be used even in the near-complete absence of structure.")

#text("In this course, we will not discuss combinatorial approaches (such as the deployment of tools from ")#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#text("additive combinatorics")]#text(") in depth, but instead focus on the analytic methods. The basic principles of this approach can be summarised as follows:")

#enum(start: 1, 
[#text("Rather than try to isolate individual primes ")#mi("{p}")#text(" in ")#mi("{{\\mathcal P}}")#text(", one works with the set of primes ")#mi("{{\\mathcal P}}")#text(" in ")#emph[#text("aggregate")]#text(", focusing in particular on ")#emph[#text("asymptotic statistics")]#text(" of this set. For instance, rather than try to find a single pair ")#mi("{n,n+2}")#text(" of twin primes, one can focus instead on the ")#emph[#text("count")]#text(" ")#tao-math("{\\left|\\{ n \\leq x: n,n+2 \\in {\\mathcal P} \\}\\right|}", block: false)#text(" of twin primes up to some threshold ")#mi("{x}")#text(". Similarly, one can focus on counts such as ")#tao-math("{\\left|\\{ n \\leq N: n, N-n \\in {\\mathcal P} \\}\\right|}", block: false)#text(", ")#tao-math("{\\left|\\{ p \\in {\\mathcal P}: N^2 < p < (N+1)^2 \\}\\right|}", block: false)#text(", or ")#tao-math("{\\left|\\{ n \\leq x: n^2 + 1 \\in {\\mathcal P} \\}\\right|}", block: false)#text(", which are the natural counts associated to the other three Landau problems. In all four of Landau’s problems, the basic task is now to obtain a non-trivial lower bounds on these counts.")],
[#text("If one wishes to proceed analytically rather than combinatorially, one should convert all these counts into sums, using the fundamental identity")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| = \\sum_n 1_A(n),", block: true)]]

#text("(or variants thereof) for the cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" of subsets ")#mi("{A}")#text(" of the natural numbers ")#mi("{{\\bf N}}")#text(", where ")#mi("{1_A}")#text(" is the indicator function of ")#mi("{A}")#text(" (and ")#mi("{n}")#text(" ranges over ")#mi("{{\\bf N}}")#text("). Thus we are now interested in estimating (and particularly in lower bounding) sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} 1_{{\\mathcal P}}(n) 1_{{\\mathcal P}}(N-n),")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1_{{\\mathcal P}}(n) 1_{{\\mathcal P}}(n+2),")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{N^2 < n < (N+1)^2} 1_{{\\mathcal P}}(n),")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1_{{\\mathcal P}}(n^2+1).")]]],
[#text("Once one expresses number-theoretic problems in this fashion, we are naturally led to the more general question of how to accurately estimate (or, less ambitiously, to lower bound or upper bound) sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n)")]]

#text("or more generally bilinear or multilinear sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\sum_m f(n,m)")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1,\\dots,n_k} f(n_1,\\dots,n_k)")]]

#text("for various functions ")#mi("{f}")#text(" of arithmetic interest. (Importantly, one should also generalise to include integrals as well as sums, particularly contour integrals or integrals over the unit circle or real line, but we postpone discussion of these generalisations to later in the course.) Indeed, a huge portion of modern analytic number theory is devoted to precisely this sort of question. In many cases, we can predict an ")#emph[#text("expected main term")]#text(" for such sums, and then the task is to control the ")#emph[#text("error term")]#text(" between the true sum and its expected main term. It is often convenient to normalise the expected main term to be zero or negligible (e.g. by subtracting a suitable constant from ")#mi("{f}")#text("), so that one is now trying to show that a sum of signed real numbers (or perhaps complex numbers) is small. In other words, the question becomes one of rigorously establishing a significant amount of ")#emph[#text("cancellation")]#text(" in one’s sums (also referred to as a ")#emph[#text("gain")]#text(" or ")#emph[#text("savings")]#text(" over a benchmark “trivial bound”). Or to phrase it negatively, the task is to rigorously prevent a ")#emph[#text("conspiracy")]#text(" of non-cancellation, caused for instance by two factors in the summand ")#mi("{f(n)}")#text(" exhibiting an unexpectedly large correlation with each other.")],
[#text("It is often difficult to discern cancellation (or to prevent conspiracy) directly for a given sum (such as ")#mi("{\\sum_n f(n)}")#text(") of interest. However, analytic number theory has developed a large number of techniques to relate one sum to another, and then the strategy is to keep transforming the sum into more and more analytically tractable expressions, until one arrives at a sum for which cancellation can be directly exhibited. (Note though that there is often a short-term tradeoff between analytic tractability and algebraic simplicity; in a typical analytic number theory argument, the sums will get expanded and decomposed into many quite messy-looking sub-sums, until at some point one applies some crude estimation to replace these messy sub-sums by tractable ones again.) There are many transformations available, ranging such basic tools as the triangle inequality, pointwise domination, or the Cauchy-Schwarz inequality to key identities such as multiplicative number theory identities (such as the ")#link("http://en.wikipedia.org/wiki/Vaughan's_identity")[#text("Vaughan identity")]#text(" and the Heath-Brown identity), Fourier-analytic identities (e.g. ")#link("http://en.wikipedia.org/wiki/Fourier_inversion_theorem")[#text("Fourier inversion")]#text(", ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation")]#text(", or more advanced trace formulae), or complex analytic identities (e.g. the ")#link("http://en.wikipedia.org/wiki/Residue_theorem")[#text("residue theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron’s formula")]#text(", or ")#link("http://en.wikipedia.org/wiki/Jensen%27s_formula")[#text("Jensen’s formula")]#text("). The sheer range of transformations available can be intimidating at first; there is no shortage of transformations and identities in this subject, and if one applies them randomly then one will typically just transform a difficult sum into an even more difficult and intractable expression. However, one can make progress if one is guided by the strategy of isolating and enhancing a desired cancellation (or conspiracy) to the point where it can be easily established (or dispelled), or alternatively to reach the point where no deep cancellation is needed for the application at hand (or equivalently, that no deep conspiracy can disrupt the application).")],
[#text("One particularly powerful technique (albeit one which, ironically, can be highly “ineffective” in a certain technical sense to be discussed later) is to use one potential conspiracy to defeat another, a technique ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("I refer to as the “dueling conspiracies” method")]#text(". This technique may be unable to prevent a single strong conspiracy, but it can sometimes be used to prevent ")#emph[#text("two or more")]#text(" such conspiracies from occurring, which is particularly useful if conspiracies come in pairs (e.g. through complex conjugation symmetry, or a functional equation). A related (but more “effective”) strategy is to try to “disperse” a single conspiracy into several distinct conspiracies, which can then be used to defeat each other.")]
)

#text("As stated before, the above strategy has not been able to establish any of the four Landau problems as stated. However, they can come close to such problems (and we now have some understanding as to why these problems remain out of reach of current methods). For instance, by using these techniques (and a lot of additional effort) one can obtain the following sample partial results in the Landau problems:")

#enum(start: 1, 
[#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("Chen’s theorem")]#text(": every sufficiently large even number ")#mi("{N}")#text(" is expressible as the sum of a prime and an ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost prime")]#text(" (the product of at most two primes). The proof proceeds by finding a nontrivial lower bound on ")#mi("{\\sum_{n \\leq N} 1_{\\mathcal P}(n) 1_{{\\mathcal E}_2}(N-n)}")#text(", where ")#mi("{{\\mathcal E}_2}")#text(" is the set of almost primes.")],
[#link("http://annals.math.princeton.edu/2014/179-3/p07")[#text("Zhang’s theorem")]#text(": There exist infinitely many pairs ")#mi("{p_n, p_{n+1}}")#text(" of consecutive primes with ")#mi("{p_{n+1} - p_n \\leq 7 \\times 10^7}")#text(". The proof proceeds by giving a non-negative lower bound on the quantity ")#mi("{\\sum_{x \\leq n \\leq 2x} (\\sum_{i=1}^k 1_{\\mathcal P}(n+h_i) - 1)}")#text(" for large ")#mi("{x}")#text(" and certain distinct integers ")#mi("{h_1,\\dots,h_k}")#text(" between ")#mi("{0}")#text(" and ")#mi("{7 \\times 10^7}")#text(". (The bound ")#mi("{7 \\times 10^7}")#text(" has ")#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")[#text("since been lowered")]#text(" to ")#mi("{246}")#text(".)")],
[#link("http://www.ams.org/mathscinet-getitem?mr=1851081")[#text("The Baker-Harman-Pintz theorem")]#text(": for sufficiently large ")#mi("{x}")#text(", there is a prime between ")#mi("{x}")#text(" and ")#mi("{x + x^{0.525}}")#text(". Proven by finding a nontrivial lower bound on ")#mi("{\\sum_{x \\leq n \\leq x+x^{0.525}} 1_{\\mathcal P}(n)}")#text(".")],
[#link("http://en.wikipedia.org/wiki/Friedlander%E2%80%93Iwaniec_theorem")[#text("The Friedlander-Iwaniec theorem")]#text(": There are infinitely many primes of the form ")#mi("{n^2+m^4}")#text(". Proven by finding a nontrivial lower bound on ")#mi("{\\sum_{n,m: n^2+m^4 \\leq x} 1_{{\\mathcal P}}(n^2+m^4)}")#text(".")]
)

#text("We will discuss (simpler versions of) several of these results in this course.")

#text("Of course, for the above general strategy to have any chance of succeeding, one must at some point use ")#emph[#text("some")]#text(" information about the set ")#mi("{{\\mathcal P}}")#text(" of primes. As stated previously, usefully structured parametric descriptions of ")#mi("{{\\mathcal P}}")#text(" do not appear to be available. However, we do have two other fundamental and useful ways to describe ")#mi("{{\\mathcal P}}")#text(":")

#enum(start: 1, 
[#text("(Sieve theory description) The primes ")#mi("{{\\mathcal P}}")#text(" consist of those numbers greater than one, that are not divisible by any smaller prime.")],
[#text("(Multiplicative number theory description) The primes ")#mi("{{\\mathcal P}}")#text(" are the multiplicative generators of the natural numbers ")#mi("{{\\bf N}}")#text(": every natural number is uniquely factorisable (up to permutation) into the product of primes (the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(").")]
)

#text("The sieve-theoretic description and its variants lead one to a good understanding of the ")#emph[#text("almost primes")]#text(", which turn out to be excellent tools for controlling the primes themselves, although there are known limitations as to how much information on the primes one can extract from sieve-theoretic methods alone, which we will discuss later in this course. The multiplicative number theory methods lead one (after some complex or Fourier analysis) to the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" (and other L-functions, particularly the ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#text("Dirichlet L-functions")]#text("), with the distribution of zeroes (and poles) of these functions playing a particularly decisive role in the multiplicative methods.")

#text("Many of our strongest results in analytic prime number theory are ultimately obtained by incorporating some combination of the above two fundamental descriptions of ")#mi("{{\\mathcal P}}")#text(" (or variants thereof) into the general strategy described above. In contrast, more advanced descriptions of ")#mi("{{\\mathcal P}}")#text(", such as those coming from the various ")#link("http://en.wikipedia.org/wiki/Primality_test")[#text("primality tests")]#text(" available, have (until now, at least) been surprisingly ineffective in practice for attacking problems such as Landau’s problems. One reason for this is that such tests generally involve operations such as exponentiation ")#mi("{a \\mapsto a^n}")#text(" or the factorial function ")#mi("{n \\mapsto n!}")#text(", which grow too quickly to be amenable to the analytic techniques discussed above.")

#text("To give a simple illustration of these two basic approaches to the primes, let us first give two variants of the usual proof of ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Euclid’s theorem)")]#text(" ")#metadata(none) <tao-d54f5fedac0862695c43>#text(" There are infinitely many primes.")
]

#emph[#text("Proof:")]#text(" (Multiplicative number theory proof) Suppose for contradiction that there were only finitely many primes ")#mi("{p_1,\\dots,p_n}")#text(". Then, by the fundamental theorem of arithmetic, every natural number is expressible as the product of the primes ")#mi("{p_1,\\dots,p_n}")#text(". But the natural number ")#mi("{p_1 \\dots p_n + 1}")#text(" is larger than one, but not divisible by any of the primes ")#mi("{p_1,\\dots,p_n}")#text(", a contradiction.")

#text("(Sieve-theoretic proof) Suppose for contradiction that there were only finitely many primes ")#mi("{p_1,\\dots,p_n}")#text(". Then, by the Chinese remainder theorem, the set of natural numbers ")#mi("{A}")#text(" that is not divisible by any of the ")#mi("{p_1,\\dots,p_n}")#text(" has density ")#mi("{\\prod_{i=1}^n (1-\\frac{1}{p_i})}")#text(", that is to say")

#align(center)[#tao-fit-display[#tao-math("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\left| A \\cap \\{1,\\dots,N\\} \\right| = \\prod_{i=1}^n (1-\\frac{1}{p_i}).", block: true)]]

#text("In particular, ")#mi("{A}")#text(" has positive density and thus contains an element larger than ")#mi("{1}")#text(". But the least such element is one further prime in addition to ")#mi("{p_1,\\dots,p_n}")#text(", a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also phrase the proof of Euclid’s theorem in a fashion that largely avoids the use of contradiction; see ")#link("https://terrytao.wordpress.com/2010/10/18/the-no-self-defeating-object-argument-revisited/")[#text("this previous blog post")]#text(" for more discussion.")
]

#text("Both proofs in fact extend to give a stronger result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Euler’s theorem)")]#text(" ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>#text(" The sum ")#mi("{\\sum_{p \\in {\\mathcal P}} \\frac{1}{p}}")#text(" is divergent.")
]

#emph[#text("Proof:")]#text(" (Multiplicative number theory proof) By the fundamental theorem of arithmetic, every natural number is expressible uniquely as the product ")#mi("{p_1^{a_1} \\dots p_n^{a_n}}")#text(" of primes in increasing order. In particular, we have the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n} = \\prod_{p \\in {\\mathcal P}} ( 1 + \\frac{1}{p} + \\frac{1}{p^2} + \\dots )")]]

#text("(both sides make sense in ")#mi("{[0,+\\infty]}")#text(" as everything is unsigned). Since the left-hand side is divergent, the right-hand side is as well. But")

#align(center)[#tao-fit-display[#mitex("( 1 + \\frac{1}{p} + \\frac{1}{p^2} + \\dots ) = \\exp( \\frac{1}{p} + O( \\frac{1}{p^2} ) )")]]

#text("and ")#mi("{\\sum_{p \\in {\\mathcal P}} \\frac{1}{p^2}\\leq \\sum_{n=1}^\\infty \\frac{1}{n^2} < \\infty}")#text(", so ")#mi("{\\sum_{p \\in {\\mathcal P}} \\frac{1}{p}}")#text(" must be divergent.")

#text("(Sieve-theoretic proof) Suppose for contradiction that the sum ")#mi("{\\sum_{p \\in {\\mathcal P}} \\frac{1}{p}}")#text(" is convergent. For each natural number ")#mi("{k}")#text(", let ")#mi("{A_k}")#text(" be the set of natural numbers not divisible by the first ")#mi("{k}")#text(" primes ")#mi("{p_1,\\dots,p_k}")#text(", and let ")#mi("{A}")#text(" be the set of numbers not divisible by any prime in ")#mi("{{\\mathcal P}}")#text(". As in the previous proof, each ")#mi("{A_k}")#text(" has density ")#mi("{\\prod_{i=1}^k (1-\\frac{1}{p_i})}")#text(". Also, since ")#mi("{\\{1,\\dots,N\\}}")#text(" contains at most ")#mi("{\\frac{N}{p}}")#text(" multiples of ")#mi("{p}")#text(", we have from the union bound that")

#align(center)[#tao-fit-display[#tao-math("\\left| A \\cap \\{1,\\dots,N \\}\\right| = \\left|A_k \\cap \\{1,\\dots,N\\}\\right| - O( N \\sum_{i > k} \\frac{1}{p_i} ).", block: true)]]

#text("Since ")#mi("{\\sum_{i=1}^\\infty \\frac{1}{p_i}}")#text(" is assumed to be convergent, we conclude that the density of ")#mi("{A_k}")#text(" converges to the density of ")#mi("{A}")#text("; thus ")#mi("{A}")#text(" has density ")#mi("{\\prod_{i=1}^\\infty (1-\\frac{1}{p_i})}")#text(", which is non-zero by the hypothesis that ")#mi("{\\sum_{i=1}^\\infty \\frac{1}{p_i}}")#text(" converges. On the other hand, since the primes are the only numbers greater than one not divisible by smaller primes, ")#mi("{A}")#text(" is just ")#mi("{\\{1\\}}")#text(", which has density zero, giving the desired contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" ")#metadata(none) <tao-00b64810555cb5d5e027>#text(" We have seen how easy it is to prove Euler’s theorem by analytic methods. In contrast, there does not seem to be any known proof of this theorem that proceeds by using any sort of prime-generating formula or a primality test, which is further evidence that such tools are not the most effective way to make progress on problems such as Landau’s problems. (But the weaker theorem of Euclid, Theorem ")#link(<tao-d54f5fedac0862695c43>)[#text("1")]#text(", can sometimes be proven by such devices.)")
]

#text("The two proofs of Theorem ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("2")]#text(" given above are essentially the same proof, as is hinted at by the geometric series identity")

#align(center)[#tao-fit-display[#mitex("1 + \\frac{1}{p} + \\frac{1}{p^2} + \\dots = (1 - \\frac{1}{p})^{-1}.")]]

#text("One can also see the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" begin to make an appearance in both proofs. Once one goes beyond Euler’s theorem, though, the sieve-theoretic and multiplicative methods begin to diverge significantly. On one hand, sieve theory can still handle to some extent sets such as twin primes, despite the lack of multiplicative structure (one simply has to sieve out two residue classes per prime, rather than one); on the other, multiplicative number theory can attain results such as the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" for which purely sieve theoretic techniques have not been able to establish. The deepest results in analytic number theory will typically require a combination of both sieve-theoretic methods and multiplicative methods in conjunction with the many transforms discussed earlier (and, in many cases, additional inputs from other fields of mathematics such as arithmetic geometry, ergodic theory, or additive combinatorics).")

#metadata(none) <tao-ddf7f43e64f8a5020a17>

#heading(level: 1)[#strong[#text(" — 1. Topics covered — ")]]

#text("Analytic prime number theory is a vast subject (the 615-page ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("text of Iwaniec and Kowalski")]#text(", for instance, gives a good indication as to its scope). I will therefore have to be somewhat selective in deciding what subset of this field to cover. I have chosen the following “core” topics to focus on:")

#list(
[#text("Elementary multiplicative number theory.")],
[#text("Heuristic random models for the primes.")],
[#text("The basic theory of the Riemann zeta function and Dirichlet L-functions, and their relationship with the primes.")],
[#text("Zero-free regions for the zeta function and the Dirichet L-function, including Siegel’s theorem.")],
[#text("The prime number theorem, the Siegel-Walfisz theorem, and the Bombieri-Vinogradov theorem.")],
[#text("Sieve theory, small and large gaps between the primes, and the parity problem.")],
[#text("Exponential sum estimates over the integers, and the Vinogradov-Korobov zero-free region.")],
[#text("Zero density estimates, Hohiesel’s theorem, and Linnik’s theorem.")],
[#text("Exponential sum estimates over finite fields, and improved distribution estimates for the primes.")],
[#text("(If time permits) Exponential sum estimates over the primes, the circle method, and Vinogradov’s three-primes theorem.")]
)

#text("In order to cover all this material, I will focus on more qualitative results, as opposed to the strongest quantitative results, in particular I will not attempt to optimise many of the numerical constants and exponents appearing in various estimates. This also allows me to downplay the role of some key components of the field which are not essential for establishing the core results of this course at such a qualitative level:")

#list(
[#text("I will minimise the use of algebraic number theory tools (such as the class number formula).")],
[#text("I will avoid deploying the functional equation (or related identities, such as Poisson summation) if they are unnecessary at a qualitative level (though I will note when the functional equation can be used to improve the quantitative results). As it turns out, ")#emph[#text("all")]#text(" of the core results mentioned above can in fact be derived without ever invoking the functional equation, although one usually gets poorer numerical exponents as a consequence.")],
[#text("Somewhat related to this, I will reduce the reliance on complex analytic methods as compared to more traditional presentations of the material, relying in some places instead on Fourier-analytic substitutes, or on results about harmonic functions. (But I will not go as far as deploying the primarily real-variable “pretentious” approach to analytic number theory currently in development by Granville and Soundararajan, although my approach here does align in spirit with that approach.)")],
[#text("The discussion on sieve methods will be somewhat abridged, focusing primarily on the Selberg sieve, which is a good general-purpose sieve for qualitative applications at least.")],
[#text("I will almost certainly avoid any discussion of automorphic forms methods.")],
[#text("Similarly, I will not cover methods that rely on additive combinatorics or ergodic theory.")]
)

#text("Of course, many of these additional topics are well covered in existing textbooks, such as the above-mentioned text of Iwaniec and Kowalski (or, for the finer points of sieve theory, the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("text of Friedlander and Iwaniec")]#text("). Other good texts that can be used for supplementary reading are Davenport’s “")#link("http://www.ams.org/mathscinet-getitem?mr=1790423")[#text("Multiplicative number theory")]#text("” and Montgomery-Vaughan’s “")#link("http://www.ams.org/mathscinet-getitem?mr=2378655")[#text("Multiplicative number theory I")]#text(".”. As for prerequisites: some exposure to complex analysis, Fourier analysis, and real analysis will be particularly helpful, although we will review some of this material as needed (particularly with regard to complex analysis and the theory of harmonic functions). Experience with other quantitative areas of mathematics in which lower bounds, upper bounds, and other forms of estimation are emphasised (e.g. asymptotic combinatorics or theoretical computer science) will also be useful. Knowledge of algebraic number theory or arithmetic geometry will add a valuable additional perspective to the course, but will not be necessary to follow most of the material.")

#heading(level: 1)[#strong[#text(" — 2. Notation — ")]]

#text("In this course, all sums will be understood to be over the natural numbers unless otherwise specified, with the exception of sums over the variable ")#mi("{p}")#text(" (or variants such as ")#mi("{p_1}")#text(", ")#mi("{p_2}")#text(", etc.), which will be understood to be over primes.")

#text("We will use asymptotic notation in two contexts, one in which there is no asymptotic parameter present, and one in which there is an asymptotic parameter (such as ")#mi("{x}")#text(") that is going to infinity. In the non-asymptotic setting (which is the default context if no asymptotic parameter is explicitly specified), we use ")#mi("{X = O(Y)}")#text(", ")#mi("{X \\ll Y}")#text(", or ")#mi("{Y \\gg X}")#text(" to denote an estimate of the form ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(", where ")#mi("{C}")#text(" is an absolute constant. ")#text("We also use ")#mi("{X \\asymp Y}")#text(" as shorthand for ")#mi("{X \\ll Y \\ll X}")#text(".")#text(" In some cases we would like the implied constant ")#mi("{C}")#text(" to depend on some additional parameters such as ")#mi("{k}")#text(", in which case we will denote this by subscripts, for instance ")#mi("{X = O_k(Y)}")#text(" denotes the claim that ")#tao-math("{\\left|X\\right| \\leq C_k Y}", block: false)#text(" for some ")#mi("{C_k}")#text(" depending on ")#mi("{k}")#text(".")

#text("In some cases it will instead be convenient to work in an asymptotic setting, in which there is an explicitly designated asymptotic parameter (such as ")#mi("{x}")#text(") going to infinity. In that case, all mathematical objects will be permitted to depend on this asymptotic parameter, unless they are explicitly referred to as being ")#emph[#text("fixed")]#text(". We then use ")#mi("{X = O(Y)}")#text(", ")#mi("{X \\ll Y}")#text(", or ")#mi("{Y \\gg X}")#text(" to denote the claim that ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some fixed ")#mi("{C}")#text(". Note that in slight contrast to the non-asymptotic setting, the implied constant ")#mi("{C}")#text(" here is allowed to depend on other parameters, so long as these parameters are also fixed. As such, the asymptotic setting can be a convenient way to manage dependencies of various implied constants on parameters. In the asymptotic setting we also use ")#mi("{X = o(Y)}")#text(" to denote the claim that ")#tao-math("{\\left|X\\right| \\leq c Y}", block: false)#text(", where ")#mi("{c}")#text(" is a quantity which goes to zero as the asymptotic parameter goes to infinity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In later posts we will make a distinction between implied constants ")#mi("{C}")#text(" that are ")#emph[#text("effective")]#text(" (they can be computed, at least in principle, by some explicit method) and those at are ")#emph[#text("ineffective")]#text(" (they can be proven to be finite, but there is no algorithm known to compute them in finite time).")
]

#text("We use ")#mi("{d|n}")#text(" to denote the assertion that ")#mi("{d}")#text(" divides ")#mi("{n}")#text(", and ")#mi("{a\\ (q)}")#text(" to denote the residue class of ")#mi("{a}")#text(" modulo ")#mi("{q}")#text(".")

#text("We use ")#mi("{1_E}")#text(" to denote the indicator function of a set ")#mi("{E}")#text(", thus ")#mi("{1_E(x) = 1}")#text(" when ")#mi("{x \\in E}")#text(" and ")#mi("{1_E(x) = 0}")#text(" otherwise. Similarly, for any mathematical statement ")#mi("{S}")#text(", we use ")#mi("{1_S}")#text(" to denote the value ")#mi("{1}")#text(" when ")#mi("{S}")#text(" is true and ")#mi("{0}")#text(" when ")#mi("{S}")#text(" is false. Thus for instance ")#mi("{1_{2|n} = 1_{n\\ (2) = 0}}")#text(" is the indicator function of the even numbers.")

#text("We use ")#tao-math("{\\left|E\\right|}", block: false)#text(" to denote the cardinality of a set ")#mi("{E}")#text(".")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c05773c06e8d326ea09565dd0eba4d8747ffb99c909113eb6b7b2bdaf5beb4a-7287cd1e65a5ce8ebc244840d39e26af8cf1dfcc1eb19fda292494b44278645e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kumar Ashok")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438571")[#strong[#text("Kumar Ashok")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2014")])]

#text("Thank you for giving me opportunity for the most precious comment!")#linebreak()#text(" Since 1901 in second week September every year all Mathematicians feel embarrassed and slapped not to nominated for Nobel Prize.Why?Not the story of love floated for A.Nobel.But for the reason ” Mathematician do not do the mathematics that suit mankind but do that suit to them. Most of them do not recognize good work for others, so it would be difficult to select the best” Today many problems are remain even after some people have solved them , but after due to not to co-operate nature of most of mathematicians and rubbish policies of Journals most of the problems are unsolved even after getting solved.These mathematician are printing rubbish subject material a burden to coming generation without any application to mankind. Mathematician need to think many times if they are working foe mankind or for self.Differentiation between then is difficult as they all are identical so they themselves recognize work among them.")#linebreak()#text(" You all have accepted 100+ page solution of FermateTheorem (real sol is 7-8 page),Goldbach problem is solved (sol- 10-12 page),Twin prime Problem is slved (sol 10+ page),Riemann problem is solved (sol 8-10 page).aaaaa……nnnn…..ddddd many more.")

#text("BUT NO NEUTRAL JOURNAL IS FOUND THIS IS MOST TEDIOUS AND DIFFICULT PROBLEM TO BE SOLVED.")#linebreak()#text(" First mathematicians have to solve this problem other will get solved immediately.")

#text("Thanks to every one who read and act to this problem")#linebreak()#text(" Kumar Ashok")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81cc45fb6e0c7e3445264f684b4c9c4746d708fdf5d991cba3f00ffcd4c21be0-4df9ceeeec4092d8fc4eff1bf2c916cb9d4e3093ddb56e3630a970cf9f8f7061.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chandan Sinha")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439695")[#strong[#text("Chandan Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("Your comment was quite insightful sir and it really states the problems with mathematicians to considerable extent but you should also take into account the applicability of advancement. Though the role of today’s mathematical development for the welfare of humanity is not apparent but it does affect in inconspicuous ways for the betterment. Also we should see that the researches have been done since almost the beginning of civilization and it has come too far. Let’s say- Integration- it is part of mathematics and would be considered as invented by mathematician itself ( Newton or Leibnitz whomever you consider) but its finds its application as a tool in almost every area which enhances the living standard. Though it was the contributing subject but so does everything else for which Nobel prize is given. The combination of all these brings the applicable result- hope you get my point! Anyway it is said that Mathematics is the queen of science and it too would have a role in running the whole empire :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438592")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2014")])]

#text("“Remark 2 We have seen how easy it is to prove Euler’s theorem” read “Remark 2 We have seen how easy it is to prove Euclid’s theorem”")

#emph[#text("[Actually, my intent here is indeed to highlight the ease of proof of Euler’s theorem if one uses analytic techniques. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438637")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2014")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2014/11/14/254a-announcement-analytic-prime-number-theory/")[#text("Singapore Maths Tuition")]#text(" and commented:")#linebreak()#text(" Bookmark Terence Tao’s site if you are interested in his notes on Analytic number theory! He will be placing lecture notes online on his blog.")#linebreak()#text(" This is a one-in-a-lifetime chance to learn Analytic Number Theory from a Master — Fields’ Medallist Terrence Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1@gmail.com")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438838")[#strong[#text("arch1@gmail.com")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("The referenced “Landau’s Problems” Wikipedia article reports only partial progress on Goldbach’s weak (3-primes) conjecture, while the “Goldbach’s weak conjecture” article reports a 2013 solution. Perhaps one of you who knows the real story can fix.")#linebreak()#text(" PS. At least the 1st article spells “D. H. J. Polymath” correctly:-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438889")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("1) Holy moly. *Thanks* for these lecture notes.")#linebreak()#text(" 2) “…using some combination…into the general strategy…”: using -> incorporating")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438890")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text(":star: :star: :star: once again big congratulations on your $3M breakthru prize and appearing on colbert! so your blog overflows with dense impersonal math, but it would be very interesting to hear your opinion of the awards, am sure many would like/ appreciate it, a personal reaction to the ceremony, etc. eg did you get to flirt with cameron diaz or kate beckinsdale at all lol :p … as a model consider Gowers coverage of the IMU2014 meeting in korea in his blog. alas, thinking you are not gonna go for it, so as a vastly inferior substitute for your readers, see eg more coverage/ commentary etc at this link, ")#link("http://vzn1.wordpress.com/2014/11/14/star-studded-cash-overflowing-2015-breakthru-prizes/")[#text("star studded, cash overflowing 2015 breakthru awards")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-438992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("Are there any references for the real-variable approach taken by Granville and Soundararajan?")

#emph[#text("[There is a book in preparation, until then one has to go to the original articles, such as ")#link("http://arxiv.org/abs/math/0503113")[#text("http://arxiv.org/abs/math/0503113")]#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439013")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("Naive Q: Is it really the case that the proof of Chen’s theorem proceeds by lower-bounding the very same sum that one seeks to lower-bound when attacking the Goldbach conjecture itself? Or in the description of Chen’s theorem, should one of the indicator functions in the sum indicate almost-primality rather than primality?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439356")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2014")])]

#text("Terry, the ref you cite (and the Mathworld article *it* cites) say that P2 is the set of “2-almost-primes” (exactly 2 prime factors, counting multiplicity). Should the P2 subscript instead be P union P2?")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439103")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("There’s an extra ‘(‘ in the last sentence of the second paragraph up from Theorem 1: “with the distribution of zeroes (and poles of these functions playing a particularly decisive role in the multiplicative methods.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be2af8833324863183e543625d6a9b6998ae7008e76ca10cd948348fb9953896-e264b72abced211c5147c522add4690016dbdb930def2b404d11fe0e31ab07b2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zr9558")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439133")[#strong[#text("zr9558")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("Reblogged this on ")#link("http://zr9558.com/2014/11/15/254a-announcement-analytic-prime-number-theory/")[#text("ZHANG RONG")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439285")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2014")])]

#text("I am still busy reading your other Math 254A")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65a567cfaee619fadc5fd274b531ad8d012261fcb845054f8fdaa76d287d8b26-ab8148b28f54fc2b9876d75dd504ff880b5617486fcff0aafc69df2f5a178e49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Lesley")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439623")[#strong[#text("Frank Lesley")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("Perri:")

#text("This looks like a rare opportunity- an on-line course on this topic, given by a real master. IComing to a computer near you in January.")

#text("David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("This seems like a fantastic course, I wish I could take it. Best of luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81cc45fb6e0c7e3445264f684b4c9c4746d708fdf5d991cba3f00ffcd4c21be0-4df9ceeeec4092d8fc4eff1bf2c916cb9d4e3093ddb56e3630a970cf9f8f7061.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chandan Sinha")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439696")[#strong[#text("Chandan Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("Will you be posting the video lectures also on any site?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81cc45fb6e0c7e3445264f684b4c9c4746d708fdf5d991cba3f00ffcd4c21be0-4df9ceeeec4092d8fc4eff1bf2c916cb9d4e3093ddb56e3630a970cf9f8f7061.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chandan Sinha")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-439698")[#strong[#text("Chandan Sinha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("Reblogged this on ")#link("http://thevindicatedaxiom.wordpress.com/2014/11/17/254a-announcement-analytic-prime-number-theory/")[#text("Divine_Lifez")]#text(" and commented:")#linebreak()#text(" Mathematics!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-da00f5df9074c7a9ca83e3b7a167c9561c673b268bc0b4dc81cee368d508d8ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Ross")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-442469")[#strong[#text("Mike Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("I sort of followed the interesting article concerning Landau’s Problems. The one most obvious thing that was not said about them is they are all related to perfect squares. The third and fourth – Legendre’s conjecture and Are there infinitely many primes p such that p-1 is a perfect square? – are overtly so. The second is the Twin Prime, and the connection here is that the product of p and p+2 is (X^2)-1. (That leaves Goldbach’s conjecture, where the connection requires looking at the products of the partitions in relation to perfect squares.) That the twin primes are always the factors of (x^2)-1, actually x-1 and x+1, shows a very precise geometric relationship with square numbers that I think is easy to overlook. Reversing the logic and considering composites first and their prime factors second can bring unexpected clarity to these four problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-442553")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("This shows that the twin prime conjecture is equivalent to the conjecture that there are infinitely many semiprimes of the form ")#mi("n^2 -1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-da00f5df9074c7a9ca83e3b7a167c9561c673b268bc0b4dc81cee368d508d8ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Ross")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-443627")[#strong[#text("Mike Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2014")])]

#text("An interesting property of even perfect squares minus 1 is the triviality of their smallest prime factor unless they are twin-prime composites. This makes it extremely fast to factor them and easy to determine the instances of twin primes (simply by elimination). The rule is that the smallest prime factor of a non-twin-prime X^2-1 composite cannot be greater than the square root of its square root – and usually much smaller. If such a factor is not found, the composite must be the product of twin primes. Thus the largest of these non-twin-prime factors less than 1 million is 991 for 999836006723.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a5bf2909be12faa52dd4b82376fb2610dce9e3ee7ca10c6d03b906735a047f-290496ff71750a3104d2dc8de4d77d81259cfe7b67d3f458c33238b93934c7c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Enrique Treviño")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-443155")[#strong[#text("Enrique Treviño")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2014")])]

#text("I enjoyed reading this entry. Looking forward to following along the rest of these lecture notes.")

#text("I found two typos:")#linebreak()#text(" 1) “One of course create…” is missing “can”.")#linebreak()#text(" 2) “A has positive density and is thus contains….” has an extra “is”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-444305")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2014")])]

#text("Reblogged this on ")#link("http://tomcircle.wordpress.com/2014/12/08/254a-announcement-analytic-prime-number-theory/")[#text("Math Online Tom Circle")]#text(" and commented:")#linebreak()#text(" This is excellent lecture notes. Thanks Prof. Terence Tao. 谢谢!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-448663")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("What do you mean here? “There does not seem to be any known proof of this theorem that proceeds by using any sort of prime-generating formula or a primality test.” I think the first proof is from around 1300 or 1400. Which makes me think we are not communicating well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-449124")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2015")])]

#text("In the Sieve-theoretic proof of Theorem 2, should the sentence instead read “As in the previous proof, each ")#mi("A_{n}")#text(" has density ")#mi("\\prod_{i = 1}^{n}(1 - \\frac{1}{p_{i}})")#text("” as opposed to ")#mi("\\prod_{i = 1}^{n}(1 - \\frac{1}{p})")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-479229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2017")])]

#text("How can I print this? Is there any book form?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-509536")[#strong[#text("Chebyshev’s Almost Prime Number Theorem – Write down what you’ve learned")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")]

#text("[…] ")#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-521314")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("[…] 27) I will be teaching a graduate course on analytic prime number theory. This will be similar to a graduate course I taught in 2015, and in particular will reuse several of the lecture notes from that course, though it will also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-539909")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2020")])]

#text("Dear Terence Tao, I hope you plan to publish your notes on analytic prime number theory. I feel these are some of your deepest expository contributions. You already had notes which did not arrive to book form. Was it because you felt unsatisfied? Because the material was fluctuating too much then? Do you feel now the time is riper?")

#text("Thank you,")#linebreak()#text(" Paul")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/704b81e58ca29743b47850bb62f82d988587af8aa950d2d86ccec5d2d2505f3a-ae78c7c51eb8b92e65e74b0790dfb510525c2923707a533c2fcc07a150e39602.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of plm")]], [#link("https://terrytao.wordpress.com/2014/11/13/254a-announcement-analytic-prime-number-theory/#comment-539910")[#strong[#text("plm")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2020")])]

#text("I meant to write this comment in your 2019 course annoucement.")
]
]
