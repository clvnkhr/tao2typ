// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/
// Converted to Typst by tao2typ: "2026-10-14T10:51:28.670979+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Submissions for the Breakthrough Junior Challenge now open", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Submissions for the Breakthrough Junior Challenge now open")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 May 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/")[#text("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short note to point out that submissions to the ")#link("https://breakthroughjuniorchallenge.org/")[#text("2019 Breakthrough Junior Challenge")]#text(" are now open until June 15. Students ages 13 to 18 from countries across the globe are invited to create and submit original videos (3:00 minutes in length maximum) that bring to life a concept or theory in the life sciences, physics or mathematics. The submissions are judged on the student’s ability to communicate complex scientific ideas in engaging, illuminating, and imaginative ways. The Challenge is organized by the Breakthrough Prize Foundation, in partnership with Khan Academy, National Geographic, and Cold Spring Harbor Laboratory. The winner of the challenge recieves a $250K college scholarship, with an addition $50K prize to the winner’s maths or science teacher, and a $100K lab for the student’s school. (This year I will be on the ")#link("https://breakthroughjuniorchallenge.org/judging/selection_committee")[#text("selection committee")]#text(" for this challenge.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb6185451c5bc63a83e94a1fe6a6cb61c4d4f643497af737916f8913653a49be-bfea5452ee4f6b95ca700c08f8da8d82b6907f5531a87afd074823c786f35e77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Davis")]], [#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/#comment-515845")[#strong[#text("David Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Great project for a teenager.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony")]], [#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/#comment-515850")[#strong[#text("Anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Spreading the $400K prize money over the best three or four, rather than all for the winning entry, might have been more effective in boosting science teaching.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a8c33efa417193a53d723b2541931133c98973ba073d4b443d5e268834e182a-fe9b6ef01e00eb1d3dca49aef807c6d5d5444f92e0050d4b8e374e31289bc680.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SATYABRATA DAS")]], [#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/#comment-515857")[#strong[#text("SATYABRATA DAS")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2019")])]

#text("Sir, I was born in 2001 on 04/05/2001. Can I submit for Breakthrough junior challenge?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/#comment-515866")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2019")])]

#text("Yes. The rules state: “You must be 13 years of age by May 15 at 12:01 AM Pacific Daylight Time (”PDT”) to participate in the Challenge, and You cannot be older than 18 years of age (not yet 19) on October 1, 2019 at 11:59 PM PDT.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3842868384da81254f483a55b3dca8f86efde15487dfd3cc95cbfa6de1cda82c-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arsene1412")]], [#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/#comment-515904")[#strong[#text("Arsene1412")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2019")])]

#text("Thanks for sharing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b21eb0be24282330bdf659eefddfe379c69a267a996878398bd440133c97d208-742ce55e7cec738789c50abe7079d2f598337d03f530fcd0da65615173da9eab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed A. Sesay")]], [#link("https://terrytao.wordpress.com/2019/05/06/submissions-for-the-breakthrough-junior-challenge-now-open/#comment-517202")[#strong[#text("Mohammed A. Sesay")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("Hello, I am very excited to participate in this year’s breakthrough junior challenge. I am a Liberian and currently 18 years and will soon be 19 by October 28. Am I eligible to submit my application?")
]
