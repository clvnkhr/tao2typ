// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/
// Converted to Typst by tao2typ: "2026-10-14T11:14:37.906843+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Smooth numbers and max-entropy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Smooth numbers and max-entropy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 September 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/")[#text("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a threshold ")#mi("{y>1}")#text(", a ")#link("https://en.wikipedia.org/wiki/Smooth_number")[#mi("{y}")#text("-smooth number")]#text(" (or ")#mi("{y}")#text("-friable number) is a natural number ")#mi("{n}")#text(" whose prime factors are all at most ")#mi("{y}")#text(". We use ")#mi("{\\Psi(x,y)}")#text(" to denote the number of ")#mi("{y}")#text("-smooth numbers up to ")#mi("{x}")#text(". In studying the asymptotic behavior of ")#mi("{\\Psi(x,y)}")#text(", it is customary to write ")#mi("{y}")#text(" as ")#mi("{x^{1/u}}")#text(" (or ")#mi("{x}")#text(" as ")#mi("{y^u}")#text(") for some ")#mi("{u>0}")#text(". For small values of ")#mi("{u}")#text(", the behavior is straightforward: for instance if ")#mi("{0 < u < 1}")#text(", then all numbers up to ")#mi("{x}")#text(" are automatically ")#mi("{y}")#text("-smooth, so")

#align(center)[#tao-fit-display[#mitex("\\Psi(x,y) \\sim x")]]

#text("in this case. If ")#mi("{1 < u < 2}")#text(", the only numbers up to ")#mi("{x}")#text(" that are not ")#mi("{y}")#text("-smooth are the multiples of primes ")#mi("{p}")#text(" between ")#mi("{y}")#text(" and ")#mi("{x}")#text(", so")

#tao-aligned(keep: true)[


#tao-math("\\Psi(x,y)  & \\sim x - \\sum_{y < p \\leq x} (\\frac{x}{p} + O(1))", block: true)



#tao-math(" & \\sim x - x (\\log\\log x - \\log\\log y)", block: true)



#tao-math(" & \\sim x (1 - \\log u)", block: true)
]

#text("where we have employed ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ second theorem")]#text(". For ")#mi("{2 < u < 3}")#text(", there is an additional correction coming from multiples of ")#emph[#text("two")]#text(" primes between ")#mi("{y}")#text(" and ")#mi("{x}")#text("; a straightforward inclusion-exclusion argument (which we omit here) eventually gives")

#align(center)[#tao-fit-display[#mitex("\\Psi(x,y) \\sim x (1 - \\log u + \\int_2^u \\frac{\\log(t-1)}{t} dt)")]]

#text("in this case.")

#text("More generally, for any fixed ")#mi("{u>0}")#text(", de Bruijn showed that")

#align(center)[#tao-fit-display[#mitex("\\Psi(x, y) \\sim \\rho(u) x")]]

#text("where ")#mi("{\\rho(u)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Dickman_function")[#text("Dickman function")]#text(". This function is a piecewise smooth, decreasing function of ")#mi("{u}")#text(", defined by the delay differential equation")

#align(center)[#tao-fit-display[#mitex("u \\rho^{\\prime}(u) + \\rho(u-1) = 0")]]

#text("with initial condition ")#mi("{\\rho(u) = 1}")#text(" for ")#mi("{0 \\leq u \\leq 1}")#text(".")

#text("The asymptotic behavior of ")#mi("{\\rho(u)}")#text(" as ")#mi("{u \\rightarrow \\infty}")#text(" is rather complicated. Very roughly speaking, it has inverse factorial behavior; there is a general upper bound ")#mi("{\\rho(u) \\leq 1/\\Gamma(u+1)}")#text(", and a crude asymptotic")

#align(center)[#tao-fit-display[#mitex("\\rho(u) = u^{-u+o(u)} = \\exp( - u \\log u + o(u \\log u)).")]]

#text("With a more careful analysis one can refine this to")

#metadata(none) <tao-74ed6deb9d32c1d7218f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho(u) = \\exp( - u \\log u - u \\log\\log u + u + o(u));")]]

#text("and with a ")#emph[#text("very")]#text(" careful application of the Laplace inversion formula one can in fact show that")

#metadata(none) <tao-9d067cb2f21af3da9584>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\rho(u) \\sim \\sqrt{\\frac{\\xi^{\\prime}(u)}{2\\pi}} \\exp( \\gamma - u \\xi(u) + \\int_0^{\\xi(u)} \\frac{e^s - 1}{s} ds)")]]

#text("where ")#mi("{\\gamma}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Euler%27s_constant")[#text("Euler-Mascheroni constant")]#text(" and ")#mi("{\\xi(u)}")#text(" is defined implicitly by the equation")

#metadata(none) <tao-2c16a79f7a9bc40e78fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("e^{\\xi(u)} - 1 = u \\xi(u).")]]

#text("One cannot write ")#mi("{\\xi(u)}")#text(" in closed form using elementary functions, but one can express it in terms of the ")#link("https://en.wikipedia.org/wiki/Lambert_W_function")[#text("Lambert ")#mi("{W}")#text(" function")]#text(" as ")#mi("{\\xi(u) = -W(-\\frac{1}{u} e^{-1/u}) - 1/u}")#text(". This is not a particularly enlightening expression, though. A more productive approach is to work with approximations. It is not hard to get the initial approximation ")#mi("{\\xi(u) \\approx \\log u}")#text(" for large ")#mi("{u}")#text(", which can then be re-inserted back into ")#link(<tao-2c16a79f7a9bc40e78fd>)[#text("(3)")]#text(" to obtain the more accurate approximation")

#align(center)[#tao-fit-display[#mitex("\\xi(u) = \\log u + \\log\\log u + O(1)")]]

#text("and inserted once again to obtain the refinement")

#align(center)[#tao-fit-display[#mitex("\\xi(u) = \\log u + \\log\\log u + O(\\frac{\\log\\log u}{\\log u}).")]]

#text("We can now see that ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text(" is consistent with previous asymptotics such as ")#link(<tao-74ed6deb9d32c1d7218f>)[#text("(1)")]#text(", after comparing the integral ")#mi("{\\int_0^{\\xi(u)} \\frac{e^s - 1}{s} ds}")#text(" to")

#align(center)[#tao-fit-display[#mitex("\\int_0^{\\xi(u)} \\frac{e^s - 1}{\\xi(u)} ds = u - 1.")]]

#text("For more details of these results, one can see for instance ")#link("https://dms.umontreal.ca/~andrew/PDF/msrire.pdf")[#text("this survey by Granville")]#text(".")

#text("This asymptotic ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text(" is quite complicated, and so one does not expect there to be any simple argument that could recover it without extensive computation. However, it turns out that one can use a “")#link("https://en.wikipedia.org/wiki/Principle_of_maximum_entropy")[#text("maximum entropy")]#text("” analysis to get a reasonably good heuristic approximation to ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text(", that at least reveals the role of the mysterious function ")#mi("{\\xi(u)}")#text(". The purpose of this blog post is to give this heuristic.")

#text("Viewing ")#mi("{x = y^u}")#text(", the task is to try to count the number of ")#mi("{y}")#text("-smooth numbers of magnitude ")#mi("{y^u}")#text(". We will propose a probabilistic model to generate ")#mi("{y}")#text("-smooth numbers as follows: for each prime ")#mi("{p \\leq y}")#text(", select the prime ")#mi("{p}")#text(" with an independent probability ")#mi("{c_p/p}")#text(" for some coefficient ")#mi("{c_p}")#text(", and then multiply all the selected primes together. This will clearly generate a random ")#mi("{y}")#text("-smooth number ")#mi("{n}")#text(", and by the law of large numbers, the (log-)magnitude of this number should be approximately ")#metadata(none) <tao-091e7397b79ab9c586b9>#mi("\\displaystyle  \\log n \\approx \\sum_{p \\leq y} \\frac{c_p}{p} \\log p, \\ \\ \\ \\ \\ (4)")#text(" ")#text(" (where we will be vague about what “")#mi("{\\approx}")#text("” means here), so to obtain a number of magnitude about ")#mi("{y^u}")#text(", we should impose the constraint ")#metadata(none) <tao-e44b4bd707c540bca861>#mi("\\displaystyle  \\sum_{p \\leq y} \\frac{c_p}{p} \\log p = u \\log y. \\ \\ \\ \\ \\ (5)")

#text("The indicator ")#mi("{1_{p|n}}")#text(" of the event that ")#mi("{p}")#text(" divides this number is a Bernoulli random variable with mean ")#mi("{c_p/p}")#text(", so the Shannon entropy of this random variable is")

#align(center)[#tao-fit-display[#mitex("\\mathbf{H}(1_{p|n}) = - \\frac{c_p}{p} \\log(\\frac{c_p}{p}) - (1 - \\frac{c_p}{p}) \\log(1 - \\frac{c_p}{p}).")]]

#text("If ")#mi("{c_p}")#text(" is not too large, then Taylor expansion gives the approximation")

#align(center)[#tao-fit-display[#mitex("\\mathbf{H}(1_{p|n}) \\approx \\frac{c_p}{p} \\log p - \\frac{c_p}{p} \\log c_p + \\frac{c_p}{p}.")]]

#text("Because of independence, the total entropy of this random variable ")#mi("{n}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\mathbf{H}(n) = \\sum_{p \\leq y} \\mathbf{H}(1_{p|n});")]]

#text("inserting the previous approximation as well as ")#link(<tao-e44b4bd707c540bca861>)[#text("(5)")]#text(", we obtain the heuristic approximation")

#align(center)[#tao-fit-display[#mitex("\\mathbf{H}(n) \\approx u \\log y - \\sum_{p \\leq y} \\frac{c_p}{p} (\\log c_p - 1).")]]

#text("The ")#link("https://en.wikipedia.org/wiki/Asymptotic_equipartition_property")[#text("asymptotic equipartition property")]#text(" of entropy, relating entropy to microstates, then suggests that the set of numbers ")#mi("{n}")#text(" that are typically generated by this random process should have cardinality approximately")

#tao-aligned(keep: true)[


#tao-math("\\exp(\\mathbf{H}(n))  & \\approx \\exp\\left(u \\log y - \\sum_{p \\leq y} \\frac{c_p}{p} (\\log c_p - 1)\\right)", block: true)



#tao-math(" & = \\exp\\left(- \\sum_{p \\leq y} \\frac{c_p \\log c_p - c_p}{p}\\right) x.", block: true)
]

#text("Using the ")#link("https://en.wikipedia.org/wiki/Principle_of_maximum_entropy")[#text("principle of maximum entropy")]#text(", one is now led to the approximation")

#metadata(none) <tao-fb43c33f90448e1c5433>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\rho(u) \\approx \\exp\\left(- \\sum_{p \\leq y} \\frac{c_p \\log c_p - c_p}{p}\\right).")]]

#text("where the weights ")#mi("{c_p}")#text(" are chosen to maximize the right-hand side subject to the constraint ")#link(<tao-e44b4bd707c540bca861>)[#text("(5)")]#text(".")

#text("One could solve this constrained optimization problem directly using Lagrange multipliers, but we simplify things a bit by passing to a continuous limit. We take a continuous ansatz ")#mi("{c_p = f(\\log p / \\log y)}")#text(", where ")#mi("{f: [0,1] \\rightarrow {\\bf R}}")#text(" is a smooth function. Using Mertens’ theorem, the constraint ")#link(<tao-e44b4bd707c540bca861>)[#text("(5)")]#text(" then heuristically becomes ")#metadata(none) <tao-dd724d81ad2fe372c1b6>#mi("\\displaystyle  \\int_0^1 f(t)\\ dt = u \\ \\ \\ \\ \\ (7)")#text(" ")#text(" and the expression ")#link(<tao-fb43c33f90448e1c5433>)[#text("(6)")]#text(" simplifies to ")#metadata(none) <tao-fe340d5b84f38873c599>#mi("\\displaystyle  \\rho(u) \\approx \\exp( - \\int_0^1 \\frac{f(t) \\log f(t) - f(t)}{t}\\ dt). \\ \\ \\ \\ \\ (8)")#text(" ")#text(" So the entropy maximization problem has now been reduced to the problem of minimizing the functional ")#mi("{\\int_0^1 \\frac{f(t) \\log f(t) - f(t)}{t}\\ dt}")#text(" subject to the constraint ")#link(<tao-dd724d81ad2fe372c1b6>)[#text("(7)")]#text(". The astute reader may notice that the integral in ")#link(<tao-fe340d5b84f38873c599>)[#text("(8)")]#text(" might diverge at ")#mi("{t=0}")#text(", but we shall ignore this technicality for the sake of the heuristic arguments.")

#text("This is a standard calculus of variations problem. The ")#link("https://en.wikipedia.org/wiki/Euler%E2%80%93Lagrange_equation")[#text("Euler-Lagrange equation")]#text(" for this problem can be easily worked out to be")

#align(center)[#tao-fit-display[#mitex("\\frac{\\log f(t)}{t} = \\lambda")]]

#text("for some Lagrange multiplier ")#mi("{\\lambda}")#text("; in other words, the optimal ")#mi("{f}")#text(" should have an exponential form ")#mi("{f(t)= e^{\\lambda t}}")#text(". The constraint ")#link(<tao-dd724d81ad2fe372c1b6>)[#text("(7)")]#text(" then becomes")

#align(center)[#tao-fit-display[#mitex("\\frac{e^\\lambda - 1}{\\lambda} = u")]]

#text("and so the Lagrange multiplier ")#mi("{\\lambda}")#text(" is precisely the mysterious quantity ")#mi("{\\xi(u)}")#text(" appearing in ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text("! The formula ")#link(<tao-fe340d5b84f38873c599>)[#text("(8)")]#text(" can now be evaluated as")

#tao-aligned(keep: true)[


#tao-math("\\rho(u)  & \\approx \\exp\\left( - \\int_0^1 \\frac{e^{\\xi(u) t} \\xi(u) t - e^{\\xi(u) t}}{t}\\ dt \\right)", block: true)



#tao-math(" & \\approx \\exp\\left( - e^{\\xi(u)} + 1 + \\int_0^1 \\frac{e^{\\xi(u) t} - 1}{t}\\ dt + \\int_0^1 \\frac{1}{t}\\ dt \\right)", block: true)



#tao-math(" & \\approx \\exp\\left( - u \\xi(u) + \\int_0^{\\xi(u)} \\frac{e^s - 1}{s}\\ ds + C\\right)", block: true)
]

#text("where ")#mi("{C}")#text(" is the divergent constant")

#align(center)[#tao-fit-display[#mitex("C = \\int_0^1 \\frac{1}{t}\\ dt.")]]

#text("This recovers a large fraction of ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text("! It is not completely accurate for multiple reasons. One is that the hypothesis of joint independence on the events ")#mi("{p|n}")#text(" is unrealistic when trying to confine ")#mi("{n}")#text(" to a single scale ")#mi("{x}")#text("; this comes down ultimately to the subtle differences between the Poisson and Poisson-Dirichlet processes, as discussed in ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this previous blog post")]#text(", and is also responsible for the otherwise mysterious ")#mi("{e^\\gamma}")#text(" factor in ")#text("Mertens’ third theorem")#text("; it also morally explains the presence of the same ")#mi("{e^\\gamma}")#text(" factor in ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text(". A related issue is that the law of large numbers ")#link(<tao-091e7397b79ab9c586b9>)[#text("(4)")]#text(" is not exact, but admits gaussian fluctuations as per the central limit theorem; morally, this is the main cause of the ")#mi("{\\sqrt{\\frac{\\xi^{\\prime}(u)}{2\\pi}}}")#text(" prefactor in ")#link(<tao-9d067cb2f21af3da9584>)[#text("(2)")]#text(".")

#text("Nevertheless, this demonstrates that the maximum entropy method can achieve a reasonably good heuristic understanding of smooth numbers. In fact we also gain some insight into the “anatomy of integers” of such numbers: the above analysis suggests that a typical ")#mi("{y}")#text("-smooth number ")#mi("{n}")#text(" will be divisible by a given prime ")#mi("{p \\sim y^t}")#text(" with probability about ")#mi("{e^{\\xi(u) t}/p}")#text(". Thus, for ")#mi("{t = 1 - O(1/\\log u)}")#text(", the probability of being divisible by ")#mi("{p}")#text(" is elevated by a factor of about ")#mi("{\\asymp e^{\\xi(u)} \\asymp u \\log u}")#text(" over the baseline probability ")#mi("{1/p}")#text(" of an arbitrary (non-smooth) number being divisible by ")#mi("{p}")#text("; so (by Mertens’ theorem) a typical ")#mi("{y}")#text("-smooth number is actually largely comprised of something like ")#mi("{\\asymp u}")#text(" prime factors all of size about ")#mi("{y^{1-O(1/\\log u)}}")#text(", with the smaller primes contributing a lower order factor. This is in marked contrast with the anatomy of a typical (non-smooth) number ")#mi("{n}")#text(", which typically has ")#mi("{O(1)}")#text(" prime factors in each hyperdyadic scale ")#mi("{[\\exp\\exp(k), \\exp\\exp(k+1)]}")#text(" in ")#mi("{[1,n]}")#text(", as per Mertens’ theorem.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2025")])]

#text("Dear prof Tao ,I already asked a question in MO regarding that new post her :")#link("https://mathoverflow.net/q/500427/573226")[#text("https://mathoverflow.net/q/500427/573226")]

#text("I wish your answer or any feedback,Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2025")])]

#text("Hm, formula (1) looks nice and quite precise for me, while formula (2) looks useless. It just expresses one function ")#mi("\\rho")#text(" (defined implicitly as a solution to a delay differential equation) using another function ")#mi("\\xi")#text(", also defined implicitly. I do not understand how you used (2) to derive some useful formulas like (1), because (2) contains the derivative of ")#mi("\\xi")#text(", and asymptotic formulas for ")#mi("\\xi")#text(" involving ")#mi("O()")#text(" term give no control on its derivative.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688775")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2025")])]

#text("One can implicitly differentiate the equation (3) to obtain an equation for ")#mi("\\xi^{\\prime}")#text(", namely ")#mi("\\xi^{\\prime} e^\\xi = \\xi + u \\xi^{\\prime}")#text(", or ")#mi("\\xi^{\\prime} = \\frac{\\xi}{e^\\xi-u} = \\frac{\\xi}{u\\xi + 1 - u}")#text(", which when combined with the other asymptotics for ")#mi("\\xi")#text(" mentioned in the blog post can be used to recover (1) (and in fact one can obtain more control on the error term with additional effort by this method). In principle one could also use the extensive asymptotics for the Lambert W-function in the literature, or complex methods based on analytic continuation of ")#mi("\\xi")#text(" and identities such as the Cauchy integral formula, to also obtain control on quantities such as ")#mi("\\xi^{\\prime}")#text(", though the above more elementary approach suffices for most applications.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b79af867da5b26d1e99314d2ada0f8624de4e40523136377a239ec20fec3f4c3-9fc098e083af397379b7a49bc964a02ac1ae358657e24f34aa87342844202003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir Gorodetsky")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688774")[#strong[#text("Ofir Gorodetsky")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2025")])]

#text("Nice heuristic argument Terry! Thank you for sharing.")

#text("It’s worthwhile mentioning that your observations regarding the anatomy have indeed been established in the literature, confirming the validity of the heuristic (in certain ranges). The derivations in the literature are usually offered as computations, so it is valuable to have an independent heuristic argument motivating them.")

#text("For instance, the constraint ")#mi("\\int_{0}^{1} f(t)\\ dt = u")#text(" which translates to ‘typical y-smooth number <= x has u prime factors’ has been established by Alladi in ‘Turán-Kubilius inequality for integers without large prime factors’ (Crelle 1982). To be precise, the expected number of prime factors of a y-smooth integer <=x is ")#mi("\\sim u +\\log \\log y")#text(", interpolating between the ")#mi("\\log \\log x")#text(" prediction (for ")#mi("y=x")#text(") and your u, with ")#mi("u")#text(" taking dominance once ")#mi("y")#text(" isn’t too big (")#mi("\\log y =o(\\log x / \\log \\log x)")#text(".")

#text("Once the ")#mi("u")#text("-behavior for the number of prime factors kicks in, it persists even for very small ")#mi("y")#text(" (as long as ")#mi("y \\to \\infty")#text(" actually), see e.g. Hildebrand’s “On the number of prime factors of integers without large prime divisors” (JNT 1987).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2025")])]

#text("The dickman function wiki link is incorrect, should be ")#link("https://en.wikipedia.org/wiki/Dickman_function")[#text("https://en.wikipedia.org/wiki/Dickman_function")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2025")])]

#text("Dear Prof. Tao,")

#text("I have a simple question.")

#text("What is the expected value for the logarithm of the largest prime factor of a y-smooth number, as predicted by this maximum entropy model, and how does this expectation change as a function of u?")

#text("Or let P(n) be the largest prime factor of an integer n. Can we analyze the behavior of the conditional expectation 𝔼[log P(n) | n is y-smooth] as a function of u = (log x) / (log y), based on the probabilistic model derived from the maximum entropy heuristic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2025")])]

#text("As mentioned in the text, when ")#mi("u")#text(" is large, a ")#mi("y")#text("-smooth number of size ")#mi("x = y^u")#text(" looks very roughly like the product of ")#mi("u")#text(" generic primes of size ")#mi("y^{1-O(1/\\log u)}")#text(" (times smaller primes), so I would expect ")#mi("\\log P(n)")#text(" to be something like ")#mi("(1-O(1/u \\log u)) \\log y")#text(" with this heuristic. It would probably be instructive to try to compute this quantity rigorously using more classical asymptotics for smooth numbers to see what one actually gets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688888")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2025")])]

#text("It seems that our link for Merten’s third theorem also links to the previous Poisson-Dirichlet processes blog post, the wikipedia page for Merten’s theorems would be ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("https://en.wikipedia.org/wiki/Mertens%27_theorems")]

#text("Thank you again for these interesting posts and work ♥️🍀!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688908")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2025")])]

#text("Geometric methods in analytic number theory over function fields often have an easier time handling rough numbers (well, really polynomials, but I’ll just say numbers for simplicity), such as prime numbers, and a harder time handling smooth numbers, and functions concentrated on smooth numbers like the higher divisor function. The relevant measure of smoothness for this is not the size of the largest prime factor, or the smallest, but instead the entropy of the probability distribution that assigns probability ")#mi("\\log p/\\log n")#text(" to each prime factor ")#mi("p")#text(" of ")#mi("n")#text(".")

#text("Since noticing this I have wondered, mostly idly, how to quantify the tail behavior of this notion of entropy, i.e. what proportion of numbers have entropy above a given cutoff. I figured I would try applying the heuristic of this blog post, which seems likely to apply equally well to this problem, and, besides, it’s amusing to use entropy methods to predict the behavior of entropy.")

#text("If I calculated right, the proportion of numbers with entropy ")#mi("> H")#text(" should for large ")#mi("H")#text(" approximate ")#mi("e^{ -e^H ( H+ \\frac{\\log H}{2} +O(1))}")#text(", and a typical such number should have about ")#mi("e^H")#text(" prime factors, distributed approximately normally with mean ")#mi("e^{-H}")#text(" and variance ")#mi("e^{-2H}/H")#text(". Unsurprisingly, the soft cutoff instead of a hard cutoff leads to a smoother distribution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4bf120efbd08066bf29d797551e072a7671c6714439171e7344f965714e9b5b-3672fb0b7659f1f9a9798dc3c751c262696bed39b7e398b8c4d2f24cb87938c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QNFT")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688911")[#strong[#text("QNFT")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2025")])]

#text("Perhaps one can recast the “entropy of prime-factor weights” tail as a variational problem on factor profiles g(t)g(t)g(t) over t=log⁡plog⁡n∈(0,1]t=frac{log p}{log n}in(0,1]t=lognlogp​∈(0,1] with the log-budget ∫01t g(t) dt=1int_0^1 t,g(t),dt=1∫01​tg(t)dt=1 and entropy H(g)=− ⁣∫01t g(t)log⁡(tg(t)) dtH(g)=-!int_0^1 t,g(t)logbig(tg(t)big),dtH(g)=−∫01​tg(t)log(tg(t))dt.")#linebreak()#text("Replacing independence/PD heuristics by a PSD kernel constraint (equivalently, minimizing K(g)=∫01glog⁡g−gt dtmathcal{K}(g)=int_0^1 frac{glog g-g}{t},dtK(g)=∫01​tglogg−g​dt subject to H(g)≥HH(g)ge HH(g)≥H) gives a saddle point g∗(t)∝exp⁡(−α/t−βt)g^*(t)propto exp(-alpha/t-beta t)g∗(t)∝exp(−α/t−βt). A Laplace evaluation at large HHH yields the LDP rate I(H)=eH ⁣(H+12log⁡H+C+o(1)),I(H)=e^{H}!left(H+tfrac{1}{2}log H + C + o(1)right),I(H)=eH(H+21​logH+C+o(1)),")

#text("hence Pr⁡(entropy≥H)=exp⁡ ⁣(−I(H)),Pr(text{entropy}ge H)=exp!big(-I(H)big),Pr(entropy≥H)=exp(−I(H)),")

#text("matching your eH(H+12log⁡H)e^{H}(H+tfrac{1}{2}log H)eH(H+21​logH) structure. The optimizer implies k∼eHksim e^{H}k∼eH prime factors with an approximately Gaussian spread in ttt around t≍1/Htasymp 1/Ht≍1/H.")#linebreak()#text("(Here CCC depends on the kernel’s bounded-trace constant; one may treat it as an external absolute constant if desired.)")

#text("This approach arises from a generalized kernel field model developed independently.")

#text("My apologies if I posted twice. I joined to answer the question. Thanks ")#linebreak()#text("Darren")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ea414e1d26b75e17418bc8401b94cd3342b73cdccbcf1751302971e66fd653b-38b844bb4da9c12ea1dc2561f42e6d7e29a968b78be5a0894e6dc4fa30680bdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JOSÉ MIGUEL MEDINA DÍAZ")]], [#link("https://terrytao.wordpress.com/2025/09/15/smooth-numbers-and-max-entropy/#comment-688942")[#strong[#text("JOSÉ MIGUEL MEDINA DÍAZ")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2025")])]

#text("Hi! I am a 14-year-old math fanatic. I am a spanish student.")

#text("I wanna learn more and do little investigations")

#text("thanks for read!!")
]
