// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/
// Converted to Typst by tao2typ: "2026-10-14T15:17:26.748394+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The cosmic distance ladder", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The cosmic distance ladder")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 September 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/")[#text("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am uploading another of my ")#link("http://www.austms.org.au/tiki-read_article.php?articleId=61")[#text("Clay-Mahler lectures")]#text(" here, namely my ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/09/cosmic-distance-ladder2.pdf")[#text("public talk on the cosmic distance ladder")]#text(" (4.3MB, PDF). These slides are based on my ")#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/")[#text("previous talks of the same name")]#text(", but I have updated and reorganised the graphics significantly as I was not fully satisfied with the previous arrangement.")

#text("[")#emph[#text("Update")]#text(", Sep 4: slides updated. The Powerpoint version of the slides (8MB) are ")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/09/cosmic-distance-ladder.pptx")[#text("available here")]#text(".]")

#text("[")#emph[#text("Update")]#text(", Oct 26: slides updated again.]")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41261")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("On slide 46, is it not the penumbra, not the umbra, which has a width of 2r?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41262")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Thanks for the beautiful lecture. Slide 51, shouldn’t it be “The earth takes 24hours to make a full rotation ” instead of the moon ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41267")[#strong[#text("Mathematical Research and the Internet « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/")[#text("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41270")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Really great slides! I am wondering if a nice graphical illustration of why Romer-Huygens measurement works can be included.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41274")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("Thanks for the corrections! Both the umbra and penumbra are approximately 2r; this is an oversimplification assuming that the sun is quite far away compared to the moon, but the third rung arguments establish that this is indeed the case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41276")[#strong[#text("Tales from the Tubes — 4/​09/​09 | Young Australian Skeptics")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")]

#text("[…] Terence Tao on really big distances. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mitchell")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41279")[#strong[#text("Mitchell")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("I’ll be at your talk at QUT on this topic.")

#text("I don’t want to look at the slides… It would spoil the speech for me!")

#text("Looking forward to it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41285")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2009")])]

#text("In the slide 69, should pi*(1/2 – 12hours/1month) be pi*(1/2 -2*12hours/1month)?")#linebreak()#text(" since moon will take 1month to rotate(2*pi) around earth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e9ef4befdf2e1897e7f75f2d266f2ac8c5354acc3f2a18dc4cafbe9c68815d0-d40391f5bea6748bc1ff9c4da41f8edfe3d2ba09272821dd349bd6b9e1c66005.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41292")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2009")])]

#text("Define the universe:)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41316")[#strong[#text("Clay-Mahler lecture series « Mathematics in Australia")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2009")]

#text("[…] Here are the slides for the public lecture “The cosmic distance ladder”. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4558e008f78201ff3b7bd35f0708bb83034603eec095f1d432ba2583b6ebd627-bd77f7e911d0e90d82a1e59af0298b40b68fb93afcaad2a090a0eb5e98afa5d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicole")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41340")[#strong[#text("Nicole")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2009")])]

#text("I thoroughly enjoyed your lecture at QUT yesterday and found the ancient methods of calculation fascinating. Was a bit miffed not to have brought something to take notes on, so you can imagine my delight and gratitude that you have made the slides available here! Thank you so much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcbdb04abb456650c2028de4b1dda8e78dbef2c7f2dd7f2e57edd199fb5213e6-8c6a342c7309e078e7000d904c1912b7e818a9b4ed3b788ba43cf744eeef8196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estelle")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-41665")[#strong[#text("Estelle")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("page 19, Aristotle (384-382 BCE)… ")#emph[#text("[Oops! That should be 384-322 BCE, thanks. The next update of the slides will have the correction. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-44777")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("Hello Terry,")#linebreak()#text(" I keep coming to your wonderful slides on the cosmic ladder. I wonder, is there anything like a “microcosmic ladder”? That is, going smaller rather than bigger.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-44781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("Well, it is much shorter; with electron microscopes, for instance, one can already get down to the atomic level, and below that range one can more or less compute everything from quantum field theory, using collider data and known values of physical constants to calibrate. The big difference is that we can study microscopic objects in a laboratory, and subject them to whatever physical tests we please in a reasonable amount of time, but we cannot send out some test or probe, say, a distant galaxy without having to wait millions of years for the result.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-44786")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2010")])]

#text("Dear Terry,")#linebreak()#text(" Thank you for your reply. Yes, I see your point. However, going down from the everyday scale to the atomic level by means of an electron microscope is like going up from the everyday scale to “the universe scale” (9th rung in your slides) by means of the Hubble telescope. It skips a lot of rungs (e.g. the width of a human hair, the edge of a very sharp knife, the porosity of crystals, the nano-scale, etc.) With my question I meant “homemade” or “just clever” ways to conceive the smallness of things along the lines of the ancient Greeks’ techniques.")#linebreak()#text(" Perhaps in the future we will be able to measure the width of the Kaluza-Klein compact dimensions in a lab with a gigantic machine. That would be fun.")#linebreak()#text(" In terms of waiting time, yes, galaxies take a long time to return our calls; but it could easily take us a longer time to measure small lengths near the Planck length (about 10^20 times smaller than the diameter of a proton, according to wikipedia).")#linebreak()#text(" Although that might all be mere speculation, it would be entertaining to illustrate their corresponding scales, as an exercise in numerical literacy…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d084d144f22860131bf45031f77c83a1b623ef01cde684f9f2e6454920339ff6-527b58d31bd0ad0ecabac5708bf4ba225ffae6cee0e00b645036f2e226cc51de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nurdin Takenov")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-45790")[#strong[#text("Nurdin Takenov")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2010")])]

#text("Good presentation, I finally ralized the Aristarches’ method.")#linebreak()#text(" Slide 24: “Aristotle also knew there were stars one could see in Greece but not in Egypt, or vice versa.” – hm, it seems that all stars senn in Greece also seen in Egypt.")#linebreak()#text(" Slide 41: “Aristotle argued that the Moon was a sphere (rather than a disk) because the terminator (the boundary of the Sun’s light on the Moon) was always a circular arc.” – isn’t the arc of terminator is elliptical?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6dbd98c03c1bf8088d2b786d124e71c1cd3e4f3d75c53f496a40d9a1503bca1-f229400d9a3491ae5650d12824dba968c47baf0e8ce4b2312cdc0b4bcdff7e27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-45969")[#strong[#text("Patrick")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2010")])]

#text("On slideshare: ")#link("http://www.slideshare.net/embeds/cosmic-distance-ladder-terrance-tao-updated-102609")[#text("http://www.slideshare.net/embeds/cosmic-distance-ladder-terrance-tao-updated-102609")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Cosmic Distance Ladder (version 4.1) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-47513")[#strong[#text("The Cosmic Distance Ladder (version 4.1) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("[…] once at UCLA. The slides I used were similar to the “version 3.0” slides I used for the same talk last year in Australia and elsewhere, but the images have been updated (and the permissions for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bfb68c76be28e5daebdcc31b61604120168848db2dc8c78a9d2d642e93c9a45-daf15531072d0fdb95e85867757553813e5f5676e29ffd290fe824f9e2042227.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of barzinho")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-514220")[#strong[#text("barzinho")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2019")])]

#text("Hello Terry! I’m a brazillian graduate student and I give classes in high school, I would like to know if I can use your slide in one of my classes about physics ? It would be awesome to introduce students using this slide for two reasons: Show that content from one of the finnest universities of the world is understandable and able of being critisized, and inspire students towards investigation and curiosity, Erastotenes made science only by observing and travelling, he didn’t did anything extraordinarily complex and yet was relevant and inspiring.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-514231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2019")])]

#text("Yes, the slides can be used either in part or in full as long as attribution is given, see the last section of ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-574326")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2020")])]

#text("Reminds me of a book/essay (perhaps several?) by Isaac Asimov where he would move from the smallest meaningful length scale and then increase step by step until he was at the largest possible meaningful distance on a cosmic scale.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2883cd72735a899126f9490c70b6c97be67f93e85ea714173281b2af9c1ad217-19c779be695f492b73bf8fd69195bd211e7e9188d792e5e5343f5febfb2e96b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunya")]], [#link("https://terrytao.wordpress.com/2009/09/03/the-cosmic-distance-ladder-2/#comment-686491")[#strong[#text("Sunya")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2024")])]

#text("This statement on slide 55 catched my attention: Aristarchus, by the way, was handicapped by not having an accurate value of π.")

#text("Does it really matter (due to law precision of other numbers involved in his calculations)? Value of π=3 seems like all that is needed. In other words, I see no handicap here.")
]
