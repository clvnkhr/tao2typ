// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/
// Converted to Typst by tao2typ: "2026-10-14T11:14:19.114013+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Decomposing a factorial into large factors (second version)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Decomposing a factorial into large factors (second version)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 June 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/")[#text("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://borisalexeev.com/")[#text("Boris Alexeev")]#text(", Evan Conway, ")#link("https://www.lirmm.fr/~mrosenfeld/")[#text("Matthieu Rosenfeld")]#text(", ")#link("https://math.mit.edu/~drew/")[#text("Andrew Sutherland")]#text(", Markus Uhr, ")#link("https://kevinventullo.com/about/")[#text("Kevin Ventullo")]#text(", and I have uploaded to the arXiv a second version of our paper “")#link("https://arxiv.org/abs/2503.20170")[#text("Decomposing a factorial into large factors")]#text("“. This is a completely rewritten and expanded version of a ")#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")[#text("previous paper of the same name")]#text(". Thanks to many additional theoretical and numerical contributors from the other coauthors, we now have much more precise control on the main quantity ")#mi("{t(N)}")#text(" studied in this paper, allowing us to settle all the previous conjectures about this quantity in the literature.")

#text("As discussed in ")#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")[#text("the previous post")]#text(", ")#mi("{t(N)}")#text(" denotes the largest integer ")#mi("{t}")#text(" such that the factorial ")#mi("{N!}")#text(" can be expressed as a product of ")#mi("{N}")#text(" factors, each of which is at least ")#mi("{t}")#text(". Computing ")#mi("{t(N)}")#text(" is a special case of the ")#link("https://en.wikipedia.org/wiki/Bin_covering_problem")[#text("bin covering problem")]#text(", which is known to be NP-hard in general; and prior to our work, ")#mi("{t(N)}")#text(" was only computed for ")#mi("{N \\leq 599}")#text("; we have been able to compute ")#mi("{t(N)}")#text(" for all ")#mi("{N \\leq 10000}")#text(". In fact, we can get surprisingly sharp upper and lower bounds on ")#mi("{t(N)}")#text(" for much larger ")#mi("{N}")#text(", with a precise asymptotic")

#mi("\\displaystyle \\frac{t(N)}{N} = \\frac{1}{e} - \\frac{c_0}{\\log N} - \\frac{O(1)}{\\log^{1+c} N}")

#text("for an explicit constant ")#mi("{c_0 = 0.30441901\\dots}")#text(", which we conjecture to be improvable to")

#mi("\\displaystyle \\frac{t(N)}{N} = \\frac{1}{e} - \\frac{c_0}{\\log N} - \\frac{c_1+o(1)}{\\log^{2} N}")

#text("for an explicit constant ")#mi("{c_1 = 0.75554808\\dots}")#text(": … For instance, we can demonstrate numerically that")

#mi("\\displaystyle 0 \\leq t(9 \\times 10^8) - 316560601 \\leq 113.")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/newplot_600.png")[#image("../assets/7960c921308867e3e8fa58c9dde6e36060b80c8a8bdbb432c8608931bdb68aa0-c74832221898238ec0520cf5ec8f601c3b927764618c0cf13aad964ad2b8caa3.png", width: 90%)]
]

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/verylarge.png")[#image("../assets/2e3ba150b62576167da8f58a651c83d993a94692de658a78709925a630be2fa8-46591d837e1a48bf802869a265775b31ac110dcb475ffe0c5727a9ceea6614ac.png", width: 90%)]
]

#text("As a consequence of this precision, we can verify several conjectures ")#link("https://zbmath.org/0918.11013")[#text("of Guy and Selfridge")]#text(", namely")

#list(
[#mi("{t(N) \\leq N/e}")#text(" for all ")#mi("{N \\neq 1,2,4}")#text(".")],
[#mi("{t(N) \\geq \\lfloor 2N/7\\rfloor}")#text(" for all ")#mi("{N \\neq 56}")#text(".")],
[#mi("{t(N) \\geq N/3}")#text(" for all ")#mi("{N \\geq 3 \\times 10^5}")#text(". (In fact we show this is true for ")#mi("{N \\geq 43632}")#text(", and that this threshold is best possible.) ")#linebreak()]
)

#text("Guy and Selfridge also claimed that one can establish ")#mi("{t(N) \\geq N/4}")#text(" for all large ")#mi("{N}")#text(" purely by rearranging factors of ")#mi("{2}")#text(" and ")#mi("{3}")#text(" from the standard factorization ")#mi("{1 \\times 2 \\times \\dots \\times N}")#text(" of ")#mi("{N!}")#text(", but surprisingly we found that this claim (barely) fails for all ")#mi("{N > 26244}")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/06/t3.png")[#image("../assets/178acce6b600f878c6133db40ca05588495560237e10b138fe6aba2e44754896-f6416cdc2bf76c04f95211bde9d5ec945e291da271e526bf6b5a2717a9672648.png", width: 90%)]
]

#text("The accuracy of our bounds comes from several techniques:")

#list(
[#emph[#text("Greedy algorithms")]#text(", in which one allocates the largest prime factors of ")#mi("{N!}")#text(" first and then moves to smaller primes, provide quickly computable, though suboptimal, lower bounds on ")#mi("{t(N)}")#text(" for small, medium, and moderately large values;")],
[#emph[#text("Linear programming")]#text(" and ")#emph[#text("integer programming")]#text(" methods provides extremely accurate upper and lower bounds on ")#mi("{t(N)}")#text(" for small and medium values of ")#mi("{N}")#text(";")],
[#emph[#text("Rearrangement methods")]#text(" can be analyzed asymptotically via linear programming, and work well for large ")#mi("{N}")#text("; and")],
[#text("The ")#emph[#text("modified approximate factorization")]#text(" strategy, discussed in ")#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")[#text("the previous post")]#text(" is now sharpened by using ")#mi("{3}")#text("-smooth numbers (products of ")#mi("{2}")#text(" and ")#mi("{3}")#text(") as the primary “liquidity pool” to reallocate factors of ")#mi("{N!}")#text(", as opposed to the previous approach of only using powers of ")#mi("{2}")#text(". ")#linebreak()]
)

#text("To me, the biggest surprise was just how stunningly accurate the linear programming methods were; the very large number of repeated prime factors here actually make this discrete problem behave rather like a continuous one.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c4d1bff465d3e54f7c79d058b9cc3b39ad93124d4ee9c39d247890e20173354-e1b8b1516558348ba14315fc94f921b88621d4ce960c423203a506e5396bd4c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcuzz")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688250")[#strong[#text("dcuzz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("not sure if it’s my device but some of these formulas don’t look right (wrt formatting, not content)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("FYI, the math after the explicit constant c_1 does not parse and the display environment before it has an error with the fraction and the equals sign.")

#emph[#text("[Fixed, thanks – T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("The math parses now but TWO display environments still look wrong to me. The thing I see is that there is a frac with t(N) on top and an equals sign on the bottom. So, I think there is an N missing in the bottom of two fracs in display environments: I think there should be frac{t(N)}N strictly before the = sign.")

#emph[#text("[Hopefully fixed now – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("For the display environment following “conjecture to be improvable”, I think the exponent 1+c should be 2.")

#emph[#text("[Corrected, thanks -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("The formulas in this post don’t seem to be rendering correctly. Not sure if it’s just me.")

#emph[#text("[This appeared to be some sort of temporary caching issue. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688259")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("This reminds me about a similar problem with a fixed number of factors (independent of N). E.g., for 3 factors we get ")#link("https://oeis.org/A061030")[#text("https://oeis.org/A061030")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("I would imagine that the linear programming/integer programming method would be quite effective at this problem also. For any fixed number ")#mi("k")#text(" of factors, one should be able to get very close to the trivial upper bound of ")#mi("(N!)^{1/k}")#text(", though I do not have a good guess for now as to what the size of the error term should be.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("Getting exact solutions with ILP is tricky as with growth of N it becomes either inaccurate or slow. I’ve brought this issue to discussion at ")#link("https://mathoverflow.net/q/419722")[#text("https://mathoverflow.net/q/419722")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Alexeev")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688263")[#strong[#text("Boris Alexeev")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("The (integer) linear programs in this paper are much better behaved than the ones in that MathOverflow question. In our case, if for example you have ")#mi("N=43631")#text(" and we wish to show that ")#mi("N!")#text(" cannot be factored into ")#mi("N")#text(" factors each of which is at least ")#mi("T=\\lceil N/3\\rceil=14544")#text(", we use variables ")#mi("m_T, ldots, m_N")#text(" representing how many times we use each factor ")#mi("T")#text(" through ")#mi("N")#text(". There are “budget” constraints for each prime ")#mi("p")#text(" that say ")#mi("sum_j m_j \\nu_p(j) \\le \\nu_p(N!)")#text(". We can either add the constraint that we want there to be at least ")#mi("\\sum_j m_j \\ge N")#text(" factors and solve a feasibility problem — or alternatively, we can set the optimization objective to maximize ")#mi("\\sum_j m_j")#text(" and then compare this objective to ")#mi("N")#text(". Note that all of the coefficients are small integers, often ")#mi("0")#text(" or ")#mi("1")#text(".")

#text("The optima also behave quite well for ")#mi("N")#text(" in this range. In the example I gave above, there is no need to use integer programming: the LP relaxation is already tight enough. And in order to be sure, we verified the dual certificate in exact arithmetic.")

#text("For comparison, if ")#mi("N=20")#text(" in the MO post above, we seek to factor ")#mi("20!")#text(" into two terms each of which is as close to ")#mi("\\sqrt{20!} \\approx 1.5 \\times 10^9")#text(" as possible. The natural integer programming formulation has many coefficients of the form ")#mi("\\log p")#text(", which aren’t even rational (yet alone small integers). Unfortunately, it is not effective to use our formulation instead because then there would be an enormous number of variables ")#mi("m_j")#text(" for different ")#mi("j")#text(" (and the approach would be worse than a simple brute-force loop).")

#text("I think the major difference is that in our formulation, the resulting answer ")#mi("T")#text(" is of the same order as ")#mi("N")#text(", while when splitting into a constant number of factors, it becomes enormous.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris Alexeev")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688267")[#strong[#text("Boris Alexeev")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2025")])]

#text("A couple more thoughts regarding the two different programs:")

#text("For the program in the MO question, the linear program relaxation (ie, not ")#emph[#text("integer")]#text(") has the obvious bound as a solution, namely that each factor must be at most ")#mi("\\sqrt{N!}")#text(". In our case, the obvious bound ")#mi("(N!)^{1/N}")#text(" is a ")#emph[#text("feasible")]#text(" dual solution, but not an optimal one. And in fact some of the paper finds better dual solutions purely mathematically (as opposed to computationally) and these rigorously prove upper bounds tighter than the obvious one.")

#text("I will also note that the ")#emph[#text("specific")]#text(" (and surprising!) issue that arose in the MO question, namely that the LP solver decides an infeasible solution is feasible due to its rounding tolerance, cannot happen in our setting. That is because all of the coefficients and variables are (small) integers, and there’s no rounding issue verifying it! Besides the separate ways in which we verify our LP results, this is a concrete sense in which our LPs are more well-behaved.")

#text("But thank you very much for linking to the MO question! I use linear programs often in my research (and then almost always verify the results in another way), and it’s nice to know which particular errors can arise. That one is particularly glaring.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/831da2ac9da5ea6418bf957c4fc82d3790b4d9c02e085a2b9a46a28caec3335f-ad5527be1bed9dd628fa60a6bf06cf3c5396f65d761d29db1c0b25ac0d1736a0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Guy-Selfridge Conjecture – Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688266")[#strong[#text("The Guy-Selfridge Conjecture – Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("[…] was a fun project! I encourage interested readers to check out the original post, as well as the follow-up post discussing the improved […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2025")])]

#text("“products of 2 and 3” -> “products of powers of 2 and 3”?")

#emph[#text("[Here I am implicitly permitting repetitions of factors. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d36763c476b561d1a41bc1b6f7d952ff15e8033376c25da8481a6e9e5d035cb-ad4607aef876d028a5f2929482e96437382cdf56e8d75c84382964286e6f4a8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Persich")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-688370")[#strong[#text("Stefan Persich")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2025")])]

#text("Really enjoying this line of work – especially how the asymptotic behavior around the N/e barrier is emerging from increasingly refined constructions.")

#text("One potentially useful variation: rather than factoring ")#raw("N!")#text(" globally, have you ever tried splitting it into multiplicative blocks of size about ")#raw("N / log N")#text(", and within each block, construct products from large factors only (say ≥ ")#raw("sqrt(N)")#text("), optimizing locally. This seems to reduce the rounding inefficiencies that arise in the greedy 2–3 rearrangements.")

#text("In my simulations up to ")#raw("N = 20,000")#text(", this block-based method consistently improves the total count ")#raw("t(N)")#text(" by around ")#strong[#text("0.5–1.5%")]#text(", with better scaling as ")#raw("N")#text(" increases. It might offer a cleaner asymptotic route toward saturating the ")#raw("N/e")#text(" limit.")

#text("Would be interesting to hear if you’ve explored something similar—or if this strategy could blend with your entropy-based or rearrangement heuristics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Growth rates of sequences governed by the squarefree properties of its translates | What's new")]], [#link("https://terrytao.wordpress.com/2025/06/03/decomposing-a-factorial-into-large-factors-second-version/#comment-689191")[#strong[#text("Growth rates of sequences governed by the squarefree properties of its translates | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2025")])]

#text("[…] However, we do not currently have enough numerical data for the sequence to completely confirm the conjecture in all cases. This could potentially be a crowdsourced project (similar to the Erdős-Guy-Selfridge project reported on in this previous blog post). […]")
]
