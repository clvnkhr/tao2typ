// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:19.991644+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Erdos-Ulam problem, varieties of general type, and the Bombieri-Lang conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Erdos-Ulam problem, varieties of general type, and the Bombieri-Lang conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 December 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/")[#text("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In 1946, Ulam, in response to a ")#link("http://www.ams.org/mathscinet-getitem?mr=13511")[#text("theorem of Anning and Erdös")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=890232")[#text("posed the following problem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Erdös-Ulam problem)")]#text(" Let ")#mi("{S \\subset {\\bf R}^2}")#text(" be a set such that the distance between any two points in ")#mi("{S}")#text(" is rational. Is it true that ")#mi("{S}")#text(" cannot be (topologically) dense in ")#mi("{{\\bf R}^2}")#text("?")
]

#text("The paper of Anning and Erdös addressed the case that all the distances between two points in ")#mi("{S}")#text(" were integer rather than rational in the affirmative.")

#text("The Erdös-Ulam problem remains open; it was discussed recently over at ")#link("http://rjlipton.wordpress.com/2014/11/08/a-conjecture-of-ulam/")[#text("Gödel’s lost letter")]#text(". It is in fact likely (as we shall see below) that the set ")#mi("{S}")#text(" in the above problem is not only forbidden to be topologically dense, but also cannot be Zariski dense either. If so, then the structure of ")#mi("{S}")#text(" is quite restricted; it was ")#link("http://www.ams.org/mathscinet-getitem?mr=2579704")[#text("shown by Solymosi and de Zeeuw")]#text(" that if ")#mi("{S}")#text(" fails to be Zariski dense, then all but finitely many of the points of ")#mi("{S}")#text(" must lie on a single line, or a single circle. (Conversely, it is easy to construct examples of dense subsets of a line or circle in which all distances are rational, though in the latter case the square of the radius of the circle must also be rational.)")

#text("The main tool of the Solymosi-de Zeeuw analysis was ")#link("http://en.wikipedia.org/wiki/Faltings%27s_theorem#039.3Bs_theorem")[#text("Faltings’ celebrated theorem")]#text(" that every algebraic curve of genus at least two contains only finitely many rational points. The purpose of this post is to observe that an affirmative answer to the full Erdös-Ulam problem similarly follows from the conjectured analogue of Falting’s theorem for surfaces, namely the following conjecture of ")#link("http://www.ams.org/mathscinet-getitem?mr=715605")[#text("Bombieri and Lang")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Bombieri-Lang conjecture)")]#text(" ")#metadata(none) <tao-29d9489564c875d73110>#text(" Let ")#mi("{X}")#text(" be a smooth projective irreducible algebraic surface defined over the rationals ")#mi("{{\\bf Q}}")#text(" which is of ")#link("http://en.wikipedia.org/wiki/Kodaira_dimension#General_type")[#text("general type")]#text(". Then the set ")#mi("{X({\\bf Q})}")#text(" of rational points of ")#mi("{X}")#text(" is not Zariski dense in ")#mi("{X}")#text(".")
]

#text("In fact, the Bombieri-Lang conjecture has been made for varieties of arbitrary dimension, and for more general number fields than the rationals, but the above special case of the conjecture is the only one needed for this application. We will review what “general type” means (for smooth projective complex varieties, at least) below the fold.")

#text("The Bombieri-Lang conjecture is considered to be extremely difficult, in particular being substantially harder than Faltings’ theorem, which is itself a highly non-trivial result. So this implication should not be viewed as a practical route to resolving the Erdös-Ulam problem unconditionally; rather, it is a demonstration of the power of the Bombieri-Lang conjecture. Still, it was an instructive algebraic geometry exercise for me to carry out the details of this implication, which quickly boils down to verifying that a certain quite explicit algebraic surface is of general type (Theorem ")#link(<tao-0feae16d55365acf07fe>)[#text("4")]#text(" below). As I am not an expert in the subject, my computations here will be rather tedious and pedestrian; it is likely that they could be made much slicker by exploiting more of the machinery of modern algebraic geometry, and I would welcome any such streamlining by actual experts in this area. (For similar reasons, there may be more typos and errors than usual in this post; corrections are welcome as always.) My calculations here are based on a similar calculation ")#link("http://www.math.leidenuniv.nl/~rvl/ps/cuboids.pdf")[#text("of van Luijk")]#text(", who used analogous arguments to show (assuming Bombieri-Lang) that the set of ")#link("http://en.wikipedia.org/wiki/Euler_brick#Perfect_cuboid")[#text("perfect cuboids")]#text(" is not Zariski-dense in its projective parameter space.")

#text("We also remark that in ")#link("http://www.ams.org/mathscinet-getitem?mr=2891094")[#text("a recent paper of Makhul and Shaffaf")]#text(", the Bombieri-Lang conjecture (or more precisely, a weaker consequence of that conjecture) was used to show that if ")#mi("{S}")#text(" is a subset of ")#mi("{{\\bf R}^2}")#text(" with rational distances which intersects any line in only finitely many points, then there is a uniform bound on the cardinality of the intersection of ")#mi("{S}")#text(" with any line. I have also recently learned (private communication) that an unpublished work of Shaffaf has obtained a result similar to the one in this post, namely that the Erdös-Ulam conjecture follows from the Bombieri-Lang conjecture, plus an additional conjecture about the rational curves in a specific surface.")

#text("Let us now give the elementary reductions to the claim that a certain variety is of general type. For sake of contradiction, let ")#mi("{S}")#text(" be a dense set such that the distance between any two points is rational. Then ")#mi("{S}")#text(" certainly contains two points that are a rational distance apart. By applying a translation, rotation, and a (rational) dilation, we may assume that these two points are ")#mi("{(0,0)}")#text(" and ")#mi("{(1,0)}")#text(". As ")#mi("{S}")#text(" is dense, there is a third point of ")#mi("{S}")#text(" not on the ")#mi("{x}")#text(" axis, which after a reflection we can place in the upper half-plane; we will write it as ")#mi("{(a,\\sqrt{b})}")#text(" with ")#mi("{b>0}")#text(".")

#text("Given any two points ")#mi("{P, Q}")#text(" in ")#mi("{S}")#text(", the quantities ")#tao-math("{\\left|P\\right|^2, \\left|Q\\right|^2, \\left|P-Q\\right|^2}", block: false)#text(" are rational, and so by the cosine rule the dot product ")#mi("{P \\cdot Q}")#text(" is rational as well. Since ")#mi("{(1,0) \\in S}")#text(", this implies that the ")#mi("{x}")#text("-component of every point ")#mi("{P}")#text(" in ")#mi("{S}")#text(" is rational; this in turn implies that the product of the ")#mi("{y}")#text("-coordinates of any two points ")#mi("{P,Q}")#text(" in ")#mi("{S}")#text(" is rational as well (since this differs from ")#mi("{P \\cdot Q}")#text(" by a rational number). In particular, ")#mi("{a}")#text(" and ")#mi("{b}")#text(" are rational, and all of the points in ")#mi("{S}")#text(" now lie in the lattice ")#mi("{\\{ ( x, y\\sqrt{b}): x, y \\in {\\bf Q} \\}}")#text(". (This fact appears to have first been observed in the 1988 habilitationschrift of Kemnitz.)")

#text("Now take four points ")#mi("{(x_j,y_j \\sqrt{b})}")#text(", ")#mi("{j=1,\\dots,4}")#text(" in ")#mi("{S}")#text(" in general position (so that the octuplet ")#mi("{(x_1,y_1\\sqrt{b},\\dots,x_4,y_4\\sqrt{b})}")#text(" avoids any pre-specified hypersurface in ")#mi("{{\\bf C}^8}")#text("); this can be done if ")#mi("{S}")#text(" is dense. (If one wished, one could re-use the three previous points ")#mi("{(0,0), (1,0), (a,\\sqrt{b})}")#text(" to be three of these four points, although this ultimately makes little difference to the analysis.) If ")#mi("{(x,y\\sqrt{b})}")#text(" is any point in ")#mi("{S}")#text(", then the distances ")#mi("{r_j}")#text(" from ")#mi("{(x,y\\sqrt{b})}")#text(" to ")#mi("{(x_j,y_j\\sqrt{b})}")#text(" are rationals that obey the equations")

#align(center)[#tao-fit-display[#mitex("(x - x_j)^2 + b (y-y_j)^2 = r_j^2")]]

#text("for ")#mi("{j=1,\\dots,4}")#text(", and thus determine a rational point in the affine complex variety ")#mi("{V = V_{b,x_1,y_1,x_2,y_2,x_3,y_3,x_4,y_4} \\subset {\\bf C}^5}")#text(" defined as")

#tao-aligned(keep: true)[


#tao-math("V  & := \\{ (x,y,r_1,r_2,r_3,r_4) \\in {\\bf C}^6:", block: true)



#tao-math("(x - x_j)^2 + b (y-y_j)^2  & = r_j^2 \\text{ for } j=1,\\dots,4 \\}.", block: true)
]

#text("By inspecting the projection ")#mi("{(x,y,r_1,r_2,r_3,r_4) \\rightarrow (x,y)}")#text(" from ")#mi("{V}")#text(" to ")#mi("{{\\bf C}^2}")#text(", we see that ")#mi("{V}")#text(" is a branched cover of ")#mi("{{\\bf C}^2}")#text(", with the generic cover having ")#mi("{2^4=16}")#text(" points (coming from the different ways to form the square roots ")#mi("{r_1,r_2,r_3,r_4}")#text("); in particular, ")#mi("{V}")#text(" is a complex affine algebraic surface, defined over the rationals. By inspecting the monodromy around the four singular base points ")#mi("{(x,y) = (x_i,y_i)}")#text(" (which switch the sign of one of the roots ")#mi("{r_i}")#text(", while keeping the other three roots unchanged), we see that the variety ")#mi("{V}")#text(" is connected away from its singular set, and thus irreducible. As ")#mi("{S}")#text(" is topologically dense in ")#mi("{{\\bf R}^2}")#text(", it is Zariski-dense in ")#mi("{{\\bf C}^2}")#text(", and so ")#mi("{S}")#text(" generates a Zariski-dense set of rational points in ")#mi("{V}")#text(". To solve the Erdös-Ulam problem, it thus suffices to show that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Claim 3")]#text(" ")#metadata(none) <tao-24fe93c9e17cb80452e5>#text(" For any non-zero rational ")#mi("{b}")#text(" and for rationals ")#mi("{x_1,y_1,x_2,y_2,x_3,y_3,x_4,y_4}")#text(" in general position, the rational points of the affine surface ")#mi("{V = V_{b,x_1,y_1,x_2,y_2,x_3,y_3,x_4,y_4}}")#text(" is not Zariski dense in ")#mi("{V}")#text(".")
]

#text("This is already very close to a claim that can be directly resolved by the Bombieri-Lang conjecture, but ")#mi("{V}")#text(" is affine rather than projective, and also contains some singularities. The first issue is easy to deal with, by working with the projectivisation ")#metadata(none) <tao-6551fb9688a72df03112>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\overline{V} := \\{ [X,Y,Z,R_1,R_2,R_3,R_4] \\in {\\bf CP}^6: Q(X,Y,Z,R_1,R_2,R_3,R_4) = 0 \\}")]]



#text(" of ")#mi("{V}")#text(", where ")#mi("{Q: {\\bf C}^7 \\rightarrow {\\bf C}^4}")#text(" is the homogeneous quadratic polynomial")

#align(center)[#tao-fit-display[#mitex("(X,Y,Z,R_1,R_2,R_3,R_4) := (Q_j(X,Y,Z,R_1,R_2,R_3,R_4) )_{j=1}^4")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("Q_j(X,Y,Z,R_1,R_2,R_3,R_4) := (X-x_j Z)^2 + b (Y-y_jZ)^2 - R_j^2")]]

#text("and the projective complex space ")#mi("{{\\bf CP}^6}")#text(" is the space of all equivalence classes ")#mi("{[X,Y,Z,R_1,R_2,R_3,R_4]}")#text(" of tuples ")#mi("{(X,Y,Z,R_1,R_2,R_3,R_4) \\in {\\bf C}^7 \\backslash \\{0\\}}")#text(" up to projective equivalence ")#mi("{(\\lambda X, \\lambda Y, \\lambda Z, \\lambda R_1, \\lambda R_2, \\lambda R_3, \\lambda R_4) \\sim (X,Y,Z,R_1,R_2,R_3,R_4)}")#text(". By identifying the affine point ")#mi("{(x,y,r_1,r_2,r_3,r_4)}")#text(" with the projective point ")#mi("{(X,Y,1,R_1,R_2,R_3,R_4)}")#text(", we see that ")#mi("{\\overline{V}}")#text(" consists of the affine variety ")#mi("{V}")#text(" together with the set ")#mi("{\\{ [X,Y,0,R_1,R_2,R_3,R_4]: X^2+bY^2=R^2; R_j = \\pm R_1 \\text{ for } j=2,3,4\\}}")#text(", which is the union of eight curves, each of which lies in the closure of ")#mi("{V}")#text(". Thus ")#mi("{\\overline{V}}")#text(" is the projective closure of ")#mi("{V}")#text(", and is thus a complex irreducible projective surface, defined over the rationals. As ")#mi("{\\overline{V}}")#text(" is cut out by four quadric equations in ")#mi("{{\\bf CP}^6}")#text(" and has degree sixteen (as can be seen for instance by inspecting the intersection of ")#mi("{\\overline{V}}")#text(" with a generic perturbation of a fibre over the generically defined projection ")#mi("{[X,Y,Z,R_1,R_2,R_3,R_4] \\mapsto [X,Y,Z]}")#text("), it is also a ")#link("http://en.wikipedia.org/wiki/Complete_intersection")[#text("complete intersection")]#text(". To show ")#link(<tao-24fe93c9e17cb80452e5>)[#text("(3)")]#text(", it then suffices to show that the rational points in ")#mi("{\\overline{V}}")#text(" are not Zariski dense in ")#mi("{\\overline{V}}")#text(".")

#text("Heuristically, the reason why we expect few rational points in ")#mi("{\\overline{V}}")#text(" is as follows. First observe from the projective nature of ")#link(<tao-6551fb9688a72df03112>)[#text("(1)")]#text(" that every rational point is equivalent to an integer point. But for a septuple ")#mi("{(X,Y,Z,R_1,R_2,R_3,R_4)}")#text(" of integers of size ")#mi("{O(N)}")#text(", the quantity ")#mi("{Q(X,Y,Z,R_1,R_2,R_3,R_4)}")#text(" is an integer point of ")#mi("{{\\bf Z}^4}")#text(" of size ")#mi("{O(N^2)}")#text(", and so should only vanish about ")#mi("{O(N^{-8})}")#text(" of the time. Hence the number of integer points ")#mi("{(X,Y,Z,R_1,R_2,R_3,R_4) \\in {\\bf Z}^7}")#text(" of height comparable to ")#mi("{N}")#text(" should be about")

#align(center)[#tao-fit-display[#mitex("O(N)^7 \\times O(N^{-8}) = O(N^{-1});")]]

#text("this is a convergent sum if ")#mi("{N}")#text(" ranges over (say) powers of two, and so from standard probabilistic heuristics (see ")#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")[#text("this previous post")]#text(") we in fact expect only finitely many solutions, in the absence of any special algebraic structure (e.g. the structure of an abelian variety, or a birational reduction to a simpler variety) that could produce an unusually large number of solutions.")

#text("The Bombieri-Lang conjecture, Conjecture ")#link(<tao-29d9489564c875d73110>)[#text("2")]#text(", can be viewed as a formalisation of the above heuristics (roughly speaking, it is one of the most optimistic natural conjectures one could make that is compatible with these heuristics while also being invariant under birational equivalence).")

#text("Unfortunately, ")#mi("{\\overline{V}}")#text(" contains some singular points. Being a complete intersection, this occurs when the Jacobian matrix of the map ")#mi("{Q: {\\bf C}^7 \\rightarrow {\\bf C}^4}")#text(" has less than full rank, or equivalently that the gradient vectors ")#metadata(none) <tao-e8f87812d444a11051fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\nabla Q_j = (2(X-x_j Z), 2(Y-y_j Z), -2x_j (X-x_j Z) - 2y_j (Y-y_j Z),")]]





#align(center)[#tao-fit-display[#mitex("0, \\dots, 0, -2R_j, 0, \\dots, 0)")]]

#text("for ")#mi("{j=1,\\dots,4}")#text(" are linearly dependent, where the ")#mi("{-2R_j}")#text(" is in the coordinate position associated to ")#mi("{R_j}")#text(". One way in which this can occur is if one of the gradient vectors ")#mi("{\\nabla Q_j}")#text(" vanish identically. This occurs at precisely ")#mi("{4 \\times 2^3 = 32}")#text(" points, when ")#mi("{[X,Y,Z]}")#text(" is equal to ")#mi("{[x_j,y_j,1]}")#text(" for some ")#mi("{j=1,\\dots,4}")#text(", and one has ")#mi("{R_k = \\pm ( (x_j - x_k)^2 + b (y_j - y_k)^2 )^{1/2}}")#text(" for all ")#mi("{k=1,\\dots,4}")#text(" (so in particular ")#mi("{R_j=0}")#text("). Let us refer to these as the ")#emph[#text("obvious")]#text(" singularities; they arise from the geometrically evident fact that the distance function ")#mi("{(x,y\\sqrt{b}) \\mapsto \\sqrt{(x-x_j)^2 + b(y-y_j)^2}}")#text(" is singular at ")#mi("{(x_j,y_j\\sqrt{b})}")#text(".")

#text("The other way in which could occur is if a non-trivial linear combination of at least two of the gradient vectors vanishes. From ")#link(<tao-e8f87812d444a11051fd>)[#text("(2)")]#text(", this can only occur if ")#mi("{R_j=R_k=0}")#text(" for some distinct ")#mi("{j,k}")#text(", which from ")#link(<tao-6551fb9688a72df03112>)[#text("(1)")]#text(" implies that ")#metadata(none) <tao-d5e463a13c774d56ebb5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(X - x_j Z) = \\pm \\sqrt{b} i (Y - y_j Z)")]]



#text(" and ")#metadata(none) <tao-839b49c4e3fd33b6200d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(X - x_k Z) = \\pm \\sqrt{b} i (Y - y_k Z)")]]



#text(" for two choices of sign ")#mi("{\\pm}")#text(". If the signs are equal, then (as ")#mi("{x_j, y_j, x_k, y_k}")#text(" are in general position) this implies that ")#mi("{Z=0}")#text(", and then we have the singular point ")#metadata(none) <tao-b9cc272cfc2456cfa99f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("[X,Y,Z,R_1,R_2,R_3,R_4] = [\\pm \\sqrt{b} i, 1, 0, 0, 0, 0, 0].")]]



#text(" If the non-trivial linear combination involved three or more gradient vectors, then by the pigeonhole principle at least two of the signs involved must be equal, and so the only singular points are ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(5)")]#text(". So the only remaining possibility is when we have two gradient vectors ")#mi("{\\nabla Q_j, \\nabla Q_k}")#text(" that are parallel but non-zero, with the signs in ")#link(<tao-d5e463a13c774d56ebb5>)[#text("(3)")]#text(", ")#link(<tao-839b49c4e3fd33b6200d>)[#text("(4)")]#text(" opposing. But then (as ")#mi("{x_j,y_j,x_k,y_k}")#text(" are in general position) the vectors ")#mi("{(X-x_j Z, Y-y_j Z), (X-x_k Z, Y-y_k Z)}")#text(" are non-zero and non-parallel to each other, a contradiction. Thus, outside of the ")#mi("{32}")#text(" obvious singular points mentioned earlier, the only other singular points are the two points ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(5)")]#text(".")

#text("We will shortly show that the ")#mi("{32}")#text(" obvious singularities are ")#emph[#text("ordinary double points")]#text("; the surface ")#mi("{\\overline{V}}")#text(" near any of these points is analytically equivalent to an ordinary cone ")#mi("{\\{ (x,y,z) \\in {\\bf C}^3: z^2 = x^2 + y^2 \\}}")#text(" near the origin, which is a cone over a smooth conic curve ")#mi("{\\{ (x,y) \\in {\\bf C}^2: x^2+y^2=1\\}}")#text(". The two non-obvious singularities ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(5)")]#text(" are slightly more complicated than ordinary double points, they are ")#emph[#text("elliptic singularities")]#text(", which approximately resemble a cone over an elliptic curve. (As far as I can tell, this resemblance is exact in the category of real smooth manifolds, but not in the category of algebraic varieties.) If one ")#link("http://en.wikipedia.org/wiki/Blowing_up")[#text("blows up")]#text(" each of the point singularities of ")#mi("{\\overline{V}}")#text(" separately, no further singularities are created, and one obtains a smooth projective surface ")#mi("{X}")#text(" (using the ")#link("http://en.wikipedia.org/wiki/Segre_embedding")[#text("Segre embedding")]#text(" as necessary to embed ")#mi("{X}")#text(" back into projective space, rather than in a product of projective spaces). Away from the singularities, the rational points of ")#mi("{\\overline{V}}")#text(" lift up to rational points of ")#mi("{X}")#text(". Assuming the Bombieri-Lang conjecture, we thus are able to answer the Erdös-Ulam problem in the affirmative once we establish")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-0feae16d55365acf07fe>#text(" The blowup ")#mi("{X}")#text(" of ")#mi("{\\overline{V}}")#text(" is of general type.")
]

#text("This will be done below the fold, by the pedestrian device of explicitly constructing global differential forms on ")#mi("{X}")#text("; I will also be working from a complex analysis viewpoint rather than an algebraic geometry viewpoint as I am more comfortable with the former approach. (As mentioned above, though, there may well be a quicker way to establish this result by using more sophisticated machinery.)")

#text("I thank Mark Green and David Gieseker for helpful conversations (and a crash course in varieties of general type!).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The above argument shows in fact (assuming Bombieri-Lang) that sets ")#mi("{S \\subset {\\bf R}^2}")#text(" with all distances rational cannot be Zariski-dense, and thus (by Solymosi-de Zeeuw) must lie on a single line or circle with only finitely many exceptions. Assuming a stronger version of Bombieri-Lang involving a general number field ")#mi("{K}")#text(", we obtain a similar conclusion with “rational” replaced by “lying in ")#mi("{K}")#text("” (one has to extend the Solymosi-de Zeeuw analysis to more general number fields, but this should be routine, using the analogue of Faltings’ theorem for such number fields).")
]

#metadata(none) <tao-4f3ee0419ea01c8dfcc3>

#heading(level: 1)[#strong[#text(" — 1. Singularities — ")]]

#text("Let us inspect the local behaviour of ")#mi("{\\overline{V}}")#text(" near an obvious singularity, when ")#mi("{[X,Y,Z]}")#text(" is close to ")#mi("{[x_j,y_j,1]}")#text(" for some ")#mi("{j}")#text(". We may normalise so that ")#mi("{j=1}")#text(" and ")#mi("{(x_j,y_j)=(0,0)}")#text(", and then we may use the affine chart ")#mi("{Z=1}")#text(", so that we are looking at the affine variety")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y,r_1,r_2,r_3,r_4) \\in {\\bf C}^6: (x-x_k)^2 + b(y-y_k)^2=r_k^2 \\text{ for } k=1,2,3,4\\}")]]

#text("for ")#mi("{(x,y)}")#text(" near ")#mi("{(0,0)}")#text(". Note that for ")#mi("{k \\neq j}")#text(", ")#mi("{(x-x_k)^2 + b(y-y_k)^2}")#text(" stays away from zero and so ")#mi("{r_k}")#text(" is a smooth branch of the square root of ")#mi("{(x-x_k)^2 + b(y-y_k)^2}")#text(" near an obvious singularity. Thus, up to an invertible analytic map, the local behaviour of ")#mi("{\\overline{V}}")#text(" near the obvious singularity is that of a cone")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y,r_1) \\in {\\bf C}^3: x^2 + by^2 = r^2 \\}.")]]

#text("Such a cone is blown up to the surface")

#align(center)[#tao-fit-display[#mitex("\\{ ((x,y,r_1), [P,Q,R]) \\in {\\bf C}^3 \\times {\\bf CP}^2: P^2+bQ^2 = R^2;")]]

#align(center)[#tao-fit-display[#mitex("(x,y,r_1) \\in \\overline{[P,Q,R]} \\}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\overline{[P,Q,R]} := \\{ (\\lambda P, \\lambda Q, \\lambda R): \\lambda \\in {\\bf C}\\}")]]

#text("is the closure of the equivalence class ")#mi("{[P,Q,R]}")#text(" in ")#mi("{{\\bf C}^3}")#text("; the origin ")#mi("{(0,0,0)}")#text(" blows up to the conic curve")

#align(center)[#tao-fit-display[#mitex("C := \\{ ((0,0,0), [P,Q,R]) \\in {\\bf C}^3 \\times {\\bf CP}^2: P^2 + bQ^2 = R^2 \\}")]]

#text("and the blowup locally looks (on the level of real smooth manifolds, at least) like the cylinder ")#mi("{{\\bf C} \\times C}")#text(". In particular, the blown up variety is smooth near the blowup of the original singularity.")

#text("Now we look at the behaviour of ")#mi("{\\overline{V}}")#text(" near a non-obvious singularity ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(5)")]#text("; for sake of discussion we work with the sign ")#mi("{\\pm = +}")#text(". Here the calculations are messier; unfortunately, I do not know of a slick way to avoid excessive computation. We use the affine chart ")#mi("{Y=1}")#text(" and write ")#mi("{X = \\sqrt{b} i + w}")#text(", then we are looking at the affine variety")

#align(center)[#tao-fit-display[#mitex("\\{ (w, z, r_1, r_2, r_3, r_4) \\in {\\bf C}^6:")]]

#align(center)[#tao-fit-display[#mitex("(\\sqrt{b} i + w - x_k z)^2 + b (1 - y_k z)^2 = r_k^2 \\text{ for } k=1,2,3,4\\}")]]

#text("for ")#mi("{(w, z, r_1, r_2, r_3, r_4)}")#text(" near ")#mi("{(0,0,0,0,0,0)}")#text(". We can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\{ (w, z, r_1, r_2, r_3, r_4) \\in {\\bf C}^6:")]]

#align(center)[#tao-fit-display[#mitex("2 \\sqrt{b} i w - (2 \\sqrt{b} i x_k + 2by_k) z = r_k^2 - (w-x_k z)^2 - b y_k^2 z^2 \\text{ for } k=1,2,3,4 \\}.")]]

#text("Using the ")#mi("{k=1,2}")#text(" equations, we can solve for ")#mi("{w}")#text(" and ")#mi("{z}")#text(" (using the general position of the ")#mi("{x_k,y_k}")#text(") to obtain equations of the form")

#tao-aligned(keep: true)[


#tao-math("w  & = \\alpha_1 r_1^2 + \\beta_1 r_2^2 + R_1( w, z )", block: true)



#tao-math("z  & = \\alpha_2 r_1^2 + \\beta_2 r_2^2 + R_2( w, z )", block: true)
]

#text("for some homogeneous quadratics ")#mi("{R_1,R_2: {\\bf C}^2 \\rightarrow {\\bf C}}")#text(" and complex coefficients ")#mi("{\\alpha_1,\\beta_1,\\alpha_2,\\beta_2 \\in {\\bf C}}")#text(" determined by the ")#mi("{x_k,y_k}")#text(". Substituting this into the ")#mi("{k=3,4}")#text(" equations we obtain equations of the form")

#tao-aligned(keep: true)[


#tao-math("r_3^2  & = \\alpha_3 r_1^2 + \\beta_3 r_2^2 + R_3( w, z )", block: true)



#tao-math("r_4^2  & = \\alpha_4 r_1^2 + \\beta_4 r_2^2 + R_4( w, z )", block: true)
]

#text("for some homogeneous quadratics ")#mi("{R_3,R_4: {\\bf C}^2 \\rightarrow {\\bf C}}")#text(" and complex coefficients ")#mi("{\\alpha_3,\\beta_3,\\alpha_4,\\beta_4 \\in {\\bf C}}")#text(" determined by the ")#mi("{x_k,y_k}")#text(". One can solve the first two equations by power series (or the inverse function theorem) for ")#mi("{r_1,r_2}")#text(" near zero to obtain an analytic representation")

#align(center)[#tao-fit-display[#mitex("w = F( r_1^2, r_2^2 ); \\quad z = G( r_1^2, r_2^2 )")]]

#text("for some functions ")#mi("{F, G: {\\bf C}^2 \\rightarrow {\\bf C}}")#text(" analytic near the origin with ")#mi("{F(0,0)=G(0,0)=0}")#text(". The second two equations then become")

#tao-aligned(keep: true)[


#tao-math("r_3^2  & = \\alpha_3 r_1^2 + \\beta_3 r_2^2 + H_3( r_1^2, r_2^2 )", block: true)



#tao-math("r_4^2  & = \\alpha_4 r_1^2 + \\beta_4 r_2^2 + H_4( r_1^2, r_2^2 )", block: true)
]

#text("for some functions ")#mi("{H_3,H_4: {\\bf C}^2 \\rightarrow {\\bf C}}")#text(" analytic near the origin that vanish to second order at ")#mi("{(0,0)}")#text(". Thus, near this non-obvious singularity, ")#mi("{\\overline{V}}")#text(" is analytically equivalent to the complex surface")

#align(center)[#tao-fit-display[#mitex("\\{ (r_1,r_2,r_3,r_4) \\in {\\bf C}^4: r_k^2 = \\alpha_k r_1^2 + \\beta_k r_2^2 + H_k(r_1^2,r_2^2) \\text{ for } k=3,4 \\}")]]

#text("near ")#mi("{(r_1,r_2,r_3,r_4)=(0,0,0,0)}")#text(".")

#text("It may be possible to simplify the surface further into an even better normal form, though I was unable to do so. Nevertheless, the current form is simple enough that one can understand the blowup (in the category of real smooth manifolds, at least), which in this case is")

#align(center)[#tao-fit-display[#mitex("\\{ (r_1,r_2,r_3,r_4) \\times [P_1,P_2,P_3,P_4] \\in {\\bf C}^4 \\times {\\bf CP}^3:")]]

#tao-aligned(keep: true)[


#tao-math("r_k^2  & = \\alpha_k r_1^2 + \\beta_k r_2^2 + H_k(r_1^2,r_2^2) \\text{ for } k=3,4;", block: true)



#tao-math("(r_1,r_2,r_3,r_4)  & \\in [P_1, P_2, P_3, P_4] \\},", block: true)
]

#text("or equivalently the three-dimensional manifold")

#align(center)[#tao-fit-display[#mitex("\\{ (t, P_1, P_2, P_3, P_4) \\in {\\bf C} \\times ({\\bf C}^4 \\backslash \\{0\\}):")]]

#align(center)[#tao-fit-display[#mitex("P_k^2 = \\alpha_k P_1^2 + \\beta_k P_2^2 + t^2 \\tilde H_k(P_1^2,P_2^2,t^2) \\text{ for } k=3,4 \\}")]]

#text("quotiented by the equivalence ")#mi("{(t,P_1,P_2,P_3,P_4) \\sim (\\lambda^{-1} t, \\lambda P_2, \\lambda P_3, \\lambda P_4)}")#text(", where ")#mi("{\\tilde H_k: {\\bf C}^3 \\rightarrow {\\bf C}}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\tilde H_k( p_1, p_2, s ) := s^{-2} H_k( s p_1, s p_2 ),")]]

#text("which is locally analytic near the origin. One can cover this manifold by the four affine charts ")#mi("{P_1=1, P_2=1, P_3=1, P_4=1}")#text(". For instance, the ")#mi("{P_1=1}")#text(" chart becomes the affine manifold")

#align(center)[#tao-fit-display[#mitex("\\{ (t, p_2,p_3,p_4) \\in {\\bf C}^4: p_k^2 = \\alpha_k p_1^2 + \\beta_k p_2^2 + t^2 \\tilde H_k(1,p_2^2,t^2) \\text{ for } k=3,4 \\}.")]]

#text("The point ")#mi("{(r_1,r_2,r_3,r_4) = (0,0,0,0)}")#text(" blows up to the curve ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\{ [P_1, P_2, P_3, P_4] \\in {\\bf CP}^3: P_k^2 = \\alpha_k P_1^2 + \\beta_k P_2^2 \\text{ for } k=3,4 \\},")]]



#text(" that is to say the intersection of two quadrics in ")#mi("{{\\bf CP}^3}")#text(". For ")#mi("{x_k,y_k}")#text(" generic, the vectors ")#mi("{(\\alpha_3, \\beta_3)}")#text(" and ")#mi("{(\\alpha_4,\\beta_4)}")#text(" are linearly independent, and one easily verifies that this is a smooth curve in ")#mi("{{\\bf CP}^3}")#text(", which by Bezout’s theorem is of degree four. If one projects from a point of this curve to a generic hyperplane, one obtains a smooth planar curve of degree three, that is to say an elliptic curve ")#mi("{C_3}")#text(". Thus, on the level of real smooth manifolds at least, the blowup of ")#mi("{\\overline{V}}")#text(" is equivalent to ")#mi("{{\\bf C} \\times C_3}")#text(", by the inverse function theorem; in particular, the blowup is smooth near the fibre of the original singularity.")

#text("To summarise, the blown up surface ")#mi("{X}")#text(" is smooth, with the obvious singularities blowing up to a conic curve ")#mi("{C}")#text(" with neighbourhood structure ")#mi("{{\\bf C} \\times C}")#text(", and the non-obvious singularities blowing up to an elliptic curve ")#mi("{C_3}")#text(" with neighbourhood structure ")#mi("{{\\bf C} \\times C_3}")#text(" (at the level of real smooth manifolds; I was not able to understand the complex or algebrai geometry structure properly).")

#heading(level: 1)[#strong[#text(" — 2. General type — ")]]

#text("Let ")#mi("{X}")#text(" be a smooth complex projective variety of some dimension ")#mi("{n}")#text(". The ")#link("http://en.wikipedia.org/wiki/Canonical_bundle")[#text("canonical bundle")]#text(" ")#mi("{\\bigwedge^n T^* X}")#text(" (also known as the ")#emph[#text("determinant bundle")]#text(") is then the top-dimensional exterior product of the cotangent bundle ")#mi("{T^* X}")#text(", thus sections of this bundle are holomorphic ")#mi("{n}")#text("-forms on ")#mi("{X}")#text(". Since the space of possible top-dimensional forms at a point is one-dimensional, this is a line bundle. One can also take higher powers ")#mi("{(\\bigwedge^n T^* X)^k}")#text(" of this bundle for any natural number ")#mi("{k}")#text(" to create further line bundles, known as ")#emph[#text("pluricanonical bundles")]#text("; sections of the pluricanonical bundle of order ")#mi("{k}")#text(" can then be locally represented as formal ")#mi("{k}")#text("-fold products of holomorphic ")#mi("{n}")#text("-forms.")

#text("For each pluricanonical bundle ")#mi("{(\\bigwedge^n T^* X)^k}")#text(", define ")#mi("{H^0(X, (\\bigwedge^n T^* X)^k)}")#text(" to be the space of global sections of this bundle; in particular, ")#mi("{H^0(X, \\bigwedge^n T^* X)}")#text(" is the space of globally holomorphic ")#mi("{n}")#text("-forms. It turns out (as can be proven for instance using compactness theorems such as ")#link("http://en.wikipedia.org/wiki/Montel%27s_theorem")[#text("Montel’s theorem")]#text(") that this space is always a finite-dimensional complex vector space; the global sections are also always algebraic (this follows from ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry_and_analytic_geometry")[#text("Serre’s GAGA paper")]#text(", but presumably can be derived from earlier results also). If the space has some positive dimension ")#mi("{d}")#text(" (that is, at least one non-trivial global section exists), we say that the bundle is ")#emph[#text("effective")]#text(", and then we can define an (almost everywhere defined) ")#emph[#text("pluricanonical map")]#text(" ")#mi("{f_k: X \\rightarrow {\\bf CP}^{k-1}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f_k(x) := [ \\phi_1(x), \\dots, \\phi_k(x) ]")]]

#text("where ")#mi("{\\phi_1,\\dots,\\phi_k}")#text(" is a complex basis for the space ")#mi("{H^0(X, \\bigwedge^n T^* X)}")#text("; note that this map can be undefined if the ")#mi("{\\phi_i}")#text(" all simultaneously vanish, but this is a measure zero set. The pluricanonical map is only defined up to choice of basis ")#mi("{\\phi_1,\\dots,\\phi_k}")#text(", but changing the basis only amounts to applying a projective linear transformation ")#mi("{T: {\\bf CP}^{k-1} \\rightarrow {\\bf CP}^{k-1}}")#text(" to ")#mi("{f_k(x)}")#text(". In particular, the image ")#mi("{f_k(X)}")#text(" of ")#mi("{X}")#text(" is well defined up to projective transformations. We refer to the ")#mi("{k=1}")#text(" case ")#mi("{f_1}")#text(" of the pluricanonical map (when it exists) as the ")#emph[#text("canonical map")]#text(".")

#text("The ")#link("http://en.wikipedia.org/wiki/Kodaira_dimension")[#text("Kodaira dimension")]#text(" of ")#mi("{X}")#text(" is then defined to be the maximum of the dimensions of ")#mi("{f_k(X)}")#text(" for all natural numbers ")#mi("{k}")#text(" with effective pluricanonical bundles, or ")#mi("{-1}")#text(" if no such ")#mi("{k}")#text(" exists (some authors use ")#mi("{-\\infty}")#text(" instead of ")#mi("{-1}")#text("). From the definition it is clear that the Kodaira dimension of ")#mi("{X}")#text(" is at most the dimension of ")#mi("{X}")#text(" as an algebraic variety (or as a complex manifold). The variety ")#mi("{X}")#text(" is said to be of ")#link("http://en.wikipedia.org/wiki/Kodaira_dimension#General_type")[#text("general type")]#text(" if the two dimensions are equal, that is to say that there is a pluricanonical map ")#mi("{f_k}")#text(" whose image has the same dimension as ")#mi("{X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" ")#metadata(none) <tao-e73c023a2e8e90349bb4>#text(" Suppose ")#mi("{X = {\\bf CP}^n}")#text(" is a projective space. On the one hand, an ")#mi("{n}")#text("-form on ")#mi("{X}")#text(" is an object ")#mi("{\\omega}")#text(" that assigns to each point ")#mi("{x \\in X}")#text(" an alternating ")#mi("{n}")#text("-form ")#mi("{(v_1,\\dots,v_n) \\mapsto \\omega_x(v_1,\\dots,v_n)}")#text(" from tangent vectors ")#mi("{v_1,\\dots,v_n \\in T_x X}")#text(" to complex numbers. But ")#mi("{X}")#text(" is the quotient of ")#mi("{{\\bf C}^{n+1} \\backslash \\{0\\}}")#text(" by dilations. Thus, one can also view the ")#mi("{n}")#text("-form ")#mi("{\\omega}")#text(" as a lifted object ")#mi("{\\tilde \\omega}")#text(" that assigns to each point ")#mi("{x \\in {\\bf C}^{n+1} \\backslash \\{0\\}}")#text(" an alternating ")#mi("{n}")#text("-form ")#mi("{(v_1,\\dots,v_n) \\mapsto \\tilde \\omega_x(v_1,\\dots,v_n)}")#text(" from complex vectors ")#mi("{v_1,\\dots,v_n \\in {\\bf C}^{n+1}}")#text(" to complex numbers, such that one has the vanishing property")

#align(center)[#tao-fit-display[#mitex("\\tilde \\omega_x( v_1, \\dots, v_n ) = 0")]]

#text("if any of the ")#mi("{v_i}")#text(" are a scalar multiple of ")#mi("{x}")#text(", as well as the scale invariance property")

#align(center)[#tao-fit-display[#mitex("\\tilde \\omega_{\\lambda x}( \\lambda v_1, \\dots, \\lambda v_n ) = \\tilde \\omega_x( v_1, \\dots, v_n )")]]

#text("for any ")#mi("{\\lambda \\in {\\bf C} \\backslash \\{0\\}}")#text(", or equivalently")

#align(center)[#tao-fit-display[#mitex("\\tilde \\omega_{\\lambda x} = \\lambda^{-n} \\tilde \\omega_x.")]]

#text("(This homogeneity of order ")#mi("{-n}")#text(", together with some calculations involving the changes of coordinate between the different affine patches of projective space, can be used to show that the canonical bundle is isomorphic to the line bundle ")#mi("{{\\mathcal O}(-n-1)}")#text(", the ")#mi("{(n+1)^{st}}")#text(" power of the ")#link("http://en.wikipedia.org/wiki/Tautological_line_bundle")[#text("tautological line bundle")]#text(" ")#mi("{{\\mathcal O}(-1)}")#text(".) In particular, if ")#mi("{\\omega}")#text(" is a globally holomorphic ")#mi("{n}")#text("-form, ")#mi("{v_1,\\dots,v_n \\in {\\bf C}^{n+1}}")#text(" are arbitrary vectors, and ")#mi("{P: {\\bf C}^{n+1} \\rightarrow {\\bf C}}")#text(" is an arbitrary homogeneous polynomial of degree ")#mi("{n}")#text(", then ")#mi("{x \\mapsto P(x) \\tilde \\omega_x(v_1,\\dots,v_n)}")#text(" is a holomorphic map from ")#mi("{{\\bf C}^{n+1} \\backslash \\{0\\}}")#text(" to ")#mi("{{\\bf C}}")#text(" which is dilation invariant, and thus descends to a holomorphic function on ")#mi("{{\\bf CP}^n}")#text(", which by Liouville’s theorem is then necessarily constant. By varying the polynomial ")#mi("{P}")#text(", this shows that ")#mi("{\\omega}")#text(" must vanish identically. Thus the canonical bundle here is not effective. A similar scaling argument shows that the pluricanonical bundles are not effective either, thus ")#mi("{{\\bf CP}^n}")#text(" has a Kodaira dimension of ")#mi("{-1}")#text(" (or ")#mi("{-\\infty}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" In the case of smooth projective algebraic curves, it turns out that genus zero curves like ")#mi("{{\\bf CP}^1}")#text(" have Kodaira dimension ")#mi("{-1}")#text(" (or ")#mi("{-\\infty}")#text("), genus one curves (such as elliptic curves) have Kodaira dimension zero, and higher genus curves have Kodaira dimension one and are thus of general type. This is basically a corollary of the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(". Intuitively, the more “holes” or other topologically interesting structure a variety ")#mi("{X}")#text(" has, the more opportunity there is for the canonical and pluricanonical bundles to have interesting global sections, and the more likely it becomes that the variety is of general type.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" As the name suggests, “most” varieties are expected to be of general type, with only a few “special” varieties being not of general type. In the case of curves, the special varieties are the genus zero and genus one curves. In the case of surfaces, the situation is analogous, but significantly more complicated, and is described by the ")#link("http://en.wikipedia.org/wiki/Enriques%E2%80%93Kodaira_classification")[#text("Enriques-Kodaira classification")]#text(". I don’t know the current level of understanding for higher dimensional varieties, but would imagine that the story becomes even more complicated than in the surface case.")
]

#heading(level: 1)[#strong[#text(" — 3. Constructing differential forms — ")]]

#text("To show that a smooth projective variety ")#mi("{X}")#text(" is of general type, it clearly suffices to locate enough global holomorphic ")#mi("{n}")#text("-forms that the canonical map has full dimension in its image. It is thus of interest to find ways to construct global holomorphic ")#mi("{n}")#text("-forms on such varieties.")

#text("Suppose first that we have a (possibly singular) complete intersection")

#align(center)[#tao-fit-display[#mitex("Y = \\{ x \\in {\\bf CP}^n: P_1(x) = \\dots = P_r(x) = 0 \\}")]]

#text("of codimension ")#mi("{r}")#text(" in ")#mi("{{\\bf CP}^n}")#text(", where ")#mi("{P_1,\\dots,P_r: {\\bf C}^{n+1} \\rightarrow {\\bf C}}")#text(" are homogeneous polynomials of degree ")#mi("{d_1,\\dots,d_r}")#text(" respectively. This variety can be viewed as the quotient of the quasiprojective variety")

#align(center)[#tao-fit-display[#mitex("\\tilde Y = \\{ x \\in {\\bf C}^{n+1}: P_1(x) = \\dots = P_r(x) = 0 \\} \\backslash \\{0\\}")]]

#text("by dilations. Similarly to Example ")#link(<tao-e73c023a2e8e90349bb4>)[#text("6")]#text(", an ")#mi("{n-r}")#text("-form ")#mi("{\\omega}")#text(" on ")#mi("{Y}")#text(" can then be identified with an ")#mi("{n-r}")#text("-form ")#mi("{\\tilde \\omega}")#text(" on ")#mi("{\\tilde Y}")#text(" obeying the vanishing condition ")#metadata(none) <tao-970b1897af0abab6127d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\tilde \\omega_x(v_1,\\dots,v_{n-r}) = 0")]]



#text(" whenever one of the ")#mi("{v_1,\\dots,v_{n-r}}")#text(" is parallel to ")#mi("{x}")#text(", as well as the scaling relationship ")#metadata(none) <tao-567cf013bf70f18fc5d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\tilde \\omega_{\\lambda x}(\\lambda v_1,\\dots,\\lambda v_{n-r}) = \\tilde \\omega_x(v_1,\\dots,v_{n-r})")]]



#text(" for any ")#mi("{\\lambda \\in {\\bf C} \\backslash \\{0\\}}")#text(".")

#text("To try to create such a form, we can start with the standard ")#mi("{n+1}")#text("-form")

#align(center)[#tao-fit-display[#mitex("(v_1,\\dots,v_{n+1}) \\mapsto \\text{det}( v_1, \\dots, v_{n+1} )")]]

#text("on ")#mi("{{\\bf C}^{n+1}}")#text(", and “divide” by the one-forms ")#mi("{dP_1, \\dots, dP_r}")#text(" to create a ")#mi("{n-r}")#text("-form ")#mi("{\\rho}")#text(" on ")#mi("{\\tilde Y}")#text(" by requiring that")

#align(center)[#tao-fit-display[#mitex("\\rho_x( v_1,\\dots,v_{n-r} ) \\text{det}( (dP)_x(v_{n-r+1}), \\dots, (dP)_x(v_n) ) = \\text{det}(v_1,\\dots,v_n,x)")]]

#text("for ")#mi("{x \\in \\tilde Y}")#text(", ")#mi("{v_1,\\dots,v_{n-r} \\in T_x \\tilde Y}")#text(", and ")#mi("{v_{n-r+1},\\dots,v_n \\in {\\bf C}^{n+1}}")#text(", where")

#align(center)[#tao-fit-display[#mitex("(dP)_x(v) := (v \\cdot \\nabla P_1(x), \\dots, v \\cdot \\nabla P_r(x)).")]]

#text("Away from the singularities of ")#mi("{\\tilde Y}")#text(", the determinant form ")#mi("{(v_{n-r+1},\\dots,v_n) \\mapsto \\text{det}( (dP)_x(v_{n-r+1}), \\dots, (dP)_x(v_n) )}")#text(" is non-degenerate (after quotienting out the ")#mi("{v_j}")#text(" by the tangent plane ")#mi("{T_x \\tilde Y}")#text(", on which this form clearly vanishes). As such, ")#mi("{\\rho_x}")#text(" is well-defined as a form on the smooth points of ")#mi("{\\tilde Y}")#text(". It also obeys the vanishing condition ")#link(<tao-970b1897af0abab6127d>)[#text("(7)")]#text(" when one of the ")#mi("{v_1,\\dots,v_{n-r}}")#text(" is parallel to ")#mi("{x}")#text(". However, it doesn’t necessarily obey the scaling relationship ")#link(<tao-567cf013bf70f18fc5d4>)[#text("(8)")]#text("; instead, one has")

#align(center)[#tao-fit-display[#mitex("\\rho_{\\lambda x}(\\lambda v_1,\\dots,\\lambda v_{n-r}) = \\lambda^{-m} \\rho_x(v_1,\\dots,v_{n-r})")]]

#text("for any ")#mi("{\\lambda \\in {\\bf C} \\backslash \\{0\\}}")#text(", where ")#mi("{m}")#text(" is the quantity")

#align(center)[#tao-fit-display[#mitex("m := d_1 + \\dots + d_r - n - 1.")]]

#text("Repeating the heuristic analysis in the introduction, we expect the number of integer points in ")#mi("{\\tilde Y}")#text(" of height ")#mi("{N}")#text(" to be ")#mi("{O( N^{-m} )}")#text(", so ")#mi("{m > 0}")#text(" should morally correspond to “general type” in some sense. This is reflected here by the ability, when ")#mi("{m>0}")#text(", to multiply ")#mi("{\\rho}")#text(" by an arbitrary homogeneous polynomial ")#mi("{P: {\\bf C}^{n+1} \\rightarrow {\\bf C}}")#text(" of degree ")#mi("{m}")#text(", leading to a form ")#mi("{P \\rho}")#text(" which does obey both ")#link(<tao-970b1897af0abab6127d>)[#text("(7)")]#text(" and ")#link(<tao-567cf013bf70f18fc5d4>)[#text("(8)")]#text(", and thus descends to an ")#mi("{n-r}")#text("-form defined on the smooth points of ")#mi("{Y}")#text(". This already shows that for ")#emph[#text("smooth")]#text(" complete intersections ")#mi("{Y}")#text(", one has general type whenever ")#mi("{m>0}")#text(" (because one can use ")#mi("{P}")#text(" of the form ")#mi("{P = Q x_i}")#text(", for ")#mi("{Q}")#text(" a fixed homogeneous polynomial of degree ")#mi("{m-1}")#text(" and ")#mi("{x_1,\\dots,x_{n+1}}")#text(" being the basis functions, to create a portion of the canonical map that is basically the tautological embedding of ")#mi("{Y}")#text(" to ")#mi("{{\\bf CP}^n}")#text("). (Indeed, this argument shows in this case that the canonical bundle on ")#mi("{Y}")#text(" is isomorphic to the pullback of ")#mi("{{\\mathcal O}(m)}")#text(" to ")#mi("{Y}")#text(".)")

#text("If ")#mi("{Y}")#text(" has singularities, then the situation is a bit more complicated; we have to pass to the blowup of ")#mi("{Y}")#text(", and the form ")#mi("{P\\rho}")#text(" may develop some singularities as one approaches the blown up fibres. For the specific blowup ")#mi("{X}")#text(" considered in Theorem ")#link(<tao-0feae16d55365acf07fe>)[#text("4")]#text(", though, it turns out that these singularities are removable, if we make ")#mi("{P}")#text(" vanish at the exceptional singular points ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(5)")]#text("; as there are only two such singular points, this will still give enough freedom in ")#mi("{P}")#text(" to make the canonical map have full dimension in the image.")

#text("We turn to the details. Starting with the complete intersection ")#mi("{\\overline{V}}")#text(" given by ")#link(<tao-6551fb9688a72df03112>)[#text("(1)")]#text(", we let ")#mi("{\\rho}")#text(" be the ")#mi("{2}")#text("-form on the smooth portion of the deprojectivised variety")

#align(center)[#tao-fit-display[#mitex("\\tilde{\\overline{V}} := \\{ (x,y,z,r_1,r_2,r_3,r_4) \\in {\\bf C}^7 \\backslash \\{0\\}: Q(x,y,z,r_1,r_2,r_3,r_4) = 0 \\}")]]

#text("defined by the above construction, thus")

#align(center)[#tao-fit-display[#mitex("\\rho_x( v_1, v_2 ) \\text{det}( (dQ)_x(v_3), (dQ)_x(v_4), (dQ)_x(v_5), (dQ)_x(v_6) )")]]

#align(center)[#tao-fit-display[#mitex("= \\text{det}(v_1,\\dots,v_6,x)")]]

#text("for ")#mi("{x}")#text(" a smooth point of ")#mi("{\\tilde{\\overline{V}}}")#text(", ")#mi("{v_1,v_2 \\in T_x \\overline{V}}")#text(", and ")#mi("{v_3,\\dots,v_6 \\in {\\bf C}^7}")#text(". In this case, ")#mi("{n=6}")#text(", ")#mi("{r=4}")#text(", and ")#mi("{d_1=\\dots=d_4=2}")#text(", so ")#mi("{m = 1}")#text(", and so for any linear function ")#mi("{L: {\\bf C}^7 \\rightarrow {\\bf C}}")#text(", the form ")#mi("{L \\rho}")#text(" descends to a ")#mi("{2}")#text("-form on the smooth portion of ")#mi("{\\overline{V}}")#text(", which then lifts to a ")#mi("{2}")#text("-form on the blown up variety ")#mi("{X}")#text(" except possibly at the exceptional fibres above each of the singular points of ")#mi("{\\overline{V}}")#text(".")

#text("We now claim that this ")#mi("{2}")#text("-form on ")#mi("{X}")#text(" can be smoothly continued to each of the fibres if the linear function ")#mi("{L}")#text(" vanishes at the two exceptional points ")#link(<tao-b9cc272cfc2456cfa99f>)[#text("(5)")]#text(", or equivalently that ")#mi("{L(x,y,z,r_1,r_2,r_3,r_4)}")#text(" is a linear combination of the coefficients ")#mi("{z,r_1,r_2,r_3,r_4}")#text(". Let us first verify this for an obvious singular point. As before, we normalise ")#mi("{j=1}")#text(" and ")#mi("{(x_j,y_j)=(0,0)}")#text(", and take the affine chart ")#mi("{Z=1}")#text(", then ")#mi("{\\overline{V}}")#text(" is locally described by the affine variety")

#align(center)[#tao-fit-display[#mitex("W := \\{ (x,y,r_1,r_2,r_3,r_4): (x-x_k)^2 + b(y-y_k)^2=r_k^2 \\text{ for } k=1,2,3,4\\},")]]

#text("where as usual we identify ")#mi("{(x,y,r_1,r_2,r_3,r_4)}")#text(" with ")#mi("{[x,y,1,r_1,r_2,r_3,r_4]}")#text(", and the form ")#mi("{L\\rho}")#text(" restricted to this affine variety takes the form ")#metadata(none) <tao-3e7085367457fdba220d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("L\\rho_{\\vec x}(v_1,v_2) \\text{det}( (dQ)_{\\vec x}(v_3), (dQ)_{\\vec x}(v_4), (dQ)_{\\vec x}(v_5), (dQ)_{\\vec x}(v_6) )")]]





#align(center)[#tao-fit-display[#mitex("= L(\\vec x) \\text{det}(v_1,\\dots,v_6)")]]

#text("for ")#mi("{\\vec x \\in W}")#text(", ")#mi("{v_1,v_2 \\in T_x W}")#text(", and ")#mi("{v_3,v_4,v_5,v_6 \\in {\\bf C}^6}")#text(". In particular, taking ")#mi("{v_j = e_j}")#text(" for ")#mi("{j=3,4,5,6}")#text(", where ")#mi("{e_1,\\dots,e_6}")#text(" is the standard basis, we have")

#align(center)[#tao-fit-display[#mitex("L\\rho_{\\vec x}(v_1,v_2) = L(\\vec x) \\frac{dx(v_1) dy(v_2) - dx(v_1) dy(v_2)}{\\text{det}( \\frac{\\partial Q}{\\partial r_1}(\\vec x),\\dots,\\frac{\\partial Q}{\\partial r_4}(\\vec x) )}")]]

#text("whenever the denominator is non-zero, where ")#mi("{dx}")#text(" is the one-form on ")#mi("{\\overline{V}}")#text(" that sends a tangent vector ")#mi("{v}")#text(" to its ")#mi("{x}")#text(" component ")#mi("{v_x}")#text(", and similarly for ")#mi("{dy}")#text(", ")#mi("{dr_1}")#text(", etc. Using the notation of ")#link("http://en.wikipedia.org/wiki/Exterior_algebra")[#text("wedge product")]#text(" ")#mi("{\\wedge}")#text(", we can write this as")

#align(center)[#tao-fit-display[#mitex("L\\rho = L \\frac{dx \\wedge dy}{\\text{det}( \\frac{\\partial Q}{\\partial r_1},\\dots,\\frac{\\partial Q}{\\partial r_4} )}.")]]

#text("Using ")#link(<tao-e8f87812d444a11051fd>)[#text("(2)")]#text(", we compute that")

#align(center)[#tao-fit-display[#mitex("\\text{det}( \\frac{\\partial Q}{\\partial r_1},\\dots,\\frac{\\partial Q}{\\partial r_4}) = 16 r_1 r_2 r_3 r_4.")]]

#text("The quantities ")#mi("{r_2,r_3,r_4}")#text(" are bounded away from zero near the singularity, and ")#mi("{L}")#text(" is also bounded. Thus we have ")#metadata(none) <tao-3bfc269594ef649228e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("L\\rho = O( \\frac{dx \\wedge dy}{r_1} )")]]



#text(" near the singularity, where we write ")#mi("{\\rho = O( \\omega )}")#text(" for ")#mi("{2}")#text("-forms ")#mi("{\\rho,\\omega}")#text(" to denote the assertion that ")#mi("{\\rho = f \\omega}")#text(" for some scalar function that is bounded near the singularity.")

#text("At first glance, it looks like this form ")#mi("{L\\rho}")#text(" could blow up whenever ")#mi("{r_1}")#text(" vanishes, but this does not actually happen as the numerator will also vanish in that case. One can see this by using a different choice of ")#mi("{v_j}")#text(" for ")#mi("{j=3,4,5,6}")#text(" in ")#link(<tao-3e7085367457fdba220d>)[#text("(9)")]#text(". For instance, if one takes ")#mi("{v_3}")#text(" to be ")#mi("{e_2}")#text(" rather than ")#mi("{e_3}")#text(", then we get")

#align(center)[#tao-fit-display[#mitex("L\\rho = -L\\frac{dx \\wedge dr_1}{\\text{det}( \\frac{\\partial Q}{\\partial y},\\dots,\\frac{\\partial Q}{\\partial r_4})}")]]

#text("and now")

#align(center)[#tao-fit-display[#mitex("\\text{det}( \\frac{\\partial Q}{\\partial y},\\dots,\\frac{\\partial Q}{\\partial r_4} ) = - 16 y r_2 r_3 r_4")]]

#text("so we obtain an alternate form ")#metadata(none) <tao-8413524bebcb6e67bf21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("L\\rho = O( \\frac{dx \\wedge dr_1}{y} )")]]



#text(" for ")#mi("{L\\rho}")#text("; similarly ")#metadata(none) <tao-fb04dcb6970e4c3d1873>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("L\\rho = O( \\frac{dy \\wedge dr_1}{x} ).")]]



#text(" One can also see the equivalence of ")#link(<tao-3bfc269594ef649228e9>)[#text("(10)")]#text(", ")#link(<tao-8413524bebcb6e67bf21>)[#text("(11)")]#text(", ")#link(<tao-fb04dcb6970e4c3d1873>)[#text("(12)")]#text(" by noting that ")#mi("{Q_1 = x^2 + by^2 - r_1^2}")#text(" vanishes on ")#mi("{\\overline{V}}")#text(", which on differentiating yields the linear dependence")

#align(center)[#tao-fit-display[#mitex("2x dx + 2by dy - 2r_1 dr_1 = 0")]]

#text("between the ")#mi("{1}")#text("-forms ")#mi("{dx, dy, dr_1}")#text(", which can then easily be used to relate ")#link(<tao-3bfc269594ef649228e9>)[#text("(10)")]#text(", ")#link(<tao-8413524bebcb6e67bf21>)[#text("(11)")]#text(", ")#link(<tao-fb04dcb6970e4c3d1873>)[#text("(12)")]#text(" to each other.")

#text("Thus the only actual singularity that could occur here is when ")#mi("{x,y,r_1}")#text(" all vanish. However, it turns out that even here the singularity is removable after blowing up the surface. Recall that the blowup surface ")#mi("{X}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\{ ((x,y,r_1), [P,Q,R]) \\in {\\bf C}^3 \\times {\\bf CP}^2:")]]

#align(center)[#tao-fit-display[#mitex("P^2+bQ^2 = R^2; (x,y,r_1) \\in \\overline{[P,Q,R]} \\}.")]]

#text("We pick an affine chart of this surface; for sake of argument we take the ")#mi("{Q=1}")#text(" chart, as the other charts ")#mi("{P=1,R=1}")#text(" are treated similarly. Then the surface can be expressed as")

#align(center)[#tao-fit-display[#mitex("\\{ (t,p,r) \\in {\\bf C}^3: p^2 + b = r^2 \\}")]]

#text("with ")#mi("{(x,y,r_1) = (tp, t, tr)}")#text(". In particular,")

#align(center)[#tao-fit-display[#mitex("dx = p dt + t dp; \\quad dr_1 = t dr_1 + r_1 dt")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("dx \\wedge dr_1 = tp dt \\wedge dr_1 + t^2 dp \\wedge dr_1 + t r_1 dp \\wedge dt.")]]

#text("The key point is that there is a common factor of ")#mi("{t}")#text(" here. Using ")#link(<tao-8413524bebcb6e67bf21>)[#text("(11)")]#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("L\\rho = O( p dt \\wedge dr_1 + t dp \\wedge dr_1 + r_1 dp \\wedge dt )")]]

#text("and so ")#mi("{L\\rho}")#text(" does not blow up in the coordinates of ")#mi("{X}")#text(" as ")#mi("{t}")#text(" approaches ")#mi("{0}")#text(". By Riemann’s theorem, (the pullback of) ")#mi("{L\\rho}")#text(" can thus be extended holomorphically to the exceptional fibre ")#mi("{t=0}")#text(".")

#text("Now we look at the behaviour near a non-obvious singularity; for sake of argument we look at the neighbourhood of")

#align(center)[#tao-fit-display[#mitex("[X,Y,Z,R_1,R_2,R_3,R_4] = [\\sqrt{b} i, 1, 0, 0, 0, 0, 0].")]]

#text("As before, we use the affine chart ")#mi("{Y=1}")#text(" and write ")#mi("{X = \\sqrt{b} i + w}")#text(", then we are looking at the affine variety")

#align(center)[#tao-fit-display[#mitex("W := \\{ (w, z, r_1, r_2, r_3, r_4) \\in {\\bf C}^6: S(w,z,r_1,r_2,r_3,r_4) = 0 \\}")]]

#text("near ")#mi("{(0,0,0,0,0,0)}")#text(", where ")#mi("{S: {\\bf C}^6 \\rightarrow {\\bf C}^4}")#text(" is the system ")#mi("{S = (S_1,S_2,S_3,S_4)}")#text(" of quadratic polynomials")

#align(center)[#tao-fit-display[#mitex("S_k(w,z,r_1,r_2,r_3,r_4) := 2 \\sqrt{b} i w - (2 \\sqrt{b} i x_k + 2by_k) z - r_k^2 + (w-x_k z)^2 + b y_k^2 z^2.")]]

#text("Applying a change of variables, we have ")#metadata(none) <tao-493ea0b6bae201e248b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("L \\rho_{\\vec x}(v_1,v_2) = C L(\\vec x) \\frac{\\text{det}(v_1,\\dots,v_6)}{\\text{det}( (dS)_{\\vec x}(v_3), \\dots, (dS)_{\\vec x}(v_6) )}")]]



#text(" for ")#mi("{\\vec x \\in W}")#text(", ")#mi("{v_1, v_2 \\in T_x W}")#text(", and ")#mi("{v_3,v_4,v_5,v_6 \\in {\\bf C}^6}")#text(", and some harmless constant ")#mi("{C}")#text(" (depending on ")#mi("{b}")#text("). As before, if we set ")#mi("{v_j = e_j}")#text(" for ")#mi("{j=3,4,5,6}")#text(", we arrive at ")#metadata(none) <tao-b710b9e75ab48f4f69b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("L\\rho = O( L \\frac{dw \\wedge dz}{r_1 r_2 r_3 r_4} )")]]



#text(" when the denominator is non-zero. Similarly ")#metadata(none) <tao-b701704bc5b8738cd1ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("L\\rho = O( L \\frac{dw \\wedge dr_1}{\\frac{\\partial S_1}{\\partial z} r_2 r_3 r_4} )")]]



#text(" and")

#align(center)[#tao-fit-display[#mitex("L\\rho = O( L \\frac{dz \\wedge dr_1}{\\frac{\\partial S_1}{\\partial w} r_2 r_3 r_4} )")]]

#text("when the denominators are non-zero. Similarly for permutations of the ")#mi("{1,2,3,4}")#text(" indices.")

#text("Now, we lift ")#mi("{L \\rho}")#text(" to the blowup manifold")

#align(center)[#tao-fit-display[#mitex("\\{ (r_1,r_2,r_3,r_4) \\times [P_1,P_2,P_3,P_4] \\in {\\bf C}^4 \\times {\\bf CP}^3:")]]

#tao-aligned(keep: true)[


#tao-math("r_k^2  & = \\alpha_k r_1^2 + \\beta_k r_2^2 + H_k(r_1^2,r_2^2) \\text{ for } k=3,4;", block: true)



#tao-math("(r_1,r_2,r_3,r_4)  & \\in \\overline{[P_1, P_2, P_3, P_4]} \\}.", block: true)
]

#text("For sake of discussion we work in the affine chart ")#mi("{P_3=1}")#text(" (say) and write ")#mi("{(r_1,r_2,r_3,r_4) = t(P_1,P_2,P_3,P_4)}")#text(", in which case the manifold becomes")

#align(center)[#tao-fit-display[#mitex("\\{ (t,p_1,p_2,p_4) \\in {\\bf C}^4: p_k^2 = \\alpha_k p_1^2 + \\beta_k p_2^2 + t^2 \\tilde H_k(p_1^2,p_2^2,t^2) \\text{ for } k=3,4 \\}")]]

#text("with the convention ")#mi("{p_3 = 3}")#text(". To convert back into the original coordinates ")#mi("{(w,z,r_1,r_2,r_3,r_4)}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("(r_1,r_2,r_3,r_4) = (tp_1, tp_2, t, tp_4)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("w = F( t^2 p_1^2, t^2 p_2^2 ); \\quad z = G( t^2 p_1^2, t^2 p_2^2 ).")]]

#text("Thus")

#align(center)[#tao-fit-display[#mitex("dw = O( t dt ) + O( t^2 dp_1 ) + O( t^2 dp_2 )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("dz = O( t dt ) + O( t^2 dp_1 ) + O( t^2 dp_2 )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("dw \\wedge dz = O( t^3 dt \\wedge dp_1 ) + O( t^3 dt \\wedge dp_2 ) + O( t^4 dp_1 \\wedge dp_2 ).")]]

#text("Also, ")#mi("{L = O(t)}")#text(". From ")#link(<tao-b710b9e75ab48f4f69b4>)[#text("(14)")]#text(" we can thus cancel all the factors of ")#mi("{t}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("L \\rho = \\frac{ O( dt \\wedge dp_1 ) + O( dt \\wedge dp_2 ) + O( t dp_1 \\wedge dp_2 ) }{p_1 p_2 p_4}")]]

#text("and so ")#mi("{L\\rho}")#text(" stays bounded up to the exceptional fibre in the blowup coordinates as long as ")#mi("{p_1,p_2,p_4}")#text(" stay bounded away from zero.")

#text("It remains to deal with the case when one of the ")#mi("{p_1,p_2,p_4}")#text(" are small. From the form of the curve ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(6)")]#text(", and the fact that the ")#mi("{x_k,y_k}")#text(" are in general position, none of the vectors ")#mi("{(1,0), (0,1), (\\alpha_3,\\beta_3), (\\alpha_4,\\beta_4)}")#text(" are scalar multiples of each other, which means that only one of the ")#mi("{p_1,p_2,p_3,p_4}")#text(" can vanish at a time. Suppose ")#mi("{p_1}")#text(" is close to vanishing, so that ")#mi("{p_2,p_4}")#text(" are comparable to one (the other cases will be similar). In this case, we use ")#link(<tao-b701704bc5b8738cd1ca>)[#text("(15)")]#text(". As before, ")#mi("{L = O(t)}")#text(" and ")#mi("{\\frac{1}{p_2 p_3 p_4} = O(t^{-3})}")#text("; also")

#align(center)[#tao-fit-display[#mitex("dr_1 = t dp_1 + p_1 dt")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("dw \\wedge dr_1 = O( t^2 dt \\wedge dp_1 ) + O( t^3 dp_1 \\wedge dp_2 ) + O( t^2 dt \\wedge dp_2 ).")]]

#text("So once again the factors of ")#mi("{t}")#text(" cancel, and")

#align(center)[#tao-fit-display[#mitex("L\\rho = O( dt \\wedge dp_1 ) + O( dt \\wedge dp_2 ) + O( t dp_1 \\wedge dp_2 )")]]

#text("and so ")#mi("{L\\rho}")#text(" stays bounded up to the exceptional fibre in this case. Similarly when one of the other ")#mi("{p_k}")#text(" are small. Thus ")#mi("{L\\rho}")#text(" stays bounded as one approaches the exceptional fibre in any direction, and so by Riemann’s theorem it can be continued holomorphically to this fibre.")

#text("In conclusion, ")#mi("{L\\rho}")#text(" lifts to a smooth ")#mi("{2}")#text("-form on the blowup surface ")#mi("{X}")#text(". By choosing ")#mi("{L}")#text(" to be the coordinate functions ")#mi("{Z,R_1,R_2,R_3,R_4}")#text(", we conclude that the image of the canonical map on ")#mi("{X}")#text(" contains the image of ")#mi("{\\overline{V}}")#text(" under the (generically defined) projection ")#mi("{[X,Y,Z,R_1,R_2,R_3,R_4] \\mapsto [Z,R_1,R_2,R_3,R_4]}")#text(". But it is easy to see that this map is generically injective on ")#mi("{\\overline{V}}")#text(" (indeed, one can solve for ")#mi("{X,Y}")#text(" as rational functions of ")#mi("{Z,R_1,R_2,R_3,R_4}")#text("), by subtracting the various equations ")#mi("{Q_j=0}")#text(" from each other), and so the image has full dimension. This establishes that ")#mi("{X}")#text(" has general type as required.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e1dd4c70f3f91ffff65faf4a5c12d9a98e665178bbc68d448592e076078157-bfef78253dd440411fa3afaf419c4a0956d32191309af0ef78ad68e407e0d80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-445923")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2014")])]

#text("Dear Terry,")

#text("This is really nice. I learned about the Erdos-Ulam problem recently, after I came across Harborth’s conjecture (1987): Every planar graph has a drawing in which all edges are straight line segments of integer length. Of course since the answer to the Erdos-Ulam problem is probably that such sets cannot be dense one must find a different approach to Harborth’s conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35e1dd4c70f3f91ffff65faf4a5c12d9a98e665178bbc68d448592e076078157-bfef78253dd440411fa3afaf419c4a0956d32191309af0ef78ad68e407e0d80f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-445924")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2014")])]

#text("To further justify the connection with Harborth’s conjecture, I guess it seems likely that for ")#mi("n")#text(" sufficiently large, say ")#mi("n\\geq 10")#text(" or something, the set of ")#mi("n")#text("-tuples of points in ")#mi("\\mathbf{R}^2")#text(" pairwise at rational distance is not dense in ")#mi("(\\mathbf{R}^2)^n")#text(". (I’m not sure whether your analysis gives this stronger variant.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-445970")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2014")])]

#text("The analysis in the post shows that, given any four points in the plane at rational distances from each other and in general position, the set of points at rational distances from these original four lies in a finite union of plane algebraic curves and thus not dense. But that is weaker than the claim above. In principle, though, the set of n-tuples with this property is the set of rational points of some variety, and for ")#mi("n")#text(" large enough it is likely that this variety becomes of general type (after blowing up to a smooth projective variety). But the computations are likely to be much more complicated than those in this post, especially given that the variety looks to have a fairly large dimension (something like ")#mi("2n")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-445973")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2014")])]

#text("“roughly speaking, it one of the most optimistic natural conjecture one could make that is compatible with these heuristics while also being invariant under birational equivalence” missing “is” after “it”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446087")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("I don’t know much algebraic geometry. Janos Kollar likes to mix asymptotic in there such as this paper ")#link("http://arxiv.org/abs/1405.2243")[#text("http://arxiv.org/abs/1405.2243")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc14d93c8648c9f8c27b3e1e0c49d17fc6c91ae03d4b012efb1ae26054976925-f6f9cd080f3adaa5541571b73a70326edb6db35cdb0cbee741396b0b7630143a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jafar Shaffaf")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446330")[#strong[#text("Jafar Shaffaf")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2014")])]

#text("Dear Terry,")#linebreak()#text(" I didn’t know that you are interested in Ulam conjecture, I proved Ulam conjeture last year but I didn’t publish it yet. In fact I associate a special surface in $\\mathbb{P}^3$ to a rational subset of the plane and I call them distance surface. I prove that these surfaces are surfaces of general type. For more detail I send this paper to your email and I hope you can see this and I appreciate it if you have any comment/idea about that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")])]

#text("Since it is announced on a blog, I suppose there is no secrecy about it: Terry, can you (dis)confirm that you have indeed received an email from Shaffaf with a claimed proof of the Ulam conjecture?")

#emph[#text("[Yes, I have seen the manuscript, but (as with this post) the proof is conditional on the Bombieri-Lang conjecture. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446380")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2014")])]

#text("Very nice! Do you have a uniform bound on the number of curves (and their degree) covering the points at rational distances from the four points? It seems that your argument implies a stronger statement. If we suppose Bombieri-Lang then there is an N such that any planar integral pointset in general position has at most N elements. (integral pointset = every distance is integer). The best known lower bound is N=7 by a construction of Sascha Kurz.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446390")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2014")])]

#text("Well, one could simply add such a uniformity claim to the Bombieri-Lang conjecture one is using as input, but this is of course cheating. There is a ")#link("http://www.ams.org/leavingmsn?url=http://dx.doi.org/10.1090/S0894-0347-97-00195-1")[#text("paper of Caporaso, Harris, and Mazur")]#text(" that uses Bombieri-Lang (in its original form) to deduce a uniform version, but only for curves (i.e. Faltings’ theorem). (I learned of this reference from the paper of Makhul and Shaffaf referenced in the post.) I don’t know if there is any hope of extending these arguments to surfaces.")

#text("I think I agree though that if such a uniformity claim was present, then by combining the arguments here with those in your paper with Frank one should be able to get a fixed upper bound N on rational-distance points in general position (though one may need a strong version of general position in which one avoids more configurations than collinear points or quadruples on a circle).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-447313")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2014")])]

#text("Re: “PS: Please take down the rating system.”")#linebreak()#text(" Just Adblock everything from poll.fm: rule “||poll.fm^”")#linebreak()#text(" I did that to kill off the up/down comment votes business long ago, not just because they aren’t useful (and they aren’t at all useful), but because contacting poll.fm can lead to very lengthy delays in loading simple wordpress pages.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teresa")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446695")[#strong[#text("Teresa")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")])]

#text("dear proffessor tao,")

#text("I m really amazing of your math intelligence. i want to know if you ever solved a conjecture, or if is a problem who you can t solve. wait for your answer, sorry for my language i dont know very well english language. happy for you, wait a answer..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7372cfbbab4243ed84baecdad4c69e88faffcbc155c1bd09aa34d8c6de559fcf-a82ff530e24f0a1f43505f94625dbb7d19952eebef96ff8c63c8fb5492ed0ea4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sonam gupta")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-446883")[#strong[#text("sonam gupta")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2014")])]

#text("Hi,")

#text("That was nicely written. I really enjoyed your post.")

#text("Thanks to share this post:)")

#text("Regards,")

#text("Sonam Gupta")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-447294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2014")])]

#text("Dear Terry,")#linebreak()#text(" Suddenly, I discover a valuable secrect:among Field medalist or Nobelist never cooperate with each other.Simple reason, among two kings never listen to each other’s idea.Another reason, all for selfish and envy.Among them , everyone thinks that he/she is the best.Once again, Yin-Yang princple of China is always true, forever.From now to 2015, 2050., …2900, no matter how good sience is , human beings can not kill their selfish or “nature of myself according to Taoism”.There is not two suns in our universe? If Field medalist or Nobelist humble each other, I’m sure we can solve 100 best hard problems or discovering many medical treatmnents for human.I’m nothing, i’m not the best intelligent man.But I think nowadays,the advance of sience is nothing.We cannot call” Paradise of sience”.For example, many diseases cannot be treated by sience , sometime olny one small leaf in nature can do very well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-447473")[#strong[#text("How many rational distances can there be between N points in the plane? | Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2014")]

#text("[…] has a nice post up bout the Erdös-Ulam problem, which was unfamiliar to me. Here’s the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-447475")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2014")])]

#text("I like this story! Idle question, from my blog: is there a “quantitative Erdos-Ulam problem?” That is: if S is a set of N points in the plane of which no more than M lie on any line or conic, how many of the ~N^2 distances between points of S can be rational? You can easily get NM; is it easy to get much more? ")#link("https://quomodocumque.wordpress.com/2014/12/29/how-many-rational-distances-can-there-be-between-n-points-in-the-plane/")[#text("https://quomodocumque.wordpress.com/2014/12/29/how-many-rational-distances-can-there-be-between-n-points-in-the-plane/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc14d93c8648c9f8c27b3e1e0c49d17fc6c91ae03d4b012efb1ae26054976925-f6f9cd080f3adaa5541571b73a70326edb6db35cdb0cbee741396b0b7630143a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jafar Shaffaf")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-448603")[#strong[#text("Jafar Shaffaf")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("I sent the paper to arxiv, it might be useful and interesting for someone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f994878e8d7396b268ab6ac3f054c0708a7f5439eeda380f6bad9d558bdd74-087cdc5448e655a3195f0fe12bb0b035630cb1ad976f7c08f13f2e3cfdc8b245.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Janko Bračič")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-448686")[#strong[#text("Janko Bračič")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("A very nice post! However, I have a question: it is said in the beginning “(Conversely, it is easy to construct examples of dense subsets of a line or circle in which all distances are rational.) ” I guess that this does not hold for any circle. It seems that the square of the radius of the circle has to be rational number.")

#emph[#text("[Yes; clarification added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67edd8ddefcbf70fa6cbcbe33fd8b7611957068d2384e4a4871f7491a37220b9-b0df7a520e24eca6449683117b2adf5aeb2358d835e10012e8f8cbd3217c5f54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elena Citro")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-453013")[#strong[#text("Elena Citro")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2015")])]

#text("Hi ! I apologize in advance for the futility of my message ( in comparison to the beauty of the topics covered ) , but it’s for a few years that I have a curiosity about your talent and did not know where to send it . I know that many prodigies are synesthetes , you also have the gift of synesthesia ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b083c5bb9f08194a4912082e131fe27214e3b1cb5b3a2656fe6ea70a4c02c593-9e681dae292ff7260bc0f14c2db549e670a1bdbc329f2d62225238c7d1790180.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georges Elencwajg")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-457787")[#strong[#text("Georges Elencwajg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2015")])]

#text("Dear Terence, in your boxed example 6 you seem to imply that the canonical bundle of $\\mathbb P^n$ is $\\mathcal O(-n)$, while in reality it is $\\mathcal O(-n-1)$. What am I misunderstanding ?")

#emph[#text("[Oops, I had not done the change of coordinate calculations carefully enough; the comment is now corrected. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-507746")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("Sándor Kovács has kindly written up a proof of Theorem 4 in more conventional algebraic geometry language, using the language of sheaves and linear systems. The main point is that as the singularities of V are all either canonical or log-canonical, one can relate sheaves on V with sheaves on the resolution in a relatively straightforward manner, so that general type can be verified more or less directly on V rather than on the resolution. I have uploaded his notes at ")#link("https://terrytao.files.wordpress.com/2018/11/bl-to-eu.pdf")[#text("https://terrytao.files.wordpress.com/2018/11/bl-to-eu.pdf")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruling out polynomial bijections over the rationals via Bombieri-Lang? | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-517183")[#strong[#text("Ruling out polynomial bijections over the rationals via Bombieri-Lang? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("[…] a powerful conjecture in Diophantine geometry known as the Bombieri-Lang conjecture (discussed in this previous post), it is at least possible to exhibit polynomials which are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97d28670d589b1245e0d9f80c9f27be85522fa102ad805d781492987bcbe0f97-479fffa787999cfc4bb170095cfa126530e22a16aa674887f338fe46738b2e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What if they are all wrong? | Igor Pak's blog")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-609301")[#strong[#text("What if they are all wrong? | Igor Pak's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2020")])]

#text("[…] since it would both imply one conjecture and give a counterexample to another? For the record, I wouldn’t do that, just making a polemical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/20/the-erdos-ulam-problem-varieties-of-general-type-and-the-bombieri-lang-conjecture/#comment-685434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("I learned about this problem from Vasek Chvatal at McGill School of Computer Science, in 1978. Thank you, Vasek!")

#text("I now offer a solution by constructing a set that meets the Erdos-Ulam conditions. Please follow the link below.")

#link("https://drive.google.com/file/d/1t0zXqnYpYJSwcA3wTadyFETm7wj-PICo/view?usp=sharing")[#text("https://drive.google.com/file/d/1t0zXqnYpYJSwcA3wTadyFETm7wj-PICo/view?usp=sharing")]

#text("Duncan McCallum")

#link("mailto:dap.mccallum@gmail.com")[#text("dap.mccallum@gmail.com")]
]
