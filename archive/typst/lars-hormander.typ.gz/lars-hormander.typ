// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/11/30/lars-hormander/
// Converted to Typst by tao2typ: "2026-10-14T15:18:31.407756+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lars Hormander", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lars Hormander")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 November 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/")[#text("https://terrytao.wordpress.com/2012/11/30/lars-hormander/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Lars_H%C3%B6rmander")[#text("Lars Hörmander")]#text(", who made fundamental contributions to all areas of partial differential equations, but particularly in developing the analysis of variable-coefficient linear PDE, ")#link("http://www.maths.lth.se/news/2012/11/28/Hormander/")[#text("died last Sunday")]#text(", aged 81.")

#text("I unfortunately never met Hörmander personally, but of course I encountered his work all the time while working in PDE. One of his major contributions to the subject was to systematically develop the calculus of ")#link("http://en.wikipedia.org/wiki/Fourier_integral_operator")[#text("Fourier integral operators")]#text(" (FIOs), which are a substantial generalisation of pseudodifferential operators and which can be used to (approximately) solve linear partial differential equations, or to transform such equations into a more convenient form. Roughly speaking, Fourier integral operators are to linear PDE as ")#link("http://en.wikipedia.org/wiki/Canonical_transformation")[#text("canonical transformations")]#text(" are to ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamiltonian mechanics")]#text(" (and one can in fact view FIOs as a quantisation of a canonical transformation). They are a large class of transformations, for instance the Fourier transform, pseudodifferential operators, and smooth changes of the spatial variable are all examples of FIOs, and (as long as certain singular situations are avoided) the composition of two FIOs is again an FIO.")

#text("The full theory of FIOs is quite extensive, occupying ")#link("http://www.ams.org/mathscinet-getitem?mr=781537")[#text("the entire final volume of")]#text(" Hormander’s famous four-volume series “The Analysis of Linear Partial Differential Operators”. I am certainly not going to try to attempt to summarise it here, but I thought I would try to motivate how these operators arise when trying to transform functions. For simplicity we will work with functions ")#mi("{f \\in L^2({\\bf R}^n)}")#text(" on a Euclidean domain ")#mi("{{\\bf R}^n}")#text(" (although FIOs can certainly be defined on more general smooth manifolds, and there is an extension of the theory that also works on manifolds with boundary). As this will be a heuristic discussion, we will ignore all the (technical, but important) issues of smoothness or convergence with regards to the functions, integrals and limits that appear below, and be rather vague with terms such as “decaying” or “concentrated”.")

#text("A function ")#mi("{f \\in L^2({\\bf R}^n)}")#text(" can be viewed from many different perspectives (reflecting the variety of bases, or approximate bases, that the Hilbert space ")#mi("{L^2({\\bf R}^n)}")#text(" offers). Most directly, we have the ")#emph[#text("physical space perspective")]#text(", viewing ")#mi("{f}")#text(" as a function ")#mi("{x \\mapsto f(x)}")#text(" of the physical variable ")#mi("{x \\in {\\bf R}^n}")#text(". In many cases, this function will be concentrated in some subregion ")#mi("{\\Omega}")#text(" of physical space. For instance, a gaussian wave packet ")#metadata(none) <tao-0e756d450a716a955fe6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(x) = A e^{-(x-x_0)^2/\\hbar} e^{i \\xi_0 \\cdot x/\\hbar},")]]

#text("where ")#mi("{\\hbar > 0}")#text(", ")#mi("{A \\in {\\bf C}}")#text(" and ")#mi("{x_0, \\xi_0 \\in {\\bf R}^n}")#text(" are parameters, would be physically concentrated in the ball ")#mi("{B(x_0,\\sqrt{\\hbar})}")#text(". Then we have the ")#emph[#text("frequency space (or momentum space) perspective")]#text(", viewing ")#mi("{f}")#text(" now as a function ")#mi("{\\xi \\mapsto \\hat f(\\xi)}")#text(" of the frequency variable ")#mi("{\\xi \\in {\\bf R}^n}")#text(". For this discussion, it will be convenient to normalise the Fourier transform using a small constant ")#mi("{\\hbar > 0}")#text(" (which has the physical interpretation of ")#link("http://en.wikipedia.org/wiki/Planck_constant")[#text("Planck’s constant")]#text(" if one is doing quantum mechanics), thus")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\frac{1}{(2\\pi \\hbar)^{n/2}} \\int_{\\bf R} e^{-i\\xi \\cdot x/\\hbar} f(x)\\ dx.")]]

#text("For instance, for the gaussian wave packet ")#link(<tao-0e756d450a716a955fe6>)[#text("(1)")]#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = A e^{i\\xi_0 \\cdot x_0/\\hbar} e^{-(\\xi-\\xi_0)^2/\\hbar} e^{-i \\xi \\cdot x_0/\\hbar},")]]

#text("and so we see that ")#mi("{f}")#text(" is concentrated in frequency space in the ball ")#mi("{B(\\xi_0,\\sqrt{\\hbar})}")#text(".")

#text("However, there is a third (but less rigorous) way to view a function ")#mi("{f}")#text(" in ")#mi("{L^2({\\bf R}^n)}")#text(", which is the ")#emph[#text("phase space perspective")]#text(" in which one tries to view ")#mi("{f}")#text(" as distributed simultaneously in physical space and in frequency space, thus being something like a measure on the ")#link("http://en.wikipedia.org/wiki/Phase_space")[#text("phase space")]#text(" ")#mi("{T^* {\\bf R}^n := \\{ (x,\\xi): x, \\xi \\in {\\bf R}^n\\}}")#text(". Thus, for instance, the function ")#link(<tao-0e756d450a716a955fe6>)[#text("(1)")]#text(" should heuristically be concentrated on the region ")#mi("{B(x_0,\\sqrt{\\hbar}) \\times B(\\xi_0,\\sqrt{\\hbar})}")#text(" in phase space. Unfortunately, due to the uncertainty principle, there is no completely satisfactory way to canonically and rigorously define what the “phase space portrait” of a function ")#mi("{f}")#text(" should be. (For instance, the ")#link("http://en.wikipedia.org/wiki/Wigner%E2%80%93Weyl_transform")[#text("Wigner transform")]#text(" of ")#mi("{f}")#text(" can be viewed as an attempt to describe the distribution of the ")#mi("{L^2}")#text(" energy of ")#mi("{f}")#text(" in phase space, except that this transform can take negative or even complex values; see ")#link("http://www.ams.org/mathscinet-getitem?mr=983366")[#text("Folland’s book")]#text(" for further discussion.) Still, it is a very useful heuristic to think of functions has having a phase space portrait, which is something like a non-negative measure on phase space that captures the distribution of functions in both space and frequency, albeit with some “quantum fuzziness” that shows up whenever one tries to inspect this measure at scales of physical space and frequency space that together violate the uncertainty principle. (The score of a piece of music is a good everyday example of a phase space portrait of a function, in this case a sound wave; here, the physical space is the time axis (the horizontal dimension of the score) and the frequency space is the vertical dimension. Here, the time and frequency scales involved are well above the uncertainty principle limit (a typical note lasts many hundreds of cycles, whereas the uncertainty principle kicks in at ")#mi("{O(1)}")#text(" cycles) and so there is no obstruction here to musical notation being unambiguous.) Furthermore, if one takes certain asymptotic limits, one can recover a precise notion of a phase space portrait; for instance if one takes the ")#emph[#text("semiclassical limit")]#text(" ")#mi("{\\hbar \\rightarrow 0}")#text(" then, under certain circumstances, the phase space portrait converges to a well-defined classical probability measure on phase space; closely related to this is the ")#emph[#text("high frequency limit")]#text(" of a fixed function, which among other things defines the ")#link("http://en.wikipedia.org/wiki/Wave_front_set")[#text("wave front set")]#text(" of that function, which can be viewed as another asymptotic realisation of the phase space portrait concept.")

#text("If functions in ")#mi("{L^2({\\bf R}^n)}")#text(" can be viewed as a sort of distribution in phase space, then linear operators ")#mi("{T: L^2({\\bf R}^n) \\rightarrow L^2({\\bf R}^n)}")#text(" should be viewed as various transformations on such distributions on phase space. For instance, a pseudodifferential operator ")#mi("{a(X,D)}")#text(" should correspond (as a zeroth approximation) to multiplying a phase space distribution by the symbol ")#mi("{a(x,\\xi)}")#text(" of that operator, as discussed in ")#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/")[#text("this previous blog post")]#text(". Note that such operators only change the amplitude of the phase space distribution, but not the support of that distribution.")

#text("Now we turn to operators that alter the support of a phase space distribution, rather than the amplitude; we will focus on unitary operators to emphasise the amplitude preservation aspect. These will eventually be key examples of Fourier integral operators. A physical translation ")#mi("{Tf(x) := f(x-x_0)}")#text(" should correspond to pushing forward the distribution by the transformation ")#mi("{(x,\\xi) \\mapsto (x+x_0,\\xi)}")#text(", as can be seen by comparing the physical and frequency space supports of ")#mi("{Tf}")#text(" with that of ")#mi("{f}")#text(". Similarly, a frequency modulation ")#mi("{Tf(x) := e^{i \\xi_0 \\cdot x/\\hbar} f(x)}")#text(" should correspond to the transformation ")#mi("{(x,\\xi) \\mapsto (x,\\xi+\\xi_0)}")#text("; a linear change of variables ")#tao-math("{Tf(x) := \\left|\\text{det} L\\right|^{-1/2} f(L^{-1} x)}", block: false)#text(", where ")#mi("{L: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" is an invertible linear transformation, should correspond to ")#mi("{(x,\\xi) \\mapsto (Lx, (L^*)^{-1} \\xi)}")#text("; and finally, the Fourier transform ")#mi("{Tf(x) := \\hat f(x)}")#text(" should correspond to the transformation ")#mi("{(x,\\xi) \\mapsto (\\xi,-x)}")#text(".")

#text("Based on these examples, one may hope that given any diffeomorphism ")#mi("{\\Phi: T^* {\\bf R}^n \\rightarrow T^* {\\bf R}^n}")#text(" of phase space, one could associate some sort of unitary (or approximately unitary) operator ")#mi("{T_\\Phi: L^2({\\bf R}^n) \\rightarrow L^2({\\bf R}^n)}")#text(", which (heuristically, at least) pushes the phase space portrait of a function forward by ")#mi("{\\Phi}")#text(". However, there is an obstruction to doing so, which can be explained as follows. If ")#mi("{T_\\Phi}")#text(" pushes phase space portraits by ")#mi("{\\Phi}")#text(", and pseudodifferential operators ")#mi("{a(X,D)}")#text(" multiply phase space portraits by ")#mi("{a}")#text(", then this suggests the intertwining relationship")

#align(center)[#tao-fit-display[#mitex("a(X,D) T_\\Phi \\approx T_\\Phi (a \\circ \\Phi)(X,D),")]]

#text("and thus ")#mi("{(a \\circ \\Phi)(X,D)}")#text(" is approximately conjugate to ")#mi("{a(X,D)}")#text(": ")#metadata(none) <tao-d1d4008481e6da67529b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(a \\circ \\Phi)(X,D) \\approx T_\\Phi^{-1} a(X,D) T_\\Phi.")]]

#text("The formalisation of this fact in the theory of Fourier integral operators is known as Egorov’s theorem, ")#link("http://www.ams.org/mathscinet-getitem?mr=265748")[#text("due to Yu Egorov")]#text(" (and not to be confused with the more widely known ")#link("http://en.wikipedia.org/wiki/Egorov's_theorem")[#text("theorem of Dmitri Egorov in measure theory")]#text(").")

#text("Applying commutators, we conclude the approximate conjugacy relationship")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{i\\hbar} [(a \\circ \\Phi)(X,D), (b \\circ \\Phi)(X,D)] \\approx T_\\Phi^{-1} \\frac{1}{i\\hbar} [a(X,D), b(X,D)] T_\\Phi.")]]

#text("Now, the pseudodifferential calculus (as discussed in ")#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/")[#text("this previous post")]#text(") tells us (heuristically, at least) that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{i\\hbar} [a(X,D), b(X,D)] \\approx \\{ a, b \\}(X,D)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{i\\hbar} [(a \\circ \\Phi)(X,D), (b \\circ \\Phi)(X,D)] \\approx \\{ a \\circ \\Phi, b \\circ \\Phi \\}(X,D)")]]

#text("where ")#mi("{\\{,\\}}")#text(" is the Poisson bracket. Comparing this with ")#link(<tao-d1d4008481e6da67529b>)[#text("(2)")]#text(", we are then led to the compatibility condition")

#align(center)[#tao-fit-display[#mitex("\\{ a \\circ \\Phi, b \\circ \\Phi \\} \\approx \\{ a, b \\} \\circ \\Phi,")]]

#text("thus ")#mi("{\\Phi}")#text(" needs to preserve (approximately, at least) the Poisson bracket, or equivalently ")#mi("{\\Phi}")#text(" needs to be a ")#link("http://en.wikipedia.org/wiki/Symplectomorphism")[#text("symplectomorphism")]#text(" (again, approximately at least).")

#text("Now suppose that ")#mi("{\\Phi: T^* {\\bf R}^n \\rightarrow T^* {\\bf R}^n}")#text(" is a symplectomorphism. This is morally equivalent to the graph ")#mi("{\\Sigma := \\{ (z, \\Phi(z)): z \\in T^* {\\bf R}^n \\}}")#text(" being a ")#link("http://en.wikipedia.org/wiki/Lagrangian_submanifold")[#text("Lagrangian submanifold")]#text(" of ")#mi("{T^* {\\bf R}^n \\times T^* {\\bf R}^n}")#text(" (where we give the second copy of phase space the negative ")#mi("{-\\omega}")#text(" of the usual symplectic form ")#mi("{\\omega}")#text(", thus yielding ")#mi("{\\omega \\oplus -\\omega}")#text(" as the full symplectic form on ")#mi("{T^* {\\bf R}^n \\times T^* {\\bf R}^n}")#text("; this is another instantiation of the closed graph theorem, as mentioned in ")#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/")[#text("this previous post")]#text(". This graph is known as the ")#emph[#text("canonical relation")]#text(" for the (putative) FIO that is associated to ")#mi("{\\Phi}")#text(". To understand what it means for this graph to be Lagrangian, we coordinatise ")#mi("{T^* {\\bf R}^n \\times T^* {\\bf R}^n}")#text(" as ")#mi("{(x,\\xi,y,\\eta)}")#text(" suppose temporarily that this graph was (locally, at least) a smooth graph in the ")#mi("{x}")#text(" and ")#mi("{y}")#text(" variables, thus")

#align(center)[#tao-fit-display[#mitex("\\Sigma = \\{ (x, F(x,y), y, G(x,y)): x, y \\in {\\bf R}^n \\}")]]

#text("for some smooth functions ")#mi("{F, G: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(". A brief computation shows that the Lagrangian property of ")#mi("{\\Sigma}")#text(" is then equivalent to the compatibility conditions")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\partial F_i}{\\partial x_j}  & = \\frac{\\partial F_j}{\\partial x_i}", block: true)



#tao-math("\\frac{\\partial G_i}{\\partial y_j}  & = \\frac{\\partial G_j}{\\partial y_i}", block: true)



#tao-math("\\frac{\\partial F_i}{\\partial y_j}  & = - \\frac{\\partial G_j}{\\partial x_i}", block: true)
]

#text("for ")#mi("{i,j=1,\\ldots,n}")#text(", where ")#mi("{F_1,\\ldots,F_n, G_1,\\ldots,G_n}")#text(" denote the components of ")#mi("{F,G}")#text(". Some Fourier analysis (or Hodge theory) lets us solve these equations as")

#align(center)[#tao-fit-display[#mitex("F_i = -\\frac{\\partial \\phi}{\\partial x_i}; \\quad G_j = \\frac{\\partial \\phi}{\\partial y_j}")]]

#text("for some smooth potential function ")#mi("{\\phi: {\\bf R}^n \\times {\\bf R}^n \\rightarrow {\\bf R}}")#text(". Thus, we have parameterised our graph ")#mi("{\\Sigma}")#text(" as ")#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Sigma = \\{ (x, -\\nabla_x \\phi(x,y), y, \\nabla_y \\phi(x,y)): x,y \\in {\\bf R}^n \\}")]]

#text("so that ")#mi("{\\Phi}")#text(" maps ")#mi("{(x, -\\nabla_x \\phi(x,y))}")#text(" to ")#mi("{(y, \\nabla_y \\phi(x,y))}")#text(".")

#text("A reasonable candidate for an operator associated to ")#mi("{\\Phi}")#text(" and ")#mi("{\\Sigma}")#text(" in this fashion is the oscillatory integral operator ")#metadata(none) <tao-09d3f92cb7418e158e82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("Tf(y) := \\frac{1}{(2\\pi \\hbar)^{n/2}} \\int_{{\\bf R}^n} e^{i \\phi(x,y)/\\hbar} a(x,y) f(x)\\ dx")]]

#text("for some smooth amplitude function ")#mi("{a}")#text(" (note that the Fourier transform is the special case when ")#mi("{a=1}")#text(" and ")#mi("{\\phi(x,y)=xy}")#text(", which helps explain the genesis of the term “Fourier integral operator”). Indeed, if one computes an inner product ")#mi("{\\int_{{\\bf R}^n} Tf(y) \\overline{g(y)}\\ dy}")#text(" for gaussian wave packets ")#mi("{f, g}")#text(" of the form ")#link(<tao-0e756d450a716a955fe6>)[#text("(1)")]#text(" and localised in phase space near ")#mi("{(x_0,\\xi_0), (y_0,\\eta_0)}")#text(" respectively, then a Taylor expansion of ")#mi("{\\phi}")#text(" around ")#mi("{(x_0,y_0)}")#text(", followed by a ")#link("http://en.wikipedia.org/wiki/Stationary_phase_approximation")[#text("stationary phase")]#text(" computation, shows (again heuristically, and assuming ")#mi("{\\phi}")#text(" is suitably non-degenerate) that ")#mi("{T}")#text(" has ")#link(<tao-a543997d84f12798350c>)[#text("(3)")]#text(" as its canonical relation. (Furthermore, a refinement of this stationary phase calculation suggests that if ")#mi("{a}")#text(" is normalised to be the ")#emph[#text("half-density")]#text(" ")#tao-math("{\\left|\\det \\nabla_x \\nabla_y \\phi\\right|^{1/2}}", block: false)#text(", then ")#mi("{T}")#text(" should be approximately unitary.) As such, we view ")#link(<tao-09d3f92cb7418e158e82>)[#text("(4)")]#text(" as an example of a Fourier integral operator (assuming various smoothness and non-degeneracy hypotheses on the phase ")#mi("{\\phi}")#text(" and amplitude ")#mi("{a}")#text(" which we do not detail here).")

#text("Of course, it may be the case that ")#mi("{\\Sigma}")#text(" is not a graph in the ")#mi("{x,y}")#text(" coordinates (for instance, the key examples of translation, modulation, and dilation are not of this form), but then it is often a graph in some other pair of coordinates, such as ")#mi("{\\xi,y}")#text(". In that case one can compose the oscillatory integral construction given above with a Fourier transform, giving another class of FIOs of the form ")#metadata(none) <tao-b696dc4ccaf4d1bd56c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("Tf(y) := \\frac{1}{(2\\pi \\hbar)^{n/2}} \\int_{{\\bf R}^n} e^{i \\phi(\\xi,y)/\\hbar} a(\\xi,y) \\hat f(\\xi)\\ d\\xi.")]]

#text("This class of FIOs covers many important cases; for instance, the translation, modulation, and dilation operators considered earlier can be written in this form after some Fourier analysis. Another typical example is the half-wave propagator ")#mi("{T := e^{it \\sqrt{-\\Delta}}}")#text(" for some time ")#mi("{t \\in {\\bf R}}")#text(", which can be written in the form")

#align(center)[#tao-fit-display[#tao-math("Tf(y) = \\frac{1}{(2\\pi \\hbar)^{n/2}} \\int_{{\\bf R}^n} e^{i (\\xi \\cdot y + t \\left|\\xi\\right|)/\\hbar} a(\\xi,y) \\hat f(\\xi)\\ d\\xi.", block: true)]]

#text("This corresponds to the phase space transformation ")#tao-math("{(x,\\xi) \\mapsto (x+t\\xi/\\left|\\xi\\right|, \\xi)}", block: false)#text(", which can be viewed as the classical propagator associated to the “quantum” propagator ")#mi("{e^{it\\sqrt{-\\Delta}}}")#text(". More generally, propagators for linear Hamiltonian partial differential equations can often be expressed (at least approximately) by Fourier integral operators corresponding to the propagator of the associated ")#emph[#text("classical")]#text(" Hamiltonian flow associated to the symbol of the Hamiltonian operator ")#mi("{H}")#text("; this leads to an important mathematical formalisation of the ")#link("http://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" between quantum mechanics and classical mechanics, that is one of the foundations of microlocal analysis and which was extensively developed in Hörmander’s work. (More recently, numerically stable versions of this theory have been developed to allow for rapid and accurate numerical solutions to various linear PDE, for instance through Emmanuel Candés’ theory of ")#link("http://en.wikipedia.org/wiki/Curvelet")[#text("curvelets")]#text(", so the theory that Hörmander built now has some quite significant practical applications in areas such as geology.)")

#text("In some cases, the canonical relation ")#mi("{\\Sigma}")#text(" may have some singularities (such as fold singularities) which prevent it from being written as graphs in the previous senses, but the theory for defining FIOs even in these cases, and in developing their calculus, is now well established, in large part due to the foundational work of Hörmander.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-198038")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2012")])]

#text("\\beign{equation} (a \\circ \\Phi)(X,D) \\approx T_\\Phi^{-1} a(X,D) T_\\Phi")

#text("Should be")

#text("\\begin{equation} (a \\circ \\Phi)(X,D) \\approx T_\\Phi^{-1} a(X,D) T_\\Phi\\end{equation}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-198196")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2012")])]

#text("The discussion of the phase space properties of the FIOs and PDOs is very approximative. The operators T are the generators of the metaplectic group; this has to be explained, because symplectic/metaplectic covariance is one crucial property leading to Weyl operators (it is a characteristic property). Otherwise, interesting popular mathematics! Hörmander was indeed a great man. His contributions toi the theory of functions of complex variables is also far from being negligible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-198748")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2012")])]

#text("Dear terry,")#linebreak()#text(" I am not sure I understood the music score analogy completely, in particular how one defines the corresponding notion of uncertainty principle. What did you mean by cycles? And why would O(1) number of cycles for one note be a problem? Thx")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-198764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2012")])]

#text("A musical note can be viewed as a rectangle in phase space (though in a musical score, it is depicted instead as an oval), with the horizontal extent of the rectangle describing the duration of the note, and the vertical extent describing the frequency range. Note that the vertical extent is non-zero (unless the note is a pure sinusoidal wave that lasts forever). The uncertainty principle asserts that the product of the horizontal extent (measured in seconds) and the vertical extent (measured in Hertz) has to be >> 1.")

#text("In a musical scale, going one octave up corresponds to multiplying the frequency by 2; there are twelve tones in an octave, so (assuming equal temperament) adjacent notes in a scale differ by a multiplicative factor of ")#mi("2^{1/12} \\approx 1.06")#text(" (each note has 6% higher frequency than the previous one). To distinguish adjacent notes from each other, one thus needs a frequency uncertainty of less than 6% of the frequency of the note, which by the uncertainty principle corresponds to a minimum of about 17 cycles for the time uncertainty. (For middle C, for instance, which has a frequency of 260 Hz, this is about 0.06 seconds; of course, actual musical notes last far longer than this and so there is no obstruction from the uncertainty principle with discerning notes from each other. But if one played a middle C and a middle C# note, for instance, for less than 0.06 seconds each, the two notes would basically be indistinguishable from each other (they would make the same number of complete cycles in that time period).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cef257c8dc726263dda1f9dd363bcd22f3655fd74ee0ed23853583bf5e88cd3-79bdc7df20332082d6b96cc49288fafa358b0657a54c9fda0d2c3a44f26d3b07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-415113")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2014")])]

#text("Right after the last equation, shouldn’t it be: (x,\\xi) \\mapsto (x + t \\frac{\\xi}{ \\vert \\xi \\vert , \\xi ) instead of (x,\\xi) \\mapsto (x + t \\vert \\xi \\vert , \\xi ). At least this would be the associated Hamiltonian flow.")

#text("Thanks for the nice article!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23e6c57a98e9410a99822b8611f12498b8c7a9588ed6f07efee6ddd0dc11e1fe-51c980178fc562b9e4cd9d1f9c1c88f2976f26f6c199982f6cfe1513ca85d482.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moritz")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-458862")[#strong[#text("Moritz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2015")])]

#text("You indicated that there is are fourier integral operators for manifolds with boundary. Could you give a reference to that? Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-460388")[#strong[#text("Lars Hörmander » kryakin_y")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2015")]

#text("[…] Юноша с горящим взглядом. Ушел. Прочитал у солнечного Тао де […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-462516")[#strong[#text("Lars Hörmander | yuriy_kryakin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2015")]

#text("[…] Юноша с горящим взглядом. Ушел. Прочитал у солнечного Тао де […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4739956f28ab584c4f0806e3d3667c8c7ec4c9085f86475834dd271070294ebb-a40ec81cb65abf81f4fa076c2ef2497e5502bdbd6cd978de90a0c3570ecd6f35.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matemáticos de la Historia :: Lars Hörmander | María de los Milagros Langhi :: Blog personal")]], [#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-465660")[#strong[#text("Matemáticos de la Historia :: Lars Hörmander | María de los Milagros Langhi :: Blog personal")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2016")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/")[#text("https://terrytao.wordpress.com/2012/11/30/lars-hormander/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/11/30/lars-hormander/#comment-482660")[#strong[#text("Lars Hörmander | kryakin_f")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2017")]

#text("[…] Юноша с горящим взглядом. Ушел. Прочитал у солнечного Тао де […]")
]
