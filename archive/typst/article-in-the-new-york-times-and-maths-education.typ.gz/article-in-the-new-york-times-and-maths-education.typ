// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/
// Converted to Typst by tao2typ: "2026-10-13T06:05:04.483673+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Article in the New York Times, and maths education", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set par(justify: true, leading: 0.65em, spacing: 0.9em)
#set heading(numbering: none)
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#text(size: 23pt, weight: "semibold")[#text("Article in the New York Times, and maths education")]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/")[#text("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-13 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve received quite a lot of inquiries regarding a recent ")#link("http://www.nytimes.com/2007/03/13/science/13prof.html")[#text("article in the New York Times")]#text(", so I am borrowing some space on this blog to respond to some of the more common of these, and also to initiate a discussion on maths education, which was briefly touched upon in the article.")

#text("Firstly, some links:")

#list(
[#text("The video for the talk “")#link("http://www.calendar.ucla.edu/event_detail.cfm?MeetingID=123080")[#text("Structure and randomness in the prime numbers")]#text("” mentioned in the article ")#link("http://164.67.141.39:8080/ramgen/specialevents/math/tao/tao-20070117.smil")[#text("can be found here")]#text(" (requires ")#link("http://www.real.com/player")[#text("RealPlayer")]#text("). The slides ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/primes.pdf")[#text("can be found here")]#text(". My other expository and research material on number theory ")#link("http://www.math.ucla.edu/~tao/preprints/acnt.html")[#text("can be found here")]#text(".")],
[#text("I don’t have any specific advice regarding gifted education, though some articles on my own experiences ")#link("http://www.math.ucla.edu/~tao/media.html")[#text("can be found here")]#text(". I do however have some ")#link("http://www.math.ucla.edu/~tao/advice.html")[#text("thoughts on career advice")]#text(" at the undergraduate level and beyond.")],
[#text("I have some responses to several other common queries (e.g. regarding books, interviews, invitations, etc.) at my ")#link("http://www.math.ucla.edu/~tao/tags.html")[#text("contact information page")]#text(".")]
)

#text("Most of the feedback I received, though, concerned the issue of maths education. I mentioned in the article that I feel that the skill of thinking in a mathematical and rigorous way is one which can be taught to virtually anyone, and I would in the future hope to be involved in some project aimed towards this goal. I received a surprising number of inquiries on this, particularly from parents of school-age children. Unfortunately, my maths teaching experience is almost completely restricted to the undergraduate and graduate levels – and my own school experience was perhaps somewhat unusual – so I currently have close to zero expertise in K-12 maths education. (This may change though as my son gets older…) Still, I think it is a worthy topic of discussion as to what the mathematical academic community can do to promote interest in mathematics, and to encourage mathematical ways of thinking and of looking at the world, so I am opening the discussion to others who may have something of interest to say on these matters.")

#text("(")#emph[#text("Update")]#text(", March 13: A bad link has been repaired. Also, I can’t resist a somewhat political plug: for Californian readers, there is an ")#link("http://www.csun.edu/~vcmth00m/govletter.html")[#text("open letter in support of California’s K-12 education standards")]#text(", together with some ")#link("http://www.csun.edu/~vcmth00m/backgroundinfo.html")[#text("background information")]#text(".)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-2/#comment-236199")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/06/26/article-in-the-new-york-times-and-maths-education/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-92")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("I think that there is no question that American children could learn more mathematics on average than they do. Of course the issue is not just a specific set of facts, but thinking mathematically and liking it. What I see in the average childhood experience in this country is a lack of cultural appreciation for mathematics. Proper cultural appreciation is something of a chicken-and-egg problem, because you need a lot of people who both like mathematics and have learned the right kind of mathematics that deserves to be liked. In the absence of such a cultural backdrop, ")#emph[#text("every")]#text(" idea for improving math education can be co-opted and rendered a travesty. It has happened many times. Many entirely positive sentiments — things that I would tell people myself — have been co-opted by all sides: parents, teachers, Democrats, Republicans, unionists, anti-unionists, you name it.")

#text("In the ideal cultural backdrop, most children would be surrounded by teachers, parents, and other children who all enjoy trying to prove a theorem. Of course, demanding general improvement on all sides is no solution at all. But I think it would help a great deal if elementary school teachers knew and liked mathematics more themselves. Roger Howe had an interesting ")#link("http://www.ams.org/notices/199802/howe.pdf")[#text("book review")]#text(" that discussed just how unprepared many math teachers are in their subject.")

#text("You can see the process of co-opting in this review. On the one hand, the idea that teachers need more training has long been coopted. American teachers are actually more trained than many other teachers, but it isn’t training in mathematics. On the other hand, the book that Howe reviews leads to yet another mathematics education mantra, “PUFM”. In the letters to the Notices a few months later, some educators testily note that they already use ideas equivalent to “PUFM”.")

#text("Certainly my experience growing up was that math classes had too much drill; they did not adequately convey creative problem-solving. That too has been coopted by a “reform math” movement with an excessively unstructured, unrigorous approach. It’s also often a labor-intensive approach, and an excuse to slow down the material.")

#text("So fine, reform math goes to far. One antidote to that is uniform testing. Just like all other good ideas, it has been coopted, this time by “No Child Left Behind” methods. They introduce a heavy-handed system of financial rewards and penalties without decent control of the tests themselves. Typically the tests are used for moral judgements — “our schools get a failing grade” — instead of as a dispassionate measure of proficiency.")

#text("Is there any escape from the cycle of distortions of good intentions? There are ways to improve the system, but they are generally subtle or unpalatable. Teachers should have less required training in education, and more required proficiency in the subject matter. Teaching mathematics should be differentiated more from teaching K12 in general, so that we don’t have the task of teaching more mathematics to all K12 teachers. There should be more connections between high schools and universities; and connections should not be utterly dominated by university education departments. There should be more choices for parents and students — but this should mainly mean curriculum choices, not school vouchers. There should be standardized testing — but it should really be a national standard, and it should not be weighed down by incentives and pass lines. State curriculum standards should be written with adequate input from mathematicians, scientists, and engineers. Well, all of these steps, and some others, are easier to think of than to properly implement and protect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-93")[#strong[#text("thomas1111")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("Thank you for initiating this discussion! First a trivial thing: isn’t your number theory page ")#link("http://www.math.ucla.edu/~tao/preprints/acnt.html")[#text("here")]#text(" instead (broken link)?")

#text("As for the question about ways to promote interest in maths by the academic community: perhaps its relations with the broader community of math and science teacher is not as smooth as it should be (it seems to be quite close to a step function rather). Learning more examples of mathematical concepts in a very low-key way might improve the teachers’ abilities to pass on their message to their pupils. More generally, you mentionned several times in interviews to have a “bag of tricks” that grows with accumulated experience and I would think many of these have a wider applicability than their pure math setting. Just maybe, a website maintained by the mathematical community covering such mathematically-minded general strategies to attack a given problem (using plain words as much as possible) could be of interest to the wider public.")

#text("Yet obviously drawing people’s attention towards math is no easy task even with enthousiastic initiatives: recall the “")#link("http://www.msri.org/specials/specials/pow/archive.html")[#text("Puzzles on Wheels")]#text("” initiative by the MSRI a few years ago (see also this ")#link("http://www.sfgate.com/cgi-bin/article.cgi?file=/chronicle/archive/2004/10/08/EBGR491I3Q32.DTL")[#text("article")]#text(";). Apparently it ended pretty fast unfortunately. (Sorry for the long post!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-94")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("Okay, having vented at length, I realized that I didn’t answer Terry’s good question, which is ways that university math departments can help. One to way to answer the question is to simply list examples of successful conduits of the mathematical tradition from universities to school-age children. (With the proviso that forms of all of these good ideas have compromised versions.)")

#text("1. Wikipedia.")#linebreak()#text(" 2. The Ross Young Scholars Program.")#linebreak()#text(" 3. The Math for America teaching program.")#linebreak()#text(" 4. AP calculus, both the test and the courses. (*)")#linebreak()#text(" 5. University math courses for high school students.")

#text("(*) Granted, AP calculus has many shortcomings, but in my view it’s a lot better than nothing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-95")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("Oh yeah, I was going to list the California State Math standards in the previous as a positive example of influence. Of course it was the involvement of the Stanford math department, not the Hoover institute, that mattered.")

#text("The California state math standards have been very useful for my own children. The standards are very clear; they make it easier to decide whether a student has mastered specific material taught in any given grade or class. The draft standards that they replaced were indistinct on this crucial point. They read instead as a description of what students should experience in a given grade rather than what they are supposed to learn or know. It made it harder to answer practical questions like “is my child ready for this class? Is my child learning the material in this class? Is the teacher teaching the right material?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-98")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("How can university math departments help? Let me draw your attention to the letter to the March 2007 Notices of the AMS from Pisheng Ding (you can find it in ")#link("http://www.ams.org/notices/200703/commentary.pdf")[#text("http://www.ams.org/notices/200703/commentary.pdf")]#text("), which I found to be quite insightful.")

#text("I wrote a letter in response to this that expressed the view that we cannot fix secondary school math education until we fix the graduate math education in this country. It has been convenient for us research mathematicians to paint the math education faculty and departments as the villains, but the fact is that our math departments are all graduating far too many incompetent majors at both the graduate and undergraduate levels. Until we are able to somehow set minimal competency requirements at all degree levels from Ph.D. down, I don’t expect us to make much progress with improving secondary school education.")

#text("Some of you may believe, as I once did, that the Ph.D. written and oral qualifying exams suffice as proof of minimal competency. It was a rude shock when I started to encounter, for example on Wall Street, math Ph.D.’s from highly ranked institutions who were capable of reciting the statements and proofs of sophisticated theorems but were incapable of dissecting and attacking elementary problems they were given (I wasn’t even looking for a solution). I learned, to my dismay, that it is indeed possible to obtain a Ph.D. in mathematics from a reputable institution through sheer memorization of facts without having developed strong basic mathematical analytical skills.")

#text("As for undergraduate math education, I’ll spare you any further rantings. Those of you unable to restrain your curiosity can find my writings about this by googling my name and “calculus”.")

#text("We in the research mathematical community are very proud of how unstructured and free our discipline is, in comparison to professional fields such as engineering, law, and medicine. I myself was attracted by this, when I first chose to go into mathematics. But I think we have to recognize the high price paid by both us and our society for our unwillingness to professionalize our discipline. It means that almost anyone can call themselves a “mathematician” or a “math teacher”, and when efforts are made by others to define what competency means, we are all too often on the periphery of the discussion, rather than leading it, as we should be.")

#text("There are some hopeful trends, with mathematicians like Wilfried Schmid getting involved in math education, but I am doubtful that we will be able to accomplish much unless we are willing to take a hard look at ourselves and make some tough pragmatic decisions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-99")[#strong[#text("Nona")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("Is it possible for someone to provide a link to the actual video file so I can download it and watch it at my computer? I right clicked on the video link and did “save as” and only got a small .RAM file.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-100")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("Greg said “What I see in the average childhood experience in this country is a lack of cultural appreciation for mathematics.”")

#text("I agree with this statement completely, and I believe that this is the primary reason for decline of mathematics skills in the U.S. A talented kid can survive bad standard curricula, but many will not survive if they are never told that their talent and their work is something of value. This has always been the case in the U.S., but I believe that the problem is getting worse. Long ago, I went to a high school whose principal valued the sports trophy case more than anything else, and never approved advanced or special classes for talented kids. I was only saved by a single smart teacher who encouraged me to apply for and attend NSF summer programs in mathematics at several universities. Unfortunately, I don’t believe that these exist anymore.")

#text("Many immigrants to this country came from ancestry that highly valued learning of all kinds. Somehow much of this has been lost and forgotten, perhaps by this stupid American attitude that learning/talent = elitism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-101")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#emph[#text("I went to a high school whose principal valued the sports trophy case more than anything else, and never approved advanced or special classes for talented kids.")]

#text("Yes, outright antiintellectualism certainly is one side of the problem, but I also had in mind something else. There is a lack of cultural understanding of mathematics, even among most well-educated people. For instance, I can offer this quote from Robert Fixmer, who was once an editor for the New York Times: “Mathematics has no emotional impact. What physicists do challenges people’s notions of origins and creations. Math doesn’t challenge any fundamental beliefs or what it means to be human.” This regrettable comment came from a successful American intellectual, not from someone who only values the sports trophy case.")

#text("I suspect that most K12 schools will say that it is very important to learn mathematics. But they may not teach good mathematics, and they may not reveal a major reason that mathematicians themselves learn it, which is that it is beautiful. (I do mathematics precisely because Fixmer is wrong, it does have an emotional impact.)")

#text("To be sure, there is more to good teaching than liking mathematics. I don’t always do a good job of it when I teach. Many of my K12 teachers and my kids’ teachers genuinely like children and communicate with them well, for all I know better than I would. But they won’t convey a perspective that they don’t have themselves. Even if they do reward talent, they may not reward it in the right way.")

#emph[#text("I was only saved by a single smart teacher who encouraged me to apply for and attend NSF summer programs in mathematics at several universities.")]

#text("I believe that the NSF program that fits this description ended, but the American Mathematical Society still supports several such programs with its ")#link("http://www.ams.org/employment/epsilon.html")[#text("Epsilon Fund")]#text(" program. These are indeed one of the main ways that univerisity math departments can popularize higher mathematics at the K12 level. I mentioned the example of the Ross program above.")

#text("Another way for math departments to help is to organize math contests and math contest training. I have seen first-hand how it can popularize rigorous mathematics. Just like all other solutions, this vehicle can be overused or coopted; it’s important to remember that the point is to stoke interest, not to “win”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-102")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("Greg,")

#text("Well put! It’s just about bed time here, so I’ll only comment on emphasizing interest (and I’ll add fun and beauty) rather than winning. Terence, for example, seems to have escaped that trap well, but the emphasis on winning can lead to burnout and the inability to settle into a long and satisfying research program which requires much work, patience and reflectivity.")

#text("Your viewpoint on the cultural and emotional aspect of mathematics is interesting, has not been discussed much, and probably needs to be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-103")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#text("I actually don’t have much of substance to say in this discussion, and am happy to primarily play the role of moderator, but I can make a few small observations.")

#text("The culture in the U.S. might not be the most intellectual one in the world, but it is at least relatively supportive of activities which lead to individual “success”, especially financial success. There seems to be a general (albeit vague) public awareness here that mathematics is somehow “useful” for various industries and careers (e.g. IT, finance, engineering, etc.), and so people here do seem to agree that maths is important, even if they mostly don’t want to touch the stuff themselves. It’s not ideal, but it’s significantly better than apathy or outright anti-intellectualism. For instance, while teaching undergraduate linear algebra here in the U.S., I’ve found that students respond well to the story of how two Stanford graduate students in mathematics and computer science managed to exploit the theory of singular value decompositions of large sparse matrices to create a rather well-known multi-billion dollar web search company :-) .")

#text("And there are some rather good educational resources lying around, if you know where to look. For instance, my four-year old son loves the Flash videos from ")#link("http://www.brainpop.com")[#text("brainpop.com")]#text(", which are remarkably well done, both in presentation and in content.")

#text("Mathematics competitions, when used in moderation, are indeed a good way to show high school students that maths has more aspects than the often rather dry material covered in classes. Out here in the west coast, though, they haven’t seem to have taken much of a hold, especially compared against more well-known activities such as the Spelling Bee. Perhaps one problem is that while a good performance at the Bee can be appreciated by just about anyone, a good result at a maths competition is only really appreciated by the participant and the grader. It would be interesting to have a maths-themed event which might have wider appeal to a non-mathematical audience.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-104")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")

#emph[#text("Out here in the west coast, though, they haven’t seem to have taken much of a hold, especially compared against more well-known activities such as the Spelling Bee.")]

#text("Some of the math graduate students here at Davis are doing a great job with ")#link("http://www.arml.com/")[#text("ARML")]#text(" “preparation”. To some extent it really is preparation for ARML, but they completely realize that it is also an excuse for a fun evening of problem solving, once a week. More students attend the meetings than will be on the team. I think that ARML is perfectly adequate for this mode of outreach. If not many students know about it in California, then people could work to change that. West Coast ARML is presently at UNLV.")

#text("Within the high school system there are also the AMC-10 and AMC-12 contests, which are the first American rung to the IMO.")

#text("At the more serious level of math summer camps, California has ")#link("http://www.ucop.edu/cosmos/")[#text("COSMOS")]#text(".")

#emph[#text("The culture in the U.S. might not be the most intellectual one in the world, but it is at least relatively supportive of activities which lead to individual “success”, especially financial success.")]

#text("Well, yes. I agree that this motivation is much better than nothing. But you see its limits when you teach standard calculus, for example; and I personally have some trouble coping with those limits. (But limits ")#emph[#text("in")]#text(" calculus are great :-).) The syllabus for standard calculus reads like a carpentry manual. I am much happier with rigorous calculus or undergraduate analysis; the difference for me is the tone of the course rather than the caliber of the students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-106")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2007")

#text("As a fomer Adjunct Professor of Mathematics (and of Astronomy), son of a teacher who specialized in Math, married to a Physics professor who’s taught in 4 countries, I think that the USA’s Math Education problem has at least these components:")

#text("(1) the overall failure of the public education system in the mean and the bottom, although sometimes successful at the top;")#linebreak()#text(" (2) Failure in most states even to admit the existence of, let alone address, the problem of Dyscalculia;")#linebreak()#text(" (3) Loss of girls and women “in the pipeline”;")#linebreak()#text(" (4) Lack of cultural context — where da Vinci in the elementary textbooks? Or Mozart and Bach?")#linebreak()#text(" (5) Very incomplete detection of young talent, and thus ability to connect the talented with the best teachers. Contrast with the Jewish quarter of Budapest in the decade that produced von Neumann, Wigner, Szilard, and Edward Teller, having attended the same “best high school system in Europe”, and enjoyed the same cafe scene, where scientists mingled with poets and philosophers and painters. About 10 world-class geniuses, who won 7 or 8 Nobel prizes, share that description, and some had the same specific teachers. Then they saw their beloved home town ruined by Nazi and Communist invasions. Some did not come to America, but rather to England or France.")

#text("As to Dyscalculia, it is a scandal that the innumerate are allowed to teach Math, and that teachers and parents alike tell students with Math Disability” don’t worry, I never liked Math either. Remember the Talking Barbie Doll who would actually say: “I hate Math. Let’s go shopping!”")

#text("I have successfully gotten students in their 50s to")#linebreak()#text(" finally grasp what eluded them through bad teachers in their past, peer pressure, bad parenting, poor self-esteem. “Discalculia” = “Math Disability.”")

#text("The educational literature on Discalculia is")#linebreak()#text(" quite clear that roughly 2/3 of the clinically Math")#linebreak()#text(" Disabled CAN — with proper teaching my specialists — finally “get it” and be able to do at least algebra.")#linebreak()#text(" Only about 1/3 have their brains hardwired to make")#linebreak()#text(" intervention ineffective.")

#text("The problem is NOT in teaching people what they don’t know (and know that they don’t know). The big problem is in teaching people who THINK that they know something, but have the wrong facts, axioms, methods in place through wrong ideas uncorrected by good teachers. My wife has published in the area of college students who fail Physics because their high school teachers were wrong, and their textbooks were wrong.")

#text("I didn’t teach myself calculus from college textbooks until I was 11, but my son learned to at least take derivatives and integrals of polynomials by age 10, passed his college entrance exam aged 12, but we made him finish 8th grade before jumpring directly to University at age 13. he’s about to get his double B.S. in Math and Computer science, having just turned 18. But — and this gets to the deprecation of Math in the USA — he will then not go for a Math or CS graduate fellowship, but instead start at a top 10 Law School, still aged 18.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-107")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2007")

#text("To follow up Jonathan’s posting, my diagnosis of the situation is that it stems from the failure of the research math community to find a way to professionalize itself. Engineering professional societies have set up a well-defined process for determining whether a person is allowed to call herself a “professional engineer” or not. The same is true for doctors, dentists, lawyers, and even architects.")

#text("We in the research mathematical community are very proud of how unstructured and free our discipline is, in comparison to the professional fields. I myself was attracted by this, when I first chose to go into mathematics. But I think we have to recognize the high price paid by both us and our society for our unwillingness to professionalize our discipline. It means that almost anyone can call themselves a “mathematician” or a “math teacher”, and when efforts are made by others to define what competency means, we are all too often on the periphery of the discussion, rather than leading it, as we should be.")

#text("I’d like to call your attention to the letter to the March 2007 Notices of the AMS from Pisheng Ding (you can find it in ")#link("http://www.ams.org/notices/200703/commentary.pdf")[#text("http://www.ams.org/notices/200703/commentary.pdf")]#text("), which I found to be quite insightful about what’s wrong with university mathematics education i this country. I suggest that we need fix these things, before we can hope to fix the secondary school math education.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-111")[#strong[#text("Quant Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2007")

#text("Did you guys ever consider that American children are smart enough to realize that studying too much math is a bad career and life–style investment? That investment banking, law, and medicine make better lives, careers, and well-rounded people? If you’re so smart, why are you not rich?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-114")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")

#text("I should also mention, in fact I should have mentioned much sooner, the “Math Circle” program at Davis and a number of other universities. These are weekly seminars for area high school students interested in mathematics. The one at Davis seems to be at least as successful as the ARML training. In particular, I asked the director, Yvonne Lai, whether the Davis program had stoked interest among any students who had once had no intention of studying higher mathematics. She said that she could definitely think of examples.")

#text("The broader lesson is that there is apparently enough extra labor at universities to export cultural appreciation of mathematics directly to many high school students. It’s hard to think of any real shortcoming to the “math circle” format. It may not scale up to the whole country, but I see no reason not to scale it up to more PhD-granting American research universities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-115")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")

#text("Dear Quant Jack,")

#text("It is somewhat ironic that people who choose non-mathematical careers in order to avoid “too much math” find that this lack of mathematical literacy comes back to haunt them at later stages of their career. I’ve seen investment bankers who need to learn Black-Scholes theory or other mathematical aspects of risk management, doctors who need to know advanced statistics in order to correctly follow current medical literature, and lawyers who need scientific literacy in order to handle expert testimony, not to mention understanding basic probability theory, rigorous definitions, and propositional logic. All three of them could also use mathematical literacy when it comes to more mundane tasks, such as selecting a mortgage for an expensive home.")

#text("I wouldn’t recommend mathematical academia for everyone – the main attractions are things like academic freedom, creative expression, intellectual challenge and satisfaction, (eventual) job security, flexible schedule, and lasting recognition or legacy, rather than purely monetary incentives – but I would definitely recommend mathematical ")#emph[#text("literacy")]#text(", both for its own intellectual sake and for its ability to enhance a surprisingly large number of careers. Though, if it is riches that is your primary goal, I can point to people such as ")#link("http://en.wikipedia.org/wiki/Sergey_Brin")[#text("Sergey Brin")]#text(" or ")#link("http://en.wikipedia.org/wiki/James_Harris_Simons")[#text("Jim Simons")]#text(" as examples of people who have used an advanced mathematical education to become extremely wealthy and successful. But it is worth noting that while intellectual ability and training can be converted into money, the converse is not always true: if you’re so rich, why are you not smart?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-116")[#strong[#text("Quant Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")

#text("Professor,")#linebreak()#text(" You indeed score valid intellectual points! It is easy to find many technically trained people who use technology (and luck) to become rich. And for every such rich techie, I can name an even more successful non-mathie (e.g., famous movie stars, writers, lawyers, politicians, investment bankers, even doctors) who might as well be mathematically illiterate because they don’t ever personally use anything beyond algebra (if that!) in their careers. But this example-counter-example sequence begs my question and does not address the problem at hand.")

#text("I am a practical fellow and the problem at hand is as follows. Suppose you are a youngster in America (such as your little boy) with life ahead of you. You want to take maximum advantage of all the opportunities America has to offer. You desire a happy, well rounded life, a wide circle of friends, a beautiful wife, wide travels, financial security, a career with high probability of success, and enough wealth to live in a great house in an upscale neighborhood, say, Bel Aire or Westwood. (Is this so unreasonable?) While you are reasonably intelligent (e.g., IQ = 100 – 125), you are not specially academically or mathematically gifted.")

#text("In this situation — which describes 90% of youngsters in middle America — what optimal strategy should a youngster adopt to achieve his aforementioned life goals? In particular, how much math should he study (if he doesn’t naturally enjoy math)? Should he take anything but the standard required math courses in high school and college? Why should he take AP Math? Why should he major in math instead of business, political science, communications, or pre-med, or pre-law? Why should he join Greg K’s “special math programs” instead of playing baseball with his friends? Why should he attend a “weekly high school math seminar” instead of enjoying his teen girl friend?")

#text("By the way, what do you advise your own kids?")

#text("QJ")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-119")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")

#emph[#text("Why should he join Greg K’s “special math programs” instead of playing baseball with his friends? Why should he attend a “weekly high school math seminar” instead of enjoying his teen girl friend?")]

#text("Jack,")

#text("My nephew, when asked, elected to go to math circle rather than trick or treating on Halloween. Why? He made a choice to do what he he has fun doing. It’s that simple. Apparently you do not like or understand math, and that’s your choice, but not necessarily the choice of others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-120")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2007")

#emph[#text("For every such rich techie, I can name an even more successful non-mathie (e.g., famous movie stars, writers, lawyers, politicians, investment bankers, even doctors) who might as well be mathematically illiterate because they don’t ever personally use anything beyond algebra (if that!) in their careers.")]

#text("There is a degree of illusion in your description of the rich people in America. A really tremendous amount of money has gone to technology in America; and even in some of the other professions, the most successful people are more mathematically literate than the others. Meanwhile very few writers or movie stars are rich, it’s rather that the few who are tend to flaunt their wealth. Most techies and businessmen tend to hide their wealth. So do many professors, for that matter. Some professors really do spend up to their credit limit, but some of them have saved a lot more money than you might expect.")

#text("That brings me to another issue, whether or why it’s worthwhile to be rich in the first place. Would you accept dementia for a million-dollar salary? (Some boxers and football players have made bargains of that sort.) I certainly wouldn’t. In my view, unless you have a certain amount of intellectual wealth, you’re not in a position to appreciate or even retain financial wealth. A striking fraction of lottery winners go bankrupt.")

#text("There are a great many Americans who fumble or quarrell away most of their money. The main reason is not a lapse of morality, because most people have a pretty good emotional sense of responsibility. Rather, the problem is that many people just do not trust or enjoy mathematics enough to make the right decisions. They splurge, they fret, they gamble, they overprotect idle cash, they accuse friends and relatives, they delegate the math to CPAs. They do everything but sit down and do the right calculation and act on it. As you say, it usually requires no more than high-school algebra. But even though most reasonably bright people have learned it, they have not learend enough beyond it to actually live by it.")

#text("On the flip side, if you do have enough intellectual wealth, you may not need a Bel Air mansion to be happy. I enjoy a raise just like everyone else, but I don’t really need my own swimming pool, because I’m perfectly happy with a long bike ride. I don’t enjoy spending money all that much; spending money just for fun is inane.")

#emph[#text("Why should he join Greg K’s “special math programs” instead of playing baseball with his friends?")]

#text("I completely respect playing sports with or without friends. (Frankly I think that baseball is boring, but there is basketball, ultimate, bicycling, etc.) My argument for a mathematics seminar for high school students is straight from “Green Eggs and Ham”. Just try it and see if you like it. I am confident that ")#emph[#text("at least")]#text(" 1 in 40 students, from high-school through college, can learn to enjoy recreational, proof-based math problems. Not just learn to do it, learn to enjoy it, whether or not you’re good at it. If you are able, you should certainly try, because it’s a wonderful, always-available, free life experience. It is also one way (certainly not the only way) to be a more logical thinker who does better at most jobs and doesn’t squander savings.")

#text("But the truth is that far fewer than 1 in 40 students are ever exposed to exciting, rigorous mathematics; it’s more like 1 in 1000. So I think that there is a lot of room for us mathematicians to popularize our tradition.")

#text("I am also confident that at least of half of high-school students could learn to enjoy word problems at the level of high school algebra. Or at least, learn to do them and not dislike them. It could make a real difference for their life experiences. Algebra-based word problems are much more accessible than proof-based problem-solving, so it’s not really the same educational issue, but it is related.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-121")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2007")

#text("This is perhaps somewhat tangential, but regarding the topic of explaining the nature and purpose of mathematics to a non-mathematical audience, Tim Gowers does an excellent job, both in his talk “")#link("http://www.ams.org/mathscinet-getitem?mr=2015543")[#text("The importance of mathematics")]#text("” (here’s the ")#link("http://claymath.msri.org/gowers2000.mov")[#text("video")]#text(" and ")#link("http://www.dpmms.cam.ac.uk/~wtg10/importance.pdf")[#text("slides")]#text(") and in his little book “")#link("http://www.oup.com/us/catalog/general/subject/Mathematics/?view=usa&ci=9780192853615")[#text("Mathematics: a very short introduction")]#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-124")[#strong[#text("Upcoming Activities... and Math Education « Less Drift, More Diffusion")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2007")

#text("[…] For an interesting read on this, check out Tery Tao’s recent blog entry. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-125")[#strong[#text("Quant Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2007")

#text(">> I can point to people such as Sergey Brin or Jim Simons as examples of people who have used an advanced mathematical education to become extremely wealthy and successful.")

#text("As a mathematician, why do you mis-use statistics? You should know better than to use extreme “tail” points to support your argument. The existence of Sergey Brey does not imply math is a good career choice any more than the existence of Shaq or Kareem Abdul Jabar proves that basketball is a good career choice for the average kid!")

#text("I also note that mathematics departments (maybe even the AMA) often mis-use statistics to try to attract math majors. In particular, many math depts put up stats touting that the “average starting salary” of a math major or actuary exceeds that of, say, the average starting salary of a business or political science major. This is a mis-use of statistics on two counts. First, if they do not control for incoming student characteristics (e.g., IQ, hours of effort invested in degree). It is likely that a high earnings math major would also earn more if s/he majored in business or pre-med — the earnings difference isn’t caused by the choice of major, its due to the innate hardworking character of the student. Second, starting salary does not reflect lifetime salary. Pre-law and business students start out lower than actuaries, but 10 years later, they are way, way ahead! If math depts are going to do a fair comparison of salaries associated with choice of major, they should compare expected lifetime salaries and control for differences of the incoming students. I have not doubt that, if they do the comparison fairly, a math degree, on average, leads to one of the LEAST rewarding careers from a financial compensation perspective. For every Terry Tao, there are a 1000 underpaid, overworked calculus teachers or math phds who can not find rewarding work in mathematics even though they “love” math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-126")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2007")

#text("Dear Quant Jack,")

#text("Sergey Brin and Jim Simons are indeed exceptional individuals, but they are also part of a much larger story. For instance, both of them run large and successful companies (Google and Renaissance Technologies), which together hire thousands of well-paid people for which mathematical literacy is an essential job requirement (and hundreds of ")#emph[#text("very")]#text(" well-paid people for which advanced mathematical education is similarly required). More broadly, they represent two major sectors of the modern economy (IT and finance) which both have an immense demand for the type of skills which are provided by mathematical training at both undergraduate and graduate levels. Maths departments routinely “lose” many of their fresh PhDs to lucrative careers in these (and other) sectors; there are real shortages created here that need to be addressed, because not enough good people are entering mathematics and related sciences. For instance, in the US, IT, finance, and academia all need to employ a significant fraction of their mathematical talent from overseas, in no small part because the domestic supply is insufficient to meet demand all by itself. In contrast, there is not exactly a shortage of people (in the US or elsewhere) lining up for an MBA or an MD.")

#text("If you have some figures for your “fair comparison of salaries”, you are welcome to share them here. As you point out, though, it is indeed a difficult task to do the maths correctly. For instance, which job is better financially: a $120K/year attorney job in which one works 60 hours/week and 12 months/year, or an $80K/year tenure-track academic job in which one works 40 hours/week and 9 months/year? (There is also the issue of repaying student loans for law or business school, while on the medical track there is also the issue of malpractice insurance; these are not entirely trivial financial burdens.) From the point of view of a “youngster in middle America”, one also needs to consider how competitive it will be to even get into the career track one is envisaging. Even the best and brightest students are not assured entry into the pre-med, law, or business school of their choice, due to the intense competition. In contrast, the top maths departments routinely compete for the first class prospective graduate students – because there are far too few bright students who want to do maths. The situation is of course more competitive for the more typical prospective graduate student in maths, but such a student would also have an even tougher time trying to get into law, business, or pre-med.")

#text("It would be a mistake to recommend one career as the “best” choice for everybody – just because (say) business careers are more lucrative than all others, does not mean that we should recommend that 100% of all students go into the business track (and discourage all interest in the other tracks). The love of the subject (and, of course, one’s natural talent for the subject) should of course be a major factor. As this discussion shows, though, students who have a potential love or talent for mathematics are often discouraged from achieving this potential for a number of reasons, including a lack of awareness of the career options that a mathematical education opens up (or equivalently, the many career options which become limited or even closed if one tries to avoid having too much maths in one’s education).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-128")[#strong[#text("KJY")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2007")

#text("“Second, starting salary does not reflect lifetime salary. Pre-law and business students start out lower than actuaries, but 10 years later, they are way, way ahead!”")

#text("I’m not sure about that. Recall that those who enter law and business credential themselves through formal schooling, usually before they enter the field, whereas actuaries credential themselves during their working years. If you look at the salary ")#link("http://www.actuaryjobs.com/salary.html")[#text("surveys")]#text(" by D.W. Simpson, an actuarial recruiting firm, you find that, for example, fellows of the Casualty Actuarial Society (fellow being the final step in the credentialing process) with 9.5-14.5 years of experience have compensation packages ranging from $138,000 to $270,000 (10th-90th percentiles). Fellows with 19.5+ years of experience have 10th-90th percentiles of $155,000-$421,000+.")

#text("A brief search for lawyer salaries yields the site ")#link("http://www.payscale.com/research/US/Job=Attorney_%2f_Lawyer/Salary")[#text("payscale.com")]#text(", which tells us that the median salary for lawyers/attorneys with 10-19 years of experience is $107,000, while the median salary for those with 20+ years of experience is $120,000. The ")#link("http://www.payscale.com/research/US/Job=Actuary/Salary")[#text("payscale.com")]#text(" entry for actuaries lists a 10-19 years median of $111,000, and a 20+ years median of $125,000, both of which are higher than the respective salaries for lawyers. The BLS’s ")#link("http://www.bls.gov/oco")[#text("occupational outlook handbook")]#text(" does tell us that a quarter of all lawyers make more than $143,000, and Monster’s salary center tells us that in Cleveland, Ohio (which is a relatively average cost-of-living area) the median salary for “Attorney III’s,” who typically have at least 5-8 years of experience, is about $147,000. So, there is some question as to whether the payscale.com numbers are entirely accurate, but in any case, I think the first paragraph shows that experienced, credentialed actuaries have salaries that are at least reasonably competitive with those of experienced, credentialed lawyers. Obviously, it would be better if someone was able to find more directly comparable numbers for lawyers.")

#text("Investment bankers will of course make more than actuaries, but it is not clear to me that it is worth sacrificing the best years of one’s life in order to make a huge amount of money later. I might add that most people who enter the field burn out; the managing directors and so forth who earn millions of dollars are not at all representative of the typical IB entrant.")

#text("Doctors also will tend to make more than actuaries, but at the cost of four years of medical school and four to eight years of residency, during which they rack up debt, and then struggle to live on a resident’s salary. We should also add that the much-hyped salaries of say, neurosurgeons and plastic surgeons, are totally different from those of say, internists and general practitioners.")

#text("Another point to make is that what mathematicians seem to be promoting is mathematical literacy, and the encouragement of serious interest in mathematics for those with the natural ability and curiosity for it. Mathematical literacy is beneficial for just about everyone, and as long as students are not “misled” into entering mathematics, the promotion of the field will only attract additional students inasmuch as those students are willing to forgo the apparently horrific compensation in exchange for whatever it is about mathematics that appeals to them. Mathematicians have never, to my knowledge, claimed that a math degree is for everyone, or that a math degree is the most lucrative option available.")

#text("On the topic of controlling for student characteristics, what about the fact that doctors, lawyers, etc, are apparently much, much more “well-rounded” than mathematicians? Perhaps most mathematicians are not capable of entering those other fields, due to their lack of well-roundedness, thus making a career in mathematics their ideal choice?")

#text("Finally, on being “well-rounded.” The distinction is often made that lawyers, doctors, executives, etc, are much more well-rounded than scientists, mathematicians, and engineers, and that this, in addition to salary considerations, means that the former are better careers, and more valuable to society. However, it was not well-rounded individuals who got us to where we are today; it was people who were extremely, extremely good at one or two things in particular. A well-rounded individual may be exceptionally talented at functioning within a given society, but he or she will never advance that society (unless, of course, he or she is a genius at everything). The rare example of Google is perhaps not directly relevant to an individual’s career choice*, but what it does is illustrate the enormous value of mathematics as a whole (especially in comparison to its meager cost), which then leads to the consideration that we should, in the interests of society, find ways of encouraging talented and interested students to choose careers in mathematics (i.e., to ")#emph[#text("make")]#text(" mathematics a good career choice).")

#text("* This is still not entirely true, as safe careers such as medicine or law are better-paying on average, but will not yield multi-billionaires such as Brin and Page. Thus, if individuals value greatly the tiny probability of becoming insanely rich, then the fact that two Stanford graduate students used mathematics to become billionaires could be relevant to their career decision. This same idea can be extended beyond mathematics to science and technology, neither of which tend to be as well-paying, on average, as medicine, law, or investment banking, but which will occasionally yield individuals who become far richer than any doctor, lawyer, or investment banker in existence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-129")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2007")

#text("In all honesty, research appointments in mathematics are so competitive that it’s hard for me to argue that there is a pressing shortage. There is certainly a shortage of Americans interested in research in mathematics, as evidenced by the fact that many mathematics departments are more than half foreign-born. For Americans, “Come study mathematics, because academia needs you badly!” is not really the right message, even though it is a popular message.")

#text("I think that mathematics departments, or NSF-funded programs, could do a lot more to connect undergraduate and graduate programs in mathematics to industry. Going to graduate school makes you want to be a research mathematician, even though the appointments are very competitive. And I suspect that many corporations don’t know to hire mathematicians, although it’s hard to blame them if the mathematicians don’t want to come. We could reform graduate training (for instance by including more computer programming) and post-graduate placement (for instance by encourging companies to use mathjobs.org) to justify the argument that more Americans should go to graduate school in mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-130")[#strong[#text("C.D.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2007")

#text("I really think you have a good point QJ. I’m a (bachelor-)student of mathematics (Univ. of. Copenhagen), and i often wonder about how my future is going to be? I thought I would give you my point of view, since I am very much in a situation relevant to the questions which you are discussing (I apologize for any spelling mistakes etc.):")

#text("I’m no wonder-kid, i just like mathematics a lot, and choose to study it, really because of it’s beautiful, beautiful nature (‘the Queen of sciences’ :-). I try to work hard and disciplined, and I would love to get a PhD some day, and to get a career doing research in pure mathematics.")#linebreak()#text(" But everywhere I turn I seem to be told that only the very best ‘gifted’ and ‘talented’ students will be able to have a somewhat successful international career; hard work isn’t enough, you need some sort of natural ability or gift, and if you didn’t compete in and won some mathematics-competition or learned to do calculus at age 10 you’re no good. if you haven’t got this ‘natural ability’, too bad if you love math and would love to spend your life doing mathematical research; you won’t be able to reach the level of those top mathematical researches. Perhaps if I am lucky, I will end up as assistant professor at the local university, never having published anything and spend all my time teaching…")

#text("So my question is really if I want to invest the next 5-10 years of my life, trying (most probably in vain) to achieve the level and skill required to do serious mathematical research. Spending many hours every day working on mathematical problems, reading and attending lectures (all of which i love), but probably never going to be able to make any original contribution. I’ll then end with a salary much lower than that of business student who never spend much time and energy studying.")

#text("And by the way, every time we (at the uni.) talk to business-representatives, they tell us: ‘Oh yes, the private industry-sector absolutely hires mathematicians, mainly because of their ability to think structured and analytical bla bla bla’. Although, we would very much prefer if you have some programming skills, or have taken some enginering-courses.’")#linebreak()#text(" So my only alternative is to take some job where I am never going to put to use anything I have learned during my 5 years at uni, and most important: not being able to work with mathematics.")

#text("Summa sumarum:")

#text("I consider myself an average mathematics student, perhaps with a somewhat ‘above-average’ will to do alot of studying. I absolutely love to study mathematics, but I am having no prospect of being able to get a career within mathematical research, and no prospect of otherwise using my knowledge somehow. Not heartening prospects at all!")#linebreak()#text(" At least, this is my impression of my status quo, here in Denmark.")

#text("Best regards C.D.")#linebreak()#text(" (Please forgive me for any grammatical mistakes, my English could be better.)")

#text("PS. A recent article in Scientific American (Aug. 2006) indicates that ‘effortful study’ is the key to becoming an expert within some field (of course), but much more important than presumed: ”The preponderance of psychological evidence indicates that experts are made, not born ”. This article have given me some hope, but still it doesn’t seem to rhyme with the general opinion on these matters. What are you’re opinions of all this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-131")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2007")

#emph[#text("Although, we would very much prefer if you have some programming skills, or have taken some enginering-courses.")]

#text("As I’ve been saying, I think that this is good advice. I have followed it myself. But it doesn’t mean that you shouldn’t study the theorems. For me, computer programming without mathematics is like sex without love.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-137")[#strong[#text("RK")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2007")

#text(">In all honesty, research appointments in mathematics are so competitive that it’s hard for me to argue that there is a pressing shortage. There is certainly a shortage of Americans interested in research in mathematics, as evidenced by the fact that many mathematics departments are more than half foreign-born.")

#text("As someone who works with maths in industry, I simply don’t see a need for more advance math research and probably a lot less should be done that what is going on in academia. I believe most math majors like me in industry find it too esoteric and self-centered for maths done for its own sake, without any regards to real-world applications. I am not saying it shouldn’t be done by a select few geniuses, since it is what they do best and could possibly lead to some breakthrough applications in the future, but for the majority of the math-loving populace, it’s a plain waste of time and should not be supported by tax dollars. Government funding for basic research in math or any other pure sciences are probably bloated, which explains why all these advance math department are seeing so many foreign-borns, when taking away these fundings would do more good and discourage such overt foreign slave-labor. The way I see it, more funding for applied math research and better math teachers who know how math is applied to everyday living is the way to improve our current maths situation. There’s too many ivory towers with their wizards and elves (publishing unfathomable works of doubtful benefit) that creates this feeling of apathy and even some resentment towards advance maths. Paring it down to a select few would more likely create the feeling of wonder and respect. I see a good analogy in the movie X-men between mutants and advance math researchers (AMR for short). How many more AMRs does the general populace need before intolerance takes over ? By the way, it has happened before in history, persecution of intellects in China and Iran are some well-known cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-139")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2007")

#text("Dear RK,")

#text("I have seen mathematicians compared to several things, but to be equated to X-men is a new one for me. Certainly it would be nice to have some sort of secret super-power. :-)")

#text("The proposal to subdivide math into “useful math” and “useless math”, and then save money by defunding the latter, has come up in the past. The ")#link("http://www.dpmms.cam.ac.uk/~wtg10/importance.pdf")[#text("talk of Tim Gowers")]#text(" that I mentioned in an earlier post already addresses the problems with this proposal rather well, but I can recap some of Tim’s points here.")

#text("Firstly, the cost-benefit ratio of mathematics is quite large: a mathematical breakthrough (e.g. fast linear programming algorithms, to name one at random) can benefit multiple sciences at once, and doesn’t require expensive labs or field tests. There are many examples of waste in government spending, but math research is nowhere near the dominant contribution to such. (See for instance ")#link("http://thebudgetgraph.com/view/")[#text("this graphic depiction of the US discretionary federal budget")]#text(" to get some idea of the relative size of the NSF (the main federal funding body for mathematics in the US) against other government agencies.)")

#text("Secondly, the benefit of mathematics can come from unexpected sources. Elliptic curves, for instance, would likely have been placed on hypothetical lists of “useless mathematics” for decades, right up until they turned out to be of major importance in cryptography. It is not entirely clear at present what fields of mathematics will contribute to the sciences of the future (e.g. protein folding or quantum computing), but it may well be ones which previously have seen very little application.")

#text("Finally, maths is much more highly interconnected than one may think; individual researchers may only focus on one or two fields, but collectively every field is connected to every other by a surprisingly small number of degrees of separation. It becomes rather self-defeating to try to draw a sharp line between useful and useless. Tim gives some examples in his talk, but I can give one from my own research experience. The closest thing I have to a “useful” research product is my work with Emmanuel Candes on compressed sensing, which has helped lead to the development of ")#link("http://www.dsp.ece.rice.edu/cscamera/")[#text("a new type of camera")]#text(" as well as my ")#link("http://www.freepatentsonline.com/20070016837.html")[#text("only patent")]#text(". This work resulted from ")#link("http://www.ams.org/mathscinet-getitem?mr=2236170")[#text("investigations into random minors of Fourier matrices")]#text(", which resulted in part from ")#link("http://www.ams.org/mathscinet-getitem?mr=2122735")[#text("my work on the uncertainty principle in cyclic groups")]#text(", which resulted from ")#link("http://www.math.ucla.edu/~tao/254a.1.03w/notes1.dvi")[#text("my attempt to understand the Cauchy-Davenport inequality")]#text(", which resulted from my attempt to understand the additive combinatorics underlying ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("Gowers’ work")]#text(", which resulted from ")#link("http://www.ams.org/mathscinet-getitem?mr=1739220")[#text("my attempt with Nets Katz")]#text(" to understand and improve the additive combinatorics underlying a ")#link("http://www.ams.org/mathscinet-getitem?mr=1692486")[#text("paper of Bourgain")]#text(", which resulted from my attempt to understand the Kakeya conjecture, which originally was a ")#link("http://en.wikipedia.org/wiki/Kakeya_set")[#text("cute but impractical problem on how to rotate a needle around in the plane")]#text(". At each stage of this process I was unaware of where next my investigations would take me, and it was a fair surprise to me to realise that my pure mathematical research had suddenly taken on a practical dimension. But this type of thing happens surprisingly often in a fundamental science such as mathematics.")

#text("(Note: for some reason two earlier posts from Deane Yang were automatically flagged as spam, and I only discovered this by accident today; they are now visible.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-47423")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2010")

#text("wow… i will be careful next time I rotate a needle:)!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-143")[#strong[#text("RK")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2007")

#text(">I have seen mathematicians compared to several things, but to be equated to X-men is a new one for me. Certainly it would be nice to have some sort of secret super-power. :-)")

#text("Thank you Terry. It is interesting that you don’t see yourself as having some secret superpower, and it feels somewhat disconcerting. If you solve a problem in less than 10 seconds while the person sitting next to you is still fumbling with it for an hour … well, you get the picture. In the Xmen movie, the mutants do tend to consider themselves as the “normal” people, while the rest of the population are treated by them as “subnormal”. Gaussian statistics dictates otherwise , don’t you agree ? Fortunately, we live in a world where one can be a dumbass in math, and be a genius in basketball :)")

#text(">Firstly, the cost-benefit ratio of mathematics is quite large: a mathematical breakthrough (e.g. fast linear programming algorithms, to name one at random) can benefit multiple sciences at once, and doesn’t require expensive labs or field tests. There are many examples of waste in government spending, but math research is nowhere near the dominant contribution to such. (See for instance this graphic depiction of the US discretionary federal budget to get some idea of the relative size of the NSF (the main federal funding body for mathematics in the US) against other government agencies.)")

#text("as I said, funding needs to be optimized, so only the deserving gets it. Not an easy thing to do I have to concede. In any case, in a free and efficient economy, NSF or other basic research funding should be small and and remain small. Out of 100 basic math proposals only 5 should be funded. Which 5 to pick is another matter for discussion. Other agencies are getting the lion’s share simply because it is what the market dictates. I would argue that most math breakthroughs occur in industry (like your fast linear programming example), not in academia. Just like in the old times, it’s the practical problems that create new useful maths (Newton, Bernoullis, Fourier are great examples). You mentioned elliptic curves. In the cryptographic field , of which I’m a bit familiar, they’re treated more as a curiosity rather than having any real applications. There are far better and sophisticated algorithms that are invented because of the need for secure communication. I happen to believe that necessity is the mother of all useful inventions. You might have invented a better mousetrap or some other trap where it’s not clear what use it may have in the future, but until someone needs it or sees a need for it, you fund it yourself first.")

#text("It seems to me that your camera patent resulted from your friend’s need to solve a practical problem, which you happened to do or have done so already. It is entirely possible that if he hadn’t met you, he’ d end up reinventing what you did with Fourier matrices, or something even new. However, kudos to you for even tackling one practical problem! I’ve had encounters with college math professors who treat any practical uses in their subject of expertise as if it were a pile of dung! (I distinctly remember one waving his hands as if having a shock) . The connections you mentioned are quite impressive, but it still require that conscious effort to make the last practical one. I imagine you have this tree of connections, that unless it ends in a leaf or flower or a fruit, will simply keep on branching nowhere. Not a pretty tree to see. I also want this tree to grow a branch where it needs to. Otherwise, I cut off all the unkempt branches. If I need an apple, I’d grow an apple tree. Someone out there likes to grow many kinds of trees for its own sake, you can do that on your own time and money. Of course, someone might need an orange in the future and you hit the jackpot if you have one, it doesn’t happen often I’m sure. Now if that camera end up in my house someday, I’d have you to thank for :).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-144")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2007")

#text("Unfortunately, RK, apple trees, like most trees, take a very long time to grow, mature, and produce fruit, acorns, or whatever. You’ll starve to death long before the apples appear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2007")

#text("Dear RK,")

#text("I actually think that the concept of “secret superpowers”, in maths (or elsewhere), is in fact rather damaging, as it conveys the impression that maths is inaccessible to mere mortals, requiring some sort of “X-men gene” in order to play. (See also “")#link("http://cosmicvariance.com/2007/02/25/the-cult-of-genius/")[#text("the cult of genius")]#text("“.) In reality, good mathematical work can be accomplished by anyone of reasonable intelligence given the right resources (interest, education, time, patience, work ethic, study ethic, access to literature, exposure to mathematical culture, inquisitiveness, good mentorship, and so forth); in that sense, it is not terribly different from other skilled professions. (Of course, giving people access to these resources is non-trivial, and is basically the original topic of this discussion.) Raw talent is of course a factor, but the differences in quality between mathematicians are mostly a matter of degree rather than kind, excepting perhaps some very rare true geniuses (Ramanujan comes to mind) who did indeed have extraordinary natural gifts. As a child, I myself was not actually able to solve hour-length problems in 10 seconds; nowadays, I can occasionally pull it off, but only because I happen to have 10 ")#emph[#text("years")]#text(" of experience in the problem area. Ultimately it is long-term skills and experience which matter the most; initial talent may help one achieve short-term goals such as a university degree, but it is not the decisive factor in long-term success.")

#text("Now regarding the relative “practicality” of different types of mathematics. It is indeed true that pure maths, applied maths, and industrial maths all have different goals, mindsets, and priorities, and many mathematicians specialise in just one of these spheres and neglect the other two. However, mathematicians in all three spheres use (essentially) the same mathematical language, and publish in journals which are generally accessible to mathematicians in the other two spheres. As a consequence, it is not necessary (or even desirable) to get every single mathematician involved (or even interested) in every single sphere. As long as there is a significant minority of interdisciplinary mathematicians who can take the published research from one sphere and apply it to the other, it is in fact a much more efficient division of labour to encourage those who have talents in pure maths to specialise in pure maths, and similarly for applied, industrial, or interdisciplinary mathematics. A typical pure mathematician may have no interest in applications (or vice versa), but the research produced will appear in journals, conferences, or in conversations with other mathematicians, and it only takes a single mathematician with an interdisciplinary mindset to pick up on the potential of that research to transfer it to another area.")

#text("Of course it is not true that all research is of equal value; the best examples of good mathematics are indeed focused on one or more goals – not only immediate applications, but also addressing more fundamental questions, such as trying to formalise and understand a mysterious mathematical phenomenon. All of these goals are important, and surprisingly often the pursuit of one goal can lead to unexpected progress on other goals (cf. Wigner’s “")#link("http://en.wikipedia.org/wiki/The_Unreasonable_Effectiveness_of_Mathematics_in_the_Natural_Sciences")[#text("unreasonable effectiveness of mathematics")]#text("“). See also my article on “")#link("http://arxiv.org/abs/math.HO/0702396")[#text("what is good mathematics?")]#text("“.")

#text("p.s. Regarding elliptic curves, the NSA’s “")#link("http://en.wikipedia.org/wiki/NSA_Suite_B")[#text("Suite B")]#text("” set of cryptographic algorithms, which may well become a standard in the near future, ")#emph[#text("exclusively")]#text(" uses elliptic curve cryptography for digital signatures and key exchange (though of course other types of cryptography are used for hashing or symmetric-key encryption). Also, ")#link("http://en.wikipedia.org/wiki/Lenstra_elliptic_curve_factorization")[#text("elliptic curve factoring methods")]#text(" are still widely used for medium-length numbers for which both trial division and number field sieve type methods are impractical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-148")[#strong[#text("van vu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2007")

#text("To RK,")

#text("You wrote:")

#text("as I said, funding needs to be optimized, so only the deserving gets it. Not an easy thing to do I have to concede. In any case, in a free and efficient economy, NSF or other basic research funding should be small and and remain small. Out of 100 basic math proposals only 5 should be funded. Which 5 to pick is another matter for discussion.")

#text("—————————————-")#linebreak()#text(" What you wrote is actually not too far from the truth (:=((. I am not sure we have free and efficient economy, but NSF funding for math is certainly small. It costs about the making of Water World (very bad movie–if you have not seen it, don’t) to fund the whole math community in the US. Furthermore, if every eligible faculties")#linebreak()#text(" applies for funding, the acceptance ratio would be far worse than 5/100 !!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-149")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2007")

#emph[#text("I actually think that the concept of “secret superpowers”, in maths (or elsewhere), is in fact rather damaging, as it conveys the impression that maths is inaccessible to mere mortals, requiring some sort of “X-men gene” in order to play.")]

#text("Of course it is defeatist to believe that mathematics research is only for a handful of geniuses. It’s hard to think of what to say to people who want to believe that. I would go back to the “Green Eggs and Ham” argument: Just try proof-based mathematics and see if you like it. Worry later about whether you would enjoy a career in it.")

#text("If it is meant as an argument against mathematics funding, then as Van Vu says, funding is already extremely competitive. NSF funds a great range of first-rate work with very little money. In a sense, Congress could hardly fund it less. Research mathematics funding could be viewed as an accident; it survives because it is a good thing and it is below the radar. Many Congressmen may not even know that it exists.")

#emph[#text("It costs about the making of Water World")]

#text("Right, one year of NSF funding of mathematics costs about the same as one high-budget Hollywood movie. Ten years of NSF funding of mathematics costs less than the Chandra X-Ray Telescope. If all research in mathematics together is cheaper than just one telescope, then it really is almost nothing given the great range of work. And nobody debates whether telescopic astronomy is practical; it is funded just because it’s cool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-150")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2007")

#text("By the way, there is another direction in math education which maybe you or we should speak to. Home schooling is very popular in the United States these days. To be sure, mathematical prodigies have to have some degree of special studies with elements of home schooling. In some circles, mathematical prodigies come across as a kind of jackpot of radical educational choices: “Unleash the genius within your child”, “see what home schooling can do”, “see what public schools can’t do”, etc.")

#text("Now, I certainly think that many public school policies are too rigid, and that public schools could teach mathematics better. But I have even less happy about overpromotion of home schooling. I can accept a right to home schooling. But even passable home schooling is hard work; good home schooling is even harder work. It is especially troublesome that parents are not in a position to criticize themselves for falling short. Bucking the system just for its own sake is a mistake.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-152")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2007")

#text("One should not be too critical of home schooling.")

#text("Public schools do not exist to teach mathematics. They exist to integrate students into society. The two goals are perhaps not so compatible.")

#text("Another thing one might add is that there is plenty that university faculty")#linebreak()#text(" can do to aid the progress of home schooling in general. Home schoolers")#linebreak()#text(" are hungry for ideas and materials. Often much more so than teachers.")

#text("Nets")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-154")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")

#text("Regarding math funding:")

#text("The MONEY spent on math seems indeed to be negligible compared both to other fields")#linebreak()#text(" and to its benefits, so let’s approximate it by zero.")#linebreak()#text(" However, I think what was missed in previous comments is the TRUE RESOURCE here,")#linebreak()#text(" which is the talent and time of all these smart people spending their life doing pure math.")#linebreak()#text(" Surely, it sometimes brings to unpredictable and useful things.")#linebreak()#text(" But many of these talented people can surely contribute much to more applied")#linebreak()#text(" fields in science and engineering (simons and brin are great examples, and also eric lander)")

#text("The true question is, had all these terry tao’s and their likes worked on applied problems in")#linebreak()#text(" engineering and science, wouldn’t their work lead to more useful stuff?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")

#emph[#text("But many of these talented people can surely contribute much to more applied fields in science and engineering (simons and brin are great examples, and also eric lander)")]

#text("To some extent, this is what is already happening. I just happened across this cover story “")#link("http://www.businessweek.com/magazine/content/06_04/b3968001.htm?chan=search")[#text("Math will rock your world")]#text("” in, of all things, BusinessWeek, which broadly (if a bit breathlessly) describes how maths is permeating various modern industries. And as discussed above, there are certainly financial incentives to work in areas other than academia. All of this does lead to shortages of mathematical talent at the higher levels, although as Greg pointed out above this is unfortunately not always translating into increased openings in academia.")

#text("But we don’t live in a centrally planned economy, and people also have the right to work in the field they enjoy the most, and get the most satisfaction out of, even if it is not the most “productive” in a utilitarian or financial sense. One should also bear in mind ")#link("http://en.wikipedia.org/wiki/Comparative_advantage")[#text("Ricardo’s law of comparative advantage")]#text(". Just because someone has some absolute advantage in, say, creating new widgets, does not mean that this is necessarily the best thing for that person to do, because he or she may have an even stronger ")#emph[#text("comparative")]#text(" advantage, in, say, proving theorems. For instance, a talented mathematician might be able to design widgets 1.5 times more efficiently than your average widget designer, but might also be able to prove theorems 100 times more efficiently than the widget designer. It is then more efficient to let the widget designer design the widgets, and let the mathematician prove the theorems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-157")[#strong[#text("ST")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")

#text("Mr. oz:")#linebreak()#text(" You must be religious(scientology?) becasue your rhetorical question presumes the existence of some mighty beings who will continue to provide the essential tools like calculus and number theory so that the terry tao’s and their likes can work on applied problems in engineering and science.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-158")[#strong[#text("Khoa Tran")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")

#text("Terry raised a good point on “Comparative Advantage”.")

#text("To address Oz’s question “had all these terry tao’s and their likes worked on applied problems in engineering and science, wouldn’t their work lead to more useful stuff?”, I’d like to add another argument, although it’s non-falsifiable. Had Terry Tao worked on Engineering, I doubt that he would have contributed to Engineering as much as he has done in Mathematics.")

#text("As Terry pointed out earlier, a person’s productivity/talent depends so much on his passion and hard work rather than raw intelligence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-159")[#strong[#text("kt")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")

#text("on math funding…")

#text("is it feasible to patent certain mathematical results so that royalt fees can be collected for commercial applications that make use of the results? the fees can then go into the “International Monetary Fund For The Advancement Of Mathematics”.")

#text("kt")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-161")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2007")

#text("ST:")

#text("I’m not religious. The question wasn’t rhetoric but a real one.")#linebreak()#text(" Sorry for the word ‘all’ which is a bit too strong – I actually meant ‘some/most’.")#linebreak()#text(" Anyway, the comparative advantage and ‘do what you like’ arguments are good ones. Still its a matter of finding the correct balance. Whether society would be better off with more/less pure mathematicians than there are today I guess nobody could ever tell.")

#text("“Had Terry Tao worked on Engineering, I doubt that he would have contributed to Engineering as much as he has done in Mathematics. ”")

#text("Probably true. But there are opposite examples like Shannon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2007")

#text("WHY DO PEOPLE HAVE TO KNOW MATHEMATICS BEYOND THE LEVEL WHICH THEY ARE TO TEACH ? 1 2 [Next]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-165")[#strong[#text("zf")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2007")

#text("Dear RK")

#text("You said “Government funding for basic research in math or any other pure sciences are probably bloated, which explains why all these advance math department are seeing so many foreign-borns, when taking away these fundings would do more good and discourage such overt foreign slave-labor.”")

#text("I am from a third-world nation. I intend on pursuing a math phd from a good school in the US. I doubt i’m ‘slave labor’. I want to go to the US because it has many good mathematicians. Your phrase sheds much light on the limitations of your thinking.")#linebreak()#text(" Moreover, I do math not because it has applications…its a bit like asking a musician why he makes patterned sound-waves which can’t be used for anything (perhaps heavy metal can scare away crows?).")#linebreak()#text(" Perhaps you’ve never felt joy doing math.")#linebreak()#text(" Strangely this is not much different from the joy ive seen felt by my physics peers..i remember being asked in my first year by a math student what possible use could there be of hilbert spaces…he shifted to physics…he loves QM and now he loves functional analysis too…but not ONLY because it has uses in QM or because its a beautiful fact that beautiful math explains deep things about nature. But because he now apprehends the beauty of the idea.")#linebreak()#text(" When i or any other serious student of math (even physics and some eco students) do math, applications is the last thing on out minds. Its not even a goal. And remember i come from a third world country — earning ‘big bucks’ is a big thing for us and we are aware of the fact that a banker gets more money than a mathematician. And yet many of us want to stick to the ‘irrational’ choice of taking up math as a career and perhaps come to the US where the pay for being just a phd student is better than what it is in my country (that helps, I wouldnt care to own a bentley, but its nice to be able to buy a small house and pay for your kids education).")

#text("– zf")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-174")[#strong[#text("On genius and hard work « Mulling Math")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2007")

#text("[…] of this cult of all, it does permeate math as well. Terry Tao in particular mentions this here and more extensively in his excellent career […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-305")[#strong[#text("Simons Lecture I: Structure and randomness in Fourier analysis and number theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2007")

#text("[…] lectures at MIT. (These lectures, incidentally, are endowed by Jim Simons, who was mentioned in some earlier discussion here.) While preparing these lectures, it occurred to me that I may as well post my lecture notes on my […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-680")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")

#text("Thank You")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-1307")[#strong[#text("Not Even Wrong » Blog Archive » All Sorts of Links")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2007")

#text("[…] Terry Tao writes a long explanation of Why Global Regularity for Navier-Stokes is Hard. He also comments about the recent New York Times piece about him and about math education issues. The comment […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-23464")[#strong[#text("AMS lecture: Structure and randomness in the prime numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2008")

#text("[…] many times before, (e.g. at my Simons lecture at MIT, my Milliman lecture at U. Washington, and my Science Research Colloquium at UCLA), and I have given similar talks to the one here – which focuses on my original 2004 paper with Ben […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/comment-page-1/#comment-90797")[#strong[#text("Peter L. Griffiths.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")

#text("The crucial ages for learning maths are from ages 10 to 15, good maths teachers are important for this age group. After 15 the student can learn further maths from good text books and from the Internet which is the best thing to happen to maths since the discovery of logarithms. The self-teaching of maths is badly ignored by most educationalists.")
]
