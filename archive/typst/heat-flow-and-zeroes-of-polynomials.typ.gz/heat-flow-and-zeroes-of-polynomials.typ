// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/
// Converted to Typst by tao2typ: "2026-10-17T11:01:22.768105+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Heat flow and zeroes of polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Heat flow and zeroes of polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 October 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")[#text("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-17 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{P(z) = z^n + a_{n-1} z^{n-1} + \\dots + a_0}")#text(" be a monic polynomial of degree ")#mi("{n}")#text(" with complex coefficients. Then by the fundamental theorem of algebra, we can factor ")#mi("{P}")#text(" as ")#metadata(none) <tao-3fd3d5b7f767d3534882>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P(z) = (z-z_1) \\dots (z-z_n)")]]

#text("for some complex zeroes ")#mi("{z_1,\\dots,z_n}")#text(" (possibly with repetition).")

#text("Now suppose we evolve ")#mi("{P}")#text(" with respect to time by heat flow, creating a function ")#mi("{P(t,z)}")#text(" of two variables with given initial data ")#mi("{P(0,z) = P(z)}")#text(" for which ")#metadata(none) <tao-9d017e2681b7f31725e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t P(t,z) = \\partial_{zz} P(t,z).")]]

#text("On the space of polynomials of degree at most ")#mi("{n}")#text(", the operator ")#mi("{\\partial_{zz}}")#text(" is nilpotent, and one can solve this equation explicitly both forwards and backwards in time by the Taylor series")

#align(center)[#tao-fit-display[#mitex("P(t,z) = \\sum_{j=0}^\\infty \\frac{t^j}{j!} \\partial_z^{2j} P(0,z).")]]

#text("For instance, if one starts with a quadratic ")#mi("{P(0,z) = z^2 + bz + c}")#text(", then the polynomial evolves by the formula")

#align(center)[#tao-fit-display[#mitex("P(t,z) = z^2 + bz + (c+2t).")]]

#text("As the polynomial ")#mi("{P(t)}")#text(" evolves in time, the zeroes ")#mi("{z_1(t),\\dots,z_n(t)}")#text(" evolve also. Assuming for sake of discussion that the zeroes are simple, the inverse function theorem tells us that the zeroes will (locally, at least) evolve smoothly in time. What are the dynamics of this evolution?")

#text("For instance, in the quadratic case, the quadratic formula tells us that the zeroes are")

#align(center)[#tao-fit-display[#mitex("z_1(t) = \\frac{-b + \\sqrt{b^2 - 4(c+2t)}}{2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("z_2(t) = \\frac{-b - \\sqrt{b^2 - 4(c+2t)}}{2}")]]

#text("after arbitrarily choosing a branch of the square root. If ")#mi("{b,c}")#text(" are real and the discriminant ")#mi("{b^2 - 4c}")#text(" is initially positive, we see that we start with two real zeroes centred around ")#mi("{-b/2}")#text(", which then approach each other until time ")#mi("{t = \\frac{b^2-4c}{8}}")#text(", at which point the roots collide and then move off from each other in an imaginary direction.")

#text("In the general case, we can obtain the equations of motion by implicitly differentiating the defining equation")

#align(center)[#tao-fit-display[#mitex("P( t, z_i(t) ) = 0")]]

#text("in time using ")#link(<tao-9d017e2681b7f31725e1>)[#text("(2)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_{zz} P( t, z_i(t) ) + \\partial_t z_i(t) \\partial_z P(t,z_i(t)) = 0.")]]

#text("To simplify notation we drop the explicit dependence on time, thus")

#align(center)[#tao-fit-display[#mitex("\\partial_{zz} P(z_i) + (\\partial_t z_i) \\partial_z P(z_i)= 0.")]]

#text("From ")#link(<tao-3fd3d5b7f767d3534882>)[#text("(1)")]#text(" and the product rule, we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_z P( z_i ) = \\prod_{j:j \\neq i} (z_i - z_j)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{zz} P( z_i ) = 2 \\sum_{k:k \\neq i} \\prod_{j:j \\neq i,k} (z_i - z_j)")]]

#text("(where all indices are understood to range over ")#mi("{1,\\dots,n}")#text(") leading to the equations of motion ")#metadata(none) <tao-bb273c8b634624978d75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t z_i = \\sum_{k:k \\neq i} \\frac{2}{z_k - z_i},")]]

#text("at least when one avoids those times in which there is a repeated zero. In the case when the zeroes ")#mi("{z_i}")#text(" are real, each term ")#mi("{\\frac{2}{z_k-z_i}}")#text(" represents a (first-order) attraction in the dynamics between ")#mi("{z_i}")#text(" and ")#mi("{z_k}")#text(", but the dynamics are more complicated for complex zeroes (e.g. purely imaginary zeroes will experience repulsion rather than attraction, as one already sees in the quadratic example). Curiously, this system resembles that of ")#link("https://terrytao.wordpress.com/tag/dyson-brownian-motion/")[#text("Dyson brownian motion")]#text(" (except with the brownian motion part removed, and time reversed). I learned of the connection between the ODE ")#link(<tao-bb273c8b634624978d75>)[#text("(3)")]#text(" and the heat equation from ")#link("http://www.ams.org/mathscinet-getitem?mr=1260363")[#text("this paper of Csordas, Smith, and Varga")]#text(", but perhaps it has been mentioned in earlier literature as well.")

#text("One interesting consequence of these equations is that if the zeroes are real at some time, then they will stay real as long as the zeroes do not collide. Let us now restrict attention to the case of real simple zeroes, in which case we will rename the zeroes as ")#mi("{x_i}")#text(" instead of ")#mi("{z_i}")#text(", and order them as ")#mi("{x_1 < \\dots < x_n}")#text(". The evolution")

#align(center)[#tao-fit-display[#mitex("\\partial_t x_i = \\sum_{k:k \\neq i} \\frac{2}{x_k - x_i}")]]

#text("can now be thought of as reverse gradient flow for the “entropy”")

#align(center)[#tao-fit-display[#tao-math("H := -\\sum_{i,j: i \\neq j} \\log \\left|x_i - x_j\\right|,", block: true)]]

#text("(which is also essentially the logarithm of the ")#link("https://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" of the polynomial) since we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t x_i = \\frac{\\partial H}{\\partial x_i}.")]]

#text("In particular, we have the monotonicity formula")

#align(center)[#tao-fit-display[#mitex("\\partial_t H = 4E")]]

#text("where ")#mi("{E}")#text(" is the “energy”")

#tao-aligned(keep: true)[


#tao-math("E  & := \\frac{1}{4} \\sum_i (\\frac{\\partial H}{\\partial x_i})^2", block: true)



#tao-math(" & = \\sum_i (\\sum_{k:k \\neq i} \\frac{1}{x_k-x_i})^2", block: true)



#tao-math(" & = \\sum_{i,k: i \\neq k} \\frac{1}{(x_k-x_i)^2} + 2 \\sum_{i,j,k: i,j,k \\text{ distinct}} \\frac{1}{(x_k-x_i)(x_j-x_i)}", block: true)



#tao-math(" & = \\sum_{i,k: i \\neq k} \\frac{1}{(x_k-x_i)^2}", block: true)
]

#text("where in the last line we use the antisymmetrisation identity")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(x_k-x_i)(x_j-x_i)} + \\frac{1}{(x_i-x_j)(x_k-x_j)} + \\frac{1}{(x_j-x_k)(x_i-x_k)} = 0.")]]

#text("Among other things, this shows that as one goes backwards in time, the entropy decreases, and so no collisions can occur to the past, only in the future, which is of course consistent with the attractive nature of the dynamics. As ")#mi("{H}")#text(" is a convex function of the positions ")#mi("{x_1,\\dots,x_n}")#text(", one expects ")#mi("{H}")#text(" to also evolve in a convex manner in time, that is to say the energy ")#mi("{E}")#text(" should be increasing. This is indeed the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\partial_t E = 2 \\sum_{i,j: i \\neq j} (\\frac{2}{(x_i-x_j)^2} - \\sum_{k: i,j,k \\text{ distinct}} \\frac{1}{(x_k-x_i)(x_k-x_j)})^2.")]]
]

#text("Symmetric polynomials of the zeroes are polynomial functions of the coefficients and should thus evolve in a polynomial fashion. One can compute this explicitly in simple cases. For instance, the center of mass is an invariant:")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\frac{1}{n} \\sum_i x_i = 0.")]]

#text("The variance decreases linearly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Establish the ")#link("https://en.wikipedia.org/wiki/Virial_theorem")[#text("virial identity")]

#align(center)[#tao-fit-display[#mitex("\\partial_t \\sum_{i,j} (x_i-x_j)^2 = - 4n^2(n-1).")]]
]

#text("As the variance (which is proportional to ")#mi("{\\sum_{i,j} (x_i-x_j)^2}")#text(") cannot become negative, this identity shows that “finite time blowup” must occur – that the zeroes must collide at or before the time ")#mi("{\\frac{1}{4n^2(n-1)} \\sum_{i,j} (x_i-x_j)^2}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that the ")#emph[#text("Stieltjes transform")]

#align(center)[#tao-fit-display[#mitex("s(t,z) = \\sum_i \\frac{1}{x_i - z}")]]

#text("solves the ")#link("https://en.wikipedia.org/wiki/Burgers%27_equation")[#text("viscous Burgers equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t s = \\partial_{zz} s - 2 s \\partial_z s,")]]

#text("either by using the original heat equation ")#link(<tao-9d017e2681b7f31725e1>)[#text("(2)")]#text(" and the identity ")#mi("{s = - \\partial_z P / P}")#text(", or else by using the equations of motion ")#link(<tao-bb273c8b634624978d75>)[#text("(3)")]#text(". This relation between the Burgers equation and the heat equation is known as the ")#link("https://en.wikipedia.org/wiki/Burgers%27_equation")[#text("Cole-Hopf transformation")]#text(".")
]

#text("The ")#link("http://www.ams.org/mathscinet-getitem?mr=1260363")[#text("paper of Csordas, Smith, and Varga")]#text(" mentioned previously gives some other bounds on the lifespan of the dynamics; roughly speaking, they show that if there is one pair of zeroes that are much closer to each other than to the other zeroes then they must collide in a short amount of time (unless there is a collision occuring even earlier at some other location). Their argument extends also to situations where there are an infinite number of zeroes, which they apply to get new results on ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("Newman’s conjecture")]#text(" in analytic number theory. I would be curious to know of further places in the literature where this dynamics has been studied.")

#heading(level: 1)[#text("Comments (40)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06b05ef2296888461077f6c2d31422f49e53a54baa671c53ba080ab262567d94-2457c90619dea003d93905ee244c722dd0ffebd3b08b50b4e6cbf5efbd60140d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487715")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("The equations of motion of point vortices (which solve the 2d Euler equations) satisfy an equation similar to your (3). See equation (6) of Aref’s Annual Review on vortex dipoles:")#linebreak()#text(" ")#link("http://www.annualreviews.org/doi/pdf/10.1146/annurev.fl.15.010183.002021")[#text("http://www.annualreviews.org/doi/pdf/10.1146/annurev.fl.15.010183.002021")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1eee564adb905c9ce9f9c36f5df15b1d725feacc10e6a229a6bd4188b1b467e-2afa0fa34935967598dce73dffd9484b0cf1342aa26799a4e0262d28aadde64c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MatjazG")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487835")[#strong[#text("MatjazG")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("It looks very similar indeed, except for a rotation of each velocity ")#mi("\\partial_t z_i")#text(" by 90° (in the complex plane) and complex conjugation. Namely, the vortices tend to swirl around one another, not collide as the polynomial zeros tend to do under heat flow. In fact, the motion of vortices is described by a Hamiltonian dynamical system (for equal strength vortices ")#mi("Re(z_i)")#text(" is the generalized position and ")#mi("Im(z_i)")#text(" is the generalized momentum) where the conserved Hamiltonian is, for equal strength vortices, precisely the entropy defined for the heat flow ")#tao-math("H \\propto -\\sum_{i,j : i \\neq j} \\log \\left|z_i - z_j\\right|", block: false)#text(". This immediately shows that point 2D vortices can in fact never collide.")

#text("We can get a bit closer to vortex motion if we Wick rotate (meaning we replace ")#mi("t")#text(" with ")#mi("it")#text(", i.e., we evolve “in complex time”) the heat Eq. (2) into the Schrödinger equation: ")#mi("i \\partial_t P = -\\partial_{zz} P")#text(". Then the Wick rotated solution for the polynomial zeroes Eq. (3) acquires an extra ")#mi("i")#text(" which is needed to rotate the velocity ")#mi("\\partial_t z_i")#text(" by 90° in the complex plane. The “only” thing that is missing is complex conjugation of the velocity (i.e. reflection across the real line).")

#text("This missing complex conjugation is quite important, however, as at least my numerical simulations tend to show that the polynomial zeroes now mostly repel one another and at late times quickly approach pair-wise diverging motion along the ")#mi("\\pm (1 - i)")#text(" directions (I checked for up to 4th order polynomials), but do not seem to ever collide at least in generic cases (there are fine-tuned degenerate cases like the ")#mi("z^2 - 2i")#text(" polynomial, though, where they do collide, and cases like polynomials of order 3 where a pair of zeroes diverges along ")#mi("\\pm (1 - i)")#text(" but one zero remains near the origin). The behaviour is similar to dynamical-system motion around a hyperbolic point instead of an elliptical one as for the motion of point vortices.")

#text("At present I do not see a trivial deformation of the heat/Schrödinger equation that would give the motion of polynomial zeros that is the same as the motion of point vortices (complex conjugating P on one side of the heat/Schrödinger equation does not do it, of course). It is intriguing how close it seems, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/576f0873ce0cb46766614437b74211d7cdc32fd6bc0b772bcd06c141a375fd17-8432db1034cccc3677642cfc3e5a40087d3aa08370f0f14f4f8f12878380b4ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487840")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("yeah,i just do a similar calculate and get the same dynamic picture in my mind,but i do not think the whole story in a physics picture.anyway,one key obeserve is that the points should diverging along n distinct line to infinity in the complex plane ")#mi("C")#text(".at least in the case the limit polynomial has n distinct root.for the degenerate situation the thing is not so easy to control we need to analysis to certain entanglement pairs.and if ")#mi("deg(f)")#text(" is odd,then we will have a root 0 in the limit case,this is also a annoying thing.")#linebreak()#text(" in my opinion,i think we need some knowledge from buried group to investigate a fix dynamic system generat by the zero of polynomial under heat flow,just think with the situation for quadratic polynomial ")#mi("z^2+c=0")#text(",this will corresponding to 2 different dynamic picture,because we do not know what happen at (0,0).this is a broken of symmetry.we need to use buried group and the jordan curve theorem(the topology only change when two point collide) to find the loss information.by the way,i think consider the deformation of zeros for polynomial function under heat equation on compact complex analytic surface(especially on ")#mi("\\hat C")#text(") is also interesting.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd970b9a4e18aef8211110cc6b486f12d8fea5b275514cd1df35d92f3ad43764-5cf43577f6a030b08198251c8aa51683c6b51f9cb706a733b8ee782d9ee599aa.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Karrmann")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487717")[#strong[#text("Matt Karrmann")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("Hello Mr. Tao,")

#text("You appear to have confused the “fundamental theorem of arithmetic” with the “fundamental theorem of algebra” at the very beginning of this post.")

#text("I would like you to know that I am truly honored to have the opportunity to point this out to you. Great post otherwise and I really appreciate the fact that you put these posts out!")

#text("P.S. In case the tone is unclear over text, I’m not pointing this out in a demeaning manner or even out of serious concern. I simply never thought I’d ever catch one of your mistakes, and I found so ironic that THIS was the mistake, that I simply had to say something! Once again, I really appreciate the fact that you make these posts!")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9f0a65d35247844b71af0887f6e7414cc20d1e687958062a734aeb06aba6be8-c9282acd3aa14c4e01e7eb79eea91dfe3e37aa7b50435d9215c99cf0f2cbcc66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tapash Bhagabati")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487744")[#strong[#text("Tapash Bhagabati")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("I totally agree with you.")

#text("Geniuses make mistakes too (Though it is a unintentional) !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487757")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("It is a typo, no confusion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fef187772cca4544a7db55f8c70b1b703a59dabe15796d0a828c4b028817b-9975ec2e0608ed9315ff6b87e050b87946993256521930bd51bc2d3a825a5da1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Camargo")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487718")[#strong[#text("André Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("I believe there is a typo in the series expansion of $P(t,z)$. Apparently the The right-hand side of the equation just after (2) does not depend on $t$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb4001a58a72f802ad32f5be62d414aabaf4569ecc9766d8c06113c91e553548-5cf43577f6a030b08198251c8aa51683c6b51f9cb706a733b8ee782d9ee599aa.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Karrmann")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487720")[#strong[#text("Matt Karrmann")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("Instead of “1” on the RHS, it should be $t^n$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8281bea6d0c2d0cef8f65b47d6cf0ef636641120b6793f9ca038e429dd91e3be-85ef4b94fbc87313913b07135d7e506cf0969aa95882c9c70087f0f01380c706.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theodore Kolokolnikov")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487732")[#strong[#text("Theodore Kolokolnikov")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("This resembles the classical Helmholtz equations for motion of fluid vortices in the plane. I wonder what the wave equation gives…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487748")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("If ")#mi("P(t, x)")#text(" is (locally) analytic in ")#mi("t, x")#text(", it has (locally) the same zero set as its Weierstrass polynomial (in ")#mi("x")#text(" – with analytic coefficients in ")#mi("t")#text(") – so the (local) dynamics of the zeros can be represented by their Puiseux series. Is it possible to extend (locally) the above results for (possibly infinitely many) zeros arranged in separated clusters of (possibly colliding) zeros?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78ec8b1a799d39e122d6c61153d59e1427ad1c7728868666214c170a87b9931a-277b29cad0ce6e212656efcd24635f5ce63475695f3d3e01b0f768658c1ba34d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487759")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("Beginner Q: Is it implicit in (2) that also P(0,z) = P(z)? Otherwise (2) does not seem to establish a relationship between P(t,z) and P(z).")

#emph[#text("[This implicit equivalence has now been added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/317cb9272dddd55e996ed173d81f56e535bec5d9cefaaf971fc288ee3995c661-04b1e4be03aa75cf77586ea9ba14d06d17d8b2023e34d1f2136c4866bab19e1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487762")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("Treating it as an optimal transport problem, I wonder if the behavior of the zeroes is a consequence of the relationship between energy geodesics, entropy and the manifold curvature (as treated for other dynamics by, for example, Cedric Villani in his “lazy gas experiment”).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487768")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("Numerical examples here: ")#link("https://twitter.com/gabrielpeyre/status/920731190461648896")[#text("https://twitter.com/gabrielpeyre/status/920731190461648896")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f31223a840996848eda3ff530849f6c77ef40ad3913e5fc1a62b1163fc399170-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Bristol")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487770")[#strong[#text("Paul Bristol")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("Fundamental theorem of algebra of course, not arithmetic.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50593937d0728897a080473b538b52c99d3818e7ce06ad6774741e45a66df879-450c0ee0d558b3d348d1bfa62274b94f44165ae7dfce6c55efe2cf64eeef8b34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Murphy")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487773")[#strong[#text("Frank Murphy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("Reblogged this on ")#link("https://fmurphyrng.wordpress.com/2017/10/18/heat-flow-and-zeroes-of-polynomials/")[#text("fmurphyrng")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b7cb4fb474c78b6d6a1be8ecb0e3a1babbc91793a1edc6ad7e175e0c2728178-41c7e2cf8d9ad276fe3a088d5450e47ce81b823deb03829ad9c8ad89a48f6e50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487776")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")])]

#text("Dimensions are incorrect in the Taylor series for [math]P(t,z)[/math]. The right side needs [math]t^n[/math] inside the summation.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/576f0873ce0cb46766614437b74211d7cdc32fd6bc0b772bcd06c141a375fd17-8432db1034cccc3677642cfc3e5a40087d3aa08370f0f14f4f8f12878380b4ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487814")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2017")])]

#text("Dear terry tao:")#linebreak()#text(" I think the limit case of the dynamic system is under control,I just mean we due to we can calculate the equation ")#mi("f(z,t)=\\sum_{k=1}^n\\sum_{0\\leq m\\leq k-2,2|k-m}\\frac{k!}{m!(k-m)!}z^mt^{k-m}.")

#mi("=\\sum_{k=1}^m\\sum_{0\\leq m\\leq k-2,2|k-m}C_k^mt^{k-m})z^mt^{k-m}")

#mi("\\sum_{m=0}^{n-2}(\\sum_{k=m,2|k-m}^nC_k^mt^{k-m})z^m")#text(".")#linebreak()#text(" exactly,so we can rescaling it and take $t\\to \\infty$,the limit case is the equation:")#mi("\\lim_{t\\to \\infty}F_t\\cdot f(z,t)=\\sum_{m=0,2|n-m}^{n-2}C_n^mz^m")#text("(*) this have n zero on ")#mi("C")#text(".")#linebreak()#text(" until now,at least for the case the n zero is distinct in (*),we know at last the zero will go to infinity along each direction come form the zeros of (*),so the only complicated thing is the finite “blow up”time i.e. the time zeroes must collide.these will lead to to breaken of symmetry(just think about the example ")#mi("z^2=c")#text(",there is only one equation,but two different pictures).to investigate this I think we need some knowledge about buried group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487815")[#strong[#text("Heat flow and the zero of polynomial-a approach to Riemann Hypesis | Relationship of relationship")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2017")]

#text("[…] this is a note after reading the blog:Heat flow and the zero of polynomial. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/868acf66444a941b59df7164b4dc7dd6cc59a64feb0078c3927c9cb6d8251f77-2f8c3295443c63496854443f4f507413046f0a00d5fccac71ac23adbde539c1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487839")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("The letter n is used as both the degree of the polynomial and the summation index of the Taylor series. Perhaps a different letter could be used in the latter purpose to avoid any possible confusion.")

#emph[#text("[Summation index changed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a402d1d45abe7ce5e5d78d4ca0c226f903b540f7c23d5c89c48e95ede5f58279-54b792f0d913b82a3e798d788bb126aac95173acc6e965768f3c27151fd5d2c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MK")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487893")[#strong[#text("MK")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2017")])]

#text("Your equation (3) reminds one of the dynamics of zeros of a power series when the coefficients undergo Brownian motions. The difference from Dyson’s BM is that the inverse distances to other zeros appears in the variance (not the drift) of the diffusion describing the motion of a particular root.")

#text("Here is (1) A movie: ")#link("https://www.stat.berkeley.edu/~peres/GAF/dynamics/dynamics.html")[#text("https://www.stat.berkeley.edu/~peres/GAF/dynamics/dynamics.html")]#text(" (2) Analysis by Peres and Virag: Display (49) of ")#link("https://arxiv.org/pdf/math/0310297.pdf")[#text("https://arxiv.org/pdf/math/0310297.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7672fa8342b7311cd9794d8dd86ceaa9a4682a7424cc0bfd716f4a6183ddabab-19daf811659490b1ae72d416a05967dbd23cbaf7ec251566b14a90aa5e1668a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ustc liu")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-487966")[#strong[#text("ustc liu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2017")])]

#text("Does this have connection with Lee-Yang theorem about the zeros of partition function in statistical mechanics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2898c31929a9bae893f4bb1b2be7db54313747b3b5c35eee7f04bac833038d2-a441989164633448caf20901f2080e980f798eb367097941cabeaea270ed11e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BR")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488246")[#strong[#text("BR")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2017")])]

#text("I am not an expert on the Lee-Yang theorem, but there is at least a small but interesting historical connection — see the (well written and self-contained) remarks made by Mark Kac at the end of the 3rd volume of Polya’s collected works, on Polya’s paper `Bemerkung uber die integraldarstellung der Riemannschen ")#mi("xi")#text("-funktion’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5aa8a8b38c6132e360e84bc81a6cd793772627202503b77d6ca5bb2bd605c93-1fc5a6105cb29de1383d400fbb0efca3bfabdc0ae64d4d82e79fbb225cb808f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488095")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")])]

#text("Solutions of the form ")#mi("\\partial_t z_k(t) =  z_k(t)")#text(" for all k give the equations of Stieltjes for the optimizer of the Coulomb gas model as in Mehta appendix 6, whose solution is Hermite zeros in random matrix theory. This is obvious b/c the Coulomb gas model is H plus the sum-of-squares. But it is also the self-similar solution of the dynamics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kjkj309")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488723")[#strong[#text("kjkj309")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("Thanks for the reference. What is the motivation for the sum-of-squares term in that model?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f92bba269543b935cfcb47448da7148aeae019243d4b03d38112b22007271fa0-c7dd2c96b513d77ecf9ed0c0f363df0df7550044b3a503b96ce6b9a7c273823f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of C Trombley")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488670")[#strong[#text("C Trombley")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2017")])]

#text("Equation after “in time using (2) to obtain” should be a difference rather than a sum, no?")

#emph[#text("[No. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kjkj309")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488715")[#strong[#text("kjkj309")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("Does anyone have any insight on how one could come up with the sum-of-squares representation for ")#mi("\\partial_t E")#text(" in Exercise 1, if one did not know it in advance? How are these algebraic identities discovered by mathematicians in practice?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488720")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("As I wrote in the post, this identity ultimately arises from the convexity of ")#mi("H")#text(". If ")#mi("x")#text(" obeys (reverse) gradient flow ")#mi("\\partial_t x_i = \\partial H/\\partial x_i")#text(", then ")#mi("\\partial_t^2 H = \\sum_{i,j} \\frac{\\partial^2 H}{\\partial x_i \\partial x_j} \\frac{\\partial H}{\\partial x_i} \\frac{\\partial H}{\\partial x_j}")#text(". If ")#mi("H")#text(" is convex, then ")#mi("\\partial^2 H/\\partial x_i \\partial x_j")#text(" is positive definite and the RHS should be expressible as the sum of squares. If one pursues this line of reasoning a bit more, one will ultimately arrive at the identity in Exercise 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kjkj309")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-488722")[#strong[#text("kjkj309")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2017")])]

#text("Oh, nice! Thanks so much for your reply. I should have paid more attention to the sentence about convexity in the post.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The De Bruijn-Newman constant is non-negativ | What's new")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-491515")[#strong[#text("The De Bruijn-Newman constant is non-negativ | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("[…] the argument proceeds as follows. As observed by Csordas, Smith, and Vargas (and also discussed in this previous blog post, the backwards heat evolution of the introduces a nice ODE dynamics on the zeroes of , namely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heat flow and zeroes of polynomials II: zeroes on a circle | What's new")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-501370")[#strong[#text("Heat flow and zeroes of polynomials II: zeroes on a circle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2018")])]

#text("[…] is a sequel to this previous blog post, in which we discussed the effect of the heat flow […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1855bbbf0121dc133f59e2d409c949c6950d9d07afdd18bdf37bbaaee1a48ce9-35659c0f34a0b6a815e9489f31e93d7fe1be12e59643c4507eb667bbb7197d12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-502035")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2018")])]

#text("Dear Prof. Tao, dear readers,")

#text("I was just interested in the following: Let’s say we’ve got a random matrix. We can associate to it a monic polynomial by taking the characteristic polynomial, and then develop it with the heat equation (or any other equation). Then all the quantities above become random variables, dependent on the entries of the random matrix.")

#text("Are these of any interest? They seem to correspond to a “real-world” problem: Namely, when the initial data is random, what can we expect after some time? (Of course only when one is interested in what the zeroes of the respective function do.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-502102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2018")])]

#text("It seems that random matrices and heat flows inhabit parallel, but disconnected, “worlds”, parameterised by an inverse temperature parameter ")#mi("\\beta")#text(", and that it is not particularly natural to mix the different worlds together. Heat flow corresponds to the deterministic (")#mi("\\beta=\\infty")#text(") world, being connected in particular to the ")#link("https://arxiv.org/abs/1504.00350")[#text("finite free convolution of Marcus, Spielman, and Srivastava")]#text(". The random matrices relating to the Gaussian Unitary Ensemble instead lie in the ")#mi("\\beta=2")#text(" world, the random matrices relating to the Gaussian Orthogonal Ensemble lie in the ")#mi("\\beta=1")#text(" world, and so forth. Each ")#mi("\\beta")#text(" has its own flow; for ")#mi("\\beta=2")#text(" it would be the ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Dyson Brownian motion")]#text(", which looks nearly identical to the heat flow dynamics of zeroes but with an additional Brownian drift term, and corresponds to perturbing each entry of the matrix by a (complex) Gaussian perturbation (subject to maintaining the Hermitian property).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1855bbbf0121dc133f59e2d409c949c6950d9d07afdd18bdf37bbaaee1a48ce9-35659c0f34a0b6a815e9489f31e93d7fe1be12e59643c4507eb667bbb7197d12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-502184")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2018")])]

#text("Thanks a lot! (Even though it’s slightly frustrating being illustrated the inferiority of one’s intellectual abilities by a peer just rattling off fringe theories fitting the subject squarely that go a thousand miles beyond showing that the statistics are just not interesting…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d131e2b92bc4c5c9c9207898982b676a967c818dcc5fdb73ac3ce5dc26a8c865-6df7b62baaf2977253055c235a423a8b8b9a5fbc0f4eb5bc82672d8151cae565.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian C. Hall")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-643235")[#strong[#text("Brian C. Hall")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("Dear Maths student, please see my post below about a random matrix interpretation of the heat flow.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-514093")[#strong[#text("Dynamical Phase Portraits | Empathic Dynamics")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2019")]

#text("[…] while ago Terence Tao wrote a post about the heat flow of polynomials, whereby one can think of a family of polynomials in a variable , and consider what happens to them […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d131e2b92bc4c5c9c9207898982b676a967c818dcc5fdb73ac3ce5dc26a8c865-6df7b62baaf2977253055c235a423a8b8b9a5fbc0f4eb5bc82672d8151cae565.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian C. Hall")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-643234")[#strong[#text("Brian C. Hall")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("A recent preprint of mine with Ching-Wei Ho gives a random matrix interpretation to the evolution of the zeros of polynomials under the heat flow, but only if you go past the first collision time and allow the roots to become complex. As a special case, we conjecture that if you apply the heat operator for time 1/N to the characteristic polynomial of an NxN GUE matrix, the roots of the new polynomial will be asymptotically uniform on the unit disk. That is, the heat flow changes semicircular to circular. See: ")#link("https://arxiv.org/abs/2202.09660")[#text("https://arxiv.org/abs/2202.09660")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-645873")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2022")])]

#text("If $\\xi$ has only simple zeros then RH is true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-645890")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2022")])]

#text("No; technically, they are logically independent statements. However, the combination of the Riemann Hypothesis and the Simple Zeroes Conjecture turns out to be a natural strengthening of the RH alone in some cases; see ")#link("https://mathoverflow.net/questions/394295/why-is-the-simple-zeros-conjecture-said-to-be-stronger-than-the-riemann-hypothes")[#text("this MathOverflow")]#text(" post for further discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-649092")[#strong[#text("Heat flow and the zero of polynomial-a approach to Riemann Hypesis - Relationship of relationship")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2022")]

#text("[…] this is a note after reading the blog:Heat flow and the zero of polynomial. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/comment-page-1/#comment-682003")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2023")])]

#text("Hi. I had done a similar study with the help of canonical representations of geometric objects in 2- and 3-dimensional space. This has become more clear in my mind with your work. Maybe there is a relationship between stationary points of flow and roots.")
]
