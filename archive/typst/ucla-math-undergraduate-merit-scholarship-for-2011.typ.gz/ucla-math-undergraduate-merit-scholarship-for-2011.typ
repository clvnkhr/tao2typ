// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/12/ucla-math-undergraduate-merit-scholarship-for-2011/
// Converted to Typst by tao2typ: "2026-10-14T09:20:44.349295+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "UCLA Math Undergraduate Merit Scholarship for 2012", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("UCLA Math Undergraduate Merit Scholarship for 2012")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/12/ucla-math-undergraduate-merit-scholarship-for-2011/")[#text("https://terrytao.wordpress.com/2011/11/12/ucla-math-undergraduate-merit-scholarship-for-2011/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[Once again, some advertising on behalf of my department, following on a similar announcement in the ")#link("https://terrytao.wordpress.com/2010/11/16/ucla-math-undergraduate-merit-scholarship-for-2010/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/")[#text("two")]#text(" years.]")]

#metadata(none) <tao-0630528f8ba94a63efe4>

#metadata(none) <tao-fd06da72a0be46f9a13c>

#text("Two years ago, the UCLA mathematics department launched a scholarship opportunity for entering freshman students with exceptional background and promise in mathematics. We have offered one scholarship every year, but this year due to an additional source of funding, we will also be able to offer an additional scholarship for California residents.The UCLA Math Undergraduate Merit Scholarship provides for full tuition, and a room and board allowance for 4 years. In addition, scholarship recipients follow an individualized accelerated program of study, as determined after consultation with UCLA faculty. ")#emph[#text(" ")]#text("The program of study leads to a Masters degree in Mathematics in four years.")

#text("More information and an application form for the scholarship can be found on the web at:")

#link("http://www.mathprograms.org/db/programs/69")[#text("http://www.mathprograms.org/db/programs/69")]

#text("and")

#link("http://www.math.ucla.edu/ugrad/meritscholarship.shtml")[#text("http://www.math.ucla.edu/ugrad/meritscholarship.shtml")]

#text("To be considered for Fall 2012, candidates must apply for the scholarship and also for admission to UCLA on or before November 30, 2011.")

#metadata(none) <tao-c7e1a4cc0bf00abf1533>

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Undergraduate Merit Scholarship for 2013 « What’s new")]], [#link("https://terrytao.wordpress.com/2011/11/12/ucla-math-undergraduate-merit-scholarship-for-2011/#comment-192989")[#strong[#text("UCLA Math Undergraduate Merit Scholarship for 2013 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2012")])]

#text("[…] [Once again, some advertising on behalf of my department, following on a similar announcement in the previous three years.] […]")
]
