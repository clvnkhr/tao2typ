// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T15:19:35.756951+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A small remark on the Elliott conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A small remark on the Elliott conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 October 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/")[#text("https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("Chowla conjecture")]#text(" asserts, among other things, that one has the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} \\lambda(n+h_1) \\dots \\lambda(n+h_k) = o(1)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(" for any distinct integers ")#mi("{h_1,\\dots,h_k}")#text(", where ")#mi("{\\lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(". (The usual formulation of the conjecture also allows one to consider more general linear forms ")#mi("{a_i n + b_i}")#text(" than the shifts ")#mi("{n+h_i}")#text(", but for sake of discussion let us focus on the shift case.) This conjecture remains open for ")#mi("{k \\geq 2}")#text(", though there are now some partial results when one averages either in ")#mi("{x}")#text(" or in the ")#mi("{h_1,\\dots,h_k}")#text(", as discussed in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("this recent post")]#text(".")

#text("A natural generalisation of the Chowla conjecture is the ")#link("http://www.ams.org/mathscinet-getitem?mr=1292619")[#text("Elliott conjecture")]#text(". Its original formulation was basically as follows: one had ")#metadata(none) <tao-a39b32492df35396c54b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{X} \\sum_{n \\leq X} g_1(n+h_1) \\dots g_k(n+h_k) = o(1)")]]



#text(" whenever ")#mi("{g_1,\\dots,g_k}")#text(" were bounded completely multiplicative functions and ")#mi("{h_1,\\dots,h_k}")#text(" were distinct integers, and one of the ")#mi("{g_i}")#text(" was “non-pretentious” in the sense that ")#metadata(none) <tao-00e37ffae0562ab6818d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_p \\frac{1 - \\text{Re}( g_i(p) \\overline{\\chi(p)} p^{-it})}{p} = +\\infty")]]



#text(" for all Dirichlet characters ")#mi("{\\chi}")#text(" and real numbers ")#mi("{t}")#text(". It is easy to see that some condition like ")#link(<tao-00e37ffae0562ab6818d>)[#text("(2)")]#text(" is necessary; for instance if ")#mi("{g(n) := \\chi(n) n^{it}}")#text(" and ")#mi("{\\chi}")#text(" has period ")#mi("{q}")#text(" then ")#mi("{\\frac{1}{X} \\sum_{n \\leq X} g(n+q) \\overline{g(n)}}")#text(" can be verified to be bounded away from zero as ")#mi("{X \\rightarrow \\infty}")#text(".")

#text("In a ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("previous paper with Matomaki and Radziwill")]#text(", we provided a counterexample to the original formulation of the Elliott conjecture, and proposed that ")#link(<tao-00e37ffae0562ab6818d>)[#text("(2)")]#text(" be replaced with the stronger condition ")#metadata(none) <tao-5d69acc46bcfeb436697>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\inf_{\\left|t\\right| \\leq X} \\sum_{p \\leq X} \\frac{1 - \\text{Re}( g_i(p) \\overline{\\chi(p)} p^{-it})}{p} \\rightarrow +\\infty", block: true)]]



#text(" as ")#mi("{X \\rightarrow \\infty}")#text(" for any Dirichlet character ")#mi("{\\chi}")#text(". To support this conjecture, we proved an averaged and non-asymptotic version of this conjecture which roughly speaking showed a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{H^k} \\sum_{h_1,\\dots,h_k \\leq H} \\left|\\frac{1}{X} \\sum_{n \\leq X} g_1(n+h_1) \\dots g_k(n+h_k)\\right| \\leq \\varepsilon", block: true)]]

#text("whenever ")#mi("{H}")#text(" was an arbitrarily slowly growing function of ")#mi("{X}")#text(", ")#mi("{X}")#text(" was sufficiently large (depending on ")#mi("{\\varepsilon,k}")#text(" and the rate at which ")#mi("{H}")#text(" grows), and one of the ")#mi("{g_i}")#text(" obeyed the condition ")#metadata(none) <tao-5e85370e555e95d27df6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\inf_{\\left|t\\right| \\leq AX} \\sum_{p \\leq X} \\frac{1 - \\text{Re}( g_i(p) \\overline{\\chi(p)} p^{-it})}{p} \\geq A", block: true)]]



#text(" for some ")#mi("{A}")#text(" that was sufficiently large depending on ")#mi("{k,\\varepsilon}")#text(", and all Dirichlet characters ")#mi("{\\chi}")#text(" of period at most ")#mi("{A}")#text(". As further support of this conjecture, I ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("recently established")]#text(" the bound")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\log \\omega} \\left|\\sum_{X/\\omega \\leq n \\leq X} \\frac{g_1(n+h_1) g_2(n+h_2)}{n}\\right| \\leq \\varepsilon", block: true)]]

#text("under the same hypotheses, where ")#mi("{\\omega}")#text(" is an arbitrarily slowly growing function of ")#mi("{X}")#text(".")

#text("In view of these results, it is tempting to conjecture that the condition ")#link(<tao-5e85370e555e95d27df6>)[#text("(4)")]#text(" for one of the ")#mi("{g_i}")#text(" should be sufficient to obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{X} \\sum_{n \\leq X} g_1(n+h_1) \\dots g_k(n+h_k)\\right| \\leq \\varepsilon", block: true)]]

#text("when ")#mi("{A}")#text(" is large enough depending on ")#mi("{k,\\varepsilon}")#text(". This may well be the case for ")#mi("{k=2}")#text(". However, the purpose of this blog post is to record a simple counterexample for ")#mi("{k>2}")#text(". Let’s take ")#mi("{k=3}")#text(" for simplicity. Let ")#mi("{t_0}")#text(" be a quantity much larger than ")#mi("{X}")#text(" but much smaller than ")#mi("{X^2}")#text(" (e.g. ")#mi("{t = X^{3/2}}")#text("), and set")

#align(center)[#tao-fit-display[#mitex("g_1(n) := n^{it_0}; \\quad g_2(n) := n^{-2it_0}; \\quad g_3(n) := n^{it_0}.")]]

#text("For ")#mi("{X/2 \\leq n \\leq X}")#text(", Taylor expansion gives")

#align(center)[#tao-fit-display[#mitex("(n+1)^{it} = n^{it_0} \\exp( i t_0 / n ) + o(1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(n+2)^{it} = n^{it_0} \\exp( 2 i t_0 / n ) + o(1)")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("g_1(n) g_2(n+1) g_3(n+2) = 1 + o(1)")]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{X} \\sum_{X/2 \\leq n \\leq X} g_1(n) g_2(n+1) g_3(n+2)\\right| \\gg 1.", block: true)]]

#text("On the other hand one can easily verify that all of the ")#mi("{g_1,g_2,g_3}")#text(" obey ")#link(<tao-5e85370e555e95d27df6>)[#text("(4)")]#text(" (the restriction ")#tao-math("{\\left|t\\right| \\leq AX}", block: false)#text(" there prevents ")#mi("{t}")#text(" from getting anywhere close to ")#mi("{t_0}")#text("). So it seems the correct non-asymptotic version of the Elliott conjecture is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Non-asymptotic Elliott conjecture)")]#text(" Let ")#mi("{k}")#text(" be a natural number, and let ")#mi("{h_1,\\dots,h_k}")#text(" be integers. Let ")#mi("{\\varepsilon > 0}")#text(", let ")#mi("{A}")#text(" be sufficiently large depending on ")#mi("{k,\\varepsilon,h_1,\\dots,h_k}")#text(", and let ")#mi("{X}")#text(" be sufficiently large depending on ")#mi("{k,\\varepsilon,h_1,\\dots,h_k,A}")#text(". Let ")#mi("{g_1,\\dots,g_k}")#text(" be bounded multiplicative functions such that for some ")#mi("{1 \\leq i \\leq k}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\inf_{\\left|t\\right| \\leq AX^{k-1}} \\sum_{p \\leq X} \\frac{1 - \\text{Re}( g_i(p) \\overline{\\chi(p)} p^{-it})}{p} \\geq A", block: true)]]

#text("for all Dirichlet characters ")#mi("{\\chi}")#text(" of conductor at most ")#mi("{A}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{X} \\sum_{n \\leq X} g_1(n+h_1) \\dots g_k(n+h_k)\\right| \\leq \\varepsilon.", block: true)]]
]

#text("The ")#mi("{k=1}")#text(" case of this conjecture follows from the ")#link("http://www.ams.org/mathscinet-getitem?mr=319930")[#text("work of Halasz")]#text("; in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("my recent paper")]#text(" a logarithmically averaged version of the ")#mi("{k=2}")#text(" case of this conjecture is established. The requirement to take ")#mi("{t}")#text(" to be as large as ")#mi("{A X^{k-1}}")#text(" does not emerge in the averaged Elliott conjecture in my ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("previous paper with Matomaki and Radziwill")]#text("; it thus seems that this averaging has concealed some of the subtler features of the Elliott conjecture. (However, this subtlety does not seem to affect the asymptotic version of the conjecture formulated in that paper, in which the hypothesis is of the form ")#link(<tao-5d69acc46bcfeb436697>)[#text("(3)")]#text(", and the conclusion is of the form ")#link(<tao-a39b32492df35396c54b>)[#text("(1)")]#text(".)")

#text("A similar subtlety arises when trying to control the maximal integral ")#metadata(none) <tao-7540bd4356952df49661>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{X} \\int_X^{2X} \\sup_\\alpha \\frac{1}{H} |\\sum_{x \\leq n \\leq x+H} g(n) e(\\alpha n)|\\ dx.")]]



#text(" In my ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("previous paper with Matomaki and Radziwill")]#text(", we could show that easier expression ")#metadata(none) <tao-4d2d1dfcb8d03bc60bce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{1}{X} \\sup_\\alpha \\int_X^{2X} \\frac{1}{H} |\\sum_{x \\leq n \\leq x+H} g(n) e(\\alpha n)|\\ dx.")]]



#text(" was small (for ")#mi("{H}")#text(" a slowly growing function of ")#mi("{X}")#text(") if ")#mi("{g}")#text(" was bounded and completely multiplicative, and one had a condition of the form ")#metadata(none) <tao-1ffc0406b9891fcd265a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\inf_{\\left|t\\right| \\leq AX} \\sum_{p \\leq X} \\frac{1 - \\text{Re}( g(p) \\overline{\\chi(p)} p^{-it})}{p} \\geq A", block: true)]]



#text(" for some large ")#mi("{A}")#text(". However, to obtain an analogous bound for ")#link(<tao-7540bd4356952df49661>)[#text("(5)")]#text(" it now appears that one needs to strengthen the above condition to")

#align(center)[#tao-fit-display[#tao-math("\\inf_{\\left|t\\right| \\leq AX^2} \\sum_{p \\leq X} \\frac{1 - \\text{Re}( g(p) \\overline{\\chi(p)} p^{-it})}{p} \\geq A", block: true)]]

#text("in order to address the counterexample in which ")#mi("{g(n) = n^{it_0}}")#text(" for some ")#mi("{t_0}")#text(" between ")#mi("{X}")#text(" and ")#mi("{X^2}")#text(". This seems to suggest that proving ")#link(<tao-7540bd4356952df49661>)[#text("(5)")]#text(" (which is closely related to the ")#mi("{k=3}")#text(" case of the Chowla conjecture) could in fact be rather difficult; the estimation of ")#link(<tao-4d2d1dfcb8d03bc60bce>)[#text("(6)")]#text(" relied primarily of ")#link("http://arxiv.org/abs/1501.04585")[#text("prior work of Matomaki and Radziwill")]#text(" which used the hypothesis ")#link(<tao-1ffc0406b9891fcd265a>)[#text("(7)")]#text(", but as this hypothesis is not sufficient to conclude ")#link(<tao-7540bd4356952df49661>)[#text("(5)")]#text(", some additional input must also be used.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/#comment-461170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2015")])]

#text("It seems that the generalized non pretentious restriction in conjecture 1, was constructed to avoid the above counterexample (for which ")#mi("g_1  \\cdots  g_k =1")#text("). Is it possible to relax this restriction by adding an appropriate restriction on the product ")#mi("g_1 \\cdots g_k")#text(" (e.g. to be ")#mi("\\neq 1")#text(") ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/#comment-461221")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2015")])]

#text("At a bare minimum, one will need ")#mi("g_1 \\dots g_k")#text(" to be non-pretentious. For instance suppose that ")#mi("g_1 = \\dots = g_1 = \\chi")#text(" is a Dirichlet character. Then the function ")#mi("n \\mapsto g_1(n+h_1) \\dots g_k(n+h_k)")#text(" will be periodic and will typically not have mean zero (one expects a square root cancellation, but not perfect cancellation). In this case ")#mi("g_1 \\dots g_k")#text(" will be a Dirichlet character which will usually not be principal. One can also multiply one or more of the ")#mi("g_i")#text(" by ")#mi("n \\mapsto n^{it}")#text(" for some small ")#mi("t")#text(" and still have some non-cancellation in the sum ")#mi("\\sum_{n \\leq x} g_1(n+h_1) \\dots g_k(n+h_k)")#text(".")

#text("In principle, once one is in the “structured” case where each of the ")#mi("g_i")#text(" pretends to be a modulated Dirichlet character ")#mi("n \\mapsto \\chi_i(n) n^{it_i}")#text(", one can write ")#mi("g_i")#text(" as a Dirichlet convolution of this modulated character with another arithmetic function that pretends to be 1, and one can evaluate the sum ")#mi("\\sum_{n \\leq x} g_1(n+h_1) \\dots g_k(n+h_k)")#text(" more or less explicitly (though to deal with some error terms one may need something like a generalised Elliott-Halberstam conjecture, or else do some smoothing in the x variable). This should in principle let one refine the condition yielding cancellation in the sum ")#mi("\\sum_{n \\leq x} g_1(n+h_1) \\dots g_k(n+h_k)")#text(" to obtain a near-optimal criterion for this cancellation. (This is analogous to the situation involving finding linear patterns in dense sets, where there is a crude “Cauchy-Schwarz complexity” criterion that handles all the cases in which a certain high order Gowers norm is small, but then there is a more refined “true complexity” criterion that uses some more advanced additive combinatorics (such as the equidistribution theory of nilsequences) to find a more optimal criterion to get equidistribution.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/#comment-461177")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2015")])]

#text("Am I wrong, or is a closing parenthesis missing in the expression of the “non-pretentious” quantity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2015/10/30/a-small-remark-on-the-elliott-conjecture/#comment-461178")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2015")])]

#text("Ok, it’s been corrected, my apologies.")
]
]
