// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/
// Converted to Typst by tao2typ: "2026-10-14T16:35:14.470387+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Hamiltonians", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Hamiltonians")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/")[#text("https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("My penultimate article for ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("my PCM series")]#text(" is a very short one, on “")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/hamiltonian.pdf")[#text("Hamiltonians")]#text("“. The PCM has a number of short articles to define terms which occur frequently in the longer articles, but are not substantive enough topics by themselves to warrant a full-length treatment. One of these is the term “Hamiltonian”, which is used in all the standard types of physical mechanics (classical or quantum, microscopic or statistical) to describe the total energy of a system. It is a remarkable feature of the laws of physics that this single object (which is a scalar-valued function in classical physics, and a self-adjoint operator in quantum mechanics) suffices to describe the entire dynamics of a system, although from a mathematical perspective it is not always easy to read off all the analytic aspects of this dynamics just from the form of the Hamiltonian.")

#text("In mathematics, Hamiltonians of course arise in the equations of mathematical physics (such as ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamilton’s equations of motion")]#text(", or ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger’s equations of motion")]#text("), but also show up in symplectic geometry (as a special case of a ")#link("http://en.wikipedia.org/wiki/Moment_map")[#text("moment map")]#text(") and in microlocal analysis.")

#text("For this post, I would also like to highlight an article of my good friend ")#link("http://www.dms.umontreal.ca/~andrew/")[#text("Andrew Granville")]#text(" on one of my own favorite topics, “")#link("http://www.dms.umontreal.ca/~andrew/PDF/PrinceComp.pdf")[#text("Analytic number theory")]#text("“, focusing in particular on the classical problem of understanding the distribution of the primes, via such analytic tools as zeta functions and L-functions, sieve theory, and the circle method.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZH")]], [#link("https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/#comment-27032")[#strong[#text("ZH")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2008")])]

#text("Dear Prof. Tao;")

#text("As a graduate mathematics student interested in PDEs, I find most of the problems in this field originating from applied sciences, mainly physics. How important do you think is studying the physical theory behind the equation in order to 1) grasp and understand the equation 2) analyse it and 3) solve it?")

#text("Also, in case a physical arguement is relavent in the analysis of a PDE, is it usually easy to translate it into a rigorous mathematical statement and prove it? It seems to me that the reverse direction (i.e. math to physics)should not be hard.")

#text("Sorry for being a bit broad in my questions.")#linebreak()#text(" Best;")#linebreak()#text(" ZH")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/#comment-27043")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2008")])]

#text("Dear ZH,")

#text("Mathematicians and physicists tend to have rather different perspectives on any given PDE, to the point where a result on a PDE in one discipline may not have much direct impact on the study of the same PDE in the other discipline. (For instance, mathematicians care much more about rigour, while physicists care much more about solutions at physically realistic scales of space, time, energy, etc. Also, mathematicians tend to study model equations and their solutions for their own sake, whereas physicists usually view these equations as approximations to reality only. Of course these are broad generalisations, and there are notable exceptions to all of these statements.)")

#text("But on the level of intuition, heuristics, and analogy, there is a lot to be learned in both directions. For instance, I have found a physical understanding of the correspondence principle between classical and quantum mechanics to be very useful in guiding my intuition on nonlinear Schrodinger equations, even though such equations are not directly subject to the correspondence principle. Many of the conjectures in PDE (e.g. global regularity for Navier-Stokes) are also motivated by physical heuristics or experimental data. In the converse direction, mathematicians have sometimes uncovered subtleties that showed that certain non-rigorous physical lines of reasoning were in fact inaccurate (e.g. a supposedly “negligible” term omitted from a physical analysis turned out to have non-trivial impact on the dynamics), and needed to be refined in various ways.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of From Bose-Einstein condensates to the nonlinear Schrodinger equation « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/07/pcm-article-hamiltonians/#comment-42542")[#strong[#text("From Bose-Einstein condensates to the nonlinear Schrodinger equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("[…] is a special observable, the Hamiltonian , which governs the evolution of the state through time, via Hamilton’s equations of motion. […]")
]
