// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/
// Converted to Typst by tao2typ: "2026-10-14T16:37:24.865902+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Kolmogorov’s power law for turbulence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Kolmogorov’s power law for turbulence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 May 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/")[#text("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Many fluid equations are expected to exhibit turbulence in their solutions, in which a significant portion of their energy ends up in high frequency modes. A typical example arises from the three-dimensional periodic ")#link("http://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_equations")[#text("Navier-Stokes equations")]

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + u \\cdot \\nabla u  & = \\nu \\Delta u - \\nabla p + f", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("where ")#mi("{u: {\\bf R} \\times {\\bf R}^3/{\\bf Z}^3 \\rightarrow {\\bf R}^3}")#text(" is the velocity field, ")#mi("{f: {\\bf R} \\times {\\bf R}^3/{\\bf Z}^3 \\rightarrow {\\bf R}^3}")#text(" is a forcing term, ")#mi("{p: {\\bf R} \\times {\\bf R}^3/{\\bf Z}^3 \\rightarrow {\\bf R}}")#text(" is a pressure field, and ")#mi("{\\nu > 0}")#text(" is the viscosity. To study the dynamics of energy for this system, we first pass to the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat u(t,k) := \\int_{{\\bf R}^3/{\\bf Z}^3} u(t,x) e^{-2\\pi i k \\cdot x}")]]

#text("so that the system becomes")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\hat u(t,k) + 2\\pi \\sum_{k = k_1 + k_2} (\\hat u(t,k_1) \\cdot ik_2) \\hat u(t,k_2) =")]]

#metadata(none) <tao-98d636bfd716cd14840b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("- 4\\pi^2 \\nu \\left|k\\right|^2 \\hat u(t,k) + 2\\pi ik \\hat p(t,k) + \\hat f(t,k)", block: true)]]





#align(center)[#tao-fit-display[#mitex("k \\cdot \\hat u(t,k) = 0.")]]

#text("We may normalise ")#mi("{u}")#text(" (and ")#mi("{f}")#text(") to have mean zero, so that ")#mi("{\\hat u(t,0)=0}")#text(". Then we introduce the dyadic energies")

#align(center)[#tao-fit-display[#tao-math("E_N(t) := \\sum_{\\left|k\\right| \\sim N} \\left|\\hat u(t,k)\\right|^2", block: true)]]

#text("where ")#mi("{N \\geq 1}")#text(" ranges over the powers of two, and ")#tao-math("{\\left|k\\right| \\sim N}", block: false)#text(" is shorthand for ")#tao-math("{N \\leq \\left|k\\right| < 2N}", block: false)#text(". Taking the inner product of ")#link(<tao-98d636bfd716cd14840b>)[#text("(1)")]#text(" with ")#mi("{\\hat u(t,k)}")#text(", we obtain the energy flow equation ")#metadata(none) <tao-6657ea873b1c446dad7f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t E_N = \\sum_{N_1,N_2} \\Pi_{N,N_1,N_2} - D_N + F_N")]]



#text(" where ")#mi("{N_1,N_2}")#text(" range over powers of two, ")#mi("{\\Pi_{N,N_1,N_2}}")#text(" is the energy flow rate")

#align(center)[#tao-fit-display[#tao-math("\\Pi_{N,N_1,N_2} := -2\\pi \\sum_{k=k_1+k_2: \\left|k\\right| \\sim N, \\left|k_1\\right| \\sim N_1, \\left|k_2\\right| \\sim N_2}", block: true)]]

#align(center)[#tao-fit-display[#mitex("(\\hat u(t,k_1) \\cdot ik_2) (\\hat u(t,k) \\cdot \\hat u(t,k_2)),")]]

#mi("{D_N}")#text(" is the energy dissipation rate")

#align(center)[#tao-fit-display[#tao-math("D_N := 4\\pi^2 \\nu \\sum_{\\left|k\\right| \\sim N} \\left|k\\right|^2 \\left|\\hat u(t,k)\\right|^2", block: true)]]

#text("and ")#mi("{F_N}")#text(" is the energy injection rate")

#align(center)[#tao-fit-display[#tao-math("F_N := \\sum_{\\left|k\\right| \\sim N} \\hat u(t,k) \\cdot \\hat f(t,k).", block: true)]]

#text("The Navier-Stokes equations are notoriously difficult to solve in general. Despite this, Kolmogorov in 1941 was able to give a convincing heuristic argument for what the distribution of the dyadic energies ")#mi("{E_N}")#text(" should become over long times, assuming that some sort of distributional steady state is reached. It is common to present this argument in the form of dimensional analysis, but one can also give a more “first principles” form Kolmogorov’s argument, which I will do here. Heuristically, one can divide the frequency scales ")#mi("{N}")#text(" into three regimes:")

#list(
[#text("The ")#emph[#text("injection regime")]#text(" in which the energy injection rate ")#mi("{F_N}")#text(" dominates the right-hand side of ")#link(<tao-6657ea873b1c446dad7f>)[#text("(2)")]#text(";")],
[#text("The ")#emph[#text("energy flow regime")]#text(" in which the flow rates ")#mi("{\\Pi_{N,N_1,N_2}}")#text(" dominate the right-hand side of ")#link(<tao-6657ea873b1c446dad7f>)[#text("(2)")]#text("; and")],
[#text("The ")#emph[#text("dissipation regime")]#text(" in which the dissipation ")#mi("{D_N}")#text(" dominates the right-hand side of ")#link(<tao-6657ea873b1c446dad7f>)[#text("(2)")]#text(".")]
)

#text("If we assume a fairly steady and smooth forcing term ")#mi("{f}")#text(", then ")#mi("{\\hat f}")#text(" will be supported on the low frequency modes ")#mi("{k=O(1)}")#text(", and so we heuristically expect the injection regime to consist of the low scales ")#mi("{N=O(1)}")#text(". Conversely, if we take the viscosity ")#mi("{\\nu}")#text(" to be small, we expect the dissipation regime to only occur for very large frequencies ")#mi("{N}")#text(", with the energy flow regime occupying the intermediate frequencies.")

#text("We can heuristically predict the dividing line between the energy flow regime. Of all the flow rates ")#mi("{\\Pi_{N,N_1,N_2}}")#text(", it turns out in practice that the terms in which ")#mi("{N_1,N_2 = N+O(1)}")#text(" (i.e., interactions between comparable scales, rather than widely separated scales) will dominate the other flow rates, so we will focus just on these terms. It is convenient to return back to physical space, decomposing the velocity field ")#mi("{u}")#text(" into Littlewood-Paley components")

#align(center)[#tao-fit-display[#tao-math("u_N(t,x) := \\sum_{\\left|k\\right| \\sim N} \\hat u(t,k) e^{2\\pi i k \\cdot x}", block: true)]]

#text("of the velocity field ")#mi("{u(t,x)}")#text(" at frequency ")#mi("{N}")#text(". By Plancherel’s theorem, this field will have an ")#mi("{L^2}")#text(" norm of ")#mi("{E_N(t)^{1/2}}")#text(", and as a naive model of turbulence we expect this field to be spread out more or less uniformly on the torus, so we have the heuristic")

#align(center)[#tao-fit-display[#tao-math("\\left|u_N(t,x)\\right| = O( E_N(t)^{1/2} ),", block: true)]]

#text("and a similar heuristic applied to ")#mi("{\\nabla u_N}")#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla u_N(t,x)\\right| = O( N E_N(t)^{1/2} ).", block: true)]]

#text("(One can consider modifications of the Kolmogorov model in which ")#mi("{u_N}")#text(" is concentrated on a lower-dimensional subset of the three-dimensional torus, leading to some changes in the numerology below, but we will not consider such variants here.) Since")

#align(center)[#tao-fit-display[#mitex("\\Pi_{N,N_1,N_2} = - \\int_{{\\bf R}^3/{\\bf Z}^3} u_N \\cdot ( (u_{N_1} \\cdot \\nabla) u_{N_2} )\\ dx")]]

#text("we thus arrive at the heuristic")

#align(center)[#tao-fit-display[#mitex("\\Pi_{N,N_1,N_2} = O( N_2 E_N^{1/2} E_{N_1}^{1/2} E_{N_2}^{1/2} ).")]]

#text("Of course, there is the possibility that due to significant cancellation, the energy flow is significantly less than ")#mi("{O( N E_N(t)^{3/2} )}")#text(", but we will assume that cancellation effects are not that significant, so that we typically have ")#metadata(none) <tao-350f32d6939653a7e26e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Pi_{N,N_1,N_2} \\sim N_2 E_N^{1/2} E_{N_1}^{1/2} E_{N_2}^{1/2}")]]



#text(" or (assuming that ")#mi("{E_N}")#text(" does not oscillate too much in ")#mi("{N}")#text(", and ")#mi("{N_1,N_2}")#text(" are close to ")#mi("{N}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\Pi_{N,N_1,N_2} \\sim N E_N^{3/2}.")]]

#text("On the other hand, we clearly have")

#align(center)[#tao-fit-display[#mitex("D_N \\sim \\nu N^2 E_N.")]]

#text("We thus expect to be in the dissipation regime when ")#metadata(none) <tao-12901dece9ce1f866e4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("N \\gtrsim \\nu^{-1} E_N^{1/2}")]]



#text(" and in the energy flow regime when ")#metadata(none) <tao-2fcb6465ee5cbfa35673>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("1 \\lesssim N \\lesssim \\nu^{-1} E_N^{1/2}.")]]





#text("Now we study the energy flow regime further. We assume a “statistically scale-invariant” dynamics in this regime, in particular assuming a power law ")#metadata(none) <tao-6c7adc1f0cba6da6fde0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("E_N \\sim A N^{-\\alpha}")]]



#text(" for some ")#mi("{A,\\alpha > 0}")#text(". From ")#link(<tao-350f32d6939653a7e26e>)[#text("(3)")]#text(", we then expect an average asymptotic of the form ")#metadata(none) <tao-a839ee0a1d14bee00f14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\Pi_{N,N_1,N_2} \\approx A^{3/2} c_{N,N_1,N_2} (N N_1 N_2)^{1/3 - \\alpha/2}")]]



#text(" for some structure constants ")#mi("{c_{N,N_1,N_2} \\sim 1}")#text(" that depend on the exact nature of the turbulence; here we have replaced the factor ")#mi("{N_2}")#text(" by the comparable term ")#mi("{(N N_1 N_2)^{1/3}}")#text(" to make things more symmetric. In order to attain a steady state in the energy flow regime, we thus need a cancellation in the structure constants: ")#metadata(none) <tao-80812d7992dd498c03bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{N_1,N_2} c_{N,N_1,N_2} (N N_1 N_2)^{1/3 - \\alpha/2} \\approx 0.")]]



#text(" On the other hand, if one is assuming statistical scale invariance, we expect the structure constants to be scale-invariant (in the energy flow regime), in that ")#metadata(none) <tao-36fa131132e2ff4f72b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("c_{\\lambda N, \\lambda N_1, \\lambda N_2} = c_{N,N_1,N_2}")]]



#text(" for dyadic ")#mi("{\\lambda > 0}")#text(". Also, since the Euler equations conserve energy, the energy flows ")#mi("{\\Pi_{N,N_1,N_2}}")#text(" symmetrise to zero,")

#align(center)[#tao-fit-display[#mitex("\\Pi_{N,N_1,N_2} + \\Pi_{N,N_2,N_1} + \\Pi_{N_1,N,N_2} + \\Pi_{N_1,N_2,N} + \\Pi_{N_2,N,N_1} + \\Pi_{N_2,N_1,N} = 0,")]]

#text("which from ")#link(<tao-a839ee0a1d14bee00f14>)[#text("(7)")]#text(" suggests a similar cancellation among the structure constants")

#align(center)[#tao-fit-display[#mitex("c_{N,N_1,N_2} + c_{N,N_2,N_1} + c_{N_1,N,N_2} + c_{N_1,N_2,N} + c_{N_2,N,N_1} + c_{N_2,N_1,N} \\approx 0.")]]

#text("Combining this with the scale-invariance ")#link(<tao-36fa131132e2ff4f72b4>)[#text("(9)")]#text(", we see that for fixed ")#mi("{N}")#text(", we may organise the structure constants ")#mi("{c_{N,N_1,N_2}}")#text(" for dyadic ")#mi("{N_1,N_2}")#text(" into sextuples which sum to zero (including some degenerate tuples of order less than six). This will ")#emph[#text("automatically")]#text(" guarantee the cancellation ")#link(<tao-80812d7992dd498c03bb>)[#text("(8)")]#text(" required for a steady state energy distribution, provided that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{3} - \\frac{\\alpha}{2} = 0")]]

#text("or in other words")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\frac{2}{3};")]]

#text("for any other value of ")#mi("{\\alpha}")#text(", there is no particular reason to expect this cancellation ")#link(<tao-80812d7992dd498c03bb>)[#text("(8)")]#text(" to hold. Thus we are led to the heuristic conclusion that the most stable power law distribution for the energies ")#mi("{E_N}")#text(" is the ")#mi("{2/3}")#text(" law ")#metadata(none) <tao-d76e458817fb86cc90b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("E_N \\sim A N^{-2/3}")]]



#text(" or in terms of shell energies, we have the famous Kolmogorov 5/3 law")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| = k_0 + O(1)} \\left|\\hat u(t,k)\\right|^2 \\sim A k_0^{-5/3}.", block: true)]]

#text("Given that frequency interactions tend to cascade from low frequencies to high (if only because there are so many more high frequencies than low ones), the above analysis predicts a stablising effect around this power law: scales at which a law ")#link(<tao-6c7adc1f0cba6da6fde0>)[#text("(6)")]#text(" holds for some ")#mi("{\\alpha > 2/3}")#text(" are likely to lose energy in the near-term, while scales at which a law ")#link(<tao-6c7adc1f0cba6da6fde0>)[#text("(6)")]#text(" hold for some ")#mi("{\\alpha< 2/3}")#text(" are conversely expected to gain energy, thus nudging the exponent of power law towards ")#mi("{2/3}")#text(".")

#text("We can solve for ")#mi("{A}")#text(" in terms of energy dissipation as follows. If we let ")#mi("{N_*}")#text(" be the frequency scale demarcating the transition from the energy flow regime ")#link(<tao-2fcb6465ee5cbfa35673>)[#text("(5)")]#text(" to the dissipation regime ")#link(<tao-12901dece9ce1f866e4a>)[#text("(4)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("N_* \\sim \\nu^{-1} E_{N_*}")]]

#text("and hence by ")#link(<tao-d76e458817fb86cc90b7>)[#text("(10)")]

#align(center)[#tao-fit-display[#mitex("N_* \\sim \\nu^{-1} A N_*^{-2/3}.")]]

#text("On the other hand, if we let ")#mi("{\\epsilon := D_{N_*}}")#text(" be the energy dissipation at this scale ")#mi("{N_*}")#text(" (which we expect to be the dominant scale of energy dissipation), we have")

#align(center)[#tao-fit-display[#mitex("\\epsilon \\sim \\nu N_*^2 E_N \\sim \\nu N_*^2 A N_*^{-2/3}.")]]

#text("Some simple algebra then lets us solve for ")#mi("{A}")#text(" and ")#mi("{N_*}")#text(" as")

#align(center)[#tao-fit-display[#mitex("N_* \\sim (\\frac{\\epsilon}{\\nu^3})^{1/4}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("A \\sim \\epsilon^{2/3}.")]]

#text("Thus, we have the Kolmogorov prediction")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| = k_0 + O(1)} \\left|\\hat u(t,k)\\right|^2 \\sim \\epsilon^{2/3} k_0^{-5/3}", block: true)]]

#text("for")

#align(center)[#tao-fit-display[#mitex("1 \\lesssim k_0 \\lesssim (\\frac{\\epsilon}{\\nu^3})^{1/4}")]]

#text("with energy dissipation occuring at the high end ")#mi("{k_0 \\sim (\\frac{\\epsilon}{\\nu^3})^{1/4}}")#text(" of this scale, which is counterbalanced by the energy injection at the low end ")#mi("{k_0 \\sim 1}")#text(" of the scale.")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d20c2faf00b92e29e07961c027448d5fb3592bc4eb027a7e9f55243a7db9cd-f7f871630eb512b4f840bb9c8b184ed30c5c8883bfb9ab9ca332914b9ddebed1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-347700")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("Hi Terry,")

#text("That was a very interesting article, thanks for sharing.")

#text("There was a recent paper in JFM about deriving the power law directly from the NS equations, by finding an exact representation of the triad interaction term in spectral space. Perhaps you will find it to be of interest:")

#link("http://journals.cambridge.org/download.php?file=%2FFLM%2FFLM748%2FS0022112014001797a.pdf&code=d92ab821d17601953d961c531b3262e2")[#text("http://journals.cambridge.org/download.php?file=%2FFLM%2FFLM748%2FS0022112014001797a.pdf&code=d92ab821d17601953d961c531b3262e2")]

#text("– Nick")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-348342")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("Hi Terence")

#text("I have tried without success to get a comment from you on the formulation of the Clay NS problem leaving out wellposedness and turbulence. Since you here consider turbulent solutions with Kolmogorov spectra, I hope you can here clarify if from your standpoint a turbulent solution with smallest scale nu^3/4 would be a smooth solution in the sense of the Clay problem, for any small nu > 0?")

#text("Best regards, Claes")

#text("PS ")#link("http://claesjohnson.blogspot.se/search/label/clay%20problem")[#text("http://claesjohnson.blogspot.se/search/label/clay%20problem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-348392")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2014")])]

#text("PS I put up a post with the same question:")

#link("http://claesjohnson.blogspot.se/2014/05/tao-on-clay-navier-stokes-and-turbulence.html")[#text("http://claesjohnson.blogspot.se/2014/05/tao-on-clay-navier-stokes-and-turbulence.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-349229")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2014")])]

#text("Brilliant … as usual !!")

#text("Especially,")#linebreak()#text(" “… if only because there are so many more high frequencies than low ones”")#linebreak()#text(" i consider a very enlightening observation.")

#text("Interestingly, in the actual physics we would have an upper limit to the dissipation regime.")#linebreak()#text(" The dyadic energy (manifesting itself in terms of dynamic pressure,")#linebreak()#text(" half of density times square of perturbation velocity)")#linebreak()#text(" obeys acoustics, i.e. is literally audible noise propagating at the speed of sound.")

#text("At some large N<")#linebreak()#text(" l) A ~ nu^-1 DN (nu^-3/4 A^3/8)^-4/3 = DN A^-1/2")#linebreak()#text(" m) A^3/2 ~ DN")#linebreak()#text(" n) A ~ DN^2/3 as stated, yay!")

#text("f) in j) –>")#linebreak()#text(" n) N* ~ (nu^-1 DN (nu^2 N^8/3)^-1)^3/4")#linebreak()#text(" o) N* ~ (nu^-1 DN nu^-2 N^-8/3)^3/4")#linebreak()#text(" p) N* ~ (nu^-3 DN N^-8/3)^3/4")#linebreak()#text(" q) N* ~ nu^-9/4 DN^3/4 N^-2")#linebreak()#text(" r) N*^3 ~ nu^-9/4 DN^3/4")#linebreak()#text(" s) N* ~ nu^-3/4 DN^1/4 as stated, phew.")

#text("So the findings are consistent, only perhaps a minor hiccup")#linebreak()#text(" in the Latex programming has occurred.")

#text("Latex sucks.")#linebreak()#text(" Apologies for my disliking of Latex.")

#text("*************************************************")

#text("Then i like to point out an interesting example from the real life: gas turbine flow.")#linebreak()#text(" Inherently a periodically unsteady flow with")#linebreak()#text(" a strong turbulence spectrum,")#linebreak()#text(" some nasty reference frame dilemmas,")#linebreak()#text(" an injection regime at exactly known N=1")#linebreak()#text(" (frequency = rotor RPM times blade count),")#linebreak()#text(" a strongly deterministic, computable and measurable energy spectrum at the low end.")

#text("There is much similaritiy between turbulence and deterministically periodic flow,")#linebreak()#text(" notably in their being subject to the same kind of Reynolds stress (apparent viscosity) manipulation,")#linebreak()#text(" as originally proposed by one Mr. Adamczyk, who is still actively pursuing his line of thought:")#linebreak()#text(" ")#link("http://turbomachinery.asmedigitalcollection.asme.org/mobile/article.aspx?articleID=1467565")[#text("http://turbomachinery.asmedigitalcollection.asme.org/mobile/article.aspx?articleID=1467565")]

#text("In a former life i was myself, at the cutting edge, running a turbine on a supercomputer.")#linebreak()#text(" Although the raw data have been thoroughly lost, i just found some eye candy which i like to share – a 30 second video footage of an actual energy spectrum (representing the dissipation regime from N=8 to N=512) of a smooth periodic Navier Stokes solution, including compressibility and Kolmogorov’s power law (crystalized in k-epsilon turbulence model), subjected to the slowest imaginable Fourier transform:")#linebreak()#text(" ")#link("https://www.dropbox.com/s/8wb1hfyuzrlhq5j/DyadicEnergySpectrumN8-256.qt")[#text("https://www.dropbox.com/s/8wb1hfyuzrlhq5j/DyadicEnergySpectrumN8-256.qt")]

#text("Thank you Terry, for bringing this up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-349465")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2014")])]

#text("Hi again Terence:")

#text("Here is another post with my arguments showing that the present formulation of the Clay NS Problem is unfortunate (mathematically meaningless):")

#link("http://claesjohnson.blogspot.se/2014/05/mr-clay-and-meaningless-navier-stokes.html")[#text("http://claesjohnson.blogspot.se/2014/05/mr-clay-and-meaningless-navier-stokes.html")]

#text("I think the World expects you to comment on these aspects of the problem.")#linebreak()#text(" In any case, I do.")

#text("Best regards, Claes")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-352322")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2014")])]

#text("Hi Claes,")

#text("i do not really agree with your view that the Clay problem would be meaningless.")#linebreak()#text(" it is incredibly relevant, easily a million times more important than the associated prize. and the formulation is open to a negative answer.")

#text("Then, what are you saying with your landing gear example?")

#text("What you have there, is a separation,")#linebreak()#text(" Adverse pressure gradient eating away all the bulk flow energy,")#linebreak()#text(" and whats left is “pure” turbulence.")#linebreak()#text(" And probably not very accurately calculated in that example.")

#text("some context on separation:")#linebreak()#text(" ")#link("http://www.desktop.aero/appliedaero/blayers/separation.html")[#text("http://www.desktop.aero/appliedaero/blayers/separation.html")]

#text("If you are trying to argue with the problem, it will not surrender to you.")

#text("If you would be saying that the problem cannot be answered positively,")#linebreak()#text(" then i mightily agree with you.")

#text("Indeed, i believe the negative answer is what the world is waiting for.")

#text("And the problem formulation explicitly is asking for some new ideas.")

#text("The first idea of course must be to NOT “restrict attention to incompressible fluids”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-352452")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2014")])]

#text("No, incompressible flow is of interest. No, a negative blow up result would not be of interest since real flow and computational flow do not blow up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-352613")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2014")])]

#text("False !")

#text("The blowup exists in the real flow.")#linebreak()#text(" ")#link("http://physics.info/shock/")[#text("http://physics.info/shock/")]

#text("With incompressibly, you do not have a speed of sound,")#linebreak()#text(" or rather you have useless infinity speed of sound.")

#text("But air and water are just NOT like that.")#linebreak()#text(" There IS resonance on the molecular level at the speed of sound.")

#text("Somehow, physics is cheating us in order to work.")#linebreak()#text(" Air can eat away what looks like unbounded amounts of kinetic energy")#linebreak()#text(" when excited at the speed of sound.")

#text("It was physically proven that air eats as much of the bulk flow kinetic energy as it must, in order to save physics.")

#text("Somehow, any supersonic velocity is strictly forbidden anywhere near the surface of a solid body moving.")

#text("The funny behavior is predicted up to unbounded bulk flow Mach Numbers, with a limiting “infinity shock” compression ratio equal to the specific heat capacity ratio.")

#text("Whether this funny behavior also applies to the apparently infinite spectrum of turbulent kinetic energies, is not proven.")

#text("The main reason, i suppose, is that nobody is able to observe this spectrum to near-infinite frequencies, and that nobody owns a computer powerful enough to process such kind of data.")

#text("But somehow it could work beautifully.")

#text("Heck, why should these two behave fundamentally any different?")#linebreak()#text(" The amount of energy does not care whether its coming just from one direction, or from all directions simultaneously.")

#text("Notably, nobody has ever observed such thing as a locally supersonic turbulence.")

#text("So in my opinion, speed of sound is the upper bound.")

#text("And then, i agree, incompressible flow is still of interest.")

#text("Can the assumption of physical speed of sound")#linebreak()#text(" (although it follows from compressibility)")#linebreak()#text(" be somehow smuggled into the incompressible NS equations?")

#text("Obviously, it is not easy and i am not a mathematician.")

#text("kind regards,")#linebreak()#text(" Roland")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-360164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2014")])]

#text("A shock is a mild jump in real compressible flow-field; it is not a singularity or a blow-up. (In math, smooth functions are dense in the shock manifold.) In Van Dyke’s an Album of Fluid Motion (1982), Plate 261 for a flow visualization of an Ogive-cylinder at Mach 1.7 shows the contrast between shock waves and the turbulence behind the cylinder/in the boundary layers. The shock and the turbulence have completely different flow structures. Essentially, the turbulence is structually identical in both compressible and incompressible flows (cf. Plate 151). The Clay problem is restricted to incompressible viscous flows which are “easier” to deal with in order to understand turbulence in a fundamental sense.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-351692")[#strong[#text("Kolmogorov’s power law for turbulence | Claudia Mihai")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2014")]

#text("[…] See on terrytao.wordpress.com […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-352731")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2014")])]

#text("Again Terence: Is my question not reasonable? If not, say it. If it is reasonable, then it deserves an answer, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-367814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2014")])]

#text("I think that the Clay NS problem is a mathematically consistent formulation. The issue of well-posedness is always attached to a PDE problem linking to physics, regardless whether it is explicitly specified. For example, if one can work out a good apriori bound for the velocity (say), the well-posedness is implied. On your second concern: how do you define turbulence? (I hope that your answer is not one of Tsinober’s entries.) What you are trying to stress, I guess, is that a solution to the Clay problem needs to include “turbulence” – whatever we attempt to convey is largely without a consensus so far. But the formulation itself does not need to recite the fact. As anticipated, a proposed math solution will tell us something significant about “turbulence”. Apart from “turbulence”, it must elaborate a lot of more on fluid flows; we know very well how complicated high-Reynolds-number jets/wakes (e.g.) behave in space and in time for given initial conditions.")

#text("The impression that no solutions have been found for the Clay problem (and the other remaining five) to date does not necessarily mean those formulations are faulty.")

#text("Nevertheless, I do share your view how a solution or an idea to crack the problem should suitably be judged, valued and hence assessed. As pointed out, a claim has been made that there exists a super-critical barrier which blocks (certain) NS solutions even though the analysis is not based on the true Navier-Stokes equation! In addition to bafflement, a mentality is however discernible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-367962")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2014")])]

#text("The silence from those in charge of the problem formulation, Fefferman, Constantin, Caffarelli and Tao, is disappointing and not helpful in convincing tax payers to support mathematics,, or making the Clay Prize meaningful and of interest to a general public. To say nothing and close the door is not a sign of strength. To leave out well-posedness is both mathematically and physically without reason, and unreasonable mathematics is not science.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-354483")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2014")])]

#text("The origins of Kolmogorov’s scaling law in the research of the polymath Lewis Fry Rickardson are engagingly described in ")#strong[#link("http://books.google.com/books?id=wUdtVHBr-OQC&pg=PA189")[#text("Section 8.4 “The four-thirds rule”")]]#text(" of Chapter 8 “A Quaker Mathematician” of T. W. Körner’s book ")#emph[#text("The Pleasures of Counting")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-369036")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2014")])]

#text("Many thanks “Anonymous”, for your comments.")

#text("Perhaps in taking the risk of exploding the scope of this particular thread,")#linebreak()#text(" i would like to ascertain that the actual shock is anything but mild.")#linebreak()#text(" In trans-sonic flow, the air-wall shakes violently")#linebreak()#text(" (between M > 1 and M < 1, as if to hide M == 1 from our observation)")#linebreak()#text(" and is able to destroy stuff like (say) the nozzle of a poorly designed rocket engine.")

#text("The Prandtl-Glauert singularity")#linebreak()#text(" (context: ")#link("http://en.wikipedia.org/wiki/Prandtl%E2%80%93Glauert_singularity")[#text("http://en.wikipedia.org/wiki/Prandtl%E2%80%93Glauert_singularity")]#text(")")#linebreak()#text(" could be imagined to actually exist, but is somehow strictly hidden from our observation.")#linebreak()#text(" Is some sort of event horizon doing this to us??")

#text("Maybe we are only lazy,")#linebreak()#text(" somehow preferring the role of the passive observer (at rest),")#linebreak()#text(" over the pain of actually \"going through the shock\" with the particle")#linebreak()#text(" via the proper Lorentz transformation??")

#text("By all means, the (2dimensional) Prandtl-Glauert rule is technically very convenient to use in aircraft design,")#linebreak()#text(" allowing (with a mathematically precise affinity) the transformation of an otherwise incompressible regime")#linebreak()#text(" to the high-subsonic (compressible) regime.")

#text("Notably, the 3dimensional expansion of the Prandtl-Glauert rule (called the Göthert-rule)")#linebreak()#text(" has the interesting property of looking stunningly similar to the relativistic Lorentz-contraction.")

#text("Context can unfortunately not so easily provided via google,")#linebreak()#text(" but it basically works as an artificial body-shape contraction in its y- and z-dimensions")#linebreak()#text(" (perpendicular to the locally wall-parallel bulk flow x) by the Prandtl-Glauert factor,")#linebreak()#text(" \\newline")#linebreak()#text(" \\beta = \\sqrt{1 – M_\\infty^2}")

#text("Or more clearly:")#linebreak()#text(" where the relativistic Lorentz-contraction (with speed of light c) says")#linebreak()#text(" \\newline")#linebreak()#text(" L_{x}^\\prime = L_{x}\\sqrt{1-v^{2}/c^{2}}")

#text("the high-subsonic Göthert-contraction (with speed of sound c) says")#linebreak()#text(" \\newline")#linebreak()#text(" L_{y,z}^\\prime = L_{y,z}\\sqrt{1-v^{2}/c^{2}}")

#text("(If only after some positive feedback & bafflement achieved),")#linebreak()#text(" i am now firmly committed to the mentality of thinking \"false\" w.r.t. the Navier-Stokes question,")#linebreak()#text(" and compressibility is the only conceivable angle of attack.")

#text("Then if perhaps not the world, at least i hope that Terry will eventually come up with the formal proof,")#linebreak()#text(" once the relevant answer of \"true\" or \"false\" has been found")#linebreak()#text(" (if only because he always writes up things so beautifully).")

#text("More importantly,")#linebreak()#text(" it is up entirely to each of us how much of the information given to us is thrown away.")

#text("In my opinion, trying to prove \"Navier-Stokes\" without \"Stokes\"")#linebreak()#text(" (without even googling jolly Mr. George Gabriel Stokes and paying some attention to the shockingly significant stuff he actually came up with in his life time, in so many areas like optics, acoustics, electricity, elasticity, shock waves, reverse-time and more) must frankly be an exercise in futility.")

#text("More modestly, until \"true\" or \"false\" has been found, i like to suggest to not throw away relativistic effects.")#linebreak()#text(" Given Einstein, \"volumetric continuity\" does not automatically substitute \"mass continuity\".")#linebreak()#text(" Indeed the proper continuity equation IS already part of the proper Navier-Stokes set")#linebreak()#text(" \\newline")#linebreak()#text(" \\partial_t \\rho + \\nabla \\cdot (\\rho \\cdot u) = 0")

#text("and could be used here (in its relativistic form, i.e. the energy-momentum relation)")#linebreak()#text(" as an independent \"measure of sanity\" constraint.")#linebreak()#text(" Something similar has already been done successfully with regard to huge black holes very far away,")#linebreak()#text(" while turbulence and audible sound are so much easier to observe in a laboratory,")#linebreak()#text(" right in front of our ears and eyes.")

#text("Possibly some observable facts about turbulence have not yet been successfully observed and may help answering the question.")#linebreak()#text(" Given the opportunity of some free lab space, i would happily commit myself to looking for something useful,")#linebreak()#text(" perhaps by quitting my day job (temporarily) and pursue a humble ph.d. somewhere, and attempt some honest and very affordable experiments.")#linebreak()#text(" But, unfortunately, academic people are so difficult to convince by a mere idea…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83916dcc9d1dc3476bd6c29a4a23de72413c23c52a477ac3bddc4db9d52bfb69-bf5910ab3d832cbe0b6d8e1f1c66b6bfbd9dd0ca3fb8a3df297e54f98eba0232.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nodota")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-377184")[#strong[#text("nodota")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")])]

#text("Reblogged this on ")#link("http://nodota.wordpress.com/2014/06/22/kolmogorovs-power-law-for-turbulence/")[#text("nodota")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avila, Bhargava, Hairer, Mirzakhani | What's new")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-404905")[#strong[#text("Avila, Bhargava, Hairer, Mirzakhani | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("[…] should asymptotically be distributed according to Kolmogorov’s power law, as discussed in this previous post. This is still far from established rigorously (although there are some results in this direction […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1097ee771bdc656de86ab924801d4d07e33dc51620cf8a2133bba767c7ad48b7-70c763413f74e6f5c483579ac247353042f7479425314327f75bcd676a0dab68.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Other Clay Maths Problem | Ajit Jadhav's Weblog")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-410569")[#strong[#text("The Other Clay Maths Problem | Ajit Jadhav's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("[…] even though Terry Tao responds at his blog to many people, he doesn’t respond to Johnson [^]. [Interestingly, though, Tao also does not delete Johnson’s replies once he publishes them. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-479938")[#strong[#text("The unexpected math behind Van Gogh’s “Starry Night” – IEG Global")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2017")]

#text("[…] Turbulence, unlike painting, is mostly a time-dependent phenomenon, and after some time, breaks statistical self-similarity that Kolmogorov predicted in the 1960s. To learn more about Kolmogorov’s predictions, Terry Tao provides a great overview of Kolmogorov’s power laws for turbulence. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-486421")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")])]

#text("Dear Tao,")

#text("I came across this blog and while reading this I am puzzled by this line:")

#text("scales at which a law (6) holds for some ")#mi("\\alpha > 2/3")#text(" are likely to lose energy in the near-term, while scales at which a law (6) hold for some ")#mi("\\alpha 2/3")#text(", ")#mi("E_N \\sim AN^{-\\alpha}")#text(" is smaller than expected, and if such scales continue to lose energy, they will have even less energy.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-486422")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")])]

#text("I may have messed up with the latex code, but I guess you can get the idea.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 2: Onsager’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-510685")[#strong[#text("255B, Notes 2: Onsager’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("[…] is also compatible with that arising from the Kolmogorov theory of turbulence (discussed in this previous post), but we will not discuss this interesting connection further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a3c9c9d0b74cdec211502062538d2dc6c908795bd1d2bfb363377a3206a5942-4e26e56683ad4c76d794a24eb50f2bf9dd15b747b2b26987b3af961b1ff27f9d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fujun Du")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-513759")[#strong[#text("Fujun Du")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2019")])]

#text("Typo in the Navier-Stokes equation? Should have a negative sign in front of ")#mi("\\nabla p")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-513786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2019")])]

#text("Dear Prof Tao,")

#text("why do you avoid thermodynamics in your analysis of Navier Stokes????")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df39a7e82fa0547daacacec84f2e90901368a671738016a89f59b3ee9780cd96-b50ccd47325e53d5c81d2863f7a400cec297ea6a16ada5968bbd18ef979e0b02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ppalme")]], [#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/#comment-682284")[#strong[#text("ppalme")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2023")])]

#text("Wind Tunnel Experiments Challenge Turbulence Theory")#linebreak()#text(" – power law prediction not correct – ")#linebreak()#text(" “new data showed that in the inertial range ζ2 𝜁2 is not independent of r. Rather, it has a clear logarithmic dependence on r for separations spanning up to two orders of magnitude.” ….”logarithmic dependance is independent of the Reynolds number, except for the fact that it occurs over an increasing range of separations as the Reynolds number is increased”")#linebreak()#text(" ")#link("https://physics.aps.org/articles/v16/123")[#text("https://physics.aps.org/articles/v16/123")]
]
