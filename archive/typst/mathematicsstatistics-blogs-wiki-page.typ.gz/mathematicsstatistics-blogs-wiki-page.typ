// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/
// Converted to Typst by tao2typ: "2026-10-14T16:35:50.887597+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics/Statistics blogs wiki page", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics/Statistics blogs wiki page")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/")[#text("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the ")#link("http://golem.ph.utexas.edu/category/2009/08/what_do_mathematicians_need_to.html")[#text("discussion on what mathematicians need to know about blogging")]#text(" mentioned in the ")#link("https://terrytao.wordpress.com/")[#text("previous post")]#text(", it was noted that there didn’t seem to be a single location on the internet to find out about mathematical blogs. Actually, there is a page, but it has been relatively obscure – the ")#link("http://wiki.henryfarrell.net/wiki/index.php/Mathematics/Statistics")[#text("Mathematics/Statistics subpage")]#text(" of the ")#link("http://wiki.henryfarrell.net/wiki/index.php/Main_Page")[#text("Academic Blogs wiki")]#text(". It does seem like a good idea to have a reasonably comprehensive page containing all the academic mathematics blogs that are out there (as well as links to other relevant sites), so I put my own maths blogroll onto the page, and encourage others to do so also (though you may wish to read the ")#link("http://wiki.henryfarrell.net/wiki/index.php/Frequently_Asked_Questions")[#text("FAQ for the wiki")]#text(" first).")

#text("It may also be useful to organise the list into sublists, and to add more commentary on each individual blog. (In theory, each blog is supposed to have its own sub-page, though in practice it seems that very few blogs do at present.)")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anotherAnonymous")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40944")[#strong[#text("anotherAnonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("Dear Terry, I’ve just made some changes as you indicated (sublists and so on, but more work to do). Is that the kind of thing you where looking for? If not please feel free to revert this to your previous version.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("This does look more organised, yes (though I would probably not have my own blog spread out over so many sections of mathematics, since in many cases I just have a handful of posts in that field). Perhaps other readers could offer feedback as to what kind of organisation for a maths blog directory they would find useful?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44134bc24b7127455e446d3683925c9d26a062fcebf2dedc4f19d4bff492f57a-45180d30f2e07ee83c62ffac6ba77df69b691df24e144e2d8deb7519744b80a3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alpmestan")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40946")[#strong[#text("alpmestan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("Hi,")

#text("I think a “tag” system instead of a “category” system would be much better. Each blog has tags representing what the content is about, very much like on a blog, with tags like “combinatorics”, etc.")

#text("Then it would be great to have pages corresponding to tags, thus listing all the blogs talking about a given tag.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c525dbb80380d49b39d66b3899a94cab193179b50b9b7143ceec37b7536137a2-b99ed5240b84b9fc5ff2d46571833825fd48270c8b1a1b54acda76545b423e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40947")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("I agree wholeheartedly. Too many math topics cross borders and don’t fit neatly into one specific math category. The tag system would be better because it would double-list.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f3110a4fe11b8f0b11e3ce966c2ab2ac2e8f0a67944606caffbfd26cbfe3313-6c6d41a295497437ca2e6ac72536111291bf8459ae5a38a65e89cd98d8469fe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40951")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("I agree with this and this is much more easier classification too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Hmm, the wiki format doesn’t really support tagging. (One could create a separate page for each blog, and assign one or more categories to each, but this has the drawback that it becomes more complicated to enter in a new blog, and the immediate objective currently is to encourage expansion of the list of blogs.)")

#text("Perhaps once the list becomes more complete, it may be possible to process it further on a different software platform…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40950")[#strong[#text("AMS Graduate Student Blog » Blog Archive » An extensive list of Mathematics and Statistics blogs")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")]

#text("[…] of riches, where ought the intrepid mathematical reader to start? A recent article at What’s New mentions a very large list of mathematics and statistics […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40965")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Strictly speaking, this is only for blogs written by academics, which is an excellent list covering 95% of what’s useful. But there are some troubling exceptions that technically shouldn’t be listed; in particular, anything written by someone below Ph.D. level doesn’t qualify, which list includes the excellent Delta Epsilons (high-schoolers) and Annoying Precision (undergraduate). (Full disclosure: This category also includes my own blog.)")

#text("In addition, I don’t know of any pure math people to whom this applies, but it appears that people who aren’t employed by some sort of degree-granting institution don’t qualify, either. (Looking at the description in the FAQ, it’s unclear whether even a professor at the IAS technically qualifies, although if there was a question I doubt that they’d throw it out.) In TCS, I believe this disqualifies Mihai Patrascu’s blog, and in other closely related fields, we have to throw out the D-Wave blog, Bruce Schneier’s blog, and Lubos Motl’s blog, all of which are certainly notable.")

#text("I don’t know that relaxing that requirement would be necessarily better; it’d be more open, and a few extra gems would turn up, but you’d run the risk of getting a bunch of cranks and ")#link("http://harrisonbrown.wordpress.com/")[#text("overinflated egos")]#text(" mixed in with the good stuff. Still, it’s probably important to keep in mind that this isn’t, in fact, intended to be a comprehensive list of math blogs, and should perhaps not be treated as such.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40967")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Hmm. I’m not sure what the best way to draw the line is here between being too snobbish or too permissive, but perhaps in the near term what should be done is to flesh out the names and affiliations of blog authors, which is still somewhat incomplete at present. Later on we can decide whether blogs that do not have an academic affiliation amongst the authors need to be reclassified, deleted, marked with an asterisk, or whatever.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44134bc24b7127455e446d3683925c9d26a062fcebf2dedc4f19d4bff492f57a-45180d30f2e07ee83c62ffac6ba77df69b691df24e144e2d8deb7519744b80a3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alpmestan")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40973")[#strong[#text("alpmestan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("I agree with that.")

#text("Though, there still is a problem for permitting multi-classifications of blogs… But IIRC, a wiki page can be associated to multiple categories, right ? If it’s so, then problem solved I guess.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44134bc24b7127455e446d3683925c9d26a062fcebf2dedc4f19d4bff492f57a-45180d30f2e07ee83c62ffac6ba77df69b691df24e144e2d8deb7519744b80a3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alpmestan")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40966")[#strong[#text("alpmestan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("To the previous post I’d answer that this list wouldn’t aim at being an alternative to the maths section of Arxiv… It’s deliberately about maths *blogs*, so we can only blame people for missing pedagogy. For pure and hard “acamedical” articles only, there are arxiv and maths journals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40972")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Harrison does have a point that as written my own overinflated ego would be disallowed. But maybe that’s a good thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40978")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("I should probably make it clear that of course I wasn’t accusing John, or any mathematical blogger, of having an overinflated ego — I was just attempting a self-deprecating joke. (John, I don’t think that you thought I was, but just in case anyone else doesn’t get it I don’t want them to think of me as that sort of person!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40974")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Oh, and I notice you’ve listed me as being at Tulane. I haven’t been at Tulane in over a year, and currently have no academic affiliation at all. Or non-academic, for that matter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7b3e5d904932dcca1708db23de32f91876c5d738e9e38a82a3c4b079977be62-3c9b7fbd63c57ffdda02f638e1891c854749eed000a4484c3f40eb7843c3c9db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Emerton")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-40980")[#strong[#text("Matthew Emerton")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Reading the FAQ for the Wiki, one finds that blogs by those pursuing a doctoral degree are allowed to be listed. So Ph.D. students at least are fine.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-41028")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2009")])]

#text("If you allow students pursuing a PH. D. then why not allow people who have them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-41029")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2009")])]

#text("Graduate students are acolytes, academics are priests, and people with Ph.D.s who aren’t in academia are excommunicate.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7b3e5d904932dcca1708db23de32f91876c5d738e9e38a82a3c4b079977be62-3c9b7fbd63c57ffdda02f638e1891c854749eed000a4484c3f40eb7843c3c9db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Emerton")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-41037")[#strong[#text("Matthew Emerton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2009")])]

#text("If you read the FAQ of the wiki, it seems that they are trying to limit the scope of their wiki to a manageable size. My impression is that in the humanities, there are many blogs out there (especially if one takes into account that the humanities and politics probably share one or more frontiers), and they don’t want their wiki to be swamped by all of them. Insisting that blogs be run by academics is one way of limiting the scope of the wiki. On the other hand, they also allow non-academic blogs (in their technical sense, i.e. non student/faculty blogs) in exceptional circumstances. (This is just what I gathered from reading the FAQ on the wiki, after learning about it from this post. My comment regarding Ph.D. students was made as a correction to Harrison’s comment. I don’t know anything more about the inner mysteries of the wiki than anyone else writing here.)")

#text("I would guess that the math part of their wiki is a fairly small part of their enterprise (since almost no-one in the math blog world seems to have even been aware of it until its existence was discussed recently here and at the n-category cafe), and so imagine that they are not going to make much of a fuss about exactly who is running the math blogs that are listed. If or when they do, it is probably time for the mathematical community (in a broad sense) to make its own list of blogs. (Or perhaps we can just keep relying on Terry’s blogroll.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-41124")[#strong[#text("גיקדום 24.9.2009 « ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2009")]

#text("[…] הדיון למעלה גרם לטרנס טאו, כנראה המתמטיקאי ה\"מפורסם\" בעולם כיום, שהדבר הראשון שמתמטיקאיים צריכים לדעת על בלוגים, הוא איזה בלוגים מתמטיקאיים יש. חשב, עשה, פתח כמה עמודי ויקי. המידע פה. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-41391")[#strong[#text("links for 2009-09-13")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2009")]

#text("[…] Mathematics/Statistics blogs wiki page « What’s new (tags: math blog internet) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55c2e7d0a26f8e06ec1e5925560b161650dfaf110bc006c4810ff46ed5b1ae95-9636cb653f1ba11a10e5e811a20ef580a9773c54f04a0ed18531653886f97678.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenrose")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-42400")[#strong[#text("Kenrose")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2009")])]

#text("Thanks a lot for pointing me to that page, I added my blog!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5fc912b63c1e63554f4cd4ec4a38737c31b4527a7efc1eac1891acc628c52d4-c8a18ffb96cb242151d2704aee4add05b516a8c1e31e5d47bebe29f5db130b76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pratik Poddar")]], [#link("https://terrytao.wordpress.com/2009/08/10/mathematicsstatistics-blogs-wiki-page/#comment-123724")[#strong[#text("Pratik Poddar")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2012")])]

#text("Wiki not working.")
]
