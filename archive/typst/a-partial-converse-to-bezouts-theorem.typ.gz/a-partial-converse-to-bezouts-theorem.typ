// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:53.855837+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A partial converse to Bezout’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A partial converse to Bezout’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 September 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/")[#text("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the first non-trivial theorems one encounters in classical algebraic geometry is ")#link("http://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bézout’s theorem")]#text(", which we will phrase as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Bézout’s theorem)")]#text(" Let ")#mi("{k}")#text(" be a field, and let ")#mi("{P, Q \\in k[x,y]}")#text(" be non-zero polynomials in two variables ")#mi("{x,y}")#text(" with no common factor. Then the two curves ")#mi("{\\{ (x,y) \\in k^2: P(x,y) = 0\\}}")#text(" and ")#mi("{\\{ (x,y) \\in k^2: Q(x,y) = 0\\}}")#text(" have no common components, and intersect in at most ")#mi("{\\text{deg}(P) \\text{deg}(Q)}")#text(" points.")
]

#text("This theorem can be proven by a number of means, for instance by using the classical tool of ")#link("http://en.wikipedia.org/wiki/Resultant")[#text("resultants")]#text(". It has many strengthenings, generalisations, and variants; see for instance this previous blog post on ")#link("https://terrytao.wordpress.com/2011/03/23/bezouts-inequality/")[#text("Bézout’s inequality")]#text(". Bézout’s theorem asserts a fundamental algebraic dichotomy, of importance in combinatorial incidence geometry: any two algebraic curves either share a common component, or else have a bounded finite intersection; there is no intermediate case in which the intersection is unbounded in cardinality, but falls short of a common component. This dichotomy is closely related to the integrality gap in algebraic dimension: an algebraic set can have an integer dimension such as ")#mi("{0}")#text(" or ")#mi("{1}")#text(", but cannot attain any intermediate dimensions such as ")#mi("{1/2}")#text(". This stands in marked contrast to sets of analytic, combinatorial, or probabilistic origin, whose “dimension” is typically not necessarily constrained to be an integer.")

#text("Bézout’s inequality tells us, roughly speaking, that the intersection of a curve of degree ")#mi("{D_1}")#text(" and a curve of degree ")#mi("{D_2}")#text(" forms a set of at most ")#mi("{D_1 D_2}")#text(" points. One can consider the converse question: given a set ")#mi("{S}")#text(" of ")#mi("{N}")#text(" points in the plane ")#mi("{k^2}")#text(", can one find two curves of degrees ")#mi("{D_1,D_2}")#text(" with ")#mi("{D_1 D_2 = O(N)}")#text(" and no common components, whose intersection contains these points?")

#text("A model example that supports the possibility of such a converse is a grid ")#mi("{S = A \\times B}")#text(" that is a Cartesian product of two finite subsets ")#mi("{A, B}")#text(" of ")#mi("{k}")#text(" with ")#tao-math("{\\left|A\\right| \\left|B\\right| = N}", block: false)#text(". In this case, one can take one curve to be the union of ")#tao-math("{\\left|A\\right|}", block: false)#text(" vertical lines, and the other curve to be the union of ")#tao-math("{\\left|B\\right|}", block: false)#text(" horizontal lines, to obtain the required decomposition. Thus, if the proposed converse to Bézout’s inequality held, it would assert that any set of ")#mi("{N}")#text(" points was essentially behaving like a “nonlinear grid” of size ")#mi("{N}")#text(".")

#text("Unfortunately, the naive converse to Bézout’s theorem is false. A counterexample can be given by considering a set ")#mi("{S = S_1 \\cup S_2}")#text(" of ")#mi("{2N}")#text(" points for some large perfect square ")#mi("{N}")#text(", where ")#mi("{P_1}")#text(" is a ")#mi("{\\sqrt{N}}")#text(" by ")#mi("{\\sqrt{N}}")#text(" grid of the form described above, and ")#mi("{S_2}")#text(" consists of ")#mi("{N}")#text(" points on an line ")#mi("{\\ell}")#text(" (e.g. a ")#mi("{1 \\times N}")#text(" or ")#mi("{N \\times 1}")#text(" grid). Each of the two component sets ")#mi("{S_1, S_2}")#text(" can be written as the intersection between two curves whose degrees multiply up to ")#mi("{N}")#text("; in the case of ")#mi("{S_1}")#text(", we can take the two families of parallel lines (viewed as reducible curves of degree ")#mi("{\\sqrt{N}}")#text(") as the curves, and in the case of ")#mi("{S_2}")#text(", one can take ")#mi("{\\ell}")#text(" as one curve, and the graph of a degree ")#mi("{N}")#text(" polynomial on ")#mi("{\\ell}")#text(" vanishing on ")#mi("{S_2}")#text(" for the second curve. But, if ")#mi("{N}")#text(" is large enough, one cannot cover ")#mi("{S}")#text(" by the intersection of a single pair ")#mi("{\\gamma_1, \\gamma_2}")#text(" of curves with no common components whose degrees ")#mi("{D_1,D_2}")#text(" multiply up to ")#mi("{D_1 D_2 = O(N)}")#text(". Indeed, if this were the case, then without loss of generality we may assume that ")#mi("{D_1 \\leq D_2}")#text(", so that ")#mi("{D_1 = O(\\sqrt{N})}")#text(". By Bézout’s theorem, ")#mi("{\\gamma_1}")#text(" either contains ")#mi("{\\ell}")#text(", or intersects ")#mi("{\\ell}")#text(" in at most ")#mi("{O(D_1) = O(\\sqrt{N})}")#text(" points. Thus, in order for ")#mi("{\\gamma_1}")#text(" to capture all of ")#mi("{S}")#text(", it must contain ")#mi("{\\ell}")#text(", which forces ")#mi("{\\gamma_2}")#text(" to not contain ")#mi("{\\ell}")#text(". But ")#mi("{\\gamma_2}")#text(" has to intersect ")#mi("{\\ell}")#text(" in ")#mi("{N}")#text(" points, so by Bézout’s theorem again we have ")#mi("{D_2 \\geq N}")#text(", thus ")#mi("{D_1 = O(1)}")#text(". But then (by more applications of Bézout’s theorem) ")#mi("{\\gamma_1}")#text(" can only capture ")#mi("{O(\\sqrt{N})}")#text(" of the ")#mi("{N}")#text(" points of ")#mi("{S_1}")#text(", a contradiction.")

#text("But the above counterexample suggests that even if an arbitrary set of ")#mi("{N}")#text(" (or ")#mi("{2N}")#text(") points cannot be covered by the single intersection of a pair of curves with degree multiplying up to ")#mi("{O(N)}")#text(", one may be able to cover such a set by a small number of such intersections. The purpose of this post is to record the simple observation that this is, indeed, the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Partial converse to Bézout’s theorem)")]#text(" Let ")#mi("{k}")#text(" be a field, and let ")#mi("{S}")#text(" be a set of ")#mi("{N}")#text(" points in ")#mi("{k}")#text(" for some ")#mi("{N > 1}")#text(". Then one can find ")#mi("{m = O(\\log N)}")#text(" and pairs ")#mi("{P_i,Q_i \\in k[x,y]}")#text(" of coprime non-zero polynomials for ")#mi("{i=1,\\ldots,m}")#text(" such that ")#metadata(none) <tao-e642b12901a6ee51456f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("S \\subset \\bigcup_{i=1}^m \\{ (x,y) \\in k^2: P_i(x,y) = Q_i(x,y) = 0 \\}")]]

#text("and ")#metadata(none) <tao-3bad94119a1d92eb9c47>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{i=1}^m \\text{deg}(P_i) \\text{deg}(Q_i) = O( N ).")]]
]

#text("Informally, every finite set in the plane is (a dense subset of) the union of logarithmically many nonlinear grids. The presence of the logarithm is necessary, as can be seen by modifying the ")#mi("{P_1 \\cup P_2}")#text(" example to be the union of logarithmically many Cartesian products of distinct dimensions, rather than just a pair of such products.")

#text("Unfortunately I do not know of any application of this converse, but I thought it was cute anyways. The proof is given below the fold.")

#metadata(none) <tao-d0c6dcfd0905359edbc4>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("The first step is to cover ")#mi("{S}")#text(" by a single, reasonably low-degree curve, which is a trick which also underlies the ")#emph[#text("polynomial method")]#text(" in incidence combinatorics. Let ")#mi("{D}")#text(" be the first natural number such that ")#mi("{\\frac{(D+1)(D+2)}{2} > N}")#text(", thus ")#mi("{D = O(\\sqrt{N})}")#text(". The space of all polynomials in two variables of degree at most ")#mi("{D}")#text(" is ")#mi("{\\frac{(D+1)(D+2)}{2}}")#text(", while the requirement that such a polynomial vanishes at every point of ")#mi("{S}")#text(" comprises ")#mi("{N}")#text(" linear constraints (not necessarily independent). By linear algebra, we conclude that there exists a non-zero polynomial ")#mi("{P \\in k[x,y]}")#text(" of degree at most ")#mi("{D = O(\\sqrt{N})}")#text(" which vanishes at every point of ")#mi("{S}")#text(".")

#text("Let ")#mi("{P^{\\prime}_1,\\ldots,P^{\\prime}_n}")#text(" denote the distinct irreducible factors of ")#mi("{P}")#text(", and ")#mi("{d^{\\prime}_j}")#text(" the degree of each ")#mi("{P^{\\prime}_j}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n d^{\\prime}_j \\ll \\sqrt{N}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S \\subset \\bigcup_{j=1}^n \\{ (x,y) \\in k^2: P^{\\prime}_j(x,y) = 0 \\}.")]]

#text("In particular, we can partition ")#mi("{S}")#text(" into ")#mi("{S_1 \\cup \\ldots \\cup S_n}")#text(", where")

#align(center)[#tao-fit-display[#mitex("S_j \\subset \\{ (x,y) \\in k^2: P^{\\prime}_j(x,y) = 0 \\}")]]

#text("for each ")#mi("{j=1,\\ldots,n}")#text(", with the ")#mi("{S_1,\\ldots,S_n}")#text(" being disjoint.")

#text("Fix an ")#mi("{j}")#text(". By applying a generic linear change of variables, we may assume that the ")#mi("{y^{d^{\\prime}_j}}")#text(" coefficient of ")#mi("{P^{\\prime}_j}")#text(" is non-zero. (Geometrically, we are changing coordinates so that the point at infinity on the ")#mi("{y}")#text("-axis does not lie on the zero locus of ")#mi("{P^{\\prime}_j}")#text(".) Observethat for any ")#mi("{D_j > 0}")#text(", the space of polynomials in the ring ")#mi("{k[x,y]/(P^{\\prime}_j)}")#text(" of degree at most ")#mi("{D_j+d^{\\prime}_j}")#text(" is at least ")#mi("{D_j d^{\\prime}_j}")#text(", since the monomials ")#mi("{x^a y^b}")#text(" for ")#mi("{0 \\leq a < D_j}")#text(" and ")#mi("{0 \\leq b < d^{\\prime}_j}")#text(" are linearly independent. Setting ")#mi("{D_j}")#text(" to be the first natural number with ")#tao-math("{D_j d^{\\prime}_j > \\left|S_j\\right|}", block: false)#text(", we conclude that we can find a polynomial ")#mi("{Q^{\\prime}_j \\in k[x,y]}")#text(" that is not a multiple of ")#mi("{P^{\\prime}_j}")#text(", which vanishes on ")#mi("{S_j}")#text(", and has degree ")#metadata(none) <tao-5154ed9edd766c720bf7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\text{deg}(Q^{\\prime}_i) \\leq D_j + d^{\\prime}_j \\ll \\frac{\\left|S_j\\right|}{d^{\\prime}_j} + d^{\\prime}_j.", block: true)]]

#text("By construction, we have")

#align(center)[#tao-fit-display[#mitex("S \\subset \\bigcup_{j=1}^n \\{ (x,y) \\in k^2: P^{\\prime}_j(x,y) = Q^{\\prime}_j(x,y) = 0 \\}.")]]

#text("This is getting close to what we want, except that we have far too many pairs ")#mi("{P^{\\prime}_j, Q^{\\prime}_j}")#text("; the quantity ")#mi("{n}")#text(" could be potentially as large as ")#mi("{\\sqrt{N}}")#text(", whereas we would like a logarithmic number instead. However, we can resolve this problem simply by dyadic pigeonholing on the quotient appearing in ")#link(<tao-5154ed9edd766c720bf7>)[#text("(3)")]#text(". Namely, for every integer ")#mi("{-10 \\log N \\leq i \\leq 10 \\log N}")#text(" (say), let ")#mi("{J_i}")#text(" be the set of indices ")#mi("{j \\in \\{1,\\ldots,n\\}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("2^i \\leq \\frac{\\left|S_j\\right|}{d^{\\prime}_j} < 2^{i+1},", block: true)]]

#text("then the ")#mi("{J_i}")#text(" partition ")#mi("{\\{1,\\ldots,n\\}}")#text(". For each ")#mi("{i}")#text(", we then set")

#align(center)[#tao-fit-display[#mitex("P_i := \\prod_{j \\in J_i} P^{\\prime}_j")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("Q_i := \\sum_{j \\in J_i} Q^{\\prime}_j \\prod_{j^{\\prime} \\in J_i: j^{\\prime} \\neq j} P^{\\prime}_{j^{\\prime}}.")]]

#text("Observe that ")#mi("{P_i, Q_i}")#text(" are coprime polynomials with")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{j \\in J_i} S_j \\subset \\{ (x,y) \\in k^2: P_i(x,y) = Q_i(x,y) = 0 \\}")]]

#text("thus giving ")#link(<tao-e642b12901a6ee51456f>)[#text("(1)")]#text(" (after some relabeling). Also, for each ")#mi("{i}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\text{deg}(P_i) = \\sum_{j \\in J_i} d^{\\prime}_j")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\text{deg}(Q_i)  & \\ll \\sup_{j \\in J_i} ( \\frac{\\left|S_j\\right|}{d^{\\prime}_j} + d^{\\prime}_j + \\sum_{j^{\\prime} \\in J_i: j^{\\prime} \\neq j} d^{\\prime}_j)", block: true)



#tao-math(" & \\ll 2^i + \\sum_{j \\in J_i} d^{\\prime}_j", block: true)
]

#text("and thus")

#tao-aligned(keep: true)[


#tao-math("\\text{deg}(P_i) \\text{deg}(Q_i)  & \\ll \\sum_{j \\in J_i} 2^i d^{\\prime}_j + (\\sum_{j \\in J_i} d^{\\prime}_j)^2", block: true)



#tao-math(" & \\ll \\sum_{j \\in J_i} \\left|S_j\\right| + (\\sum_{j \\in J_i} d^{\\prime}_j)^2.", block: true)
]

#text("Summing in ")#mi("{i}")#text(", we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\sum_i \\text{deg}(P_i) \\text{deg}(Q_i)  & \\ll \\sum_{j=1}^n \\left|S_j\\right| + \\sum_i (\\sum_{j \\in J_i} d^{\\prime}_j)^2", block: true)



#tao-math(" & \\ll \\left|S\\right| + (\\sum_i \\sum_{j \\in J_i} d^{\\prime}_j)^2", block: true)



#tao-math(" & = n + (\\sum_{j=1}^n d^{\\prime}_j)^2", block: true)



#tao-math(" & \\ll n + O(\\sqrt{n})^2", block: true)



#tao-math(" & \\ll n", block: true)
]

#text("and ")#link(<tao-3bad94119a1d92eb9c47>)[#text("(2)")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument implicitly relied on some estimates on the ")#link("http://en.wikipedia.org/wiki/Hilbert_series_and_Hilbert_polynomial")[#text("Hilbert polynomial")]#text(" of the ring ")#mi("{k[x,y]/(P^{\\prime}_j)}")#text(". These Hilbert polynomials become more complicated in higher dimensions (especially given that the intersection of multiple hypersurfaces need not be a ")#link("http://en.wikipedia.org/wiki/Complete_intersection")[#text("complete intersection")]#text(" in higher dimensions), and so I do not see immediately how to extend the above result to higher dimensions.")
]

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/#comment-175427")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("What did you mean by “dense” subset?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/#comment-175429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("Dense in the combinatorial sense (the density is bounded away from zero), rather than the algebraic (Zariski) sense. I’ll edit the post to clarify this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/#comment-176710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2012")])]

#text("prof,")#linebreak()#text(" can u make a post of applied maths and numerical analysis? or link me up with any blog that involve those two field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08807294bb381db18e6bc11ef17dfcaf350e6d4760d806a3c544b64afd5d14d8-d3fabdb4e1467012facd100442a258cb9be6f1b7bf18d0cc8f2fe6506df88b98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jackson")]], [#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/#comment-176713")[#strong[#text("Jackson")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2012")])]

#text("how can the society benefit from this?!")#linebreak()#text(" what are the place of pure mathematicians in the society?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/#comment-176828")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2012")])]

#text("In (1) of theorem 2 there is a typo – it it should be Pi(x,y)=Qi(x,y)=0.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a775b7d3b56766195e97035f4fba4d88ea2e4b48f093aa7040c5c8a3b71e8107-6c213679c8b829462255726a1e4b8888ca42a52d7f63b451d4d2d114924a397c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gaurav patil")]], [#link("https://terrytao.wordpress.com/2012/09/25/a-partial-converse-to-bezouts-theorem/#comment-607178")[#strong[#text("gaurav patil")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Is there a way to characterizing the set S for which it can be seen as an intersection of two curves. For example would such a condition on S be seen as a series of allergic equations on its co-ordinates?")
]
