// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/
// Converted to Typst by tao2typ: "2026-10-14T09:28:53.805539+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The spectral proof of the Szemeredi regularity lemma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The spectral proof of the Szemeredi regularity lemma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 December 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/")[#text("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Perhaps the most important structural result about general large dense graphs is ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("the Szemerédi regularity lemma")]#text(". Here is a standard formulation of that lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Szemerédi regularity lemma)")]#text(" ")#metadata(none) <tao-748d8735530048af931c>#text(" Let ")#mi("{G = (V,E)}")#text(" be a graph on ")#mi("{n}")#text(" vertices, and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_M}")#text(" for some ")#mi("{M \\leq M(\\epsilon)}")#text(" with the property that for all but at most ")#mi("{\\epsilon M^2}")#text(" of the pairs ")#mi("{1 \\leq i \\leq j \\leq M}")#text(", the pair ")#mi("{V_i, V_j}")#text(" is ")#emph[#mi("{\\epsilon}")#text("-regular")]#text(" in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left| d( A, B ) - d( V_i, V_j ) \\right| \\leq \\epsilon", block: true)]]

#text("whenever ")#mi("{A \\subset V_i, B \\subset V_j}")#text(" are such that ")#tao-math("{\\left|A\\right| \\geq \\epsilon \\left|V_i\\right|}", block: false)#text(" and ")#tao-math("{\\left|B\\right| \\geq \\epsilon \\left|V_j\\right|}", block: false)#text(", and ")#tao-math("{d(A,B) := \\left|\\{ (a,b) \\in A \\times B: \\{a,b\\} \\in E \\}\\right|/\\left|A\\right| \\left|B\\right|}", block: false)#text(" is the edge density between ")#mi("{A}")#text(" and ")#mi("{B}")#text(". Furthermore, the partition is ")#emph[#text("equitable")]#text(" in the sense that ")#tao-math("{\\left|\\left|V_i\\right| - \\left|V_j\\right|\\right| \\leq 1}", block: false)#text(" for all ")#mi("{1 \\leq i \\leq j \\leq M}")#text(".")
]

#text("There are many proofs of this lemma, which is actually not that difficult to establish; see for instance ")#link("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/")[#text("previous")]#text(" blog posts for some examples. In this post I would like to record one further proof, based on the spectral decomposition of the adjacency matrix of ")#mi("{G}")#text(", which is essentially due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1723039")[#text("Frieze")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1450598")[#text("and Kannan")]#text(". (Strictly speaking, Frieze and Kannan used a variant of this argument to establish a weaker form of the regularity lemma, but it is not difficult to modify the Frieze-Kannan argument to obtain the usual form of the regularity lemma instead. Some closely related spectral regularity lemmas were also developed ")#link("http://arxiv.org/abs/1003.5588")[#text("by Szegedy")]#text(".) I found recently (while speaking at the ")#link("http://www.ima.umn.edu/2012-2013/SW11.29-12.1.12/")[#text("Abel conference in honour of this year’s laureate, Endre Szemerédi")]#text(") that this particular argument is not as widely known among graph theory experts as I had thought, so I thought I would record it here.")

#text("For reasons of exposition, it is convenient to first establish a slightly weaker form of the lemma, in which one drops the hypothesis of equitability (but then has to weight the cells ")#mi("{V_i}")#text(" by their magnitude when counting bad pairs):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Szemerédi regularity lemma, weakened variant)")]#text(" ")#metadata(none) <tao-6327baf32430ee1a2792>#text(". Let ")#mi("{G = (V,E)}")#text(" be a graph on ")#mi("{n}")#text(" vertices, and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_M}")#text(" for some ")#mi("{M \\leq M(\\epsilon)}")#text(" with the property that for all pairs ")#mi("{(i,j) \\in \\{1,\\ldots,M\\}^2}")#text(" outside of an exceptional set ")#mi("{\\Sigma}")#text(", one has ")#metadata(none) <tao-42ee150e0f7c475178a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left| E(A,B) - d_{ij} \\right|A\\left| \\left|B\\right| \\right| \\ll \\epsilon \\left|V_i\\right| \\left|V_j\\right|", block: true)]]

#text("whenever ")#mi("{A \\subset V_i, B \\subset V_j}")#text(", for some real number ")#mi("{d_{ij}}")#text(", where ")#tao-math("{E(A,B) := \\left|\\{ (a,b) \\in A \\times B: \\{a,b\\} \\in E \\}\\right|}", block: false)#text(" is the number of edges between ")#mi("{A}")#text(" and ")#mi("{B}")#text(". Furthermore, we have ")#metadata(none) <tao-bd83b55af54bc95fe2de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{(i,j) \\in \\Sigma} \\left|V_i\\right| \\left|V_j\\right| \\ll \\epsilon \\left|V\\right|^2.", block: true)]]
]

#text("Let us now prove Lemma ")#link(<tao-6327baf32430ee1a2792>)[#text("2")]#text(". We enumerate ")#mi("{V}")#text(" (after relabeling) as ")#mi("{V = \\{1,\\ldots,n\\}}")#text(". The ")#link("http://en.wikipedia.org/wiki/Adjacency_matrix")[#text("adjacency matrix")]#text(" ")#mi("{T}")#text(" of the graph ")#mi("{G}")#text(" is then a self-adjoint ")#mi("{n \\times n}")#text(" matrix, and thus admits an eigenvalue decomposition")

#align(center)[#tao-fit-display[#mitex("T = \\sum_{i=1}^n \\lambda_i u_i^* u_i")]]

#text("for some orthonormal basis ")#mi("{u_1,\\ldots,u_n}")#text(" of ")#mi("{{\\bf C}^n}")#text(" and some eigenvalues ")#mi("{\\lambda_1,\\ldots,\\lambda_n \\in {\\bf R}}")#text(", which we arrange in decreasing order of magnitude:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\lambda_1\\right| \\geq \\ldots \\geq \\left|\\lambda_n\\right|.", block: true)]]

#text("We can compute the trace of ")#mi("{T^2}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\text{tr}(T^2) = \\sum_{i=1}^n \\left|\\lambda_i\\right|^2.", block: true)]]

#text("But we also have ")#tao-math("{\\text{tr}(T^2) = 2\\left|E\\right| \\leq n^2}", block: false)#text(", so ")#metadata(none) <tao-e00443c76cfe2be97aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{i=1}^n \\left|\\lambda_i\\right|^2 \\leq n^2.", block: true)]]

#text("Among other things, this implies that ")#metadata(none) <tao-13cc358c604102b8449c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\lambda_i\\right| \\leq \\frac{n}{\\sqrt{i}}", block: true)]]

#text("for all ")#mi("{i \\geq 1}")#text(".")

#text("Let ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" be a function (depending on ")#mi("{\\epsilon}")#text(") to be chosen later, with ")#mi("{F(i) \\geq i}")#text(" for all ")#mi("{i}")#text(". Applying ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(3)")]#text(" and the pigeonhole principle (or the finite convergence principle, see ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this blog post")]#text("), we can find ")#mi("{J \\leq C(F,\\epsilon)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{J \\leq i < F(J)} \\left|\\lambda_i\\right|^2 \\leq \\epsilon^3 n^2.", block: true)]]

#text("(Indeed, the bound on ")#mi("{J}")#text(" is basically ")#mi("{F}")#text(" iterated ")#mi("{1/\\epsilon^3}")#text(" times.) We can now split ")#metadata(none) <tao-91b518a0a82931b4485e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("T = T_1 + T_2 + T_3,")]]

#text("where ")#mi("{T_1}")#text(" is the “structured” component ")#metadata(none) <tao-8c740cc83280c7102d28>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("T_1 := \\sum_{i < J} \\lambda_i u_i^* u_i,")]]

#mi("{T_2}")#text(" is the “small” component ")#metadata(none) <tao-9a719db3b7b27a6498fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("T_2 := \\sum_{J \\leq i < F(J)} \\lambda_i u_i^* u_i,")]]

#text("and ")#mi("{T_3}")#text(" is the “pseudorandom” component ")#metadata(none) <tao-12fcb5b54d66d4da531d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("T_3 := \\sum_{i > F(J)} \\lambda_i u_i^* u_i.")]]

#text("We now design a vertex partition to make ")#mi("{T_1}")#text(" approximately constant on most cells. For each ")#mi("{i < J}")#text(", we partition ")#mi("{V}")#text(" into ")#mi("{O_{J,\\epsilon}(1)}")#text(" cells on which ")#mi("{u_i}")#text(" (viewed as a function from ")#mi("{V}")#text(" to ")#mi("{{\\bf C}}")#text(") only fluctuates by ")#mi("{O(\\epsilon n^{-1/2} /J)}")#text(", plus an exceptional cell of size ")#tao-math("{O( \\frac{\\epsilon}{J} \\left|V\\right|)}", block: false)#text(" coming from the values where ")#tao-math("{\\left|u_i\\right|}", block: false)#text(" is excessively large (larger than ")#mi("{\\sqrt{\\frac{J}{\\epsilon}} n^{-1/2}}")#text("). Combining all these partitions together, we can write ")#mi("{V = V_1 \\cup \\ldots \\cup V_{M-1} \\cup V_M}")#text(" for some ")#mi("{M = O_{J,\\epsilon}(1)}")#text(", where ")#mi("{V_M}")#text(" has cardinality at most ")#tao-math("{\\epsilon \\left|V\\right|}", block: false)#text(", and for all ")#mi("{1 \\leq i \\leq M-1}")#text(", the eigenfunctions ")#mi("{u_1,\\ldots,u_{J-1}}")#text(" all fluctuate by at most ")#mi("{O(\\epsilon/J)}")#text(". In particular, if ")#mi("{1 \\leq i,j \\leq M-1}")#text(", then (by ")#link(<tao-13cc358c604102b8449c>)[#text("(4)")]#text(" and ")#link(<tao-8c740cc83280c7102d28>)[#text("(6)")]#text(") the entries of ")#mi("{T_1}")#text(" fluctuate by at most ")#mi("{O(\\epsilon)}")#text(" on each block ")#mi("{V_i \\times V_j}")#text(". If we let ")#mi("{d_{ij}}")#text(" be the mean value of these entries on ")#mi("{V_i \\times V_j}")#text(", we thus have ")#metadata(none) <tao-7804e79a90b6fc9bd20d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("1_B^* T_1 1_A = d_{ij} \\left|A\\right| \\left|B\\right| + O( \\epsilon \\left|V_i\\right| \\left|V_j\\right| )", block: true)]]

#text("for any ")#mi("{1 \\leq i,j \\leq M-1}")#text(" and ")#mi("{A \\subset V_i, B \\subset V_j}")#text(", where we view the indicator functions ")#mi("{1_A, 1_B}")#text(" as column vectors of dimension ")#mi("{n}")#text(".")

#text("Next, we observe from ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(3)")]#text(" and ")#link(<tao-9a719db3b7b27a6498fc>)[#text("(7)")]#text(" that ")#mi("{\\text{tr} T_2^2 \\leq \\epsilon^3 n^2}")#text(". If we let ")#mi("{x_{ab}}")#text(" be the coefficients of ")#mi("{T_2}")#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a,b \\in V} \\left|x_{ab}\\right|^2 \\leq \\epsilon^3 n^2", block: true)]]

#text("and hence by Markov’s inequality we have ")#metadata(none) <tao-8fbbd06a906c38c09377>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{a \\in V_i} \\sum_{b \\in V_j} \\left|x_{ab}\\right|^2 \\leq \\epsilon^2 \\left|V_i\\right| \\left|V_j\\right|", block: true)]]

#text("for all pairs ")#mi("{(i,j) \\in \\{1,\\ldots,M-1\\}^2}")#text(" outside of an exceptional set ")#mi("{\\Sigma_1}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\sum_{(i,j) \\in \\Sigma_1} \\left|V_i\\right| \\left|V_j\\right| \\leq \\epsilon \\left|V\\right|^2.", block: true)]]

#text("If ")#mi("{(i,j) \\in \\{1,\\ldots,M-1\\}^2}")#text(" avoids ")#mi("{\\Sigma_1}")#text(", we thus have ")#metadata(none) <tao-476201a589e8f585e499>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("1_B^* T_2 1_A = O( \\epsilon \\left|V_i\\right| \\left|V_j\\right| )", block: true)]]

#text("for any ")#mi("{A \\subset V_i, B \\subset V_j}")#text(", by ")#link(<tao-8fbbd06a906c38c09377>)[#text("(10)")]#text(" and the Cauchy-Schwarz inequality.")

#text("Finally, to control ")#mi("{T_3}")#text(" we see from ")#link(<tao-13cc358c604102b8449c>)[#text("(4)")]#text(" and ")#link(<tao-12fcb5b54d66d4da531d>)[#text("(8)")]#text(" that ")#mi("{T_3}")#text(" has an operator norm of at most ")#mi("{n/\\sqrt{F(J)}}")#text(". In particular, we have from the Cauchy-Schwarz inequality that ")#metadata(none) <tao-ed20beb667c3c78d1a93>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("1_B^* T_3 1_A = O( n^2 / \\sqrt{F(J)} )")]]

#text("for any ")#mi("{A, B \\subset V}")#text(".")

#text("Let ")#mi("{\\Sigma}")#text(" be the set of all pairs ")#mi("{(i,j) \\in \\{1,\\ldots,M\\}^2}")#text(" where either ")#mi("{(i,j) \\in \\Sigma_1}")#text(", ")#mi("{i = M}")#text(", ")#mi("{j=M}")#text(", or")

#align(center)[#tao-fit-display[#tao-math("\\min(\\left|V_i\\right|, \\left|V_j\\right|) \\leq \\frac{\\epsilon}{M} n.", block: true)]]

#text("One easily verifies that ")#link(<tao-bd83b55af54bc95fe2de>)[#text("(2)")]#text(" holds. If ")#mi("{(i,j) \\in \\{1,\\ldots,M\\}^2}")#text(" is not in ")#mi("{\\Sigma}")#text(", then by summing ")#link(<tao-7804e79a90b6fc9bd20d>)[#text("(9)")]#text(", ")#link(<tao-476201a589e8f585e499>)[#text("(11)")]#text(", ")#link(<tao-ed20beb667c3c78d1a93>)[#text("(12)")]#text(" and using ")#link(<tao-91b518a0a82931b4485e>)[#text("(5)")]#text(", we see that ")#metadata(none) <tao-ca00fccfb408989eddc4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("1_B^* T 1_A = d_{ij} \\left|A\\right| \\left|B\\right| + O( \\epsilon \\left|V_i\\right| \\left|V_j\\right| ) + O( n^2 / \\sqrt{F(J)} )", block: true)]]

#text("for all ")#mi("{A \\subset V_i, B \\subset V_j}")#text(". The left-hand side is just ")#mi("{E(A,B)}")#text(". As ")#mi("{(i,j) \\not \\in \\Sigma}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|V_i\\right|, \\left|V_j\\right| > \\frac{\\epsilon}{M} n", block: true)]]

#text("and so (since ")#mi("{M = O_{J,\\epsilon}(1)}")#text(")")

#align(center)[#tao-fit-display[#tao-math("n^2 / \\sqrt{F(J)} \\ll_{J,\\epsilon} \\left|V_i\\right| \\left|V_j\\right| / \\sqrt{F(J)}.", block: true)]]

#text("If we let ")#mi("{F}")#text(" be a sufficiently rapidly growing function of ")#mi("{J}")#text(" that depends on ")#mi("{\\epsilon}")#text(", the second error term in ")#link(<tao-ca00fccfb408989eddc4>)[#text("(13)")]#text(" can be absorbed in the first, and ")#link(<tao-42ee150e0f7c475178a7>)[#text("(1)")]#text(" follows. This concludes the proof of Lemma ")#link(<tao-6327baf32430ee1a2792>)[#text("2")]#text(".")

#text("To prove Lemma ")#link(<tao-748d8735530048af931c>)[#text("1")]#text(", one argues similarly (after modifying ")#mi("{\\epsilon}")#text(" as necessary), except that the initial partition ")#mi("{V_1,\\ldots,V_M}")#text(" of ")#mi("{V}")#text(" constructed above needs to be subdivided further into equitable components (of size ")#tao-math("{\\epsilon \\left|V\\right|/M+O(1)}", block: false)#text("), plus some remainder sets which can be aggregated into an exceptional component of size ")#tao-math("{O( \\epsilon \\left|V\\right| )}", block: false)#text(" (and which can then be redistributed amongst the other components to arrive at a truly equitable partition). We omit the details.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" It is easy to verify that ")#mi("{F}")#text(" needs to be growing exponentially in ")#mi("{J}")#text(" in order for the above argument to work, which leads to tower-exponential bounds in the number of cells ")#mi("{M}")#text(" in the partition. It was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=1445389")[#text("by Gowers")]#text(" that a tower-exponential bound is actually necessary here. By varying ")#mi("{F}")#text(", one basically obtains the ")#emph[#text("strong regularity lemma")]#text(" first established ")#link("http://www.ams.org/mathscinet-getitem?mr=1804820")[#text("by Alon, Fischer, Krivelevich, and Szegedy")]#text("; in the opposite direction, setting ")#mi("{F(J) := J}")#text(" essentially gives the ")#emph[#text("weak regularity lemma")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1450598")[#text("of Frieze and Kannan")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" If we specialise to a Cayley graph, in which ")#mi("{V = (V,+)}")#text(" is a finite abelian group and ")#mi("{E = \\{ (a,b): a-b \\in A \\}}")#text(" for some (symmetric) subset ")#mi("{A}")#text(" of ")#mi("{V}")#text(", then the eigenvectors are characters, and one essentially recovers the ")#emph[#text("arithmetic regularity lemma")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("of Green")]#text(", in which the vertex partition classes ")#mi("{V_i}")#text(" are given by Bohr sets (and one can then place additional regularity properties on these Bohr sets with some additional arguments). The components ")#mi("{T_1, T_2, T_3}")#text(" of ")#mi("{T}")#text(", representing high, medium, and low eigenvalues of ")#mi("{T}")#text(", then become a decomposition associated to high, medium, and low Fourier coefficients of ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The use of spectral theory here is parallel to the use of Fourier analysis to establish results such as ")#link("http://en.wikipedia.org/wiki/Roth%27s_theorem")[#text("Roth’s theorem on arithmetic progressions of length three")]#text(". In analogy with this, one could view hypergraph regularity as being a sort of “higher order spectral theory”, although this spectral perspective is not as convenient as it is in the graph case.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca640c7f60206dfdc2e877f639343f2704f64dfe284fd6ab57277171df2e223e-e09bfd82b885450a84386bc766a113e6e8f028f94ba8370cc22353e894244428.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shubhendu Trivedi")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199175")[#strong[#text("Shubhendu Trivedi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2012")])]

#text("I have general question about Remark 3 (but concerning Szemeredi Regular Partitions). I apologize if it is too elementary.")

#text("A simple algorithm to generate a regular partition by Frieze-Kannan is over here ")#link("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.44.721")[#text("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.44.721")]#text(" (they mention the paper that you cite over here as well). Note that here they only consider the first singular value to check for regularity at each stage.")

#text("My question is: Why wouldn’t this work for a Hypergraph Case? I understand that there is no analog for “SVD” for tensors. That is, the best ")#mi("r")#text(" rank approximation for ")#mi("k")#text(" order tensor ")#mi("A")#text(", ")#mi("Approx(A,r)")#text(" has no solutions in general. The notable exceptions are two specific cases (for rank one tensors i.e. ")#mi("r = 1")#text(" and when ")#mi("A")#text(" is a matrix i.e. ")#mi("k =2")#text(". Since in the Graph case the first singular value is all that we need, shouldn’t this work for the hypergraph case as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199518")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("There is a subtlety in the hypergraph case which has to do with the fact that there are several different types of hypergraph regularity one could ask for. In particular there is an “order 1” hypergraph regularity which does indeed fit well with rank one approximation, but in many applications one actually needs a higher order notion of hypergraph regularity which does not interact well with bounded rank approximations.")

#text("To explain this, begin with the graph case. An edge set E can be viewed as an indicator function ")#mi("1_E(v,w)")#text(" of two vertex-valued variables ")#mi("v, w")#text(". Graph regularity has to do with understanding sums such as")

#mi("\\sum_{v \\in V} \\sum_{w \\in V} 1_E(v,w) 1_A(v) 1_B(w)")

#text("and this can be done by using the SVD to split ")#mi("1_E(v,w)")#text(" into finite rank components such as ")#mi("f(v) g(w)")#text(".")

#text("Now consider a 3-uniform hypergraph, which now comes with an indicator function ")#mi("1_E(u,v,w)")#text(". If one were interested in counting “order 1” sums such as")

#mi("\\sum_{u,v,w \\in V} 1_E(u,v,w) 1_A(u) 1_B(v) 1_C(w)")

#text("then a bounded rank approximation to ")#mi("1_E")#text(" would be effective; this would correspond, roughly speaking, to the hypergraph regularity lemma ")#link("http://www.ams.org/mathscinet-getitem?mr=1099803")[#text("of Chung")]#text(". But in practice, this type of regularity is insufficient; one often needs to count expressions such as")

#mi("\\sum_{u,v,w \\in V} 1_E(u,v,w) 1_F(u,v) 1_G(v,w) 1_H(w,u)")#text(" (*)")

#text("for some graphs F,G,H, and bounded rank approximations can be quite terrible for this purpose. (See for instance the discussion in ")#link("http://www.ams.org/mathscinet-getitem?mr=2195580")[#text("this paper of Gowers")]#text(".) In particular, there are 3-uniform hypergraphs with no bounded rank approxmiations which have nontrivial behaviour with respect to sums such as (*). Instead one has to consider “order 2” bounded rank approximations to ")#mi("1_E(u,v,w)")#text(", using linear combinations of functions of the form ")#mi("f(u,v) g(v,w) h(u,w)")#text(" rather than ")#mi("f(u) g(v) h(w)")#text(". (These two-variable functions ")#mi("f(u,v), g(v,w), h(u,w)")#text(" in turn then need to be approximated by “order 1” bounded rank functions.) This can still be done, but one is now quite far from the classical theory of rank.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca640c7f60206dfdc2e877f639343f2704f64dfe284fd6ab57277171df2e223e-e09bfd82b885450a84386bc766a113e6e8f028f94ba8370cc22353e894244428.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shubhendu Trivedi")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199977")[#strong[#text("Shubhendu Trivedi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Couldn’t thank you enough for your answer!")

#text("So if I understood correct, there should still be a way to obtain Chung’s version in a simple algorithmic way as in the graph case suggested by Frieze and Kannan.")

#text("More precisely, there should be an analog of Lemma 2 in ")#link("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.44.721")[#text("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.44.721")]#text(" for the higher order case.")

#text("That is, something along these lines must hold:")

#text("/// Let ")#mi("W")#text(" be a ")#mi("k")#text(" dimensional Tensor ")#mi("V_1 \\times V_2 \\times \\dots V_i")#text(", with ")#tao-math("\\left|V_i\\right| = p_i", block: false)#text(" and ")#mi("W(i,j, \\dots, k) \\leq 1")#text(". If ")#mi("\\gamma")#text(" is a small positive real number then,")

#text("(a) if there exists ")#mi("A_i \\subseteq V_i")#text(" such that ")#tao-math("\\left|A_i\\right| \\geq \\gamma p_i", block: false)#text(" and ")#tao-math("\\left|W(A_1, A_2, \\dots, A_k)\\right| \\geq \\gamma \\left|A_1\\right|\\left|A_2\\right| \\dots \\left|A_k\\right|", block: false)#text(" then ")#mi("\\sigma(W) \\geq \\gamma^{k+1} \\sqrt{p_1 p_2 \\dots p_k}")

#text("(b) if ")#mi("\\sigma(W) \\geq \\gamma\\sqrt{p_1 p_2 \\dots p_k}")#text(" then there exists ")#mi("A_i \\subseteq V_i")#text(" such that ")#tao-math("\\left|A_i\\right| \\geq \\gamma^{\\prime} p_i", block: false)#text(" and ")#tao-math("\\left|W(A_1, A_2, \\dots A_k)\\right| \\geq \\gamma^{\\prime}\\left|A_1\\right|\\left|A_2\\right| \\dots A_k", block: false)#text(" where ")#mi("\\gamma^{\\prime} = c \\gamma^{k+1}")#text(", ")#mi("c")#text(" is a constant. Such ")#mi("A_1, A_2, \\dots A_k")#text(" might be constructed in polynomial time. ///")

#text("Is this a correct way of thinking about it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199987")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Well, I don’t know how exactly you will be defining the greatest singular value of a tensor, but something along these lines should be possible. Note that one can also essentially prove Chung’s regularity lemma by viewing a hypergraph ")#mi("E \\subset V_1 \\times V_2 \\times V_3")#text(" (say) first as a graph between ")#mi("V_1")#text(" and ")#mi("V_2 \\times V_3")#text(", applying the usual regularity lemma to this, and then applying the regularity lemma one further time to the components of ")#mi("V_2 \\times V_3")#text(" obtained from the first application of that lemma. (Actually, to make all this work properly, it is more convenient to work with a strong version of the regularity lemma that has an additional function parameter F.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca640c7f60206dfdc2e877f639343f2704f64dfe284fd6ab57277171df2e223e-e09bfd82b885450a84386bc766a113e6e8f028f94ba8370cc22353e894244428.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shubhendu Trivedi")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199988")[#strong[#text("Shubhendu Trivedi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Thanks a lot again for your reply!")

#text("PS: Minor comment. One tag is misspelled as “eigenvales”.")

#emph[#text("[Corrected, thanks -T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199177")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2012")])]

#text("A couple of orphaned/mismatched html tags:")

#text("In the paragraph after Lemma 1:")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e950aebe2c38e335523c77d9e75578535fbff4ec87f9d1c7a7bea06dd84caa73-45b670a18b3369e69605ecf6e6cf7365047c86dfa1e6f0ff4b8279713d80671f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-199242")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("Hi Terry,")

#text("I am not a mathematician or anything. Just a college undergrad studying their gen eds…")

#text("But reading a quote from Paul Graham, from the link on the left of your blog, which was an amazing read by the way,")

#text("“To a newly arrived undergraduate, all university departments look much the same. The professors all seem forbiddingly intellectual and publish papers unintelligible to outsiders. But while in some fields the papers are unintelligible because they’re full of hard ideas, in others they’re deliberately written in an obscure way to seem as if they’re saying something important. This may seem a scandalous proposition, but it has been experimentally verified, in the famous Social Text affair. Suspecting that the papers published by literary theorists were often just intellectual-sounding nonsense, a physicist deliberately wrote a paper full of intellectual-sounding nonsense, and submitted it to a literary theory journal, which published it.”")

#text("I hope you are not writing anything in an obscure way to seem as if what you are writing is important :(")

#text("Sincerely,")

#text("Craig")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd83ab57967ccfe2fec3a7390f8ee470a99d34703c8a83778c9a2dff057d0298-fd0b212ab9166c7049cdb64effce4a7b0cb415ba88a6226266fd2fd598d74fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davetweed")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-206483")[#strong[#text("davetweed")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2012")])]

#text("Note that the quote’s logic isn’t quite right. Submitting a paper full of nonsense (which has been done in other disciplines, eg, theoretical physics) isn’t capable of experimentally verifying that a substantial number of the papers in a discipline are nonsense, only that papers in the discipline can’t be reliably distinguished from nonsense. (The proposition may well still be true, but that’s not established by this test.)")

#text("Even with my cynics hat on, I’m more inclined towards the weaker interpretation: referees have no ")#emph[#text("strong")]#text(" incentive to actually understand a paper rather than just see if anything it says looks “obviously wrong”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-202877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2012")])]

#text("In (1), Lemma 2, should $d_{i,j} |V_i| |V_j|$ be $d_{i,j} |A| |B|$ ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-211210")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("Dear Terry,")

#text("For the sake of clompleteness let me mention that I wrote a paper about the spectral proof of the stronng regularity lemma which clarifies the same issues that you discuss (see below). It may also contain some new interesting aspect. (For example connection to graph limits and group theory)")

#text("Limits of kernel operators and the spectral regularity lemma")

#link("http://arxiv.org/abs/1003.5588")[#text("http://arxiv.org/abs/1003.5588")]

#text("European J. of Comb, Volume 32, Issue 7, October 2011, p. 1156-1167")

#emph[#text("[Thanks, I’e added a link to this in the main post. Good to see that we now have spectral proofs of the weak, strong, and standard regularity lemmas in the literature – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2f7f25e680d72cce24f6d17100f87cfb65a2d1ac015c935135beb17fa5d1537-b22460d36bf8686133ea9974de8d4acd94ef07f21f8fc2697737d61ecf60729b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-213357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2013")])]

#text("Don’t want to sound uncaring for your precious time at all. If at all it comes across like that, I apologize for it. But I was wondering if it would ever be possible to have an expository post for the paper Balazs just posted?")#linebreak()#text(" I have spent a couple of months trying to understand it but it seems impregnable but at the same time very important and deep.")

#text("Regards.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A spectral theory proof of the algebraic regularity lemma | What's new")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-249425")[#strong[#text("A spectral theory proof of the algebraic regularity lemma | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("[…] group. It turns out that the spectral proof of the Szemerédi regularity lemma (discussed in this previous blog post) adapts very nicely to this setting. The key fact needed about definable sets over finite fields is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-280916")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2014")])]

#text("two lines below inequality (10): ")#mi("\\Sigma")#text(" should be ")#mi("\\Sigma_1")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A proof of Roth’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-312039")[#strong[#text("A proof of Roth’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2014")])]

#text("[…] and “highly pseudorandom” components, as is common in the subject (e.g. in this previous blog post), but even though we crucially need to retain non-negativity of one of the components in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-461867")[#strong[#text("The spectral proof of the Szemeredi regularity lemma | Systems, Networks and Control")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")]

#text("[…] Source: The spectral proof of the Szemeredi regularity lemma […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/#comment-693879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2026")])]

#text("The use of spectral theory here is parallel to the use of Fourier analysis to establish results such as Roth’s theorem on arithmetic progressions of length three. In analogy with this, one could view hypergraph regularity as being a sort of “higher order spectral theory”, although this spectral perspective is not as convenient as it is in the graph case.")

#text("apart from the word spectral and fourier and their relation I don’t see how. Is their an eigenvalue proof of Roth? There is new results on 3ap. Is there new proof of regularity lemma and szemerdi regularity lemma bases on it?")
]
