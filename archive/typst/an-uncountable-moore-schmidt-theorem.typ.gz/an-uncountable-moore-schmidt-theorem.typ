// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:38:38.719080+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An uncountable Moore-Schmidt theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An uncountable Moore-Schmidt theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 November 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/")[#text("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://asgarjam.wixsite.com/home")[#text("Asgar Jamneshan")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1911.12033")[#text("An uncountable Moore-Schmidt theorem")]#text("“. This paper revisits a classical theorem of Moore and Schmidt in measurable cohomology of measure-preserving systems. To state the theorem, let ")#mi("{X = (X,{\\mathcal X},\\mu)}")#text(" be a probability space, and ")#mi("{\\mathrm{Aut}(X, {\\mathcal X}, \\mu)}")#text(" be the group of measure-preserving automorphisms of this space, that is to say the invertible bimeasurable maps ")#mi("{T: X \\rightarrow X}")#text(" that preserve the measure ")#mi("{\\mu}")#text(": ")#mi("{T_* \\mu = \\mu}")#text(". To avoid some ambiguity later in this post when we introduce abstract analogues of measure theory, we will refer to measurable maps as ")#emph[#text("concrete measurable maps")]#text(", and ")#link("https://en.wikipedia.org/wiki/Measurable_space")[#text("measurable spaces")]#text(" as ")#emph[#text("concrete measurable spaces")]#text(". (One could also call ")#mi("{X = (X,{\\mathcal X}, \\mu)}")#text(" a concrete probability space, but we will not need to do so here as we will not be working explicitly with abstract probability spaces.)")

#text("Let ")#mi("{\\Gamma = (\\Gamma,\\cdot)}")#text(" be a discrete group. A ")#emph[#text("(concrete) measure-preserving action")]#text(" of ")#mi("{\\Gamma}")#text(" on ")#mi("{X}")#text(" is a group homomorphism ")#mi("{\\gamma \\mapsto T^\\gamma}")#text(" from ")#mi("{\\Gamma}")#text(" to ")#mi("{\\mathrm{Aut}(X, {\\mathcal X}, \\mu)}")#text(", thus ")#mi("{T^1}")#text(" is the identity map and ")#mi("{T^{\\gamma_1} \\circ T^{\\gamma_2} = T^{\\gamma_1 \\gamma_2}}")#text(" for all ")#mi("{\\gamma_1,\\gamma_2 \\in \\Gamma}")#text(". A large portion of ergodic theory is concerned with the study of such measure-preserving actions, especially in the classical case when ")#mi("{\\Gamma}")#text(" is the integers (with the additive group law).")

#text("Let ")#mi("{K = (K,+)}")#text(" be a compact Hausdorff abelian group, which we can endow with the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}(K)}")#text(". A ")#emph[#text("(concrete measurable) ")#mi("{K}")#text("–")#link("https://en.wikipedia.org/wiki/Cocycle")[#text("cocycle")]]#text(" is a collection ")#mi("{\\rho = (\\rho_\\gamma)_{\\gamma \\in \\Gamma}}")#text(" of concrete measurable maps ")#mi("{\\rho_\\gamma: X \\rightarrow K}")#text(" obeying the ")#emph[#text("cocycle equation")]#text(" ")#metadata(none) <tao-94179e8c8137f343b1f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho_{\\gamma_1 \\gamma_2}(x) = \\rho_{\\gamma_1} \\circ T^{\\gamma_2}(x) + \\rho_{\\gamma_2}(x)")]]

#text("for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(". (Here we are glossing over a measure-theoretic subtlety that we will return to later in this post – see if you can spot it before then!) Cocycles arise naturally in the theory of group extensions of dynamical systems; in particular (and ignoring the aforementioned subtlety), each cocycle induces a measure-preserving action ")#mi("{\\gamma \\mapsto S^\\gamma}")#text(" on ")#mi("{X \\times K}")#text(" (which we endow with the product of ")#mi("{\\mu}")#text(" with Haar probability measure on ")#mi("{K}")#text("), defined by")

#align(center)[#tao-fit-display[#mitex("S^\\gamma( x, k ) := (T^\\gamma x, k + \\rho_\\gamma(x) ).")]]

#text("This connection with group extensions was the original motivation for our study of measurable cohomology, but is not the focus of the current paper.")

#text("A special case of a ")#mi("{K}")#text("-valued cocycle is a ")#emph[#text("(concrete measurable) ")#mi("{K}")#text("-valued coboundary")]#text(", in which ")#mi("{\\rho_\\gamma}")#text(" for each ")#mi("{\\gamma \\in \\Gamma}")#text(" takes the special form")

#align(center)[#tao-fit-display[#mitex("\\rho_\\gamma(x) = F \\circ T^\\gamma(x) - F(x)")]]

#text("for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(", where ")#mi("{F: X \\rightarrow K}")#text(" is some measurable function; note that (ignoring the aforementioned subtlety), every function of this form is automatically a concrete measurable ")#mi("{K}")#text("-valued cocycle. One of the first basic questions in measurable cohomology is to try to characterize which ")#mi("{K}")#text("-valued cocycles are in fact ")#mi("{K}")#text("-valued coboundaries. This is a difficult question in general. However, there is a general ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=572015")[#text("result of Moore and Schmidt")]#text(" that at least allows one to reduce to the model case when ")#mi("{K}")#text(" is the unit circle ")#mi("{\\mathbf{T} = {\\bf R}/{\\bf Z}}")#text(", by taking advantage of the Pontryagin dual group ")#mi("{\\hat K}")#text(" of characters ")#mi("{\\hat k: K \\rightarrow \\mathbf{T}}")#text(", that is to say the collection of continuous homomorphisms ")#mi("{\\hat k: k \\mapsto \\langle \\hat k, k \\rangle}")#text(" to the unit circle. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Countable Moore-Schmidt theorem)")]#text(" ")#metadata(none) <tao-55b36ded268414bb2b03>#text(" Let ")#mi("{\\Gamma}")#text(" be a discrete group acting in a concrete measure-preserving fashion on a probability space ")#mi("{X}")#text(". Let ")#mi("{K}")#text(" be a compact Hausdorff abelian group. Assume the following additional hypotheses:")

#list(
[#text("(i) ")#mi("{\\Gamma}")#text(" is at most countable.")],
[#text("(ii) ")#mi("{X}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Standard_Borel_space")[#text("standard Borel space")]#text(".")],
[#text("(iii) ")#mi("{K}")#text(" is metrisable.")]
)

#text("Then a ")#mi("{K}")#text("-valued concrete measurable cocycle ")#mi("{\\rho = (\\rho_\\gamma)_{\\gamma \\in \\Gamma}}")#text(" is a concrete coboundary if and only if for each character ")#mi("{\\hat k \\in \\hat K}")#text(", the ")#mi("{\\mathbf{T}}")#text("-valued cocycles ")#mi("{\\langle \\hat k, \\rho \\rangle = ( \\langle \\hat k, \\rho_\\gamma \\rangle )_{\\gamma \\in \\Gamma}}")#text(" are concrete coboundaries.")
]

#text("The hypotheses (i), (ii), (iii) are saying in some sense that the data ")#mi("{\\Gamma, X, K}")#text(" are not too “large”; in all three cases they are saying in some sense that the data are only “countably complicated”. For instance, (iii) is equivalent to ")#mi("{K}")#text(" being ")#link("https://en.wikipedia.org/wiki/Second-countable_space")[#text("second countable")]#text(", and (ii) is equivalent to ")#mi("{X}")#text(" being modeled by a complete separable metric space. It is because of this restriction that we refer to this result as a “countable” Moore-Schmidt theorem. This theorem is a useful tool in several other applications, such as the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra structure theorem")]#text(" for ergodic systems; I hope to return to these subsequent applications in a future post.")

#text("Let us very briefly sketch the main ideas of the proof of Theorem ")#link(<tao-55b36ded268414bb2b03>)[#text("1")]#text(". Ignore for now issues of measurability, and pretend that something that holds almost everywhere in fact holds everywhere. The hard direction is to show that if each ")#mi("{\\langle \\hat k, \\rho \\rangle}")#text(" is a coboundary, then so is ")#mi("{\\rho}")#text(". By hypothesis, we then have an equation of the form ")#metadata(none) <tao-739b9d664d77db3ee3ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\langle \\hat k, \\rho_\\gamma(x) \\rangle = \\alpha_{\\hat k} \\circ T^\\gamma(x) - \\alpha_{\\hat k}(x)")]]

#text("for all ")#mi("{\\hat k, \\gamma, x}")#text(" and some functions ")#mi("{\\alpha_{\\hat k}: X \\rightarrow {\\mathbf T}}")#text(", and our task is then to produce a function ")#mi("{F: X \\rightarrow K}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\rho_\\gamma(x) = F \\circ T^\\gamma(x) - F(x)")]]

#text("for all ")#mi("{\\gamma,x}")#text(".")

#text("Comparing the two equations, the task would be easy if we could find an ")#mi("{F: X \\rightarrow K}")#text(" for which ")#metadata(none) <tao-f3514f7d40a5aa298ea6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\langle \\hat k, F(x) \\rangle = \\alpha_{\\hat k}(x)")]]

#text("for all ")#mi("{\\hat k, x}")#text(". However there is an obstruction to this: the left-hand side of ")#link(<tao-f3514f7d40a5aa298ea6>)[#text("(3)")]#text(" is additive in ")#mi("{\\hat k}")#text(", so the right-hand side would have to be also in order to obtain such a representation. In other words, for this strategy to work, one would have to first establish the identity ")#metadata(none) <tao-ad370ed99b189921e7fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\alpha_{\\hat k_1 + \\hat k_2}(x) - \\alpha_{\\hat k_1}(x) - \\alpha_{\\hat k_2}(x) = 0")]]

#text("for all ")#mi("{\\hat k_1, \\hat k_2, x}")#text(". On the other hand, the good news is that if we somehow manage to obtain the equation, then we can obtain a function ")#mi("{F}")#text(" obeying ")#link(<tao-f3514f7d40a5aa298ea6>)[#text("(3)")]#text(", thanks to ")#link("https://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin duality")]#text(", which gives a one-to-one correspondence between ")#mi("{K}")#text(" and the homomorphisms of the (discrete) group ")#mi("{\\hat K}")#text(" to ")#mi("{\\mathbf{T}}")#text(".")

#text("Now, it turns out that one cannot derive the equation ")#link(<tao-ad370ed99b189921e7fe>)[#text("(4)")]#text(" directly from the given information ")#link(<tao-739b9d664d77db3ee3ca>)[#text("(2)")]#text(". However, the left-hand side of ")#link(<tao-739b9d664d77db3ee3ca>)[#text("(2)")]#text(" is additive in ")#mi("{\\hat k}")#text(", so the right-hand side must be also. Manipulating this fact, we eventually arrive at")

#align(center)[#tao-fit-display[#mitex("(\\alpha_{\\hat k_1 + \\hat k_2} - \\alpha_{\\hat k_1} - \\alpha_{\\hat k_2}) \\circ T^\\gamma(x) = (\\alpha_{\\hat k_1 + \\hat k_2} - \\alpha_{\\hat k_1} - \\alpha_{\\hat k_2})(x).")]]

#text("In other words, we don’t get to show that the left-hand side of ")#link(<tao-ad370ed99b189921e7fe>)[#text("(4)")]#text(" vanishes, but we do at least get to show that it is ")#mi("{\\Gamma}")#text("-invariant. Now let us assume for sake of argument that the action of ")#mi("{\\Gamma}")#text(" is ergodic, which (ignoring issues about sets of measure zero) basically asserts that the only ")#mi("{\\Gamma}")#text("-invariant functions are constant. So now we get a weaker version of ")#link(<tao-ad370ed99b189921e7fe>)[#text("(4)")]#text(", namely ")#metadata(none) <tao-c66d1c378c60fac51347>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\alpha_{\\hat k_1 + \\hat k_2}(x) - \\alpha_{\\hat k_1}(x) - \\alpha_{\\hat k_2}(x) = c_{\\hat k_1, \\hat k_2}")]]

#text("for some constants ")#mi("{c_{\\hat k_1, \\hat k_2} \\in \\mathbf{T}}")#text(".")

#text("Now we need to eliminate the constants. This can be done by the following group-theoretic projection. Let ")#mi("{L^0({\\bf X} \\rightarrow {\\bf T})}")#text(" denote the space of concrete measurable maps ")#mi("{\\alpha}")#text(" from ")#mi("{{\\bf X}}")#text(" to ")#mi("{{\\bf T}}")#text(", up to almost everywhere equivalence; this is an abelian group where the various terms in ")#link(<tao-c66d1c378c60fac51347>)[#text("(5)")]#text(" naturally live. Inside this group we have the subgroup ")#mi("{{\\bf T}}")#text(" of constant functions (up to almost everywhere equivalence); this is where the right-hand side of ")#link(<tao-c66d1c378c60fac51347>)[#text("(5)")]#text(" lives. Because ")#mi("{{\\bf T}}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Divisible_group")[#text("divisible group")]#text(", there is an application of Zorn’s lemma (a good exercise for those who are not acquainted with these things) to show that there exists a ")#link("https://en.wikipedia.org/wiki/Section_(category_theory)")[#text("retraction")]#text(" ")#mi("{w: L^0({\\bf X} \\rightarrow {\\bf T}) \\rightarrow {\\bf T}}")#text(", that is to say a group homomorphism that is the identity on the subgroup ")#mi("{{\\bf T}}")#text(". We can use this retraction, or more precisely the complement ")#mi("{\\alpha \\mapsto \\alpha - w(\\alpha)}")#text(", to eliminate the constant in ")#link(<tao-c66d1c378c60fac51347>)[#text("(5)")]#text(". Indeed, if we set")

#align(center)[#tao-fit-display[#mitex("\\tilde \\alpha_{\\hat k}(x) := \\alpha_{\\hat k}(x) - w(\\alpha_{\\hat k})")]]

#text("then from ")#link(<tao-c66d1c378c60fac51347>)[#text("(5)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\tilde \\alpha_{\\hat k_1 + \\hat k_2}(x) - \\tilde \\alpha_{\\hat k_1}(x) - \\tilde \\alpha_{\\hat k_2}(x) = 0")]]

#text("while from ")#link(<tao-739b9d664d77db3ee3ca>)[#text("(2)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\langle \\hat k, \\rho_\\gamma(x) \\rangle = \\tilde \\alpha_{\\hat k} \\circ T^\\gamma(x) - \\tilde \\alpha_{\\hat k}(x)")]]

#text("and now the previous strategy works with ")#mi("{\\alpha_{\\hat k}}")#text(" replaced by ")#mi("{\\tilde \\alpha_{\\hat k}}")#text(". This concludes the sketch of proof of Theorem ")#link(<tao-55b36ded268414bb2b03>)[#text("1")]#text(".")

#text("In making the above argument rigorous, the hypotheses (i)-(iii) are used in several places. For instance, to reduce to the ergodic case one relies on the ")#link("https://en.wikipedia.org/wiki/Ergodicity#Ergodic_decomposition")[#text("ergodic decomposition")]#text(", which requires the hypothesis (ii). Also, most of the above equations only hold outside of a set of measure zero, and the hypothesis (i) and the hypothesis (iii) (which is equivalent to ")#mi("{\\hat K}")#text(" being at most countable) to avoid the problem that an uncountable union of sets of measure zero could have positive measure (or fail to be measurable at all).")

#text("My co-author Asgar Jamneshan and I are working on a long-term project to extend many results in ergodic theory (such as the aforementioned Host-Kra structure theorem) to “uncountable” settings in which hypotheses analogous to (i)-(iii) are omitted; thus we wish to consider actions on uncountable groups, on spaces that are not standard Borel, and cocycles taking values in groups that are not metrisable. Such uncountable contexts naturally arise when trying to apply ergodic theory techniques to combinatorial problems (such as the inverse conjecture for the Gowers norms), as one often relies on the ultraproduct construction (or something similar) to generate an ergodic theory translation of these problems, and these constructions usually give “uncountable” objects rather than “countable” ones. (For instance, the ultraproduct of finite groups is a hyperfinite group, which is usually uncountable.). This paper marks the first step in this project by extending the Moore-Schmidt theorem to the uncountable setting.")

#text("If one simply drops the hypotheses (i)-(iii) and tries to prove the Moore-Schmidt theorem, several serious difficulties arise. We have already mentioned the loss of the ergodic decomposition and the possibility that one has to control an uncountable union of null sets. But there is in fact a more basic problem when one deletes (iii): the addition operation ")#mi("{+: K \\times K \\rightarrow K}")#text(", while still continuous, can fail to be measurable as a map from ")#mi("{(K \\times K, {\\mathcal B}(K) \\otimes {\\mathcal B}(K))}")#text(" to ")#mi("{(K, {\\mathcal B}(K))}")#text("! Thus for instance the sum of two measurable functions ")#mi("{F: X \\rightarrow K}")#text(" need not remain measurable, which makes even the very definition of a measurable cocycle or measurable coboundary problematic (or at least unnatural). This phenomenon is known as the ")#emph[#text("Nedoma pathology")]#text(". A standard example arises when ")#mi("{K}")#text(" is the uncountable torus ")#mi("{{\\mathbf T}^{{\\bf R}}}")#text(", endowed with the product topology. Crucially, the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}(K)}")#text(" generated by this uncountable product is ")#emph[#text("not")]#text(" the product ")#mi("{{\\mathcal B}(\\mathbf{T})^{\\otimes {\\bf R}}}")#text(" of the factor Borel ")#mi("{\\sigma}")#text("-algebras (the discrepancy ultimately arises from the fact that topologies permit uncountable unions, but ")#mi("{\\sigma}")#text("-algebras do not); relating to this, the product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}(K) \\otimes {\\mathcal B}(K)}")#text(" is ")#emph[#text("not")]#text(" the same as the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}(K \\times K)}")#text(", but is instead a strict sub-algebra. If the group operations on ")#mi("{K}")#text(" were measurable, then the diagonal set")

#align(center)[#tao-fit-display[#mitex("K^\\Delta := \\{ (k,k^{\\prime}) \\in K \\times K: k = k^{\\prime} \\} = \\{ (k,k^{\\prime}) \\in K \\times K: k - k^{\\prime} = 0 \\}")]]

#text("would be measurable in ")#mi("{{\\mathcal B}(K) \\otimes {\\mathcal B}(K)}")#text(". But it is an easy exercise in manipulation of ")#mi("{\\sigma}")#text("-algebras to show that if ")#mi("{(X, {\\mathcal X}), (Y, {\\mathcal Y})}")#text(" are any two measurable spaces and ")#mi("{E \\subset X \\times Y}")#text(" is measurable in ")#mi("{{\\mathcal X} \\otimes {\\mathcal Y}}")#text(", then the fibres ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\}}")#text(" of ")#mi("{E}")#text(" are contained in some countably generated subalgebra of ")#mi("{{\\mathcal Y}}")#text(". Thus if ")#mi("{K^\\Delta}")#text(" were ")#mi("{{\\mathcal B}(K) \\otimes {\\mathcal B}(K)}")#text("-measurable, then all the points of ")#mi("{K}")#text(" would lie in a single countably generated ")#mi("{\\sigma}")#text("-algebra. But the cardinality of such an algebra is at most ")#mi("{2^{\\alpha_0}}")#text(" while the cardinality of ")#mi("{K}")#text(" is ")#mi("{2^{2^{\\alpha_0}}}")#text(", and ")#link("https://en.wikipedia.org/wiki/Cantor%27s_theorem")[#text("Cantor’s theorem")]#text(" then gives a contradiction.")

#text("To resolve this problem, we give ")#mi("{K}")#text(" a coarser ")#mi("{\\sigma}")#text("-algebra than the Borel ")#mi("{\\sigma}")#text("-algebra, namely the ")#emph[#text("Baire ")#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal B}^\\otimes(K)}")#text(", thus coarsening the measurable space structure on ")#mi("{K = (K,{\\mathcal B}(K))}")#text(" to a new measurable space ")#mi("{K_\\otimes := (K, {\\mathcal B}^\\otimes(K))}")#text(". In the case of compact Hausdorff abelian groups, ")#mi("{{\\mathcal B}^{\\otimes}(K)}")#text(" can be defined as the ")#mi("{\\sigma}")#text("-algebra generated by the characters ")#mi("{\\hat k: K \\rightarrow {\\mathbf T}}")#text("; for more general compact abelian groups, one can define ")#mi("{{\\mathcal B}^{\\otimes}(K)}")#text(" as the ")#mi("{\\sigma}")#text("-algebra generated by all continuous maps into metric spaces. This ")#mi("{\\sigma}")#text("-algebra is equal to ")#mi("{{\\mathcal B}(K)}")#text(" when ")#mi("{K}")#text(" is metrisable but can be smaller for other ")#mi("{K}")#text(". With this measurable structure, ")#mi("{K_\\otimes}")#text(" becomes a measurable group; it seems that once one leaves the metrisable world that ")#mi("{K_\\otimes}")#text(" is a superior (or at least equally good) space to work with than ")#mi("{K}")#text(" for analysis, as it avoids the Nedoma pathology. (For instance, from Plancherel’s theorem, we see that if ")#mi("{m_K}")#text(" is the Haar probability measure on ")#mi("{K}")#text(", then ")#mi("{L^2(K,m_K) = L^2(K_\\otimes,m_K)}")#text(" (thus, every ")#mi("{K}")#text("-measurable set is equivalent modulo ")#mi("{m_K}")#text("-null sets to a ")#mi("{K_\\otimes}")#text("-measurable set), so there is no damage to Plancherel caused by passing to the Baire ")#mi("{\\sigma}")#text("-algebra.")

#text("Passing to the Baire ")#mi("{\\sigma}")#text("-algebra ")#mi("{K_\\otimes}")#text(" fixes the most severe problems with an uncountable Moore-Schmidt theorem, but one is still faced with an issue of having to potentially take an uncountable union of null sets. To avoid this sort of problem, we pass to the framework of ")#emph[#text("abstract measure theory")]#text(", in which we remove explicit mention of “points” and can easily delete all null sets at a very early stage of the formalism. In this setup, the category of concrete measurable spaces is replaced with the larger category of ")#emph[#text("abstract measurable spaces")]#text(", which we formally define as the ")#link("https://en.wikipedia.org/wiki/Opposite_category")[#text("opposite category")]#text(" of the category of ")#mi("{\\sigma}")#text("-algebras (with Boolean algebra homomorphisms). Thus, we define an ")#emph[#text("abstract measurable space")]#text(" to be an object of the form ")#mi("{{\\mathcal X}^{\\mathrm{op}}}")#text(", where ")#mi("{{\\mathcal X}}")#text(" is an (abstract) ")#mi("{\\sigma}")#text("-algebra and ")#mi("{\\mathrm{op}}")#text(" is a formal placeholder symbol that signifies use of the opposite category, and an ")#emph[#text("abstract measurable map")]#text(" ")#mi("{T: {\\mathcal X}^{\\mathrm{op}} \\rightarrow {\\mathcal Y}^{\\mathrm{op}}}")#text(" is an object of the form ")#mi("{(T^*)^{\\mathrm{op}}}")#text(", where ")#mi("{T^*: {\\mathcal Y} \\rightarrow {\\mathcal X}}")#text(" is a Boolean algebra homomorphism and ")#mi("{\\mathrm{op}}")#text(" is again used as a formal placeholder; we call ")#mi("{T^*}")#text(" the ")#emph[#text("pullback map")]#text(" associated to ")#mi("{T}")#text(". [UPDATE: It turns out that this definition of a measurable map led to technical issues. In a forthcoming revision of the paper we also impose the requirement that the abstract measurable map be ")#mi("\\sigma")#text("-complete (i.e., it respects countable joins).] The composition ")#mi("{S \\circ T: {\\mathcal X}^{\\mathrm{op}} \\rightarrow {\\mathcal Z}^{\\mathrm{op}}}")#text(" of two abstract measurable maps ")#mi("{T: {\\mathcal X}^{\\mathrm{op}} \\rightarrow {\\mathcal Y}^{\\mathrm{op}}}")#text(", ")#mi("{S: {\\mathcal Y}^{\\mathrm{op}} \\rightarrow {\\mathcal Z}^{\\mathrm{op}}}")#text(" is defined by the formula ")#mi("{S \\circ T := (T^* \\circ S^*)^{\\mathrm{op}}}")#text(", or equivalently ")#mi("{(S \\circ T)^* = T^* \\circ S^*}")#text(".")

#text("Every concrete measurable space ")#mi("{X = (X,{\\mathcal X})}")#text(" can be identified with an abstract counterpart ")#mi("{{\\mathcal X}^{op}}")#text(", and similarly every concrete measurable map ")#mi("{T: X \\rightarrow Y}")#text(" can be identified with an abstract counterpart ")#mi("{(T^*)^{op}}")#text(", where ")#mi("{T^*: {\\mathcal Y} \\rightarrow {\\mathcal X}}")#text(" is the pullback map ")#mi("{T^* E := T^{-1}(E)}")#text(". Thus the category of concrete measurable spaces can be viewed as a ")#link("https://en.wikipedia.org/wiki/Subcategory")[#text("subcategory")]#text(" of the category of abstract measurable spaces. The advantage of working in the abstract setting is that it gives us access to more spaces that could not be directly defined in the concrete setting. Most importantly for us, we have a new abstract space, the ")#emph[#text("opposite ")#link("https://en.wikipedia.org/wiki/Measure_algebra")[#text("measure algebra")]]#text(" ")#mi("{X_\\mu}")#text(" of ")#mi("{X}")#text(", defined as ")#mi("{({\\bf X}/{\\bf N})^*}")#text(" where ")#mi("{{\\bf N}}")#text(" is the ideal of null sets in ")#mi("{{\\bf X}}")#text(". Informally, ")#mi("{X_\\mu}")#text(" is the space ")#mi("{X}")#text(" with all the null sets removed; there is a canonical abstract embedding map ")#mi("{\\iota: X_\\mu \\rightarrow X}")#text(", which allows one to convert any concrete measurable map ")#mi("{f: X \\rightarrow Y}")#text(" into an abstract one ")#mi("{[f]: X_\\mu \\rightarrow Y}")#text(". One can then define the notion of an abstract action, abstract cocycle, and abstract coboundary by replacing every occurrence of the category of concrete measurable spaces with their abstract counterparts, and replacing ")#mi("{X}")#text(" with the opposite measure algebra ")#mi("{X_\\mu}")#text("; see the paper for details. Our main theorem is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Uncountable Moore-Schmidt theorem)")]#text(" ")#metadata(none) <tao-7f93b0fd8143d0886ced>#text(" Let ")#mi("{\\Gamma}")#text(" be a discrete group acting abstractly on a ")#mi("{\\sigma}")#text("-finite measure space ")#mi("{X}")#text(". Let ")#mi("{K}")#text(" be a compact Hausdorff abelian group. Then a ")#mi("{K_\\otimes}")#text("-valued abstract measurable cocycle ")#mi("{\\rho = (\\rho_\\gamma)_{\\gamma \\in \\Gamma}}")#text(" is an abstract coboundary if and only if for each character ")#mi("{\\hat k \\in \\hat K}")#text(", the ")#mi("{\\mathbf{T}}")#text("-valued cocycles ")#mi("{\\langle \\hat k, \\rho \\rangle = ( \\langle \\hat k, \\rho_\\gamma \\rangle )_{\\gamma \\in \\Gamma}}")#text(" are abstract coboundaries.")
]

#text("With the abstract formalism, the proof of the uncountable Moore-Schmidt theorem is almost identical to the countable one (in fact we were able to make some simplifications, such as avoiding the use of the ergodic decomposition). A key tool is what we call a “conditional Pontryagin duality” theorem, which asserts that if one has an abstract measurable map ")#mi("{\\alpha_{\\hat k}: X_\\mu \\rightarrow {\\bf T}}")#text(" for each ")#mi("{\\hat k \\in K}")#text(" obeying the identity ")#mi("{ \\alpha_{\\hat k_1 + \\hat k_2} - \\alpha_{\\hat k_1} - \\alpha_{\\hat k_2} = 0}")#text(" for all ")#mi("{\\hat k_1,\\hat k_2 \\in \\hat K}")#text(", then there is an abstract measurable map ")#mi("{F: X_\\mu \\rightarrow K_\\otimes}")#text(" such that ")#mi("{\\alpha_{\\hat k} = \\langle \\hat k, F \\rangle}")#text(" for all ")#mi("{\\hat k \\in \\hat K}")#text(". This is derived from the usual Pontryagin duality and some other tools, most notably the completeness of the ")#mi("{\\sigma}")#text("-algebra of ")#mi("{X_\\mu}")#text(", and ")#link("https://planetmath.org/SikorskisExtensionTheorem")[#text("the Sikorski extension theorem")]#text(".")

#text("We feel that it is natural to stay within the abstract measure theory formalism whenever dealing with uncountable situations. However, it is still an interesting question as to when one can guarantee that the abstract objects constructed in this formalism are representable by concrete analogues. The basic questions in this regard are:")

#list(
[#text("(i) Suppose one has an abstract measurable map ")#mi("{f: X_\\mu \\rightarrow Y}")#text(" into a concrete measurable space. Does there exist a representation of ")#mi("{f}")#text(" by a concrete measurable map ")#mi("{\\tilde f: X \\rightarrow Y}")#text("? Is it unique up to almost everywhere equivalence?")],
[#text("(ii) Suppose one has a concrete cocycle that is an abstract coboundary. When can it be represented by a concrete coboundary?")]
)

#text("For (i) the answer is somewhat interesting (as I learned after posing ")#link("https://mathoverflow.net/questions/346903/can-random-variables-that-almost-surely-solve-equations-be-repaired-to-surely-so/347012#347012")[#text("this MathOverflow question")]#text("):")

#list(
[#text("If ")#mi("{Y}")#text(" does not separate points, or is not compact metrisable or Polish, there can be counterexamples to uniqueness. If ")#mi("{Y}")#text(" is not compact or Polish, there can be counterexamples to existence.")],
[#text("If ")#mi("{Y}")#text(" is a compact metric space or a Polish space, then one always has existence and uniqueness.")],
[#text("If ")#mi("{Y}")#text(" is a compact Hausdorff abelian group, one always has existence.")],
[#text("If ")#mi("{X}")#text(" is a complete measure space, then one always has existence (from a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=105479")[#text("theorem of Maharam")]#text(").")],
[#text("If ")#mi("{X}")#text(" is the unit interval with the Borel ")#mi("{\\sigma}")#text("-algebra and Lebesgue measure, then one has existence for all compact Hausdorff ")#mi("{Y}")#text(" assuming the continuum hypothesis (from a ")#link("https://mathscinet.ams.org/mathscinet/search/publdoc.html?pg1=MR&s1=1581278&loc=fromreflist")[#text("theorem of von Neumann")]#text(") but existence can fail under other extensions of ZFC (from a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=710248")[#text("theorem of Shelah")]#text(", using the method of ")#link("https://en.wikipedia.org/wiki/Forcing_(mathematics)")[#text("forcing")]#text(").")],
[#text("For more general ")#mi("{X}")#text(", existence for all compact Hausdorff ")#mi("{Y}")#text(" is equivalent to the existence of a lifting from the ")#mi("{\\sigma}")#text("-algebra ")#mi("{\\mathcal{X}/\\mathcal{N}}")#text(" to ")#mi("{\\mathcal{X}}")#text(" (or, in the language of abstract measurable spaces, the existence of an abstract retraction from ")#mi("{X}")#text(" to ")#mi("{X_\\mu}")#text(").")],
[#text("It is a long-standing open question (posed for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=991611")[#text("by Fremlin")]#text(") whether it is relatively consistent with ZFC that existence holds whenever ")#mi("{Y}")#text(" is compact Hausdorff.")]
)

#text("Our understanding of (ii) is much less complete:")

#list(
[#text("If ")#mi("{K}")#text(" is metrisable, the answer is “always” (which among other things establishes the countable Moore-Schmidt theorem as a corollary of the uncountable one).")],
[#text("If ")#mi("{\\Gamma}")#text(" is at most countable and ")#mi("{X}")#text(" is a complete measure space, then the answer is again “always”.")]
)

#text("In view of the answers to (i), I would not be surprised if the full answer to (ii) was also sensitive to axioms of set theory. However, such set theoretic issues seem to be almost completely avoided if one sticks with the abstract formalism throughout; they only arise when trying to pass back and forth between the abstract and concrete categories.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-530479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2019")])]

#text("The beginning of the post seems to be corrupted")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83e05c438a785a8b8ee90ef06a33d90588e8fcd626d753fa27811c9b36ecced6-b8998a25291df0d30b40981f6791d43bb2992808db882ba95a6ef74f66808567.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-530486")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2019")])]

#text("Measurable cohomology is fascinating because of its relations with other mathematics and because simple questions are hard. An example which came up for me when studying continuity of Lyapunov exponents: if ")#mi("T: X \\to X")#text(" is an ergodic automorphism of a probability space ")#mi("(X,{\\mathcal X},\\mu)")#text(" and ")#mi("K=Z_2")#text(" then the space of K-cocycles is ")#mi("{\\mathcal X}")#text(" itself. The ")#mi("K")#text("-coboundaries ")#mi("{\\mathcal C}")#text(" are the sets of the form ")#mi("A \\Delta T(A)")#text(", where ")#mi("\\Delta")#text(" is the symmetric difference. It is an additive subgroup of the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" and ")#mi("H^1={\\mathcal X}/{\\mathcal C}")#text(" is the first cohomology group of the dynamical system ")#mi("(X,T,{\\mathcal X},\\mu)")#text(". While writing my thesis, I pondered for a while the question to determine the cardinality of this group (is it countable or uncountable if ")#mi("T")#text(" is aperiodic? In the periodic case, if X is a finite set, then ")#mi("H^1")#text(" is ")#mi("Z_2")#text(" as the even subsets are the coboundaries). After asking this in 1995 to my then colleague Greg Hjorth, he showed me within hours a proof (using theorems known in descriptive set theory) that the group is uncountable. By the way, Greg had been at UCLA later, before moving to Australia. He unfortunately passed away in 2011.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-530882")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("I was curious if I could spot the ‘measure-theoretic subtlety’, and I didn’t see it explicitly addressed later (although alluded to, if I am right, by “one is still faced with an issue of having to potentially take an uncountable union of null sets”). Is it the difference between “for every ")#mi("\\gamma")#text(", there is a measure-0 set off of which …” and “there is a measure-0 set off of which, for every ")#mi("\\gamma")#text(", …” (a difference which is of course unimportant for countable groups, but becomes important in the uncountable setting)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-530901")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("The subtlety arises from the fact that the group operation ")#mi("+: K \\times K \\to K")#text(" is not necessarily measurable (if one endows ")#mi("K")#text(" with the Borel sigma algebra), so in particular expressions such as ")#mi("\\rho_{\\gamma_1} \\circ T^{\\gamma_2} + \\rho_{\\gamma_2}")#text(" need not be measurable functions if ")#mi("\\rho_{\\gamma_1}, \\rho_{\\gamma_2}")#text(" are measurable. (Strictly speaking, one *could* still technically define the notion of a measurable cocycle even without having a guarantee that the right-hand side of (1) is necessarily measurable, but it would be an unnatural definition and would likely lead to various undesirable pathologies. For instance, the sum of two measurable cocycles might no longer be a measurable cocycle, and not every measurable function ")#mi("F: X \\to K")#text(" would necessarily generate a coboundary.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c26f0315cfad3587dfc501754697db37f9f564cd97d5838243638aa8ba5798a-8aa9f769fdd27b5f12508cfbafa4ead5b70b23ed8ee71a85228df2d8c75ce653.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rogier Brussee")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-531154")[#strong[#text("Rogier Brussee")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2019")])]

#text("The opposite category of the category of Rings is the category of affine spectra, whose objects are the prime ideals with a sheaf of rings. The opposite category of the category of Boolean algebras are the Stone spaces.")

#text("The Stone space is very concretely the set of Boolean algebra homs to the 2 element Boolean algebra ")#mi("\\mathbb{B}= \\{\\mathrm{false}, \\mathrm{true}\\}")#text(".")

#text("The category of sigma algebras is a subcategory of the category of Boolean algebras, so it seems that the abstract measurable spaces can be identified as the space of Homs ")#mi("x:\\mathcal{B} \\to  \\mathbb{B}")#text(" (essentially, “a Dirac measure”) with the an additional countable continuity property ")#mi("x(\\bigcup_{n=1}^\\infty A_n) = \\bigvee_{n=1}^\\infty x(A_n)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49f5d7ebee63e4b3b66565d2509d48c1dc4209a5105f6afbe2fea1de6dc2c222-9c4bd0bf51fc85cad709fbb2f985c778166207676e3d06ccb2e7f314a2918362.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kmurali73")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-534349")[#strong[#text("kmurali73")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2019")])]

#text("I have a difficulty subscribing to the post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-534368")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2019")])]

#text("Hmm, I had a quick look through the configuration options for this blog and was not able to find an option or plugin for being able to subscribe to individual posts. (If anyone familiar with wordpress.com hosted sites knows how to do this, though, I will be happy to do so.) I did at least add a button on the sidebar for subscribing to the blog as a whole.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An uncountable Mackey-Zimmer theorem | What's new")]], [#link("https://terrytao.wordpress.com/2019/11/28/an-uncountable-moore-schmidt-theorem/#comment-592718")[#strong[#text("An uncountable Mackey-Zimmer theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("[…] project to develop “uncountable” versions of various theorems in ergodic theory; see this previous paper of Asgar and myself for the first paper in this series (and another paper will appear […]")
]
