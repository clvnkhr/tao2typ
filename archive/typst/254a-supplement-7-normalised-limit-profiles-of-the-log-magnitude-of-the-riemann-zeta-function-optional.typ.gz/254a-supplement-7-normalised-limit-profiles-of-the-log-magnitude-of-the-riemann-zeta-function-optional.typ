// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/
// Converted to Typst by tao2typ: "2026-10-14T16:37:39.284561+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 March 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/")[#text("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A major topic of interest of analytic number theory is the asymptotic behaviour of the Riemann zeta function ")#mi("{\\zeta}")#text(" in the critical strip ")#mi("{\\{ \\sigma+it: 0 < \\sigma < 1; t \\in {\\bf R} \\}}")#text(" in the limit ")#mi("{t \\rightarrow +\\infty}")#text(". For the purposes of this set of notes, it is a little simpler technically to work with the log-magnitude ")#tao-math("{\\log \\left|\\zeta\\right|: {\\bf C} \\rightarrow [-\\infty,+\\infty]}", block: false)#text(" of the zeta function. (In principle, one can reconstruct a branch of ")#mi("{\\log \\zeta}")#text(", and hence ")#mi("{\\zeta}")#text(" itself, from ")#tao-math("{\\log \\left|\\zeta\\right|}", block: false)#text(" using the Cauchy-Riemann equations, or tools such as the ")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Carath%C3%A9odory_theorem")[#text("Borel-Carathéodory theorem")]#text(", see Exercise 40 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(".)")

#text("One has the classical estimate")

#align(center)[#tao-fit-display[#mitex("\\zeta(\\sigma+it) = O( t^{O(1)} )")]]

#text("when ")#mi("{\\sigma = O(1)}")#text(" and ")#mi("{t \\geq 10}")#text(" (say), so that ")#metadata(none) <tao-139d544b821b13ebea14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\log \\left|\\zeta(\\sigma+it)\\right| \\leq O( \\log t ).", block: true)]]



#text(" (See e.g. Exercise 37 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".) In view of this, let us define the normalised log-magnitudes ")#mi("{F_T: {\\bf C} \\rightarrow [-\\infty,+\\infty]}")#text(" for any ")#mi("{T \\geq 10}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("F_T( \\sigma + it ) := \\frac{1}{\\log T} \\log \\left|\\zeta( \\sigma + i(T + t) )\\right|;", block: true)]]

#text("informally, this is a normalised window into ")#tao-math("{\\log \\left|\\zeta\\right|}", block: false)#text(" near ")#mi("{iT}")#text(". One can rephrase several assertions about the zeta function in terms of the asymptotic behaviour of ")#mi("{F_T}")#text(". For instance:")

#list(
[#text("(i) The bound ")#link(<tao-139d544b821b13ebea14>)[#text("(1)")]#text(" implies that ")#mi("{F_T}")#text(" is asymptotically locally bounded from above in the limit ")#mi("{T \\rightarrow \\infty}")#text(", thus for any compact set ")#mi("{K \\subset {\\bf C}}")#text(" we have ")#mi("{F_T(\\sigma+it) \\leq O_K(1)}")#text(" for ")#mi("{\\sigma+it \\in K}")#text(" and ")#mi("{T}")#text(" sufficiently large. In fact the implied constant in ")#mi("{K}")#text(" only depends on the projection of ")#mi("{K}")#text(" to the real axis.")],
[#text("(ii) For ")#mi("{\\sigma > 1}")#text(", we have the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\zeta(\\sigma+it)\\right|, \\frac{1}{\\left|\\zeta(\\sigma+it)\\right|} \\leq \\zeta(\\sigma)", block: true)]]

#text("which implies that ")#mi("{F_T}")#text(" converges locally uniformly as ")#mi("{T \\rightarrow +\\infty}")#text(" to zero in the region ")#mi("{\\{ \\sigma+it: \\sigma > 1, t \\in {\\bf R} \\}}")#text(".")],
[#text("(iii) The functional equation, together with the symmetry ")#mi("{\\zeta(\\sigma-it) = \\overline{\\zeta(\\sigma+it)}}")#text(", implies that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\zeta(\\sigma+it)\\right| = 2^\\sigma \\pi^{\\sigma-1} \\left|\\sin \\frac{\\pi(\\sigma+it)}{2}\\right| \\left|\\Gamma(1-\\sigma-it)\\right| \\left|\\zeta(1-\\sigma+it)\\right|", block: true)]]

#text("which by Exercise 17 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(" shows that")

#align(center)[#tao-fit-display[#mitex("F_T( 1-\\sigma+it ) = \\frac{1}{2}-\\sigma + F_T(\\sigma+it) + o(1)")]]

#text("as ")#mi("{T \\rightarrow \\infty}")#text(", locally uniformly in ")#mi("{\\sigma+it}")#text(". In particular, when combined with the previous item, we see that ")#mi("{F_T(\\sigma+it)}")#text(" converges locally uniformly as ")#mi("{T \\rightarrow +\\infty}")#text(" to ")#mi("{\\frac{1}{2}-\\sigma}")#text(" in the region ")#mi("{\\{ \\sigma+it: \\sigma < 0, t \\in {\\bf R}\\}}")#text(".")],
[#text("(iv) From Jensen’s formula (Theorem 16 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") we see that ")#tao-math("{\\log\\left|\\zeta\\right|}", block: false)#text(" is a subharmonic function, and thus ")#mi("{F_T}")#text(" is subharmonic as well. In particular we have the mean value inequality")

#align(center)[#tao-fit-display[#tao-math("F_T( z_0 ) \\leq \\frac{1}{\\pi r^2} \\int_{z: \\left|z-z_0\\right| \\leq r} F_T(z)", block: true)]]

#text("for any disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(", where the integral is with respect to area measure. From this and (ii) we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_{z: \\left|z-z_0\\right| \\leq r} F_T(z) \\geq O_{z_0,r}(1)", block: true)]]

#text("for any disk with ")#mi("{\\text{Re}(z_0)>1}")#text(" and sufficiently large ")#mi("{T}")#text("; combining this with (i) we conclude that ")#mi("{F_T}")#text(" is asymptotically locally bounded in ")#mi("{L^1}")#text(" in the limit ")#mi("{T \\rightarrow \\infty}")#text(", thus for any compact set ")#mi("{K \\subset {\\bf C}}")#text(" we have ")#tao-math("{\\int_K \\left|F_T\\right| \\ll_K 1}", block: false)#text(" for sufficiently large ")#mi("{T}")#text(".")]
)

#text("From (iv) and the usual Arzela-Ascoli diagonalisation argument, we see that the ")#mi("{F_T}")#text(" are asymptotically compact in the topology of distributions: given any sequence ")#mi("{T_n}")#text(" tending to ")#mi("{+\\infty}")#text(", one can extract a subsequence such that the ")#mi("{F_T}")#text(" converge in the sense of distributions. Let us then define a ")#emph[#text("normalised limit profile")]#text(" of ")#tao-math("{\\log\\left|\\zeta\\right|}", block: false)#text(" to be a distributional limit ")#mi("{F}")#text(" of a sequence of ")#mi("{F_T}")#text("; they are analogous to limiting profiles in PDE, and also to the more recent introduction of “graphons” in the theory of ")#link("http://en.wikipedia.org/wiki/Continuous_graph")[#text("graph limits")]#text(". Then by taking limits in (i)-(iv) we can say a lot about such normalised limit profiles ")#mi("{F}")#text(" (up to almost everywhere equivalence, which is an issue we will address shortly):")

#list(
[#text("(i) ")#mi("{F}")#text(" is bounded from above in the critical strip ")#mi("{\\{ \\sigma+it: 0 \\leq \\sigma \\leq 1 \\}}")#text(".")],
[#text("(ii) ")#mi("{F}")#text(" vanishes on ")#mi("{\\{ \\sigma+it: \\sigma \\geq 1\\}}")#text(".")],
[#text("(iii) We have the functional equation ")#mi("{F(1-\\sigma+it) = \\frac{1}{2}-\\sigma + F(\\sigma+it)}")#text(" for all ")#mi("{\\sigma+it}")#text(". In particular ")#mi("{F(\\sigma+it) = \\frac{1}{2}-\\sigma}")#text(" for ")#mi("{\\sigma<0}")#text(".")],
[#text("(iv) ")#mi("{F}")#text(" is subharmonic.")]
)

#text("Unfortunately, (i)-(iv) fail to characterise ")#mi("{F}")#text(" completely. For instance, one could have ")#mi("{F(\\sigma+it) = f(\\sigma)}")#text(" for any convex function ")#mi("{f(\\sigma)}")#text(" of ")#mi("{\\sigma}")#text(" that equals ")#mi("{0}")#text(" for ")#mi("{\\sigma \\geq 1}")#text(", ")#mi("{\\frac{1}{2}-\\sigma}")#text(" for ")#mi("{\\sigma \\leq 1}")#text(", and obeys the functional equation ")#mi("{f(1-\\sigma) = \\frac{1}{2}-\\sigma+f(\\sigma)}")#text(", and this would be consistent with (i)-(iv). One can also perturb such examples in a region where ")#mi("{f}")#text(" is strictly convex to create further examples of functions obeying (i)-(iv). Note from subharmonicity that the function ")#mi("{\\sigma \\mapsto \\sup_t F(\\sigma+it)}")#text(" is always going to be convex in ")#mi("{\\sigma}")#text("; this can be seen as a limiting case of the ")#link("http://en.wikipedia.org/wiki/Hadamard_three-lines_theorem")[#text("Hadamard three-lines theorem")]#text(" (Exercise 41 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(").")

#text("We pause to address one minor technicality. We have defined ")#mi("{F}")#text(" as a distributional limit, and as such it is ")#emph[#text("a priori")]#text(" only defined up to almost everywhere equivalence. However, due to subharmonicity, there is a unique upper semi-continuous representative of ")#mi("{F}")#text(" (taking values in ")#mi("{[-\\infty,+\\infty)}")#text("), defined by the formula")

#align(center)[#tao-fit-display[#mitex("F(z_0) = \\lim_{r \\rightarrow 0^+} \\frac{1}{\\pi r^2} \\int_{B(z_0,r)} F(z)\\ dz")]]

#text("for any ")#mi("{z_0 \\in {\\bf C}}")#text(" (note from subharmonicity that the expression in the limit is monotone nonincreasing as ")#mi("{r \\rightarrow 0}")#text(", and is also continuous in ")#mi("{z_0}")#text("). We will now view this upper semi-continuous representative of ")#mi("{F}")#text(" as ")#emph[#text("the")]#text(" canonical representative of ")#mi("{F}")#text(", so that ")#mi("{F}")#text(" is now defined everywhere, rather than up to almost everywhere equivalence.")

#text("By a classical theorem of Riesz, a function ")#mi("{F}")#text(" is subharmonic if and only if the distribution ")#mi("{-\\Delta F}")#text(" is a non-negative measure, where ")#mi("{\\Delta := \\frac{\\partial^2}{\\partial \\sigma^2} + \\frac{\\partial^2}{\\partial t^2}}")#text(" is the Laplacian in the ")#mi("{\\sigma,t}")#text(" coordinates. Jensen’s formula (or Greens’ theorem), when interpreted distributionally, tells us that")

#align(center)[#tao-fit-display[#tao-math("-\\Delta \\log \\left|\\zeta\\right| = \\frac{1}{2\\pi} \\sum_\\rho \\delta_\\rho", block: true)]]

#text("away from the real axis, where ")#mi("{\\rho}")#text(" ranges over the non-trivial zeroes of ")#mi("{\\zeta}")#text(". Thus, if ")#mi("{F}")#text(" is a normalised limit profile for ")#tao-math("{\\log \\left|\\zeta\\right|}", block: false)#text(" that is the distributional limit of ")#mi("{F_{T_n}}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("-\\Delta F = \\nu")]]

#text("where ")#mi("{\\nu}")#text(" is a non-negative measure which is the limit in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" of the measures")

#align(center)[#tao-fit-display[#mitex("\\nu_{T_n} := \\frac{1}{2\\pi \\log T_n} \\sum_\\rho \\delta_{\\rho - T_n}.")]]

#text("Thus ")#mi("{\\nu}")#text(" is a normalised limit profile of the zeroes of the Riemann zeta function.")

#text("Using this machinery, we can recover many classical theorems about the Riemann zeta function by “soft” arguments that do not require extensive calculation. Here are some examples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" The ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" implies the ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelöf hypothesis")]#text(".")
]

#emph[#text("Proof:")]#text(" It suffices to show that any limiting profile ")#mi("{F}")#text(" (arising as the limit of some ")#mi("{F_{T_n}}")#text(") vanishes on the critical line ")#mi("{\\{1/2+it: t \\in {\\bf R}\\}}")#text(". But if the Riemann hypothesis holds, then the measures ")#mi("{\\nu_{T_n}}")#text(" are supported on the critical line ")#mi("{\\{1/2+it: t \\in {\\bf R}\\}}")#text(", so the normalised limit profile ")#mi("{\\nu}")#text(" is also supported on this line. This implies that ")#mi("{F}")#text(" is harmonic outside of the critical line. By (ii) and unique continuation for harmonic functions, this implies that ")#mi("{F}")#text(" vanishes on the half-space ")#mi("{\\{ \\sigma+it: \\sigma \\geq \\frac{1}{2} \\}}")#text(" (and equals ")#mi("{\\frac{1}{2}-\\sigma}")#text(" on the complementary half-space, by (iii)), giving the claim. ")#mi("\\Box")

#text("In fact, we have the following sharper statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Backlund)")]#text(" The Lindelöf hypothesis is equivalent to the assertion that for any fixed ")#mi("{\\sigma_0 > \\frac{1}{2}}")#text(", the number of zeroes in the region ")#mi("{\\{ \\sigma+it: \\sigma > \\sigma_0, T \\leq t \\leq T+1 \\}}")#text(" is ")#mi("{o(\\log T)}")#text(" as ")#mi("{T \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" If the latter claim holds, then for any ")#mi("{T_n \\rightarrow \\infty}")#text(", the measures ")#mi("{\\nu_{T_n}}")#text(" assign a mass of ")#mi("{o(1)}")#text(" to any region of the form ")#mi("{\\{ \\sigma+it: \\sigma > \\sigma_0; t_0 \\leq t \\leq t_0+1 \\}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{\\sigma_0>\\frac{1}{2}}")#text(" and ")#mi("{t_0 \\in {\\bf R}}")#text(". Thus the normalised limiting profile measure ")#mi("{\\nu}")#text(" is supported on the critical line, and we can repeat the previous argument.")

#text("Conversely, suppose the claim fails, then we can find a sequence ")#mi("{T_n}")#text(" and ")#mi("{\\sigma_0>0}")#text(" such that ")#mi("{\\nu_{T_n}}")#text(" assigns a mass of ")#mi("{\\gg 1}")#text(" to the region ")#mi("{\\{ \\sigma+it: \\sigma > \\sigma_0; 0\\leq t \\leq 1 \\}}")#text(". Extracting a normalised limiting profile, we conclude that the normalised limiting profile measure ")#mi("{\\nu}")#text(" is non-trivial somewhere to the right of the critical line, so the associated subharmonic function ")#mi("{F}")#text(" is not harmonic everywhere to the right of the critical line. From the maximum principle and (ii) this implies that ")#mi("{F}")#text(" has to be positive somewhere on the critical line, but this contradicts the Lindelöf hypothesis. (One has to take a bit of care in the last step since ")#mi("{F_{T_n}}")#text(" only converges to ")#mi("{F}")#text(" in the sense of distributions, but it turns out that the subharmonicity of all the functions involved gives enough regularity to justify the argument; we omit the details here.) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Littlewood)")]#text(" Assume the Lindelöf hypothesis. Then for any fixed ")#mi("{\\alpha>0}")#text(", the number of zeroes in the region ")#mi("{\\{ \\sigma+it: T \\leq t \\leq T+\\alpha \\}}")#text(" is ")#mi("{(2\\pi \\alpha+o(1)) \\log T}")#text(" as ")#mi("{T \\rightarrow +\\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" By the previous arguments, the only possible normalised limiting profile for ")#tao-math("{\\log \\left|\\zeta\\right|}", block: false)#text(" is ")#mi("{\\max( 0, \\frac{1}{2}-\\sigma )}")#text(". Taking distributional Laplacians, we see that the only possible normalised limiting profile for the zeroes is Lebesgue measure on the critical line. Thus, ")#mi("{\\nu_T( \\{\\sigma+it: T \\leq t \\leq T+\\alpha \\} )}")#text(" can only converge to ")#mi("{\\alpha}")#text(" as ")#mi("{T \\rightarrow +\\infty}")#text(", and the claim follows. ")#mi("\\Box")

#text("Even without the Lindelöf hypothesis, we have the following result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Titchmarsh)")]#text(" For any fixed ")#mi("{\\alpha>0}")#text(", there are ")#mi("{\\gg_\\alpha \\log T}")#text(" zeroes in the region ")#mi("{\\{ \\sigma+it: T \\leq t \\leq T+\\alpha \\}}")#text(" for sufficiently large ")#mi("{T}")#text(".")
]

#text("Among other things, this theorem recovers a classical result of Littlewood that the gaps between the imaginary parts of the zeroes goes to zero, even without assuming unproven conjectures such as the Riemann or Lindelöf hypotheses.")

#emph[#text("Proof:")]#text(" Suppose for contradiction that this were not the case, then we can find ")#mi("{\\alpha > 0}")#text(" and a sequence ")#mi("{T_n \\rightarrow \\infty}")#text(" such that ")#mi("{\\{ \\sigma+it: T_n \\leq t \\leq T_n+\\alpha \\}}")#text(" contains ")#mi("{o(\\log T)}")#text(" zeroes. Passing to a subsequence to extract a limit profile, we conclude that the normalised limit profile measure ")#mi("{\\nu}")#text(" assigns no mass to the horizontal strip ")#mi("{\\{ \\sigma+it: 0 \\leq t \\leq\\alpha \\}}")#text(". Thus the associated subharmonic function ")#mi("{F}")#text(" is actually harmonic on this strip. But by (ii) and unique continuation this forces ")#mi("{F}")#text(" to vanish on this strip, contradicting the functional equation (iii). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Use limiting profiles to obtain the matching upper bound of ")#mi("{O_\\alpha(\\log T)}")#text(" for the number of zeroes in ")#mi("{\\{ \\sigma+it: T \\leq t \\leq T+\\alpha \\}}")#text(" for sufficiently large ")#mi("{T}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" One can remove the need to take limiting profiles in the above arguments if one can come up with quantitative (or “hard”) substitutes for qualitative (or “soft”) results such as the unique continuation property for harmonic functions. This would also allow one to replace the qualitative decay rates ")#mi("{o(1)}")#text(" with more quantitative decay rates such as ")#mi("{1/\\log \\log T}")#text(" or ")#mi("{1/\\log\\log\\log T}")#text(". Indeed, the classical proofs of the above theorems come with quantitative bounds that are typically of this form (see e.g. the ")#link("http://www.ams.org/mathscinet-getitem?mr=882550")[#text("text of Titchmarsh")]#text(" for details).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{S(T)}")#text(" denote the quantity ")#mi("{S(T) := \\frac{1}{\\pi} \\text{arg} \\zeta(\\frac{1}{2}+iT)}")#text(", where the branch of the argument is taken by using a line segment connecting ")#mi("{\\frac{1}{2}+iT}")#text(" to (say) ")#mi("{2+iT}")#text(", and then to ")#mi("{2}")#text(". If we have a sequence ")#mi("{T_n \\rightarrow \\infty}")#text(" producing normalised limit profiles ")#mi("{F, \\nu}")#text(" for ")#tao-math("{\\log\\left|\\zeta\\right|}", block: false)#text(" and the zeroes respectively, show that ")#mi("{t \\mapsto \\frac{1}{\\log T_n} S(T_n + t)}")#text(" converges in the sense of distributions to the function ")#mi("{t \\mapsto \\frac{1}{\\pi} \\int_{1/2}^1 \\frac{\\partial F}{\\partial t}(\\sigma+it)\\ d\\sigma}")#text(", or equivalently")

#align(center)[#tao-fit-display[#mitex("t \\mapsto \\frac{1}{2\\pi} \\frac{\\partial}{\\partial t} \\int_0^1 F(\\sigma+it)\\ d\\sigma.")]]

#text("Conclude in particular that if the Lindelöf hypothesis holds, then ")#mi("{S(T) = o(\\log T)}")#text(" as ")#mi("{T \\rightarrow \\infty}")#text(".")
]

#text("A little bit more about the normalised limit profiles ")#mi("{F}")#text(" are known unconditionally, beyond (i)-(iv). For instance, from Exercise 3 of ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("Notes 5")]#text(" we have ")#mi("{\\zeta(1/2 + it ) = O( t^{1/6+o(1)} )}")#text(" as ")#mi("{t \\rightarrow +\\infty}")#text(", which implies that any normalised limit profile ")#mi("{F}")#text(" for ")#tao-math("{\\log\\left|\\zeta\\right|}", block: false)#text(" is bounded by ")#mi("{1/6}")#text(" on the critical line, beating the bound of ")#mi("{1/4}")#text(" coming from convexity and (ii), (iii), and then convexity can be used to further bound ")#mi("{F}")#text(" away from the critical line also. Some further small improvements of this type are known (coming from various methods for estimating exponential sums), though they fall well short of determining ")#mi("{F}")#text(" completely at our current level of understanding. Of course, given that we believe the Riemann hypothesis (and hence the Lindelöf hypothesis) to be true, the only actual limit profile that should exist is ")#mi("{\\max(0,\\frac{1}{2}-\\sigma)}")#text(" (in fact this assertion is equivalent to the Lindelöf hypothesis, by the arguments above).")

#text("Better control on limiting profiles is available if we do not insist on controlling ")#mi("{\\zeta}")#text(" for ")#emph[#text("all")]#text(" values of the height parameter ")#mi("{T}")#text(", but only for ")#emph[#text("most")]#text(" such values, thanks to the existence of several ")#emph[#text("mean value theorems")]#text(" for the zeta function, as discussed in ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text("; we discuss this below the fold.")

#metadata(none) <tao-a6ea7b28c9f6b8d2b468>

#heading(level: 1)[#strong[#text(" — 1. Limiting profiles outside of exceptional sets — ")]]

#text("In order to avoid an excessive number of extraction of subsequences and discarding of exceptional sets, we now move away from the standard sequential notion of a limit, and instead work with the less popular, but equally valid notion of an ")#emph[#text("ultrafilter limit")]#text(". Recall that an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" ")#mi("{p}")#text(" on a set ")#mi("{X}")#text(" is a collection of subsets of ")#mi("{X}")#text(" (which we will call the “")#mi("{p}")#text("-large” sets) which are the sets of full measure with regards to some finitely additive ")#mi("{\\{0,1\\}}")#text("-valued probability measure on ")#mi("{X}")#text(" (with the power set Boolean algebra ")#mi("{2^X}")#text("). We call a subset of ")#mi("{X}")#text(" ")#emph[#mi("{p}")#text("-small")]#text(" if it is not ")#mi("{p}")#text("-large. Given a function ")#mi("{f: X \\rightarrow Y}")#text(" into a topological space ")#mi("{Y}")#text(" and a point ")#mi("{y \\in Y}")#text(", we say that ")#mi("{f}")#text(" ")#emph[#text("converges to ")#mi("{y}")#text(" along ")#mi("{p}")]#text(" if ")#mi("{f^{-1}(U)}")#text(" is ")#mi("{p}")#text("-large for every neighbourhood ")#mi("{U}")#text(" of ")#mi("{y}")#text(", and then we call ")#mi("{y}")#text(" a ")#emph[#mi("{p}")#text("-limit")]#text(" of ")#mi("{f}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{f: X \\rightarrow Y}")#text(" be a function into a topological space ")#mi("{Y}")#text(", and let ")#mi("{p}")#text(" be an ultrafilter on ")#mi("{X}")#text(".")

#list(
[#text("(i) If ")#mi("{Y}")#text(" is compact, show that ")#mi("{f}")#text(" has at least one ")#mi("{p}")#text("-limit.")],
[#text("(ii) If ")#mi("{Y}")#text(" is Hausdorff, show that ")#mi("{f}")#text(" has at most one ")#mi("{p}")#text("-limit.")],
[#text("(iii) Conversely, if ")#mi("{Y}")#text(" fails to be compact (resp. Hausdorff), show that there exists a function ")#mi("{f: X \\rightarrow Y}")#text(" and an ultrafilter ")#mi("{p}")#text(" on ")#mi("{X}")#text(" such that ")#mi("{f}")#text(" has no ")#mi("{p}")#text("-limit (resp. more than one ")#mi("{p}")#text("-limit).")]
)
]

#text("In particular, given an ultrafilter ")#mi("{p}")#text(" on the non-negative reals ")#mi("{{\\bf R}^+ = [0,+\\infty)}")#text(", which is non-principal in the sense that all compact subsets of ")#mi("{{\\bf R}^+}")#text(" are ")#mi("{p}")#text("-small,, there exists a unique normalised limiting profile ")#mi("{F}")#text(" that is the limit of ")#mi("{T \\mapsto F_T}")#text(" along ")#mi("{p}")#text(", and similarly for ")#mi("{\\nu}")#text(". Because the distributional topology is second countable, such limiting profiles are also limiting profiles of sequences ")#mi("{T_n \\rightarrow \\infty}")#text(" as in the previous discussion, and so we retain all existing properties of limit profiles such as (i)-(iv). However, in the ultrafilter formalism we can now easily avoid various “small” exceptional sets of ")#mi("{T}")#text(", in addition to the compact sets that have already been excluded. For instance, let us call an ultrafilter ")#mi("{p}")#text(" ")#emph[#text("generic")]#text(" if every Lebesgue measurable subset ")#mi("{A}")#text(" of ")#mi("{{\\bf R}}")#text(" of zero upper density (thus ")#mi("{A \\cap [0,T]}")#text(" has Lebesgue measure ")#mi("{o(T)}")#text(" as ")#mi("{T \\rightarrow \\infty}")#text(") is ")#mi("{p}")#text("-small. The existence of generic ultrafilters follows easily from Zorn’s lemma. Define a ")#emph[#text("generic limit profile")]#text(" to be a limit profile that arises from a generic ultrafilter; informally, these capture the possible behaviour of the zeta function outside of a set of heights ")#mi("{T}")#text(" of zero density. To see how these profiles are better than arbitrary limit profiles, we recall from Exercise 2 of ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\sum_j \\left|\\sum_{n=1}^N a_n n^{-it_j}\\right|^2 \\ll (\\sum_{n=1}^N \\left|a_n\\right|^2) (T+N)", block: true)]]

#text("if the ")#mi("{t_j}")#text(" are ")#mi("{1}")#text("-separated elements of ")#mi("{[0,T]}")#text(" and ")#mi("{a_n}")#text(" are arbitrary complex coefficients. If we set ")#mi("{T=N}")#text(", we can conclude (among other things), that for any constant ")#mi("{C}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sup_{t^{\\prime}: \\left|t-t^{\\prime}\\right| \\leq C} \\left|\\sum_{n=1}^T a_n n^{-it}\\right| \\ll T^{o(1)} (\\sum_{n=1}^T \\left|a_n\\right|^2)^{1/2}", block: true)]]

#text("for all ")#mi("{t \\in [0,T]}")#text(" outside of a set of measure ")#mi("{o(T)}")#text(" (informally: “square root cancellation occurs generically”). Using this, one can for instance show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{t^{\\prime}: \\left|t-t^{\\prime}\\right| \\leq C} \\left|\\zeta(\\frac{1}{2}+it^{\\prime})\\right| \\ll T^{o(1)}", block: true)]]

#text("for all ")#mi("{t \\in [0,T]}")#text(" outside of a set of measure ")#mi("{o(T)}")#text(", which implies that any ")#emph[#text("generic")]#text(" limit profile ")#mi("{F}")#text(" vanishes on the critical line, and thus must be ")#mi("{\\max(0, \\frac{1}{2}-\\sigma)}")#text("; that is to say, the Lindelöf hypothesis is true “generically”.")

#text("One can profitably explore the regime between arbitrary non-principal ultrafilters and generic ultrafilters by introducing the intermediate notion of an ")#emph[#mi("{\\alpha}")#text("-generic ultrafilter")]#text(" for any ")#mi("{0 < \\alpha < 1}")#text(", defined as an ultrafilter ")#mi("{p}")#text(" with the property that any Lebesgue measurable subset ")#mi("{A}")#text(" of ")#mi("{{\\bf R}}")#text(" of “dimension at most ")#mi("{\\alpha}")#text("” in the sense that ")#mi("{A \\cap [0,T]}")#text(" has measure ")#mi("{O( T^{\\alpha+o(1)})}")#text(", is ")#mi("{p}")#text("-small. One can then interpret many existing mean value theorems on the zeta function (or on other Dirichlet series) as controlling the ")#mi("{\\alpha}")#text("-generic limit profiles of ")#tao-math("{\\log\\left|\\zeta\\right|}", block: false)#text(", or more generally of the log-magnitude of various Dirichlet series (e.g. ")#mi("{\\sum_{n \\leq T^\\theta} \\frac{\\mu(n)}{n^s}}")#text(" for various exponents ")#mi("{\\theta}")#text("). For instance, the previous argument shows that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{t^{\\prime}: \\left|t-t^{\\prime}\\right| \\leq C} \\left|\\zeta(\\frac{1}{2}+it^{\\prime})\\right| \\ll T^{(1-\\alpha)/2+o(1)}", block: true)]]

#text("for all ")#mi("{t \\in [0,T]}")#text(" outside of a set of measure ")#mi("{T^{\\alpha+o(1)}}")#text(", which implies that any ")#mi("{\\alpha}")#text("-generic limit profile ")#mi("{F}")#text(" is bounded above by ")#mi("{\\frac{1-\\alpha}{2}}")#text(" on the critical line. One can also recast much of the arguments in Notes 6 in this language (defining limit profiles for various Dirichlet polynomials, and using such profiles and zero-detecting polynomials to establish ")#mi("{\\alpha}")#text("-generic zero-free regions), although this is mostly just a change of notation and does not seem to yield any major simplifications to these arguments.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-452638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("In the mean value inequality for ")#mi("F_T")#text(", it seems (but not stated) that the integral is with the area measure.")

#emph[#text("[Clarification added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-452648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("Theorem 3 shows that Lindelof hypothesis implies that the elementary estimate ")#tao-math("O(\\log \\left|t\\right|)", block: false)#text(" for the multiplicities of the non-trivial zeros (with large ")#tao-math("\\left|t\\right|", block: false)#text(") can be improved to ")#tao-math("o(\\log \\left|t\\right|)", block: false)#text(". Is it possible to improve the last estimate by letting (in theorem 3) ")#mi("\\alpha \\to 0")#text(" as ")#mi("T \\to \\infty")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-452650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("My feeling is that if one only assumes the standard qualitative form of Lindelof (namely that ")#mi("\\zeta(1/2+it) = t^{o(1)}")#text(" as ")#mi("t \\to \\infty")#text(", with no information about the decay rate in the ")#mi("o(1)")#text(" exponent) then one cannot improve upon the ")#tao-math("o( \\log \\left|t\\right| )", block: false)#text(" bound, basically because smashing together ")#mi("\\varepsilon \\log t")#text(" nearby zeroes to form a single zero of high multiplicity would only increase the magnitude of the zeta function by about ")#mi("t^\\varepsilon")#text(" or so at most near these zeroes, so for any ")#mi("\\varepsilon = o(1)")#text(" such an “edit” to the zeta function would be undetectable (at least by naive means) to the Lindelof hypothesis. (See also Remark 30 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(" for a related example of “editing” the zeta function.)")

#text("However, if one assumed a more quantitative form of the Lindelof hypothesis, then one should be able to do better. For instance, it is a classical result of Littlewood that the RH implies ")#mi("S(t) = O( \\log T / \\log\\log T )")#text(", which implies that any zero has multiplicity at most ")#mi("O( \\log T / \\log \\log T )")#text(". The implied constant was lowered to ")#mi("1/2+o(1)")#text(" by ")#link("http://www.ams.org/mathscinet-getitem?mr=2331578")[#text("Goldston and Gonek")]#text("; there has been some further work in this direction but this is still close to the state of the art for what one can say on RH.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-452651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("Graph limits (iii)")#linebreak()#text(" If : ")#mi("{F(\\sigma + it) = \\frac{1}{2} - \\sigma}")#text(" for ")#mi("{\\sigma < 1}")#linebreak()#text(" and ")#mi("{F(\\sigma + it) = \\frac{1}{3} - \\sigma}")#linebreak()#text(" then.")#linebreak()#text(" ")#mi("\\frac{1}{2} - \\sigma = \\frac{1}{3} - \\sigma")

#emph[#text("[There was a typo: ")#mi("F(\\sigma+it) = \\frac{1}{2}-\\sigma")#text(" is only known for ")#mi("\\sigma < 0")#text(", not ")#mi("\\sigma < 1")#text(". This typo has now been fixed. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b5b5dcc86d676770e1a55b62e44666c9dbccf50325bb34469810e7a3d2e2d02-56fc762903c625f9f055aa84d4af69900a1146796d78802467a04ba238913af9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0f33418c7da5cbb5")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-459638")[#strong[#text("0f33418c7da5cbb5")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("Sorry for the comment that in some sense does not apply to this post.The zeros of the Riemann zeta function compares integers (zero exists or not).Applying Cantor’s diagonal method is easy to show that the conversion of all real numbers ")#mi("\\displaystyle 1/2 - \\frac{R}{log(T/2\\pi )}\\leq  \\varpi (T)\\leq 1/2-\\frac{R}{log(T/2\\pi )}+\\frac{1}{T}")#text(" interval does not exist(for some ")#mi("T")#text(" and ")#mi("R")#text(" – constant).Focusing above now we can say that there are an infinite number of real zeros in the half-interval.The function ")#mi("\\varpi (T)")#text(" will adjust the values of ")#mi("\\alpha")#text("-(defined in the Levinson) for their match with the actual numbers are not zeros of the zeta function.Now we can use the length molifer ")#mi("T")#text(" instead of ")#mi("T^{4/7}")#text(".And following the Levinson can conclude that the number of zeros for some ")#mi("T")#text(" has an overall principal term at ")#mi("1/2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b5b5dcc86d676770e1a55b62e44666c9dbccf50325bb34469810e7a3d2e2d02-56fc762903c625f9f055aa84d4af69900a1146796d78802467a04ba238913af9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 0f33418c7da5cbb5")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-459676")[#strong[#text("0f33418c7da5cbb5")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")])]

#text("Maybe I made a mistake, instead of the ")#mi("\\frac{1}{T}")#text(" need at least ")#mi("\\frac{1}{Tlog(T)log(log(T))}")#text(".")#linebreak()#text(" It means ")#mi("\\displaystyle \\sum_{n=1}^{\\infty }\\frac{1}{n^{1/2-\\frac{R}{log(T/2\\pi )}+\\varpi (T)+it}}\\neq 0")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{n=1}^{t^{1-\\varepsilon}} \\frac{1}{n^{1/2-\\frac{R}{log(T/2\\pi )}+\\varpi (T)+it}}")#linebreak()#text(" ")#mi("\\displaystyle t^{1-\\varepsilon }")#text(" instead ")#mi("\\displaystyle t^{4/7}")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The De Bruijn-Newman constant is non-negativ | What's new")]], [#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/#comment-491516")[#strong[#text("The De Bruijn-Newman constant is non-negativ | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("[…] we get to assume the Riemann hypothesis, we can sharpen this to , a result of Littlewood (see this previous blog post for a proof). Ideally, we would like to obtain similar control for the other , , as well. […]")
]
