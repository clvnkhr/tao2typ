// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/
// Converted to Typst by tao2typ: "2026-10-14T11:16:11.877829+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Old and new apps, via modern coding agents", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Old and new apps, via modern coding agents")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/")[#text("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have been interested in machine-assisted ways to do and teach mathematics from as far back as 1999, when I started coding ")#link("https://terrytao.wordpress.com/applets/")[#text("several applets in Java 1.0")]#text(", both for my complex analysis and linear algebra courses, as well as to visualize various mathematical objects I was interested in (such as honeycombs or Besicovitch sets). This was moderately successful; but the applets were time-consuming to program. Eventually, the standards for web pages stopped supporting this version of Java, and ")#link("https://terrytao.wordpress.com/2008/12/01/upgrading-old-java-applets/")[#text("the applets became non-functional.")]

#text("However, in the last few days I have begun the process of migrating much of my old web page and blog data to a ")#link("https://teorth.github.io/tao-web/")[#text("more maintainable repository")]#text(", using modern AI assistance. As an experiment, I asked the agent to port my old applets to a modern supported language (we landed on Javascript), and it ")#link("https://teorth.github.io/tao-web/apps/porting-legacy-applets.html")[#text("managed to do so")]#text(" in a matter of hours, with ")#link("https://teorth.github.io/tao-web/applets.html")[#text("all of my old applets now functional again")]#text(", with even a few graphical upgrades (for instance, the ")#link("https://teorth.github.io/tao-web/apps/besicovitch-sets.html")[#text("Besicovitch set applet")]#text(" is now colorized, in contrast to my original monochrome version). I am particularly pleased to see the honeycomb applet that I wrote with ")#link("https://pi.math.cornell.edu/~allenk/")[#text("Allen Knutson")]#text(" in 1999 ")#link("https://teorth.github.io/tao-web/apps/honeycombs.html")[#text("come back to life")]#text(", as this was a particularly tricky one to code by hand:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image.png")[#image("../assets/45a5a18d4e9ad716ed80d17321fdfeca8ab2ca9f22d6292c7d465a47a5bd37fe-c01fa5ad9c0cd6c83ccf6f568c7259bc57d86ed9f0edf7b26d7b6dd4ee53fb46.png", width: 90%)]
]

#text("Notoriously, LLM-based coding agents can create various blatant or subtle bugs in their code; but in the porting of these two dozen or so applets, I could only find one minor bug (the handling of a drag event in one of the complex analysis applets had unwanted behavior when dragging outside of the main box), and in fact the agent identified two bugs in the original code that I was not aware of, so it ended up being a net wash as far as code quality was concerned. In any event, as these applets are meant to be secondary visual aids rather than critical components of a mathematical argument, the downside risk of such bugs is relatively low.")

#text("The process was ")#link("https://teorth.github.io/tao-web/apps/porting-legacy-applets.html")[#text("painless enough")]#text(" that I decided to also try coding some new apps, in addition to porting the old ones. Back in 1999 I had an ambitious idea for a visualization tool for special relativity; this was before the release of the software tool Inkscape, but the idea I had in mind was basically “Inkscape, but in Minkowski space”. I had even started ")#link("https://www.math.ucla.edu/~tao/java/Relativity/")[#text("writing Java code for this app")]#text(", but the code complexity became too much for me, and I abandoned the project. However, after a couple hours of “vibe coding” with an AI agent, I was finally able to generate an applet that matched the vision I had back in 1999, which ")#link("https://teorth.github.io/tao-web/apps/spacetime-diagram.html")[#text("can now be found here")]#text(". A summary of the conversation I had with the agent to generate this code ")#link("https://teorth.github.io/tao-web/apps/spacetime-diagram-making-of.html")[#text("can be found here")]#text(" (it has been edited down to remove a large number of tedious technical implementation reports). While I have playtested the app somewhat, I would be interested in receiving further feedback on this “alpha” version of the applet, as I am sure (especially given the LLM-generated nature of the code) that there are still some bugs and rough edges to be ironed out.")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-1.png")[#image("../assets/48ed5953fb813e4f0c9d23e321d26b4f05d5e28137dce8ed79543a17b188c7fe-1484ddbe5375c752043f409732e43300811b822dbe4b7e26f8f5bc8a4ec21c66.png", width: 90%)]
]

#text("After writing my blog post on the Gilbreath conjecture paper earlier today, I realized that I could similarly ask the agent to code a visualization tool for the Gilbreath conjecture to accompany the paper and blog post. After another few hours of conversation, this is now done; you can ")#link("https://teorth.github.io/tao-web/apps/gilbreath.html")[#text("try out the visualization here")]#text(". Again, the procedure was quite painless (see ")#link("https://teorth.github.io/tao-web/apps/gilbreath-making-of.html")[#text("this transcript of the process")]#text("), and I think I may add such interactive visualizations as supplements for future papers; as such supplements are not mission-critical to the core of the paper, I again feel that the downside risk of using guided interaction with LLM agents to generate such visualizations is acceptable.")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-2.png")[#image("../assets/e45bf297831438accc9bf61c1f2cfe0c00bea6d392124db661eae6270bc779dc-22b5fc186563b4ca061f3950cc40c11d3347bec1cc064dbf4df25064fea7f9a1.png", width: 90%)]
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d881a966306fc30a6e04943ec9b2cc31cfc3f442da7fcfc535fc4c8421b37765-88fdffb8dffcfff0ef987fdcfb6845f563faae647e70b26cf844d191d30dddb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 정동우")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693296")[#strong[#text("정동우")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("I noticed a small inconsistency in the per-panel boost controls. The displayed β value and the slider appear to be relative to the other panel, via `relBeta(i)` and the slider handler.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Yes, this is intentional; each of the reference frames is only described in terms of the other. There is a “laboratory” rest frame in the back end of the applet which is fixed, and is used for data storage purposes to record the state of the objects and reference frames that are visible, but I have deliberately kept this frame as an implementation detail hidden from the public interface in order to keep with the spirit of the principle of relativity. (With more effort, I could also have coded the data storage system to not rely on any laboratory rest frame at all, or to add such a frame to the data model, but I’m happy with the compromise of using preferred reference frames in the backend but not in the frontend.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693297")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("These are so beautiful! Maybe you could also add to or improve that visualization you made earlier: ")#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")[#text("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")]#text(". And, since there’s already an app for special relativity, would it be possible to make one for general relativity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("In fact I was midway through developing precisely that random variable app. Given the interest, I have published an in-progress version at ")#link("https://teorth.github.io/tao-web/apps/random-variables.html")[#text("https://teorth.github.io/tao-web/apps/random-variables.html")]#text(" , but I am still testing it, tweaking the design, and adding more features, so this should be viewed as a pre-alpha version. Any feedback would be very welcome!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Yay!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("You mentioned “[adding] such interactive visualizations as supplements for future papers”. Guessing you would provide links in papers and blog posts and host the apps on your site. How avoid the creeping obsolescence of your earlier, hand-coded applets?")

#text("Some projects, like OpenAI’s Symphony, are being shipped as specification files, written in Markdown. Feeding the spec to a coding agent generates the working app.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693315")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("When I ported my legacy Java 1.0 apps, I found that the agent was already able to understand the structure of the code just from inspecting it, as well as the HTML page containing it, and could use this to do a faithful port; my only guidance was, for the more complex apps, to build the app in stages, for instance building the math engine and test it first before buiding the GUI, but even this the agent largely handled on its own.")

#text("Probably the fact that the apps were performing standard mathematical tasks (such as Gaussian elimination) for which the LLM already had plenty of context about from training helped with this; I also like to think that my hand-written code was already structured in a logical enough fashion that the spec could be extracted from it without too much difficulty.")

#text("In general, I think that the precise language or spec that a given piece of software is written in has become far less relevant now that the friction and cost of porting from one language to another has gone down to nearly zero. As long as there is enough context provided (either through a formal spec, or other companion material, such as web pages discussing the software), and that the task being performed uses standard concepts that are already familiar to the agent, then LLMs do a perfectly adequate job of conversion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("ok sir what’s ur conclusion, is not worth to learn to code and does having domain knowledge or being software engineer has an advantage")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Definitely I consider my programming experience (whether it has been in Java, Python, Lean, or otherwise) as well as domain expertise (in, say special relativity) essential to being able to get useful code from the agent, and to be able to detect and diagnose issues. With the relativity app, for instance, being able to distinguish the data model (in which objects are recorded with respect to a fixed laboratory frame) and the user interface (where objects are only rendered in the two current reference frames) was essential in order to get the agent to understand my intention and to capture the spirit of the principle of relativity, which was one of the key initial motivations of that project. The high level code design decisions still remain in the “vibe coding” model; it is the lower level syntax and implementation issues that have been largely automated away. But most likely any new programmer will need to spend time working those lower levels by hand to acquire a solid grasp of the higher level code abstractions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-693368")[#strong[#text("Terence Tao AI Coding Agents Experiment: Two Dozen 1999 Java Applets Revived in Hours — and 2 Bugs He Never Knew About - Sean Kim — Arts and Tech")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")]

#text("[…] dozen applets ported from Java to JavaScript “in a matter of hours,” as he puts it in the original post, now running in any modern browser and hosted publicly on GitHub Pages. One detail worth flagging: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c468377144f25fa6779f0067feba68c953d8b299fe553b0f836174dd933947f-69e5c9ffeca36f03ef3737cb65abb5e04ed1efe89727aea1cd203170ab5fe878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2026/07/11/old-and-new-apps-via-modern-coding-agents/#comment-695679")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("The detail about the agent resurrecting two bugs the original applets never surfaced is the best argument in the piece for keeping the old code around: legacy artifacts double as test oracles. It also matches what heavy users of coding agents keep reporting – the interesting failures are rarely about generating code, they are about state, verification and quotas. That last one is underrated: usage windows and resets now interrupt long agentic sessions the way build times used to, which is why I track Codex reset windows on a small independent reference site (")#link("https://codexreset.today/")[#text("https://codexreset.today/")]#text(").")
]
