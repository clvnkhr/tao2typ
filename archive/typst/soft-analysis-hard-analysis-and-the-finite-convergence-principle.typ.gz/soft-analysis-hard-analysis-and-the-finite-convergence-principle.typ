// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:16:24.141347+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Soft analysis, hard analysis, and the finite convergence principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Soft analysis, hard analysis, and the finite convergence principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In the field of analysis, it is common to make a distinction between “hard”, “quantitative”, or “finitary” analysis on one hand, and “soft”, “qualitative”, or “infinitary” analysis on the other. “Hard analysis” is mostly concerned with finite quantities (e.g. the cardinality of finite sets, the measure of bounded sets, the value of convergent integrals, the norm of finite-dimensional vectors, etc.) and their ")#emph[#text("quantitative")]#text(" properties (in particular, upper and lower bounds). “Soft analysis”, on the other hand, tends to deal with more infinitary objects (e.g. sequences, measurable sets and functions, ")#link("http://en.wikipedia.org/wiki/Sigma_algebra")[#mi("\\sigma")#text("-algebras")]#text(", Banach spaces, etc.) and their ")#emph[#text("qualitative")]#text(" properties (convergence, boundedness, integrability, completeness, compactness, etc.). To put it more symbolically, hard analysis is the mathematics of ")#mi("\\varepsilon")#text(", ")#mi("N")#text(", ")#mi("O()")#text(", and ")#mi("\\leq")#super[#metadata(none) <tao-0571ae0f92f852c73bd4>#link(<tao-15d1bf3817061431954f>)[#text("[1]")]]#text("; soft analysis is the mathematics of 0, ")#mi("\\infty")#text(", ")#mi("\\in")#text(", and ")#mi("\\to")#text(".")

#text("At first glance, the two types of analysis look very different; they deal with different types of objects, ask different types of questions, and seem to use different techniques in their proofs. They even use")#super[#metadata(none) <tao-66a0e60a38292533e3b7>#link(<tao-2c7d80c96f435df03042>)[#text("[2] ")]]#text("different axioms of mathematics; the ")#link("http://en.wikipedia.org/wiki/Axiom_of_infinity")[#text("axiom of infinity")]#text(", the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Completeness_%28order_theory%29")[#text("Dedekind completeness axiom")]#text(" for the real numbers are often invoked in soft analysis, but rarely in hard analysis. (As a consequence, there are occasionally some finitary results that can be proven easily by soft analysis but are in fact ")#emph[#text("impossible")]#text(" to prove via hard analysis methods; the ")#link("http://en.wikipedia.org/wiki/Paris-Harrington_theorem")[#text("Paris-Harrington theorem")]#text(" gives a famous example.) Because of all these differences, it is common for analysts to specialise in only one of the two types of analysis. For instance, as a general rule (and with notable exceptions), discrete mathematicians, computer scientists, real-variable harmonic analysts, and analytic number theorists tend to rely on “hard analysis” tools, whereas ")#text("functional analysts,")#text(" operator algebraists, abstract harmonic analysts, and ergodic theorists tend to rely on “soft analysis” tools. (PDE is an interesting intermediate case in which ")#emph[#text("both")]#text(" types of analysis are popular and useful, though many practitioners of PDE still prefer to primarily use just one of the two types. Another interesting transition occurs on the interface between point-set topology, which largely uses soft analysis, and metric geometry, which largely uses hard analysis. Also, the ineffective bounds which crop up from time to time in analytic number theory are a sort of hybrid of hard and soft analysis. Finally, there are examples of evolution of a field from soft analysis to hard (e.g. Banach space geometry) or vice versa (e.g. recent developments in extremal combinatorics, particularly in relation to the regularity lemma).)")

#metadata(none) <tao-cdcae5c984a376fecbca>

#text("It is fairly well known that the ")#emph[#text("results ")]#text("obtained by hard and soft analysis respectively can be connected to each other by various “correspondence principles” or “compactness principles”. It is however my belief that the relationship between the two types of analysis is in fact much closer")#super[#metadata(none) <tao-885fcad64b166bd7a2f4>#link(<tao-b2e6b3530322788ef36c>)[#text("[3]")]]#text(" than just this; in many cases, qualitative analysis can be viewed as a convenient abstraction of quantitative analysis, in which the precise dependencies between various finite quantities has been efficiently concealed from view by use of infinitary notation. Conversely, quantitative analysis can often be viewed as a more precise and detailed refinement of qualitative analysis. Furthermore, a method from hard analysis often has some analogue in soft analysis and vice versa, though the language and notation of the analogue may look completely different from that of the original. I therefore feel that it is often profitable for a practitioner of one type of analysis to learn about the other, as they both offer their own strengths, weaknesses, and intuition, and knowledge of one gives more insight")#super[#metadata(none) <tao-6d495777cca9c0c52d0b>#link(<tao-67d2e46a7a5912b5767a>)[#text("[4]")]]#text(" into the workings of the other. I wish to illustrate this point here using a simple but not terribly well known result, which I shall call the “finite convergence principle” (thanks to ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" for suggesting this name; ")#link("http://research.microsoft.com/en-us/um/people/jchayes/")[#text("Jennifer Chayes")]#text(" has also suggested the “")#link("http://en.wikipedia.org/wiki/Metastability")[#text("metastability")]#text(" principle”). It is the finitary analogue of an utterly trivial infinitary result – namely, that every bounded monotone sequence converges – but sometimes, a careful analysis of a trivial result can be surprisingly revealing, as I hope to demonstrate here.")

#text("Before I discuss this principle, let me first present an informal, incomplete, and inaccurate “dictionary” between soft and hard analysis, to try to give a rough idea of the (partial) correspondences between the two:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Soft analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Hard analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("x finite")],
table.cell(colspan: 1, rowspan: 1)[#text("x bounded (e.g. x = O(1))")],
table.cell(colspan: 1, rowspan: 1)[#text("x vanishes")],
table.cell(colspan: 1, rowspan: 1)[#text("x small (e.g. ")#tao-math("\\left|x\\right| \\leq \\varepsilon", block: false)#text(")")],
table.cell(colspan: 1, rowspan: 1)[#text("x infinite")],
table.cell(colspan: 1, rowspan: 1)[#text("x large (e.g. ")#tao-math("\\left|x\\right| \\geq N", block: false)#text(")")],
table.cell(colspan: 1, rowspan: 1)[#mi("x_n \\to 0")],
table.cell(colspan: 1, rowspan: 1)[#text("Quantitative decay bound (e.g. ")#mi("x_n = O(n^{-c})")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#mi("x_n")#text(" is convergent")],
table.cell(colspan: 1, rowspan: 1)[#mi("x_n")#text(" is metastable (see below)")],
table.cell(colspan: 1, rowspan: 1)[#text("f uniformly continuous")],
table.cell(colspan: 1, rowspan: 1)[#text("Lipschitz or Hölder bound on f (e.g. ")#tao-math("\\left|f(x)-f(y)\\right| = O(\\left|x-y\\right|)", block: false)#text(")")],
table.cell(colspan: 1, rowspan: 1)[#mi("f \\in X")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("\\left\\|f\\right\\|_X = O(1)", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("E compact")],
table.cell(colspan: 1, rowspan: 1)[#text("Metric entropy bound on E")],
table.cell(colspan: 1, rowspan: 1)[#text("E is Lebesgue measurable")],
table.cell(colspan: 1, rowspan: 1)[#text("E is (quantitatively) approximated by bounded complexity sets")],
table.cell(colspan: 1, rowspan: 1)[#text("V is generated by S")],
table.cell(colspan: 1, rowspan: 1)[#text("V is an algorithm initialised by S")],
table.cell(colspan: 1, rowspan: 1)[#text("u locally extremises F(u)")],
table.cell(colspan: 1, rowspan: 1)[#text("u has no nearby competitor with significantly better value of F")]
)

#text("One can draw two conclusions from this table:")

#enum(start: 1, 
[#text("Soft analysis statements can often be stated both succinctly and rigorously, by using precisely defined and useful concepts (e.g. compactness, measurability, etc.). In hard analysis, one usually has to sacrifice one or the other: either one is rigorous but verbose (using lots of parameters such as ")#mi("\\varepsilon")#text(", N, etc.), or succinct but “fuzzy” (using intuitive but vaguely defined concepts such as “size”, “complexity”, “nearby”, etc.).")],
[#text("A single concept in soft analysis can have multiple hard analysis counterparts; a “naive” translation of a statement in soft analysis into hard analysis may be incorrect. (In particular, one should not use the above table blindly to convert from one to the other.)")]
)

#text("Anyway, back to the finite convergence principle. The infinite convergence principle is well known, though perhaps not by this name, to anyone who has taken undergraduate analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Infinite convergence principle.")]#text(" Every bounded monotone sequence ")#mi("x_n")#text(" of real numbers is convergent.")
]

#text("This basic principle – essentially equivalent to the Dedekind completeness axiom for the real numbers – is of course fundamental to many parts of infinitary analysis, most obviously in the theory of infinite sequences and series, but it also is implicit in just about any context in which one studies an “infinite” object (e.g. an infinite-dimensional vector space) by expressing it as a monotone limit of “finite” objects. It is undoubtedly an important tool in soft analysis. What, then, is its counterpart in hard analysis?")

#text("We will answer this question presently, but let us first make the infinite convergence principle a bit more quantitative. We may as well normalise the bounded sequence ")#mi("x_n")#text(" to lie between 0 and 1. Expanding out the “epsilon-delta” definition of convergence, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Infinite convergence principle (again).")]#text(" If ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq 1")#text(", then there exists a real number x such that for every ")#mi("\\varepsilon > 0")#text(", there exists an N such that ")#tao-math("\\left|x_n-x\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("n \\geq N")#text(".")
]

#text("There are quite a lot of quantifiers here. One can cut down the complexity a little bit by replacing the notion of a convergent sequence with that of a ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy sequence")]#text(". This lets us eliminate the need for a limit x, which does not have an obvious finitary counterpart. So we get")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Infinite convergence principle (yet again).")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq 1")#text(", there exists an N such that ")#tao-math("\\left|x_n-x_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("n,m \\geq N")#text(".")
]

#text("Note now that one does not need the real number system to make this principle both meaningful and non-trivial; the principle already works quite well when restricted to the rationals. (Exercise: prove this principle for the rationals without constructing the real number system.) Informally speaking, this principle asserts that every bounded monotone sequence is eventually stable up to error ")#mi("\\varepsilon")#text(".")

#text("Now let’s try to find the finitary (quantitative) equivalent of this principle. The most naive thing to do is simply to replace the infinite sequence by a finite sequence, thus")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Finite convergence principle (first attempt).")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq x_M \\leq 1")#text(", there exists an N such that ")#tao-math("\\left|x_n-x_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq M")#text(".")
]

#text("But this is trivially true; one can simply set N equal to M (or any number larger than M). So one needs to strengthen the claim. What about making N be independent of M, and only dependent on ")#mi("\\varepsilon")#text("?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Finite convergence principle (second attempt).")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq x_M \\leq 1")#text(", there exists an ")#mi("N = N(\\varepsilon)")#text(" depending only on ")#mi("\\varepsilon")#text(" such that ")#tao-math("\\left|x_n-x_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq M")#text(".")
]

#text("But this is trivially false; consider for instance a sequence ")#mi("x_i")#text(" which equals zero except at i=M, at which point we jump up to ")#mi("x_M = 1")#text(". We are not going to get the Cauchy property unless we set N to be as large as M… but we can’t do that if we only want N to depend on ")#mi("\\varepsilon")#text(".")

#text("So, is there anything non-trivial that one can say at all about finite bounded monotone sequences? Well, we have the ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Pigeonhole principle.")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq x_M \\leq 1")#text(" is such that ")#mi("M \\geq 1/\\varepsilon + 1")#text(", there exists an ")#mi("1 \\leq N < M")#text(" such that ")#tao-math("\\left|x_{N+1} - x_N\\right| \\leq \\varepsilon", block: false)#text(".")
]

#text("Indeed, if the gaps between each element ")#mi("x_N")#text(" of the sequence and the next ")#mi("x_{N+1}")#text(" were always larger than ")#mi("\\varepsilon")#text(", then ")#mi("x_M - x_1")#text(" would exceed ")#mi("(M-1)\\epsilon \\geq 1")#text(", a contradiction. This principle is true, but it is too weak to be considered a true finitary version of the infinite convergence principle; indeed, we see that the pigeonhole principle easily implies")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Weak infinite convergence principle.")]#text(" If ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq 1")#text(", then ")#tao-math("\\liminf_{n \\to \\infty} \\left|x_{n+1}-x_n\\right| = 0", block: false)#text(".")
]

#text("but does not obviously imply the full infinite convergence principle.")

#text("The problem is that the pigeonhole principle only establishes ")#emph[#text("instantaneous")]#text(" stability of the sequence at some point n, whereas the infinite convergence principle concludes the ")#emph[#text("permanent")]#text(" stability of the sequence after some point N. To get a better finitary match to the infinite convergence principle, we need to extend the region of stability that the pigeonhole principle offers. Now, one can do some trivial extensions such as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Pigeonhole principle (second version).")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("k \\geq 1")#text(" and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq x_M \\leq 1")#text(" is such that ")#mi("M \\geq k/\\varepsilon + k")#text(", there exists ")#mi("1 \\leq N < N+k \\leq M")#text(" such that ")#tao-math("\\left|x_n - x_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq N+k")#text(",")
]

#text("which one can quickly deduce from the first pigeonhole principle by considering the sparsified sequence ")#mi("x_k, x_{2k}, x_{3k}, \\ldots")#text(". But this is only a little bit better, as it now gives the infinitary statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Slightly less weak infinite convergence principle.")]#text(" If ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq 1")#text(", then ")#tao-math("\\liminf_{n \\to \\infty} \\left|x_{n+k}-x_n\\right| = 0", block: false)#text(" for all k,")
]

#text("but is still not strong enough to imply the infinite convergence principle in its full strength. Nevertheless, it shows that we can extend the realm of stability offered by the pigeonhole principle. One can for instance sparsify further, replacing n+k with 2n:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Pigeonhole principle (third version).")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq x_M \\leq 1")#text(" is such that ")#mi("M \\geq 2^{1/\\varepsilon + 1}")#text(", there exists ")#mi("1 \\leq N < M \\leq 2N")#text(" such that ")#tao-math("\\left|x_n - x_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq 2N")#text(".")
]

#text("This can be proven by applying the first version of the pigeonhole principle to the sparsified sequence ")#mi("x_1, x_2, x_4, x_8, \\ldots")#text(". This corresponds to an infinite convergence principle in which the conclusion is that ")#tao-math("\\liminf_{n \\to \\infty} \\left|x_{2n} - x_n\\right| = 0", block: false)#text(".")

#text("One can of course keep doing this, achieving various sparsified versions of the pigeonhole principle which each capture part of the infinite convergence principle. To get the full infinite convergence principle, one cannot use any single such sparsified version of the pigeonhole principle, but instead must take ")#strong[#text("all of them at once")]#text(". This is the full strength of the finite convergence principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Finite convergence principle")]#strong[#text(".")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("F: {\\Bbb Z}_+ \\to {\\Bbb Z}_+")#text(" is a function and ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq x_M \\leq 1")#text(" is such that ")#mi("M")#text(" is sufficiently large depending on F and ")#mi("\\varepsilon")#text(", then there exists ")#mi("1 \\leq N < N+F(N) \\leq M")#text(" such that ")#tao-math("\\left|x_n - x_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq N+F(N)")#text(".")
]

#text("This principle is easily proven by appealing to the first pigeonhole principle with the sparsified sequence ")#mi("x_{i_1}, x_{i_2}, x_{i_3}, \\ldots")#text(" where the indices are defined recursively by ")#mi("i_1 := 1")#text(" and ")#mi("i_{j+1} := i_j + F(i_j)")#text(". This gives an explicit bound on M as ")#mi("M := i_{\\lfloor 1/\\varepsilon\\rfloor + 1}")#text(". Note that the first pigeonhole principle corresponds to the case ")#mi("F(N) \\equiv 1")#text(", the second pigeonhole principle to the case ")#mi("F(N) \\equiv k")#text(", and the third to the case ")#mi("F(N) \\equiv N")#text(". A particularly useful case for applications is when F grows exponentially in N, in which case M grows ")#link("http://en.wikipedia.org/wiki/Tetration")[#text("tower-exponentially")]#text(" in ")#mi("1/\\varepsilon")#text(".")

#text("Informally, the above principle asserts that any sufficiently long (but finite) bounded monotone sequence will experience arbitrarily high-quality amounts of ")#link("http://en.wikipedia.org/wiki/Metastability")[#text("metastability")]#text(" with a specified error tolerance ")#mi("\\varepsilon")#text(", in which the duration F(N) of the metastability exceeds the time N of onset of the metastability by an arbitrary function F which is specified in advance.")

#text("Let us now convince ourselves that this is the true finitary version of the infinite convergence principle, by deducing them from each other:")

#strong[#text("The finite convergence principle implies the infinite convergence principle")]#text(". Suppose for contradiction that the infinite convergence principle failed. Untangling the quantifiers, this asserts that there is an infinite sequence ")#mi("0 \\leq x_1 \\leq x_2 \\leq \\ldots \\leq 1")#text(" and an ")#mi("\\varepsilon > 0")#text(" with the property that, given any positive integer N, there exists a larger integer ")#mi("N+F(N)")#text(" such that ")#mi("x_{N+F(N)} - x_N > \\varepsilon")#text(". But this contradicts the finite convergence principle. ")#mi("\\Box")

#strong[#text("The infinite convergence principle implies the finite convergence principle")]#text(". Suppose for contradiction that the finite convergence principle failed. Untangling the quantifiers, this asserts that there exists ")#mi("\\varepsilon > 0")#text(" and a function F, together with a collection ")#mi("0 \\leq x^{(i)}_1 \\leq \\ldots \\leq x^{(i)}_{M_i} \\leq 1")#text(" of bounded monotone sequences whose length ")#mi("M_i")#text(" goes to infinity, such that for each one of these sequences, there does ")#strong[#text("not")]#text(" exist ")#mi("1 \\leq N < N+F(N) \\leq M_i")#text(" such that ")#tao-math("\\left|x^{(i)}_n - x^{(i)}_m\\right| \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq N+F(N)")#text(". Let us extend each of the finite bounded sequences to infinite bounded sequences in some arbitrary manner, e.g. defining ")#mi("x^{(i)}_n = 1")#text(" whenever ")#mi("n > M_i")#text(". The space of all bounded sequences is well-known")#super[#metadata(none) <tao-eee263f7c59517945529>#link(<tao-3a59bd84c27bba1ea4b7>)[#text("[5]")]]#text(" to be ")#link("http://en.wikipedia.org/wiki/Sequentially_compact")[#text("sequentially compact")]#text(" in the ")#link("http://en.wikipedia.org/wiki/Product_topology")[#text("product topology")]#text(", thus after refining the i labels to a subsequence if necessary, we can assume that the sequences ")#mi("(x^{(i)}_n)_{n=1}^\\infty")#text(" converge in the product topology (i.e. pointwise) to a new limit sequence ")#mi("(x_n)_{n=1}^\\infty")#text(". Since each of the original sequences were bounded in the interval [0,1] and monotone, we see that the limit sequence is also. Furthermore, we claim that there does not exist any ")#mi("N \\geq 1")#text(" for which ")#tao-math("\\left|x_n - x_m\\right| < \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq N+F(N)")#text(". Indeed, if this were the case, then by pointwise convergence we would also have ")#tao-math("\\left|x^{(i)}_n - x^{(i)}_m\\right| < \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq N+F(N)")#text(" and all sufficiently large i, but this contradicts the construction of the ")#mi("x^{(i)}_n")#text(". But now we see that this infinite bounded monotone sequence ")#mi("(x_n)_{n=1}^\\infty")#text(" contradicts the infinite convergence principle. ")#mi("\\Box")

#text("One can draw some morals from the above discussion:")

#enum(start: 1, 
[#text("The finitary version of an infinitary statement can be significantly more verbose and ugly-looking than the infinitary original, and the arrangement of quantifiers becomes crucial.")],
[#text("The “naive” finitisation of an infinitary statement is often not the correct one.")],
[#text("While the finitary version of an infinitary statement is indeed quantitative, the bounds obtained can be quite poor (e.g. tower-exponential or worse).")],
[#text("The deduction of the infinitary statement from the finitary one is quite short, as long as one is willing to work indirectly (arguing by contradiction).")],
[#text("The deduction of the finitary statement from the infinitary one is a bit more complicated, but still straightforward, and relies primarily on compactness.")],
[#text("In particular, the equivalence of the finitary and infinitary formulations requires a non-trivial amount of infinitary mathematics (though in this particular case, we can at least leave the ultrafilters out of it).")]
)

#text("These morals apply not only to the finite and infinite convergence principle, but to many other pairs of finitary and infinitary statements, for instance ")#link("http://en.wikipedia.org/wiki/Szemeredi%27s_theorem")[#text("Szemerédi’s theorem")]#text(" on one hand and the ")#emph[#text("Furstenberg recurrence theorem")]#text(" on the other, as briefly discussed in ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("my Simons lecture on these topics")]#text(". (In these contexts, the correspondence between the finitary and infinitary statements is known as the ")#emph[#text("Furstenberg correspondence principle")]#text(".)")

#heading(level: 1)[#text("— Applications —")]

#text("So, we’ve now extracted a quantitative finitary equivalent of the infinitary principle that every bounded monotone sequence converges. But can we actually ")#emph[#text("use")]#text(" this finite convergence principle for some non-trivial finitary application? The answer is a definite ")#strong[#text("yes")]#text(": the finite convergence principle (implicitly) underlies the famous ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", which is a major tool in graph theory, and also underlies some rather less well known regularity lemmas, such as the ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("arithmetic regularity lemma of Green")]#text(". More generally, this principle seems to often arise in any finitary application in which tower-exponential bounds are inevitably involved.")

#text("Before plunging into these applications, let us first establish a Hilbert space version")#super[#metadata(none) <tao-5cb6008ceea7110a3e18>#link(<tao-d563ef6e7d15813d2187>)[#text("[6]")]]#text(" of the convergence principle. Given a (closed) subspace X of a Hilbert space H, and a vector ")#mi("v \\in H")#text(", let ")#mi("\\pi_X v")#text(" be the ")#link("http://en.wikipedia.org/wiki/Orthogonal_projection")[#text("orthogonal projection")]#text(" from v onto X. If X is finite dimensional, then this projection can be defined in a finitary way, for instance by using the ")#link("http://en.wikipedia.org/wiki/Gram%E2%80%93Schmidt_process")[#text("Gram-Schmidt orthogonalisation procedure")]#text(" to X. If X is infinite dimensional, then even the existence of the orthogonal projection is not completely trivial, and in fact relies ultimately on the infinite convergence principle. Closely related to the existence of this projection is the following monotone continuity property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Hilbert space infinite convergence principle")]#text(". Let ")#mi("0 \\subset X_1 \\subset X_2 \\subset \\ldots \\subset H")#text(" be a nested sequence of subspaces of a Hilbert space H, and let ")#mi("X := \\overline{\\bigcup_{n=1}^\\infty X_n}")#text(" be the monotone closed limit of the ")#mi("X_n")#text(". Then for any vector v, ")#mi("\\pi_{X_n} v")#text(" converges strongly in H to ")#mi("\\pi_X v")#text(".")
]

#text("As with the infinite convergence principle in [0,1], there is a Cauchy sequence version which already captures the bulk of the content:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Hilbert space infinite convergence principle (again)")]#text(". Let ")#mi("0 \\subset X_1 \\subset X_2 \\subset \\ldots \\subset H")#text(" be a nested sequence of subspaces of a Hilbert space H, and let ")#mi("\\varepsilon > 0")#text(". Then for any vector v there exists N such that ")#tao-math("\\left\\| \\pi_{X_n} v - \\pi_{X_m} v \\right\\|_H^2 \\leq \\varepsilon", block: false)#text(" for all ")#mi("n,m \\geq N")#text(".")
]

#text("One can deduce this principle from the analogous principle in [0,1] by first normalising ")#tao-math("\\left\\|v\\right\\|_H = 1", block: false)#text(", and then observing from Pythagoras’ theorem that ")#tao-math("\\left\\| \\pi_{X_n} v \\right\\|_H^2", block: false)#text(" (which one should view as the ")#emph[#text("energy")]#text(" of ")#mi("X_n")#text(" as measured relative to v) is a bounded monotone sequence from 0 to 1. Applying the infinite convergence principle, followed by Pythagoras’ theorem yet again, we obtain the claim. Once one sees this, one immediately concludes that there is also a finitary equivalent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Hilbert space finite convergence principle.")]#text(" If ")#mi("\\varepsilon > 0")#text(" and ")#mi("F: {\\Bbb Z}_+ \\to {\\Bbb Z}_+")#text(", and ")#mi("0 \\subset X_1 \\subset X_2 \\subset \\ldots X_M \\subset H")#text(" is such that M is sufficiently large depending on F and ")#mi("\\varepsilon")#text(", then for any vector v with ")#tao-math("\\left\\|v\\right\\|_H \\leq 1", block: false)#text(" there exists ")#mi("1 \\leq N \\leq N + F(N) \\leq M")#text(" such that ")#tao-math("\\left\\| \\pi_{X_n} v - \\pi_{X_m} v \\right\\|_H^2 \\leq \\varepsilon", block: false)#text(" for all ")#mi("N \\leq n,m \\leq N+F(N)")#text(".")
]

#text("Informally, given a long enough sequence of nested subspaces, and a given bounded vector v, one can find an arbitrarily good region of metastability in the orthogonal projections of v into these subspaces.")

#text("From this principle one can then quickly deduce the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" as follows. Let G = (V,E) be a graph. One can think of the adjacency matrix ")#mi("1_E")#text(" of this graph as an element of the (finite-dimensional) Hilbert space ")#mi("L^2(V \\times V)")#text(", where the product space ")#mi("V \\times V")#text(" is given normalised counting measure (and the discrete sigma-algebra ")#mi("2^V \\times 2^V")#text("). We can construct a nested sequence ")#mi("{\\mathcal B}_0 \\subset {\\mathcal B}_1 \\subset {\\mathcal B}_2 \\subset \\ldots")#text(" of ")#mi("\\sigma")#text("-algebras in ")#mi("V")#text(" (which one can think of as a sequence of increasingly fine partitions of V), together with the attendant sequence ")#mi("L^2({\\mathcal B}_0 \\times {\\mathcal B}_0) \\subset L^2({\\mathcal B}_1 \\times {\\mathcal B}_1) \\subset \\ldots")#text(" of subspaces (this corresponds to functions on ")#mi("V \\times V")#text(" which are constant on any product of pair of cells in the partition), by the following greedy algorithm")#super[#metadata(none) <tao-15d3e7e362e67832619e>#link(<tao-2a7a7897ecb4392c905d>)[#text("[7]")]]#text(":")

#enum(start: 1, 
[#text("Initialise ")#mi("{\\mathcal B}_0 := \\{ \\emptyset, V\\}")#text(" to be the trivial ")#mi("\\sigma")#text("-algebra (i.e. the trivial partition).")],
[#text("Given ")#mi("{\\mathcal B}_n")#text(", let ")#mi("f_n := {\\mathbb E}( 1_E | {\\mathcal B}_n \\times {\\mathcal B}_n)")#text(" be the orthogonal projection of ")#mi("1_E")#text(" to the space ")#mi("L^2({\\mathcal B}_n \\times {\\mathcal B}_n)")#text(" (thus the value on any product of cells is just the edge density between that pair of cells), and let ")#mi("g_n := 1_E - f_n")#text(" be the deviation of the graph from its density.")],
[#text("Let ")#mi("A_n, B_n")#text(" be sets in V which maximise the discrepancy ")#tao-math("\\frac{1}{\\left|V\\right|^2} \\sum_{a \\in A_n} \\sum_{b \\in B_n} g_n(a,b)", block: false)#text(".")],
[#text("Let ")#mi("{\\mathcal B}_{n+1}")#text(" be the ")#mi("\\sigma")#text("-algebra generated by ")#mi("{\\mathcal B}_n")#text(" and ")#mi("A_n, B_n")#text(". Now increment n by n+1 and return to Step 2.")]
)

#text("Let ")#mi("\\varepsilon > 0")#text(" and ")#mi("F: {\\Bbb Z}_+ \\to {\\Bbb Z}_+")#text(" be a function. Applying the Hilbert space finite convergence principle to the above sequence of vector spaces, we obtain some N with some bounded size (depending on ")#mi("\\varepsilon")#text(" and F) such that")

#align(center)[#tao-math("\\left\\| f_n - f_m \\right\\|_{L^2(V \\times V)} \\leq \\varepsilon^2", block: false)#text(" (*)")]

#text("for all ")#mi("N \\leq n, m \\leq N+F(N)")#text(". By a further application of the pigeonhole principle (for Hilbert spaces), one can find ")#mi("N \\leq n \\leq N+F(N)")#text(" such that")

#align(center)[#tao-math("\\left\\| f_{n+1} - f_n\\right\\|_{L^2(V \\times V)} \\leq \\varepsilon^2/F(N)", block: false)#text(".")]

#text("What this basically means is that the partition ")#mi("{\\mathcal B}_n")#text(" is very regular, in that even the greediest way to refine this partition does not significantly capture any more of the fluctuations of the graph G. By choosing F to be a suitable exponentially growing function, one can make the regularity of this partition exceed the number of cells (which is basically ")#mi("2^{2N}")#text(") in the partition ")#mi("{\\mathcal B}_N")#text(", which is “within epsilon” of the partition ")#mi("{\\mathcal B}_n")#text(" in the sense of (*). Putting all this together, one can get a strong version of the Szemerédi regularity lemma, which implies the usual formulation by a simple argument; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2212136")[#text("my paper on this topic")]#text(" for further discussion. The choice of F being exponential is what results in the notorious tower-exponential bounds in this regularity lemma (which are necessary, thanks to a ")#link("http://www.ams.org/mathscinet-getitem?mr=1445389")[#text("result of Gowers")]#text("). But one can reduce F to, say, a polynomial, resulting in more civilised bounds but with a weaker regularity conclusion. Such a “weak regularity lemma” was for instance established ")#link("http://www.ams.org/mathscinet-getitem?mr=1723039")[#text("by Frieze and Kannan")]#text(", and also underlies the “generalised Koopman von Neumann theorem” which is a key component of ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("my result with Ben Green")]#text(" establishing long arithmetic progressions in the primes. In the opposite direction, various flavours of “strong regularity lemma” have appeared in the literature, for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=2181610")[#text("this paper of Alon and Shapira")]#text(", and also turn out to be convenient ways to formulate hypergraph versions of the regularity lemma of adequate strength to imply non-trivial theorems (such as Szemerédi’s theorem).")

#text("Rather than using sets which maximise discrepancy, one can also use sublevel sets of the eigenvectors of the adjacency matrix corresponding to the largest eigenvalues of the matrix to generate the partition; see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1674741")[#text("paper of Frieze and Kannan")]#text(" for details of a closely related construction.")

#text("The appearance of spectral theory (eigenvalues and eigenvectors) into this topic brings one in contact with Fourier analysis, especially if one considers ")#link("http://en.wikipedia.org/wiki/Circulant_matrix")[#text("circulant matrices")]#text(" (which correspond in graph-theoretic terms to ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graphs")]#text(" on a cyclic group). This leads us towards the ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("arithmetic regularity lemma of Green")]#text(", which regularises a bounded function f on a finite abelian group G in terms of a partition generated by the sublevel sets (Bohr sets) of a bounded number of characters; the precise formulation is a bit lengthy to state properly, although it simplifies substantially in the “finite field model” case when G is a vector space over a small finite field (e.g. ")#mi("{\\Bbb F}_2")#text("). This arithmetic regularity lemma can also be established using the finite convergence principle (in either the numerical form or the Hilbert space form). Indeed, if we let ")#mi("H = L^2(G)")#text(" and let ")#mi("V_n")#text(" be the vector space generated by the characters associated to the n largest Fourier coefficients of f, then by applying the finite convergence principle (with v = f) we can locate a metastable region, where there is not much going on (in an ")#mi("L^2")#text(" sense) between ")#mi("V_N")#text(" and ")#mi("V_{N+F(N)}")#text(" for some (exponentially growing) function F, thus there is a “spectral gap” of sorts between the N largest Fourier coefficients and the coefficients ranked N+F(N) and beyond. The sublevel sets of characters associated to the N largest coefficients can then be used to regularise the original function f. Similar ideas also appear in ")#link("http://www.ams.org/mathscinet-getitem?mr=853455")[#text("an old paper of Bourgain")]#text(", and in a paper of ")#link("http://www.arxiv.org/pdf/math.CA/0601565")[#text("Green and Konyagin")]#text(".")

#heading(level: 1)[#text("— A non-finitisable statement —")]

#text("One may think from the above discussion that every infinitary statement concerning, say, the natural numbers, has a finitary analogue which is equivalent to it. It turns out that this is not quite the case (and in fact some subtle issues in logic come in), even for very “natural” and “non-pathological” infinitary statements. In particular, the following innocuous-looking infinitary statement is basically non-finitisable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Infinite pigeonhole principle. ")]#text("If the natural numbers are divided into finitely many colour classes, then one of the colour classes is infinite.")
]

#text("This principle is of course a triviality in the infinitary world, and there are some obvious candidates for finitary versions (e.g. the finite pigeonhole principle), but they are not equivalent to the infinitary principle the same way that the finite convergence principle is equivalent to the infinite convergence principle; there is a failure of compactness here. There is a finitary version (of sorts), but it is somewhat difficult to state. Define a ")#emph[#text("set function ")]#text("to be any function f which takes a finite set A of natural numbers as input, and returns a natural number F(A) as output. Let us say that a set function F is ")#emph[#text("asymptotically stable near infinite sets")]#super[#metadata(none) <tao-fa49745befb079975b37>#link(<tao-62852170b88a13fb0235>)[#text("[8]")]]#text(" if, given any sequence ")#mi("A_1, A_2, A_3, \\ldots")#text(" of finite sets of natural numbers which converges to an infinite set ")#mi("A")#text(" in the sense that for any finite set I, ")#mi("A_n \\cap I = A \\cap I")#text(" for all sufficiently large n, the numbers ")#mi("F(A_n)")#text(" are constant for sufficiently large n. For instance, the “least element” set function ")#mi("f(A) = \\inf( A )")#text(" (adopting the non-standard convention that the infimum of the empty set is 0) is asymptotically stable, but the “cardinality” set function ")#tao-math("f(A) = \\left|A\\right|", block: false)#text(" is not. Anyway, the correct “finitary” version of the infinite pigeonhole principle is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("“Finitary” infinite pigeonhole principle. ")]#text("Let F be a set function that is asymptotically stable near infinite sets, and let k be a positive integer. Then there exists a positive integer N with the property that whenever the set {1,…,N} is divided into k colour classes, at least one of the colour classes A has the property that |A| > F(A).")
]

#text("It is a good exercise to see that this principle is equivalent to the infinite pigeonhole principle. Note that the plain old pigeonhole principle essentially corresponds to the case when F is a constant function – and is thus definitely a very special case. The case when ")#mi("F(A) = f(\\inf( A ))")#text(" for some fixed function f is already very interesting – it is the 1-uniform case of a “strong Ramsey theorem”and is barely provable by finitary means (try it, say for k=10 and ")#mi("F(A) := \\inf(A) + 10")#text(". What quantitative bound for N do you get?), although the general case of that theorem is not (but does follow easily from the above principle), thanks to the ")#link("http://en.wikipedia.org/wiki/Paris-Harrington_theorem")[#text("Paris-Harrington theorem")]#text(". The assumption of asymptotic stability of F near infinite sets is necessary, as one can see by considering the counterexample F(A) := |A|.")

#text("I am enclosing “finitary” in quotes because while most of the assertion of this principle is finitary, one part still is not, which is the notion of “asymptotically stable near infinite sets”. This is a notion which cannot be precisely formulated in a purely finitary manner, even though the notion of a set function is basically a finitary concept (ignoring for now a subtle issue about what “function” means). If one insists on working in a finitary setting, then one can recast the infinite pigeonhole principle as a ")#link("http://en.wikipedia.org/wiki/Axiom_schema")[#text("schema")]#text(" of finitary principles, one for each set function F that is asymptotically stable near infinite sets, but in order to work out exactly which set functions are asymptotically stable near infinite sets or not requires infinitary mathematics. (And for some (constructible, well-defined) set functions, the asymptotic stability near infinite sets is ")#emph[#text("undecidable")]#text("; this fact is closely related to the undecidability of the ")#link("http://en.wikipedia.org/wiki/Halting_problem")[#text("halting problem")]#text(" and is left as an exercise to the reader.)")

#text("The topic of exactly which statements in infinitary mathematics are “truly infinitary” is a fascinating one, and is basically a question in ")#link("http://en.wikipedia.org/wiki/Reverse_mathematics")[#text("reverse mathematics")]#text(", but we will not be able to discuss it here.")

#text("(I am indebted to ")#link("http://en.wikipedia.org/wiki/Harvey_Friedman")[#text("Harvey Friedman")]#text(" for discussions on the Paris-Harrington theorem and the infinite pigeonhole principle.)")

#heading(level: 1)[#text("— Footnotes —")]

#text("(N.B. Footnotes were created following the suggestions from ")#link("http://santoki.wordpress.com/2007/02/12/footnotes-the-long-way/")[#text("this post")]#text(" by ")#link("http://santoki.wordpress.com/")[#text("santoki")]#text(".)")

#metadata(none) <tao-15d1bf3817061431954f>#link(<tao-0571ae0f92f852c73bd4>)[#text("[1]")]#text(" One can subdivide hard analysis into further subcategories by inspecting what kind of inequalities are used. There is “exact hard analysis” where one really uses ")#mi("\\leq")#text("; “quasi-exact hard analysis” in which one is willing to lose absolute constants (and so one sees notation such as O(), ")#mi("\\lesssim")#text(", or ")#mi("\\ll")#text("); “logarithmically coarse hard analysis” in which one is willing to lose quantities such as ")#mi("\\log^{O(1)} N")#text(" which are “logarithmic” in some key parameter N; and “polynomially coarse hard analysis” in which one is willing to lose quantities such as ")#mi("N^{O(1)}")#text(" which are polynomial in key parameters. Finally, there is “")#link("http://en.wikipedia.org/wiki/Coarse_structure")[#text("coarse analysis")]#text("” in which one is willing to lose arbitrary functions of key parameters. The relationships between these flavours of hard analysis are interesting, but will have to wait to be discussed elsewhere.")

#metadata(none) <tao-2c7d80c96f435df03042>#link(<tao-66a0e60a38292533e3b7>)[#text("[2]")]#text(" One can use these axioms to make finer distinctions, for instance “strongly finitary” analysis, in which one is not even willing to use real numbers, but instead only works with finite complexity numbers (e.g. rationals), and “strongly infinitary” analysis, in which one freely uses the axiom of choice (or related concepts such as ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text("). There are also hybrids between finitary and infinitary analysis, such as “pre-infinitary” analysis, in which one takes sequences of increasingly large or complex objects, and uses phrases such as “passing to a subsequence if necessary” a lot, but does not actually “jump to the limit”; we also have “pseudo-finitary” analysis, of which ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("non-standard analysis")]#text(" is the most prominent example, in which infinitary methods are re-expressed using infinitesimals or other pseudo-finitary objects. Again, these distinctions will have to wait to be discussed elsewhere.")

#metadata(none) <tao-b2e6b3530322788ef36c>#link(<tao-885fcad64b166bd7a2f4>)[#text("[3]")]#text(" There are rigorous results from ")#link("http://en.wikipedia.org/wiki/Proof_theory")[#text("proof theory")]#text(", such as ")#link("http://en.wikipedia.org/wiki/Herbrand%27s_theorem_%28proof_theory%29")[#text("Herbrand’s theorem")]#text(", which can allow one to automatically convert certain types of qualitative arguments into quantitative ones")#text(", but there appears to be only a small amount of literature applying these general results in logic to actual soft analysis arguments")#text(". (See the comments to this post for some recent developments in this area.)")

#metadata(none) <tao-67d2e46a7a5912b5767a>#link(<tao-6d495777cca9c0c52d0b>)[#text("[4]")]#text(" For instance, in ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("my result with Ben Green")]#text(" establishing arbitrarily long arithmetic progressions of primes, the argument was (necessarily) finitary in nature, but it was absolutely essential for us to be aware of the infinitary arguments and intuition that had been developed in ergodic theory, as we had to adapt such arguments to the finitary setting in order to conclude our proof, and it would have been far less evident how to discover such arguments if we were always restricted to looking at finitary settings. In general, it seems that infinitary methods are good for “long-range” mathematics, as by ignoring all quantitative issues one can move more rapidly to uncover qualitatively new kinds of results, whereas finitary methods are good for “short-range” mathematics, in which existing “soft” results are refined and understood much better via the process of making them increasingly sharp, precise, and quantitative. I feel therefore that these two methods are complementary, and are both important to deepening our understanding of mathematics as a whole.")

#metadata(none) <tao-3a59bd84c27bba1ea4b7>#link(<tao-eee263f7c59517945529>)[#text("[5]")]#text(" This looks like ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(", but because we require sequential compactness here rather than topological compactness, the result here is in fact much closer in spirit to the ")#link("http://en.wikipedia.org/wiki/Arzela-Ascoli_theorem")[#text("Arzelà-Ascoli theorem")]#text(". In particular, the ")#link("http://en.wikipedia.org/wiki/Arzela-Ascoli_theorem")[#text("axiom of choice")]#text(" is not actually used here, instead one repeatedly uses the ")#link("http://en.wikipedia.org/wiki/Bolzano-Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(" for the interval [0,1] followed by a ")#link("http://en.wikipedia.org/wiki/Diagonalization_argument")[#text("diagonalisation argument")]#text(". The astute reader here will observe that the Bolzano-Weierstrass theorem is essentially equivalent to the infinite convergence principle! Fortunately, there is no circularity here, because we are only using this theorem in order to deduce the finite convergence principle from the infinite, and not the other way around.")

#metadata(none) <tao-d563ef6e7d15813d2187>#link(<tao-5cb6008ceea7110a3e18>)[#text("[6]")]#text(" One could also view this as a “noncommutative” or “quantum” version of the convergence principle, but this is somewhat of an abuse of terminology, despite the presence of the Hilbert space, since we don’t actually have any noncommutativity or any other quantum weirdness going on.")

#metadata(none) <tao-2a7a7897ecb4392c905d>#link(<tao-15d3e7e362e67832619e>)[#text("[7]")]#text(" One can also replace this greedy algorithm by a random algorithm, in which each ")#mi("{\\mathcal B}_{n+1}")#text(" is obtained from ")#mi("{\\mathcal B}_n")#text(" by adding a neighbourhood ")#mi("N(v_n)")#text(" of a randomly chosen vertex ")#mi("v_n")#text(" in V. This use of randomisation appears in the infinitary setting in this ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("paper of myself")]#text(", and in the finitary setting in this ")#link("http://arxiv.org/pdf/math/0612838")[#text("paper of Ishigami")]#text(".")

#metadata(none) <tao-62852170b88a13fb0235>#link(<tao-fa49745befb079975b37>)[#text("[8]")]#text(" This notation is ")#emph[#text("very")]#text(" roughly equivalent to the notion of a function F(A) defined for all sets of integers (both finite and infinite) which can always be “computed” in “finite time” if the set is infinite. But one should take this informal definition with a large grain of salt: while there is indeed an algorithm for computing F(A) for any given set A which will eventually give the right answer, you might not be able to tell when the algorithm has finished! A good example is the function ")#mi("F(A) := \\inf(A)")#text(" which is asymptotically stable near infinite sets: you can “compute” this function for any set A by initialising the answer to 0, running a counter n from 0 to infinity, and resetting the answer permanently to n the first time n lies in A. As long as A is non-empty, this algorithm terminates in finite time with the correct answer; if A is empty, the algorithm gives the right answer from the beginning, but you can never be sure of this fact! In contrast, the cardinality |A| of a possibly infinite set A cannot be computed even in this rather unsatisfactory sense of having a running “provisional answer” which is guaranteed to eventually be correct.")

#text("[")#emph[#text("Update")]#text(", May 24: Typos corrected. A distinction drawn between the strong Ramsey theorem (a theorem that can be stated in finitary mathematics), and the Paris-Harrington theorem (which shows that the strong Ramsey theorem is unprovable by finitary means). Acknowledgment to Harvey Friedman added, as well as a link to reverse mathematics.]")

#text("[")#emph[#text("Update")]#text(", May 25: functional analysis changed to operator algebras. Footnote [3] modified in view of recent comments.]")

#text("[")#emph[#text("Update")]#text(", May 31: ")#mi("\\inf(A \\cup \\{0\\})")#text(" corrected to “")#mi("\\inf(A)")#text(" when A is non-empty, and 0 if A is empty”.]")

#text("[")#emph[#text("Update")]#text(", Aug 19, 2008: Definition of asymptotic stability corrected; thanks to Jaime Gaspar for pointing out the problem.]")

#heading(level: 1)[#text("Comments (87)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-165073")[#strong[#text("Hard analysis, soft analysis — The Endeavour")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2012")]

#text("[…] I was trained as a bird, but I’ve become more of a frog over time. Of course these categories are not exclusive. Frogs sometimes act as birds and vice versa. The categories of hard and soft analysis are not exclusive either. See Terry Tao’s article on relating hard and soft analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-176965")[#strong[#text("Functional Analysis – Introduction. Part II « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2012")]

#text("[…] of substance, which applies to concrete cases in analysis, that does not involve some kind of hard analysis, some epsilonaustics, some sweat. In our example, the hard analysis comes in the proof of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-185892")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] which is useful in situations in which one does not expect a uniform convergence rate; see this previous blog post for some discussion of metastability. When interpreted in a finitary setting, this concept requires […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The three Moirai, continued « chorasimilarity")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-195459")[#strong[#text("The three Moirai, continued « chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2012")])]

#text("[…] Now the construction is finished, let us let the Moirai to do their job. Finally, I shall recall my real goal, which I have never forgot. The real goal is to pass from understanding of the power of this lambda calculus sector of graphic lambda calculus to the real deal, called “computing with space”, namely to understand space from a computational perspective, not as a given receptacle, but as a small list of procedures along with some impossible to verify assertions (like that we may rescale indefinitely space), see “emergent algebras”, which can always be eliminated a posteriori, by a kind of finitization procedure. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The spectral proof of the Szemeredi regularity lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-199142")[#strong[#text("The spectral proof of the Szemeredi regularity lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2012")])]

#text("[…] with for all . Applying (3) and the pigeonhole principle (or the finite convergence principle, see this blog post), we can find such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-228784")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Analogies between finitary and infinitary math (adapted from “Soft analysis, hard analysis and the finite convergence principle“) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-230025")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2013")])]

#text("Jennifer Chayes’s link is outdated. The current link should be ")#link("http://research.microsoft.com/en-us/um/people/jchayes/")[#text("http://research.microsoft.com/en-us/um/people/jchayes/")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65ae3855a75f689c8726b4fe1d0490183a4155008a16f79d89b65d48506c8169-aef4e2b5f4032197906f44a3e87c25dca9885793b44731842f4a4ebf3a6a15d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-230111")[#strong[#text("Frank")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2013")])]

#text("Dear professor:")#linebreak()#text(" Sorry for my ignorance. In my opinion, the proof of the part (the infinite convergence principle implying the finite convergence principle) is imperfect. The compactness or completeness of the real line might as well be avoided, since the theorem, i.e, the monotone sequence of rational numbers on ")#mi("[0,1]")#text(" is Cauchy as well. The compactness of ")#mi("[0,1]^\\omega")#text(" depends on that, I think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-230426")[#strong[#text("Analogies between finitary and infinitary math | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2013")]

#text("[…] [1.3] Soft analysis, hard analysis, and the finite convergence principle […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97cad56efee7c74c7e6d2d171aafe8611bb711fcf48a37f12cc548cea2f9677a-ee1dcc4173142628a072e9a65ef790b6cbdc547ffacb9999bb159b92b8a9cc03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-672631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2023")])]

#text("Dear professor Tao, do you have something in mind about something in operator algebra that has some analog in “hard analysis”? Because to my knowledge (which is surely still lacking in many ways), operator algebra in the sense of Connes feels extremely algebraic and doesn’t feel like the usual functional analysis that interacts with PDEs (but sorry if I’m wrong about this)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-231779")[#strong[#text("Topological order for mixed states | Tobias J. Osborne's research notes")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2013")]

#text("[…] The definition provided by Hastings is much closer in spirit with this second definition. (It’s worth noting that by working in the infinite lattice size limit we can avoid lots of s and s; we can make our soft analysis definition a hard analysis definition if we like in the standard way.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-243296")[#strong[#text("O intâlnire cu informatica teoretică românească: FMI@150 Ziua I | Isarlâk")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2013")]

#text("[…] de faptul că domeniul este unul interesant vă puteți convinge de exemplu citind această discuție pe blogul lui Terry Tao. Ar fi interesant de văzut câte din lucrurile din acest domeniu pot fi automatizate. Impresia pe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-459432")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] at some point one must reach a metastable region (cf. the finite convergence principle discussed in this previous blog post), within which very little mutual information can be shared between the sequence and the graph . […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-474999")[#strong[#text("Hilbert’s Curve, and the usefulness of infinite results in a finite world | Coding Craze")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2016")]

#text("[…] Soft analysis, hard analysis, and the finite convergence principle c++ programs […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-475024")[#strong[#text("Hilbert’s Curve, and the usefulness of infinite results in a finite world | Coding Tweaks")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2016")]

#text("[…] Soft analysis, hard analysis, and the finite convergence principle c++ programs […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-477259")[#strong[#text("Hard analysis, soft analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2017")]

#text("[…] I was trained as a bird, but I’ve become more of a frog over time. Of course these categories are not exclusive. Frogs sometimes act as birds and vice versa. The categories of hard and soft analysis are not exclusive either. See Terry Tao’s article on relating hard and soft analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-484006")[#strong[#text("An Epsilon of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-pri&#8230")[#text("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-pri&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56eba5fb7499d8619021afdfe6bb2718b45acfdde6ea8504607ed9c38648ec88-4aa1d6208bafa195b0556949c3ba68e7011c316b45c72ffa1699d18d96bdd3ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elienasrallah")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-484143")[#strong[#text("elienasrallah")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Reblogged this on ")#link("https://elienasrallah.wordpress.com/2017/07/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("Elie Nasrallah")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83ef19a6b97844861ddbbc4ff5b3e18082ed66b6d0a52b25882ce4d5a0155b72-b1cf1f88a0d95b501207ff47025d5f1930313da80b485f8a5708002a000d3a09.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of franchb")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-484433")[#strong[#text("franchb")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2017")])]

#text("Reblogged this on ")#link("https://irusin.wordpress.com/2017/07/31/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("irusin")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-498388")[#strong[#text("Finitary versions of theorems – Write down what you’ve done")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2018")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-pri&#8230")[#text("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-pri&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-513910")[#strong[#text("An Epsilon of Mathematics … draft …")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-pri&#8230")[#text("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-pri&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f765711d513918780cd4f249bf7a2f46684c986454c99f0a19de526f59d010a3-ce0b7fb479e0fe47f5cefdecd96663023bc53a8c6e3c09902ab3da18f3613590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rationality from Irrationality Part 3: From Matching Pennies to Matching Regrets – Technicalities")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-516214")[#strong[#text("Rationality from Irrationality Part 3: From Matching Pennies to Matching Regrets – Technicalities")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2019")])]

#text("[…] proof will be a long sequence of hard (as opposed to soft) analysis problems centered around the following main idea: for , we want to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative bounds for critically bounded solutions to the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-519676")[#strong[#text("Quantitative bounds for critically bounded solutions to the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2019")])]

#text("[…] the use of compactness by more complicated substitutes that give effective bounds; see for instance these previous blog posts for more discussion. I therefore was interested in trying to obtain a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48bea38b0bd8c7d42870371b62ad0bcad0f98631214254429ab628eae02b1a4c-98e3f7880fdcd38499ad6a7eae8b2ea433e561c03eab9e9afedb3426a0f75f22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vilhelm Agdur")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-546478")[#strong[#text("Vilhelm Agdur")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("Regarding the very last part, with the “finitary infinitary pigeonhole principle”, does this result crucially depend on the notion of being asymptotically stable near infinite sets quantifying over all sets, or do we still get something interesting if we weaken it to an almost-surely w.r.t. the uniform measure?")

#text("In particular, I mean this: suppose we have a function ")#mi("f: \\mathcal{P}(\\mathbb{N}) \\to \\mathbb{N}")#text(" such that for a randomly chosen ")#mi("A\\subset \\mathbb{N}")#text(", for any sequence ")#mi("A_1, A_2, \\ldots")#text(" of finite sets convergent to ")#mi("A")#text(", w.p.1 the sequence ")#mi("f(A_1), f(A_2), \\ldots")#text(" is eventually constant and equal to ")#mi("f(A)")#text(". Do we still get an interesting conclusion?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-564647")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("[…] the correspondence Serre discusses is slightly different from the one I discuss for instance in here or here, although there seems to be a common theme of “compactness” (or of model […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-579050")[#strong[#text("What proof mining is about, Part IV: Kohlenbach & friends - The Proof Theory Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")]

#text("[…] Tao in 2007 during his work on multiple ergodic averages, introduced at the time to the public in this blog post and named as such by Jennifer Chayes. Kohlenbach’s general logical metatheorems of proof […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/547b9d5df37140b8ea78d092fa6d4927a79ab3c12db85eed8d52091e6c91c759-92be033657fa5e0df82c9f02bec626fa066a5c97de6e891f6296d04629aca1eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Finitary proofs of Borel-Cantelli lemmas | Subin Pulari")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-629167")[#strong[#text("Finitary proofs of Borel-Cantelli lemmas | Subin Pulari")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2021")])]

#text("[…] we explore the Borel-Cantelli lemmas from a hard analytic/finitary perspective. We obtain finitary analogues of these lemmas using elementary tail bounds from […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-641070")[#strong[#text("Mengingat jumlah monyet yang tidak terbatas dan waktu yang tidak terbatas, apakah salah satu dari mereka akan menulis Hamlet? - Pripun?net")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2022")]

#text("[…] adalah contoh dari Jenderal “analisis lunak ke analisis kerasPrinsip yang diperjuangkan oleh Terry Tao antara lain: hampir semua bukti dalam analisis dapat […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-660182")[#strong[#text("Numerical constants are not a red flag – some compact thoughts")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2022")]

#text("[…] proof, because let’s be honest, nobody else commenting on the proof, other than experts in hard analytic number theory, has any chance of understanding the proof either. And since Peking […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the B+B+t theorem | What's new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-684804")[#strong[#text("Notes on the B+B+t theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2024")])]

#text("[…] 1 is then equivalent to the following “almost finitary” version (cf. this previous discussion of almost finitary versions of the infinite pigeonhole […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-686061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2024")])]

#text("It might be interesting to note that this distinction has made its way to statistics in the split between asymptotic theory (the Van der Vaart textbook) and nonasymptotic theory (the Wainwright textbook).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-689538")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2025")])]

#text("Dear professor Tao:")

#text("In the third version of the pigeonhole principle, there is a redundant condition ")#mi("k \\geq 1")#text(", and ")#mi("2N \\leq M")#text(" should be ")#mi("2N < M")#text(" corresponds to the original pigeonhole principle.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-689542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#metadata(none) <tao-8bbfbd5f3cb9a3a6a76b>

#text("Dear Prof. Tao,")

#metadata(none) <tao-e98bc166ae19c8f84945>

#text("I find a small typo: “…an set…” should ” a set “.")

#emph[#text("[Corrected, thanks -T.]")]

#metadata(none) <tao-76c2350688b3ef2c8b32>

#text("I am confused about: why is “E compact” corresponded to ” Metric entropy bound on E” ?")

#emph[#text("[A set in a metric space is compact iff it is complete and totally bounded; the latter is equivalent to all metric entropies being finite. -T]")]

#metadata(none) <tao-318cd83ed94495dc1c3e>
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-689550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2026")])]

#text("Dr. Tao,")

#text("I think that it would be better if “…it would have far less evident…” → “…it would have ")#emph[#text("been")]#text(" far less evident…”")

#emph[#text("[Corrected, thanks – T.]")]

#text("In the table you said “V is generated by S” corresponds to “V is an algorithm initialised by S”, however I fail to see what this means, say ")#emph[#text("the generation of σ-algebras")]#text(" : <F> is the σ-algebra generated by F, could you specify what the algorithm initialided in this case is?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-689553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2026")])]

#text("Excuse me, Dr. Tao, did I miss something? Was I not clear enough in my expression?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-689561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2026")])]

#text("Dear Dr Tao, I know in this post you used some informal terms, but could you explain a bit more of “complexity”? Though this could be intuitive, but I also feels fuzzy on complexity. Or could you provide some examples of “E is (quantitatively) approximated by bounded complexity sets”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-2/#comment-689566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2026")])]

#text("I go into this topic in more detail at ")#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thomas1111")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1149")[#strong[#text("thomas1111")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")])]

#text("That’s a fascinating post! I was wondering if this had any chance of appearing in book form one day (e.g. in a second edition of your undergraduate books on analysis)?")

#text("(Btw, a few trivial typos: 5. should read “The deduction ")#emph[#text("of")]#text(" the finitary statement…”, and the ‘latex’ command is misplaced in the Hilbert space infinitary convergence principle, and missing in a paragraph a little later.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Kinyon")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1151")[#strong[#text("Michael Kinyon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")])]

#text("A very well-written and insightful essay. You should consider submitting this to the Monthly, if you haven’t already.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1153")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")])]

#text("Thanks for the suggestions! Actually, Ben Green and I are planning to write a paper on the finite convergence principle and the philosophy surrounding it, once we have collected a few more applications of this principle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0106d1a51149435c0e7cc34d90e8026547a432e9bf1348c67b9eb9712116364-f26191209d651bb87abe0695a0206e6e25995780d590cc394681eab053fdce6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of richard borcherds")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1154")[#strong[#text("richard borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")])]

#text("I suggest that hard analysis is essentially first order (Peano) arithmetic, while soft analysis is")#linebreak()#text(" second order arithmetic; in other words, hard analysis proofs are those that can be encoded in Peano arithmetic. Harvey Friedman has done a lot of work on what happens when you try to convert a proof in second order arithmetic into one in first order arithmetic: even when this is possible, the proof can get MUCH longer.")

#text("Friedman has also investigated several subsystems of second order arithmetic, which might be related to the different subsystems of soft analysis mentioned in the article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")])]

#text("Dear Richard,")#linebreak()#text(" Thanks for your comment! I think you are essentially correct in this. There seems to be a vague correspondence between how strong a logic one is willing to use, and how rapidly growing a function from the natural numbers to itself that one is willing to use (e.g. polynomial, exponential, primitive recursive, Ackermann, non-computable, ineffective, etc.) The latter is of course already very similar to the quantitative/qualitative distinction in analysis.")#linebreak()#text(" Incidentally, Harvey was the one who pointed me towards the Paris-Harrington theorem and the non-finitisability of the infinite pigeonhole principle; I had neglected to attribute this and will correct the post accordingly. I’m also adding a pointer to the field of reverse mathematics, which is very relevant to these issues and to which Harvey has contributed quite a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1162")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")]

#text("[…] Soft analysis, hard analysis, and the finite convergence principle In the field of analysis, it is common to make a distinction between “hard”, “quantitative”, or […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e911f2477ba3edc2ab0a6d81dfe561f188f2d6ef8474e98fbc30b653d658941c-9efd85762d1439b62f5df2dbb769fa6fd290fd3b77ba008c45b1309ec6e3b289.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1164")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2007")])]

#text("You name functional analysis as one field which relies primarily on soft analysis tools. However, the spectrum of problems studied by modern functional analysts draws on both hard and soft tools to various extents; the flavor of the distinctions you discuss and finer distinctions of footnote [1] are familiar just within the geometry of Banach spaces. On the soft analysis end is the isomorphic theory of infinite-dimensional Banach spaces, which is the most classical part of the field. On the hard analysis end is the isometric theory of infinite- or finite-dimensional Banach spaces. In between are what are called the isomorphic and almost-isometric theories of finite-dimensional Banach spaces, which can be characterized in your terminology as “quasi-exact hard analysis”, with the almost-isometric theory being harder (or more exact) than the isomorphic theory. For a discussion of the latter two theories, see for example Bo’az Klartag’s 2006 ICM talk.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1176")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("Dear Mark,")

#text("Thanks for your comments! I guess I managed to cause some misunderstanding; here at UCLA “functional analysis” usually gets identified with “operator algebras” (e.g. von Neumann algebras) rather than “Banach space geometry”, due to the nature of our research group in that area; I’ll correct the post accordingly. Actually, Banach space geometry is indeed a nice example of an evolution of a field from soft infinitary analysis towards hard finitary analysis. (In the converse direction, extremal combinatorics has been firmly in the “hard analysis” camp until very recently, when signs of soft analysis have begun appearing.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Towsner")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1180")[#strong[#text("Henry Towsner")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("The finitary convergence principle is an instance of a proof-theoretic technique called the Dialectica translation. Given an arbitrary formula, the Dialectica translation produces an equivalent formula (possibly involving higher types) with the property that, given a proof (in a suitable logical system–say, Peano Arithmetic) of the original formula, there is a constructive proof of the translated formula.")

#text("The key property is that Pi-0-2 (“forall x there exists a y such that P(x,y)” where P(x,y) is computable) formulas are unchanged. So given a proof of a Pi-0-2 formula using infinitary methods that give no quantitative information, the Dialectica translation describes how to extract a constructive proof with quantitative bounds. Not every proof has this property–it depends on the exact logical system the proof is in–but there’s a fair amount of work, especially by Ulrich Kohlenbach, on exactly how far the translation can be pushed.")

#text("For a long time, there were a handful of specific applications (Luckhardt to the Thue-Sigel-Roth theorem, Girard to van der Waerden’s theorem, various results by Bishop and his associates), but not many people systematically working at the applications of those techniques, but that’s changed in the last ten or fifteen years. The biggest group in that area is Kohlenbach and his students, who have a produced a number of results working by applying these techniques to soft analytic proofs (mainly in fixed point theory). (I may as well plug my own work–Jeremy Avigad and I recently started trying to produce hard analytic versions of certain soft analytic proofs in ergodic theory, and, together with Philipp Gerhardy, just finished a paper with a hard analytic version of the ergodic theorem which should be online in the next week or two.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c4195e5dc954ecbe350ea8090375abbf2deb0e6afffd80b30f19e2813386c34-4cb28dbefab7a84cda7371f33c38135a975c7335925feddc82227f74a70be069.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich Kohlenbach")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1185")[#strong[#text("Ulrich Kohlenbach")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("As my work has been mentioned in Henry Towsner’s mail, I like to give a few pointers to my papers:")#linebreak()#text(" The “finite convergence principle” as discussed by Terence Tao features")#linebreak()#text(" prominently e.g. in my papers")

#text("1) Some computational aspects of metric fixed point theory. Nonlinear")#linebreak()#text(" Analysis vol.61, no.5, pp.823-837 (2005)")#linebreak()#text(" 2) Bounds on iterations of asymptotically quasi-nonexpansive mappings")#linebreak()#text(" (with Branimir Lambov). In: Falset, Fuster, Sims (eds.), Proc.")#linebreak()#text(" International Conference on Fixed Point Theory and Applications,")#linebreak()#text(" Valencia 2003, pp. 143-172, Yokohama Publishers (2004).")

#text("A general survey is in my paper “Effective bounds from proofs in abstract")#linebreak()#text(" functional analysis”. In: Cooper, Loewe, Sorbi (eds.), CiE 2005. New Computational Paradigms. Springer. To appear 2007 (available from my homepage, see theorems 22 and 30).")

#text("The new paper by Avigad, Gerhardy and Towsner provides another nice")#linebreak()#text(" use of this concept and the logical methodology sketched below.")#linebreak()#text(" There also is another paper by myself and Laurentiu Leustean using")#linebreak()#text(" this concept coming up soon.")

#text("The finite convergence principle is exactly the so-called Herbrand normal")#linebreak()#text(" form or no-counterexample interpretation (G. Kreisel) of (one formulation of) the usual Cauchy statement which in this simple case at hand also")#linebreak()#text(" coincides with the Goedel functional interpretation (of the Goedel negative")#linebreak()#text(" translation of) the Cauchy property (as pointed out by Henry Towsner). For more complicated statements Goedel’s interpretation differs from the Herbrand normal form in order to achieve a much better logical behavior compared to the Herbrand normal form on the expense of using functionals in higher function spaces (rather than just number theoretic functions M). In fact, proofs can be logically analyzed by transforming")#linebreak()#text(" every statement in the proof (no matter what logical form they have) into")#linebreak()#text(" the Goedel interpretation to guarantee an effective witness for it")#linebreak()#text(" (i.e. an effective bound on the finite convergence version in the case the conclusion is a convergence statement). This applies to strong formal")#linebreak()#text(" systems in which the bulk of ordinary analysis can be formalized.")#linebreak()#text(" The “finitary” infinite pigeonhole principle is just another instance of the")#linebreak()#text(" aforementioned interpretation schema.")

#text("General background information on Goedel’s method and its modern")#linebreak()#text(" refinements necessary to make it applicable in analysis can be found in my invited chapter for the Goedel Centenary Volume")#linebreak()#text(" “Goedel’s functional interpretation and its use in current mathematics”")#linebreak()#text(" (available on my homepage) as well as my forthcoming book")#linebreak()#text(" “Applied Proof Theory: Proof Interpretations and their use in Mathematics”")#linebreak()#text(" which I am currently finishing for Springer Monographs in Mathematics")#linebreak()#text(" (approx. 500pp., expected to appear in 2008)")

#text("See also my joint survey with Paulo Oliva “Proof mining: a systematic")#linebreak()#text(" way of analysing proofs in analysis”, Proc. Steklov Inst. Math. vol 242,pp.")#linebreak()#text(" 136-164 (2003).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1186")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("Dear Henry and Ulrich,")

#text("Thank you for bringing these recent developments in proof theory to my attention (and to the attention of other readers, of course). I was aware of Girard’s work on finitising the Furstenberg-Weiss proof of van der Waerden’s theorem, but not on later developments, and I am happy to hear that there is active work in this direction. In particular, the issue of finitising the work of Furstenberg and his school in ergodic theory seems to be particularly relevant to current developments in combinatorics and number theory.")

#text("Hopefully there will be a bit more dialogue between the hard analysts, soft analysts, and proof theorists, in the future :-) .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JL")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1193")[#strong[#text("JL")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("As you mention in footnote [1], us “hard analysts” often distinguish between different types of growth and consider them qualitatively different (O(1) vs. polylog(n) vs. polynomial, etc.) While there is often a hard soft correspondence (usually via some type of compactness) when the quantitative growth can be considered O(1) with respect to some parameter, there are far fewer examples where, for instance, polynomial growth manifests itself as infinitary stability, while super-polynomial growth does not (i.e. “soft” conclusions that correspond only to certain types of super-constant bounds). A notable exception is Gromov’s theorem on groups of polynomial growth.")

#text("Mike Freedman ")#link("http://portal.acm.org/citation.cfm?id=276871&dl=")[#text("suggested")]#text(" a few years ago that maybe such a correspondence could be used to elucidate the P vs. NP question. His basic idea is that problems in P should have decidable limits, while hard problems (e.g. SATisfiability) should become undecidable in the limit (whatever “limit” means).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1194")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("Dear JL,")

#text("Thanks for the comment, and for the pointer to Freedman’s work! I have also felt that the “polynomially quantitative” category of hard analysis should be equivalent to either some sort of soft analysis in the “polynomial limit”, or to some sort of restricted “polynomial logic” in which certain operations (notably excessive use of induction, which can easily lead to exponential growth or worse) are prohibited. Certainly there are many polynomially quantitative arguments in which one can basically just glance at the ")#emph[#text("form")]#text(" of the argument and say “OK, there is nothing really iterative happening here, thus I am convinced that the argument will necessarily output a bound of polynomial type” – but with our current mathematical tools we still have to verify the polynomial growth by tedious calculation. I have even tried once or twice to construct an infinitary limit object by brute force (e.g. considering sequences of finitary objects tending to infinity, quotiented by the equivalence relation of being equivalent up to polynomial losses, and maybe throwing in an ultrafilter to force limits to exist) but nothing particularly interesting seems to emerge at the other end of the process.")

#text("What one really wants to see is some rich infinitary theory come into the picture, similar to how the theory of Lie groups enters in Gromov’s limit of groups of polynomial growth. But the polynomial infinitary limit – whatever it is – seems strangely “incomplete” (due to the forbidden nature of induction) and so much of the power of soft analysis seems to be lost (many of the really deep theorems in soft analysis only work on ")#emph[#text("complete")]#text(" metric spaces, such as Banach or Hilbert spaces). [It may be that one needs to “compactify” the infinitary limit somehow, creating new infinitary objects exhibiting some sort of weird “virtual” polynomial growth; but this is of course extremely speculative.]")

#text("One possible concrete area where it may be reasonable to implement such a soft theory is the recent developments in sum-product theorems, as developed primarily by Bourgain and his co-authors. Here, the whole aim of the game is to extract a power gain ")#mi("p^\\epsilon")#text(" in something like a sum set or product set, where p is the cardinality of the underlying field and one doesn’t care at all exactly what ")#mi("\\epsilon")#text(" is so long as it is positive and independent of p. As one would expect from Bourgain, all the papers are written in the “hard analysis” style, but I feel these arguments have some inherent softness to them (because the exact value of all the ")#mi("\\epsilon")#text("s involved play virtually no role whatsoever in the argument) and one might be able to clean up the arguments and reduce a lot of epsilon-bookkeeping by moving to a softer approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("Perhaps in the spirit of Gromov’s theorem, I should rename “polynomial logic” as “")#emph[#text("nilpotent")]#text(" logic”; some iteration / use of induction is allowed (e.g., given that ")#mi("f(n+1)-f(n)")#text(" has polynomial growth, to deduce that ")#mi("f(n)")#text(" has polynomial growth), but there has to be some finite depth to this iteration to prevent exponential growth from occurring. (There seems to be a vague analogy here with the concept of primitive recursive functions in computability theory, though it doesn’t seem to be exactly the same thing.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Open question: effective Skolem-Mahler-Lech theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1203")[#strong[#text("Open question: effective Skolem-Mahler-Lech theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("[…] #1, there are often ways to make these arguments quantitative and effective, as discussed in my previous post. But #2 and #3 seem to be irreducibly ineffective: if you know that a set A has finite cardinality […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1207")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2007")])]

#text("I think results like Gromov’s are atypical examples of polynomially-bounded objects. I would argue that finitely-presented groups are “naturally” either finite or of exponential growth, which makes polynomial growth a strong condition to impose, one that sharply limits the structure of the group. I would guess this is something peculiar to an equationally-presented theory such as the theory of groups, and is not something you would see very often in more combinatorial settings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e911f2477ba3edc2ab0a6d81dfe561f188f2d6ef8474e98fbc30b653d658941c-9efd85762d1439b62f5df2dbb769fa6fd290fd3b77ba008c45b1309ec6e3b289.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1216")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("Terry,")

#text("I know you’re well aware of the quantitative side of Banach space geometry; I just wanted to take the oppurtunity to advertise a field I like. To continue on that note, I could add that there are parts of the theory of operator algebras that, via free probability theory and random matrices, involve some very hard analysis indeed. Of course I can’t take issue with your statement that operator algebraists “tend to” use softer tools.")

#text("On a different note, can you say some more, or give some references to the appearance of soft analysis in extremal combinatorics that you mentioned?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("Dear Mark,")

#text("This is a good point about free probability/random matrices. (Also, there is a lot of recent work on getting usefully quantitative versions of Kazhdan property T.) I guess I should be a little more cautious in designating camps for various fields; nowadays all the techniques are slowly getting blended together, which I think is a very healthy thing for analysis as a whole.")

#text("As I mentioned in my main post, the Szemeredi regularity lemma in graph theory (which has some bearing on extremal graph theory problems, as mentioned in my post on the triangle-diamond problem) can be proven by a finitary version of an infinitary statement (the infinite convergence principle), which then suggests that the regularity lemma itself should have an infinitary formulation. Recently, a couple proposals for this have appeared, notably the theory of limits of sequences of increasingly large graphs and hypergraphs by Lovasz-Szegedy (dubbed “graphons”), and similar work by Borgs, Chayes, Lovasz, Sos, and Vesztergombi, and also in a more “ergodic theory” approach (based on a hypergraph analogue of the Furstenberg correspondence principle) by myself; also, Lovasz-Szegedy and Bollobas have observed that the regularity lemma has meaningful applications to infinitary settings, for instance establishing compactness of various classes of operators in certain topologies. Infinitary approaches (e.g. ultrafilters, especially idempotent ultrafilters) have also played an important role in Ramsey theory for some time now, and of course Szemeredi’s theorem itself has a fully infinitary proof (by ergodic theory) and a pre-infinitary proof (Szemeredi’s original proof involved lots of sequences of things going to infinity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2007")])]

#text("Dear Walt,")

#text("That’s an interesting point. Actually it seems that there are two sorts of results involving polynomial bounds which are sort of dual to each other; one tries to establish polynomial bounds as a ")#emph[#text("conclusion")]#text(" starting from a hypothesis which does not obviously exhibit polynomiality, and one tries to use polynomial bounds as a ")#emph[#text("hypothesis")]#text(" and obtain a conclusion which is much stronger than polynomiality. Gromov’s theorem is of course in the second category, whereas most results involving polynomial bounds tend to be in the first category. It may well be that the infinitisability of the former is indeed a completely different story from the latter, as you propose.")

#text("On the other hand, I feel that Gromov’s theorem is not completely singular; it is an example of a rigidity theorem (weak or approximate structure implies strong or algebraic structure), and these seem to be all over the place in mathematics (and always incredibly useful and deep whenever they do show up).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ea215694766949c85b8564ec205c7754f7e9a0fe7aeb28b6181d9d96aba7f41-14a2c37b8d949e244da5367adcaa4464d268cd0119451bd8c5c69993627944d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen G. Simpson")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1540")[#strong[#text("Stephen G. Simpson")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")])]

#text("REVERSE MATHEMATICS")

#text("There is an extensive, highly developed research program in the")#linebreak()#text(" foundations of mathematics, known as REVERSE MATHEMATICS. The purpose of reverse mathematics is to determine the strength of the")#linebreak()#text(" set-existence axioms which are needed in order to prove various")#linebreak()#text(" specific mathematical theorems.")

#text("The specific mathematical theorems which have been analyzed from the")#linebreak()#text(" reverse mathematics point of view include many well known theorems")#linebreak()#text(" from real analysis, functional analysis, complex analysis, algebra,")#linebreak()#text(" geometry, and combinatorics. Recently Mummert and Simpson have")#linebreak()#text(" extended reverse mathematics into the realm of general topology.")

#text("The basic reference on reverse mathematics is my book Subsystems of")#linebreak()#text(" Second Order Arithmetic, published by Springer-Verlag in 1999. A")#linebreak()#text(" second edition will be published soon by the Association for Symbolic")#linebreak()#text(" Logic and Cambridge University Press. The subsystems which arise")#linebreak()#text(" there correspond to a hierarchy of stronger and stronger set existence")#linebreak()#text(" axioms which are potentially useful in mathematics.")

#text("Below I list some references to papers dealing with the reverse")#linebreak()#text(" mathematics of various theorems in countable combinatorics.")

#text("1. The analysis of Ramsey’s Theorem from the reverse mathematics point")#linebreak()#text(" of view is essentially due to Carl Jockusch in the 1960s, though at")#linebreak()#text(" the time the results were not formulated in this way.")

#text("2. A reverse mathematics analysis of Hindman’s Theorem, as well as the")#linebreak()#text(" closely related Auslander/Ellis Theorem from topological dynamics, has")#linebreak()#text(" been carried out by Andreas Blass, Jeffry Hirst, and Stephen Simpson.")#linebreak()#text(" (Hindman’s Theorem says that, if the positive integers are colored")#linebreak()#text(" with finitely many colors, then there exists an infinite set of")#linebreak()#text(" positive integers, X, such that all sums of finite subsets of X have")#linebreak()#text(" the same color.) The Blass/Hirst/Simpson paper was published in the")#linebreak()#text(" volume Logic and Combinatorics, in the AMS book series Contemporary")#linebreak()#text(" Mathematics, volume 65, 1987.")

#text("3. The reverse mathematics analysis of the Podewski/Steffens Theorem")#linebreak()#text(" (this is essentially the Koenig Duality Theorem for countably infinite")#linebreak()#text(" graphs) was begun by Aharoni/Magidor/Shore and completed by Simpson.")#linebreak()#text(" Simpson’s paper is in the Journal of Symbolic Logic, volume 59, 1994.")

#text("4. A reverse mathematics analysis of the Carlson/Simpson Dual Ramsey")#linebreak()#text(" Theorem (Advances in Mathematics, volume 53, 1984) has been carried")#linebreak()#text(" out by Joseph S. Miller and Reed Solomon. Unfortunately the")#linebreak()#text(" Miller/Solomon results are only partial, but they are interesting")#linebreak()#text(" nonetheless. The Miller/Solomon paper is in Archive for Mathematical")#linebreak()#text(" Logic, 43, 2004.")

#text("Additional information and references are available on my web pages.")

#text("Stephen G. Simpson")#linebreak()#text(" Professor of Mathematics")#linebreak()#text(" Pennsylvania State University")#linebreak()#text(" ")#link("http://www.math.psu.edu/simpson/")[#text("http://www.math.psu.edu/simpson/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-1542")[#strong[#text("Thoughts on \"Soft analysis, hard analysis, and the finite convergence principle\" by T.Tao « cow_gone_mad")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2007")]

#text("[…] by T.Tao Posted in Uncategorized by cowgonemad on the June 2nd, 2007 Having read Soft analysis, hard analysis, and the finite convergence principle « What’s new by Terrence Tao, there are a few things I am wondering about connected to the approximation of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04f46819b994df538dd49762f260e79f7a82921ec4a697f6ad8d62b1997476b6-fd05cbb18a06fc83ead137c8cac5342ad18c1b2519ba0debf79fea195789e17b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Avigad")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-2103")[#strong[#text("Jeremy Avigad")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2007")])]

#text("Friends,")

#text("Philipp Gerhardy, Henry Towsner, and I have put the current draft of our paper, “Local stability of ergodic averages,” on arXiv (")#link("http://arxiv.org/abs/0706.1512")[#text("http://arxiv.org/abs/0706.1512")]#text("). We show that even though one cannot, in general, compute a bound on the rate of convergence of a sequence of ergodic averages, one can bound how far one has to look to find large intervals on which such a sequence is relatively stable. Our proofs are entirely explicit, providing “hard” versions of the mean and pointwise ergodic theorems, in the sense of Tao’s post.")

#text("We have hopes that such results will bear on applications of ergodic theory to number theory and combinatorics, where, at the end of the day, one is only interested in the behavior of sequences on sufficiently large finite intervals. But we are essentially just a bunch of logicians messing around with ergodic theory, so thoughts and comments are especially welcome.")

#text("Best wishes,")

#text("Jeremy Avigad")#linebreak()#text(" Carnegie Mellon University")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c82a157e96e308fe8046a27390b25a004f6da1624430a43b681a3af03e7c75b5-1a1f9042d6f06413ddbafd0f950963ef144780d0550996b6b9bb5d58483474a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabor Elek")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-2141")[#strong[#text("Gabor Elek")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2007")])]

#text("Dears,")

#text("We have a recent preprint with Balazs Szegedy")#linebreak()#text(" which sort of illustrates the point of Terence Tao.")#linebreak()#text(" On arXiv ")#link("http://arxiv.org/abs/0705.2179")[#text("http://arxiv.org/abs/0705.2179")]#text(" Limits of Hypergraphs, Removal and")#linebreak()#text(" Regularity Lemmas. A Non-standard Approach.")

#text("Here we used pseudo-finitary analysis – Tao mentioned in his post – as")#linebreak()#text(" a bridge that connects the finite and the infinite analysis.")

#text("It turns out that the Lebesgue Density Theorem can be translated to")#linebreak()#text(" the Hypergraph Removal Lemma of Rodl et. al. and the Rectangular")#linebreak()#text(" Approximability Lemma can be translated to the Hypergraph Regularity")#linebreak()#text(" Lemma the same way the Convergence of Bounded Monotone Sequences")#linebreak()#text(" is translated to the Finite Convergence Principle.")

#text("Best regards,")

#text("Gabor Elek")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Lebesgue differentiation theorem and the Szemeredi regularity lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-2426")[#strong[#text("The Lebesgue differentiation theorem and the Szemeredi regularity lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2007")])]

#text("[…] June 18th, 2007 in short story This post is a sequel of sorts to my earlier post on hard and soft analysis, and the finite convergence principle. Here, I want to discuss a well-known theorem in infinitary soft analysis – the Lebesgue […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultrafilters, nonstandard analysis, and epsilon management « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-3016")[#strong[#text("Ultrafilters, nonstandard analysis, and epsilon management « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("[…] 2007 in short story, opinion This post is in some ways an antithesis of my previous postings on hard and soft analysis. In those posts, the emphasis was on taking a result in soft analysis and converting it into a hard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Norm convergence of multiple ergodic averages for commuting transformations « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-4020")[#strong[#text("Norm convergence of multiple ergodic averages for commuting transformations « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2007")])]

#text("[…] result by an equivalent finitary norm convergence result, in exactly the same way that the infinite convergence principle is equivalent to the finite convergence principle. (This is in marked contrast with the usual ergodic-theory approach to these problems, in which one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/885209e74d951c7ff8e6ae7eb2778b184a83edcb2bbfd5007d527c0a768e02cf-508a06d4ba44923deb021d782eef34f0693354cdac072bb3e83e3a2f0cd90aad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SEDSAT-2 » Blog Archive » Analysis, Analysis, Analysis")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-4490")[#strong[#text("SEDSAT-2 » Blog Archive » Analysis, Analysis, Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("[…] I seem to be doing a lot of this now a days – analysing. Analysing what questions have a higher probability of appearing in the exams, analysing which sub-system I might need to give some more mass to, analysing how we are going to build the satellite (this is far into the future but anyway). So, it felt strange to read this post by mathematician Terrence Tao on analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 4: Multiple recurrence « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-24764")[#strong[#text("254A, Lecture 4: Multiple recurrence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("[…] Exercise 3. Use Theorem 2 to deduce a finitary version: given any positive integers m and k, there exists an integer N such that whenever is coloured into m colour classes, one of the colour classes contains an arithmetic progression of length k. (Hint: use a “compactness and contradiction” argument, as in my article on hard and soft analysis.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 5: Other topological recurrence results « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-24781")[#strong[#text("254A, Lecture 5: Other topological recurrence results « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("[…] Remark 3. There is a stronger statement known, namely that G contains an infinitely large monochromatic subhypergraph, but we will not prove this statement, known as the infinite hypergraph Ramsey theorem. In the case k=1, these statements are the pigeonhole principle and infinite pigeonhole principle respectively, and are compared in my article on hard and soft analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd04be6db72e2104c08f64365f51ebbfb2a1fab29fdfd01a55b6ce5cbd9748e4-62cccdb3d95822c07f7ac7206ae9d0ed2390fd36b6fa9f95b0bdd189813c07c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-25910")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Cool article. I was however slightly confused by what hard analysis and soft analysis are supposed to be. Is there a precise (i.e. mathematico-logical) distinction? For example, does the principle “every nonempty set of natural numbers has a least element” count as a principle of soft analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-25914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Dear Dan,")

#text("There is not really a precise dividing line – it’s one of these “I know it when I see it” distinctions – but I would classify the well-ordering principle (every non-empty set of naturals has a least element) as a statement in soft analysis, because (a) it is typically applied to infinite sets rather than finite sets, and (b) it does not provide any quantitative bound as to what the least element is.")

#text("This particular statement is actually rather difficult to convert into a useful hard analysis statement because of a subtle issue in the innocuous adjective “non-empty”. Due to the undecidability of the halting problem, we know that there are sets of naturals that are explicitly describable (or more precisely, computably enumerable) but for which it is undecidable whether the set is empty or not. (e.g. consider the set of numbers which are the ASCII code for a proof that ZFC is inconsistent.) Because of this, the mere knowledge that a set is non-empty cannot translate to any useful bound unless that knowledge is strengthened in some concrete way. For instance, if one can actually exhibit an element in the set to prove its non-emptiness, then that clearly places an upper bound on the least element of that set, which can then be located in finite time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd04be6db72e2104c08f64365f51ebbfb2a1fab29fdfd01a55b6ce5cbd9748e4-62cccdb3d95822c07f7ac7206ae9d0ed2390fd36b6fa9f95b0bdd189813c07c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-25926")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("OK. I think I isolated the source of my confusion. I was confused by mention of the Paris-Harrington theorem which made me think “hard analysis” was meant to be first order Peano Arithmetic, and “soft analysis” was meant to be second or higher order arithmetic, terms which I have a vague familiarity with from reading about logic. That would be a precise dividing line, thus I guess there are either first order (i.e. only using arbitrary number) “soft” statements or second or higher order (i.e. drawing upon arbitrary set of numbers or set of sets of numbers, etc.) “hard” statements. And in fact for the epsilon-delta definition of limit and basic real analysis, you do need higher order, so I guess this is indeed the case.")

#text("I have seen a proof of Strengthened Finite Ramsey theorem (the one that Paris-Harrington refers to) before and it didn’t seem too complicated or seem to use difficult concepts. I shall have to check it out. Thanks for the reply!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-25929")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] describe the simple but fundamental Furstenberg correspondence principle which connects the “soft analysis” subject of ergodic theory (in particular, recurrence theorems) with the “hard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-27364")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2008")])]

#text("Dear professor:")

#text("Have you written a paper on this subject yet? I’m interested in this")#linebreak()#text(" subject and want to learn more.")

#text("A correction: Before the last sentence of the proof from the finite")#linebreak()#text(" convergence principal to the infinite convergence, I believe that is")#linebreak()#text(" ")#mi("x_{N+F(N)} - x_N > \\varepsilon")#text(", not ")#mi("1/\\varepsilon")#text(".")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-27490")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2008")])]

#text("Dear Liu,")

#text("Thanks for the correction! In the print version of this article, which I am currently preparing as part of my book for this blog, I will add a few more references, but there is not really a systematic development of these types of conversions from soft analysis to hard analysis, other than some recent papers arising from the proof theory approach to things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-29964")[#strong[#text("285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("[…] main idea here is to exploit what I have called the infinite convergence principle in a previous post: that every bounded monotone sequence converges. In the context of -solutions, we can apply this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The strong law of large numbers « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-30468")[#strong[#text("The strong law of large numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2008")])]

#text("[…] coming from the monotone convergence theorem is ineffective (one could effectivise this using the finite convergence principle, but this turns out to give very poor results […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-30486")[#strong[#text("Heavy tails of distributions of words in literary texts « Things I’m working on and thinking about… Gary E. Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")]

#text("[…] of a positive integer variable is slowly varying if as , for some number . (This is a “soft analysis” definition in Terry Tao’s sense, I believe. In the applications we have in mind it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-32326")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("[…] tools from one type of mathematics can be used to prove results in the other. (See my previous post on soft analysis and hard analysis for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness and the profile decomposition « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-33408")[#strong[#text("Concentration compactness and the profile decomposition « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2008")])]

#text("[…] fact we have the slightly stronger statement (2)). In particular, the must go to zero as (the infinite convergence principle!). If the were selected in a “greedy” manner, this shows that the asymptotic norm […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 1: Signed measures and the Radon-Nikodym-Lebesgue theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-34688")[#strong[#text("245B, notes 1: Signed measures and the Radon-Nikodym-Lebesgue theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2009")])]

#text("[…] non-trivial version of the above theory that can be applied to finite sets (cf. my blog post on the relationship between soft analysis and hard analysis). The cleanest formulation is to apply it to a sequence of (increasingly large) sets, rather than […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki: Give yourself an epsilon of room « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-36198")[#strong[#text("Tricks Wiki: Give yourself an epsilon of room « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("[…] Tao Today I’d like to discuss (in the Tricks Wiki format) a fundamental trick in “soft” analysis, sometimes known as the “limiting argument” or “epsilon […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Infinite fields, finite fields, and the Ax-Grothendieck theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-36427")[#strong[#text("Infinite fields, finite fields, and the Ax-Grothendieck theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("[…] the correspondence Serre discusses is slightly different from the one I discuss for instance in here or here, although there seems to be a common theme of “compactness” (or of model […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-39464")[#strong[#text("Sequential compactness theorem @ unwanted capture")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")]

#text("[…] the kind of correspondence principle that Tao has in mind, one which was discussed in detail in an earlier post from Tao’s blog. First we have what is essentially a quantitative version of the statement […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 把一些染色定理推广到高维去 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-40554")[#strong[#text("把一些染色定理推广到高维去 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("[…] 证明：首先，我们使用Van der waerden定理的有限形式：对于任意给定的k和m，存在N，使得只要,给集合染m种颜色，期间一定存在k长的单色等差数列。关于此种形式和一般形式的等价性，可以使用一个标准的方法证明。参看Tao教授的帖子，软分析和硬分析。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-42806")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] Looking at the statements and proofs of these two theorems it is clear that the two results are in some sense the “same” result, except that the latter has been made sufficiently quantitative that it is meaningful in such finitary settings as . In this note I will show how this equivalence can be made formal using the language of non-standard analysis. This is not a particularly deep (or new) observation, but it is perhaps the simplest example I know of that illustrates how nonstandard analysis can be used to transfer a quantifier-heavy finitary statement, such as Theorem 2, into a quantifier-light infinitary statement, such as Theorem 1, thus lessening the need to perform “epsilon management” duties, such as keeping track of unspecified growth functions such as . This type of transference is discussed at length in this previous blog post of mine. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-43421")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] Bezout's theorem, nonstandard analysis, ultrafilters, ultralimit analysis | by Terence Tao I have blogged a number of times in the past about the relationship between finitary (or “hard”, or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-43933")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] mathematics (involving only finitely many points or numbers, etc.); I have explored this theme in a number of previous blog posts. So, one may ask: what is the finitary analogue of statements such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-48889")[#strong[#text("Ultrafilters in Ramsey theory « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2010")]

#text("[…] theorem uses the infinite pigeonhole principle, which is stronger; this is part of the subject of a post by Terence Tao which is quite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/comment-page-1/#comment-93078")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] poor (particularly if the proof of (i) relied extensively on infinitary tools, such as limits). See this blog post for some related […]")
]
