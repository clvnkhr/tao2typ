// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/
// Converted to Typst by tao2typ: "2026-10-14T16:38:34.296461+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The spherical Cayley-Menger determinant and the radius of the Earth", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The spherical Cayley-Menger determinant and the radius of the Earth")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 May 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/")[#text("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given three points ")#mi("{A,B,C}")#text(" in the plane, the distances ")#tao-math("{\\left|AB\\right|, \\left|BC\\right|, \\left|AC\\right|}", block: false)#text(" between them have to be non-negative and obey the triangle inequalities")

#align(center)[#tao-fit-display[#tao-math("\\left|AB\\right| \\leq \\left|BC\\right| + \\left|AC\\right|, \\left|BC\\right| \\leq \\left|AC\\right| + \\left|AB\\right|, \\left|AC\\right| \\leq \\left|AB\\right| + \\left|BC\\right|", block: true)]]

#text("but are otherwise unconstrained. But if one has ")#emph[#text("four")]#text(" points ")#mi("{A,B,C,D}")#text(" in the plane, then there is an additional constraint connecting the six distances ")#tao-math("{\\left|AB\\right|, \\left|AC\\right|, \\left|AD\\right|, \\left|BC\\right|, \\left|BD\\right|, \\left|CD\\right|}", block: false)#text(" between them, coming from the ")#link("https://en.wikipedia.org/wiki/Cayley%E2%80%93Menger_determinant")[#text("Cayley-Menger determinant")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Cayley-Menger determinant)")]#text(" If ")#mi("{A,B,C,D}")#text(" are four points in the plane, then the Cayley-Menger determinant ")#metadata(none) <tao-327fb97d65cd3e8a4455>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\mathrm{det} \\begin{pmatrix} 0 & 1 & 1 & 1 & 1 \\\\ 1 & 0 & \\left|AB\\right|^2 & \\left|AC\\right|^2 & \\left|AD\\right|^2 \\\\ 1 & \\left|AB\\right|^2 & 0 & \\left|BC\\right|^2 & \\left|BD\\right|^2 \\\\ 1 & \\left|AC\\right|^2 & \\left|BC\\right|^2 & 0 & \\left|CD\\right|^2 \\\\ 1 & \\left|AD\\right|^2 & \\left|BD\\right|^2 & \\left|CD\\right|^2 & 0 \\end{pmatrix}", block: true)]]

#text("vanishes.")
]

#emph[#text("Proof:")]#text(" If we view ")#mi("{A,B,C,D}")#text(" as vectors in ")#mi("{{\\bf R}^2}")#text(", then we have the usual cosine rule ")#tao-math("{\\left|AB\\right|^2 = \\left|A\\right|^2 + \\left|B\\right|^2 - 2 A \\cdot B}", block: false)#text(", and similarly for all the other distances. The ")#mi("{5 \\times 5}")#text(" matrix appearing in ")#link(<tao-327fb97d65cd3e8a4455>)[#text("(1)")]#text(" can then be written as ")#mi("{M+M^T-2\\tilde G}")#text(", where ")#mi("{M}")#text(" is the matrix")

#align(center)[#tao-fit-display[#tao-math("M := \\begin{pmatrix} 0 & 0 & 0 & 0 & 0 \\\\ 1 & \\left|A\\right|^2 & \\left|B\\right|^2 & \\left|C\\right|^2 & \\left|D\\right|^2 \\\\ 1 & \\left|A\\right|^2 & \\left|B\\right|^2 & \\left|C\\right|^2 & \\left|D\\right|^2 \\\\ 1 & \\left|A\\right|^2 & \\left|B\\right|^2 & \\left|C\\right|^2 & \\left|D\\right|^2 \\\\ 1 & \\left|A\\right|^2 & \\left|B\\right|^2 & \\left|C\\right|^2 & \\left|D\\right|^2 \\end{pmatrix}", block: true)]]

#text("and ")#mi("{\\tilde G}")#text(" is the (augmented) ")#link("https://en.wikipedia.org/wiki/Gramian_matrix")[#text("Gram matrix")]

#align(center)[#tao-fit-display[#mitex("\\tilde G := \\begin{pmatrix} 0 & 0 & 0 & 0 & 0 \\\\ 0 & A \\cdot A & A \\cdot B & A \\cdot C & A \\cdot D \\\\ 0 & B \\cdot A & B \\cdot B & B \\cdot C & B \\cdot D \\\\ 0 & C \\cdot A & C \\cdot B & C \\cdot C & C \\cdot D \\\\ 0 & D \\cdot A & D \\cdot B & D \\cdot C & D \\cdot D \\end{pmatrix}.")]]

#text("The matrix ")#mi("{M}")#text(" is a rank one matrix, and so ")#mi("{M^T}")#text(" is also. The Gram matrix ")#mi("{\\tilde G}")#text(" factorises as ")#mi("{\\tilde G = \\tilde \\Sigma \\tilde \\Sigma^T}")#text(", where ")#mi("{\\tilde \\Sigma}")#text(" is the ")#mi("{5 \\times 2}")#text(" matrix with rows ")#mi("{0,A,B,C,D}")#text(", and thus has rank at most ")#mi("{2}")#text(". Therefore the matrix ")#mi("{M+M^T-2\\tilde G}")#text(" in ")#link(<tao-327fb97d65cd3e8a4455>)[#text("(1)")]#text(" has rank at most ")#mi("{1+1+2=4}")#text(", and hence has determinant zero as claimed. ")#mi("\\Box")

#text("For instance, if we know that ")#tao-math("{\\left|AB\\right|=\\left|AC\\right|=\\left|DB\\right|=\\left|DC\\right|=1}", block: false)#text(" and ")#tao-math("{\\left|BC\\right|=\\sqrt{2}}", block: false)#text(", then in order for ")#mi("{A,B,C,D}")#text(" to be coplanar, the remaining distance ")#tao-math("{\\left|AD\\right|}", block: false)#text(" has to obey the equation")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{det} \\begin{pmatrix} 0 & 1 & 1 & 1 & 1 \\\\ 1 & 0 & 1 & 1 & \\left|AD\\right|^2 \\\\ 1 & 1 & 0 & 2 & 1 \\\\ 1 & 1 & 2 & 0 & 1 \\\\ 1 & \\left|AD\\right|^2 & 1 & 1 & 0 \\end{pmatrix} = 0.", block: true)]]

#text("After some calculation the left-hand side simplifies to ")#tao-math("{-4 \\left|AD\\right|^4 + 8 \\left|AD\\right|^2}", block: false)#text(", so the non-negative quantity is constrained to equal either ")#mi("{0}")#text(" or ")#mi("{\\sqrt{2}}")#text(". The former happens when ")#mi("{A,B,C}")#text(" form a unit right-angled triangle with right angle at ")#mi("{A}")#text(" and ")#mi("{D=A}")#text("; the latter happens when ")#mi("{A,B,D,C}")#text(" form the vertices of a unit square traversed in that order. Any other value for ")#tao-math("{\\left|AD\\right|}", block: false)#text(" is not compatible with the hypothesis for ")#mi("{A,B,C,D}")#text(" lying on a plane; hence the Cayley-Menger determinant can be used as a test for planarity.")

#text("Now suppose that we have four points ")#mi("{A,B,C,D}")#text(" on a sphere ")#mi("{S_R}")#text(" of radius ")#mi("{R}")#text(", with six distances ")#tao-math("{\\left|AB\\right|_R, \\left|AC\\right|_R, \\left|AD\\right|_R, \\left|BC\\right|_R, \\left|BD\\right|_R, \\left|AD\\right|_R}", block: false)#text(" now measured as lengths of arcs on the sphere. There is a spherical analogue of the Cayley-Menger determinant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Spherical Cayley-Menger determinant)")]#text(" If ")#mi("{A,B,C,D}")#text(" are four points on a sphere ")#mi("{S_R}")#text(" of radius ")#mi("{R}")#text(" in ")#mi("{{\\bf R}^3}")#text(", then the spherical Cayley-Menger determinant ")#metadata(none) <tao-fc8060a7f06fbc722e6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\mathrm{det} \\begin{pmatrix} 1 & \\cos \\frac{\\left|AB\\right|_R}{R} & \\cos \\frac{\\left|AC\\right|_R}{R} & \\cos \\frac{\\left|AD\\right|_R}{R} \\\\ \\cos \\frac{\\left|AB\\right|_R}{R} & 1 & \\cos \\frac{\\left|BC\\right|_R}{R} & \\cos \\frac{\\left|BD\\right|_R}{R} \\\\ \\cos \\frac{\\left|AC\\right|_R}{R} & \\cos \\frac{\\left|BC\\right|_R}{R} & 1 & \\cos \\frac{\\left|CD\\right|_R}{R} \\\\ \\cos \\frac{\\left|AD\\right|_R}{R} & \\cos \\frac{\\left|BD\\right|_R}{R} & \\cos \\frac{\\left|CD\\right|_R}{R} & 1 \\end{pmatrix}", block: true)]]

#text("vanishes.")
]

#emph[#text("Proof:")]#text(" We can assume that the sphere ")#mi("{S_R}")#text(" is centred at the origin of ")#mi("{{\\bf R}^3}")#text(", and view ")#mi("{A,B,C,D}")#text(" as vectors in ")#mi("{{\\bf R}^3}")#text(" of magnitude ")#mi("{R}")#text(". The angle subtended by ")#mi("{AB}")#text(" from the origin is ")#tao-math("{\\left|AB\\right|_R/R}", block: false)#text(", so by the cosine rule we have")

#align(center)[#tao-fit-display[#tao-math("A \\cdot B = R^{2} \\cos \\frac{\\left|AB\\right|_R}{R}.", block: true)]]

#text("Similarly for all the other inner products. Thus the matrix in ")#link(<tao-fc8060a7f06fbc722e6e>)[#text("(2)")]#text(" can be written as ")#mi("{R^{-2} G}")#text(", where ")#mi("{G}")#text(" is the Gram matrix")

#align(center)[#tao-fit-display[#mitex("G := \\begin{pmatrix} A \\cdot A & A \\cdot B & A \\cdot C & A \\cdot D \\\\ B \\cdot A & B \\cdot B & B \\cdot C & B \\cdot D \\\\ C \\cdot A & C \\cdot B & C \\cdot C & C \\cdot D \\\\ D \\cdot A & D \\cdot B & D \\cdot C & D \\cdot D \\end{pmatrix}.")]]

#text("We can factor ")#mi("{G = \\Sigma \\Sigma^T}")#text(" where ")#mi("{\\Sigma}")#text(" is the ")#mi("{4 \\times 3}")#text(" matrix with rows ")#mi("{A,B,C,D}")#text(". Thus ")#mi("{R^{-2} G}")#text(" has rank at most ")#mi("{3}")#text(" and thus the determinant vanishes as required. ")#mi("\\Box")

#text("Just as the Cayley-Menger determinant can be used to test for coplanarity, the spherical Cayley-Menger determinant can be used to test for lying on a sphere of radius ")#mi("{R}")#text(". For instance, if we know that ")#mi("{A,B,C,D}")#text(" lie on ")#mi("{S_R}")#text(" and ")#tao-math("{\\left|AB\\right|_R, \\left|AC\\right|_R, \\left|BC\\right|_R, \\left|BD\\right|_R, \\left|CD\\right|_R}", block: false)#text(" are all equal to ")#mi("{\\pi R/2}")#text(", then the above proposition gives")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{det} \\begin{pmatrix} 1 & 0 & 0 & \\cos \\frac{\\left|AD\\right|_R}{R} \\\\ 0 & 1 & 0 & 0 \\\\ 0 & 0 & 1 & 0 \\\\ \\cos \\frac{\\left|AD\\right|_R}{R} & 0 & 0 & 1 \\end{pmatrix} = 0.", block: true)]]

#text("The left-hand side evaluates to ")#tao-math("{1 - \\cos^2 \\frac{\\left|AD\\right|_R}{R}}", block: false)#text("; as ")#tao-math("{\\left|AD\\right|_R}", block: false)#text(" lies between ")#mi("{0}")#text(" and ")#mi("{\\pi R}")#text(", the only choices for this distance are then ")#mi("{0}")#text(" and ")#mi("{\\pi R}")#text(". The former happens for instance when ")#mi("{A}")#text(" lies on the north pole ")#mi("{(R,0,0)}")#text(", ")#mi("{B = (0,R,0), C = (0,R,0)}")#text(" are points on the equator with longitudes differing by 90 degrees, and ")#mi("{D=(R,0,0)}")#text(" is also equal to the north pole; the latter occurs when ")#mi("{D=(-R,0,0)}")#text(" is instead placed on the south pole.")

#text("The Cayley-Menger and spherical Cayley-Menger determinants look slightly different from each other, but one can transform the latter into something resembling the former by row and column operations. Indeed, the determinant ")#link(<tao-fc8060a7f06fbc722e6e>)[#text("(2)")]#text(" can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{det} \\begin{pmatrix} 1 & 1 & 1 & 1 & 1 \\\\ 1 & 0 & 1 - \\cos \\frac{\\left|AB\\right|_R}{R} & 1 - \\cos \\frac{\\left|AC\\right|_R}{R} & 1 - \\cos \\frac{\\left|AD\\right|_R}{R} \\\\ 1 & 1-\\cos \\frac{\\left|AB\\right|_R}{R} & 0 & 1-\\cos \\frac{\\left|BC\\right|_R}{R} & 1- \\cos \\frac{\\left|BD\\right|_R}{R} \\\\ 1 & 1-\\cos \\frac{\\left|AC\\right|_R}{R} & 1-\\cos \\frac{\\left|BC\\right|_R}{R} & 0 & 1-\\cos \\frac{\\left|CD\\right|_R}{R} \\\\ 1 & 1-\\cos \\frac{\\left|AD\\right|_R}{R} & 1-\\cos \\frac{\\left|BD\\right|_R}{R} & 1- \\cos \\frac{\\left|CD\\right|_R}{R} & 0 \\end{pmatrix}", block: true)]]

#text("and by further row and column operations, this determinant vanishes if and only if the determinant ")#metadata(none) <tao-b5594ea998144e67ed06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\mathrm{det} \\begin{pmatrix} \\frac{1}{2R^2} & 1 & 1 & 1 & 1 \\\\ 1 & 0 & f_R(\\left|AB\\right|_R) & f_R(\\left|AC\\right|_R) & f_R(\\left|AD\\right|_R) \\\\ 1 & f_R(\\left|AB\\right|_R) & 0 & f_R(\\left|BC\\right|_R) & f_R(\\left|BD\\right|_R) \\\\ 1 & f_R(\\left|AC\\right|_R) & f_R(\\left|BC\\right|_R) & 0 & f_R(\\left|CD\\right|_R) \\\\ 1 & f_R(\\left|AD\\right|_R) & f_R(\\left|BD\\right|_R) & f_R(\\left|CD\\right|_R) & 0 \\end{pmatrix}", block: true)]]

#text("vanishes, where ")#mi("{f_R(x) := 2R^2 (1-\\cos \\frac{x}{R})}")#text(". In the limit ")#mi("{R \\rightarrow \\infty}")#text(" (so that the curvature of the sphere ")#mi("{S_R}")#text(" tends to zero), ")#tao-math("{\\left|AB\\right|_R}", block: false)#text(" tends to ")#tao-math("{\\left|AB\\right|}", block: false)#text(", and by Taylor expansion ")#tao-math("{f_R(\\left|AB\\right|_R)}", block: false)#text(" tends to ")#tao-math("{\\left|AB\\right|^2}", block: false)#text("; similarly for the other distances. Now we see that the planar Cayley-Menger determinant emerges as the limit of ")#link(<tao-b5594ea998144e67ed06>)[#text("(3)")]#text(" as ")#mi("{R \\rightarrow \\infty}")#text(", as would be expected from the intuition that a plane is essentially a sphere of infinite radius.")

#text("In principle, one can now estimate the radius ")#mi("{R}")#text(" of the Earth (assuming that it is either a sphere ")#mi("{S_R}")#text(" or a flat plane ")#mi("{S_\\infty}")#text(") if one is given the six distances ")#tao-math("{\\left|AB\\right|_R, \\left|AC\\right|_R, \\left|AD\\right|_R, \\left|BC\\right|_R, \\left|BD\\right|_R, \\left|CD\\right|_R}", block: false)#text(" between four points ")#mi("{A,B,C,D}")#text(" on the Earth. Of course, if one wishes to do so, one should have ")#mi("{A,B,C,D}")#text(" rather far apart from each other, since otherwise it would be difficult to for instance distinguish the round Earth from a flat one. As an experiment, and just for fun, I wanted to see how accurate this would be with some real world data. I decided to take ")#mi("{A}")#text(", ")#mi("{B}")#text(", ")#mi("{C}")#text(", ")#mi("{D}")#text(" be the cities of London, Los Angeles, Tokyo, and Dubai respectively. As an initial test, I used distances from ")#link("https://flighttime-calculator.com/")[#text("this online flight calculator")]#text(", measured in kilometers:")

#tao-aligned(keep: true)[


#tao-math("\\left|AB\\right|_R  & = 8790", block: true)



#tao-math("\\left|AC\\right|_R  & = 9597 \\mathrm{km}", block: true)



#tao-math("\\left|AD\\right|_R  & = 5488\\mathrm{km}", block: true)



#tao-math("\\left|BC\\right|_R  & = 8849\\mathrm{km}", block: true)



#tao-math("\\left|BD\\right|_R  & = 13435\\mathrm{km}", block: true)



#tao-math("\\left|CD\\right|_R  & = 7957\\mathrm{km}.", block: true)
]

#text("Given that the true radius of the earth was about ")#mi("{R_0 := 6371 \\mathrm{km}}")#text(" kilometers, I chose the change of variables ")#mi("{R = R_0/k}")#text(" (so that ")#mi("{k=1}")#text(" corresponds to the round Earth model with the commonly accepted value for the Earth’s radius, and ")#mi("{k=0}")#text(" corresponds to the flat Earth), and obtained the following plot for ")#link(<tao-b5594ea998144e67ed06>)[#text("(3)")]#text(":")

#image("../assets/441f0ce8a9629f15e04850cec2f7f6a9fddc6f43b5fee59415542a19bdef7625-3c5fd48551a0ed0e71819e23478db9109a8938ec474ff8dc45ea6fed37415262.png", width: 90%)

#text("In particular, the determinant does indeed come very close to vanishing when ")#mi("{k=1}")#text(", which is unsurprising since, as ")#link("https://flighttime-calculator.com/flighttime-flightdistance-calculation")[#text("explained on the web site")]#text(", the online flight calculator uses a model in which the Earth is an ellipsoid of radii close to ")#mi("{6371}")#text(" km. There is another radius that would also be compatible with this data at ")#mi("{k\\approx 1.3}")#text(" (corresponding to an Earth of radius about ")#mi("{4900}")#text(" km), but presumably one could rule out this as a spurious coincidence by experimenting with other quadruples of cities than the ones I selected. On the other hand, these distances are highly incompatible with the flat Earth model ")#mi("{k=0}")#text("; one could also see this with a piece of paper and a ruler by trying to lay down four points ")#mi("{A,B,C,D}")#text(" on the paper with (an appropriately rescaled) version of the above distances (e.g., with ")#tao-math("{\\left|AB\\right| = 8.790 \\mathrm{cm}}", block: false)#text(", ")#tao-math("{\\left|AC\\right| = 9.597 \\mathrm{cm}}", block: false)#text(", etc.).")

#text("If instead one goes to the flight time calculator and uses flight travel times instead of distances, one now gets the following data (measured in hours):")

#tao-aligned(keep: true)[


#tao-math("\\left|AB\\right|_R  & = 10\\mathrm{h}\\ 3\\mathrm{m}", block: true)



#tao-math("\\left|AC\\right|_R  & = 11\\mathrm{h}\\ 49\\mathrm{m}", block: true)



#tao-math("\\left|AD\\right|_R  & = 6\\mathrm{h}\\ 56\\mathrm{m}", block: true)



#tao-math("\\left|BC\\right|_R  & = 10\\mathrm{h}\\ 56\\mathrm{m}", block: true)



#tao-math("\\left|BD\\right|_R  & = 16\\mathrm{h}\\ 23\\mathrm{m}", block: true)



#tao-math("\\left|CD\\right|_R  & = 9\\mathrm{h}\\ 52\\mathrm{m}.", block: true)
]

#text("Assuming that planes travel at about ")#mi("{800}")#text(" kilometers per hour, the true radius of the Earth should be about ")#mi("{R_1 := 8\\mathrm{h}}")#text(" of flight time. If one then uses the normalisation ")#mi("{R = R_1/k}")#text(", one obtains the following plot:")

#image("../assets/416fd9d3d76ab024eb0a6324563ba74df3d452a6f080eb4dd5a8b7b06037adcb-493f16d8b5be0df77f35e0fd04225eaa301a3aebc067e7fad63b886b54f21e9d.png", width: 90%)

#text("Not too surprisingly, this is basically a rescaled version of the previous plot, with vanishing near ")#mi("{k=1}")#text(" and at ")#mi("{k=1.3}")#text(". (The website for the flight calculator does say it calculates short and long haul flight times slightly differently, which may be the cause of the slight discrepancies between this figure and the previous one.)")

#text("Of course, these two data sets are “cheating” since they come from a model which already presupposes what the radius of the Earth is. But one can input real world flight times between these four cities instead of the above idealised data. Here one runs into the issue that the flight time from ")#mi("{A}")#text(" to ")#mi("{B}")#text(" is not necessarily the same as that from ")#mi("{B}")#text(" to ")#mi("{A}")#text(" due to such factors as windspeed. For instance, I looked up the online flight time from Tokyo to Dubai to be 11 hours and 10 minutes, whereas the online flight time from Dubai to Tokyo was 9 hours and 50 minutes. The simplest thing to do here is take an arithmetic mean of the two times as a preliminary estimate for the flight time without windspeed factors, thus for instance the Tokyo-Dubai flight time would now be 10 hours and 30 minutes, and more generally")

#tao-aligned(keep: true)[


#tao-math("\\left|AB\\right|_R  & = 10\\mathrm{h}\\ 47\\mathrm{m}", block: true)



#tao-math("\\left|AC\\right|_R  & = 12\\mathrm{h}\\ 0\\mathrm{m}", block: true)



#tao-math("\\left|AD\\right|_R  & = 7\\mathrm{h}\\ 17\\mathrm{m}", block: true)



#tao-math("\\left|BC\\right|_R  & = 10\\mathrm{h}\\ 50\\mathrm{m}", block: true)



#tao-math("\\left|BD\\right|_R  & = 15\\mathrm{h}\\ 55\\mathrm{m}", block: true)



#tao-math("\\left|CD\\right|_R  & = 10\\mathrm{h}\\ 30\\mathrm{m}.", block: true)
]

#text("This data is not too far off from the online calculator data, but it does distort the graph slightly (taking ")#mi("{R=8/k}")#text(" as before):")

#image("../assets/043b155ae4193ee9bcee91eb5a14b3ccf8eadbfd38be0d72342feed294acfdb2-f4cde3a57be8aee36baa72556f9347cb3081493d2149e80c43afd4b455c48671.png", width: 90%)

#text("Now one gets estimates for the radius of the Earth that are off by about a factor of ")#mi("{2}")#text(" from the truth, although the ")#mi("{k=1}")#text(" round Earth model still is twice as accurate as the flat Earth model ")#mi("{k=0}")#text(".")

#text("Given that windspeed should additively affect flight velocity rather than flight time, and the two are inversely proportional to each other, it is more natural to take a ")#link("https://en.wikipedia.org/wiki/Harmonic_mean")[#text("harmonic mean")]#text(" rather than an arithmetic mean. This gives the slightly different values")

#tao-aligned(keep: true)[


#tao-math("\\left|AB\\right|_R  & = 10\\mathrm{h}\\ 51\\mathrm{m}", block: true)



#tao-math("\\left|AC\\right|_R  & = 11\\mathrm{h}\\ 59\\mathrm{m}", block: true)



#tao-math("\\left|AD\\right|_R  & = 7\\mathrm{h}\\ 16\\mathrm{m}", block: true)



#tao-math("\\left|BC\\right|_R  & = 10\\mathrm{h}\\ 46\\mathrm{m}", block: true)



#tao-math("\\left|BD\\right|_R  & = 15\\mathrm{h}\\ 54\\mathrm{m}", block: true)



#tao-math("\\left|CD\\right|_R  & = 10\\mathrm{h}\\ 27\\mathrm{m}", block: true)
]

#text("but one still gets essentially the same plot:")

#image("../assets/0dbf757ceb091ad88dbece550b635c4d3cfd7fc7bec56c542244134b3dc933aa-9e9e25a1f63f0c605cfafc369f11c04af223a79e99766126743e74d3c8512674.png", width: 90%)

#text("So the inaccuracies are presumably coming from some other source. (Note for instance that the true flight time from Tokyo to Dubai is about ")#mi("{6\\%}")#text(" greater than the calculator predicts, while the flight time from LA to Dubai is about ")#mi("{3\\%}")#text(" less; these sorts of errors seem to pile up in this calculation.) Nevertheless, it does seem that flight time data is (barely) enough to establish the roundness of the Earth and obtain a somewhat ballpark estimate for its radius. (I assume that the fit would be better if one could include some Southern Hemisphere cities such as Sydney or Santiago, but I was not able to find a good quadruple of widely spaced cities on both hemispheres for which there were direct flights between all six pairs.)")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mircea")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516647")[#strong[#text("Mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("Maybe the Cayley-Menger determinant calculations here are related to Schoenberg’s theorem on embeddability of metric spaces in Euclidean spaces, or to some special case of it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94f5ae54fcca3079015fb21388521b84a1f041374db0bf2dcee5b89e352c1e82-a9361974d3f6491bd1478fb00d92d5b0b5701937d87d44f0b5d9bfc657496896.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amsmath")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516655")[#strong[#text("amsmath")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("I am actually quite full right now, but I am kinda sure that „but one can transform the latter into something resembling the latter“ was not meant to be said. Good night.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516659")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("I think that real travel data can have too many factors: there’s an additive constant of take off and landing; planes might not fly on the shortest path; between different cities there might be different planes flying with different speeds. Because of this, the distance based model sounds more reliable. I wonder what it would give for 4 nearby cities, e.g., like all in the US.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2019")])]

#text("It would be interesting to generalize (if possible) this determinant to ")#mi("m")#text(" points in ")#mi("\\mathbb R^n")#text(" and to n-spheres.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516670")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2019")])]

#text("Propositions 1 and 2 extend to higher dimensions (taking ")#mi("m=n+2")#text(" throughout), with basically the same proof. There is also a variant of these propositions, due to Menger and Schoenberg, describing exactly when a set of putative distances ")#mi("d_{ij}, 1 \\leq i,j \\leq m")#text(" between ")#mi("m")#text(" points can be realised in ")#mi("{\\bf R}^n")#text(" or ")#mi("S^n")#text(" in terms of the positive semi-definiteness and rank properties of matrices similar to those appearing in those propositions: see Theorem 2.1, 2.3 of ")#link("https://arxiv.org/abs/1812.05482")[#text("https://arxiv.org/abs/1812.05482")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3357f9caffa41f80d34f24eac153a8dd25889673999d5fc7bb0641309a2634f7-91ea8d65b625eb8a772cd38b2682a42c950f875fef90ce2e1c3736a8966f62d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ravenclawprefect")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516668")[#strong[#text("ravenclawprefect")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2019")])]

#text("I assume these flight times include factors like taxiing and the process of obtaining cruising speed and altitude, which should be reasonably similar across long-haul flights.")

#text("If we subtract an hour uniformly from the times in the last graph (really I should subtract first and then take the harmonic mean, but I don’t have the original times and suspect it doesn’t make much difference), we get the graph at ")#link("https://imgur.com/rdkfrqU")[#text("https://imgur.com/rdkfrqU")]#text(", where the tally marks are at k=0.8, 1, and 1.2. Clearly, this gives far better agreement with the true radius of the Earth. (Apologies for the low quality, I’m rendering it pixel-by-pixel in a simple Python script.)")

#text("Of course, an hour happens to work remarkably well here, and I’m not sure this is the actual time to reach cruising altitude in most long-haul flights, but it suggests that taking this sort of thing into consideration would give much closer estimates.")

#text("(By comparing multiple 4-tuples of cities, one might be able to work out what this constant should be by trying to maximize consistency, even without knowing any details of real-life plane flights.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabe")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516684")[#strong[#text("Gabe")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2019")])]

#text("I agree that flight times aren’t ideal here. I assume the idea is to use a metric that everyone agrees on. Are latitude and longitude undisputable enough?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef4423c53c5ed17f86aef264f9ac9e0649daa01ff0ec29d66444a41ad200afa-deb84e0d9e9d8d5f0fd26405aad02f813f1e39286fecfb7faa41881d008c848f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of postmortes")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516828")[#strong[#text("postmortes")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("It’s reasonably well-known (see for example, ")#link("https://www.theguardian.com/world/2018/aug/27/flight-times-extended-by-major-airlines-to-avoid-payouts-report-claims")[#text("https://www.theguardian.com/world/2018/aug/27/flight-times-extended-by-major-airlines-to-avoid-payouts-report-claims")]#text(" ) that flight times are padded — not just to avoid payouts, but to anticipate problems and delays. So using flight times is unfortunately a poor choice as you’ll struggle to compensate for the unknown padding added by each airline.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ae58e6b8fe5ea3144afad20c33803980fff19ebea195c1aa3bc437c7b64deb0-eb4c1da61b282a2a26dc1694f4cea0f29baa9c82633749b5cbc78520b9b96621.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516669")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2019")])]

#text("Does a similar determinant (with hyperbolic cosines and curvature instead of the radius) exist in hyperbolic plane (e.g. by means of the analytic continuation)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516671")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2019")])]

#text("Yes; one simply works with the unit hyperboloid in Minkowski space instead of the unit sphere in Euclidean space (with the Minkowski inner product replacing the Euclidean dot product, and hyperbolic angle replacing Euclidean angle). Analytic continuation would also work (in the spirit of Osborn’s rule). I haven’t plotted the graphs, but would suspect that the hyperbolic Earth model (replacing all the cosines by hyperbolic cosines) would fare worse than the flat or round Earth models for all the data sets given above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("It seems that in the context of special relativity, the distances correspond to Minkowski metric (i.e. “proper times” between spacetime events.)")#linebreak()#text(" Is it possible to replace your example of the time of flight data by a similar example of measured proper times of propagation of signals from several GPS satellites to a GPS rceiver ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/facde9293129e2fc7cd1d7f68029bebb08cae323354c460cd926523ac70186e7-58ed111715d5737c1c5fed43ef0bd35e705ea0ce258ad3096d13a16f4019f66e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of njwildberger: tangential thoughts")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516698")[#strong[#text("njwildberger: tangential thoughts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2019")])]

#text("This entire subject is much simplified, and logically improved, if you make the transition to Rational Trigonometry. We dispense with angles and lengths, and rely rather on the purely algebraic analogs coming ultimately from the quadratic form or symmetric bilinear form which generates the geometry. There is then no mention of circular functions and their inverses. For a (very) elementary introduction, see my Wild Trig YouTube series, or for something more advanced which explains the spherical versions, see the lectures in Part II of the Universal Hyperbolic Geometry series starting with ")#link("https://www.youtube.com/watch?v=Sop6KXIX014&list=PLIljB45xT85DZby7Ju-SupKHxErzdRvgI")[#text("https://www.youtube.com/watch?v=Sop6KXIX014&list=PLIljB45xT85DZby7Ju-SupKHxErzdRvgI")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d479a9092fe57b8e2d6d6fcf5793c0b4c028ece225497abd395a6e04838173d4-8ce432f383f6a7eae62e471ed084d3a631332791756696ffaae5ca39d7a86c65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of df")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516792")[#strong[#text("df")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("Rational Trigonometry is great.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b77d7c433b7d869610ec7e7a6432ac638e6eb233d70bae864ab44397d3335a3-399cf85bb4cfd1f072b9b6dec0d69176bafdd29cdc7becd9ff4a57d8efcb80f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of no")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516880")[#strong[#text("no")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("No it’s not.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516708")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2019")])]

#text("This does not prove anything or close to prove anything or increase evidence of anything or shows anything close to what Occam’s razor would need. You are looking at two biased hypothesis and making a conclusion from that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gosha F")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516714")[#strong[#text("Gosha F")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2019")])]

#text("It seems that $\\Sigma$ in the first proof is $5\\times 1$, so that $\\mathrm{rank}(M + M^T – 2\\widetilde{G}) = 1 + 1 + 1$")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gosha F")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516715")[#strong[#text("Gosha F")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2019")])]

#text("No, it isn’t. Sorry, mixed it up.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60cc2a1d3313a6d9fca3d9ee957c389aecf587f2de8d701460179a053e52eb99-602c64e5076dd8b436fbb81d7987c4f8dc0d377635cb2933d62ab654ded306b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Malkevitch")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516718")[#strong[#text("Joseph Malkevitch")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2019")])]

#text("A tetrahedron is a collection of 4 points in 3-space that don’t lie in a plane or have three points on a line. One can think of a “degenerate” tetrahedron as 4 points in the plane, no three on a line, which will determine 6 distances. The existence of a tetrahedron can be determined using the Cayley-Menger determinant (together with having the triangle inequality hold properly for each of the 4 faces). The space of ordered sextuples (corresponding to some canonical labeling of the edges) it seems to me deserves to be better explored in the context of edge lengths of tetrahedra. In particular, such a sextuple (reordered) can be realized by anywhere from 0 to 30 tetrahedra, but, for example, what sextuples correspond to having exactly 23 tetrahedra is poorly explored and understood. Furthermore, there is a not widely known 3×3 determinant due to William McCrae, Analytical Geometry of Three Dimensions, 2nd. ed., pg. 30 (There is a Dover Press edition.) that can be used to determine when a candidate sextuple for a tetrahedron has positive or zero volume.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f1c2c26011ae8e2fcbab19e893755ad90265322d1a7e66b36b824b74823267-3bc7d9b12889e567e74ca96a5585b9c14093284cc1ec545eea5b7b873e4b3430.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YG")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516974")[#strong[#text("YG")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")])]

#text("“In particular, such a sextuple (reordered) can be realized by anywhere from 0 to 30 tetrahedra, but, for example, what sextuples correspond to having exactly 23 tetrahedra is poorly explored and understood” – Do you have any reference for that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60cc2a1d3313a6d9fca3d9ee957c389aecf587f2de8d701460179a053e52eb99-602c64e5076dd8b436fbb81d7987c4f8dc0d377635cb2933d62ab654ded306b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Malkevitch")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516983")[#strong[#text("Joseph Malkevitch")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2019")])]

#text("Look at this paper and the references given there:")

#link("https://faculty.math.illinois.edu/~hildebr/ugresearch/Hildebrand-Calculus-Spring2015-report.pdf")[#text("Click to access Hildebrand-Calculus-Spring2015-report.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-681970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("McCrae is spelled incorrectly. See")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/William_McCrea_(astronomer)")[#text("https://en.wikipedia.org/wiki/William_McCrea_(astronomer)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da01e4265ed807ad6ee44b9ead6b6c26e3154f23822b76aea126badbb9c61b56-e6af651d569ce1e201d73c1d5d45a84ab5a4a6c99ca4f5d87826e3d431ce9f8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GeneralAi")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516808")[#strong[#text("GeneralAi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2019")])]

#text("Terence tao why don’t you work in the area of motion planning and specific humanoid motion palnning?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8b535ba19730c35a11a54e0f6a172b8257b3231d3f6bcb585012a98f16a4c7-b074f52a1020db534fef6621b105be8a1ffe96a2efd905bdf88cb80e35925a68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehud")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516847")[#strong[#text("Ehud")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2019")])]

#text("A heuristic for why I would expect one constraint (realized by the Cayley-Menger determinant) for this problem: There are 2*4 = 8 degrees of freedom in the coordinates of the four points in the plane, but translations (2 d.o.f) and rotations (1 d.o.f) leave the distances invariant. Hence there are 8 – 2 – 1 = 5 degrees of freedom for the 6 distances, leaving them indeed with 1 constraint.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2019")])]

#text("Maybe the error is because you didn’t take into account that the Earth is flat. Or maybe this is what you’re trying to prove!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afb929af1f2f0756f453f00125ae7ae7bf05309fe96db8c676eff4323580099b-23132d79826bb986eb9179697697a2d83f1e21fe4f888557994d3cec43431f84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516912")[#strong[#text("Jean")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("Hello ,maybe im totally wrong, but why can G be not factorized into simply 5×1 (0,A,B,C,D)^t . Then (0,A,B,C,D)^t * (0,A,B,C,D) i would get G. Same case in the spherical case just without the 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/afb929af1f2f0756f453f00125ae7ae7bf05309fe96db8c676eff4323580099b-23132d79826bb986eb9179697697a2d83f1e21fe4f888557994d3cec43431f84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-516931")[#strong[#text("Jean")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Hello, i totally forgot that A, B , C, D are vectors, my mistake")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-518110")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2019")])]

#text("Projective geometry is very interesting. For instance, coplanarity in projective 3-space is invariant under projective transformations. Yet, the Cayley‒Menger determinant is not invariant under projective transformations.")

#text("After all, this determinant describes the volume of a simplex ")#mi("S")#text(", so that the formula ")#mi("\\mu(LS) = \\det(L) \\mu(S)")#text(" holds, where ")#mi("L")#text(" is a linear transformation.")

#text("Unfortunately, projective transformations seem to create chaos. Suppose that ")#mi("\\mathbb R^3")#text(" is embedded in ")#mi("\\mathbb R^4")#text(" via the embedding ")#mi("(x_1, x_2, x_3) \\mapsto (x_1, x_2, x_3, 1)")#text(". Obviously, the volume of any simplex in ")#mi("\\mathbb R^3")#text(" remains invariant under any shifts along ")#mi("\\mathbb R^3")#text(", and we may extract the volume by passing to a four-dimensional simplex by adjoining a suitable fifth point. Yet dependent on where the simplex is, once the (4D) linear transformation behind the (3D) projective transformation is applied, the volume of the augmented simplex will have a different relation to the volume of the original simplex.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8623715e7208758e7e29420dffcbdbd91ce2e73185ed98ed07d8495b4a71f9c-1b73944890bb4f0cc314afce2f7216bee1e59d2a6bddaac644986efd0402bd9e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2019/05/25/the-spherical-cayley-menger-determinant-and-the-radius-of-the-earth/#comment-519713")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2019")])]

#text("I don’t think it’s the greatest assumption to say that the Earth should be approximated by a sphere, although the difference in error for GPS is usually miniscule for most applications. Using the wgs 84 framework with an ellipsoid revolute is what most technology companies appear to be using today, even if egm 96 is replacing it, most calculations are intensive with a topographic map of Earth’s geoid. Still, this is a cool tidbit. This blog is neat, I certainly can’t remember anything about measure theory and differential geometry but Terry’s theorems definitely look amazing.")
]
