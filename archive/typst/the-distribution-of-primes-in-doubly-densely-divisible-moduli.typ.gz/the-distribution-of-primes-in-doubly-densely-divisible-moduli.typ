// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/
// Converted to Typst by tao2typ: "2026-10-14T09:32:18.361186+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The distribution of primes in doubly densely divisible moduli", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The distribution of primes in doubly densely divisible moduli")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As in previous posts, we use the following asymptotic notation: ")#mi("{x}")#text(" is a parameter going off to infinity, and all quantities may depend on ")#mi("{x}")#text(" unless explicitly declared to be “fixed”. The asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" is then defined relative to this parameter. A quantity ")#mi("{q}")#text(" is said to be ")#emph[#text("of polynomial size")]#text(" if one has ")#mi("{q = O(x^{O(1)})}")#text(", and ")#emph[#text("bounded")]#text(" if ")#mi("{q=O(1)}")#text(". We also write ")#mi("{X \\lessapprox Y}")#text(" for ")#mi("{X \\ll x^{o(1)} Y}")#text(", and ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\ll Y \\ll X}")#text(".")

#text("The purpose of this post is to collect together all the various refinements to the second half of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text(" that have been obtained as part of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text(" and present them as a coherent argument. In order to state the main result, we need to recall some definitions. If ")#mi("{I}")#text(" is a bounded subset of ")#mi("{{\\bf R}}")#text(", let ")#mi("{{\\mathcal S}_I}")#text(" denote the square-free numbers whose prime factors lie in ")#mi("{I}")#text(", and let ")#mi("{P_I := \\prod_{p \\in I} p}")#text(" denote the product of the primes ")#mi("{p}")#text(" in ")#mi("{I}")#text(". Note by the Chinese remainder theorem that the set ")#mi("{({\\bf Z}/P_I{\\bf Z})^\\times}")#text(" of primitive congruence classes ")#mi("{a\\ (P_I)}")#text(" modulo ")#mi("{P_I}")#text(" can be identified with the tuples ")#mi("{(a_q\\ (q))_{q \\in {\\mathcal S}_I}}")#text(" of primitive congruence classes ")#mi("{a_q\\ (q)}")#text(" of congruence classes modulo ")#mi("{q}")#text(" for each ")#mi("{q \\in {\\mathcal S}_I}")#text(" which obey the Chinese remainder theorem")

#align(center)[#tao-fit-display[#mitex("(a_{qr}\\ (qr)) = (a_q\\ (q)) \\cap (a_r\\ (r))")]]

#text("for all coprime ")#mi("{q,r \\in {\\mathcal S}_I}")#text(", since one can identify ")#mi("{a\\ (P_I)}")#text(" with the tuple ")#mi("{(a\\ (q))_{q \\in {\\mathcal S}_I}}")#text(" for each ")#mi("{a \\in ({\\bf Z}/P_I{\\bf Z})^\\times}")#text(".")

#text("If ")#mi("{y > 1}")#text(" and ")#mi("{n}")#text(" is a natural number, we say that ")#mi("{n}")#text(" is ")#emph[#mi("{y}")#text("-densely divisible")]#text(" if, for every ")#mi("{1 \\leq R \\leq n}")#text(", one can find a factor of ")#mi("{n}")#text(" in the interval ")#mi("{[y^{-1} R, R]}")#text(". We say that ")#mi("{n}")#text(" is ")#emph[#text("doubly ")#mi("{y}")#text("-densely divisible")]#text(" if, for every ")#mi("{1 \\leq R \\leq n}")#text(", one can find a factor ")#mi("{m}")#text(" of ")#mi("{n}")#text(" in the interval ")#mi("{[y^{-1} R, R]}")#text(" such that ")#mi("{m}")#text(" is itself ")#mi("{y}")#text("-densely divisible. We let ")#mi("{{\\mathcal D}_y^2}")#text(" denote the set of doubly ")#mi("{y}")#text("-densely divisible natural numbers, and ")#mi("{{\\mathcal D}_y}")#text(" the set of ")#mi("{y}")#text("-densely divisible numbers.")

#text("Given any finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf C}}")#text(" and any primitive residue class ")#mi("{a\\ (q)}")#text(", we define the discrepancy")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha; a \\ (q)) := \\sum_{n: n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} \\alpha(n).")]]

#text("For any fixed ")#mi("{\\varpi, \\delta > 0}")#text(", we let ")#mi("{MPZ^{\\prime\\prime}[\\varpi,\\delta]}")#text(" denote the assertion that ")#metadata(none) <tao-54d1cac47e17ad572009>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^2: q \\leq x^{1/2+2\\varpi}} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A > 0}")#text(", any bounded ")#mi("{I}")#text(", and any primitive ")#mi("{a\\ (P_I)}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(". Importantly, we do ")#emph[#text("not")]#text(" require ")#mi("{I}")#text(" or ")#mi("{a}")#text(" to be fixed, in particular ")#mi("{I}")#text(" could grow polynomially in ")#mi("{x}")#text(", and ")#mi("{a}")#text(" could grow exponentially in ")#mi("{x}")#text(", but the implied constant in ")#link(<tao-54d1cac47e17ad572009>)[#text("(1)")]#text(" would still need to be fixed (so it has to be uniform in ")#mi("{I}")#text(" and ")#mi("{a}")#text("). (In previous formulations of these estimates, the system of congruence ")#mi("{a\\ (q)}")#text(" was also required to obey a controlled multiplicity hypothesis, but we no longer need this hypothesis in our arguments.) In this post we will record the proof of the following result, which is currently the best distribution result produced by the ongoing polymath8 project to optimise Zhang’s theorem on bounded gaps between primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" We have ")#mi("{MPZ^{\\prime\\prime}[\\varpi,\\delta]}")#text(" whenever ")#mi("{\\frac{280}{3} \\varpi + \\frac{80}{3} \\delta < 1}")#text(".")
]

#text("This improves upon the previous constraint of ")#mi("{148 \\varpi + 33 \\delta < 1}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("this previous post")]#text("), although that latter statement was stronger in that it only required single dense divisibility rather than double dense divisibility. However, thanks to the efficiency of the sieving step of our argument, the upgrade of the single dense divisibility hypothesis to double dense divisibility costs almost nothing with respect to the ")#mi("{k_0}")#text(" parameter (which, using this constraint, gives a value of ")#mi("{k_0=720}")#text(" as verified in ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237306")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-237324")[#text("comments")]#text(", which then implies a value of ")#mi("{H = 5,414}")#text(").")

#text("This estimate is deduced from three sub-estimates, which require a bit more notation to state. We need a fixed quantity ")#mi("{A_0>0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" A ")#emph[#text("coefficient sequence")]#text(" is a finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf R}}")#text(" that obeys the bounds ")#metadata(none) <tao-afd7bf72960f2f867380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\alpha(n)\\right| \\ll \\tau^{O(1)}(n) \\log^{O(1)}(x)", block: true)]]

#text("for all ")#mi("{n}")#text(", where ")#mi("{\\tau}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(".")

#list(
[#text("(i) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("at scale ")#mi("{N}")]#text(" for some ")#mi("{N \\geq 1}")#text(" if it is supported on an interval of the form ")#mi("{[(1-O(\\log^{-A_0} x)) N, (1+O(\\log^{-A_0} x)) N]}")#text(".")],
[#text("(ii) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to ")#emph[#text("obey the Siegel-Walfisz theorem")]#text(" if one has")

#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left| \\Delta(\\alpha 1_{(\\cdot,q)=1}; a\\ (r)) \\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q,r \\geq 1}")#text(", any fixed ")#mi("{A}")#text(", and any primitive residue class ")#mi("{a\\ (r)}")#text(".")],
[#text("(iii) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" (relative to this choice of ")#mi("{A_0}")#text(") is said to be ")#emph[#text("smooth")]#text(" if it takes the form ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(" for some smooth function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[1-O(\\log^{-A_0} x), 1+O(\\log^{-A_0} x)]}")#text(" obeying the derivative bounds")

#metadata(none) <tao-ab1e6be2000a7c9c3d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\psi^{(j)}(t) = O( \\log^{j A_0} x )")]]

#text("for all fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant in the ")#mi("{O()}")#text(" notation may depend on ")#mi("{j}")#text(").")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Type I, Type II, Type III estimates)")]#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", and ")#mi("{0 < \\sigma < 1/2}")#text(" be fixed quantities. We let ")#mi("{I}")#text(" be an arbitrary bounded subset of ")#mi("{{\\bf R}}")#text(", and ")#mi("{a\\ (P_I)}")#text(" a primitive congruence class.")

#list(
[#text("(i) We say that ")#mi("{Type^{\\prime\\prime}_I[\\varpi,\\delta,\\sigma]}")#text(" holds if, whenever ")#mi("{M, N \\gg 1}")#text(" are quantities with")

#metadata(none) <tao-2f48b881ea7073f1c6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("M N \\sim x")]]

#text("and")

#metadata(none) <tao-58e0413224af6b6d3505>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("x^{1/2-\\sigma} \\lessapprox N \\lessapprox x^{1/2-2\\varpi-c}")]]

#text("for some fixed ")#mi("{c>0}")#text(", and ")#mi("{\\alpha,\\beta}")#text(" are coefficient sequences at scales ")#mi("{M,N}")#text(" respectively, with ")#mi("{\\beta}")#text(" obeying a Siegel-Walfisz theorem, we have")

#metadata(none) <tao-a8b405ab6f00d98196ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^2: q \\leq x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha * \\beta; a\\ (q))\\right| \\ll x \\log^{-A} x.", block: true)]]],
[#text("(ii) We say that ")#mi("{Type^{\\prime\\prime}_{II}[\\varpi,\\delta]}")#text(" holds if the conclusion ")#link(<tao-a8b405ab6f00d98196ba>)[#text("(7)")]#text(" of ")#mi("{Type^{\\prime\\prime}_I[\\varpi,\\delta,\\sigma]}")#text(" holds under the same hypotheses as before, except that ")#link(<tao-58e0413224af6b6d3505>)[#text("(6)")]#text(" is replaced with")

#metadata(none) <tao-2f37db5234a05e9b49a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("x^{1/2-2\\varpi-c} \\lessapprox N \\lessapprox x^{1/2}")]]

#text("for some sufficiently small fixed ")#mi("{c>0}")#text(".")],
[#text("(iii) We say that ")#mi("{Type^{\\prime\\prime}_{III}[\\varpi,\\delta,\\sigma]}")#text(" holds if, whenever ")#mi("{M, N_1,N_2,N_3 \\gg 1}")#text(" are quantities with")

#align(center)[#tao-fit-display[#mitex("M N_1 N_2 N_3 \\sim x")]]

#text("and ")#metadata(none) <tao-370c6000f89ba9fdee2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("N_1 N_2, N_1 N_3, N_2 N_3 \\gtrapprox x^{1/2+\\sigma}")]]

#text("and ")#metadata(none) <tao-e373cff4b2b4c4426145>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("x^{2\\sigma} \\lessapprox N_1,N_2,N_3 \\lessapprox x^{1/2-\\sigma}")]]

#text("and ")#mi("{\\alpha,\\psi_1,\\psi_2,\\psi_3}")#text(" are coefficient sequences at scales ")#mi("{M,N_1,N_2,N_3}")#text(" respectively, with ")#mi("{\\psi_1,\\psi_2,\\psi_3}")#text(" smooth, we have ")#metadata(none) <tao-e3a7e307523ee048d2b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^2: q \\leq x^{1/2+2\\varpi}}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a\\ (q))\\right| \\ll x \\log^{-A} x.", block: true)]]]
)
]

#text("Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" is then a consequence of the following four statements.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Type I estimate)")]#text(" ")#metadata(none) <tao-840c81157f3688e42875>#text(" ")#mi("{Type^{\\prime\\prime}_I[\\varpi,\\delta,\\sigma]}")#text(" holds whenever ")#mi("{\\varpi,\\delta,\\sigma > 0}")#text(" are fixed quantities such that")

#align(center)[#tao-fit-display[#mitex("56 \\varpi + 16 \\delta + 4\\sigma < 1.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Type II estimate)")]#text(" ")#metadata(none) <tao-9ce19620746a8f953f54>#text(" ")#mi("{Type^{\\prime\\prime}_{II}[\\varpi,\\delta]}")#text(" holds whenever ")#mi("{\\varpi,\\delta > 0}")#text(" are fixed quantities such that")

#align(center)[#tao-fit-display[#mitex("68 \\varpi + 14 \\delta < 1.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Type III estimate)")]#text(" ")#metadata(none) <tao-27b250d25accb10de21a>#text(" ")#mi("{Type^{\\prime\\prime}_{III}[\\varpi,\\delta,\\sigma]}")#text(" holds whenever ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", and ")#mi("{\\sigma > 0}")#text(" are fixed quantities such that ")#metadata(none) <tao-06efe37f5e983469e860>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sigma > \\frac{1}{18} + \\frac{28}{9} \\varpi + \\frac{2}{9} \\delta")]]

#text("and ")#metadata(none) <tao-bedae6ae5c6856f323db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\varpi< \\frac{1}{12}.")]]

#text("In particular, if")

#align(center)[#tao-fit-display[#mitex("70 \\varpi + 5 \\delta < 1.")]]

#text("then all values of ")#mi("{\\sigma}")#text(" that are sufficiently close to ")#mi("{1/10}")#text(" are admissible.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Combinatorial lemma)")]#text(" ")#metadata(none) <tao-ef4e3f50798387464764>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", and ")#mi("{1/10 < \\sigma < 1/2}")#text(" be such that ")#mi("{Type^{\\prime\\prime}_I[\\varpi,\\delta,\\sigma]}")#text(", ")#mi("{Type^{\\prime\\prime}_{II}[\\varpi,\\delta]}")#text(", and ")#mi("{Type^{\\prime\\prime}_{III}[\\varpi,\\delta,\\sigma]}")#text(" simultaneously hold. Then ")#mi("{MPZ^{\\prime\\prime}[\\varpi,\\delta]}")#text(" holds.")
]

#text("Indeed, if ")#mi("{\\frac{280}{3} \\varpi + \\frac{80}{3} \\delta < 1}")#text(", one checks that the hypotheses for Theorems ")#link(<tao-840c81157f3688e42875>)[#text("4")]#text(", ")#link(<tao-9ce19620746a8f953f54>)[#text("5")]#text(", ")#link(<tao-27b250d25accb10de21a>)[#text("6")]#text(" are obeyed for ")#mi("{\\sigma}")#text(" sufficiently close to ")#mi("{1/10}")#text(", at which point the claim follows from Lemma ")#link(<tao-ef4e3f50798387464764>)[#text("7")]#text(".")

#text("The proofs of Theorems ")#link(<tao-840c81157f3688e42875>)[#text("4")]#text(", ")#link(<tao-9ce19620746a8f953f54>)[#text("5")]#text(", ")#link(<tao-27b250d25accb10de21a>)[#text("6")]#text(" will be given below the fold, while the proof of Lemma ")#link(<tao-ef4e3f50798387464764>)[#text("7")]#text(" follows from the arguments in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(". We remark that in our current arguments, the double dense divisibility is only fully used in the Type I estimates; the Type II and Type III estimates are also valid just with single dense divisibility.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Theorem ")#link(<tao-27b250d25accb10de21a>)[#text("6")]#text(" is vacuously true for ")#mi("{\\sigma > 1/6}")#text(", as the condition ")#link(<tao-e373cff4b2b4c4426145>)[#text("(10)")]#text(" cannot be satisfied in this case. If we use this trivial case of Theorem ")#link(<tao-27b250d25accb10de21a>)[#text("6")]#text(", while keeping the full strength of Theorems ")#link(<tao-840c81157f3688e42875>)[#text("4")]#text(" and ")#link(<tao-9ce19620746a8f953f54>)[#text("5")]#text(", we obtain Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" in the regime")

#align(center)[#tao-fit-display[#mitex("168 \\varpi + 48 \\delta < 1.")]]
]

#metadata(none) <tao-1c3f7fae0cb470f37861>

#heading(level: 1)[#strong[#text(" — 1. Exponential sum estimates — ")]]

#text("It will be convenient to introduce a little bit of formal algebraic notation. Define an ")#emph[#text("integral rational function")]#text(" to be a formal rational function ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" in a formal indeterminate ")#mi("{t}")#text(" where ")#mi("{P,Q \\in {\\bf Z}[t]}")#text(" are polynomials with integer coefficients, and ")#mi("{Q}")#text(" is monic; in particular any polynomial ")#mi("{P(t) \\in {\\bf Z}[t]}")#text(" can be identified with the integral rational function ")#mi("{P(t) \\equiv \\frac{P(t)}{1}}")#text(". For minor technical reasons we do ")#emph[#text("not")]#text(" equate integral rational functions under cancelling, thus for instance we consider ")#mi("{\\frac{P(t)R(t)}{Q(t)R(t)}}")#text(" to be distinct from ")#mi("{\\frac{P(t)}{Q(t)}}")#text("; we need to do this because the domain of definition of these two functions is a little different (the former is not defined when ")#mi("{R(t)=0}")#text(", but the latter can still be defined here). Because we refuse to cancel, we have to be a little careful how we define algebraic operations: specifically, we define")

#tao-aligned(keep: true)[


#tao-math("\\frac{P_1(t)}{Q_1(t)} + \\frac{P_2(t)}{Q_2(t)}  & := \\frac{P_1(t) Q_2(t) + P_2(t) Q_1(t)}{Q_1(t) Q_2(t)}", block: true)



#tao-math("\\frac{P_1(t)}{Q_1(t)} - \\frac{P_2(t)}{Q_2(t)}  & := \\frac{P_1(t) Q_2(t) - P_2(t) Q_1(t)}{Q_1(t) Q_2(t)}", block: true)



#tao-math("\\frac{P_1(t)}{Q_1(t)} \\cdot \\frac{P_2(t)}{Q_2(t)}  & := \\frac{P_1(t) P_2(t)}{Q_1(t) Q_2(t)}", block: true)



#tao-math("(\\frac{P(t)}{Q(t)})^{\\prime}  & := \\frac{P^{\\prime}(t) Q(t) - P(t) Q^{\\prime}(t)}{Q(t)^2}.", block: true)
]

#text("Note that the denominator always remains monic with respect to these operations. This is not quite a ring with a derivation (the subtraction operation does not quite cancel the addition operation due to the inability to cancel) but this will not bother us in practice. (On the other hand, addition and multiplication remain associative, and the latter continues to distribute over the former, and differentiation obeys the usual sum and product rules.) Note that if ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" is an integral rational function, we can localise it modulo ")#mi("{q}")#text(" for any modulus ")#mi("{q}")#text(" to obtain a rational function ")#mi("{f(t)\\ (q) := \\frac{P(t)\\ (q)}{Q(t)\\ (q)}}")#text(" that is the ratio of two polynomials ")#mi("{P\\ (q), Q\\ (q)}")#text(" in ")#mi("{({\\bf Z}/q{\\bf Z})[t]}")#text(", with the denominator monic and hence non-vanishing. We can define the algebraic operations of addition, subtraction, multiplication, and differentiation on integral rational functions modulo ")#mi("{q}")#text(" by the same formulae as above, and we observe that these operations are completely compatible with their counterparts over ")#mi("{{\\bf Z}}")#text(" (even without the ability to cancel), thus for instance ")#mi("{(f+g)\\ (q) = (f\\ (q)) + (g\\ (q))}")#text(". We say that ")#mi("{f}")#text(" is ")#emph[#text("divisible")]#text(" by ")#mi("{q}")#text(", and write ")#mi("{q|f}")#text(", if the numerator ")#mi("{P(t)}")#text(" of ")#mi("{f(t)}")#text(" has all coefficients divisible by ")#mi("{q}")#text(".")

#text("If ")#mi("{f}")#text(" is an integral rational function and ")#mi("{n \\in {\\bf Z}/q{\\bf Z}}")#text(", then ")#mi("{f(n)}")#text(" is well defined as an element of ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" except when ")#mi("{Q(n)}")#text(" is a zero divisor in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(". We adopt the convention that ")#mi("{e_q(f(n)) = 0}")#text(" when ")#mi("{Q(n)}")#text(" is a zero divisor in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(", thus ")#mi("{e_q(f(n))}")#text(" is really shorthand for ")#mi("{1_{(Q(n),q)=1} e_q(f(n))}")#text("; by abuse of notation we view ")#mi("{n \\mapsto e_q(f(n))}")#text(" both as a function on ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" and as a ")#mi("{q}")#text("-periodic function on ")#mi("{{\\bf Z}}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#mitex("e_q( \\frac{0}{n} ) = 1_{(n,q)=1}.")]]

#text("Note that if ")#mi("{q|f}")#text(", then ")#mi("{f(n)=0\\ (q)}")#text(" for all ")#mi("{n \\in {\\bf Z}/q{\\bf Z}}")#text(" for which ")#mi("{f(n)}")#text(" is well defined. We define ")#mi("{(f,q)}")#text(" to be the largest factor ")#mi("{q^{\\prime}}")#text(" of ")#mi("{q}")#text(" for which ")#mi("{q^{\\prime}|f}")#text("; in particular, if ")#mi("{q}")#text(" is square-free, we have")

#align(center)[#tao-fit-display[#mitex("(f,q) = \\prod_{p|q: p|f} p.")]]

#text("Note with these conventions that ")#mi("{(0,q)=q}")#text(".")

#text("We recall the following Chinese remainder theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Chinese remainder theorem)")]#text(" ")#metadata(none) <tao-793ff64f83b41b5d467a>#text(" Let ")#mi("{q = q_1 q_2}")#text(" with ")#mi("{q_1,q_2}")#text(" coprime positive integers. If ")#mi("{f}")#text(" is a rational function, then")

#align(center)[#tao-fit-display[#mitex("e_q( f(n) ) = e_{q_1}( \\overline{q_2} f(n) ) e_{q_2} ( \\bar{q_1} f(n) )")]]

#text("for all integers ")#mi("{n}")#text(", where ")#mi("{\\overline{q_2}}")#text(" is the inverse of ")#mi("{q_2}")#text(" in ")#mi("{{\\bf Z}/q_1{\\bf Z}}")#text(" and similarly for ")#mi("{\\overline{q_1}}")#text(".")
]

#text("When there is no chance of confusion we will write ")#mi("{e_{q_1} ( \\frac{1}{q_2} f(n) )}")#text(" for ")#mi("{e_{q_1}( \\overline{q_2} f(n) )}")#text(" (though note that ")#mi("{\\frac{1}{q_2}}")#text(" does not qualify as an integral rational function since the constant ")#mi("{q_2}")#text(" is not monic).")

#emph[#text("Proof:")]#text(" See Lemma 7 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(". ")#mi("\\Box")

#text("Now we give an estimate for complete exponential sums, which combines both Ramanujan sum bounds with Weil conjecture bounds.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Ramanujan-Weil bounds)")]#text(" ")#metadata(none) <tao-740fc4991133b1523bc4>#text(" Let ")#mi("{q}")#text(" be a positive square-free integer of polynomial size, and let ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" be an integral rational function with ")#mi("{P,Q}")#text(" of bounded degree. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( f(n) )\\right| \\lessapprox q^{1/2} \\frac{(f^{\\prime},q)}{(f^{\\prime\\prime},q)^{1/2}}.", block: true)]]
]

#emph[#text("Proof:")]#text(" See Proposition 4 of ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("this previous post")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Incomplete sums)")]#text(" ")#metadata(none) <tao-fa9383a4bc9106e8f9d9>#text(" Let ")#mi("{q}")#text(" be a positive square-free integer of polynomial size, and let ")#mi("{f(t) = \\frac{P(t)}{Q(t)}}")#text(" be an integral rational function with ")#mi("{P,Q}")#text(" of bounded degree with ")#mi("{\\text{deg}(P) < \\text{deg}(Q)}")#text(". Let ")#mi("{l \\geq 1}")#text(" be a fixed integer, and suppose that we have a factorisation ")#mi("{q = q_1 \\ldots q_l}")#text(". Then for any ")#mi("{N \\gg 1}")#text(", and any coefficient sequence ")#mi("{\\psi_N}")#text(" at scale ")#mi("{N}")#text(" of polynomial size, one has")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_n \\psi_N(n) e_q(f(n))\\right| \\lessapprox \\sum_{i=1}^{l-1} N^{1-1/2^i} (q^{\\prime}_i)^{1/2^i}  & + N^{1-1/2^{l-1}} (q^{\\prime}_l)^{1/2^l}", block: true)



#tao-math(" & + \\frac{N}{q^{\\prime}} 1_{N \\geq q^{\\prime}} \\left|\\sum_{n \\in {\\bf Z}/q^{\\prime}{\\bf Z}} e_{q^{\\prime}}(f(n) / (f,q) )\\right|", block: true)
]

#text("where ")#mi("{q^{\\prime} := q / (f,q)}")#text(" and ")#mi("{q^{\\prime}_i := (q_i,q^{\\prime})}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{C}")#text(" be a sufficiently large fixed quantity depending on the degrees of ")#mi("{P}")#text(" and ")#mi("{Q}")#text(". We first make the technical reduction that it suffices to establish the claim in the case when ")#mi("{q}")#text(" has no prime factors less than ")#mi("{C}")#text(", for otherwise one can factor ")#mi("{q = q_0 q^{\\prime}}")#text(" where ")#mi("{q_0}")#text(" is the product of all the prime factors of ")#mi("{q}")#text(" less than ")#mi("{C}")#text(", and by splitting the ")#mi("{n}")#text(" summation into residue classes ")#mi("{b\\ (q_0)}")#text(" and performing the substitution ")#mi("{n = q_0^{\\prime} n + b}")#text(" and applying the proposition with ")#mi("{q}")#text(" replaced by ")#mi("{q^{\\prime}}")#text(" (and adjusting ")#mi("{q_1,\\ldots q_l,P,Q,f}")#text(" accordingly) we obtain the claim.")

#text("By dividing ")#mi("{f}")#text(" through by ")#mi("{(f,q)}")#text(" (and replacing ")#mi("{q_i}")#text(" with ")#mi("{q^{\\prime}_i}")#text(") we may assume without loss of generality that ")#mi("{(f,q)=1}")#text(" and ")#mi("{q_i = q^{\\prime}_i}")#text(". As ")#mi("{f}")#text(" vanishes at infinity, this implies that ")#mi("{(f^{\\prime},q)=1}")#text(" and ")#mi("{(f^{\\prime\\prime},q)=1}")#text(" (see Lemma 3 from ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("this previous post")]#text(").")

#text("We induct on ")#mi("{l}")#text(". We begin with the base case ")#mi("{l=1}")#text(", where the task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) e_q(f(n))\\right| \\lessapprox q^{1/2} + \\frac{N}{q} 1_{N \\geq q} |\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_{q}(f(n))|.", block: true)]]

#text("By Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("9")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_{q}(f(n))\\right| \\lessapprox q^{1/2}", block: true)]]

#text("so we may delete the condition ")#mi("{1_{N \\geq q}}")#text(" on the right-hand side without penalty.")

#text("By completion of sums (see Lemma 6 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("), the left-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox 1 + \\frac{N}{q} \\sum_{\\left|h\\right| \\lessapprox q/N} \\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn)\\right|", block: true)]]

#text("so it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{N}{q} \\sum_{0 < \\left|h\\right| \\lessapprox q/N} |\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n) + hn)| \\lessapprox q^{1/2}.", block: true)]]

#text("By Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("9")]#text(" again, the left-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\lessapprox \\frac{N}{q^{1/2}} \\sum_{0 < \\left|h\\right| \\lessapprox q/N} (f^{\\prime}+h,q).", block: true)]]

#text("Since ")#mi("{(f^{\\prime\\prime},q)=1}")#text(", we see that ")#mi("{(f^{\\prime}+h,q)=1}")#text(", and the claim follows.")

#text("Now suppose that ")#mi("{l > 1}")#text(", and that the claim has already been proven for ")#mi("{l-1}")#text(". We use the ")#mi("{q}")#text("-van der Corput ")#mi("{A}")#text("-process of ")#link("http://www.ams.org/mathscinet-getitem?mr=485727")[#text("Heath-Brown")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1084186")[#text("Graham-Ringrose")]#text(". If we have ")#mi("{N \\geq q_l}")#text(", then")

#align(center)[#tao-fit-display[#mitex("N^{1-1/2^{l-1}} q_{l-1}^{1/2^{l-1}} + N^{1-1/2^{l-1}} q_l^{1/2^l} \\geq N^{1-1/2^{l-2}} (q_{l-1} q_l)^{1/2^{l-1}}")]]

#text("and the claim then follows by the induction hypothesis (concatenating ")#mi("{q_l}")#text(" and ")#mi("{q_{l-1}}")#text("). Similarly, if ")#mi("{N \\leq q_1}")#text(", then ")#mi("{N^{1/2} q_1^{1/2} \\geq N}")#text(", and the claim follows from the triangle inequality. Thus we may assume that")

#align(center)[#tao-fit-display[#mitex("q_1 < N < q_l.")]]

#text("Let ")#mi("{K := \\lfloor N/q_1\\rfloor}")#text(". We can rewrite ")#mi("{\\sum_n \\psi_N(n) e_q(f(n))}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{K} \\sum_n \\sum_{k=1}^K \\psi_N(n+kq_1) e_q(f(n+kq_1)).")]]

#text("By Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("8")]#text(" we have ")#mi("{e_q(f(n+kq_1)) = e_{q_1}(\\overline{q_2 \\ldots q_l} f(n)) e_{q_2 \\ldots q_l}( \\overline{q_1} f(n+kq_1) )}")#text(", and so by the triangle inequality and the Cauchy-Schwarz inequality")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_n \\psi_N(n) e_q(f(n))\\right|  & \\leq \\frac{1}{K} \\sum_n \\left|\\sum_{k=1}^K \\psi_N(n+kq_1) e_{q_2 \\ldots q_l}( \\overline{q_1} f(n+kq_1) )\\right|", block: true)



#tao-math(" & \\ll \\frac{N^{1/2}}{K} (\\sum_n \\left|\\sum_{k=1}^K \\psi_N(n+kq_1) e_{q_2 \\ldots q_l}( \\overline{q_1} f(n+kq_1) )\\right|^2)^{1/2}", block: true)
]

#text("since the summand is only non-zero when ")#mi("{n}")#text(" is supported on an interval of length ")#mi("{O(N)}")#text(". This last expression may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\frac{N^{1/2}}{K} |\\sum_{1 \\leq k,k^{\\prime} \\leq K} \\sum_n \\psi_N(n+kq_1) \\overline{\\psi_N(n+k^{\\prime}q_1)}")]]

#align(center)[#tao-fit-display[#mitex("e_{q_2 \\ldots q_l}( \\overline{q_1} (f(n+kq_1) - f(n+k^{\\prime}q_1) ) )|^{1/2}.")]]

#text("The diagonal contribution ")#mi("{k=k^{\\prime}}")#text(" can be estimated by ")#mi("{O( \\frac{N^{1/2}}{K} ( K N )^{1/2} ) = O( N^{1/2} q_1^{1/2} )}")#text(", which is acceptable, so it suffices to show that ")#metadata(none) <tao-d0350a6064de840458ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("|\\sum_{1 \\leq k,k^{\\prime} \\leq K: k \\neq k^{\\prime}} \\sum_n \\psi_N(n+kq_1) \\overline{\\psi_N(n+k^{\\prime}q_1)}")]]

#align(center)[#tao-fit-display[#mitex("e_{q_2 \\ldots q_l}( \\overline{q_1} (f(n+kq_1) - f(n+k^{\\prime}q_1) ) )|")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox K^2 ( \\sum_{i=2}^{l-1} N^{1-1/2^{i-1}} q_i^{1/2^{i-1}} + N^{1-1/2^{l-2}} q_l^{1/2^{l-1}} ).")]]

#text("We observe that ")#mi("{n \\mapsto \\overline{q_1} (f(n+kq_1) - f(n+k^{\\prime}q_1) )}")#text(" is an integral rational function whose numerator has lower degree than the denominator. If a prime ")#mi("{p}")#text(" dividing ")#mi("{q_2 \\ldots q_l}")#text(" also divides this rational function, then ")#mi("{f(n+(k-k^{\\prime})q_1)-f(n)}")#text(" is divisible by ")#mi("{p}")#text("; if ")#mi("{k-k^{\\prime}}")#text(" is not divisible by ")#mi("{p}")#text(", this implies by telescoping series that ")#mi("{p|f(n+a)-f(n)}")#text(" for all ")#mi("{a}")#text(". This implies that ")#mi("{f(n)\\ (p)}")#text(" is constant where it is defined; as ")#mi("{f}")#text(" vanishes at infinity and is defined outside of ")#mi("{O(1)}")#text(" elements, this implies that ")#mi("{p|f}")#text(" (here we use the fact that ")#mi("{p}")#text(" must exceed ")#mi("{C}")#text(", since it divides ")#mi("{q}")#text("). We conclude that")

#align(center)[#tao-fit-display[#mitex("(q_2 \\ldots q_l, \\overline{q_1} (f(\\cdot+kq_1) - f(\\cdot+k^{\\prime}q_1) )) \\leq (q_2 \\ldots q_l, k-k^{\\prime}).")]]

#text("Applying the induction hypothesis and Proposition ")#link(<tao-740fc4991133b1523bc4>)[#text("9")]#text(", we may thus bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n+kq_1) \\overline{\\psi_N(n+k^{\\prime}q_1)} e_{q_2 \\ldots q_l}( \\overline{q_1} (f(n+kq_1) - f(n+k^{\\prime}q_1) ) )\\right|", block: true)]]

#text("by")

#tao-aligned(keep: true)[


#tao-math("\\lessapprox \\sum_{i=2}^{l-1} N^{1-1/2^{i-1}} q_i^{1/2^{i-1}}  & + N^{1-1/2^{l-2}} q_l^{1/2^{l-1}}", block: true)



#tao-math(" & + N (q_2 \\ldots q_l)^{-1/2} (q_2 \\ldots q_l, k-k^{\\prime})^{1/2} 1_{N \\geq q_2 \\ldots q_l / (q_2 \\ldots q_l, k-k^{\\prime})}.", block: true)
]

#text("The contribution of the first two terms to ")#link(<tao-d0350a6064de840458ae>)[#text("(14)")]#text(" is acceptable, so the only contribution remaining to control is")

#align(center)[#tao-fit-display[#mitex("N (q_2 \\ldots q_l)^{-1/2} \\sum_{1 \\leq k,k^{\\prime} \\leq K: k \\neq k^{\\prime}} (q_2 \\ldots q_l, k-k^{\\prime})^{1/2} 1_{N \\geq q_2 \\ldots q_l / (q_2 \\ldots q_l, k-k^{\\prime})}.")]]

#text("If we bound ")#mi("{1_{N \\geq q_2 \\ldots q_l / (q_2 \\ldots q_l, k-k^{\\prime})}}")#text(" by ")#mi("{(q_2 \\ldots q_l, k-k^{\\prime})^{1/2} (q_2 \\ldots q_l)^{-1/2} N^{1/2}}")#text(", we can bound this expression by")

#align(center)[#tao-fit-display[#mitex("N^{3/2} (q_2 \\ldots q_l)^{-1} \\sum_{1 \\leq k,k^{\\prime} \\leq K: k \\neq k^{\\prime}} (q_2 \\ldots q_l, k-k^{\\prime})")]]

#text("which by Lemma 5 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(" and the bound ")#mi("{N < q_l}")#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox K^2 N^{1-1/2^{l-2}} q_l^{1/2^{l-1}}")]]

#text("which is acceptable. ")#mi("\\Box")

#text("We record a special case of the above proposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11")]#text(" ")#metadata(none) <tao-ceea36e7bdbb7c65e0e2>#text(" Let ")#mi("{d_1,d_2}")#text(" be square-free numbers (not necessarily coprime) of polynomial size, let ")#mi("{c_1,c_2,l,l^{\\prime},m}")#text(" be integers, let ")#mi("{N \\gg 1}")#text(", and let ")#mi("{\\psi_N}")#text(" be a coefficient sequence at scale ")#mi("{N}")#text(". Suppose that ")#mi("{[d_1,d_2]}")#text(" is ")#mi("{y}")#text("-densely divisible. Let ")#mi("{a\\ (q_0)}")#text(" be a residue class with ")#mi("{q_0 | (d_1,d_2)}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n : n = a\\ (q_0)} \\psi_N(n+m) e_{d_1}( \\frac{c_1}{n+l} ) e_{d_2}( \\frac{c_2}{n+l^{\\prime}} )\\right| \\lessapprox", block: true)]]

#align(center)[#tao-fit-display[#mitex("q_0^{-1/2} N^{1/2} [d_1,d_2]^{1/6} y^{1/6} + q_0^{-1} \\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\frac{(c_2,d^{\\prime}_2)}{d^{\\prime}_2} N")]]

#text("where ")#mi("{d^{\\prime}_i := d_i/(d_1,d_2)}")#text(" for ")#mi("{i=1,2}")#text(". We also have the variant bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n : n = a\\ (q_0)} \\psi_N(n+m) e_{d_1}( \\frac{c_1}{n + l} ) e_{d_2}( \\frac{c_2}{n+l^{\\prime}} )\\right| \\lessapprox", block: true)]]

#align(center)[#tao-fit-display[#mitex("q_0^{-1/2} [d_1,d_2]^{1/2} + q_0^{-1} \\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\frac{(c_2,d^{\\prime}_2)}{d^{\\prime}_2} N.")]]
]

#emph[#text("Proof:")]#text(" We first consider the case ")#mi("{q_0=1}")#text(", so that the congruence condition ")#mi("{n = a\\ (q_0)}")#text(" can be deleted. By the dense divisibility hypothesis we may factor ")#mi("{[d_1,d_2] = q_1 q_2}")#text(" for some")

#align(center)[#tao-fit-display[#mitex("y^{-2/3}[d_1,d_2]^{1/3} \\leq q_1 \\leq y^{1/3} [d_1,d_2]^{1/3}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("y^{-1/3}[d_1,d_2]^{2/3} \\leq q_2 \\leq y^{2/3} [d_1,d_2]^{2/3}.")]]

#text("The first bound then follows from the ")#mi("{l=2}")#text(" case of Proposition ")#link(<tao-fa9383a4bc9106e8f9d9>)[#text("10")]#text(", combined with the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/[d_1,d_2]{\\bf Z}} e_{d_1}( \\frac{c_1}{n+l} ) e_{d_2}( \\frac{c_2}{n+l^{\\prime}} )\\right| \\lessapprox (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2) (d_1,d_2)", block: true)]]

#text("that is proven as part of Proposition 5 of ")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("this previous post")]#text(". The second bound similarly follows from the ")#mi("{l=1}")#text(" case of Proposition")#link(<tao-fa9383a4bc9106e8f9d9>)[#text("10")]#text(".")

#text("Now we consider the case when ")#mi("{q_0 > 1}")#text(". Writing ")#mi("{n = n^{\\prime} q_0 + a}")#text(", ")#mi("{d_1 = q_0 \\tilde d_1}")#text(", and ")#mi("{d_2 =q_0 \\tilde d_2}")#text(", we have from Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("8")]#text(" that")

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{c_1}{n+l} ) = e_{\\tilde d_1}( \\frac{c_1 \\overline{q_0}^2}{n^{\\prime} + (a+l) \\overline{q_0} } ) e_{q_0}( \\frac{c_1 \\overline{\\tilde d_1}}{a+l} )")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{c_2}{n+l^{\\prime}} ) = e_{\\tilde d_2}( \\frac{c_2 \\overline{q_0}^2}{n^{\\prime} + (a+l^{\\prime}) \\overline{q_0} } ) e_{q_0}( \\frac{c_2 \\overline{\\tilde d_2}}{a+l^{\\prime}} ).")]]

#text("If we then apply the previous results with ")#mi("{d_1,d_2}")#text(" replaced by ")#mi("{\\tilde d_1,\\tilde d_2}")#text(" (with ")#mi("{[\\tilde d_1,\\tilde d_2] = [d_1,d_2]/q_0}")#text(" being ")#mi("{q_0y}")#text("-densely divisible) and ")#mi("{N}")#text(" replaced by ")#mi("{N/q_0}")#text(" (and with suitable alterations to ")#mi("{c_1,c_2,l,l^{\\prime}}")#text("), we obtain the required claims. ")#mi("\\Box")

#text("For the Type III estimate we will also need a deeper exponential sum estimate, involving the hyper-Kloosterman sums ")#metadata(none) <tao-5755154c48de70c4dafb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("K_3(a;q) := \\frac{1}{q} \\sum_{x,y,z \\in ({\\bf Z}/q{\\bf Z})^\\times: xyz=a} e_q(x+y+z)")]]

#text("for square-free ")#mi("{q}")#text(" and ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12 (Correlation of hyper-Kloosterman sums)")]#text(" Let ")#mi("{s,r_1,r_2}")#text(" be square-free numbers of polynomial size with ")#mi("{(s,r_1)=(s,r_2)=1}")#text(". Let ")#mi("{a_1 \\in ({\\bf Z}/r_1 s)^\\times}")#text(", ")#mi("{a_2 \\in ({\\bf Z}/r_2s)^\\times}")#text(", and ")#mi("{n \\in {\\bf Z}/([r_1,r_2] s){\\bf Z}}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h \\in ({\\bf Z}/[r_1, r_2]s {\\bf Z})^\\times} K_3(a_1 h; r_1 s) \\overline{K_3(a_2 h; r_2 s)} e_{[r_1,r_2] s}( nh )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox d^{1/2} s^{1/2} [r_1,r_2]^{1/2} (r_1,r_2,a_2-a_1,n)^{1/2}")]]

#text("where ")#mi("{d := (a_2 r_1^3 - a_1 r_2^3, n, s)}")#text(".")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("8")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("K_3( a_i h; r_i s ) = K_3( a_i \\bar{s}^3 h; r_i) K_3( a_i \\overline{r_i}^3 h; s )")]]

#text("and so it suffices to prove the estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h \\in ({\\bf Z}/[r_1, r_2] {\\bf Z})^\\times} K_3(a_1 \\bar{s}^3 h; r_1) \\overline{K_3(a_2 \\bar{s}^3 h; r_2)} e_{[r_1,r_2]}( \\bar{s} nh )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox [r_1,r_2]^{1/2} (r_1,r_2,a_2-a_1,n)^{1/2}")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h \\in ({\\bf Z}/s {\\bf Z})^\\times} K_3(a_1 \\overline{r_1}^3 h; s) \\overline{K_3(a_2 \\overline{r_2}^3 h; s)} e_{s}( \\overline{[r_1,r_2]} nh )\\right| \\lessapprox d^{1/2} s^{1/2}.", block: true)]]

#text("By further application of Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("8")]#text(", together with the divisor bound, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h \\in ({\\bf Z}/p {\\bf Z})^\\times} K_3(b_1 h; d_1) \\overline{K_3(b_2 h; d_2)} e_{p}( mh )\\right| \\ll p^{1/2} (b_1-b_2,m,d_1,d_2)^{1/2}", block: true)]]

#text("whenever ")#mi("{[d_1,d_2] = p}")#text(", ")#mi("{m \\in {\\bf Z}/p{\\bf Z}}")#text(", and ")#mi("{b_1,b_2 \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(".")

#text("Suppose first that ")#mi("{d_2=1}")#text(", so that ")#mi("{d_1=p}")#text(". Then ")#mi("{\\overline{K_3(b_2 h; d_2)} = 1}")#text(", and the left-hand side simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h \\in ({\\bf Z}/p {\\bf Z})^\\times} K_3(b_1 h; p) e_{p}( mh )\\right|", block: true)]]

#text("which can be expanded as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} | \\sum_{x,y,z \\in ({{\\bf Z}/p{\\bf Z}})^\\times} e_p( m \\overline{b_1} xyz + x + y + z ) |.")]]

#text("Performing the Fourier summation in ")#mi("{z}")#text(", this can be bounded by the sum of")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{x,y \\in ({{\\bf Z}/p{\\bf Z}})^\\times} e_p( x + y ) 1_{m \\overline{b_1} xy = -1}\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} | \\sum_{x,y \\in ({{\\bf Z}/p{\\bf Z}})^\\times} e_p( x + y ) |.")]]

#text("The first term either vanishes or is a Kloosterman sum, and is ")#mi("{O(\\sqrt{p})}")#text(" in either case, while the second term can be calculated by Fourier series to be ")#mi("{O(1)}")#text(", and the claim follows. Similarly if ")#mi("{d_1=1}")#text(".")

#text("Now suppose that ")#mi("{d_1=d_2=p}")#text(" and ")#mi("{b_1-b_2=m=0\\ (p)}")#text(". Then we use the ")#link("http://www.ams.org/mathscinet-getitem?mr=340258")[#text("Deligne bound")]#text(" ")#tao-math("{\\left|K_3(h; p)\\right| \\ll 1}", block: false)#text(" to obtain the desired claim. The only remaining case is when ")#mi("{d_1=d_2=p}")#text(" and ")#mi("{b_1-b_2 \\neq 0\\ (p)}")#text(" or ")#mi("{m \\neq 0\\ (p)}")#text(", so our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h \\in ({\\bf Z}/p {\\bf Z})^\\times} K_3(b_1 h; p) \\overline{K_3(b_2 h; p)} e_{p}( mh )\\right| \\ll p^{1/2}", block: true)]]

#text("in this case. A proof of this claim (which uses the full strength of Deligne’s work) can be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=1652005")[#text("this paper of Michel")]#text(" (see also Proposition 6 of ")#link("http://www.math.ethz.ch/~kowalski/friedlander-iwaniec-sum.pdf")[#text("this recent expository note of Fouvry, Kowalski, and Michel")]#text("). ")#mi("\\Box")

#text("From this and completion and sums we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13 (Correlation of hyper-Kloosterman sums, II)")]#text(" ")#metadata(none) <tao-7f4e1a13f6e91c1a2831>#text(" Let ")#mi("{s,r_1,r_2}")#text(" be square-free numbers of polynomial size with ")#mi("{(s,r_1)=(s,r_2)=1}")#text(". Let ")#mi("{a_1 \\in ({\\bf Z}/r_1 s)^\\times}")#text(", ")#mi("{a_2 \\in ({\\bf Z}/r_2s)^\\times}")#text(". Let ")#mi("{\\Psi: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a smooth function adapted to the interval ")#mi("{[-2H,2H]}")#text(" which equals one on ")#mi("{[-H,H]}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_h \\Psi(h) K_3(a_1 h; r_1 s) \\overline{K_3(a_2 h; r_2 s)} e_{[r_1,r_2] s}( nh )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox (\\frac{H}{[r_1,r_2]s} + 1) d^{1/2} s^{1/2} [r_1,r_2]^{1/2} (a_2-a_1,r_1,r_2)^{1/2}")]]

#text("where ")#mi("{d := (a_2 r_1^3 - a_1 r_2^3, s)}")#text(", and the sum runs over those ")#mi("{h}")#text(" coprime to ")#mi("{[r_1,r_2]s}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Type I estimate — ")]]

#text("We begin the proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("4")]#text(", closely following the arguments from Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(". Let ")#mi("{I, a, N, M, \\alpha}")#text(" be as in the theorem. We can restrict ")#mi("{q}")#text(" to the range")

#align(center)[#tao-fit-display[#mitex("q \\gtrapprox x^{1/2}")]]

#text("for some sufficiently slowly decaying ")#mi("{o(1)}")#text(", since otherwise we may use the Bombieri-Vinogradov theorem (Theorem 4 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("). Thus, by dyadic decomposition, we need to show that ")#metadata(none) <tao-4b3d4a0dd732f791ca89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sum_{d \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^2: D \\leq d < 2D} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (d))\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any fixed ")#mi("{A}")#text(" and for any ")#mi("{D}")#text(" in the range")

#align(center)[#tao-fit-display[#mitex("x^{1/2} \\lessapprox D \\lessapprox x^{1/2+2\\varpi}.")]]

#text("Let ")#metadata(none) <tao-352b5b6699d83cdc4efd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\epsilon > 0")]]

#text("be a sufficiently small fixed exponent.")

#text("By Lemma 11 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", we know that for all ")#mi("{d}")#text(" in ")#mi("{[D,2D]}")#text(" outside of a small number of exceptions, we have ")#metadata(none) <tao-3afbd5577a879d3382d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\prod_{p|d: p \\leq D_0} p \\lessapprox 1")]]

#text("where ")#metadata(none) <tao-0ad52e338662c923b15f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("D_0 := \\exp(\\log^{1/3} x).")]]

#text("Specifically, the number of exceptions in the interval ")#mi("{[D,2D]}")#text(" is ")#mi("{O(D \\log^{-A} x)}")#text(" for any fixed ")#mi("{A>0}")#text(". The contribution of the exceptional ")#mi("{d}")#text(" can be shown to be acceptable by Cauchy-Schwarz and trivial estimates (see Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("), so we restrict attention to those ")#mi("{d}")#text(" for which ")#link(<tao-3afbd5577a879d3382d9>)[#text("(18)")]#text(" holds. In particular, as ")#mi("{d}")#text(" is restricted to be doubly ")#mi("{x^\\delta}")#text("-densely divisible we may factor")

#align(center)[#tao-fit-display[#mitex("d=qr")]]

#text("with ")#mi("{q,r}")#text(" coprime and square-free, with ")#mi("{q \\in {\\mathcal S}_{I^{\\prime}}}")#text(" ")#mi("{x^\\delta}")#text("-densely divisible with ")#mi("{I^{\\prime} := [D_0,\\infty) \\cap I}")#text(", and")

#align(center)[#tao-fit-display[#mitex("x^{-\\epsilon-\\delta} N \\lessapprox r \\lessapprox x^{-\\epsilon} N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{1/2} \\lessapprox qr \\lessapprox x^{1/2+2\\varpi}.")]]

#text("Here we use the easily verified fact that ")#mi("{N \\gtrapprox x^\\epsilon}")#text(". Since ")#mi("{d}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible, we also have ")#mi("{qr \\in {\\mathcal D}_{x^\\delta}}")#text(".")

#text("By dyadic decomposition, it thus sufices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_{I^{\\prime}} \\cap {\\mathcal D}_{x^\\delta}: q \\sim Q} \\sum_{r \\in {\\mathcal S}_I: r \\sim R; qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (qr))\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{Q, R \\geq 1}")#text(" obey the size conditions ")#metadata(none) <tao-375676bd26868505668f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("x^{-\\epsilon-\\delta} N \\lessapprox R \\lessapprox x^{-\\epsilon} N")]]

#text("and ")#metadata(none) <tao-2617708489831f17c7b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("x^{1/2} \\lessapprox QR \\lessapprox x^{1/2 + 2\\varpi}.")]]

#text("Fix ")#mi("{Q,R}")#text(". We abbreviate ")#mi("{\\sum_{q \\in {\\mathcal S}_{I^{\\prime}} \\cap {\\mathcal D}_{x^\\delta}: q \\sim Q}}")#text(" and ")#mi("{\\sum_{r \\in {\\mathcal S}_I: r \\sim R}}")#text(" by ")#mi("{\\sum_q}")#text(" and ")#mi("{\\sum_r}")#text(" respectively, thus our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_q \\sum_{r: qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (qr))\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("We now split the discrepancy")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha \\ast \\beta; a\\ (qr)) = \\sum_{n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)")]]

#text("as the sum of the subdiscrepancies")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n).")]]

#text("In Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", it was established (using the Bombieri-Vinogradov theorem) that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)\\right| \\ll", block: true)]]

#align(center)[#tao-fit-display[#mitex("NM \\log^{-A} x")]]

#text("so it suffices to show that ")#metadata(none) <tao-c75de8c1b7c3ae525209>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\sum_{q} \\sum_{r; qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} \\left|\\sum_{n: n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM \\log^{-A} x.")]]

#text("As in the previous notes, we will not take advantage of the ")#mi("{r}")#text(" summation, and use crude estimates to reduce to showing that ")#metadata(none) <tao-e9fa0453869469e08db9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\sum_{q: qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} \\left|\\sum_{n: n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for each individual ")#mi("{r \\in {\\mathcal S}_I}")#text(" with ")#mi("{r \\sim R}")#text(", which we now select. It will suffice to prove the slightly stronger statement")

#metadata(none) <tao-53da29cd5a3142dbfa1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\sum_{q: qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} \\left|\\sum_{n: n = a\\ (r); n= b\\ (q)} \\alpha \\ast \\beta(n) - \\sum_{n: (n,q)=1; n = a\\ (r); n = b^{\\prime}\\ (q)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for all ")#mi("{a,b,b^{\\prime}}")#text(" coprime to ")#mi("{P_I}")#text(", since if one then specialises to the case when ")#mi("{b=a}")#text(" and averages over all primitive ")#mi("{b^{\\prime}\\ (P_I)}")#text(" we obtain ")#link(<tao-e9fa0453869469e08db9>)[#text("(23)")]#text(" from the triangle inequality.")

#text("We use the dispersion method. We write the left-hand side of ")#link(<tao-53da29cd5a3142dbfa1f>)[#text("(24)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q: qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} c_q (\\sum_{n: n = a\\ (r); n= b\\ (q)} \\alpha \\ast \\beta(n) - \\sum_{n: n = a\\ (r); n = b^{\\prime}\\ (q)} \\alpha \\ast \\beta(n))")]]

#text("for some bounded sequence ")#mi("{c_q}")#text(" (which may also depend on ")#mi("{r}")#text(", but we suppress this dependence). This expression may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\alpha(m) (\\sum_{q,n: mn = a\\ (r); qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} c_{q} \\beta(n) (1_{mn = b\\ (q)} - 1_{mn = b^{\\prime}\\ (q)})),")]]

#text("so from the Cauchy-Schwarz inequality and crude estimates it suffices to show that ")#metadata(none) <tao-8dd42f9fc74cd334c8dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\sum_{m} \\psi_M(m) \\left|\\sum_{q,n: mn = a\\ (r); qr \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} c_{q} \\beta(n) (1_{mn = b\\ (q)} - 1_{mn = b^{\\prime}\\ (q)})\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{\\psi_M}")#text(" is a smooth coefficient sequence at scale ")#mi("{M}")#text(". Expanding out the square, it suffices to show that ")#metadata(none) <tao-70848ccfe56d24288a89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a\\ (r); q_1r,q_2r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} \\overline{c_{q_2}} \\beta(n_1) \\overline{\\beta(n_2)} 1_{mn_1 = b\\ (q_1)} 1_{mn_2 = b^{\\prime}\\ (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x )")]]

#text("where ")#mi("{q_1,q_2}")#text(" is subject to the same constraints as ")#mi("{q}")#text(" (thus ")#mi("{q_i \\in {\\mathcal S}_{I^{\\prime}} \\cap {\\mathcal D}_{x^\\delta}}")#text(" and ")#mi("{q_i \\sim Q}")#text(" for ")#mi("{i=1,2}")#text("), and ")#mi("{X}")#text(" is some quantity that is independent of ")#mi("{b,b^{\\prime}}")#text(".")

#text("Observe that ")#mi("{n_1}")#text(" must be coprime to ")#mi("{q_1r}")#text(" and ")#mi("{n_2}")#text(" coprime to ")#mi("{q_2r}")#text(", with ")#mi("{n_1 = n_2\\ (r)}")#text(", to have a non-zero contribution to ")#link(<tao-70848ccfe56d24288a89>)[#text("(26)")]#text(". We then rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q_1,q_2: q_1r,q_2r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: n_1=n_2\\ (r); (n_1,q_1r)=(n_2,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} \\overline{c_{q_2}} \\overline{\\beta(n_1)} \\overline{\\beta(n_2)} 1_{m = a/n_1\\ (r); m = b/n_1\\ (q_1); m = b^{\\prime}/n_2 (q_2)};")]]

#text("note that these inverses in the various rings ")#mi("{{\\bf Z}/r{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_1{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_2{\\bf Z}}")#text(" are well-defined thanks to the coprimality hypotheses.")

#text("We may write ")#mi("{n_2 = n_1+kr}")#text(" for some ")#mi("{k = O(N/R)}")#text(". By the triangle inequality, and relabeling ")#mi("{n_1}")#text(" as ")#mi("{n}")#text(", it thus suffices to show that for any particular ")#metadata(none) <tao-996e1ebb1203243399dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("k = O(N/R),")]]

#text("one has ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\sum_{k = O(N/R)} \\sum_{q_1,q_2: q_1r,q_2r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} |\\sum_{n; (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} \\overline{c_{q_2}} \\beta(n) \\overline{\\beta(n+kr)} \\sum_{m} \\psi_M(m) 1_{m = a/n\\ (r); m = b/n\\ (q_1); m = b^{\\prime}/(n+kr) (q_2)}|")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-2} \\log^{-A} x )")]]

#text("for some ")#mi("{X}")#text(" independent of ")#mi("{b}")#text(", ")#mi("{b^{\\prime}}")#text(".")

#text("At this stage in previous posts we isolated the coprime case ")#mi("{(q_1,q_2)=1}")#text(" as the dominant case, using a controlled multiplicity hypothesis to deal with the non-coprime case. Here, we will carry the non-coprime case with us for a little longer so as not to rely on a controlled multiplicity hypothesis; this introduces some additional factors of ")#mi("{q_0 := (q_1,q_2)}")#text(" into the analysis but they should be ignored on a first reading.")

#text("Applying completion of sums (Section 2 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("), we can express the left-hand side of ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(28)")]#text(" as a main term ")#metadata(none) <tao-fc6def58fecc3ee66f39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\sum_{k = O(N/R)} \\sum_{q_1,q_2: q_1r,q_2r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}} |\\sum_{n; (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} \\overline{c_{q_2}} \\beta(n) \\overline{\\beta(n+kr)} (\\sum_{m} \\psi_M(m)) \\frac{1}{r[q_1,q_2]} 1_{b/n = b^{\\prime}/(n+kr)\\ ((q_1,q_2))}")]]

#text("plus an error term ")#metadata(none) <tao-a7a8572a4aabf25aac4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("O( \\frac{1}{H} \\sum_{k=O(N/R)} \\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2} \\left|\\sum_{n} \\beta(n) \\beta(n+kr) \\Phi_{k,r}(h,q_1,q_2; n)\\right| )", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ O( x^{-A} ),")]]

#text("where ")#metadata(none) <tao-a81ffb258bff4eddc451>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("H := x^\\epsilon Q^2 R/M")]]

#text("and ")#mi("{\\Phi = \\Phi_{k,r}}")#text(" is the phase ")#metadata(none) <tao-e46fd696bb4d24c149d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\Phi(h,q_1,q_2;n) := 1_{(n,r)=(n,q_1)=(n+kr,q_2)=1} 1_{q_1,q_2,q_1r,q_2r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}}")]]

#align(center)[#tao-fit-display[#mitex("1_{b/n=b^{\\prime}/(n+kr)\\ ((q_1,q_2))}")]]

#align(center)[#tao-fit-display[#mitex("e_r( \\frac{ah}{nq_1 q^{\\prime}_2} ) e_{q_1}( \\frac{bh}{n r q^{\\prime}_2} ) e_{q^{\\prime}_2}( \\frac{b^{\\prime} h}{(n+kr) r q_1} ),")]]

#text("where ")#mi("{q^{\\prime}_2 := q_2/(q_1,q_2)}")#text(".")

#text("Let us first deal with the main term ")#link(<tao-fc6def58fecc3ee66f39>)[#text("(29)")]#text(". The contribution of the coprime case ")#mi("{(q_1,q_2)=1}")#text(" does not depend on ")#mi("{b,b^{\\prime}}")#text(" and can thus be absorbed into the ")#mi("{X}")#text(" term. Now we consider the contribution of the non-coprime case when ")#mi("{q_0 = (q_1,q_2) > 1}")#text(". We may estimate the contribution of this case by")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{k = O(N/R)} \\sum_{q_0 \\in {\\mathcal S}_{I^{\\prime}}: 1 < q_0 \\ll Q, (q_0,r)=1} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0} |\\sum_{n: b/n = b^{\\prime}/(n+kr)\\ (q_0)}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n)\\right| |\\beta(n+kr)| M \\frac{1}{rq_0 q^{\\prime}_1 q^{\\prime}_2} ).", block: true)]]

#text("We may estimate ")#tao-math("{\\left|\\beta(n)\\right| \\left|\\beta(n+kr)\\right|}", block: false)#text(" by ")#tao-math("{\\left|\\beta(n)\\right|^2 + \\left|\\beta(n+kr)\\right|^2}", block: false)#text(". We just estimate the contribution of ")#tao-math("{\\left|\\beta(n)\\right|^2}", block: false)#text(", as the other case is treated similarly (after shifting ")#mi("{n}")#text(" by ")#mi("{kr}")#text("). We rearrange this contribution as")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{q_0 \\in {\\mathcal S}_{I^{\\prime}}: 1 < q_0 \\ll Q, (q_0,r)=1} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0} |\\sum_{n}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n)\\right|^2 M \\frac{1}{Rq_0 q^{\\prime}_1 q^{\\prime}_2} \\sum_{k = O(N/R)} 1_{b/n = b^{\\prime}/(n+kr)\\ (q_0)} ).", block: true)]]

#text("The ")#mi("{k}")#text(" summation is ")#mi("{O( 1 + \\frac{N}{Rq_0} )}")#text(". Evaluating the ")#mi("{n}")#text(" and ")#mi("{q^{\\prime}_1,q^{\\prime}_2}")#text(" summations, we obtain a bound of")

#align(center)[#tao-fit-display[#mitex("O( \\frac{MN}{R} \\log^{O(1)} x \\sum_{q_0 \\in {\\mathcal S}_{I^{\\prime}}: 1 < q_0 \\ll Q} \\frac{1}{q_0} ( 1 + \\frac{N}{Rq_0} ) ).")]]

#text("Since ")#mi("{q_0 > 1}")#text(" and ")#mi("{q_0 \\in {\\mathcal S}_{I^{\\prime}}}")#text(", we have ")#mi("{q_0 \\geq D_0}")#text(", and so we may evaluate the ")#mi("{q_0}")#text(" summation as")

#align(center)[#tao-fit-display[#mitex("O( \\frac{MN}{R} \\log^{O(1)} x (1 + \\frac{N}{RD_0} ) ).")]]

#text("By ")#link(<tao-375676bd26868505668f>)[#text("(20)")]#text(" and ")#link(<tao-0ad52e338662c923b15f>)[#text("(19)")]#text(", this is ")#mi("{O( N^2 M R^{-2} \\log^{-A} x )}")#text(" as required.")

#text("It remains to control ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(30)")]#text(". We may assume that ")#mi("{H \\geq 1}")#text(", as the claim is trivial otherwise. It will suffice to obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{H} \\sum_{k=O(N/R)} \\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} \\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi_{k,r}(h,q_1,q_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^{-\\epsilon} N^2 M R^{-2}.")]]

#text("Using ")#link(<tao-a81ffb258bff4eddc451>)[#text("(31)")]#text(", it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} \\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi_{k,r}(h,q_1,q_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N")]]

#text("for each ")#mi("{k = O(N/R)}")#text(".")

#text("We now work with a single ")#mi("{k}")#text(", and abbreviate ")#mi("{\\Phi_{k,r}}")#text(" as ")#mi("{\\Phi}")#text(". To proceed further, we write ")#mi("{q_0 := (q_1,q_2)}")#text(" and ")#mi("{q_1 = q_0 q^{\\prime}_1}")#text(", ")#mi("{q_2 = q_0 q^{\\prime}_2}")#text("; it then suffices to show that ")#metadata(none) <tao-9834876dcfb05cb167a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\sum_{1 \\leq h \\leq H} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = 1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N / q_0")]]

#text("for each ")#mi("{q_0 \\geq 1}")#text(".")

#text("Henceforth we work with a single choice of ")#mi("{q_0}")#text(". We pause to verify the relationship")

#align(center)[#tao-fit-display[#mitex("H \\lessapprox Q.")]]

#text("From ")#link(<tao-a81ffb258bff4eddc451>)[#text("(31)")]#text(" and ")#link(<tao-2617708489831f17c7b6>)[#text("(21)")]#text(", this follows from the assertion that")

#align(center)[#tao-fit-display[#mitex("x^{1/2+2\\varpi+\\epsilon} \\lessapprox M,")]]

#text("but this follows from ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(5)")]#text(", ")#link(<tao-58e0413224af6b6d3505>)[#text("(6)")]#text(" if ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{c}")#text(".")

#text("As ")#mi("{q_1}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible, we may now factor ")#mi("{q_1 = s_1 t_1}")#text(" where")

#align(center)[#tao-fit-display[#mitex("x^{-\\delta} Q/H \\lessapprox s_1 \\lessapprox Q/H")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("H \\lessapprox t_1 \\lessapprox x^\\delta H.")]]

#text("Factoring out ")#mi("{q_0}")#text(", we may then write ")#mi("{q^{\\prime}_1 = s^{\\prime}_1 t^{\\prime}_1}")#text(" where")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} x^{-\\delta} Q/H \\lessapprox s^{\\prime}_1 \\lessapprox Q/H")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} H \\lessapprox t^{\\prime}_1 \\lessapprox x^\\delta H.")]]

#text("By dyadic decomposition, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h \\leq H} \\sum_{s^{\\prime}_1 \\sim S; t^{\\prime}_1 \\sim T; q^{\\prime}_2 \\sim Q/q_0: (s^{\\prime}_1 t^{\\prime}_1,q^{\\prime}_2) = 1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N / q_0")]]

#text("whenever ")#mi("{S,T}")#text(" are such that")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} x^{-\\delta} Q/H \\lessapprox S \\lessapprox Q/H")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} H \\lessapprox T \\lessapprox x^\\delta H.")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("ST \\sim Q/q_0.")]]

#text("We rearrange this estimate as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0} \\beta(n) \\overline{\\beta(n+kr)} \\sum_{1 \\leq h \\leq H; t^{\\prime}_1 \\sim T} c_{h,s^{\\prime}_1,t^{\\prime}_1,q^{\\prime}_2} \\Phi(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox QSTN")]]

#text("for some bounded sequence ")#mi("{c_{h,s_1,t_1,q_2}}")#text(" which is only non-zero when")

#align(center)[#tao-fit-display[#mitex("(s^{\\prime}_1 t^{\\prime}_1,q^{\\prime}_2) = (q_0,s^{\\prime}_1t^{\\prime}_1) = (q_0,q^{\\prime}_2) = 1.")]]

#text("By Cauchy-Schwarz and crude estimates, it then suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0} \\psi_N(n) \\left|\\sum_{1 \\leq h \\leq H; t^{\\prime}_1 \\sim T} c_{h,s^{\\prime}_1,t^{\\prime}_1,q^{\\prime}_2} \\Phi(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q_2; n)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox QST^2 N q_0")]]

#text("where ")#mi("{\\psi_N}")#text(" is a coefficient sequence at scale ")#mi("{N}")#text(". The left-hand side may be bounded by ")#metadata(none) <tao-cb6e53541e37a1d6076e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\sum_{1 \\leq h,\\tilde h \\leq H; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0; (s^{\\prime}_1t^{\\prime}_1\\tilde t^{\\prime}_1,q^{\\prime}_2)=1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi(h, q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) } \\right|.", block: true)]]

#text("The contribution of the diagonal case ")#mi("{h \\tilde t^{\\prime}_1 = \\tilde h t^{\\prime}_1}")#text(" is ")#mi("{\\lessapprox HTSQ N/q_0}")#text(" by the divisor bound, which is acceptable since ")#mi("{q_0 T \\gtrapprox H}")#text(". Thus it suffices to control the off-diagonal case ")#mi("{h\\tilde t^{\\prime}_1 \\neq \\tilde ht^{\\prime}_1}")#text(". Observe that for a given choice of ")#mi("{h,\\tilde h,s^{\\prime}_1,t^{\\prime}_1,\\tilde t^{\\prime}_1,q^{\\prime}_2}")#text(", the phase ")#mi("{\\Phi(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) }}")#text(" either vanishes identically, or is equal to")

#align(center)[#tao-fit-display[#mitex("1_{b/n=b^{\\prime}/(n+kr)\\ (q_0)} e_{r q_0 s^{\\prime}_1 [t^{\\prime}_1, \\tilde t^{\\prime}_1]}(\\frac{c_1}{n} ) e_{q_0 q^{\\prime}_2}(\\frac{c_2}{n+kr} )")]]

#text("for some quantities ")#mi("{c_1,c_2}")#text(" with")

#align(center)[#tao-fit-display[#mitex("(c_1,r) = (h\\tilde t^{\\prime}_1-\\tilde ht^{\\prime}_1, r).")]]

#text("Also, by construction, ")#mi("{rq_0 s^{\\prime}_1 t^{\\prime}_1}")#text(", ")#mi("{rq_0 s^{\\prime}_1 \\tilde t^{\\prime}_1}")#text(" and ")#mi("{q_0 q^{\\prime}_2}")#text(" are ")#mi("{x^\\delta}")#text("-densely divisible, so ")#mi("{[rq_0 s^{\\prime}_1 t^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2]}")#text(" is as well. (Here we use the fact that the least common multiple of two ")#mi("{x^\\delta}")#text("-densely divisible numbers is again ")#mi("{x^\\delta}")#text("-densely divisible, which follows from the more general fact that if ")#mi("{q=q_1 q_2}")#text(", ")#mi("{q_2 \\leq \\sqrt{q}}")#text(", and ")#mi("{q_1}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible, then ")#mi("{q}")#text(" is also.) The condition ")#mi("{1_{b/n=b^{\\prime}/(n+kr)\\ (q_0)}}")#text(" is either not satisfiable, or restricts ")#mi("{n}")#text(" to a congruence class ")#mi("{a\\ (q)}")#text(" for some ")#mi("{q}")#text(" dividing ")#mi("{q_0}")#text(". We can thus apply Corollary ")#link(<tao-ceea36e7bdbb7c65e0e2>)[#text("11")]#text(" and bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi(h, q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) } \\right|", block: true)]]

#text("by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox N^{1/2} (Rq_0 ST^2 Q/q_0)^{1/6} x^{\\delta/6} + \\frac{(h\\tilde t^{\\prime}_1-\\tilde ht^{\\prime}_1, r)}{R} N.")]]

#text("Bounding ")#mi("{Rq_0 ST^2 Q/q_0}")#text(" by ")#mi("{x^\\delta RQ^2 H}")#text(", we can thus bound the off-diagonal contribution to ")#link(<tao-cb6e53541e37a1d6076e>)[#text("(34)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox \\sum_{1 \\leq h,\\tilde h \\leq H; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T: h \\tilde t^{\\prime}_1 \\neq \\tilde h t^{\\prime}_1}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0} N^{1/2} x^{\\delta/3} (RQ^2 H)^{1/6} + \\frac{(h\\tilde t^{\\prime}_1-\\tilde ht^{\\prime}_1, r)}{R} N")]]

#text("which sums (using Lemma 5 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(" and the divisor bound) to")

#align(center)[#tao-fit-display[#mitex("\\lessapprox (H^2 T^2 S Q / q_0 ) (N^{1/2} x^{\\delta/3} (RQ^2 H)^{1/6} + \\frac{1}{R} N ).")]]

#text("Discarding some factors of ")#mi("{q_0}")#text(", we reduce to showing that")

#align(center)[#tao-fit-display[#mitex("N^{1/2} x^{\\delta/3} (RQ^2 H)^{1/6} + \\frac{1}{R} N \\lessapprox H^{-2} N.")]]

#text("From ")#link(<tao-a81ffb258bff4eddc451>)[#text("(31)")]#text(", ")#link(<tao-2617708489831f17c7b6>)[#text("(21)")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(5)")]#text(" we have ")#mi("{Q \\lessapprox x^{1/2+2\\varpi} R^{-1}}")#text(" and ")#mi("{H \\lessapprox x^{4\\varpi+\\epsilon} N R^{-1}}")#text(", so the previous estimate will be implied by")

#align(center)[#tao-fit-display[#mitex("N^{1/2} x^{\\delta/3} (x^{1+8\\varpi+\\epsilon} N R^{-2})^{1/6} + \\frac{1}{R} N \\lessapprox x^{-8\\varpi-2\\epsilon} R^2 N^{-1}.")]]

#text("From ")#link(<tao-375676bd26868505668f>)[#text("(20)")]#text(", this will be implied by")

#align(center)[#tao-fit-display[#mitex("N^{1/2} x^{\\delta/3} (x^{1+8\\varpi+2\\delta+3\\epsilon} N^{-1})^{1/6} + x^{\\delta+\\epsilon} \\lessapprox x^{-8\\varpi-2\\delta-4\\epsilon} N")]]

#text("or equivalently that")

#align(center)[#tao-fit-display[#mitex("x^{\\frac{1}{4} + 14 \\varpi + 4 \\delta + \\frac{27}{4} \\epsilon} \\lessapprox N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{8 \\varpi + 3 \\delta + 5 \\epsilon} \\lessapprox N")]]

#text("which by ")#link(<tao-58e0413224af6b6d3505>)[#text("(6)")]#text(" is obeyed whenever")

#align(center)[#tao-fit-display[#mitex("56 \\varpi + 16 \\delta + 4\\sigma < 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("16 \\varpi + 6 \\delta + 2 \\sigma < 1.")]]

#text("The second condition is implied by the first and may be deleted. The proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("4")]#text(" is now complete.")

#heading(level: 1)[#strong[#text(" — 3. Type II estimate — ")]]

#text("Now we prove Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("5")]#text(". We repeat the Type I arguments through to ")#link(<tao-9834876dcfb05cb167a5>)[#text("(33)")]#text(" (noting that the hypothesis ")#link(<tao-58e0413224af6b6d3505>)[#text("(6)")]#text(" is never used until that point, other than to ensure that ")#mi("{N \\gtrapprox x^\\epsilon}")#text("), thus we are again faced with the task of proving")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq h \\leq H} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = 1} \\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N / q_0.")]]

#text("This time, however, we do not have ")#mi("{H \\lessapprox Q}")#text("; however we claim the weaker bound ")#metadata(none) <tao-883ada0bed08b1db587b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("H \\lessapprox Q^2.")]]

#text("Indeed by ")#link(<tao-a81ffb258bff4eddc451>)[#text("(31)")]#text(" this is equivalent to")

#align(center)[#tao-fit-display[#mitex("x^\\epsilon R \\lessapprox M")]]

#text("and this follows from ")#link(<tao-375676bd26868505668f>)[#text("(20)")]#text(" and ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(5)")]#text(", ")#link(<tao-2f37db5234a05e9b49a5>)[#text("(8)")]#text(".")

#text("With this weaker bound ")#link(<tao-883ada0bed08b1db587b>)[#text("(35)")]#text(" we have to perform Cauchy-Schwarz differently. We rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\beta(n) \\overline{\\beta(n+kr)} ( \\sum_{1 \\leq h \\leq H}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = 1} c_{h,q^{\\prime}_1,q^{\\prime}_2} \\Phi(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n) )")]]

#text("for some bounded coefficients ")#mi("{c_{h,q^{\\prime}_1,q^{\\prime}_2}}")#text(". Applying Cauchy-Schwarz, it then suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\psi_N(n) |\\sum_{1 \\leq h \\leq H}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = 1} c_{h,q^{\\prime}_1,q^{\\prime}_2} \\Phi(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n)|^2")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^4 N / q_0^2.")]]

#text("The left-hand side may be bounded by")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h, \\tilde h \\leq H} \\sum_{q^{\\prime}_1,q^{\\prime}_2,\\tilde q^{\\prime}_1,\\tilde q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = (\\tilde q^{\\prime}_1,\\tilde q^{\\prime}_2) = 1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_n \\psi_N(n) \\Phi(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{\\Phi(\\tilde h,q_0 \\tilde q^{\\prime}_1,q_0 \\tilde q^{\\prime}_2; n)} \\right|.", block: true)]]

#text("We isolate the diagonal case ")#mi("{h \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2 = \\tilde h q^{\\prime}_1 q^{\\prime}_2}")#text(". By the divisor bound, the contribution of this case is ")#mi("{\\lessapprox HN (Q/q_0)^2}")#text(", which is acceptable by ")#link(<tao-883ada0bed08b1db587b>)[#text("(35)")]#text(". So we now restrict attention to the off-diagonal case ")#mi("{h \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2 \\neq \\tilde h q^{\\prime}_1 q^{\\prime}_2}")#text(". The phase ")#mi("{\\Phi(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{\\Phi(\\tilde h,q_0 \\tilde q^{\\prime}_1,q_0 \\tilde q^{\\prime}_2; n)}}")#text(" either vanishes identically, or takes the form")

#align(center)[#tao-fit-display[#mitex("1_{b/n=b^{\\prime}/(n+kr)\\ (q_0)} e_{r q_0 [q^{\\prime}_1, \\tilde q^{\\prime}_1]}(\\frac{c_1}{n} ) e_{q_0 [q^{\\prime}_2, \\tilde q^{\\prime}_2]}(\\frac{c_2}{n+kr} )")]]

#text("for some ")#mi("{c_1,c_2}")#text(" with ")#mi("{(c_1,r) = (h \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2 - \\tilde h q^{\\prime}_1 q^{\\prime}_2, r)}")#text(". By the second part of Corollary ")#link(<tao-ceea36e7bdbb7c65e0e2>)[#text("11")]#text(" we may thus bound the previous expression by")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h, \\tilde h \\leq H} \\sum_{q^{\\prime}_1,q^{\\prime}_2,\\tilde q^{\\prime}_1,\\tilde q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = (\\tilde q^{\\prime}_1,\\tilde q^{\\prime}_2) = 1}")]]

#align(center)[#tao-fit-display[#mitex("(r q_0 q^{\\prime}_1 q^{\\prime}_2 \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2)^{1/2} + (h \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2 - \\tilde h q^{\\prime}_1 q^{\\prime}_2, r) R^{-1} N.")]]

#text("By the divisor bound and Lemma 5 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(", this sums to")

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^2 (Q/q_0)^4 ( ( R q_0 (Q/q_0)^4 )^{1/2} + R^{-1} N ).")]]

#text("Discarding some factors of ")#mi("{q_0}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("(RQ^4)^{1/2} + R^{-1} N \\lessapprox H^{-2} N.")]]

#text("From ")#link(<tao-a81ffb258bff4eddc451>)[#text("(31)")]#text(", ")#link(<tao-2617708489831f17c7b6>)[#text("(21)")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(5)")]#text(" we have ")#mi("{Q \\lessapprox x^{1/2+2\\varpi} R^{-1}}")#text(" and ")#mi("{H \\lessapprox x^{4\\varpi+\\epsilon} N R^{-1}}")#text(", so the previous estimate will be implied by")

#align(center)[#tao-fit-display[#mitex("(x^{2+8\\varpi} R^{-3})^{1/2} + \\frac{1}{R} N \\lessapprox x^{-8\\varpi-2\\epsilon} R^2 N^{-1}.")]]

#text("From ")#link(<tao-375676bd26868505668f>)[#text("(20)")]#text(", this will be implied by")

#align(center)[#tao-fit-display[#mitex("(x^{2+8\\varpi+3\\delta+3\\epsilon})^{1/2} N^{-3/2} + x^{\\delta+\\epsilon} \\lessapprox x^{-8\\varpi-2\\delta-4\\epsilon} N")]]

#text("or equivalently that")

#align(center)[#tao-fit-display[#mitex("x^{\\frac{2}{5} + \\frac{24}{5} \\varpi + \\frac{7}{5} \\delta + \\frac{11}{5} \\epsilon} \\lessapprox N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{8 \\varpi + 3 \\delta + 5 \\epsilon} \\lessapprox N")]]

#text("which by ")#link(<tao-2f37db5234a05e9b49a5>)[#text("(8)")]#text(" is obeyed whenever")

#align(center)[#tao-fit-display[#mitex("68 \\varpi + 14 \\delta < 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("20 \\varpi + 6 \\delta < 1.")]]

#text("The second condition is implied by the first and may be deleted. The proof of Theorem ")#link(<tao-9ce19620746a8f953f54>)[#text("5")]#text(" is now complete.")

#heading(level: 1)[#strong[#text(" — 4. Type III estimate — ")]]

#text("We now prove Theorem ")#link(<tao-27b250d25accb10de21a>)[#text("6")]#text(". Let ")#mi("{M,N_1,N_2,N_3,\\alpha,\\psi_1,\\psi_2,\\psi_3,I,a}")#text(" be as in the definition of ")#mi("{Type^{\\prime\\prime}_{III}[\\varpi,\\delta,\\sigma]}")#text(". We will not need the full strength of double dense divisibility here, and work instead with single dense divisibility. By a finer-than-dyadic decomposition (and using the Bombieri-Vinogradov theorem to handle small moduli), it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}: q = (1+O(x^{-\\epsilon})) Q} |\\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a\\ (q))| \\lessapprox x^{-2\\epsilon} M N")]]

#text("for some sufficiently small fixed ")#mi("{\\epsilon>0}")#text(" and all ")#metadata(none) <tao-cb96897bd0f82fd54c24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("x^{1/2} \\lessapprox Q \\ll x^{1/2+2\\varpi},")]]

#text("where ")#mi("{N := N_1 N_2 N_3}")#text(".")

#text("Henceforth we work with a single choice of ")#mi("{Q}")#text(", and abbreviate the ")#mi("{q}")#text(" summation as ")#mi("{\\sum_q}")#text(". The left-hand side may then be written as")

#align(center)[#tao-fit-display[#mitex("\\sum_q c_q \\Delta(\\alpha * \\psi_1 * \\psi_2 * \\psi_3; a\\ (q))")]]

#text("for some bounded sequence ")#mi("{c_q}")#text(". So it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_q c_q \\sum_{n = a\\ (q)} \\alpha * \\psi_1 * \\psi_2 * \\psi_3(n) = X + O( x^{-2\\epsilon+o(1)} M N )")]]

#text("for some ")#mi("{X}")#text(" that is independent of ")#mi("{a}")#text(", as the claim then follows by averaging in ")#mi("{a}")#text(".")

#text("The left-hand side may be rewritten as ")#metadata(none) <tao-ab547757da37eb600011>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\sum_q c_q \\sum_{m: (m,q)=1} \\alpha(m) \\sum_{n_1,n_2,n_3} \\psi_1(n_1) \\psi_2(n_2) \\psi_3(n_3) 1_{mn_1n_2n_3 = a\\ (q)}.")]]

#text("Note that for ")#mi("{i=1,2,3}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("N_i \\lessapprox x^{1/2-\\sigma} \\lessapprox x^{-\\sigma} x^{1/2} \\lessapprox x^{-\\sigma} Q.")]]

#text("By Fourier inversion we have")

#align(center)[#tao-fit-display[#mitex("\\psi_i(n_i) = \\frac{1}{q} \\sum_{-q/2 < h_i \\leq q/2} \\hat \\psi_i(h_i/q) e_{q}( h_i n_i )")]]

#text("for all ")#mi("{-q/2 < n_i \\leq q/2}")#text(", where ")#mi("{\\hat \\psi_i}")#text(" is the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat \\psi_i(\\theta) := \\sum_{n_i} \\psi_i(n_i) e(-\\theta n_i).")]]

#text("From the smoothness of ")#mi("{\\psi_i}")#text(", Poisson summation, and integration by parts we have the decay estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat \\psi_i(\\theta)\\right| \\lessapprox N_i (1 + N_i \\left|\\theta\\right|)^{-C}", block: true)]]

#text("for any fixed ")#mi("{C \\geq 0}")#text(" and any ")#mi("{-1/2 \\leq \\theta \\leq 1/2}")#text(". More generally, we also have the derivative estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{d^j}{d\\theta^j} \\hat \\psi_i(\\theta)\\right| \\lessapprox N_i^{1+j} (1 + N_i \\left|\\theta\\right|)^{-C}", block: true)]]

#text("for any fixed ")#mi("{C,j \\geq 0}")#text(" and any ")#mi("{-1/2 \\leq \\theta \\leq 1/2}")#text(". We thus have")

#align(center)[#tao-fit-display[#mitex("\\hat \\psi_i(h_i/q) = O(x^{-100})")]]

#text("(say) when ")#tao-math("{\\left|h_i\\right| > x^\\epsilon H_i}", block: false)#text(", where")

#align(center)[#tao-fit-display[#mitex("H_i := Q / N_i.")]]

#text("Furthermore, for ")#tao-math("{\\left|h_i\\right| \\leq x^\\epsilon H_i}", block: false)#text(", we can perform a Taylor expansion around ")#mi("{q=Q}")#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{q} \\hat \\psi_i(h_i/q) = \\frac{1}{H_i} \\sum_{j=0}^J c_{i,j,h_i} (\\frac{q-Q}{Q})^j + O( x^{-100} )")]]

#text("for some fixed ")#mi("{J > 0}")#text(" (depending on ")#mi("{\\epsilon}")#text("), any ")#mi("{q = (1+O(x^{-\\epsilon})) Q}")#text(", and some coefficients ")#mi("{c_{i,j,h_i} = O(1)}")#text(" whose exact value will not be of importance to us. We may thus express ")#link(<tao-ab547757da37eb600011>)[#text("(37)")]#text(", up to negligible errors, as the sum of a bounded number of expressions of the form")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{H} \\sum_q c^{\\prime}_q \\sum_{m: (m,q)=1} \\alpha(m) \\sum_{h_1,h_2,h_3} c^{\\prime\\prime}_{h_1,h_2,h_3}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1,n_2,n_3 \\in {\\bf Z}/q{\\bf Z}} e_{q}( h_1 n_1 + h_2 n_2 + h_3 n_3 ) 1_{mn_1n_2n_3 = a\\ (q)}")]]

#text("for some bounded sequences ")#mi("{c^{\\prime}_q, c^{\\prime\\prime}_{h_1,h_2,h_3}}")#text(" whose exact value will not be of importance to us other than their support, which is contained in the sets")

#align(center)[#tao-fit-display[#mitex("\\{ q = (1 + O(x^{-\\epsilon})) Q: q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\{ (h_1,h_2,h_3): \\left|h_1\\right| \\leq x^\\epsilon H_1, \\left|h_2\\right| \\leq x^\\epsilon H_2, \\left|h_3\\right| \\leq x^\\epsilon H_3 \\}", block: true)]]

#text("respectively, and where")

#align(center)[#tao-fit-display[#mitex("H := H_1 H_2 H_3 = Q^3 / N.")]]

#text("If we then introduce the modified hyper-Kloosterman sum")

#align(center)[#tao-fit-display[#mitex("F( h_1,h_2,h_3, a; q) :=")]]

#align(center)[#tao-fit-display[#mitex("\\frac{1}{q} \\sum_{n_1,n_2,n_3 \\in ({\\bf Z}/q{\\bf Z})^\\times} e_{q}( h_1 n_1 + h_2 n_2 + h_3 n_3 ) 1_{n_1n_2n_3 = a\\ (q)}")]]

#text("defined for ")#mi("{h_1,h_2,h_3 \\in {\\bf Z}/q{\\bf Z}}")#text(" and ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(", then our objective is now to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_q \\tilde c^{\\prime}_q \\sum_{m: (m,q)=1} \\alpha(m) \\sum_{h_1,h_2,h_3} c^{\\prime\\prime}_{h_1,h_2,h_3} F( h_1,h_2,h_3, a \\overline{m}, q)")]]

#align(center)[#tao-fit-display[#mitex("= X^{\\prime} + O( x^{-2\\epsilon+o(1)} H MN / Q)")]]

#text("for some ")#mi("{X^{\\prime}}")#text(" that does not depend on ")#mi("{a}")#text(", where ")#mi("{\\overline{m}}")#text(" is the reciprocal of ")#mi("{m}")#text(" in ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" and ")#mi("{\\tilde c^{\\prime}_q := \\frac{q}{Q} c^{\\prime}_q}")#text(".")

#text("We may rewrite ")#mi("{HMN/Q}")#text(" as ")#mi("{M Q^2}")#text(". Observe that ")#mi("{F(h_1,h_2,h_3, a \\overline{m}; q)}")#text(" is independent of ")#mi("{a}")#text(" if one of ")#mi("{h_1}")#text(" vanishes (as can be seen by dilating ")#mi("{n_1}")#text("), and similarly if ")#mi("{h_2}")#text(" or ")#mi("{h_3}")#text(" vanishes. Thus we may delete the case ")#mi("{h_1h_2h_3=0}")#text(" from the above sum, and reduce to showing that ")#metadata(none) <tao-5a8d6bc40c357aa677f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#tao-math("\\left|\\sum_q \\tilde c^{\\prime}_q \\sum_{m: (m,q)=1} \\alpha(m) \\sum_{h_1,h_2,h_3: h_1h_2h_3 \\neq 0} c^{\\prime\\prime}_{h_1,h_2,h_3} F( h_1,h_2,h_3, a \\overline{m}; q)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^{-2\\epsilon} M Q^2.")]]

#text("At this point we need to account for a technical problem that the ")#mi("{h_1,h_2,h_3}")#text(" may still share a common factor with ")#mi("{q}")#text(" even after being restricted to be non-zero. For ")#mi("{i=1,2,3}")#text(", let ")#mi("{b_i := \\prod_{p|q; p^j || h_i} p^j}")#text(" be the product of all the primes in ")#mi("{h_i}")#text(" (counting multiplicity) that also divide ")#mi("{q}")#text("; thus ")#mi("{h_i = b_i h^{\\prime}_i}")#text(" where ")#mi("{h^{\\prime}_i}")#text(" is coprime to ")#mi("{q}")#text(". As we shall see, the case ")#mi("{b_1=b_2=b_3=1}")#text(" is dominant, and on a first reading one may wish to focus exclusively on this case in what follows to simplify the discussion. We then write ")#mi("{b := \\prod_{p|b_1b_2b_3} p = (h_1h_2h_3,q)}")#text("; this divides ")#mi("{q}")#text(", so we may write ")#mi("{q = bq^{\\prime}}")#text(". Note that as ")#mi("{q}")#text(" is ")#mi("{x^\\delta}")#text("-densely divisible, ")#mi("{q^{\\prime}}")#text(" is ")#mi("{bx^\\delta}")#text("-densely divisible, thus ")#mi("{q^{\\prime} \\in {\\mathcal S}_I \\cap {\\mathcal D}_{bx^\\delta}}")#text(".")

#text("Now we factor ")#mi("{F}")#text(". From Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("8")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("F( h_1,h_2,h_3, a \\overline{m}; q) = F( h_1 \\overline{q^{\\prime}},h_2 \\overline{q^{\\prime}},h_3 \\overline{q^{\\prime}}, a \\overline{m}; b) F( h_1 \\overline{b},h_2 \\overline{b},h_3 \\overline{b}, a \\overline{m}; q^{\\prime}).")]]

#text("For the second term, we observe that ")#mi("{h_i \\overline{b}}")#text(" is coprime to ")#mi("{q^{\\prime}}")#text(" for ")#mi("{i=1,2,3}")#text(", and so by dilating the variables ")#mi("{n_1,n_2,n_3}")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("F( h_1 \\overline{b},h_2 \\overline{b},h_3 \\overline{b}, a \\overline{m}; q^{\\prime})  & = K_3( a h_1 h_2 h_3 \\overline{b}^3 \\overline{m}; q^{\\prime} )", block: true)



#tao-math(" & = K_3( a_{b_1,b_2,b_3,q^{\\prime}} h^{\\prime}_1 h^{\\prime}_2 h^{\\prime}_3 \\overline{m}; q^{\\prime})", block: true)
]

#text("where ")#mi("{a_{b_1,b_2,b_3,q^{\\prime}}}")#text(" is the residue class")

#align(center)[#tao-fit-display[#mitex("a_{b_1,b_2,b_3,q^{\\prime}} := \\frac{a b_1 b_2 b_3}{b^3}\\ (q^{\\prime})")]]

#text("and we recall that ")#mi("{K_3}")#text(" is the normalised hyper-Kloosterman sum")

#align(center)[#tao-fit-display[#mitex("K_3( a;q) := \\frac{1}{q} \\sum_{x,y,z \\in ({\\bf Z}/q{\\bf Z})^\\times: xyz = a\\ (q)} e_q(x+y+z).")]]

#text("As for the first term, we have the following estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14")]#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\left|F( h_1 \\overline{q^{\\prime}},h_2 \\overline{q^{\\prime}},h_3 \\overline{q^{\\prime}}, a \\overline{m}; b)\\right| \\leq \\frac{\\text{rad}(b_1) \\text{rad}(b_2) \\text{rad}(b_3)}{\\text{rad}(b_1 b_2 b_3)^2}.", block: true)]]

#text("where ")#mi("{\\text{rad}(a) := \\prod_{p|a} p}")#text(" (thus for instance ")#mi("{b = \\text{rad}(b_1 b_2 b_3)}")#text(").")
]

#emph[#text("Proof:")]#text(" By further applications of Lemma ")#link(<tao-793ff64f83b41b5d467a>)[#text("8")]#text(" it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|F( c_1, c_2, c_3, a; p)\\right| \\leq \\frac{(c_1,p) (c_2,p) (c_3,p)}{p^2}", block: true)]]

#text("whenever ")#mi("{p}")#text(" is prime, ")#mi("{c_1,c_2,c_3 \\in {\\bf Z}/p{\\bf Z}}")#text(" with ")#mi("{c_1c_2c_3 = 0\\ (p)}")#text(", and ")#mi("{a \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(".")

#text("Without loss of generality we may assume that ")#mi("{c_3 = 0\\ (p)}")#text(", then we may rewrite ")#mi("{F(c_1,c_2,c_3,a;p)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p} \\sum_{n_1,n_2 \\in ({\\bf Z}/p{\\bf Z})^\\times} e_p( c_1 n_1 + c_2 n_2 ).")]]

#text("But this factors as the product of two Ramanujan sums divided by ")#mi("{p}")#text(", and the claim then follows by direct computation. ")#mi("\\Box")

#text("For brevity we write ")#mi("{\\vec b}")#text(" for ")#mi("{b_1,b_2,b_3}")#text(". We may thus bound the left-hand side of ")#link(<tao-5a8d6bc40c357aa677f9>)[#text("(38)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\vec b} \\frac{\\text{rad}(b_1) \\text{rad}(b_2) \\text{rad}(b_3)}{\\text{rad}(b_1 b_2 b_3)^2} \\sum_{h^{\\prime}_1,h^{\\prime}_2,h^{\\prime}_3}")]]

#align(center)[#tao-fit-display[#mitex("|\\sum_{q^{\\prime}\\in {\\mathcal S}_I \\cap {\\mathcal D}_{bx^\\delta}: (b h^{\\prime}_1 h^{\\prime}_2 h^{\\prime}_3,q^{\\prime})=1} \\tilde c^{\\prime}_{bq^{\\prime}}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m: (bq^{\\prime},m)=1} \\alpha(m) K_3( a_{\\vec b,q^{\\prime}} h^{\\prime}_1 h^{\\prime}_2 h^{\\prime}_3 \\overline{m}; q^{\\prime} )|")]]

#text("where the ")#mi("{h^{\\prime}_i}")#text(" summations are over the ranges")

#align(center)[#tao-fit-display[#tao-math("0 < \\left|h^{\\prime}_i\\right| \\leq \\frac{x^\\epsilon H_i}{b_i}.", block: true)]]

#text("Writing ")#mi("{h := h^{\\prime}_1 h^{\\prime}_2 h^{\\prime}_3}")#text(", so that")

#align(center)[#tao-fit-display[#tao-math("0 < \\left|h\\right| \\leq \\frac{x^{3\\epsilon} H}{b_1 b_2 b_3},", block: true)]]

#text("and recalling that ")#mi("{b = \\text{rad}(b_1b_2b_3)}")#text(", we may thus estimate the previous expression by")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\vec b} \\frac{\\text{rad}(b_1) \\text{rad}(b_2) \\text{rad}(b_3)}{b^2} S_{\\vec b}")]]

#text("where ")#mi("{S_{\\vec b}}")#text(" is the quantity")

#align(center)[#tao-fit-display[#tao-math("S_{\\vec b} := \\sum_{0 < \\left|h\\right| \\leq H_{\\vec b}} \\tau_3(h) |\\sum_{q^{\\prime}\\in {\\mathcal S}_I \\cap {\\mathcal D}_{bx^\\delta}: (b h,q^{\\prime})=1} \\tilde c^{\\prime}_{bq^{\\prime}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m: (bq^{\\prime},m)=1} \\alpha(m) K_3( a_{\\vec b,q^{\\prime}} h \\overline{m}; q^{\\prime} )|")]]

#text("where ")#mi("{\\tau_3(h) := \\sum_{h_1,h_2,h_3: h_1h_2h_3=1} 1}")#text(" is the third divisor function and")

#align(center)[#tao-fit-display[#mitex("H_{\\vec b} := \\frac{x^{3\\epsilon} H}{b_1 b_2 b_3}.")]]

#text("Our task is now to show that ")#metadata(none) <tao-0ebb429fa86d481c2630>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\sum_{\\vec b} \\frac{\\text{rad}(b_1) \\text{rad}(b_2) \\text{rad}(b_3)}{b^2} S_{\\vec b} \\lessapprox x^{-2\\epsilon} M Q^2.")]]

#text("We now focus on estimating ")#mi("{S_{\\vec b}}")#text(".")

#text("We let ")#metadata(none) <tao-8e35c2cd3bf6641bdb0e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("1 \\leq S_0 \\leq y Q_{\\vec b}")]]

#text("be a quantity to optimise in later, where")

#align(center)[#tao-fit-display[#mitex("Q_{\\vec b} := \\frac{Q}{b}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("y := x^\\delta b.")]]

#text("We may assume that ")#metadata(none) <tao-ec9ff5791bbccd47c022>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("Q_{\\vec b}, H_{\\vec b} \\gg 1")]]

#text("Observe that every ")#mi("{q^{\\prime}}")#text(" that appears in the expression for ")#mi("{S_{\\vec b}}")#text(" is ")#mi("{y}")#text("-densely divisible and may thus be factored as ")#mi("{q^{\\prime}=rs}")#text(" for some coprime ")#mi("{r,s}")#text(" with")

#align(center)[#tao-fit-display[#mitex("y^{-1} S_0 \\ll s \\ll S_0")]]

#text("with ")#mi("{rs \\sim Q_{\\vec b}}")#text(". Thus we may write")

#align(center)[#tao-fit-display[#tao-math("S_{\\vec b} \\ll \\sum_{y^{-1} S_0 \\ll s \\ll S_0} \\sum_{0 < \\left|h\\right| \\leq H_{\\vec b}} \\tau_3(h) |\\sum_{r \\in {\\mathcal S}_I: (b h,rs)=(r,s)=1} \\tilde c^{\\prime}_{brs} \\sum_{m: (brs,m)=1} \\alpha(m)", block: true)]]

#align(center)[#tao-fit-display[#mitex("K_3( a_{\\vec b,rs} h \\overline{m}; rs )|")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("H_{\\vec b} := \\frac{x^{3\\epsilon} H}{b_1 b_2 b_3}.")]]

#text("From crude estimates we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{y^{-1} S_0 \\ll s \\ll S_0} \\sum_{0 < \\left|h\\right| \\leq H_{\\vec b}} \\frac{\\tau_3(h)^2}{s} \\lessapprox H_{\\vec b}", block: true)]]

#text("so from the Cauchy-Schwarz inequality we have ")#metadata(none) <tao-47dfae9288abf3d5d225>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("S_{\\vec b} \\lessapprox H_{\\vec b}^{1/2} (S^{\\prime}_{\\vec b})^{1/2}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b} = \\sum_{y^{-1} S_0 \\ll s \\ll S_0} \\sum_h \\Psi(h) s |\\sum_{r\\in {\\mathcal S}_I: (b h,rs)=(r,s)=1} \\tilde c^{\\prime}_{brs}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m: (brs,m)=1} \\alpha(m) K_3( a_{\\vec b,rs} h \\overline{m}; rs )|^2")]]

#text("and ")#mi("{\\Psi = \\Psi_{\\vec b}}")#text(" is a smooth cutoff function supported on the interval ")#mi("{[-2H_{\\vec b},2H_{\\vec b}]}")#text(" which equals one on ")#mi("{[-H_{\\vec b},H_{\\vec b}]}")#text(".")

#text("Now we estimate ")#mi("{S^{\\prime}_{\\vec b}}")#text(". We can expand this expression as")

#align(center)[#tao-fit-display[#mitex("\\sum_{r_1,r_2 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\sim r_2 \\ll yQ_{\\vec b}/S_0} \\sum_{s \\sim Q_{\\vec b}/r_1: (r_1r_2,s)=1 = (r_1r_2 s, b)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,m_2: (br_1s,m_1)=(br_2s,m_2)=1} \\tilde c^{\\prime}_{br_1s} \\overline{\\tilde c^{\\prime}_{br_2 s}}")]]

#align(center)[#tao-fit-display[#mitex("s \\alpha(m_1) \\overline{\\alpha(m_2)}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{h: (r_1r_2 s,h)=1} \\Psi(h) K_3( a_{\\vec b,r_1s} h \\overline{m_1}; r_1s ) \\overline{K_3( a_{\\vec b,r_2s} h \\overline{m_2}; r_2s )}.")]]

#text("We first dispose of the diagonal case ")#mi("{m_1 r_1^3 - m_2 r_2^3 = 0}")#text(". Here we use the Deligne bound ")#tao-math("{\\left|K_3\\right| \\lessapprox 1}", block: false)#text(" to bound this case in magnitude by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox \\sum_{r_1,r_2 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\sim r_2 \\ll yQ_{\\vec b}/S_0} \\sum_{s \\sim Q_{\\vec b}/r_1} \\sum_{m_1,m_2: m_1 r_1^3 = m_2 r_2^3} s H_{\\vec b}.")]]

#text("By the divisor bound, for each ")#mi("{r_1,m_1}")#text(" there are ")#mi("{\\lessapprox 1}")#text(" choices for ")#mi("{m_2,r_2}")#text(", so this expression is")

#align(center)[#tao-fit-display[#mitex("\\lessapprox \\sum_{r_1 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\ll yQ_{\\vec b}/S_0} M (Q_{\\vec b}/r_1)^2 H_{\\vec b}")]]

#text("which sums to ")#mi("{\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b}}")#text(".")

#text("Applying Lemma ")#link(<tao-7f4e1a13f6e91c1a2831>)[#text("13")]#text(" for the off-diagonal case ")#mi("{m_1 r_1^3 - m_2 r_2^3 \\neq 0}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + \\sum_{r_1,r_2 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\sim r_2 \\ll yQ_{\\vec b}/S_0} \\sum_{s \\sim Q_{\\vec b}/r_1: (r_1r_2,s)=(r_1r_2s,b)=1} \\sum_{m_1,m_2 \\sim M: m_1 r_1^3 - m_2 r_2^3 \\neq 0} s")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{[r_1,r_2] s} + 1) d^{1/2} s^{1/2} [r_1,r_2]^{1/2} (r_1,r_2,m_2-m_1)^{1/2}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("d  & := (a_{\\vec b,r_2s} \\overline{m_2} r_1^3 - a_{\\vec b,r_1s} \\overline{m_1} r_2^3, s )", block: true)



#tao-math(" & = (m_1 r_1^3 - m_2 r_2^3, s ).", block: true)
]

#text("Using the bound ")#mi("{s \\sim Q_{\\vec b}/r_1}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + \\sum_{r_1,r_2 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\sim r_2 \\ll yQ_{\\vec b}/S_0; m_1r_1^3-m_2r_2^3 \\neq 0} \\sum_{s \\sim Q_{\\vec b}/r_1} \\sum_{m_1,m_2 \\sim M}")]]

#align(center)[#tao-fit-display[#mitex("(Q_{\\vec b}/r_1) (\\frac{ H_{\\vec b}}{[r_1,r_2]^{1/2} (Q_{\\vec b}/r_1)^{1/2}} + [r_1,r_2]^{1/2} (Q_{\\vec b}/r_1)^{1/2})")]]

#align(center)[#tao-fit-display[#mitex("(m_1r_1^3 -m_2r_2^3, s)^{1/2} (r_1,r_2,m_2-m_1)^{1/2}.")]]

#text("By Lemma 5 from ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{s \\sim Q_{\\vec b}/r_1} (m_1r_1^3 -m_2r_2^3, s) \\lessapprox Q_{\\vec b}/r_1")]]

#text("and hence also")

#align(center)[#tao-fit-display[#mitex("\\sum_{s \\sim Q_{\\vec b}/r_1} (m_1r_1^3 -m_2r_2^3, s)^{1/2} \\lessapprox Q_{\\vec b}/r_1")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + \\sum_{r_1,r_2 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\sim r_2 \\ll yQ_{\\vec b}/S_0} \\sum_{m_1,m_2 \\sim M} (Q_{\\vec b}/r_1)^2")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{[r_1,r_2]^{1/2} (Q_{\\vec b}/r_1)^{1/2}} + [r_1,r_2]^{1/2} (Q_{\\vec b}/r_1)^{1/2}) (r_1,r_2,m_2-m_1)^{1/2}.")]]

#text("Similarly, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,m_2 \\sim M: d | m_2-m_1} d^{1/2} \\lessapprox \\frac{M^2}{d^{1/2}} + M d^{1/2}")]]

#text("for all ")#mi("{d}")#text(", so on summing over all ")#mi("{d|(r_1,r_2)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,m_2 \\sim M} (r_1,r_2,m_2-m_1)^{1/2} \\lessapprox M^2 + M (r_1,r_2)^{1/2}.")]]

#text("We thus have")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + \\sum_{r_1,r_2 \\in {\\mathcal S}_I: Q_{\\vec b}/S_0 \\ll r_1 \\sim r_2 \\ll yQ_{\\vec b}/S_0} (Q_{\\vec b}/r_1)^2")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{[r_1,r_2]^{1/2} (Q_{\\vec b}/r_1)^{1/2}} + [r_1,r_2]^{1/2} (Q_{\\vec b}/r_1)^{1/2}) (M^2 + M (r_1,r_2)^{1/2}).")]]

#text("Writing ")#mi("{r_0 := (r_1,r_2)}")#text(", ")#mi("{r_1 = r_0 r^{\\prime}_1}")#text(" and ")#mi("{r_2 = r_0 r^{\\prime}_2}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0Q_{\\vec b} H_{\\vec b} + \\sum_{r_0 \\ll yQ_{\\vec b}/S_0} \\sum_{r^{\\prime}_1,r^{\\prime}_2 \\in {\\mathcal S}_I: \\frac{Q_{\\vec b}}{S_0 r_0} \\ll r^{\\prime}_1 \\sim r^{\\prime}_2 \\ll \\frac{yQ_{\\vec b}}{S_0r_0}} (\\frac{Q_{\\vec b}}{r_0r^{\\prime}_1})^2")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{(Q_{\\vec b} r^{\\prime}_2)^{1/2}} + (Q_{\\vec b} r^{\\prime}_2)^{1/2}) (M^2 + M r_0^{1/2}).")]]

#text("Performing the ")#mi("{r^{\\prime}_2}")#text(" summation, this becomes")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + \\sum_{r_0 \\ll yQ_{\\vec b}/S_0} \\sum_{r^{\\prime}_1 \\in {\\mathcal S}_I: \\frac{Q_{\\vec b}}{S_0 r_0} \\ll r^{\\prime}_1 \\ll \\frac{yQ_{\\vec b}}{S_0r_0}} (\\frac{Q_{\\vec b}}{r_0})^2")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{Q_{\\vec b}^{1/2}} (r^{\\prime}_1)^{-3/2} + Q_{\\vec b}^{1/2} (r^{\\prime}_1)^{-1/2}) (M^2 + M r_0^{1/2})")]]

#text("and then performing the ")#mi("{r^{\\prime}_1}")#text(" summation we obtain")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + \\sum_{r_0 \\ll yQ_{\\vec b}/S_0} (\\frac{Q_{\\vec b}}{r_0})^2")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{Q_{\\vec b}^{1/2}} (\\frac{Q_{\\vec b}}{S_0 r_0})^{-1/2} + Q_{\\vec b}^{1/2} (\\frac{yQ_{\\vec b}}{S_0 r_0})^{1/2}) (M^2 + M r_0^{1/2}).")]]

#text("The net power of ")#mi("{r_0}")#text(" here is always at most ")#mi("{-1}")#text(", so the ")#mi("{r_0=1}")#text(" term in the summation dominates:")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b}\\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + Q_{\\vec b}^2")]]

#align(center)[#tao-fit-display[#mitex("(\\frac{ H_{\\vec b}}{Q_{\\vec b}^{1/2}} (\\frac{Q_{\\vec b}}{S_0})^{-1/2} + Q_{\\vec b}^{1/2} (\\frac{yQ_{\\vec b}}{S_0})^{1/2}) M^2.")]]

#text("We simplify this as ")#metadata(none) <tao-35f6619c2e9ae9b0e0e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("S^{\\prime}_{\\vec b} \\lessapprox M S_0 Q_{\\vec b} H_{\\vec b} + M^2 H_{\\vec b} Q_{\\vec b} S_0^{1/2} + y^{1/2} M^2 Q_{\\vec b}^3 S_0^{-1/2}.")]]

#text("To optimise this in ")#mi("{S_0}")#text(", we select")

#align(center)[#tao-fit-display[#mitex("S_0 := \\min( Q_{\\vec b}^{4/3} M^{2/3} H_{\\vec b}^{-2/3} y^{1/3}, yQ_{\\vec b} ).")]]

#text("(The quantity ")#mi("{Q_{\\vec b}^{4/3} M^{2/3} H_{\\vec b}^{-2/3} y^{1/3}}")#text(" comes from equating ")#mi("{MS_0 Q_{\\vec b} H_{\\vec b}}")#text(" and ")#mi("{y^{1/2} M^2 Q_{\\vec b}^3 S_0^{-1/2}}")#text(".) By construction, we have the second inequality in ")#link(<tao-8e35c2cd3bf6641bdb0e>)[#text("(40)")]#text(". We also claim the first inequality, since this is equivalent to")

#align(center)[#tao-fit-display[#mitex("H_{\\vec b} \\leq Q_{\\vec b}^2 M y^{1/2}")]]

#text("which would follow if")

#align(center)[#tao-fit-display[#mitex("b^{1/2} Q \\frac{b}{b_1 b_2 b_3} \\leq x^{1+\\delta/2-4\\epsilon}.")]]

#text("But from ")#link(<tao-ec9ff5791bbccd47c022>)[#text("(41)")]#text(" one has ")#mi("{b^{1/2} \\ll Q^{1/2}}")#text(" and ")#mi("{\\frac{b}{b_1 b_2 b_3} \\leq 1}")#text(", and the claim now follows from ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(36)")]#text(" and ")#link(<tao-bedae6ae5c6856f323db>)[#text("(13)")]#text(".")

#text("Inserting this value of ")#mi("{S_0}")#text(" (using ")#mi("{S_0 \\leq Q_{\\vec b}^{4/3} M^{2/3} H_{\\vec b}^{-2/3} y^{1/3}}")#text(" for the first two terms in ")#link(<tao-35f6619c2e9ae9b0e0e9>)[#text("(43)")]#text("), we conclude that")

#align(center)[#tao-fit-display[#mitex("S^{\\prime}_{\\vec b} \\lessapprox M^{5/3} Q_{\\vec b}^{7/3} H_{\\vec b}^{1/3} y^{1/3} + M^{7/3} H_{\\vec b}^{2/3} Q_{\\vec b}^{5/3} y^{1/6} + M^2 Q_{\\vec b}^{5/2}.")]]

#text("One should view the first term here as the main term. By ")#link(<tao-47dfae9288abf3d5d225>)[#text("(42)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("S_{\\vec b} \\lessapprox M^{5/6} Q_{\\vec b}^{7/6} H_{\\vec b}^{2/3} y^{1/6} + M^{7/6} H_{\\vec b}^{5/6} Q_{\\vec b}^{5/6} y^{1/12} + M H_{\\vec b}^{1/2} Q_{\\vec b}^{5/4}.")]]

#text("Since ")#mi("{H_{\\vec b} = x^{3\\epsilon} H (b_1 b_2 b_3)^{-1} \\leq x^{3\\epsilon} H b^{-1}}")#text(", ")#mi("{Q_{\\vec b} = Q b^{-1}}")#text(", and ")#mi("{y = x^\\delta b}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("S_{\\vec b} \\lessapprox x^{5\\epsilon/2} b^{-1} (b_1 b_2 b_3)^{-1/2} ( M^{5/6} Q^{7/6} H^{2/3} x^{\\delta/6} + M^{7/6} H^{5/6} Q^{5/6} x^{\\delta/12} + M H^{1/2} Q^{5/4} ).")]]

#text("From Euler products we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\vec b} \\frac{\\text{rad}(b_1) \\text{rad}(b_2) \\text{rad}(b_3)}{b^2} b^{-1} (b_1 b_2 b_3)^{-1/2} \\ll 1")]]

#text("and so to prove ")#link(<tao-0ebb429fa86d481c2630>)[#text("(39)")]#text(" it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("M^{5/6} Q^{7/6} H^{2/3} x^{\\delta/6} + M^{7/6} H^{5/6} Q^{5/6} x^{\\delta/12} + M H^{1/2} Q^{5/4} \\lessapprox x^{-5\\epsilon} M Q^2.")]]

#text("We can rewrite these conditions as upper bounds on ")#mi("{H}")#text(":")

#align(center)[#tao-fit-display[#mitex("H \\lessapprox x^{-\\delta/4 - 15 \\epsilon/2} M^{1/4} Q^{5/4}")]]

#align(center)[#tao-fit-display[#mitex("H \\lessapprox x^{-\\delta/10 - 6 \\epsilon} M^{-1/5} Q^{7/5}")]]

#align(center)[#tao-fit-display[#mitex("H \\lessapprox x^{-10\\epsilon} Q^{3/2}.")]]

#text("As ")#mi("{H = Q^3 / N}")#text(" and ")#mi("{MN \\sim x}")#text(", we can rewrite these conditions as upper bounds on ")#mi("{Q}")#text(":")

#align(center)[#tao-fit-display[#mitex("Q^{7/4} \\lessapprox x^{1/4-\\delta/4 - 15 \\epsilon/2} N^{3/4}")]]

#align(center)[#tao-fit-display[#mitex("Q^{8/5} \\lessapprox x^{-1/5-\\delta/10 - 6 \\epsilon} N^{6/5}")]]

#align(center)[#tao-fit-display[#mitex("Q^{3/2} \\lessapprox x^{-10\\epsilon} N.")]]

#text("Since ")#mi("{N \\gtrapprox x^{\\frac{3}{2} (\\frac{1}{2}+\\sigma)}}")#text(" and ")#mi("{Q \\lessapprox x^{1/2+2\\varpi}}")#text(", these conditions become")

#tao-aligned(keep: true)[


#tao-math("\\frac{7}{4} (\\frac{1}{2}+2\\varpi)  & < \\frac{1}{4} - \\frac{\\delta}{4} + \\frac{3}{4} \\frac{3}{2} (\\frac{1}{2} + \\sigma)", block: true)



#tao-math("\\frac{8}{5} (\\frac{1}{2}+2\\varpi)  & < -\\frac{1}{5} - \\frac{\\delta}{10} + \\frac{6}{5} \\frac{3}{2} (\\frac{1}{2} + \\sigma)", block: true)



#tao-math("\\frac{3}{2} (\\frac{1}{2}+2\\varpi)  & < \\frac{3}{2} (\\frac{1}{2} + \\sigma)", block: true)
]

#text("which we may rearrange as")

#tao-aligned(keep: true)[


#tao-math("\\sigma  & > \\frac{1}{18} + \\frac{28}{9} \\varpi + \\frac{2}{9} \\delta", block: true)



#tao-math("\\sigma  & > \\frac{1}{18} + \\frac{16}{9} \\varpi + \\frac{1}{18} \\delta", block: true)



#tao-math("\\sigma  & > 2 \\varpi", block: true)
]

#text("but these follow from ")#link(<tao-06efe37f5e983469e860>)[#text("(12)")]#text(". The proof of Theorem ")#link(<tao-27b250d25accb10de21a>)[#text("6")]#text(" is complete.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (94)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237799")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("(empty comment to subscribe to email updates)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237802")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Probably-clueless question here, motivated purely by aesthetics:")

#text("Clearly 2 is a gratuitously specific number :-). What happens if we replace the notion of “doubly dense divisibility” by, let’s call it, “hereditarily dense divisibility”: x is y-HDD iff either x=1 or in every interval [R/y,R] with 1 <= R <= x there is a factor of x that's also y-HDD. It seems like this is stronger than DDD but weaker than y-smoothness (but maybe intuition is deceptive here?).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("I think this property is equivalent to y-smoothness, since by setting R slightly less than x we see that every y-HDD number is the product of a number in (1,y] and another number which is y-HDD, and hence by induction is y-smooth. So we have a fairly continuous hierarchy of properties, from y-dense divisibility (the weakest), to double y-dense divisibility, to triple y-dense divisibility, …, all the way to hereditary y-dense divisibility or equivalently y-smoothness (the strongest property).")

#text("The sieving step can purchase us double y-dense divisibility for almost the same price as y-dense divisibility, but presumably the price keeps rising as we ask for more and more divisibility. For instance, with our current best values of ")#mi("\\varpi,\\delta")#text(" we can purchase double dense divsibility at ")#mi("k_0=720")#text(" (and single dense divisibility at more or less the same level), whereas smoothness requires ")#mi("k_0")#text(" to be 873 or so.")

#text("There is a chance that we will need triple or higher dense divisibility if we start iterating the van der Corput process more often than we are doing now, but thus far this seems to have been counterproductive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237805")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Is inequality (12) reversed? Otherwise large values of ")#mi("\\sigma")#text(" wouldn’t violate it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("No, I think the inequalities are the right way for the Type III estimates. The parameter ")#mi("\\sigma")#text(" demarcates the border between Type I and Type III; if one increases ")#mi("\\sigma")#text(", then we dump more cases into Type I (which then becomes harder to prove) but take more cases out of Type III (which becomes easier to prove). So the necessary conditions for Type I involve upper bounds on ")#mi("\\sigma")#text(" while the necessary conditions for Type III involve lower bounds, which have to be balanced against each other (and with the combinatorial condition ")#mi("\\sigma > 1/10")#text(") to get the final range of ")#mi("\\varpi,\\delta")#text(". (Actually, with our current technology, the combinatorial constraint is giving a stronger lower bound than the Type III estimates, so it is not currently a critical priority to try to improve the Type III estimates further.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237830")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Let ")#mi("P_2(x, H)")#text(" denotes the number of consecutive prime pairs")#linebreak()#text(" ")#mi("(p, p^{\\prime})")#text(" satisfying ")#mi("p > 1")#text(". Since it is known that")#linebreak()#text(" ")#mi("P_2(x, 2) = O(x/ \\log ^2 x)")#text(", the next (natural) step is to give an explicit lower bound on the growth of ")#mi("P_2(x, H)")#text(" for some ")#mi("H")#text(", where ")#mi("P_2(x,H)")#text(" is the number of consecutive prime pairs ")#mi("(p,p^{\\prime})")#text(" satisfying ")#mi("p < p^{\\prime} \\leq p+H \\leq x")#text(".")

#text("(even. ")#mi("P_2(x, H) >> \\log x")#text(" should be a great advance!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237834")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("In terms of ")#mi("P_2(x, H)")#text(" as defined above, Zhang’s theorem is equivalent to ")#mi("P_2(x, H) >>1")#text(" for some ")#mi("H")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237842")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("I haven’t followed all the details, but isn’t the argument producing an H such that, for all x large enough, there is a pair of primes at distance at most H in the interval [x,2x]? That directly gives the bound ")#mi("P_2(x,H) \\gg \\log x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237845")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("You are right of course! (it is interesting that even Bertrand’s postulate shows that Zhang’s theorem implies this seemingly stronger result.)")#linebreak()#text(" So perhaps the next step is to find a lower bound on the growth of P_2(x, H) as implied by the best known upper bound on the gap between consecutive primes.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Dear Eytan,")

#text("You might be interested in this recent paper of Pintz at ")#link("http://arxiv.org/abs/1305.6289")[#text("http://arxiv.org/abs/1305.6289")]#text(" which discusses what results of this type one can get as consequences of Zhang’s theorem (or variants thereof). In particular, I think the bound of ")#mi("P_2(x,H) \\gg x /\\log^{k_0} x")#text(" can be obtained from the sieve-theoretic arguments. The arguments of Goldston, Pintz, and Yildirim at ")#link("http://arxiv.org/abs/1103.5886")[#text("http://arxiv.org/abs/1103.5886")]#text(" should in principle be able to improve this, though I don’t know if we can get the optimal ")#mi("P_2(x,H) \\gg x / \\log^2 x")#text(" this way. This question is a little outside of the direct scope of the Polymath8 project, but perhaps someone will look into it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237879")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Dear Terence, Thanks for the information ! (It seems that the conjecture that ")#mi("p^{\\prime} = p + O(\\log ^2 p)")#text(" is sufficient to get ")#mi("P_2(x, H) >>x/ \\log^2 x")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237887")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("@Eytan: Why would ")#mi("p^{\\prime} = p + O(\\log ^2 p)")#text(" imply ")#mi("P_2(x, H) \\gg x/ \\log^2 x)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237893")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Assuming the conjecture ")#mi("p_{n+1}  \\le p_n + C \\log^2 p_n)")#text(" for some absolute constant ")#mi("C")#text(" for each prime ")#mi("p_n")#text(". My idea was to define the sequence ")#mi("x_n, n \\ge 1")#text(" by ")#mi("x_{n+1} = x_n + 3 C \\log ^2 x_n")#text(", starting with sufficiently large ")#mi("x_1")#text(" so each interval ")#mi("(x_n, x_{n+1})")#text(" contains a pair of consecutive primes, and the number of such intervals below")#linebreak()#text(" ")#mi("x")#text(" is ")#mi(">> x/ \\log ^2 x")#text(", but (thanks to Gergely question) I realized that the problem is that for each fixed H, the number of H-bounded prime gaps can grow arbitrarily slower than the number of such intervals below ")#mi("x")#text(".")#linebreak()#text(" So it is not clear now how to get any explicit lower bound on the growth of")#linebreak()#text(" ")#mi("P_2(x, H)")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237874")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("In my previous comment (8 July, 4:57 am), the definition of ")#mi("P_2(x, H)")#text(" should be the number of consecutive prime pairs ")#mi("(p, p^{\\prime})")#text(" satisfying")#linebreak()#text(" ")#mi("p < p^{\\prime} \\le  p + H \\le x")#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M Flax")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237837")[#strong[#text("M Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("In the first formula of definition (2), should log(x) be log(n)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237890")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("No. By convention, ")#mi("\\alpha")#text(" is implicitly a function of ")#mi("x")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237861")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Since the current boundary is the the combinatorial bound ")#mi("\\sigma\\geq 1/10")#text(", it makes sense to see what happens if we replace the approximation ")#mi("N\\approx x^{\\frac{3}{2}(\\frac{1}{2}+\\sigma)}")#text(" in the Type III computations with the weaker ")#mi("N\\approx x^{6\\sigma}")#text(", which avoids the combinatorial obstacles. If we do, the three lower bounds on ")#mi("\\sigma")#text(" that we obtain are")

#mi("\\frac{5}{36}+\\frac{7}{9}\\varpi + \\frac{1}{18}\\delta<\\sigma")

#text("and")

#mi("\\frac{1}{12}+\\frac{4}{9}\\varpi + \\frac{1}{72}\\delta<\\sigma")

#text("and")

#mi("\\frac{1}{8}+\\frac{1}{2}\\varpi <\\sigma")#text(".")

#text("It appears that there is room to rebalance these inequalities, but only the second one currently surpasses the ")#mi("\\sigma\\geq 1/10")#text(" obstacle.")

#text("It would also be interesting to rework the Type III computations but instead of working with three smooth functions use only one or two (with, respectively, ")#mi("N\\approx x^{2\\sigma}, N\\approx x^{4\\sigma}")#text("). We would then need to bound formulas involving ")#mi("K_1,K_2")#text(" instead of ")#mi("K_3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237900")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("The pages “Dickson -Hardy-Littlewood theorems” and “Distribution of primes in smooth moduli” should be updated according to this post.")

#emph[#text("[Done, thanks for the suggestion – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237984")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("More corrections:")

#text("1. In the page “Dickson-Hardy-Littlewood theorems”, in the last title MPZ should be replaced by MPZ”.")#linebreak()#text(" Also (to ensure that ")#mi("\\tilde{\\theta} \\le 1")#text("), ")#mi("\\tilde{\\theta}")#text(" in the last section should be defined (as already suggested by Gergely Harcos) as the minimum between its current expression and 1.")

#text("2. In the page “Distribution of primes in smooth moduli”, in the second line MPZ” should also be mentioned. Also the definition of MPZ” should also be added as well as the definitions of ")#mi("D_y")#text(" and ")#mi("D_y ^2")#text(" .")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237997")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Let me clarify. Regarding Theorem 5 and its later variant of the earlier thread (")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")]#text(") I suggested that there was no need to redefine ")#mi("\\tilde\\theta")#text(", because ")#mi("G_{k_0-1,\\tilde \\theta}=G_{k_0-1,\\min(\\tilde \\theta,1)}")#text(". The wiki page (")#link("http://michaelnielsen.org/polymath1/index.php?title=Dickson-Hardy-Littlewood_theorems")[#text("http://michaelnielsen.org/polymath1/index.php?title=Dickson-Hardy-Littlewood_theorems")]#text(") is a slightly different issue, because the Maple code there contains an upper bound for ")#mi("G_{k_0-1,\\tilde \\theta}(0,0)")#text(" rather than its actual value. On the other hand, this upper bound is increasing in ")#mi("\\tilde\\theta")#text(" (it is the antiderivative of a nonnegative function), hence if ")#mi("\\kappa_3")#text(" is admissible for some ")#mi("\\tilde\\theta>1")#text(", then it is admissible for the redefined ")#mi("\\tilde\\theta:=1")#text(" as well. This means that the Maple code worked fine in its original form (i.e. without taking the minimum of ")#mi("\\tilde\\theta")#text(" and ")#mi("1")#text("), but of course it is more efficient in its current updated form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238004")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Thank you! (now I understand it better.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237938")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("I believe that ")#mi("16\\delta")#text(" in the Type I estimate bounds should be ")#mi("32\\delta")#text(".")

#emph[#text("[Sorry about this, actually the ")#mi("16\\delta")#text(" is I think correct, but in the display deriving it at the bottom of Section 2, I had an ")#mi("8\\delta")#text(" where there should have been a ")#mi("4\\delta")#text(" instead, which I’ve now corrected. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9416663b651b778717651979274d12d1690c666bbbf176ec2a3880a1ebe29a6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Hilferty")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237949")[#strong[#text("James Hilferty")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2013")])]

#text("Is all this not a little fruitless and over complicated? I have a far simpler sum, namely the Black-Scholes formula. No one has actually disproved it and for a theorem which never worked at anytime just look at all the damage it caused to the financial system. I was just recently looking at JP Morgan’s “Var” formula and they admit that there is no accurate method at predicting the price “volatility” of a future’s option and you all are trying to do something similar with your new (?) probability theorem. What do you all think?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("I admire your imagination but deplore your ignorance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("As usual, I am recording the critical numerology, i.e. the endpoint case that we currently can’t treat with our methods. Setting ")#mi("\\delta=0")#text(" for simplicity, this is ")#mi("\\varpi = 3/280")#text(" and ")#mi("\\sigma = 1/10")#text(". In the Heath-Brown decomposition, the enemy here is either a “Type IV” expression of the form ")#mi("\\psi_1 * \\psi_2 * \\psi_3 * \\psi_4")#text(" where ")#mi("\\psi_1,\\psi_2,\\psi_3")#text(" are smooth and supported at scale ")#mi("x^{1/5}")#text(" and ")#mi("\\psi_4")#text(" is smooth and supported at scale ")#mi("x^{2/5}")#text(", or a “Type V” sum of the form ")#mi("\\psi_1 * \\psi_2 * \\psi_3 * \\psi_4 * \\psi_5")#text(" where all of the ")#mi("\\psi_i")#text(" are smooth and supported at scale ")#mi("n^{1/5}")#text(". While it looks like the Type IV sum is treatable from the Type I method by exploiting the additional smoothness of ")#mi("\\beta")#text(" in this case, it does not seem that this is available for the Type V sum, which is also far from being treatable by Type III methods.")

#text("If we attack the Type V sum by Type I methods, we factor it as ")#mi("\\alpha *\\beta")#text(" where ")#mi("\\alpha = \\psi_1 * \\psi_2 * \\psi_3")#text(" is supported at scale ")#mi("M = x^{3/5}")#text(", and ")#mi("\\beta = \\psi_4 * \\psi_5")#text(" is supported at scale ")#mi("N = x^{2/5}")#text(". The modulus ")#mi("d")#text(" has magnitude ")#mi("d \\sim x^{1/2+2\\varpi}")#text(" and is factored as ")#mi("d = qr")#text(", where ")#mi("r \\sim R = N = x^{2/5}")#text(" (ignoring epsilons) and so ")#mi("q \\sim Q = x^{1/10 + 2\\varpi}")#text(". After various Cauchy-Schwarz type manipulations, our task is then to show that")

#tao-math("\\left|\\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} \\sum_n \\beta(n) \\beta(n+kr) \\Phi_{k,r}(h,q_1,q_2;n)\\right| \\lessapprox x^{-\\varepsilon} Q^2 N", block: false)

#text("where ")#mi("H \\approx Q^2 R/M = x^{4\\varpi}")#text(", and we may take ")#mi("q_1,q_2")#text(" to be coprime as the dominant case (so ")#mi("q_0=1")#text("). Thus we need to gain about ")#mi("H \\approx x^{4\\varpi}")#text(" over the trivial bound. There is also some additional averaging in the k and r parameters (the k averaging is over a negligible range, but r ranges over scales ")#mi("r \\sim R = x^{2/5}")#text(" and is potentially useful) but we currently do not know how to exploit this extra averaging. The phase ")#mi("\\Phi_{k,r}")#text(" is periodic with period ")#mi("r q_1 q_2 \\approx x^{3/5 + 4\\varpi}")#text(".")

#text("The way we are currently treating the Type I sum, we are factoring ")#mi("q_1 = s_1 t_1")#text(" with ")#mi("t_1 \\approx T \\approx H \\approx x^{4\\varpi}")#text(" and ")#mi("s_1 \\approx S \\approx Q/H \\approx x^{1/10 - 2\\varpi}")#text(". After Cauchy-Schwarz, we are reduced to showing that")

#mi("\\sum_{1 \\leq h,\\tilde h \\leq H; t_1,\\tilde t_1 \\sim T; s_1 \\sim S; q_2 \\sim Q}")

#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi(h, s_1 t_1,  q_2; n) \\overline{ \\Phi(\\tilde h, s_1 \\tilde t_1, q_2; n) } \\right|", block: false)

#mi("\\lessapprox x^{-\\varepsilon} TSQN,")

#text("thus we need to save a factor of ")#mi("H^{-2} = x^{-8\\varpi}")#text(" over the trivial bound. Thus, on average, we need to obtain an exponential sum estimate of the form")

#tao-math("\\left|\\sum_n \\psi_N(n) \\Psi_q(n)\\right| \\lessapprox x^{-8\\varpi-\\varepsilon} N", block: false)

#text("where ")#mi("\\Psi_q")#text(" is an explicit but slightly messy phase of period ")#mi("q = r s_1 t_1 \\tilde t_1 q_2 \\approx x^{3/5+8\\varpi}")#text(". With the particular choice of ")#mi("\\varpi = 3/280")#text(", we have ")#mi("N \\sim q^{7/12}")#text(" and ")#mi("x^{8 \\varpi} \\sim q^{1/8}")#text(", so our objective is to prove something like")

#tao-math("\\left|\\sum_{n \\sim q^{7/12}} \\Psi_q(n)\\right| \\lessapprox q^{11/24 - \\varepsilon}", block: false)

#text("for an “average” phase ")#mi("\\Psi_q")#text(" of period ")#mi("q")#text(" (as a zeroth approximation, think of the model case ")#mi("\\Psi_q(n) = e_q(c/n)")#text(" where ")#mi("c")#text(" ranges over a shortish interval, say of length ")#mi("x^{8\\varpi} \\approx q^{1/8}")#text("). This is currently being treated by the van der Corput estimate, which roughly has the shape")

#tao-math("\\left|\\sum_{n \\sim N} \\Psi_q(n)\\right| \\lessapprox N^{1/2} q^{1/6}", block: false)#text(" (*)")

#text("which doesn’t save the epsilon, and is ultimately why we just barely fail to make ")#mi("\\varpi")#text(" reach ")#mi("3/280")#text(". So the basic challenge is to do better than (*) when ")#mi("N \\sim q^{7/12}")#text(", possibly after exploiting the additional averaging in the ")#mi("k, r, h, \\tilde h, t_1, \\tilde t_1, s_1, q_2")#text(" parameters that are available. But these parameters are hard to exploit: the k averaging is negligible, the ")#mi("r,t_1,s_1,q_2")#text(" averages are substantial but affect the modulus which is bad, leaving only the ")#mi("h,\\tilde h")#text(" averaging which looks promising but is only over a fairly short range. A model problem would be to obtain a bound of the form")

#tao-math("\\left|\\sum_{c \\sim q^{1/8}} \\sum_{n \\sim q^{7/12}} e_q( c/n )\\right| \\lessapprox q^{7/12 - \\varepsilon}", block: false)

#text("for a “typical” sufficiently smooth modulus ")#mi("q")#text(", whatever “typical” means. (Here we are implicitly using smooth cutoffs where necessary, and adopting the convention that ")#mi("e_q(c/n)")#text(" vanishes when ")#mi("n")#text(" is not coprime to ")#mi("q")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("By chance I happened to attend a nice talk by Igor Shparlinski while at Budapest in which he gave a nice summary of the start of the art on how to estimate multidimensional incomplete exponential sums (though he focused primarily on the prime modulus case rather than the smooth modulus case). In addition to the standard technique of completion of sums, he also mentioned Vinogradov-type techniques (which are traditionally used to estimate exponential sums over the integers, e.g. for Waring’s problem or in bounding the zeta function, but can also give non-trivial results in finite fields), as well as the sum-product methods of Bourgain and co-authors (but this requires a lot of multiplicative structure), and also the Burgess type arguments (again this requires some sort of multiplicativity in the phase though).")

#text("Another route is to develop the q-van der Corput theory more fully, basically replicating the theory of exponent pairs in the q-setting. There are some exponent pairs that are known that are not obtainable from the standard A- and B- processes (e.g. the work of Huxley and Watt). These may end up being a bit complicated to execute though (if we do too many fancy manipulations, the dependence on ")#mi("\\delta")#text(" is eventually going to hurt us; also, the Deligne-type exponential sum we will need to control at the end gets more and more complicated, though perhaps there is only a finite amount of algebraic geometry verification to be done for each specific application of this machinery).")

#text("One route that looks moderately promising to me is to try to combine the van der Corput A-process that we are currently using with the additional averaging in auxiliary parameters such as ")#mi("h,h^{\\prime}")#text(" that we are currently unable to exploit (I called this a “Level 5” Type I estimate on the wiki). This should attenuate the diagonal contribution which should allow for some rebalancing of parameters that takes some of the load off of the off-diagonal contribution. (This trick already was used to good effect on the Type III sums.) I’ve tried to do this a few times in the last few days, but the problem has always been that the parameters being averaged over are over a shorter range than the difference ")#mi("q_1")#text(" that one is Weyl differencing over so no additional gain could be extracted, but I did not exhaust all the possible permutations of this strategy.")

#text("ADDED LATER: I forgot to add automorphic forms techniques (or “Kloostermania”) as a possible further technique which can exploit averaging in the modulus although once one moves away from the model problem and starts considering more realistic sums such as ")#mi("\\sum_c \\sum_n e_q( a_q c / n )")#text(" where ")#mi("a_q")#text(" varies with ")#mi("q")#text(" in a manner consistent with the Chinese remainder theorem, my understanding is that these methods become significantly more difficult to deploy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238002")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Dear Terry,")

#text("Thank you for this analysis. I’ll try to absorb it more fully over the next week. In the meantime I did have a few questions (some perhaps easier to answer than others).")

#text("1. I’m a little weak on when it is allowable to use the Linnik decomposition rather than the Heath-Brown decomposition. Assuming that we can use the Linnik decomp., is there any extra information we gain that helps in these analyses? For instance, do we gain any insight into the scales involved in the coefficient sequences?")

#text("2. In your computations above, you take ")#mi("\\beta=\\psi_4\\ast \\psi_5")#text(". Another option would be to take ")#mi("\\beta=\\psi_5")#text(" and try to take advantage of the smoothness of ")#mi("\\beta")#text(". Does the smoothness (and thus avoidance of an extra Cauchy-Schwarz) make up for the smaller scale size? Or is this just a pipe dream?")

#text("3. Perhaps a better way to take advantage of the smoothness would instead be to modify the Type III computations from ")#mi("\\alpha\\ast \\psi_1\\ast \\psi_2\\ast \\psi_3")#text(" to ")#mi("\\alpha \\ast \\psi_1\\ast \\psi_2")#text(" or ")#mi("\\alpha \\ast \\psi_1")#text(" (with ")#mi("\\psi_i")#text(" of scale ")#mi("N_i\\sim x^{2\\sigma}")#text("). This would replace bounds on ")#mi("K_3")#text(" with needing bounds on ")#mi("K_2, K_1")#text(", which seem to be much more controllable. (Again, this might be a pipe dream.)")

#text("Best wishes,")#linebreak()#text(" Pace")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Dear Pace,")

#text("1. Morally speaking the Linnik decomposition should work in these arguments, but it has infinitely many terms and there is basically no hope of controlling sums involving the divisor function ")#mi("\\tau^{\\prime}_k")#text(" with a really good dependence on k. Note for instance that ")#mi("\\sum_{n \\leq x} \\tau^{\\prime}_k(n) \\mu(n)")#text(" is (conjecturally on the Mobius pseudorandomness conjecture) believed to be ")#mi("o(x)")#text(" for any fixed ")#mi("k")#text(" (with the decay rate being highly non-uniform in ")#mi("k")#text("), while ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\mu(n)")#text(" is certainly not ")#mi("o(x)")#text(", so one can’t hope to use Linnik to get good estimates for ")#mi("\\Lambda")#text(" from good estimates for ")#mi("\\tau^{\\prime}_k")#text(".")

#text("2. Let’s do a quick computation. If one halts the Type I argument before the final Cauchy-Schwarz, the objective in the critical case is to obtain an estimate roughly of the form")

#tao-math("\\left|\\sum_n \\beta(n) \\beta(n+kr) \\Phi_q(n)\\right| \\lessapprox x^{-\\varepsilon} H^{-1} N", block: false)

#text("for some phase ")#mi("\\Phi_q(n)")#text(" of period ")#mi("q = r q_1 q_2 \\approx x^{1/2+\\sigma+4\\varpi}")#text(", where ")#mi("H \\approx x^{4\\varpi}")#text(". If ")#mi("\\beta")#text(" is smooth, one can use the completion of sums bound")

#tao-math("\\left|\\sum_n \\beta(n) \\beta(n+kr) \\Phi_q(n)\\right| \\lessapprox q^{1/2}", block: false)

#text("which suggests the constraint")

#mi("\\frac{1}{2} (\\frac{1}{2} + \\sigma + 4 \\varpi) < - 4\\varpi + \\frac{1}{2} - \\sigma")

#text("which rearranges to")

#mi("6 \\sigma + 24 \\varpi < 1.")

#text("If we instead use the van der Corput bound")

#tao-math("\\left|\\sum_n \\beta(n) \\beta(n+kr) \\Phi_q(n)\\right| \\lessapprox N^{1/2} q^{1/6}", block: false)

#text("then we are led to the constraint")

#mi("\\frac{1}{2} (\\frac{1}{2}-\\sigma) + \\frac{1}{6} (\\frac{1}{2} + \\sigma + 4 \\varpi) < - 4\\varpi + \\frac{1}{2} - \\sigma")

#text("which becomes")

#mi("4 \\sigma + 28 \\varpi < 1.")

#text("This is a bit better than the current Type I constraint of ")#mi("4\\sigma + 56 \\varpi < 1")#text(", with ")#mi("\\varpi = 3/280")#text(", it allows us to take ")#mi("\\sigma")#text(" as large as ")#mi("7/40 = 0.175")#text(" when ")#mi("\\beta")#text(" is smooth, so we can basically handle any configuration ")#mi("(t_1,\\ldots,t_n)")#text(" of exponents with ")#mi("t_1 > 13/40 = 0.325")#text(". That’s not bad – it should dispose of most of the “Type IV” type sums we will encounter – but still quite far from dealing with the tuple ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" which would basically require stretching ")#mi("\\sigma")#text(" to be as large as ")#mi("3/10")#text(".")

#text("If we apply the next iteration of van der Corput, this gives")

#tao-math("\\left|\\sum_n \\beta(n) \\beta(n+kr) \\Phi_q(n)\\right| \\lessapprox N^{5/7} q^{1/14}", block: false)

#text("leading to the constraint")

#mi("\\frac{5}{7} (\\frac{1}{2}-\\sigma) + \\frac{1}{14} (\\frac{1}{2} + \\sigma + 4 \\varpi) < - 4\\varpi + \\frac{1}{2} - \\sigma")

#text("which rearranges as")

#mi("\\frac{10}{3} \\sigma + 40 \\varpi < 1")

#text("which, at ")#mi("\\varpi = 3/280")#text(", gets ")#mi("\\sigma")#text(" as large as ")#mi("6/35 = 0.171\\ldots")#text(", which is actually worse than what we got with just one van der Corput (which is consistent with the other times that we have tried iterated van der Corput, the gain in the ")#mi("\\sigma")#text(" aspect is generally outweighed by the loss in the ")#mi("\\varpi")#text(" aspect). So we’re not making much progress here towards stretching the Type I sums all the way to the ")#mi("\\sigma=3/10")#text(" case when ")#mi("\\beta")#text(" is smooth.")

#text("One last numerology check: if we assume the most optimistic exponential sum bound (the Hooley conjecture)")

#tao-math("\\left|\\sum_n \\beta(n) \\beta(n+kr) \\Phi_q(n)\\right| \\lessapprox N^{1/2},", block: false)

#text("one gets")

#mi("2\\sigma + 16 \\varpi < 1")

#text("which clears the bar with room to spare (")#mi("\\sigma")#text(" can now be as large as ")#mi("29/70 = 0.4143\\ldots")#text("). So there is hope, but it does require quite strong exponential sum estimates.")

#text("3. I haven’t given this a shot yet, but I’ll take a look at the suggestion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238154")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Dear Terry,")

#text("Thank you for working this out. It appears that I wasn’t conveying myself well, since my question #2 was about a lower bound on ")#mi("\\sigma")#text(", not upper bounds. However, your answer was still extremely helpful for me, and hopefully will help me explain my idea a bit better.")

#text("For simplicity I’m going to ignore all the ")#mi("\\delta")#text("‘s and ")#mi("\\epsilon")#text("‘s.")

#text("As you know, the combinatorial data gives a natural meeting place between the Type I/II and Type III sums, which can be thought of as given, respectively, by upper and lower bounds on ")#mi("\\sigma")#text(". The Type III sums arise from consideration of how many smooth sequences have scales somewhere in the range ")#mi("[x^{2\\sigma},x^{1/2-\\sigma}]")#text(". If there are too few (or too many) such sequences (and ")#mi("1/10 <\\sigma")#text("), then we can reduce to the Type I/II bounds. On the other hand, if there are exactly three sequences in this range, we can then either again reduce to the Type I/II bounds, or we have that the product of the three scales is at least ")#mi("x^{3/2(1/2+\\sigma)}")#text(" which we call the Type III case.")

#text("My idea is to forget about some of this information in exchange for weaker combinatorial restrictions. So, for example, when we are in the Type III situation I forget about the fact that there are three smooth sequences in the range ")#mi("[x^{2\\sigma},x^{1/2-\\sigma}]")#text(" for which the product of the scales is fairly large, and instead only retain the information that there is a single smooth sequence in the range. This is clearly going to lead to inequalities worse than the usual Type III bounds, but as the current restriction occurs between the Type I bounds and ")#mi("\\sigma=1/10")#text(", this might not be too bad.")

#text("So, now let's work through the numerology. We have ")#mi("N\\approx x^{2\\sigma}")#text(". Similarly, ")#mi("R\\approx N \\approx x^{2\\sigma}")#text(" since we are ignoring ")#mi("\\delta")#text(". We also have ")#mi("H\\approx Q^{2}R/M \\approx (QN)^{2}/x")#text(", where ")#mi("x^{1/2}\\lessapprox QN\\lessapprox x^{1/2+2\\varpi}")#text(". Finally, ")#mi("q=rq_1q_2\\approx (QN)^{2}/N")#text(". Now let's consider the four types of bounds from your post.")

#text("————**Completion of sums**—————")

#text("We need ")#mi("q^{1/2} \\lessapprox N/H")#text(". This leads to ")#mi("(QN)^{3} \\lessapprox xN^{3/2}")#text(". Hence")

#mi("\\frac{1}{6}+2\\varpi < \\sigma")#text(".")

#text("This, in conjunction with the given Type I bound, yields ")#mi("\\varpi < 1/192")#text(" which is worse than what we normally get.")

#text("————–**van der Corput once**—————-")

#text("We need ")#mi("N^{1/2}q^{1/6} \\lessapprox N/H")#text(". This leads to ")#mi("(QN)^{2+1/3} \\lessapprox xN^{1-1/2+1/6}")#text(". Hence")

#mi("\\frac{1}{8} + \\frac{3}{2}\\varpi < \\sigma")#text(".")

#text("This, in conjunction with the given Type I bound, yields ")#mi("\\varpi < 1/124")#text(".")

#text("—————–**van der Corput twice**—————-")

#text("We need ")#mi("N^{5/7}q^{1/14} \\lessapprox N/H")#text(". This leads to ")#mi("(QN)^{2+1/7} \\lessapprox xN^{1-5/7+1/14}")#text(". Hence")

#mi("\\frac{1}{10}+6\\varpi < \\sigma")#text(".")

#text("This, in conjunction with the given Type I bound, yields ")#mi("\\varpi < 3/400")#text(", which is worse than the single van der Corput.")

#text("Notice further that in all three cases we never surpass the ")#mi("1/10<\\sigma")#text(" bound.")

#text("—————-**Hooley Conjecture**———————")

#text("We need ")#mi("N^{1/2} \\lessapprox N/H")#text(". This leads to ")#mi("(QN)^{2} \\lessapprox xN^{1-1/2}")#text(". Hence")

#mi("4\\varpi <\\sigma")#text(".")

#text("In this case, it appears that we can actually remove all of the Type I considerations and reduce to the Type II sums!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238166")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("In case you’re interested, the general form of the van der Corput estimate (assuming as much smoothness as needed) is")

#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi_q(n)\\right| \\lessapprox  N^{1 - \\frac{k+1}{2^{k+2}-2}} q^{1 / (2^{k+2} - 2)}", block: false)

#text("so ")#mi("q^{1/2}")#text(" for ")#mi("k=0")#text(" (completion of sums), ")#mi("N^{1/2} q^{1/6}")#text(" for ")#mi("k=1")#text(" (single van der Corput), ")#mi("N^{5/7} q^{1/14}")#text(" for ")#mi("k=2")#text(" (double van der Corput), ")#mi("N^{5/6} q^{1/30}")#text(" for ")#mi("k=3")#text(", and so forth. I believe one would eventually push ")#mi("\\sigma")#text(" down as low as desired by continually iterating van der Corput, but it becomes exponentially expensive in ")#mi("\\varpi")#text(" to do so, so unfortunately it is not a net win. (However if one just wants to prove Zhang’s theorem and don’t care how small ")#mi("\\varpi")#text(" (or ")#mi("\\delta")#text(") has to be, I think we now have the technology to do so entirely using the Type II argument, and we could even replace the completion of sums bound ")#mi("q^{1/2}")#text(" by the weaker, but more elementary, Kloosterman bound of ")#mi("q^{3/4}")#text(" that avoids the Weil conjectures completely.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("I played around a little with item 3, i.e. modifying the Type III computations to deal with ")#mi("\\alpha * \\psi_1 * \\psi_2")#text(" or ")#mi("\\alpha * \\psi_1")#text(" instead of ")#mi("\\alpha * \\psi_1 * \\psi_2 * \\psi_3")#text(". This is like asking for averaged distribution results for the trivial divisor function ")#mi("\\tau_1 = 1")#text(" or the classical divisor function ")#mi("\\tau_2(n) = \\sum_{n_1 n_2 = n} 1")#text(" rather than the third order divisor function ")#mi("\\tau_3(n) = \\sum_{n_1 n_2 n_3 = n} 1")#text(". It turns out that while the distribution results for the former functions are indeed better than the latter, this is more than compensated by the fact that a much smaller portion of the total convolution is actually coming from the divisor function in these cases, so it doesn’t look like a win.")

#text("To illustrate what is going on let us revert to “Level 3” Type III estimates that do not exploit the alpha averaging. Fouvry, Kowalski, Michel, and Nelson showed that ")#mi("\\tau_3")#text(" has a level of distribution of 4/7 for smooth moduli, which roughly speaking means that they have good control on ")#mi("\\sum_{n \\leq N: n=a\\ (q)} \\tau_3(n)")#text(" on average for ")#mi("q \\lessapprox N^{4/7}")#text(". This allows one to get good distribution results for ")#mi("\\alpha * \\psi_1 * \\psi_2 * \\psi_3")#text(" for moduli ")#mi("q \\lessapprox x^{1/2+2\\varpi}")#text(", where each ")#mi("\\psi_i")#text(" is supported at scale ")#mi("x^{t_i}")#text(", provided that")

#mi("\\frac{1}{2} + 2 \\varpi < \\frac{4}{7} (t_1 + t_2 + t_3).")

#text("Now suppose we work instead with ")#mi("\\tau_2")#text(". Here the classical result of Linnik and Selberg is that the level of distribution is at least 2/3. (Sketch of proof: one basically needs to estimate ")#mi("\\sum_{n \\sim N} \\sum_{m \\sim M} 1_{nm = a\\ (q)}")#text(" to accuracy ")#mi("o( NM/q )")#text(" when ")#mi("q = o( (NM)^{2/3} )")#text(". Assuming ")#mi("N,M = o(q)")#text(", we can perform Fourier summation and reduce to estimating ")#mi("\\sum_{h = O(q/N)} \\sum_{k = O( q/M) } \\sqrt{q} K_2( \\frac{ahk}{n}; q )")#text(" to accuracy ")#mi("o( \\frac{q}{N} \\frac{q}{M} \\frac{NM}{q} ) = o(q)")#text(", where ")#mi("K_2")#text(" is the normalised Kloosterman sum")

#mi("K_2(a;q) = \\frac{1}{\\sqrt{q}} \\sum_{xy = a\\ (q)} e_q( x + y).")

#text("If one then uses the Weyl bound ")#tao-math("\\left|K_2\\right| \\lessapprox 1", block: false)#text(" (ignoring the zero frequency contribution ")#mi("a=b=0")#text("), we obtain the desired claim.) For smooth moduli, Fouvry and Iwaniec (and Katz) improved the 2/3 slightly to 2/3+1/48, and perhaps with Zhang's new arguments one can push this a bit further, but let's work with the 2/3 number for now. This gives good estimates for ")#mi("\\alpha * \\psi_1 * \\psi_2")#text(" when")

#mi("\\frac{1}{2} + 2 \\varpi < \\frac{2}{3} (t_1 + t_2).")

#text("This constraint is better in that the 4/7 is improved to a 2/3, but worse in that we are only summing two of the ")#mi("t_i")#text(" instead of one. In the model case ")#mi("t_1=t_2=t_3")#text(" we end up significantly worse off if we try to use this estimate.")

#text("Finally, if we work with ")#mi("\\tau_1")#text(", this trivially has level of distribution 1, so we obtain a good estimate for ")#mi("\\alpha * \\psi_1")#text(" when")

#mi("\\frac{1}{2} + 2\\varpi < t_1.")

#text("This is the Type 0 estimate that we are already using. Again, the 4/7 or 2/3 factor has been improved to 1, but at the cost of now only using one of the ")#mi("t_i")#text(", so this is not a win in the cases we need the most badly.")

#text("Finally, for ")#mi("\\tau_4")#text(" we do not have level of distribution results better than 1/2 for smooth moduli (though in principle the Type I/II/III estimates we have should give us something which is at least as good as the estimates we have for MPZ, and perhaps a little bit better because the pesky Type V sums don’t appear for ")#mi("\\tau_4")#text(" – actually, it might be worth having a look to see what numerology we can get for ")#mi("\\tau_4")#text(", as this may offer a benchmark as to what to hope to get for ")#mi("\\Lambda")#text("), so we only get")

#mi("\\frac{1}{2} + 2 \\varpi < \\frac{1}{2} (t_1+t_2+t_3+t_4)")

#text("which is in fact never satisfied for any positive ")#mi("\\varpi")#text(".")

#text("The numerology changes a bit if we use the latest Type III estimates but I think the general picture is more or less the same.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238185")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Thanks once again for answering my questions. What seems surprising to me is how badly the constants work out in the ")#mi("t_1=t_2=t_3=1/5")#text(" case. Perhaps more surprising to me is that even though the Type III summation techniques have been optimized to improve the lower bound on ")#mi("\\sigma")#text(", we seem to do better using the techniques from the Type I case when we are restricted to two sequences. That is, when trying to deal with sums involving ")#mi("\\alpha\\ast \\psi")#text(" with ")#mi("\\psi")#text(" smooth of scale ")#mi("N=x^{2\\sigma}")#text(", we get better bounds trivially modifying the Type I techniques rather than using the techniques for Type III. Unfortunately, even if it were the case that some methods from the Type I analysis made the Type III analysis turn out better, that isn’t the current point of conflict.")

#text("Thank you for your very clear analysis. It appears that to make any headway on the Type V sums, we would need to improve the level of distribution for ")#mi("K_4")#text(" quite a bit (or to get Hooley’s conjecture and skip it all).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9de13c3c77059e2381357dce91d8408811e186d9d73d672aa8a814d24502a97-6908235e9bb52c626e6c19f1d38e16ef432f563317e7085fab69ed891489f3c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sniffnoy")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238075")[#strong[#text("Sniffnoy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Just a question from an interested onlooker: Everything since H=12006 has been marked “?”. What part of H=5414 is still unconfirmed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238145")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Basically, these later bounds rely on the Type I, II and III estimates described first in a number of scattered blog comments, and then finally compiled in one place in this blog post. So far, none of the other participants of the project have confirmed these estimates (they are somewhat lengthy, and there are a number of places where an arithmetic error could occur; I myself found a few minor ones when converting the comments to the blog format), but this will presumably happen eventually. (It’s not as if we are racing against time here.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238186")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("I think I figured out a way (in principle, at least, subject to the verification of some Deligne-level exponential sum estimates) to improve the van der Corput estimate")

#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi_q(n)\\right| \\lessapprox N^{1/2} q^{1/6}", block: false)

#text("for smooth functions ")#mi("\\psi_N")#text(" at some scale ")#mi("N \\ll q")#text(" and some reasonable phase ")#mi("\\Phi_q(n)")#text(" (e.g. the Kloosterman phase ")#mi("\\Phi_q(n) = e_q(c/n)")#text(") periodic with a smooth period ")#mi("q")#text(", very slightly to")

#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi_q(n)\\right| \\lessapprox N^{1/2} q^{2/13}", block: false)

#text("if one is allowed to do some averaging in the q aspect, and if one ignores the role of ")#mi("\\delta")#text(". As far as the Type I sums are concerned, this would improve the constraint")

#mi("\\frac{1}{2} (\\frac{1}{2}-\\sigma) + \\frac{1}{6} ( \\frac{1}{2} + \\sigma + 8\\varpi ) < -8\\varpi + \\frac{1}{2}-\\sigma")

#text("(or equivalently, ")#mi("56\\varpi + 4 \\sigma < 1")#text(") to")

#mi("\\frac{1}{2} (\\frac{1}{2}-\\sigma) + \\frac{2}{13} ( \\frac{1}{2} + \\sigma + 8\\varpi ) < -8\\varpi + \\frac{1}{2}-\\sigma")

#text("(or equivalently ")#mi("\\frac{160}{3} \\varpi + \\frac{34}{9} \\sigma < 1")#text("). Playing this against ")#mi("\\sigma > 1/10")#text(", this suggests that we can improve ")#mi("\\varpi")#text(" from ")#mi("3/280 \\approx 0.0107")#text(" to ")#mi("7/600 \\approx 0.0117")#text(" – not much, but better than nothing. (Using xfxie’s table at ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")]#text(" , this should correspond to ")#mi("k_0")#text(" somewhere near 630, which by the prime tuples page at ")#link("http://math.mit.edu/~primegaps/")[#text("http://math.mit.edu/~primegaps/")]#text(" suggests a value of ")#mi("H")#text(" somewhere near 4660. But this is an extremely rough back-of-the-envelope calculation.)")

#text("To explain the strategy, let me make the general remark that much of the game here is trying to estimate averaged exponential sums such as")

#mi("\\sum_{h_1 = O(H_1)} \\alpha_1(h_1) \\ldots \\sum_{h_k = O(H_k)} \\alpha_k(h_k)  \\Phi_q(h_1,\\ldots,h_k)")

#text("where the ")#mi("\\alpha_1,\\ldots,\\alpha_k")#text(" are various weights at various scales ")#mi("H_1,\\ldots,H_k")#text(" and ")#mi("\\Phi")#text(" is some explicit algebraic phase depending on ")#mi("h_1,\\ldots,h_k")#text("; also the modulus ")#mi("q")#text(" is also allowed to depend on one or more of the ")#mi("h_1,\\ldots,h_k")#text(" parameters. The various averages ")#mi("\\sum_i \\alpha_i(h_i)")#text(" can be informally divided into various types:")

#text("* “smooth” averages (in which ")#mi("\\alpha_i")#text(" is smooth) and “rough” averages (in which ")#mi("\\alpha_i")#text(" has no smoothness).")

#text("* “long” averages (in which ")#mi("H_i")#text(" is large) and “short” averages (in which ")#mi("H_i")#text(" is small).")

#text("* “non-modulus-altering” averages (in which ")#mi("q")#text(" does not depend on ")#mi("h_i")#text(") and “modulus-altering” averages (in which ")#mi("q")#text(" does depend on ")#mi("h_i")#text(").")

#text("Basically, we want to have smooth long non-modulus-altering averages around, because there are a lot of techniques available (e.g. completion of sums) for exploiting such averaging. In contrast, averages that are rough, short, and/or modulus-altering are not easy to exploit directly and so often just have to be discarded through the triangle inequality. However, the Cauchy-Schwarz inequality and its variants (e.g. Weyl differencing, dispersion method, or Holder’s inequality) can often be used to convert a “bad” average to a “good” average, albeit at the cost of “square-rooting” any gain one gets (and often the modulus ")#mi("q")#text(" grows a little bit after one applies Cauchy-Schwarz). So the game is to use Cauchy-Schwarz as sparingly as possible to extract one or more “good” averages that one can then squeeze some cancellation out of (which, in all of our arguments so far, is only obtainable by using completion of sums combined with the Weil conjectures).")

#text("The point is that when one applies the van der Corput method once, there is a moderately long smooth average in a parameter ")#mi("d_1")#text(" which manages to not alter the modulus. After using Fourier inversion to deal with another long smooth average, we can then deal with the moderately long smooth average by a second van der Corput. (In principle one could keep iterating this procedure, but it is already rather complicated as it is so I won’t try to do so here.)")

#text("OK, to the details. We will study the averaged sum")

#mi("{\\bf E}_{q \\sim Q} |\\sum_n \\psi_N(n) \\Phi_q(n)|.")

#text("We factor ")#mi("q = d_1 d_2")#text(" where ")#mi("d_1 \\sim D_1")#text(", ")#mi("d_2 \\sim D_2")#text(", and ")#mi("D_1 D_2 = Q")#text(" is to be optimised in later, though we assume we are in the regime ")#mi("D_1 \\ll N \\ll D_2")#text(" which is the regime of interest when applying van der Corput. We throw away the ")#mi("d_2")#text(" averaging and just average in ")#mi("d_1")#text(", thus we need to bound")

#mi("{\\bf E}_{d_1 \\sim D_1} |\\sum_n \\psi_N(n) \\Phi_{d_1 d_2}(n)|.")

#text("for a given ")#mi("d_2 \\sim D_2")#text(".")

#text("We perform Weyl differencing in the ")#mi("d_1")#text(" direction and end up staring at")

#mi("{\\bf E}_{d_1 \\sim D_1} |{\\bf E}_{k = o(N/D_1)} \\sum_n \\psi_N(n+kd_1) \\Phi_{d_1 d_2}(n+kd_1)  |.")

#text("Pulling out the n summation from the absolute values and then applying Cauchy-Schwarz, we can bound this by")

#mi("N^{1/2} ( {\\bf E}_{d_1 \\sim D_1} \\sum_n {\\bf E}_{k,k^{\\prime} = o(N/D_1)} \\psi_N(n+kd_1) \\psi_N(n+k^{\\prime}d_1)")#linebreak()#text(" ")#mi("\\Phi_{d_1 d_2}(n+kd_1) \\overline{\\Phi_{d_1 d_2}(n+k^{\\prime}d_1)} )^{1/2}.")

#text("The diagonal term ")#mi("k=k^{\\prime}")#text(" contributes ")#mi("O( N^{1/2} D_1^{1/2} )")#text(". For the off-diagonal terms, we crucially note (as in previous applications of van der Corput) that the ")#mi("d_1")#text(" component of the phases cancel, and the phase ")#mi("\\Phi_{d_1 d_2}(n+kd_1) \\overline{\\Phi_{d_1 d_2}(n+k^{\\prime}d_1)}")#text(" collapses to something like ")#mi("\\tilde \\Phi_{d_2}( k, k^{\\prime}, d_1, n )")#text(", so we are now looking at")

#tao-math("N^{1/2} \\left| {\\bf E}_{d_1 \\sim D_1} \\sum_n {\\bf E}_{k,k^{\\prime} = o(N/D_1); k \\neq k^{\\prime}} \\tilde \\psi_N(n) \\tilde \\Phi_{d_2}(k,k^{\\prime},d_1,n) \\right|^{1/2}.", block: false)

#text("for the off-diagonal contribution, where ")#mi("\\tilde \\psi_N")#text(" is some smooth cutoff function whose exact form is not too important here. If we estimate this by completion of sums, we get an additional term of ")#mi("N^{1/2} D_2^{1/4}")#text(", giving the van der Corput bound of ")#mi("O( N^{1/2} D_1^{1/2} + N^{1/2} D_2^{1/4} )")#text(" which optimises to ")#mi("O( N^{1/2} q^{1/6} )")#text(" as before. To do better than this, we first deal with the n summation by Fourier inversion, rewriting the above as something like")

#tao-math("N^{1/2} \\left| {\\bf E}_{d_1 \\sim D_1} {\\bf E}_{h = O( D_2/N)} {\\bf E}_{k,k^{\\prime} = o(N/D_1); k \\neq k^{\\prime}} D_2^{1/2} K( h, k, k^{\\prime}, d_1; d_2) \\right|^{1/2}", block: false)

#text("where ")#mi("K")#text(" is the Kloosterman-type sum")

#mi("K(h,k,k^{\\prime},d_1; d_2) := \\frac{1}{\\sqrt{d_2}} \\sum_{n \\in {\\bf Z}/d_2{\\bf Z}} \\tilde \\Phi_{d_2}(k,k^{\\prime},d_1,n) e_{d_2}(hn).")

#text("The point is that the ")#mi("d_1")#text(" summation is a moderately long smooth average (of length vaguely comparable to ")#mi("d_2^{1/2}")#text(" or so) that does not affect the modulus of ")#mi("K(h,k,k^{\\prime},d_1;d_2)")#text(", and so (assuming certain Deligne-level estimates are OK) we expect a van der Corput bound of the form")

#tao-math("\\left|\\sum_{d_1 \\sim D_1}  K( h, k, k^{\\prime}, d_1; d_2)\\right| \\lessapprox D_1^{1/2} d_2^{1/6}", block: false)

#text("which if one does the arithmetic gives a bound of ")#mi("N^{1/2} D_2^{1/3} D_1^{-1/4}")#text(" for the off-diagonal terms. We have thus bounded the original exponential sum by")

#mi("O( N^{1/2} D_1^{1/2} + N^{1/2} D_2^{1/3} D_1^{-1/4} )")

#text("which optimises to ")#mi("N^{1/2} Q^{2/13}")#text(" as claimed by setting ")#mi("D_1 := Q^{4/13}")#text(" and ")#mi("D_2 := Q^{9/13}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Terry, Let’s do a trade, I go to ucla to learn math from you, you learn Cantonese from me, OK?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238208")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("What prevents one from starting with a rough sequence, and then introducing a smooth sequence at the Cauchy-Schwarz step, as has been done in the past? (I initially thought there might be problems as now ")#mi("\\psi_N")#text(" depends not only on ")#mi("n")#text(" but also ")#mi("k,d_1")#text(". But if that were the issue, wouldn’t it also cause problems in the Fourier inversion step as well? I’m probably just missing something simple here.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238211")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Yes, one can use Cauchy-Schwarz to convert all sorts of rough sequences to smooth sequences, but it can cause some of the other averages to be duplicated, and more importantly it square roots the gain one gets at the end of the day (or equivalently, it doubles the amount of gain one now has to produce to meet one’s original objectives). For instance, if one had to gain ")#mi("x^{-4\\varpi}")#text(" over the trivial bound for an averaged exponential sum involving a rough sequence and then used Cauchy-Schwarz to make the rough sequence smooth, one would now have to gain ")#mi("x^{-8\\varpi}")#text(" over the trivial bound (this is how the Type I and Type II arguments eliminate the rough sequence ")#mi("\\beta(n) \\beta(n+kr)")#text(").")

#text("In the van der Corput analysis above, it turns out that all the relevant sequences are already smooth; we need Cauchy-Schwarz to perform Weyl differencing but not to eliminate rough sequences (well actually there is a rough sequence implicit in the ")#mi("d_1")#text(" summation (which lies outside the absolute values) that is eliminated by the Cauchy-Schwarz that performs the Weyl differencing, so the Cauchy-Schwarz is actually doing double duty here).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238832")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("I think, the required Deligne type estimates are valid here: the Kloosterman type sum that occurs ")#mi("K(h)")#text(" say (the Fourier transform of a fraction looking like ")#mi("x\\rightarrow 1/(x-k_1)-1/(x-k_2)")#text(" for ")#mi("k_1\\not=k_2")#text(") is the Frobenius trace function of a sheaf which has a singularity at ")#mi("0")#text(".")

#text("Now the VdC method amounts to knowing whether some non-trivial additive shift of K can correlate with K times a(ny) additive character (then, in absence of correlation, Deligne bootstraps this to square root cancellation). This is equivalent to deciding whether or not the additive shift of the sheaf underlying ")#mi("K")#text(" is geometrically isomorphic to the tensor product of itself with the trivial or any Artin-Schreier sheaf. In particular these isomorphic sheaves would have the same singularities on the affine line (since additive translation fixes infinity). The Artin-Schreier sheaf has no singularities on the affine line (hence cannot “destroy” any of the affine singularities of ")#mi("K")#text(" in the tensor product), that means that the set of affine singularities of ")#mi("K")#text(" (which is non-empty) would have to be invariant under non-trivial additive translation and in particular would cover the whole finite field which is not possible (if ")#mi("p")#text(" is large enough). There are probably other arguments possible but that one is fairly general.")

#text("These sort of things will be explained in more details in my lectures tomorrow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238843")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("Great! Looking forward to your lectures (at Caltech) tomorrow; this sheaf-based perspective to Deligne type estimates does indeed seem to be very well suited for analytic number theory, as all the basic operations on phases or Kloosterman sums on finite fields (e.g. Weyl differencing, pointwise multiplication, Fourier transforms, or computing correlations) seem to have natural geometric counterparts on the associated sheaves. Will definitely be taking notes :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238976")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2013")])]

#text("Dear Philippe,")

#text("After your very nice lectures (I now understand the role of l-adic sheaves a lot better now!) I tried to flesh out the Deligne-level estimates needed for the multiple van der Corput, but unfortunately I found that the sheaf Fourier transform of Deligne, Laumon, and Katz isn’t quite appropriate for the correlation sum needed, because I need the sheaf to run over a different variable than the Fourier variable.")

#text("Let me explain with the model problem of estimating an averaged incomplete Kloosterman sum")

#tao-math("\\sum_{q \\sim Q}\\left|\\sum_{n \\sim N} e_q( a / n )\\right|", block: false)

#text("(being vague about smooth cutoffs etc.), and with ")#mi("q")#text(" smooth. We factor ")#mi("q = d_1 d_2")#text(" for some suitable ")#mi("d_1,d_2")#text(" of a certain magnitude ")#mi("D_1,D_2")#text(" and throw away the ")#mi("d_2")#text(" averaging, leaving us with")

#mi("\\sum_{d_1 \\sim D_1} |\\sum_{n \\sim N} e_{d_1 d_2}( a / n )|.")

#text("For the inner sum we perform the q-van der Corput A-process in the ")#mi("d_1")#text(" direction, which leaves us with the task of bounding things like")

#tao-math("\\displaystyle \\left|\\sum_{d_1 \\sim D_1} \\sum_{n \\sim N} e_{d_1 d_2}( \\frac{a}{n+kd_1} - \\frac{a}{n} )\\right|", block: false)

#text("for some non-zero ")#mi("k")#text(" (one could conceivably try to exploit averaging in the ")#mi("k")#text(" parameter, but I will not attempt this here). As usual, the modulus of the phase collapses from ")#mi("d_1 d_2")#text(" to ")#mi("d_2")#text(" (which is the whole point of the q-van der Corput process):")

#tao-math("\\displaystyle \\left|\\sum_{d_1 \\sim D_1} \\sum_{n \\sim N} e_{d_2}( \\frac{ka}{n(n+kd_1)})\\right|.", block: false)

#text("Now we perform completion of sums in the n variable and end up with things like")

#tao-math("\\displaystyle \\left|\\sum_{d_1 \\sim D_1} \\sum_{n \\in {\\bf Z}/d_2} e_{d_2}( \\frac{ka}{n(n+kd_1)} + hn)\\right|", block: false)

#text("for various ")#mi("h")#text(" (again, we will not attempt to exploit averaging in ")#mi("h")#text(", it is quite a short average in practice). So we need to control something like")

#mi("\\sum_{d_1 \\sim D_1} K( ka, kd_1, h; d_2 )")

#text("where ")#mi("K")#text(" is the Kloosterman-type sum")

#mi("\\displaystyle K( a, b, h; d_2 ) := \\frac{1}{\\sqrt{d_2}} \\sum_{n \\in {\\bf Z}/d_2} e_{d_2}( \\frac{a}{n(n+b)} + hn ).")

#text("Now, the Deligne-Laumon-Katz theorem lets us express ")#mi("K")#text(" as the trace of a Frobenius of a lisse sheaf in the h variable, but unfortunately that’s the wrong variable; we instead need a sheaf interpretation of ")#mi("K")#text(" in the b variable. That’s not obviously a Fourier transform, so DLK does not directly apply. It’s still the pushforward of a two-dimensional sheaf, though, so in principle one can still view it as a one-dimensional sheaf (though it may be a bit harder to track the singularities – presumably Laumon’s sheaf-theoretic stationary phase still applies though? Also, it may be trickier to maintain geometric irreducibility in this variable, since we don’t have the Plancherel trick any more).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239000")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2013")])]

#text("Oh I see; sorry, I took the wrong variable; thanks for correcting. I will look at the right problem now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239019")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Dear Philippe and Terry, it would be nice and useful to have a brief account of the l-adic techniques and their relation to older techniques (or alternately a transcript/recording/notes of Philippe’s lectures) on this blog.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("I’ll try to write something over the coming days. Philippe, Emmanuel, and Etienne are planning a monograph on this topic but that will probably take a bit longer :) [But Chapter 11 of Iwaniec-Kowalski already has a pretty good summary.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239054")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("I think that being irreducible may not be too much an issue: given ")#mi("K")#text(" some trace function associated to some sheaf ")#mi("KK")#text(" the VdC method requires that for all but a bounded number of ")#mi("l")#text(", ")#mi("x \\to K(x+l)")#text(" does not correlate with ")#mi("K(x)\\psi(x)")#text(" for any additive character ")#mi("\\psi")#text(". If ")#mi("KK")#text(" is irreducible this would work for all non-zero ")#mi("l")#text(" (provided ")#mi("p")#text(" is large compared to the conductor that ")#mi("KK")#text(" satisfy some mild additional condition like having a singularity on the affine line or large enough Swan conductor at ")#mi("\\infty")#text(", ")#mi(">2 ?")#text(" -the later to avoid thing like quadratic phases-).")

#text("If there are more than one irreducible component (each one satisfying the assumptions above) then it seem that the number of bad ")#mi("l")#text(" might increase but by a bounded amount only. That concerns of course the weight 0 part and if the sheaf mixed of weight ")#mi("\\leq 0")#text(" the contribution from the negative weight part can be bounded trivially. So maybe there is a relatively soft proof of this form of VdC for general ")#mi("K")#text(": of course one needs to know a bit about that specific sheaf and especially its weight 0 part but maybe not as much as one would know if it were a Fourier transforms.")

#text("That is an interesting question !")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239060")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("I think it may be convenient to decompose ")#mi("K")#text(" into irreducible components before applying the vdC method (this may require some uniformity of the decomposition (e.g. uniform bounds on the conductor of the components) with respect to all the various primes p dividing the modulus q, but perhaps one can appeal to some scheme-theoretic nonsense to justify this), so one doesn’t have to see the interactions between different components, instead simply using the plain old triangle inequality to glue together the contributions of each component. For a single component, I think one can in fact get an “inverse theorem” to the effect that the expected vdC theorem works unless the component is coming from a quadratic phase ")#mi("x \\mapsto e_q(ax^2+bx+c)")#text(" (if one was using iterated vdC, then also higher polynomial phases would appear). So basically one has to show that ")#mi("K")#text(" usually doesn’t correlate with a quadratic phase in the b variable, which looks like a relatively easy thing to verify (but it is, naively at least, still a two-dimensional exponential sum or worse, so one still needs some Deligne-level technology to dispose of it).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239088")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("A simple way to decide whether the sheaf contains geometrically a quadratic phase (or any phase) is to use Hooley’s criterion")#linebreak()#text(" (On exponential sums and certain of their applications, Exeter) which state that for ")#mi("f(X,Y)")#text(" a rational function with")#linebreak()#text(" numerator and denominator with rational coefficient the sum")

#mi("\\sum_{x,y(p)}e_p(f(x,y))=O(p)")

#text("if the curve")

#mi("f(X,Y)-T=0")

#text("is geometrically generically irreducible (irreducible over an algebraic closure of ")#mi("F_p(T)")#text(") and")#linebreak()#text(" if for any ")#mi("t\\in\\overline{F_p}")#text(" the ")#mi("F_p")#text("-variety")

#mi("f(X,Y)-t=0")

#text("is a curve (possibly reducible). This is a nice and simple application of Parseval together with the invariance of the weights under Galois conjugation!")

#text("One can find in (Fouvry-Michel, Sur certaines sommes d’exponentielles sur les nombres premiers) examples where this criterion is applied (and a simple criterion Prop 2.1 to verify Hooley’s criterion). I have not checked it yet on our case.")

#text("Of course it will be very interesting to have a general result to apply VdC to general trace weights of composite moduli, but that depend both on the shape of the local trace weights mod ")#mi("p")#text(" and the way the global one factorizes under the CRT. Anyway that criterion should permit to make good progress on this specific case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("I’m recording here the details of Hooley’s argument from ")#link("http://www.ams.org/mathscinet-getitem?mr=697259")[#text("http://www.ams.org/mathscinet-getitem?mr=697259")]#text(" as it is indeed very neat. Deligne’s theorems give an expansion of the form")

#mi("\\sum_{x,y \\in {\\Bbb F}_{p^r}} e_p( \\text{Tr}( f(x,y) ) ) = \\sum_{i=1}^k c_i \\alpha_i^r")

#text("where ")#mi("\\text{Tr}")#text(" is the trace from ")#mi("{\\Bbb F}_{p^r}")#text(" to ")#mi("{\\Bbb F}_p")#text(", ")#mi("k")#text(" and ")#mi("c_1,\\ldots,c_k")#text(" are bounded integers, and ")#mi("\\alpha_i")#text(" are distinct algebraic integers whose magnitude is a power of ")#mi("p^{1/2}")#text(" (and all Galois conjugates of ")#mi("\\alpha_i")#text(" have the same magnitude). The problem here is that some of the ")#mi("\\alpha_i")#text(" may be of too high weight – of magnitude ")#mi("p^{3/2}")#text(" or ")#mi("p^2")#text(". But we can eliminate this using Galois theory and the Plancherel identity as follows. The left-hand side lives in the cyclotomic integers of order ")#mi("p")#text(", so the weights ")#mi("\\alpha_i")#text(" do as well. We then have")

#mi("\\sum_{x,y \\in {\\Bbb F}_{p^r}} e_p( s \\text{Tr}( f(x,y) ) ) = \\sum_{i=1}^k c_i \\sigma_s(\\alpha_i)^r")

#text("for all non-zero ")#mi("s \\in {\\Bbb F}_p")#text(", where ")#mi("\\sigma_s")#text(" is the Galois automorphism of the cyclotomic integers that maps ")#mi("e^{2\\pi i/p}")#text(" to ")#mi("e^{2\\pi i s/p}")#text(". If one of the ")#mi("\\alpha_i")#text(" has magnitude ")#mi("p^{3/2}")#text(" or more, we can then square-sum in ")#mi("s")#text(" and conclude that")

#tao-math("\\sum_{s \\in {\\Bbb F}_p \\backslash 0} \\left|\\sum_{x,y \\in {\\Bbb F}_{p^r}} e_p( s \\text{Tr}( f(x,y) ) )\\right|^2 \\gg p^{3r+1}", block: false)

#text("for infinitely many ")#mi("r")#text(", which certainly implies")

#tao-math("\\sum_{s \\in {\\Bbb F}_{p^r} \\backslash 0} \\left|\\sum_{x,y \\in {\\Bbb F}_{p^r}} e_p( \\text{Tr}( s f(x,y) ) )\\right|^2 \\gg p^{3r+1}.", block: false)

#text("But by Plancherel, the left-hand side may be rewritten as")

#tao-math("p^r \\sum_{t \\in {\\Bbb F}_{p^r}} \\left|N_r(t) - p^r\\right|^2", block: false)

#text("where ")#tao-math("N_r(t) := \\left|\\{ (x,y) \\in {\\Bbb F}_{p^r}^2: f(x,y) = t \\}\\right|", block: false)#text(". From the hypotheses on ")#mi("f")#text(" and the Weil conjectures for curves we have ")#mi("N_r(t) = p^r + O(p^{r/2})")#text(" for all but boundedly many ")#mi("t")#text(", and ")#mi("N_r(t) = O(p^r)")#text(" in general, so the previous expression is ")#mi("O(p^{3r})")#text(", leading to a contradiction for ")#mi("p")#text(" large enough.")

#text("For our specific application, namely showing that the function ")#mi("b \\mapsto \\frac{1}{\\sqrt{p}} \\sum_{n \\in {\\Bbb F}_p} e_p( \\frac{a}{n(n+b)} + hn)")#text(" does not correlate with any quadratic phase, it seems that it boils down to showing that the quartic curve ")#mi("\\{ (x,y): \\frac{a}{x(x+y)} + hx + cy^2 + dy - T = 0\\}")#text(" is geometrically generically irreducible for ")#mi("a,h")#text(" non-zero, which looks like something that can be verified by some ad hoc finite computation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239096")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("OK, so the question of making K not correlate with a quadratic phase doesn’t look too bad then, it will “just” require some classical algebraic geometry (one of Bertini’s theorems, perhaps). (For the actual application to bounded gaps, K will be a little more complicated than advertised above, because we are not summing a Kloosterman phase ")#mi("e_q(a/n)")#text(", but rather the more complicated phase in equation (34) of this blog post that arose after two applications of Cauchy-Schwarz to eliminate the ")#mi("\\alpha,\\beta")#text(" weights, but hopefully the arguments will extend.) So it seems the main thing is to check that K is still coming from some reasonably well-behaved (though not necessarily geometrically irreducible) sheaf in the b variable. (I now think the decomposition of the modulus into individual primes p will not be a problem, the CRT allows one to reduce the treatment of completed exponential sums (even higher-dimensional ones) on composite (squarefree) moduli to prime moduli without much difficulty.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239098")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("“(I now think the decomposition of the modulus into individual primes p will not be a problem, the CRT allows one to reduce the treatment of completed exponential sums (even higher-dimensional ones) on composite (squarefree) moduli to prime moduli without much difficulty.)”")

#text("What I was meaning about the CRT factorization for general trace weights was just the following:")

#text("imagine the original trace function were, say , a Kloosterman sum ")#mi("KL_k(n;rs)")#text(" the CRT yields")

#mi("KL_k(n;rs)=KL_k(s^{-k}n;r)KL_k(r^{-k}n;s)")

#text("so after doing VdC one would get a transform of the shape")

#mi("\\sum_n KL_k(b^{-k}n;r)\\overline{KL_k(b^{-k}(n+b);r)}e_r(hn)")

#text("(or as you say something a bit more complicated) so one would need to look at the variation in ")#mi("b")#text(" of the correlation of ")#mi("Kl_k")#text(" with the pair of arguments")

#mi("b^{-k}n,\\ b^{-k}(n+b)")

#text("so different values of ")#mi("k")#text(" would yield different pairs to study.")

#text("Similarly, if the trace function were (Paul’s notation)")

#mi("KL_{-k}(n;rs):=KL_k(n^{-1};rs)")

#text("(which is the problem in present case with ")#mi("k=1")#text("), the pair would be")

#mi("b^{-k}n^{-1},\\ b^{-k}(n+b)^{-1}")

#text("I just mean I don’t see yet a general geometric pattern allowing to treat all possible cases all at once (unlike the case of the general Polya-Vinogradov method or the treatment of type II sums for general trace weights).")

#text("Maybe such a pattern will emerge after the present case has been sufficiently understood and digested…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239261")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("The generic geometric reducibility of the curve can be checked via the following criterion (Prop. 2.1 of Fouvry-Michel, Sur certaines sommes d’exponentielles sur les nombres premiers): ")#mi("f(X,Y)-T")#text(" is reducible over ")#mi("\\overline{F_p(T)}")#text(" iff ")#mi("f(X,Y)")#text(" can be written ")#mi("u(v(X,Y))")#text(" with ")#mi("u(V)\\in F_p(V)")#text(" not a fractional linear transformation (not a ratio of polynomials of degree ")#mi("\\leq 1")#text(") and ")#mi("v(X,Y)\\in F_p(X,Y)")#text("; in other terms the morphism ")#mi("f")#text(" factors non-trivially through the projective line. Moreover, in the present case (since ")#mi("f")#text(" has non-constant denominator) if one allow the fractions to have coefficients in ")#mi("\\overline F_p")#text(" one may assume that ")#mi("u")#text(" has positive degree (a pole at ")#mi("\\infty")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Dear Phillippe: thanks for this! Your criterion with Fouvry seems very close to Bertini’s second theorem, see Theorem 5.3 of ")#link("http://arxiv.org/abs/alg-geom/9704018")[#text("this survey of Kleiman")]#text(". In this particular case of trying to show that ")#mi("f(x,y) - T")#text(" is generically irreducible with ")#mi("f(x,y) = \\frac{a}{x(x+y)} +hx + cy + dy^2")#text(", I think we can combine this criterion (in a somewhat ad hoc fashion) with Eytan’s observation (using the cubic nature of the curve ")#mi("f(x,y)-T=0")#text(" in y) that if this expression was generically reducible, the components would have to be linear of the form ")#mi("y - f_T(x)")#text(" (note that the factors have to be Galois conjugate to each other over ")#mi("\\overline{\\Bbb F}(T)")#text(", indeed they are of the form ")#mi("v(x,y)=c_T")#text("), which I think means that the rational function ")#mi("v")#text(" in the putative factorisation ")#mi("\\frac{a}{x(x+y)} + hx + cy + dy^2 = u(v(x,y))")#text(" has to be of the form ")#mi("v(x,y) = g(x) y + h(x)")#text(" (otherwise the curves ")#mi("v = \\text{const}")#text(" have too much multiplicity in the ")#mi("y")#text(" direction). On the other hand, as ")#mi("a")#text(" is non-zero, this rational function is singular at ")#mi("x(x+y)=0")#text(", which means that (after shifting ")#mi("v")#text(" by a constant) we have ")#mi("v(x,y) = k(x) x(x+y)")#text(" for some rational function ")#mi("k")#text(". Writing ")#mi("y = \\frac{v}{x k(x)} - x")#text(", we thus have")

#mi("f = \\frac{ak(x)}{v} + bx - cx + \\frac{cv}{xk(x)} + d (\\frac{v}{xk(x)} - x)^2")

#text("Looking at the behaviour as ")#mi("v")#text(" approaches zero, we see that ")#mi("f")#text(" cannot be a function of ")#mi("v")#text(" alone unless ")#mi("k")#text(" is constant, but then by considering the behaviour as ")#mi("x")#text(" approaches zero we must have ")#mi("c, d")#text(" both vanishing, but then taking ")#mi("x \\to \\infty")#text(" we see that ")#mi("b")#text(" must vanish also, which we assumed not to be the case. So I think this proves that ")#mi("f(x,y)-T")#text(" is generically geometrically irreducible. (Probably there is a less ad hoc way to do this though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239269")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Dear terry")

#text("thanks for the reference to Kleiman which I didn’t t know and is great to read. No geometer pointed it to me before.")

#text("Another reference which is relevant to this discussion is this inverse theorem for Gowers norms for l adic sheaves (")#link("http://arxiv.org/abs/1211.3282")[#text("http://arxiv.org/abs/1211.3282")]#text(") which unfortunately does not include the decomposition question in its statements. Given this and earlier comment you made: wouldn’t it be interesting to restate VdC and iterations of it systematically in terms of Gowers norms ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Dear Philippe,")

#text("One can use lots of Cauchy-Schwarz (or van der Corput) to control incomplete sums such as ")#mi("\\sum_n \\psi_N(n) K(n)")#text(" in terms of various Gowers norms of ")#mi("K")#text(", but the process is rather inefficient in the exponents, though if one is only interested in qualitative cancellation (e.g. gaining powers of ")#mi("N^{-\\varepsilon}")#text(" over the trivial bound where one doesn’t care about how small ")#mi("\\varepsilon")#text(" is) then one can do everything through Gowers norms. But since in this project we need exponents that are as good as possible, I don’t think it’s worth going through the Gowers norms here.")

#text("On the other hand, it seems likely that the Hooley argument allows one to deduce the inverse theorem for van der Corput (roughly speaking, that ")#mi("\\sum_n \\psi_N(n) K(n)")#text(" obeys a van der Corput estimate unless ")#mi("K")#text(" contains or correlates with a polynomial phase at many primes ")#mi("p")#text(" dividing the modulus ")#mi("q")#text(" of ")#mi("K")#text(") from the inverse theorem for the Gowers norms in your paper with Emmanuel and Etienne you linked to above… though this is sort of a roundabout way to do it, since I think the inverse van der Corput argument can be proven directly using an easier version of the methods in that paper (particularly since in our case we only use the first van der Corput estimate and not any higher iteration, though probably the inverse theorem for the iterated vdC follows by the same methods).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238188")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Prof. Tao,")#linebreak()#text(" Is the new ")#mi("\\omega")#text(" 7/600 or 6/700? It’s one way here and the other way on the Polymath wiki.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238562")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("Two suggestions and some typos:")

#text("1. In the proof of Corollary 11, you refer to Proposition 5 of the previous post (")#link("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")[#text("https://terrytao.wordpress.com/2013/06/22/bounding-short-exponential-sums-on-smooth-moduli-via-weyl-differencing/")]#text("). For the sake of the reader it would be cleaner/simpler to refer to just one important step in the proof of this proposition, namely to")

#tao-math("\\left|\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(f(n))\\right| \\lessapprox (c_1,d^{\\prime}_1) (c_2,d^{\\prime}_2) (d_1,d_2)", block: false)#text(",")

#text("where ")#mi("q:=[d_1,d_2]")#text(" and ")#mi("f(t) := \\frac{c_1 d^{\\prime}_2}{t+l-m} + \\frac{c_2 d^{\\prime}_1}{t+l^{\\prime}-m}")#text(". This implies that the last term in Proposition 10 (for this choice of parameters) is")

#tao-math("\\leq \\frac{N}{q^{\\prime}} \\left|\\sum_{n \\in {\\bf Z}/q^{\\prime}{\\bf Z}} e_{q^{\\prime}}(f(n) / (f,q) )\\right|=\\frac{N}{q} |\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_{q}(f(n))| \\lessapprox \\frac{(c_1,d^{\\prime}_1)}{d^{\\prime}_1} \\frac{(c_2,d^{\\prime}_2)}{d^{\\prime}_2} N", block: false)#text(".")

#text("2. In the proof of Lemma 12, the term ")#mi("(b_1-b_2,m,p)^{1/2}")#text(" should be ")#mi("(b_1-b_2,m,d_1,d_2)^{1/2}")#text(". Moreover, in three consecutive displays of this proof, ")#mi("\\bf Z/p{\\bf Z}")#text(" should be ")#mi("{\\bf Z}/p{\\bf Z}")#text(".")

#text("3. Two lines below (7), ")#mi("Type_I[\\varpi,\\delta,\\sigma]")#text(" should be ")#mi("Type^{\\prime\\prime}_I[\\varpi,\\delta,\\sigma]")#text(".")

#text("4. ")#mi("q_2\\ldots q_k")#text(" should be ")#mi("q_2\\ldots q_l")#text(" (four occurrences).")

#text("5. In Corollary 11, ")#mi("q | d_1,d_2")#text(" should be ")#mi("q_0 | d_1,d_2")#text("; perhaps ")#mi("q_0 | (d_1,d_2)")#text(" would be even better. In addition, ")#mi("d_1/(d_1,d_2)")#text(" should be ")#mi("d_i/(d_1,d_2)")#text(".")

#text("6. In the proof of Corollary 11, “replaced by ")#mi("d^{\\prime}_1,d^{\\prime}_2")#text("” should be “replaced by ")#mi("\\tilde d_1, \\tilde d_2")#text("“, and ")#mi("[d^{\\prime}_1,d^{\\prime}_2]")#text(" should be ")#mi("[\\tilde d_1, \\tilde d_2]")#text(".")

#text("7. In Lemma 12, ")#mi("[r_1 r_2]")#text(" should be ")#mi("[r_1, r_2]")#text(".")

#text("8. Three displays above Lemma 13, ")#mi("1_{m \\bar{b_1} yz = 1}")#text(" should be ")#mi("1_{m \\bar{b_1} xy = -1}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238581")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("9. I think in Proposition 10 all prime factors of ")#mi("q")#text(" should be sufficiently large to make the implication")

#mi("(f,q)=1\\Longrightarrow (f^{\\prime},q)=1\\Longrightarrow (f^{\\prime\\prime},q)=1")

#text("valid. We can remove this restriction on ")#mi("q")#text(" by decomposing")

#mi("\\sum_n \\psi_N(n) e_q(f(n)) = \\sum_{a\\in{\\bf Z}/q_0{\\bf Z}}\\sum_{n=a\\ (q_0)} \\psi_N(n) e_q(f(n))")#text(",")

#text("where ")#mi("q_0")#text(" is the product of the small prime factors of ")#mi("q")#text(". A similar comment applies to Corollary 11.")

#text("10. Three displays above Lemma 13, ")#mi("1_{m \\bar{b_1} xy = 1}")#text(" should be ")#mi("1_{m \\bar{b_1} xy = -1}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("I am recording here a variant of the combinatorial lemma that relaxes the constraint ")#mi("\\sigma > 1/10")#text(" to ")#mi("\\sigma > 1/12")#text(", at the cost of introducing two additional cases, the “Type IV” and “Type V” cases. We have good estimates for the Type IV case, but unfortunately not for the Type V case, so this lemma does not actually give any improvement on ")#mi("\\varpi,\\delta")#text(" for our application. (However if one is interested in a distribution theorem for ")#mi("\\tau_4")#text(" rather than for ")#mi("\\Lambda")#text(", then the Type V case is excluded and we can do a little bit better than what we currently have (specifically, if we ignore ")#mi("\\delta")#text(", we improve ")#mi("\\varpi")#text(" from ")#mi("3/280")#text(" to ")#mi("1/88")#text(").")

#text("Here is the precise lemma:")

#strong[#text("Combinatorial lemma")]#text(" Let ")#mi("t_1,\\ldots,t_n")#text(" be non-negative quantities adding up to ")#mi("1")#text(", and let ")#mi("1/12 < \\sigma < 1/2")#text(". Then at least one of the following occurs:")

#text("* (Type 0 case) We have ")#mi("t_i \\geq 1/2 + \\sigma")#text(" for some ")#mi("i")#text(".")

#text("* (Type I/II case) There exists a partition ")#mi("\\{1,\\ldots,n\\} = A \\cup B")#text(" such that ")#mi("1/2 - \\sigma \\leq \\sum_{i \\in A} t_i \\leq \\frac{1}{2} \\leq \\sum_{i \\in B} t_i \\leq 1/2 + \\sigma")#text(".")

#text("* (Type III case) There exist distinct ")#mi("i,j,k")#text(" such that ")#mi("2\\sigma \\leq t_i \\leq t_j \\leq t_k \\leq 1/2-\\sigma")#text(" and ")#mi("t_i+t_j \\geq 1/2+\\sigma")#text(". (This case only occurs when ")#mi("\\sigma \\leq 1/6")#text(".)")

#text("* (Type IV case) There exist distinct ")#mi("i,j,k,l")#text(" such that ")#mi("2 \\sigma \\leq t_i \\leq t_j \\leq t_k \\leq t_l \\leq 1/2-\\sigma")#text(" and ")#mi("t_i+t_l \\geq 1/2+\\sigma")#text(". In particular we have ")#mi("t_i \\leq \\frac{1-t_i-t_l}{2} \\leq \\frac{1}{4}-\\frac{1}{2}\\sigma")#text(", and hence ")#mi("\\frac{1}{4} + \\frac{3}{2} \\sigma \\leq t_l \\leq 1/2 - \\sigma")#text(". (This case only occurs when ")#mi("\\sigma \\leq 1/10")#text(".)")

#text("* (Type V case) There exist distinct ")#mi("i,j,k,l,m")#text(" such that ")#mi("2 \\sigma \\leq t_i \\leq t_j \\leq t_k \\leq t_l \\leq t_m \\leq 1/2-3\\sigma")#text(" and ")#mi("t_i+t_j+t_k \\geq 1/2+\\sigma")#text(". (This case only occurs when ")#mi("\\sigma \\leq 1/10")#text(".)")

#strong[#text(" Proof")]#text(" If we have ")#mi("\\sum_{i \\in A} t_i \\in [1/2-\\sigma,1/2+\\sigma]")#text(" for some ")#mi("A")#text(" then we are in the Type I/II case (possibly after replacing ")#mi("A")#text(" with its complement), so we may assume that this does not occur. Thus every ")#mi("\\sum_{i \\in A} t_i")#text(" is “small” (less than ")#mi("1/2-\\sigma")#text(") or “large” (greater than ")#mi("1/2+\\sigma")#text(").")

#text("As before, call an element ")#mi("t_i")#text(" “powerful” if the addition of ")#mi("t_i")#text(" can convert a small sum into a large sum, and “powerless” otherwise. All the powerful elements must be at least ")#mi("2\\sigma")#text(", and have large sum. If any of the powerful elements are large then we are in Type 0, so we may assume that they are all small, which implies that they remain small even if we add in all the powerless elements; in particular, there are at least three powerful elements (since two small quantities cannot sum to 1). On the other hand, since ")#mi("2\\sigma > 1/6")#text(", we see that there are at most five powerful elements.")

#text("We now divide into cases. If there are exactly three powerful elements ")#mi("t_i,t_j,t_k")#text(", then without loss of generality ")#mi("2\\sigma \\leq t_i \\leq t_j \\leq t_k \\leq 1/2-\\sigma")#text(". Since ")#mi("t_k")#text(" plus all the powerless elements is small, we conclude that ")#mi("t_i+t_j")#text(" is large, and we are in the Type III case.")

#text("If there are exactly four powerful elements ")#mi("t_i,t_j,t_k,t_l")#text(", then without loss of generality ")#mi("2\\sigma \\leq t_i \\leq t_j \\leq t_k \\leq t_l \\leq 1/2-\\sigma")#text(". If ")#mi("t_i+t_l")#text(" is large then we are in the Type IV case, so suppose instead that ")#mi("t_i+t_l")#text(" is small. Then ")#mi("t_i+t_l")#text(" plus all the powerless elements is still small, so ")#mi("t_j+t_k")#text(" is large. But then ")#mi("t_j,t_k,t_l")#text(" place us in the Type III case, and we are again done.")

#text("Finally suppose that there are exactly five powerful elements ")#mi("t_i,t_j,t_k,t_l")#text(". Without loss of generality we have ")#mi("2\\sigma \\leq t_i \\leq t_j \\leq t_k \\leq t_l \\leq t_m \\leq 1/2-\\sigma")#text(". Note that ")#mi("t_i+t_j+t_k")#text(" is at least ")#mi("6\\sigma")#text(", which is greater than ")#mi("1/2")#text("; thus ")#mi("t_i+t_j+t_k")#text(" is large. Thus forces ")#mi("t_l+t_m")#text(" to be small; since ")#mi("t_l \\geq 2\\sigma")#text(", we conclude that ")#mi("t_m \\leq 1/2-3\\sigma")#text(" as required. ")#mi("\\Box")

#text("We can illustrate this lemma with the ")#mi("\\tau_4")#text(" estimate when there is no Type V estimate. Ignoring ")#mi("\\delta")#text(", we can control the Type 0 sums whenever")

#mi("\\sigma > 2\\varpi,")

#text("the Type I sums whenever")

#mi("4\\sigma + 56 \\varpi < 1")

#text("the Type II sums whenever")

#mi("68 \\varpi < 1")

#text("and the Type III sums whenever")

#mi("\\sigma > 1/18 + 28/9")#text(".")

#text("(The Type I condition might be improvable in view of this previous comment ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238186")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238186")]#text(" , but let’s ignore that for")

#text("now.)")

#text("To handle the Type IV sums, we see that as ")#mi("t_l \\geq 1/2 - (1/4 - 3\\sigma/2)")#text(", we can view these sums as a Type I sum with ")#mi("\\sigma")#text(" replaced by ")#mi("1/4-3\\sigma/2")#text(", and with the “")#mi("\\beta")#text("” factor smooth. In this comment ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238054")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238054")]#text(" it is shown (or at least sketched) that such sums can be controlled if")

#mi("4(1/4-3\\sigma/2) + 28 \\varpi < 1")#text(".")

#text("One can check that these conditions (as well as the combinatorial constraint ")#mi("\\sigma > 1/12")#text(") are satisfiable in the neighbourhood of ")#mi("\\sigma = 1/11")#text(", ")#mi("\\varpi = 1/88")#text("). It’s a pity that we don’t yet have any good way to control Type V sums (other than to treat them to a Type I sum), otherwise we could hope to obtain this sort of improvement for the actual problem, rather than for the ")#mi("\\tau_4")#text(" distribution problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00dc47e8e330cb19d37e5ea9e016efa5bb9b2fb9240b2a171290a849c3a05d9c-d497eb896c681f5a9ba63c6cd8d9a29f038f9088bf1743cc2b7a1649337f3f59.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Rothbach")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238577")[#strong[#text("Brian Rothbach")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("Shouldn’t you be able to improve 1/12 to 1/14 in the lemma? The sum of three powerful elements just needs to be greater than ")#mi("1/2-\\sigma")#text(" to be large, not ")#mi("\\sigma")#text(" ")#emph[#text("[probably you mean ")#mi("1/2")#text(" here – T.]")]#text("; once you have that, you can’t have 6 powerful elements with a sum less than 1 (since both the first three and the last three would sum to at least ")#mi("1/2+\\sigma")#text(").")

#text("The next obstacle to the combinatorial lemma appears to be a collections of seven 1/7th’s (and other clusterings of 1/7th), and in general collections of 2n+1 1/(2n+1)’s start new cases..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238579")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2013")])]

#text("Nice observation! I think you’re right. (At present this doesn’t improve any exponents because the Type I/Type III barrier is currently at ")#mi("\\sigma = 1/11")#text(", but in principle this improvement could become relevant in the future.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238723")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")])]

#text("Here is something I tried to figure out but couldn’t make it work. Does the Type V decomposition actually occur in the cases we care about? That is, when utilizing the Heath-Brown decomposition, can we have exactly 5 smooth terms, each roughly of scale ")#mi("x^{1/5}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")])]

#text("I’m recording here an observation which is a bit tricky to formalise properly, but roughly asserts that one cannot hope to do much better than the Heath-Brown identity when decomposing ")#mi("\\Lambda")#text(" into various Type I, Type II, Type III, etc. convolutions of various coefficient sequences, some smooth and some not, at different scales.")

#text("Let me try to explain what I mean by this. Currently, with the Heath-Brown identity, one has decomposed ")#mi("\\Lambda")#text(" into a finite (or more precisely, a polylogarithmic) number of convolutions ")#mi("\\alpha_1 * \\ldots * \\alpha_n")#text(", where each ")#mi("\\alpha_i")#text(" is a coefficient sequence at scale ")#mi("x^{t_i}")#text(" for some non-negative real numbers ")#mi("t_1,\\ldots,t_n")#text(" summing to 1. Furthermore, the ")#mi("\\alpha_i")#text(" are smooth whenever the ")#mi("t_i")#text(" are not absolutely tiny. We then need to find enough Type I, Type II, Type III, etc. estimates to cover all possible values of the tuple ")#mi("(t_1,\\ldots,t_n)")#text(". Each “Type X” estimate covers convolutions of a certain form ")#mi("\\beta_1 * \\ldots * \\beta_m")#text(", where each ")#mi("\\beta_i")#text(" is supported at some scale ")#mi("x^{s_i}")#text(", with some constraints on the ")#mi("s_1,\\ldots,s_m")#text(" (typically a collection of linear inequalities), and also some requirements that some of the ")#mi("\\beta_i")#text(" are smooth. (There is also a Siegel-Walfisz condition, but this is easily verified in practice and will be ignored here.) Such an estimate can “cover” a certain convolution ")#mi("\\alpha_1 * \\ldots * \\alpha_n")#text(" if there is some way to regroup this convolution (e.g. by concatenating ")#mi("\\alpha_i * \\alpha_j")#text(" into a single sequence ")#mi("\\beta_k")#text(" at scale ")#mi("x^{t_i+t_j}")#text(") to place it in a form treatable by the estimate (keeping in mind that convolution destroys smoothness).")

#text("One could hope that one could repeat this strategy with the Heath-Brown identity replaced by another identity (e.g. Vaughan’s identity) that similarly splits ")#mi("\\Lambda")#text(" into finitely many pieces, each of which is covered by some “Type X” estimate, but which is superior to Heath-Brown in the sense that not every tuple ")#mi("(t_1,\\ldots,t_n)")#text(" summing to 1 needs to be covered. For instance, our current nemesis is the tuple ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" – wouldn’t it be great if there was an identity that avoided the need to control this tuple? Note that one has to interpret the phrase “avoided the need to control this tuple” carefully. For instance, in the Vaughan identity")

#mi("\\Lambda_{> V} = \\mu_{\\leq U} * L + \\mu_{> U} * \\Lambda_{> V} * 1 - \\mu_{\\leq U} * \\Lambda_{\\leq V} * 1")

#text("with ")#mi("U=V=x^{1/3}")#text(" (say), there is no term that involves the convolution of five factors, and so the tuple ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" does not ")#emph[#text("explicitly")]#text(" appear in this decomposition. However, it appears ")#emph[#text("implicitly")]#text(", for instance through the component of ")#mi("\\mu_{> U} * \\Lambda_{> V} * 1")#text(" in which the first two terms are at scale ")#mi("x^{2/5}")#text(" and the last term is at scale ")#mi("x^{1/5}")#text(". This is a convolution of two rough sequences at scale ")#mi("x^{2/5}")#text(" and one smooth sequence at scale ")#mi("x^{1/5}")#text(", which is a pattern which can also be attained by a convolution ")#mi("\\psi_1 * \\psi_2 * \\psi_3 * \\psi_4 * \\psi_5")#text(" of five smooth sequences associated the tuple ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" by grouping together two pairs of the ")#mi("\\psi_i")#text(" together. Hence, if the former convolution can be treated by some “Type X” estimate, then the latter convolution can also be treated by the same estimate, and so we have not actually avoided the need to control the tuple ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" here. In order to do that, the decomposition would have to avoid not only any term which resembled the original convolution ")#mi("\\psi_1*\\psi_2*\\psi_3*\\psi_4*\\psi_5")#text(", but also any term that resembles some regrouping of this convolution, e.g. ")#mi("\\alpha * \\beta * \\psi_5")#text(" where ")#mi("\\alpha,\\beta")#text(" are rough sequences at scale ")#mi("x^{2/5}")#text(". It is an instructive exercise to verify that no matter how one chooses the parameters ")#mi("U,V")#text(" for the Vaughan identity, one cannot avoid some recombination of ")#mi("(1/5,1/5,1/5,1/5,1/5)")#text(" using this identity.")

#text("More generally, I now believe that given any tuple ")#mi("(t_1,\\ldots,t_n)")#text(" of strictly positive real numbers summing to one, any Heath-Brown or Vaughan-type decomposition of ")#mi("\\Lambda")#text(" must involve at least one component that resembles some recombination of the convolution ")#mi("\\psi_1 * \\ldots * \\psi_n")#text(" of smooth functions at scales ")#mi("x^{t_1},\\ldots,x^{t_n}")#text(" respectively, which basically means that one is forced to find enough Type X estimates to cover all such tuples ")#mi("(t_1,\\ldots,t_n)")#text(". I’ll illustrate this with the tuple ")#mi("(0.4,0.6)")#text(" for sake of concreteness, although the construction generalises of course to other tuples (after setting up a certain amount of notation).")

#text("Basically, the idea is to exploit duality, introducing a weight function ")#mi("f")#text(" (which one can think of as a sort of restricted, renormalised Mobius function) that correlates with ")#mi("\\Lambda")#text(", but does not correlate with any of the convolutions of the type that come out of a Heath-Brown or Vaughan type identity EXCEPT for those which resemble the tuple ")#mi("(0.4,0.6)")#text(" or a recombination thereof. Specifically, consider the function ")#mi("f: {\\bf N} \\to {\\bf R}")#text(" defined by setting")

#mi("f(pq) = +\\log p \\log q \\log^{2A_0} x")

#text("when ")#mi("p,q")#text(" are primes in ")#mi("[x^{0.4}, (1+\\log^{-A_0} x) x^{0.4}]")#text(" and ")#mi("[x^{0.6}, (1+\\log^{-A_0} x) x^{0.6}]")#text(" respectively, and")

#mi("f(p) = -\\log p \\log^{A_0} x")

#text("when ")#mi("p")#text(" is a prime in ")#mi("[x, (1+\\log^{-A_0} x) x]")#text(", and zero otherwise, where ")#mi("A_0")#text(" is a large fixed constant. The normalisations here have been set up so that f essentially has mean zero, indeed from the prime number theorem we see that")

#mi("\\sum_n f(n) \\psi(n) = O( x \\log^{-A_0+O(1)} x)")

#text("for any smooth coefficient sequence ")#mi("\\psi")#text(" at scale ")#mi("x")#text(". So ")#mi("f")#text(" basically does not correlate with any smooth coefficient sequence. Also, because ")#mi("f")#text(" is supported on numbers with at most two prime factors, ")#mi("f")#text(" does not correlate with any convolution of three or more non-trivial sequences (where “non-trivial” means “not supported at 1), and can only correlate with a convolution of two sequences at scale ")#mi("x^{t_1}, x^{t_2}")#text(" respectively if ")#mi("t_1,t_2")#text(" are basically equal to ")#mi("0.4,0.6")#text(" up to permutations. On the other hand, ")#mi("f")#text(" has a strong correlation with ")#mi("\\Lambda(n)")#text(":")

#tao-math("\\left|\\sum_n f(n) \\Lambda(n)\\right| \\sim x \\log x.", block: false)

#text("Thus, regardless of how one splits up ")#mi("\\Lambda")#text(" into convolutions of various coefficient sequences at various scales, at least one of the convolutions thus obtained must either be a rough sequence at scale ")#mi("x")#text(", or else the convolution of two sequences at scale ")#mi("x^{0.4}")#text(" and ")#mi("x^{0.6}")#text(". Controlling either of these two types of sequences by some Type X estimate would also imply the ability to control a convolution ")#mi("\\psi_1 * \\psi_2")#text(" of two smooth sequences at scales ")#mi("x^{0.4}, x^{0.6}")#text(" respectively, and so we must somehow be able to cover the tuple ")#mi("(0.4,0.6)")#text(" by some Type X estimate.")

#text("There are similar arguments for longer tuples but it gets messy. For instance, for the tuple ")#mi("(0.1,0.3,0.6)")#text(", one would want to choose a function ")#mi("f")#text(" with")

#mi("f(pqr) = +\\log p \\log q \\log r \\log^{3A_0} x")

#text("if ")#mi("p,q,r")#text(" are primes in ")#mi("[x^{0.1}, (1+\\log^{-A_0} x) x^{0.1}]")#text(", ")#mi("[x^{0.3}, (1+\\log^{-A_0} x) x^{0.3}]")#text(", ")#mi("[x^{0.6}, (1+\\log^{-A_0} x) x^{0.6}]")#text(" respectively,")

#mi("f(pq) = - \\log p \\log q \\log^{2A_0} x")

#text("if ")#mi("p,q")#text(" are primes in ")#mi("[x^{0.1+0.3}, (1+\\log^{-A_0} x) x^{0.1+0.3}]")#text(", ")#mi("[x^{0.6}, (1+\\log^{-A_0} x) x^{0.6}]")#text(" respectively, and similarly for two other ways to concatenate the tuple ")#mi("(0.1,0.3,0.6)")#text(", and finally")

#mi("f(p) = + \\log p \\log^{A_0} x")

#text("when ")#mi("p")#text(" is a prime in ")#mi("[x, (1+\\log^{-A_0} x) x]")#text(". Then one can show that the only sequences coming out of a Heath-Brown type decomposition that can correlate strongly with ")#mi("f")#text(" are either smooth at scale ")#mi("x")#text(", or convolutions ")#mi("\\alpha * \\beta")#text(" where ")#mi("\\alpha")#text(" is rough at scale ")#mi("x^{0.1+0.3}")#text(" and ")#mi("\\beta")#text(" is at scale ")#mi("x^{0.6}")#text(" (or permutations thereof), or convolutions ")#mi("\\alpha_1*\\alpha_2*\\alpha_3")#text(" where ")#mi("\\alpha_1,\\alpha_2,\\alpha_3")#text(" are at scales ")#mi("x^{0.1}, x^{0.3}, x^{0.6}")#text(" (or permutations thereof). If a Type X estimate can handle any of these expressions, it can also handle the convolution ")#mi("\\psi_1*\\psi_2*\\psi_3")#text(" of smooth sequences at scales ")#mi("x^{0.1}, x^{0.3}, x^{0.6}")#text(" respectively, proving that one has to be able to cover the tuple ")#mi("(0.1,0.3,0.6)")#text(" in any argument of this type.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29ffcd3147edb0dd4c82b549d3e3e551146b2f5f7f14defcbcf664b98ce0eb1d-2c5a7e1a4e5e07d382fdbbd8886d3aad5e179a86580a9d10af603fa9fa0353a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike Ruxton")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238781")[#strong[#text("Mike Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")])]

#text("In the polymath wiki, the distribution result is listed as")

#text("280/3 omega bar + 70/3 delta")

#text("while your theorem 1 has 80/3 delta.")

#emph[#text("[Oops, that was a typo on the wiki; corrected now, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("I’m recording some elementary facts about “multiple dense divisibility”, which I think will be needed in order to flesh out the most recent refinement to the Type I estimates from ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")]#text(" (in particular, a back-of-the-envelope calculation suggests that quadruple dense divisibility is needed here).")

#text("First, the definition. Fix ")#mi("y \\geq 1")#text(". We define the notion of a ")#mi("k")#text("-tuply ")#mi("y")#text("-densely divisible natural number ")#mi("n")#text(" recursively as follows: every natural number is ")#mi("0")#text("-tuply ")#mi("y")#text("-densely divisible, and if ")#mi("k \\geq 1")#text(", we call ")#mi("n")#text(" ")#mi("k")#text("-tuply ")#mi("y")#text("-densely divisible if, for every ")#mi("i,j \\geq 0")#text(" with ")#mi("i+j < k")#text(" and every ")#mi("1 \\leq R \\leq n")#text(", one can find a factorisation ")#mi("n = qr")#text(" with ")#mi("q \\in [y^{-1} R, R]")#text(", ")#mi("q")#text(" ")#mi("i")#text("-tuply ")#mi("y")#text("-densely divisible, and ")#mi("r")#text(" ")#mi("j")#text("-tuply ")#mi("y")#text("-densely divisible.")

#text("Some easy facts:")

#text("* ")#mi("k+1")#text("-tuply ")#mi("y")#text("-dense divisibility implies ")#mi("k")#text("-tuply ")#mi("y")#text("-dense divisibility.")

#text("* ")#mi("y")#text("-smooth numbers are ")#mi("k")#text("-tuply ")#mi("y")#text("-dense divisible for every ")#mi("k")#text(" (and conversely).")

#text("* More generally, if ")#mi("n")#text(" is square-free and ")#mi("z")#text("-smooth for some ")#mi("z \\geq y")#text(" and ")#mi("\\prod_{p \\leq y: p|n} p \\geq \\min( (z/y)^k, n )")#text(", then ")#mi("n")#text(" is ")#mi("k")#text("-tuply ")#mi("y")#text("-densely divisible.")

#text("* If ")#mi("n")#text(" is ")#mi("k")#text("-tuply ")#mi("y")#text("-densely divisible and ")#mi("m")#text(" is a factor of ")#mi("n")#text(", then ")#mi("m")#text(" is ")#mi("k")#text("-tuply ")#mi("y(n/m)")#text("-densely divisible.")

#text("I also conjecture that the least common multiple of two ")#mi("k")#text("-tuply ")#mi("y")#text("-densely divisible natural numbers is again ")#mi("k")#text("-tuply ")#mi("y")#text("-densely divisible (this will be convenient in some arguments). I can prove this for ")#mi("k=1")#text(" currently. (If this turns out to fail, then we may end up redefining ")#mi("k")#text("-tuple ")#mi("y")#text("-dense divisibility using the criterion ")#mi("\\prod_{p \\leq y: p|n} p \\geq \\min( (z/y)^k, n )")#text(" instead, since this is certainly preserved by least common multiple.")

#text("The sieve machinery that lets us reduce to single or double dense divisibility also lets us reduce to ")#mi("k")#text("-tuply ")#mi("x^\\delta")#text("-dense divisibility as well, the only difference being that the quantity ")#mi("\\tilde \\theta")#text(" now needs to be set equal to ")#mi("\\frac{k(\\delta^{\\prime}-\\delta)/2+\\varpi}{1/4+\\varpi}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238890")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("A suggestion and some typos:")

#text("1. A few lines below (34) you use your earlier observation that if ")#mi("a, b")#text(" are both ")#mi("y")#text("-densely divisible, then ")#mi("[a,b]")#text(" is also ")#mi("y")#text("-densely divisible (")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236387")]#text("). For the sake of the reader I would reproduce the proof here.")

#text("2. In (22), ")#mi("a_{qr}")#text(" should be ")#mi("a")#text(".")

#text("3. In the display below (24), the condition ")#mi("(n,q)=1")#text(" can be deleted.")

#text("4. In (25) and the preceding display, ")#mi("n=a\\ (r)")#text(" should be ")#mi("mn=a\\ (r)")#text(".")

#text("5. In the display below (26), ")#mi("c_{q_1} c_{q_2} \\overline{\\beta(n_1)} \\overline{\\beta(n_2)}")#text(" should be ")#mi("c_{q_1} \\overline{c_{q_2}} \\beta(n_1) \\overline{\\beta(n_2)}")#text(".")

#text("6. In (32), ")#mi("q_1r,q_2r \\in {\\mathcal D}_{x^\\delta}")#text(" should be ")#mi("q_1,q_2 \\in {\\mathcal D}_{x^\\delta}")#text(".")

#text("7. In the second line below (32), ")#mi("(q_1,q_2)")#text(" should be ")#mi("(q_1,q_2)=1")#text(".")

#text("8. In the fifth display below (32), ")#mi("\\Phi(h,q_1,q_2; n)")#text(" should be ")#mi("\\Phi_{k,r}(h,q_1,q_2; n)")#text(".")

#text("9. In the seventh display below (33), the condition “")#mi("s_1 \\sim S; t_1 \\sim T; q_2 \\sim Q")#text("” should be “")#mi("s^{\\prime}_1 \\sim S; t^{\\prime}_1 \\sim T; q^{\\prime}_2 \\sim Q/q_0")#text("“.")

#text("10. In the display before (34), ")#mi("\\psi_N")#text(" should be ")#mi("\\psi_N(n)")#text(".")

#text("11. In (34), the condition “")#mi("t_1,\\tilde t_1 \\sim T; s_1 \\sim S; q_2 \\sim Q/q_0")#text("” should be “")#mi("t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0")#text("“.")

#text("12. In the three lines following (34), ")#mi("h \\tilde t_1 = \\tilde h t_1")#text(" (resp. ")#mi("h\\tilde t_1 \\neq \\tilde ht_1")#text(") should be ")#mi("h \\tilde t^{\\prime}_1 = \\tilde h t^{\\prime}_1")#text(" (resp. ")#mi("h\\tilde t^{\\prime}_1 \\neq \\tilde ht^{\\prime}_1")#text("), and ")#mi("T \\gtrapprox H")#text(" should be ")#mi("q_0 T \\gtrapprox H")#text(".")

#text("13. In the second and fourth display below (34), ")#mi("h\\tilde t_1-\\tilde ht_1")#text(" should be ")#mi("h\\tilde t^{\\prime}_1-\\tilde ht^{\\prime}_1")#text(".")

#text("14. In the fifth display below (34), the condition “")#mi("t_1,\\tilde t_1 \\sim T: h \\tilde t_1 \\neq \\tilde h t_1")#text("” should be “")#mi("t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T: h \\tilde t^{\\prime}_1 \\neq \\tilde h t^{\\prime}_1")#text("“, the condition “")#mi("s_1 \\sim S; q_2 \\sim Q/q_0")#text("” should be “")#mi("s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0")#text("“, and ")#mi("h\\tilde t_1-\\tilde ht_1")#text(" should be ")#mi("h\\tilde t^{\\prime}_1-\\tilde ht^{\\prime}_1")#text(".")

#text("15. In the ninth and tenth line below (34), “")#mi("rq_0 s^{\\prime}_1 t^{\\prime}_2")#text(" and ")#mi("q^{\\prime}_0 \\tilde q^{\\prime}_2")#text("” should be “")#mi("rq_0 s^{\\prime}_1 \\tilde t^{\\prime}_1")#text(" and ")#mi("q_0 q^{\\prime}_2")#text("“, and ")#mi("[rq_0 s^{\\prime}_1 t^{\\prime}_1 \\tilde t^{\\prime}_1,q^{\\prime}_0 q^{\\prime}_2]")#text(" should be ")#mi("[rq_0 s^{\\prime}_1 t^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2]")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239017")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Dear Terry, a further suggestion and some typos:")

#text("16. As we need the condition ")#mi("q_1r,q_2r \\in {\\mathcal D}_{x^\\delta}")#text(" in (32) for later purposes, we should impose ")#mi("qr \\in {\\mathcal D}_{x^\\delta}")#text(" as a condition on ")#mi("r")#text(" from the display before (20) up to (22), then as a condition on ")#mi("q")#text(" from (23) to (25). Finally, from (26) to (30) we should add the condition ")#mi("q_1r,q_2r \\in {\\mathcal D}_{x^\\delta}")#text(" as well.")

#text("17. In the seventh display below (33), ")#mi("q^{\\prime}_2 \\sim Q")#text(" should be ")#mi("q^{\\prime}_2 \\sim Q/q_0")#text(".")

#text("18. In the second line following (34), ")#mi("T \\gtrapprox H")#text(" should be ")#mi("q_0 T \\gtrapprox H")#text(".")

#text("19. Correction #14 has not been implemented.")

#text("20. In the ninth line below (34), ")#mi("q_0 \\tilde q^{\\prime}_2")#text(" should be ")#mi("q_0 q^{\\prime}_2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239061")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Two related suggestions and a typo:")

#text("1. I wonder if the case ")#mi("P(t)=0")#text(" was meant to be included in Proposition 10. Perhaps not, because the degree is usually not defined for the zero polynomial. At any rate, it would be useful to clarify, because while the statement is valid in this case, the proof is not. Specifically, the display following (14) fails when ")#mi("P(t)=0")#text(". In fact, already at the beginning, we cannot achieve ")#mi("(f,q)=1")#text(" when ")#mi("P(t)=0")#text(".")

#text("2. Shortly before (14) we infer that ")#mi("p|f")#text(" if ")#mi("p")#text(" is sufficiently large. The way I see it, we don’t need to assume here that ")#mi("p")#text(" is sufficiently large, because ")#mi("Q(t)")#text(" is monic. In fact the largeness assumption might cause subtle uniformity issues, because the implied constant in Proposition 10 must not depend on the actual coefficients of ")#mi("P(t)")#text(" and ")#mi("Q(t)")#text(". On the other hand, ")#mi("p|f")#text(" contradicts the initial assumption that ")#mi("(f,q)=1")#text(", so everything is fine. In fact this way we obtain the stronger conclusion")

#mi("(q_2 \\ldots q_l, \\overline{q_1} (f(\\cdot+kq_1) - f(\\cdot+k^{\\prime}q_1) )) \\leq (q_2 \\ldots q_l, k-k^{\\prime})")#text(",")

#text("and I think we need this stronger conclusion.")

#text("3. In the fifth display below (34), ")#mi("s_1 \\sim S")#text(" should be ")#mi("s^{\\prime}_1 \\sim S")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239063")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("1. Actually I think the f=0 case is fine. With the conventions given, (f,q) is equal to q when f vanishes, and the initial reductions in the case land one in the trivial setting q=1.")

#text("2. Unfortunately I don’t think we can remove the sufficiently large hypothesis. For instance if ")#mi("f(x) = \\frac{1}{x^p-x+1}")#text(" then ")#mi("p | f(x+1)-f(x)")#text(" but ")#mi("p \\not | f")#text(" even though ")#mi("f")#text(" ostensibly vanishes at infinity. On the other hand, the implied constant in “sufficiently large” depends only on the degree of f and not on the coefficients (it’s the number of poles and zeroes of f that are the problem), so I don’t think the uniformity is an issue. I’ve adjusted the text slightly to emphasise this.")

#text("3. Corrected, thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239070")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Thank you! You are absolutely right, I overlooked silly things like: ")#mi("q/q=1")#text(" or that a polynomial that is nonzero mod ")#mi("p")#text(" can still vanish mod ")#mi("p")#text(" at every integer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239075")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Actually the initial reduction that ")#mi("q")#text(" has no prime factor less than ")#mi("C")#text(" can be used to infer that ")#mi("p|(f,q)")#text(", contradicting ")#mi("(f,q)=1")#text(", whence")

#mi("(q_2 \\ldots q_l, \\overline{q_1} (f(\\cdot+kq_1) - f(\\cdot+k^{\\prime}q_1) )) \\leq (q_2 \\ldots q_l, k-k^{\\prime})")#text(".")

#text("This is a very minor point, but it makes the argument more structured and easier to follow.")

#emph[#text("[Fair enough – I’ve adjusted the text accordingly. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239139")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Some small suggestions:")

#text("1. In (32) I would change ")#mi("{\\mathcal D}_{x^\\delta}")#text(" to ")#mi("{\\mathcal S}_{[1,\\infty)} \\cap {\\mathcal D}_{x^\\delta}")#text(" to avoid some necessary restrictions later. For example, without this change we would need further coprimality assumptions in (34) to guarantee the square-freeness of the moduli ")#mi("r q_0 s^{\\prime}_1 t^{\\prime}_1 \\tilde t^{\\prime}_1")#text(" and ")#mi("q_0 q^{\\prime}_2")#text(" later (see also item 4 below).")

#text("2. If the previous suggestion is implemented, in (32) ")#mi("(q_1,r)=(q_2,r)=1")#text(" can be deleted. Moreover, in (33) ")#mi("(q_0,q^{\\prime}_1)=(q_0,q^{\\prime}_2)=1")#text(" and seven displays later ")#mi("(q_0,s^{\\prime}_1t^{\\prime}_1) = (q_0,q^{\\prime}_2) = 1")#text(" can be deleted.")

#text("3. In (34) I would add the condition ")#mi("(s^{\\prime}_1 t^{\\prime}_1 \\tilde t^{\\prime}_1,q^{\\prime}_2) = 1")#text(" as it seems necessary to ensure the relation ")#mi("(c_1,r) = (h\\tilde t^{\\prime}_1-\\tilde ht^{\\prime}_1, r)")#text(" later.")

#text("4. In the display below (34), I would change ")#mi("t^{\\prime}_1\\tilde t^{\\prime}_1")#text(" to ")#mi("[t^{\\prime}_1,\\tilde t^{\\prime}_1]")#text(" to ensure the square-freeness of the moduli necessary for Corollary 11 (see also item 1 above).")

#text("5. In the endgame of the proof of Proposition 10, ")#mi("1_{N > q_2 \\ldots q_l / (q_2 \\ldots q_l, k-k^{\\prime})}")#text(" should be ")#mi("1_{N \\geq q_2 \\ldots q_l / (q_2 \\ldots q_l, k-k^{\\prime})}")#text(": three occurrences.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239146")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Further small suggestions and typos:")

#text("6. If item 1 is implemented, in the first, fourth, and fifth display of Section 3, ")#mi("(q_0,q^{\\prime}_1)=(q_0,q^{\\prime}_2)=1")#text(" can be deleted. Moreover, in the sixth and eight display of Section 3, ")#mi("(q_0,q^{\\prime}_1 q^{\\prime}_2 \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2) = 1")#text(" can be deleted.")

#text("7. In the fourth display below (35), ")#mi("\\Phi(\\tilde h,q_0 \\tilde q^{\\prime}_1,q_0 \\tilde q^{\\prime}_2; n)")#text(" should be conjugated.")

#text("8. The fifth display below (35) should read")

#mi("1_{b/n=b^{\\prime}/(n+kr)\\ (q_0)} e_{r q_0 [q^{\\prime}_1, \\tilde q^{\\prime}_1]}(\\frac{c_1}{n} ) e_{q_0 [q^{\\prime}_2, \\tilde q^{\\prime}_2]}(\\frac{c_2}{n+kr} )")#text(".")

#text("9. In Line 25 of Section 3, ")#mi("\\lessapprox H (Q/q_0)^2")#text(" should be ")#mi("\\lessapprox HN (Q/q_0)^2")#text(". In the next line, ")#mi("h \\tilde q^{\\prime}_1 \\tilde q^{\\prime}_2 = \\tilde h q^{\\prime}_1 q^{\\prime}_2")#text(" should be negated. In the next line, ")#mi("\\Phi(\\tilde h,q_0 \\tilde q^{\\prime}_1,q_0 \\tilde q^{\\prime}_2; n)")#text(" should be conjugated, and “taks” should be “takes”.")

#text("10. In the seventh display below (33) we may write ")#mi("\\Phi")#text(" for ")#mi("\\Phi_{k,r}")#text(".")

#emph[#text("[Corrected, thanks -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239151")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("In the page “Dickson-Hardy-Littlewood theorems”, all the criteria for conversion to DHL demand (implicitly) the (necessary) condition")#linebreak()#text(" ")#mi("j_{k_0 - 2}^2 < 2 k_0 (k_0  - 1)")#text(" which is not satisfied for ")#mi("k_0 < 6")#text(".")#linebreak()#text(" Perhaps a remark about it should be added to this page.")

#emph[#text("[I added a remark to this effect. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5e9db5caa41183da5e149d0a6584ea1262a42810f968b4e4c364925a18ea0cc-1aec633d5d4d91eecda2a731789a66d0dd9730d7af7d75fee50917b4dbf464d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Lantern")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239164")[#strong[#text("George Lantern")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Hello Terence,")#linebreak()#text(" What do you think of this conjecture I found when I was reading at viXra.org ")#link("http://vixra.org/abs/1307.0081")[#text("http://vixra.org/abs/1307.0081")]#linebreak()#text(" Greetings from US.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db1f526501244b3f451f7ceccd3aa3c0fa70ca62f0de63d7465ffa53a8d89fc-31a323d2d777b850f268092fd6cb2aaf1443e23586c8a858ab5fce2c700f6386.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mangas & Maths²")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239177")[#strong[#text("Mangas & Maths²")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("very interesting george thanks for sharing ;-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239169")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Dear Terry, thanks for the new post on l-adic sheaves! Thanks for implementing my numerous small comments as well. Here is a new list:")

#text("1. The notation ")#mi("b")#text(" is a bit ambiguous for me, starting with Lemma 14. The original definition is ")#mi("b:=\\text{rad}(b_1 b_2 b_3)")#text(", but this is not emphasized in Lemma 14, and in fact the symbol ")#mi("b")#text(" plays two roles there. Likewise, in the third display below Lemma 14, the relation of ")#mi("b")#text(" to ")#mi("b_1,b_2,b_3")#text(" is not explained. More importantly, (41) and the text below it suggest that ")#mi("Q_b")#text(" is meant to be ")#mi("\\frac{Q}{b}=\\frac{Q}{\\text{rad}(b_1 b_2 b_3)}")#text(" instead of what its definition below (40) says. I think the definition of ")#mi("y")#text(" should be updated in a similar fashion, i.e. it should be ")#mi("x^\\delta b=x^\\delta \\text{rad}(b_1 b_2 b_3)")#text(". Finally, the notation ")#mi("H_b")#text(" is also a bit confusing, because it does not really depend on ")#mi("b")#text(" but on ")#mi("b_1b_2b_3")#text(".")

#text("2. In the first display of Section 4, ")#mi("(1+O(x^{-\\epsilon}) Q")#text(" should be ")#mi("(1+O(x^{-\\epsilon})) Q")#text(". In the next display, the lower bound should be ")#mi("x^{1/2} \\lessapprox Q")#text(". In the next display, ")#mi("rs")#text(" should be ")#mi("q")#text(".")

#text("3. Seven lines below (37), I would add “by Poisson summation and integration by parts” for the sake of the reader.")

#text("4. In the sixth display below (37), ")#mi("rs")#text(" should be ")#mi("q")#text(".")

#text("5. In the display before (38), ")#mi("\\sum_m \\alpha_{m: (m,q)=1}")#text(" should be ")#mi("\\sum_{m: (m,q)=1} \\alpha(m)")#text(".")

#text("6. The display before Lemma 14 is missing the normalisation factor ")#mi("\\frac{1}{q}")#text(". In fact this quantity was already defined in (15).")

#text("7. In the display after Lemma 14, the denominator should be ")#mi("p^2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239175")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("1. OK, so ")#mi("Q_{\\vec b}")#text(" is not ")#mi("Q/b")#text(" as I thought. But then I don’t understand why ")#mi("rs \\sim Q_{\\vec b}")#text(", as stated four lines below (41). I thought that ")#mi("q=bq^{\\prime}=brs= (1 + O(x^{-\\epsilon})) Q")#text(", whence ")#mi("rs \\sim Q/b")#text(". Also, I don’t understand why we may assume that ")#mi("Q_{\\vec b} \\gg 1")#text(" with the current definition of ")#mi("Q_{\\vec b}")#text(", as stated by (41). Sorry if I am missing the obvious.")

#text("2. I think the fifth display below (35) is still not right. It should be")

#mi("1_{b/n=b^{\\prime}/(n+kr)\\ (q_0)} e_{r q_0 [q^{\\prime}_1, \\tilde q^{\\prime}_1]}(\\frac{c_1}{n} ) e_{q_0 [q^{\\prime}_2, \\tilde q^{\\prime}_2]}(\\frac{c_2}{n+kr} )")#text(".")

#text("3. In the fifth display above (38), ")#mi("n^{-\\epsilon}")#text(" should be ")#mi("x^{-\\epsilon}")#text(".")

#emph[#text("[Sorry about that – I was in the process of fixing a problem with my previous correction, it should be all right now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("I’m recording some calculations to obtain more precise numerology on what the proposed improvement ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238186")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238186")]#text(" in the exponential sum estimates would give for ")#mi("\\varpi,\\delta")#text(", assuming quadruple dense divisibility (which means that ")#mi("\\tilde \\theta")#text(" is now taken to be ")#mi("\\frac{2(\\delta^{\\prime}-\\delta)+\\varpi}{1/4+\\varpi}")#text("). I’m going to skip some of the details which I believe will not affect the numerology.")

#text("We will assume the following Deligne-level estimate: if ")#mi("p")#text(" is a large prime and ")#mi("K")#text(" is the Kloosterman-type sum")

#mi("K(a,b,h;p) := \\frac{1}{\\sqrt{p}} \\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p( \\frac{a}{n(n+b)} + hn)")

#text("then one has")

#tao-math("\\left|\\sum_{b \\in {\\bf Z}/p{\\bf Z}} K(a,b+l,h;p) \\overline{K(a,b,h,p)} e_p( kl )\\right| \\ll \\sqrt{p}", block: false)

#text("for any ")#mi("a,h,k \\in {\\bf Z}/p{\\bf Z} \\backslash \\{0\\}")#text(". This is roughly comparable in strength to the Bombieri-Birch estimate, but I was not able to reduce this estimate to known estimates.")

#text("Anyway, to the numerology. We repeat the argument in the blog post up to equation (34), but retain the averaging in ")#mi("r")#text("; for simplicity we work in the case ")#mi("q_0=1")#text(", which should be dominant. Our task is then basically to show that")

#mi("{\\bf E}_{r \\sim R; h,\\tilde h \\sim H; s_1 \\sim S; t_1,\\tilde t_1 \\sim T; q_2 \\sim Q}")#linebreak()#text(" ")#tao-math("\\left|\\sum_n \\psi_N(n) \\Phi_{k,r}(h,s_1t_1,q_2;n) \\overline{\\Phi_{k,r}(\\tilde h,s_1\\tilde t_1,q_2;n)}\\right| \\lessapprox H^{-2} N.", block: false)

#text("If we assume the original moduli to be quadruply ")#mi("x^\\delta")#text("-densely divisible, one can assume that ")#mi("r")#text(" is doubly densely divisible and the ")#mi("q")#text(" variables are densely divisible, which was already needed to obtain the factorisation of ")#mi("q_1")#text(" into ")#mi("s_1")#text(" and ")#mi("t_1")#text(" variables.")

#text("We now split ")#mi("r = d_1 r^{\\prime}")#text(" where ")#mi("x^{-\\delta} D_1 \\lessapprox d_1 \\lessapprox D_1")#text(" and ")#mi("1 \\lessapprox D_1 \\lessapprox R")#text(" is to be chosen later, and ")#mi("r^{\\prime}")#text(" is densely divisible. Throwing away most of the averages, we need to show")

#mi("{\\bf E}_{d_1 \\sim D} |\\sum_n \\psi_N(n) \\Psi(d_1,n)| \\lessapprox H^{-2} N")

#text("for typical values of ")#mi("r^{\\prime},h,\\tilde h, s_1, t_1, \\tilde t_1, q_2")#text(" and some ")#mi("x^{-\\delta} D_1 \\lessapprox D \\lessapprox D_1")#text(", where")

#mi("\\Psi(d_1,n) := \\Phi_{k,d_1 r^{\\prime}}(h,s_1t_1,q_2;n) \\overline{\\Phi_{k,d_1r^{\\prime}}(\\tilde h,s_1\\tilde t_1,q_2;n)}")#text(".")

#text("We apply van der Corput and reduce to showing that")

#tao-math("\\left|{\\bf E}_{d_1 \\sim D} {\\bf E}_{l = O( N/D)} \\sum_n \\tilde \\psi_N(n) \\Psi(d_1,n+ld_1) \\overline{\\Psi(d_1,n)}\\right| \\lessapprox H^{-4} N.", block: false)

#text("The diagonal case ")#mi("l=0")#text(" contributes ")#mi("O( \\frac{D}{N} N )")#text(", so we need")

#mi("D_1 \\lessapprox H^{-4} N.")#text(" (*)")

#text("For the off-diagonal case, we complete sums in the n variable, noting that ")#mi("\\Psi(d_1,n+ld_1) \\overline{\\Psi(d_1,n)}")#text(" is periodic with period ")#mi("d_2 := r^{\\prime} s_1 [t_1,t^{\\prime}_1] q_2")#text(", and reduce to showing that")

#tao-math("\\left|\\sum_{d_1 \\sim D} \\sum_{n \\in {\\bf Z}/d_2{\\bf Z}} \\Psi(d_1,n+ld_1) \\overline{\\Psi(d_1,n)} e_{d_2}( mn )\\right| \\lessapprox H^{-4} D N", block: false)

#text("for arbitrary ")#mi("m")#text(". By construction, ")#mi("d_2")#text(" is ")#mi("x^\\delta")#text("-densely divisible. Using van der Corput and assuming the Deligne level estimates, the left-hand side may be bounded by")

#mi("d_2^{1/2} \\times D^{1/2} x^{\\delta/6} d_2^{1/6}")

#text("so we need")

#mi("(d_2 D)^{2/3} x^{\\delta/6} \\lessapprox H^{-4} D^{7/6} N")#text(".")

#text("We can bound ")#mi("d_2 D \\lessapprox R S T^2 Q")#text(" and ")#mi("D \\gtrapprox x^{-\\delta} D_1")#text(", so we need")

#mi("(RST^2 Q)^{2/3} x^{\\delta/6} \\lessapprox H^{-4} x^{-7\\delta/6} D_1^{7/6} N")#text(".")

#text("Combining this with (*) we reduce to")

#mi("(RST^2 Q)^{2/3} x^{\\delta/6} \\lessapprox H^{-4} x^{-7\\delta/6} (H^{-4} N)^{7/6} N")#text(".")

#text("Since ")#mi("T \\lessapprox x^\\delta H,")#text("latex ST \\sim Q$, we reduce to")

#mi("(RQ^2 H x^{\\delta})^{2/3} x^{\\delta/6} \\lessapprox H^{-4} x^{-7\\delta/6} (H^{-4} N)^{7/6} N")

#text("which we rearrange as")

#mi("x^{2\\delta} H^{28/3} R^{2/3} Q^{4/3} \\lessapprox N^{13/6}.")

#text("Since ")#mi("H")#text(" is basically ")#mi("Q^2 R/M \\lessapprox x^{4\\varpi+\\delta}")#text(", and ")#mi("Q \\lessapprox x^{1/2+2\\varpi}/R")#text(", this becomes")

#mi("x^{34\\delta/3} x^{112\\varpi/3}  R^{-2/3} x^{4/3 (1/2+2\\varpi)} \\lessapprox N^{13/6}")

#text("which (since ")#mi("R^{-2/3} \\lessapprox N^{-2/3} x^{2\\delta/3}")#text(") becomes")

#mi("x^{12\\delta} x^{40\\varpi} x^{2/3} \\lessapprox N^{17/6};")

#text("since ")#mi("N \\gtrapprox x^{1/2-\\sigma}")#text(", this becomes (after some algebra)")

#mi("\\frac{160}{3} \\varpi + 16 \\delta + \\frac{34}{9} \\sigma < 1")#text(";")

#text("setting ")#mi("\\sigma=1/10")#text(", this becomes")

#mi("\\frac{600}{7} \\varpi + \\frac{180}{7} \\delta < 1")#text(".")

#text("As mentioned previously, this should lead to ")#mi("k_0")#text(" roughly around 630, keeping in mind that one has to adjust ")#mi("\\tilde \\theta")#text(" to ensure quadruple dense divisibility.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239223")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Two quick novice-level questions:")

#text("1) Is this refinement essentially what is referred to as “Type I level 5” on the wiki, or does that refinement still potentially exist as a next step?")

#text("2) Given the exhaustion of options in Type I and the consequent need to focus on somehow reducing sigma, I’m curious at the lack of response to Pace Nielsen’s comment ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238723")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238723")]#text(" . Is it obviated by Terry’s comment posted just five minutes later? If not, and if there is indeed some mysterious reason why a Type V situation is impossible, is that the lowest-hanging fruit at this point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239232")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("1) Yes, one could view this as partially realising the idea behind the Level 5 Type I estimate, although the original version of this idea didn’t quite work; it tried to push additional averaging, e.g. over ")#mi("r")#text(" parameters, inside the Cauchy-Schwarz to reduce the diagonal terms, which it does do, but this makes the off-diagonal terms much worse because these the modulus varies with these parameters and one is left with a sum over a much larger modulus, which is undesirable. However the ")#mi("r")#text(" averaging can be partially used after applying a van der Corput to modify the modulus to the point where it does not depend on one of the factors ")#mi("d_1")#text(" of ")#mi("r")#text(", and then one can safely exploit averaging in the ")#mi("d_1")#text(" parameter. (There is a related idea of Fouvry and Iwaniec that was pointed out to me by Philippe.) I’ve updated the wiki to reflect this.")

#text("2) The stumbling block is having to invent a new type of estimate – a Type V estimate – to deal with the convolution of five smooth but very short sequences. The only way we know how to do this is to combine some of the short sequences into rough sequences and then use the Type I arguments; the Type III arguments (which can control the convolution of three smooth and medium-length sequences) don’t seem to give a favorable numerology in the quintuple convolution setting (even the quadruple convolution case makes this argument only recover the Bombieri-Vinogradov type bound). There’s a more general problem with exponential sum estimates in that very short averages are quite difficult to exploit, even if there are many of them; the main trick to exploit such averages is to combine many of them together into one long average (weighted by some divisor function which is then eliminated by a Cauchy-Schwarz), but one has to perform at least one completion of sums trick before one can do this, and when one is convolving many short sequences together this becomes very expensive. It may be that one will have to wait for a radically new technique for controlling exponential sums to be discovered before one can start making Type V estimates that are competitive with the existing Type I, II, III estimates in the parameter ranges of interest.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239236")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("1) Thanks! 2) Well sure, but what I was referring to was this comment from Pace: “Here is something I tried to figure out but couldn’t make it work. Does the Type V decomposition actually occur in the cases we care about? That is, when utilizing the Heath-Brown decomposition, can we have exactly 5 smooth terms, each roughly of scale x^{1/5}?”. I am far from being able to know in sufficient detail just what are “the cases we care about”, but is there anything in this? Maybe Pace could elaborate?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239246")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("@Aubrey,")

#text("Terry’s post five minutes after mine was exactly the type of thing I was asking after. It appears that we cannot simply avoid consideration of the Type V case; it does actually occur in practice.")

#text("Thus, as far as I understand it, the only easy/likely way we currently can improve the estimates is by directly improving the numerics in the Type I case.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239247")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("In the specific case of the Heath-Brown identity")

#mi("\\Lambda = \\sum_{j=1}^K (-1)^{j-1} \\binom{K}{j} \\mu_{\\leq x^{1/K}}^{*j} * 1^{*j-1} * L")

#text("the Type V sum arises as follows. If ")#mi("K \\geq 5")#text(", then the ")#mi("j=5")#text(" term contains, among other things, a component of the form ")#mi("1 * 1 * 1 * 1 * L")#text(", which on dyadic decomposition gives Type V sums, including the most critical one where all five components are at scale ")#mi("x^{1/5}")#text(". For smaller values of ")#mi("K")#text(", the Type V sums are more implicit. For instance, when ")#mi("K=4")#text(", we have a term of the form ")#mi("\\mu_{\\leq x^{1/4}} * 1 * 1 * 1 * L")#text(" which is actually worse than a Type V sum because one of the factors is rough instead of smooth, and for which all five components can be at scale ")#mi("x^{1/5}")#text(". Similarly for ")#mi("K=3")#text(" and ")#mi("\\mu_{\\leq x^{1/3}} * \\mu_{\\leq x^{1/3}} * 1 * 1 * L")#text(". For ")#mi("K=2")#text(", we have a term of the form ")#mi("\\mu_{\\leq x^{1/2}} * \\mu_{\\leq x^{1/2}} * 1 * L")#text(", which among other things contains the convolution of a rough sequence at scale ")#mi("x^{2/5}")#text(", a rough sequence at scale ")#mi("x^{1/5}")#text(", and two smooth sequences at scale ")#mi("x^{1/5}")#text(" which is a worse convolution to deal with than five smooth convolutions at scale ")#mi("x^{1/5}")#text(" (since the latter type of convolution is a subcase of the former). Similarly for ")#mi("K=1")#text(" and ")#mi("\\mu * L")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239248")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Thanks! And anyway, I note that reducing sigma has become almost non-beneficial with the latest type I improvement (I’m getting 123/1318 or about 1/10.7 for the optimal sigma, with varpi at 8/659 if that sigma were permitted), pending any Type III improvements.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239251")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("Dear Terry, congratulations to this amazing post. I have verified everything carefully, so all the question marks at the relevant Wiki pages can be deleted.")

#text("Here is a list of minor suggestions and corrections:")

#text("1. In Lemma 13 we should make clear that ")#mi("h")#text(" runs through integers coprime with ")#mi("r_1r_2s")#text(".")

#text("2. In the second display below (42), the conditions ")#mi("(r_1r_2s,b)=1")#text(" and ")#mi("(h,r_1r_2s)=1")#text(" are missing. More importantly, the factor ")#mi("\\tilde c^{\\prime}_{br_1s} \\overline{\\tilde c^{\\prime}_{br_2s}}")#text(" is missing.")

#text("3. In the fifth display below (42), I would add the condition ")#mi("(r_1r_2s,b)=1")#text(" for clarity, although formally speaking this is not necessary.")

#text("4. In the seventh display below (42), the condition ")#mi("m_1 r_1^3 - m_2 r_2^3 \\neq 0")#text(" is missing.")

#text("5. In the sixth display above (43), ")#mi("\\ll")#text(" should be ")#mi("\\lessapprox")#text(", and the condition ")#mi("d | m_2-m_1")#text(" should be deleted.")

#text("6. In the third and fourth display above (43), ")#mi("r_1,r_2 \\in {\\mathcal S}_I")#text(" should be ")#mi("r^{\\prime}_1,r^{\\prime}_2 \\in {\\mathcal S}_I")#text(".")

#text("7. In the display below (43), ")#mi("\\frac{yQ_{\\vec b}}{b}")#text(" should be ")#mi("yQ_{\\vec b}")#text(".")

#text("8. I think that (13) needs to be strengthened to ")#mi("\\varpi< \\frac{1}{12}")#text(" in order to yield the third display below (43).")

#text("9. In the fourth display below (43), the factor ")#mi("b^{1/2}")#text(" can be deleted (cf. item 7). Accordingly, in the next display the factor ")#mi("b^{1/4}")#text(" can be deleted.")

#text("10. In the ninth and twelfth display below (43), ")#mi("10\\epsilon/3")#text(" should be ")#mi("15\\epsilon/2")#text(".")

#emph[#text("[Corrected, thanks, and many thanks for the careful reading of all the blog posts! – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239275")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2013")])]

#text("1. In the second display below (42), the condition ")#mi("(r_1r_2s,hb)=1")#text(" appears too early as ")#mi("h")#text(" does not exist at that point. This is why I suggested the separate conditions ")#mi("(r_1r_2s,b)=1")#text(" and ")#mi("(h,r_1r_2s)=1")#text(".")

#text("2. In the third display above (43), ")#mi("r_1,r_2 \\in {\\mathcal S}_I")#text(" should be ")#mi("r^{\\prime}_1 \\in {\\mathcal S}_I")#text(".")

#text("3. In the twelfth display below (43), ")#mi("10\\epsilon/3")#text(" should be ")#mi("15\\epsilon/2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239255")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("It seems that if the above quartic curve is reducible, then its factors should be of first degree with respect to y. So y should be a rational function of x for both factors.")#linebreak()#text(" Therefore this factorization is generic in the above parameters only if the discriminant of the resulting quadratic equation of y is a square of a polynomial in x for each choise of the above parameters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("I managed to get a value of ")#mi("k_0 = 633")#text(" from the constraint ")#mi("600 \\varpi./7 + 180 \\delta/7 < 1")#text(" from ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239189")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239189")]#text(" and quadruple dense divisibility (which means that the quatity ")#mi("\\tilde \\theta")#text(" is set equal to ")#mi("\\frac{2(\\delta^{\\prime} - \\delta) + \\varpi}{1/4 + \\varpi}")#text(" instead of ")#mi("\\frac{(\\delta^{\\prime} - \\delta)/2 + \\varpi}{1/4 + \\varpi}")#text(" (for dense divisibility) or ")#mi("\\frac{(\\delta^{\\prime} - \\delta) + \\varpi}{1/4 + \\varpi}")#text(" (for double dense divisibility). It is likely that one can shave ")#mi("k_0")#text(" a little bit more by optimising the free parameters ")#mi("\\delta, \\delta^{\\prime}, A")#text(" further. From the tables at ")#link("http://math.mit.edu/~primegaps/")[#text("http://math.mit.edu/~primegaps/")]#text(" , this gives bounded gaps between primes with ")#mi("H = 4,686")#text(".")

#text("I’m in the process of writing the details of the Type I estimate leading to this improvement in a blog post which should be ready within a day or two.")

#raw("\nk0 := 633;\ndelta := 1/8000;\nvarpi := (1 - 180*delta/7) * 7 / 600;\ndeltap := 1/130;\nA := 500;\ntheta := deltap / (1/4 + varpi);\nthetat := min( (2*(deltap - delta) + varpi) / (1/4 + varpi), 1);\ndeltat := delta / (1/4 + varpi);\nj := BesselJZeros(k0-2,1);\neps := 1 - j^2 / (k0 * (k0-1) * (1+\t4*varpi));\nkappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);\nkappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);\nalpha := j^2 / (4 * (k0-1));\ne := exp( A + (k0-1) * int( exp(-(A+2*alpha)*t)/t, t=deltat..theta, numeric ) );\ngd := (j^2/2) * BesselJ(k0-3,j)^2;\ntn := sqrt(thetat)*j;\ngn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));\nkappa3 := (gn/gd) * e;\neps2 := 2*(kappa1+kappa2+kappa3);\n# we win if eps2 < eps\n")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239889")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("Sounds great! I think ")#mi("k_0=632")#text(" is admissible, yielding prime gaps of size ")#mi("H=4680")#text(" (")#link("http://math.mit.edu/~primegaps/tuples/admissible_632_4680.txt")[#text("http://math.mit.edu/~primegaps/tuples/admissible_632_4680.txt")]#text("). Using ")#mi("\\varpi=7/600-1/39000")#text(", ")#mi("\\delta=(7-600*\\varpi)/180")#text(", ")#mi("\\delta^{\\prime}=1/131")#text(", ")#mi("A=202")#text(", I am getting ")#mi("\\epsilon\\approx 1.83\\times 10^{-5}")#text(", ")#mi("2\\kappa_1\\approx 1.68\\times 10^{-5}")#text(", ")#mi("2\\kappa_2\\approx 4.86\\times 10^{-7}")#text(", ")#mi("2\\kappa_3\\approx 5.32\\times 10^{-7}")#text(". Please check as I am writing this in a rush.")

#emph[#text("[This seems to check out – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239904")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("Oops, I encountered a problem while writing up the argument… it turns out that in order for a ")#mi("y^{\\prime}")#text("-smooth number ")#mi("n")#text(" to be ")#mi("k")#text("-tuply densely divisible, it is not enough for ")#mi("\\prod_{p|n: p \\leq y} p \\geq (y^{\\prime}/y)^k")#text(" as I had thought… instead one needs the slightly stronger condition ")#mi("\\prod_{p|n: p \\leq y} p \\geq (y^{\\prime})^k /y")#text(". This has the effect of increasing ")#mi("\\tilde \\theta")#text(" slightly from ")#mi("(2(\\delta^{\\prime} - \\delta) + \\varpi) / (1/4 + \\varpi)")#text(" to ")#mi("(2\\delta^{\\prime} - \\delta/2 + \\varpi) / (1/4 + \\varpi)")#text(". I can recover ")#mi("k_0=633")#text(" with this weaker criterion (using ")#mi("\\varpi = 7/600 - 1/39000")#text(", ")#mi("\\delta^{\\prime} = 1/131.7")#text(", and ")#mi("A = 200")#text(") but just barely fail recovering ")#mi("k_0=632")#text(" (keeping those same values of ")#mi("\\varpi,\\delta^{\\prime},A")#text(" one is only off by about 5% or so). But perhaps a more careful optimisation can recover this.")

#text("In any event, even without delta issues, ")#mi("\\varpi=7/600")#text(" gives ")#mi("k_0=630")#text(" at best, so there isn’t terribly much room for further optimisation without improving ")#mi("\\varpi")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239910")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#mi("k_0=632")#text(" seems to follows with the parameters ")#mi("\\delta=1/11500")#text(", ")#mi("\\delta^{\\prime}=1/128")#text(", ")#mi("A=200")#text(".")

#emph[#text("[Confirmed, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239916")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#mi("k_0=632")#text(" also seems to follow from the clean parameters ")#mi("\\delta=1/10000")#text(", ")#mi("\\delta^{\\prime}=1/105")#text(", ")#mi("A=200")#text(". These yield ")#mi("\\epsilon\\approx 1.68\\times 10^{-6}")#text(", ")#mi("2\\kappa_1\\approx 1.29\\times 10^{-6}")#text(", ")#mi("2\\kappa_2\\approx 3.50\\times 10^{-9}")#text(", ")#mi("2\\kappa_3\\approx 1.40\\times 10^{-7}")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-240231")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2013")])]

#text("Since ")#mi("\\kappa_1")#text(" is (significantly) dominant over")#linebreak()#text(" ")#mi("\\kappa_2, \\kappa_3")#text(", it seems that its reduction may lead to a further (small) reduction in ")#mi("k_0")#text(". One possibility is by trying to increase")#linebreak()#text(" ")#mi("\\delta^{\\prime}")#text(" (and thereby ")#mi("\\theta")#text("). Another possibility is to improve the upper bound on ")#mi("\\kappa_1")#text(" (by improving the current bound on")#linebreak()#text(" ")#mi("G_{k_0 - 1} (0, t)")#text(" – I just found a simple improved bound – I’m preparing the details.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An improved Type I estimate | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239912")[#strong[#text("An improved Type I estimate | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2013")])]

#text("[…] purpose of this (rather technical) post is both to roll over the polymath8 research thread from this previous post, and also to record the details of the latest improvement to the Type I estimates (based on […]")
]
