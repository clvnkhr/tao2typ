// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/
// Converted to Typst by tao2typ: "2026-10-14T11:10:16.130675+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An upper bound on the mean value of the Erdős-Hooley delta function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An upper bound on the mean value of the Erdős-Hooley delta function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/")[#text("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://dms.umontreal.ca/~koukoulo/")[#text("Dimitris Koukoulopoulos")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2306.08615")[#text("An upper bound on the mean value of the Erdős-Hooley delta function")]#text("“. This paper concerns a (still somewhat poorly understood) basic ")#link("https://en.wikipedia.org/wiki/Arithmetic_function")[#text("arithmetic function")]#text(" in multiplicative number theory, namely the ")#emph[#text("Erdos-Hooley delta function")]

#align(center)[#tao-fit-display[#mitex("\\Delta(n) := \\sup_u \\Delta(n;u)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Delta(n;u) := \\# \\{ d|n: e^u < d \\leq e^{u+1} \\}.")]]

#text("The function ")#mi("{\\Delta}")#text(" measures the extent to which the divisors of a natural number can be concentrated in a dyadic (or more precisely, ")#mi("{e}")#text("-dyadic) interval ")#mi("{(e^u, e^{u+1}]}")#text(". From the pigeonhole principle, we have the bounds")

#align(center)[#tao-fit-display[#mitex("\\frac{\\tau(n)}{\\log n} \\ll \\Delta(n) \\leq \\tau(n),")]]

#text("where ")#mi("{\\tau(n) := \\# \\{ d: d|n\\}}")#text(" is the usual divisor function. The statistical behavior of the divisor function is well understood; for instance, if ")#mi("{n}")#text(" is drawn at random from ")#mi("{1}")#text(" to ")#mi("{x}")#text(", then the mean value of ")#mi("{\\tau(n)}")#text(" is roughly ")#mi("{\\log x}")#text(", the median is roughly ")#mi("{\\log^{\\log 2} x}")#text(", and (by the ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdős-Kac")]#text(" theorem) ")#mi("{\\tau(n)}")#text(" asymptotically has a log-normal distribution. In particular, there are a small proportion of highly divisible numbers that skew the mean to be significantly higher than the median.")

#text("On the other hand, the statistical behavior of the Erdős-Hooley delta function is significantly less well understood, even conjecturally. Again drawing ")#mi("{n}")#text(" at random from ")#mi("{1}")#text(" to ")#mi("{x}")#text(" for large ")#mi("{x}")#text(", the median is known to be somewhere between ")#mi("{(\\log\\log x)^{0.3533\\dots}}")#text(" and ")#mi("{(\\log\\log x)^{0.6102\\dots}}")#text(" for large ")#mi("{x}")#text(" – a (difficult) recent ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4588563")[#text("result of Ford, Green, and Koukoulopolous")]#text(" (for the lower bound) and ")#link("https://arxiv.org/abs/2210.13897")[#text("La Bretèche and Tenenbaum")]#text(" (for the upper bound). And the mean ")#mi("{\\frac{1}{x} \\sum_{n \\leq x} \\Delta(n)}")#text(" was even less well controlled; the best previous bounds were")

#align(center)[#tao-fit-display[#mitex("\\log \\log x \\ll \\frac{1}{x} \\sum_{n \\leq x} \\Delta(n) \\ll \\exp( c \\sqrt{\\log\\log x} )")]]

#text("for any ")#mi("{c > \\sqrt{2} \\log 2}")#text(", with the lower bound ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=964687")[#text("due to Hall and Tenenbaum")]#text(", and the upper bound a recent result of ")#link("https://arxiv.org/abs/2210.13897")[#text("La Bretèche and Tenenbaum")]#text(".")

#text("The main result of this paper is an improvement of the upper bound to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} \\Delta(n) \\ll (\\log \\log x)^{11/4}.")]]

#text("It is still unclear to us exactly what to conjecture regarding the actual order of the mean value.")

#text("The reason we looked into this problem was that it was connected to forthcoming work of David Conlon, Jacob Fox, and Huy Pham on the following problem of Erdos: what is the size of the largest subset ")#mi("{A}")#text(" of ")#mi("{\\{1,\\dots,N\\}}")#text(" with the property that no non-empty subset of ")#mi("{A}")#text(" sums to a perfect square? Erdos observed that one can obtain sets of size ")#mi("{\\gg N^{1/3}}")#text(" (basically by considering certain homogeneous arithmetic progressions), and ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2815612")[#text("Nguyen and Vu")]#text(" showed an upper bound of ")#mi("{\\ll N^{1/3} (\\log N)^{O(1)}}")#text(". With our mean value bound as input, together with several new arguments, Conlon, Fox, and Pham have been able to improve the upper bound to ")#mi("{\\ll N^{1/3} (\\log\\log N)^{O(1)})}")#text(".")

#text("Let me now discuss some of the ingredients of the proof. The first few steps are standard. Firstly we may restrict attention to square-free numbers without much difficulty (the point being that if a number ")#mi("{n}")#text(" factors as ")#mi("{n = d^2 m}")#text(" with ")#mi("{m}")#text(" squarefree, then ")#mi("{\\Delta(n) \\leq \\tau(d^2) \\Delta(m)}")#text("). Next, because a square-free number ")#mi("{n>1}")#text(" can be uniquely factored as ")#mi("{n = pm}")#text(" where ")#mi("{p}")#text(" is a prime and ")#mi("{m}")#text(" lies in the finite set ")#mi("{{\\mathcal S}_{<p}}")#text(" of squarefree numbers whose prime factors are less than ")#mi("{p}")#text(", and ")#mi("{\\Delta(n) \\leq \\tau(p) \\Delta(m) = 2 \\Delta(m)}")#text(", it is not difficult to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\in {\\mathcal S}_{<x}} \\Delta(n) \\ll \\sup_{2 \\leq y\\leq x} \\frac{1}{\\log y} \\sum_{n \\in {\\mathcal S}_{<y}} \\frac{\\Delta(n)}{n}.")]]

#text("The upshot of this is that one can replace an ordinary average with a logarithmic average, thus it suffices to show")

#metadata(none) <tao-836ff184e7b41b1e13cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{\\log x} \\sum_{n \\in {\\mathcal S}_{<x}} \\frac{\\Delta(n)}{n} \\ll (\\log \\log x)^{11/4}.")]]

#text("We actually prove a slightly more refined distributional estimate: for any ")#mi("{A \\geq 2}")#text(", we have a bound")

#metadata(none) <tao-dca941206e8164333866>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta(n) \\ll A \\log^{3/4} A")]]

#text("outside of an exceptional set ")#mi("{E}")#text(" which is small in the sense that")

#metadata(none) <tao-81db8ebbbbc69c6c6ad4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{\\log x} \\sum_{n \\in {\\mathcal S}_{<x}: n \\in E} \\frac{1}{n} \\ll \\frac{1}{A}.")]]

#text("It is not difficult to get from this distributional estimate to the logarithmic average estimate ")#link(<tao-836ff184e7b41b1e13cb>)[#text("(1)")]#text(" (worsening the exponent ")#mi("{3/4}")#text(" to ")#mi("{3/4+2 = 11/4}")#text(").")

#text("To get some intuition on the size of ")#mi("{\\Delta(n)}")#text(", we observe that if ")#mi("{y > 0}")#text(" and ")#mi("{n_{<y}}")#text(" is the factor of ")#mi("{n}")#text(" coming from the prime factors less than ")#mi("{y}")#text(", then ")#metadata(none) <tao-17f5da734a40b9107c0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Delta(n) \\geq \\Delta(n_{<y}) \\gg \\frac{\\tau(n_{<y})}{\\log n_{<y}}.")]]

#text(" ")#text(" On the other hand, standard estimates let one establish that")

#metadata(none) <tao-e40d16db6ea0c7b0cca1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\tau(n_{<y}) \\ll A \\log n_{<y}")]]

#text("for all ")#mi("{y}")#text(", and all ")#mi("{n}")#text(" outside of an exceptional set that is small in the sense ")#link(<tao-81db8ebbbbc69c6c6ad4>)[#text("(3)")]#text("; in fact it turns out that one can also get an additional gain in this estimate unless ")#mi("{\\log y}")#text(" is close to ")#mi("{A^{\\log 4}}")#text(", which turns out to be useful when optimizing the bounds. So we would like to approximately reverse the inequalities in ")#link(<tao-17f5da734a40b9107c0b>)[#text("(4)")]#text(" and get from ")#link(<tao-e40d16db6ea0c7b0cca1>)[#text("(5)")]#text(" to ")#link(<tao-dca941206e8164333866>)[#text("(2)")]#text(", possibly after throwing away further exceptional sets of size ")#link(<tao-81db8ebbbbc69c6c6ad4>)[#text("(3)")]#text(".")

#text("At this point we perform another standard technique, namely the ")#link("https://en.wikipedia.org/wiki/Second_moment_method")[#text("moment method")]#text(" of controlling the supremum ")#mi("{\\Delta(n) = \\sup_u \\Delta(n;u)}")#text(" by the moments")

#align(center)[#tao-fit-display[#mitex("M_q(n) := \\int_{{\\bf R}} \\Delta(n,u)^q\\ du")]]

#text("for natural numbers ")#mi("{q}")#text("; it is not difficult to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\Delta(n) \\ll M_q(n)^{1/q}")]]

#text("and one expects this bound to become essentially sharp once ")#mi("{q \\sim \\log\\log x}")#text(". We will be able to show a moment bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\mathcal S}_{<x} \\backslash E_q} \\frac{M_q(n) / \\tau(n)}{n} \\leq O(q)^q A^{q-2} \\log^{3q/4} A")]]

#text("for any ")#mi("{q \\geq 2}")#text(" for some exceptional set ")#mi("{E_q}")#text(" obeying the smallness condition ")#link(<tao-81db8ebbbbc69c6c6ad4>)[#text("(3)")]#text(" (actually, for technical reasons we need to improve the right-hand side slightly to close an induction on ")#mi("{q}")#text("); this will imply the distributional bound ")#link(<tao-dca941206e8164333866>)[#text("(2)")]#text(" from a standard Markov inequality argument (setting ")#mi("{q \\sim \\log\\log x}")#text(").")

#text("The strategy is then to obtain a good recursive inequality for (averages of) ")#mi("{M_q(n)}")#text(". As in the reduction to ")#link(<tao-836ff184e7b41b1e13cb>)[#text("(1)")]#text(", we factor ")#mi("{n=pm}")#text(" where ")#mi("{p}")#text(" is a prime and ")#mi("{m \\in {\\mathcal S}_{<p}}")#text(". One observes the identity")

#align(center)[#tao-fit-display[#mitex("\\Delta(n;u) = \\Delta(m;u) + \\Delta(m;u-\\log p)")]]

#text("for any ")#mi("{u}")#text("; taking moments, one obtains the identity")

#align(center)[#tao-fit-display[#mitex("M_q(n) = \\sum_{a+b=q; 0 \\leq b \\leq q} \\binom{q}{a} \\int_{\\bf R} \\Delta(m;u)^a \\Delta(m;u-\\log p)^b\\ du.")]]

#text("As in previous literature, one can try to average in ")#mi("{p}")#text(" here and apply Hölder’s inequality. But it convenient to first use the symmetry of the summand in ")#mi("{a,b}")#text(" to reduce to the case of relatively small values of ")#mi("{b}")#text(":")

#align(center)[#tao-fit-display[#mitex("M_q(n) \\leq 2 \\sum_{a+b=q; 0 \\leq b \\leq q/2} \\binom{q}{a} \\int_{\\bf R} \\Delta(m;u)^a \\Delta(m;u-\\log p)^b\\ du.")]]

#text("One can extract out the ")#mi("{b=0}")#text(" term as")

#tao-aligned(keep: true)[


#tao-math("M_q(n)  & \\leq 2 M_q(m)", block: true)



#tao-math(" & + 2 \\sum_{a+b=q; 1 \\leq b \\leq q/2} \\binom{q}{a} \\int_{\\bf R} \\Delta(m;u)^a \\Delta(m;u-\\log p)^b\\ du.", block: true)
]

#text("It is convenient to eliminate the factor of ")#mi("{2}")#text(" by dividing out by the divisor function:")

#tao-aligned(keep: true)[


#tao-math("\\frac{M_q(n)}{\\tau(n)}  & \\leq \\frac{M_q(m)}{\\tau(m)}", block: true)



#tao-math(" & + \\frac{1}{m} \\sum_{a+b=q; 1 \\leq b \\leq q/2} \\binom{q}{a} \\int_{\\bf R} \\Delta(m;u)^a \\Delta(m;u-\\log p)^b\\ du.", block: true)
]

#text("This inequality is suitable for iterating and also averaging in ")#mi("{p}")#text(" and ")#mi("{m}")#text(". After some standard manipulations (using the Brun–Titchmarsh and Hölder inequalities), one is able to estimate sums such as")

#metadata(none) <tao-09f5ffef28309853265c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\in {\\mathcal S}_{<x} \\backslash E_q} \\frac{M_q(n)/\\tau(n)}{n}")]]

#text("in terms of sums such as")

#align(center)[#tao-fit-display[#mitex("\\int_2^{x^2} \\sum_{a+b=q; 1 \\leq b \\leq q/2} \\binom{q}{a} \\sum_{n \\in {\\mathcal S}_{<x} \\backslash E_q} \\frac{M_a(n) M_b(n)}{\\tau(n) n} \\frac{dy}{\\log^2 y}")]]

#text("(assuming a certain monotonicity property of the exceptional set ")#mi("{E_q}")#text(" that turns out to hold in our application). By an induction hypothesis and a Markov inequality argument, one can get a reasonable pointwise upper bound on ")#mi("{M_b}")#text(" (after removing another exceptional set), and the net result is that one can basically control the sum ")#link(<tao-09f5ffef28309853265c>)[#text("(6)")]#text(" in terms of expressions such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\mathcal S}_{<x} \\backslash E_a} \\frac{M_a(n)/\\tau(n)}{n}")]]

#text("for various ")#mi("{a < q}")#text(". This allows one to estimate these expressions efficiently by induction.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678718")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2023")])]

#text("Terry,")

#text("Just to remark that the a.s. upper bound you state is in fact due to Tenenbaum and la Breteche ")#link("https://arxiv.org/abs/2210.13897")[#text("https://arxiv.org/abs/2210.13897")]

#text("Best wishes,")#linebreak()#text(" Ben")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2023")])]

#text("Is there any simple sufficient condition for a general class of functions ")#mi("f(n)")#text(" which enable estimating its mean by its logarithmic mean (as done for ")#mi("Delta(n)")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2023")])]

#text("You can do this for any non-negative function ")#mi("f")#text(" obeying a bound of the form ")#mi("f(dm) \\ll f(m) \\tau(d)^{O(1)}")#text(", by some standard elementary calculations:")

#mi("\\displaystyle \\sum_{n \\leq x} \\log n f(n) = \\sum_{dm \\leq x} \\Lambda(d) f(dm)")

#mi("\\displaystyle \\ll \\sum_{m \\leq x} f(m) \\sum_{d \\leq x/m} \\Lambda(d) \\tau(d)^{O(1)}")

#mi("\\displaystyle \\ll \\sum_{m \\leq x} f(m) \\frac{x}{m}")

#text("and also")

#mi("\\displaystyle \\sum_{n \\leq x} \\log \\frac{x}{n} f(n) \\ll \\sum_{n \\leq x} \\frac{x}{n} f(n)")

#text("which upon summing gives")

#mi("\\displaystyle \\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll \\frac{1}{\\log x} \\sum_{n \\leq x} \\frac{f(n)}{n}.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678726")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2023")])]

#text("Typo in the definition of Delta: l instead of ;")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678741")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2023")])]

#text("In the first displayed equation the l should be a semicolon.")

#emph[#text("[Corrected; thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2023")])]

#text("You misspelled your coauthor’s name…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678759")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("PROF only IQ 200+ can understand what U wrote 🤗")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678760")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("PROF UR too smart i can’t understand what U wrote")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678761")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("PROF why my comments getting delated😏")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abc")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-678767")[#strong[#text("abc")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("the link to [Nguyen and Vu] does not work.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A lower bound on the mean value of the Erd”os-Hooley delta function | What's new")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-681138")[#strong[#text("A lower bound on the mean value of the Erd”os-Hooley delta function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2023")])]

#text("[…] bound on the mean value of the Erdös-Hooley delta function“. This paper complements the recent paper of Dimitris and myself obtaining the upper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-691910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("Sorry if I am missing something obvious, but it seems to me that there is a typo in your equation (3), and I can’t figure out what you meant there. Did you just mean ")#tao-fit-display[#mitex("\\frac 1{\\log x}\\sum_{n\\in E} \\frac 1n\\ll \\frac 1A")]#text(" or do you also want $n$ to be in $S_{<x}$? The set on which you are summing isn’t completely clear to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/16/a-note-on-the-mean-value-of-the-hooley-delta-function/#comment-691916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("The typo has now been corrected. One is summing over ")#mi("E \\cap S_{<x}")#text(" where ")#mi("E")#text(" is an exceptional set that does not depend on ")#mi("x")#text(".")
]
]
