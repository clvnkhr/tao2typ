// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/
// Converted to Typst by tao2typ: "2026-10-14T15:20:24.059158+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Elgindi’s approximation of the Biot-Savart law", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Elgindi’s approximation of the Biot-Savart law")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 December 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/")[#text("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{u: {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" be a divergence-free vector field, thus ")#mi("{\\nabla \\cdot u = 0}")#text(", which we interpret as a velocity field. In this post we will proceed formally, largely ignoring the analytic issues of whether the fields in question have sufficient regularity and decay to justify the calculations. The ")#link("https://en.wikipedia.org/wiki/Vorticity")[#text("vorticity field")]#text(" ")#mi("{\\omega: {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" is then defined as the curl of the velocity:")

#align(center)[#tao-fit-display[#mitex("\\omega = \\nabla \\times u.")]]

#text("(From a differential geometry viewpoint, it would be more accurate (especially in other dimensions than three) to define the vorticity as the exterior derivative ")#mi("{\\omega = d(g \\cdot u)}")#text(" of the ")#link("https://en.wikipedia.org/wiki/Musical_isomorphism")[#text("musical isomorphism")]#text(" ")#mi("{g \\cdot u}")#text(" of the Euclidean metric ")#mi("{g}")#text(" applied to the velocity field ")#mi("{u}")#text("; see ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("these previous lecture notes")]#text(". However, we will not need this geometric formalism in this post.)")

#text("Assuming suitable regularity and decay hypotheses of the velocity field ")#mi("{u}")#text(", it is possible to recover the velocity from the vorticity as follows. From the general vector identity ")#mi("{\\nabla \\times \\nabla \\times X = \\nabla(\\nabla \\cdot X) - \\Delta X}")#text(" applied to the velocity field ")#mi("{u}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\nabla \\times \\omega = -\\Delta u")]]

#text("and thus (by the commutativity of all the differential operators involved)")

#align(center)[#tao-fit-display[#mitex("u = - \\nabla \\times \\Delta^{-1} \\omega.")]]

#text("Using the ")#link("https://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newton potential")]#text(" formula")

#align(center)[#tao-fit-display[#tao-math("-\\Delta^{-1} \\omega(x) := \\frac{1}{4\\pi} \\int_{{\\bf R}^3} \\frac{\\omega(y)}{\\left|x-y\\right|}\\ dy", block: true)]]

#text("and formally differentiating under the integral sign, we obtain the ")#link("https://en.wikipedia.org/wiki/Newtonian_potential")[#text("Biot-Savart law")]#text(" ")#metadata(none) <tao-5975baa1903491a53c35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("u(x) = \\frac{1}{4\\pi} \\int_{{\\bf R}^3} \\frac{\\omega(y) \\times (x-y)}{\\left|x-y\\right|^3}\\ dy.", block: true)]]

#text("This law is of fundamental importance in the study of incompressible fluid equations, such as the Euler equations")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + (u \\cdot \\nabla) u = -\\nabla p; \\quad \\nabla \\cdot u = 0")]]

#text("since on applying the curl operator one obtains the ")#link("https://en.wikipedia.org/wiki/Vorticity_equation")[#text("vorticity equation")]#text(" ")#metadata(none) <tao-f77f484ce99781cbf892>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t \\omega + (u \\cdot \\nabla) \\omega = (\\omega \\cdot \\nabla) u")]]

#text("and then by substituting ")#link(<tao-5975baa1903491a53c35>)[#text("(1)")]#text(" one gets an autonomous equation for the vorticity field ")#mi("{\\omega}")#text(". Unfortunately, this equation is non-local, due to the integration present in ")#link(<tao-5975baa1903491a53c35>)[#text("(1)")]#text(".")

#text("In a ")#link("https://arxiv.org/abs/1904.04795")[#text("recent work")]#text(", it was observed by Elgindi that in a certain regime, the Biot-Savart law can be approximated by a more “low rank” law, which makes the non-local effects significantly simpler in nature. This simplification was carried out in spherical coordinates, and hinged on a study of the invertibility properties of a certain second order linear differential operator in the latitude variable ")#mi("{\\theta}")#text("; however in this post I would like to observe that the approximation can also be seen directly in Cartesian coordinates from the classical Biot-Savart law ")#link(<tao-5975baa1903491a53c35>)[#text("(1)")]#text(". As a consequence one can also initiate the beginning of Elgindi’s analysis in constructing somewhat regular solutions to the Euler equations that exhibit self-similar blowup in finite time, though I have not attempted to execute the entirety of the analysis in this setting.")

#text("Elgindi’s approximation applies under the following hypotheses:")

#list(
[#text("(i) (Axial symmetry without swirl) The velocity field ")#mi("{u}")#text(" is assumed to take the form")

#metadata(none) <tao-f0df68810c32b280efd1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(x_1,x_2,x_3) = ( u_r(r,x_3) \\frac{x_1}{r}, u_r(r,x_3) \\frac{x_2}{r}, u_3(r,x_3) )")]]

#text("for some functions ")#mi("{u_r, u_3: [0,+\\infty) \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" of the cylindrical radial variable ")#mi("{r := \\sqrt{x_1^2+x_2^2}}")#text(" and the vertical coordinate ")#mi("{x_3}")#text(". As a consequence, the vorticity field ")#mi("{\\omega}")#text(" takes the form")

#metadata(none) <tao-304b4a90a76a1cbe4c11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\omega(x_1,x_2,x_3) = (\\omega_{r3}(r,x_3) \\frac{x_2}{r}, \\omega_{r3}(r,x_3) \\frac{-x_1}{r}, 0)")]]

#text("where ")#mi("{\\omega_{r3}: [0,+\\infty) \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is the field")

#align(center)[#tao-fit-display[#mitex("\\omega_{r3} = \\partial_r u_3 - \\partial_3 u_r.")]]],
[#text("(ii) (Odd symmetry) We assume that ")#mi("{u_3(r,-x_3) = -u_3(r,x_3)}")#text(" and ")#mi("{u_r(r,-x_3)=u_r(r,x_3)}")#text(", so that ")#mi("{\\omega_{r3}(r,-x_3)=\\omega_{r3}(r,x_3)}")#text(".")]
)

#text("A model example of a divergence-free vector field obeying these properties (but without good decay at infinity) is the linear vector field ")#metadata(none) <tao-7f2fe580edb35154041f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("X(x) = (x_1, x_2, -2x_3)")]]

#text("which is of the form ")#link(<tao-f0df68810c32b280efd1>)[#text("(3)")]#text(" with ")#mi("{u_r(r,x_3) = r}")#text(" and ")#mi("{u_3(r,x_3) = -2x_3}")#text(". The associated vorticity ")#mi("{\\omega}")#text(" vanishes.")

#text("We can now give an illustration of Elgindi’s approximation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Elgindi’s approximation)")]#text(" ")#metadata(none) <tao-8c1634dbc4f92409282c>#text(" Under the above hypotheses (and assuing suitable regularity and decay), we have the pointwise bounds")

#align(center)[#tao-fit-display[#tao-math("u(x) = \\frac{1}{2} {\\mathcal L}_{12}(\\omega)(\\left|x\\right|) X(x) + O( \\left|x\\right| \\left\\|\\omega\\right\\|_{L^\\infty({\\bf R}^3)} )", block: true)]]

#text("for any ")#mi("{x \\in {\\bf R}^3}")#text(", where ")#mi("{X}")#text(" is the vector field ")#link(<tao-7f2fe580edb35154041f>)[#text("(5)")]#text(", and ")#mi("{{\\mathcal L}_{12}(\\omega): {\\bf R}^+ \\rightarrow {\\bf R}}")#text(" is the scalar function")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal L}_{12}(\\omega)(\\rho) := \\frac{3}{4\\pi} \\int_{\\left|y\\right| \\geq \\rho} \\frac{r y_3}{\\left|y\\right|^5} \\omega_{r3}(r,y_3)\\ dy.", block: true)]]
]

#text("Thus under the hypotheses (i), (ii), and assuming that ")#mi("{\\omega}")#text(" is slowly varying, we expect ")#mi("{u}")#text(" to behave like the linear vector field ")#mi("{X}")#text(" modulated by a radial scalar function. In applications one needs to control the error in various function spaces instead of pointwise, and with ")#mi("{\\omega}")#text(" similarly controlled in other function space norms than the ")#mi("{L^\\infty}")#text(" norm, but this proposition already gives a flavour of the approximation. If one uses spherical coordinates")

#align(center)[#tao-fit-display[#mitex("\\omega_{r3}( \\rho \\cos \\theta, \\rho \\sin \\theta ) = \\Omega( \\rho, \\theta )")]]

#text("then we have (using the spherical change of variables formula ")#mi("{dy = \\rho^2 \\cos \\theta d\\rho d\\theta d\\phi}")#text(" and the odd nature of ")#mi("{\\Omega}")#text(")")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L}_{12}(\\omega) = L_{12}(\\Omega),")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("L_{12}(\\Omega)(\\rho) = 3 \\int_\\rho^\\infty \\int_0^{\\pi/2} \\frac{\\Omega(r, \\theta) \\sin(\\theta) \\cos^2(\\theta)}{r}\\ d\\theta dr")]]

#text("is the operator introduced in Elgindi’s paper.")

#emph[#text("Proof:")]#text(" By a limiting argument we may assume that ")#mi("{x}")#text(" is non-zero, and we may normalise ")#tao-math("{\\left\\|\\omega\\right\\|_{L^\\infty({\\bf R}^3)}=1}", block: false)#text(". From the triangle inequality we have")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\left|y\\right| \\leq 10\\left|x\\right|} \\frac{\\omega(y) \\times (x-y)}{\\left|x-y\\right|^3}\\ dy  & \\leq \\int_{\\left|y\\right| \\leq 10\\left|x\\right|} \\frac{1}{\\left|x-y\\right|^2}\\ dy", block: true)



#tao-math(" & \\leq \\int_{\\left|z\\right| \\leq 11 \\left|x\\right|} \\frac{1}{\\left|z\\right|^2}\\ dz", block: true)



#tao-math(" & = O( \\left|x\\right| )", block: true)
]

#text("and hence by ")#link(<tao-5975baa1903491a53c35>)[#text("(1)")]

#align(center)[#tao-fit-display[#tao-math("u(x) = \\frac{1}{4\\pi} \\int_{\\left|y\\right| > 10\\left|x\\right|} \\frac{\\omega(y) \\times (x-y)}{\\left|x-y\\right|^3}\\ dy + O(\\left|x\\right|).", block: true)]]

#text("In the regime ")#tao-math("{\\left|y\\right| > 2\\left|x\\right|}", block: false)#text(" we may perform the Taylor expansion")

#tao-aligned(keep: true)[


#tao-math("\\frac{x-y}{\\left|x-y\\right|^3}  & = \\frac{x-y}{\\left|y\\right|^3} (1 - \\frac{2 x \\cdot y}{\\left|y\\right|^2} + \\frac{\\left|x\\right|^2}{\\left|y\\right|^2})^{-3/2}", block: true)



#tao-math(" & = \\frac{x-y}{\\left|y\\right|^3} (1 + \\frac{3 x \\cdot y}{\\left|y\\right|^2} + O( \\frac{\\left|x\\right|^2}{\\left|y\\right|^2} ) )", block: true)



#tao-math(" & = -\\frac{y}{\\left|y\\right|^3} + \\frac{x}{\\left|y\\right|^3} - \\frac{3 (x \\cdot y) y}{\\left|y\\right|^5} + O( \\frac{\\left|x\\right|^2}{\\left|y\\right|^4} ).", block: true)
]

#text("Since")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|y\\right| > 10\\left|x\\right|} \\frac{\\left|x\\right|^2}{\\left|y\\right|^4}\\ dy = O(\\left|x\\right|)", block: true)]]

#text("we see from the triangle inequality that the error term contributes ")#tao-math("{O(\\left|x\\right|)}", block: false)#text(" to ")#mi("{u(x)}")#text(". We thus have")

#align(center)[#tao-fit-display[#tao-math("u(x) = -A_0(x) + A_1(x) - 3A^{\\prime}_1(x) + O(\\left|x\\right|)", block: true)]]

#text("where ")#mi("{A_0}")#text(" is the constant term")

#align(center)[#tao-fit-display[#tao-math("A_0 := \\int_{\\left|y\\right| > 10\\left|x\\right|} \\frac{\\omega(y) \\times y}{\\left|y\\right|^3}\\ dy,", block: true)]]

#text("and ")#mi("{A_1, A^{\\prime}_1}")#text(" are the linear term")

#tao-aligned(keep: true)[


#tao-math("A_1  & := \\int_{\\left|y\\right| > 10\\left|x\\right|} \\frac{\\omega(y) \\times x}{\\left|y\\right|^3}\\ dy,", block: true)



#tao-math("A^{\\prime}_1  & := \\int_{\\left|y\\right| > 10\\left|x\\right|} (x \\cdot y) \\frac{\\omega(y) \\times y}{\\left|y\\right|^5}\\ dy.", block: true)
]

#text("By the hypotheses (i), (ii), we have the symmetries ")#metadata(none) <tao-a92c0666f328de18a469>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\omega(y_1,y_2,-y_3) = - \\omega(y_1,y_2,y_3)")]]

#text("and ")#metadata(none) <tao-68afb980d4de0a4e53f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\omega(-y_1,-y_2,y_3) = - \\omega(y_1,y_2,y_3)")]]

#text("and hence also ")#metadata(none) <tao-13a74850ccc73207401e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\omega(-y_1,-y_2,-y_3) = \\omega(y_1,y_2,y_3).")]]

#text("The even symmetry ")#link(<tao-13a74850ccc73207401e>)[#text("(8)")]#text(" ensures that the integrand in ")#mi("{A_0}")#text(" is odd, so ")#mi("{A_0}")#text(" vanishes. The symmetry ")#link(<tao-a92c0666f328de18a469>)[#text("(6)")]#text(" or ")#link(<tao-68afb980d4de0a4e53f3>)[#text("(7)")]#text(" similarly ensures that ")#tao-math("{\\int_{\\left|y\\right| > 10\\left|x\\right|} \\frac{\\omega(y)}{\\left|y\\right|^3}\\ dy = 0}", block: false)#text(", so ")#mi("{A_1}")#text(" vanishes. Since ")#tao-math("{\\int_{\\left|x\\right| < y \\leq 10\\left|x\\right|} \\frac{\\left|x \\cdot y\\right| \\left|y\\right|}{\\left|y\\right|^5}\\ dy = O( \\left|x\\right| )}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\omega(x) = -3\\int_{\\left|y\\right| \\geq \\left|x\\right|} (x \\cdot y) \\frac{\\omega(y) \\times y}{\\left|y\\right|^5}\\ dy + O(\\left|x\\right|).", block: true)]]

#text("Using ")#link(<tao-304b4a90a76a1cbe4c11>)[#text("(4)")]#text(", the right-hand side is")

#align(center)[#tao-fit-display[#tao-math("-3\\int_{\\left|y\\right| \\geq \\left|x\\right|} (x_1 y_1 + x_2 y_2 + x_3 y_3) \\frac{\\omega_{r3}(r,y_3) (-y_1 y_3, -y_2 y_3, y_1^2+y_2^2)}{r\\left|y\\right|^5}\\ dy", block: true)]]

#align(center)[#tao-fit-display[#tao-math("+ O(\\left|x\\right|)", block: true)]]

#text("where ")#mi("{r := \\sqrt{y_1^2+y_2^2}}")#text(". Because of the odd nature of ")#mi("{\\omega_{r3}}")#text(", only those terms with one factor of ")#mi("{y_3}")#text(" give a non-vanishing contribution to the integral. Using the rotation symmetry ")#mi("{(y_1,y_2,y_3) \\mapsto (-y_2,y_1,y_3)}")#text(" we also see that any term with a factor of ")#mi("{y_1 y_2}")#text(" also vanishes. We can thus simplify the above expression as")

#align(center)[#tao-fit-display[#tao-math("-3\\int_{\\left|y\\right| \\geq \\left|x\\right|} \\frac{\\omega_{r3}(r,y_3) (-x_1 y_1^2 y_3, -x_2 y_2^2 y_3, x_3 (y_1^2+y_2^2) y_3)}{r\\left|y\\right|^5}\\ dy + O(\\left|x\\right|).", block: true)]]

#text("Using the rotation symmetry ")#mi("{(y_1,y_2,y_3) \\mapsto (-y_2,y_1,y_3)}")#text(" again, we see that the term ")#mi("{y_1^2}")#text(" in the first component can be replaced by ")#mi("{y_2^2}")#text(" or by ")#mi("{\\frac{1}{2} (y_1^2+y_2^2) = \\frac{r^2}{2}}")#text(", and similarly for the ")#mi("{y_2^2}")#text(" term in the second component. Thus the above expression is")

#align(center)[#tao-fit-display[#tao-math("\\frac{3}{2} \\int_{\\left|y\\right| \\geq \\left|x\\right|} \\frac{\\omega_{r3}(r,y_3) (x_1 , x_2, -2x_3) r y_3}{\\left|y\\right|^5}\\ dy + O(\\left|x\\right|)", block: true)]]

#text("giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Consider the divergence-free vector field ")#mi("{u := \\nabla \\times \\psi}")#text(", where the vector potential ")#mi("{\\psi}")#text(" takes the form")

#align(center)[#tao-fit-display[#tao-math("\\psi(x_1,x_2,x_3) := (x_2 x_3, -x_1 x_3, 0) \\eta(\\left|x\\right|)", block: true)]]

#text("for some bump function ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}}")#text(" supported in ")#mi("{(0,+\\infty)}")#text(". We can then calculate")

#align(center)[#tao-fit-display[#tao-math("u(x_1,x_2,x_3) = X(x) \\eta(\\left|x\\right|) + (x_1 x_3, x_2 x_3, -x_1^2-x_2^2) \\frac{\\eta^{\\prime}(\\left|x\\right|) x_3}{\\left|x\\right|}.", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\omega(x_1,x_2,x_3) = (-6x_2 x_3, 6x_1 x_3, 0) \\frac{\\eta^{\\prime}(\\left|x\\right|)}{\\left|x\\right|} + (-x_2 x_3, x_1 x_3, 0) \\eta^{\\prime\\prime}(\\left|x\\right|).", block: true)]]

#text("In particular the hypotheses (i), (ii) are satisfied with")

#align(center)[#tao-fit-display[#tao-math("\\omega_{r3}(r,x_3) = - 6 \\eta^{\\prime}(\\left|x\\right|) \\frac{x_3 r}{\\left|x\\right|} - \\eta^{\\prime\\prime}(\\left|x\\right|) x_3 r.", block: true)]]

#text("One can then calculate")

#tao-aligned(keep: true)[


#tao-math("L_{12}(\\omega)(\\rho)  & = -\\frac{3}{4\\pi} \\int_{\\left|y\\right| \\geq \\rho} (6\\frac{\\eta^{\\prime}(\\left|y\\right|)}{\\left|y\\right|^6} + \\frac{\\eta^{\\prime\\prime}(\\left|y\\right|)}{\\left|y\\right|^5}) r^2 y_3^2\\ dy", block: true)



#tao-math(" & = -\\frac{2}{5} \\int_\\rho^\\infty 6\\eta^{\\prime}(s) + s\\eta^{\\prime\\prime}(s)\\ ds", block: true)



#tao-math(" & = 2\\eta(\\rho) + \\frac{2}{5} \\rho \\eta^{\\prime}(\\rho).", block: true)
]

#text("If we take the specific choice")

#align(center)[#tao-fit-display[#mitex("\\eta(\\rho) = \\varphi( \\rho^\\alpha )")]]

#text("where ")#mi("{\\varphi}")#text(" is a fixed bump function supported some interval ")#mi("{[c,C] \\subset (0,+\\infty)}")#text(" and ")#mi("{\\alpha>0}")#text(" is a small parameter (so that ")#mi("{\\eta}")#text(" is spread out over the range ")#mi("{\\rho \\in [c^{1/\\alpha},C^{1/\\alpha}]}")#text("), then we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\omega \\right\\|_{L^\\infty} = O( \\alpha )", block: true)]]

#text("(with implied constants allowed to depend on ")#mi("{\\varphi}")#text("),")

#align(center)[#tao-fit-display[#mitex("L_{12}(\\omega)(\\rho) = 2\\eta(\\rho) + O(\\alpha),")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("u = X(x) \\eta(\\left|x\\right|) + O( \\alpha \\left|x\\right| ),", block: true)]]

#text("which is completely consistent with Proposition ")#link(<tao-8c1634dbc4f92409282c>)[#text("1")]#text(".")
]

#text("One can use this approximation to extract a plausible ansatz for a self-similar blowup to the Euler equations. We let ")#mi("{\\alpha>0}")#text(" be a small parameter and let ")#mi("{\\omega_{rx_3}}")#text(" be a time-dependent vorticity field obeying (i), (ii) of the form")

#align(center)[#tao-fit-display[#mitex("\\omega_{rx_3}(t,r,x_3) \\approx \\alpha \\Omega( t, R ) \\mathrm{sgn}(x_3)")]]

#text("where ")#tao-math("{R := \\left|x\\right|^\\alpha = (r^2+x_3^2)^{\\alpha/2}}", block: false)#text(" and ")#mi("{\\Omega: {\\bf R} \\times [0,+\\infty) \\rightarrow {\\bf R}}")#text(" is a smooth field to be chosen later. Admittedly the signum function ")#mi("{\\mathrm{sgn}}")#text(" is not smooth at ")#mi("{x_3}")#text(", but let us ignore this issue for now (to rigorously make an ansatz one will have to smooth out this function a little bit; Elgindi uses the choice ")#tao-math("{(\\left|\\sin \\theta\\right| \\cos^2 \\theta)^{\\alpha/3} \\mathrm{sgn}(x_3)}", block: false)#text(", where ")#mi("{\\theta := \\mathrm{arctan}(x_3/r)}")#text("). With this ansatz one may compute")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal L}_{12}(\\omega(t))(\\rho)  & \\approx \\frac{3\\alpha}{2\\pi} \\int_{\\left|y\\right| \\geq \\rho; y_3 \\geq 0} \\Omega(t,R) \\frac{r y_3}{\\left|y\\right|^5}\\ dy", block: true)



#tao-math(" & = \\alpha \\int_\\rho^\\infty \\Omega(t, s^\\alpha) \\frac{ds}{s}", block: true)



#tao-math(" & = \\int_{\\rho^\\alpha}^\\infty \\Omega(t,s) \\frac{ds}{s}.", block: true)
]

#text("By Proposition ")#link(<tao-8c1634dbc4f92409282c>)[#text("1")]#text(", we thus expect to have the approximation")

#align(center)[#tao-fit-display[#tao-math("u(t,x) \\approx \\frac{1}{2} \\int_{\\left|x\\right|^\\alpha}^\\infty \\Omega(t,s) \\frac{ds}{s} X(x).", block: true)]]

#text("We insert this into the vorticity equation ")#link(<tao-f77f484ce99781cbf892>)[#text("(2)")]#text(". The transport term ")#mi("{(u \\cdot \\nabla) \\omega}")#text(" will be expected to be negligible because ")#mi("{R}")#text(", and hence ")#mi("{\\omega_{rx_3}}")#text(", is slowly varying (the discontinuity of ")#mi("{\\mathrm{sgn}(x_3)}")#text(" will not be encountered because the vector field ")#mi("{X}")#text(" is parallel to this singularity). The modulating function ")#tao-math("{\\frac{1}{2} \\int_{\\left|x\\right|^\\alpha}^\\infty \\Omega(t,s) \\frac{ds}{s}}", block: false)#text(" is similarly slowly varying, so derivatives falling on this function should be lower order. Neglecting such terms, we arrive at the approximation")

#align(center)[#tao-fit-display[#tao-math("(\\omega \\cdot \\nabla) u \\approx \\frac{1}{2} \\int_{\\left|x\\right|^\\alpha}^\\infty \\Omega(t,s) \\frac{ds}{s} \\omega", block: true)]]

#text("and so in the limit ")#mi("{\\alpha \\rightarrow 0}")#text(" we expect obtain a simple model equation for the evolution of the vorticity envelope ")#mi("{\\Omega}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\Omega(t,R) = \\frac{1}{2} \\int_R^\\infty \\Omega(t,S) \\frac{dS}{S} \\Omega(t,R).")]]

#text("If we write ")#mi("{L(t,R) := \\int_R^\\infty \\Omega(t,S)\\frac{dS}{S}}")#text(" for the logarithmic primitive of ")#mi("{\\Omega}")#text(", then we have ")#mi("{\\Omega = - R \\partial_R L}")#text(" and hence")

#align(center)[#tao-fit-display[#mitex("\\partial_t (R \\partial_R L) = \\frac{1}{2} L (R \\partial_R L)")]]

#text("which integrates to the Ricatti equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t L = \\frac{1}{4} L^2")]]

#text("which can be explicitly solved as")

#align(center)[#tao-fit-display[#mitex("L(t,R) = \\frac{2}{f(R) - t/2}")]]

#text("where ")#mi("{f(R)}")#text(" is any function of ")#mi("{R}")#text(" that one pleases. (In Elgindi’s work a time dilation is used to remove the unsightly factor of ")#mi("{1/2}")#text(" appearing here in the denominator.) If for instance we set ")#mi("{f(R) = 1+R}")#text(", we obtain the self-similar solution")

#align(center)[#tao-fit-display[#mitex("L(t,R) = \\frac{2}{1+R-t/2}")]]

#text("and then on applying ")#mi("{-R \\partial_R}")

#align(center)[#tao-fit-display[#mitex("\\Omega(t,R) = \\frac{2R}{(1+R-t/2)^2}.")]]

#text("Thus, we expect to be able to construct a self-similar blowup to the Euler equations with a vorticity field approximately behaving like")

#align(center)[#tao-fit-display[#mitex("\\omega(t,x) \\approx \\alpha \\frac{2R}{(1+R-t/2)^2} \\mathrm{sgn}(x_3) (\\frac{x_2}{r}, -\\frac{x_1}{r}, 0)")]]

#text("and velocity field behaving like")

#align(center)[#tao-fit-display[#mitex("u(t,x) \\approx \\frac{1}{1+R-t/2} X(x).")]]

#text("In particular, ")#mi("{u}")#text(" would be expected to be of regularity ")#mi("{C^{1,\\alpha}}")#text(" (and smooth away from the origin), and blows up in (say) ")#mi("{L^\\infty}")#text(" norm at time ")#mi("{t/2 = 1}")#text(", and one has the self-similarity")

#align(center)[#tao-fit-display[#mitex("u(t,x) = (1-t/2)^{\\frac{1}{\\alpha}-1} u( 0, \\frac{x}{(1-t/2)^{1/\\alpha}} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\omega(t,x) = (1-t/2)^{-1} \\omega( 0, \\frac{x}{(1-t/2)^{1/\\alpha}} ).")]]

#text("A self-similar solution of this approximate shape is in fact constructed rigorously in Elgindi’s paper (using spherical coordinates instead of the Cartesian approach adopted here), using a nonlinear stability analysis of the above ansatz. It seems plausible that one could also carry out this stability analysis using this Cartesian coordinate approach, although I have not tried to do this in detail.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-534221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("Hello, if one were to proceed from here in the manner of Elgindi to construct a solution with approximately self-similar blowup, how would the conclusion differ from what he found?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-534260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("I think with the Cartesian coordinate approach, using the explicit kernel of the Biot-Savart law, it may be possible to obtain elliptic estimates for the velocity in terms of the vorticity somewhat more easily, and in particular it may be possible to relax the hypothesis of being axially symmetric without swirl. One reason why one would like to do so is that for smooth data that is axially symmetric without swirl global regularity is known, so if one is to have any hope of adapting these methods to disprove global regularity for Euler then one would have to either introduce swirl or abandon axial symmetry altogether.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-534248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("Dear Pro.Tao,")#linebreak()#text(" All people in the world are going to welcome New year, I have nothing special to give you. I only wish you always be healthy , happy and having many great breakthrough of maths in new year. I always expect the most interesting informations from you.")#linebreak()#text(" Best wishes,")#linebreak()#text(" Beal")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Burger")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-534283")[#strong[#text("Ralph Burger")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2019")])]

#text("Usually in Physics one encounters the Biot-Savart law first in electrodynamics where it relates the current density (w) with the magnetisation density (u). I wonder if this approximation has an interesting physical interpretation in that sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-534296")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2019")])]

#text("This approximation would correspond to a situation in which the current density is distributed more or less evenly over a large ball, but one is only interested in the magnetic field near the origin. The adjoint (dual) situation in which the current density is localised, but one is interested in the far field behaviour of the magnetic field, is more common in physical situations. Indeed one can view the adjoint of this approximation (now measuring using ")#mi("L^1")#text(" norms rather than ")#mi("L^\\infty")#text(" norms) as basically the first two terms of the ")#link("https://en.wikipedia.org/wiki/Multipole_expansion")[#text("multipole expansion")]#text(" for the far field for the Biot-Savart law (which is basically its own adjoint, up to signs); in the case when the current density is axially symmetric and without “swirl”, the zeroth term of the expansion vanishes vanishes, leaving only the first-order term (which decays like the cube of the distance).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-534448")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("I think the breakthrough in the blowup solution of Euler equation will soon lead to the discovery of blowup solution of the Navier Stokes equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72f43f012cc4176eddd4defda2889a2294cb5b3d48c4789ec22c249f0a0fd71f-d39964267686407cb8f696d75050326ea6357865398147aac86e2fc057467eac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clement")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-535082")[#strong[#text("Clement")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2020")])]

#text("Hello,")

#text("Thanks for the interesting post!")

#text("A (perhaps somehow) related question: do you know of studies of the PDE ")#mi("\\partial_t u = \\nabla \\times u")#text(" (with some boundary conditions). I am curious about the behavior of the solutions to such an equation (and about what this would tell us about the eigenfunctions of the curl operator).")

#text("Best,")#linebreak()#text(" Clement")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-535136")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2020")])]

#text("I have not encountered this equation in the literature. On Euclidean spaces or on the torus one can solve the equation exactly using the Fourier transform of course. On the other hand, the eigenfunctions of curl are also known as ")#link("https://en.wikipedia.org/wiki/Beltrami_flow")[#text("Beltrami flows")]#text(" and have been extensively studied in the fluids literature.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf61bc322ab75831afdc7cfec94838fe017a6063ad00cd3ef08bab46b670d887-86efa4169457958702e15671cc399fd87baa4f3cf92db02c375eaa4ec8bfb676.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of s 1291")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-535643")[#strong[#text("s 1291")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#text("Hello Professor,")#linebreak()#text(" You could refine this new theory of flight that states “The Brandtl Boundary layer assumptions are wrong”. ")#link("https://link.springer.com/content/pdf/10.1007/s00021-015-0220-y.pdf")[#text("https://link.springer.com/content/pdf/10.1007/s00021-015-0220-y.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf61bc322ab75831afdc7cfec94838fe017a6063ad00cd3ef08bab46b670d887-86efa4169457958702e15671cc399fd87baa4f3cf92db02c375eaa4ec8bfb676.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of s 1291")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-535645")[#strong[#text("s 1291")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#text("Just to be more precise, here is the summary:")#linebreak()#text(" The new theory shows that the miracle of flight is made possible by the combined effects of (i) incompressibility, (ii) slip boundary condition and (iii) 3d rotational slip separation, creating a flow around a wing which can be described as (iv) potential flow modified by 3d rotational separation. The basic novelty of the theory is expressed in (iii) as a fundamental 3d flow phenomenon only recently discovered by advanced computation and analyzed mathematically, and thus is not present in the classical theory. Finally, (iv) can be viewed as a realization in our computer age of Euler’s original dream to in his equations capture an unified theory of fluid flow. The crucial conditions of (ii) a slip boundary condition and (iii) 3d rotational slip separation show to be safely satisfied by incompressible flow if the Reynolds number is larger than 106. For lower Reynolds numbers the new theory suggests analysis and design with focus on maintaining (ii) and (iii). In forthcoming work we will study the mechanism and computational prediction of stall in more detail.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A possible approach to finite time blowup for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2019/12/26/elgindis-approximation-of-the-biot-savart-law/#comment-685743")[#strong[#text("A possible approach to finite time blowup for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2024")])]

#text("[…] versions of this problem. For instance, there is the well-known result of Elgindi (discussed in this previous post) that when and is sufficiently small, there exists a solution to the Euler equations on that […]")
]
