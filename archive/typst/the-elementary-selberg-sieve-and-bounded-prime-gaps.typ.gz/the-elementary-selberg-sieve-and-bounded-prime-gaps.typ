// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/
// Converted to Typst by tao2typ: "2026-10-14T15:18:38.771675+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The elementary Selberg sieve and bounded prime gaps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The elementary Selberg sieve and bounded prime gaps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post is a continuation of the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("previous post on sieve theory")]#text(", which is an ongoing part of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(" to improve the various parameters in ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s proof")]#text(" that bounded gaps between primes occur infinitely often. Given that the comments on that page are getting quite lengthy, this is also a good opportunity to “roll over” that thread.")

#text("We will continue the notation from the previous post, including the concept of an admissible tuple, the use of an asymptotic parameter ")#mi("{x}")#text(" going to infinity, and a quantity ")#mi("{w}")#text(" depending on ")#mi("{x}")#text(" that goes to infinity sufficiently slowly with ")#mi("{x}")#text(", and ")#mi("{W := \\prod_{p<w} p}")#text(" (the ")#mi("{W}")#text("-trick).")

#text("The objective of this portion of the Polymath8 project is to make as efficient as possible the connection between two types of results, which we call ")#mi("{DHL[k_0,2]}")#text(" and ")#mi("{MPZ[\\varpi,\\delta]}")#text(". Let us first state ")#mi("{DHL[k_0,2]}")#text(", which has an integer parameter ")#mi("{k_0 \\geq 2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1")]#text(" (")#mi("{DHL[k_0,2]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple. Then there are infinitely many translates ")#mi("{n+{\\mathcal H}}")#text(" of ")#mi("{{\\mathcal H}}")#text(" which contain at least two primes.")
]

#text("Zhang was the first to prove a result of this type with ")#mi("{k_0 = 3,500,000}")#text(". Since then the value of ")#mi("{k_0}")#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#World_records")[#text("has been lowered substantially")]#text("; at this time of writing, the current record is ")#mi("{k_0 = 26,024}")#text(".")

#text("There are two basic ways known currently to attain this conjecture. The first is to use the Elliott-Halberstam conjecture ")#mi("{EH[\\theta]}")#text(" for some ")#mi("{\\theta>1/2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2")]#text(" (")#mi("{EH[\\theta]}")#text(") One has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq q \\leq x^\\theta} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{n < x: n = a\\ (q)} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{n < x} \\Lambda(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("= O( \\frac{x}{\\log^A x} )")]]

#text("for all fixed ")#mi("{A>0}")#text(". Here we use the abbreviation ")#mi("{n=a\\ (q)}")#text(" for ")#mi("{n=a \\text{ mod } q}")#text(".")
]

#text("Here of course ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" and ")#mi("{\\phi}")#text(" the ")#link("http://en.wikipedia.org/wiki/Euler_totient_function")[#text("Euler totient function")]#text(". It is conjectured that ")#mi("{EH[\\theta]}")#text(" holds for all ")#mi("{0 < \\theta < 1}")#text(", but this is currently only known for ")#mi("{0 < \\theta < 1/2}")#text(", an important result known as the ")#link("http://en.wikipedia.org/wiki/Bombieri-Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(".")

#text("In a breakthrough paper, ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("Goldston, Yildirim, and Pintz")]#text(" established an implication of the form ")#metadata(none) <tao-798e31944547f9190838>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("EH[\\theta] \\implies DHL[k_0,2]")]]

#text("for any ")#mi("{1/2 < \\theta < 1}")#text(", where ")#mi("{k_0 = k_0(\\theta)}")#text(" depends on ")#mi("{\\theta}")#text(". This deduction was very recently optimised ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("by Farkas, Pintz, and Revesz")]#text(" and also independently in the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("comments to the previous blog post")]#text(", leading to the following implication:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (EH implies DHL)")]#text(" ")#metadata(none) <tao-8d02dd559534832e1f68>#text(" Let ")#mi("{1/2 < \\theta < 1}")#text(" be a real number, and let ")#mi("{k_0 \\geq 2}")#text(" be an integer obeying the inequality ")#metadata(none) <tao-37b767adda79b779b49d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("2\\theta > \\frac{j_{k_0-2}^2}{k_0(k_0-1)},")]]

#text("where ")#mi("{j_n}")#text(" is the first positive zero of the Bessel function ")#mi("{J_n(x)}")#text(". Then ")#mi("{EH[\\theta]}")#text(" implies ")#mi("{DHL[k_0,2]}")#text(".")
]

#text("Note that the right-hand side of ")#link(<tao-37b767adda79b779b49d>)[#text("(2)")]#text(" is larger than ")#mi("{1}")#text(", but tends asymptotically to ")#mi("{1}")#text(" as ")#mi("{k_0 \\rightarrow \\infty}")#text(". We give an alternate proof of Theorem ")#link(<tao-8d02dd559534832e1f68>)[#text("3")]#text(" below the fold.")

#text("Implications of the form Theorem ")#link(<tao-8d02dd559534832e1f68>)[#text("3")]#text(" were modified ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("by Motohashi and Pintz")]#text(", which in our notation replaces ")#mi("{EH[\\theta]}")#text(" by an easier conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" for some ")#mi("{0 < \\varpi < 1/4}")#text(" and ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", at the cost of degrading the sufficient condition ")#link(<tao-37b767adda79b779b49d>)[#text("(2)")]#text(" slightly. In our notation, this conjecture takes the following form for each choice of parameters ")#mi("{\\varpi,\\delta}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 4")]#text(" (")#mi("{MPZ[\\varpi,\\delta]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be a fixed ")#mi("{k_0}")#text("-tuple (not necessarily admissible) for some fixed ")#mi("{k_0 \\geq 2}")#text(", and let ")#mi("{b\\ (W)}")#text(" be a primitive residue class. Then ")#metadata(none) <tao-6d7e04068fa604f0ea60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\sum_{a \\in C(q)} \\left|\\Delta_{b,W}(\\Lambda; q,a)\\right| = O( x \\log^{-A} x)", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{I = (w,x^{\\delta})}")#text(", ")#mi("{{\\mathcal S}_I}")#text(" are the square-free integers whose prime factors lie in ")#mi("{I}")#text(", and ")#mi("{\\Delta_{b,W}(\\Lambda;q,a)}")#text(" is the quantity ")#metadata(none) <tao-c1a421182e1fb908168f>

#tao-aligned(keep: true)[


#tao-math("\\Delta_{b,W}(\\Lambda;q,a)  & := | \\sum_{x \\leq n \\leq 2x: n=b\\ (W); n = a\\ (q)} \\Lambda(n)", block: true, numbering: n => [#text("(4)")])



#tao-math(" & - \\frac{1}{\\phi(q)} \\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\Lambda(n)|.", block: true)
]

#text("and ")#mi("{C(q)}")#text(" is the set of congruence classes")

#align(center)[#tao-fit-display[#mitex("C(q) := \\{ a \\in ({\\bf Z}/q{\\bf Z})^\\times: P(a) = 0 \\}")]]

#text("and ")#mi("{P}")#text(" is the polynomial")

#align(center)[#tao-fit-display[#mitex("P(a) := \\prod_{h \\in {\\mathcal H}} (a+h).")]]
]

#text("This is a weakened version of the Elliott-Halberstam conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (EH implies MPZ)")]#text(" ")#metadata(none) <tao-3e66ba098b3789d68366>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(" and ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(". Then ")#mi("{EH[1/2+2\\varpi+\\epsilon]}")#text(" implies ")#mi("{MPZ[\\varpi,\\delta]}")#text(" for any ")#mi("{\\epsilon>0}")#text(". (In abbreviated form: ")#mi("{EH[1/2+2\\varpi+]}")#text(" implies ")#mi("{MPZ[\\varpi,\\delta]}")#text(".)")
]

#text("In particular, since ")#mi("{EH[\\theta]}")#text(" is conjecturally true for all ")#mi("{0 < \\theta < 1/2}")#text(", we conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" to be true for all ")#mi("{0 < \\varpi < 1/4}")#text(" and ")#mi("{0<\\delta<1/4+\\varpi}")#text(".")

#emph[#text("Proof:")]#text(" Define")

#align(center)[#tao-fit-display[#tao-math("E(q) := \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{x \\leq n \\leq 2x: n = a\\ (q)} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{x \\leq n \\leq 2x} \\Lambda(n)\\right|", block: true)]]

#text("then the hypothesis ")#mi("{EH[1/2+2\\varpi+\\epsilon]}")#text(" (applied to ")#mi("{x}")#text(" and ")#mi("{2x}")#text(" and then subtracting) tells us that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq q \\leq Wx^{1/2+2\\varpi}} E(q) \\ll x \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(". From the Chinese remainder theorem and the Siegel-Walfisz theorem we have")

#align(center)[#tao-fit-display[#mitex("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\Delta_{b,W}(\\Lambda;q,a) \\ll E(qW) + \\frac{1}{\\phi(q)} x \\log^{-A} x")]]

#text("for any ")#mi("{q}")#text(" coprime to ")#mi("{W}")#text(" (and in particular for ")#mi("{q \\in {\\mathcal S}_I}")#text("). Since ")#tao-math("{\\left|C(q)\\right| \\leq k_0^{\\Omega(q)}}", block: false)#text(", where ")#mi("{\\Omega(q)}")#text(" is the number of prime divisors of ")#mi("{q}")#text(", we can thus bound the left-hand side of ")#link(<tao-6d7e04068fa604f0ea60>)[#text("(3)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} k_0^{\\Omega(q)} E(qW) + k_0^{\\Omega(q)} \\frac{1}{\\phi(q)} x \\log^{-A} x.")]]

#text("The contribution of the second term is ")#mi("{O(x \\log^{-A+O(1)} x)}")#text(" by standard estimates (see Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" below). Using the very crude bound")

#align(center)[#tao-fit-display[#mitex("E(q) \\ll \\frac{1}{\\phi(q)} x \\log x")]]

#text("and standard estimates we also have")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} k_0^{2\\Omega(q)} E(qW) \\ll x \\log^{O(1)} A")]]

#text("and the claim now follows from the Cauchy-Schwarz inequality. ")#mi("\\Box")

#text("In practice, the conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" is easier to prove than ")#mi("{EH[1/2+2\\varpi+]}")#text(" due to the restriction of the residue classes ")#mi("{a}")#text(" to ")#mi("{C(q)}")#text(", and also the restriction of the modulus ")#mi("{q}")#text(" to ")#mi("{x^\\delta}")#text("-smooth numbers. ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang proved")]#text(" ")#mi("{MPZ[\\varpi,\\varpi]}")#text(" for any ")#mi("{0 < \\varpi < 1/1168}")#text(". More recently, our Polymath8 group has analysed Zhang’s argument (using in part a corrected version of the analysis of a ")#link("http://arxiv.org/abs/1306.1497")[#text("recent preprint of Pintz")]#text(") to obtain ")#mi("{MPZ[\\varpi,\\delta]}")#text(" whenever ")#mi("{\\delta, \\varpi > 0}")#text(" are such that")

#align(center)[#tao-fit-display[#mitex("207\\varpi + 43\\delta < \\frac{1}{4}.")]]

#text("The work of Motohashi and Pintz, and later Zhang, implicitly describe arguments that allow one to deduce ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{MPZ[\\varpi,\\delta]}")#text(" provided that ")#mi("{k_0}")#text(" is sufficiently large depending on ")#mi("{\\varpi,\\delta}")#text(". The best implication of this sort that we have been able to verify thus far is the following result, established in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("the previous post")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (MPZ implies DHL)")]#text(" ")#metadata(none) <tao-ced2128f3bc92a5720f7>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", and let ")#mi("{k_0 \\geq 2}")#text(" be an integer obeying the constraint ")#metadata(none) <tao-2348f998744212575d85>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("1+4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")]]

#text("where ")#mi("{\\kappa}")#text(" is the quantity")

#align(center)[#tao-fit-display[#mitex("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0/2} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) ).")]]

#text("Then ")#mi("{MPZ[\\varpi,\\delta]}")#text(" implies ")#mi("{DHL[k_0,2]}")#text(".")
]

#text("This complicated version of ")#mi("{\\kappa}")#text(" is roughly of size ")#mi("{3 \\log(2) k_0 \\exp( - k_0 \\delta)}")#text(". It is unlikely to be optimal; the ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("work of Motohashi-Pintz")]#text(" and ")#link("http://arxiv.org/abs/1306.1497")[#text("Pintz")]#text(" suggests that it can essentially be improved to ")#mi("{\\frac{1}{\\delta} \\exp(-k_0 \\delta)}")#text(", but currently we are unable to verify this claim. One of the aims of this post is to encourage further discussion as to how to improve the ")#mi("{\\kappa}")#text(" term in results such as Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("6")]#text(".")

#text("We remark that as ")#link(<tao-2348f998744212575d85>)[#text("(5)")]#text(" is an open condition, it is unaffected by infinitesimal modifications to ")#mi("{\\varpi,\\delta}")#text(", and so we do not ascribe much importance to such modifications (e.g. replacing ")#mi("{\\varpi}")#text(" by ")#mi("{\\varpi-\\epsilon}")#text(" for some arbitrarily small ")#mi("{\\epsilon>0}")#text(").")

#text("The known deductions of ")#mi("{DHL[k_0,2]}")#text(" from claims such as ")#mi("{EH[\\theta]}")#text(" or ")#mi("{MPZ[\\varpi,\\delta]}")#text(" rely on the following elementary observation of Goldston, Pintz, and Yildirim (essentially a weighted pigeonhole principle), which we have placed in “")#mi("{W}")#text("-tricked form”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Criterion for DHL)")]#text(" ")#metadata(none) <tao-d5963d22f572ba25cba0>#text(" Let ")#mi("{k_0 \\geq 2}")#text(". Suppose that for each fixed admissible ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(" and each congruence class ")#mi("{b\\ (W)}")#text(" such that ")#mi("{b+h}")#text(" is coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(", one can find a non-negative weight function ")#mi("{\\nu: {\\bf N} \\rightarrow {\\bf R}^+}")#text(", fixed quantities ")#mi("{\\alpha,\\beta > 0}")#text(", a quantity ")#mi("{A>0}")#text(", and a fixed positive power ")#mi("{R}")#text(" of ")#mi("{x}")#text(" such that one has the upper bound ")#metadata(none) <tao-e8bc163c82eee1873328>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\leq (\\alpha+o(1)) A\\frac{x}{W},")]]

#text("the lower bound ")#metadata(none) <tao-ad328846aa18b32a3358>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) \\theta(n+h_i) \\geq (\\beta-o(1)) A\\frac{x}{W} \\log R")]]

#text("for all ")#mi("{h_i \\in {\\mathcal H}}")#text(", and the key inequality ")#metadata(none) <tao-2c70e12b7a0646f92279>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{\\log R}{\\log x} > \\frac{1}{k_0} \\frac{\\alpha}{\\beta}")]]

#text("holds. Then ")#mi("{DHL[k_0,2]}")#text(" holds. Here ")#mi("{\\theta(n)}")#text(" is defined to equal ")#mi("{\\log n}")#text(" when ")#mi("{n}")#text(" is prime and ")#mi("{0}")#text(" otherwise.")
]

#emph[#text("Proof:")]#text(" Consider the quantity ")#metadata(none) <tao-7327d4d86dcf6bd569c0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b\\ (W)} \\nu(n) (\\sum_{h \\in {\\mathcal H}} \\theta(n+h) - \\log(3x)).")]]

#text("By ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(", this quantity is at least")

#align(center)[#tao-fit-display[#mitex("k_0 \\beta A\\frac{x}{W} \\log R - \\alpha \\log(3x) A\\frac{x}{W} - o(A\\frac{x}{W} \\log x).")]]

#text("By ")#link(<tao-2c70e12b7a0646f92279>)[#text("(8)")]#text(", this expression is positive for all sufficiently large ")#mi("{x}")#text(". On the other hand, ")#link(<tao-7327d4d86dcf6bd569c0>)[#text("(9)")]#text(" can only be positive if at least one summand is positive, which only can happen when ")#mi("{n+{\\mathcal H}}")#text(" contains at least two primes for some ")#mi("{x \\leq n \\leq 2x}")#text(" with ")#mi("{n=b\\ (W)}")#text(". Letting ")#mi("{x \\rightarrow \\infty}")#text(" we obtain ")#mi("{DHL[k_0,2]}")#text(" as claimed. ")#mi("\\Box")

#text("In practice, the quantity ")#mi("{R}")#text(" (referred to as the ")#emph[#text("sieve level")]#text(") is a power of ")#mi("{x}")#text(" such as ")#mi("{x^{\\theta/2}}")#text(" or ")#mi("{x^{1/4+\\varpi}}")#text(", and reflects the strength of the distribution hypothesis ")#mi("{EH[\\theta]}")#text(" or ")#mi("{MPZ[\\varpi,\\delta]}")#text(" that is available; the quantity ")#mi("{R}")#text(" will also be a key parameter in the definition of the sieve weight ")#mi("{\\nu}")#text(". The factor ")#mi("{A}")#text(" reflects the order of magnitude of the expected density of ")#mi("{\\nu}")#text(" in the residue class ")#mi("{b\\ (W)}")#text("; it could be absorbed into the sieve weight ")#mi("{\\nu}")#text(" by dividing that weight by ")#mi("{A}")#text(", but it is convenient to not enforce such a normalisation so as not to clutter up the formulae. In practice, ")#mi("{A}")#text(" will some combination of ")#mi("{\\frac{\\phi(W)}{W}}")#text(" and ")#mi("{\\log R}")#text(".")

#text("Once one has decided to rely on Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("7")]#text(", the next main task is to select a good weight ")#mi("{\\nu}")#text(" for which the ratio ")#mi("{\\alpha/\\beta}")#text(" is as small as possible (and for which the sieve level ")#mi("{R}")#text(" is as large as possible. To ensure non-negativity, we use the Selberg sieve ")#metadata(none) <tao-30864e2911d2701d1f80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\nu = \\lambda^2,")]]

#text("where ")#mi("{\\lambda(n)}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) = \\sum_{d \\in {\\mathcal S}_I: d|P(n)} \\mu(d) a_d")]]

#text("for some weights ")#mi("{a_d \\in {\\bf R}}")#text(" vanishing for ")#mi("{d>R}")#text(" that are to be chosen, where ")#mi("{I \\subset (w,+\\infty)}")#text(" is an interval and ")#mi("{P}")#text(" is the polynomial ")#mi("{P(n) := \\prod_{h \\in {\\mathcal H}} (n+h)}")#text(". If the distribution hypothesis is ")#mi("{EH[\\theta]}")#text(", one takes ")#mi("{R := x^{\\theta/2}}")#text(" and ")#mi("{I := (w,+\\infty)}")#text("; if the distribution hypothesis is instead ")#mi("{MPZ[\\varpi,\\delta]}")#text(", one takes ")#mi("{R := x^{1/4+\\varpi}}")#text(" and ")#mi("{I := (w,x^\\delta)}")#text(".")

#text("One has a useful amount of flexibility in selecting the weights ")#mi("{a_d}")#text(" for the Selberg sieve. The ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("original work of Goldston, Pintz, and Yildirim")]#text(", as well as the subsequent ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("paper of Zhang")]#text(", the choice")

#align(center)[#tao-fit-display[#mitex("a_d := \\log(\\frac{R}{d})_+^{k_0+\\ell_0}")]]

#text("is used for some additional parameter ")#mi("{\\ell_0 > 0}")#text(" to be optimised over. More generally, one can take")

#align(center)[#tao-fit-display[#mitex("a_d := g( \\frac{\\log d}{\\log R} )")]]

#text("for some suitable (in particular, sufficiently smooth) cutoff function ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}}")#text(". We will refer to this choice of sieve weights as the “analytic Selberg sieve”; this is the choice used in the analysis in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("the previous post")]#text(".")

#text("However, there is a slight variant choice of sieve weights that one can use, which I will call the “elementary Selberg sieve”, and it takes the form ")#metadata(none) <tao-56de49fda9f32f60654b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("a_d := \\frac{1}{\\Phi(d) \\Delta(d)} \\sum_{q \\in {\\mathcal S}_I: (q,d)=1} \\frac{1}{\\Phi(q)} f^{\\prime}( \\frac{\\log dq}{\\log R})")]]

#text("for a sufficiently smooth function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Phi(d) := \\prod_{p|d} \\frac{p-k_0}{k_0}")]]

#text("for ")#mi("{d \\in {\\mathcal S}_I}")#text(" is a ")#mi("{k_0}")#text("-variant of the Euler totient function, and")

#align(center)[#tao-fit-display[#mitex("\\Delta(d) := \\prod_{p|d} \\frac{k_0}{p} = \\frac{k_0^{\\Omega(d)}}{d}")]]

#text("for ")#mi("{d \\in {\\mathcal S}_I}")#text(" is a ")#mi("{k_0}")#text("-variant of the function ")#mi("{1/d}")#text(". (The derivative on the ")#mi("{f}")#text(" cutoff is convenient for computations, as will be made clearer later in this post.) This choice of weights ")#mi("{a_d}")#text(" may seem somewhat arbitrary, but it arises naturally when considering how to optimise the quadratic form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\Delta([d_1,d_2])")]]

#text("(which arises naturally in the estimation of ")#mi("{\\alpha}")#text(" in ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(") subject to a fixed value of ")#mi("{a_1}")#text(" (which morally is associated to the estimation of ")#mi("{\\beta}")#text(" in ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text("); this is discussed in any sieve theory text as part of the general theory of the Selberg sieve, e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("Friedlander-Iwaniec")]#text(".")

#text("The use of the elementary Selberg sieve for the bounded prime gaps problem was studied ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("by Motohashi and Pintz")]#text(". Their arguments give an alternate derivation of ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{MPZ[\\varpi,\\theta]}")#text(" for ")#mi("{k_0}")#text(" sufficiently large, although unfortunately we were not able to confirm some of their calculations regarding the precise dependence of ")#mi("{k_0}")#text(" on ")#mi("{\\varpi,\\theta}")#text(", and in particular we have not yet been able to improve upon the specific criterion in Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("6")]#text(" using the elementary sieve. However it is quite plausible that such improvements could become available with additional arguments.")

#text("Below the fold we describe how the elementary Selberg sieve can be used to reprove Theorem ")#link(<tao-8d02dd559534832e1f68>)[#text("3")]#text(", and discuss how they could potentially be used to improve upon Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("6")]#text(". (But the elementary Selberg sieve and the analytic Selberg sieve are in any event closely related; see the appendix of ")#link("http://www.ams.org/mathscinet-getitem?mr=2245880")[#text("this paper of mine with Ben Green")]#text(" for some further discussion.) For the purposes of polymath8, either developing the elementary Selberg sieve or continuing the analysis of the analytic Selberg sieve from the previous post would be a relevant topic of conversation in the comments to this post.")

#metadata(none) <tao-aab164f87f5e68cfa5ba>

#heading(level: 1)[#strong[#text(" — 1. Sums of multiplicative functions — ")]]

#text("In this section we review a standard estimate on a sum of ")#link("http://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative functions")]#text(". We fix an interval ")#mi("{I \\subset (w,+\\infty)}")#text(". For any positive integer ")#mi("{k}")#text(", we say that a multiplicative function ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" ")#emph[#text("has dimension")]#text(" ")#mi("{k}")#text(" if one has the asymptotic")

#align(center)[#tao-fit-display[#mitex("f(p) = k + O(\\frac{1}{p})")]]

#text("for all ")#mi("{p \\in I}")#text("; in particular (since ")#mi("{w \\rightarrow \\infty}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(") we see that ")#mi("{f}")#text(" is non-negative on ")#mi("{S_I}")#text(" for ")#mi("{x}")#text(" large enough. Thus for instance")

#align(center)[#tao-fit-display[#mitex("n \\mapsto \\frac{\\phi(n)}{n}")]]

#text("has dimension one, the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]

#align(center)[#tao-fit-display[#mitex("n \\mapsto \\tau(n)")]]

#text("has dimension two, and the functions")

#tao-aligned(keep: true)[


#tao-math("n  & \\mapsto k_0^{\\Omega(n)},", block: true)



#tao-math("n  & \\mapsto \\frac{n}{\\Phi(n)},", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("n \\mapsto n \\Delta(n)")]]

#text("defined in the introduction have dimension ")#mi("{k_0}")#text(". Dimension interacts well with multiplication; the product of a ")#mi("{k}")#text("-dimensional multiplicative function and a ")#mi("{k^{\\prime}}")#text("-dimensional multiplicative function is clearly a ")#mi("{kk^{\\prime}}")#text("-multiplicative function.")

#text("We have the following basic asymptotic in the untruncated case ")#mi("{I = (w,+\\infty)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Untruncated asymptotic)")]#text(" ")#metadata(none) <tao-30b84cf23324188a95ee>#text(" Let ")#mi("{I = (w,+\\infty)}")#text(" Let ")#mi("{k}")#text(" be a fixed positive integer, and let ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" be a multiplicative function of dimension ")#mi("{k}")#text(". Then for any fixed compactly supported, Riemann-integrable function ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}}")#text(", and any ")#mi("{R>1}")#text(" that goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I} \\frac{f(d)}{d} g(\\frac{\\log d}{\\log R}) = (\\frac{\\phi(W)}{W} \\log R)^k ( \\int_0^\\infty g(t) \\frac{t^{k-1}}{(k-1)!}\\ dt + o(1) ).")]]
]

#emph[#text("Proof:")]#text(" By approximating ")#mi("{g}")#text(" from above and below by smooth compactly supported functions we see that we may assume without loss of generality that ")#mi("{g}")#text(" is smooth and compactly supported. But then the claim follows from Proposition 10 of the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("previous post")]#text(". ")#mi("\\Box")

#text("We remark that Proposition 10 of the previous post also gives asymptotics for a number of other sums of multiplicative functions, but one (small) advantage of the elementary Selberg sieve is that these (slightly) more complicated asymptotics are not needed. The generalisation in Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" from smooth ")#mi("{g}")#text(" to Riemann integrable ")#mi("{g}")#text(" implies in particular that ")#metadata(none) <tao-751b6b487c02be8b0efe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{d \\in {\\mathcal S}_I: d \\leq R} \\frac{f(d)}{d} = (\\frac{1}{k!} + o(1)) (\\frac{\\phi(W)}{W} \\log R)^k")]]

#text("and conversely Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" can be easily deduced from ")#link(<tao-751b6b487c02be8b0efe>)[#text("(12)")]#text(" by another approximation argument (using piecewise constant functions instead of smooth functions). We also make the trivial remark that if ")#mi("{g}")#text(" is non-negative and ")#mi("{J}")#text(" is any subset of ")#mi("{I}")#text(", then we have the upper bound ")#metadata(none) <tao-63718a50ee57d3201e7d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{d \\in {\\mathcal S}_J} \\frac{f(d)}{d} g(\\frac{\\log d}{\\log R}) \\leq (\\frac{\\phi(W)}{W} \\log R)^k ( \\int_0^\\infty g(t) \\frac{t^{k-1}}{(k-1)!}\\ dt + o(1) )")]]

#text("for any non-negative Riemann integrable ")#mi("{g}")#text(".")

#text("Actually, ")#link(<tao-751b6b487c02be8b0efe>)[#text("(12)")]#text(" can be derived by purely elementary means (without the need to explicitly work with asymptotics of zeta functions as was done in the previous post) by an induction on the dimension ")#mi("{k}")#text(" as follows. In the dimension zero case we have the Euler product")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\in {\\mathcal S}_I} \\frac{\\left|f(d)\\right|}{d} = \\prod_{p \\in I} (1 + \\frac{\\left|f(p)\\right|}{p}) = 1+o(1)", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\in {\\mathcal S}_I: d\\neq 1} \\frac{\\left|f(d)\\right|}{d} = o(1)", block: true)]]

#text("which gives ")#link(<tao-751b6b487c02be8b0efe>)[#text("(12)")]#text(" in the ")#mi("{k=0}")#text(" case.")

#text("Now suppose that ")#mi("{f}")#text(" has dimension ")#mi("{1}")#text(". In this case we write ")#metadata(none) <tao-c380779f6175766fdbe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("f(d) 1_{{\\mathcal S}_I}(d) = \\sum_{a|d; d/a \\in {\\mathcal S}_I} h(a)")]]

#text("where ")#mi("{h}")#text(" is a multiplicative function with")

#align(center)[#tao-fit-display[#mitex("h(p^j) := (-1)^{j-1} (f(p)-1) = O(\\frac{1}{p^2}),")]]

#text("for all ")#mi("{p > w}")#text(" and ")#mi("{j \\geq 1}")#text(", and ")#mi("{h(p^j)=0}")#text(" for ")#mi("{p \\leq w}")#text(" and ")#mi("{j \\geq 1}")#text(". Then the left-hand side of ")#link(<tao-751b6b487c02be8b0efe>)[#text("(12)")]#text(" can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\leq R} \\frac{h(a)}{a} \\sum_{d \\in {\\mathcal S}_I: d \\leq R/a} \\frac{1}{d}.")]]

#text("Elementary sieving gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d \\leq y} 1 = (\\frac{\\phi(W)}{W} + o(1)) y + O( W )")]]

#text("and hence by summation by parts")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d \\leq y} \\frac{1}{d} = (\\frac{\\phi(W)}{W} + o(1)) \\log y + O( W ).")]]

#text("Meanwhile we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_a \\frac{\\left|h(a)\\right|}{a} = \\prod_{p > w} (1 + \\sum_{p=1}^\\infty \\frac{\\left|f(p)-1\\right|}{p^j}) = 1+o(1)", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\neq 1} \\frac{\\left|h(a)\\right|}{a} = o(1).", block: true)]]

#text("From these estimates one easily obtains ")#link(<tao-751b6b487c02be8b0efe>)[#text("(12)")]#text(" for ")#mi("{k=1}")#text(".")

#text("Now suppose that ")#mi("{k \\geq 1}")#text(" and that the claim has been proven inductively for ")#mi("{k-1}")#text(". We again may decompose ")#link(<tao-c380779f6175766fdbe9>)[#text("(14)")]#text(", but now ")#mi("{g}")#text(" has dimension ")#mi("{k-1}")#text(" instead of dimension zero. Arguing as before, we can write the left-hand side of ")#link(<tao-751b6b487c02be8b0efe>)[#text("(12)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in {\\mathcal S}_I: a \\leq R} \\frac{h(a)}{a} ( (\\frac{\\phi(W)}{W} + o(1)) \\log y + O( W ) ).")]]

#text("The contribution of the ")#mi("{o(1)}")#text(" and ")#mi("{O(W)}")#text(" error terms are acceptable by induction hypothesis, and the main term is also acceptable from induction hypothesis and summation by parts, giving the claim.")

#heading(level: 1)[#strong[#text(" — 2. Untruncated implication — ")]]

#text("We first reprove Theorem ")#link(<tao-8d02dd559534832e1f68>)[#text("3")]#text(". The key calculations for ")#mi("{\\alpha}")#text(" and ")#mi("{\\beta}")#text(" are as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Untruncated sieve bounds)")]#text(" ")#metadata(none) <tao-311f38b7836c4228463d>#text(" Assume ")#mi("{EH[\\theta+\\epsilon]}")#text(" holds for some ")#mi("{1/2 < \\theta < 1}")#text(" and some ")#mi("{\\epsilon>0}")#text(". Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a smooth function that is supported on ")#mi("{[-1,1]}")#text(", let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple for some fixed ")#mi("{k_0 \\geq 2}")#text(", let ")#mi("{b\\ (W)}")#text(" be such that ")#mi("{b+h}")#text(" is coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(", and let ")#mi("{\\nu}")#text(" be the elementary Selberg sieve with weights ")#link(<tao-56de49fda9f32f60654b>)[#text("(11)")]#text(" associated to the function ")#mi("{f}")#text(", the sieve level ")#mi("{R := x^{\\theta/2}}")#text(" and the untruncated interval ")#mi("{I := (w,+\\infty)}")#text(". Then ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(" hold with ")#metadata(none) <tao-f81ab872625c131d92e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\alpha := \\int_0^1 f^{\\prime}(t)^2 \\frac{t^{k_0-1}}{(k_0-1)!}\\ dt,")]]

#metadata(none) <tao-f096890dbb1b514cf178>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\beta := \\int_0^1 f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt,")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("A := (\\frac{\\phi(W)}{W} \\log R)^{k_0}.")]]
]

#text("As computed in Theorem 14 of ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("the previous post")]#text(" (and also in the ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("recent preprint of Farkas, Pintz, and Revesz")]#text("), the ratio")

#align(center)[#tao-fit-display[#mitex("\\frac{\\int_0^1 f^{\\prime}(t)^2 t^{k_0-1}\\ dt}{\\int_0^1 f(t)^2 t^{k_0-2}\\ dt}")]]

#text("for non-zero ")#mi("{f}")#text(" can be made arbitrarily close to ")#mi("{j_{k_0-2}^2/4}")#text(" (the extremiser is not quite smooth at ")#mi("{t=1}")#text(" if one extends by zero for ")#mi("{t>1}")#text(", but this can be easily dealt with by a standard regularisation argument), and Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("6")]#text(" then follows from Lemma ")#link(<tao-d5963d22f572ba25cba0>)[#text("7")]#text(" (using the open nature of ")#link(<tao-37b767adda79b779b49d>)[#text("(2)")]#text(" to replace ")#mi("{EH[\\theta]}")#text(" by ")#mi("{EH[\\theta+\\epsilon]}")#text(" for some small ")#mi("{\\epsilon>0}")#text(").")

#text("It remains to prove Lemma ")#link(<tao-311f38b7836c4228463d>)[#text("9")]#text(". We begin with the proof of ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(" (which will in fact be an asymptotic and not just an upper bound).")

#text("We expand the left-hand side of ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\sum_{x \\leq n \\leq 2x: [d_1,d_2] | P(n); n=b\\ (W)} 1.")]]

#text("The weights ")#mi("{a_{d_1} a_{d_2}}")#text(" are only non-vanishing when ")#mi("{d_1,d_2 \\leq R}")#text(". From the Chinese remainder theorem we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: [d_1,d_2] | P(n); n=b\\ (W)} 1 = \\frac{x}{W} \\Delta([d_1,d_2]) + O( [d_1,d_2] \\Delta([d_1,d_2]) ).")]]

#text("The contribution of the error term is")

#align(center)[#tao-fit-display[#tao-math("\\ll \\sum_{d_1,d_2 \\in {\\mathcal S}_I: d_1,d_2 \\leq R} \\left|a_{d_1}\\right| \\left|a_{d_2}\\right| k_0^{\\Omega([d_1,d_2])}", block: true)]]

#text("which we can upper bound by")

#align(center)[#tao-fit-display[#mitex("\\ll (\\sum_{d \\in {\\mathcal S}_I: d \\leq R} |a_d| k_0^{\\Omega(d)})^2.")]]

#text("Using ")#link(<tao-56de49fda9f32f60654b>)[#text("(11)")]#text(" and Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" we have the crude upper bound ")#metadata(none) <tao-7e9e5ac30f2216fd0fd6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|a_d\\right| \\ll \\frac{1}{\\Phi(d) \\Delta(d)} (\\frac{\\phi(W)}{W} \\log R)^{k_0}", block: true)]]

#text("and hence by another application of Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" the previous expression may be upper bounded by ")#mi("{O( (W/\\phi(W))^{O(1)} R^2 \\log^{O(1)} R )}")#text(", which is negligible by choice of ")#mi("{R}")#text(". So we reduce to showing that ")#metadata(none) <tao-788eb2efc52660fe4147>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\Delta([d_1,d_2]) \\leq (\\alpha+o(1)) (\\frac{\\phi(W)}{W} \\log R)^{k_0}.")]]

#text("To proceed further we follow Selberg and observe the decomposition ")#metadata(none) <tao-7f23cf2a7e4f1b47d6b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\Delta([d_1,d_2]) = \\sum_{d_0|d_1,d_2} \\Phi(d_0) \\Delta(d_1) \\Delta(d_2)")]]

#text("for ")#mi("{d_1,d_2 \\in {\\mathcal S}_I}")#text(", which can be easily verified by working locally (when ")#mi("{d_1,d_2 \\in \\{1,p\\}}")#text(" for some prime ")#mi("{p \\in I}")#text(") and then using multiplicativity. Using this identity we can diagonalise the left-hand side of ")#link(<tao-788eb2efc52660fe4147>)[#text("(18)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\Phi(d_0) (\\sum_{d \\in {\\mathcal S}_I: d_0|d} \\mu(d) a_d \\Delta(d))^2.")]]

#text("Now we use the form ")#link(<tao-56de49fda9f32f60654b>)[#text("(11)")]#text(" of ")#mi("{a_d}")#text(", which has been optimised specifically for ease of computing this expression. We can expand ")#mi("{\\sum_{d \\in {\\mathcal S}_I: d_0|d} \\mu(d) a_d \\Delta(d)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d_0|d} \\frac{\\mu(d)}{\\Phi(d)} \\sum_{q \\in {\\mathcal S}_I: (q,d) = 1} \\frac{1}{\\Phi(q)} f^{\\prime}( \\frac{\\log dq}{\\log R});")]]

#text("writing ")#mi("{d = d_0 d_1}")#text(" and ")#mi("{m = d_1 q}")#text(", we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mu(d_0)}{\\Phi(d_0)} \\sum_{m \\in {\\mathcal S}_I: (m,d_0)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\Phi(m)} \\sum_{d_1 | m} \\mu(d_1)")]]

#text("which by Möbius inversion simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mu(d_0)}{\\Phi(d_0)} f^{\\prime}( \\frac{\\log d_0}{\\log R} ).")]]

#text("The left-hand side of ")#link(<tao-788eb2efc52660fe4147>)[#text("(18)")]#text(" has now simplified to")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{1}{\\Phi(d_0)} f^{\\prime}( \\frac{\\log d_0}{\\log R} )^2.")]]

#text("By Lemma ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" and ")#link(<tao-f81ab872625c131d92e7>)[#text("(15)")]#text(" we obtain ")#link(<tao-788eb2efc52660fe4147>)[#text("(18)")]#text(" and hence ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(" as required.")

#text("Now we turn to the more difficult lower bound ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(" for a fixed ")#mi("{h_i \\in {\\mathcal H}}")#text(" (again we will be able to get an asymptotic here rather than just a lower bound). The left-hand side expands as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\sum_{x \\leq n \\leq 2x: [d_1,d_2] | P(n); n = b\\ (W)} \\theta(n+h_i).")]]

#text("Again, ")#mi("{d_1,d_2}")#text(" may be restricted to at most ")#mi("{R}")#text(", so that ")#mi("{[d_1,d_2]}")#text(" is at most ")#mi("{R^2 = x^{1/2+2\\varpi}}")#text(". As before, the inner summand vanishes unless ")#mi("{n+h_i \\ ([d_1,d_2])}")#text(" lies in one of the residue classes ")#mi("{C_i([d_1,d_2])}")#text(", where")

#align(center)[#tao-fit-display[#mitex("C_i(q) := \\{ a \\in {\\bf Z}/q{\\bf Z}^\\times: P_i(a) = 0 \\}")]]

#text("and ")#mi("{P_i}")#text(" is the modified polynomial")

#align(center)[#tao-fit-display[#mitex("P_i(a) := \\prod_{h \\in {\\mathcal H} \\backslash \\{h_i\\}} (a+h-h_i).")]]

#text("The cardinality of ")#mi("{C_i(q)}")#text(" is ")#mi("{\\phi(q)\\Delta^*(q)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Delta^*(q) := \\prod_{p|q} \\frac{k_0-1}{p-1} = \\frac{(k_0-1)^{\\Omega(q)}}{\\phi(q)}.")]]

#text("We can thus estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: [d_1,d_2] | P(n); n = b\\ (W)} \\Lambda(n+h) = \\frac{1}{\\phi(W)} x \\Delta^*([d_1,d_2]) + O( E^*([d_1,d_2]) )")]]

#text("where the error term ")#mi("{E^*(q)}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("E^*(q) = \\sum_{a \\in C_i(q)} | \\sum_{x \\leq n \\leq 2x: n=b\\ (W); n = a\\ (q)} \\theta(n) - \\frac{x}{\\phi(Wq)}|.")]]

#text("By a modification of the proof of Proposition ")#link(<tao-3e66ba098b3789d68366>)[#text("5")]#text(" we see that the hypothesis ")#mi("{EH[\\theta+\\epsilon]}")#text(" implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\leq R^2} h(q) E^*(q) \\ll x \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(" and any multiplicative function ")#mi("{h}")#text(" of a fixed dimension ")#mi("{k}")#text(". Using the bound ")#link(<tao-7e9e5ac30f2216fd0fd6>)[#text("(17)")]#text(" we can then conclude that the contribution of the error term ")#mi("{E^*([d_1,d_2])}")#text(" to ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(" is negligible. So ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(" becomes ")#metadata(none) <tao-26826f908b6d45902ae7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\Delta^*([d_1,d_2])")]]

#align(center)[#tao-fit-display[#mitex("\\geq (\\beta-o(1)) (\\frac{\\phi(W)}{W}\\log R)^{k_0+1}.")]]

#text("Analogously to ")#link(<tao-7f23cf2a7e4f1b47d6b7>)[#text("(19)")]#text(" we have the decomposition ")#metadata(none) <tao-00c33679defef8af576e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\Delta^*([d_1,d_2]) = \\sum_{d_0|d_1,d_2} \\Phi^*(d_0) \\Delta^*(d_1) \\Delta^*(d_2)")]]

#text("for ")#mi("{d_1,d_2 \\in {\\mathcal S}_I}")#text(", where ")#mi("{\\Phi^*}")#text(" is the function")

#align(center)[#tao-fit-display[#mitex("\\Phi^*(d) := \\prod_{p|d} \\frac{p-k_0}{k_0-1}.")]]

#text("We can thus diagonalise the left-hand side of ")#link(<tao-26826f908b6d45902ae7>)[#text("(20)")]#text(" similarly to before as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\Phi^*(d_0) (\\sum_{d \\in S_I: d_0|d} \\mu(d) a_d \\Delta^*(d))^2.")]]

#text("We can expand ")#mi("{\\sum_{d \\in {\\mathcal S}_I: d_0|d} \\mu(d) a_d \\Delta^*(d)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d_0|d} \\frac{\\mu(d)}{\\Phi(d)} \\frac{\\Delta^*(d)}{\\Delta(d)} \\sum_{q \\in {\\mathcal S}_I: (q,d) = 1} \\frac{1}{\\Phi(q)} f^{\\prime}( \\frac{\\log dq}{\\log R});")]]

#text("writing ")#mi("{d = d_0 d_1}")#text(" and ")#mi("{m = d_1 q}")#text(" and noting that ")#mi("{\\frac{\\Delta^*(d)}{\\Delta(d)} = (1-\\frac{1}{k_0})^{\\Omega(d)}}")#text(", we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mu(d_0)}{\\Phi(d_0)} \\frac{\\Delta^*(d_0)}{\\Delta(d_0)} \\sum_{m \\in {\\mathcal S}_I: (m,d_0)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\Phi(m)} \\sum_{d_1 | m} \\mu(d_1) \\frac{\\Delta^*(d_1)}{\\Delta(d_1)}.")]]

#text("Observe that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\Phi(m)} \\sum_{d_1|m} \\mu(d_1) \\frac{\\Delta^*(d_1)}{\\Delta(d_1)} = \\frac{1}{\\phi(m)}")]]

#text("so we can simplify the left-hand side of ")#link(<tao-26826f908b6d45902ae7>)[#text("(20)")]#text(" as ")#metadata(none) <tao-b9b75a0312eb1298e5c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{h(d_0)}{d_0} (\\sum_{m \\in {\\mathcal S}_I: (m,d_0)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)} )^2")]]

#text("where ")#mi("{h}")#text(" is the ")#mi("{k_0-1}")#text("-dimensional multiplicative function")

#tao-aligned(keep: true)[


#tao-math("h(d)  & := d \\frac{\\Phi^*(d)}{\\Phi(d)^2} (\\frac{\\Delta^*(d)}{\\Delta(d)})^2", block: true)



#tao-math(" & = \\prod_{p|d} (k_0-1) \\frac{(p-1)^2}{p(p-k_0)}.", block: true)
]

#text("To control this sum, let us first pretend that the ")#mi("{(m,d_0)=1}")#text(" constraint was not present, thus suppose we had to estimate ")#metadata(none) <tao-100e8472c6bfa325aca8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{h(d_0)}{d_0} (\\sum_{m \\in {\\mathcal S}_I} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)} )^2.")]]

#text("By Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(", the inner sum ")#mi("{\\sum_{m \\in {\\mathcal S}_I} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)}}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("= (\\frac{\\phi(W)}{W} \\log R) (\\int_0^\\infty f^{\\prime}(t + \\frac{\\log d_0}{\\log R})\\ dt + o(1))")]]

#text("which by the fundamental theorem of calculus simplifies to")

#align(center)[#tao-fit-display[#mitex("= - (\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log d_0}{\\log R})+ o(1)).")]]

#text("We remark that the error term ")#mi("{o(1)}")#text(" here is uniform in ")#mi("{d_0}")#text(", because the translates ")#mi("{f^{\\prime}(\\cdot + \\frac{\\log d_0}{\\log R})}")#text(" are equicontinuous and thus uniformly Riemann integrable. We conclude that ")#link(<tao-100e8472c6bfa325aca8>)[#text("(23)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0 \\in {\\mathcal S}_I} \\frac{h(d_0)}{d_0} (f(\\frac{\\log d_0}{\\log R})^2+ o(1))")]]

#text("where the error term ")#mi("{o(1)}")#text(" is again uniform in ")#mi("{d_0}")#text(". By Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" and ")#link(<tao-f096890dbb1b514cf178>)[#text("(16)")]#text(", this expression is equal to ")#metadata(none) <tao-0ae467cc10e077a17e83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("(\\beta-o(1)) (\\frac{\\phi(W)}{W} \\log R)^{k_0+1}")]]

#text("as required.")

#text("Now we reinstate the condition ")#mi("{(m,d_0)=1}")#text(", which turns out to be negligible thanks to the ")#mi("{W}")#text("-trick. More precisely, we may use Möbius inversion to write ")#metadata(none) <tao-60ba1dd5d232b0213d4e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{m \\in {\\mathcal S}_{(w,+\\infty)}: (m,d_0)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)}")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{k | d_0} \\frac{\\mu(k)}{\\phi(k)} \\sum_{m \\in {\\mathcal S}_{(w,+\\infty)}: (m,k)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 k m}{\\log R})}{\\phi(m)}.")]]

#text("By the preceding discussion, the ")#mi("{k=1}")#text(" term of this sum is")

#align(center)[#tao-fit-display[#mitex("- (\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log k}{\\log R}) + o(1))")]]

#text("Now we consider the ")#mi("{k \\neq 1}")#text(" terms, which are error terms. We may bound the total contribution of these terms in magnitude by")

#align(center)[#tao-fit-display[#tao-math("O( \\sum_{k|d_0: k \\neq 1} \\frac{1}{\\phi(k)} \\left|\\sum_{m \\in {\\mathcal S}_{(w,+\\infty)}} \\frac{f^{\\prime}(\\frac{\\log d_0 k m}{\\log R})}{\\phi(m)}\\right| ).", block: true)]]

#text("Arguing as before we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\mathcal S}_{(w,+\\infty)}} \\frac{f^{\\prime}(\\frac{\\log d_0 k m}{\\log R})}{\\phi(m)} = O( \\frac{\\phi(W)}{W} \\log R )")]]

#text("and so the expression ")#link(<tao-60ba1dd5d232b0213d4e>)[#text("(25)")]#text(" becomes")

#align(center)[#tao-fit-display[#mitex("-(\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log d_0}{\\log R}) + O( \\frac{d_0}{\\phi(d_0)}-1 ) + o(1) )")]]

#text("where the implied constant in the ")#mi("{O()}")#text(" notation can depend on ")#mi("{f}")#text(". The square of this expression is then")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^2 (f(\\frac{\\log d_0}{\\log R})^2 + O( (\\frac{d_0}{\\phi(d_0)}-1)^2 ) + O( \\frac{d_0}{\\phi(d_0)}-1 ) + o(1) ).")]]

#text("The left-hand side of ")#link(<tao-26826f908b6d45902ae7>)[#text("(20)")]#text(" is now expressed as the sum of the main term")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0 \\in {\\mathcal S}_I} \\frac{h(d_0)}{d_0} f(\\frac{\\log d_0}{\\log R})^2")]]

#text("and the error terms")

#align(center)[#tao-fit-display[#mitex("O( (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0 \\in {\\mathcal S}_I: d_0 \\leq R} \\frac{h(d_0)}{d_0} (\\frac{d_0}{\\phi(d_0)}-1)^j )")]]

#text("for ")#mi("{j=1,2}")#text(" and")

#align(center)[#tao-fit-display[#mitex("o( (\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0 \\in {\\mathcal S}_I: d_0 \\leq R} \\frac{h(d_0)}{d_0} ).")]]

#text("The main term has already been estimated as ")#link(<tao-0ae467cc10e077a17e83>)[#text("(24)")]#text(". From Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal S}_I: d_0 \\leq R} \\frac{h(d_0)}{d_0} (\\frac{d_0}{\\phi(d_0)})^j = (\\frac{\\phi(W)}{W} \\log R)^{k_0-1} \\int_0^1 \\frac{x^{k_0-2}}{(k_0-2)!}+o(1)")]]

#text("for ")#mi("{j=0,1,2}")#text(", and so all of the error terms end up being ")#mi("{o( (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} )}")#text(", and ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(" follows. This concludes the proof of Theorem ")#link(<tao-8d02dd559534832e1f68>)[#text("3")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Applying truncation — ")]]

#text("Now we experiment with truncating the above argument to ")#mi("{I = (w,x^\\delta)}")#text(" to obtain results of the shape of Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("6")]#text(". Unfortunately thus far the results do not give very good explicit dependencies of ")#mi("{k_0}")#text(" on ")#mi("{\\varpi,\\delta}")#text(", but this may perhaps improve with further effort.")

#text("Assume ")#mi("{MPZ[\\varpi,\\delta]}")#text(" holds for some ")#mi("{0 < \\varpi < 1/4}")#text(" and some ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(". Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a smooth function that is supported on ")#mi("{[-1,1]}")#text(", let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple for some fixed ")#mi("{k_0 \\geq 2}")#text(", let ")#mi("{b\\ (W)}")#text(" be such that ")#mi("{b+h}")#text(" is coprime to ")#mi("{W}")#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(", and let ")#mi("{\\nu}")#text(" be the elementary Selberg sieve with weights ")#link(<tao-56de49fda9f32f60654b>)[#text("(11)")]#text(" associated to the function ")#mi("{f}")#text(", the sieve level ")#mi("{R := x^{1/4 + \\varpi}}")#text(" and the truncated interval ")#mi("{I := (w,x^\\delta)}")#text(". As before, we set")

#align(center)[#tao-fit-display[#mitex("A := (\\frac{\\phi(W)}{W} \\log R)^{k_0}")]]

#text("and seek the best values for ")#mi("{\\alpha,\\beta}")#text(" for which we can establish the upper bound ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(" and the lower bound ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(". Arguing as in the previous section (using ")#link(<tao-63718a50ee57d3201e7d>)[#text("(13)")]#text(" to control error terms) we can reduce ")#link(<tao-e8bc163c82eee1873328>)[#text("(6)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{1}{\\Phi(d_0)} f^{\\prime}( \\frac{\\log d_0}{\\log R} )^2 \\leq (\\alpha+o(1)) (\\frac{\\phi(W)}{W} \\log R)^{k_0}.")]]

#text("If we crudely replace the truncated interval ")#mi("{(w,x^\\delta)}")#text(" by the untruncated interval ")#mi("{(w,\\infty)}")#text(" and apply Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" (or ")#link(<tao-63718a50ee57d3201e7d>)[#text("(13)")]#text(") we may reuse the previous value")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\int_0^1 f^{\\prime}(t)^2 \\frac{t^{k_0-1}}{(k_0-1)!}\\ dx")]]

#text("for ")#mi("{\\alpha}")#text(" here, but it is possible that we could do better than this.")

#text("Now we turn to ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(". Arguing as in the previous section, we reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{h(d_0)}{d_0} (\\sum_{m \\in {\\mathcal S}_I: (m,d_0)=1} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)} )^2")]]

#align(center)[#tao-fit-display[#mitex("\\geq (\\beta-o(1)) (\\frac{\\phi(W)}{W} \\log R)^{k_0+1}.")]]

#text("We can, if desired, discard the ")#mi("{(m,d_0)=1}")#text(" constraint here by arguing as in the previous section, leaving us with ")#metadata(none) <tao-ee48ee67db5d730efb11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{d_0 \\in {\\mathcal S}_I} \\frac{h(d_0)}{d_0} (\\sum_{m \\in {\\mathcal S}_I} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)} )^2")]]

#align(center)[#tao-fit-display[#mitex("\\geq (\\beta-o(1)) (\\frac{\\phi(W)}{W} \\log R)^{k_0+1}.")]]

#text("Because we now seek a ")#emph[#text("lower")]#text(" bound, we cannot simply pass to the untruncated interval ")#mi("{(w,\\infty)}")#text(" (e.g. using ")#link(<tao-63718a50ee57d3201e7d>)[#text("(13)")]#text("), and must proceed more carefully. A simple way to proceed (as was done ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("by Motohashi and Pintz")]#text(") is to just discard all ")#mi("{d_0}")#text(" less than ")#mi("{x^{-\\delta} R}")#text(", only retaining those ")#mi("{d_0}")#text(" in the region between ")#mi("{x^{-\\delta} R}")#text(" and ")#mi("{R}")#text(". The reason for doing this is that the ")#mi("{m}")#text(" parameter is then forced to be at most ")#mi("{x^\\delta}")#text(" if one wants the summand to be non-zero, and so for the ")#mi("{m}")#text(" summation at least one can replace ")#mi("{I}")#text(" by ")#mi("{(w,+\\infty)}")#text(" without incurring any error. As in the previous section we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\mathcal S}_I} \\frac{f^{\\prime}(\\frac{\\log d_0 m}{\\log R})}{\\phi(m)} = - (\\frac{\\phi(W)}{W} \\log R) (f(\\frac{\\log d_0}{\\log R})+ o(1))")]]

#text("and so one can ")#emph[#text("lower bound")]#text(" ")#link(<tao-ee48ee67db5d730efb11>)[#text("(26)")]#text(", up to negligible errors, by")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^2 \\sum_{d_0 \\in {\\mathcal S}_I: x^{-\\delta} R \\leq d_0 \\leq R} \\frac{h(d_0)}{d_0} f(\\frac{\\log d_0}{\\log R})^2.")]]

#text("If the truncated interval ")#mi("{I}")#text(" were replaced by the untruncated interval ")#mi("{(w,\\infty)}")#text(", then Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(" would estimate this expression as")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^{k+1} \\int_{1-\\frac{\\delta}{1/4+\\varpi}}^1 f(t)^2 \\frac{t^{k-2}}{(k-2)!}\\ dt.")]]

#text("To deal with the truncated interval ")#mi("{I}")#text(", we use a variant of the Buchstab identity, namely the easy inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d \\leq R} F(d) \\geq \\sum_{d \\in {\\mathcal S}_{(w,+\\infty)}: d \\leq R} F(d) - \\sum_{x^\\delta \\leq p \\leq R} \\sum_{d \\in {\\mathcal S}_{(w,+\\infty)}: d \\leq R/p} F(pd)")]]

#text("for any non-negative function ")#mi("{F}")#text(". Using this identity and Proposition ")#link(<tao-30b84cf23324188a95ee>)[#text("8")]#text(", we find that we may lower bound ")#link(<tao-ee48ee67db5d730efb11>)[#text("(26)")]#text(", up to negligible errors, by")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^{k+1} \\int_{1-\\frac{\\delta}{1/4+\\varpi}}^1 f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt")]]

#text("minus the sum")

#align(center)[#tao-fit-display[#mitex("(k_0-1) (\\frac{\\phi(W)}{W} \\log R)^{k_0+1} \\sum_{x^\\delta \\leq p \\leq R} \\int_0^{1-\\log p/\\log R} f(t+\\frac{\\log p}{\\log R})^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt.")]]

#text("(The ")#mi("{(k_0-1)}")#text(" term comes from ")#mi("{h(p)}")#text(".)If ")#mi("{f}")#text(" is non-negative and non-increasing on ")#mi("{[0,1]}")#text(", then we can upper bound")

#align(center)[#tao-fit-display[#mitex("f(t+\\frac{\\log p}{\\log R}) \\leq f( t / (1 - \\frac{\\log p}{\\log R}) )")]]

#text("for ")#mi("{0 \\leq t \\leq 1-\\log p/\\log R}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\int_0^{1-\\log p/\\log R} f(t+\\frac{\\log p}{\\log R})^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt")]]

#align(center)[#tao-fit-display[#mitex("\\leq (1-\\frac{\\log p}{\\log R})^{k_0-1} \\int_0^1 f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt.")]]

#text("On the other hand, from the prime number theorem we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^\\delta \\leq p \\leq R} (1-\\frac{\\log p}{\\log R})^{k_0-1} = \\int_{\\delta/(1/4+\\varpi)}^1 (1-t)^{k_0-1}\\ \\frac{dt}{t} + o(1).")]]

#text("Putting all this together, we can thus obtain ")#link(<tao-ad328846aa18b32a3358>)[#text("(7)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("\\beta := (1-\\kappa) \\int_0^1 f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt")]]

#text("where ")#metadata(none) <tao-22cd1a24fccc7de045d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\kappa := \\frac{\\int_0^{1-\\frac{\\delta}{1/4+\\varpi}} f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt}{\\int_0^{1} f(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt} + \\kappa^{\\prime}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} := (k_0-1) \\int_{\\delta/(1/4+\\varpi)}^1 (1-t)^{k_0-1}\\ \\frac{dt}{t}.")]]

#link("http://arxiv.org/abs/1306.1497")[#text("Following Pintz")]#text(", we may upper bound ")#mi("{(1-t)^{k_0-1}}")#text(" by ")#mi("{\\exp(-(k_0-1) t)}")#text(" and rescale to obtain")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} \\leq \\int_{(k_0-1)\\delta/(1/4+\\varpi)} \\exp(-t) \\frac{dt}{t}")]]

#text("which we can crudely bound by")

#align(center)[#tao-fit-display[#mitex("\\kappa^{\\prime} \\leq \\exp( - (k_0-1)\\delta/(1/4+\\varpi)).")]]

#text("But of course we can also calculate ")#mi("{\\kappa}")#text(" and ")#mi("{\\kappa^{\\prime}}")#text(" explicitly for any fixed choice of ")#mi("{\\delta,\\varpi,k_0}")#text(". We conclude the following variant of Theorem ")#link(<tao-ced2128f3bc92a5720f7>)[#text("6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (MPZ implies DHL)")]#text(" ")#metadata(none) <tao-93884523f4936915f788>#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", and let ")#mi("{k_0 \\geq 2}")#text(" be an integer obeying the constraint")

#align(center)[#tao-fit-display[#mitex("(1+4\\varpi)(1-\\kappa) > \\frac{4}{k_0(k_0-1)} \\frac{\\int_0^1 f^{\\prime}(t)^2 t^{k_0-1}\\ dt}{\\int_{1-\\frac{\\delta}{1/4+\\varpi}}^1 f(t)^2 t^{k_0-2}\\ dt},")]]

#text("with ")#mi("{\\kappa}")#text(" given by ")#link(<tao-22cd1a24fccc7de045d3>)[#text("(27)")]#text(", and some smooth ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" supported on ")#mi("{[-1,1]}")#text(" which is non-negative and non-increasing on ")#mi("{[0,1]}")#text(". Then ")#mi("{MPZ[\\varpi,\\delta]}")#text(" implies ")#mi("{DHL[k_0]}")#text(".")
]

#text("For ")#mi("{k_0}")#text(" large enough depending on ")#mi("{\\varpi,\\delta}")#text(" the hypotheses in Theorem ")#link(<tao-93884523f4936915f788>)[#text("10")]#text(" can be verified (e.g. by setting ")#mi("{f(t) = (1-t)^l}")#text(" for a reasonably large ")#mi("{l}")#text(") but the dependence is poor due to the localisation of the integral in the denominator to the narrow interval ")#mi("{[1-\\delta/(1/4+\\varpi),1]}")#text(". But perhaps there is a way to not have such a strict localisation in these arguments.")

#heading(level: 1)[#text("Comments (98)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233463")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Incidentally, I heard back from Pintz, who has confirmed the")#linebreak()#text(" issues raised about his most recent preprint on bounded gaps between primes, but believes that one can salvage the estimates with somewhat worse explicit numerical constants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff39422bba87564dc362dba86346d189c9f13ca60591c0da8772f2d6a73db39-476ea7aed1980e9919a56099f0ba871fd83e9da2e7284c64684097196a1c55a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omar aboura")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233466")[#strong[#text("omar aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("In “Using the bound (17) we can then conclude that the conribution…” conribution should be contribution.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233468")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("The link in “and also independently in the theorem” does not work. Also, is it not slightly misleading to say that that the current record is ")#mi("k_0 = 10,719")#text("?")

#emph[#text("[Corrected, thanks. The post was written over a period of a few days and I forgot to update some of the material at the beginning of it. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d37a90e0a87f142de7cd0562fdf8c017d926c0f959ed87bc6e8bea45769fc2-ac07214c1e07b43680453f38c92b37224b98e315473b3a4ed6c01810549e2274.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elliott")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233479")[#strong[#text("elliott")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("elliott ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233505")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("There is no need to invoke the Brun-Titchmarsh inequality as the trivial bound ")#mi("E(q)\\ll\\frac{x}{\\varphi(q)}\\log x")#text(" suffices.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233506")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Instead of “The conjecture ")#mi("MPZ[\\varpi,\\delta]")#text(" is easier to prove than etc.” you probably wanted to say “The conjecture ")#mi("MPZ[\\varpi,\\delta]")#text(" is weaker than etc.”, because the sentence continues by “but is easier to prove”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233508")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("In Lemma 7, “be a congruence class” should be deleted. BTW feel free to delete such minor comments of mine, I just try to be helpful.")

#emph[#text("[Corrected, thanks – and the comments are appreciated! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233509")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("In (7), the inequality should be reversed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27781d5f9f1cf309d2c329dbf6557cd2df23148c92092930998ea479fa2916d7-cac8d40de9451c0568a412d2bbe715c9180e9857e2bedf8ffaea49ab3538a06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO TRIVIÑO N")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233514")[#strong[#text("HUMBERTO TRIVIÑO N")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("INTERESANTE SU EXPOSICIÓN E IGUALMENTE PREDOMINA UN MARCADO INTERÉS POR ENCONTRAR NUEVAS RELACIONES ENTRE LOS TEOREMAS")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27781d5f9f1cf309d2c329dbf6557cd2df23148c92092930998ea479fa2916d7-cac8d40de9451c0568a412d2bbe715c9180e9857e2bedf8ffaea49ab3538a06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO TRIVIÑO N")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233515")[#strong[#text("HUMBERTO TRIVIÑO N")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("REVIZAR 15 Y 16 DEL LEMA 10")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233518")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("1. In the fourth display below Lemma 9, ")#mi("d")#text(" should be coprime with ")#mi("a")#text(", otherwise ")#mi("ad\\not\\in\\mathcal{S}_I")#text(". This leads to some complications, namely a slight tweaking of ")#mi("h(a)")#text(" seems necessary.")

#text("2. For the approximation argument in the proof of Lemma 8, don’t we need that ")#mi("f")#text(" is real-valued, i.e. that ")#mi("f(d)>0")#text(" in the sum?")#linebreak()#text(" Actually, this condition is implicit in (13).")

#text("3. ")#mi("R := x^{1/2+\\varpi}")#text(" should be ")#mi("R := x^{1/4+\\varpi}")#text(".")

#text("4. “dependence of ")#mi("k_0")#text(" depending on ")#mi("\\varpi,\\theta")#text("” should be “dependence of ")#mi("k_0")#text(" on ")#mi("\\varpi,\\theta")#text("“.")

#text("5. “we see that ")#mi("f")#text(" is non-negative” should be “we see that ")#mi("f")#text(" is non-zero”, because ")#mi("f")#text(" is complex-valued.")

#text("6. ")#tao-math("1+\\left|h(p)\\right|", block: false)#text(" should be ")#tao-math("1+\\frac{\\left|h(p)\\right|}{p}", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233533")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I have a rather simplistic question – Pintz in the latest preprint (even if incorrect) has ")#mi("(k+2l)")#text(" in his exponent instead of ")#mi("k")#text(", does your analysis hide this extra ")#mi("2l")#text(" somewhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233536")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I give up this extra ")#mi("2l")#text(" because I don’t assume as much on the test function ")#mi("f")#text(" – only that it is non-negative and non-increasing, which is enough to get the inequality")

#mi("\\int_0^{1-a} f(t+a)^2 t^{k_0-2}\\ dt \\leq (1-a)^{k_0-1} \\int_0^1 f(t)^2 t^{k_0-2}\\ dt")

#text("for any ")#mi("0 < a < 1")#text(". With a monomial choice for ")#mi("f")#text(" such as ")#mi("f(t) = (1-t)^{l_0}")#text(" one gets the improved bound")

#mi("\\int_0^{1-a} f(t+a)^2 t^{k_0-2}\\ dt \\leq (1-a)^{k_0+2l_0-1} \\int_0^1 f(t)^2 t^{k_0-2}\\ dt")

#text("(in fact this is an equality). But of course with the most recent sieves, ")#mi("f")#text(" is not a monomial but is instead a Bessel function. Perhaps there is still something to be squeezed out here but considering how ")#mi("l_0")#text(" is relatively small compared to ")#mi("k_0")#text(" in practice, this is unlikely to yield dramatic improvements in the final value of ")#mi("k_0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233541")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("7. Somehow the proof of (12) in the dimension zero case (")#mi("k=0")#text(") has disappeared, although it is needed later.")

#text("8. In the display below (10), ")#mi("d|n")#text(" should be ")#mi("d|P(n)")#text(". Also, I think, ")#mi("P(n)")#text(" was not defined in this post.")

#text("9. In the display below Lemma 9 (formerly Lemma 10), the factorials should be omitted. Alternately, in the next display, the denominator should be multiplied by ")#mi("k_0-1")#text(".")

#text("10. In (17) the exponent ")#mi("k_0")#text(" is missing from the end.")

#text("11. In the third display below (19), ")#mi("f")#text(" should be ")#mi("f^{\\prime}")#text(". In the next display, ")#mi("f^{\\prime}")#text(" should not be squared.")

#text("12. In the display before (20), it would be better to use a different letter for ")#mi("f(q)")#text(", as ")#mi("f")#text(" is reserved already.")

#text("13. I don’t quite see how to get (24) from (23). In the intermediate steps we are dealing with ")#mi("o(1)")#text(" terms that depend on ")#mi("d_0")#text(". So I only see (24) as a lower bound (which is sufficient), by fixing ")#mi("w")#text(" to be large and then considering a large but fixed number of ")#mi("d_0")#text("‘s. The more ")#mi("d_0")#text("‘s we consider, the closer we get to the constant ")#mi("\\beta")#text(" in (24). Here I also used positivity from (22).")

#text("14. In (25) and in the next display, ")#mi("f")#text(" should be ")#mi("f^{\\prime}")#text(" on the left hand side. More importantly, in (25), the factor ")#mi("h(km)/m")#text(" should be ")#mi("1/\\varphi(m)")#text(", and the summation should be restricted to ")#mi("m")#text(" coprime with ")#mi("k")#text(". So I think the ")#mi("k=1")#text(" term should be detached at this point, and the ")#mi("k>1")#text(" terms should be bounded from above immediately, by relaxing the coprimality condition. That is, I think, the two displays following (25) are not quite right: ")#mi("\\mu(k)")#text(" for ")#mi("k>1")#text(" should really be ")#mi("O(1)")#text(".")

#text("15. In the last display of Section 2, a ")#mi("o(1)")#text(" is missing on the right hand side.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233547")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Regarding #13: Perhaps the ")#mi("o(1)")#text(" terms can be made independent of ")#mi("d_0")#text(" by noting that replacing ")#mi("g(x)")#text(" by ")#mi("g(x+c)")#text(" for ")#mi("c>0")#text(" does not increase ")#tao-math("\\left|\\hat g(t)\\right|", block: false)#text(" from the previous post?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233555")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Thanks for the explanation regarding #13 (and the whole blog entry). Further small comments: the second display after (25) now doesn’t parse, ")#mi("\\Phi(W)")#text(" should be ")#mi("\\phi(W)")#text(" at several places, and, in Theorem 10, ")#mi("f(t)^2t^{k_0-1}")#text(" should be ")#mi("f(t)^2t^{k_0-2}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233599")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Some remarks:")

#text("1. In theorem 3, it should be “first positive zero”.")

#text("2. The statement of conjecture 4 does not include its dependence on")#linebreak()#text(" ")#mi("\\omega")#text(" and ")#mi("\\delta")#text("“.")

#text("3. In theorem 6, can one change the bounds 1/4 and 1/2 on ")#mi("\\omega")#text(" and ")#mi("\\delta")#text(" (which seems to be only convenient choices for the analysis), and in such a case does the (modified) analysis leads to a different constraint (with coefficients different than 207 and 43) on ")#mi("\\omega")#text(" and ")#mi("\\delta")#text("?")

#text("4. It seems that the above constraint (with 207 and 43) is no longer necessary in theorem 10, but in this case is it important that the integral in the denominator should be over sub-interval of [0, 1]? (in such a case, this impose a new restriction on ")#mi("\\omega")#text(" and ")#mi("\\delta")#text(").")

#emph[#text("[Corrected, thanks. As Gergely noted above, the condition ")#mi("0 < \\delta < 1/2")#text(" is a bit arbitrary but certainly far more permissive than anything one could reasonably hope for at this juncture. The condition ")#mi("0 < \\varpi < 1/4")#text(" is necessary though; the conjecture is almost certain to fail at the endpoint ")#mi("\\varpi = 1/4")#text(" (given that Elliott-Halberstam is known to fail at the corresponding endpoint ")#mi("\\theta = 1/2")#text(" – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233603")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Correction to my third remark above: $omega$ and $delta$ do appear in the statement of conjecture 4! – but without any restrictions (even positiveness), also it is not clear what is w (the endpoint of the interval I).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233615")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("In both posts, ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" are positive constants (to be optimized later), and ")#mi("w")#text(" is a function of ")#mi("x")#text(", sufficiently slowly increasing to infinity, to make all the statements valid.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233690")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("OK. but the restrictions on ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" should be EXPLICITLY stated in conjecture 4 along with the conditions that the function ")#mi("w(x)")#text(" should satisfy.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Actually, I intend Conjecture 4 to be a family of conjectures ")#mi("MPZ[\\varpi,\\delta]")#text(", one for each choice of ")#mi("\\varpi,\\delta")#text(", rather than a single conjecture, so I don’t want to quantify the ")#mi("\\varpi,\\delta")#text(" within the conjecture. As stated after Proposition 5, it is conjectured that ")#mi("MPZ[\\varpi,\\delta]")#text(" is true for all ")#mi("0 < \\varpi < 1/4")#text(" and ")#mi("0 < \\delta < 1/4+\\varpi")#text(".")

#text("The conventions on w are introduced in the second paragraph of the blog post and are assumed to be in force throughout in order not to have to state \"Assume ")#mi("w")#text(" is a sufficiently slowly growing function of ")#mi("x")#text("\" in every single assertion in the post.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233627")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("It would be contra-productive to consider ")#mi("q\\geq x")#text(" or ")#mi("d_1d_2\\geq x")#text(", hence the conditions ")#mi("\\frac{1}{2}+2\\varpi<1")#text(" and ")#mi("2\\delta<1")#text(" are natural. In fact we want to consider ")#mi("q")#text(" up to level ")#mi("1/2+2\\varpi")#text(", hence ")#mi("d")#text(" up to level ")#mi("1/4+\\varpi")#text(", with prime divisors up to level ")#mi("\\delta")#text(", hence the stronger condition ")#mi("0<\\delta\\leq\\frac{1}{4}+\\varpi<\\frac{1}{2}")#text(" is also natural to the whole setup. This gives automatically that integration in Theorem 10 is above a subinterval of ")#mi("[0,1]")#text(". At any rate, decreasing ")#mi("\\varpi,\\delta")#text(" only makes ")#mi("MPZ[\\varpi,\\delta]")#text(" easier, so if a monotonic condition (like the one you quote from the online reading seminar) is necessary for small values of ")#mi("\\varpi,\\delta")#text(", then it is also necessary for larger values of ")#mi("\\varpi,\\delta")#text(". Currently we can only hope for ")#mi("MPZ[\\varpi,\\delta]")#text(" when ")#mi("\\varpi,\\delta<\\frac{1}{40}")#text(" or so.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233629")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("In Section 3, ")#mi("R:= x^{1/2+\\varpi}")#text(" should be ")#mi("R:= x^{1/4+\\varpi}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233639")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("A few related questions (some of which have been partly raised here and there) : Is there any closed formula or at least tight approximations regarding the connection between the gap ")#mi("H(k_0)")#text(" and the parameter ")#mi("k_0")#text(", including the case of small values of ")#mi("k_0")#text(" (in the pace things are going on here, this is starting to be important!)? In this connection, can one give a rigorous explanation and good error estimates to the claimed asymptotic expression")

#mi("H\\approx c(k_0)k_0\\log(k_0)")#text(" for some ")#mi("0.5 \\leq c(k_0)\\leq 1")#text("?")

#text("The same questions for the relationship ")#mi("H=H(\\overline{\\omega},\\delta)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233652")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("To get an upper bound ")#mi("H \\leq (1+o(1)) k_0 \\log k_0")#text(", one can already use the construction of Zhang, namely take the tuple to be consecutive primes ")#mi("p_{m+1},\\ldots,\\ldots,p_{m+k_0}")#text(" where ")#mi("p_m")#text(" is the first prime larger than ")#mi("k_0")#text(", as this is automatically an admissible tuple (this is a nice exercise to check) and has diameter ")#mi("(1+o(1)) k_0 \\log k_0")#text(" from the prime number theorem. In the opposite direction, the ")#link("http://en.wikipedia.org/wiki/Brun%E2%80%93Titchmarsh_theorem")[#text("Brun-Titchmarsh inequality")]#text(" (or more precisely, the proof of this inequality) gives the lower bound ")#mi("H \\geq (1/2-o(1)) k_0 \\log k_0")#text("; in fact we have the more precise inequality")

#mi("k_0 \\leq (\\sum_{q \\leq z} (H+1+cqz)^{-1} \\mu(q)^2 \\prod_{p|q} \\frac{1}{p-1})^{-1}")

#text("for any ")#mi("z")#text(", where the constant c can be taken as small as ")#mi("3.2/\\pi")#text(", thanks to the work of Montgomery-Vaughan (actually they get the slightly larger value of ")#mi("c=3/2")#text(", the ")#mi("3.2/\\pi")#text(" value is an unpublished work of Selberg).")

#text("UPDATE: I created a wiki page at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_narrow_admissible_tuples")[#text("http://michaelnielsen.org/polymath1/index.php?title=Finding_narrow_admissible_tuples")]#text(" to give more details on these topics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233671")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("I added new benchmark data at ")#link("http://sbseminar.wordpress.com/2013/06/05/more-narrow-admissible-sets/#comment-23774")[#text("http://sbseminar.wordpress.com/2013/06/05/more-narrow-admissible-sets/#comment-23774")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233672")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Corrected new benchmark data at ")#link("http://sbseminar.wordpress.com/2013/06/05/more-narrow-admissible-sets/#comment-23777")[#text("http://sbseminar.wordpress.com/2013/06/05/more-narrow-admissible-sets/#comment-23777")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233800")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Thanks for the answer and for creating the Wiki page. The information in that page is indeed useful. Two minor remarks on this page: First, it seems that the upper bound ")#mi("(1+o(1))k_0\\log k_0")#text(" on ")#mi("H")#text(" is somewhat missing from the “Upper bounds” section. Second, there are very minor typos [ two cases of missing “)” ] in the introduction.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233640")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Another question, perhaps somewhat innocent: Is there any proof that for each natural number $k$ there exists a ")#mi("k")#text("– admissible set? For the bounded gap project it is of course not needed to look at too large numbers (less than 40000 now), but still, the question is theoretical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233658")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Yes, simply take any $k$ primes beyond $k$. This is the construction used by Zhang.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233642")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Yet another question, now regarding the parameter ")#mi("\\delta")#text(": perhaps it will be useful for the sake of optimization (or other purposes) to introduce")#linebreak()#text(" additional parameters?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233660")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Additional parameters shall come from a new or modified argument. Such arguments are welcome, this is one of the purposes of this blog (aka polymath8 project). On the other hand, the pair ")#mi("(\\varpi,\\delta)")#text(" is far from optimized yet, and it also unclear how small ")#mi("k_0")#text(" we can deduce from a given pair ")#mi("(\\varpi,\\delta)")#text(". Finally, for a given ")#mi("k_0")#text(" it is not clear how to find an admissible set of smallest diameter. In short, there are already a handful of arguments and algorithms to be optimized (and optimization is already underway!), which is the principal goal of the polymath8 project (in my opinion).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233804")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Thanks for both answers. It seems from the discussion below that some ideas have already been suggested. At least some of them may indeed help in one way or another in the optimization. However, let me add regarding these suggestions that my intuition is that more fundamental parameters (or functions) can be introduced, beyond some somewhat arbitrary constants which implicit or explicit in certain expressions. They may also help in the theoretical analysis (not just for optimization). But first a more concrete example should be suggested, and I will try to find such a one.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Is this the right place to post dumb questions about the polymath project? If yes, I’m wondering why everyone is hunting for the smallest possible tuples. Could it be that there are some larger tuples than the smallest ones found so far, but which have smaller diameters? Maybe there are systematic ways to look for them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("This is a reasonably appropriate place for these sorts of “dumb” questions (one can also use the general discussion thread at ")#link("http://polymathprojects.org/2013/06/04/polymath-proposal-bounded-gaps-between-primes/")[#text("http://polymathprojects.org/2013/06/04/polymath-proposal-bounded-gaps-between-primes/")]#text(" , but your question is more or less on topic for this post).")

#text("If one removes one or more elements from an admissible tuple, then one still gets an admissible tuple. So if one finds a large tuple with small diameter, then by removing elements one can get a smaller tuple with smaller diameter. So one may as well work with the smallest size ")#mi("k_0")#text(" of tuple that one can get away with (right now we know that ")#mi("k_0 = 26,024")#text(" is a safe choice to use, but I expect this number to decrease in the next week or so as our understanding of various aspects of Zhang’s argument improve).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233675")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("The two frontiers of optimizing Zhang (a la Pintz/Green) for parameters ")#mi("(\\omega,\\delta)")#text(" are: the diagonal contribution from Weyl shifting in S13&14, and the non”singular” ")#mi("hq^{\\prime}\\neq qh^{\\prime}")#text(" contribution in Section 11. For the former, as suggested by FI in their paper (see remarks to Theorem 4), an improvement perhaps could come along the lines of using Holder rather than Cauchy. What I think they mean is: from our argument you won’t beat the main ")#mi("d^{3/2}")#text(" from Deligne, but the secondary terms (involving interval lengths moreso than the modulus) might be improved. This is Ok for us, as Zhang saves his ")#mi("\\sqrt {r}")#text(" in the main term, and so we mainly need concern about the secondary.")

#text("The latter frontier in S11, directly applies Lemma 11 and the main ")#mi("\\sqrt{d_1d_2}")#text(" of Deligne would again be difficult to beat. I don’t prognosticate so much movement there.")

#text("If nothing else, the value of ")#mi("\\kappa")#text(" should decrease somewhat via finer sieve analysis, which permits a slight ")#mi("k_0")#text(" decrement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233680")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("I suppose we should check there is no way of excluding the contribution from those ")#mi("d")#text(" which factor as ")#mi("p_1 \\dots p_k")#text(" with ")#mi("p_i")#text(" almost exactly ")#mi("X^{\\delta}")#text(" for all ")#mi("i")#text(" by some other means. I don’t see why one would expect there to be. But if we’re not in this case we should get a small gain (you should be able to arrange the factorisation ")#mi("d = qr")#text(" more critically).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233681")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("More remarks:")

#text("5. Since the integral defining $\\kappa$ in (27) should be over a sub-interval of (0, 1], we need to impose the (additional) appropriate restriction:")

#mi("\\delta \\le \\frac{1}{4} + \\varpi")

#text("(note that this restriction does NOT follows from the other restrictions in theorem 10!)")

#emph[#text("[Corrected, thanks -T.]")]

#text("6. Concerning the exact computation of $\\kappa$ by (27), it seems that the simplest method to compute the integral in (27) is to use the binomial formula to expand the denominator of the integrand into powers of t, from which the indefinite integral is obvious, but this method is very ill conditioned numerically (if the lower limit of the integral is very close to 1) because of sign alternations by expanding (1-t) to a high power – resulting by numerical near cancellation of several (relatively) large consecutive terms.")

#text("Fortunately, there is a similar method which is much more numerically stable: the idea is to change the integration variable into ")#mi("u = 1-t")#text(" and the resulting integrand ")#mi("u^{k_0 -1}/1-u")#text(" gives the simpler (and numerically stable) result")

#mi("\\kappa=(k_0 -1)[\\log \\frac{\\frac{1}{4}+\\varpi}{\\delta} - \\sum_{k=1}^{k_0 -1}\\frac{1}{k}(1-\\frac{\\delta}{\\frac{1}{4} +\\varpi})^k]")

#text("Note that all the terms in the sum are positive with simple coefficients (instead of the binomial coefficients with alternating signs in the numerically unstable method).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233682")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("The expression for ")#mi("\\kappa")#text(" above is")#linebreak()#text(" ")#mi("\\kappa=(k_0 -1)[\\log \\frac{\\frac{1}{4}+\\varpi}{\\delta} - \\sum_{k=1}^{k_0 -1}\\frac{1}{k}(1-\\frac{\\delta}{\\frac{1}{4} +\\varpi})^k]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233684")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("To elaborate my previous comment, maybe there is an incredibly tedious way to make tiny gains, as follows.")

#text("If not all the prime factors of ")#mi("d")#text(" are pretty much exactly ")#mi("X^{\\delta}")#text(", then we can hopefully make gains by arranging factorisations suitably (I haven’t checked this carefully).")

#text("Suppose then that all the prime factors of ")#mi("d")#text(" are almost exactly ")#mi("X^{\\delta}")#text(".")

#text("If I calculated correctly, in the extremal case at the Type I/III boundary, we have two splittings ")#mi("d = qr")#text(", one in the Type I case and one in the Type III. In the Type I case the critical value of ")#mi("q")#text(" (so I calculate) is ")#mi("X^{\\phi_*}")#text(" with ")#mi("\\phi_* = \\frac{1}{8} - \\frac{7}{2}\\omega - \\frac{3}{2}\\delta")#text(". With our factorisation of ")#mi("d")#text(" into ")#mi("X^{\\delta}")#text(" smooths, we were only able to guarantee ")#mi("q \\sim X^{\\phi}")#text(" with ")#mi("\\phi_* \\leq \\phi \\leq \\phi_* + \\delta")#text(". But unless ")#mi("\\delta")#text(" divides ")#mi("\\phi_*")#text(" exactly, we can do slightly better. And presumably for the published optimal values of ")#mi("\\omega")#text(" and ")#mi("\\delta")#text(", this is not the case? I haven’t checked.")

#text("Similarly one would hope to do slightly better at the Type III boundary, where we instead want ")#mi("r \\sim X^{\\rho_*}")#text(" with, I think, ")#mi("\\rho_* = \\frac{1}{16} - \\frac{23}{2}\\omega - \\frac{3}{2}\\delta")#text(".")

#text("These will be microscopic gains.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233686")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("You can always slip ")#mi("(\\omega,\\delta)")#text(" one way or the other by a smidge w/o changing the best integral ")#mi("k_0")#text(". I chose ")#mi("\\omega \\approx 1/946")#text(" for simplicity, but it is really not the maximum with the Bessel zeros, considering them as a smooth function in ")#mi("k_0")#text(" from the approximation. This could yield us some (tiny) leeway as you indicate. Whether or not it would allow ")#mi("k_0")#text(" to be decremented (as an integer) is a different issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233688")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("I do not propose to be the one to address this question in detail. Perhaps it’s best left alone until thinking about ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" has settled.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233835")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("As the problem is purely combinatorial and can be attacked independently of the rest of the polymath8 project, I split off a post about it at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("A combinatorial subset sum problem associated with bounded prime gaps")]
]

#text("I plan to expand this post a bit later by fleshing out the number theoretic side to this combinatorial argument (i.e. Section 6 of Zhang). Instead of one enormous post on Zhang’s theorem, I now plan to have two subsequent posts, one on the Type I/II arguments and one on the Type III arguments, which will split the polymath8 project into five (!) independent parts:")

#text("1. Improving the Type I/II estimates.")#linebreak()#text(" 2. Improving the Type III estimates.")#linebreak()#text(" 3. Improving the combinatorics that combine the Type I/II and Type III estimates to give ")#mi("MPZ[\\varpi,\\delta]")#text(" estimates.")#linebreak()#text(" 4. Improving the sieve theory that deduces ")#mi("DHL[k_0,2]")#text(" from ")#mi("MPZ[\\varpi,\\delta]")#text(".")#linebreak()#text(" 5. Finding narrow prime tuples of a fixed size ")#mi("k_0")#text(".")

#text("Currently we have blog posts for parts 3,4,5, while the rather overburdened reading seminar blog post is still holding the discussion for parts 1 and 2, but I hope to send out posts to cover those areas soon…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233837")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Sounds like a good strategy. Note that I posted here a small improvement for part #4.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233694")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("A remark about the constraint ")#mi("207 \\varpi + 43 \\delta < \\frac{1}{4}")#text(":")

#text("Since this gives a simple sufficient condition for ")#mi("MPZ[\\varpi, \\delta]")#text(" (assuming of course the positivity of these parameters!),")#linebreak()#text(" Another direction of optimization is to find the explicit expressions for the coefficients 207, 43 and 1/4 in the constraint as functions of free (i.e. “convenient” arbitrary) parameters used by Zhang and Pintz (if I remember correctly the number 10 was used as a parameter and also 1\\4).")#linebreak()#text(" I think that by knowing the exact dependence of 207, 43, 1/4 on these “free” parameters (along with their necessary restrictions), we can “play” with them as ADDITIONAL “control” parameters to further minimize ")#mi("k_0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233698")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("I think this is what v08ltu claimed to have done on 7 June, 2013 at 11:03 pm (see ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/#comment-233364")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/#comment-233364")]#text("). Of course v08ltu worked with the analytic Selberg sieve (Theorem 6 above), while one can also try the elementary Selberg sieve (Theorem 10 above). From Terry’s comments I anticipate that Theorem 6 gives better results here. On the other hand, improving on either theorem might lead to a better ")#mi("k_0")#text(". Also, we still need confirmation from the online reading seminar team that the constraints you mention are sufficient for ")#mi("(\\varpi,\\delta)")#text(" to be admissible. There are many details to be checked, although my feeling is that the constraints are ok, and probably we’ll even see larger pairs ")#mi("(\\varpi,\\delta)")#text(" in the near future.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233700")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Thanks!")#linebreak()#text(" (BTW, I meant to identify ALL the convenient arbitrary parameters used throughout the analysis and their necessary constraints in order to replace the 207, 43, 1/4 by these “control” parameters to optimize ")#mi("k_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233702")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("I am not sure what you mean by “convenient arbitrary parameters used throughout the analysis”. At this point we have Theorems 6 and 10 above to obtain an admissible ")#mi("k_0")#text(", and they utilize the parameters ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(". Of course these are not arbitrary parameters, they are the ones that parametrize a natural generalization of Zhang’s main result (Theorem 2 in his paper), called ")#mi("MPZ[\\varpi,\\delta]")#text(" here. More parameters would require an even more flexible generalization of Zhang’s result, and (most likely) an even more complicated treatment to achieve it. Already the present proof (in Zhang’s paper) is rather involved!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233703")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Perhaps I misunderstood you. At any rate, the coefficients 207, 43, 1/4 do not come from any control parameters. They come from analyzing Zhang’s proof step by step to see what is needed to achieve ")#mi("MPZ[\\varpi,\\delta]")#text(" instead of Zhang’s original ")#mi("MPZ[\\frac{1}{1168},\\frac{1}{1168}]")#text(". Each step works for a certain set of pairs ")#mi("(\\varpi,\\delta)")#text(", and the final condition describes the intersection of all these sets. Zhang’s theorem says that the pair ")#mi("(\\frac{1}{1168},\\frac{1}{1168})")#text(" is in the intersection, and the online reading seminar tries to see what other pairs are included.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233709")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("A (perhaps not full) list of “arbitrary” parameters used by Zhang:")

#text("1. The exponent 1/4 in (2.5).")#linebreak()#text(" 2. l_0 = 180 in page 6.")#linebreak()#text(" 3. 3/8, 8, 1/2, -1/4 in (2.13)")#linebreak()#text(" 4. The exponent 20 in (A5) page 7.")#linebreak()#text(" 5. The exponent 1/10 and sum of 10 terms in lemma 6.")#linebreak()#text(" 6. The exponents 19, 1/4, 2/3 in Lemma 7.")#linebreak()#text(" 7. 10 in lemma 11. (page 13)")#linebreak()#text(" 8. 292 before (4.14) (I don’t see the reason for ")#mi("\\log 293")#text(" in (4.14) and its possible dependence of previous “arbitrary” parameters)")#linebreak()#text(" 9. 44, 45 in (13, 12).")#linebreak()#text(" 10. -1/2, -48 in (13.15)")

#text("My questions: Is it true that one can slightly change the above parameters without destroying Zhang analysis? If so, my second question is about the")#linebreak()#text(" coefficients 207, 43, 1/4 – are they invariant to slight perturbations in the above “arbitrary” parameters, or they depend in some way on the “arbitrary” parameters ?(if the latter possibility is true then one may try to optimize k_0 using the above “arbitrary” parameters)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233713")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("1. The 1/4 here is just a convenient (additive) rescaling, in that its square is 1/2, which was the previous barrier. This allows one to measure, in terms of ")#mi("2\\omega")#text(", by how much one has beaten sqrt.")#linebreak()#text(" 2. It seems as though the use of the better sieves and/or weighting functions has made this parameter evaporate. In the original GY work, it was around ")#mi("\\sqrt {k}")#text(" if I recall correctly (to optimize some binomial coefficient quotient), but I don’t think it matters now.")#linebreak()#text(" 3&9&10. These have been rewritten in terms of ")#mi("\\omega,\\delta")#text(" by Green and Pintz. It turns out that ")#mi("x_1")#text(" is critical, while ")#mi("x_2")#text(" is not.")#linebreak()#text(" 4&5. These come about the decomposition in Section 6. Any number at least 9 (I think) will work. This changes nothing in the argument to make it larger, as you will still have the same type of sums to investigate, only possibly with more convolvedness. As Tao pointed out in a comment somewhere, if you wanted to get bounds on how large ")#mi("x")#text(" had to be in order to guarantee a tuple, then they would be more relevant (and you would likely minimize the “10”).")#linebreak()#text(" 6. The 19 in Lemma is 2*10-1 from 4&5. The 1/4 and 2/3 are just lower/upper bounds, as he also invokes this lemma with in an interval whose size in x-powers is always somewhere in ")#mi("[3/8-A\\omega-B\\delta,5/8+C\\omega+D\\omega]")#text(". These put very weak bounds on ")#mi("\\omega,\\delta")#text(".The 1/4 and 2/3 come nowhere into that lemma really (you can make them 1/100 and 99/100), as you get exponential decay any extra constants in the error term do not matter.")#linebreak()#text(" 7. I have no idea why Zhang put that condition in Lemma 11. It looks funny to me (I even underlined it). He always invokes it with ")#mi("d\\gg x^{5/12}")#text(" or something, so it is not a problem.")#linebreak()#text(" 8. The 292 is just from ")#mi("4/\\omega")#text(" I think.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233728")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Please see my reply (8:37 pm) which somehow “jumped” above.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233711")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Dear Terry, some corrections to the previous post on the analytic Selberg sieve:")

#text("1. In the third display below (20), ")#mi("d_1")#text(" (resp. ")#mi("d_2")#text(") should be coprime with ")#mi("a_1")#text(" (resp. ")#mi("a_2")#text("). This condition can be dealt with as in (25) of the present post.")

#text("2. Six lines below (21), ")#mi("k_0\\varpi\\ll\\log k_0")#text(" should be ")#mi("k_0\\varpi\\gg\\log k_0")#text(".")

#text("3. In the display before (23), a closing parenthesis is missing on the right.")

#text("4. In the line below (23), ")#mi("y>z")#text(" should be ")#mi("y\\geq z")#text(" (necessary for the ")#mi("n=1")#text(" case of Lemma 13).")

#text("5. In (24), ")#mi("\\frac{x}{p}")#text(" should be ")#mi("\\frac{z}{p}")#text(". Also, (24) seems to be an identity as there are no repeated factors in (22).")

#text("6. In the proof of Lemma 13, ")#mi("y>\\varpi")#text(" should be ")#mi("y\\geq x^\\varpi")#text(". More importantly, in the induction step we only need Mertens’ theorem instead of the stronger PNT.")

#text("7. In the fourth display below (26), a factor ")#mi("(k_0-1)^{\\Omega([d_1,d_2])}")#text(" is missing.")

#text("8. A few lines above (29), a parenthesis is unclosed in “(and extended by zero to ")#mi("[1,\\infty)")#text("“.")

#text("9. In the display before (29), the factor ")#mi("\\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]}")#text(" is missing.")

#emph[#text("[Corrected, thanks – T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233720")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Regarding #1, I also don’t see how this display follows from the previous one, i.e. how the second display below (20) implies the next one. It seems to utilize ")#mi("[a_1d_1,a_2d_2]=[a_1,a_2][d_1,d_2]")#text(", but this might fail even when ")#mi("(a_1,d_1)=1")#text(" and ")#mi("(a_2,d_2)=1")#text(". Grouping the terms according to ")#mi("(a_1,d_2)")#text(" and ")#mi("(a_2,d_1)")#text(" might help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233721")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Another idea would be to do the partial Möbius inversion not via summing over ")#mi("a_1|d_1")#text(" and ")#mi("a_2|d_2")#text(" simultaneously, but via summing over ")#mi("a|[d_1,d_2]")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233712")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("For some reason the longish message I sent 5 minutes ago (at 7:00pm) appears 5 replies above. It contains several corrections to the previous post on the analytic Selberg sieve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233722")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Thanks for the explanation! Can you please repeat the formula that does not parse?")

#text("More questions: Do you think that the coefficients 207, 43, 1/4 are independent on the “arbitrary” parameter 10? (note also that the exponent 19 in lemma depends on the parameter “10”)")

#text("The parameter 292 before (4.14) is also “arbitrary” because it depends on Zhang’s arbitrary parameter 1/1168. Do you think that 207, 43, 1/4 are also independent of the arbitrary parameter 292?")

#text("(Incidentally, from the current constraint it follows that under Zhang’s restriction ")#mi("\\delta = \\varpi")#text(", it follows that ")#mi("\\varpi = 1/1000")#linebreak()#text(" which is a slight improvement over Zhang’s value.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233725")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("The above message was reply to vo8ltu answer (7:26 pm) to my questions in my message below.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69328ca38020bfdb13e572a59ca53eaf4bd575cc30bf6a9da7fcbe218b11e62b-35ac0fb53b4d8dfdaafdeca5cc6d4320e35ac400b23bc0818982f7d91f3d6ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Zhang’s main objective was to get a finite number for k_0. Along the paper he did some simplifying assumptions (some parameters equal) and some “rough” estimates along the way so he would not be bogged down with sometimes complicated “details”. That is perfectly normal in such a complicated piece of mathematics.")

#text("As I can infer from the discussions here most of these inefficiencies have now been dealt with. All that while preserving his core arguments. There are no more “natural” parameters to wiggle around. If we want more parameters we must come up with new ideas in the main argument.")

#text("As ugly as the numbers 207 and 43 look like they are not “parameters” in any way they are numbers that appear by adding and multiplying what are most probably already tight estimates of very complicated terms.")

#text("That does not mean the estimates cannot be improved it just means that the tactics needed now are different.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233736")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Here is a suggestion how to decrease ")#mi("\\kappa")#text(" in Theorem 6, namely how to replace ")#mi("3k_0")#text(" by ")#mi("k_0")#text(" and more. In the previous post, (21) results from (20) by extending the summation to ")#mi("d_1,d_2\\in\\mathcal{S}_{I\\cup J}")#text(", and then doing a partial Möbius inversion by summing over divisors in ")#mi("\\mathcal{S}_J")#text(" of ")#mi("d_1")#text(" and ")#mi("d_2")#text(". It is simpler to do a partial Möbius inversion by summing over divisors in ")#mi("\\mathcal{S}_J")#text(" of ")#mi("[d_1,d_2]")#text(". Note that ")#mi("[d_1,d_2]\\in S_I")#text(" iff ")#mi("d_1,d_2\\in S_I")#text(". Then we get a version of (21) and (22) where ")#mi("a_1=a_2")#text(", and we save the complications right below (21). This also simplifies the argument after (22), e.g. we don’t need Cauchy, and the value of ")#mi("\\alpha")#text(" can be decreased which is good.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233819")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Sorry, this was nonsense. For some reason I pretended that $a|[d_1,d_2]$ iff $a|d_1$ and $a|d_2$. That is, I mixed up $[d_1,d_2]$ with $(d_1,d_2)$.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233797")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("After equation (1), “where ")#mi("k_0 = k_0(\\theta)")#text(" depends on ")#mi("k_0")#text("” should read “depends on ")#mi("\\theta")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233798")[#strong[#text("More narrow admissible sets | Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")]

#text("[…] on sieve theory, bridging the gap begin Zhang’s Theorem 2 and the parameter k_0 (see also the follow-up post). 3) Efforts to find narrow admissible sets of a given cardinality k_0 — the width of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233817")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Apparent problem with the definition of ")#mi("\\varpi")#text(" in theorem 6:")

#text("According to this definition ")#mi("\\varpi = 0")#text(" (?) whenever")#linebreak()#text(" ")#mi("2\\delta < 1+4\\varpi")#text(", (which is permitted by the current constraints)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233818")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I meant of course the reverse inequality, but the problem is still there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233820")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("The conditions (not definitions) are ")#mi("0<\\varpi<1/4")#text(" and ")#mi("0<\\delta<1/4+\\varpi")#text(". I don't see any problem with that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233823")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("You are right of course (it was my error!)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233829")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("In theorem 10, f is supported on [-1, 1]. Is it really necessary ? (i.e. can we replace [-1,1] by [0, 1] ?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233831")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Here is another attempt to decrease ")#mi("\\kappa")#text(" in Theorem 6. By the comments below (21) in the previous post, we can restrict to ")#mi("(a_1,a_2)=1")#text(" in (21) and later. Then, for a given ")#mi("a\\in\\mathcal{S}_J")#text(", the number of representations ")#mi("a=[a_1,a_2]")#text(" is ")#mi("2^{\\Omega(a)}")#text(" instead of ")#mi("3^{\\Omega(a)}")#text(". More importantly, we can now more efficiently bound")

#mi("(1 - \\frac{\\log a_1}{\\log R})_+(1 - \\frac{\\log a_2}{\\log R})_+ \\leq (1 - \\frac{\\log a_1a_2}{\\log R^2})_+^2")

#text("by the inequality")#linebreak()#text(" between the geometric and arithmetic means. All this shows that Theorem 6 is valid with the smaller value")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0} \\prod_{j=1}^{n} (1 + 2k_0 \\log(1+\\frac{1}{j}))")#text(".")

#text("Note that the exponent ")#mi("k_0")#text(" was originally ")#mi("k_0/2")#text(", and the factor ")#mi("2k_0")#text(" was originally ")#mi("3k_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Oh, I think that works! So now we have ")#mi("DHL[k_0,2]")#text(" whenever we can find ")#mi("\\varpi, \\delta")#text(" obeying the constraints")

#mi("207\\varpi + 43\\delta < \\frac{1}{4}")

#text("and")

#mi("1+4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")

#text("where ")#mi("\\kappa")#text(" is the quantity")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0} \\prod_{j=1}^{n} (1 + 2k_0 \\log(1+\\frac{1}{j})) ).")

#text("Hopefully this will decrease the value of ")#mi("k_0")#text(" somewhat from its current value of 26,024 (and maybe close to the value of 25,111 that v08ltu computed using Pintz's overly optimistic (and now retracted) value ")#mi("\\kappa = \\frac{1}{\\delta} \\exp( - k_0 \\delta)")#text(" of ")#mi("\\kappa")#text(", though probably we won't get quite that far).")

#text("p.s. It’s nice that the process of correcting an error in the original argument led to a substantive improvement in the bounds of the argument; usually it works in the opposite direction. :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233850")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("In fact, this is better than the Pintz version (the exponent ")#mi("k_0/2")#text(" really helps), I get that ")#mi("(\\omega,\\delta)=(1/899,71/154628)")#text(" and ")#mi("k_0=23283")#text(" works. Here ")#mi("\\kappa\\approx 0.000018194031")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233852")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I’ve confirmed these values. Great, we’ve improved k_0; time to tell the H team again :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233857")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("That’s good news, thanks! Using SAGE I am getting a much smaller value of ")#mi("\\kappa")#text(", which is probably in error. Let ")#mi("(\\varpi,\\delta,k_0)=(1/899,71/154628,23283)")#text(". Can you or Terry tell me which ")#mi("1\\leq n<\\frac{1+4\\varpi}{2\\delta}")#text(" has the largest contribution to ")#mi("\\kappa")#text(",")#linebreak()#text(" and what are the numerical values ")#mi("(1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0}")#text(" and ")#mi("\\prod_{j=1}^{n} (1 + 2k_0 \\log(1+\\frac{1}{j}))")#text(" separately for that particular ")#mi("n")#text("? This will help me find the error in my code.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233860")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("It is almost totally dominated by the ")#mi("n=1")#text(" term, the next term is essentially the square of that (of size ")#mi("10^{-10})")#text(".")#linebreak()#text(" I am not sure the PARI/GP code will parse easily in HTML, but:")

#text("Bz(k)=k+1.85575708149*k^(1/3)+1.033150/k^(1/3);")

#text("KAPPA(om,d,k0)=sum(n=1,(1+4*om)/2/d,(1.0-2*n*d/(1+4*om))^k0*\\")#linebreak()#text(" prod(j=1,n,1.0+2*k0*log(1+1/j)));")

#text("DELTA(om)=(1/4-207*om)/43;")

#text("INEQ(om,k0)=(1+4*om)-Bz(k0-2)^2/k0/(k0-1)*(1+KAPPA(om,DELTA(om),k0));")

#text("INEQ(1/899,23283) \\\\ 1.0129862941699405267254440279736940545E-7")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233862")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("The gain of ")#mi("k_0/2")#text(" in the exponent means that (as ")#mi("n=1")#text(" dominates) the effect is in the limit ")#mi("e^{-2k_0\\delta/(1+4\\omega)}")#text(", which is square of the previous (there is also no ")#mi("1/\\delta")#text(" in front as with Pintz either). Small sized numerics are similarly superior. Any theoretical reason why this wins another power back? Does the better weighting function help the analysis, or is the analysis just more robust now?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233864")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I think the original analysis was a bit wasteful: the product of two numbers in ")#mi("[0,1]")#text(" was upper bounded by the larger of the two. Hence if both numbers were small (which is typically the case), only the effect of one of them was exploited. The new analysis is more efficient/natural in the sense that the effect of both numbers is used.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233863")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Thanks for the code, I found the bug in mine!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233873")[#strong[#text("Polymath8: Bounded Gaps Between Primes | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")]

#text("[…] Zhang’s proof and improving the upper bound for the gaps. Here are links for three posts (I, II, III) on Terry Tao’s blog and for a post on the polymath blog. And here is the table for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A combinatorial subset sum problem associated with bounded prime gaps | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233901")[#strong[#text("A combinatorial subset sum problem associated with bounded prime gaps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("[…] this follows from e.g. Proposition 5 of this previous post. From (10) we also deduce (11). To show (12), it suffices to show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Regarding further improvement of ")#mi("\\kappa")#text(" (and also a secondary quantity ")#mi("\\kappa^{\\prime}")#text(" – see below), I see two ways forward, but they have the drawback of making the formulae for ")#mi("\\kappa")#text(" more complicated")

#text("(1) Starting from Gergely’s formula")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0} \\prod_{j=1}^{n} (1 + 2k_0 \\log(1+\\frac{1}{j})) ).")#text(",")

#text("extract out the n=1 term (which experience has shown dominates all the other terms in practice) and compute it more carefully, in particular avoiding the use of the arithmetic mean-geometric mean inequality and perhaps also avoiding the use of the decreasing nature of the Bessel function. In other words, just keep the funny weighted Bessel integral as it is. This can be computed numerically and perhaps the numerical value is significantly better than the upper bound we currently have.")

#text("(2) This is an approach briefly mentioned in the previous post: instead of working purely on the “alpha” side of things, we can also work on the “beta” side of things and not throw away some positive terms. Namely, one should be able to improve the condition")

#mi("1+4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")

#text("to")

#mi("(1+4\\varpi) (1+\\kappa^{\\prime}) > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")

#text("where ")#mi("\\kappa^{\\prime}")#text(" is a quantity somewhat similar in nature to ")#mi("\\kappa")#text(". Again, we might only need to save the n=1 term given that it is likely to dominate all the others. It may be that the n=1 term for ")#mi("\\kappa^{\\prime}")#text(" can be used to cancel a large portion of the n=1 term for ")#mi("\\kappa")#text(" which would lead to quite a noticeable improvement I think (of course one can’t hope to do better than eliminating kappa entirely though, or at least I don’t think this should be the case, otherwise we could make improvements to Theorem 3 as well as Theorem 6 which seems unlikely.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234047")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("For (1), is it correct that we would essentially be interested in ")#mi("\\int_\\delta^{2\\delta}\\int_\\delta^{2\\delta}\\int_0 f_0^{\\prime}(x+{\\beta_1\\over 1/4+\\omega})f_0^{\\prime}(x+{\\beta_2\\over 1/4+\\omega}){x^{k_0-1}\\over (k_0-1)!}\\,dx\\,d\\beta_1\\,d\\beta_2")#text(" where the ")#mi("x")#text("-integral goes up to the point where one of the ")#mi("f_0^{\\prime}")#text(" arguments exceeds 1? I pieced this together from (30) and following from the previous post, with elements from (22) and beyond interlaced.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b9eda2558d5600a51e77983ac544b19be7082bb35cff57525d4c894bbcee842-2694b509de9d64d3577779b6df007dbbfc03a94b3403e60e819f63520c0172c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CraigH")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234019")[#strong[#text("CraigH")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("I am slightly confused. I am looking at the proof of Lemma 7, and it seems that one can easily modify the proof to show DHL[")#mi("k_0")#text(", 3] for exactly the same value of ")#mi("k_0")#text(" simply by replacing ")#mi("\\log(5x)")#text(" in the place of ")#mi("\\log(3x)")#text(" in (9). Likewise for any fixed value of ")#mi("m")#text(" in DHL[")#mi("k_0")#text(", m]. Where does this break down?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234021")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("@CraigH: to get ")#mi("DHL[k_0,3]")#text(" one would need to replace ")#mi("\\log(3x)")#text(" not by ")#mi("\\log(5x)")#text(", but by the significantly larger quantity ")#mi("2 \\log(3x)")#text(". Unfortunately it does not appear that the GPY method lets one do this, even with the best distribution hypothesis (i.e. the Elliott-Halberstam conjecture) and the best choice of sieve weights.")

#text("[For some reason, comments are not coming in in order in this post; I am unable to locate the source of this error.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b9eda2558d5600a51e77983ac544b19be7082bb35cff57525d4c894bbcee842-2694b509de9d64d3577779b6df007dbbfc03a94b3403e60e819f63520c0172c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CraigH")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234031")[#strong[#text("CraigH")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Right, sorry. So it is actually ")#mi("\\log((2+\\epsilon) x)")#text(" gives you two primes, and ")#mi("m \\log((2+\\epsilon) x)")#text(" gives you ")#mi("m+1")#text(" primes. Thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Gah… I just realised that the “correction” I implemented to Gergely’s issue #1 of his 9 June 2013 ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233711")[#text("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-233711")]#text(" (in the material after (21) in the previous post ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")]#text(" ) does not work (the issue is that the ")#mi("\\frac{1}{p_*^2}")#text(" factor is actually only ")#mi("\\frac{1}{p_*}")#text(" due to the least common multiple operator in ")#mi("[a_1 d_1,a_2 d_2]")#text("). This unfortunately puts the three most recent values of ")#mi("k_0")#text(" (34429, 26024 and 23283) into question. I think i can salvage the first two (as Gergely already indicated in his comment) but the last one might not survive.")

#text("Will try to sort this out soon; sorry about this!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234078")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("I think the big improvement in ")#mi("\\kappa")#text(" still survives, because")

#mi("(1 - \\frac{\\log a_1}{\\log R})_+(1 - \\frac{\\log a_2}{\\log R})_+ \\leq (1 - \\frac{\\log a_1a_2}{\\log R^2})_+^2 \\leq (1 - \\frac{\\log [a_1,a_2]}{\\log R^2})_+^2")

#text("holds in general. Hence")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j}))")

#text("should work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234081")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("So it seems the good way to proceed in the previous post is as follows. In (21) the presence of ")#mi("\\mu(a_1d_1)\\mu(a_2d_2)")#text(" automatically gives that ")#mi("(a_1,d_1)=1")#text(" and ")#mi("(a_2,d_2)=1")#text(". By the ")#mi("W")#text("-trick we can also impose ")#mi("(a_1,d_2)=1")#text(" and ")#mi("(a_2,d_1)=1")#text(", so that ")#mi("[a_1d_1,a_2d_2]=[a_1,a_2][d_1,d_2]")#text(". Now we have the third display below (21) with the extra condition ")#mi("(a_1a_2,d_1d_2)=1")#text(". We get rid of this condition by applying the ")#mi("W")#text("-trick again. Finally we obtain the improved ")#mi("\\kappa")#text(", with ")#mi("3k_0")#text(" in place of ")#mi("3k_0")#text(", by applying the arithmetic-geometric mean inequality and noting that ")#mi("[a_1,a_2]\\leq a_1a_2")#text(". I hope this makes sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234085")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("It is worthwhile to remark that the factorization ")#mi("[a_1d_1,a_2d_2]=[a_1,a_2][d_1,d_2]")#text(" is valid when ")#mi("(a_1a_2,d_1d_2)=1")#text(". It suffices to verify this when each variable is a power of the same prime. Then the condition forces that ")#mi("a_1a_2=1")#text(" or ")#mi("d_1d_2=1")#text(", and the formula is clear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234089")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("OK, I was able to salvage the first two values of ")#mi("k_0")#text(". The point is that we cannot actually reduce to the case when no two of ")#mi("a_1,a_2,d_1,d_2")#text(" have no large prime common factor. However, we can still reduce to the case when ")#mi("a_i, d_j")#text(" have no large prime common factor for any ")#mi("(1+4\\varpi) (1-\\kappa^{\\prime}) > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")#text(" where ")#mi("\\kappa^{\\prime}")#text(" is very similar to ")#mi("\\kappa")#text(". However by being more careful with the ")#mi("n=1")#text(" terms I can make those terms at least get back to where they were before the error was found; since the n=1 terms were so dominant this may end up not costing us anything in the k_0 error at all. I’ll write this up properly as a blog post now (it’s nearly time to roll over the thread anyway, especially given that this particular post seems to have something wrong with the comment ordering).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234096")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Can we not achieve ")#mi("(a_1a_2,d_1d_2)=1")#text(" by the ")#mi("W")#text("-trick? This is sufficient for ")#mi("[a_1d_1,a_2d_2]=[a_1,a_2][d_1,d_2]")#text(".")

#text("Also, can we still use ")#mi("(1 - \\frac{\\log a_1}{\\log R})_+(1 - \\frac{\\log a_2}{\\log R})_+ \\leq (1 - \\frac{\\log [a_1,a_2]}{\\log R^2})_+^2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("The second inequality is still available, which is good news as it captures the bulk of the gain for kappa. The coprimality is unfortunately not available from the W-trick because the sum is weighted by ")#mi("\\frac{1}{[a_1d_1,a_2d_2]}")#text(" rather than ")#mi("\\frac{1}{a_1d_1a_2d_2}")#text(" and so the non-coprime terms have a comparable contribution to the coprime terms. However, after working things out and using some ideas from the most recent preprint of Pintz (avoiding the parts of that preprint which were in error, of course) to substitute for Buchstab iteration, I was able to get a criterion which is actually better than the one we already have, basically the previous error had the shape ")#mi("2k_0 \\exp( - \\frac{2k_0 \\delta}{1+4\\varpi} )")#text(" and I can now improve this to ")#mi("\\frac{1+4\\varpi}{\\delta} \\exp( - \\frac{2k_0\\delta}{1+4\\varpi})")#text(". See the newest post for details (but the argument certainly needs to be checked!).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Further analysis of the truncated GPY sieve | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234103")[#strong[#text("Further analysis of the truncated GPY sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("[…] post is a continuation of the previous post on sieve theory, which is an ongoing part of the Polymath8 project. As the previous post was getting somewhat full, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Given the number of comments on this post, it is probably time to roll over to a new thread, so we are moving to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("Further analysis of the truncated GPY sieve")]
]

#text("where I believe I have fixed the issue in the previous arguments linking ")#mi("\\varpi,\\delta")#text(" to ")#mi("k_0")#text(", and in the process found a somewhat better bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-234214")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] the claim then follows by dividing by and summing using standard estimates (see Lemma 8 of this previous post). But this claim follows from the Bombieri-Vinogradov theorem (Theorem 4), after restricting to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A truncated elementary Selberg sieve of Pintz | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-235112")[#strong[#text("A truncated elementary Selberg sieve of Pintz | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("[…] argument uses the elementary Selberg sieve, discussed in this previous post, but with a more efficient estimation of the quantity , in particular avoiding the truncation to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-236190")[#strong[#text("Zhang’s theorem on bounded prime gaps | random number theory generator")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")]

#text("[…] would be prime. It remains to estimate the numerator and denominator of . To this end, we introduce Selberg’s functions which, with judicious weights, approximate our previous . Fix with , and put , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-238201")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("Just a typo: the third display below (11) should be ")#mi("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) a_{d_1} \\mu(d_2) a_{d_2} \\Delta([d_1,d_2])")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/#comment-462486")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("Reblogged this on ")#link("https://tomcircle.wordpress.com/2015/11/27/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("Math Online Tom Circle")]#text(".")
]
