// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/
// Converted to Typst by tao2typ: "2026-10-14T16:35:00.898347+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Printer-friendly CSS, and nonfirstorderisability", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Printer-friendly CSS, and nonfirstorderisability")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/")[#text("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I recently discovered a ")#link("http://en.forums.wordpress.com/topic.php?id=7015&page&replies=3")[#text("CSS hack")]#text(" which automatically makes wordpress pages friendlier to print (stripping out the sidebar, header, footer, and comments), and installed it on this blog (in response to an emailed suggestion). There should be no visible changes unless one “print previews” the page.")

#text("In order to prevent this post from being totally devoid of mathematical content, I’ll mention that I recently came across the phenomenon of ")#link("http://en.wikipedia.org/wiki/Nonfirstorderizability")[#text("nonfirstorderisability")]#text(" in mathematical logic: there are perfectly meaningful and useful statements in mathematics which cannot be phrased within the confines of ")#link("http://en.wikipedia.org/wiki/First_order_logic")[#text("first order logic ")]#text("(combined with the language of set theory, or any other standard mathematical theory); one must use a more powerful language such as ")#link("http://en.wikipedia.org/wiki/Second_order_logic")[#text("second order logic")]#text(" instead. This phenomenon is very well known among logicians, but I hadn’t learned about it until very recently, and had naively assumed that first order logic sufficed for “everyday” usage of mathematics.")

#metadata(none) <tao-df211764fc07e5fdeaa9>#text("Let’s begin with some simple examples of statements which ")#emph[#text("can")]#text(" be expressed in first-order logic. If B(x,y) is a binary relation on two objects x, y, then we can express the statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For every x, there exists a y depending on x such that B(x,y) is true")
]

#text("in first order logic as")

#align(center)[#tao-fit-display[#mitex("\\forall x \\exists y: B(x,y)")]]

#text("whereas the statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For every x, there exists a y ")#emph[#text("independent")]#text(" of x such that B(x,y) is true")
]

#text("can be expressed as")

#align(center)[#tao-fit-display[#mitex("\\exists y \\forall x: B(x,y).")]]

#text("Moving on to a more complicated example, if Q(x,x’,y,y’) is a quaternary relation on four objects x,x’,y,y’, then we can express the statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For every x and x’, there exists a y depending only on x and a y’ depending on x and x’ such that Q(x,x’,y,y’) is true")
]

#text("as")

#align(center)[#tao-fit-display[#mitex("\\forall x \\exists y \\forall x^{\\prime} \\exists y^{\\prime}: Q(x,x^{\\prime},y,y^{\\prime})")]]

#text("(note that this allows y’ to depend on y also, but this turns out to be moot, because y depends only on x), and one can similarly express")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For every x and x’, there exists a y depending on x and x’ and a y’ depending only on x’ such that Q(x,x’,y,y’) is true")
]

#text("as")

#align(center)[#tao-fit-display[#mitex("\\forall x^{\\prime} \\exists y^{\\prime} \\forall x \\exists y: Q(x,x^{\\prime},y,y^{\\prime})")]]

#text("but it seems that one cannot express")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For every x and x’, there exists a y depending only on x and a y’ depending only on x’ such that Q(x,x’,y,y’) is true (*)")
]

#text("in first order logic! For instance, the statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("To every finitely generated real vector space V one can associate a unique non-negative integer ")#mi("\\dim(V)")#text(" such that")

#enum(start: 1, 
[#text("V, W are isomorphic if and only if ")#mi("\\dim(V) = \\dim(W)")#text(";")],
[#text("an injection from V to W exists if and only if ")#mi("\\dim(V) \\leq \\dim(W)")#text(";")],
[#text("a surjection from V to W exists if and only if ")#mi("\\dim(V) \\geq \\dim(W)")#text(";")],
[#mi("\\dim({\\mathbb R}) = 1")#text("; and")],
[#mi("\\dim(V \\oplus W) = \\dim(V) + \\dim(W)")#text(" for all V, W,")]
)
]

#text("which is part of the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_linear_algebra")[#text("fundamental theorem of linear algebra")]#text(", does not seem to be expressible as stated in first order set theory (though of course the concept of dimension can be explicitly constructed within this language), even if we drop the uniqueness and restrict ourselves to just the assertion that ")#mi("\\dim()")#text(" obey, say, property 1, so that we get an assertion of the form (*). Note that the category of all finite-dimensional vector spaces is not a set (for reasons relating to ")#link("http://en.wikipedia.org/wiki/Russell's_paradox")[#text("Russell’s paradox")]#text(") and so we cannot view ")#mi("\\dim")#text(" as a function. More generally, many statements in category theory dealing with ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("large categories")]#text(" seem to not be expressible in first order logic.")

#text("I can’t quite show that (*) is not expressible in first-order logic, but I can come very close, using ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("non-standard analysis")]#text(". The statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For every real numbers x and x’ there exists real numbers st(x) and st(x’) depending only on x and x’ respectively, such that st(x+x’) = st(x)+st(x’), st(xx’) = st(x) st(x’), st(1)=1, and st(x) is non-negative whenever x is non-negative, and also such that st(x) is not always equal to x")
]

#text("is true in the non-standard model of the real numbers, but false in the standard model (this is the classic algebra homework problem that the only order-preserving field homomorphism on the reals is the identity). Since the transfer principle ensures that all first-order statements that are true in the standard reals are also true in the non-standard reals, this means that the above statement cannot be expressed in first-order logic. If it weren’t for the “st(x) is not always equal to x” part, this would basically be of the form (*).")

#text("It seems to me that first order logic is limited by the linear (and thus totally ordered) nature of its sentences; every new variable that is introduced must be allowed to depend on ")#emph[#text("all")]#text(" the previous variables introduced to the left of that variable. This does not fully capture all of the dependency trees of variables which one deals with in mathematics. In analysis, we tend to get around this by using English phrasings such as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("… assuming N is chosen sufficiently large depending on ")#mi("\\epsilon")#text(", and ")#mi("\\delta")#text(" chosen sufficiently small depending on N …")
]

#text("and")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("… where C can depend on k and d, but is uniform with respect to n and f …,")
]

#text("or by using the tremendously convenient ")#link("http://en.wikipedia.org/wiki/Big_O_notation")[#text("O() and o() notation of Landau")]#text(". One then takes for granted that one can eventually unwind all these phrasings to get back to a sentence in formal, first-order logic. As far as analysis is concerned, this is a fairly safe assumption, since one usually deals with objects in very concrete sets such as the real numbers, and one can easily model all of these dependencies using functions from concrete sets to other concrete sets if necessary. (Also, the hierarchy of magnitudes in analysis does often tend to be rather linearly ordered.) But some subtleties may appear when one deals with large categories, such as the category of sets, groups, or vector spaces (though in most applications, one can cap the cardinality of these objects and then one can represent these categories up to equivalence by an actual set). It may be that a more diagrammatic language (perhaps analogous to the commutative diagrams in category theory, or one based on trees or partially ordered sets rather than linearly ordered ones) may be a closer fit to expressing the way one actually thinks about how variables interact with each other. (")#link("http://en.wikipedia.org/wiki/Second_order_logic")[#text("Second-order logic")]#text(" is, of course, an obvious candidate for such a language, but it may be overqualified for the task. And, in practice, there’s ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/take-advantage-of-the-english-language/")[#text("nothing wrong with just using plain old mathematical English")]#text(".)")

#text("[")#emph[#text("Update")]#text(", Aug 27: bad link fixed.]")

#heading(level: 1)[#text("Comments (54)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh Venkat")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-7962")[#strong[#text("Suresh Venkat")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("Hi,")#linebreak()#text(" It’s worth mentioning here that first and second order logic are closely related to complexity classes, via an area of complexity theory called descriptive complexity. A famous result proved by Ron Fagin showed that NP is precisely the class of languages expressible by predicates in existential second order logic, a result that is very intriguing in how it connects “syntax” and “algorithmic complexity”. Other results include the characterization of P by first order logic + a fixed point operator + an ordering operator, and results for lower complexity classes, many of these results shown by Neil Immerman.")

#link("http://en.wikipedia.org/wiki/Descriptive_complexity")[#text("http://en.wikipedia.org/wiki/Descriptive_complexity")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oleg Izhvanov")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-7964")[#strong[#text("Oleg Izhvanov")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("Hi,")#linebreak()#text(" A technical note: the last link in the post is broken.")

#text("“And, in practice, there’s nothing wrong with")#linebreak()#text(" just using plain old mathematical English”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-7975")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("Dear Suresh and Oleg,")

#text("Thanks for the references and corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ori Gurel-Gurevich")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8003")[#strong[#text("Ori Gurel-Gurevich")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")])]

#text("“Note that the category of all finite-dimensional vector spaces is not a set (for reasons relating to Russell’s paradox) and so we cannot view \\dim as a function. More generally, many statements in category theory dealing with large categories seem to not be expressible in first order logic.”")

#text("That is true if we restrict ourselves to ZFC. However, an extended set theory like ")#link("http://en.wikipedia.org/wiki/Von_Neumann%E2%80%93Bernays%E2%80%93G%C3%B6del_set_theory")[#text("NBG")]#text(" is more suitable for such things. This would allow one to talk about such class functions as ")#mi("\\dim")#text(" without resorting to second order theories. There’s also the additional benefit of NBG being finitely axiomatizable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy D")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8030")[#strong[#text("Andy D")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")])]

#text("I believe I can show that the statement (*) Terry was discussing is not FO-definable for a particular FO-definable quaternary relation Q(x, x’, y, y’).")

#text("Namely, let Q(x, x’, y, y’) be")

#text("(y != x) and [(x = x’) implies (y = y’)] and [ (x != x’) implies (y != y’)].")

#text("Then (somebody please check this) statement (*) is true iff there exists a perfect matching over the universe’s elements.")

#text("Any infinite universe has such a matching; so the negation of (*) is true iff the universe is finite and has an odd number of elements (and the class of FO-definable properties is closed under negation). But universe parity is known not to be FO-definable.")

#text("FO-inexpressibility results are to my knowledge generally shown by one of two approaches:")

#text("i) analysis of the associated ‘Ehrenfeucht-Fraisse-Game’, an approach which can show inexpressibility of parity;")

#text("ii) reduction to a known FO-inexpressible property, as above. The most common reduction targets seem to be parity/counting properties, and graph connectivity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d707a7232d544292227e6c17fcb9cd17b598f1724070621f5c8eec56b6135102-a3ac8e32c47df3e2b4e9b1f672ea79b7ed3262754491a2810e1fa51eb3101b98.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8035")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")])]

#text("I’d heard of ")#link("http://en.wikipedia.org/wiki/Branching_quantifier")[#text("branching quantifiers")]#text(" before, but didn’t know what they were good for (except that some linguists, like Hintikka, have suggested that they might be good for analyzing natural language). It’s good to have some examples now!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61a41f9901217a6de1256a8b0d1638ac16eff5dec67bec389f3aa733236aed36-8ecbda28ae40c5f75e88d4d0173384140670cc8b955e99dab9becbec48f125a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8046")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")])]

#text("As Kenny’s link mentions, branching quantifiers have been treated by Hintikka in his ‘independence-friendly’ logic. The formula with four variable mentioned corresponds to a 2 vs 2 player game with incomplete information. Samson Abramsky, the theoretical computer scientist, has done some interesting ")#link("http://web.comlab.ox.ac.uk/oucl/work/samson.abramsky/sandu.pdf")[#text("work")]#text(" looking into the syntax and semantics of logics corresponding to multi-player games, with one ulterior aim being the modelling of concurrency.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2e69fe991008100445ec71dcce3acc2dd72f160b39f34a569b2669354396f85-1909c969e8c28926f573b796901e14bbf8458eb0ecb81c2ff446a678aa5879f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy D")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8053")[#strong[#text("Andy D")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")])]

#text("OK, looks like what I wrote is subsumed by the results mentioned on Q_H in Kenny’s reference. (*) seems like a surprisingly powerful schema.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69efe336c9821201d3ff47fe9dd91c27bf823742bad79841adfde0bc6a6b7432-a4d5c9fae47380411a02040bc257c2db5b940a97abe4dbc7b0d68f1110ef3656.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8077")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")])]

#text("Here’s another example dear to your heart. For each positive integer k, the statement, “the set A contains an arithmetic progression of length k” is transparently FO, while the statement “for each positive integer k, the set A contains an arithmetic progression of length k” is not (at least not in any straightforward manner).")

#text("A famously non-FO statement is “Every set with an upper bound has a least upper bound”, which is true for the reals, but not true for the non-standard reals, and so cannot be FO. This is, it seems to me, part of the undertapped mojo of nonstandard analysis (beyond epsilon management). You get access to different second order theorems (you lose a few but also gain a few) to help you prove first order theorems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8095")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("Dear Kevin,")

#text("I’m not sure I understand your examples, at least if I am interpreting “set” in an internal sense. Wouldn’t")

#mi("\\forall k > 0: \\exists a,r: ((r \\neq 0) \\wedge (\\forall 0 \\leq j \\leq r-1: a+jr \\in A))")

#text("be a first-order sentence that asserts that A contains arbitrarily long progressions? Similarly, the statement that every set with an upper bound has a least upper bound is still true for the non-standard reals if one restricts attention to non-standard sets of reals (as opposed to sets of non-standard reals). If one interprets the concept of “set” internally then")

#mi("\\forall A \\subset {\\Bbb R}: ((A \\neq \\emptyset) \\wedge \\exists x: \\forall y \\in A: y \\leq x) \\implies (\\exists z: (\\forall y \\in A: y \\leq z) \\wedge (\\forall x: (\\forall y \\in A: y \\leq x) \\implies (x \\geq z)))")

#text("seems to be a first-order sentence (albeit a rather ugly one) that asserts that every (non-empty) set with an upper bound has a least upper bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d707a7232d544292227e6c17fcb9cd17b598f1724070621f5c8eec56b6135102-a3ac8e32c47df3e2b4e9b1f672ea79b7ed3262754491a2810e1fa51eb3101b98.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8113")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("I think in your first example you mean ")#mi("\\forall 0\\leq j\\leq k-1")#text(" rather than ")#mi("\\forall 0\\leq j\\leq r-1")#text(".")

#text("As for the second example, it’s always sort of sneaky to quantify over sets in a first-order way – when you do that, you get non-standard models where the objects are just fine, but you’re missing some of the sets or something. I know people working on reverse mathematics (like Harvey Friedman and Steven Simpson at various points) do that with models of “second-order” arithmetic (really just first-order arithmetic where they use first-order quantification over sets as well) to prove that certain standard theorems are independent of weakened axiom systems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87a870e8818dc22b85c392e9f134a7eb1060d7ff08a385cddfa07b027736bbb5-c2243ed8a00fa802a0a7eae6e90a02d7f052a30076be02c30935a6ee420f78cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott McKuen")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8123")[#strong[#text("Scott McKuen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("Terry’s first example (mod Kenny) looks good if we’re willing to accept infinitely-long arithmetric progressions in the nonstandard models (since the variable k then runs over nonstandard positive integers as well). If we just want arbitrarily-long-but-finite progressions, which I think is what Kevin intended, then it fails.")

#text("If we’re working outside the theory of arithmetic, say in fields, and we don’t have a predicate to designate the integers as a definable set, then it doesn’t work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8149")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("Restricting the “domain” of quantification (I’m not sure which is the")#linebreak()#text(" technically correct word in logic/model theory) may make a huge")#linebreak()#text(" difference in what sets first order theory can define. One very cute")#linebreak()#text(" example, which does not seem to be so well-known, considers definable")#linebreak()#text(" sets in the first order theory of rings (+, -, *, 0, 1, …) applied")#linebreak()#text(" to finite fields: if we have a formula ")#mi("\\varphi(x)")#text(" with")#linebreak()#text(" ")#mi("x=(x_1,\\ldots, x_n)")#text(", it has been shown by Chatzidakis, van den Dries")#linebreak()#text(" and Macintyre (J. Reine angew. Math. 427 (1992), 107–135) that the")#linebreak()#text(" number of “solutions” in a finite field ")#mi("\\mathbf{F}_q")#text(" (i.e., the")#linebreak()#text(" number of ")#mi("x")#text(" in ")#mi("\\mathbf{F}_q^n")#text(" for which the formula is “true”,")#linebreak()#text(" with the standard interpretation of the language, and all quantifiers")#linebreak()#text(" implicitly running over ")#mi("\\mathbf{F}_q")#text(" only) is always (either 0 or)")#linebreak()#text(" of the type")

#mi("\\delta q^{d}+O(q^{d-1/2})")

#text("where ")#mi("\\delta")#text(" is a rational number (which may depend on ")#mi("q")#text(", but can only")#linebreak()#text(" take finitely many values for a given ")#mi("\\varphi")#text("), and ")#mi("d\\geq 0")#text(" is an")#linebreak()#text(" integer with the same property. This is of course reminiscent (and")#linebreak()#text(" ultimately derived from) the Lang-Weil estimate for the number of points")#linebreak()#text(" on an algebraic variety over a finite field.")

#text("So in particular the subfield ")#mi("\\mathbf{F}_p")#text(" of ")#mi("\\mathbf{F}_{p^2}")#text(" is")#linebreak()#text(" not definable in the first order theory of rings, i.e., there is no")#linebreak()#text(" formula ")#mi("\\varphi(x)")#text(", for which the set of “solutions” in")#linebreak()#text(" ")#mi("\\mathbf{F}_{p^2}")#text(" is ")#mi("\\mathbf{F}_p")#text(" for infinitely many ")#mi("p")#text(". (Come to")#linebreak()#text(" think of it, I’m not sure how using second order theory of rings could")#linebreak()#text(" help here; of course, adding something like the Frobenius automorphism")#linebreak()#text(" in the language would solve the problem).")

#text("(Note: one can even ")#link("http://arxiv.org/abs/math/0504316")[#text("add")#linebreak()#text(" exponential sums")]#text(" into the mixture and show cancellation statements")#linebreak()#text(" in exponential sums over such definable sets, similar to the results")#linebreak()#text(" of Weil and Deligne on exponential sums over finite fields — at least")#linebreak()#text(" the simplest statements extend –; in particular, it follows that an")#linebreak()#text(" “interval” (or an arithmetic progression) in ")#mi("\\mathbf{Z}/p\\mathbf{Z}")#linebreak()#text(" is also not definable in this language (unless it’s a fixed number of")#linebreak()#text(" elements, or the complement of such a thing). This is not surprising,")#linebreak()#text(" but for intervals with positive density one needs more than the result")#linebreak()#text(" of C-vdD-M — namely some additive characters do not cancel")#linebreak()#text(" appreciably over a long interval/arithmetic progression).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2007")])]

#text("I’m confused about how the 2×2 branching quantifier")

#mi("(Q_Hx_1,x_2,y_1,y_2) \\equiv\\begin{pmatrix}\\forall x_1 \\exists y_1\\\\ \\forall x_2 \\exists y_2\\end{pmatrix}")

#text("is supposed to support the “there are infinitely many” quantifier. Here’ s the quantifier-free clause in question for a generic formula (phi):")

#mi("\\psi(a,x_1,x_2,y_1,y_2)\\equiv[\\phi a\\land (x_1=x_2 \\leftrightarrow y_1=y_2) \\land (\\phi (x_1)\\rightarrow (\\phi (y_1)\\land y_1\\neq a))]")

#text("The three parts appear to say")

#text("1) something satisfies the formula;")

#text("2) if you have one satisfier, you can get another that isn’t just the starting point (no loops that start at “a”);")

#text("3) the map from one satisfier to the next is a bijection (no loops can start later on, either).")

#text("Why does quantifying this way:")

#mi("(Q_{\\geq\\mathbb{N}}x)\\phi (x)\\equiv\\exists a\\begin{pmatrix}\\forall x_1 \\exists y_1\\\\ \\forall x_2 \\exists y_2\\end{pmatrix} \\psi(a,x_1,x_2,y_1,y_2)")

#text("force “there are infinitely many” but quantifying, say, like this:")

#mi("\\exists a \\forall x_1 \\exists y_1\\\\ \\forall x_2 \\exists y_2 \\psi (a,x_1,x_2,y_1,y_2)")

#text("does not? Can we exhibit a finite model of the first-order version?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2007")])]

#text("Dear anonymous,")

#text("I’m assuming that your final display was of a standard first-order sentence rather than a branching quantifier one, despite the line break. In that case, the problem with that sentence is that ")#mi("y_2")#text(" is allowed to depend on ")#mi("x_1, y_1")#text(" as well as ")#mi("a, x_2")#text("; once you allow that, the clause ")#mi("\\psi(a,x_1,x_2,y_1,y_2)")#text(" is very easy to satisfy even for a model in which ")#mi("\\phi")#text(" is only satisfied at two values, a and b; one just sets ")#mi("y_1")#text(" to always equal b, and ")#mi("y_2")#text(" to equal ")#mi("b")#text(" when ")#mi("x_1=x_2")#text(", and a otherwise.")

#text("It seems that the branching quantifier offers a way to define the concept of a class function ")#mi("x \\mapsto y")#text(" in a manner which can’t be replicated in first order logic, because one needs to assert that equal inputs force equal outputs, and you can’t do this if one of the outputs is allowed to depend on the other input.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87a870e8818dc22b85c392e9f134a7eb1060d7ff08a385cddfa07b027736bbb5-c2243ed8a00fa802a0a7eae6e90a02d7f052a30076be02c30935a6ee420f78cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott McKuen")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8227")[#strong[#text("Scott McKuen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2007")])]

#text("Hi, Terry,")

#text("That was my anonymous bad LaTeX above – yes, no line break intended. Thanks for the example – now it’s clear why the bijection isn’t enforced. Rewriting the thing with Skolem functions helped, too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8253")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("While I find non-firstorderability very interesting, I think it’s the norm rather than the exception, which is why we use set theory rather than first-order models for everything. For example, first-order logic can’t express the Archimedean axiom, or the Riemann hypothesis. Or am I misunderstanding?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8260")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("Dear Walt,")

#text("If you combine first-order logic with a standard set theory such as ZFC, then I agree that you can describe, say, Riemann hypothesis (though I won’t try to write down the actual sentences here, they would be atrociously long), because one can use set theory to model objects such as the zeta function. (The Archimedean axiom seems to me to be expressible in the first-order language of the integers and reals without any need for set theory.) What was surprising, to me at least, was that even with ZFC, statements such as the existence of an integer dimension for each finitely generated vector space do not seem to be easily firstorderisable; set theory doesn’t directly help here because it cannot describe class functions such as ")#mi("\\text{dim}")#text(" unless one performs some trickery to reduce the size of the category of vector spaces to the point where it can be modeled by a set rather than a class.")

#text("As Ori pointed out though, if one uses von Neumann-Bernays-Godel theory instead of ZFC, one can deal with classes and class functions more easily and many of these issues seem to disappear. Since NBG and ZFC are equivalent when restricted to sentences that refer only to sets, the nonfirstorderisability issue is mostly moot, but it still is more subtle than one might naively first imagine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8267")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("I see what you’re getting at. I think the ZFC-ists answer would be to translate it into a collection of statements, parametrized by ordinals, so that for each ordinal a you can state and prove that dim exists for the set V_a in the von Neumann heirarchy. (That’s probably what you mean by “some trickery”.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8287")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("Actually, I think you can basically formalize this in ZFC. You can’t formalize your statement exactly, of course, since it involves branching quantifiers, but you can formalize a statement in ZFC that implies yours. I don’t know much about branching quantifiers, though, so I could be getting this totally wrong.")

#text("Let P(V,n) be the propositional formula that specifies that V is a finite-dimensional vector space, and n is its unique dimension. Then you should be able to prove a statement like: (all V)(exists n)P(V,n) and ( (all V)(exists n)P(V,n) implies Q(V,V’,n,n’) ), where Q is one of your theorems about vector spaces.")

#text("I think you can show this will imply your branching quantifier statement by Skolemization. P(V,n) turns into P(V, n(V)), Q(V,V’,n,n’) would turn into Q(V, V’, n(V, V’), n'(V, V’)), but you can prove by the uniqueness of dimension that n(V,V’) = n(V) and n'(V, V’) = n'(V’). (Though as I said, I don’t know much about branching quantifiers, so this may be more of a parade of my ignorance than anything else.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69efe336c9821201d3ff47fe9dd91c27bf823742bad79841adfde0bc6a6b7432-a4d5c9fae47380411a02040bc257c2db5b940a97abe4dbc7b0d68f1110ef3656.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8354")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")])]

#text("Regarding the first-orderizability of containing arbitrarily long arithmetic progressions…")

#text("Terry’s sentence")#linebreak()#text(" ")#mi("\\forall k>0 : \\exists a,r : ((r \\not=0) \\wedge (\\forall 0 \\leq j \\leq k-1 : a+jr \\in A))")#linebreak()#text(" only captures what we mean by arithmetic progressions in some settings. The first quantifier ")#mi("\\forall k>0")#text(" is inherently referring to the natural numbers, while the other quantifiers ")#mi("\\exists a,r")#text(" are referring to elements of the model. If the only models we’re interested in contain the ring of integers (so that ")#mi("a+jr")#text(" makes the usual sense), then it’s fine.")

#text("The problem with this arises because we talk about arithmetic progressions in general abelian groups. In a group the statement ")#mi("a+jr")#text(" does not make sense. For ")#mi("j=4")#text(", for example, we can replace ")#mi("a+jr")#text(" with ")#mi("a+r+r+r+r")#text(", and so for each particular ")#mi("j")#text(" we can make it make sense. But to make it make sense for all ")#mi("j")#text(", we need to quantify over the natural numbers. By definition “first order” means that we quantify only over elements of the model.")

#text("For example, we all concur precisely on the meaning of “arithmetic progression” in the group of rational points on an elliptic curve. The set ")#mi("A")#text(" contains ")#mi("k")#text(" terms in arithmetic progression (for a natural number k) if ")#mi("\\exists a,r : a\\in A \\wedge a+r \\in A \\wedge \\dots \\wedge a+r+r+\\dots +r \\in A")#text(". For any particular natural number ")#mi("k")#text(", those dots represent finite strings. But without the natural numbers intrinisically available to us, we cannot quantify over ")#mi("k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")])]

#text("Do we ever talk about axiom systems that are modelled by elliptic curves?! I thought an elliptic curve was just another set sitting in ZFC or NBG or NF or whatever. Therefore, normally when we speak of elliptic curves, they are inside our set theory, and the integers are available to us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8370")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2007")])]

#text("Working with axioms systems like “first order theory of [something]s”,")#linebreak()#text(" where [something] could be groups, rings, elliptic curves, etc, is")#linebreak()#text(" definitely something important. I’m not sure about elliptic curves,")#linebreak()#text(" but the first-order theory of rings (and fields, which can be defined")#linebreak()#text(" in this language) has many applications in algebra and number theory.")#linebreak()#text(" The fact that some sets can be defined in such a way can have")#linebreak()#text(" important consequences for applications. This can be thought-of (maybe) as an")#linebreak()#text(" analogue of “smoothness” for functions: not all functions are")#linebreak()#text(" smooth, but if you know that one is, it can be very useful! E.g., the")#linebreak()#text(" unit group of a ring can be defined by ")#mi("\\exists y, xy=1")#text(", but not the")#linebreak()#text(" torsion subgroup of the unit group, because there is no a priori upper")#linebreak()#text(" bound on the order of a torsion unit — note of course if we can")#linebreak()#text(" invoke integers, the torsion subgroup is easy to define…")

#text("As an example of application, using the results of Chatzidakis, van")#linebreak()#text(" den Dries and Macintyre I mentioned in my previous comment on")#linebreak()#text(" definable sets in finite fields (and other logical things I don’t")#linebreak()#text(" understand, including ultrafilters), Hrushovsky and Pillay managed to")#linebreak()#text(" prove the following theorem (Crelle 462, 1995, p. 69–91, Prop. 7.3):")

#text("“Let ")#mi("\\Gamma")#text(" be any Zariski-dense finitely generated subgroup of a")#linebreak()#text(" (almost simple, simply-connected) algebraic group ")#mi("G")#text(" defined over")#linebreak()#text(" ")#mi("\\mathbf{Z}")#text(", for instance ")#mi("G=GL(n)")#text(", or ")#mi("G=SL(n)")#text(" or ")#mi("G=Sp(2g)")#text("; then")#linebreak()#text(" for almost all primes ")#mi("p")#text(", the reduction map ")#mi("\\Gamma\\rightarrow G(\\mathbf{Z}/p\\mathbf{Z})")#text(" is surjective.”")

#text("Notice the statement is purely algebraic and very natural (and")#linebreak()#text(" beautiful). In fact it was proved earlier by Matthews, Vaserstein and")#linebreak()#text(" Weisfeiler, who used the classification of finite simple groups! Even")#linebreak()#text(" for ")#mi("SL(n)")#text(", this is not so obvious to prove by hand, and for a")#linebreak()#text(" Zariski-dense subgroup, which can be a very thin subset, this is")#linebreak()#text(" really deep.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8517")[#strong[#text("Logic games « Forking, Forcing and Back-and-Forthing")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2007")]

#text("[…] a recent post, Terence Tao evokes statements that cannot be formalized in first-order logic. David Corfield has […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2007")])]

#text("Dear Walt,")

#text("Your statement concerning dimension is a first order one as long as you specify what your predicate P(V,n) is – i.e. you give an explicit definition of the concept of dimension. If you don’t actually want to write down this definition, and instead want to assert the abstract existence of a concept of dimension which satisfies various properties, then you need to pass to second-order logic (as you will need a second-order quantifier such as ")#mi("\\exists P")#text(").")

#text("Dear Kevin,")

#text("Thanks for the clarification. I guess the moral is that statements involving integers can require the integers to be part of the language in order to express them in first-order logic; similarly statements involving sets or functions may require set theory to be firstorderisable; and statements involving class functions may require a language that can express the concept of a class, such as NBG.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5d4c911dc5d51f8757b4d7fabe43d6a281a9a6bd8676cbf103455279e6eb16b-f6ae0d95065b59d202ee27117b9cf1548584a76ec9210f3d3b50091720258f64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8678")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("The definition of firstorderizability, as far as I understand it, is that a sentence in a theory is firstorderizable if its truth value (as you range over models of the theory) is the same as a first-order sentence. While your sentence requires second-order logic to express, its truth value over models of ZFC is the same as the sentence using the explicit definition. In that sense, your sentence is firstorderizable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8680")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("Dear Walt,")

#text("Technically you are correct, but by this definition any statement that one can actually prove in ZFC becomes firstorderizable for trivial reasons, because it has the same truth value as a tautology such as 0=0. But one can easily tweak the sentence to avoid this, by replacing the question “do vector spaces have a unique notion of dimension?” to “does a [insert vector-space like object here] have a unique notion of dimension?”, where we view the concept of a vector-space like object as a primitive. For instance, one could imagine that one has a class of vector-space-like objects which form an abelian category with a distinguished “one-dimensional” object (the analogue of ")#mi("{\\Bbb R}")#text(" in the actual vector space example), and one can ask whether this class has a notion of dimension which obeys all the properties listed above (replacing surjections by epimorphisms, replacing ")#mi("{\\Bbb R}")#text(" by the distinguished one-dimensional object, and so forth). If we model this class of objects by a unary predicate (e.g. Vec(V) is the statement that V is a vector-space-like object), then the question “Does the class Vec have a unique notion of dimension?” becomes a statement which I believe is not firstorderisable in ZFC, though I might be wrong on this if there is a sufficiently canonical way to define dimension which works for all abelian categories that admit such a notion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5d4c911dc5d51f8757b4d7fabe43d6a281a9a6bd8676cbf103455279e6eb16b-f6ae0d95065b59d202ee27117b9cf1548584a76ec9210f3d3b50091720258f64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walt")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-8696")[#strong[#text("Walt")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("I’m only trying to be technically correct. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1417d03ff8ddc1d9acad1b072c41bf4cdd53e443eba39418186857a5c437fba6-201d5bcc7f107bc973301fdc85d2365ba79700d5e1e9e798a9bcad9ff7b0717e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Chow")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-45269")[#strong[#text("Timothy Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2010")])]

#text("It may be worth mentioning that the inability of ZFC to talk about proper classes directly is not as serious a handicap as it might seem at first glance. The standard dodge, as explained for example in Kunen’s book on set theory, is to use formulas to represent (definable) classes. Thus we can’t talk about the class of all vector spaces directly, but we can write down a formula that expresses “x is a vector space” and for almost all purposes this formula serves as a perfectly fine surrogate for the class of all vector spaces. For example, the dimension “function” is most intuitively thought of as a map from the class of all vector spaces to the natural numbers, or in other words as a class of ordered pairs (V,d) where V is a vector space and d is a natural numbers. Though this is a proper class and can’t be “talked about directly” in the first-order language of set theory, we can write down a formula that expresses “d is the cardinality of a basis for V” and use this formula whenever we want to say something about the dimension “function.”")

#text("If using formulas as surrogates for classes gets too cumbersome, then another trick is to use a set ")#mi("V_\\kappa")#text(", where ")#mi("\\kappa")#text(" is a strongly inaccessible cardinal, as a surrogate for the class of all sets. ")#mi("V_\\kappa")#text(" is a model for ZFC, so for any fact about the set-theoretic universe that you might want to prove using the ZFC axioms, there is a corresponding fact about ")#mi("V_\\kappa")#text(". The point is that ")#mi("V_\\kappa")#text(" is something you can talk about directly since it’s a set. So by pretending that ")#mi("V_\\kappa")#text(" is the class of all sets, you can take all the things you want to say about classes and formalize them as statements about sets in ")#mi("V_\\kappa")#text(". This can all be done in ZFC + “there exists a strongly inaccessible cardinal” (or maybe a slightly stronger large cardinal axiom if you are doing some really fancy reasoning with classes). Strictly speaking you’re not really talking about proper classes but about all sets in ")#mi("V_\\kappa")#text(", but since ")#mi("V_\\kappa")#text(" is a model of ZFC, this is typically good enough.")

#text("These kinds of tricks demonstrate why a system like Mizar, which is based on ZFC + a large cardinal axiom, is expected to be powerful enough to formalize any mathematical proof we might care to encode in it. If Mizar couldn’t even formalize the dimension of a vector space then clearly it wouldn’t be sufficient to formalize all of mathematics!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadim Tropashko")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-50073")[#strong[#text("Vadim Tropashko")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2011")])]

#text("Why [formal] conjunction of")

#text("“For every x and x’, there exists a y depending only on x and a y’ depending on x and x’ such that Q(x,x’,y,y’) is true”")

#text("with")

#text("“For every x and x’, there exists a y depending on x and x’ and a y’ depending only on x’ such that Q(x,x’,y,y’) is true”")

#text("isn’t equivalent to")

#text("“For every x and x’, there exists a y depending only on x and a y’ depending only on x’ such that Q(x,x’,y,y’) is true (*)”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-50074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2011")])]

#text("Because the y and y’ in the first sentence need not match up with the y and y’ in the second sentence.")

#text("An explicit counterexample is given by the predicate")

#text("Q(x,x’,y,y’) = ” ")#mi("y = y^{\\prime} \\in \\{x,x^{\\prime}\\}")#text(" “.")

#text("For this choice of predicate, the first and second of your sentences are true, but the third sentence is false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f499b319ec5a1490397be4b9dead1e9bcb68452b1b6dc6b8f5bc247721b8b39e-7708429fb69c340451d010ec7ae6c72333ce2c9ed9ae11aa42c4ae2ff15edcb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadim Tropashko")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-50075")[#strong[#text("Vadim Tropashko")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2011")])]

#text("All three statements are propositions which are closed formulas involving quaternary predicate Q(_,_,_,_), so my intuition fail to see why variables should match.")

#text("In your counter example can you please add parenthesis: is it set membership relation equal to y, or binary identity relation y=y’ being member of a set with two elements? (In second interpretation it is symmetric with respect to y and y’)")

#text("Perhaps you have meant ” y = y’ \\wedge y’ \\in \\{x,x’\\} “? Still this predicate is symmetric with regards to y and y’.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-50085")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2011")])]

#text("Yes, in my counterexample, Q(x,x’,y,y’) is the assertion that ")#mi("y=y^{\\prime}")#text(" and that ")#mi("y^{\\prime} \\in \\{x,x^{\\prime}\\}")#text(", and is thus symmetric in y and y’. Equivalently, Q(x,x’,y,y’) is the assertion that either ")#mi("y=y^{\\prime}=x")#text(" or ")#mi("y=y^{\\prime}=x^{\\prime}")#text(".")

#text("Perhaps it will be easier to understand the distinction between the three sentences by adopting a game-theoretic approach. Consider the following (cooperative) game involving two players. The first player is of age x, and the second player is of age x’. In the game, the first player writes down a number y, and the second player writes down a number y’, and then both numbers are revealed. The players win the game if")

#text("(a) the two numbers are the same; AND")#linebreak()#text(" (b) this number is either equal to the age x of the first player, or the age x’ of the second player.")

#text("Initially, both players know their own age, but not the age of the other player.")#linebreak()#text(" The players are allowed to discuss strategy beforehand, but there are three variants of the game, depending on what information can be shared:")

#text("Variant 1: the second player may learn the age x of the first player, but the first player may not learn the age x’ of the second player (i.e. the first player can only use x).")#linebreak()#text(" Variant 2: the first player may learn the age x’ of the second player, but the second player may not learn the age x of the first player (i.e. the second player can only use x’).")#linebreak()#text(" Variant 3: neither player may learn the age of the other (i.e. the first player can only use x, and the second player can only use x’).")

#text("It is easy to always win Variant 1: both players write down the number x (which they both know).")

#text("It is easy to always win Variant 2: both players write down the number x’ (which they both know).")

#text("However, it is not possible in general to win Variant 3, because they do not both know x and they do not both know x’, and so cannot find a strategy that obeys both (a) and (b).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f499b319ec5a1490397be4b9dead1e9bcb68452b1b6dc6b8f5bc247721b8b39e-7708429fb69c340451d010ec7ae6c72333ce2c9ed9ae11aa42c4ae2ff15edcb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadim Tropashko")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-50126")[#strong[#text("Vadim Tropashko")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2011")])]

#text("OK, let [grudgingly] admit branching quantifier exists:-) Is the expression")

#text("all x exists y all xx exists yy R(x,xx,y,yy)")#linebreak()#text(" &")#linebreak()#text(" all xx exists yy all x exists y R(x,xx,y,yy)")

#text("stronger or weaker than")

#text("Q_H(x,xx,y,yy) R(x,xx,y,yy)")

#text("? Next, your counter example actually satisfies stronger assertions")

#text("all x exists y exists yy all xx Q(x,xx,y,yy)")

#text("and")

#text("all xx exists y exists yy all x Q(x,xx,y,yy)")

#text("Is this expressible via FOL + Henkin’s quantifier?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a12b12f98bf6e01f6f75bc5769b306d1d689b0cdec7bba1c40cd29367ce55b8e-fde133828543cce4b11ba751302f11df57e617d2bd2d2133289fd1aa64f2636c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Mann")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-117259")[#strong[#text("Allen Mann")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("Dear Professor Tao,")

#text("In your second reply to Vadim (on 5 February 2011) you explain the semantics of a branching quantifier sentence by interpreting the individual quantifiers (")#mi("\\forall x")#text(", ")#mi("\\exists y")#text(") as moves in a two-player game. This is the essential insight that led Hintikka and Sandu to develop game-theoretic semantics.")

#text("The semantic game for a first-order sentence is a contest between two players. The existential player (Eloise) tries to verify the sentence by choosing the values of existentially quantified variables, while the universal player (Abelard) tries to falsify it by picking the values of universally quantified variables. Disjunctions prompt the verifier to choose which disjunct she wishes to verify; conjunctions prompt the falsifier to pick which conjunct he wishes to falsify. Negation tells the players to switch roles. (To verify ")#mi("\\neg\\varphi")#text(", one must falsify ")#mi("\\varphi")#text(".)")

#text("Notice that, in your example, first two variants of the game are essentially games with perfect information, while the third variant is a game with imperfect information.")

#text("First-order logic with imperfect information is an extension of first-order logic that explicitly allows semantic games with imperfect information. There many syntactic devices one can use to indicate what information is available to the players. In independence-friendly (IF) logic, one adds a “slash set” to each quantifier that contains all of the previously quantified variables from which the quantifier is independent. For example, the fact that the universe has infinitely many elements can be expressed by the IF sentence")

#mi("\\exists w \\forall x \\big{\\left( y / \\{w\\} \\right)} \\big{\\left( \\exists z/ \\{w,x\\} \\right)} [ z = x \\land y \\not= w ] \\qquad (*)")

#text("the Skolemization of which is")

#mi("\\forall x \\Big{\\left[ g \\big{\\left( f(x) \\right)} = x \\land f(x) \\not= c \\right]}  where")#text("latex c$ is a constant. The Skolemization is satisfiable if and only if the universe admits a non-surjective injection (i.e., the universe is Dedekind infinite).")

#text("Gabriel Sandu, Merlijn Sevenster, and I have recently published a book, ")#link("http://www.amazon.com/Independence-Friendly-Logic-Game-Theoretic-Approach-Mathematical/dp/0521149347/ref=sr_1_1?s=books&ie=UTF8&qid=1324406416&sr=1-1")[#text("Independence-Friendly Logic")]#text(", that emphasizes the game-theoretic approach to logic, including first-order logic with imperfect information.")

#link("http://www.amazon.com/Dependence-Logic-Approach-Independence-Mathematical/dp/0521700159")[#text("Dependence logic")]#text(" is another approach to logic with imperfect information. Instead of “slashing” each quantifier, dependencies between variables are indicated using new atomic formulas called dependence atoms. For example, the dependence atom ")#mi("=(x_{1}, \\dots, x_{n}, y)")#text(" asserts that the value of the variable ")#mi("y")#text(" depends on (only) the values of $\\latex x_{1}, \\ldots, x_{n}$. The sentence ")#mi("(*)")#text(" can be expressed in dependence logic as")

#mi("\\exists w \\forall x \\exists y \\exists z \\big{\\left[ z = x \\land y \\not= w \\land =(x,y) \\land =(y,z) \\right]}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a12b12f98bf6e01f6f75bc5769b306d1d689b0cdec7bba1c40cd29367ce55b8e-fde133828543cce4b11ba751302f11df57e617d2bd2d2133289fd1aa64f2636c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Mann")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-117260")[#strong[#text("Allen Mann")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("CORRECTION. The variable ")#mi("y")#text(" in the sentence ")#mi("(*)")#text(" above should be existentially quantified:")

#mi("\\exists w \\forall x \\big{\\left(\\exists y / \\{w\\} \\right)} \\big{\\left( \\exists z/ \\{w,x\\} \\right)} [ z = x \\land y \\not= w ] \\qquad (*)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d264c88a53f24b7d44e27ebe147d6d0f4ec6614e2eea0ad3cac75fb0f3ffa080-d906a88bbf86db49eea5fb75b63d5f2eb425bbfb29cec71af26cd27e22b86a4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ivvrrzc")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121700")[#strong[#text("ivvrrzc")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("I guess, the original (*) sentence can be 1st order deciphered as follows: \\forall x \\exists y \\forall x_0 \\exists y_0 \\forall x’ \\exists y’ [O(x,x’,y,y’) \\and Q(x_0,x’,y_0,y’)]. Of course, I agree with the aouthor that “plain old mathematical English,” i.e. expanding the language by the exactly intended two functions, is the best.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121707")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("Unfortunately, this sentence is not equivalent to (*). If, for instance, all variables are quantified over a set with at least three elements, and ")#mi("Q(x,x^{\\prime},y,y^{\\prime})")#text(" is the assertion that ")#mi("y^{\\prime} \\neq x")#text(", then (*) is false, but the statement you write is true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("I think, “\\forall x \\exists y \\forall x_0 \\exists y_0 \\forall x’ \\exists y’ [O(x,x’,y,y’) is true and is equivalent to Q(x_0,x’,y_0,y’)]” gives the correct semantics of (*).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121716")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("Again, the counterexample I mentioned previously (in which ")#mi("Q(x,x^{\\prime},y,y^{\\prime})")#text(" is the assertion that ")#mi("y^{\\prime} \\neq x")#text(") demonstrates that this is not the case. It is clear that (*) is not true for this choice of Q (since y’, which depends only on x’, cannot avoid every value of x), but your statement is true. (For each x, choose y=x; for each x_0, choose y_0=x_0; and for each x’, choose y’ to be an element that is not equal to either x or x_0. Then Q(x,x’,y,y’) and Q(x_0,x’,y_0,y’) are both true and thus also equivalent to each other.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2012")])]

#text("Dear Professor Tao, first of all, thank you for your")#linebreak()#text(" patience and teaching me more sophistication.")#linebreak()#text(" Now, is writing “\\forall x")#linebreak()#text(" \\exists y \\forall x’ \\exists y’ \\forall x_0 [O(x,x’,y,y’)")#linebreak()#text(" \\and (O(x,x’,y,y’) \\implies Q(x_0,x’,y,y’))] ”")#linebreak()#text(" satisfactory?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121891")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2012")])]

#text("Sorry, or rather: “\\forall x \\exists y \\forall x’ \\exists y’ \\forall x_0 \\exists y_0 [O(x,x’,y,y’) \\and (O(x,x’,y,y’) \\implies Q(x_0,x’,y_0,y’))]. “")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-121730")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2012")])]

#text("Just a little note: you parenthetically mentioned that “the only order-preserving field automorphism of the reals is the identity”. In fact you don’t need to assume order-preservation: it’s a consequence!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-156641")[#strong[#text("Nieludzka logika… « FIKSACJE")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2012")]

#text("[…] Nonfirstorderizability – zjawisko polegające na tym, że pewne wyrażenia logiczne nie dają się zapisać jako zdania w logice pierwszego rzędu. Nic w tym dziwnego, takich stwierdzeń jest bardzo dużo, niektóre całkiem “proste” jak np. “przestrzeń wektorowa skończonego wymiaru”, lub “zbiór o skończone liczbie elementów”. Okazuje się, że istnieje jednak podejście nazywane Branching które ogólnie polega na porzuceniu liniowego następstwa kwantyfikatorów ogólnych ( “dla każdego” …) i wprowadzeniu dodatkowej konwencji że mogą być one używane “jednocześnie”, lub “atomowo w grupie”. Po wprowadzeniu takiej modyfikacji uzyskujemy logikę która nadal jest słabsza niz logika drugiego rzędu ( a więc nie ma kwantyfikacji po zdaniach) jednak jest mocniejsza niż logika pierwszego rzędu. W szczególności pozwala na wyrażanie stwierdzeń o prawdziwej niezależności dwu i więcej zmiennych ( proszę porównać: ")#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/")[#text("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/")]#text(") […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-472808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("Dear Terry! I am certainly a latecomer to this discussion, but thank you for sharing the idea of nonfirstorderisability, it’s very interesting! :-)")

#text("Just a little question: You write:")

#text("“Moving on to a more complicated example, if Q(x,x’,y,y’) is a quaternary relation on four objects x,x’,y,y’, then we can express the statement")

#text("For every x and x’, there exists a y depending only on x and a y’ depending on x and x’ such that Q(x,x’,y,y’) is true")

#text("as")

#mi("\\forall x \\exists y \\forall x^{\\prime} \\exists y^{\\prime}: Q(x,x^{\\prime},y,y^{\\prime})")

#text("(note that this allows y’ to depend on y also, but this turns out to be moot, because y depends only on x)”")

#text("I don’t understand your last comment within the parantheses. Is it even possible for a variable to depend on a variable that is bound by an *existential* quantifier? I always thought that existential variables are the only type of variable that can depend on another variable and that these existential variables can only depend on universal variables. (“Existential variable” means “variable bound by an existential quantfier”, similarly “universal variable”)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-472809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("One can ")#link("https://en.wikipedia.org/wiki/Skolem_normal_form")[#text("Skolemize")]#text(" a first-order logic sentence either by replacing the existential variables with functions of all preceding universal variables, or by replacing them with all preceding variables including the existential ones, but the latter replacement adds no additional generality since, as noted in the text, the existential variables included would in turn be dependent on prior universal variables.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-473229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2016")])]

#text("Dear Prof. Tao,")#linebreak()#text(" 1. I’m not familiar with the terminology “a variable depends on another variable”. Where can one read the definition of this concept? (Since you said that one uses them in Analysis: can one find them in an introduction to analysis?)")

#text("2. Also, I’m a little confused reading the thread")#linebreak()#text(" ")#link("http://mathoverflow.net/questions/118254/usage-of-set-theory-in-undergraduate-studies/118261")[#text("http://mathoverflow.net/questions/118254/usage-of-set-theory-in-undergraduate-studies/118261")]#linebreak()#text(" where Andrej Bauer points out:")#linebreak()#text(" “We should never say that one variable depends on another.”")#linebreak()#text(" Whom should I believe?")

#text("3. When you for example say")#linebreak()#text(" “For every x and x’, there exists a y depending only on x and a y’ depending only on x’ such that Q(x,x’,y,y’) is true”,")#linebreak()#text(" do you mean the second-order sentence that says")#linebreak()#text(" “There is are functions f and f’ such that for any x and x’, Q(x, x’, f(x), f(x’))”")#linebreak()#text(" ?")

#text("4. How can one prove that if a variable y depends only on a variable x, and the variable z only depends on x, that then z depends only on x?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-473233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2016")])]

#text("In the strict sense, Andrej is correct: variables in a first-order sentence are not functions of other variables. However, when one converts such a first-order sentence to an equivalent (or more precisely, ")#link("https://en.wikipedia.org/wiki/Equisatisfiable")[#text("equisatisfiable")]#text(") ")#link("https://en.wikipedia.org/wiki/Skolem_normal_form")[#text("Skolem normal form")]#text(", the existential variables become functions of preceding variables (and depending on how one carries out this form, the function either only involves preceding universal variables, or can be a function of both the preceding universal and existential variables, with the latter in turn being functions of further variables).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-473237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2016")])]

#text("Thanks!")

#text("What about questions 3 and 4?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-473777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2016")])]

#text("Dear Terry,")

#text("I think that the problem with first-order logic you describe is really Russell’s paradox in disguise. That the statement about dimensions and vector spaces is not formalizable in FOL + ZFC is due to the fact that in ZFC, one cannot speak about proper classes (and thus also not about proper class functions). But also a class theory like Morse-Kelley can’t express every mathematically meaningful statement, like statements about metaclasses (that is, arbitrary collections of classes). As Gödel pointed out in his famous paper “Über formal unentscheidbare Sätze der Principia Mathematica und verwandter Systeme 1”:")

#text("“The true source of the incompleteness attaching to all formal systems of mathematics, is to be found — as will be shown in Part II of this essay — in the fact that the formation of ever higher types can be continued into the transfinite (cf. D. Hilbert ‘Über das Unendliche’, Math. Ann. 95, p. 184), whereas in every formal system at most denumerably many types occur. It can be shown, that is, that the undecidable propositions here presented always become decidable by the adjunction of suitable higher types (e.g. of type ω for the system P). A similar result also holds for the axiom system of set theory.”")

#text("So one can always add another stage to the ontology of a formal system.")

#text("Also, a logic that can express dependence relations between variables has been developed by Hintikka. See ")#link("https://en.wikipedia.org/wiki/Independence-friendly_logic")[#text("https://en.wikipedia.org/wiki/Independence-friendly_logic")]

#text("“Hintikka’s proposal that IF logic and its extended version be used as foundations of mathematics has been met with skepticism by other mathematicians, including Väänänen and Solomon Feferman.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-474656")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("You say “I can’t quite show that (*) is not expressible in first-order logic”. And (*) is this statement:")

#text("For every x and x’, there exists a y depending only on x and a y’ depending only on x’ such that Q(x,x’,y,y’) is true (*)")

#text("How can one formally define/express things like “(*) is not expressible in first-order logic”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56f6b5188f504ee2aee7d99e312baeb0a7041eaef7bbd38447fe273c9d802fc5-0cb7e04d8a0a780eb5d92c000facb784fadb499679c4da0bb3bbf3d7b413566c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bowen Chen")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-685646")[#strong[#text("Bowen Chen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2024")])]

#text("First, we can define (*) in second order logic, as the dependency of y on x can be expressed as the existence of function y=f(x).")

#text("Then, “(*) is not expressible in first-order logic”, is to say there is no first order formula with {Q} being its vocabulary that is equivalent to the second order formula defined previously.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-614692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2021")])]

#emph[#text(" This phenomenon is very well known among logicians, but I hadn’t learned about it until very recently, and had naively assumed that first order logic sufficed for “everyday” usage of mathematics.")#linebreak()#text(" ")]

#text("Can one now say that second-order logic is sufficient for “everyday” usage of mathematics, particularly analysis?")

#text("Are there examples in analysis that one actually needs the power of a higher order logic (than second order)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/27/printer-friendly-css-and-nonfirstorderizability/#comment-614717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2021")])]

#text("The order of logic used in a formal argument is not actually all that good of a proxy for the “power” of that argument. Most instances of second-order (or higher-order) logic involving basic mathematical objects such as numbers, for instance, can be replicated quite faithfully as first-order logic in a set theory such as ZFC, which can encode not only numbers but sets of numbers, functions from numbers to other numbers, and so forth. And then there are arguments that go outside of a single formal logical system (first-order, second-order, or whatever) and invoke metamathematical arguments; for instance in nonstandard analysis one often appeals to the metamathematical transfer principle (Los’s theorem) to convert a first-order theorem in standard analysis to its nonstandard counterpart. Again, one can usually formalise this sort of maneuver within first-order ZFC if desired. So I would say that for analysis first-order ZFC is usually more than sufficient as a formal structure to model one’s arguments, although one is not necessarily confined to this structure if one prefers to work in some other formal structure (or to reason less formally).")

#text("Outside of analysis, one sometimes has to manipulate very large categories, in which case it is sometimes convenient to work with Grothendieck universes or similar objects which can’t quite be constructed purely within first-order ZFC. My understanding though is that in practice these universes are more convenient technicalities than essential components to the arguments.")
]
]
