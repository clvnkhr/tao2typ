// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/
// Converted to Typst by tao2typ: "2026-10-14T06:52:59.367659+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Milliman Lecture III: Sum-product estimates, expanders, and exponential sums", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Milliman Lecture III: Sum-product estimates, expanders, and exponential sums")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/")[#text("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is my ")#link("http://www.math.washington.edu/Seminars/milliman_0708.php")[#text("final Milliman lecture")]#text(", in which I talk about the sum-product phenomenon in arithmetic combinatorics, and some selected recent applications of this phenomenon to uniform distribution of exponentials, ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander graphs")]#text(", ")#link("http://en.wikipedia.org/wiki/Extractor")[#text("randomness extractors")]#text(", and detecting (")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieving")]#text(") ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost primes")]#text(" in group orbits, particularly as developed by Bourgain and his co-authors.")#linebreak()#text(" ")#metadata(none) <tao-f0e50d91a880894ba377>#text("In the previous two lectures we had concentrated on ")#emph[#text("additive combinatorics")]#text(" – the study of additive operations and patterns on sets. Now we will look at ")#emph[#text("arithmetic combinatorics")]#text(" – the simultaneous study of additive ")#emph[#text("and")]#text(" multiplicative operations on sets; this is sort of a combinatorial analogue of ")#link("http://en.wikipedia.org/wiki/Commutative_algebra")[#text("commutative algebra")]#text(".")

#text("There are many questions to study here, but the most basic is the sum-product problem, which we can state as follows. Let A be a finite non-empty set of elements of a ring R (e.g. finite sets of integers, or elements of a cyclic group ")#mi("{\\Bbb Z}/q{\\Bbb Z}")#text(", or sets of matrices over some ring). Then we can form the ")#emph[#text("sum set")]

#align(center)[#tao-fit-display[#mitex("A+A := \\{ a + b: a, b \\in A \\}")]]

#text("and the ")#emph[#text("product set")]

#align(center)[#tao-fit-display[#mitex("A \\cdot A := \\{ a \\cdot b: a, b \\in A \\}")]]

#text("To avoid degeneracies, let us assume that none (or very few) of the elements in A are ")#link("http://en.wikipedia.org/wiki/Zero_divisor")[#text("zero divisors")]#text(" (as this may cause ")#mi("A \\cdot A")#text(" to become very small). Then it is easy to see that ")#mi("A+A")#text(" and ")#mi("A \\cdot A")#text(" will be at least as large as A itself.")

#text("Typically, both of these sets will be much larger than A itself, indeed, if we select A at random, we generically expect ")#mi("A+A")#text(" and ")#mi("A \\cdot A")#text(" to have cardinality comparable to ")#tao-math("\\left|A\\right|^2", block: false)#text(". But when A enjoys additive or multiplicative structure, the sets ")#mi("A+A")#text(" or ")#mi("A \\cdot A")#text(" can be of size comparable to A. For instance, if A is an arithmetic progression ")#mi("\\{a, a+r, a+2r, \\ldots, a+(k-1)r\\}")#text(" or an additive subgroup in the ring R (modulo zero divisors, such as 0), then ")#tao-math("\\left|A+A\\right| \\sim \\left|A\\right|", block: false)#text(". Similarly, if A is a geometric progression ")#mi("\\{a, ar, ar^2, \\ldots, ar^{k-1} \\}")#text(" or a multiplicative subgroup in the ring R, then ")#tao-math("\\left|A \\cdot A\\right| \\sim \\left|A\\right|", block: false)#text(". And of course, if A is both an additive and a multiplicative subgroup of R (modulo zero divisors), i.e. if A is a subring of R, then ")#tao-math("\\left|A+A\\right|", block: false)#text(" and ")#tao-math("\\left|A \\cdot A\\right|", block: false)#text(" are both comparable in size to |A|. These examples are robust with respect to small perturbations; for instance, if A is a dense subset of an arithmetic progression or additive subgroup, then it is still the case that ")#mi("A+A")#text(" is comparable in size to A. There are also slightly more complicated examples of interest, such as ")#link("http://en.wikipedia.org/wiki/Generalized_arithmetic_progression")[#text("generalised arithmetic progressions")]#text(", but we will not discuss these here.")

#text("Now let us work in the ring of integers ")#mi("{\\Bbb Z}")#text(". This ring has no non-trivial finite additive subgroups or multiplicative subgroups (and it certainly has no non-trivial finite subrings), but it of course has plenty of arithmetic progressions and geometric progressions. But observe that it is rather difficult for a finite set A of integers to resemble both an arithmetic progression and a geometric progression simultaneously (unless A is very small). So one expects at least one of ")#mi("A+A")#text(" and ")#mi("A \\cdot A")#text(" to be significantly larger than A itself. This claim was made precise ")#link("http://www.ams.org/mathscinet-getitem?mr=820223")[#text("by Erdős and Szemerédi")]#text(", who showed that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\max( \\left|A+A\\right|, \\left|A \\cdot A\\right| ) \\gg \\left|A\\right|^{1+\\varepsilon}", block: true)]]

#text("for some absolute constant ")#mi("\\varepsilon > 0")#text(". The value of this constant as improved steadily over the years; the best result currently is due ")#link("http://www.ams.org/mathscinet-getitem?mr=2212132")[#text("to Solymosi")]#text(", who showed that one can take ")#mi("\\varepsilon")#text(" arbitrarily close to 3/11. Erdős and Szemerédi in fact conjectured that one can take ")#mi("\\varepsilon")#text(" arbitrarily close to 1 (i.e. for any finite set of integers A, either the sum set or product set has to be very close to its maximal size of ")#tao-math("\\left|A\\right|^2", block: false)#text("), but this conjecture seems out of reach at present. Nevertheless, even just the epsilon improvement over the trivial bound of |A| is actually quite useful. It is the first example of what is now called the sum-product phenomenon: if a finite set A is not close to an actual subring, then either the sum set ")#mi("A+A")#text(" or the product set ")#mi("A \\cdot A")#text(" must be significantly larger than A itself. One can view (1) as a “robust” version of the assertion that the integers contain no non-trivial finite subrings; (1) is asserting that in fact the integers contain no non-trivial finite sets which even come close to behaving like a subring.")

#text("In 1999, Tom Wolff posed the question of whether the sum-product phenomenon held true in finite fields ")#mi("{\\Bbb F}_p")#text(" of prime order (note that such fields have no non-trivial subrings), and in particular whether (1) was true when ")#mi("A \\subset {\\Bbb F}_p")#text(", and A was not close to being all of ")#mi("{\\Bbb F}_p")#text(", in the sense that ")#tao-math("\\left|A\\right| \\leq p^{1-\\delta}", block: false)#text(" for some ")#mi("\\delta > 0")#text("; of course one would need ")#mi("\\varepsilon")#text(" to depend on ")#mi("\\delta")#text(". (Actually, Tom only posed the question for ")#tao-math("\\left|A\\right| \\sim p^{1/2}", block: false)#text(", being motivated by finite field analogues of the Kakeya problem, but the question was clearly of interest for other ranges of A as well.) This question was solved in the affirmative ")#link("http://front.math.ucdavis.edu/math.CO/0301343")[#text("by Bourgain, Katz, and myself")]#text(" (in the range ")#tao-math("p^\\delta \\leq \\left|A\\right| \\leq p^{1-\\delta}", block: false)#text(") and then ")#link("http://arxiv.org/abs/math/0304217")[#text("by Bourgain, Glibichuk, and Konyagin")]#text(" (in the full range ")#tao-math("1 \\leq \\left|A\\right| \\leq p^{1-\\delta}", block: false)#text("); the result is now known as the ")#emph[#text("sum-product theorem")]#text(" for ")#mi("{\\Bbb F}_p")#text(" (and there have since been several further proofs and refinements of this theorem). The fact that the field has prime order is key; if for instance we were working in a field of order ")#mi("p^2")#text(", then by taking A to be the subfield of order p we see that both ")#mi("A+A")#text(" and ")#mi("A \\cdot A")#text(" have exactly the same size as A. So any proof of the sum-product theorem must use at some point the fact that the field has prime order.")

#text("As in the integers, one can view the sum-product theorem as a robust assertion of the obvious statement that the field ")#mi("{\\Bbb F}_p")#text(" contains no non-trivial subrings. So the main difficulty in the proof is to find a proof of this latter fact which is robust enough to generalise to this combinatorial setting. The standard way to classify subrings is to use ")#link("http://en.wikipedia.org/wiki/Lagrange%27s_theorem_%28group_theory%29")[#text("Lagrange’s theorem")]#text(" that the order of a subgroup divides the order of the whole group, which is proven by partitioning the whole group into cosets of the subgroup, but this argument is very unstable and does not extend to the combinatorial setting. But there are other ways to proceed. The argument of Bourgain, Katz, and myself (which is based on an earlier argument ")#link("http://www.ams.org/mathscinet-getitem?mr=1948103")[#text("of Edgar and Miller")]#text("), roughly speaking, proceeds by investigating the “dimension” of ")#mi("{\\Bbb F}_p")#text(" relative to A, or in other words the least number of elements ")#mi("v_1, \\ldots, v_d")#text(" in ")#mi("{\\Bbb F}_p")#text(" such that every element of ")#mi("{\\Bbb F}")#text(" can be expressed in the form ")#mi("a_1 v_1 + \\ldots + a_d v_d")#text(". Note that the number of such representations is equal to ")#tao-math("\\left|A\\right|^d", block: false)#text(". The key observation is that as ")#tao-math("\\left|{\\Bbb F}_p\\right|", block: false)#text(" is prime, it cannot equal ")#tao-math("\\left|A\\right|^d", block: false)#text(" if ")#mi("d > 1")#text(", and so by the pigeonhole principle some element must have more than one representation. One can use this “linear dependence” to reduce the dimension by 1 (assuming that A behaves a lot like a subring), and so can eventually reduce to the d=1 case, which is prohibited by our assumption ")#mi("A < p^{1-\\delta}")#text(". (The hypothesis ")#tao-math("\\left|A\\right| > p^{\\delta}", block: false)#text(" is needed to ensure that the initial dimension d is bounded, so that the iteration only requires a bounded number of steps.) The argument of Bourgain, Glibichuk, and Konyagin uses a more algebraic method (a variant of the polynomial method of Stepanov), using the basic observation that the number of zeroes of a polynomial (counting multiplicity) is bounded by the degree of that polynomial to obtain upper bounds for various sets (such as the number of parallelograms in A). More recently, a ")#link("http://arxiv.org/abs/math/0702780")[#text("short argument of Garaev")]#text(" proceeds using the simple observation that if A is any non-trivial subset of ")#mi("{\\Bbb F}_p")#text(", then there must exist ")#mi("a \\in A")#text(" such that ")#mi("a+1 \\not \\in A")#text("; applying this to the “fraction field” ")#mi("Q[A] := \\{ (a-b)/(c-d): a,b,c,d \\in A, c \\neq d \\}")#text(" of A one can conclude that Q[A] does not in fact behave like a field, and hence A does not behave like a ring.")

#text("The sum-product phenomenon implies that if a set ")#mi("A \\subset {\\Bbb F}_p")#text(" of medium size ")#tao-math("p^\\delta \\leq \\left|A\\right| \\leq p^{1-\\delta}", block: false)#text(" is multiplicatively structured (e.g. it is a geometric progression or a multiplicative subgroup) then it cannot be additively structured: ")#mi("A+A")#text(" is significantly larger than A. It turns out that with a little bit of extra work, this observation can be iterated: A+A+A+A is even larger than A, and so on and so forth, and in fact one can show that ")#mi("kA = {\\Bbb F}_p")#text(" for some bounded k depending only on ")#mi("\\delta")#text(", where ")#mi("kA := A + \\ldots + A")#text(" is the k-fold sumset of A. (The key to this iteration essentially lies in the inclusion ")#mi("(kA) \\cdot (kA) \\subset k^2 (A^2)")#text(", which is a consequence of the ")#link("http://en.wikipedia.org/wiki/Distributive_law")[#text("distributive law")]#text(". The use of this law unfortunately breaks the symmetry between multiplication and addition that one sees in the sum-product estimates.) Thus any multiplicatively structured subset A of ")#mi("{\\Bbb F}_p")#text(" of medium size must eventually additively generate the whole field. As a consequence of this, one can show that A is an additive expander, which roughly speaking means that ")#mi("A+B")#text(" is spread out on a significantly larger set than B for any medium-sized set B. (In more probabilistic language, if one considered the random walk whose steps were drawn randomly from A, then this walk would converge extremely rapidly to the uniform distribution.) From that observation (and some more combinatorial effort), one can in fact conclude that multiplicatively structured sets must be distributed uniformly in an additive sense; if they concentrated too much in, say, a subinterval of ")#mi("{\\Bbb F}_p")#text(", then this could be used to contradict the additive expansion property.")

#text("Let me note one cute application of this technology, due to Bourgain, to the ")#link("http://en.wikipedia.org/wiki/Diffie-Hellman_key_exchange")[#text("Diffie-Hellman key exchange protocol")]#text(" and its relatives in cryptography. Suppose we have two people, Alice and Bob, who want to communicate privately and securely, but have never met each other before and can only contact each other via an unsecured network (e.g. the internet, or physical mail), in which anyone can eavesdrop. How can Alice and Bob achieve this?")

#text("If one was sending a physical object (e.g. a physical letter) by physical mail (which could be opened by third parties), one could proceed as follows.")

#enum(start: 1, 
[#text("Alice places the object in a box, and locks the box with her own padlock, keeping the key. She then mails the locked box to Bob. Anyone who intercepts the box cannot open it, since they don’t have Alice’s key.")],
[#text("Of course, Bob can’t open the box either. But what he can do instead is put his own padlock on the box (keeping the key), and sends the doubly locked box back to Alice.")],
[#text("Alice can’t unlock Bob’s padlock… but she can unlock her own. So she removes her lock, and sends the singly locked box back to Bob.")],
[#text("Bob can unlock his own padlock, and so retreives the object safely. At no point was the object available to any interceptor.")]
)

#text("A similar procedure (a slight variant of the Diffie-Hellman protocol, essentially the ")#link("http://en.wikipedia.org/wiki/Massey-Omura_cryptosystem")[#text("Massey-Omura cryptosystem")]#text(") can be used to transmit a digital message g (which one should think of as just being a number) from Alice to Bob over an unsecured network, as follows:")

#enum(start: 1, 
[#text("Alice and Bob agree (over the unsecured network) on some large prime p (larger than the maximum size of the message g).")],
[#text("Alice “locks” the message g by raising it to a power a mod p, where Alice generates the “key” a randomly and keeps it secret. She then sends the locked message ")#mi("g^a \\text{ mod } p")#text(" to Bob.")],
[#text("Bob can’t decode this message (he doesn’t know a), but he doubly locks the message by raising the message to his own power b, and returns the doubly locked message ")#mi("g^{ab} \\text{ mod } p")#text(" back to Alice.")],
[#text("Alice then “unlocks” her part of the message by taking the ")#mi("a^{th}")#text(" root (which can be done by ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_theorem_%28group_theory%29")[#text("Cauchy’s theorem")]#text(") and sends ")#mi("g^b \\text{ mod } p")#text(" back to Bob.")],
[#text("Bob then takes the ")#mi("b^{th}")#text(" root of the message and recovers g.")]
)

#text("An eavesdropper (let’s call her Eve) could intercept p, as well as the three “locked” values ")#mi("g^a, g^b, g^{ab} \\text{ mod } p")#text(", but does not directly recover g. Now, it is possible that one could use this information to reconstruct g (indeed, if one could quickly take discrete logarithms, then this would be a fairly easy task) but no feasible algorithm for this is known (if p is large, e.g. 500+ digits); the problem is generally believed to be roughly comparable in difficulty to that of factoring large numbers. But no-one knows how to rigorously prove that the Diffie-Hellman reconstruction problem is hard (e.g. non-polynomial time); indeed, this would imply ")#link("http://en.wikipedia.org/wiki/P_%3D_NP_problem")[#mi("P \\neq NP")]#text(", since this reconstruction problem is easily seen to be in NP (though it is not believed to be ")#link("http://en.wikipedia.org/wiki/NP-complete")[#text("NP-complete")]#text(").")

#text("Using the sum-product technology, Bourgain was at least able to show that the Diffie-Hellman protocol was secure (for sufficiently large p) if Eve was only able to see the ")#link("http://en.wikipedia.org/wiki/Significant_figures")[#text("high bits")]#text(" of ")#mi("g^a, g^b, g^{ab} \\text{ mod } p")#text(", thus pinning down ")#mi("g^a, g^b, g^{ab}")#text(" to intervals. The reason for this is that the set ")#mi("\\{ (g^a, g^b, g^{ab}) \\in {\\Bbb F}_p^3: a,b \\in {\\Bbb Z} \\}")#text(" has a lot of multiplicative structure (indeed, it is a multiplicative subgroup of the ring ")#mi("{\\Bbb F}_p^3")#text(") and so should be uniformly distributed in an additive sense (by adapting the above sum-product technology to ")#mi("{\\Bbb F}_p^3")#text(").")

#text("Another application of sum-product technology was to build efficient ")#link("http://en.wikipedia.org/wiki/Extractor")[#text("randomness extractors")]#text(" – deterministic algorithms that can create high-quality (very uniform) random bits from several independent low-quality (non-uniform) random sources; such extractors are of importance in computer science and cryptography. Basically, the sum-product estimate implies that if ")#mi("A, B, C \\subset {\\Bbb F}_p")#text(" are sets of medium size, then the set ")#mi("A+B \\cdot C")#text(" is significantly larger than A, B, or C. As a consequence, if X, Y, Z are independent random variables in ")#mi("{\\Bbb F}_p")#text(" which are not too narrowly distributed(in particular, they are not deterministic, and thus distributed only on a single value), one can show (with the assistance of some additive combinatorics) that the random variable ")#mi("X+YZ")#text(" is significantly more uniformly distributed than X, Y, or Z. Iterating this leads to some surprisingly good randomness extractors, as was first observed ")#link("http://www.cs.princeton.edu/~boaz/Papers/msamples.ps")[#text("by Barak, Impagliazzo, and Wigderson")]#text(".")

#text("Another application of the above sum-product technology was to get a product estimate in matrix groups, such as ")#mi("SL_2({\\Bbb F}_p)")#text(". Indeed, ")#link("http://arxiv.org/abs/math/0509024")[#text("Helfgott was able to show")]#text(" that if A was a subset of ")#mi("SL_2({\\Bbb F}_p)")#text(" of medium or small size, and it was not trapped inside a proper subgroup of ")#mi("SL_2({\\Bbb F}_p)")#text(", then ")#mi("A \\cdot A \\cdot A")#text(" was significantly larger than A itself. (One needs to work with triple products here instead of double products for a rather trivial reason: if ")#mi("A")#text(" was the union of a subgroup and some external element, then ")#mi("A \\cdot A")#text(" is still comparable in size to A, but ")#mi("A \\cdot A \\cdot A")#text(" will be much larger. This result may not immediately look like a sum-product estimate, because there is no obvious addition, but it is concealed within the matrix multiplication law for ")#mi("SL_2({\\Bbb F}_p)")#text(". The key observation in Helfgott’s argument, which relies crucially on the sum-product estimate, is that if V is a collection of diagonal matrices in ")#mi("SL_2({\\Bbb F}_p)")#text(" of medium size, and g is a non-diagonal matrix element, then the set ")#mi("\\text{tr}(V g V g^{-1})")#text(" is significantly larger than V itself. If one works out explicitly what this trace is, one sees a sum-product type of result emerging. Conversely, if the trace ")#mi("\\text{tr}(A)")#text(" of a group-like set A is large, then the conjugacy classes in A are fairly small (since trace is conjugation-invariant), which forces many pairs in A to commute, which creates large sets V of simultaneously commuting (and hence simultaneously diagonalisable) elements, due to the fact (specific to ")#mi("SL_2")#text(") that if two elements commute with a third, then they are quite likely to commute with each other. The tension between these two implications is what underlies Helfgott’s results.")

#text("The estimate of Helfgott shows that multiplication by medium-size sets in ")#mi("SL_2({\\Bbb F}_p)")#text(" expands rapidly across the group (unless it is trapped in a subgroup). As a consequence of Helfgott’s estimate, ")#link("http://www.ams.org/mathscinet-getitem?mr=2227746")[#text("Bourgain and Gamburd")]#text(" were able to show that if S was any finite symmetric set of matrices in ")#mi("SL_2({\\Bbb Z})")#text(" which generated a sufficiently large (or more precisely, Zariski dense) subgroup of ")#mi("SL_2({\\Bbb Z})")#text(", and ")#mi("S_p")#text(" was the projection of S to ")#mi("SL_2({\\Bbb Z}_p)")#text(", then the random walk using ")#mi("S_p")#text(" on ")#mi("SL_2({\\Bbb Z}_p)")#text(" was very rapidly mixing, so that after about ")#mi("O(\\log p)")#text(" steps, the walk was very close to uniform. (The precise statement was that the ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(" associated to ")#mi("S_p")#text(" for each p formed an ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander family")]#text(".) Quite recently, ")#link("http://www.ams.org/mathscinet-getitem?mr=2246331")[#text("Bourgain, Gamburd, and Sarnak")]#text(" have applied these results (and generalisations thereof) to the problem of detecting (or ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieving")]#text(") almost primes in thin algebraically generated sets. To motivate the problem, we observe that many classical questions in prime number theory can be rephrased as one of detecting prime points ")#mi("(p_1,\\ldots,p_d) \\in {\\mathcal P}^d")#text(" in algebraic subsets ")#mi("{\\mathcal O}")#text(" of a lattice ")#mi("{\\Bbb Z}^d")#text(". For instance, the twin prime problem asks whether the line ")#mi("{\\mathcal O} = \\{ (n,n+2) \\in {\\Bbb Z}^2 \\}")#text(" contains infinitely many prime points. In general, these problems are very difficult, especially once one considers sets described by polynomials rather than linear functions; even the one-dimensional problem of determining whether the set ")#mi("{\\mathcal O} = \\{ n^2+1: n \\in {\\Bbb Z} \\}")#text(" contains infinitely many primes has been open for quite a long time (though it is worth mentioning the celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=1670065")[#text("result of Friedlander and Iwaniec")]#text(" that the somewhat larger set ")#mi("{\\mathcal O} = \\{ n^2 + m^4: n,m \\in {\\Bbb Z} \\}")#text(" is known to have infinitely many primes).")

#text("So prime points are hard to detect. However, by using methods from sieve theory, one can often detect almost prime points in various sets ")#mi("{\\mathcal O}")#text(" – points whose coordinates are the products of only a few primes. For instance, a famous ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("theorem of Chen")]#text(" shows that the line ")#mi("{\\mathcal O} = \\{ (n,n+2) \\in {\\Bbb Z}^2 \\}")#text(" contains infinitely many points which are ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost prime")]#text(" in the sense that the first coordinate is prime, and the second coordinate is the product of at most two primes. The basic idea of sieve theory is to sift out primes and almost primes by removing all points whose coordinates are divisible by small factors (and then, due to various generalisations of the ")#link("http://en.wikipedia.org/wiki/Inclusion-exclusion_principle")[#text("inclusion-exclusion principle")]#text(", one has to add back in points which are divisible by multiple small factors, and so forth). See ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("my post on sieve theory and the parity problem")]#text(" for further discussion. In order for sieve theory to work well, one needs to be able to accurately count the size of the original set ")#mi("{\\mathcal O}")#text(" (or more precisely, the size of this set restricted to a ball or a similar object), and also need to count how many points in that set have a certain residue class modulo q, for various values of q. (For instance, to sieve out twin primes or twin almost primes in the interval {1,..,N}, one needs to count how many elements n in that interval are such that n and n+2 are both invertible modulo q (i.e. coprime to q) for various values of q.)")

#text("For arbitrary algebraic sets ")#mi("{\\mathcal O}")#text(", these tasks are very difficult. For instance, even the basic task of determining whether a set ")#mi("{\\mathcal O}")#text(" described by several polynomials is non-empty is essentially ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_tenth_problem")[#text("Hilbert’s tenth problem")]#text(", which is undecidable in general. But if the set ")#mi("{\\mathcal O}")#text(" is generated by a group ")#mi("\\Lambda")#text(" acting on ")#mi("{\\Bbb Z}^d")#text(" (in some polynomial fashion), thus ")#mi("{\\mathcal O} = \\Lambda b")#text(" for some point ")#mi("b \\in {\\Bbb Z}^d")#text(", then the problems become much more tractable. If the group ")#mi("\\Lambda")#text(" is generated by some finite set S, and we restrict attention to group elements with some given word length, the problem of understanding how ")#mi("{\\mathcal O}")#text(" is distributed modulo q is equivalent to asking how random walks on S of a given length distribute themselves on ")#mi("({\\Bbb Z}/q{\\Bbb Z})^d")#text(". This latter problem is very close to the problem solved by the mixing results of Bourgain and Gamburd mentioned earlier, which is where the link to sum-product estimates arises from. Indeed, Bourgain, Gamburd, and Sarnak have now shown that rather general classes of algebraic sets generated by subgroups of ")#mi("SL_2({\\Bbb Z})")#text(" will contain infinitely many almost primes, as long as there are no obvious algebraic obstructions; the methods should hopefully extend to more general groups, such as subgroups of ")#mi("SL_n({\\Bbb Z})")#text(".")

#text("[")#emph[#text("Update")]#text(", Dec 7: terminology and typos corrected.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5654949e859ddea82b43416938a38372ba96fbfea7f2869d5afc67dc7990b402-68f66dd72ad7e7da550eb9d4c271150e71c92971e62173dd894851a03d463ae3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of intoverflow")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19292")[#strong[#text("intoverflow")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("If I’m not mistaken, the variant on Diffie-Hellman here presented is the Massey-Omura crypto system. Also, I’ve heard rumors that the box-with-locks system was actually used to move shared keys between US embassies prior to the discovery of public key methods ala Cliff Cocks and RSA, although I can’t personally testify to their truth.")

#text("I enjoyed your lectures this week very much, and hope you had a pleasant time in Seattle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19338")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Dear intoverflow,")

#text("Thanks for pointing out the Massey-Omura system! It seems like this system is usually proposed for fields of small characteristic (such as ")#mi("GF(2^m)")#text("), but of course it can be implemented in any finite field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qi")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19357")[#strong[#text("Qi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("In your definition of A*A, shoud + be * instead?")

#text("I really enjoy this post. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a508e0c02e9c8cf3f0144f5862c6fa7cd3c9be9d016b578598fd9fc6e1add47-2224d6eb8042cae9c93d0f7f6c3756d60dff6b8c4f2b59d3d60a154d03ba57f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19368")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Dear Terence,")

#text("(a) As it happens, I proved |A A A|>|A|^{1+epsilon} not just for middle-sized sets, but for all A that are not very large (|A| < |G|^{0.9999}, say). This was, of course, possible thanks to the strengthening of your result due to Konyagin et al.")

#text("(Bourgain and Gamburd need the result only for middle-sized sets, but that is another matter.)")

#text("(b) By now, I am not sure that looking at how sums and products “hide” inside the law for matrix multiplication is the best thing to do, or the best way to explain why growth happens in SL_2 (and, let us hope, in some other groups). The entries are not independent variables, and so no direct application of sum-product is possible, even for SL_2(Z/pZ).")

#text("Rather, I would say that the sum-product theorem is really about multiplication and linearity; since SL_2 is a linear algebraic group, there is a certain tension between its linearity and the fact that it is a group. The argument connecting V and traces is crucial because it shows that a set A that does not grow would have to have a large intersection with a maximal torus; inside the torus, the group operation is simply multiplication of numbers – and thus we obtain the desired tension between linearity and multiplication.")

#text("In the general case, the “linearity” will most like show itself through characters, rather than through explicit computations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2007")])]

#text("Dear Qi and Harald: thanks for the corrections!")

#text("Dear Harald: I like this new perspective, it looks somewhat less “ad hoc” than the current arguments, which bodes well for extension to more general groups. So I guess the point is that having an element g outside the maximal torus induces a nontrivial (but linear) conjugation operation on that torus, which when combined with multiplication causes the expansion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathaaron")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19468")[#strong[#text("mathaaron")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2007")])]

#text("Prof Tao,")#linebreak()#text(" Can you talk more about why Tom Wolff posted the sum product problem")#linebreak()#text(" for the range |A|~ p^1/2 ? You mentioned that it was motivated by Kakeya problem in finite fields. Also, as we know, for any big enough promes P , one can construct A whose size ~|p^1/2 , so that the sum-product of A is less that |A|^3/2 .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guest")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19487")[#strong[#text("Guest")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2007")])]

#text("Prof. Tao,")

#text("Is there any chance this year’s lectures will be made available online (like last years)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-19505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2007")])]

#text("Dear Mathaaron,")

#text("Tom was working on the Kakeya conjecture in the three dimensional finite vector space ")#mi("{\\Bbb F}_p^3")#text(". He showed that Kakeya sets in that setting have cardinality ")#mi("\\gtrsim p^{5/2}")#text(". He had some heuristic arguments (based to some extent on consideration of the Heisenberg group, which can be thought of as a sort of 5/2-dimensional manifold in ")#mi("{\\Bbb C}^3")#text(" which contains lots of (complex) lines and so behaves much like a Kakeya set) which suggested that one would need to exploit a sum-product phenomenon to improve this bound. In my paper with Bourgain and Katz, we made these heuristics rigorous by using our sum-product estimate to improve the lower bound for the cardinality of Kakeya sets in ")#mi("{\\Bbb F}_p^3")#text(" to ")#mi("p^{5/2+\\varepsilon}")#text(" for some ")#mi("\\varepsilon > 0")#text(".")

#text("Dear Guest: You would have to ask someone at the UW math department, I do not know what they will be doing with the video of the lectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e80fd5aa78b931e6c144b092d1240f54e14db04a5431f3205a8e3cf6a23dbee-dc1ba121c46de6f5010f776e4cc2d40a32f85bb07d8bc06612fd6a2f325754f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Larry")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-20779")[#strong[#text("Larry")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2007")])]

#text("hey! your lecture is very understandable! thanks for this lecture!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-21504")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2007")])]

#text("There is also the issue of whether the sum-product theorem is the “right” theorem at all. One of the latest incarnations of the proof works for sets of rather unequal size. What is more – it seems to me that the proof can be transferred effortlessly to things that are not fields, but modules.")

#text("To wit: let G be an abelian group acting on an abelian group A. (In other words, A is a ")#mi("{\\Bbb Z}[G]")#text(" module.) Then, given a subset A’ of A and a subset G’ of G, and given a non-trivial technical condition (namely, the map on A given by ")#mi("x \\to (g_1 x - g_2 x)")#text(" is required to be injective for all distinct g_1, g_2 in G’), either")

#text("(a) we can play with G’ and A’ a bounded number of times (eight or so!) to get at least |G’| |A’| elements of A, or")

#text("(b) |G’| |A’| is quite large, and we can play with G’ and A’ a bounded number of times to get all of ")#mi("\\langle \\langle G^{\\prime} \\rangle \\cdot \\langle A^{\\prime} \\rangle \\rangle")#text(" (i.e., the submodule of A generated by all our friends in G’ and A’).")

#text("End of lemma.")

#text("My two favourite examples?")

#text("(a) G = A = F, where F is a field. For ")#mi("F = {\\Bbb Z}/p{\\Bbb Z}")#text(", we know that")#linebreak()#text(" ")#mi("\\langle \\langle G \\rangle\\langle A \\rangle \\rangle = \\langle A \\rangle = {\\Bbb Z}/p{\\Bbb Z}")#text(" (since F is cyclic) and thus we get the sum-product theorem we know and love (=yours);")

#text("(b) S a solvable (linear algebraic) group, G the maximal torus, A any quotient in the abelian tower of the group of nilpotent elements of S. (G acts on the nilpotents by conjugation.) In SL_n, what I called the “technical condition” above becomes “the restriction of any root map ")#mi("g \\to r_i(g)/r_j(g)")#text(" to G’ is injective”. Perhaps something like that is true in general, but I haven’t checked.")

#text("* * *")

#text("The technical condition looks somewhat nasty, but it is not hard to construct examples in the style (b) showing that it (or something like it) is necessary. I wonder whether it has a nicer-looking avatar, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-21582")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2007")])]

#text("Actually, it seems A need not be abelian at all. Thus,")#linebreak()#text(" we should really be talking about an abelian group of automorphisms (was: G) of an arbitrary group (was: A).")#linebreak()#text(" The same proof should work there.")

#text("Here’s an immediate application of this – the group A could be the upper-triangular matrices in SL_n with 1’s in the diagonal, and the group of automorphisms could consist of conjugation by diagonal matrices.")

#text("The “technical condition” can be replaced by a much softer quantitative version of itself. Will write more later. Thanks for an incentive to thought…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-21584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2007")])]

#text("Sounds very interesting! Beyond the immediate applications to various interesting rings, the fact that these techniques could apply to pairs of sets of different sizes should also be very useful. If nothing else, they may be able to simplify a lot of the current analysis of Bourgain, Bourgain-Gamburd, and others, in which one has to iteratively expand some set until it stabilises in size, all so that one can apply symmetric sum-product theorems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Helfgott")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-21778")[#strong[#text("Harald Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2007")])]

#text("When I first saw a statement of sum-product valid for sets of different sizes, I was quite excited; it is very tempting to think that it should lead to direct proofs of expansion – perhaps uniform expansion for all generators.")

#text("However, both my methods and all known statements of sum-product do involve operations involving at least two copies of either of the two given sets A, B (and, thus, at least two copies of the larger of the two sets). This makes the possibility of deriving expansion directly rather more doubtful.")

#text("* * *")

#text("Returning to the nilpotents: that gives us the statement A*A*A > A^{1+eps} for G = SL_n under the assumption that |A| is more than the")#linebreak()#text(" square root of |G| or so. This is a rather broader range than that given by the (very elegant) methods of Gowers and Babai-Nikolov-Pyber.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Avi Wigderson, “Expander graphs - constructions and applications” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-23913")[#strong[#text("Distinguished Lecture Series II: Avi Wigderson, “Expander graphs - constructions and applications” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("[…] The talk was largely based on (a variant of) these slides. Avi also has a recent monograph with Hoory and Linial on these topics. (For a brief introduction to expanders, I can also recommend Peter Sarnak’s Notices article. I also mention expanders to some extent in my third Milliman lecture.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The sum-product phenomenon in arbitrary rings « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-30453")[#strong[#text("The sum-product phenomenon in arbitrary rings « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2008")])]

#text("[…] also my third Milliman lecture “Sum-product estimates, expanders, and exponential sums”.] Possibly related posts: (automatically generated)“Mittens” In The RingsI dare youLight […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-32721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2008")])]

#text("I learned the sad news that György Elekes died on Monday (29 September, 2008).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-32749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2008")])]

#text("That is indeed sad. I only met György once (at a conference in Montreal) but I have of course known his elegant work on this and other problems for some time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lecture IV: “Sieving for almost primes and expanders” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-33601")[#strong[#text("Marker lecture IV: “Sieving for almost primes and expanders” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2008")])]

#text("[…] of certain “nonlinear” or “noncommutative” behaviour in the group ; see my Milliman lecture for a bit more discussion on this. For now, let me just say that Helfgott’s proof on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-199607")[#strong[#text("A sum-product function in function fields (Bloom, Jones) « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")]

#text("[…] This kind of sum-product problem has been the subject of sustained interest for a long time; the exponent is supposed to be 2 (i.e, either the sums are more or less distinct from each other or the products are) but nothing close to this has been obtained in any case. The exponent here is better than the best known for finite fields of prime order, but worse than the best known for the real numbers. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-539535")[#strong[#text("The largest clique in the Paley Graph: unexpected significant progress and surprising connections. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2020")]

#text("[…] MO answer.) Of course, the sum-product phenomena is a huge area with amazing applications (See, here, here, here, and here; I recall that Jean Bourgain referred to it as a gold mine or something like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc7976a59ea3f9e2e26c97cb17b837d10e7bc61ceed83b1f677cac8b06b938c-7d047d48a7ee58eff1be3e3beb48d7a277868c33a2c848c6d8507b7004b43a0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-594986")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("What is the reference for Bourgain’s diffie-hellman work?")

#emph[#text("[The main reference is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2140627")[#text("https://mathscinet.ams.org/mathscinet-getitem?mr=2140627")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1fcd1e68a87e6d278dbb9b4149fc04f6398d65bc9367f41b35b46da63abd538-e4e2e2b99e430bbe6eae7f2b61b39afd0f5d6106a3f68a1578e60baff461792b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-594988")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Also could you explain how cauchy’s theorem helps in extracting roots? Isn’t identifying principal roots hard?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-595038")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Cauchy’s theorem (and a little extra work) shows that the multiplicative group of ")#mi("{\\bf F}_p")#text(" is isomorphic to ")#mi("{\\bf Z}/(p-1){\\bf Z}")#text(". As a consequence, taking an ")#mi("a^{th}")#text(" root is the same as taking a ")#mi("b^{th}")#text(" power whenever ")#mi("b")#text(" is such that ")#mi("ab=1 \\text{ mod } p-1")#text(". Locating such a ")#mi("b")#text(" and computing the ")#mi("b^{th}")#text(" power can be done quite rapidly (the latter by expanding ")#mi("b")#text(" in binary and repeatedly squaring, for instance).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366c09fd27c7ee210128e08a0eb0e8ee2c05dde1a2c2e7f40dedff449d6006fe-d4da866694afb7692e7a7e6ecf007e3a31083be7a6a765168771284eb8625dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-595083")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("I would have imagined there are $a$ possibilities and that would be an issue. Why is it avoided here but not avoided in section 4.3 in ")#link("http://www.cs.cmu.edu/~ryanw/crypto/lec13.pdf")[#text("http://www.cs.cmu.edu/~ryanw/crypto/lec13.pdf")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f3e149df8d800bcb8bf9727e2cdae899e8786f5710ec9a2253855037c4dbdf1-1c3b344e932372fbc8f87bdd221d5cdb38841472f0bad0ac0f3c52c5b07e083a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-595124")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("I am using it as analogy. There is no b such that 2b=1 mod \\lambda(p) in the example. So there is only one $a$th root?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-595161")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("That is an algorithm for the discrete logarithm, not for taking ")#mi("a^{th}")#text(" roots. In a field ")#mi("{\\bf F}_p")#text(", there are often far fewer than ")#mi("a")#text(" roots that are inside ")#mi("{\\bf F}_p")#text("; in general there are only ")#mi("\\mathrm{gcd}(a,p-1)")#text(" roots, which is typically quite small (especially if one chooses a ")#link("https://en.wikipedia.org/wiki/Safe_and_Sophie_Germain_primes")[#text("safe prime")]#text("). (There will be ")#mi("a")#text(" roots (counting multiplicity) in the algebraic closure ")#mi("\\overline{\\bf F}_p")#text(", but this is a far laerger field.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/394d18b8a5398c68dafd131e7ed75e6102b27dea0804cfa1940602af5057a96f-2583fb5a0d92dfc7bc31d237ba32ad9ea12954839b26372ec280238a1417b488.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-595321")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("1. The notes do say if you can find principal roots we can solve discrete logarithm for those primes. I think perhaps 1/2 does not exist the.method fails. Perhaps there is a different method.")

#text("2. Is the standard theorem ‘at most gcd(a,q-1) roots in F_q where q is prime power’? Where can I find it? So a is carefully chosen.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/#comment-595392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("Because of the existence of the discrete logarithm, the multiplicative group of ")#mi("{\\bf F}_q")#text(" is isomorphic to the additive group ")#mi("{\\bf Z}/(q-1){\\bf Z}")#text(", which is why ")#mi("a^{th}")#text(" roots have multiplicity ")#mi("\\mathrm{gcd}(a,q-1)")#text(". This would definitely be a problem for even ")#mi("a")#text(" (it would force a multiplicity of at least two), and in particular in the square root problem mentioned in the notes, but if one is working with odd ")#mi("a")#text(" then one can almost always avoid ambiguity in taking ")#mi("a^{th}")#text(" roots. (The situation is not dissimilar to taking roots in the real numbers, where even roots are ambiguous up to sign but odd roots are unambiguous.)")
]
]
