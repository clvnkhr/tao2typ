// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/
// Converted to Typst by tao2typ: "2026-10-14T15:16:44.198097+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 4: Finite time extinction of the second homotopy group", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 4: Finite time extinction of the second homotopy group")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")[#text("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("Returning (perhaps anticlimactically) to the subject of the Poincaré conjecture, recall from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(" that one of the key pillars of the proof of that conjecture is the finite time extinction result (see Theorem 4 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("that lecture")]#text("), which asserted that if a compact Riemannian 3-manifold (M,g) was initially simply connected, then after a finite amount of time evolving via Ricci flow with surgery, the manifold will be empty.")

#text("In this lecture and the next few, we will describe some of the key ideas used to prove this theorem. We will not be able to completely establish this theorem at present, because we do not have a full definition of “surgery”, but we will be able to establish some partial results, and indicate (in informal terms) how to cope with the additional technicalities caused by the surgery procedure. Hopefully, if time permits later in the class, once we have studied the surgery process, I will be able to revisit this material and flesh out these technicalities a bit more.")

#text("The proof of finite time extinction proceeds in several stages. The first stage, which was already accomplished in the previous lecture (in the absence of surgery, at least), is to establish lower bounds on the least scalar curvature ")#mi("R_{\\min}")#text(". The next stage, which we discuss in this lecture, is to show that the second ")#link("http://en.wikipedia.org/wiki/Homotopy_group")[#text("homotopy group")]#text(" ")#mi("\\pi_2(M)")#text(" of the manifold must become extinct in finite time, thus all ")#link("http://en.wikipedia.org/wiki/Immersion_%28mathematics%29")[#text("immersed")]#text(" copies of the 2-sphere ")#mi("S^2")#text(" in M(t) for sufficiently large t must be contractible to a point. The third stage is to show that the third homotopy group ")#mi("\\pi_3(M)")#text(" also becomes extinct so that all immersed copies of the 3-sphere ")#mi("S^3")#text(" in M are similarly contractible. The final stage, which uses homology theory, is to show that a non-empty 3-manifold cannot have ")#mi("\\pi_1(M), \\pi_2(M), \\pi_3(M)")#text(" simultaneously trivial, thus yielding the desired claim (note that a simply connected manifold has trivial ")#mi("\\pi_1(M)")#text(" by definition; also, from Exercise 2 of Lecture 2 we see that all components of M remain simply connected even after surgery).")

#text("More precisely, in this lecture we will discuss (most of) the proof of")

#strong[#text("Theorem 1.")]#text(" (Finite time extinction of ")#mi("\\pi_2(M)")#text(") Let ")#mi("t \\mapsto (M(t),g(t))")#text(" be a Ricci flow with surgery on compact 3-manifolds with ")#mi("t \\in [0,+\\infty)")#text(", with M(0) containing no embedded copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle. Then for all sufficiently large t, ")#mi("\\pi_2(M(t))")#text(" is trivial (or more precisely, every connected component of M(t) has trivial ")#mi("\\pi_2")#text(").")

#text("The technical assumption about having no copy of ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle is needed solely in order to apply the known existence theory for Ricci flow with surgery (see Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/04/01/285g-lecture-2-the-ricci-flow-approach-to-the-poincare-conjecture/")[#text("Lecture 2")]#text(").")

#text("The intuition for this result is as follows. From the ")#link("http://en.wikipedia.org/wiki/Gauss%E2%80%93Bonnet_theorem")[#text("Gauss-Bonnet theorem")]#text(" (and the fact that the ")#link("http://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler characteristic")]#text(" ")#mi("\\chi(S^2)=V-E+F=2")#text(" of the sphere is positive), we know that 2-spheres tend to have positive (")#link("http://en.wikipedia.org/wiki/Gaussian_curvature")[#text("Gaussian")]#text(") curvature on the average, which should make them shrink under Ricci flow. (Here I am conflating Gaussian curvature with Ricci curvature; however, by restricting to a special class of 2-spheres, namely ")#link("http://en.wikipedia.org/wiki/Minimal_surface")[#text("minimal surfaces")]#text(", one can connect the two notions of curvature to each other (and to scalar curvature) quite nicely.) On the other hand, the presence of negative scalar curvature can counteract this by expanding these spheres. But the lower bounds on scalar curvature tell us that the negativity of scalar curvature becomes weakened over time, and it turns out that the shrinkage caused by the Gauss-Bonnet theorem eventually dominates and sends the area of all minimal immersed 2-spheres into zero, at which point one can conclude the triviality of ")#mi("\\pi_2(M)")#text(" by the ")#link("http://www.ams.org/mathscinet-getitem?mr=604040")[#text("Sacks-Uhlenbeck theory")]#text(" of minimal 2-spheres.")

#text("The arguments here are drawn from the book of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(" and from the paper of ")#link("http://xxx.lanl.gov/abs/math.AP/0308090")[#text("Colding-Minicozzi")]#text(". The idea of using minimal surfaces to force disappearance of various topological structures under Ricci flow originates ")#link("http://www.ams.org/mathscinet-getitem?mr=1714939")[#text("with Hamilton")]#text(" (who used 2-torii instead of 2-spheres, but the idea is broadly the same).")

#metadata(none) <tao-6f309b7df504b6d66e0a>

#heading(level: 1)[#text("— Curvature on surfaces —")]

#text("We have seen how Riemannian manifolds ")#mi("(M,g)")#text(" have various notions of curvature: Riemannian curvature ")#mi("\\text{Riem}")#text(", Ricci curvature ")#mi("\\text{Ric}")#text(", and scalar curvature R. These are ")#emph[#text("intrinsic")]#text(" notions of curvature: they depend only on the manifold M (and its metric g), and not how this manifold is embedded (if it is embedded at all) in some larger space. However, there are some important ")#emph[#text("extrinsic")]#text(" notions of curvature as well, which describe how an immersed manifold ")#mi("\\Sigma")#text(" is curved inside its ambient space M. In particular, we will recall the ")#link("http://en.wikipedia.org/wiki/Gaussian_curvature")[#text("Gauss curvature")]#text(" K, ")#link("http://en.wikipedia.org/wiki/Principal_curvature")[#text("principal curvatures")]#text(" ")#mi("\\lambda_1, \\lambda_2")#text(", and ")#link("http://en.wikipedia.org/wiki/Mean_curvature")[#text("mean curvature")]#text(" H of a surface (i.e. a 2-dimensional manifold) ")#mi("\\Sigma")#text(" inside a 3-manifold (M,g). [These notions can also be defined for other dimensions, but we will focus exclusively on the case of surfaces inside 3-manifolds.] We will also recall the standard fact that the mean curvature H vanishes whenever the surface is a minimal surface.")

#text("Let ")#mi("\\Sigma")#text(" be an immersed 2-surface in a Riemannian 3-manifold ")#mi("(M,g)")#text(". All our computations here will be local, in the neighbourhood of some point ")#mi("x_0")#text(" in ")#mi("\\Sigma")#text(" (and thus in M; in particular we can pretend that the immersed manifold ")#mi("\\Sigma")#text(" is in fact embedded as a submanifold of M. If we let h be the restriction of the metric ")#mi("g")#text(" to ")#mi("\\Sigma")#text(" (restricting TM to ")#mi("T\\Sigma")#text(", etc.) then of course ")#mi("(\\Sigma,h)")#text(" is a Riemannian 2-manifold.")

#text("It is convenient to pick a unit normal vector field ")#mi("n \\in  \\Gamma(TM)")#text(", thus n has norm 1 and is orthogonal to ")#mi("T\\Sigma")#text(" at every point in ")#mi("\\Sigma")#text(". It is only the value of n on the submanifold ")#mi("\\Sigma")#text(" which is important, but we will arbitrarily extend n smoothly to all of M so that we can take advantage of vector field operations on the ambient space. There is a choice of sign for n (e.g. if ")#mi("\\Sigma")#text(" bounded a three-dimensional region, we could pick either the outward or inward normal), which can lead to an ambiguity in sign in the principal and mean curvatures, but it will not affect the sign of the Gauss curvature.")

#text("Let ")#mi("\\nabla = \\nabla^{(M)}")#text(" be the Levi-Civita connection on M, and let X, Y be two vector fields which are tangential to ")#mi("\\Sigma")#text(", thus ")#mi("X(x), Y(x) \\in T_x \\Sigma")#text(" for all ")#mi("x \\in \\Sigma")#text(". Then the covariant derivative ")#mi("\\nabla^{(M)}_X Y")#text(" need not be tangential to ")#mi("\\Sigma")#text(", but we can decompose")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\nabla^{(M)}_X Y = \\nabla^{(\\Sigma)}_X Y + \\Pi(X,Y) n,")]]

#text("where ")#mi("\\Pi(X,Y) n")#text(" is the component of ")#mi("\\nabla^{(M)}_X Y")#text(" parallel to n, and ")#mi("\\nabla^{(\\Sigma)}_X Y")#text(" is the component which is orthogonal to n (and in particular lies in ")#mi("T\\Sigma")#text(" on ")#mi("\\Sigma")#text(".")

#strong[#text("Exercise 1.")]#text(" Show that ")#mi("\\nabla^{(\\Sigma)}")#text(" is the Levi-Civita connection on ")#mi("(\\Sigma,h)")#text(", and that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Pi(X,Y) = - g(\\nabla^{(M)}_X n, Y)")]]

#text("on ")#mi("\\Sigma")#text(". (Hint: for the latter, compute the quantity ")#mi("\\nabla_X g(n,Y)")#text(" in two different ways.) Conclude that ")#mi("\\Pi")#text(" can be identified with a symmetric rank (0,2) tensor (known as the ")#link("http://en.wikipedia.org/wiki/Second_fundamental_form")[#text("second fundamental form")]#text(") on ")#mi("\\Sigma")#text(", which (up to sign) is independent of the choice of normal ")#mi("n")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Using (1), deduce the ")#emph[#text("Gauss equation")]

#tao-aligned(keep: true)[


#tao-math("g( \\text{Riem}^{(M)}(X,Y) Z, W )  & = g( \\text{Riem}^{(\\Sigma)}(X,Y) Z, W )", block: true)



#tao-math(" & + \\Pi(X,W) \\Pi(Y,Z) - \\Pi(X,Z) \\Pi(Y,W)", block: true, numbering: n => [#text("(3)")])
]

#text("on ")#mi("\\Sigma")#text(", whenever X, Y, Z, W are vector fields that are tangent to ")#mi("\\Sigma")#text(", and ")#mi("\\text{Riem}^{(M)}")#text(" and ")#mi("\\text{Riem}^{(\\Sigma)}")#text(" are the Riemann curvature tensors of ")#mi("(M,g)")#text(" and ")#mi("(\\Sigma,h)")#text(" respectively. (One could of course write (3) in abstract index notation, but we have chosen not to do so to avoid confusion between the two bundles ")#mi("TM")#text(" and ")#mi("T\\Sigma")#text(" that are implicitly in play here.) ")#mi("\\diamond")

#text("At any point ")#mi("x \\in \\Sigma")#text(", the second fundamental form ")#mi("\\Pi(x)")#text(" can be viewed as a symmetric bilinear form on the two-dimensional space ")#mi("T_x \\Sigma")#text(", which thus has two real eigenvalues ")#mi("\\lambda_1\\geq \\lambda_2")#text(", known as the ")#link("http://en.wikipedia.org/wiki/Principal_curvature")[#text("principal curvatures")]#text(" of ")#mi("\\Sigma")#text(" (as embedded in M) in x. The normalised trace ")#mi("H := \\frac{1}{2}\\text{tr}(\\Pi)= \\frac{1}{2}(\\lambda_1 + \\lambda_2)")#text(" of the second fundamental form is known as the ")#link("http://en.wikipedia.org/wiki/Mean_curvature")[#text("mean curvature")]#text(". Meanwhile, the ")#link("http://en.wikipedia.org/wiki/Gaussian_curvature")[#text("Gauss curvature")]#text(" K = K(x) at a point ")#mi("x \\in \\Sigma")#text(" is defined as equal to half the scalar curvature of ")#mi("\\Sigma")#text(": ")#mi("K = \\frac{1}{2} R^{(\\Sigma)}")#text(". (In particular, this manifestly demonstrates that the Gauss curvature K is intrinsic; this fact, combined with Exercise 3 below, is essentially the famous ")#link("http://en.wikipedia.org/wiki/Theorema_egregium")[#text("theorema egregium")]#text(" of Gauss.)")

#strong[#text("Exercise 3. ")]#text(" Using Exercise 2, establish the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("K = \\det(\\Pi) + K_M = \\lambda_1 \\lambda_2 + K_M")]]

#text("where ")#mi("K_M")#text(" is the ")#link("http://en.wikipedia.org/wiki/Sectional_curvature")[#text("sectional curvature")]#text(" of ")#mi("T\\Sigma")#text(" in M, defined at a point x by the formula ")#mi("K_M = g(\\text{Riem}^{(M)}(X,Y) X,Y)")#text(" where ")#mi("X,Y")#text(" are an orthonormal basis of ")#mi("T\\Sigma")#text(" at x. In particular, if ")#mi("M = (\\Bbb{R}^3,\\eta)")#text(" is Euclidean space, then the Gauss curvature is just the product of the two principal curvatures (or equivalently, the determinant of the second fundamental form). ")#mi("\\diamond")

#text("From (4) and the arithmetic mean-geometric mean inequality, we obtain in particular the following relationship between Gauss, mean, and sectional curvature:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("K \\leq H^2 + K_M.")]]

#text("Next, we now recall a special case of the ")#link("http://en.wikipedia.org/wiki/Gauss-Bonnet_theorem")[#text("Gauss-Bonnet theorem")]#text(".")

#strong[#text("Proposition 1")]#text(". (Gauss-Bonnet theorem for ")#mi("S^2")#text(") Let ")#mi("(\\Sigma,h)")#text(" be an immersion of the sphere ")#mi("S^2")#text(", and let ")#mi("K := \\frac{1}{2} R")#text(" be the Gauss curvature. Then ")#mi("\\int_\\Sigma K\\ d\\mu = 4\\pi")#text(", where ")#mi("\\mu")#text(" is the volume measure (or area measure) associated to h.")

#strong[#text("Proof")]#text(". We use a flow-based argument. Since Gauss curvature is intrinsic, we may pull back and assume that ")#mi("\\Sigma")#text(" is in fact equal to ")#mi("S^2")#text(", but with some generic Riemannian metric which we shall call ")#mi("h_0")#text(", which may differ from the standard Riemannian metric on ")#mi("S^2")#text(", which we shall call ")#mi("h_1")#text(". We can flow from ")#mi("h_0")#text(" to ")#mi("h_1")#text(" by the linear flow ")#mi("h(t) := (1-t) h_0 + t h_1")#text(" (say); note that this is a smooth flow on Riemannian metrics. Our task is to show that ")#mi("\\int_{S^2} R\\ d\\mu = 8 \\pi")#text(" at time zero. By equations (15), (19) of ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(", we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{d}{dt} \\int_{S^2} R\\ d\\mu = \\int_{S^2} (- \\text{Ric}^{\\alpha \\beta} \\dot h_{\\alpha \\beta} - \\Delta \\text{tr}(\\dot h_{\\alpha \\beta}) + \\nabla^\\alpha \\nabla^\\beta \\dot h_{\\alpha \\beta} + \\frac{1}{2} R \\text{tr}( \\dot h_{\\alpha \\beta} ) )\\ d\\mu.")]]

#text("The contribution of the second and third terms vanish thanks to Stokes’ theorem (equation (28) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("). And in two dimensions, the Bianchi identities force the Ricci curvature ")#mi("\\text{Ric}^{\\alpha \\beta}")#text(" to be conformal, i.e. it is equal to ")#mi("\\frac{1}{2} R h^{\\alpha \\beta}")#text(". Thus the right-hand side of (6) vanishes completely, and so by the fundamental theorem of calculus, the value of ")#mi("\\int_{S^2} R\\ d\\mu")#text(" at time 0 is equal to that at time 1. The claim then follows from the standard facts that ")#mi("S^2")#text(" with the usual metric has area ")#mi("4\\pi")#text(" and constant scalar curvature +2 (or Gauss curvature +1). ")#mi("\\Box")

#text("From this and (5) we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_{\\Sigma} K_M + H^2\\ d\\mu \\geq 4\\pi")]]

#text("for any immersed copy of ")#mi("S^2")#text(". Thus we can start lower bounding sectional curvatures on the average, as soon as we figure out how to deal with the mean curvature H.")

#text("To do this, we now specialise to immersed spheres ")#mi("\\Sigma")#text(" which are ")#link("http://en.wikipedia.org/wiki/Minimal_surface")[#text("minimal")]#text("; they have minimal area ")#mi("\\int_\\Sigma\\ d\\mu")#text(" with respect to smooth deformations. The following proposition is very well known:")

#strong[#text("Proposition 2.")]#text(" Let ")#mi("\\Sigma")#text(" be a minimal immersed surface. Then the mean curvature H of ")#mi("\\Sigma")#text(" is identically zero.")

#strong[#text("Proof. ")]#text(" Let us consider a local perturbation of ")#mi("\\Sigma")#text(". Working in local coordinates as before, we choose a unit normal field n, and flow ")#mi("\\Sigma")#text(" using the velocity field ")#mi("Z := fn")#text(", where f is a localised scalar function. This has the effect of deforming the metric h on ")#mi("\\Sigma")#text(" at the rate ")#mi("\\dot h = {\\mathcal L}_Z g")#text(", where ")#mi("{\\mathcal L}_Z")#text(" is the Lie derivative along the vector field Z. By equation (19) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(", the area of ")#mi("\\Sigma")#text(" will thus change under this deformation at the rate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{d}{dt} \\int_\\Sigma\\ d\\mu = \\int_\\Sigma \\frac{1}{2} \\text{tr}_h( {\\mathcal L}_Z g)\\ d\\mu.")]]

#text("On the other hand, as ")#mi("\\Sigma")#text(" is minimal, the left-hand side vanishes. Also, using equation (25) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(", we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\text{tr}_h( {\\mathcal L}_Z g) = 2 \\nabla_\\alpha Z_\\beta (X^\\alpha X^\\beta + Y^\\alpha Y^\\beta)")]]

#text("where X, Y is an orthonormal frame of ")#mi("\\Sigma")#text(" (we can work locally, so as to avoid the topological obstruction of the ")#link("http://en.wikipedia.org/wiki/Hairy_ball_theorem")[#text("hairy ball theorem")]#text("). Expanding out ")#mi("Z_\\beta = f n_\\beta")#text(" and recalling that n is orthogonal to X and Y, some calculation using (2) allows us to express (9) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("- 2 f  ( \\Pi(X,X) + \\Pi(Y,Y) ) = -4 f H.")]]

#text("Putting all this together, we conclude that ")#mi("\\int_\\Sigma fH\\ d\\mu = 0")#text(" for all local perturbations f, which implies that H vanishes identically. ")#mi("\\Box")

#text("It is an instructive exercise to try to convince oneself of the validity of Proposition 2 by pure geometric intuition regarding curvature and area.")

#text("From (7) and Proposition 2 we conclude a lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_{\\Sigma} K_\\Sigma\\ d\\mu \\geq 4\\pi")]]

#text("for the integrated sectional curvature of a minimal immersed 2-sphere ")#mi("\\Sigma")#text(" in a 3-manifold M.")

#heading(level: 1)[#text("— Minimal immersed spheres and Ricci flow —")]

#text("Now let ")#mi("(M,g)")#text(" be a compact 3-manifold with a non-trivial second homotopy group ")#mi("\\pi_2(M)")#text(". Thus there exist immersions ")#mi("f: S^2 \\to M")#text(" which cannot be contracted to a point. It is a theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=604040")[#text("of Sacks and Uhlenbeck")]#text(" that the area of such incontractible immersions cannot be arbitrarily small (for fixed M, g), and so if one defines ")#mi("W_2(M)")#text(" to be the infimum of the areas of all incontractible immersed spheres, then ")#mi("W_2(M)")#text(" is strictly positive.")

#text("It is a result ")#link("http://www.ams.org/mathscinet/search/publdoc.html?arg3=&co4=AND&co5=AND&co6=AND&co7=AND&dr=all&pg4=AUCN&pg5=AUCN&pg6=ALLF&pg7=IC&pg8=ET&s4=Meeks%20&s5=Yau&s6=&s7=&s8=All&yearRangeFirst=&yearRangeSecond=&yrop=eq&r=8&mx-pid=595203")[#text("of Meeks and Yau")]#text(" that the infimum here is actually attained, which would mean that there is a incontractible minimal immersed 2-sphere ")#mi("f: S^2 \\to M")#text(" which has area exactly ")#mi("W_2(M)")#text(". However, it suffices for our purposes to use a simpler result that an incontractible minimal 2-sphere ")#mi("f: S^2 \\to M")#text(" of area exactly ")#mi("W_2(M)")#text(" exists which is a ")#emph[#text("branched")]#text(" immersion rather than an immersion, which roughly speaking means that there are a finite number of points in ")#mi("S^2")#text(" where the function f behaves like an embedding of the power function ")#mi("z \\mapsto z^n")#text(" in the neighbourhood of the complex origin. See Lemma 18.10 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(" for details (roughly, one needs to regularise the energy functional to obtain the ")#link("http://en.wikipedia.org/wiki/Palais-Smale_compactness_condition")[#text("Palais-Smale condition")]#text(", then take limits to obtain a weak ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic map")]#text(", using a somewhat crude surgery argument to show that bubbling does not occur in the minimum area limit). For simplicity we shall ignore the effects of branching here; basically, branch points increase the integrated Gauss curvature in the Gauss-Bonnet theorem, but this effect turns out to have a favourable sign and is thus ultimately harmless.")

#text("Now suppose that ")#mi("t \\mapsto (M,g(t))")#text(" is a Ricci flow for t in some time interval I. Suppose that t lies in I but is not the right endpoint of I. Then we have an incontractible minimal 2-sphere ")#mi("f: S^2 \\to M")#text(" of area ")#mi("W_2(M(t))")#text(" which is a branched immersion; we will suppose that it is an immersion for simplicity. Let us now see how the area ")#mi("\\int_{f(S^2)}\\ d\\mu")#text(" of ")#mi("f(S^2)")#text(" changes under Ricci flow. Using the variation formula (19) for the 2-dimensional measure ")#mi("d\\mu")#text(", specialised to Ricci flow, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\frac{d}{dt} \\int_{f(S^2)}\\ d\\mu = - \\int_{f(S^2)}\\ \\text{tr}_h( \\text{Ric}^{(M)} ) d\\mu")]]

#text("where ")#mi("\\text{Ric}^{(M)}")#text(" is the Ricci curvature of the 3-manifold M, and h is the 2-dimensional metric formed by restricting g to ")#mi("f(S^2)")#text(". We now apply the following identity:")

#strong[#text("Exercise 4. ")]#text("Show that ")#mi("\\text{tr}_h( \\text{Ric}^{(M)} ) = K_{f(S^2)} + \\frac{1}{2} R")#text(", where ")#mi("K_{f(S^2)}")#text(" is the sectional curvature of ")#mi("f(S^2)")#text(" and ")#mi("R")#text(" is the scalar curvature of M. (Hint: use two tangent vectors of ")#mi("f(S^2)")#text(" and one normal vector to build an orthonormal basis, and write the Ricci and scalar curvatures in terms of sectional curvatures.) ")#mi("\\diamond")

#text("Inserting this identity into (12) and using (11), as well as the lower bound ")#mi("R \\geq R_{\\min}")#text(", we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{d}{dt} \\int_{f(S^2)}\\ d\\mu \\leq - 4\\pi - \\frac{1}{2} R_{\\min} \\int_{f(S^2)}\\ d\\mu;")]]

#text("by definition of ")#mi("W_2(M(t))")#text(", we thus conclude the ordinary differential inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{d}{dt} W_2(M(t)) \\leq - 4\\pi - \\frac{1}{2} R_{\\min} W_2(M(t))")]]

#text("in the sense of forward difference quotients.")

#text("This is already enough to obtain a weak version of Theorem 1:")

#strong[#text("Theorem 2.")]#text(" (Non-trivial ")#mi("\\pi_2(M)")#text(" implies finite time singularity) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a Ricci flow on a time interval [0,T) for a compact 3-manifold with ")#mi("\\pi_2(M)")#text(" non-trivial. Then T must be finite.")

#strong[#text("Proof.")]#text(" At time zero, the minimal scalar curvature ")#mi("R_{\\min}(0)")#text(" is of course finite. By rescaling if necessary we may assume ")#mi("R_{\\min}(0) \\geq -1")#text(" (say). Then Proposition 2 of Lecture 3 implies that ")#mi("R_{\\min}(t) \\geq -3/(3+2t)")#text(", and so from (14) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\frac{d}{dt} W_2(M(t)) \\leq - 4\\pi + \\frac{3}{6+4t} W_2(M(t)).")]]

#text("This can be rewritten (by the usual method of ")#link("http://en.wikipedia.org/wiki/Integrating_factor")[#text("integrating factors")]#text(") as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\frac{d}{dt} \\big{\\left( (6+4t)^{-3/4} W_2(M(t)) \\right)} \\leq - 4\\pi (6+4t)^{-3/4}.")]]

#text("Now, the expression ")#mi("4\\pi (6+4t)^{-3/4}")#text(" is divergent when integrated from zero to infinity, while the expression ")#mi("(6+4t)^{-3/4} W_2(M(t))")#text(" is finite and non-negative. These two facts contradict each other if T is infinite, and so T is finite as claimed. ")#mi("\\Box")

#text("Note that this argument in fact gives an explicit upper bound for the time of development of the first singularity, in terms of the minimal Ricci curvature at time zero and minimal area of an immersed sphere at time zero.")

#text("We now briefly discuss how the same arguments can be extended to tackle Ricci flow with surgery, though this discussion will have to be somewhat informal since we have not yet fully defined what surgery is. The basic idea is to ensure that the inequality (14) persists through surgery. In a little more detail, the argument proceeds as follows:")

#enum(start: 1, 
[#text("The first step is to clarify the topological nature of the surgery. It turns out that at each surgery time t, the manifold ")#mi("M(t)")#text(" can be obtained (in the topological category) from ")#mi("M(t-)")#text(" by finding a collection of disjoint 2-spheres in ")#mi("M(t-)")#text(", performing surgery on each 2-sphere to replace it with a pair of disks, then removing all but finitely many of the connected components that are created as a consequence.")],
[#text("At any given time t, let s(t) denote the maximal number of embedded 2-spheres one can place in ")#mi("M(t)")#text(" which are ")#emph[#text("homotopically essential")]#text(" in the sense that none of these spheres can be contracted to a point, or deformed to any other sphere. It is possible to use homological arguments and ")#link("http://en.wikipedia.org/wiki/Seifert%E2%80%93van_Kampen_theorem")[#text("van Kampen’s theorem ")]#text("to show that s(t) is always finite.")],
[#text("By homotopy theory, one can show that every time a surgery involves at least one homotopically essential sphere, the quantity s(t) decreases by at least one. Thus, after a finite number of surgeries, all spheres involved in surgery are contractible to a point. By shifting the time variable if necessary, we may thus assume that the above claim is true for all times ")#mi("t \\geq 0")#text(".")],
[#text("Once all spheres involved in surgery are contractible, one can show that whenever surgery is applied to a connected manifold, either the manifold is removed completely, or one of the post-surgery components is homotopy equivalent to the original manifold, and the rest are homotopy spheres. In particular, if a connected manifold has non-trivial ")#mi("\\pi_2")#text(" before surgery, then it is either removed by surgery, or one of the post-surgery components has the same ")#mi("\\pi_2")#text("; and if a connected manifold has trivial ")#mi("\\pi_2")#text(" then all post-surgery components do also. Thus if Theorem 1 fails, one can find a “path of components” through the Ricci flow with surgery with non-trivial ")#mi("\\pi_2")#text(" for all time. We now restrict attention to this path of components, which by abuse of notation we shall continue to call M(t) at each time t.")],
[#text("Using the geometric properties of the surgery and standard limiting arguments, we can show that if ")#mi("R_{\\min}")#text(" is non-positive before surgery, then it cannot decrease as a consequence of surgery (thus ")#mi("R_{\\min}(t) \\geq \\lim_{t^{\\prime} \\to t^-} R_{\\min}(t^{\\prime})")#text(", and similarly if ")#mi("R_{\\min}")#text(" is non-negative before surgery, then it stays non-negative after surgery (here we adopt the convention that ")#mi("R_{\\min} = +\\infty")#text(" when the manifold is empty). These facts are ultimately because surgery is only performed in regions of high positive curvature. From this, one can conclude (assuming the initial normalisation ")#mi("R_{\\min}(0) \\ge -1")#text(" that the bound ")#mi("R_{\\min}(t) \\geq -3/(3+2t)")#text(" persists even after surgery.")],
[#text("Finally, using the geometric properties of the surgery and standard limiting arguments, one can show that ")#mi("W_2(M(t))")#text(" has no upward jump discontinuity at surgery times t in the sense that ")#mi("W_2(M(t)) \\leq \\liminf_{t^{\\prime} \\to t^-} W_2(M(t^{\\prime}))")#text(". This allows us to repeat the proof of Theorem 2 and obtain the desired contradiction to prove Theorem 1.")]
)

#text("Further details can be found in Section 18.12 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(", and I will hopefully return to this matter later in the course.")

#text("[")#emph[#text("Update")]#text(", April 13: minor corrections.]")

#text("[")#emph[#text("Update")]#text(", April 15: Condition about no embedded ")#mi("\\Bbb{RP}^2")#text(" with trivial normal bundle added.]")

#text("[")#emph[#text("Update")]#text(", April 17: Behaviour of ")#mi("\\pi_2")#text(" with respect to surgery clarified.]")

#text("[Update, May 7: Meeks-Yau reference added; thanks to Sylvain Maillot for this correction (as well as various corrections to other lectures).]")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2a7319b4c813add912eb7cbcb445bb0501c65e22a0d20ccf3125e288439487-15e66ce58b68b90fe19e4e74be7b94f81a691f4d226a6d01999f4f5193efe092.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedfan")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-28881")[#strong[#text("fedfan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2008")])]

#text("A slightly off topic question Professor Tao: what references do you suggest")#linebreak()#text(" for the basic theory of Riemannian manifolds?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wenwen")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-28897")[#strong[#text("wenwen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2008")])]

#text("Dear Terry,")#linebreak()#text(" Some possible typo s:")#linebreak()#text(" 1. 3rd line of the proof of Prop2, h^\\dot =L_Z g instead of h^\\dot =L_X g")#linebreak()#text(" 2. 4th line of the proof of Prop2, By equation (19) instead of (15)")

#text("One question about theorem 2 is that, for Sacks-Uhlenbeck, we don’t need a vanishing \\pi_2 to construct minimal branched sphere. So can we remove this assumption in theorem 2?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Sanders")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-28933")[#strong[#text("Andy Sanders")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2008")])]

#text("Prof Tao,")

#text("Just a quick typo, in the proof of theorem 2 I think you want to say, “These two facts contradict….” But I find myself significantly more confused by what this contradiction is. It seems that none of the expressions on the right hand sides, (15) and what follows, are non-negative. Could you clarify the conclusion of this proof?")

#text("On another note, I’m curious where you found this nice analytic proof of Gauss Bonnet for S^2. It appears to be genuinely different, in quite a pretty and concise way, than other proofs I have seen.")

#text("Thanks,")#linebreak()#text(" Andy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-28966")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2008")])]

#text("Dear all: thanks for the corrections! (There was a bizarre formatting error in Theorem 2 that was making it read strangely, but it’s finally fixed now.)")

#text("As for the analytic proof of Gauss-Bonnet, I’m sure it must be folklore, but I simply computed the first variation (i.e. the derivative) of the expression ")#mi("\\int_\\Sigma K\\ d\\mu")#text(" (which, ")#emph[#text("a fortiori")]#text(", must vanish if Gauss-Bonnet is true), and indeed everything canceled out (as it must). More generally, the trick of proving an integral identity by taking a first variation tends to reduce matters (after doing all the obvious integration by parts) to establishing a ")#emph[#text("pointwise")]#text(" identity, which can usually be verified in finite time by pure algebra (assuming that the integrand consisted entirely of local terms, and that there are no ambient constraint equations).")

#text("As for books, I am using Petersen’s “Riemannian Geometry”, though I am somewhat biased because I have the advantage of having Peter Petersen sitting in my class to answer questions as I teach this course. I also have profitably used Chavel’s book and Jost’s book in the past, as well as some general relativity texts that also cover (pseudo-)Riemannian geometry, though I am not relying on them currently.")

#text("As for the question about trivial ")#mi("\\pi_2")#text(", I would believe in this case that there might not be any non-trivial minimal spheres; as far as I am aware, Sacks-Uhlenbeck theory only applies to spheres that are not contractible to a point, and of course such spheres do not exist when ")#mi("\\pi_2(M)")#text(" is trivial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wenwen")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-28977")[#strong[#text("wenwen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2008")])]

#text("In fact, the Sacks-Uhlenbeck stuff works for trivial ")#mi("\\pi_2")#text(". For example, let’s take ")#mi("S^3")#text(" (we know ")#mi("\\pi_2(S^3)=1")#text(". But the standard embedding of ")#mi("S^2")#text(" is a “maximal” sphere (so is minimal).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Sanders")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-28999")[#strong[#text("Andy Sanders")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2008")])]

#text("Thanks for the clarifications.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 5: Finite time extinction of the third homotopy group, I. « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-29062")[#strong[#text("285G, Lecture 5: Finite time extinction of the third homotopy group, I. « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2008")])]

#text("[…] the previous lecture, we saw that Ricci flow with surgery ensures that the second homotopy group became extinct in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-29063")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2008")])]

#text("Dear wenwen,")

#text("Ah, now I see what you’re saying. (I was thinking of “minimal surface” as necessarily being a local minimiser of the area functional, when instead it is usually defined as merely being a critical point of that functional, i.e. zero mean curvature.) The key inequality (13) still holds for such surfaces, but it does not lead to the inequality (14) for the width functional ")#mi("W_2(t)")#text(". However, one can use (13) for such surfaces to obtain a similar inequality for another width functional ")#mi("W_3(t)")#text(", which is defined whenever one has non-trivial ")#mi("\\pi_3")#text(" (rather than non-trivial ")#mi("\\pi_2")#text("); this is discussed in the Lecture 5 notes which I’ve just uploaded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-29142")[#strong[#text("285G, Lecture 6: Finite time extinction of the third homotopy group, II « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2008")])]

#text("[…] Lecture 4, we studied minimal immersed spheres into a three-manifold, and how their area varied with respect […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-29227")[#strong[#text("285G, Lecture 7: Rescaling of Ricci flows and kappa-noncollapsing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2008")])]

#text("[…] 2 and are also supercritical. Thus the various bounds we have on these quantities from Lectures 4, 5, 6 do not directly tell us anything about asymptotic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-29312")[#strong[#text("285A, Lecture 8: Ricci flow as a gradient flow, log-Sobolev inequalities, and Perelman entropy « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2008")])]

#text("[…] (we have already exploited this fact to prove the Gauss-Bonnet formula, see Proposition 1 from Lecture 4). More generally, we recover see from (10) the fact (well known in general relativity) that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-30139")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] 1 near infinity. But this means that , contradicting the Gauss-Bonnet formula (Proposition 1 from Lecture 4). Thus Case 3 cannot in fact […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/11/285g-lecture-4-finite-time-extinction-of-the-second-homotopy-group/#comment-30176")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] to be instead of the quotient . Then we observe from the Gauss-Bonnet theorem (Proposition 1 from Lecture 4) that , and hence by the volume variation formula (equation (33) from Lecture 1) the volume is […]")
]
