// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/
// Converted to Typst by tao2typ: "2026-10-14T08:50:19.716517+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reading seminar 5: “Stable group theory and approximate subgroups”, by Ehud Hrushovski", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reading seminar 5: “Stable group theory and approximate subgroups”, by Ehud Hrushovski")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/")[#text("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("After a one-week hiatus, we are resuming our ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("reading seminar")]#text(" of the ")#link("http://arxiv.org/abs/0909.2190")[#text("Hrushovski paper")]#text(". This week, we are taking a break from the paper proper, and are instead focusing on the subject of ")#emph[#text("stable theories")]#text(" (or more precisely, ")#emph[#mi("{\\omega}")#text("-stable theories")]#text("), which form an important component of the general model-theoretic machinery that the Hrushovski paper uses. (Actually, Hrushovski’s paper needs to work with more general theories than the stable ones, but apparently many of the tools used to study stable theories will generalise to the theories studied in this paper.)")

#text("Roughly speaking, stable theories are those in which there are “few” definable sets; a classic example is the theory of algebraically closed fields (of characteristic zero, say), in which the only definable sets are boolean combinations of algebraic varieties. Because of this paucity of definable sets, it becomes possible to define the notion of the ")#emph[#text("Morley rank")]#text(" of a definable set (analogous to the dimension of an algebraic set), together with the more refined notion of ")#emph[#text("Morley degree")]#text(" of such sets (analogous to the number of top-dimensional irreducible components of an algebraic set). Stable theories can also be characterised by their inability to order infinite collections of elements in a definable fashion.")

#text("The material here was presented by ")#link("http://www.math.ucla.edu/~anush/")[#text("Anush Tserunyan")]#text("; her notes on the subject ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/11/w-stable-theories1.pdf")[#text("can be found here")]#text(". Let me also repeat the previous list of resources on this paper (updated slightly):")

#list(
[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/11/hrushovskinotesb.pdf")[#text("Henry Towsner’s notes")]#text(" (which most of Notes 2-4 have been based on; updated to remove references to homogeneity, using only countable saturation);")],
[#link("http://www.math.ucla.edu/~alexus/papers/talks/udi1.pdf")[#text("Alex Usvyatsov’s notes")]#text(" on the derivation of Corollary 1.2 (broadly parallel to the notes here);")],
[#link("http://www.math.uiuc.edu/~vddries/approx.pdf")[#text("Lou van den Dries’ notes")]#text(" (covering most of what we have done so far, and also material on stable theories); and")],
[#link("https://terrytao.wordpress.com/2009/10/22/reading-seminar-2-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovski/#comment-42065")[#text("Anand Pillay’s sketch")]#text(" of a simplified proof of Theorem 1.1.")]
)

#metadata(none) <tao-05df51055c58f6a60710>

#strong[#text(" — 1. Stable theories — ")]

#text("Let ")#mi("{L}")#text(" be a countable language. Recall that if we have a structure ")#mi("{M}")#text(" for ")#mi("{L}")#text(", and a set ")#mi("{A}")#text(" of constants in ")#mi("{M}")#text(", we can define an (")#mi("{n}")#text("-ary) ")#emph[#text("type")]#text(" of ")#mi("{M}")#text(" over ")#mi("{A}")#text(" to be a maximal consistent family ")#mi("{p}")#text(" of formulae ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" for an ")#mi("{n}")#text("-tuple ")#mi("{\\vec x = (x_1,\\ldots,x_n)}")#text(", where the formulae are allowed to use ")#mi("{A}")#text(" as constants. For instance, in the language of algebraically closed fields over some base field ")#mi("{k}")#text(" (all elements of which are constants in ")#mi("{L}")#text("), if ")#mi("{M}")#text(" is an algebraic closed field and ")#mi("{A}")#text(" is empty, the type associated to a “generic” element of an algebraic variety ")#mi("{V \\subset M^n}")#text(" defined over ")#mi("{k}")#text(" (i.e. elements that obey the defining equations for ")#mi("{k}")#text(", but do not obey any other algebraic relations over ")#mi("{k}")#text(") is a type. If one makes ")#mi("{A}")#text(" non-empty, then one now also needs to consider algebraic relations over ")#mi("{k(A)}")#text(", the field formed by adjoining ")#mi("{A}")#text(" to ")#mi("{k}")#text(". Note that in general, a type will not be realised in the structure ")#mi("{M}")#text(" (unless that structure is so huge as to be ")#emph[#text("saturated")]#text(" over the cardinality of ")#mi("{A}")#text("), but can always be realised in some extension of ")#mi("{M}")#text(", by the completeness theorem.")

#text("The set of all ")#mi("{n}")#text("-ary types of ")#mi("{M}")#text(" over ")#mi("{A}")#text(" is denoted ")#mi("{S_n^M(A)}")#text(". It has a natural topology, the ")#emph[#text("Stone topology")]#text(", whose basic open (in fact, clopen) sets are given by ")#mi("{U_\\phi := \\{ p \\in S_n^M(A): \\phi \\in p \\}}")#text(" for any formula ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" defined over ")#mi("{A}")#text(". This makes the space of types a Stone space (totally disconnected, Hausdorff, compact).")

#text("In general, the number of types in the world can be quite large: if ")#mi("{A}")#text(" has cardinality ")#mi("{\\kappa}")#text(" for some infinite ")#mi("{\\kappa}")#text(", then the total number of formulae in ")#mi("{L(A)}")#text(" is also ")#mi("{\\kappa}")#text(", so the number of types could conceivably be as large as ")#mi("{2^\\kappa}")#text(". But for a special class of theories – the ")#emph[#mi("{\\kappa}")#text("-stable theories")]#text(" – the number is much smaller:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" Let ")#mi("{\\kappa}")#text(" be an infinite cardinal. A complete theory ")#mi("{T}")#text(" is ")#emph[#mi("{\\kappa}")#text("-stable")]#text(" if, for any structure ")#mi("{M}")#text(" satisfying ")#mi("{T}")#text(", and any set ")#mi("{A}")#text(" of constants in ")#mi("{M}")#text(" of cardinality at most ")#mi("{\\kappa}")#text(", the set of ")#mi("{n}")#text("-ary types of ")#mi("{M}")#text(" over ")#mi("{A}")#text(" is at most ")#mi("{\\kappa}")#text(" for every ")#mi("{n}")#text(".")
]

#text("The classic example of a ")#mi("{\\kappa}")#text("-stable theory (for any infinite ")#mi("{\\kappa}")#text(") is the theory of algebraically closed fields with fixed characteristic (it is a classical theorem that this theory is complete, basically thanks to quantifier elimination). By quantifier elimination (or by many applications of the nullstellensatz), one can show that the ")#mi("{n}")#text("-ary types in this theory over ")#mi("{A}")#text(" are in one-to-one correspondence with minimal ideals in ")#mi("{F(x_1,\\ldots,x_n)}")#text(", where ")#mi("{F = k(A)}")#text(", where ")#mi("{k}")#text(" is the base field of given characteristic, with a type ")#mi("{p}")#text(" consisting of the “generic” points cut out by the ideal ")#mi("{I := \\{ f \\in F(x_1,\\ldots,x_n): (f(x_1,\\ldots,x_n)=0) \\in p \\}}")#text(". More succinctly, ")#mi("{S_n^M(A) \\equiv Spec(F(x_1,\\ldots,x_n))}")#text(". By Hilbert’s basis theorem, all ideals in ")#mi("{F(x_1,\\ldots,x_n)}")#text(" are finitely generated, and so the cardinality of types is easily seen to be at most ")#mi("{\\kappa}")#text(".")

#text("When ")#mi("{\\kappa}")#text(" is uncountable, a more general example of a ")#mi("{\\kappa}")#text("-stable theory is that of a ")#emph[#mi("{\\kappa}")#text("-categorical")]#text(" theory – a theory such that any two models of cardinality ")#mi("{\\kappa}")#text(" are isomorphic. (Details can be found in Anush’s notes.)")

#text("The classic example of a theory which is ")#emph[#text("not")]#text(" ")#mi("{\\kappa}")#text("-stable is the theory of dense linear orderings, i.e. the theory of the rationals ")#mi("{{\\mathbb Q}}")#text(" with the order relation ")#mi("{<}")#text(". Using Dedekind cuts, one can associate a type in ")#mi("{S_1^{\\mathbb Q}({\\mathbb Q})}")#text(" to every real number, and so there are uncountably many types here even though the number of constants is countable. Thus this theory is not ")#mi("{\\omega}")#text("-stable (though it is ")#mi("{\\omega}")#text("-categorical).")

#text("Now we look at alternate characterisations of stability, particularly ")#mi("{\\omega}")#text("-stability. If ")#mi("{M}")#text(" is a model of a theory ")#mi("{T}")#text(" in a language ")#mi("{L}")#text(", define a ")#emph[#text("binary tree")]#text(" in ")#mi("{M}")#text(" to be a collection ")#mi("{\\phi_s(x_1,\\ldots,x_n)}")#text(" of ")#mi("{n}")#text("-ary formulas in ")#mi("{L(M)}")#text(", where ")#mi("{s}")#text(" are indexed by finite strings of ")#mi("{0}")#text("s and ")#mi("{1}")#text("s, each of which are consistent with ")#mi("{T}")#text(", and such that for any string ")#mi("{s}")#text(" and its two children ")#mi("{s0}")#text(" and ")#mi("{s1}")#text(", the formulae ")#mi("{\\phi_{s0}}")#text(" and ")#mi("{\\phi_{s1}}")#text(" cut out disjoint subsets of the set cut out by ")#mi("{\\phi_s}")#text(" relative to ")#mi("{T}")#text(", or more precisely that ")#mi("{\\phi_{s0},\\phi_{s1}}")#text(" are mutually inconsistent in ")#mi("{T}")#text(", but both imply ")#mi("{\\phi_s}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" For a countable language ")#mi("{L}")#text(" and a complete theory ")#mi("{T}")#text(", the following are equivalent:")

#list(
[#text("(i) No binary tree of formulae exists for any model ")#mi("{M}")#text(" of ")#mi("{T}")#text(".")],
[#text("(ii) ")#mi("{T}")#text(" is ")#mi("{\\kappa}")#text("-stable for every infinite ")#mi("{\\kappa}")#text(";")],
[#text("(iii) ")#mi("{T}")#text(" is ")#mi("{\\omega}")#text("-stable.")]
)
]

#emph[#text("Proof:")]#text(" (ii) trivially implies (iii). Now we show that (i) implies (ii), i.e. we take a theory which is not ")#mi("{\\kappa}")#text("-stable for some infinite ")#mi("{\\kappa}")#text(" and use it to create a binary tree.")

#text("By hypothesis, we can find a model ")#mi("{M}")#text(" and a set ")#mi("{A}")#text(" of constants of cardinality at most ")#mi("{\\kappa}")#text(", and an ")#mi("{n}")#text(" such that the number of ")#mi("{n}")#text("-ary types exceeds ")#mi("{\\kappa}")#text(". We can use this to create a binary tree as follows. Call a formula ")#mi("{\\phi(x_1,\\ldots,x_n)}")#text(" defined over ")#mi("{A}")#text(" ")#emph[#text("large")]#text(" if it is contained in more than ")#mi("{\\kappa}")#text(" types (i.e. if ")#mi("{U_\\phi}")#text(" has cardinality more than ")#mi("{\\kappa}")#text("), and ")#emph[#text("small")]#text(" types; thus in particular any tautology is large. We set the root ")#mi("{\\phi_\\emptyset}")#text(" of the binary tree to be such a large formula. We then remove all the types associated to small formulae from ")#mi("{U_{\\phi_\\emptyset}}")#text(", and still retain more than ")#mi("{\\kappa}")#text(" types. Picking two such distinct types ")#mi("{p,q}")#text(", one can find a formula ")#mi("{\\psi}")#text(" separating ")#mi("{p}")#text(" from ")#mi("{q}")#text(" (since ")#mi("{p \\neq q}")#text("), which allows one to find two formulae ")#mi("{\\phi_1, \\phi_2}")#text(" which are inconsistent with each other and imply ")#mi("{\\phi_\\emptyset}")#text(" (namely ")#mi("{\\phi \\wedge \\neg \\psi}")#text(" and ")#mi("{\\phi_\\emptyset \\wedge \\neg \\psi}")#text("); by construction, these formulae are also large. Iterating this procedure gives the binary tree.")

#text("Finally, to show (iii) implies (i), we see from taking Dedekind cuts again that an infinite binary tree can be used to define an uncountable number of types (by including all the formulae to the left of a cut, excluding all the ones to the right, and then completing to a complete type), which violates ")#mi("{\\omega}")#text("-stability. ")#mi("\\Box")

#text("The property of not having binary trees is also known as being ")#emph[#text("totally transcendental")]#text(", though it was unclear where this terminology came from (especially given that the theory of algebraically closed fields is the classic example of a totally transcendental theory).")

#text("We have seen that order theories tend to be unstable. Indeed, ")#mi("{\\omega}")#text("-stable theories is that they are unable to definably order infinite sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" ")#metadata(none) <tao-6bde0b830d8bd56dea61>#text(" Let ")#mi("{T}")#text(" be an ")#mi("{\\omega}")#text("-stable theory, let ")#mi("{M}")#text(" be a model of ")#mi("{T}")#text(", and let ")#mi("{X}")#text(" be an infinite subset of ")#mi("{M}")#text(". Then there is no definable relation ")#mi("{<}")#text(" in ")#mi("{L}")#text(" that is a total ordering on ")#mi("{X}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose this is not the case. Using the compactness theorem, we can thus find a model of ")#mi("{M}")#text(" with a countably infinite subset ")#mi("{X}")#text(" for which ")#mi("{<}")#text(" endows ")#mi("{X}")#text(" with the order structure of the rationals. But then by Dedekind cuts one can then create an uncountable number of types over ")#mi("{X}")#text(", contradicting ")#mi("{\\omega}")#text("-stability. ")#mi("\\Box")

#text("It is easy to generalise ")#mi("{\\omega}")#text("-stability in the above theorem to ")#mi("{\\kappa}")#text("-stability for any infinite ")#mi("{\\kappa}")#text(", by developing analogues of the rational order structure for other cardinalities; see Anush’s notes.")

#text("There was some debate as to whether the theory of the ")#link("http://en.wikipedia.org/wiki/Rado_graph")[#text("Rado graph")]#text(" admitted any obvious definable total ordering on a countable set, but the discussion was inconclusive.")

#strong[#text(" — 2. Stability and indiscernability — ")]

#text("Recall from previous notes that a sequence ")#mi("{x_1,x_2,\\ldots}")#text(" of elements of a structure ")#mi("{M}")#text(" were ")#emph[#text("order-indiscernible")]#text(" if all of the ")#mi("{k}")#text("-tuples ")#mi("{(x_{i_1},\\ldots,x_{i_k})}")#text(" with ")#mi("{i_1<\\ldots<i_k}")#text(" were elementarily indistinguishable from each other (i.e. every formula obeyed by one tuple, is obeyed by all the other tuples). One can use Ramsey-theoretic methods to generate a plentiful supply of order-indiscernibles.")

#text("One would however like a stronger notion of indiscernability, which we will just call ")#emph[#text("indiscernability")]#text(", in which ")#emph[#text("all")]#text(" ")#mi("{k}")#text("-tuples ")#mi("{(x_{i_1},\\ldots,x_{i_k})}")#text(" with ")#mi("{i_1,\\ldots,i_k}")#text(" distinct (but not necessarily ordered) are indistinguishable. In general, order indiscernability does not imply indiscernability. But because stable theories cannot “see” order, one has equivalence in this case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" In an ")#mi("{\\omega}")#text("-stable theory, every order-indiscernible sequence is indiscernible.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{x_1,x_2,\\ldots}")#text(" be order-indiscernible in some model ")#mi("{M}")#text(". To show indiscernibility, it suffices to show that permutations of ")#mi("{(x_{i_1},\\ldots,x_{i_k})}")#text(" are indistinguishable from each other. As permutations are generated by adjacent transpositions, it suffices to do this for adjacent transpositions. For notational simplicity we will just show that ")#mi("{(x_1,x_2)}")#text(" and ")#mi("{(x_2,x_1)}")#text(" are indistinguishable; the general case is similar.")

#text("Suppose this is not the case, thus there is a formula ")#mi("{\\phi}")#text(" such that ")#mi("{\\phi(x_1,x_2)}")#text(" holds in ")#mi("{M}")#text(" but ")#mi("{\\phi(x_2,x_1)}")#text(" fails. Then ")#mi("{\\phi(x_i,x_j)}")#text(" holds precisely when ")#mi("{i < j}")#text(", thus ")#mi("{\\phi}")#text(" orders ")#mi("{x_1,x_2,\\ldots}")#text(", contradicting the previous theorem.")

#text("(In the general case, one cannot quite use Theorem ")#link(<tao-6bde0b830d8bd56dea61>)[#text("3")]#text(" directly, but one can modify the proof to achieve a similar result; see Anush’s notes.) ")#mi("\\Box")

#text("By the previous remarks, the argument can also be extended to ")#mi("{\\kappa}")#text("-stable theories for any infinite ")#mi("{\\kappa}")#text(".")

#strong[#text(" — 3. Morley rank and degree — ")]

#text("Suppose one was working in the theory of algebraically closed fields of characteristic zero, and wanted to define the notion of the dimension of an algebraic set ")#mi("{V}")#text(". Clearly, one would want finite sets to have dimension ")#mi("{0}")#text(", and to be the only sets with this property. As for infinite sets, one could recursively define dimension by enforcing the following statement: an algebraic set has dimension at least ")#mi("{\\alpha+1}")#text(" if and only if it contains infinitely many disjoint algebraic sets of dimension at least ")#mi("{\\alpha}")#text(".")

#text("One can do the same for any theory, assigning to each definable set in a structure ")#mi("{M}")#text(" a ")#emph[#text("Morley rank")]#text(", which is either ")#mi("{-1}")#text(", an ordinal, or ")#mi("{\\infty}")#text(" (which we consider to be larger than all the ordinals (!)) by the following rules:")

#list(
[#text("The empty set has Morley rank ")#mi("{-1}")#text("; all other definable sets have Morley rank at least ")#mi("{0}")#text(".")],
[#text("If ")#mi("{\\alpha}")#text(" is an ordinal, then a definable set has Morley rank at least ")#mi("{\\alpha+1}")#text(" if and only if it contains infinitely many disjoint definable sets of Morley rank at least ")#mi("{\\alpha}")#text(".")]
)

#text("Note that for a limit ordinal ")#mi("{\\alpha}")#text(", a set will have Morley rank at least ")#mi("{\\alpha}")#text(" iff it has Morley rank at least ")#mi("{\\beta}")#text(" for all ")#mi("{\\beta < \\alpha}")#text(", and a set will have Morley rank ")#mi("{\\infty}")#text(" if it has Morley rank at least ")#mi("{\\alpha}")#text(" for every ordinal ")#mi("{\\alpha}")#text(". Using this, one can show by transfinite induction that every definable set has a Morley rank.")

#text("The Morley rank of a formula ")#mi("{\\phi}")#text(" cutting out a definable set in a structure ")#mi("{M}")#text(" may depend on the choice of structure ")#mi("{M}")#text(". However, if we assume that the structure ")#mi("{M}")#text(" is ")#emph[#text("countably saturated")]#text(", i.e. that any finitely satisfiable collection of formulae involving at most countably many constants is fully satisfiable, then the dependence on ")#mi("{M}")#text(" largely disappears. To see this, we first need a preliminary lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" Let ")#mi("{M}")#text(" be countably saturated, and let ")#mi("{A_a}")#text(" be a definable set depending on a parameter ")#mi("{a}")#text(". Then the Morley rank of ")#mi("{A_a}")#text(" in ")#mi("{M}")#text(" depends only on the type of ")#mi("{a}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{a, b}")#text(" have the same type (i.e. they are elementarily indistinguishable). We need to show that ")#mi("{A_a}")#text(", ")#mi("{A_b}")#text(" have the same Morley rank. Suppose not. If ")#mi("{A_a}")#text(" was empty, then ")#mi("{A_b}")#text(" would be also by indistinguishability, and the claim is obvious; so suppose that both sets are non-empty. Then, without loss of generality, we may assume that ")#mi("{A_a}")#text(" has Morley rank ")#mi("{\\alpha}")#text(" but ")#mi("{A_b}")#text(" has Morley rank at least ")#mi("{\\alpha+1}")#text(", thus ")#mi("{A_b}")#text(" contains a countable family of disjoint definable sets ")#mi("{B_{b,c_1}, B_{b,c_2}, \\ldots}")#text(" of Morley rank at least ")#mi("{\\alpha}")#text(" defined using some constants ")#mi("{c_1, c_2, \\ldots}")#text(". Using countable saturation, one can find inductively constants ")#mi("{d_1,d_2,\\ldots}")#text(" such that ")#mi("{(a,d_1,\\ldots,d_m)}")#text(" has the same type as ")#mi("{(b,c_1,\\ldots,c_m)}")#text(" for every ")#mi("{m}")#text(". This creates a countable family of djsoint definable sets ")#mi("{B_{a,d_1},B_{a,d_2},\\ldots}")#text(" of ")#mi("{A_a}")#text(", which by an induction hypothesis on ")#mi("{\\alpha}")#text(" can be assumed to have Morley rank at least ")#mi("{\\alpha}")#text(", which forces ")#mi("{A_a}")#text(" to have Morley rank at least ")#mi("{\\alpha+1}")#text(", a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" If ")#mi("{M}")#text(" is countably saturated, and ")#mi("{\\phi_a}")#text(" is a formula defined using some constants ")#mi("{a}")#text(" in ")#mi("{M}")#text(", then the Morley rank of ")#mi("{\\phi_a}")#text(" in ")#mi("{M}")#text(" is equal to the Morley rank of ")#mi("{\\phi_a}")#text(" in ")#mi("{N}")#text(", for any elementary extension ")#mi("{N}")#text(" of ")#mi("{M}")#text(".")
]

#emph[#text("Proof:")]#text(" It is easy to see by transfinite induction that the Morley rank in ")#mi("{N}")#text(" is at least as large as that of ")#mi("{M}")#text(" (there are more non-empty definable sets). Suppose for contradiction that the Morley rank in ")#mi("{M}")#text(" is ")#mi("{\\alpha}")#text(", but the Morley rank in ")#mi("{N}")#text(" is at least ")#mi("{\\alpha+1}")#text(". (The case when ")#mi("{\\phi_a}")#text(" cuts out an empty set in ")#mi("{M}")#text(" or ")#mi("{N}")#text(" is trivial from elementary equivalence.) Then the set ")#mi("{\\phi_a(N)}")#text(" cut out by ")#mi("{\\phi_a}")#text(" in ")#mi("{N}")#text(" contains a countable family of disjoint definable sets ")#mi("{\\psi_{a,b_1}(N), \\psi_{a,b_2}(N), \\ldots}")#text(" of Morley rank at least ")#mi("{\\alpha}")#text(", for some ")#mi("{b_1, b_2, \\ldots}")#text(" in ")#mi("{N}")#text(". By elementary equivalence and countable saturation, one can inductively find ")#mi("{c_1,c_2,\\ldots}")#text(" in ")#mi("{M}")#text(" such that the type of ")#mi("{(a,c_1,\\ldots,c_m)}")#text(" in ")#mi("{M}")#text(" equals the type of ")#mi("{(a,b_1,\\ldots,b_m)}")#text(" in ")#mi("{N}")#text(". Then ")#mi("{\\psi_{a,c_1}(M), \\psi_{a,c_2}(M), \\ldots}")#text(" form a countable family of disjoint definable sets in ")#mi("{\\phi_a(M)}")#text(", which have Morley rank at least ")#mi("{\\alpha}")#text(" by the previous lemma, giving the desired contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7")]#text(" If ")#mi("{N_0, N_1}")#text(" are countably saturated elementary extensions of ")#mi("{M}")#text(", and ")#mi("{\\phi_a}")#text(" is a formula defined using some constants ")#mi("{a}")#text(" in ")#mi("{M}")#text(", then the Morley rank of ")#mi("{\\phi_a}")#text(" in ")#mi("{N_0}")#text(" is the same as that in ")#mi("{N_1}")#text(".")
]

#emph[#text("Proof:")]#text(" Take a common countably saturated elementary extension ")#mi("{N}")#text(" of both ")#mi("{N_0}")#text(" and ")#mi("{N_1}")#text("; by the previous corollary, the rank in ")#mi("{N_0}")#text(" or in ")#mi("{N_1}")#text(" is equal to that in ")#mi("{N}")#text(". ")#mi("\\Box")

#text("We can thus define the (structure-independent) Morley rank of any formula ")#mi("{\\phi}")#text(" in ")#mi("{M}")#text(" to be the rank of ")#mi("{\\phi}")#text(" in any countably saturated elementary extension.")

#text("It is not hard to show that Morley rank obeys the basic properties of a dimension, e.g. the dimension of a union is the larger of the dimensions of the two summands (in particular, Morley rank is monotone with respect to set inclusion), and that the only sets of dimension zero are the finite sets.")

#text("To avoid technical issues, let us now assume that all models ")#mi("{M}")#text(" we work in are small elementary submodels of a universal model ")#mi("{{\\Bbb M}}")#text(" (i.e. a model which is saturated with respect to all small models).")

#text("We know that any set of a given Morley rank ")#mi("{\\alpha}")#text(" cannot be partitioned into infinitely many disjoint subsets of the same rank. Using this and ")#link("http://en.wikipedia.org/wiki/K%C3%B6nig's_lemma")[#text("König’s lemma")]#text(", we in fact conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" If a definable set ")#mi("{A}")#text(" has an ordinal Morley rank ")#mi("{\\alpha}")#text(", then there exists a finite ")#mi("{d}")#text(" such that ")#mi("{A}")#text(" cannot be partitioned into more than ")#mi("{d}")#text(" definable subsets of Morley rank ")#mi("{\\alpha}")#text(".")
]

#emph[#text("Proof:")]#text(" We form a partial binary tree by taking ")#mi("{A}")#text(" and splitting it (if possible) into disjoint non-empty subsets of Morley rank ")#mi("{\\alpha}")#text(", then taking these subsets and splitting them further, continuing until no further splitting is possible. If this tree is infinite, then König’s lemma ensures an infinite path, which easily gives a decomposition of ")#mi("{A}")#text(" into infinitely many disjoint definable sets of Morley rank ")#mi("{\\alpha}")#text(", a contradiction. Thus this tree is finite, and decomposes ")#mi("{A}")#text(" into some finite number ")#mi("{B_1,\\ldots,B_d}")#text(" of rank ")#mi("{\\alpha}")#text(" definable sets which are “irreducible” in the sense that they cannot be partitioned into two subsets of rank ")#mi("{\\alpha}")#text(".")

#text("We now claim that any other partition ")#mi("{A = C_1 \\cup \\ldots \\cup C_m}")#text(" of ")#mi("{A}")#text(" into rank ")#mi("{\\alpha}")#text(" definable sets must have ")#mi("{m \\leq d}")#text(". Note that for each ")#mi("{B_i}")#text(" there is at most one ")#mi("{C_j}")#text(" for which ")#mi("{B_i \\cap C_j}")#text(" has rank ")#mi("{\\alpha}")#text(", otherwise ")#mi("{B_i}")#text(" would not be irreducible. On the other hand, each ")#mi("{C_j}")#text(" has to have at least one ")#mi("{B_i}")#text(" for which ")#mi("{B_i \\cap C_j}")#text(" had rank ")#mi("{\\alpha}")#text(", for if all the ")#mi("{B_i \\cap C_j}")#text(" had rank less than ")#mi("{\\alpha}")#text(" then ")#mi("{C_j}")#text(" would also. Thus we can assign disjoint non-empty subsets of ")#mi("{\\{1,\\ldots,d\\}}")#text(" to each ")#mi("{j}")#text(" in ")#mi("{\\{1,\\ldots,m\\}}")#text(", which forces ")#mi("{m \\leq d}")#text(". ")#mi("\\Box")

#text("We thus define the ")#emph[#text("Morley degree")]#text(" of ")#mi("{A}")#text(" to be the largest ")#mi("{d}")#text(" for which one can partition ")#mi("{A}")#text(" into disjoint definable sets of the same rank. Note that all such components necessarily have degree ")#mi("{1}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaed0abc7e358133c38f6cdbe201713e4f795ade6b5a9b50d90dc79fc437b7e6-169ed54092edba23e1076ef1642a3d9e616d91a4ba40bded81b3c34d5d4c29e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anush Tserunyan")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42450")[#strong[#text("Anush Tserunyan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2009")])]

#text("Hi Prof. Tao,")

#text("In the end of the proof of Proposition 8, you say that we have an injection from ")#mi("{1,2,...,m}")#text(" to ")#mi("{1,2,...,d}")#text(", but the correspondence may not be a function since for one ")#mi("C_j")#text(" there may be two different ")#mi("B_i")#text("-s having rank ")#mi("\\alpha")#text(" intersections with ")#mi("C_j")#text(". That’s why in the notes I wrote it as a partial function going the other way.")

#text("Thanks,")#linebreak()#text(" Anush")

#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42495")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2009")])]

#text("Dear Terry,")

#text("What did you mean by a definable ordering on a countable set (for the random graph)? There is no definable ordering on a definable subset of ")#mi("M^n")#text(" for any ")#mi("n")#text(". The order property is exemplified by singletons: there are indiscernible sequences a_i, b_j such that R(a_i,b_j) iff i<j. So there is a definable order on an indiscernible sequence of ")#emph[#text("pairs")]#text(": ")#mi("a_ib_i < a_jb_j")#text(" iff ")#mi("R(a_i,b_j)")#text(". If, on the other hand, you take a set of singletons ")#mi("X")#text(", then by quantifier elimination the type of a pair ")#mi("ab \\in X^2")#text(" is determined by whether or not they are R-related (note that any two singletons have the same type), so there is no ordering… One might ask what happens when one works with parameters, but I don't think that this is any different: given an ordering with parameters on an infinite set of singletons ")#mi("X")#text(", one may assume that all the elements have the same type over the parameters, so the type of a pair from ")#mi("X")#text(" is still symmetric.")

#text("Possibly a small suggestion: stability theory can also be done locally (that is, looking at a single formula). Since one basic idea in Udi's paper is that a lot can be done once you have just one stable relation, it might be interesting to develop some of the local theory as well as the global one (global stability theory can be also deduced from the local one, but not e.g. ")#mi("\\omega")#text("-stability, Morley rank, etc).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42529")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Ah, I see now. The relation you define gives rise to orderings on arbitrarily large sets in the random graph itself, and thus to orderings on infinite sets in other models of the random graph (e.g. a nonstandard random graph), but does not order any definable sets. Thanks!")

#text("I personally don’t understand stability well enough yet to comment intelligently on your suggestion, but hopefully it will become clearer what the minimal amount of stability theory tools are needed to get Hrushovski’s results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf86ac8ecae9e26bf07c8e66663f0823c01854bb67d4edcb9b3e1679c4ff182d-d586dace0f88eaf8b2db08e6bd57f5b9514bf017ad795affe372f68b23e936de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Usvyatsov")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42551")[#strong[#text("Alex Usvyatsov")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2009")])]

#text("Oh, I understand you question now (I think). You are asking whether the random graph is an unstable ")#emph[#text("structure")]#text(", that is, whether there is an infinite subset of the random graph itself which is definably ordered. The short answer is yes, but let me elaborate a bit.")

#text("First, although in model theory we normally don’t distinguish between a model and its elementary extensions when it comes to properties like stability (just like we often don’t distinguish between a definable order on a subset of the model and a subset of the model to some finite power), these distinctions are sometimes important. There are stable structures with unstable theories (structures in which one can order arbitrarily large finite sets, but no infinite set), and they have certain interesting properties (related to things I have been working on recently, actually). One example is Krivine-Maurey theorem saying that a quantifier-free stable separable Banach space (here stability is of the structure, not the theory; one has to define stability in the right way for this context, but let’s ignore this for a moment) embeds an ")#mi("\\ell_p")#text(" space almost isometrically.")

#text("As for the random graph ")#mi("G")#text(", you can actually find the ordering on pairs I was talking about in the structure itself. There are several related ways of seeing that this has to be the case. First, since ")#mi("G")#text(" is ")#mi("\\omega")#text("-saturated, so if you have an instance of the order property in an elementary extension, you can construct an ordering on an infinite subset of ")#mi("G")#text(" itself by saturation. Second, ")#mi("G")#text(" is ")#mi("\\omega")#text("-categorical; so if you have the order property in an elementary extension, there is such a countable elementary extension, but it is isomorphic to ")#mi("G")#text(". Since ")#mi("\\omega")#text("-categoricity implies ")#mi("\\omega")#text("-saturation, this is in some sense a stronger argument.")

#text("But in this case, the straightforward construction that I mentioned simply works: choose ")#mi("a_i, b_i \\in G")#text(" in by induction such that")

#mi("a_i")#text(" are R-related to ")#mi("b_{<i}")#text(" (that is, to all ")#mi("b_j")#text(" for j<i")#linebreak()#text(" ")#mi("b_i")#text(" is ")#emph[#text("not")]#text(" R-related to ")#mi("a_{<i}")#linebreak()#text(" ")#mi("a_i")#text(" is not R-related to ")#mi("a_{<i}")#text(", same for the b_i's.")

#text("The last clause is somewhat arbitrary, but it ensures that both sequences are indiscernible, so not only do you get a definable ordering on the sequence of pairs, but we have constructed an instance of the order property in ")#mi("G")#text(" itself, no compactness arguments needed.")

#text("Still. it is true that there is no order on definable sets or on infinite sets of singletons.")

#text("The answer to your question about how much stability is actually needed for Hrushovski’s paper is “virtually none”. But local stability can be an illuminating background discussion, just like ")#mi("\\omega")#text("-stability that you have been looking at. If you are currently mostly interested in stable group theory (e.g. existence of stabilizers), then ")#mi("\\omega")#text("-stability is a simpler framework (due to the existence of Morley rank), and possibly a better choice. But if you would also like to see some general model theoretic properties of stable theories (such as definability of types), I personally would recommend the local approach. The very beginning of Pillay’s book “Geometric stability theory” is a good source.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fac69da6e0d794f94685ad10f6056e814925fc9d3cab80d129eafcc5ddb8900-48e515fdfd57683800ffc1868c65fc6d183f828e5232a5712a04c4bec4097fdc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonard")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42505")[#strong[#text("Leonard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Hi Prof. Tao,")

#text("It’s interesting to note that all the tools which your reading group has discussed so far are sufficient to develop a proof of Morley’s Categoricity Theorem, which states that a complete theory in a countable language is k-categorical for all uncountable cardinals k if and only if it is l-categorical for just one uncountable cardinal l. However, I suppose that this result, though an important one, won’t be of any relevance to your discussion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Morley’s theorem is mentioned in passing in Anush’s notes (to explain why categorical theories are stable), but yes, it does seem to not play a direct role in Hrushovski’s paper, though it is of course in the same general subject area.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9cbb1ceff3536f8268b3f66a8c4064c56757cc8c0a106eed6f7c7aa970be02a-96c0b0be93e3bd79ebbce4591ff36c00e96b0e4d3d5e33e0af8a5b82ef752fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of imiro")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42648")[#strong[#text("imiro")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("I am a former model-theorist: my advisor was Jerry Keisler, my “grandfather” was Alfred Tarski, whom I knew well while in Berkeley teaching set theory and model theory. I find your investigations between model theory and other parts of mathematics fascinating and to help I would like to bring to your attention my paper on Modeloids (Transactions of AMS, vol. 250, June 1979, pp. 47 – 90); the concepts discussed there are naturally tied to the fields (group theory, combinatorics, topological dynamics, etc.) where you apply model theory.")

#text("What follows is a brief synopsis of modeloids balancing brevity and accuracy (brief rather than pedantic):")

#text("The group of automorphisms of a structure M = (A R, … ) in a language L provides useful information about M but the set of partial automorphisms (finite functions on A preserving the relations of L) captures the essence of the structure M, the salient model-theoretic properties like homogeneity, being saturated, etc. discussed in your postings. The set F of partial automorphisms of a model M satisfies the following properties:")

#text("0. elements of F are one-to-one finite functions on A (from subsets of A to A)")#linebreak()#text(" 1. all finite identities (including the empty one) are in F")#linebreak()#text(" 2. F is closed under inverses")#linebreak()#text(" 3. F is closed under compositions (compositions may be empty)")

#text("A modeloid on A is a set F of functions on A satisfying the above properties.")

#text("Note that the somewhat arbitrary language L is gone. However, given a modeloid F on A there is a language L and a structure M = (A, R, …) in that language such that F is the set of partial automorphisms of M.")

#text("The key operation on modeloids is the derivative defined as the set F’ of functions in F which can be “extended”: ")#mi("f \\in F")#text("’ iff")#linebreak()#text(" ")#mi("( \\forall x \\in A ) ( \\exists g \\in F ) [ x \\in domain(g) \\wedge f \\subseteq g ]")#text(" and")#linebreak()#text(" ")#mi("( \\forall y \\in A ) ( \\exists g \\in F ) [ y \\in range(g) \\wedge f \\subseteq g ]")#linebreak()#text(" Clearly, F’ is a modeloid included in F and we can iterate the operation by ")#mi("F^{\\alpha + 1} = ( F^{\\alpha}")#text(")’ and taking the intersection at limit ordinals. Eventually we end with ")#mi("F^b")#text(" (b for basic) such ")#mi("( F^b )")#text("’ = ")#mi("F^b")#text(" , the basic modeloid for b.")

#text("The paper characterizes basic modeloids in terms of topological dynamics (section 5 of the paper). For countable A, Fb consists exactly of the “partial automorphisms” which can be extended to an automorphism – a back-and-forth argument).")

#text("When I wrote the paper it looked like the process of taking successive derivatives was akin to obtaining a Poisson stable point in the qualitative theory of differential equations (see p. 71 of the paper).")

#text("The paper is actually written in terms of a “dual” notion, in terms of equivalence relations. Notation seems easier and it is more general since it allows languages without equality.")#linebreak()#text(" Modeloid F is represented as an equivalence relation ")#mi("E_F")#text(" on A* (the set of finite sequences from A) as follows: (a, b in A* are sequences of the same length):")#linebreak()#text(" ")#mi("a E_F b")#text(" iff for some f in F f(a) = b (the natural extension of f to words in A*)")#linebreak()#text(" In this terminology (and a model M = (A, R, …) of L in the back of our mind), the equivalence classes correspond to the minimal subsets definable in the structure using no quantifiers.")#linebreak()#text(" The derivative of a modeloid E is then a more precise equivalence relation E’ (also on A*) defined by: aE’b iff")#linebreak()#text(" ")#mi("( \\forall x \\in A ) ( \\exists y \\in A ) [ axEby ]")#text(" and")#linebreak()#text(" ")#mi("( \\forall y \\in A ) ( \\exists x \\in A ) [ axEby ]")#linebreak()#text(" (ax is the concatenation of a from A* with the element x of A) This is essentially an Ehrenfeucht game: I choose x (or y) and, to win, you have to find y (or x) to make axEby true. The equivalence classes of E’ are the minimal subsets of M definable in the structure using one quantifier.")

#text("As before, the operation can be iterated to obtain the basic modeloid ")#mi("E^b")#text(" whose derivative is itself. The key model-theoretical properties are contained in the manner of how the basic modeloid for E “fits” into E (see Proposition 4.9 and Proposition 7.1).")

#text("To give an example, the type of a k-tuple a from A* is {a/")#mi("E^n")#text(" | n > 0 } (the ")#mi("E^n")#text(" equivalence classes containing a). A type in general is a descending sequence of equivalence classes ")#mi("a_n / E^n")#text(" where a’s are from ")#mi("A^k")#text(" (fixed k). Note that ")#mi("a_n E^n a_{n + 1}")#text(" because ")#mi("E^n \\subseteq E^{n + 1}")#text(".")#linebreak()#text(" Countable saturation means that all types are realized, that is")#linebreak()#text(" For each sequence ")#mi("a_n \\in A^k")#text(" such that ")#mi("a_n E^n a_{n + 1}")#text(" we can find ")#mi("a \\in A^k")#text(" satisfying ")#mi("a E^n a_n")#text(" for large enough n’s.")#linebreak()#text(" (If you think of ")#mi("a E^n b")#text(" as |a – b| < 1/n (i.e. a and b are 1/n close) then this is very much like the completeness of reals).")#linebreak()#text(" Other model-theory concepts like homogeneity, stability, ultraproducts, etc. are discussed in section 7 of the paper. Take a look.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9cbb1ceff3536f8268b3f66a8c4064c56757cc8c0a106eed6f7c7aa970be02a-96c0b0be93e3bd79ebbce4591ff36c00e96b0e4d3d5e33e0af8a5b82ef752fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miro Benda")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42659")[#strong[#text("Miro Benda")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("One more thing that I would like to add to my (iMiro) comment about modeloids (Trans of AMS, vol. 250, June 1979, pp. 47 – 90): As a specific example of modeloid techniques I used modeloids associated with subgroups of symmetric groups to show that for n > 4 the alternating group is the only non-trivial normal subgroup (see Application 6.13 on p. 75). The proof relies just on equivalences; I label it there as “an exercise in pretending”. Though it is not a “proof without words” it does not invoke Sylow’s Theorem, Galois Theory, or other high power machinery.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d4b1a6de6e0fd40d74d84c3e624961092853687a1800a7fec72b164bf9b9540-a94caf01edffc0fca1de26c6649ed560e82fe9a084cf556678969f14e96ce539.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ILovePermutations")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-521557")[#strong[#text("ILovePermutations")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2019")])]

#text("@Miro Benda: I have read your paper on modeloids in detail and would like to explain to you a few aspects of its meaning that you seemingly have missed or not noticed, though Dana Scott has likely given you tips on that topic a while ago. That paper has more connections to other areas of mathematics than you likely realised. I would like to contact you.")

#text("@Terence Tao: If you could forward my email to Miroslav Benda, that would be great.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar 6: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-42706")[#strong[#text("Reading seminar 6: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2009")])]

#text("[…] that any countable set of constants can only generate at most a countable number of types. Last time, we showed that -stability also implied that for any other infinite cardinal , a set of constants […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/#comment-169908")[#strong[#text("Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2012")])]

#text("[…] geometry; for instance, the concept of Morley rank and Morley degree in model theory (discussed in this previous blog post) directly generalises the concepts of dimension and degree in algebraic geometry.) Over , the […]")
]
