// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/
// Converted to Typst by tao2typ: "2026-10-14T15:19:30.677266+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for the continuous Gowers uniformity norm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for the continuous Gowers uniformity norm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/")[#text("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A few years ago, Ben Green, Tamar Ziegler, and myself ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("proved the following")]#text(" (rather technical-looking) inverse theorem for the Gowers norms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Discrete inverse theorem for Gowers norms)")]#text(" ")#metadata(none) <tao-6bf99799d0ef91be6c25>#text(" Let ")#mi("{N \\geq 1}")#text(" and ")#mi("{s \\geq 1}")#text(" be integers, and let ")#mi("{\\delta > 0}")#text(". Suppose that ")#mi("{f: {\\bf Z} \\rightarrow [-1,1]}")#text(" is a function supported on ")#mi("{[N] := \\{1,\\dots,N\\}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{s+2}} \\sum_{n,h_1,\\dots,h_{s+1}} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(n+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}) \\geq \\delta.")]]

#text("Then there exists a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{\\leq s}")#text(" and complexity ")#mi("{O_{s,\\delta}(1)}")#text(", a polynomial sequence ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(", and a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_n f(n) F(g(n) \\Gamma) \\gg_{s,\\delta} 1.")]]
]

#text("For the definitions of “filtered nilmanifold”, “degree”, “complexity”, and “polynomial sequence”, see ")#link("http://arxiv.org/abs/1009.3998")[#text("the paper of Ben, Tammy, and myself")]#text(". (I should caution the reader that this blog post will presume a fair amount of familiarity with this subfield of additive combinatorics.) This result has a number of applications, for instance to establishing asymptotics for linear equations in the primes, but this will not be the focus of discussion here.")

#text("The purpose of this post is to record the observation that this “discrete” inverse theorem, together with an equidistribution theorem for nilsequences that Ben and I worked out in a ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("separate paper")]#text(", implies a continuous version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Continuous inverse theorem for Gowers norms)")]#text(" ")#metadata(none) <tao-58d118590928d0b20a75>#text(" Let ")#mi("{s \\geq 1}")#text(" be an integer, and let ")#mi("{\\delta>0}")#text(". Suppose that ")#mi("{f: {\\bf R} \\rightarrow [-1,1]}")#text(" is a measurable function supported on ")#mi("{[0,1]}")#text(" such that ")#metadata(none) <tao-590d75a7b5b50aa3822c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_{{\\bf R}^{s+1}} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(t+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1})\\ dt dh_1 \\dots dh_{s+1} \\geq \\delta.")]]

#text("Then there exists a filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" of degree ")#mi("{\\leq s}")#text(" and complexity ")#mi("{O_{s,\\delta}(1)}")#text(", a (smooth) polynomial sequence ")#mi("{g: {\\bf R} \\rightarrow G}")#text(", and a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(t) F(g(t) \\Gamma)\\ dt \\gg_{s,\\delta} 1.")]]
]

#text("The interval ")#mi("{[0,1]}")#text(" can be easily replaced with any other fixed interval by a change of variables. A key point here is that the bounds are completely uniform in the choice of ")#mi("{f}")#text(". Note though that the coefficients of ")#mi("{g}")#text(" can be arbitrarily large (and this is necessary, as can be seen just by considering functions of the form ")#mi("{f(t) = \\cos( \\xi t)}")#text(" for some arbitrarily large frequency ")#mi("{\\xi}")#text(").")

#text("It is likely that one could prove Theorem ")#link(<tao-58d118590928d0b20a75>)[#text("2")]#text(" by carefully going through the proof of Theorem ")#link(<tao-6bf99799d0ef91be6c25>)[#text("1")]#text(" and replacing all instances of ")#mi("{{\\bf Z}}")#text(" with ")#mi("{{\\bf R}}")#text(" (and making appropriate modifications to the argument to accommodate this). However, the proof of Theorem ")#link(<tao-6bf99799d0ef91be6c25>)[#text("1")]#text(" is quite lengthy. Here, we shall proceed by the usual limiting process of viewing the continuous interval ")#mi("{[0,1]}")#text(" as a limit of the discrete interval ")#mi("{\\frac{1}{N} \\cdot [N]}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(". However there will be some problems taking the limit due to a failure of compactness, and specifically with regards to the coefficients of the polynomial sequence ")#mi("{g: {\\bf N} \\rightarrow G}")#text(" produced by Theorem ")#link(<tao-6bf99799d0ef91be6c25>)[#text("1")]#text(", after normalising these coefficients by ")#mi("{N}")#text(". Fortunately, a factorisation theorem from a paper of Ben Green and myself resolves this problem by splitting ")#mi("{g}")#text(" into a “smooth” part which does enjoy good compactness properties, as well as “totally equidistributed” and “periodic” parts which can be eliminated using the measurability (and thus, approximate smoothness), of ")#mi("{f}")#text(".")

#metadata(none) <tao-139f6ff72d30a7d74ba2>

#text("We now prove Theorem ")#link(<tao-58d118590928d0b20a75>)[#text("2")]#text(". Firstly observe from Hölder’s inequality that the Gowers norm expression in the left-hand side of ")#link(<tao-590d75a7b5b50aa3822c>)[#text("(1)")]#text(" is continuous in ")#mi("{f}")#text(" in the ")#mi("{L^{2^{s+1}}({\\bf R})}")#text(" topology. As such, it suffices to prove the theorem for a dense class of ")#mi("{f}")#text(", such as the Lipschitz-continuous ")#mi("{f}")#text(", so long as the bounds remain uniform in ")#mi("{f}")#text(". Thus, we may assume without loss of generality that ")#mi("{f}")#text(" is Lipschitz continuous.")

#text("Now let ")#mi("{N}")#text(" be a large integer (which will eventually be sent to infinity along a subsequence). As ")#mi("{f}")#text(" is Lipschitz continuous, the integral in ")#link(<tao-590d75a7b5b50aa3822c>)[#text("(1)")]#text(" is certainly Riemann integrable, and so for sufficiently large ")#mi("{N}")#text(" (where we allow “sufficiently large” to depend on the Lipschitz constant) we will have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^{s+1}} \\sum_{n,h_1,\\dots,h_{s+1}} \\prod_{\\omega \\in \\{0,1\\}^{s+1}} f(\\frac{n+\\omega_1 h_1 + \\dots + \\omega_{s+1} h_{s+1}}{N}) \\geq \\delta/2")]]

#text("(say). Applying Theorem ")#link(<tao-58d118590928d0b20a75>)[#text("2")]#text(", we can thus find for sufficiently large ")#mi("{N}")#text(", a filtered nilmanifold ")#mi("{G_N/\\Gamma_N}")#text(" of degree ")#mi("{s}")#text(" and complexity ")#mi("{O_{s,\\delta}(1)}")#text(", a polynomial sequence ")#mi("{g_N: {\\bf Z} \\rightarrow G_N}")#text(", and a Lipschitz function ")#mi("{F_N: G_N/\\Gamma_N \\rightarrow {\\bf R}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta}(1)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_n f(\\frac{n}{N}) F_N(g_N(n) \\Gamma_N) \\gg_{s,\\delta} 1.")]]

#text("Now we prepare to take limits as ")#mi("{N \\rightarrow \\infty}")#text(", passing to subsequences as necessary. Using Mal’cev bases, one can easily check that there are only finitely many filtered nilmanifolds ")#mi("{G_N/\\Gamma_N}")#text(" of a fixed degree and complexity, hence by passing to a subsequence of ")#mi("{N}")#text(" we may assume that ")#mi("{G_N/\\Gamma_N = G/\\Gamma}")#text(" is independent of ")#mi("{N}")#text(". The Lipschitz functions ")#mi("{F_N}")#text(" are now equicontinuous on a fixed compact domain ")#mi("{G/\\Gamma}")#text(", so by the Arzelá-Ascoli theorem and further passage to a subsequence we may assume that ")#mi("{F_N}")#text(" converges uniformly to a Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(" of Lipschitz constant ")#mi("{O_{s,\\delta}(1)}")#text(". In particular (passing to a further subsequence as necessary) we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_n f(\\frac{n}{N}) F(g_N(n) \\Gamma) \\gg_{s,\\delta} 1.")]]

#text("We have removed a lot of the dependencies of the nilsequence ")#mi("{F_N(g_N(n) \\Gamma_N)}")#text(" on ")#mi("{N}")#text(", however there is still a serious lack of compactness in the remaining dependency of the polynomial sequence ")#mi("{g_N(n)}")#text(" on ")#mi("{N}")#text(". Fortunately, we can argue as follows. Let ")#mi("{M_0, A}")#text(" be large quantities (depending on ")#mi("{s,\\delta}")#text(", and the Lipschitz constant of ")#mi("{f}")#text(") to be chosen later. Applying the factorisation theorem for polynomial sequences (see Theorem 1.19 of ")#link("http://arxiv.org/abs/0709.3562")[#text("this paper of Ben Green and myself")]#text("), we may find for each ")#mi("{N}")#text(" in the current subsequence, an integer ")#mi("{M_0 \\leq M_N \\ll_{M_0,d,s,\\delta} 1}")#text(", a rational subgroup ")#mi("{G^{\\prime}_N}")#text(" of ")#mi("{G}")#text(" whose associated filtered nilmanifold ")#mi("{G^{\\prime}_N/\\Gamma^{\\prime}_N}")#text(" has structure constants that are ")#mi("{M_N}")#text("-rational with respect to the Mal’cev bais of ")#mi("{G/\\Gamma}")#text(", and a decomposition")

#align(center)[#tao-fit-display[#mitex("g_N(n) = \\varepsilon_N(n) g^{\\prime}_N(n) \\gamma_N(n)")]]

#text("where")

#list(
[#mi("{\\varepsilon_N: {\\bf Z} \\rightarrow G}")#text(" is a polynomial sequence which is ")#mi("{(M_N,N)}")#text("-smooth;")],
[#mi("{g^{\\prime}_N: {\\bf Z} \\rightarrow G^{\\prime}}")#text(" is a polynomial sequence with ")#mi("{n \\mapsto g^{\\prime}_N(n) \\Gamma^{\\prime}_N}")#text(" is totally ")#mi("{1/M_N^A}")#text("-equidistributed in ")#mi("{G^{\\prime}_N/\\Gamma^{\\prime}_N}")#text("; and")],
[#mi("{\\gamma_N: {\\bf Z} \\rightarrow G}")#text(" is a polynomial sequence which is ")#mi("{M}")#text("-rational, and ")#mi("{n \\mapsto \\gamma_N(n) \\Gamma}")#text(" is periodic with period at most ")#mi("{M}")#text(".")]
)

#text("See the above referenced paper for a definition of all the terminology used here.")

#text("Once again we can make a lot of the data here independent of ")#mi("{N}")#text(" by passing to a subsequence. Firstly, ")#mi("{M_N}")#text(" takes only finitely many values so by passing to a subsequence we may assume that ")#mi("{M_N=M}")#text(" is independent of ")#mi("{N}")#text(". Then the number of rational subgroups ")#mi("{G^{\\prime}_N}")#text(" with ")#mi("{M}")#text("-rational structure constants is also finite, so by passing to a further subsequence we may take ")#mi("{G^{\\prime}_N = G^{\\prime}}")#text(" independent of ")#mi("{N}")#text(", so ")#mi("{\\Gamma^{\\prime}_N = \\Gamma^{\\prime} = G^{\\prime} \\cap \\Gamma}")#text(" is also independent of ")#mi("{N}")#text(". Up to right multiplication by polynomial sequences from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{\\Gamma}")#text(" (which do not affect the value of ")#mi("{g_N(n) \\Gamma}")#text("), there are only finitely many ")#mi("{M}")#text("-rational polynomial sequences ")#mi("{\\gamma_N}")#text(" that are periodic with period at most ")#mi("{N}")#text(", so we may take ")#mi("{\\gamma_N = \\gamma}")#text(" independent of ")#mi("{N}")#text(". Finally, using coordinates one can write ")#mi("{\\varepsilon_N(n) = \\tilde \\varepsilon_N( \\frac{n}{N} )}")#text(" where ")#mi("{\\tilde \\varepsilon_N: {\\bf R} \\rightarrow G}")#text(" is a continuous polynomial sequence whose coefficients are bounded uniformly in ")#mi("{N}")#text(". By Bolzano-Weierstrass, we may assume on passing to a subsequence that ")#mi("{\\tilde \\varepsilon_N}")#text(" converges locally uniformly to a limit ")#mi("{\\tilde \\varepsilon: {\\bf R} \\rightarrow G}")#text(", which is again a continuous polynomial sequence. Thus, on passing to a further subsequence, we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N} \\sum_n f(\\frac{n}{N}) F(\\tilde \\varepsilon(\\frac{n}{N}) g^{\\prime}_N(n) \\gamma(n) \\Gamma) \\gg_{s,\\delta} 1.")]]

#text("Let ")#mi("{q}")#text(" be the period of ")#mi("{\\gamma}")#text(". By the pigeonhole principle (and again passing to a subsequence) we may find a residue class ")#mi("{a \\text{ mod } q}")#text(" independent of ")#mi("{N}")#text(" such that ")#metadata(none) <tao-a9c3c1f7674502331a5a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{q}{N} \\sum_{n = a \\text{ mod } q} f(\\frac{n}{N}) F(\\tilde \\varepsilon(\\frac{n}{N}) g^{\\prime}_N(n) \\gamma(a) \\Gamma) \\gg_{s,\\delta} 1.")]]

#text("Because ")#mi("{g^{\\prime}_N(n)}")#text(" is totally ")#mi("{1/M^A}")#text("-equidistributed in ")#mi("{G^{\\prime}/\\Gamma^{\\prime}}")#text(", and ")#mi("{\\gamma(a)}")#text(" is ")#mi("{M}")#text("-rational, the conjugate ")#mi("{\\gamma(a)^{-1} g^{\\prime}_N(n) \\gamma(a)}")#text(" is totally ")#mi("{1/M^{A-O_{s,\\delta}(1)}}")#text("-equidistributed in ")#mi("{G^{\\prime\\prime}/\\Gamma^{\\prime\\prime}}")#text(", where ")#mi("{G^{\\prime\\prime} := \\gamma(a)^{-1} G^{\\prime} \\gamma(a)}")#text(" and ")#mi("{\\Gamma^{\\prime\\prime} := G^{\\prime\\prime} \\cap \\Gamma}")#text("; see Section 2 of ")#link("http://arxiv.org/abs/0807.1736")[#text("this paper of Ben and myself")]#text(" for a derivation of this fact. From this, we have the approximation")

#align(center)[#tao-fit-display[#tao-math("\\frac{q}{N} \\sum_{n = a \\text{ mod } q} 1_I( \\frac{n}{N}) \\tilde F( \\gamma(a)^{-1} g^{\\prime}_N(n) \\gamma(a) \\Gamma) = \\left|I\\right| \\int_{G^{\\prime\\prime}/\\Gamma^{\\prime\\prime}} \\tilde F + O(\\kappa)", block: true)]]

#text("for any ")#mi("{\\kappa > 0}")#text(" and any fixed interval ")#mi("{I}")#text(", where ")#tao-math("{\\left|I\\right|}", block: false)#text(" is the length of ")#mi("{I}")#text(" and the integral is with respect to Haar measure, and ")#mi("{M_0,A}")#text(" are sufficiently large depending on ")#mi("{\\kappa,s,\\delta,I}")#text(". Using Riemann integration, we thus see that the left-hand side of ")#link(<tao-a9c3c1f7674502331a5a>)[#text("(2)")]#text(" is thus of the form")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(t) (\\int_{G^{\\prime\\prime}/\\Gamma^{\\prime\\prime}} F( \\tilde \\varepsilon(t) \\gamma(a) \\cdot ))\\ dt + O(\\kappa)")]]

#text("for sufficiently large ")#mi("{N}")#text(" if ")#mi("{M_0,A}")#text(" are sufficiently large depending on ")#mi("{\\kappa,s,\\delta}")#text(", and the Lipschitz constant of ")#mi("{f}")#text(", and so (writing ")#mi("{g_0(t) := \\tilde \\varepsilon(t) \\gamma(a)}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(t) (\\int_{G^{\\prime\\prime}/\\Gamma^{\\prime\\prime}} F( g_0(t) \\cdot ))\\ dt \\gg_{s,\\delta} 1")]]

#text("if ")#mi("{M_0,A}")#text(" are sufficiently large depending on ")#mi("{s,\\delta}")#text(", and the Lipschitz constant of ")#mi("{f}")#text(". If we let ")#mi("{h: {\\bf R} \\rightarrow G^{\\prime\\prime}}")#text(" be a continuous polynomial sequence that is equidistributed in ")#mi("{G^{\\prime\\prime}}")#text(" (which will happen as soon as the sequence is equidistributed with respect to the abelianisation of ")#mi("{G^{\\prime\\prime}}")#text(", by an ")#link("http://www.ams.org/mathscinet-getitem?mr=126504")[#text("old result of Leon Green")]#text("), then a similar argument shows that")

#align(center)[#tao-fit-display[#mitex("\\lim_{T \\rightarrow \\infty} \\int_{\\bf R} f(t) F(g_0(t) h(\\frac{t}{T}))\\ dt = \\int_{\\bf R} f(t) (\\int_{G^{\\prime\\prime}/\\Gamma^{\\prime\\prime}} F( g(t) \\cdot ))\\ dt")]]

#text("and thus there exists ")#mi("{T}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(t) F(g_0(t) h(\\frac{t}{T}))\\ dt \\gg_{s,\\delta} 1.")]]

#text("Setting ")#mi("{g(t) := g_0(t) h(\\frac{t}{T})}")#text(", we obtain the claim.")

#text("I thank Ben Green for helpful conversations that inspired this post.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem. | What's new")]], [#link("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/#comment-457636")[#strong[#text("Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem. | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("[…] mentioned in the previous post, Ben Green, Tamar Ziegler, and myself proved the following inverse theorem for the Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version | What's new")]], [#link("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/#comment-457653")[#strong[#text("Deducing the inverse theorem for the multidimensional Gowers norms from the one-dimensional version | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2015")])]

#text("[…] mentioned in the previous two posts, Ben Green, Tamar Ziegler, and myself proved the following inverse theorem for the Gowers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31faf295f975ec460236723d6214b79188ad427f6eb42aa3c46e1454dcee7326-e76ee473018f2a4a95895bae813c7e374b8da35f87fd8f5fd37b128dc3296dc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arkadeep Mukhopadhyay")]], [#link("https://terrytao.wordpress.com/2015/07/22/an-inverse-theorem-for-the-continuous-gowers-uniformity-norm/#comment-457789")[#strong[#text("Arkadeep Mukhopadhyay")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2015")])]

#text("I am sure I am viewing a blog written by a true author. I love physics and maths greatly although i am a medical student.Till now I have read only two posts but I can assure you that within few days I’ll increase the tally exponentially!")#linebreak()#text(" I also have a blog at wordpress named ")#text("Antarctica Daily")#text(". I will be honoured if you please visit my blog. Thank you.")
]
