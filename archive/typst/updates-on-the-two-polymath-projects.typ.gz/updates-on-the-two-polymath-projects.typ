// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/06/15/updates-on-the-two-polymath-projects/
// Converted to Typst by tao2typ: "2026-10-14T16:36:51.877675+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Updates on the two polymath projects", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Updates on the two polymath projects")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 June 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/06/15/updates-on-the-two-polymath-projects/")[#text("https://terrytao.wordpress.com/2012/06/15/updates-on-the-two-polymath-projects/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Two quick updates with regards to polymath projects. Firstly, ")#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/")[#text("given the poll on starting the mini-polymath4 project")]#text(", I will start the project at ")#link("http://www.timeanddate.com/worldclock/fixedtime.html?iso=20120712T22")[#text("Thu July 12 2012 UTC 22:00")]#text(". As usual, the main research thread on this project will be held at the ")#link("https://polymathprojects.org/")[#text("polymath blog")]#text(", with the discussion thread hosted separately on this blog.")

#text("Second, the ")#link("http://michaelnielsen.org/polymath1/index.php?title=The_hot_spots_conjecture")[#text("Polymath7 project")]#text(", which seeks to establish the “")#link("http://www.math.missouri.edu/~evanslc/Polymath/")[#text("hot spots conjecture")]#text("” for acute-angled triangles, has made a fair amount of progress so far; for instance, the first part of the conjecture (asserting that the second Neumann eigenfunction of an acute non-equilateral triangle is simple) is now solved, and the second part (asserting that the “hot spots” (i.e. extrema) of that second eigenfunction lie on the boundary of the triangle) has been solved in a number of special cases (such as the isosceles case). It’s been quite an active discussion in the last week or so, with almost 200 comments ")#link("http://polymathprojects.org/2012/06/03/polymath-proposal-the-hot-spots-conjecture-for-acute-triangles/")[#text("across two")]#text(" ")#link("http://polymathprojects.org/2012/06/12/polymath7-research-thread-1-the-hot-spots-conjecture/")[#text("threads")]#text(" (and a ")#link("http://polymathprojects.org/2012/06/15/polymath7-research-threads-2-the-hot-spots-conjecture/")[#text("third thread freshly opened up")]#text(" just now). While the problem is still not completely solved, I feel optimistic that it should fall within the next few weeks (if nothing else, it seems that the problem is now at least amenable to a brute force numerical attack, though personally I would prefer to see a more conceptual solution).")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ce2f3d6b15795e810ec8257c444dabeed5fcdda8a85024769678d66fad747d7-d79bce078ff3927897af86fd88494d8f74e9fc87db67333baacbfea640abdd99.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis R. Guzman, Jr.")]], [#link("https://terrytao.wordpress.com/2012/06/15/updates-on-the-two-polymath-projects/#comment-147513")[#strong[#text("Luis R. Guzman, Jr.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2012")])]

#text("Reblogged this on ")#link("http://luisrguzmanjr.wordpress.com/2012/06/17/1411/")[#text("Guzman's Mathematics Weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/06/15/updates-on-the-two-polymath-projects/#comment-151657")[#strong[#text("Polymath project: social problem-solving | Civil Statistician")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2012")]

#text("[…] will be hosting a fourth “mini-polymath” tonight (July 12, 2012), starting at UTC 22:00, which is 6pm EST for us here on the US East Coast. If you […]")
]
