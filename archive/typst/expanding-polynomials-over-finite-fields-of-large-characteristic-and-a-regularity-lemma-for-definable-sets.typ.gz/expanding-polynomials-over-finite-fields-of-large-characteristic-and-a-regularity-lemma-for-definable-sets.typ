// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/
// Converted to Typst by tao2typ: "2026-10-14T16:36:55.963279+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 November 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1211.2894")[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets")]#text("“, submitted to ")#link("http://cdm.ucalgary.ca/cdm/")[#text("Contrib. Disc. Math")]#text(". The motivation of this paper is to understand a certain polynomial variant of the ")#emph[#text("sum-product phenomenon")]#text(" in finite fields. This phenomenon asserts that if ")#mi("{A}")#text(" is a non-empty subset of a finite field ")#mi("{F}")#text(", then either the sumset ")#mi("{A+A := \\{a+b: a,b \\in A\\}}")#text(" or product set ")#mi("{A \\cdot A := \\{ab: a,b \\in A \\}}")#text(" will be significantly larger than ")#mi("{A}")#text(", unless ")#mi("{A}")#text(" is close to a subfield of ")#mi("{F}")#text(" (or to ")#mi("{\\{1\\}}")#text("). In particular, in the regime when ")#mi("{A}")#text(" is large, say ")#tao-math("{\\left|F\\right|^{1-c} < \\left|A\\right| \\leq \\left|F\\right|}", block: false)#text(", one expects an expansion bound of the form ")#metadata(none) <tao-3160c321bcd0c49b6755>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|A+A\\right| + \\left|A \\cdot A\\right| \\gg (\\left|F\\right|/\\left|A\\right|)^{c^{\\prime}} \\left|A\\right|", block: true)]]

#text("for some absolute constants ")#mi("{c, c^{\\prime} > 0}")#text(". Results of this type are known; for instance, ")#link("http://arxiv.org/abs/math/0609426")[#text("Hart, Iosevich, and Solymosi")]#text(" obtained precisely this bound for ")#mi("{(c,c^{\\prime})=(3/10,1/3)}")#text(" (in the case when ")#tao-math("{\\left|F\\right|}", block: false)#text(" is prime), which was then ")#link("http://arxiv.org/abs/0706.0702")[#text("improved by Garaev")]#text(" to ")#mi("{(c,c^{\\prime})=(1/3,1/2)}")#text(".")

#text("We have focused here on the case when ")#mi("{A}")#text(" is a large subset of ")#mi("{F}")#text(", but sum-product estimates are also extremely interesting in the opposite regime in which ")#mi("{A}")#text(" is allowed to be small (see for instance the papers of ")#link("http://arxiv.org/abs/math/0703676")[#text("Katz")]#text("–")#link("http://arxiv.org/abs/math/0703614")[#text("Shen")]#text(" and ")#link("http://arxiv.org/abs/0907.2051")[#text("Li")]#text(" and ")#link("http://arxiv.org/abs/math/0702780")[#text("of Garaev")]#text(" for some recent work in this case, building on some older ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("papers of Bourgain, Katz and myself")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2225493")[#text("of Bourgain, Glibichuk, and Konyagin")]#text("). However, the techniques used in these two regimes are rather different. For large subsets of ")#mi("{F}")#text(", it is often profitable to use techniques such as the Fourier transform or the Cauchy-Schwarz inequality to “complete” a sum over a large set (such as ")#mi("{A}")#text(") into a set over the entire field ")#mi("{F}")#text(", and then to use identities concerning complete sums (such as the Weil bound on complete exponential sums over a finite field). For small subsets of ")#mi("{F}")#text(", such techniques are usually quite inefficient, and one has to proceed by somewhat different combinatorial methods which do not try to exploit the ambient field ")#mi("{F}")#text(". But my paper focuses exclusively on the large ")#mi("{A}")#text(" regime, and unfortunately does not directly say much (except through reasoning by analogy) about the small ")#mi("{A}")#text(" case.")

#text("Note that it is necessary to have both ")#mi("{A+A}")#text(" and ")#mi("{A \\cdot A}")#text(" appear on the left-hand side of ")#link(<tao-3160c321bcd0c49b6755>)[#text("(1)")]#text(". Indeed, if one just has the sumset ")#mi("{A+A}")#text(", then one can set ")#mi("{A}")#text(" to be a long arithmetic progression to give counterexamples to ")#link(<tao-3160c321bcd0c49b6755>)[#text("(1)")]#text(". Similarly, if one just has a product set ")#mi("{A \\cdot A}")#text(", then one can set ")#mi("{A}")#text(" to be a long geometric progression. The sum-product phenomenon can then be viewed that it is not possible to simultaneously behave like a long arithmetic progression and a long geometric progression, unless one is already very close to behaving like a subfield.")

#text("Now we consider a polynomial variant of the sum-product phenomenon, where we consider a polynomial image")

#align(center)[#tao-fit-display[#mitex("P(A,A) := \\{ P(a,b): a,b \\in A \\}")]]

#text("of a set ")#mi("{A \\subset F}")#text(" with respect to a polynomial ")#mi("{P: F \\times F \\rightarrow F}")#text("; we can also consider the asymmetric setting of the image")

#align(center)[#tao-fit-display[#mitex("P(A,B) := \\{ P(a,b): a \\in A,b \\in B \\}")]]

#text("of two subsets ")#mi("{A,B \\subset F}")#text(". The regime we will be interested is the one where the field ")#mi("{F}")#text(" is large, and the subsets ")#mi("{A, B}")#text(" of ")#mi("{F}")#text(" are also large, but the polynomial ")#mi("{P}")#text(" has bounded degree. Actually, for technical reasons it will not be enough for us to assume that ")#mi("{F}")#text(" has large cardinality; we will also need to assume that ")#mi("{F}")#text(" has large ")#link("http://en.wikipedia.org/wiki/Characteristic_(algebra)")[#text("characteristic")]#text(". (The two concepts are synonymous for fields of prime order, but not in general; for instance, the field with ")#mi("{2^n}")#text(" elements becomes large as ")#mi("{n \\rightarrow \\infty}")#text(" while the characteristic remains fixed at ")#mi("{2}")#text(", and is thus not going to be covered by the results in this paper.)")

#text("In ")#link("http://arxiv.org/abs/0705.0715")[#text("this paper of Vu")]#text(", it was shown that one could replace ")#mi("{A \\cdot A}")#text(" with ")#mi("{P(A,A)}")#text(" in ")#link(<tao-3160c321bcd0c49b6755>)[#text("(1)")]#text(", thus obtaining a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\left|A+A\\right| + \\left|P(A,A)\\right| \\gg (\\left|F\\right|/\\left|A\\right|)^{c^{\\prime}} \\left|A\\right|", block: true)]]

#text("whenever ")#tao-math("{\\left|A\\right| \\geq \\left|F\\right|^{1-c}}", block: false)#text(" for some absolute constants ")#mi("{c, c^{\\prime} > 0}")#text(", unless the polynomial ")#mi("{P}")#text(" had the degenerate form ")#mi("{P(x,y) = Q(L(x,y))}")#text(" for some linear function ")#mi("{L: F \\times F \\rightarrow F}")#text(" and polynomial ")#mi("{Q: F \\rightarrow F}")#text(", in which ")#mi("{P(A,A)}")#text(" behaves too much like ")#mi("{A+A}")#text(" to get reasonable expansion. In this paper, we focus instead on the question of bounding ")#mi("{P(A,A)}")#text(" alone. In particular, one can ask to classify the polynomials ")#mi("{P}")#text(" for which one has the ")#emph[#text("weak expansion property")]

#align(center)[#tao-fit-display[#tao-math("\\left|P(A,A)\\right| \\gg (\\left|F\\right|/\\left|A\\right|)^{c^{\\prime}} \\left|A\\right|", block: true)]]

#text("whenever ")#tao-math("{\\left|A\\right| \\geq \\left|F\\right|^{1-c}}", block: false)#text(" for some absolute constants ")#mi("{c, c^{\\prime} > 0}")#text(". One can also ask for stronger versions of this expander property, such as the ")#emph[#text("moderate expansion property")]

#align(center)[#tao-fit-display[#tao-math("\\left|P(A,A)\\right| \\gg \\left|F\\right|", block: true)]]

#text("whenever ")#tao-math("{\\left|A\\right| \\geq \\left|F\\right|^{1-c}}", block: false)#text(", or the ")#emph[#text("almost strong expansion property")]

#align(center)[#tao-fit-display[#tao-math("\\left|P(A,A)\\right| \\geq \\left|F\\right| - O( \\left|F\\right|^{1-c^{\\prime}})", block: true)]]

#text("whenever ")#tao-math("{\\left|A\\right| \\geq \\left|F\\right|^{1-c}}", block: false)#text(". (One can consider even stronger expansion properties, such as the ")#emph[#text("strong expansion property")]#text(" ")#tao-math("{\\left|P(A,A)\\right| \\geq \\left|F\\right|-O(1)}", block: false)#text(", but it was shown by ")#link("http://www.ams.org/mathscinet-getitem?mr=2407038")[#text("Gyarmati and Sarkozy")]#text(" that this property cannot hold for polynomials of two variables of bounded degree when ")#tao-math("{\\left|F\\right| \\rightarrow \\infty}", block: false)#text(".) One can also consider asymmetric versions of these properties, in which one obtains lower bounds on ")#tao-math("{\\left|P(A,B)\\right|}", block: false)#text(" rather than ")#tao-math("{\\left|P(A,A)\\right|}", block: false)#text(".")

#text("The example of a long arithmetic or geometric progression shows that the polynomials ")#mi("{P(x,y) = x+y}")#text(" or ")#mi("{P(x,y) = xy}")#text(" cannot be expanders in any of the above senses, and a similar construction also shows that polynomials of the form ")#mi("{P(x,y) = Q(f(x)+f(y))}")#text(" or ")#mi("{P(x,y) = Q(f(x) f(y))}")#text(" for some polynomials ")#mi("{Q, f: F \\rightarrow F}")#text(" cannot be expanders. On the other hand, there are a number of results in the literature establishing expansion for various polynomials in two or more variables that are not of this degenerate form (in part because such results are related to incidence geometry questions in finite fields, such as the finite field version of the ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s_distinct_distances_problem")[#text("Erdos distinct distances problem")]#text("). For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=2484652")[#text("Solymosi established")]#text(" weak expansion for polynomials of the form ")#mi("{P(x,y) = f(x)+y}")#text(" when ")#mi("{f}")#text(" is a nonlinear polynomial, with generalisations ")#link("http://arxiv.org/abs/0909.5471")[#text("by Hart, Li, and Shen")]#text(" for various polynomials of the form ")#mi("{P(x,y) = f(x) + g(y)}")#text(" or ")#mi("{P(x,y) = f(x) g(y)}")#text(". Further examples of expanding polynomials appear in the work ")#link("http://arxiv.org/abs/0909.3269")[#text("of Shkredov")]#text(", ")#link("http://arxiv.org/abs/0909.3269")[#text("Iosevich-Rudnev")]#text(", and ")#link("http://arxiv.org/abs/1002.2554")[#text("Bukh-Tsimerman")]#text(", as well as the previously mentioned ")#link("http://arxiv.org/abs/0705.0715")[#text("paper of Vu")]#text(" and ")#link("http://arxiv.org/abs/0909.5471")[#text("of Hart-Li-Shen")]#text(", and these papers in turn cite many further results which are in the spirit of the polynomial expansion bounds discussed here (for instance, dealing with the small ")#mi("{A}")#text(" regime, or working in other fields such as ")#mi("{{\\bf R}}")#text(" instead of in finite fields ")#mi("{F}")#text("). We will not summarise all these results here; they are summarised briefly in my paper, and in more detail in the papers ")#link("http://arxiv.org/abs/0909.5471")[#text("of Hart-Li-Shen")]#text(" and ")#link("http://arxiv.org/abs/1002.2554")[#text("of Bukh-Tsimerman")]#text(". But we will single out one of the results of Bukh-Tsimerman, which is one of most recent and general of these results, and closest to the results of my own paper. Roughly speaking, in this paper it is shown that a polynomial ")#mi("{P(x,y)}")#text(" of two variables and bounded degree will be a moderate expander if it is ")#emph[#text("non-composite")]#text(" (in the sense that it does not take the form ")#mi("{P(x,y) = Q(R(x,y))}")#text(" for some non-linear polynomial ")#mi("{Q}")#text(" and some polynomial ")#mi("{R}")#text(", possibly having coefficients in the algebraic completion of ")#mi("{F}")#text(") and is monic on both ")#mi("{x}")#text(" and ")#mi("{y}")#text(", thus it takes the form ")#mi("{P(x,y) = x^d + S(x,y)}")#text(" for some ")#mi("{d \\geq 1}")#text(" and some polynomial ")#mi("{S}")#text(" of degree at most ")#mi("{d-1}")#text(" in ")#mi("{x}")#text(", and similarly with the roles of ")#mi("{x}")#text(" and ")#mi("{y}")#text(" reversed, unless ")#mi("{P}")#text(" is of the form ")#mi("{P(x,y) = f(x) + g(y)}")#text(" or ")#mi("{P(x,y) = f(x) g(y)}")#text(" (in which case the expansion theory is covered to a large extent by ")#link("http://arxiv.org/abs/0909.5471")[#text("the previous work of Hart, Li, and Shen")]#text(").")

#text("Our first main result improves upon the Bukh-Tsimerman result by strengthening the notion of expansion and removing the non-composite and monic hypotheses, but imposes a condition of large characteristic. I’ll state the result here slightly informally as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Criterion for moderate expansion)")]#text(" Let ")#mi("{P: F \\times F \\rightarrow F}")#text(" be a polynomial of bounded degree over a finite field ")#mi("{F}")#text(" of sufficiently large characteristic, and suppose that ")#mi("{P}")#text(" is not of the form ")#mi("{P(x,y) = Q(f(x)+g(y))}")#text(" or ")#mi("{P(x,y) = Q(f(x)g(y))}")#text(" for some polynomials ")#mi("{Q,f,g: F \\rightarrow F}")#text(". Then one has the (asymmetric) moderate expansion property")

#align(center)[#tao-fit-display[#tao-math("\\left|P(A,B)\\right| \\gg \\left|F\\right|", block: true)]]

#text("whenever ")#tao-math("{\\left|A\\right| |B| \\ggg \\left|F\\right|^{2-1/8}}", block: false)#text(".")
]

#text("This is basically a sharp necessary and sufficient condition for asymmetric expansion moderate for polynomials of two variables. In the paper, analogous sufficient conditions for weak or almost strong expansion are also given, although these are not quite as satisfactory (particularly the conditions for almost strong expansion, which include a somewhat complicated algebraic condition which is not easy to check, and which I would like to simplify further, but was unable to).")

#text("The argument here resembles the Bukh-Tsimerman argument in many ways. One can view the result as an assertion about the expansion properties of the graph ")#mi("{\\{ (a,b,P(a,b)): a,b \\in F \\}}")#text(", which can essentially be thought of as a somewhat sparse three-uniform hypergraph on ")#mi("{F}")#text(". Being sparse, it is difficult to directly apply techniques from dense graph or hypergraph theory for this situation; however, after a few applications of the Cauchy-Schwarz inequality, it turns out (as observed by Bukh and Tsimerman) that one can essentially convert the problem to one about the expansion properties of the set ")#metadata(none) <tao-929df7fc8cdf44855c5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\{ (P(a,c), P(b,c), P(a,d), P(b,d)): a,b,c,d \\in F \\}")]]

#text("(actually, one should view this as a ")#link("http://en.wikipedia.org/wiki/Multiset")[#text("multiset")]#text(", but let us ignore this technicality) which one expects to be a dense set in ")#mi("{F^4}")#text(", except in the case when the associated algebraic variety")

#align(center)[#tao-fit-display[#mitex("\\{ (P(a,c), P(b,c), P(a,d), P(b,d)): a,b,c,d \\in \\overline{F} \\}")]]

#text("fails to be Zariski dense, but it turns out that in this case one can use some differential geometry and Riemann surface arguments (after first invoking the ")#link("http://mathoverflow.net/questions/90551/what-does-the-lefschetz-principle-in-algebraic-geometry-mean-exactly")[#text("Lefschetz principle")]#text(" and the high characteristic hypothesis to work over the complex numbers instead over a finite field) to show that ")#mi("{P}")#text(" is of the form ")#mi("{Q(f(x)+g(y))}")#text(" or ")#mi("{Q(f(x)g(y))}")#text(". This reduction is related to the classical fact that the only one-dimensional algebraic groups over the complex numbers are the additive group ")#mi("{({\\bf C},+)}")#text(", the multiplicative group ")#mi("{({\\bf C} \\backslash \\{0\\},\\times)}")#text(", or the elliptic curves (but the latter have a group law given by rational functions rather than polynomials, and so ultimately end up being eliminated from consideration, though they would play an important role if one wanted to study the expansion properties of rational functions).")

#text("It remains to understand the structure of the set ")#link(<tao-929df7fc8cdf44855c5c>)[#text("(2)")]#text(" is. To understand dense graphs or hypergraphs, one of the standard tools of choice is the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", which carves up such graphs into a bounded number of cells, with the graph behaving pseudorandomly on most pairs of cells. However, the bounds in this lemma are notoriously poor (the regularity obtained is an inverse tower exponential function of the number of cells), and this makes this lemma unsuitable for the type of expansion properties we seek (in which we want to deal with sets ")#mi("{A}")#text(" which have a polynomial sparsity, e.g. ")#tao-math("{\\left|A\\right| \\sim \\left|F\\right|^{1-c}}", block: false)#text("). Fortunately, in the case of sets such as ")#link(<tao-929df7fc8cdf44855c5c>)[#text("(2)")]#text(" which are ")#link("http://en.wikipedia.org/wiki/Definable_set")[#text("definable")]#text(" over the language of rings, it turns out that a much stronger regularity lemma is available, which I call the “algebraic regularity lemma”. I’ll state it (again, slightly informally) in the context of graphs as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Algebraic regularity lemma)")]#text(" ")#metadata(none) <tao-251d732a624507e06da9>#text(" Let ")#mi("{F}")#text(" be a finite field of large characteristic, and let ")#mi("{V, W}")#text(" be definable sets over ")#mi("{F}")#text(" of bounded complexity (i.e. ")#mi("{V, W}")#text(" are subsets of ")#mi("{F^n}")#text(", ")#mi("{F^m}")#text(" for some bounded ")#mi("{n,m}")#text(" that can be described by some first-order predicate in the language of rings of bounded length and involving boundedly many constants). Let ")#mi("{E}")#text(" be a definable subset of ")#mi("{V \\times W}")#text(", again of bounded complexity (one can view ")#mi("{E}")#text(" as a bipartite graph connecting ")#mi("{V}")#text(" and ")#mi("{W}")#text("). Then one can partition ")#mi("{V, W}")#text(" into a bounded number of cells ")#mi("{V_1,\\ldots,V_a}")#text(", ")#mi("{W_1,\\ldots,W_b}")#text(", still definable with bounded complexity, such that for ")#emph[#text("all")]#text(" pairs ")#mi("{i =1,\\ldots a}")#text(", ")#mi("{j=1,\\ldots,b}")#text(", one has the regularity property")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap (A \\times B)\\right| = d_{ij} \\left|A\\right| \\left|B\\right| + O( \\left|F\\right|^{-1/4} \\left|V\\right| \\left|W\\right| )", block: true)]]

#text("for all ")#mi("{A \\subset V_i, B \\subset W_i}")#text(", where ")#tao-math("{d_{ij} := \\frac{\\left|E \\cap (V_i \\times W_j)\\right|}{\\left|V_i\\right| \\left|W_j\\right|}}", block: false)#text(" is the density of ")#mi("{E}")#text(" in ")#mi("{V_i \\times W_j}")#text(".")
]

#text("This lemma resembles the Szemerédi regularity lemma, but regularises ")#emph[#text("all")]#text(" pairs of cells (not just most pairs), and the regularity is of polynomial strength in ")#tao-math("{\\left|F\\right|}", block: false)#text(", rather than inverse tower exponential in the number of cells. Also, the cells are not arbitrary subsets of ")#mi("{V,W}")#text(", but are themselves definable with bounded complexity, which turns out to be crucial for applications. I am optimistic that this lemma will be useful not just for studying expanding polynomials, but for many other combinatorial questions involving dense subsets of definable sets over finite fields.")

#text("The above lemma is stated for graphs ")#mi("{E \\subset V \\times W}")#text(", but one can iterate it to obtain an analogous regularisation of hypergraphs ")#mi("{E \\subset V_1 \\times \\ldots \\times V_k}")#text(" for any bounded ")#mi("{k}")#text(" (for application to ")#link(<tao-929df7fc8cdf44855c5c>)[#text("(2)")]#text(", we need ")#mi("{k=4}")#text("). This hypergraph regularity lemma, by the way, is ")#emph[#text("not")]#text(" analogous to the strong hypergraph regularity lemmas of Rodl et al. and Gowers developed in the last six or so years, but closer in spirit to the older (but weaker) hypergraph regularity ")#link("http://www.ams.org/mathscinet-getitem?mr=1099803")[#text("lemma of Chung")]#text(" which gives the same “order ")#mi("{1}")#text("” regularity that the graph regularity lemma gives, rather than higher order regularity.")

#text("One feature of the proof of Lemma ")#link(<tao-251d732a624507e06da9>)[#text("2")]#text(" which I found striking was the need to use some fairly high powered technology from algebraic geometry, and in particular the Lang-Weil bound on counting points in varieties over a finite field (discussed ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("in this previous blog post")]#text("), and also the theory of the ")#link("http://en.wikipedia.org/wiki/%C3%89tale_fundamental_group")[#text("etale fundamental group")]#text(". Let me try to briefly explain why this is the case. A model example of a definable set of bounded complexity ")#mi("{E}")#text(" is a set ")#mi("{E \\subset F^n \\times F^m}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("E = \\{ (x,y) \\in F^n \\times F^m: \\exists t \\in F; P(x,y,t)=0 \\}")]]

#text("for some polynomial ")#mi("{P: F^n \\times F^m \\times F \\rightarrow F}")#text(". (Actually, it turns out that one can essentially write all definable sets as an intersection of sets of this form; see ")#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/")[#text("this previous blog")]#text(" post for more discussion.) To regularise the set ")#mi("{E}")#text(", it is convenient to square the adjacency matrix, which soon leads to the study of counting functions such as")

#align(center)[#tao-fit-display[#tao-math("\\mu(x,x^{\\prime}) := \\left| \\{ (y,t,t^{\\prime}) \\in F^m \\times F \\times F: P(x,y,t) = P(x^{\\prime},y,t^{\\prime}) = 0 \\}\\right|.", block: true)]]

#text("If one can show that this function ")#mi("{\\mu}")#text(" is “approximately finite rank” in the sense that (modulo lower order errors, of size ")#tao-math("{O(\\left|F\\right|^{-1/2})}", block: false)#text(" smaller than the main term), this quantity depends only on a bounded number of bits of information about ")#mi("{x}")#text(" and a bounded number of bits of information about ")#mi("{x^{\\prime}}")#text(", then a little bit of linear algebra will then give the required regularity result.")

#text("One can recognise ")#mi("{\\mu(x,x^{\\prime})}")#text(" as counting ")#mi("{F}")#text("-points of a certain algebraic variety")

#align(center)[#tao-fit-display[#mitex("V_{x,x^{\\prime}} := \\{ (y,t,t^{\\prime}) \\in \\overline{F}^m \\times \\overline{F} \\times \\overline{F}: P(x,y,t) = P(x^{\\prime},y,t^{\\prime}) = 0 \\}.")]]

#text("The Lang-Weil bound (discussed in ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this previous post")]#text(") provides a formula for this count, in terms of the number ")#mi("{c(x,x^{\\prime})}")#text(" of geometrically irreducible components of ")#mi("{V_{x,x^{\\prime}}}")#text(" that are defined over ")#mi("{F}")#text(" (or equivalently, are invariant with respect to the ")#link("http://en.wikipedia.org/wiki/Frobenius_endomorphism")[#text("Frobenius endomorphism")]#text(" associated to ")#mi("{F}")#text("). So the problem boils down to ensuring that this quantity ")#mi("{c(x,x^{\\prime})}")#text(" is “generically bounded rank”, in the sense that for generic ")#mi("{x,x^{\\prime}}")#text(", its value depends only on a bounded number of bits of ")#mi("{x}")#text(" and a bounded number of bits of ")#mi("{x^{\\prime}}")#text(".")

#text("Here is where the étale fundamental group comes in. One can view ")#mi("{V_{x,x^{\\prime}}}")#text(" as a fibre product ")#mi("{V_x \\times_{\\overline{F}^m} V_{x^{\\prime}}}")#text(" of the varieties")

#align(center)[#tao-fit-display[#mitex("V_x := \\{ (y,t) \\in \\overline{F}^m \\times \\overline{F}: P(x,y,t) = 0 \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("V_{x^{\\prime}} := \\{ (y,t) \\in \\overline{F}^m \\times \\overline{F}: P(x^{\\prime},y,t) = 0 \\}")]]

#text("over ")#mi("{\\overline{F}^m}")#text(". If one is in sufficiently high characteristic (or even better, in zero characteristic, which one can reduce to by an ultraproduct (or nonstandard analysis) construction, similar to that discussed in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous post")]#text("), the varieties ")#mi("{V_x,V_{x^{\\prime}}}")#text(" are generically ")#link("http://en.wikipedia.org/wiki/Finite_morphism")[#text("finite")]#text(" ")#link("http://en.wikipedia.org/wiki/%C3%89tale_morphism")[#text("étale")]#text(" ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("covers")]#text(" of ")#mi("{\\overline{F}^m}")#text(", and the fibre product ")#mi("{V_x \\times_{\\overline{F}^m} V_{x^{\\prime}}}")#text(" is then also generically a finite étale cover. One can count the components of a finite étale cover of a connected variety by counting the number of orbits of the étale fundamental group acting on a fibre of that variety (much as the number of components of a cover of a connected manifold is the number of orbits of the topological fundamental group acting on that fibre). So if one understands the étale fundamental group of a certain generic subset of ")#mi("{\\overline{F}^m}")#text(" (formed by intersecting together an ")#mi("{x}")#text("-dependent generic subset of ")#mi("{\\overline{F}^m}")#text(" with an ")#mi("{x^{\\prime}}")#text("-dependent generic subset), this in principle controls ")#mi("{c(x,x^{\\prime})}")#text(". It turns out that one can decouple the ")#mi("{x}")#text(" and ")#mi("{x^{\\prime}}")#text(" dependence of this fundamental group by using an étale version of the van Kampen theorem for the fundamental group, which I discussed in ")#link("https://terrytao.wordpress.com/2012/10/28/van-kampens-theorem-via-covering-spaces/")[#text("this previous blog post")]#text(". With this fact (and another deep fact about the étale fundamental group in zero characteristic, namely that it is topologically finitely generated), one can obtain the desired generic bounded rank property of ")#mi("{c(x,x^{\\prime})}")#text(", which gives the regularity lemma.")

#text("In order to expedite the deployment of all this algebraic geometry (as well as some Riemann surface theory), it is convenient to use the formalism of ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(" (or the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" construction), which among other things can convert quantitative, finitary problems in large characteristic into equivalent qualitative, infinitary problems in zero characteristic (in the spirit of ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("this blog post")]#text("). This allows one to use several tools from those fields as “black boxes”; not just the theory of étale fundamental groups (which are considerably simpler and more favorable in characteristic zero than they are in positive characteristic), but also some results limiting the morphisms between compact Riemann surfaces of high genus (such as the ")#link("http://en.wikipedia.org/wiki/De_Franchis_theorem")[#text("de Franchis theorem")]#text(", the ")#link("http://en.wikipedia.org/wiki/Riemann_hurwitz_formula")[#text("Riemann-Hurwitz formula")]#text(", or the fact that all morphisms between elliptic curves are essentially group homomorphisms), which would be quite unwieldy to utilise if one did not first pass to the zero characteristic case (and thence to the complex case) via the ultraproduct construction (followed by the Lefschetz principle).")

#text("I found this project to be particularly educational for me, as it forced me to wander ")#link("https://terrytao.wordpress.com/career-advice/continually-aim-just-beyond-your-current-range/")[#text("outside of my usual range")]#text(" by quite a bit in order to pick up the tools from algebraic geometry and Riemann surfaces that I needed (in particular, I read through several chapters of ")#link("http://en.wikipedia.org/wiki/%C3%89l%C3%A9ments_de_g%C3%A9om%C3%A9trie_alg%C3%A9brique")[#text("EGA")]#text(" and ")#link("http://en.wikipedia.org/wiki/S%C3%A9minaire_de_G%C3%A9om%C3%A9trie_Alg%C3%A9brique_du_Bois_Marie")[#text("SGA")]#text(" for the first time). This did however put me in the slightly unnerving position of having to use results (such as the ")#link("http://en.wikipedia.org/wiki/Riemann_existence_theorem")[#text("Riemann existence theorem")]#text(") whose proofs I have not fully verified for myself, but which are easy to find in the literature, and widely accepted in the field. I suppose this type of dependence on results in the literature is more common in the more structured fields of mathematics than it is in analysis, which by its nature has fewer reusable black boxes, and so key tools often need to be rederived and modified for each new application. (This distinction is discussed further in ")#link("https://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("this article of Gowers")]#text(".)")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurice de Gosson")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-192686")[#strong[#text("Maurice de Gosson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("Fascinating! Useful?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-192694")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("The last link seems to be wrong…")

#text("I think that maybe, instead of passing to characteristic 0, one should in many cases here be able to argue that one works with tame covers and fundamental groups. Even in positive characteristic, these behave like the characteristic zero picture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-192715")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("Thanks, I’ve corrected the link now.")

#text("I agree that most of the arguments in the paper should also extend to the positive characteristic case (though one may still need some effective lower bound on that characteristic in terms of the degrees of the various varieties and morphisms involved, for instance to keep the varieties generically smooth and to stay in the prime-to-p component of the etale fundamental group). My intuition on these topics deteriorates quite rapidly though, once I don’t get to use the Lefschetz principle to run to the complex algebraic geometry setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-192702")[#strong[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definab…. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0a2228a9820c3ede99d76ca22753dde73855413a45af7623a58b2003d96cf0-1d517eab58787d0544ddf4f717bb6dcc328f089ddc749a0c311db8e0ba698846.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of acbd")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-192718")[#strong[#text("acbd")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("Impressive breadth of tools and references!")

#text("A tiny nitpick: in the paper, there are some missing letters and accents in the tricky ref 27 (the others seem fine). According to the french wikipedia, the TeX should rather read something like:")

#text("\\bibitem{sga2}")#linebreak()#text(" A. Grothendieck, M. Raynaud, (Y. Laszlo, ed.),")#linebreak()#text(" Cohomologie locale des faisceaux coh\\’erents et th\\’eor\\`emes de Lefschetz locaux et globaux (SGA 2). Documents Math\\’ematiques, 4, Soci\\’et\\’e Math\\’ematique de France, Paris (2005). [New edition of the 1968 original].")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-193916")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("For what it is worth, my paper on SL_2 included a proof that a function P(x,y) was expanding in your sense for any sets (large or small). This was then used in a crucial step (since P(x,y) appeared as a trace of a product of elements of SL_2). Of course, P wasn’t quite a polynomial – rather, it was a polynomial on x, y, x^{-1} and y^{-1}. I’ve remained interested in the question, though – for which polynomials (on x and y, or on x, y, x^{-1} and y^{-1}) can we prove expansion even for very small subsets of finite fields?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-193917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2012")])]

#text("Thanks, Harald, for pointing that out! (Though, strictly speaking, your examples (say, Proposition 3.3 of ")#link("http://arxiv.org/pdf/math/0509024.pdf")[#text("http://arxiv.org/pdf/math/0509024.pdf")]#text(" for sake of concreteness) are actually polynomial functions of the products ")#mi("x_1 \\ldots x_{20}, y_1 \\ldots y_{20}")#text(" and their inverses, and they don’t quite give expansion in the senses I state above because epsilon is not required to depend linearly on delta in the limit ")#mi("\\delta \\to 0")#text(", but it is certainly in the same spirit.)")

#text("The methods in my paper (based on regularity lemmas) only work for very large sets (of size ")#tao-math("\\left|F\\right|^{1-1/16}", block: false)#text(" or larger, basically). For extremely small sets (of size less than ")#tao-math("\\log \\left|F\\right|", block: false)#text(") there should be some sort of Lefschetz principle that allows one to embed the configuration into the complex field, where the work of ")#link("http://www.springerlink.com/content/r007063h6q17020p/")[#text("Elekes and Szabo")]#text(" gives satisfactory results. It seems reasonable to conjecture that the Elekes-Szabo theory extends to sets of cardinality up to ")#tao-math("\\left|F\\right|^c", block: false)#text(" for some absolute constant c (for fields of prime order at least, to avoid subfield obstructions), but then there is presumably some crossover to the large set case when ")#mi("P(A,A)")#text(" begins to have positive density in F.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-194234")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Terry, Prop. 3.3 of ")#link("http://arxiv.org/pdf/math/0509024.pdf")[#text("http://arxiv.org/pdf/math/0509024.pdf")]#text(" works uniformly for small and medium-sized sets, which are (in my view) the hardest cases; I didn’t optimize things for large sets because other (easier) methods worked for them in the context I was working in.")

#text("I gave these matters some thoughts a few years ago (I think Akshay and I talked about them). I would be pretty impressed if the transference arguments that work for very small sets could be extended to size ")#tao-math("\\left|F\\right|^\\delta", block: false)#text(", ")#mi("\\delta>0")#text(" a small constant. I would imagine there would still be a large gap between small and large sets even in this case, and that would be the main challenge.")

#text("My intuition is that there should be large-set methods that work for all ")#tao-math("\\left|A\\right|\\geq \\sqrt{F}", block: false)#text(" (see: Deligne). Don’t you agree?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-194251")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Sorry, I meant to say that the ")#emph[#text("conclusions")]#text(" of the transference argument should extend to the ")#tao-math("\\left|F\\right|^\\delta", block: false)#text(" case (in the prime order case, at least), even if the transference method itself breaks down. (For instance, one could speculatively consider some sort of “approximate embedding” of such smallish sets into characteristic zero which isn’t an exact embedding in the Freiman sense, but is still somehow “good enough” for some vestige of the characteristic zero arguments to be applicable.)")

#text("For large sets, I agree that ")#tao-math("\\left|F\\right|^{1/2}", block: false)#text(" is the natural barrier (for weak expansion, at least) since it is the last place where subfield obstructions can occur. (For moderate or strong expansion, there is the possibility of larger counterexamples, e.g. by intersecting together large arithmetic progressions with large geometric progressions, so I don’t have a firm intuition for this case.) My arguments use Deligne’s work (via the Lang-Weil bound) but because of the need to use Cauchy-Schwarz several times to eliminate all the arbitrary sets A, it only starts working at ")#tao-math("\\left|F\\right|^{1-1/16}", block: false)#text(". I can believe that by being more careful, one could reduce the number of applications of Cauchy-Schwarz to get down to ")#tao-math("\\left|F\\right|^{1-1/8}", block: false)#text(" or ")#tao-math("\\left|F\\right|^{1-1/4}", block: false)#text(", but to get all the way down to ")#tao-math("\\left|F\\right|^{1-1/2}", block: false)#text(" would require a very different idea; it can’t just be using Cauchy-Schwarz to “complete” all sums involving A, followed by Deligne to estimate the completed sums. (In sufficiently “additive” or “multiplicative” situations one can use the relevant Fourier transform as a replacement for Cauchy-Schwarz, and this can get down to the right barrier of ")#tao-math("\\left|F\\right|^{1/2}", block: false)#text(", but this trick does not appear to be available in the general case.)")

#text("In any case, I agree that the theories for small, medium, and large sets will initially all be rather different from each other (much as is the case with the Bourgain-Gamburd expansion machinery), though perhaps a unified treatment will eventually emerge (for instance, one may optimistically hope that the small set theory will eventually extend all the way up to ")#tao-math("\\left|F\\right|^{1/2}", block: false)#text(", and the large set theory down to ")#tao-math("\\left|F\\right|^{1/2}", block: false)#text(", thus ultimately eliminating the need for a medium set theory).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c75b16fb55a9199d36cd0cb52e126328239db57f1b3551965b59ae949156a55c-4a06b6fee8e4c3c0d0706a18fbaf8c915f242fcc00d1ef624d9983196718da64.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Milad")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-194083")[#strong[#text("Milad")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2012")])]

#text("Sorry for asking this question here, but how do you use mathematical symbols between your sentences?")#linebreak()#text(" Do you use a special program or something?!")

#emph[#text("[The short answer is yes. See the second section of ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bf1a369b46f80a37f403db0a1d4dbd97381cf2eadc130998d4b8613975c4009-3d94e632824227280875c9bb6bec278e2bc310ca9f1b74e6a4e1022ecb30e2d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derrick")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-197255")[#strong[#text("Derrick")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("Does the result on on asymmetric moderate expanders extend to the case when one considers the image of arbitrary subsets ")#mi("E")#text(" of ")#mi("\\mathbb F^2")#text(" as opposed to Cartesian products of sets ")#mi("E=A\\times B")#text("?")

#text("Do you think analogous statements can be made in a geometric measure theory context? Perhaps, define strong expansion to be something along the lines of the image of a set with large fractal dimension contains an interval, moderate expansion says that large fractal dimension implies positive Lebesgue measure, and weak expansion to mean the a set with large fractal dimension would imply that the fractal dimension of the image would be bigger than ")#mi("(1-c)")#text(" times that fractal dimension of the set plus ")#mi("c")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-197382")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("For the first question, if one considers images ")#mi("P(E)")#text(" of arbitrary subsets ")#mi("E")#text(" of ")#mi("{\\Bbb F}^2")#text(" then one could simply take ")#mi("E = P^{-1}(C)")#text(" for some arbitrary set ")#mi("C")#text(", in which case one does not do any better than the easy bound ")#tao-math("\\left|P(E)\\right| \\gg \\left|E\\right|/\\left|{\\Bbb F}\\right|", block: false)#text(" (assuming P non-constant of course).")

#text("For the second question, there are some scattered results of this type. A typical result here is ")#link("http://imrn.oxfordjournals.org/content/1999/10/547.extract")[#text("Wolff’s result on the Falconer distance conjecture")]#text(", that if ")#mi("E \\subset {\\bf R}^2")#text(" is a compact set with Hausdorff dimension greater than 4/3, then the distance set ")#tao-math("\\Delta(E) := \\{ \\left|x-y\\right|: x,y \\in E \\}", block: false)#text(" has positive Lebesgue measure; among other things, this (morally, at least) implies that the image of ")#mi("A^4")#text(" under the polynomial ")#mi("P(x,y,z,w) := (x-y)^2+(z-w)^2")#text(" has positive Lebesgue measure whenever ")#mi("A \\subset {\\bf R}")#text(" is a compact set of dimension at least ")#mi("1/2")#text(". I don’t know if anyone has studied the problem for arbitrary polynomials P though. (In principle, the results of Elekes and Szabo could be transferable to this setting, but in practice it is often quite difficult to convert a discrete incidence combinatorics result into a continuous geometric measure theory result; for instance, the near-resolution of the Erdos distance problem by Guth and Katz has, to date, not led to further progress on the continuous counterpart, namely the Falconer distance conjecture.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mixing for progressions in non-abelian groups « What’s new")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-203695")[#strong[#text("Mixing for progressions in non-abelian groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("[…] online submission system). This paper is loosely related in subject topic to my two previous papers on polynomial expansion and on recurrence in quasirandom groups (with Vitaly Bergelson), although the methods here are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rectification and the Lefschetz principle | What's new")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-219477")[#strong[#text("Rectification and the Lefschetz principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2013")])]

#text("[…] This principle (first laid out in an appendix of Lefschetz’s book), among other things, often allows one to use the methods of complex analysis (e.g. Riemann surface theory) to study many other fields of characteristic zero. There are many variants and extensions of this principle; see for instance this MathOverflow post for some discussion of these. I used this baby version of the Lefschetz principle recently in a paper on expanding polynomial maps. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A spectral theory proof of the algebraic regularity lemma | What's new")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-249423")[#strong[#text("A spectral theory proof of the algebraic regularity lemma | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("[…] a recent paper, I established (in the large characteristic case) the following regularity lemma for dense […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-251376")[#strong[#text("Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")])]

#text("[…] If are definable sets, then the uniform measure on is the product of the uniform measure on and the uniform measure on ; the proof of the Fubini-Tonelli type statement that justifies this may be found for instance in Lemma 13 of this paper of mine. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-688558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2025")])]

#text("“This did however put me in the slightly unnerving position of having to use results (such as the ")#link("http://en.wikipedia.org/wiki/Riemann_existence_theorem")[#text("Riemann existence theorem")]#text(") whose proofs I have not fully verified for myself, but which are easy to find in the literature, and widely accepted in the field.”")

#text("Really? Are you saying that (save for a project like this) you verify the proof of every tool you use?? Is this still the case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-688573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("Not always in a line by line fashion, but I do usually try to get to the point where I at least understand the proof strategy required for each input, or a heuristic justification of why the result would be expected to be true. That said, there have since been other projects I have been involved in that required some deep result outside of analysis (e.g., the classification of finite simple groups) that I had to accept on the basis of community acceptance of the result rather than my own understanding. Hopefully as the formalization of mathematics progresses, this will be less of a concern and it will become easier to rely more crucially on results that one could not verify or justify oneself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/#comment-689464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("So how did you go about reading SGA/EGA? As an outsider to algebraic geometry, how did you judge the “proper level of understanding” you needed to reach (if that question makes sense)?")
]
