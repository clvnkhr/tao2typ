// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/
// Converted to Typst by tao2typ: "2026-10-14T16:35:38.720845+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B final; 245C course announcement", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B final; 245C course announcement")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/")[#text("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The 245B final can be ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/03/final245.pdf")[#text("found here")]#text(". I am not posting solutions, but readers (both students and non-students) are welcome to discuss the final questions in the comments below.")

#text("The continuation to this course, ")#link("http://www.math.ucla.edu/~tao/245c.1.09s")[#text("245C")]#text(", will begin on Monday, March 29. The topics for this course are still somewhat fluid – but I tentatively plan to cover the following topics, roughly in order:")

#list(
[#mi("L^p")#text(" spaces and interpolation; fractional integration")],
[#text("The Fourier transform on ")#mi("{\\Bbb R}^n")#text(" (a very quick review; this is of course covered more fully in 247A)")],
[#text("Schwartz functions, and the theory of distributions")],
[#text("Hausdorff measure")],
[#text("The spectral theorem (introduction only; the topic is covered in depth in 255A)")]
)

#text("I am open to further suggestions for topics that would build upon the 245AB material, which would be of interest to students, and which would not overlap too substantially with other graduate courses offered at UCLA.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 关于实分析三 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36830")[#strong[#text("关于实分析三 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("[…] 关于实分析三 三月 17, 2009 at 4:18 下午 | In Maths（数学）, Real Analysis(实分析), life（生活） | Terence Tao教授将于三月二十九日开是一门新课，实分析三。这门课的具体讲授内容还没有确定下来。事实上，Tao教授本人在自己的博客上正在广泛征求意见。鉴于春季学期Tao教授的课程实分析二，刚刚结束。我想两门课间的种种联系是少不了的。我打算把这门课程学下来，但是由于课程内容还没有确定，更不用说所需要的知识到底多少为宜了。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36839")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("Great course. How many students took it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a28988122a4217fce7677439f832c73258e22c57daee1b0919bdc63105bd5e5e-d05ee6637bf90b7d452bc04373a6ccaf343443c9f3c9e50ba27dbb8261d2f89e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wmr")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36842")[#strong[#text("wmr")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("你很伟大")

#text("You are great")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36844")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("Great! I am looking forward to learning it :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36845")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("I would like to suggest some materials on Sobolev space such as Sobolev inequality, Embedding theorems.")

#text("I also suggest you teach some courses on PDE (especially on wave equations) in future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("A typo(again!) on the final: 245B instead of 245A.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vedadi")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36853")[#strong[#text("vedadi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("Dear Prof Tao,")

#text("If you teach sobolev spaces, embedding theorems, it would be perfect.")#linebreak()#text(" We hope that you teach a PDE course just after that course.")

#text("Thank you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f997fa2ad8839adf0ab215638d34a42be5eb2c2fc7a89d0a4d465fdb314cb49-9a8e97053fad47fd5d9e2f4a445c750d5c2359a3f03c0332cfa773d94338ac41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Baroi")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-36868")[#strong[#text("Max Baroi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("Maybe some the beginnings of Ergodic Theory? There doesn’t seem to be a regular course at UCLA on the subject, though maybe 254 will again devote itself to that material next year.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa8e0026304bde0f0335731a84ccbdbd60b2de97830af815694eae4db91ec8ea-3cf2a76b6c008bca6d7c5aa49697694f074fc6a07bc98dca6b68efdb2d60ac2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brad")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-37293")[#strong[#text("Brad")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("I would be interested in results on the Kakeya conjecture (if this material is never taught in the Fourier analysis sequence, that is).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The discussion of real analysis: 0 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/03/16/245b-final-245c-course-announcement/#comment-37502")[#strong[#text("The discussion of real analysis: 0 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("[…] The discussion of real analysis: 0 三月 29, 2009 at 5:26 下午 | In Uncategorized | Recently several co-learners contacted me, showing their interests in learning Professor Tao’s new course: Real Analysis 3. The Course page is here. […]")
]
