// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:37.656110+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Infinite fields, finite fields, and the Ax-Grothendieck theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Infinite fields, finite fields, and the Ax-Grothendieck theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Jean-Pierre_Serre")[#text("Jean-Pierre Serre")]#text(" (whose papers are, of course, always worth reading) recently posted a lovely lecture on the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" entitled “")#link("http://arxiv.org/abs/0903.0517")[#text("How to use finite fields for problems concerning infinite fields")]#text("“. In it, he describes several ways in which algebraic statements over fields of zero characteristic, such as ")#mi("{{\\bf C}}")#text(", can be deduced from their positive characteristic counterparts such as ")#mi("{F_{p^m}}")#text(", despite the fact that there is no non-trivial field homomorphism between the two types of fields. In particular finitary tools, including such basic concepts as cardinality, can now be deployed to establish infinitary results. This leads to some simple and elegant proofs of non-trivial algebraic results which are not easy to establish by other means.")#linebreak()#text(" One deduction of this type is based on the idea that positive characteristic fields can partially ")#emph[#text("model")]#text(" zero characteristic fields, and proceeds like this: if a certain algebraic statement failed over (say) ")#mi("{{\\bf C}}")#text(", then there should be a “finitary algebraic” obstruction that “witnesses” this failure over ")#mi("{{\\bf C}}")#text(". Because this obstruction is both finitary and algebraic, it must also be definable in some (large) finite characteristic, thus leading to a comparable failure over a finite characteristic field. Taking contrapositives, one obtains the claim.")#linebreak()#text(" Algebra is definitely not my own field of expertise, but it is interesting to note that similar themes have also come up in my own area of additive combinatorics (and more generally arithmetic combinatorics), because the combinatorics of addition and multiplication on finite sets is definitely of a “finitary algebraic” nature. For instance, a ")#link("http://arxiv.org/abs/0711.4407")[#text("recent paper of Vu, Wood, and Wood")]#text(" establishes a finitary “Freiman-type” homomorphism from (finite subsets of) the complex numbers to large finite fields that allows them to pull back many results in arithmetic combinatorics in finite fields (e.g. the sum-product theorem) to the complex plane. (Van Vu and I ")#link("http://front.math.ucdavis.edu/math.CO/0501313")[#text("also used a similar trick")]#text(" to control the singularity property of random sign matrices by first mapping them into finite fields in which cardinality arguments became available.) And I have a particular fondness for correspondences between finitary and infinitary mathematics; the correspondence Serre discusses is slightly different from the one I discuss for instance in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("here")]#text(" or ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("here")]#text(", although there seems to be a common theme of “compactness” (or of model theory) tying these correspondences together.")#linebreak()#text(" As one of his examples, Serre cites one of my own favourite results in algebra, discovered independently ")#link("http://www.ams.org/mathscinet-getitem?mr=229613")[#text("by Ax")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=217086")[#text("by Grothendieck")]#text(" (and then rediscovered many times since). Here is a special case of that theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Ax-Grothendieck theorem, special case)")]#text(" ")#metadata(none) <tao-2cf3ad35047e38f8eb42>#text(" Let ")#mi("{P: {\\bf C}^n \\rightarrow {\\bf C}^n}")#text(" be a polynomial map from a complex vector space to itself. If ")#mi("{P}")#text(" is injective, then ")#mi("{P}")#text(" is bijective.")
]

#text("The full version of the theorem allows one to replace ")#mi("{{\\bf C}^n}")#text(" by an algebraic variety ")#mi("{X}")#text(" over any algebraically closed field, and for ")#mi("{P}")#text(" to be an morphism from the algebraic variety ")#mi("{X}")#text(" to itself, but for simplicity I will just discuss the above special case. This theorem is not at all obvious; it is not too difficult (see Lemma ")#link(<tao-87b252819778c32deb99>)[#text("5")]#text(" below) to show that the ")#link("http://en.wikipedia.org/wiki/Jacobian")[#text("Jacobian")]#text(" of ")#mi("{P}")#text(" is non-degenerate, but this does not come close to solving the problem since one would then be faced with the notorious ")#link("http://en.wikipedia.org/wiki/Jacobian_conjecture")[#text("Jacobian conjecture")]#text(". Also, the claim fails if “polynomial” is replaced by “holomorphic”, due to the existence of ")#link("http://en.wikipedia.org/wiki/Fatou-Bieberbach_domain")[#text("Fatou-Bieberbach domains")]#text(".")#linebreak()#text(" In this post I would like to give the proof of Theorem ")#link(<tao-2cf3ad35047e38f8eb42>)[#text("1")]#text(" based on finite fields as mentioned by Serre, as well as another elegant proof ")#link("http://www.ams.org/mathscinet-getitem?mr=1336641")[#text("of Rudin")]#text(" that combines algebra with some elementary complex variable methods. (There are several other proofs of this theorem and its generalisations, for instance a topological proof ")#link("http://www.ams.org/mathscinet-getitem?mr=255545")[#text("by Borel")]#text(", which I will not discuss here.)")#linebreak()#text(" ")#emph[#text("Update, March 8: Some corrections to the finite field proof. Thanks to Matthias Aschenbrenner also for clarifying the relationship with Tarski’s theorem and some further references.")]#linebreak()#text(" ")#metadata(none) <tao-71a2b16989395bc88d10>

#heading(level: 1)[#strong[#text(" — 1. Proof via finite fields — ")]]

#text("The first observation is that the theorem is utterly trivial in the finite field case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Ax-Grothendieck theorem in ")#mi("{F}")#text(")")]#text(" ")#metadata(none) <tao-cb36d709821763e750a5>#text(" Let ")#mi("{F}")#text(" be a finite field, and let ")#mi("{P: F^n \\rightarrow F^n}")#text(" be a polynomial. If ")#mi("{P}")#text(" is injective, then ")#mi("{P}")#text(" is bijective.")
]

#emph[#text("Proof:")]#text(" Any injection from a finite set to itself is necessarily bijective. (The hypothesis that ")#mi("{P}")#text(" is a polynomial is not needed at this stage, but becomes crucial later on.) ")#mi("\\Box")#linebreak()#text(" Next, we pass from a finite field ")#mi("{F}")#text(" to its algebraic closure ")#mi("{\\overline{F}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Ax-Grothendieck theorem in ")#mi("{\\overline{F}}")#text(")")]#text(" ")#metadata(none) <tao-e1c316712b18ff3c8f1a>#text(" Let ")#mi("{F}")#text(" be a finite field, let ")#mi("{\\overline{F}}")#text(" be its algebraic closure, and let ")#mi("{P: \\overline{F}^n \\rightarrow \\overline{F}^n}")#text(" be a polynomial. If ")#mi("{P}")#text(" is injective, then ")#mi("{P}")#text(" is bijective.")
]

#emph[#text("Proof:")]#text(" Our main tool here is ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_Nullstellensatz")[#text("Hilbert’s nullstellensatz")]#text(", which we interpret here as an assertion that if an algebraic problem is insoluble, then there exists a finitary algebraic obstruction that witnesses this lack of solution (see also my ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("blog post")]#text(" on this topic). Specifically, suppose for contradiction that we can find a polynomial ")#mi("{P: \\overline{F}^n \\rightarrow \\overline{F}^n}")#text(" which is injective but not surjective. Injectivity of ")#mi("{P}")#text(" means that the algebraic system")

#align(center)[#tao-fit-display[#mitex("P(x) = P(y); \\quad x \\neq y")]]

#text("has no solution over the algebraically closed field ")#mi("{\\overline{F}}")#text("; by the nullstellensatz, this implies that for each ")#mi("{j=1,\\dots,n}")#text(", there must exist an algebraic identity of the form ")#metadata(none) <tao-e21c1390de633690e4df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(P(x) - P(y)) \\cdot Q_j(x,y) = (x_j-y_j)^r")]]

#text("for some ")#mi("{r \\geq 1}")#text(" and some polynomial ")#mi("{Q: \\overline{F}^n \\times \\overline{F}^n \\rightarrow \\overline{F}^n}")#text(" that specifically witnesses this lack of solvability. Similarly, lack of surjectivity means the existence of an ")#mi("{z_0 \\in \\overline{F}^n}")#text(" such that the algebraic system")

#align(center)[#tao-fit-display[#mitex("P(x) = z_0")]]

#text("has no solution over the algebraically closed field ")#mi("{\\overline{F}}")#text("; by another application of the nullstellensatz, there must exist an algebraic identity of the form ")#metadata(none) <tao-c5dc270d8892796ce8ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(P(x) - z_0) \\cdot R(x) = 1")]]

#text("for some polynomial ")#mi("{R: \\overline{F}^n \\rightarrow \\overline{F}^n}")#text(" that specifically witnesses this lack of solvability.")#linebreak()#text(" Fix ")#mi("{Q_j, z_0, R}")#text(" as above, and let ")#mi("{k}")#text(" be the subfield of ")#mi("{\\overline{F}}")#text(" generated by ")#mi("{F}")#text(" and the coefficients of ")#mi("{P, Q_j, z_0, R}")#text(". Then we observe (thanks to our explicit witnesses ")#link(<tao-e21c1390de633690e4df>)[#text("(1)")]#text(", ")#link(<tao-c5dc270d8892796ce8ba>)[#text("(2)")]#text(") that the counterexample ")#mi("{P}")#text(" descends from ")#mi("{\\overline{F}}")#text(" to ")#mi("{k}")#text("; ")#mi("{P}")#text(" is a polynomial from ")#mi("{k^n}")#text(" to ")#mi("{k^n}")#text(" which is injective but not surjective.")#linebreak()#text(" But ")#mi("{k}")#text(" is finitely generated, and every element of ")#mi("{k}")#text(" is algebraic over the finite field ")#mi("{F}")#text(", thus ")#mi("{k}")#text(" is finite. But this contradicts Theorem ")#link(<tao-cb36d709821763e750a5>)[#text("2")]#text(". ")#mi("\\Box")#linebreak()#text(" The complex case ")#mi("{{\\bf C}}")#text(" follows by a slight extension of the argument used to prove Theorem ")#link(<tao-e1c316712b18ff3c8f1a>)[#text("3")]#text(". Indeed, suppose for contradiction that there is a polynomial ")#mi("{P: {\\bf C}^n \\rightarrow {\\bf C}^n}")#text(" which is injective but not surjective. As ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#mi("{{\\bf C}}")#text(" is algebraically closed")]#text(", we may invoke the nullstellensatz as before and find witnesses ")#link(<tao-e21c1390de633690e4df>)[#text("(1)")]#text(", ")#link(<tao-c5dc270d8892796ce8ba>)[#text("(2)")]#text(" for some ")#mi("{Q, z_0, R}")#text(".")#linebreak()#text(" Now let ")#mi("{k={\\bf Q}[{\\mathcal C}]}")#text(" be the subfield of ")#mi("{{\\bf C}}")#text(" generated by the rationals ")#mi("{{\\bf Q}}")#text(" and the coefficients ")#mi("{{\\mathcal C}}")#text(" of ")#mi("{P, Q, z_0, R}")#text(". Then we can descend the counterexample to ")#mi("{k}")#text(". This time, ")#mi("{k}")#text(" is not finite, but we can descend it to a finite field (and obtain the desired contradiction) by a number of methods. One approach, which is the one taken by Serre, is to quotient the ring ")#mi("{{\\bf Z}[{\\mathcal C}]}")#text(" generated by the above coefficients by a maximal ideal, observing that this quotient is necessarily a finite field. Another is to use a general mapping theorem of ")#link("http://arxiv.org/abs/0711.4407")[#text("Vu, Wood, and Wood")]#text(". We sketch the latter approach as follows. Being finitely generated, we know that ")#mi("{k}")#text(" has a finite ")#link("http://en.wikipedia.org/wiki/Transcendence_degree")[#text("transcendence basis")]#text(" ")#mi("{\\alpha_1,\\ldots,\\alpha_m}")#text(" over ")#mi("{{\\bf Q}}")#text(". Applying the ")#link("http://en.wikipedia.org/wiki/Primitive_element_theorem")[#text("primitive element theorem")]#text(", we can then express ")#mi("{k}")#text(" as the finite extension of ")#mi("{{\\bf Q}[\\alpha_1,\\ldots,\\alpha_m]}")#text(" by an element ")#mi("{\\beta}")#text(" which is algebraic over ")#mi("{{\\bf Q}[\\alpha_1,\\ldots,\\alpha_m]}")#text("; all the coefficients ")#mi("{{\\mathcal C}}")#text(" are thus rational combinations of ")#mi("{\\alpha_1,\\ldots,\\alpha_m,\\beta}")#text(". By rationalising, we can ensure that the denominators of the expressions of these coefficients are integers in ")#mi("{{\\bf Z}[\\alpha_1,\\ldots,\\alpha_m]}")#text("; dividing ")#mi("{\\beta}")#text(" by an appropriate power of the product of these denominators we may assume that the coefficients in ")#mi("{{\\mathcal C}}")#text(" all lie in the commutative ring ")#mi("{{\\bf Z}[\\alpha_1,\\ldots,\\alpha_m,\\beta]}")#text(", which can be identified with the commutative ring ")#mi("{{\\bf Z}[a_1,\\ldots,a_m,b]}")#text(" generated by formal indeterminates ")#mi("{a_1,\\ldots,a_m,b}")#text(", quotiented by the ideal generated by the minimal polynomial ")#mi("{f \\in {\\bf Z}[a_1,\\ldots,a_m,b]}")#text(" of ")#mi("{\\beta}")#text("; the algebraic identities ")#link(<tao-e21c1390de633690e4df>)[#text("(1)")]#text(", ")#link(<tao-c5dc270d8892796ce8ba>)[#text("(2)")]#text(" then transfer to this ring. Now pick a large prime ")#mi("{p}")#text(", and map ")#mi("{a_1,\\ldots,a_m}")#text(" to random elements of ")#mi("{F_p}")#text(". With high probability, the image of ")#mi("{f}")#text(" (which is now in ")#mi("{F_p[b]}")#text(") is non-degenerate; we can then map ")#mi("{b}")#text(" to a root of this image in a finite extension of ")#mi("{F_p}")#text(". (In fact, by using the ")#link("http://en.wikipedia.org/wiki/Chebotarev%27s_density_theorem")[#text("Chebotarev density theorem")]#text(" (or Frobenius density theorem), we can place ")#mi("{b}")#text(" back in ")#mi("{F_p}")#text(" for infinitely many primes ")#mi("{p}")#text(".) This descends the identities ")#link(<tao-e21c1390de633690e4df>)[#text("(1)")]#text(", ")#link(<tao-c5dc270d8892796ce8ba>)[#text("(2)")]#text(" to this finite extension, as desired.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" This argument can be generalised substantially; it can be used to show that any first-order sentence in the language of fields is true in all algebraically closed fields of characteristic zero if and only if it is true for all algebraically closed fields of sufficiently large characteristic. This result can be deduced from the famous result (proved ")#link("http://www.ams.org/mathscinet-getitem?mr=44472")[#text("by Tarski")]#text(", and independently, in an equivalent formulation, by Chevalley) that the theory of algebraically closed fields (in the language of rings) admits elimination of quantifiers. See for instance Section IV.23.4 of the ")#link("http://press.princeton.edu/titles/8350.html")[#text("Princeton Companion to Mathematics")]#text(". There are also analogues for real closed fields, starting with the paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=140516")[#text("Bialynicki-Birula and Rosenlicht")]#text(", with a general result established ")#link("http://www.ams.org/mathscinet-getitem?mr=1666793")[#text("by Kurdyka")]#text(". Ax-Grothendieck type properties in other categories have been studied ")#link("http://www.ams.org/mathscinet-getitem?mr=1694588")[#text("by Gromov")]#text(", who calls this property “surjunctivity”.")
]

#heading(level: 1)[#strong[#text(" — 2. Rudin’s proof — ")]]

#text("Now we give Rudin’s proof, which does not use the nullstellensatz, instead relying on some Galois theory and the topological structure of ")#mi("{{\\bf C}}")#text(". We first need a basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-87b252819778c32deb99>#text(" Let ")#mi("{\\Omega \\subset {\\bf C}^n}")#text(" be an open set, and let ")#mi("{f: \\Omega \\rightarrow {\\bf C}^n}")#text(" be an injective holomorphic map. Then the Jacobian of ")#mi("{f}")#text(" is non-degenerate, i.e. ")#mi("{\\det Df(z) \\neq 0}")#text(" for all ")#mi("{z \\in \\Omega}")#text(".")
]

#text("Actually, we only need the special case of this lemma when ")#mi("{f}")#text(" is a polynomial.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=674524")[#text("of Rosay")]#text(". For ")#mi("{n=1}")#text(" the claim follows from Taylor expansion. Now suppose ")#mi("{n>1}")#text(" and the claim is proven for ")#mi("{n-1}")#text(". Suppose for contradiction that ")#mi("{\\det Df(z_0)=0}")#text(" for some ")#mi("{z_0 \\in \\Omega}")#text(". We claim that ")#mi("{Df(z_0)}")#text(" in fact vanishes entirely. If not, then we can find ")#mi("{1 \\leq i,j \\leq n}")#text(" such that ")#mi("{\\frac{\\partial}{\\partial z_j} f_i(z_0) \\neq 0}")#text("; by permuting we may take ")#mi("{i=j=1}")#text(". We can also normalise ")#mi("{z_0=f(z_0)=0}")#text(". Then the map ")#mi("{h: z \\mapsto (f_1(z),z_2,\\ldots,z_n)}")#text(" is holomorphic with non-degenerate Jacobian at ")#mi("{0}")#text(" and is thus locally invertible at ")#mi("{0}")#text(". The map ")#mi("{f \\circ h^{-1}}")#text(" is then holomorphic at ")#mi("{0}")#text(" and preserves the ")#mi("{z_1}")#text(" coordinate, and thus descends to an injective holomorphic map on a neighbourhood of the origin ")#mi("{{\\bf C}^{n-1}}")#text(", and so its Jacobian is non-degenerate by induction hypothesis, a contradiction.")#linebreak()#text(" We have just shown that the gradient of ")#mi("{f}")#text(" vanishes on the zero set ")#mi("{\\{ \\det Df = 0 \\}}")#text(", which is an analytic variety of codimension ")#mi("{1}")#text(" (if ")#mi("{f}")#text(" is polynomial, it is of course an algebraic variety). Thus ")#mi("{f}")#text(" is locally constant on this variety, which contradicts injectivity and we are done. ")#mi("\\Box")#linebreak()#text(" From this lemma and the inverse function theorem we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-c403c007df3f235b062c>#text(" Injective holomorphic maps from ")#mi("{{\\bf C}^n}")#text(" to ")#mi("{{\\bf C}^n}")#text(" are ")#link("http://en.wikipedia.org/wiki/Open_map")[#text("open")]#text(".")
]

#text("Now we can give Rudin’s proof. Let ")#mi("{P: {\\bf C}^n \\rightarrow {\\bf C}^n}")#text(" be an injective polynomial. We let ")#mi("{k}")#text(" be the field generated by ")#mi("{{\\bf Q}}")#text(" and the coefficients of ")#mi("{P}")#text("; thus ")#mi("{P}")#text(" is definable over ")#mi("{k}")#text(". Let ")#mi("{k[z] = k[z_1,\\ldots,z_n]}")#text(" be the extension of ")#mi("{k}")#text(" by ")#mi("{n}")#text(" indeterminates ")#mi("{z_1,\\ldots,z_n}")#text(". Inside ")#mi("{k[z]}")#text(" we have the subfield ")#mi("{k[P(z)]}")#text(" generated by ")#mi("{k}")#text(" and the components of ")#mi("{P(z)}")#text(".")#linebreak()#text(" We claim that ")#mi("{k[P(z)]}")#text(" is all of ")#mi("{k[z]}")#text(". For if this were not the case, we see from Galois theory that there is a non-trivial automorphism ")#mi("{\\phi: k[z] \\rightarrow k[z]}")#text(" that fixes ")#mi("{k[P(z)]}")#text("; in particular, there exists a non-trivial rational (over ")#mi("{k}")#text(") combination ")#mi("{Q(z)/R(z)}")#text(" of ")#mi("{z}")#text(" such that ")#mi("{P(Q(z)/R(z)) = P(z)}")#text(". Now map ")#mi("{z}")#text(" to a random complex number in ")#mi("{{\\bf C}}")#text(", which will almost surely be transcendental over the countable field ")#mi("{k}")#text("; this explicitly demonstrates non-injectivity of ")#mi("{P}")#text(", a contradiction.")#linebreak()#text(" Since ")#mi("{k[P(z)] = k[z]}")#text(", there exists a rational function ")#mi("{Q_j(z)/R_j(z)}")#text(" over ")#mi("{k}")#text(" for each ")#mi("{j=1,\\ldots,n}")#text(" such that ")#mi("{z_j = Q_j(P(z))/R_j(P(z))}")#text(". We may of course assume that ")#mi("{Q_j, R_j}")#text(" have no common factors.")#linebreak()#text(" We have the polynomial identity ")#mi("{Q_j(P(z)) = z_j R_j(P(z))}")#text(". In particular, this implies that on the domain ")#mi("{P({\\bf C}^n) \\subset {\\bf C}^n}")#text(" (which is open by Corollary ")#link(<tao-c403c007df3f235b062c>)[#text("6")]#text("), the zero set of ")#mi("{R_j}")#text(" is contained in the zero set of ")#mi("{Q_j}")#text(". But as ")#mi("{Q_j}")#text(" and ")#mi("{R_j}")#text(" have no common factors, this is impossible by elementary algebraic geometry; thus ")#mi("{R_j}")#text(" is non-vanishing on ")#mi("{P({\\bf C}^n)}")#text(". Thus the polynomial ")#mi("{R_j \\circ P}")#text(" has no zeroes and is thus constant; we may then normalise so that ")#mi("{R_j \\circ P = 1}")#text(". Thus we now have ")#mi("{z = Q(P(z))}")#text(" for some polynomial ")#mi("{Q}")#text(", which implies that ")#mi("{w = P(Q(w))}")#text(" for all ")#mi("{w}")#text(" in the open set ")#mi("{P({\\bf C}^n)}")#text(". But ")#mi("{w}")#text(" and ")#mi("{P(Q(w))}")#text(" are both polynomials, and thus must agree on all of ")#mi("{{\\bf C}^n}")#text(". Thus ")#mi("{P}")#text(" is bijective as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Note that Rudin’s proof gives the stronger statement that if a polynomial map from ")#mi("{{\\bf C}^n}")#text(" to ")#mi("{{\\bf C}^n}")#text(" is injective, then it is bijective and its inverse is also a polynomial.")
]

#heading(level: 1)[#text("Comments (39)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39df25627658b0dd90740966a4389fd03261c3f6eb6482782ff1b6d838bcf4d6-d168c122999e78cab3a31581ab794822e1230f8ce813c107c0a0fd0a393bcd22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fdreher")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36430")[#strong[#text("fdreher")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("To move the problem from ")#mi("k")#text(" to the finite field ")#mi("G")#text(", you suggest a field homomorphism that maps the elements of a transcendence base to ")#mi("0")#text(". But is it not true that a field homomorphism has to be injective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36435")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("Ah, you’re right (one would instead need to map the basis elements to elements of high enough degree that one can still meaningfully define all the expressions being considered here, even if it is not, strictly speaking, a field homomorphism).")

#text("Actually I was silly; since we are working inside the algebraic closure of F, k is already finite, and this step is not even needed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39df25627658b0dd90740966a4389fd03261c3f6eb6482782ff1b6d838bcf4d6-d168c122999e78cab3a31581ab794822e1230f8ce813c107c0a0fd0a393bcd22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fdreher")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36460")[#strong[#text("fdreher")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("As long as the problem is in ")#mi("\\overline{\\mathbb F}_p")#text(", there are no transcendent extensions. The situation is different in the complex case (if ")#mi("k \\subseteq \\mathbb C")#text(", but ")#mi("k \\nsubseteq \\overline{\\mathbb{Q}}")#text("), so this step (or something different altogether) is still needed to proof Theorem 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c0610557fec15b04fe8bc3efe2f71c76bb79a710c125faace160311dbc526b1-e4bfd81f1ef1f73ff2b62f147aeeede8d7a3c7f5b9ea07a748711ca1a240b09c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ricardo Menares")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36461")[#strong[#text("Ricardo Menares")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("In the proof of the Ax-Grothendieck theorem for the complex numbers you give no explanation to descend from $k$ to the number field $G$ (k may very well be not a finite extension of $\\mathbb{Q}$). I guess this happened because you erased the analog explanation for the positive characteristic case after fdreher’s comment (which is correct).")

#text("A way to deal with this is the following: define $k$ as the subring of $\\mathbb{C}$ generated over $\\mathbb{Z}$ by the coefficients of $P, Q, z_0, R$. Let $I$ be a maximal ideal of $k$. Then use the fact that $k/I$ is a finite field (Serre gives the reference Bourbaki, Algèbre commutative. Chapitre V. Entiers, p.68, cor.1 ). Equations (1) and (2) still hold in this finite field, contradicting Theorem 2.")

#text("It seems to me that you don’t even have to worry about the characteristic of the finite field being big enough, because the finitary versions of all the polynomials are well defined and (1) and (2) prevent them from being trivial.")

#text("And thanks for this great blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("Fair enough. Serre’s approach is probably the slickest, but I think I fixed the approach I had in mind (in which one “models” transcendental elements by elements in a finite field), by using some ideas of Vu, Wood, and Wood and working with the ring generated by the coefficients rather than the field. The two approaches ultimately seem to be very similar, though. (I don’t have the Bourbaki reference handy; is it easy to give a self-contained proof of the finiteness of k/I? Algebra is, unfortunately, not my strongest suit.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36483")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("Terry, I too very much like the Ax-Grothendieck theorem, which I first came across when editing a beautiful article by David Marker on this kind of thing for the Princeton Companion. I hope you’ll forgive the plug …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john mangual")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36488")[#strong[#text("john mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("this result has the same feel of the Hasse principle which says you solve a quadratic form over Q, by solving them over the p-adic numbers for each prime p and use the chinese remainder theorem.")

#text("Maybe your obstruction strategy is like proving that given a variety V in $\\latex \\mathbb{C}^n$, the set ")#mi("V_g =  \\{ p \\in V : g(p) \\neq 0 \\}")#text(" is also an affine variety. Varieties are the zero sets of polynomials and there is no reason a priori we should find polynomials which vanish precisely where g(p) is nonzero. But… if ")#mi("V = \\{ f_1 = \\dots = f_n = 0\\}")#text(" can adjoin a new variable, y, and say ")#mi("V = \\{  f_1 = \\dots = f_n = 1 - gy = 0 \\}")#text(" and this is a variety. (This example comes from a draft by David Cox on Toric Varieties)")

#text("However this example is much crazier. Above, we showed the nonvanishing of something equals the vanishing of something else. Instead we do the same thing with existence and pulling a variety quite out of thin air.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john mangual")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36489")[#strong[#text("john mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("Rather… ")#mi("V_g \\subseteq \\mathbb{C}^n")#text(" is in bijection with the variety ")#mi("\\{ f_1 = \\dots = f_n = 1 - gy = 0 \\} \\subseteq \\mathbb{C} \\times \\mathbb{C}^n")#text(" by the projection map.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c0610557fec15b04fe8bc3efe2f71c76bb79a710c125faace160311dbc526b1-e4bfd81f1ef1f73ff2b62f147aeeede8d7a3c7f5b9ea07a748711ca1a240b09c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ricardo Menares")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36504")[#strong[#text("Ricardo Menares")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Here’s a proof of the finiteness of the field ")#mi("k/I")#text(" coming from algebra, using the nullstellensatz:")

#text("Step 1. ")#mi("k/I")#text(" has positive characteristic: if not, then the map ")#mi("\\mathbb{Z} \\rightarrow k/I")#text(" is injective. As ")#mi("k/I")#text(" is finitely generated over ")#mi("\\mathbb{Z}")#text(", we conclude that the rational field ")#mi("\\mathbb{Q}")#text(" has the same property, and this is impossible (if only a finite number of rational numbers are allowed as generators, then there are only a finite number of primes that can appear in the denominators of the algebraic ")#mi("\\mathbb{Z}")#text("-span of such a generator set).")

#text("Step 2. Pass to an algebraic closure to use the nullstellensatz: let ")#mi("p")#text(" be the characteristic of ")#mi("k/I")#text(", so we have an embedding ")#mi("F_p \\rightarrow k/I")#text(". Let ")#mi("k/I \\rightarrow \\overline{k/I}")#text(" be an embedding in the algebraic closure compatible with the embedding ")#mi("F_p \\rightarrow \\overline{F_p}")#text(".")

#text("Write ")#mi("k = \\mathbb{Z}[\\alpha_1, \\ldots, \\alpha_n]")#text(", where the ")#mi("\\alpha_i")#text(" are complex numbers. We have a surjection ")#mi("\\overline{F_p}[x_1, \\ldots, x_n] \\rightarrow \\overline{k/I}")#text(" defined by the rule ")#mi("x_i \\mapsto \\alpha_i \\textrm{ mod } I")#text(" (it’s crucial here that ")#mi("k/I")#text(" is finitely generated over ")#mi("F_p")#text(").")

#text("Let $J$ be the kernell of the homomorphism above. We have ")#mi("L:= \\overline{F_p}[x_1, \\ldots, x_n]/J")#text(" isomorphic to ")#mi("\\overline{k/I}")#text(". In particular, ")#mi("L")#text(" is a field, so ")#mi("J")#text(" is a maximal ideal and the nullstellensatz then implies that $L$ is isomorphic to ")#mi("\\overline{F_p}")#text(". Hence the ")#mi("\\alpha_i")#text(" mod $I$ are algebraic over ")#mi("F_p")#text(", showing the result.")

#text("To compare with your approach based on Vu, Wood, and Wood, I would say you choose the finite field over which you “model” the trascendental elements by puting a non triviality condition on the model of the minimal polynomial of the primitive element you need. This allows for some effectivity, in the sense that if you know the polynomials giving equations (1) and (2) then you can devise some test to choose the prime ")#mi("p")#text(" (I think the primitive element theorem can be made effective too). On the other hand, in the algebraic approach above the choice of the finite field is determined by the choice of the maximal ideal (thus relying on the axiom of choice), and I don’t know if this can be explicitely done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Dear Ricardo: thanks for the proof, and the interesting comparison between approaches!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36537")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("@Ricardo Menares: “As k/I is finitely generated over \\mathbb{Z}, we conclude that the rational field \\mathbb{Q} has the same property”: This is true for modules over Noetherian rings, but is it also true for algebras over Noetherian rings?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36540")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("But one can solve it using the general Nullstellensatz in Eisenbud, Theorem 4.19 because $\\mathbf{Z}$ is Jacobson by Eisenbud, Lemma 4.20.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089af42b6de33865363accf89896726d69fbff5dbad8131d978f116cc1c48f6c-bdd943e2ac8103b7a611b6b9cd1bbf72ce462d5f55e40845e23397804164b1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Utpal Sarkar")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-36546")[#strong[#text("Utpal Sarkar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Hi Ricardo,")

#text("Is there an easy argument to show that the map ")#mi("\\overline{\\mathbb{F}_p}[x_1,\\ldots,x_m]\\longrightarrow\\overline{k/I}")#text(" is surjective (this is clear for ")#mi("\\mathbb{F}_p[x_1,\\ldots,x_m]\\longrightarrow k/I")#text(")?")

#text("One could alternatively reason that since ")#mi("k/I")#text(" is a field that is finitely generated as an algebra over ")#mi("\\mathbb{F}_p")#text(", it actually is finite over ")#mi("\\mathbb{F}_p")#text(" (this holds in general for field extensions).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricki now live « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-38204")[#strong[#text("Tricki now live « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("[…] an article on using finite fields to prove results about infinite fields which is loosely based on my own post on the topic, which is in turn based on an article of Serre.) It seems to already be growing at a reasonable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0e5a93a357d135d32f89a7292320a191ae5d2b45109aa00c941ca4eedc5d2f5-eed88e2b2ed0d68270c9989792e915304ef0c03e730e1b3466121de267cf1a25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Hughes")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-38516")[#strong[#text("Terry Hughes")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2009")])]

#text("Terry,")

#text("If you like this theorem, perhaps you would be interested in some partial converses to it proved by Ken McKenna a while ago. Here are two:")

#text("1) A generically surjective polynomial map of n-dimensional affine space over a finitely generated extension of Z or Z/(p)[t] is bijective with a polynomial inverse raional over the same ring (and therefore bijective on affine space of the algebraic closure).")

#text("2) A generically surjective rational map of n-dimensional affine space over a Hilbertian field is generically bijective with a rational inverse defined over the same field.")

#text("Both proofs use model theory. McKenna used (1) to show some curious facts about the distribution of integral points of a hypothetical polynomial map defined over the integers with Jacobian equal to 1 that did not satisfy the Bieberbach conjecture. He never published, but some of the material was eventually included in a paper by Lou Van den Dries in Manuscripta Mathematica some years back.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4899a6c320808d232367f9ec0ffe97c2d00a4a4b61233af140429f93079fe17e-d2a4ef82c46ab57c3bf97717c348097ef73bb5ec158e701de781d4a6a7fad1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L Spice")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-42769")[#strong[#text("L Spice")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("I’m probably being silly, but I was confused by your proof that an injective polynomial self-map ")#mi("P")#text(" on the algebraic closure of a finite field is bijective. Rather than using the full power of the Nullstellensatz, why not just observe that ")#mi("P")#text(" is an injective polynomial map on all the finite fields containing its coefficients, hence is bijective on any such field, and then proceed by taking limits?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-42789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")])]

#text("Ah yes, that would work too :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-43359")[#strong[#text("Jacobian conjecture « Simple or not simple?")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2010")]

#text("[…] Tao, Terence (2009-03-07). “Infinite fields, finite fields, and the Ax-Grothendieck theorem”. What’s New. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a39d63342a47e2c6c20a4116481ddc5d2a08320674ea79dcd5940db7c9cd12dd-36bb729d921774568954e45cd3a761f48fe8f3fce5478fa9dccd39948707c858.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-50592")[#strong[#text("Random")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2011")])]

#text("Minor correction: in the proof of Corollary 5, z should be mapped to a random vector in C^n, not a random complex number.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-52969")[#strong[#text("More On Coloring The Plane « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2011")]

#text("[…] A powerful meta-principle that I have discussed before is the close connection between questions about complex numbers and finite fields. For a much better explanation than I could give, please see the discussion a while ago by Terence Tao here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-169851")[#strong[#text("Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2012")])]

#text("[…] first studied systematically by Ax (in the same paper where the Ax-Grothendieck theorem, discussed previously on this blog, was established), with important further contributions by Kiefe, by Fried-Sacerdote by Cherlin-van […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The closed graph theorem in various categories « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-194635")[#strong[#text("The closed graph theorem in various categories « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("[…] several complex variables, it is a classical theorem (see e.g. Lemma 4 of this blog post) that a holomorphic function from a domain in to is locally injective if and only if it is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5884a0b7bf92a1bdd6f3cc8eba238b3ce2463a4ea5f1ae7d86830a2350e54fea-606566de2b45fd44b08dbffd4e28bdb82c3d59489462e39b310d3daea6e349ac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TH")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-225710")[#strong[#text("TH")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2013")])]

#text("Hello there,")#linebreak()#text(" it seems to me that you have to consider polynomial maps (i.e. n-tuples of polynomials) instead of just polynomials, as you do. Then the equations coming from the Nullstellensatz have to be adapted accordingly (which is not hard), etc.")#linebreak()#text(" Best regards –")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ae3095d32387e9cdbf0c3f111b4c0cd771a7fcc9231e372af282ba21c35743a-47afd6308db3dcec79069499c29ce86a068c40c7446e3cf580cbac6efa35225d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koushik Ghosh")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-246486")[#strong[#text("Koushik Ghosh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Is there some counterexample for the following “weaker jacobian conjecture for holomorphic functions” replace polynomials with holomorphic functions and instead of asking for invertibility asking just injectivity of the holomorphic map if the jacobian does not vanish or is a non-zero constant")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ae3095d32387e9cdbf0c3f111b4c0cd771a7fcc9231e372af282ba21c35743a-47afd6308db3dcec79069499c29ce86a068c40c7446e3cf580cbac6efa35225d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koushik Ghosh")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-246487")[#strong[#text("Koushik Ghosh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("The jacobian conjecture gets reduced to asking injectivity of polynomial map from the rudin’s theorem if the jacobian is a nonzero constant.So,I am asking if the same holds if polynomials are replaced by holomorphic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-451452")[#strong[#text("Théorème d’Ax-Grothendieck | Huhuw's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theo&#8230")[#text("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theo&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c98d78c824f98ebd3982a8fd218bcf7fb8ba9335c15dba8ff9588a9bc97386ec-0e406e6606824985b4969cc8c0af267257d57f2fffb98653e7a46be629506574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Loeb")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-524587")[#strong[#text("Loeb")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2019")])]

#text("Is There an example in positive characteristic")#linebreak()#text(" Of a bijection polynomial map which is not")#linebreak()#text(" An automorphism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3388a8bbc2dff53b471abe566f20c9e10218a8d17e1605e4e2bf73b7fa62bec2-bf9d47e267b5d6858660759c8142fc2add9dc55004e000e13a7c1144c5724229.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark R.")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-564526")[#strong[#text("Mark R.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Apologies if my understanding is a bit weak, but in your proof of Theorem 3 (Ax-Grothendieck theorem for algebraic closures of finite fields), if I’m understanding correctly, ")#mi("x")#text(" and ")#mi("y")#text(" are both lists of ")#mi("n")#text(" indeterminates; if so, what would ")#mi("(x - y)^r")#text(" mean in that context?")

#text("And kinda related, why do (1) and (2) each only involve one witness (")#mi("Q")#text(" and ")#mi("R")#text(") rather than a list of ")#mi("n")#text(" witness polynomials? Aren’t ")#mi("P(x) = P(y)")#text(" and ")#mi("P(w) = z_0")#text(" both systems of polynomial equations?")

#text("For this latter, I’m guessing the fix is quite easy (just replace them with many polynomials), but for ")#mi("(x - y)^r")#text(", I can’t seem to find a fix. I’m unable to find a single polynomial equation ")#mi("M(x) \\not= 0")#text(" that is equivalent to ")#mi("(x_1, ..., x_n) \\not= (y_1, ..., y_n)")#text(".")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-564650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Oops, you are right, one needs to use a system of equations rather than one equation, involving ")#mi("(x_j-y_j)^r")#text(" for ")#mi("j=1,\\dots,n")#text(". I’ve adjusted the text accordingly. Also the witnesses are not scalar polynomials, but themselves vector valued (")#mi("Q_j, R")#text(" take values in ")#mi("\\overline{F}^n")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3388a8bbc2dff53b471abe566f20c9e10218a8d17e1605e4e2bf73b7fa62bec2-bf9d47e267b5d6858660759c8142fc2add9dc55004e000e13a7c1144c5724229.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark R.")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-564888")[#strong[#text("Mark R.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2020")])]

#text("Thanks for clarifying the text. And you’re right, ")#mi("Q_j")#text(" and ")#mi("R")#text(" are indeed vector-valued (I missed it), so it makes sense now. Thanks again. Great writeup, I learned a lot!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f8f9f37deae6014403f0e3d90b6e8fd4f702ef87a40339ce282b089f68d1753-764e659d3dcfd8363df66f6d7b91ec47ab07718572de26278c8204df9758fd99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-606593")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2020")])]

#text("The notes here ")#link("http://www.cmls.polytechnique.fr/perso/laszlo/aussois/Notes10.pdf")[#text("http://www.cmls.polytechnique.fr/perso/laszlo/aussois/Notes10.pdf")]#text(" (in french…) do elaborate on your remark 4 and also provide a much easier proof for theorem 3 (Nullstellensatz looks overly complicated, but I may have missed something).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c89bbe95b1f39565dbf716860669266006d004af6b8084d9f9604b394d2371d8-66d4c70b5760176b7c61eef025444b320dc364bad6eb3ffaccfc7add3204250c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Teorema di Ax-Grothendieck - Wikipedia - SAPERELIBERO")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-644506")[#strong[#text("Teorema di Ax-Grothendieck - Wikipedia - SAPERELIBERO")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2022")])]

#text("[…] Terence (2009-03-07). “Campi infiniti, campi finiti e teorema di Ax-Grothendieck”. Cosa c’è di nuovo. Archiviato dall’originale l’11 marzo 2009. Recuperato […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744b04a8d94c2ba7a2de937a4d7ee36c6c44dc9b6c4f096ccc3dcfe330ad9d43-aa6e92b4c213fae8f79403233da9647ac98b30b476d231ffe8a236e295fd330c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sfeesh")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-682389")[#strong[#text("sfeesh")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2023")])]

#text("In the sentence starting with “Now let {k=Q[{\\mathcal C}]} be the subfield of {{\\bf C}}…” I think it should be {k = {\\bf Q}[{\\mathcal C}]}. Normally I wouldn’t be so pedantic, but boldface and non-boldface Q’s are being used in the same sentence.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-686781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2024")])]

#text("It should be ")#mi("R_j \\circ P")#text(" (composition), instead of ")#mi("R_j \\cdot P")#text(" , right? In the very end, right before Remark 7")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-686791")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2024")])]

#text("I’m confused by “in particular, there exists a non-trivial rational ")#mi("Q(z)/R(z)")#text(" such that ")#mi("P(Q(z)/R(z))=P(z)")#text("“")

#mi("P")#text(" is ")#mi("\\mathbb{C}^n \\to \\mathbb{C}^n")#text(", so what does ")#mi("Q(z)/R(z)")#text(" mean? How is it multivariate?")

#emph[#text("[Here ")#mi("z = (z_1,\\dots,z_n)")#text(" is to be interpreted as an element of ")#mi("\\mathbb{C}^n")#text(" rather than of ")#mi("\\mathbb{C}")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-686795")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2024")])]

#text("Apologies for not being clear. As I understand, ")#mi("Q(z)")#text(" and ")#mi("R(z)")#text(" live in ")#mi("\\mathbb{C}^n")#text(". Now I can’t see what ")#mi("Q(z)/R(z)")#text(" means")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-686798")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2024")])]

#text("This is shorthand for a tuple ")#mi("(Q_1(z)/R_1(z), \\dots, Q_n(z)/R_n(z))")#text(" of multivariate polynomials ")#mi("Q_i,R_i: {\\mathbb C}^n \\to {\\mathbb C}")#text(" (with none of the ")#mi("R_i")#text(" vanishing identically).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-687544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2025")])]

#text("I think Theorem 3 can be proved in a much simpler way. Given an injective polynomial ")#mi("P\\colon\\overline F^n\\to\\overline F^n")#text(", let ")#mi("G\\supseteq F")#text(" be a finite extension that contains all coefficients of ")#mi("P")#text(". Then for any finite extension ")#mi("H\\supseteq G")#text(", ")#mi("P")#text(" maps ")#mi("H^n")#text(" to itself, and it is injective, hence it is surjective by Theorem 2. Thus, the image of ")#mi("P")#text(" on ")#mi("\\overline F^n")#text(" includes ")#mi("H^n")#text(" for all finite extensions ")#mi("H\\supseteq F")#text(", and as such it is surjective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A digestion of the Jacobian conjecture counterexample | What's new")]], [#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/#comment-693735")[#strong[#text("A digestion of the Jacobian conjecture counterexample | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("[…] can be derived from the Weierstrass preparation theorem, but is omitted here; see also Lemma 5 of this previous blog post.) Also, from the fundamental theorem of algebra, once the Jacobian polynomial is non-zero, it must […]")
]
