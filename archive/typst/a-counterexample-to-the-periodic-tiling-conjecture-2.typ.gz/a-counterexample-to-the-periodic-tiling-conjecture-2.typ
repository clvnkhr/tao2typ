// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/
// Converted to Typst by tao2typ: "2026-10-14T16:39:04.632063+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A counterexample to the periodic tiling conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A counterexample to the periodic tiling conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 November 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")[#text("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.ias.edu/scholars/rachel-greenfeld")[#text("Rachel Greenfeld")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2211.15847")[#text("A counterexample to the periodic tiling conjecture")]#text("“. This is the full version of the result I announced on this blog ")#link("https://terrytao.wordpress.com/2022/09/19/a-counterexample-to-the-periodic-tiling-conjecture/")[#text("a few months ago")]#text(", in which we disprove the ")#emph[#text("periodic tiling conjecture")]#text(" of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=857454")[#text("Grünbaum-Shephard")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1369421")[#text("Lagarias-Wang")]#text(". The paper took a little longer than expected to finish, due to a technical issue that we did not realize at the time of the announcement that required a workaround.")

#text("In more detail: the original strategy, as described in the announcement, was to build a “tiling language” that was capable of encoding a certain “")#mi("{p}")#text("-adic Sudoku puzzle”, and then show that the latter type of puzzle had only non-periodic solutions if ")#mi("{p}")#text(" was a sufficiently large prime. As it turns out, the second half of this strategy worked out, but there was an issue in the first part: our tiling language was able (using ")#mi("{2}")#text("-group-valued functions) to encode arbitrary boolean relationships between boolean functions, and was also able (using ")#mi("{{\\bf Z}/p{\\bf Z}}")#text("-valued functions) to encode “clock” functions such as ")#mi("{n \\mapsto n \\text{ mod } p}")#text(" that were part of our ")#mi("{p}")#text("-adic Sudoku puzzle, but we were not able to make these two types of functions “talk” to each other in the way that was needed to encode the ")#mi("{p}")#text("-adic Sudoku puzzle (the basic problem being that if ")#mi("{H}")#text(" is a finite abelian ")#mi("{2}")#text("-group then there are no non-trivial subgroups of ")#mi("{H \\times {\\bf Z}/p{\\bf Z}}")#text(" that are not contained in ")#mi("{H}")#text(" or trivial in the ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" direction). As a consequence, we had to replace our “")#mi("{p}")#text("-adic Sudoku puzzle” by a “")#mi("{2}")#text("-adic Sudoku puzzle” which basically amounts to replacing the prime ")#mi("{p}")#text(" by a sufficiently large power of ")#mi("{2}")#text(" (we believe ")#mi("{2^{10}}")#text(" will suffice). This solved the encoding issue, but the analysis of the ")#mi("{2}")#text("-adic Sudoku puzzles was a little bit more complicated than the ")#mi("{p}")#text("-adic case, for the following reason. The following is a nice exercise in analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Linearity in three directions implies full linearity)")]#text(" Let ")#mi("{F: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" be a smooth function which is affine-linear on every horizontal line, diagonal (line of slope ")#mi("{1}")#text("), and anti-diagonal (line of slope ")#mi("{-1}")#text("). In other words, for any ")#mi("{c \\in {\\bf R}}")#text(", the functions ")#mi("{x \\mapsto F(x,c)}")#text(", ")#mi("{x \\mapsto F(x,c+x)}")#text(", and ")#mi("{x \\mapsto F(x,c-x)}")#text(" are each affine functions on ")#mi("{{\\bf R}}")#text(". Then ")#mi("{F}")#text(" is an affine function on ")#mi("{{\\bf R}^2}")#text(".")
]

#text("Indeed, the property of being affine in three directions shows that the quadratic form associated to the Hessian ")#mi("{\\nabla^2 F(x,y)}")#text(" at any given point vanishes at ")#mi("{(1,0)}")#text(", ")#mi("{(1,1)}")#text(", and ")#mi("{(1,-1)}")#text(", and thus must vanish everywhere. In fact the smoothness hypothesis is not necessary; we leave this as an exercise to the interested reader. The same statement turns out to be true if one replaces ")#mi("{{\\bf R}}")#text(" with the cyclic group ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" as long as ")#mi("{p}")#text(" is odd; this is the key for us to showing that our ")#mi("{p}")#text("-adic Sudoku puzzles have an (approximate) two-dimensional affine structure, which on further analysis can then be used to show that it is in fact non-periodic. However, it turns out that the corresponding claim for cyclic groups ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" can fail when ")#mi("{q}")#text(" is a sufficiently large power of ")#mi("{2}")#text("! In fact the general form of functions ")#mi("{F: ({\\bf Z}/q{\\bf Z})^2 \\rightarrow {\\bf Z}/q{\\bf Z}}")#text(" that are affine on every horizontal line, diagonal, and anti-diagonal takes the form")

#align(center)[#tao-fit-display[#mitex("F(x,y) = Ax + By + C + D \\frac{q}{4} y(x-y)")]]

#text("for some integer coefficients ")#mi("{A,B,C,D}")#text(". This additional “pseudo-affine” term ")#mi("{D \\frac{q}{4} y(x-y)}")#text(" causes some additional technical complications but ultimately turns out to be manageable.")

#text("During the writing process we also discovered that the encoding part of the proof becomes more modular and conceptual once one introduces two new definitions, that of an “expressible property” and a “weakly expressible property”. These concepts are somewhat analogous to that of ")#mi("{\\Pi^0_0}")#text(" sentences and ")#mi("{\\Sigma^0_1}")#text(" sentences in the ")#link("https://en.wikipedia.org/wiki/Arithmetical_hierarchy")[#text("arithmetic hierarchy")]#text(", or to ")#link("https://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic sets")]#text(" and ")#link("https://en.wikipedia.org/wiki/Semialgebraic_set")[#text("semi-algebraic sets")]#text(" in real algebraic geometry. Roughly speaking, an expressible property is a property of a tuple of functions ")#mi("{f_w: G \\rightarrow H_w}")#text(", ")#mi("{w \\in {\\mathcal W}}")#text(" from an abelian group ")#mi("{G}")#text(" to finite abelian groups ")#mi("{H_w}")#text(", such that the property can be expressed in terms of one or more tiling equations on the graph")

#align(center)[#tao-fit-display[#mitex("A := \\{ (x, (f_w(x))_{w \\in {\\mathcal W}} \\subset G \\times \\prod_{w \\in {\\mathcal W}} H_w.")]]

#text("For instance, the property that two functions ")#mi("{f,g: {\\bf Z} \\rightarrow H}")#text(" differ by a constant can be expressed in terms of the tiling equation")

#align(center)[#tao-fit-display[#mitex("A \\oplus (\\{0\\} \\times H^2) = {\\bf Z} \\times H^2")]]

#text("(the vertical line test), as well as")

#align(center)[#tao-fit-display[#mitex("A \\oplus (\\{0\\} \\times \\Delta \\cup \\{1\\} \\times (H^2 \\backslash \\Delta)) = G \\times H^2,")]]

#text("where ")#mi("{\\Delta = \\{ (h,h): h \\in H \\}}")#text(" is the diagonal subgroup of ")#mi("{H^2}")#text(". A weakly expressible property ")#mi("{P}")#text(" is an existential quantification of some expressible property ")#mi("{P^*}")#text(", so that a tuple of functions ")#mi("{(f_w)_{w \\in W}}")#text(" obeys the property ")#mi("{P}")#text(" if and only if there exists an extension of this tuple by some additional functions that obey the property ")#mi("{P^*}")#text(". It turns out that weakly expressible properties are closed under a number of useful operations, and allow us to easily construct quite complicated weakly expressible properties out of a “library” of simple weakly expressible properties, much as a complex computer program can be constructed out of simple library routines. In particular we will be able to “program” our Sudoku puzzle as a weakly expressible property.")

#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2022")])]

#text("Very, very excellent. Thanks you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669556")[#strong[#text("No periodic tiling proof – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2022")]

#text("[…] Rachel Greenfeld and I have just uploaded to the arXiv our paper “A counterexample to the periodic tiling conjecture“. This is the full version of the result I announced on this blog a few months ago, in which we disprove the periodic tiling conjecture of Grünbaum-Shephard and Lagarias-Wang. The paper took a little longer than expected to finish, due to a technical issue that we did not realize at the time of the announcement that required a workaround. … (Terence Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669560")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2022")])]

#text("Great news! Congratulations Rachel and Terry!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2022")])]

#text("This seems to be the most sophisticated mathematical application of a Soduko-like combinatorial design!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a75edac8286128b0d4e899a2e4e2601b1d30471a4849383ddf741b499b67dcd0-ad941f6a12224375189bb2fa337a573a0f4ac2878458ed85060fed0fb3f85670.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of REINALDO F CRISTO")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669790")[#strong[#text("REINALDO F CRISTO")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2022")])]

#text("Congratulations, the explanatory tags inside the paper are great, keep using this feature widely!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d512ca171a41af1190c06095ed4f8adf49cde65a930b64f20a11fcefbafafba-60485da70f03b542d93f7d2d7d588eab8266257342081a9e4440a3d1cf6588ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Apoorva Khare")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669849")[#strong[#text("Apoorva Khare")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2022")])]

#text("A few “FYI remarks”, re: (the opening) Theorem 1 in the blogpost: it appears that")

#text("(1) The test set can be reduced, in that in addition to all (anti)diagonals, one doesn’t need to use *every* horizontal line – just the X-axis will do. Or any one line through the origin, with slope not 1 or -1.")

#text("(2) This result – with the reduced test set – extends to all modules over all unital commutative rings with sufficiently large characteristic. (E.g. for “the above setting” of modules with 2 generators, 1+1 should not be a zerodivisor in the ring.)")

#text("The proof, including a quantitative refinement (which uses $B_h$-sets / Sidon sets studied by Bose-Chowla and Erdos-Turan), can be found in ")#link("https://arxiv.org/abs/2212.02429")[#text("https://arxiv.org/abs/2212.02429")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-669862")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2022")])]

#text("You tell a good story – I loved the journey! Signposts along the way point to new ideas that you’ve formulated to help you reach the destination. And seeing how and when you do so can give readers some insight into why maths has so many definitions of [multiply [adjectivally qualified]] objects; e.g., “weakly expressible property” – not a notion that would occur _naturally_ to a student!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-670405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2022")])]

#text("Quanta article: ")#link("https://www.quantamagazine.org/nasty-geometry-breaks-decades-old-tiling-conjecture-20221215/")[#text("https://www.quantamagazine.org/nasty-geometry-breaks-decades-old-tiling-conjecture-20221215/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-670744")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2022")])]

#text("Thanks for sharing this interesting explanation for non-specialists! And it’s lovely to see Terry playing with his kids’ toys! Mathematicians never DO grow up – thankfully ;-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672385")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("Another conjecture that is apparently false, is the RH. I know that this is extremely unlikely, but if you’re well-versed in basic complex analysis and basic analytic number theory, i kindly invite you to judge this 4-page paper for yourself:")

#link("https://figshare.com/articles/preprint/Untitled_Item/14776146")[#text("https://figshare.com/articles/preprint/Untitled_Item/14776146")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66568563e6a6b734ec4b9ada3b1b93a72623a9406957e38edbfe2792b4724d8b-602087049d7cb0b9b4efc0d4b19f879d0a1a4c12dfa6e14f4a6ede06e80da390.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Muon")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672528")[#strong[#text("Muon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("Unfortunately, as good as this paper evidently is, it will be very hard for it to be taken seriously by the “experts”. By now, we all know that research math operates in mafia style.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72049c29a094c03587c892118c65274d751775071f5f86424d5bc0e0284e0e43-658be7536ee2866029081acd30cc5cad91708e9a07d70e280be643cc7de3e43d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("The standard proceedure is submitting to a top journal. If the author did so, i’m pretty sure some experts are seriously looking at the paper.")

#text("But yes, it’s quite remarkable paper IMHO. Credit where it’s due.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/890eeec6b7cc0bef62cfcfb0ebbf26ba13b9598a99aaeb23b6d1016b21ca29dc-cdc63cba54a7e3d6c92a3f0dd59c55ec115863d1f0ea8e94ced945dda3ec14d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-673320")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2023")])]

#text("Does your argument also work for other L-functions ?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("sock pupetry at its finest from TK")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7d751b944ea3b56e07f6f2c154c1a4757a20bf57adf9acda3194a4faccd9ba8-80cdd04b393541c5542b46bdb1b04b26feabba45f370e88fdaf0eae97fefb056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672540")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("Well, it’s a 4-page paper claiming to solve the most important math problem of our time. It’s therefore not too unreasonable for people to be skeptical, nomatter how clear/elegant the argument is. However, i can reliably tell you that a few experts are already taking this paper seriously.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("We have heard this from TK for many years now – the so-called experts that take him seriously never materialized before and frankly if there were such, why waste time posting here to essentially spam the best math blog there is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86517a0250e0d07fac7c67edc4d116ce1bd86e1b770d5e7946e6c679dda5d914-380dfe326e07a18a2285931bc25f78c5ecb42ebbd28c82c174b5f78d9129b37c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672559")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2023")])]

#text("I have indeed worked very, very hard on the RH for many years, working under extremely difficult socioeconomic conditions, because it’s a problem that i’m deeply passionate about. I made lots and lots of mistakes in the beginning, but in the right direction i would say. The said mistakes encouraged me to work much harder and in the process, i understood the problem better.")

#text("It’s easy for you to misinterpret my posting here as “spamming”, because you have absolutely no idea of what it’s like to be in my shoes. It took a lot of sacrifice and focus forme to reach this point. We do not have any analytic number theorist in this part of the world, whereas this blog it’s a place that is frequently visited by expert analytic number theorists, some of whom are open-minded and kind-hearted enough to evaluate my paper solely on merit. That’s the reason why I’m posting here. I’m not “spamming” !")

#text("Since I’m only interested in math, i won’t respond to these type of comments any further.")

#text("Regards,")

#text("TK.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d53a5d0a81bb0e9ff47242d9f05e2d075d71434e50e3f7b9f8cfe5d6851f06-08a13e8650c86b9f26b4dcc182171f5d0ba69696ee363ff99633dd3d1e39a5f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2023")])]

#text("In this lecture:")

#text("Maynard mentions (between the 15th and 20th minutes) that there could be some zeros of zeta on the 3/4 line. Curiously, TK’s paper claims that the supremum of the real parts of the zeta zeros is at least 3/4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f7194a28a5b7ee1c082176cf7665588019821b271c0dbef1e2f32faf8bde4cd1-2527f55e9804e718046441ead4aca4db00a7c8c34c1f2f9f1cb9f3e95d13c578.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nori Kermiche")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672585")[#strong[#text("Nori Kermiche")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2023")])]

#text("This could be a nice example for Terry’s Oscillatory Integrals Lectures. The article uses both stationary and non-stationary phase methods to approximate of the zeta function in the critical strip.")#linebreak()#text(" ")#link("https://www.techrxiv.org/articles/preprint/The_Riemann_Zeta_function_using_the_Method_of_Stationary_Phase_Approximation_of_the_Van_der_Pol_Fourier_Integral/21938345")[#text("https://www.techrxiv.org/articles/preprint/The_Riemann_Zeta_function_using_the_Method_of_Stationary_Phase_Approximation_of_the_Van_der_Pol_Fourier_Integral/21938345")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2023")])]

#text("Has the work been published officially? Which journal?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2023")])]

#text("In a year or two you’ll see it in Annals, JAMS, or Acta.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2023")])]

#text("Heard this for 10+ years and it’s always next year…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2023")])]

#text("Are you slow? This paper is a few weeks old.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-672976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2023")])]

#text("of course, this particular version is a few weeks old, but it is version who knows what, 40, 80 whatever, and is fatally flawed like the others; I predict that in a few months, we have the next version proving RH again rather than disproving it like here")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d53a5d0a81bb0e9ff47242d9f05e2d075d71434e50e3f7b9f8cfe5d6851f06-08a13e8650c86b9f26b4dcc182171f5d0ba69696ee363ff99633dd3d1e39a5f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heterotic string")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-673847")[#strong[#text("Heterotic string")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2023")])]

#text("This question is directed the anonymous previous poster:")

#text("You claim that the paper is “fatally flawed”. Can you please explain for us what the “fatal flaw” is? By the way, i don’t know why you’re sounding bitter, lol.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-673283")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2023")])]

#text("The beat advanced MATH bloger in the world i ve been learning so much from YOU)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-676547")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2023")])]

#text("Any comments on the recent paper by Smith et al on an aperiodic monotile?")

#link("https://arxiv.org/pdf/2303.10798.pdf")[#text("Click to access 2303.10798.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-677426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2023")])]

#text("Professor, this very interesting work of yours, and also the recent results of Myers et al on aperiodic monotiles, seem to leave open the question of whether there is an aperiodic monotile with a tiling without reflections (just translation and rotation). Do you know of recent progress on this, or do you have an opinion on whether the answer to this question is yes or no?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-677505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2023")])]

#text("This is an interesting open question. I could well imagine that several groups of people are looking into this right now. I don’t know of any obstruction that would definitively prevent such an improved aperiodic monotile from existing, but presumably some cleverness (and perhaps some computer experimentation) will be needed to actually locate one – I doubt that the Myers et al. construction can be easily adapted in this manner (though perhaps the older Socolar-Taylor construction has a better chance, at least if one is willing to drop the connectedness requirement for now).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-678348")[#strong[#text("Wouldn't it be attainable to create a device to routinely diagram papers? - Being Teaching 2023")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2023")]

#text("[…] On account of the convention I began fascinated about what attainable pc instruments may now be developed that might be of broad use to mathematicians, notably those that don’t have prior experience with the finer points of writing code or putting in software program. One concept that got here to thoughts was a possible device to may take, say, an arXiv preprint as enter, and return some kind of diagram detailing the logical stream of the principle theorems and lemmas within the paper. That is at present carried out by hand by authors in some, however not all, papers (and may usually even be routinely generated from formally verified proofs, as seen as an illustration within the graphic accompanying the IPAM workshop, or this diagram generated from Massot’s blueprint software program from a manually inputted set of theorems and dependencies as a precursor to formalization of a proof [thanks to Thomas Bloom for this example]). For example, here’s a diagram that my co-author Rachel Greenfeld and I drew for a current paper: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Undecidability of translational monotilings | What's new")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-681826")[#strong[#text("Undecidability of translational monotilings | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("[…] the arXiv our paper “Undecidability of translational monotilings“. This is a sequel to our previous paper in which we constructed a translational monotiling of a high-dimensional lattice (thus the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-681828")[#strong[#text("Undecidability of translational monotilings | What's new - keiseronlineuniversity.com")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")]

#text("[…] to the arXiv our paper “Undecidability of translational monotilings“. This can be a sequel to our earlier paper wherein we constructed a translational monotiling of a high-dimensional lattice (thus the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some variants of the periodic tiling conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/#comment-688006")[#strong[#text("Some variants of the periodic tiling conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("[…] and in , but it can fail for for certain finite , and also for for sufficiently large ; see this previous blog post for more discussion. But now one can consider other variants of this […]")
]
