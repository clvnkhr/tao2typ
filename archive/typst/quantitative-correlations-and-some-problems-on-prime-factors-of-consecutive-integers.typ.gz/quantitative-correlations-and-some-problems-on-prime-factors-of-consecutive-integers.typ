// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/
// Converted to Typst by tao2typ: "2026-10-14T11:15:06.257855+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quantitative correlations and some problems on prime factors of consecutive integers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quantitative correlations and some problems on prime factors of consecutive integers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 December 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/")[#text("https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://sites.google.com/view/joniteravainen/home")[#text("Joni Teravainen")]#text(" and I have uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2512.01739")[#text("Quantitative correlations and some problems on prime factors of consecutive integers")]#text("“. This paper applies modern analytic number theory tools – most notably, the Maynard sieve and the ")#link("https://arxiv.org/abs/2310.19357")[#text("recent correlation estimates")]#text(" for bounded multiplicative functions of Pilatte – to resolve (either partially or fully) some old problems of Erdős, Strauss, Pomerance, Sárközy, and Hildebrand, mostly regarding the prime counting function")

#align(center)[#tao-fit-display[#mitex("\\omega(n) := \\sum_{p|n} 1")]]

#text("and its relatives. The famous ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy–Ramanujan")]#text(" and ")#link("https://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("Erdős–Kac laws")]#text(" tell us that asymptotically for ")#mi("{n \\sim x}")#text(", ")#mi("{\\omega(n)}")#text(" should behave like a gaussian random variable with mean and variance both close to ")#mi("{\\log\\log x}")#text("; but the question of the ")#emph[#text("joint")]#text(" distribution of consecutive values such as ")#mi("{\\omega(n), \\omega(n+1)}")#text(" is still only partially understood. Aside from some lower order correlations at small primes (arising from such observations as the fact that precisely one of ")#mi("{n,n+1}")#text(" will be divisible by ")#mi("{2}")#text("), the expectation is that such consecutive values behave like independent random variables. As an indication of the state of the art, it was recently ")#link("https://arxiv.org/abs/2412.17583")[#text("shown by Charamaras and Richter")]#text(" that any bounded observables ")#mi("{f(\\omega(n))}")#text(", ")#mi("{g(\\omega(n+1))}")#text(" will be asymptotically decorrelated in the limit ")#mi("{n \\rightarrow \\infty}")#text(" if one performs a logarithmic statistical averaging. Roughly speaking, this confirms the independence heuristic at the scale ")#mi("{\\sqrt{\\log\\log x}}")#text(" of the standard deviation, but does not resolve finer-grained information, such as precisely estimating the probability of the event ")#mi("{\\omega(n)=\\omega(n+1)}")#text(".")

#text("Our first result, ")#link("https://www.erdosproblems.com/248")[#text("answering a question of Erdős")]#text(", shows that there are infinitely many ")#mi("{n}")#text(" for which one has the bound")

#align(center)[#tao-fit-display[#mitex("\\omega(n+k) \\ll k")]]

#text("for all ")#mi("{k \\geq 1}")#text(". For ")#mi("{k \\gg \\log\\log n}")#text(", such a bound is already to be expected (though not completely universal) from the Hardy–Ramanujan law; the main difficulty is thus with the short shifts ")#mi("{k = o(\\log\\log n)}")#text(". If one only had to demonstrate this type of bound for a bounded number of ")#mi("{k}")#text(", then this type of result is well within standard sieve theory methods, which can make any bounded number of shifts ")#mi("{n+k}")#text(" “almost prime” in the sense that ")#mi("{\\omega(n+k)}")#text(" becomes bounded. Thus the problem is that the “sieve dimension” ")#mi("{\\sim \\log\\log n}")#text(" grows (slowly) with ")#mi("{n}")#text(". When writing about this problem in 1980, Erdős and Graham write “we just know too little about sieves to be able to handle such a question (“we” here means not just us but the collective wisdom (?) of our poor struggling human race)”.")

#text("However, with the advent of the Maynard sieve (also sometimes referred to as the Maynard–Tao sieve), it turns out to be possible to sieve for the conditions ")#mi("{\\omega(n+k) \\ll k}")#text(" for all ")#mi("{k = o(\\log\\log n)}")#text(" simultaneously (roughly speaking, by sieving out any ")#mi("{n}")#text(" for which ")#mi("{n+k}")#text(" is divisible by a prime ")#mi("{p \\ll x^{1/\\exp(Ck)}}")#text(" for a large ")#mi("{C}")#text("), and then performing a moment calculation analogous to the standard proof (due to Turán) of the Hardy–Ramanujan law, but weighted by the Maynard sieve. (In order to get good enough convergence, one needs to control fourth moments as well as second moments, but these are standard, if somewhat tedious, calculations).")

#text("Our second result, which answers a separate ")#link("https://www.erdosproblems.com/69")[#text("question of Erdős")]#text(", establishes that the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\omega(n)}{2^n} = 0.5169428\\dots")]]

#text("is irrational; this had recently been ")#link("https://arxiv.org/abs/2409.15185")[#text("established by Pratt")]#text(" under the assumption of the prime tuples conjecture, but we are able to establish this result unconditoinally. The binary expansion of this number is of course closely related to the distribution of ")#mi("{\\omega}")#text(", but in view of the Hardy–Ramanujan law, the ")#mi("{n^{th}}")#text(" digit of this number is influenced by about ")#mi("{\\log\\log\\log n}")#text(" nearby values of ")#mi("{\\omega}")#text(", which is too many correlations for current technology to handle. However, it is possible to do some “Gowers norm” type calculations to decouple things to the point where pairwise correlation information is sufficient. To see this, suppose for contradiction that this number was a rational ")#mi("{a/q}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("q \\sum_n \\frac{\\omega(n)}{2^n} = 0 \\text{ mod } 1.")]]

#text("Multiplying by ")#mi("{2^n}")#text(", we obtain some relations between shifts ")#mi("{\\omega(n+h)}")#text(":")

#align(center)[#tao-fit-display[#mitex("q \\sum_{h=1}^\\infty \\frac{\\omega(n+h)}{2^h} = 0 \\text{ mod } 1.")]]

#text("Using the additive nature of ")#mi("{\\omega}")#text(", one then also gets similar relations on arithmetic progressions, for many ")#mi("{n}")#text(" and ")#mi("{p}")#text(":")

#align(center)[#tao-fit-display[#mitex("q \\sum_{h=1}^\\infty \\frac{\\omega(n+ph)}{2^h} = 0 \\text{ mod } 1.")]]

#text("Taking alternating sums of this sort of identity for various ")#mi("{n}")#text(" and ")#mi("{p}")#text(" (in analogy to how averages involving arithmetic progressions can be related to Gowers norm-type expressions over cubes), one can eventually arrive eliminate the contribution of small ")#mi("{H}")#text(", and arrive at an identity of the form")

#metadata(none) <tao-3eca4424d164d0e02850>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("q \\sum_{h=1}^\\infty \\frac{\\sum_{\\epsilon \\in \\{0,1\\}^K} (-1)^{\\left|\\epsilon\\right|} \\omega(n + r_{\\epsilon,h+K})}{2^{h+K}} = 0 \\text{ mod } 1", block: true)]]

#text("for many ")#mi("{n}")#text(", where ")#mi("{K}")#text(" is a parameter (we eventually take ")#mi("{K \\sim \\log\\log\\log\\log n}")#text(") and ")#mi("{r_{\\epsilon,h+K}}")#text(" are various shifts that we will not write out explicitly here. This looks like quite a messy expression; however, one can adapt proofs of the Erdős–Kac law and show that, as long as one ignores the contribution of really large prime factors (of order ")#mi("{\\gg n^{1/10}}")#text(", say) to the ")#mi("{\\omega(n + r_{\\epsilon,h+K})}")#text(", that this sort of sum behaves like a gaussian, and in particular once one can show a suitable local limit theorem, one can contradict ")#link(<tao-3eca4424d164d0e02850>)[#text("(1)")]#text(". The contribution of the large prime factors does cause a problem though, as a naive application of the triangle inequality bounds this contribution by ")#mi("{O(1)}")#text(", which is an error that overwhelms the information provided by ")#link(<tao-3eca4424d164d0e02850>)[#text("(1)")]#text(". To resolve this we have to adapt the pairwise correlation estimates of Pilatte mentioned earlier to demonstrate that the these contributions are in fact ")#mi("{o(1)}")#text(". Here it is important that the error estimates of Pilatte are quite strong (of order ")#mi("{O(\\log^{-c} n)}")#text("); previous correlation estimates of this type (such as those used in ")#link("https://terrytao.wordpress.com/2018/09/10/the-structure-of-correlations-of-multiplicative-functions-at-almost-all-scales-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("this earlier paper with Joni")]#text(") turn out to be too weak for this argument to close.")

#text("Our final result concerns the asymptotic behavior of the density")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\{n \\leq x: \\omega(n+1) = \\omega(n)\\}")]]

#text("(we also address similar questions for ")#mi("{\\Omega(n+1)=\\Omega(n)}")#text(" and ")#mi("{\\tau(n+1)=\\tau(n)}")#text("). Heuristic arguments led ")#link("https://zbmath.org/0574.10012")[#text("Erdős, Pomerance, and Sárközy to conjecture")]#text(" that this quantity was asymptotically ")#mi("{\\frac{1}{2\\sqrt{\\pi \\log\\log x}}}")#text(". They were able to establish an upper bound of ")#mi("{O(1/\\log\\log x)}")#text(", while Hildebrand obtained a lower bound of ")#mi("{\\gg 1/(\\log\\log x)^3}")#text(", due to ")#link("https://zbmath.org/0591.10035")[#text("Hildebrand")]#text(". Here, we obtain the asymptotic for almost all ")#mi("{x}")#text(" (the limitation here is the standard one, which is that the current technology on pairwise correlation estimates either requires logarithmic averaging, or is restricted to almost all scales rather than all scales). Roughly speaking, the idea is to use the circle method to rewrite the above density in terms of expressions")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} e(\\alpha \\omega(n+1)) e(-\\alpha \\omega(n))")]]

#text("for various frequencies ")#mi("{\\alpha}")#text(", use the estimates of Pilatte to handle the minor arc ")#mi("{\\alpha}")#text(", and convert the major arc contribution back into physical space (in which ")#mi("{\\omega(n+1)}")#text(" and ")#mi("{\\omega(n)}")#text(" are now permitted to differ by a large amount) and use more traditional sieve theoretic methods to estimate the result.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/#comment-689201")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("This and the previous post refer to “my paper”. I think you might prefer to write “our paper”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/#comment-689205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("“Platt” -> “Pratt”")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/#comment-689206")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Hi T² —")

#text("Here’s a related line of inquiry you might like to take up —")

#text("• ")#link("https://oeis.org/wiki/Riffs_and_Rotes")[#text("https://oeis.org/wiki/Riffs_and_Rotes")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert D. Silverman")]], [#link("https://terrytao.wordpress.com/2025/12/01/quantitative-correlations-and-some-problems-on-prime-factors-of-consecutive-integers/#comment-689246")[#strong[#text("Robert D. Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2025")])]

#text("May I suggest that it would be nice to find improvements in methods for finding prime divisors? It’s been 35 years since we had a new algorithm (NFS).")
]
