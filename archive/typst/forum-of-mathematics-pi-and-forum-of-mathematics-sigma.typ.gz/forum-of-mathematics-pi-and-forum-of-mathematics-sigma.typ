// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/
// Converted to Typst by tao2typ: "2026-10-14T16:36:52.082081+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Forum of Mathematics, Pi and Forum of Mathematics, Sigma", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Forum of Mathematics, Pi and Forum of Mathematics, Sigma")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 July 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/")[#text("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("For the past few months, ")#link("http://www.cambridge.org/home/home/item5655304/")[#text("Cambridge University Press")]#text(" (in consultation with a number of mathematicians, including Tim Gowers and myself) has been preparing to launch a new open access journal (or more precisely, a complex of journals – see below) in mathematics, under the title “")#link("http://journals.cambridge.org/forumofmathematics")[#text("Forum of Mathematics")]#text("“, as an experiment in moving away from the traditional library subscription based model of mathematical academic publishing. (The initial planning for this journal happened to precede the ")#link("http://thecostofknowledge.com/")[#text("Cost of Knowledge boycott")]#text(", but the philosophy behind the journal is certainly aligned with that of the boycott, which I believe is further evidence that the time has come for mathematical journal reform.) The journal will formally begin accepting submissions on October 1st, but it has already been ")#link("http://www.cambridge.org/home/news/article/item6968539/")[#text("officially announced")]#text(" by Cambridge University Press, with an ")#link("http://journals.cambridge.org/action/displaySpecialPage?pageId=3896")[#text("editorial board")]#text(" (with Rob Kirby as managing editor, thirteen other editors including Tim and myself, and a board of associate editors that is still in the process of being assembled) and ")#link("http://journals.cambridge.org/images/fileUpload/images/Final_FAQs_26-06-2012.pdf")[#text("FAQ")]#text(" already in place.")

#text("In many respects, Forum of Mathematics functions as a regular mathematics journal, in that papers are submitted by the authors, sent out to referees by the editors, and (if accepted) published by the Forum. There are however a couple of important features that distinguish the Forum from traditional mathematics journals. The first is the open access, publication-charge based publishing model (sometimes known as “gold open access”). Namely, all articles will be freely available without subscription charges, but authors, upon their paper being accepted, be asked to pay a publication charge to cover costs. The publication charges will be set at zero for the first three years, and then raised to somewhere around £500 GBP or $750 USD after the initial three-year period (with fee waivers available for authors from developing countries). (One reason that the publication charges are not entirely fixed at this point is that there is the possibility of obtaining additional funding sources for this journal, for instance from philanthropic organisations, which may allow for fee reductions or additional waivers.) This is of course a non-trivial sum of money, but it is significantly lower than the charges for most other gold open access journals. Also, editorial decisions will not be influenced by the author’s ability to pay for the charges, which only come into effect in the event that the paper is accepted for publication.")

#text("(One way in which Cambridge University Press is keeping costs low, by the way, is to keep the journal purely electronic, with physical issues available on a print-on-demand basis only. A side benefit of this choice is that there is no hard constraint on how many or how few pages will be published each year, so that acceptance decisions will not be influenced by artificial constraints such as the size of the journal backlog.)")

#text("Another distinctive feature of Forum of Mathematics lies in its scope and structure. It is not exactly a single journal, but is instead a complex consisting of a generalist flagship journal (officially known as Forum of Mathematics, Pi) and a specialist journal (Forum of Mathematics, Sigma) which is in turn loosely organised for editorial purposes into “clusters” for each of the major subfields of mathematics (analysis, topology, algebra, discrete mathematics, etc.). As a first approximation, Pi is intended as a top-tier journal (on the level of, say, the Journal of the American Mathematical Society, Inventiones, or Annals of Mathematics) that only accepts significant papers of interest to a wide audience of mathematicians, while Sigma resembles a collection of specialist journals, one for each major subfield of mathematics. However, the journals will be using the same editorial interface, and so it will be possible to easily transfer a submission between journals or clusters (while retaining all the referee reports and other editorial data). This is meant to help address a common issue in traditional mathematical journals, namely that if the editorial board decides that a submission falls too far outside the scope of the journal, or is not quite at the desired level of quality, then the authors have to start all over again with a new journal (and new referee reports). Of course, it is still possible (and perhaps even fairly common) that a submission to Forum of Mathematics will be deemed unsuitable for either Pi or Sigma, and thus rejected entirely; but the structure of the Forum should give some additional flexibility, to reduce the frequency that papers are rejected for artificial reasons such as being out of scope. (Of course, we would still expect authors to aim their submission at the most appropriate location to begin with, in order to reduce the time and effort expended on processing the paper by everyone involved.)")

#text("Further discussion of this journal can be found ")#link("http://gowers.wordpress.com/2012/07/02/a-new-open-access-venture-from-cambridge-university-press")[#text("at Tim Gowers’ blog")]#text(". It should be fully operational in a few months (barring last-minute hitches, we should be open for submissions on 1 October 2012). Of course, a single journal is not going to resolve all the extant concerns about the need for journal publishing reform, such as those raised in the ")#link("http://thecostofknowledge.com/")[#text("Cost of Knowledge boycott")]#text("; but I feel that it is important to have some experimentation with different publishing models, to see what alternatives to the ")#emph[#text("status quo")]#text(" are possible.")

#heading(level: 1)[#text("Comments (105)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df84c9526a0fa890c7cc0044ff2461923824615ecc25a09f9dda8d82e5de5e2e-de41318dc711d1596e0dfbd57201831314f701f00a5fb0def8b218bb50f52866.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark N.")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149791")[#strong[#text("Mark N.")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("I’m unsure if it’s due to disciplinary differences or differences in scope, but after having discussed this with several people in several contexts, I must admit I’m still confused as to why these “gold” open access charges are necessary, especially since, in mathematics at least, the authors are able to do their own typesetting in LaTeX. In computer science, the top journal in machine learning, the ")#emph[#text("Journal of Machine Learning Research")]#text(", follows just such a model of being both open-access and free-to-publish. And, it doesn’t do that due to generous funding or fundraising, but just because it costs almost nothing to operate. MIT donates server space to host its online presence, reviewers and editors as per usual practice are not paid, and that’s the extent of the necessities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149822")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("I don’t have a detailed breakdown of costs, but I believe there will be some paid employees (or fractions thereof) at CUP to handle some typesetting, web design, publicity, and so forth. Certainly one could imagine a more bare-bones setup with no paid employees, and there are examples of such journals out there (e.g. the Electronic Journal of Combinatorics), but there would be more limits as to how such journals could scale up in size, as well as occasional technical issues when a donor is no longer able to supply essential support, such as web servers or unpaid technical assistance. (Also, from a more capitalistic point of view, I think that the existence of a revenue stream can help a project such as this outlast its initial founders.)")

#text("But I think that low cost journals and even lower cost journals should be able to coexist; as I said in the post above, I don’t view the FoM model as the only solution to reforming the journal publishing system, but I think it is a step in the right direction, and I hope that there will soon be several other journals in mathematics that will be experimenting with alternative publishing models.")

#text("(One advantage I see in a publication-charge model, by the way, as opposed to a library subscription-based model, is that there will be a more meaningful price competition; an author can certainly take comparison of publication charges into account when deciding what journal to submit to, but libraries are more or less forced to subscribe to both cheap and expensive non-open-access journals in order to obtain something close to comprehensive access to literature. I’d be happy to see FoM compete on both price and quality with other open-access journals in the near future…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/539a832ffa713fd33af5ef1d4e5f7ecb977d5258eea61b724e2ea8fee59f7b4f-cfee8a548c6fdbb835956c80868a68a60c455003c6d8cc0be449e284a5c44293.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark N.")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149890")[#strong[#text("Mark N.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("That’s reasonable; thanks for the thoughtful reply! I do hope the endeavor succeeds, and think it will be an important improvement in access to mathematics research. In particular, if it will follow the common practice where fees are waived for authors who aren’t able to pay the fee, that should avoid the biggest worry about fees creating barriers to publishing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150232")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("CUP has said explicitly that they will waive fees for authors who can demonstrate that they do not have access to appropriate funds for paying them. (This can be found in the FAQ that Terry links to in the post above.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3cb4ca1b189ab5e1e58a4a0979954e097efb67d066e50eba1d6454a3bd98d12-8146089f8c2af3fb4f4defecb64f1004a18d2a1b9b021624b29f10a911d90f60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonin Chambolle")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-153199")[#strong[#text("Antonin Chambolle")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2012")])]

#text("Dear Terence, that’s perfectly understandable, but on the other hand, Cambridge University (and all major universities) is paying a lot in subscriptions: if all these institutions were dedicating the corresponding expenses to the publication of open access journals, then they probably could also fund the editing process and staff… Of course there is a big difficulty: how could we organize the transition from one system to the other? And Elsevier and Springer’s shareholders might not like the idea.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo Fernandes")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149813")[#strong[#text("Marcelo Fernandes")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2012/07/03/219/")[#text("Marcelo Fernandes de Almeida")]#text(" and commented:")#linebreak()#text(" Here in Brazil there is a WebQualis for journals, and the most important journals are based in Journal Impact Factor (JCR). It journals are classified in a decrescent quality A1, A2, B1,…, B5. For example, “Inventiones mathematicae” is A1. So, how to qualify Forum of Mathematics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149823")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("Well, my preferred long-term solution here would be to decrease the reliance of university administrators and funding agencies on these sorts of citation indices and journal rankings, but this is a separate long and ongoing struggle which this project is not intended to directly address. We will of course be trying to get the highest quality papers that we can published in these journals; hopefully, they will be well cited, and will thus presumably have a respectable showing with regards to the various indices and rankings out there once enough time has passed and enough papers have appeared in the journal, but we are not going to try to “game” these indices directly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a865e28b69cf0588f5e5abbbeb464705627f26e6687d6683267556d942210b78-edf89fe94f375e7fbff46c1d7295af22e44d8fcb461799574515406d20c67276.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neil Cuadra")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149815")[#strong[#text("Neil Cuadra")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("Given the electronic nature of these journals, might a paper that crosses cluster boundaries be permitted to appear in more than one Sigma journal? For example, would a paper on algebraic topology, say reporting new applications of the Borsuk–Ulam theorem, be limited to just the topology cluster or just the algebra cluster, even if the editors and referees span both clusters and find the paper suitable for either? The one-to-one (paper-to-cluster) model requires a best fit approach that could keep quality papers from being seen by subscribers who focus on a particular area of interest. What are the tradeoffs between a one-to-one model and a one-to-many model?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149820")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2012")])]

#text("The clusters are mostly for internal administrative purposes, determining which group of editors (and associate editors, once this group has also been selected) will primarily deal with the submission. If a paper spans several clusters, then that will just mean that a different set of editors will be dealing with the paper. I think the idea is to treat Sigma as essentially being a unified journal, with the clusters being merely a secondary designation (much as, say, the arXiv subcategories (math.CA, math.NT, etc.) are to the math arXiv).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/684fc750c76c764057af6a95cdad100e6499dc133fbb54d39ccbe88a532c8b92-3e5e8edf5f2b05aaa2694a86b3844d086ba35e56c586b860b66e678a56453396.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sangameshwar Patil")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149889")[#strong[#text("Sangameshwar Patil")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("It could be useful to look at Journal of Machine Learning Research (JMLR: ")#link("http://jmlr.csail.mit.edu/")[#text("http://jmlr.csail.mit.edu/")]#text(" ) which is similar in spirit and a successful experiment in open access journal publishing. JMLR is among the top-tier journals in Machine Learning / Computer Science and also enjoyed the highest impact factor in machine learning area.")

#text("Regarding cost of management, this blog could be quite useful ")#link("http://blogs.law.harvard.edu/pamphlet/2012/03/06/an-efficient-journal/")[#text("http://blogs.law.harvard.edu/pamphlet/2012/03/06/an-efficient-journal/")]#text(" It claims (update of 18th March 2012) the cost per article for JMLR is approx $ 6.50. Even if we factor in the server hosting cost etc., I guess the JMLR per article cost would significantly lower than the projected cost for these fora. There could be many things that can be learnt / re-used from the JMLR model.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efec18835293329a340c1ba7c2bd3eed5e4047807410a02055858659e755b906-523221dee35c9c30ca99daa59b76e98a9c97d4d7f994554d8ed3dd5526fa7f92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Cohn")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150372")[#strong[#text("Henry Cohn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("The $6.50 counts only the monetary costs, by putting a value of zero on the large amounts of volunteer labor behind the scenes. Running a volunteer journal is a wonderful contribution to the community, but it’s not actually saving nearly as much as it seems to (just moving it off the balance sheet), and I’m not convinced massive volunteerism would be the most efficient way for the community to handle the non-mathematical aspects of running our publication system.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Essentially all of the technical volunteer labor (editing, refereeing, etc) is still present in this proposal (or any of the others I have seen). Typesetting, copy editing, and web design are really the only services that will be handled by CUP in exchange for the $750 (aside, of course, pestering people to pay the $750). I don’t see the harm in omitting these `added value’ services altogether by having the journal consist solely of a plaintext file consisting of a list of `accepted’ arXiv numbers (I’ll even spring for hosting the plaintext file!).")

#text("This isn’t even inconsistent with preserving the fancy copy editing, typesetting, and web design for those who appreciate it. We could also allow CUP, Elsevier or anyone else to prepare web and print services with all of these `added value’ frills. If some consumers feel the frills are worth the money then they will be free to purchase access to them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-153245")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2012")])]

#text("Right! There should be no problem refereeing a quarter of a page article containing a statement of a theorem, followed by “Proof. See arxiv:1234.5678v2”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60206d41a404eb8bdf7a9a9b59ee982ceb0d347a2c54dde08f347850691c3cc9-e1143ae1b28cbe3efaefb9e1472d91c3cfeea91b6596a3b722d64796ddc50e18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aram")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150407")[#strong[#text("aram")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Henry, I’m really curious: what volunteer labor do the JMLR editors have to do? (To pick an example that a lot of people have been discussing.) That is, beyond the labor that any volunteer editor or referee would do anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efec18835293329a340c1ba7c2bd3eed5e4047807410a02055858659e755b906-523221dee35c9c30ca99daa59b76e98a9c97d4d7f994554d8ed3dd5526fa7f92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Cohn")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150513")[#strong[#text("Henry Cohn")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("Regarding non-scholarly volunteer labor, it adds up fast even if there’s only a small amount. If you assume a $100k salary on average (presumably an underestimate for JMLR editors) and 50% overhead for benefits, office space, etc., then that’s $75/hour. You’re certainly right that the scholarly aspects of editing/refereeing are a much bigger time commitment than the other activities. However, even if you omit typesetting and copyediting completely, some other work is needed. Secretarial tasks, website administration, permanent archiving, IRS filings (something JMLR hasn’t always kept up with), etc. JMLR publishes about a hundred papers per year, so if these other tasks occupy just a total of two hours per week for all the editors combined, then that’s already $75/paper in implicit costs. And I can’t believe they operate a journal with only two hours per week total beyond the academic activities. (I imagine nobody is keeping careful track of hours, so nobody has good data on this, but the truth is surely substantially higher.) I’d bet that the total costs of running JMLR are well under $750/paper even if one accounts for everything, because they do get savings on copyediting and typesetting (although I’m not convinced it’s a good deal). However, they are nowhere near a hundred times cheaper.")

#text("Part of the difficulty with volunteer journals is that they typically depend on a core of really committed volunteers who take care of the things nobody else wants to do. That can work beautifully, and I certainly don’t mean these comments as a complaint, but it’s probably not scalable to the entire publishing system. There are not so many people who want to do this, who are capable of doing it well, and who will stick with it for years until they recruit a successor.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-149996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2012")])]

#text("This mimics PLoS journals, correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150101")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("The Public Library of Science journals are also based on the “gold open access” publishing model, and are perhaps the best known example of such journals in the sciences, although I think CUP is not aiming for an exact duplicate of those journals here. (For instance, the publication charges of FoM will be about half or less of those of PLoS.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0400076dc057edec8e589d61f82aa09f2ad678d733f172986432c23791c9fb69-04792883ed12fe6555927c881fe80c2f011f37d6ac74323047454ce0604dc4f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bobito")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150031")[#strong[#text("Bobito")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("It seems to me ridiculous to consider a journal with publication charges as an improvement. In mathematics there have never been publication charges, and their imposition is a great burden for researchers from most countries, not just “developing” countries, particularly because the proposed fees are considerable. How in the world is such a system an improvement over what Elsevier does?")

#text("Finally, the proposed fees are quite large for researchers even from many European countries. Budgets, salaries, and grants are not like in the US.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150108")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("Well, the improvement comes from the library side of the equation; it typically costs a library a few thousand dollars (or euros, etc.) a year to access each non-open-access journal in mathematics (and, in many cases, the cheapest option for libraries is to lock into a bundle of hundreds of journals – including many journals which the library users do not want or use – for hundreds of thousands of dollars). These costs may not be as immediately visible to an author as a publication charge, but they are definitely present and non-trivial; the cost of these journals will mostly be paid by departments, universities and/or the national government, and is thus directly competing with availability of funds for individual researchers.")

#text("On Tim’s blog it was suggested that journals such as FoM allow for a “subscription” by libraries which would allow for a waiver of publication charges by all authors affiliated with that library’s institution; this is certainly an interesting idea, as it makes the comparison of total costs on a university between traditional journals and these sorts of journals clearer.")

#text("As I said in the main post, though, this is just a single journal, and is not intended as the unique solution to journal publishing reform. I think the important thing in the near term is to experiment with as many publication models as possible, to get a better idea of what systems one could feasibly transition to that improve upon the status quo.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150339")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Hi Terry,")

#text("“I think the important thing in the near term is to experiment with as many publication models as possible,” – It is very unfortunate to think of a journal which you hope to have the level of the Annals as an “experiment”. You let junior mathematicians to submit there their best papers, and then you say “the experiment is over, lets start with another model”?")

#text("One think is journal pricing. It is important, but libraries should care primarily, and I am actually surprised it is not them initializing the discussion. Us, mathematicians should mostly aim to create an enviroment which for example helps good young collegues get good jobs; and unstable journals with varying reputations will not do.")

#text("Somewhat unrelated to this: how much people know about conditions ordinary mathematicians work in? Do they have access to journals, would their institutuion give them $750 for publishing a paper, in what countries are some stupid numbers (IF, …) the only decisive factor for getting a job or a grant? It seems that this would deserve some serious statistics if you are trying to do something big.")

#text("Best regards,")#linebreak()#text(" -K")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("I view this journal both as an experiment (in the sense that it will collect new and useful real-world data about publishing models) and as an ongoing concern. I hope it succeeds in the long-term, of course, though possibly with some changes to the journal structure in the future as we gain a better understanding of what works well and what works less well.")

#text("Since you bring up the Annals, it’s worth noting that they also tinker with their model from time to time; for instance they experimented for a few years with an arXiv and Project Euclid overlay of all of their newly published papers, although they were forced to cancel this experiment after libraries started dropping subscriptions to the Annals in large numbers; see e.g. ")#link("http://sbseminar.wordpress.com/2012/02/01/journals-and-the-arxiv/")[#text("this blog post")]#text(" for some discussion of these events. It’s unfortunate that that particular experiment didn’t work, but the Annals of course survives with its reputation intact, and some useful data was gained from the experience. (In particular, we now know that even a journal as prestigious as the Annals will still find an inherent conflict between a subscription-based funding model and full open access.)")

#text("The journal pricing issue is one which is difficult to solve by libraries alone, due to an agency problem: it’s the academics, rather than the librarians, who choose where to submit their work, and who request what set of research papers are of highest priority to gain access to. So a large part of the solution has to lie with having the academic community change their behaviour with regards to their interaction with the journal publishing system. One component of that – though certainly not the only component – is in allowing for a diverse range of quality journals that one can submit to, so that one is not forced to submit to a journal with an undesirable publication model because it is the only good alternative in that subject. Because of this, I think that it is worthwhile to try to have at least one decent set of maths journals using the gold open access model, while simultaneously believing that it is also important to have good maths journals that use models other than gold open access. The philosophy here is to increase the number of genuinely different options available to authors, rather than to decrease them. (Note that the mere existence of the Forum of Mathematics journals by no means prohibits an author from submitting to a more traditional journal from either a commercial or non-commercial publisher, if he or she so desires.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150367")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("“Note that the mere existence of the Forum of Mathematics journals by no means prohibits an author from submitting to a more traditional journal from either a commercial or non-commercial publisher, if he or she so desires”")

#text("In other words, if you don’t like FOM, then don’t publish in it, publish elsewhere. It’s alright, FOM will be OK. I’m Terry Tao and a whole lot of mathematicians will follow my lead regardless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DejaVu")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150375")[#strong[#text("DejaVu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("“Note that the mere existence of the Forum of Mathematics journals by no means prohibits an author from submitting to a more traditional journal from either a commercial or non-commercial publisher, if he or she so desires.”")

#text("In this paragraph, replace “Forum of Mathematics” by “Advances in Mathematics” or “Journal of Functional Analysis”, and what you get would be statement from a tactless Elsevier executive. On whose shortsightedness would have him fired immediately.")

#text("You’re the best at Math Terry. Period. You’re very bad at this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150442")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("The Annals was experimenting with various ways how to get money, and being open access. But they never hazarded with their reputation. So all the time there has been a clear message which has been pretty well understood even by people outside the community: “this guy published in the Annals so we should give him this grant, fellowship, …”. Of course such a message is a huge and unfair simplification but among all such simplifications this is probably the best one; and the current world needs simplifications.")

#text("What I am concerned with is that these “experiments” will result in a lack of easily identifieble criteria of quality of research. What you, Tim Gowers, and some other influential mathematicians do creates an uncertain and unsecure enviroment (On the other hand I should say that it may be that this impact is really tiny, and that if say a PhD student gets a paper in the Inventiones it will remain to be evaluated as a great achievemtn for at least 5 more years. I cannot judge).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150146")[#strong[#text("New Maths Journals | Kevin Houston")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")]

#text("[…] pop over to Tim Gower’s blog to see this announcement on new journals. There’s also a little bit on Terry Tao’s blog. It looks like this could be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Outraged")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150292")[#strong[#text("Outraged")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Well, here is a possible way to read all this: You boycott a publisher so you can launch your own project with another publisher and then ask for $750. $750??? You got to be kidding me. Don’t you see that as kind of losing touch with reality a little bit…? Can’t you come up with a less expensive “experiment”?")

#text("“Also, editorial decisions will not be influenced by the author’s ability to pay for the charges”. Really? Can you completely vouch for this? How?")

#text("Your explanation on how “the improvement comes from the library side of the equation” is terribly weak. If CUP will sell bundles unless $750 are paid, then CUP is part of the problem and you’re conniving at their extortion.")

#text("It’s saddening to read the most brilliant mathematician of our time babbling about publications costs and their breakdowns. You’re way out of your element and hopefully your reputation won’t suffer much from this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("I expect it’s something like PLOS: the publication charges are handled by the administrative side of the journal. The editorial side (referees etc.) who handle the submissions, see only the content and they aren’t told (and hopefully don’t care) whether the author has asked the administrative side for a fee waiver. The decision to publish is made by the editorial side independently of the fee arrangement. I’m not too worried about this aspect since many journals have page charges. I don’t think they’re a particular problem for PLOS, for example.")

#text("I have to admit not really understanding what good the CUP bureaucracy does in this picture. The journals could be done without them, as JMLR shows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150796")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2012")])]

#text("Politics of T. Gowers")#linebreak()#text(" owl-sowa.blogspot.com")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151179")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Dear Outraged, before talking about losing touch with reality, do you have any idea how much money is spend by universities all over the world to subscribe to journals? It’s a number difficult to estimate, but it is easily estimated to much more than 750$ (I would say between two times and ten times as much).")

#text("For example, a 30 pages article published in Crelle costs about 40$ for each subscriber (and a given subscriber pays 40$ for each such article published). So the total amount of money spent for a typical Crelle paper may easily be up to ten times this 750$ fee. There are well funded objections to this model, but it is outrageous to act just as if the current model was perfect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151202")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Sorry, but I do not think any of us can make any calculations about the costs of a journal subscription within a factor of 2 or 10. (I am certain I cannot do this within a factor of 20, likewise I am unable to get the price of a space ship within a factor of 100).")

#text("But still the argument is this: there are existing, good journals, which run at cost 0. New York Journal of Math, Electronic Journal of Combinatorics,… And I am missing any argument why the total volume of papers published in these truly free journals could not be bigger. These journals give stamps of quality, they produce pdf file which anyone can print – and that is all what we need. I agree a greater variety of them would be good; for instance in discrete math all the better ranked journals are run by commercial publishers. But that is exactly how top mathematicians should take part:submit there best papers to either existsing or new truly open access journals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151209")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Concerning the costs, see ")#link("http://svpow.com/2012/07/09/what-does-it-cost-to-publish-a-paper-with-elsevier/")[#text("http://svpow.com/2012/07/09/what-does-it-cost-to-publish-a-paper-with-elsevier/")]#text(" I also computed the ratio between the total amount my department pays for subscriptions and the number of papers we publish, and I got a ratio of at least 1300€ per published paper (this is very rough for estimating total costs, but gives a precise idea of how my department will do in this new context: far better).")

#text("Concerning the free journals, it is great that they exist, but they rely a lot on the time of scientists, which is neither free nor infinite. I do not think we can scale them to the entire system unless we find a huge lot of new volonteers, and I am not sure it would be the wisest way to spend our time.")

#text("Moreover, I feel copy-editing is a good thing to keep at least for the papers that are likely to be read by a lot of people, while it would probably be harmless (maybe even efficient) to drop it for most papers. Having scientists do copy-editing seems not really the best move either, that’s why I can see the use of a somewhat expensive (but much cheaper that the average) journal at a high level. Funding it via institutions would be better than on a paper by paper basis, though.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Outraged")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150298")[#strong[#text("Outraged")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Two concerns about CUP:")

#text("1. What was Cambridge University Press’ *definite* position on the Research Works Act? I mean the *official* and *definite* announcement of their position on RWA.")

#text("2. How about the Cambridge University Press et al. v. Patton et al. case?")

#link("http://en.wikipedia.org/wiki/Cambridge_University_Press_v._Patton")[#text("http://en.wikipedia.org/wiki/Cambridge_University_Press_v._Patton")]#linebreak()#text(" ")#link("http://chronicle.com/article/Whats-at-Stake-in-the-Georgia/127718/")[#text("http://chronicle.com/article/Whats-at-Stake-in-the-Georgia/127718/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5858e7dc96e34f4692ba10c86561345a3483955ecaf1c6007e714ea59add1b3c-2b13cb6469b58d5ec49ddedf893612988fc709c00df6149574bf4bf8e05f013c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Alcala")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150307")[#strong[#text("Jose Alcala")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Why would an author pay money to make his work available for free? Maybe the next step is for authors to start paying readers to read.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/979b4e1d0aa3ed0f6c9237fdb8d88ccbce5851da43fa8e8584f176da93bfd742-082afc4a9fef7454ab195b7f94a2f2cb2425c51ae606a8627144d5d6c7432471.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150352")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("I think $750 is way more expensive than is warranted. A handful of math grad students (with standard TA-level stipends and tuition waivers) ought to be able to handle any additional-to-the-submitter’s-own typesetting that is needed. What, exactly, is the “problem” with the Electronic Journal of Combinatorics’ model, that warrants these new journals be handed over to CUP?")

#text("It is good that at least these journals (according to the FAQ) are moving away from the barbaric practice of making authors sign over their own copyrights. (Of course, for Seven-Hundred-Fifty-Freakin’-Dollars, I’d *BETTER* be able to keep the copyright!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efec18835293329a340c1ba7c2bd3eed5e4047807410a02055858659e755b906-523221dee35c9c30ca99daa59b76e98a9c97d4d7f994554d8ed3dd5526fa7f92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Cohn")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150371")[#strong[#text("Henry Cohn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Actually, a handful of math grad students with standard TA-level stipends and tuition waivers is really expensive: about $50-60k each at most universities. If a journal publishes 200 papers at $750 each, then that’s enough to fund three TAs, and you’ve already used up all the funding. To get the actual costs down to $750/paper you’ve got to be more efficient than that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/979b4e1d0aa3ed0f6c9237fdb8d88ccbce5851da43fa8e8584f176da93bfd742-082afc4a9fef7454ab195b7f94a2f2cb2425c51ae606a8627144d5d6c7432471.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150374")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("I’m one of those grad students and I (and my credit union) beg to differ. I make less than $20,000 before taxes, and I’m pretty sure I’m not being ripped off by a factor of over 100%. And grad students from other departments consider me to be extremely lucky to get that much! I mentioned the tuition waiver because to the student, it is part of the compensation package, but please remember that to the *university*, it is free (even though they try their very hardest to hide this with sleight of hand, making their own departments pass imaginary money back and forth to each other)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a28963456d7a9be6f33c72157605272a54577f998b78bd8129b2a40c06b6d5-95aa5c5c712d24820a96c68bd41607ebf832eef678ca4cbc90532306e36d1fdf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. Hampton")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150378")[#strong[#text("M. Hampton")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("No, your tuition is definitely NOT free to the university. Do you think the professors that teach your graduate classes are free to the university?")#linebreak()#text(" Also, besides tuition, you probably receive some health care through the university – even if you pay some sort of deductible it is heavily subsidized. Then there is office space, and a long tail of other costs. $50,000 total is not unrealistic.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150439")[#strong[#text("Ghaith")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("I think this is possibly getting off-topic, but while I don’t understand anon’s point, I feel the estimates of the cost of a TA that are mentioned (“$50-60k”, or “$50,000 total”) might be a little absurd since they seem to suggest to me that a TA costs nearly as much as a post-doc at most universities… is that really true??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efec18835293329a340c1ba7c2bd3eed5e4047807410a02055858659e755b906-523221dee35c9c30ca99daa59b76e98a9c97d4d7f994554d8ed3dd5526fa7f92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Cohn")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150451")[#strong[#text("Henry Cohn")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text(">since they seem to suggest to me that")#linebreak()#text(" >a TA costs nearly as much as a post-doc")#linebreak()#text(" >at most universities… is that really true??")

#text("Postdocs don’t need the tuition coverage,")#linebreak()#text(" but they typically earn more money. How this")#linebreak()#text(" works out depends on how generous the salary")#linebreak()#text(" is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150457")[#strong[#text("Ghaith")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("Thanks for your comment. But I still don’t really understand this: e.g. “depends on how generous the salary is”… isn’t that already taken care of since implicitly, to facilitate the current discussion, one sort-of performs an anecdotal average over many universities, since otherwise it’s hopeless to attach meaning to many posts? In any case, I’m still not able to tell — though, again, this might be getting off-topic –: Is the claim that a TA costs as much as a post-doc at most universities? Is this a generally accepted impression? Perhaps part of the reason I’m pressing this point is because I wonder if this type of accounting resembles what’s used to calculate the cost of “publishing” an article in a journal…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c58d20ac76d30688691ba02cd1ba2090efa08a031aa044e1c84aebfd3e7a2b2-c6238ca5fb438c878029dd135258924aab53e9fd3b29079ad77063ed9f9048bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noah Snyder")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150707")[#strong[#text("Noah Snyder")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("The comparison in costs between a postdoc and a graduate student are very different for public and private schools and for foreign and domestic students. For private schools or for foreign students, the costs are indeed often roughly comparable. But for domestic students at state schools tuition after the first year is typically in-state and so graduate students are genuinely much cheaper than postdocs. However, remember that part of the hidden costs (benefits and space) apply at least as much to postdocs as to graduate students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150715")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("A rule of thumb that I’ve heard (but unfortunately can’t remember a source for) is that the cost of non-monetary benefits (primarily health care) and supporting administration (payroll, HR, office maintenance) for a white collar employee is roughly equal to that employee’s salary. If so, postdoc’s cost a university a lot more than $50,000.")

#text("By the way, as I understand it, tuition waivers are a net-zero for the UNIVERSITY; they are a cost to the DEPARTMENT.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/979b4e1d0aa3ed0f6c9237fdb8d88ccbce5851da43fa8e8584f176da93bfd742-082afc4a9fef7454ab195b7f94a2f2cb2425c51ae606a8627144d5d6c7432471.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150353")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("For a short paper of a not-too-difficult-to-follow nature, I think a better option for the author would be to put the paper on the arXiv and then pay 150 grad students $5 each to read the paper and take a short quiz to prove they read it. Or 15 grad students $50 each or 30 grad students $25 each or etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of volunteer")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150360")[#strong[#text("volunteer")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Forget about TAs, for this money even professors would jump at the opportunity!!!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/762147f87d5f3807bb0e2aae39b62a7c9ea16e249553e49a1541132b9375bfa0-45a35fce32fe84d4c5af7fb070a16f44a7ad2c3c7c39c77320d343f5c2384a44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Woo")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151107")[#strong[#text("Alexander Woo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("Are you kidding? Out of my ten or so papers, I think only one takes less than 2 full days to read carefully.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151143")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("I agree with Alexander, and find it hard to believe that these suggestions can be made by anyone with any experience of refereeing or copy-editing.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Accountability")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150362")[#strong[#text("Accountability")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("On the same basis PIs cannot book 5-star hotels, 1-st class flights, or limousine rides and pay for them with their NSF money, the tax-payer money SHOULD NOT go to publishing companies with unreasonable, unwarranted costs.")

#text("If some snobbish researcher wants to be on board of Terry’s 750-dollars-a-paper experiment, then they should pay out of their own pockets!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151181")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Then no public university should ever subscribe to Crelle, JCTB, Inventiones, …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Idea!")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150365")[#strong[#text("Idea!")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2012")])]

#text("Since, apparently, there are too few publishing options, let’s create a top journal and to make it even more elitist let’s ask for $750. Damn! Elsevier is starting to look like the good guy here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150509")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("It’s unfortunate this post has gotten so many vitriolic anonymous comments whose main content is personal attacks…")

#text("I’m a grad student and I don’t think $750 is all that much. For comparison, my impression is that fees for “publishing” a thesis at Cornell are something like $200. Has anyone done some kind of calculation for some for-profit journal to estimate their gross revenue (from library subscription fees) per paper? (I suppose bundling could make this difficult.)")

#text("One benefit to the community that I didn’t see mentioned above is that a fee to publish papers would encourage authors to write fewer papers and to make them higher quality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0400076dc057edec8e589d61f82aa09f2ad678d733f172986432c23791c9fb69-04792883ed12fe6555927c881fe80c2f011f37d6ac74323047454ce0604dc4f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bobito")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150946")[#strong[#text("Bobito")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("Petper: I’m a professor in a European university and $750 is nearly half my monthly take home pay.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150554")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("I’m really surprised at the number of sockpuppet anonymous responders polluting these comments. I was under the impression that members of the mathematics community were more thoughtful. Of course, if they are not members…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Plato")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150578")[#strong[#text("Plato")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("If they are not members, then they could be thoughtful or not. Because the fact that p => q doesn’t imply that q => p.")#linebreak()#text(" I agree, I thought that the contributors to this blogs would be more thoughtful, or at least, more logically savvy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150565")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("“but authors, upon their paper being accepted, be asked to pay a publication charge to cover costs. The publication charges will be set at zero for the first three years, and then raised to somewhere around £500 GBP or $750 USD after the initial three-year period (with fee waivers available for authors from developing countries)”.")

#text("Well, count me out then. If you pay that amount TO the authors of accepted papers and charge half of it as the fee for every SUBMISSION, I’m willing to consider this model. But the idea of paying for the opportunity to share one’s work with others is revolting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/762147f87d5f3807bb0e2aae39b62a7c9ea16e249553e49a1541132b9375bfa0-45a35fce32fe84d4c5af7fb070a16f44a7ad2c3c7c39c77320d343f5c2384a44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Woo")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150576")[#strong[#text("Alexander Woo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2012")])]

#text("When a mathematician gives a talk at the Joint Math Meetings and pays a registration fee, he or she is also paying for the opportunity to share one’s work with others.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0400076dc057edec8e589d61f82aa09f2ad678d733f172986432c23791c9fb69-04792883ed12fe6555927c881fe80c2f011f37d6ac74323047454ce0604dc4f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bobito")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150947")[#strong[#text("Bobito")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("@Alexander: when someone pays money (registration) in order to be able to give a talk, he is paying to have something to put on his curriculum. Most talks are invited. I’ve never paid money to give a talk.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("Fedja,")

#text("I think your proposal has some serious issues. First of all, just to break even the journal would need to reject 1/2 of its submissions. If the processing costs for publishing a paper is truly $750 (as CuP contends), then the journal would need to reject 3/4 of the submissions. These would need to be hard quotas independent of quality just to keep the journal afloat (and may even need to vastly fluctuate over time in sympathy with the journals cashflow needs). If we moved to this system on a larger scale the average paper would need to be rejected 3 times for the system to be sustainable. There are cranks out there who might feed a little money into the system this way, but not nearly on the scale to make this sustainable. Under this model, the burden of paying for publishing would be pushed onto those who frequently submit their work to journals with a borderline chance of acceptance (aka young people without permanent positions). This would also create a large advantage for those who have the resources to afford to gamble on borderline submissions.")

#text("In addition, this all assumes that accept/reject decisions are always fair and meritorious. Certainly I do not feel that my best papers are the ones that have gotten into the best journals (and I have heard well-known mathematicians make similar claims).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec8edcceee579044885607b9828977a295054a9f1a48db68b7c94eb72bfd7371-7cd695b11676f5787375be785118177eff6a90f25ed3d5ef2f542b34e6d621c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr Shalit")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150607")[#strong[#text("Orr Shalit")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("I think that this is completely in the wrong direction. The only reason for submitting papers to journals nowadays is to obtain a stamp of scientific credibility. The option of putting these stamps of credibility up for sale is wrong. It is ethically wrong regardless of math, and it is also a bad idea practically for math.")

#text("Re Alexander Woo – in the case of Pi and Sigma, people will not be paying for the opportunity to share their work (this they can obviously do), but to buy some of the respectability that comes with the names Cambridge, Gowers, Tao. (And by the way, of course I believe that conferences without registration fees are better, but in any case I think it is fair to be asked to pay for my coffee and cookies).")

#text("I think that copy-editing and type setting are truly added value, and I am very happy that some more people will be able to make a living off these journals, but funding this by a morally wrong procedure is not the way. A better idea would have been to open this new journal (which seems to have some other very worthy novelties) at a low subscription cost, with the developing countries waver given to developing countries universities, for example.")

#text("Maybe the following thought experiment can help explain why I think that buying and selling stamps of credibility is wrong. Imagine that Elsevier would have announced that due to the ongoing concern about their relationship with mathematicians (bla bla bla…) they are moving Journal of Functional Analysis and Journal of Algebra to gold open access. Maybe they would also offer that for the first year the APC will be 0$. How would have this been accepted by the community? As a step forward?")

#text("This new journal endorses the gold open access model, and this wrong cannot be made right no matter how generously and responsibly this single journal is going to be run.")

#text("If prominent mathematicians wish to support (true) open-access, then I suggest they submit their next big papers to existing (true) open-access journals, such as New York Journal of Math or Banach Journal of Mathematical Analysis (I am not familiar with others), and help them gain credibility.")

#text("I think that opening this new journal in this way, which is gold open-access but for three years will be 0$ cost, with a dream team of editors, is a kind of slap in the face for existing true open-access journals, or for independent “middle of the road” journals that have been struggling to keep prices reasonable.")

#text("One last point, regarding Terry’s remark that he is experimenting with different models: It is one thing to experiment with, say, using MathJax on your blog, but it is another thing to take action in the real world. Action which has moral and practical significance cannot be excused as experimentation, it has to be thought out carefully and backed up by values. And this is completely different from the Annals experiment mentioned above because they at no point gave legitimacy for a wrong practice. I have no doubt that the mathematicians taking part in this initiative are trying to act according to their noble values, but I am worried that perhaps they got confused between the blog-sphere and the real world, and are experimenting haphazardly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-152290")[#strong[#text("Yiftach")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2012")])]

#text("I fully support Orr’s comment.")

#text("This model shifts the control over publications from the authors to administrators. Suppose that I have no research grant and in my department there is a limited budget for publications. This means a decent paper might not be submitted to such publications. At least in the current model I have control over where I submit my papers.")

#text("I also want to add that while the people involved in this project all seem genuine about improving things, what will happen with the next journal in this model with say another publisher? There is too much motivation in this model for corruption which means corruption will happen.")

#text("Another point is what will happen if these journals fail and people will not pay for publications?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150616")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("“When a mathematician gives a talk at the Joint Math Meetings and pays a registration fee, he or she is also paying for the opportunity to share one’s work with others.”")

#text("Correct. That’s why I never go there unless the registration fee is waved and all expenses are reimbursed.. My position is very simple. I’ve done the work, the other people want to see it, so it is they who should pay, not I. If they are not interested enough, well, they can do it themselves. When I write something for a journal, I have enough pride to consider my name on it as a sign of quality and I’m willing to put my money where my mouth goes, so the submission fee is fine with me: if the paper is found later to be of inferior quality, it is my fault that I lost the money. However, if the people agree that what I’ve done is a quality work, I should be paid for it, not the other way around. This isn’t called “moral” or “ethics”. This is called common sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Contrast")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150645")[#strong[#text("Contrast")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("Remind me again, what $750-an-article journal did Perelman publish in? What $1,000 journal is he now putting together?")

#text("Talk about alternatives to the status quo…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150682")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("ArXiv is a great step forward on the way to free access to mathematics, no doubt. I only wish it would be used by more good mathematicians and by fewer bad ones. That’s the answer to the first question. As to the second one, he is not putting together any journal, $1,000 or $-1,000. Terry and Tim try to set up something general and highly reputable at once. They do need to balance the budget, no question, so the money has to come from somewhere. It is not the idea that someone has to pay that bothers me here. That I accept. It is the idea that they try to get money from the people who will be doing the most important work for them and on whose cooperation they depend more than on anything else. No matter what the editorial board is, if there are no good articles in the journal portfolio, it soon becomes junk and once that happens, there is a strong trigger effect that prevents it from getting back on track. To get money, you need to sell something to someone, not to squeeze it by force or by appeals to sympathy, morals, etc. The latter ways may work on occasional basis but not on the regular one. So, the question to which it all boils down is “What and to whom are they going to sell here?”. Until that is answered, the scheme is financially doomed. It can live for a while on the enthusiasm of the organizers, but it isn’t sustainable. If in the “author pays” scheme Tim and Terry are going to sell their reputation, as Orr suggested, then there will be no qualified buyers: all mathematicians whose papers increase rather than decrease the journal quality have their own and, as far as I can tell, most of them have severe problems with converting reputation to money, not the other way around. So, IMHO, we’d better look elsewhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/762147f87d5f3807bb0e2aae39b62a7c9ea16e249553e49a1541132b9375bfa0-45a35fce32fe84d4c5af7fb070a16f44a7ad2c3c7c39c77320d343f5c2384a44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Woo")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150695")[#strong[#text("Alexander Woo")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("Here’s the problem: the practical value of pure mathematics research is pretty close to $0. It’s really an established cultural art form supported by patronage, just as the opera is mostly supported by patronage. (Actually, opera has a lot more entertainment value than mathematics research, and not significantly less practical value.) It is true that, unlike in the 18th century, most patronage comes from the government rather than wealthy private individuals, but that doesn’t make it not patronage.")

#text("Patronage fundamentally comes not by selling something of value to someone but by appeals to sympathy, morals, vanity, or the like.")

#text("For the record, I definitely support patronage both for the opera and for mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/041e0d8efb404a6a2cf18b2270a848edf2c64e454a9f79bc7b5042d769355180-62fe160b29fccbce5500ff3d0ac989c0d3a0e9678d38be9c88331b114d02c1d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2012")])]

#text("“To get money, you need to sell something to someone, not to squeeze it by…”")

#text("As Alexander points out, the market value for access to a (even a high quality) math paper is close to $0. If you do not believe this the next time you prove a theorem put the statement of it on your webpage and see how much money you can make selling copies of the proof.")

#text("If you assume the role of a journal is to distribute results then it is the reader who is being provided a service. Today (in the era of the Internet and the arXiv) the role is rather to provide a certification of the level of quality of a paper. This is indeed a service to the author (and is an essential service if you plan to apply for jobs, promotions, grants, etc).")

#text("If you acknowledge that journals have become a `certification service for the author’ rather than a `delivery service for the reader’ then (in accordance with your argument) it seems natural to align the point of payment with the person consuming the service (or more precisely, the institution of the person consuming the service).")

#text("(That said, I still would like to see much more justification for the $750 price tag and clarification around what circumstances will merit a fee waiver before I am comfortable with this particular proposal.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-150799")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2012")])]

#text("“Here’s the problem: the practical value of pure mathematics research is pretty close to $0.”")

#text("Actually, the practical value of everything is $0$, including the human life itself. The question you ask on the market is not “What has (practical or whatever else) value?”, but “What sells to whom?”. I agree that you will have more trouble selling tickets to a math. lecture than to a football match to the general audience (though I doubt you believe that a football match has significantly larger value from any point of view). Moreover, I agree that even mathematicians themselves are quite reluctant to buy, or even to read other people’s proofs unless they need it for the particular problem they try to solve themselves. Frankly speaking, I do not really know why I still publish anything at all (most of the time it is my co-authors that force me). However, maybe, I’ll try to put a proof on e-bay one day for sale (whoever pays gets his name attached to it and gets the right to publish it and to get all the credit) to assess the market value of a math. theorem. I’m just too lazy to do it right now :).")

#text("“If you acknowledge that journals have become a `certification service for the author’ rather than a `delivery service for the reader’ then (in accordance with your argument) it seems natural to align the point of payment with the person consuming the service”")

#text("Sure. I do not argue with that. However, as I said, I do not need this kind of service myself and I doubt any mathematician with minimally established reputation needs it either. If this is supposed to be a journal for publishing opuses of ambitious grad. students and postdocs, then I see no problem whatsoever (except that grad. students and postdocs usually do not have that much of free money).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("I feel there is an obligation for academics to publish their research in an open access format such as this new journal or arxiv. This obligation stems from the support universities receive from public taxes in the form of grants or direct funding in the case of public universities.")

#text("The academic is not an independent who creates something for sale to the highest bidder. He has, instead, accepted a salary and possibly a tenured position to teach and do research that should be avilable for all.")

#text("The question of how much one should pay to publish is a legitimate one, but I see nothing obnxious with a journal that asks the author or the author’s insititution to help shoulder publishing costs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-153870")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2012")])]

#text("And how many taxpayers would exercise this putative right to read Inventiones?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-154268")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2012")])]

#text("I would, should my honorary position not be renewed and I hadn’t an academic job…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef923ef071082eddff8770534355ccbfa2a94608a36a9220d4ad4c80b511de04-254a17b6419319f84393641f6f3db006bafdf2f8de79da6e190bf4fc8b38bdef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-154455")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2012")])]

#text("So would my friend Phil Brooker, FWIW. It is however not clear to me that the two of youse are what the louder cries for “taxpayer access to taxpayer-funded research!” usually have in mind (and you both know people who can get their hands on any particular paper you need, unless you are telling me that you read Inventiones on an ongoing basis…)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/133755780b56fd1a8a37beac0471e8bac8a9bdf48835ca384aae9b0749300d34-18201dd24e44ad841d60fbf742f9d526a9e9257b78432e343b6293ce4bf3f899.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quantummoxie")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151219")[#strong[#text("quantummoxie")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Shifting the cost from subscription fees to publication fees only solves half the problem. It allows the research to be publicly disseminated but still keeps costs unreasonably high for researchers in not just developing countries but also at smaller institutions. In the quantum information & foundations community, we have a number of major contributors to our field (e.g. Ben Schumacher who coined the word ‘qubit’) who teach at these institutions.")

#text("Frankly, given that editors and referees are not paid for their services and given the success of the completely free arXiv, I am a little surprised no one has developed a 100% free electronic journal (or at least one that people have heard of). Toss in a discretely placed ad here or there and it seems as if it would pay for itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97c379768e90d015546d67ff23f140962b03db463d136511fa6f4c1a81695584-dd1f2444daf133c9430d97602192e5113b0fb9599318bb2f7369aaa11f4a4179.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Marks")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151251")[#strong[#text("Greg Marks")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Minor point: on the Forum of Mathematics FAQ sheet, I think Richard Taylor’s affiliation should be listed as Institute for Advanced Study. ")#emph[#text("[Will forward this onto the CUP staff – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f99afad0427f4cfa3af77c57f81833f7886bc496fb37e4ad56b96efe544f1e24-4500611f16b62429ce3e34cac89d417823a028776f48257e25bf555606c13f33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jörg Neunhäuserer")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151399")[#strong[#text("Jörg Neunhäuserer")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2012")])]

#text("Dear Terence Tao,")

#text("I also do like the policy of classical mathematical journal. They try to sell my papers for 20-40$ for a download, which is too expensive and I as the author get nothing from this. On the other hand, if I got things right, I do not like the publishing concept You prefer. The author should pay that his paper is published? That is completely unacceptable for me. In Germany I get no money for research, I am only paid for lecturing math and not at all good. So how should find 750$ or whatever for publishing a paper?.")

#text("I would prefer the following two publications concepts:")

#text("1. An open access journal which takes no money from the author and is funded by the community (like ECP and EJP)")

#text("2. A journal which takes, lets say, 2-4$ for a paper from each reader and pays, lets say, 0.5-1$ from this to the author.")

#text("Very Best")

#text("Jörg Neunhäuserer")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/762147f87d5f3807bb0e2aae39b62a7c9ea16e249553e49a1541132b9375bfa0-45a35fce32fe84d4c5af7fb070a16f44a7ad2c3c7c39c77320d343f5c2384a44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Woo")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151510")[#strong[#text("Alexander Woo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2012")])]

#text("I think you vastly overestimate how much even a fairly good paper is read.")

#text("Even at $4 a paper, people would only read papers they had some nontrivial reason to read. I think even an [i]Advances[/i] paper would average no more than 20 readers. Certainly one would not get 200 on average, which is what it would take to net something like $750.")

#text("I can imagine a mathematician reading 20 papers for every one he or she writes. (Counting only research papers and counting going through the introduction thoroughly as reading, I probably come closer to 10.) I cannot imagine a mathematician who reads 200 papers for every one he or she writes.")

#text("As for a completely free journal like the [i]Electronic Journal of Combinatorics[/i], I think that journal has already taken the only half dozen combinatorialists willing and able to do for free the mostly secretarial job they call “Managing Editor”, so there won’t be a second such journal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f99afad0427f4cfa3af77c57f81833f7886bc496fb37e4ad56b96efe544f1e24-4500611f16b62429ce3e34cac89d417823a028776f48257e25bf555606c13f33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jörg Neunhäuserer")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-151717")[#strong[#text("Jörg Neunhäuserer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2012")])]

#text("Dear Alexander Woo,")

#text("1. I did not mean the Electronic Journal of Combinatorics but the Electronic Journal of Probability and the Electronic Communications in Probability. So we now have three journals that are free of economics. I think there are more than this, and I hope there will be many journals just for public utility in the future. I think the concept fits good for journals that are only electronic. I myself think about founding the Simplizissimus a E-journal for simple proofs.")

#text("2.Your economic reasoning may be right but a mathematical journal should not obey the market-economy. It is the task of the international society to support our journals and to fill in the gap between coasts of publication, a good price for readers and the payment of the author. Of course new insight in mathematics (and many other areas) and their publications has a higher value than economic interests of people.")

#text("Very Best")

#text("Jörg Neunhäuserer")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-153510")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2012")])]

#text("Asking money directly to authors I think is unethical. I have no doubt on the good purposes of the editors of these journals but they should not have accepted to be part of them. They were in the position to ask the universities to organised themselves as a consortium to cover the costs in the first place, leaving the publishing cost issue out of the responsibilities of the authors. Instead they are here talking about experimentations and assuring us that they will do everything they can to apply fairness. I appreciate that. But the model is clear at the moment: Classic Gold open access. I do not buy the idea that people will produce less papers with higher quality. With this model, the more the papers accepted, the better (for the “cashier”).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-155526")[#strong[#text("CUP’s “Forum of Mathematics” Open Access Journal | Aleph Zero Categorical")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2012")]

#text("[…] or she does not have access to these funds. There have been extensive discussions on the blogs of Terence Tao and Timothy Gowers, and these discussions have surprised me with the amount of negativity towards […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ee31510df3f52ddca255a2c79ef510e7dc7a86dc8c85bea96dc61603bc82fb4-eff6a90e4f17430e38242055ed1521ae6d9404483ee9181743cb8a1cc2719830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicola Arcozzi")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-157131")[#strong[#text("Nicola Arcozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2012")])]

#text("Having two new high level math journals free for readers is good news, but article charges are too high. You might have in the same Math. Dept. researchers who can pay and researchers who can not, possibly just because they have grants subject to more rigid rules.")#linebreak()#text(" Something which ought to be out there is an arXiv-like platform collecting reviews of articles posted in the arXiv. Such reviews should be signed by their authors, who will take full responsability for what they write. For instance, I read an article, I find it important or useful and I write a (signed) review of it. Or I find a counterexample to the main theorem… Such a platform would be synergetic with the Arxiv.")#linebreak()#text(" Nicola")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d13918ef9f22956fbcd9b9a912ddd47fa9514b783193c321c0fa1f369cff4c1-7154fd69c9ab960ebc666fa03dce79abfd0d7acd3640136a63ccf46879d3e4e9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-164915")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2012")])]

#text("Personally, I do not like the idea of paying for publication. I am open to arguments, but I am surprised and upset that such an important change is presented to the community as a result and not a suggestion in one of the many discussions about this topic. (Maybe I missed the decisive one?) Why is the mathematical community faced with such fundamental decisions without any open discussion before hand? Great effort is made to blog mathematical news, discuss the future of publication in mathematics, and to mobilize the community with good arguments to join the Elsevier boycott? Why is there no effort this time?")

#text("At the same time, this “experimenting” has an enormous influence on the perception of the Elsevier boycott. It has been beneficial for the boycott (in the perception among mathematicians and others) that there has not been the slightest sign that commercial interests could play a role to boycott Elsevier. I think that this still is the case, but now it is much more difficult to explain if the pioneers of the boycott support an alternative commercial model, asking the community to pay for their own work. 750 USD for a paper in an electronic journal, that sounds ridiculous to me; given that all the type-setting and proof-reading is done by the community.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-164922")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2012")])]

#text("Since nobody is forced to submit to FoM, the launch itself is a suggestion. If the community is not interested in this model, then there will be too few submission for FoM to survive on the long run without changing its model. The inertia of academics is so great that to advance, one has often to try things rather than discuss them endlessly.")

#text("Concerning the justification of the price, you seem ill informed. *Not* all the type-setting and proof-reading is done by the community. Right now, for the second time in my life, I have to compile a volume of proceedings, and it is difficult to realize the amount of work it represents before doing it. 750 USd represent, with charges, equipment and so on, what? 15 to 30 hours of qualified work? This is decent, but not huge to deal with the average paper written by a mathematician, if I judge from the source I’ve seen so far. It is the price paid by Geometry and Topology to have 25 pages typeset (and only this, do not forget that organizing peer-review and making articles available have some cost too).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d13918ef9f22956fbcd9b9a912ddd47fa9514b783193c321c0fa1f369cff4c1-7154fd69c9ab960ebc666fa03dce79abfd0d7acd3640136a63ccf46879d3e4e9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andreas Thom")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-164940")[#strong[#text("Andreas Thom")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2012")])]

#text("I do not want to discuss “endlessly”. It seems to me that before hand there has been not discussion at all about this option.")

#text("Maybe you are right and 750 USD is justified for the production of a publication. However, paying a justified amount when buying the journal seems to me much more reasonable. The initial problem was not that nobody would want to pay for the production, but that certain companies would charge too much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-164956")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2012")])]

#text("There has been discussions in a variety of places, including on the Internet, for quite some time now; maybe mathematicians where not involved enough, but this is our own responsibility; I am not sure to see which place could host a community-wide discussion about this kind of issues (except maybe the blog on publishing and journal ranking launched by the IMU and that only gathered a few dozen comments). Moreover, I think the discussion is much more vivid now that a journal is announced and that we can discuss specific details (like the price).")

#text("What you call the initial problem is only one aspect of the many issues we currently face regarding scientific publishing. For example, a journal like Journal of Topology has a hard time selling as many subscription as Topology did, while it was founded by the very same editorial board and is much cheaper than Topology was. Several journals that are not kept behind the bundle of a big commercial publisher face unsubscriptions. More importantly, many researchers cannot access all the articles they want and need because their library cannot afford to subscribe to everything: Open Access has a tremendous value.")

#text("One striking aspect of this is that I learned from one of the Springer executives that Inventiones had much fewer subscription than in old good days (something like 200 instead of 800, but my memory is not very reliable). Since there are probably not be that many department closing nor university libraries merging, this means that far fewer people can access all Inventiones papers today than people that felt they where interested a few decades ago. Of course Inventiones is expensive, but still one of the last one would want to unsubscribe.")

#text("Overall, I am convinced that the Gold OA model announced by FoM should not be used widely in math, but there is certainly room for several models and a urge to experiment before we have no choice left.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-165666")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")])]

#text("–15 to 30 hours of qualified work? This is decent, but not huge to deal with the average paper written by a mathematician,– Is this ALL the publishing folks put into a paper???? Then they owe us quite a lot of money! The average amount of work that goes into creating a math. paper is a few hundred hours from getting the problem to finishing the typing and proofreading (and that is if you are lucky with finding a solution quickly; if not, you start counting in years, not in hours).")

#text("–It has been beneficial for the boycott (in the perception among mathematicians and others) that there has not been the slightest sign that commercial interests could play a role to boycott Elsevier. I think that this still is the case, but now it is much more difficult to explain if the pioneers of the boycott support an alternative commercial model, asking the community to pay for their own work.–")

#text("Actually, it is not “much more difficult”. It is just impossible. There have been ugly rumors already that the Elsevier boycott was there to benefit Springer. Normally, when hearing that I would just shrug my shoulders and reply “That’s bullshit!”. Now all I can say is “Well, I don’t know…”")

#text("–urge to experiment before we have no choice left– Can you elaborate? Who’s going to leave us no choice and with what army?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-165731")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")])]

#text("Dear Fedja,")

#text("I see a inconsistency in your comment: you seem to think both that publishers as CUP should put more than 30 hours of qualified work in each of our paper, but that 750$ is a huge price for us to pay for this work. One can consider they should do less work (no additional typesetting, etc.) and charge much less, or work more and charge more, but it seems not consistent to ask them more work for less money (at least in the case of FoM and given the figure we are considering).")

#text("Several people here seem to make a confusion: the money paid to the publisher is not for the research, it is for the publishing! The research work is paid to us by our institutions (at least for the lucky ones that have a research position, which are the vast majority of authors), and given the average salary of a researcher in most research-intensive countries and, as you stress, the amount of time we need for one paper, we are paid for each paper a pair of orders of magnitude above the price of its publishing in FoM. This is of course completely right, but we should not forget there are two kind of works, that are legitimately done by two different kind of people with different competences, and paid independently.")

#text("Concerning the potentially commercial exploitation of the boycott, it stuns me that this comes out for a new journal that will earn much less to CUP than most of the other journals. If Professors Tao and Gowers where entering in a comity of e.g. Crelle’s journal, no one would have blamed them. But this is one of the most expensive journals in math, it sucks a awful lot of money from our libraries!")

#text("Concerning my sentence on the urge to experiment, one has to consider the following facts :")#linebreak()#text(" 1. we are in a green OA situation (meaning we have the right to put our preprints on the arXiv),")#linebreak()#text(" 2. not everyone does this, though,")#linebreak()#text(" 3.even Ann. of Math. failed in maintaining subscriptions when it tried to put all its accepted papers on the arXiv,")#linebreak()#text(" 4. the UK and the EU are already taking big steps in the direction of mandatory open access, and the USA could very well follow closely.")

#text("From 4. and 1., I deduce that in a few year, all math paper will be on the arXiv, which is a good thing of course. But from 2. and 3., I deduce that this will represent a big threat to subscription journals. So, there will probably be a point where big commercial publisher will have to charge us in another way to continue their business. Since they charge around 3000$ a paper for many of their open access offers, and right now they get even more than that from our libraries, I guess that if do not have alternatives at that point, we will still be stuck dealing with these kind of offers.")

#text("That’s why I think we should, right now, put together alternatives.Of course, the best thing would be to have journal funded by academic institutions (e.g. universities, redirecting the subscription money and library workforce to internal publishing). But FoM makes a good point : in principle, if in three years it secures funding directly from institutions, then it will be able to waive the fees indefinitely. We should better push in this direction than constantly blaming people that do something for us.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcb476221e7301fa673c4c590611ddefefe7faf2f946ff10ed02a89ac25d447d-96ce30ed98947948eed257ad227a565402c049bcd631fa4c00c0b028831047fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl Smith")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-166212")[#strong[#text("Carl Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2012")])]

#text("Dear Benoît,")

#text("as I can tell from personal experience, it does not take 15-30 hours per paper to do just the technical part of the publication process. However, a vast amount of time is eaten up by the refereeing process if the referee takes the task serious and actually reads the paper.")

#text("As I understand the concept of FoM, the referee is still not paid for his/her work. You might argue that being a referee is part of research (\\”quality garantee\\”) and thus automatically covered by his/her income. But then I consider also the typesetting and other administrative tasks of the publishing process as part of research (\\”dissemination\\”).")

#text("After all any published article will be handled by two very low paid researchers, namely the review writers for MathSciNet and Zentralblatt.")

#text("So how does it fit together that an author should pay a serious amount per paper to get published but the referees and reviewers do not receive anything from this money?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-166788")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2012")])]

#text("My only personal experiences with the technical aspect of publishing math papers was to compile proceedings, and I confess that while it seemed incredibly long to me, it was probably only a few hours per paper and would be quicker with good habits and working flow — but I only had to compile them, I did not do proper copy-editing and had no peer-review to organize. So I would have a hard time guessing if 15-30 hours, or 750 dollars, is much for taking care of a paper, if I had no figure – but it happens that G&T (which, being one of the cheapest math journals, must be quite efficient) spends $50 a page to publish its articles, so $750 seems not that high given the average length of articles. It is often overlooked that, while scientific editors and reviewers are not paid, (groups of) journals often employ assistants and sometimes managing editors to deal with the organization of peer-review and sysadmins for web and hosting aspects, in addition to copy-editors.")

#text("The point is that the $750 are (probably, but CUP plans on making the details available) here to pay for these people, and the figures I have seem to let little margin in the current publication process. We have a lot of options, for example:")#linebreak()#text(" 1) dropping copy-editing or other services to lower prices,")#linebreak()#text(" 2) do more of the tasks on researchers time to lower prices,")#linebreak()#text(" 3) raise prices to pay authors and reviewers,")#linebreak()#text(" 4) do 2) and 3), shifting some burden from referees and authors to editors,")#linebreak()#text(" 5) shift all journals to publishers that ask decent prices (because sure, a lot of editor ask for far more than really needed, as the discrepancy between prices shows).")#linebreak()#text(" But saying both that $750 is too high and that at that price, authors and referees should be paid in addition to their institutional salary while keeping our current publishing process, seems inconsistent.")

#text("I understand that the Article processing fee system is not welcomed (I am not a big fan either), but I really do not understand why there is such a big deal about the amount itself. Again: each time we publish now, we make libraries around the world spend much more money. And how is it that we are happy when we work on expensive beautiful campuses, but we do not want $750 to be spent to process an article we have dedicated months to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-167317")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2012")])]

#text("Dear Benoit, as someone who wrote 12 to 14 papers before landing a tenure-track job, I am less sanguine about author charges than you appear to be. Also, as I have said elsewhere, if we save universities money, then who says the saving is passed onto our department, or us as researchers? The money set aside to pay researchers an allowance for author charges will I fear rapidly be directed/focused/targeted on those doing “productive research”, and guess what, cohomology of Banach algebras can’t compare with work on species of grain.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85a188b385a378b90299ed773ab1af8bd6b68720a58f3c1a01880221a92773ea-0f6bee3bb8f9ca5c929594aa64a739946773ec2f7e24c059441b8fe685297059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiftach")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-167487")[#strong[#text("Yiftach")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2012")])]

#text("There is actually a good chance that the money will go to buy a yacht for the vice-chancellor or some similar important spending.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83d96e7c8c96d50373c16adc05ffdc481068318f19d01c35f33dbf86af20cc59-49eb4a9ab4a203065f352353af9896244ac4db2c7bdcf7e3cc5be30ab6ba8c3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-175308")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("Dear Benoit.")

#text("Let’s face one truth: we are *not* paid for our research. What we are paid for is teaching low level undergraduate courses. That’s where the math. departments get the main bulk of their money. The rest is grants. That this money is *distributed* taking the research into account is, of course, true, so it creates a perception that we are really rewarded for doing better research, but this is merely moving the money from one pocket to another. If everybody suddenly became an equivalent on Terry and Tim together, there would be no salary increases, just bigger headaches for the personnel committees.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-175608")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("I am unable to give this more than one “thumbs up”, so this comment is merely intended to signal several more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903f9a03317aee81859a63c4241bb0ac07326fd36194a636db9fc87b46f3695c-6e66b1d5cffc06673abb9a55b82805cdfe03a2d05dd6eabbde5f7435793af632.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoît Régent-Kloeckner")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-175609")[#strong[#text("Benoît Régent-Kloeckner")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("Dear fedja, I have quite strong evidence that I am paid for my research. In my department, some colleagues have teaching-only positions, and they teach more than twice as much as I do, not being paid more than me. Some other colleagues have similar salaries and research-only positions. The status of my job is also quite clear about the fact that I should devote half my time to research. Given the budget of French universities, if the state was not willing to pay for research in math departments, we would replace all leaving professors and assistant professors by teaching-only position; it is actually quite the opposite, the few teaching-only positions leaved being often replaced by assistant professor ones.")

#text("Anyway, this does not change much my point: either we want to live from royalties from our published articles, and the publish-or-perish we currently face is nothing compared to what we want, or we accept that the money related to publication is to pay for publishers work, not author work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-175591")[#strong[#text("Worse than Elsevier « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")]

#text("[…] has been my opinion for a long time, and it didn’t change when Gowers and Tao joined the bad guys. Here’s what I think is bad about the publishing model where authors pay to have their papers […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/086aa16f3413461278e99eb4e210709674ff13e296c4cb47973987f3fab21b5d-f0baba68fddbb8f2f0f16c8f89aeca33d2257f97ce836767578d5a2e3bc8a806.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thalinda")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-199480")[#strong[#text("Thalinda")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2012")])]

#text("It seems everybody needs to earn a living. I do not agree with paying for publishing….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Journal of very short papers « chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-207546")[#strong[#text("Journal of very short papers « chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2012")])]

#text("[…] the information is packed in the references. Let’s take this to extreme (idea inspired by this comment which I made at this post by Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-208836")[#strong[#text("Worse than Elsevier, worse than … « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2012")]

#text("[…] really hope that mathematicians will not flock behind the leaders of this initiative. The overall impression I get is that my hopes are hopeless. So here is one last cry: you are going in the wrong […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-214031")[#strong[#text("Dr. Gowers and Mr. Hyde | AMS Graduate Student Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2013")]

#text("[…] journals Forum of Mathematics, Pi and Forum of Mathematics, Sigma. Both Timothy Gowers and Terence Tao discussed their involvement with this project in July of last […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-219876")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2013")])]

#text("Do you happen to know how the two Forum of Math journals are progressing? In particular, do you happen to know when one might expect their first set of articles to be published?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-220009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2013")])]

#text("Sigma has about a dozen articles in various stages of the refereeing process, and accepted articles should be appearing soon on the site. Pi has one or two serious articles in process currently, and will probably take a bit longer given that these articles need particularly careful refereeing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-221106")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2013")])]

#text("I just wanted to thank you for getting back to me.")

#text("David Lowry-Duda")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2570b3bcc477a2284bcbacb55170c13731a58aa12639939924ad7ba65c7c561-087155c33396edf249cc212943cfcbe20681308939f6354f13e9bde81e820db9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan diego")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-220164")[#strong[#text("Juan diego")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2013")])]

#text("a question Terence Tao")#linebreak()#text(" you’re my idol ,I have eleven years old and I’m from Latin America")#linebreak()#text(" you know math books of advanced mathematics and quantum free books on the internet, help me please")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa8e0026304bde0f0335731a84ccbdbd60b2de97830af815694eae4db91ec8ea-3cf2a76b6c008bca6d7c5aa49697694f074fc6a07bc98dca6b68efdb2d60ac2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-220210")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2013")])]

#text("Juan, this page of ‘t Hooft may be helpful:")

#link("http://www.staff.science.uu.nl/~hooft101/theorist.html")[#text("http://www.staff.science.uu.nl/~hooft101/theorist.html")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a2bf7d2b385a1ef843ae75f9c9d71cbb65b343c649e0d6a115414d97a723dc1-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dims Vs")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-459633")[#strong[#text("Dims Vs")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2015")])]

#text("Diophantine equation with 3 variables")#linebreak()#text(" ")#link("http://www.abakbot.ru/online-16/281-diofantovoe-uravnenie-s-tremya-neizvestnymi")[#text("http://www.abakbot.ru/online-16/281-diofantovoe-uravnenie-s-tremya-neizvestnymi")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97d28670d589b1245e0d9f80c9f27be85522fa102ad805d781492987bcbe0f97-479fffa787999cfc4bb170095cfa126530e22a16aa674887f338fe46738b2e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The status quo of math publishing | Igor Pak's blog")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-513974")[#strong[#text("The status quo of math publishing | Igor Pak's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2019")])]

#text("[…] Sigma charge $1000 per article for “processing”, whatever that entails. Terry Tao wrote that this hints at “alternatives to the status quo”. Maybe. But how exactly is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1554f96095900d814ad00c4c9014f1f9aec19855eb4bf86da7abc79d3ff4c93e-96f69990a880a02228eeff1db90ca0c79546c382b286050f43d91d631ca7ae3c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-637607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Dear Professor Tao, I was wondering why the generic journal is called Pi and the cluster is called Sigma. I feel they sort of make sense but was wondering if you could give an official answer.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-637614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("My understanding is that Pi sounds like pie, the food people eat. And pie is very basic, for the general public.")#linebreak()#text(" Sigma is the summation sign used in series, so it makes sense for the cluster to use this name.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marcel goh")]], [#link("https://terrytao.wordpress.com/2012/07/02/forum-of-mathematics-pi-and-forum-of-mathematics-sigma/#comment-687972")[#strong[#text("marcel goh")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2025")])]

#text("Being a (relatively) new researcher, I just spent an hour or so perusing the various threads and controversies surrounding the foundation of these two journals. From what I gather, they have now become quite established and respected. What I cannot find any information on is when the £500 AUP idea was discarded in favour of more standard prices (the most recent figure I saw was £1850), and what the justification for this might be. To an outside observer, looking 13 years on, it really does seem like FoM just joined the ranks of the “evil” journals it was meant to replace. (I would really like to believe otherwise, so I would appreciate input from anyone who is in the know.)")
]
